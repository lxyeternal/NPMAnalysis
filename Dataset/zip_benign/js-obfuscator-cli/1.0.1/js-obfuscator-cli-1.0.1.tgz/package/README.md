# js-obfuscator-cli

一个简单易用的JavaScript代码混淆命令行工具，基于[javascript-obfuscator](https://github.com/javascript-obfuscator/javascript-obfuscator)。

## 安装

### 全局安装

```bash
npm install -g js-obfuscator-cli
```

### 本地安装

```bash
npm install --save-dev js-obfuscator-cli
```

## 使用方法

### 命令行

```bash
js-obfuscate [options]
```

### 选项

- `-s, --source <directory>` - 源代码目录，默认为 `static`
- `-o, --output <directory>` - 输出目录，默认为 `dist`
- `-c, --config <file>` - 混淆配置文件路径，默认为当前目录下的 `obfuscate.config.js`
- `-v, --version` - 显示版本号
- `-h, --help` - 显示帮助信息

### 配置文件

在项目根目录创建 `obfuscate.config.js` 文件：

```js
module.exports = {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.75,
  deadCodeInjection: true,
  deadCodeInjectionThreshold: 0.4,
  stringArray: true,
  stringArrayThreshold: 0.75,
  rotateStringArray: true,
  // 更多配置选项请参考 javascript-obfuscator 文档
};
```

## 示例

```bash
# 使用默认配置
js-obfuscate

# 指定源目录和输出目录
js-obfuscate --source src --output build

# 指定配置文件
js-obfuscate --config my-config.js
```

## 许可证

MIT