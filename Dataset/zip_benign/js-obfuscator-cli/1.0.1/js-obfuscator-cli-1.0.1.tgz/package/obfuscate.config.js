module.exports = {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    stringArray: true,
    stringArrayThreshold: 0.75,
    rotateStringArray: true,
    identifierNamesGenerator: 'hexadecimal',
    selfDefending: true,
    transformObjectKeys: true,
    unicodeEscapeSequence: true
}