import Scene from "scenejs";
import Media from "./Media";
import { MediaSceneInfo } from "./types";
export default class MediaScene extends Scene {
    private playInfos;
    constructor();
    addMedia(id: string, url?: string | HTMLMediaElement): Media;
    getInfo(): MediaSceneInfo;
}
