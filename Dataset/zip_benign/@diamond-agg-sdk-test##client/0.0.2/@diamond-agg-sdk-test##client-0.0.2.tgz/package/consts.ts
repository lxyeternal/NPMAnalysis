export const API_URL = "https://prod.diamond-agg.api.hellomoon.io";
