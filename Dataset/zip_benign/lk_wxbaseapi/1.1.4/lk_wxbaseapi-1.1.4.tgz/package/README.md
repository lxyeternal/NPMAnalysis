# 来康小程序API

## 接入方式
* 在小程序中加载 npm 包

```
npm i lk_wxbaseapi
```

* 构建 npm 包

在微信小程序开发工具的**工具**菜单下点击**构建 npm**命令，进行 npm 包的构建，此构建可以将 npm 包构建成在小程序中可加载使用的包。

* 勾选**使用 npm 模块**选项

在微信小程序开发工具的**详情**下点击**使用 npm 模块**

* 使用npm包

js 中引入 npm 包：

```
const pg = require('lk_wxbaseapi')

onLaunch: function () {
    console.log('App Launch')
    pg.setData({
      //用户中心地址
      ucUrl: "https://lk-sso-wx-qa.op.laikang.com",
      //小程序APPID
      appId: "wx6c7c1563c84d7245",
      //用户中心分配小程序Code
      appCode: "9000016",
      //小程序APPSecret
      appSecret: "edd03d885efa0e3d122513c074e85054",
      //用户行为code 带环境标识
      behaviorCode: "qa_7000002"
    })
  },
```

使用 npm 包中的自定义组件：

```
{
 "usingComponents": {
  "package": "packageName"
 }
}
```

## 简介
* 小程序基本流程
* 登录/注册
* 数据持久化
* 图片压缩
* 日志采集
* 用户行为分析


### 小程序基本流程

1.注册

  [微信公众平台首页](https://mp.weixin.qq.com)
  [小程序接入指南](https://developers.weixin.qq.com/miniprogram/introduction/index.html)
  请预先准备好先关资料：**企业资料**、**管理员资料**、以及**资质认证**相关
  获取微信手机号需通过**微信认证**

2.开发

  **注意事项**：
* 小程序基本信息修改次数有限（每人月重置）
* 服务器域名配置次数有限（每人月重置），测试、生产地址尽量一次全部配置完成，并且必须为Https,未配置的域名将无法访问。
* 小程序分：开发版、体验版、正式。合理应用区分各个环境
* 发版之前尽量在真机预览，开发工具及真机调试有时无法复现问题

3.发布

  审核周期：
    首次：0.5-1天（包含周末）

  发布方式：
    全量发布：所有用户全部升级
    部分发布：部分用户试用


### 登录/注册
* 页面：
  授权按钮（可弹框或单独授权页）

  `<button class="authorization_btn" open-type="getUserInfo" bindgetuserinfo="getUserInfo">微信授权登录</button>`

* JS：

  ```
  var loginUtil = require('lk_wxbaseapi').lk;

  getUserInfo: function (e) {
        if (e.detail.errMsg === "getUserInfo:fail auth deny") {
            wx.showToast({
                title: '您已拒绝授权',
                icon: "none"
            });
        } else {
            app.globalData.userInfo = e.detail.userInfo
            this.setData({
                userInfo: e.detail.userInfo,
                hasUserInfo: true
            })
            wx.showLoading({
                title: '',
            })
            loginUtil.login(this.loginCallBack);
        }
    }
  ```

* 登录/注册（lkLogin.login）:

```
/**
 * 根据授权获取Data登录
 * 根据微信授权登录，无需手机号
 */
var login = function loginWithPhone(callBack) 
```

* 明文手机号+验证码登录/注册(lkLogin.loginWithPhone):

```
/**
 * 根据用户输入手机号、验证码登录
 * phoneNumber：手机号
 * vCode：验证码
 * callBack（errorMes，sucessResult）：回调
 */
var loginWithPhone = function loginWithPhone(phoneNumber, vCode, callBack)
```

* 微信手机号加密数据登录注册（lkLogin.loginWithPhoneData）:

```
/**
 * 根据授权获取Data登录
 * phoneNumberData: 获取微信手机号加密数据
 * phoneIv：获取微信手机号加密密码
 * callBack（errorMes，sucessResult）：回调
 */
var loginWithPhoneData = function loginWithPhone(phoneNumberData, phoneIv, callBack)
```


### 数据持久化

### 图片压缩

* 裁剪图片

```
/**
 * 截取图片中某片区域
 * 注意：画布尺寸比例应与图片一致，避免变形
 * ctxId：画布ID
 * imgPath：图片路径
 * cvWidth：画布宽度
 * cvHeight：画布高度
 * startX：起始x（相对于画布）
 * startY：起始Y (相对于画布)
 * cutWidth: 截取宽度（相对于画布）
 * cutHeight: 截取高度 (相对于画布)
 * zoom: 放大比例
 * quality: 图片质量 0-1
 * callBack(imgPath): 回调
 */
function cutImgWith(data)
```

* 填充图片

```
/**
 * 根据图片填充画布
 * 注意：画布尺寸比例应与期望尺寸比例一致
 * ctxId：画布ID
 * imgPath：图片路径
 * cvWidth：画布宽度
 * cvHeight：画布高度
 * imgScale：图片尺寸比例
 * zoom: 放大比例
 * quality: 图片质量 0-1
 * callBack(imgPath): 回调
 */
function supplementImageWith(data)
```


### 日志采集
* 日志采集类型：普通日志、错误日志
* 日志采集策略：小程序运行时所有日志存入本地，小程序关闭或下次开启时上传服务器。错误日志实时上传告警。
* 使用方式：

```
let EnnDebug = require('./lib/index.js')

EnnDebug.default.init({
  apiKey: 'aasdfasdkl',
  url: 'https://lk-sso-wx-qa.op.laikang.com/sso/loginAndGrantAuthThirdProgram',
  getNetwordkType: true
})
```

### 用户行为分析

```
const behavior = require("lk_wxbaseapi/behavior/behavior")

//点击事件添加
behavior.addClickEvent({
          eventId: 8001,
          userId: app.globalData.lkUserInfo.userId,
          callback: function (errorMes, result) {
            if (errorMes){
              console.log("用户行为统计失败 = " + errorMes)
            }else{
              console.log("用户行为统计 = " + JSON.stringify(result))
            }

          }
        })

```

### 依赖包
* [weui-wxss](https://github.com/Tencent/weui-wxss):


```
var Fly=require("flyio/dist/npm/wx")
var fly=new Fly
```




