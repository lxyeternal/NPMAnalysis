## About

An experimental library that facilitates the manipulation of the web audio api inspired by React's Virtual DOM.

Proceed with caution as this project is still under development!!

## 🚴 Usage

```
npm i fretting

```

```
import { Graph } from 'fretting'

const vg = new Graph();

vg.update(
  [
		{
			"type": "OscillatorNode",
			"properties": [
				{
					"type": "AudioParam",
					"label": "frequency",
					"value": 440 
				}
			],
			"connections": [
				{
					"type": "GainNode",
					"properties": [
						{
							"type": "AudioParam",
							"label": "gain",
							"value": 0.5 
						}
					],
					"connections": [
						{
							"type": "AudioDestinationNode",
							properties": [],
							"connections": []
						}
					]
				}
			]
		}
  ]
)
```
