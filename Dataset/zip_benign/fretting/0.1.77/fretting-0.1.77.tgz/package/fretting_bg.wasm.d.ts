/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_graph_free(a: number): void;
export function graph_new(): number;
export function graph_time(a: number): number;
export function graph_debugger(a: number): void;
export function graph_resume(a: number): void;
export function graph_update(a: number, b: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hea5a57a80fb7b73b(a: number, b: number, c: number): void;
export function __wbindgen_exn_store(a: number): void;
