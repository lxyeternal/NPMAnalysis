import * as wasm from "./fretting_bg.wasm";
export * from "./fretting_bg.js";