/* tslint:disable */
/* eslint-disable */
/**
*/
export class Graph {
  free(): void;
/**
*/
  constructor();
/**
* @returns {number}
*/
  time(): number;
/**
*/
  debugger(): void;
/**
*/
  resume(): void;
/**
* @param {any} data
*/
  update(data: any): void;
}
