import * as wasm from './fretting_bg.wasm';

const lAudioContext = (typeof AudioContext !== 'undefined' ? AudioContext : webkitAudioContext);

const heap = new Array(32).fill(undefined);

heap.push(undefined, null, true, false);

function getObject(idx) { return heap[idx]; }

let heap_next = heap.length;

function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

let WASM_VECTOR_LEN = 0;

let cachegetUint8Memory0 = null;
function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== wasm.memory.buffer) {
        cachegetUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachegetUint8Memory0;
}

const lTextEncoder = typeof TextEncoder === 'undefined' ? (0, module.require)('util').TextEncoder : TextEncoder;

let cachedTextEncoder = new lTextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length);
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len);

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3);
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachegetInt32Memory0 = null;
function getInt32Memory0() {
    if (cachegetInt32Memory0 === null || cachegetInt32Memory0.buffer !== wasm.memory.buffer) {
        cachegetInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachegetInt32Memory0;
}

const lTextDecoder = typeof TextDecoder === 'undefined' ? (0, module.require)('util').TextDecoder : TextDecoder;

let cachedTextDecoder = new lTextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {
        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            if (--state.cnt === 0) {
                wasm.__wbindgen_export_2.get(state.dtor)(a, state.b);

            } else {
                state.a = a;
            }
        }
    };
    real.original = state;

    return real;
}
function __wbg_adapter_20(arg0, arg1, arg2) {
    wasm._dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hea5a57a80fb7b73b(arg0, arg1, addHeapObject(arg2));
}

let stack_pointer = 32;

function addBorrowedObject(obj) {
    if (stack_pointer == 1) throw new Error('out of js stack');
    heap[--stack_pointer] = obj;
    return stack_pointer;
}

function handleError(f) {
    return function () {
        try {
            return f.apply(this, arguments);

        } catch (e) {
            wasm.__wbindgen_exn_store(addHeapObject(e));
        }
    };
}
/**
*/
export class Graph {

    static __wrap(ptr) {
        const obj = Object.create(Graph.prototype);
        obj.ptr = ptr;

        return obj;
    }

    free() {
        const ptr = this.ptr;
        this.ptr = 0;

        wasm.__wbg_graph_free(ptr);
    }
    /**
    */
    constructor() {
        var ret = wasm.graph_new();
        return Graph.__wrap(ret);
    }
    /**
    * @returns {number}
    */
    time() {
        var ret = wasm.graph_time(this.ptr);
        return ret;
    }
    /**
    */
    debugger() {
        wasm.graph_debugger(this.ptr);
    }
    /**
    */
    resume() {
        wasm.graph_resume(this.ptr);
    }
    /**
    * @param {any} data
    */
    update(data) {
        try {
            wasm.graph_update(this.ptr, addBorrowedObject(data));
        } finally {
            heap[stack_pointer++] = undefined;
        }
    }
}

export const __wbindgen_object_drop_ref = function(arg0) {
    takeObject(arg0);
};

export const __wbindgen_json_serialize = function(arg0, arg1) {
    const obj = getObject(arg1);
    var ret = JSON.stringify(obj === undefined ? null : obj);
    var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export const __wbindgen_string_new = function(arg0, arg1) {
    var ret = getStringFromWasm0(arg0, arg1);
    return addHeapObject(ret);
};

export const __wbindgen_cb_drop = function(arg0) {
    const obj = takeObject(arg0).original;
    if (obj.cnt-- == 1) {
        obj.a = 0;
        return true;
    }
    var ret = false;
    return ret;
};

export const __wbg_log_3bafd82835c6de6d = function(arg0) {
    console.log(getObject(arg0));
};

export const __wbg_connect_a4e3fd3dce194b2c = handleError(function(arg0, arg1) {
    var ret = getObject(arg0).connect(getObject(arg1));
    return addHeapObject(ret);
});

export const __wbg_connect_40a02004fddf975c = handleError(function(arg0, arg1) {
    getObject(arg0).connect(getObject(arg1));
});

export const __wbg_disconnect_8df0b73a8807dcc1 = handleError(function(arg0) {
    getObject(arg0).disconnect();
});

export const __wbg_disconnect_b555370c155c0800 = handleError(function(arg0, arg1) {
    getObject(arg0).disconnect(getObject(arg1));
});

export const __wbg_disconnect_533e4e7d11acafa0 = handleError(function(arg0, arg1) {
    getObject(arg0).disconnect(getObject(arg1));
});

export const __wbg_settype_88630ac138d23895 = function(arg0, arg1) {
    getObject(arg0).type = takeObject(arg1);
};

export const __wbg_frequency_3d4b1e3749c692f2 = function(arg0) {
    var ret = getObject(arg0).frequency;
    return addHeapObject(ret);
};

export const __wbg_detune_84951aa91f2e0d7d = function(arg0) {
    var ret = getObject(arg0).detune;
    return addHeapObject(ret);
};

export const __wbg_Q_7f1aea85872f6ad0 = function(arg0) {
    var ret = getObject(arg0).Q;
    return addHeapObject(ret);
};

export const __wbg_gain_ee3e3e63c8597a37 = function(arg0) {
    var ret = getObject(arg0).gain;
    return addHeapObject(ret);
};

export const __wbg_gain_4df90433f6e80c75 = function(arg0) {
    var ret = getObject(arg0).gain;
    return addHeapObject(ret);
};

export const __wbindgen_number_new = function(arg0) {
    var ret = arg0;
    return addHeapObject(ret);
};

export const __wbg_delayTime_c4ec0d4f3b1f42e6 = function(arg0) {
    var ret = getObject(arg0).delayTime;
    return addHeapObject(ret);
};

export const __wbg_destination_647daf47bfcda8af = function(arg0) {
    var ret = getObject(arg0).destination;
    return addHeapObject(ret);
};

export const __wbg_currentTime_9790fc4a74b6d62f = function(arg0) {
    var ret = getObject(arg0).currentTime;
    return ret;
};

export const __wbg_state_5a434ba3efa1082c = function(arg0) {
    var ret = getObject(arg0).state;
    return addHeapObject(ret);
};

export const __wbg_newwithcontextoptions_9a358aad2fed2fc3 = handleError(function(arg0) {
    var ret = new lAudioContext(getObject(arg0));
    return addHeapObject(ret);
});

export const __wbg_close_4d14821b14172f7b = handleError(function(arg0) {
    var ret = getObject(arg0).close();
    return addHeapObject(ret);
});

export const __wbg_createBiquadFilter_a5b217f1d3a499e8 = handleError(function(arg0) {
    var ret = getObject(arg0).createBiquadFilter();
    return addHeapObject(ret);
});

export const __wbg_createDelay_9ace221be1e30276 = handleError(function(arg0, arg1) {
    var ret = getObject(arg0).createDelay(arg1);
    return addHeapObject(ret);
});

export const __wbg_createGain_76746a6a33b74c41 = handleError(function(arg0) {
    var ret = getObject(arg0).createGain();
    return addHeapObject(ret);
});

export const __wbg_createOscillator_9a94a320d7ac5f61 = handleError(function(arg0) {
    var ret = getObject(arg0).createOscillator();
    return addHeapObject(ret);
});

export const __wbg_resume_777b6136e3bbedbe = handleError(function(arg0) {
    var ret = getObject(arg0).resume();
    return addHeapObject(ret);
});

export const __wbg_setvalue_b131e8da9633811c = function(arg0, arg1) {
    getObject(arg0).value = arg1;
};

export const __wbg_defaultValue_5bc9f2b838d2416a = function(arg0) {
    var ret = getObject(arg0).defaultValue;
    return ret;
};

export const __wbg_cancelScheduledValues_4506c4121dbdcd42 = handleError(function(arg0, arg1) {
    var ret = getObject(arg0).cancelScheduledValues(arg1);
    return addHeapObject(ret);
});

export const __wbg_exponentialRampToValueAtTime_ccd853885fdc8e73 = handleError(function(arg0, arg1, arg2) {
    var ret = getObject(arg0).exponentialRampToValueAtTime(arg1, arg2);
    return addHeapObject(ret);
});

export const __wbg_linearRampToValueAtTime_4028c11b93eb9d3f = handleError(function(arg0, arg1, arg2) {
    var ret = getObject(arg0).linearRampToValueAtTime(arg1, arg2);
    return addHeapObject(ret);
});

export const __wbg_setValueAtTime_ff5c6049704e5bbd = handleError(function(arg0, arg1, arg2) {
    var ret = getObject(arg0).setValueAtTime(arg1, arg2);
    return addHeapObject(ret);
});

export const __wbg_settype_a9ea8e401f4d6a47 = function(arg0, arg1) {
    getObject(arg0).type = takeObject(arg1);
};

export const __wbg_frequency_69c7510c02057a38 = function(arg0) {
    var ret = getObject(arg0).frequency;
    return addHeapObject(ret);
};

export const __wbg_detune_91ff56f5142c5452 = function(arg0) {
    var ret = getObject(arg0).detune;
    return addHeapObject(ret);
};

export const __wbg_start_b52cd19764c92efb = handleError(function(arg0) {
    getObject(arg0).start();
});

export const __wbg_stop_af5e1e8af6a87fde = handleError(function(arg0) {
    getObject(arg0).stop();
});

export const __wbg_new_3e06d4f36713e4cb = function() {
    var ret = new Object();
    return addHeapObject(ret);
};

export const __wbg_then_3b7ac098cfda2fa5 = function(arg0, arg1, arg2) {
    var ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
    return addHeapObject(ret);
};

export const __wbg_set_304f2ec1a3ab3b79 = handleError(function(arg0, arg1, arg2) {
    var ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
    return ret;
});

export const __wbindgen_string_get = function(arg0, arg1) {
    const obj = getObject(arg1);
    var ret = typeof(obj) === 'string' ? obj : undefined;
    var ptr0 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export const __wbindgen_debug_string = function(arg0, arg1) {
    var ret = debugString(getObject(arg1));
    var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export const __wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

export const __wbindgen_rethrow = function(arg0) {
    throw takeObject(arg0);
};

export const __wbindgen_closure_wrapper794 = function(arg0, arg1, arg2) {
    var ret = makeMutClosure(arg0, arg1, 164, __wbg_adapter_20);
    return addHeapObject(ret);
};

