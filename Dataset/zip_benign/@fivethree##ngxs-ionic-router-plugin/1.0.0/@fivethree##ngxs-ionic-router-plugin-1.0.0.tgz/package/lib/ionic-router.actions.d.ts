import { UrlTree } from '@angular/router';
import { NavigationOptions, AnimationOptions } from './symbols';
export declare class NavigateRoot {
    readonly path: string | UrlTree | any[];
    readonly options?: NavigationOptions;
    static readonly type = "[Router] NavigateRoot";
    constructor(path: string | UrlTree | any[], options?: NavigationOptions);
}
export declare class NavigateForward {
    readonly path: string | UrlTree | any[];
    readonly options?: NavigationOptions;
    static readonly type = "[Router] NavigateForward";
    constructor(path: string | UrlTree | any[], options?: NavigationOptions);
}
export declare class NavigateBackward {
    readonly path: string | UrlTree | any[];
    readonly options?: NavigationOptions;
    static readonly type = "[Router] NavigateBackward";
    constructor(path: string | UrlTree | any[], options?: NavigationOptions);
}
export declare class NavigateBack {
    readonly options?: AnimationOptions;
    static readonly type = "[Router] NavigateBack";
    constructor(options?: AnimationOptions);
}
