import { ModuleWithProviders } from '@angular/core';
export declare class NgxsIonicRouterPluginModule {
    static forRoot(): ModuleWithProviders<NgxsIonicRouterPluginModule>;
}
