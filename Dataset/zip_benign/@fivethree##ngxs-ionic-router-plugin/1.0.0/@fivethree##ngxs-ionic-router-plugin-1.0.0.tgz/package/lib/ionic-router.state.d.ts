import { StateContext } from '@ngxs/store';
import { NavController } from '@ionic/angular';
import { NgZone } from '@angular/core';
import { NavigateRoot, NavigateForward, NavigateBackward, NavigateBack } from './ionic-router.actions';
export interface IonicRouterStateModel {
    path?: any;
}
export declare class IonicRouterState {
    private navCtrl;
    private ngZone;
    constructor(navCtrl: NavController, ngZone: NgZone);
    navigateRoot(context: StateContext<IonicRouterStateModel>, action: NavigateRoot): void;
    navigateForward(context: StateContext<IonicRouterStateModel>, action: NavigateForward): void;
    navigateBack(context: StateContext<IonicRouterStateModel>, action: NavigateBackward): void;
    goBack(context: StateContext<IonicRouterStateModel>, action: NavigateBack): void;
}
