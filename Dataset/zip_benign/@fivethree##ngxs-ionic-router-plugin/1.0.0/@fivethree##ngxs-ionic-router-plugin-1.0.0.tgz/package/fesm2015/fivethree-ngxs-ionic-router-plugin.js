import { Injectable, NgZone, NgModule } from '@angular/core';
import { Action, State, NgxsModule } from '@ngxs/store';
import { __decorate, __metadata } from 'tslib';
import { NavController } from '@ionic/angular';

class NavigateRoot {
    constructor(path, options) {
        this.path = path;
        this.options = options;
    }
}
NavigateRoot.type = '[Router] NavigateRoot';
class NavigateForward {
    constructor(path, options) {
        this.path = path;
        this.options = options;
    }
}
NavigateForward.type = '[Router] NavigateForward';
class NavigateBackward {
    constructor(path, options) {
        this.path = path;
        this.options = options;
    }
}
NavigateBackward.type = '[Router] NavigateBackward';
class NavigateBack {
    constructor(options) {
        this.options = options;
    }
}
NavigateBack.type = '[Router] NavigateBack';

let IonicRouterState = class IonicRouterState {
    constructor(navCtrl, ngZone) {
        this.navCtrl = navCtrl;
        this.ngZone = ngZone;
    }
    navigateRoot(context, action) {
        this.ngZone.run(() => this.navCtrl.navigateRoot(action.path, action.options));
        context.setState({ path: action.path });
    }
    navigateForward(context, action) {
        this.ngZone.run(() => this.navCtrl.navigateForward(action.path, action.options));
        context.setState({ path: action.path });
    }
    navigateBack(context, action) {
        this.ngZone.run(() => this.navCtrl.navigateBack(action.path, action.options));
        context.setState({ path: action.path });
    }
    goBack(context, action) {
        this.ngZone.run(() => this.navCtrl.back(action.options));
        context.setState({ path: null });
    }
};
IonicRouterState.decorators = [
    { type: Injectable }
];
IonicRouterState.ctorParameters = () => [
    { type: NavController },
    { type: NgZone }
];
__decorate([
    Action(NavigateRoot),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, NavigateRoot]),
    __metadata("design:returntype", void 0)
], IonicRouterState.prototype, "navigateRoot", null);
__decorate([
    Action(NavigateForward),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, NavigateForward]),
    __metadata("design:returntype", void 0)
], IonicRouterState.prototype, "navigateForward", null);
__decorate([
    Action(NavigateBackward),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, NavigateBackward]),
    __metadata("design:returntype", void 0)
], IonicRouterState.prototype, "navigateBack", null);
__decorate([
    Action(NavigateBack),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, NavigateBack]),
    __metadata("design:returntype", void 0)
], IonicRouterState.prototype, "goBack", null);
IonicRouterState = __decorate([
    State({
        name: 'ionicRouter',
        defaults: {
            path: undefined
        }
    }),
    __metadata("design:paramtypes", [NavController, NgZone])
], IonicRouterState);

// NOTE: Must mark as `dynamic` due to
// https://github.com/dherges/ng-packagr/issues/767
// export const NgxsModuleRouterState = NgxsModule.forFeature([IonicRouterState]);
class NgxsIonicRouterPluginModule {
    static forRoot() {
        return {
            ngModule: NgxsIonicRouterPluginModule,
            providers: []
        };
    }
}
NgxsIonicRouterPluginModule.decorators = [
    { type: NgModule, args: [{
                imports: [NgxsModule.forFeature([IonicRouterState])]
            },] }
];

/**
 * Generated bundle index. Do not edit.
 */

export { IonicRouterState, NavigateBack, NavigateBackward, NavigateForward, NavigateRoot, NgxsIonicRouterPluginModule };
//# sourceMappingURL=fivethree-ngxs-ionic-router-plugin.js.map
