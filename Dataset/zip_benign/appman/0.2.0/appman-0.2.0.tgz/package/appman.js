#! /usr/bin/env node

'use strict';

var cluster = require('cluster');
/*

Appman is composed of four components

i. The appman commandline tool
ii. The Node module to be loaded in apps
iii. The monitor program - responsibe for watching the process and the dir, and restarting the app if required
iv. The script runner - responsible for parsing and executing the appman.js script

*/

// applicable only in master process
if (cluster.isMaster) {
  if (process.argv[2] == 'monitor') {
    if (process.stdin.isTTY) console.log('\n Appman monitor cannot be started from the commandline\n'.red);
    else require(__dirname + '/lib/monitor.js');
  }
  // this is a call for the script runner - invoked by appman script
  else if (process.argv[2] == 'script') {
    module.exports = require(__dirname + '/lib/script-runner.js');
  }
  // this is a call for the commandline - invoked by appman command
  else if (require.main == module) {
    require(__dirname + '/lib/commandline.js');
  }
  // this is a call for the appman api - invoked by by app
  else {
    module.exports = require(__dirname + '/lib/appmodule.js');
  }
}
