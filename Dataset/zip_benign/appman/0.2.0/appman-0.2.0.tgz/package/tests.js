
/*

Write test for the following:

appman start
appman start --file <existent file>
appman start --file <missing file>
appman start --file <buggy file>
appman start -w
appman start -w --file <existent file>
appman start -r
appman start -r --file <existent file>
appman start -e
appman start -e --file <existent file>
appman start -d
appman start -d --file <existent file>
appman start -dw
appman start -dw --watch-files '*.js, *.html'
appman start -dw --ignore-directories 'public, static/js'
appman start -dw --watch-files '*.js,*.html'
appman start -drew
appman start -drew --file <existent file>

  Run these commands for all the start options

  appman status
  appman info

  appman stop
  appman restart

  appman clean
  appman reset

Repeat the start tests using appman script
Test event listeners
Ensure API is working

*/