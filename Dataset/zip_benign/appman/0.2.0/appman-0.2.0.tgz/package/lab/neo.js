
setInterval(function () {
  console.log('HAHAHA');
}, 2000);
