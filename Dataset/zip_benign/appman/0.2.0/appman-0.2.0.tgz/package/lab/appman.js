var appman = require('../');

appman.set('daemon', true);
appman.set({
  'file': 'neo.js',
  'watch': true,
  'watch-files': '*.js,*.jade',
  'revive': false,
  'crash-check-interval': 500,
  'revival-attempts': 5,
  'enable-api': false,
  'daemon': true
});
//appman.set('watch-files', '*.js, *.jade');

//console.log(appman.get('crash-check-interval'));
//console.log(appman.get('watch-files'));

var app = appman.app();

app.on('start', function(start) {
  console.log('APP START: ', start.time, start.pid);
  console.log(appman.get('file'));
});

app.on('restart', function(restart) {
  console.log('RESTARTED: ', restart.time, restart.pid);
});

// when app crash is detected, backup for crash event
app.on('crashDetect', function(crash) {
  console.log('APP CRASH DETECTED: ', crash.time);
});

// when the app crashes, may not be triggered with guarantee
app.on('crash', function(crash) {
  console.log('APP CRASH: ', crash.time);
});

/*

app.on('stop', function(stop) {

});

app.on('restart', function(restart) {

});

app.on('crash', function(crash) {

  console.log('Crash detected at %s', crash.time);
  var crashes = appman.info.get('crashes');
  appman.info.set(++crashes);

});

app.on('query', function() {

});

// custom events - name - emitter
app.createEvent('memoryDanger', function () {
  setInterval(function () { if (x > y) { appman.emit('memoryDanger', data); }}, 1000);
});
app.on('memoryDanger', function() {

});

// command - create your own appman commands - executed from the commandline
appman.command('prune', function () {

});

// plugin - add functionality to appman via appman APIs
appman.plugin('netview', function () {

  var server = http();

  server.get('/start', function () {
    appman.app.start();
  });

  server.listen(3000);

});
*/
