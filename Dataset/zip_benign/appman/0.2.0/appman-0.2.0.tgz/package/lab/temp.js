'use strict';

var appman = require('../appman.js');

setInterval(function() {
  console.log(Date.now(), 'YES WE CAN!');
}, 1000);


setTimeout(function () {

  appman.info.set('host', 'localhost');
  appman.info.set('port', 3000);

}, 1500);