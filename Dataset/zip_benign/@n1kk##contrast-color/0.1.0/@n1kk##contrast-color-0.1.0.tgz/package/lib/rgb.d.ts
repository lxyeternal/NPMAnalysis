import { ColorValue } from "./types";
export declare type RGB = [r: number, g: number, b: number];
export declare const sRGB: (rgb: RGB) => RGB;
export declare function hexToRGB(hex: string): RGB;
export declare function decToRGB(dec: number): RGB;
export declare function toRGB(color: ColorValue): RGB;
