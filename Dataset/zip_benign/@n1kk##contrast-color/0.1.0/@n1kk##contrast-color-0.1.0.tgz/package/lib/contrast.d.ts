import { ColorValue } from "./types";
export declare function colorsContrast(color1: ColorValue, color2: ColorValue): number;
export declare function colorsContrastRatio(color1: ColorValue, color2: ColorValue): number;
export declare function colorsHaveSufficientContrast(color1: ColorValue, color2: ColorValue): boolean;
export declare function pickMostContrast<T extends ColorValue>(colors: T[], target: ColorValue): T;
export declare function contrastingTextColor(backgroundColor: ColorValue, { threshold, dark, light, }?: {
    threshold?: number;
    dark?: string;
    light?: string;
}): string;
