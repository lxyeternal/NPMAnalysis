import { RGB } from "./rgb";
export declare type ColorValue = number | string | RGB | number[];
