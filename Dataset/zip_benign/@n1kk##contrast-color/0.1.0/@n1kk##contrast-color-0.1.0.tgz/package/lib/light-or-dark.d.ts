export declare type LightOrDarkOptions = {
    dark?: string;
    light?: string;
    threshold?: number;
    onBadColor?: string;
    lumFactors?: [r: number, g: number, b: number];
};
export declare function lightOrDark(this: LightOrDarkOptions | void, color: string, options?: LightOrDarkOptions): string;
