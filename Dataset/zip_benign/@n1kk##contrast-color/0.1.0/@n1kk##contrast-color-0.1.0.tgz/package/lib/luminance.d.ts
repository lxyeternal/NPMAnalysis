import { ColorValue } from "./types";
export declare function colorLuminance(color: ColorValue): number;
