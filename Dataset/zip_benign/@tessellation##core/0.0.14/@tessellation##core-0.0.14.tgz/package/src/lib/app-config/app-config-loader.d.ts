/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { AppConfig } from './app-config';
import { GenericAppConfig } from './generic-app-config';
/**
 * @param config
 */
export declare function appConfigLoader<T extends GenericAppConfig>(config: T): AppConfig<T>;
