/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { ContainerInstance } from './container-instance';
import { GenericIdentifier } from './generic-identifier';
import { Handler } from './handler';
import { ServiceIdentifier } from './service-identifier';
import { ServiceOptions } from './service-options';
import { Token } from './token';
export declare class Container {
    static readonly handlers: Array<Handler>;
    private static readonly _globalInstance;
    private static readonly _instances;
    static of(containerId?: GenericIdentifier): ContainerInstance;
    static has<T>(identifier: ServiceIdentifier<T>): boolean;
    static get<T>(identifier: ServiceIdentifier<T>): T;
    static getMany<T>(id: Token<T> | string): Array<T>;
    static set<T = unknown>(identifierOrServiceMetadata: Array<ServiceOptions<T>> | ServiceIdentifier<T> | ServiceOptions<T>, value?: unknown): Container;
    static remove<T = unknown>(identifierOrIdentifierArray: Array<ServiceIdentifier<T>> | ServiceIdentifier<T>): Container;
    static reset(containerId?: GenericIdentifier): Container;
    static registerHandler(handler: Handler): Container;
    static import(services: Array<CallableFunction>): Container;
}
