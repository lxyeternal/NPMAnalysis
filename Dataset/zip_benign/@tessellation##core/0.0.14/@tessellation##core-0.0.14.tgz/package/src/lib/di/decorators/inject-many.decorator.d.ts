/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { Constructable } from '../../constructable';
import { ServiceIdentifier } from '../service-identifier';
/**
 * @param typeOrIdentifier
 */
export declare function InjectMany(typeOrIdentifier?: ServiceIdentifier | ((type?: never) => Constructable<unknown>)): CallableFunction;
