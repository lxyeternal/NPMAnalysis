/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare enum ComponentTypes {
    APPLICATION = "APPLICATION",
    LOADER = "LOADER",
    MODULE = "MODULE",
    PROVIDER = "PROVIDER"
}
