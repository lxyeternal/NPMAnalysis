/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { Constructable } from '../constructable';
import { GenericIdentifier } from './generic-identifier';
import { ServiceIdentifier } from './service-identifier';
export declare type TypeOrIdentifier = ServiceIdentifier | ((type?: never) => Constructable<unknown>) | null | undefined;
export declare type EagerType = ServiceIdentifier | null | undefined;
export declare type LazyType = (type?: unknown) => ServiceIdentifier | undefined;
export interface TypeWrapper {
    eagerType: EagerType;
    lazyType: LazyType;
}
export declare type MaybeTypeWrapper = TypeWrapper | undefined;
export interface ReflectType {
    getMetadata: (a: string, b: object, c?: GenericIdentifier) => Array<unknown> | unknown;
}
/**
 * @param typeOrIdentifier
 * @param target
 * @param propertyName
 * @param index
 */
export declare function resolveToTypeWrapper(typeOrIdentifier: TypeOrIdentifier, target: object, propertyName: GenericIdentifier, index?: number): MaybeTypeWrapper;
