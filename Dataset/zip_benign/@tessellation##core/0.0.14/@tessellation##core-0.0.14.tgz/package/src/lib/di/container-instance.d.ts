/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { GenericIdentifier } from './generic-identifier';
import { ServiceIdentifier } from './service-identifier';
import { ServiceOptions } from './service-options';
interface ResetOptions {
    strategy: 'resetServices' | 'resetValue';
}
export declare class ContainerInstance {
    readonly id: GenericIdentifier;
    private _services;
    constructor(id: GenericIdentifier);
    has<T>(identifier: ServiceIdentifier<T>): boolean;
    get<T>(identifier: ServiceIdentifier<T>): T;
    getMany<T>(identifier: ServiceIdentifier<T>): Array<T>;
    set<T = unknown>(identifierOrServiceMetadata: Array<ServiceOptions<T>> | ServiceIdentifier | ServiceOptions<T>, value?: T): this;
    remove(identifierOrIdentifierArray: Array<ServiceIdentifier> | ServiceIdentifier): this;
    reset(options?: ResetOptions): this;
    private _findAllServices;
    private _findService;
    private _getServiceValue;
    private _fromFactory;
    private _initializeParams;
    private _isPrimitiveParamType;
    private _applyPropertyHandlers;
    private _destroyServiceInstance;
}
export {};
