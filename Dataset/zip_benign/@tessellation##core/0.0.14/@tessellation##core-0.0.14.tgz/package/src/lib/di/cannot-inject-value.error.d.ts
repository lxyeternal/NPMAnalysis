/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { Constructable } from '../constructable';
/**
 * Thrown when DI cannot inject value into property decorated by @Inject decorator.
 */
export declare class CannotInjectValueError extends Error {
    private readonly _target;
    private readonly _propertyName;
    name: string;
    get message(): string;
    constructor(_target: Constructable<unknown>, _propertyName: string);
}
