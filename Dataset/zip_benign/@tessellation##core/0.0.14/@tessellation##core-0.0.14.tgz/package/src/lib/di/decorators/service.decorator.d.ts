/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { ServiceOptions } from '../service-options';
import { Token } from '../token';
/**
 * @param optionsOrServiceIdentifier
 */
export declare function Service<T>(optionsOrServiceIdentifier?: ServiceOptions<T> | Token<T> | string): ClassDecorator;
