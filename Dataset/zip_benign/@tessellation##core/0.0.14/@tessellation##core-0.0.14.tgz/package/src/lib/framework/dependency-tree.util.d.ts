/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare type Tree = Map<string, Tree | null> | null;
export declare const generateDependencyTree: (dependencyInverseRelationships: Record<string, Array<string>>) => Tree;
export declare const flattenDependencyTree: (dependencyTree: Tree) => Array<string>;
export declare const dedupeArray: <T>(array: T[]) => T[];
