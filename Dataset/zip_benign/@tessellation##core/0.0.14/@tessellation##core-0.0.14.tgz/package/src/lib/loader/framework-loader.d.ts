/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { ComponentTypes } from '../component-types.enum';
import { ConstructableWithPrototype } from '../constructable';
import { FrameworkSettings } from '../settings';
import { NonEmptyArray } from '../types';
export declare type FrameworkLoaderFunction = <T>(settings?: FrameworkSettings) => Promise<T> | Promise<void> | T | void;
export declare type FrameworkUnloaderFunction = <T>(settings?: FrameworkSettings) => Promise<T> | Promise<void> | T | void;
export interface FrameworkLoader {
    loader: () => FrameworkLoaderFunction;
    unloader?: () => FrameworkUnloaderFunction;
}
export declare enum FrameworkLoaderOrder {
    FIRST = "FIRST",
    LAST = "LAST",
    ANY = "ANY"
}
export interface FrameworkLoaderPrototype {
    name: string;
    created: string;
    type: ComponentTypes.LOADER;
    deps?: NonEmptyArray<ConstructableFrameworkLoader>;
    order: FrameworkLoaderOrder;
}
export declare type ConstructableFrameworkLoader = ConstructableWithPrototype<FrameworkLoader, FrameworkLoaderPrototype>;
