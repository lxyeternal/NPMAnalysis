/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { FrameworkModuleOptions } from './framework-module-options';
/**
 * @param options
 */
export declare function Module(options: FrameworkModuleOptions): ClassDecorator;
