/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { AppConfig, GenericAppConfig } from '../app-config';
import { FrameworkApplicationOptions } from './framework-application-options';
export declare const Application: <T extends AppConfig<GenericAppConfig>>(options: FrameworkApplicationOptions<T>) => ClassDecorator;
