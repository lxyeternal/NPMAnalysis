/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
/**
 * @param collection
 * @param callback
 */
export declare function runInOrder<T, U>(collection: Array<T>, callback: (item: T) => Promise<U>): Promise<Array<U>>;
