/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare const DEFAULT_CONTAINER_ID: unique symbol;
