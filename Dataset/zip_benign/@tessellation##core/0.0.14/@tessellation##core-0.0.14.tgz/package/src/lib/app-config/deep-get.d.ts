/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
/**
 * @param object
 * @param path
 * @param required
 */
export declare function deepGet(object: Record<string, unknown>, path: Array<string> | string, required?: boolean): unknown;
