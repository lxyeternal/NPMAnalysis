/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { AppConfig, GenericAppConfig } from '../app-config';
import { FrameworkConfiguration } from './framework-configuration';
export declare class Framework {
    private _appConfig;
    private readonly _modules;
    private readonly _providers;
    private readonly _loaders;
    private readonly _unloaders;
    constructor();
    start(): Promise<void>;
    private _registerAppConfigToken;
    private _registerModules;
    private _registerProviders;
    private _registerLoaders;
    private _registerUnloaders;
    private _recursiveParseModule;
    private _bootstrapModules;
    private _bootstrapProviders;
    private _bootstrapLoaders;
    static configure<T extends AppConfig<GenericAppConfig>>(config: FrameworkConfiguration<T>): Framework;
}
