/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { FrameworkLoaderOptions } from './framework-loader-options';
/**
 * @param options
 */
export declare function Loader(options?: FrameworkLoaderOptions): ClassDecorator;
