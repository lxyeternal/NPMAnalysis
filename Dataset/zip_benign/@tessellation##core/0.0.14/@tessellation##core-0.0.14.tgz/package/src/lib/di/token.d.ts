/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare class Token<T> {
    name?: string | undefined;
    private readonly _value;
    constructor(name?: string | undefined);
}
