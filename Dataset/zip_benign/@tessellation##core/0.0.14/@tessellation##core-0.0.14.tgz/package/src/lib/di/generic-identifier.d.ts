/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare type GenericIdentifier = string | symbol;
