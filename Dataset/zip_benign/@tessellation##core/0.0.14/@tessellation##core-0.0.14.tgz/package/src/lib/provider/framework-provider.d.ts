/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { Token } from '../di';
export declare const APP_CONFIG_TOKEN_SYMBOL: unique symbol;
export interface FrameworkProvider<T> {
    provide: Token<T> | typeof APP_CONFIG_TOKEN_SYMBOL;
    deps?: Array<Token<unknown> | typeof APP_CONFIG_TOKEN_SYMBOL>;
    useValue: ((...arguments_: any[]) => Promise<T>) | ((...arguments_: any[]) => T);
}
export declare type GenericFrameworkProvider = FrameworkProvider<unknown>;
