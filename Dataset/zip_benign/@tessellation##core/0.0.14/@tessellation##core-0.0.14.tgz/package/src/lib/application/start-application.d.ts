/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import 'source-map-support/register';
export declare const startApplication: (application: unknown) => void;
