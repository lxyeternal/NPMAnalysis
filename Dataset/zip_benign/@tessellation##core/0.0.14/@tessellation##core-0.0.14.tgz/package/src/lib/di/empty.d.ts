/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare const EMPTY_VALUE: unique symbol;
