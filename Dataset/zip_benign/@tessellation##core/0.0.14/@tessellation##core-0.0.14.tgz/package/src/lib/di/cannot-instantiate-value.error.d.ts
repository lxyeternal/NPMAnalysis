/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { ServiceIdentifier } from './service-identifier';
export declare class CannotInstantiateValueError extends Error {
    name: string;
    private readonly _normalizedIdentifier;
    get message(): string;
    constructor(identifier: ServiceIdentifier);
}
