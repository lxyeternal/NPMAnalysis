/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare const notNullOrUndefined: (value: unknown | null | undefined) => boolean;
export declare const notNullish: (value: unknown) => boolean;
