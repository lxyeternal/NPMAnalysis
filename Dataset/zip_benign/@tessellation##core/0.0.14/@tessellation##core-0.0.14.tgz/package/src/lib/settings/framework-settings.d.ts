/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
export declare class FrameworkSettings {
    private readonly _settings;
    setValue(key: string, value: unknown): void;
    getValue<T>(key: string): T;
    hasValue(key: string): boolean;
}
