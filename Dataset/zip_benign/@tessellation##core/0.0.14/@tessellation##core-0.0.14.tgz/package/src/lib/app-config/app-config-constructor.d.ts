/*************************
 * Copyright 2022
 * Ethan Elliott
 *************************/
import { AppConfig } from './app-config';
import { GenericAppConfig } from './generic-app-config';
export declare class AppConfigConstructor<T extends GenericAppConfig> implements AppConfig<T> {
    config: T;
    constructor(config: T);
    get<P>(path: string, required?: boolean): P;
}
