# Pcalc

> A javascript Precise calculation Library

## Usage

Import library

```javascript
const Pcalc from 'pcalcjs'

Pcalc.add(0.1, 0.2)		// 0.3

Pcalc.sub(0.3, 0.2)		// 0.1

Pcalc.mul(0.23, 0.4)	// 0.092

Pcalc.div(0.3, 0.2)		// 1.5
```

