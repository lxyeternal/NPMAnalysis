'use strict'

const Pcalc = {}

Pcalc.add = (a, b) => {
	let c, d, e
	try {
		c = a.toString().split(".")[1].length
	} catch (f) {
		c = 0
	}
	try {
		d = b.toString().split(".")[1].length
	} catch (f) {
		d = 0
	}
	return e = Math.pow(10, Math.max(c, d)), (Pcalc.mul(a, e) + Pcalc.mul(b, e)) / e
}

Pcalc.sub = (a, b) => {
	let c, d, e
	try {
	    c = a.toString().split(".")[1].length
	} catch (f) {
	    c = 0
	}
	try {
	    d = b.toString().split(".")[1].length
	} catch (f) {
	    d = 0
	}
	return e = Math.pow(10, Math.max(c, d)), (Pcalc.mul(a, e) - Pcalc.mul(b, e)) / e
}

Pcalc.mul = (a, b) => {
	let c = 0,
	    d = a.toString(),
	    e = b.toString()
	try {
	    c += d.split(".")[1].length
	} catch (f) {}
	try {
	    c += e.split(".")[1].length
	} catch (f) {}
	return Number(d.replace(".", "")) * Number(e.replace(".", "")) / Math.pow(10, c)
}

Pcalc.div = (a, b) => {
	var c, d, e = 0, f = 0
	try {
	    e = a.toString().split(".")[1].length
	} catch (g) {}
	try {
	    f = b.toString().split(".")[1].length
	} catch (g) {}
	return c = Number(a.toString().replace(".", "")), d = Number(b.toString().replace(".", "")), Pcalc.mul(c / d, Math.pow(10, f - e))
}


module.exports = Pcalc
