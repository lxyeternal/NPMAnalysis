const Pcalc = require('./index.js')

test('test 0.1 plus 0.2 should equal 0.3', () => {
	expect(Pcalc.add(0.1, 0.2)).toBe(0.3)
})

test('test 1 plus 2 should equal 3', () => {
	expect(Pcalc.add(1, 2)).toBe(3)
})

test('test 0.3 minus 0.2 should equal 0.1', () => {
	expect(Pcalc.sub(0.3, 0.2)).toBe(0.1)
})

test('test 3 minus 2 should equal 1', () => {
	expect(Pcalc.sub(3, 2)).toBe(1)
})

test('test 0.3 minus 0.2 minus 0.1 should equal 0', () => {
	expect(Pcalc.sub(Pcalc.sub(0.3, 0.2), 0.1)).toBe(0)
})

test('test 0.23 multiply 0.4 should equal 0.092', () => {
	expect(Pcalc.mul(0.23, 0.4)).toBe(0.092)
})

test('test 4 multiply 8 should equal 32', () => {
	expect(Pcalc.mul(4, 8)).toBe(32)
})

test('test 0.3 divide 0.2 should equal 1.5', () => {
	expect(Pcalc.div(0.3, 0.2)).toBe(1.5)
})

test('test 3 divide 2 should equal 1.5', () => {
	expect(Pcalc.div(3, 2)).toBe(1.5)
})


