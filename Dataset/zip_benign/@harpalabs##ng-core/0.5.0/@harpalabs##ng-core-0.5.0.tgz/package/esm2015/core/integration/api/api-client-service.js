/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
/**
 * Generic API Client service for the Angular (NG) Harpa Framework.
 *
 * @author Denis Pinheiro
 */
export class ApiClientService {
    constructor(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * Get the headers for all HTTP requests.
     * This method might be redefined by the concrete
     * API client service if is need to send
     * headers data in all HTTP requests.
     */
    getHeaders() {
        return [];
    }
    /**
     * Get the params for all HTTP requests.
     * This method might be redefined by the concrete
     * API client service if is need to send
     * params data in all HTTP requests.
     */
    getParams() {
        return [];
    }
    /**
     * The GET method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    get(resourcePath, headers = [], params = []) {
        return this.httpClient.get(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * The POST method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param input the input JSON object the be sent as a payload.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    post(resourcePath, input, headers = [], params = []) {
        return this.httpClient.post(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), input, {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * The PUT method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param input the input JSON object the be sent as a payload.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    put(resourcePath, input, headers = [], params = []) {
        return this.httpClient.put(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), input, {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * The DELETE method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    delete(resourcePath, headers = [], params = []) {
        return this.httpClient.delete(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * Defines if the communication should be encripted using SSL/TSL.
     * Whether true, HTTPS should be used, otherwise, it uses HTTP.
     * This method might be redefined by the concrete API client
     * service. The default value is false.
     */
    isEncriptionEnabled() {
        return false;
    }
    /**
     * Normalizes the API Server URL in order to have HTTP/HTTPS and without '/' in the end.
     * @param apiServerUrl The API Server URL.
     */
    normalizeApiServerUrl(apiServerUrl) {
        let normalizedApiServerUrl = apiServerUrl;
        if (!normalizedApiServerUrl.startsWith('http://')
            && !normalizedApiServerUrl.startsWith('https://')) {
            normalizedApiServerUrl = ((this.isEncriptionEnabled()) ? "https://" : "http://") + normalizedApiServerUrl;
        }
        if (normalizedApiServerUrl.endsWith('/')) {
            normalizedApiServerUrl = normalizedApiServerUrl.substr(0, normalizedApiServerUrl.length - 1);
        }
        return normalizedApiServerUrl;
    }
    /**
     * Normalizes the resource path of a REST API call in order to start with '/'.
     * @param resourcePath The resource path.
     * @return The normalized resource path.
     */
    normalizeResourcePath(resourcePath) {
        let normalizedResourcePath = resourcePath;
        if (!normalizedResourcePath.startsWith('/')) {
            normalizedResourcePath = "/" + normalizedResourcePath;
        }
        return normalizedResourcePath;
    }
    /**
     * Convert the given API Headers into HttpHeaders.
     * @param headers The API headers to be converted.
     * @returns The Http headers converted from the given API headers.
     */
    convertHttpHeaders(headers) {
        let httpHeaders = new HttpHeaders();
        if (headers) {
            for (let header of headers) {
                httpHeaders = httpHeaders.set(header.headerName, header.headerValue);
            }
        }
        return httpHeaders;
    }
    /**
     * Convert the given API Params into HttpParams.
     * @param params The API parameters to be converted.
     * @returns The Http parameters converted from the given API parameters.
     */
    convertHttpParams(params) {
        let httpParams = new HttpParams();
        if (params) {
            for (let param of params) {
                httpParams = httpParams.set(param.paramName, param.paramValue);
            }
        }
        return httpParams;
    }
}
ApiClientService.decorators = [
    { type: Injectable }
];
ApiClientService.ctorParameters = () => [
    { type: HttpClient }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLWNsaWVudC1zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvbmctY29yZS9zcmMvY29yZS9pbnRlZ3JhdGlvbi9hcGkvYXBpLWNsaWVudC1zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7O0dBSUc7QUFFSCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBc0IzRTs7OztHQUlHO0FBRUgsTUFBTSxPQUFnQixnQkFBZ0I7SUFFbEMsWUFBc0IsVUFBc0I7UUFBdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUFHLENBQUM7SUFTaEQ7Ozs7O09BS0c7SUFDTyxVQUFVO1FBQ2hCLE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ08sU0FBUztRQUNmLE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLEdBQUcsQ0FBQyxZQUFvQixFQUFFLFVBQXVCLEVBQUUsRUFBRSxTQUFxQixFQUFFO1FBQy9FLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQ3RCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDM0YsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25FLE1BQU0sRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNsRSxDQUFDLENBQUM7SUFDWCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLElBQUksQ0FBQyxZQUFvQixFQUFFLEtBQVMsRUFBRSxVQUF1QixFQUFFLEVBQUUsU0FBcUIsRUFBRTtRQUMzRixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUN2QixJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxFQUFFLEtBQUssRUFBRTtZQUNsRyxPQUFPLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbkUsTUFBTSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2xFLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksR0FBRyxDQUFDLFlBQW9CLEVBQUUsS0FBUyxFQUFFLFVBQXVCLEVBQUUsRUFBRSxTQUFxQixFQUFFO1FBQzFGLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQ3RCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsWUFBWSxDQUFDLEVBQUUsS0FBSyxFQUFFO1lBQ2xHLE9BQU8sRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNuRSxNQUFNLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbEUsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxZQUFvQixFQUFFLFVBQXVCLEVBQUUsRUFBRSxTQUFxQixFQUFFO1FBQ2xGLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQ3pCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDM0YsT0FBTyxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25FLE1BQU0sRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNsRSxDQUFDLENBQUM7SUFDWCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDTyxtQkFBbUI7UUFDekIsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVEOzs7T0FHRztJQUNLLHFCQUFxQixDQUFDLFlBQW9CO1FBQzlDLElBQUksc0JBQXNCLEdBQUcsWUFBWSxDQUFDO1FBQzFDLElBQUksQ0FBRSxzQkFBc0IsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO2VBQzNDLENBQUUsc0JBQXNCLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ3BELHNCQUFzQixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLHNCQUFzQixDQUFDO1NBQzdHO1FBQ0QsSUFBSSxzQkFBc0IsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDdEMsc0JBQXNCLEdBQUcsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxzQkFBc0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEc7UUFDRCxPQUFPLHNCQUFzQixDQUFDO0lBQ2xDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0sscUJBQXFCLENBQUMsWUFBb0I7UUFDOUMsSUFBSSxzQkFBc0IsR0FBRyxZQUFZLENBQUM7UUFDMUMsSUFBSSxDQUFFLHNCQUFzQixDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUMxQyxzQkFBc0IsR0FBRyxHQUFHLEdBQUcsc0JBQXNCLENBQUM7U0FDekQ7UUFDRCxPQUFPLHNCQUFzQixDQUFDO0lBQ2xDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssa0JBQWtCLENBQUMsT0FBb0I7UUFDM0MsSUFBSSxXQUFXLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQztRQUNwQyxJQUFJLE9BQU8sRUFBRTtZQUNULEtBQUssSUFBSSxNQUFNLElBQUksT0FBTyxFQUFFO2dCQUMxQixXQUFXLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQTthQUNyRTtTQUNKO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxpQkFBaUIsQ0FBQyxNQUFrQjtRQUN4QyxJQUFJLFVBQVUsR0FBRyxJQUFJLFVBQVUsRUFBRSxDQUFDO1FBQ2xDLElBQUksTUFBTSxFQUFFO1lBQ1IsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLEVBQUU7Z0JBQ3hCLFVBQVUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ2hFO1NBQ0o7UUFDRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDOzs7WUFqS0osVUFBVTs7O1lBM0JGLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQGxpY2Vuc2UgQGhhcnBhbGFicy9uZy1jb3JlXHJcbiAqIChjKSAyMDE4IEhhcnBhIExhYnMsIExUREEuXHJcbiAqIExpY2VuY2U6IE1JVC5cclxuICovXHJcblxyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cEhlYWRlcnMsIEh0dHBQYXJhbXMgfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uL2h0dHBcIjtcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gXCJyeGpzXCI7XHJcblxyXG4vKipcclxuICogVGhlIGdlbmVyaWMgQVBJIEhlYWRlciBkZWZpbml0aW9uLCB3aGljaCBoYXMgdGhlIGhlYWRlciBuYW1lIGFuZCB0aGUgaGVhZGVyIHZhbHVlLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBBcGlIZWFkZXIgeyBoZWFkZXJOYW1lOiBzdHJpbmcsIGhlYWRlclZhbHVlOiBzdHJpbmcgfVxyXG4vKipcclxuICogVGhlIGdlbmVyaWMgQVBJIFBhcmFtIGRlZmluaXRpb24sIHdoaWNoIGhhcyB0aGUgcGFyYW0gbmFtZSBhbmQgdGhlIHBhcmFtIHZhbHVlLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBBcGlQYXJhbSB7IHBhcmFtTmFtZTogc3RyaW5nLCBwYXJhbVZhbHVlOiBzdHJpbmcgfVxyXG5cclxuLyoqXHJcbiAqIFRoZSBnZW5lcmljIEFwaSBJbnB1dCBkZWZpbml0aW9uLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBBcGlJbnB1dCB7fVxyXG5cclxuLyoqXHJcbiAqIFRoZSBnZW5lcmljIEFwaSBPdXRwdXQgZGVmaW5pdGlvbi5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXBpT3V0cHV0IHt9XHJcblxyXG4vKipcclxuICogR2VuZXJpYyBBUEkgQ2xpZW50IHNlcnZpY2UgZm9yIHRoZSBBbmd1bGFyIChORykgSGFycGEgRnJhbWV3b3JrLlxyXG4gKlxyXG4gKiBAYXV0aG9yIERlbmlzIFBpbmhlaXJvXHJcbiAqL1xyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBBcGlDbGllbnRTZXJ2aWNlPElOIGV4dGVuZHMgQXBpSW5wdXQsIE9VVCBleHRlbmRzIEFwaU91dHB1dD4ge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBodHRwQ2xpZW50OiBIdHRwQ2xpZW50KSB7fVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogVGhlIEFQSSBTZXJ2ZXIgVXJsIGRlZmluaXRpb24uXHJcbiAgICAgKiBUaGlzIG1ldGhvZCBzaG91bGQgYmUgaW1wbGVtZW50ZWQgYnkgdGhlIGdlbmVyaWNcclxuICAgICAqIEFQSSBjbGllbnQgc2VydmljZSBvZiB0aGUgYXBwbGljYXRpb24gcHJvamVjdC5cclxuICAgICAqL1xyXG4gICAgYWJzdHJhY3QgZ2V0QXBpU2VydmVyVXJsKCk6IHN0cmluZztcclxuXHJcbiAgICAvKipcclxuICAgICAqIEdldCB0aGUgaGVhZGVycyBmb3IgYWxsIEhUVFAgcmVxdWVzdHMuXHJcbiAgICAgKiBUaGlzIG1ldGhvZCBtaWdodCBiZSByZWRlZmluZWQgYnkgdGhlIGNvbmNyZXRlXHJcbiAgICAgKiBBUEkgY2xpZW50IHNlcnZpY2UgaWYgaXMgbmVlZCB0byBzZW5kXHJcbiAgICAgKiBoZWFkZXJzIGRhdGEgaW4gYWxsIEhUVFAgcmVxdWVzdHMuXHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBnZXRIZWFkZXJzKCkgOiBBcGlIZWFkZXJbXSB7XHJcbiAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogR2V0IHRoZSBwYXJhbXMgZm9yIGFsbCBIVFRQIHJlcXVlc3RzLlxyXG4gICAgICogVGhpcyBtZXRob2QgbWlnaHQgYmUgcmVkZWZpbmVkIGJ5IHRoZSBjb25jcmV0ZVxyXG4gICAgICogQVBJIGNsaWVudCBzZXJ2aWNlIGlmIGlzIG5lZWQgdG8gc2VuZFxyXG4gICAgICogcGFyYW1zIGRhdGEgaW4gYWxsIEhUVFAgcmVxdWVzdHMuXHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBnZXRQYXJhbXMoKSA6IEFwaVBhcmFtW10ge1xyXG4gICAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFRoZSBHRVQgbWV0aG9kIGluIHRoZSBSRVNUL0hUVFAgcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSByZXNvdXJjZVBhdGggdGhlIGNvbnRleHQgcGF0aCBvZiB0aGUgcmVzb3VyY2UuXHJcbiAgICAgKiBAcGFyYW0gaGVhZGVycyB0aGUgSFRUUCBoZWFkZXJzIHRvIGJlIHNlbnQgaW4gdGhlIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gcGFyYW1zIHRoZSBIVFRQIHBhcmFtcyB0byBiZSBzZW50IGluIHRoZSByZXF1ZXN0LlxyXG4gICAgICogQHJldHVybnMgQW4gT2JzZXJ2YWJsZS9Qcm9taXNlIG9mIHRoZSBPdXRwdXQuXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXQocmVzb3VyY2VQYXRoOiBzdHJpbmcsIGhlYWRlcnM6IEFwaUhlYWRlcltdID0gW10sIHBhcmFtczogQXBpUGFyYW1bXSA9IFtdKSA6IE9ic2VydmFibGU8T1VUPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5nZXQ8T1VUPihcclxuICAgICAgICAgICAgdGhpcy5ub3JtYWxpemVBcGlTZXJ2ZXJVcmwodGhpcy5nZXRBcGlTZXJ2ZXJVcmwoKSkgKyB0aGlzLm5vcm1hbGl6ZVJlc291cmNlUGF0aChyZXNvdXJjZVBhdGgpLCB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB0aGlzLmNvbnZlcnRIdHRwSGVhZGVycyh0aGlzLmdldEhlYWRlcnMoKS5jb25jYXQoaGVhZGVycykpLFxyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB0aGlzLmNvbnZlcnRIdHRwUGFyYW1zKHRoaXMuZ2V0UGFyYW1zKCkuY29uY2F0KHBhcmFtcykpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogVGhlIFBPU1QgbWV0aG9kIGluIHRoZSBSRVNUL0hUVFAgcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSByZXNvdXJjZVBhdGggdGhlIGNvbnRleHQgcGF0aCBvZiB0aGUgcmVzb3VyY2UuXHJcbiAgICAgKiBAcGFyYW0gaW5wdXQgdGhlIGlucHV0IEpTT04gb2JqZWN0IHRoZSBiZSBzZW50IGFzIGEgcGF5bG9hZC5cclxuICAgICAqIEBwYXJhbSBoZWFkZXJzIHRoZSBIVFRQIGhlYWRlcnMgdG8gYmUgc2VudCBpbiB0aGUgcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBwYXJhbXMgdGhlIEhUVFAgcGFyYW1zIHRvIGJlIHNlbnQgaW4gdGhlIHJlcXVlc3QuXHJcbiAgICAgKiBAcmV0dXJucyBBbiBPYnNlcnZhYmxlL1Byb21pc2Ugb2YgdGhlIE91dHB1dC5cclxuICAgICAqL1xyXG4gICAgcHVibGljIHBvc3QocmVzb3VyY2VQYXRoOiBzdHJpbmcsIGlucHV0OiBJTiwgaGVhZGVyczogQXBpSGVhZGVyW10gPSBbXSwgcGFyYW1zOiBBcGlQYXJhbVtdID0gW10pIDogT2JzZXJ2YWJsZTxPVVQ+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LnBvc3Q8T1VUPihcclxuICAgICAgICAgICAgdGhpcy5ub3JtYWxpemVBcGlTZXJ2ZXJVcmwodGhpcy5nZXRBcGlTZXJ2ZXJVcmwoKSkgKyB0aGlzLm5vcm1hbGl6ZVJlc291cmNlUGF0aChyZXNvdXJjZVBhdGgpLCBpbnB1dCwge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczogdGhpcy5jb252ZXJ0SHR0cEhlYWRlcnModGhpcy5nZXRIZWFkZXJzKCkuY29uY2F0KGhlYWRlcnMpKSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczogdGhpcy5jb252ZXJ0SHR0cFBhcmFtcyh0aGlzLmdldFBhcmFtcygpLmNvbmNhdChwYXJhbXMpKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFRoZSBQVVQgbWV0aG9kIGluIHRoZSBSRVNUL0hUVFAgcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSByZXNvdXJjZVBhdGggdGhlIGNvbnRleHQgcGF0aCBvZiB0aGUgcmVzb3VyY2UuXHJcbiAgICAgKiBAcGFyYW0gaW5wdXQgdGhlIGlucHV0IEpTT04gb2JqZWN0IHRoZSBiZSBzZW50IGFzIGEgcGF5bG9hZC5cclxuICAgICAqIEBwYXJhbSBoZWFkZXJzIHRoZSBIVFRQIGhlYWRlcnMgdG8gYmUgc2VudCBpbiB0aGUgcmVxdWVzdC5cclxuICAgICAqIEBwYXJhbSBwYXJhbXMgdGhlIEhUVFAgcGFyYW1zIHRvIGJlIHNlbnQgaW4gdGhlIHJlcXVlc3QuXHJcbiAgICAgKiBAcmV0dXJucyBBbiBPYnNlcnZhYmxlL1Byb21pc2Ugb2YgdGhlIE91dHB1dC5cclxuICAgICAqL1xyXG4gICAgcHVibGljIHB1dChyZXNvdXJjZVBhdGg6IHN0cmluZywgaW5wdXQ6IElOLCBoZWFkZXJzOiBBcGlIZWFkZXJbXSA9IFtdLCBwYXJhbXM6IEFwaVBhcmFtW10gPSBbXSkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnQucHV0PE9VVD4oXHJcbiAgICAgICAgICAgIHRoaXMubm9ybWFsaXplQXBpU2VydmVyVXJsKHRoaXMuZ2V0QXBpU2VydmVyVXJsKCkpICsgdGhpcy5ub3JtYWxpemVSZXNvdXJjZVBhdGgocmVzb3VyY2VQYXRoKSwgaW5wdXQsIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHRoaXMuY29udmVydEh0dHBIZWFkZXJzKHRoaXMuZ2V0SGVhZGVycygpLmNvbmNhdChoZWFkZXJzKSksXHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHRoaXMuY29udmVydEh0dHBQYXJhbXModGhpcy5nZXRQYXJhbXMoKS5jb25jYXQocGFyYW1zKSlcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBUaGUgREVMRVRFIG1ldGhvZCBpbiB0aGUgUkVTVC9IVFRQIHJlcXVlc3QuXHJcbiAgICAgKiBAcGFyYW0gcmVzb3VyY2VQYXRoIHRoZSBjb250ZXh0IHBhdGggb2YgdGhlIHJlc291cmNlLlxyXG4gICAgICogQHBhcmFtIGhlYWRlcnMgdGhlIEhUVFAgaGVhZGVycyB0byBiZSBzZW50IGluIHRoZSByZXF1ZXN0LlxyXG4gICAgICogQHBhcmFtIHBhcmFtcyB0aGUgSFRUUCBwYXJhbXMgdG8gYmUgc2VudCBpbiB0aGUgcmVxdWVzdC5cclxuICAgICAqIEByZXR1cm5zIEFuIE9ic2VydmFibGUvUHJvbWlzZSBvZiB0aGUgT3V0cHV0LlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZGVsZXRlKHJlc291cmNlUGF0aDogc3RyaW5nLCBoZWFkZXJzOiBBcGlIZWFkZXJbXSA9IFtdLCBwYXJhbXM6IEFwaVBhcmFtW10gPSBbXSkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnQuZGVsZXRlPE9VVD4oXHJcbiAgICAgICAgICAgIHRoaXMubm9ybWFsaXplQXBpU2VydmVyVXJsKHRoaXMuZ2V0QXBpU2VydmVyVXJsKCkpICsgdGhpcy5ub3JtYWxpemVSZXNvdXJjZVBhdGgocmVzb3VyY2VQYXRoKSwge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczogdGhpcy5jb252ZXJ0SHR0cEhlYWRlcnModGhpcy5nZXRIZWFkZXJzKCkuY29uY2F0KGhlYWRlcnMpKSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczogdGhpcy5jb252ZXJ0SHR0cFBhcmFtcyh0aGlzLmdldFBhcmFtcygpLmNvbmNhdChwYXJhbXMpKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIERlZmluZXMgaWYgdGhlIGNvbW11bmljYXRpb24gc2hvdWxkIGJlIGVuY3JpcHRlZCB1c2luZyBTU0wvVFNMLlxyXG4gICAgICogV2hldGhlciB0cnVlLCBIVFRQUyBzaG91bGQgYmUgdXNlZCwgb3RoZXJ3aXNlLCBpdCB1c2VzIEhUVFAuXHJcbiAgICAgKiBUaGlzIG1ldGhvZCBtaWdodCBiZSByZWRlZmluZWQgYnkgdGhlIGNvbmNyZXRlIEFQSSBjbGllbnRcclxuICAgICAqIHNlcnZpY2UuIFRoZSBkZWZhdWx0IHZhbHVlIGlzIGZhbHNlLlxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgaXNFbmNyaXB0aW9uRW5hYmxlZCgpIDogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTm9ybWFsaXplcyB0aGUgQVBJIFNlcnZlciBVUkwgaW4gb3JkZXIgdG8gaGF2ZSBIVFRQL0hUVFBTIGFuZCB3aXRob3V0ICcvJyBpbiB0aGUgZW5kLlxyXG4gICAgICogQHBhcmFtIGFwaVNlcnZlclVybCBUaGUgQVBJIFNlcnZlciBVUkwuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgbm9ybWFsaXplQXBpU2VydmVyVXJsKGFwaVNlcnZlclVybDogc3RyaW5nKSA6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IG5vcm1hbGl6ZWRBcGlTZXJ2ZXJVcmwgPSBhcGlTZXJ2ZXJVcmw7XHJcbiAgICAgICAgaWYgKCEgbm9ybWFsaXplZEFwaVNlcnZlclVybC5zdGFydHNXaXRoKCdodHRwOi8vJylcclxuICAgICAgICAgICAgJiYgISBub3JtYWxpemVkQXBpU2VydmVyVXJsLnN0YXJ0c1dpdGgoJ2h0dHBzOi8vJykpIHtcclxuICAgICAgICAgICAgbm9ybWFsaXplZEFwaVNlcnZlclVybCA9ICgodGhpcy5pc0VuY3JpcHRpb25FbmFibGVkKCkpID8gXCJodHRwczovL1wiIDogXCJodHRwOi8vXCIpICsgbm9ybWFsaXplZEFwaVNlcnZlclVybDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG5vcm1hbGl6ZWRBcGlTZXJ2ZXJVcmwuZW5kc1dpdGgoJy8nKSkge1xyXG4gICAgICAgICAgICBub3JtYWxpemVkQXBpU2VydmVyVXJsID0gbm9ybWFsaXplZEFwaVNlcnZlclVybC5zdWJzdHIoMCwgbm9ybWFsaXplZEFwaVNlcnZlclVybC5sZW5ndGggLSAxKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5vcm1hbGl6ZWRBcGlTZXJ2ZXJVcmw7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBOb3JtYWxpemVzIHRoZSByZXNvdXJjZSBwYXRoIG9mIGEgUkVTVCBBUEkgY2FsbCBpbiBvcmRlciB0byBzdGFydCB3aXRoICcvJy5cclxuICAgICAqIEBwYXJhbSByZXNvdXJjZVBhdGggVGhlIHJlc291cmNlIHBhdGguXHJcbiAgICAgKiBAcmV0dXJuIFRoZSBub3JtYWxpemVkIHJlc291cmNlIHBhdGguXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgbm9ybWFsaXplUmVzb3VyY2VQYXRoKHJlc291cmNlUGF0aDogc3RyaW5nKSA6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IG5vcm1hbGl6ZWRSZXNvdXJjZVBhdGggPSByZXNvdXJjZVBhdGg7XHJcbiAgICAgICAgaWYgKCEgbm9ybWFsaXplZFJlc291cmNlUGF0aC5zdGFydHNXaXRoKCcvJykpIHtcclxuICAgICAgICAgICAgbm9ybWFsaXplZFJlc291cmNlUGF0aCA9IFwiL1wiICsgbm9ybWFsaXplZFJlc291cmNlUGF0aDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5vcm1hbGl6ZWRSZXNvdXJjZVBhdGg7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDb252ZXJ0IHRoZSBnaXZlbiBBUEkgSGVhZGVycyBpbnRvIEh0dHBIZWFkZXJzLlxyXG4gICAgICogQHBhcmFtIGhlYWRlcnMgVGhlIEFQSSBoZWFkZXJzIHRvIGJlIGNvbnZlcnRlZC5cclxuICAgICAqIEByZXR1cm5zIFRoZSBIdHRwIGhlYWRlcnMgY29udmVydGVkIGZyb20gdGhlIGdpdmVuIEFQSSBoZWFkZXJzLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGNvbnZlcnRIdHRwSGVhZGVycyhoZWFkZXJzOiBBcGlIZWFkZXJbXSkgOiBIdHRwSGVhZGVycyB7XHJcbiAgICAgICAgbGV0IGh0dHBIZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKCk7XHJcbiAgICAgICAgaWYgKGhlYWRlcnMpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaGVhZGVyIG9mIGhlYWRlcnMpIHtcclxuICAgICAgICAgICAgICBodHRwSGVhZGVycyA9IGh0dHBIZWFkZXJzLnNldChoZWFkZXIuaGVhZGVyTmFtZSwgaGVhZGVyLmhlYWRlclZhbHVlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBodHRwSGVhZGVycztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIENvbnZlcnQgdGhlIGdpdmVuIEFQSSBQYXJhbXMgaW50byBIdHRwUGFyYW1zLlxyXG4gICAgICogQHBhcmFtIHBhcmFtcyBUaGUgQVBJIHBhcmFtZXRlcnMgdG8gYmUgY29udmVydGVkLlxyXG4gICAgICogQHJldHVybnMgVGhlIEh0dHAgcGFyYW1ldGVycyBjb252ZXJ0ZWQgZnJvbSB0aGUgZ2l2ZW4gQVBJIHBhcmFtZXRlcnMuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgY29udmVydEh0dHBQYXJhbXMocGFyYW1zOiBBcGlQYXJhbVtdKSA6IEh0dHBQYXJhbXMge1xyXG4gICAgICAgIGxldCBodHRwUGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKTtcclxuICAgICAgICBpZiAocGFyYW1zKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHBhcmFtIG9mIHBhcmFtcykge1xyXG4gICAgICAgICAgICAgIGh0dHBQYXJhbXMgPSBodHRwUGFyYW1zLnNldChwYXJhbS5wYXJhbU5hbWUsIHBhcmFtLnBhcmFtVmFsdWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBodHRwUGFyYW1zO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=