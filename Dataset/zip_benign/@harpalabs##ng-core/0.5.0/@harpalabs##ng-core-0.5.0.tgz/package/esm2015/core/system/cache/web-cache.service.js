/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { Injectable } from '@angular/core';
import { CacheConfig } from './cache.config';
import * as i0 from "@angular/core";
/**
 * Storage Cache Service definition for the Angular (NG) Harpa Framework,
 * based on Session and Local Web Storage.
 *
 * @author Denis Pinheiro
 */
export class WebCacheService {
    /**
     * Constructs the Storage Cache Service object with the initial default values
     * only if the Web Storage is available for the application.
     */
    constructor() {
        this.initStorageCacheAvailability();
        this.config = new CacheConfig();
    }
    configCache(config) {
        /* Implements CacheService.configCache(..) definition. */
        this.initStorageCacheAvailability();
        this.config.set(config);
    }
    set(key, value, transient, expiration) {
        /* Implements CacheService.set(..) definition. */
        this.initStorageCacheAvailability();
        transient = transient != null ? transient : this.config.transient;
        if (transient) {
            this.setTransientEntry(key, value);
        }
        else {
            this.setPersistentEntry(key, value, expiration);
        }
    }
    get(key) {
        /* Implements CacheService.get(..) definition. */
        this.initStorageCacheAvailability();
        let value = this.sessionStorage.getItem(this.config.prefix + key);
        if (!value) {
            value = this.localStorage.getItem(this.config.prefix + key);
        }
        return value;
    }
    remove(key) {
        /* Implements CacheService.remove(..) definition. */
        this.initStorageCacheAvailability();
        let value = this.sessionStorage.getItem(this.config.prefix + key);
        if (value) {
            this.sessionStorage.removeItem(this.config.prefix + key);
        }
        else {
            value = this.localStorage.getItem(this.config.prefix + key);
            if (value) {
                this.localStorage.removeItem(this.config.prefix + key);
                this.localStorage.removeItem(this.config.prefix + key + '_expiration_timestamp');
            }
        }
        return value;
    }
    /**
     * Sets a transient entry in the sessionStorage object.
     * @param key the transient item key.
     * @param value the transient item value.
     */
    setTransientEntry(key, value) {
        this.sessionStorage.setItem(this.config.prefix + key, value);
    }
    /**
     * Sets a not transient entry in the localStorage object.
     * @param key the persistent item key.
     * @param value the persistent item value.
     * @param expiration the number of days for the expiration deadline.
     */
    setPersistentEntry(key, value, expiration) {
        this.localStorage.setItem(this.config.prefix + key, value);
        if (!expiration) {
            expiration = this.config.expiration;
        }
        const expiration_timestamp = (expiration /* minutes */ * 60 /* seconds */ * 1000 /* millis */);
        if (expiration_timestamp > 0) {
            this.localStorage.setItem(this.config.prefix + key + '_expiration_timestamp', String(expiration_timestamp + Date.now() /* millis since 1/1/1970*/));
        }
    }
    cleanExpiratedPersistentEntries() {
        const keysToRemove = [];
        for (let i = 0; i < this.localStorage.length; i++) {
            const key = this.localStorage.key(i);
            if (key && key.endsWith('_expiration_timestamp')) {
                const timestamp = this.localStorage.getItem(key);
                if (Date.now() > Number(timestamp)) {
                    const keySubs = key.substring(0, key.indexOf('_expiration_timestamp'));
                    keysToRemove.push(key);
                    keysToRemove.push(keySubs);
                }
            }
        }
        for (const key of keysToRemove) {
            this.localStorage.removeItem(key);
        }
    }
    initStorageCacheAvailability() {
        if (this.storageAvailable) {
            return;
        }
        /* Availability verification */
        this.storageAvailable = this.checkStorageAvailability('localStorage') && this.checkStorageAvailability('sessionStorage');
        if (!this.storageAvailable) {
            throw new Error('Storage Cache Service (sessionStorage or localStorage) not available.');
        }
        else {
            this.localStorage = window.localStorage;
            this.sessionStorage = window.sessionStorage;
            /** clean the localStorage - the persistent entries*/
            this.cleanExpiratedPersistentEntries();
        }
    }
    /**
     * Checks the availability of Local or Session Storage.
     * Ref: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
     */
    checkStorageAvailability(type) {
        try {
            var storage = window[type];
            const x = '__storage_test__';
            storage.setItem(x, x);
            storage.removeItem(x);
            return true;
        }
        catch (e) {
            return e instanceof DOMException && (
            // everything except Firefox
            e.code === 22 ||
                // Firefox
                e.code === 1014 ||
                // test name field too, because code might not be present
                // everything except Firefox
                e.name === 'QuotaExceededError' ||
                // Firefox
                e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
                // acknowledge QuotaExceededError only if there's something already stored
                storage.length !== 0;
        }
    }
}
WebCacheService.ɵprov = i0.ɵɵdefineInjectable({ factory: function WebCacheService_Factory() { return new WebCacheService(); }, token: WebCacheService, providedIn: "root" });
WebCacheService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
WebCacheService.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2ViLWNhY2hlLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9uZy1jb3JlL3NyYy9jb3JlL3N5c3RlbS9jYWNoZS93ZWItY2FjaGUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7OztHQUlHO0FBRUgsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUczQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7O0FBRTdDOzs7OztHQUtHO0FBSUgsTUFBTSxPQUFPLGVBQWU7SUFzQnhCOzs7T0FHRztJQUNIO1FBQ0ksSUFBSSxDQUFDLDRCQUE0QixFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLFdBQVcsRUFBRSxDQUFDO0lBQ3BDLENBQUM7SUFFTSxXQUFXLENBQUMsTUFBbUI7UUFDbEMseURBQXlEO1FBQ3pELElBQUksQ0FBQyw0QkFBNEIsRUFBRSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFFTSxHQUFHLENBQUMsR0FBVyxFQUFFLEtBQWEsRUFBRSxTQUFtQixFQUFFLFVBQW1CO1FBQzNFLGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsNEJBQTRCLEVBQUUsQ0FBQztRQUNwQyxTQUFTLEdBQUcsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUNsRSxJQUFJLFNBQVMsRUFBRTtZQUNYLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDdEM7YUFBTTtZQUNILElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQ25EO0lBQ0wsQ0FBQztJQUVNLEdBQUcsQ0FBQyxHQUFXO1FBQ2xCLGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsNEJBQTRCLEVBQUUsQ0FBQztRQUNwQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsRSxJQUFJLENBQUUsS0FBSyxFQUFFO1lBQ1QsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1NBQy9EO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLE1BQU0sQ0FBQyxHQUFXO1FBQ3JCLG9EQUFvRDtRQUNwRCxJQUFJLENBQUMsNEJBQTRCLEVBQUUsQ0FBQztRQUNwQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztRQUNsRSxJQUFJLEtBQUssRUFBRTtZQUNQLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1NBQzVEO2FBQU07WUFDSCxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDNUQsSUFBSSxLQUFLLEVBQUU7Z0JBQ1AsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBQ3ZELElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO2FBQ3BGO1NBQ0o7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGlCQUFpQixDQUFDLEdBQVcsRUFBRSxLQUFhO1FBQ2hELElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxrQkFBa0IsQ0FBQyxHQUFXLEVBQUUsS0FBYSxFQUFFLFVBQW1CO1FBQ3RFLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2IsVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1NBQ3ZDO1FBQ0QsTUFBTSxvQkFBb0IsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDL0YsSUFBSSxvQkFBb0IsR0FBRyxDQUFDLEVBQUU7WUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLHVCQUF1QixFQUNwRSxNQUFNLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLDBCQUEwQixDQUFFLENBQUMsQ0FBQztTQUNsRjtJQUNMLENBQUM7SUFFTywrQkFBK0I7UUFDbkMsTUFBTSxZQUFZLEdBQWEsRUFBRSxDQUFDO1FBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNyQyxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLEVBQUU7Z0JBQzlDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNqRCxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUU7b0JBQ2hDLE1BQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDO29CQUN2RSxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUN2QixZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM5QjthQUNKO1NBQ0o7UUFDRCxLQUFLLE1BQU0sR0FBRyxJQUFJLFlBQVksRUFBRTtZQUM1QixJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNyQztJQUNMLENBQUM7SUFFTyw0QkFBNEI7UUFDaEMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDdkIsT0FBTztTQUNWO1FBQ0QsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsY0FBYyxDQUFDLElBQUksSUFBSSxDQUFDLHdCQUF3QixDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDekgsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN4QixNQUFNLElBQUksS0FBSyxDQUFDLHVFQUF1RSxDQUFDLENBQUM7U0FDNUY7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQztZQUN4QyxJQUFJLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7WUFDNUMscURBQXFEO1lBQ3JELElBQUksQ0FBQywrQkFBK0IsRUFBRSxDQUFDO1NBQzFDO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLHdCQUF3QixDQUFDLElBQVk7UUFDekMsSUFBSTtZQUNBLElBQUksT0FBTyxHQUFTLE1BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNsQyxNQUFNLENBQUMsR0FBRyxrQkFBa0IsQ0FBQztZQUM3QixPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN0QixPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3RCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNSLE9BQU8sQ0FBQyxZQUFZLFlBQVksSUFBSTtZQUNoQyw0QkFBNEI7WUFDNUIsQ0FBQyxDQUFDLElBQUksS0FBSyxFQUFFO2dCQUNiLFVBQVU7Z0JBQ1YsQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJO2dCQUNmLHlEQUF5RDtnQkFDekQsNEJBQTRCO2dCQUM1QixDQUFDLENBQUMsSUFBSSxLQUFLLG9CQUFvQjtnQkFDL0IsVUFBVTtnQkFDVixDQUFDLENBQUMsSUFBSSxLQUFLLDRCQUE0QixDQUFDO2dCQUN4QywwRUFBMEU7Z0JBQzFFLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQzs7OztZQW5LSixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQGxpY2Vuc2UgQGhhcnBhbGFicy9uZy1jb3JlXHJcbiAqIChjKSAyMDE4IEhhcnBhIExhYnMsIExUREEuXHJcbiAqIExpY2VuY2U6IE1JVC5cclxuICovXHJcblxyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbXBvcnQgeyBJQ2FjaGVTZXJ2aWNlIH0gZnJvbSAnLi9pLmNhY2hlLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBDYWNoZUNvbmZpZyB9IGZyb20gJy4vY2FjaGUuY29uZmlnJztcclxuXHJcbi8qKlxyXG4gKiBTdG9yYWdlIENhY2hlIFNlcnZpY2UgZGVmaW5pdGlvbiBmb3IgdGhlIEFuZ3VsYXIgKE5HKSBIYXJwYSBGcmFtZXdvcmssXHJcbiAqIGJhc2VkIG9uIFNlc3Npb24gYW5kIExvY2FsIFdlYiBTdG9yYWdlLlxyXG4gKlxyXG4gKiBAYXV0aG9yIERlbmlzIFBpbmhlaXJvXHJcbiAqL1xyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFdlYkNhY2hlU2VydmljZSBpbXBsZW1lbnRzIElDYWNoZVNlcnZpY2Uge1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogVGhlIGNhY2hlIGNvbmZpZ3VyYXRpb24gb2JqZWN0LlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGNvbmZpZzogQ2FjaGVDb25maWc7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBUaGUgV2luZG93LmxvY2FsU3RvcmFnZSByZWZlcmVuY2UuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgbG9jYWxTdG9yYWdlITogU3RvcmFnZTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIFRoZSBXaW5kb3cuc2Vzc2lvblN0b3JhZ2UgcmVmZXJlbmNlLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHNlc3Npb25TdG9yYWdlITogU3RvcmFnZTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIEluZGljYXRlcyBpZiB0aGUgV2ViIFN0b3JhZ2UgaXMgYXZhaWxhYmxlLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHN0b3JhZ2VBdmFpbGFibGUhOiBib29sZWFuO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ29uc3RydWN0cyB0aGUgU3RvcmFnZSBDYWNoZSBTZXJ2aWNlIG9iamVjdCB3aXRoIHRoZSBpbml0aWFsIGRlZmF1bHQgdmFsdWVzXHJcbiAgICAgKiBvbmx5IGlmIHRoZSBXZWIgU3RvcmFnZSBpcyBhdmFpbGFibGUgZm9yIHRoZSBhcHBsaWNhdGlvbi5cclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgdGhpcy5pbml0U3RvcmFnZUNhY2hlQXZhaWxhYmlsaXR5KCk7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBuZXcgQ2FjaGVDb25maWcoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY29uZmlnQ2FjaGUoY29uZmlnOiBDYWNoZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIC8qIEltcGxlbWVudHMgQ2FjaGVTZXJ2aWNlLmNvbmZpZ0NhY2hlKC4uKSBkZWZpbml0aW9uLiAqL1xyXG4gICAgICAgIHRoaXMuaW5pdFN0b3JhZ2VDYWNoZUF2YWlsYWJpbGl0eSgpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnLnNldChjb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXQoa2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcsIHRyYW5zaWVudD86IGJvb2xlYW4sIGV4cGlyYXRpb24/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICAvKiBJbXBsZW1lbnRzIENhY2hlU2VydmljZS5zZXQoLi4pIGRlZmluaXRpb24uICovXHJcbiAgICAgICAgdGhpcy5pbml0U3RvcmFnZUNhY2hlQXZhaWxhYmlsaXR5KCk7XHJcbiAgICAgICAgdHJhbnNpZW50ID0gdHJhbnNpZW50ICE9IG51bGwgPyB0cmFuc2llbnQgOiB0aGlzLmNvbmZpZy50cmFuc2llbnQ7XHJcbiAgICAgICAgaWYgKHRyYW5zaWVudCkge1xyXG4gICAgICAgICAgICB0aGlzLnNldFRyYW5zaWVudEVudHJ5KGtleSwgdmFsdWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0UGVyc2lzdGVudEVudHJ5KGtleSwgdmFsdWUsIGV4cGlyYXRpb24pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0KGtleTogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICAgICAgLyogSW1wbGVtZW50cyBDYWNoZVNlcnZpY2UuZ2V0KC4uKSBkZWZpbml0aW9uLiAqL1xyXG4gICAgICAgIHRoaXMuaW5pdFN0b3JhZ2VDYWNoZUF2YWlsYWJpbGl0eSgpO1xyXG4gICAgICAgIGxldCB2YWx1ZSA9IHRoaXMuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSh0aGlzLmNvbmZpZy5wcmVmaXggKyBrZXkpO1xyXG4gICAgICAgIGlmICghIHZhbHVlKSB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gdGhpcy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLmNvbmZpZy5wcmVmaXggKyBrZXkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlbW92ZShrZXk6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgICAgIC8qIEltcGxlbWVudHMgQ2FjaGVTZXJ2aWNlLnJlbW92ZSguLikgZGVmaW5pdGlvbi4gKi9cclxuICAgICAgICB0aGlzLmluaXRTdG9yYWdlQ2FjaGVBdmFpbGFiaWxpdHkoKTtcclxuICAgICAgICBsZXQgdmFsdWUgPSB0aGlzLnNlc3Npb25TdG9yYWdlLmdldEl0ZW0odGhpcy5jb25maWcucHJlZml4ICsga2V5KTtcclxuICAgICAgICBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKHRoaXMuY29uZmlnLnByZWZpeCArIGtleSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdmFsdWUgPSB0aGlzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuY29uZmlnLnByZWZpeCArIGtleSk7XHJcbiAgICAgICAgICAgIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSh0aGlzLmNvbmZpZy5wcmVmaXggKyBrZXkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSh0aGlzLmNvbmZpZy5wcmVmaXggKyBrZXkgKyAnX2V4cGlyYXRpb25fdGltZXN0YW1wJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogU2V0cyBhIHRyYW5zaWVudCBlbnRyeSBpbiB0aGUgc2Vzc2lvblN0b3JhZ2Ugb2JqZWN0LlxyXG4gICAgICogQHBhcmFtIGtleSB0aGUgdHJhbnNpZW50IGl0ZW0ga2V5LlxyXG4gICAgICogQHBhcmFtIHZhbHVlIHRoZSB0cmFuc2llbnQgaXRlbSB2YWx1ZS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBzZXRUcmFuc2llbnRFbnRyeShrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSh0aGlzLmNvbmZpZy5wcmVmaXggKyBrZXksIHZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldHMgYSBub3QgdHJhbnNpZW50IGVudHJ5IGluIHRoZSBsb2NhbFN0b3JhZ2Ugb2JqZWN0LlxyXG4gICAgICogQHBhcmFtIGtleSB0aGUgcGVyc2lzdGVudCBpdGVtIGtleS5cclxuICAgICAqIEBwYXJhbSB2YWx1ZSB0aGUgcGVyc2lzdGVudCBpdGVtIHZhbHVlLlxyXG4gICAgICogQHBhcmFtIGV4cGlyYXRpb24gdGhlIG51bWJlciBvZiBkYXlzIGZvciB0aGUgZXhwaXJhdGlvbiBkZWFkbGluZS5cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBzZXRQZXJzaXN0ZW50RW50cnkoa2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcsIGV4cGlyYXRpb24/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuY29uZmlnLnByZWZpeCArIGtleSwgdmFsdWUpO1xyXG4gICAgICAgIGlmICghZXhwaXJhdGlvbikge1xyXG4gICAgICAgICAgICBleHBpcmF0aW9uID0gdGhpcy5jb25maWcuZXhwaXJhdGlvbjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgZXhwaXJhdGlvbl90aW1lc3RhbXAgPSAoZXhwaXJhdGlvbiAvKiBtaW51dGVzICovICogNjAgLyogc2Vjb25kcyAqLyAqIDEwMDAgLyogbWlsbGlzICovKTtcclxuICAgICAgICBpZiAoZXhwaXJhdGlvbl90aW1lc3RhbXAgPiAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5jb25maWcucHJlZml4ICsga2V5ICsgJ19leHBpcmF0aW9uX3RpbWVzdGFtcCcsXHJcbiAgICAgICAgICAgICAgICAgICAgU3RyaW5nKGV4cGlyYXRpb25fdGltZXN0YW1wICsgRGF0ZS5ub3coKSAvKiBtaWxsaXMgc2luY2UgMS8xLzE5NzAqLyApKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBjbGVhbkV4cGlyYXRlZFBlcnNpc3RlbnRFbnRyaWVzKCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGtleXNUb1JlbW92ZTogc3RyaW5nW10gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMubG9jYWxTdG9yYWdlLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IHRoaXMubG9jYWxTdG9yYWdlLmtleShpKTtcclxuICAgICAgICAgICAgaWYgKGtleSAmJiBrZXkuZW5kc1dpdGgoJ19leHBpcmF0aW9uX3RpbWVzdGFtcCcpKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB0aW1lc3RhbXAgPSB0aGlzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoRGF0ZS5ub3coKSA+IE51bWJlcih0aW1lc3RhbXApKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5U3VicyA9IGtleS5zdWJzdHJpbmcoMCwga2V5LmluZGV4T2YoJ19leHBpcmF0aW9uX3RpbWVzdGFtcCcpKTtcclxuICAgICAgICAgICAgICAgICAgICBrZXlzVG9SZW1vdmUucHVzaChrZXkpO1xyXG4gICAgICAgICAgICAgICAgICAgIGtleXNUb1JlbW92ZS5wdXNoKGtleVN1YnMpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXNUb1JlbW92ZSkge1xyXG4gICAgICAgICAgICB0aGlzLmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGtleSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgaW5pdFN0b3JhZ2VDYWNoZUF2YWlsYWJpbGl0eSgpIHtcclxuICAgICAgICBpZiAodGhpcy5zdG9yYWdlQXZhaWxhYmxlKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLyogQXZhaWxhYmlsaXR5IHZlcmlmaWNhdGlvbiAqL1xyXG4gICAgICAgIHRoaXMuc3RvcmFnZUF2YWlsYWJsZSA9IHRoaXMuY2hlY2tTdG9yYWdlQXZhaWxhYmlsaXR5KCdsb2NhbFN0b3JhZ2UnKSAmJiB0aGlzLmNoZWNrU3RvcmFnZUF2YWlsYWJpbGl0eSgnc2Vzc2lvblN0b3JhZ2UnKTtcclxuICAgICAgICBpZiAoIXRoaXMuc3RvcmFnZUF2YWlsYWJsZSkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1N0b3JhZ2UgQ2FjaGUgU2VydmljZSAoc2Vzc2lvblN0b3JhZ2Ugb3IgbG9jYWxTdG9yYWdlKSBub3QgYXZhaWxhYmxlLicpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubG9jYWxTdG9yYWdlID0gd2luZG93LmxvY2FsU3RvcmFnZTtcclxuICAgICAgICAgICAgdGhpcy5zZXNzaW9uU3RvcmFnZSA9IHdpbmRvdy5zZXNzaW9uU3RvcmFnZTtcclxuICAgICAgICAgICAgLyoqIGNsZWFuIHRoZSBsb2NhbFN0b3JhZ2UgLSB0aGUgcGVyc2lzdGVudCBlbnRyaWVzKi9cclxuICAgICAgICAgICAgdGhpcy5jbGVhbkV4cGlyYXRlZFBlcnNpc3RlbnRFbnRyaWVzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQ2hlY2tzIHRoZSBhdmFpbGFiaWxpdHkgb2YgTG9jYWwgb3IgU2Vzc2lvbiBTdG9yYWdlLlxyXG4gICAgICogUmVmOiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2ViX1N0b3JhZ2VfQVBJL1VzaW5nX3RoZV9XZWJfU3RvcmFnZV9BUElcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBjaGVja1N0b3JhZ2VBdmFpbGFiaWxpdHkodHlwZTogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgdmFyIHN0b3JhZ2UgPSAoPGFueT53aW5kb3cpW3R5cGVdO1xyXG4gICAgICAgICAgICBjb25zdCB4ID0gJ19fc3RvcmFnZV90ZXN0X18nO1xyXG4gICAgICAgICAgICBzdG9yYWdlLnNldEl0ZW0oeCwgeCk7XHJcbiAgICAgICAgICAgIHN0b3JhZ2UucmVtb3ZlSXRlbSh4KTtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICByZXR1cm4gZSBpbnN0YW5jZW9mIERPTUV4Y2VwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAvLyBldmVyeXRoaW5nIGV4Y2VwdCBGaXJlZm94XHJcbiAgICAgICAgICAgICAgICBlLmNvZGUgPT09IDIyIHx8XHJcbiAgICAgICAgICAgICAgICAvLyBGaXJlZm94XHJcbiAgICAgICAgICAgICAgICBlLmNvZGUgPT09IDEwMTQgfHxcclxuICAgICAgICAgICAgICAgIC8vIHRlc3QgbmFtZSBmaWVsZCB0b28sIGJlY2F1c2UgY29kZSBtaWdodCBub3QgYmUgcHJlc2VudFxyXG4gICAgICAgICAgICAgICAgLy8gZXZlcnl0aGluZyBleGNlcHQgRmlyZWZveFxyXG4gICAgICAgICAgICAgICAgZS5uYW1lID09PSAnUXVvdGFFeGNlZWRlZEVycm9yJyB8fFxyXG4gICAgICAgICAgICAgICAgLy8gRmlyZWZveFxyXG4gICAgICAgICAgICAgICAgZS5uYW1lID09PSAnTlNfRVJST1JfRE9NX1FVT1RBX1JFQUNIRUQnKSAmJlxyXG4gICAgICAgICAgICAgICAgLy8gYWNrbm93bGVkZ2UgUXVvdGFFeGNlZWRlZEVycm9yIG9ubHkgaWYgdGhlcmUncyBzb21ldGhpbmcgYWxyZWFkeSBzdG9yZWRcclxuICAgICAgICAgICAgICAgIHN0b3JhZ2UubGVuZ3RoICE9PSAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19