/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class SystemContextService {
    constructor() { }
    set applicationId(id) {
        this._applicationId = id;
    }
    get applicationId() {
        return this._applicationId;
    }
    get cacheService() {
        return this._cacheService;
    }
    set cacheService(value) {
        this._cacheService = value;
    }
    get i18nService() {
        return this._i18nService;
    }
    set i18nService(value) {
        this._i18nService = value;
    }
    get version() {
        return this._version;
    }
    set version(value) {
        this._version = value;
    }
    get build() {
        return this._build;
    }
    set build(value) {
        this._build = value;
    }
}
SystemContextService.ɵprov = i0.ɵɵdefineInjectable({ factory: function SystemContextService_Factory() { return new SystemContextService(); }, token: SystemContextService, providedIn: "root" });
SystemContextService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
SystemContextService.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3lzdGVtLWNvbnRleHQuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL25nLWNvcmUvc3JjL2NvcmUvc3lzdGVtL2NvbnRleHQvc3lzdGVtLWNvbnRleHQuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7OztHQUlHO0FBRUgsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFRM0MsTUFBTSxPQUFPLG9CQUFvQjtJQUU3QixnQkFBZ0IsQ0FBQztJQVlqQixJQUFXLGFBQWEsQ0FBQyxFQUFVO1FBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFRCxJQUFXLGFBQWE7UUFDcEIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDO0lBQy9CLENBQUM7SUFFRCxJQUFXLFlBQVk7UUFDbkIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQzlCLENBQUM7SUFFRCxJQUFXLFlBQVksQ0FBQyxLQUFvQjtRQUN4QyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUM3QixDQUFDO0lBRUQsSUFBVyxXQUFXLENBQUMsS0FBbUI7UUFDdEMsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUVELElBQVcsT0FBTztRQUNkLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN6QixDQUFDO0lBRUQsSUFBVyxPQUFPLENBQUMsS0FBYTtRQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUMxQixDQUFDO0lBRUQsSUFBVyxLQUFLO1FBQ1osT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxJQUFXLEtBQUssQ0FBQyxLQUFhO1FBQzFCLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3hCLENBQUM7Ozs7WUF2REosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEBsaWNlbnNlIEBoYXJwYWxhYnMvbmctY29yZVxyXG4gKiAoYykgMjAxOCBIYXJwYSBMYWJzLCBMVERBLlxyXG4gKiBMaWNlbmNlOiBNSVQuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgSUNhY2hlU2VydmljZSB9IGZyb20gJy4vLi4vY2FjaGUvaS5jYWNoZS5zZXJ2aWNlJztcclxuaW1wb3J0IHsgSUkxOG5TZXJ2aWNlIH0gZnJvbSAnLi4vaTE4bi9pLmkxOG4uc2VydmljZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFN5c3RlbUNvbnRleHRTZXJ2aWNlIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHsgfVxyXG5cclxuICAgIHByaXZhdGUgX2FwcGxpY2F0aW9uSWQhOiBudW1iZXI7XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FjaGVTZXJ2aWNlITogSUNhY2hlU2VydmljZTtcclxuXHJcbiAgICBwcml2YXRlIF9pMThuU2VydmljZSE6IElJMThuU2VydmljZTtcclxuXHJcbiAgICBwcml2YXRlIF92ZXJzaW9uITogc3RyaW5nO1xyXG5cclxuICAgIHByaXZhdGUgX2J1aWxkITogbnVtYmVyO1xyXG5cclxuICAgIHB1YmxpYyBzZXQgYXBwbGljYXRpb25JZChpZDogbnVtYmVyKSB7XHJcbiAgICAgICAgdGhpcy5fYXBwbGljYXRpb25JZCA9IGlkO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXQgYXBwbGljYXRpb25JZCgpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9hcHBsaWNhdGlvbklkO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXQgY2FjaGVTZXJ2aWNlKCk6IElDYWNoZVNlcnZpY2Uge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9jYWNoZVNlcnZpY2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldCBjYWNoZVNlcnZpY2UodmFsdWU6IElDYWNoZVNlcnZpY2UpIHtcclxuICAgICAgICB0aGlzLl9jYWNoZVNlcnZpY2UgPSB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0IGkxOG5TZXJ2aWNlKCk6IElJMThuU2VydmljZSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2kxOG5TZXJ2aWNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXQgaTE4blNlcnZpY2UodmFsdWU6IElJMThuU2VydmljZSkge1xyXG4gICAgICAgIHRoaXMuX2kxOG5TZXJ2aWNlID0gdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldCB2ZXJzaW9uKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZlcnNpb247XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldCB2ZXJzaW9uKHZhbHVlOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl92ZXJzaW9uID0gdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldCBidWlsZCgpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9idWlsZDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0IGJ1aWxkKHZhbHVlOiBudW1iZXIpIHtcclxuICAgICAgICB0aGlzLl9idWlsZCA9IHZhbHVlO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=