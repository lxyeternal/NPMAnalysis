/**
 * @license @harpalabs/ng-core v1.0.0
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { I18nPipe } from './system/i18n';
/**
 * The Angular Core Module for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
export class CoreModule {
}
CoreModule.decorators = [
    { type: NgModule, args: [{
                declarations: [I18nPipe],
                imports: [HttpClientModule],
                exports: [HttpClientModule, I18nPipe]
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29yZS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9uZy1jb3JlL3NyYy9jb3JlL2NvcmUubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7O0dBSUc7QUFDSCxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBRXhELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFekM7OztHQUdHO0FBTUgsTUFBTSxPQUFPLFVBQVU7OztZQUx0QixRQUFRLFNBQUM7Z0JBQ04sWUFBWSxFQUFFLENBQUUsUUFBUSxDQUFFO2dCQUMxQixPQUFPLEVBQUUsQ0FBRSxnQkFBZ0IsQ0FBRTtnQkFDN0IsT0FBTyxFQUFFLENBQUUsZ0JBQWdCLEVBQUUsUUFBUSxDQUFFO2FBQzFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEBsaWNlbnNlIEBoYXJwYWxhYnMvbmctY29yZSB2MS4wLjBcclxuICogKGMpIDIwMTggSGFycGEgTGFicywgTFREQS5cclxuICogTGljZW5jZTogTUlULlxyXG4gKi9cclxuaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50TW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vbi9odHRwXCI7XHJcblxyXG5pbXBvcnQgeyBJMThuUGlwZSB9IGZyb20gJy4vc3lzdGVtL2kxOG4nO1xyXG5cclxuLyoqXHJcbiAqIFRoZSBBbmd1bGFyIENvcmUgTW9kdWxlIGZvciB0aGUgQW5ndWxhciAoTkcpIEhhcnBhIEZyYW1ld29yay5cclxuICogQGF1dGhvciBEZW5pcyBQaW5oZWlyb1xyXG4gKi9cclxuQE5nTW9kdWxlKHtcclxuICAgIGRlY2xhcmF0aW9uczogWyBJMThuUGlwZSBdLFxyXG4gICAgaW1wb3J0czogWyBIdHRwQ2xpZW50TW9kdWxlIF0sXHJcbiAgICBleHBvcnRzOiBbIEh0dHBDbGllbnRNb2R1bGUsIEkxOG5QaXBlIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIENvcmVNb2R1bGUge31cclxuIl19