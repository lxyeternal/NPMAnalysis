/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 *
 * Generic Entity model for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
export class Entity {
    constructor() {
        this.id = 0;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW50aXR5LW1vZGVsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvbmctY29yZS9zcmMvY29yZS9idXNpbmVzcy9tb2RlbC9lbnRpdHktbW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7R0FPRztBQUNILE1BQU0sT0FBZ0IsTUFBTTtJQUE1QjtRQUNJLE9BQUUsR0FBVyxDQUFDLENBQUM7SUFDbkIsQ0FBQztDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEBsaWNlbnNlIEBoYXJwYWxhYnMvbmctY29yZVxyXG4gKiAoYykgMjAxOCBIYXJwYSBMYWJzLCBMVERBLlxyXG4gKiBMaWNlbmNlOiBNSVQuXHJcbiAqXHJcbiAqIEdlbmVyaWMgRW50aXR5IG1vZGVsIGZvciB0aGUgQW5ndWxhciAoTkcpIEhhcnBhIEZyYW1ld29yay5cclxuICogQGF1dGhvciBEZW5pcyBQaW5oZWlyb1xyXG4gKi9cclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEVudGl0eSB7XHJcbiAgICBpZDogbnVtYmVyID0gMDtcclxufVxyXG4iXX0=