import { Pipe } from '@angular/core';
import { I18nService } from './i18n.service';
export class I18nPipe {
    constructor(i18nService) {
        this.i18nService = i18nService;
    }
    transform(key, type) {
        let translated;
        if (type) {
            if (type === 'msg') {
                translated = this.i18nService.getMessage(key);
            }
            else {
                translated = this.i18nService.getLabel(key);
            }
        }
        else {
            translated = this.i18nService.getLabel(key);
            if (!translated) {
                translated = this.i18nService.getMessage(key);
            }
        }
        return translated;
    }
}
I18nPipe.decorators = [
    { type: Pipe, args: [{ name: 'i18n' },] }
];
I18nPipe.ctorParameters = () => [
    { type: I18nService }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaTE4bi5waXBlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvbmctY29yZS9zcmMvY29yZS9zeXN0ZW0vaTE4bi9pMThuLnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFpQixJQUFJLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDcEQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBRzdDLE1BQU0sT0FBTyxRQUFRO0lBRWpCLFlBQW9CLFdBQXdCO1FBQXhCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO0lBQzVDLENBQUM7SUFFRCxTQUFTLENBQUMsR0FBVyxFQUFFLElBQWE7UUFDaEMsSUFBSSxVQUFrQixDQUFDO1FBQ3ZCLElBQUksSUFBSSxFQUFFO1lBQ04sSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFO2dCQUNoQixVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDakQ7aUJBQU07Z0JBQ0gsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9DO1NBQ0o7YUFBTTtZQUNILFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNiLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUNqRDtTQUNKO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQzs7O1lBckJKLElBQUksU0FBQyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7OztZQUZiLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlVHJhbnNmb3JtLCBQaXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEkxOG5TZXJ2aWNlIH0gZnJvbSAnLi9pMThuLnNlcnZpY2UnO1xyXG5cclxuQFBpcGUoeyBuYW1lOiAnaTE4bicgfSlcclxuZXhwb3J0IGNsYXNzIEkxOG5QaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSB7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBpMThuU2VydmljZTogSTE4blNlcnZpY2UpIHtcclxuICAgIH1cclxuXHJcbiAgICB0cmFuc2Zvcm0oa2V5OiBzdHJpbmcsIHR5cGU/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCB0cmFuc2xhdGVkOiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKHR5cGUpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGUgPT09ICdtc2cnKSB7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2xhdGVkID0gdGhpcy5pMThuU2VydmljZS5nZXRNZXNzYWdlKGtleSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2xhdGVkID0gdGhpcy5pMThuU2VydmljZS5nZXRMYWJlbChrZXkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdHJhbnNsYXRlZCA9IHRoaXMuaTE4blNlcnZpY2UuZ2V0TGFiZWwoa2V5KTtcclxuICAgICAgICAgICAgaWYgKCF0cmFuc2xhdGVkKSB7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2xhdGVkID0gdGhpcy5pMThuU2VydmljZS5nZXRNZXNzYWdlKGtleSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRyYW5zbGF0ZWQ7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==