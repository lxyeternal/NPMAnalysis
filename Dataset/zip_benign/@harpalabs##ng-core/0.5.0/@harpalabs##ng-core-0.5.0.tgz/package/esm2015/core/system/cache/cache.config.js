/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
/**
 * Cache Config definition for the Angular (NG) Harpa Framework.
 *
 * @author Denis Pinheiro
 */
export class CacheConfig {
    constructor() {
        /**
         * The prefix for the all key in the cache service to avoid colisions.
         */
        this.prefix = '@harpalabs/ng-core/';
        /**
         * Specify if the cached item is transient or not.
         */
        this.transient = true;
        /**
         * The expiration time (in minutes) for the cached item life time (default is 0).
         */
        this.expiration = 0;
    }
    /**
     * Sets new cache configuration values. Any parameter not defined will
     * remains with the default value.
     * @param config the cache configuration object.
     */
    set(config) {
        this.prefix = (config.prefix != null) ? config.prefix : this.prefix;
        this.transient = (config.transient != null) ? config.transient : this.transient;
        this.expiration = (config.expiration != null) ? config.expiration : this.expiration;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FjaGUuY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvbmctY29yZS9zcmMvY29yZS9zeXN0ZW0vY2FjaGUvY2FjaGUuY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7O0dBSUc7QUFFSDs7OztHQUlHO0FBQ0gsTUFBTSxPQUFPLFdBQVc7SUFBeEI7UUFDSTs7V0FFRztRQUNILFdBQU0sR0FBRyxxQkFBcUIsQ0FBQztRQUUvQjs7V0FFRztRQUNILGNBQVMsR0FBRyxJQUFJLENBQUM7UUFFakI7O1dBRUc7UUFDSCxlQUFVLEdBQUcsQ0FBQyxDQUFDO0lBYW5CLENBQUM7SUFYRzs7OztPQUlHO0lBQ0gsR0FBRyxDQUFDLE1BQW1CO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3BFLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO0lBQ3hGLENBQUM7Q0FFSiIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBAbGljZW5zZSBAaGFycGFsYWJzL25nLWNvcmVcclxuICogKGMpIDIwMTggSGFycGEgTGFicywgTFREQS5cclxuICogTGljZW5jZTogTUlULlxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBDYWNoZSBDb25maWcgZGVmaW5pdGlvbiBmb3IgdGhlIEFuZ3VsYXIgKE5HKSBIYXJwYSBGcmFtZXdvcmsuXHJcbiAqXHJcbiAqIEBhdXRob3IgRGVuaXMgUGluaGVpcm9cclxuICovXHJcbmV4cG9ydCBjbGFzcyBDYWNoZUNvbmZpZyB7XHJcbiAgICAvKipcclxuICAgICAqIFRoZSBwcmVmaXggZm9yIHRoZSBhbGwga2V5IGluIHRoZSBjYWNoZSBzZXJ2aWNlIHRvIGF2b2lkIGNvbGlzaW9ucy5cclxuICAgICAqL1xyXG4gICAgcHJlZml4ID0gJ0BoYXJwYWxhYnMvbmctY29yZS8nO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogU3BlY2lmeSBpZiB0aGUgY2FjaGVkIGl0ZW0gaXMgdHJhbnNpZW50IG9yIG5vdC5cclxuICAgICAqL1xyXG4gICAgdHJhbnNpZW50ID0gdHJ1ZTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIFRoZSBleHBpcmF0aW9uIHRpbWUgKGluIG1pbnV0ZXMpIGZvciB0aGUgY2FjaGVkIGl0ZW0gbGlmZSB0aW1lIChkZWZhdWx0IGlzIDApLlxyXG4gICAgICovXHJcbiAgICBleHBpcmF0aW9uID0gMDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIFNldHMgbmV3IGNhY2hlIGNvbmZpZ3VyYXRpb24gdmFsdWVzLiBBbnkgcGFyYW1ldGVyIG5vdCBkZWZpbmVkIHdpbGxcclxuICAgICAqIHJlbWFpbnMgd2l0aCB0aGUgZGVmYXVsdCB2YWx1ZS5cclxuICAgICAqIEBwYXJhbSBjb25maWcgdGhlIGNhY2hlIGNvbmZpZ3VyYXRpb24gb2JqZWN0LlxyXG4gICAgICovXHJcbiAgICBzZXQoY29uZmlnOiBDYWNoZUNvbmZpZykge1xyXG4gICAgICAgIHRoaXMucHJlZml4ID0gKGNvbmZpZy5wcmVmaXggIT0gbnVsbCkgPyBjb25maWcucHJlZml4IDogdGhpcy5wcmVmaXg7XHJcbiAgICAgICAgdGhpcy50cmFuc2llbnQgPSAoY29uZmlnLnRyYW5zaWVudCAhPSBudWxsKSA/IGNvbmZpZy50cmFuc2llbnQgOiB0aGlzLnRyYW5zaWVudDtcclxuICAgICAgICB0aGlzLmV4cGlyYXRpb24gPSAoY29uZmlnLmV4cGlyYXRpb24gIT0gbnVsbCkgPyBjb25maWcuZXhwaXJhdGlvbiA6IHRoaXMuZXhwaXJhdGlvbjtcclxuICAgIH1cclxuXHJcbn1cclxuIl19