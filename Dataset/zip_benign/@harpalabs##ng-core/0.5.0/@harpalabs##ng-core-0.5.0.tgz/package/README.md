# Harpa Framework - Angular (NG) Core Module - 0.5.X
This package is the core module of the Angular (NG) Harpa Framework for Web solution using Angular 11+.


## Architecture
The Harpa Framework is a reference architecture implementation for building Enterprise Application using a layered architecture.
The main layers are the Presentation layer, Business layer and the Integration layer. Each layer is composed by components which 
have specifics responsabilities. Another System wide layer is also provided, where there are utilities components to support the
others layers. Those layers and components are based on the well known design patterns and best practices for building Enterprise
Applications.

The Presentation layer contains views and controllers components, which are responsible for handling both the human and systems 
interaction. User interfaces views and controllers are examples of components that handle human interaction. APIs controllers, 
like REST and Web Services, are examples of controllers which handle systems communication/interaction. Then, the presentation
layer is responsible to present the result data of the system performed operations. Componenets from the presentation layer should
only communicate with the Business and System layer components.

The Business layer contains the model and the services components. Both are responsible to specify the model for the application
domain and the placeholder for the business rules implementation. All presentation controllers components should delegate the operations
to the services components using business model objects to hold the domain data to execute the business rules. Business services should
communicate with the Integration components in order to access remote data and services, like database, messaging or legacy systems.

The Integration layer contains all the middleware components to communicate with remote systems, i.e., database, messaging, e-mail, sms,
filestore, REST and WebServices APIs, mainframe, and others remote systems. All the complexities to interact with other systems shoul be
in the Integration Layer.

Finally, in the System layer is found the utilities components, like cache, configuration, error handling, and others system wide components.

