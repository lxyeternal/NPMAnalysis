(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http')) :
    typeof define === 'function' && define.amd ? define('@harpalabs/ng-core', ['exports', '@angular/core', '@angular/common/http'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.harpalabs = global.harpalabs || {}, global.harpalabs['ng-core'] = {}), global.ng.core, global.ng.common.http));
}(this, (function (exports, i0, http) { 'use strict';

    var I18nService = /** @class */ (function () {
        function I18nService() {
            this._locale = '';
            this.i18nCache = new Map();
        }
        I18nService.prototype.getLabel = function (key, locale) {
            return this.get(key, '/assets/i18n/labels.json', locale);
        };
        I18nService.prototype.getMessage = function (property, parameters, locale) {
            var msg = this.get(property, '/assets/i18n/messages.json', locale);
            var text = msg;
            if (parameters) {
                Object.keys(parameters).forEach(function (prop) {
                    var value = parameters[prop];
                    text = text.replace("{" + prop + "}", value);
                });
            }
            return text;
        };
        I18nService.prototype.get = function (property, resource, locale) {
            if (!locale) {
                locale = this._locale;
            }
            // console.log('LOCALE: ' + locale);
            if (locale) {
                resource = resource.replace('.json', '-' + locale + '.json');
            }
            // console.log('RESOURCE: ' + resource);
            var props = this.loadJSON(resource);
            if (props[property]) {
                return props[property];
            }
            else {
                return property;
            }
        };
        Object.defineProperty(I18nService.prototype, "locale", {
            set: function (locale) {
                // console.log('LOCALE: ' + locale);
                this._locale = locale;
            },
            enumerable: false,
            configurable: true
        });
        I18nService.prototype.loadJSON = function (filePath) {
            var cachedJson = this.i18nCache.get(filePath);
            if (!cachedJson) {
                var json = this.loadTextFileAjaxSync(filePath, 'application/json');
                if (json) {
                    cachedJson = JSON.parse(json);
                    this.i18nCache.set(filePath, cachedJson);
                }
            }
            return cachedJson;
        };
        I18nService.prototype.loadTextFileAjaxSync = function (filePath, mimeType) {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.open('GET', filePath, false);
            if (mimeType != null) {
                if (xmlhttp.overrideMimeType) {
                    xmlhttp.overrideMimeType(mimeType);
                }
            }
            xmlhttp.send();
            if (xmlhttp.status === 200) {
                return xmlhttp.responseText;
            }
            else {
                return null;
            }
        };
        return I18nService;
    }());
    I18nService.ɵprov = i0.ɵɵdefineInjectable({ factory: function I18nService_Factory() { return new I18nService(); }, token: I18nService, providedIn: "root" });
    I18nService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];

    var I18nPipe = /** @class */ (function () {
        function I18nPipe(i18nService) {
            this.i18nService = i18nService;
        }
        I18nPipe.prototype.transform = function (key, type) {
            var translated;
            if (type) {
                if (type === 'msg') {
                    translated = this.i18nService.getMessage(key);
                }
                else {
                    translated = this.i18nService.getLabel(key);
                }
            }
            else {
                translated = this.i18nService.getLabel(key);
                if (!translated) {
                    translated = this.i18nService.getMessage(key);
                }
            }
            return translated;
        };
        return I18nPipe;
    }());
    I18nPipe.decorators = [
        { type: i0.Pipe, args: [{ name: 'i18n' },] }
    ];
    I18nPipe.ctorParameters = function () { return [
        { type: I18nService }
    ]; };

    /**
     * @license @harpalabs/ng-core v1.0.0
     * (c) 2018 Harpa Labs, LTDA.
     * Licence: MIT.
     */
    /**
     * The Angular Core Module for the Angular (NG) Harpa Framework.
     * @author Denis Pinheiro
     */
    var CoreModule = /** @class */ (function () {
        function CoreModule() {
        }
        return CoreModule;
    }());
    CoreModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [I18nPipe],
                    imports: [http.HttpClientModule],
                    exports: [http.HttpClientModule, I18nPipe]
                },] }
    ];

    /**
     * @license @harpalabs/ng-core
     * (c) 2018 Harpa Labs, LTDA.
     * Licence: MIT.
     *
     * Generic Entity model for the Angular (NG) Harpa Framework.
     * @author Denis Pinheiro
     */
    var Entity = /** @class */ (function () {
        function Entity() {
            this.id = 0;
        }
        return Entity;
    }());

    /**
     * Generic Entity model for the Angular (NG) Harpa Framework.
     * @author Denis Pinheiro
     */
    var BusinessService = /** @class */ (function () {
        function BusinessService() {
        }
        return BusinessService;
    }());

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from) {
        for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
            to[j] = from[i];
        return to;
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }
    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * Generic API Client service for the Angular (NG) Harpa Framework.
     *
     * @author Denis Pinheiro
     */
    var ApiClientService = /** @class */ (function () {
        function ApiClientService(httpClient) {
            this.httpClient = httpClient;
        }
        /**
         * Get the headers for all HTTP requests.
         * This method might be redefined by the concrete
         * API client service if is need to send
         * headers data in all HTTP requests.
         */
        ApiClientService.prototype.getHeaders = function () {
            return [];
        };
        /**
         * Get the params for all HTTP requests.
         * This method might be redefined by the concrete
         * API client service if is need to send
         * params data in all HTTP requests.
         */
        ApiClientService.prototype.getParams = function () {
            return [];
        };
        /**
         * The GET method in the REST/HTTP request.
         * @param resourcePath the context path of the resource.
         * @param headers the HTTP headers to be sent in the request.
         * @param params the HTTP params to be sent in the request.
         * @returns An Observable/Promise of the Output.
         */
        ApiClientService.prototype.get = function (resourcePath, headers, params) {
            if (headers === void 0) { headers = []; }
            if (params === void 0) { params = []; }
            return this.httpClient.get(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), {
                headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
                params: this.convertHttpParams(this.getParams().concat(params))
            });
        };
        /**
         * The POST method in the REST/HTTP request.
         * @param resourcePath the context path of the resource.
         * @param input the input JSON object the be sent as a payload.
         * @param headers the HTTP headers to be sent in the request.
         * @param params the HTTP params to be sent in the request.
         * @returns An Observable/Promise of the Output.
         */
        ApiClientService.prototype.post = function (resourcePath, input, headers, params) {
            if (headers === void 0) { headers = []; }
            if (params === void 0) { params = []; }
            return this.httpClient.post(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), input, {
                headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
                params: this.convertHttpParams(this.getParams().concat(params))
            });
        };
        /**
         * The PUT method in the REST/HTTP request.
         * @param resourcePath the context path of the resource.
         * @param input the input JSON object the be sent as a payload.
         * @param headers the HTTP headers to be sent in the request.
         * @param params the HTTP params to be sent in the request.
         * @returns An Observable/Promise of the Output.
         */
        ApiClientService.prototype.put = function (resourcePath, input, headers, params) {
            if (headers === void 0) { headers = []; }
            if (params === void 0) { params = []; }
            return this.httpClient.put(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), input, {
                headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
                params: this.convertHttpParams(this.getParams().concat(params))
            });
        };
        /**
         * The DELETE method in the REST/HTTP request.
         * @param resourcePath the context path of the resource.
         * @param headers the HTTP headers to be sent in the request.
         * @param params the HTTP params to be sent in the request.
         * @returns An Observable/Promise of the Output.
         */
        ApiClientService.prototype.delete = function (resourcePath, headers, params) {
            if (headers === void 0) { headers = []; }
            if (params === void 0) { params = []; }
            return this.httpClient.delete(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), {
                headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
                params: this.convertHttpParams(this.getParams().concat(params))
            });
        };
        /**
         * Defines if the communication should be encripted using SSL/TSL.
         * Whether true, HTTPS should be used, otherwise, it uses HTTP.
         * This method might be redefined by the concrete API client
         * service. The default value is false.
         */
        ApiClientService.prototype.isEncriptionEnabled = function () {
            return false;
        };
        /**
         * Normalizes the API Server URL in order to have HTTP/HTTPS and without '/' in the end.
         * @param apiServerUrl The API Server URL.
         */
        ApiClientService.prototype.normalizeApiServerUrl = function (apiServerUrl) {
            var normalizedApiServerUrl = apiServerUrl;
            if (!normalizedApiServerUrl.startsWith('http://')
                && !normalizedApiServerUrl.startsWith('https://')) {
                normalizedApiServerUrl = ((this.isEncriptionEnabled()) ? "https://" : "http://") + normalizedApiServerUrl;
            }
            if (normalizedApiServerUrl.endsWith('/')) {
                normalizedApiServerUrl = normalizedApiServerUrl.substr(0, normalizedApiServerUrl.length - 1);
            }
            return normalizedApiServerUrl;
        };
        /**
         * Normalizes the resource path of a REST API call in order to start with '/'.
         * @param resourcePath The resource path.
         * @return The normalized resource path.
         */
        ApiClientService.prototype.normalizeResourcePath = function (resourcePath) {
            var normalizedResourcePath = resourcePath;
            if (!normalizedResourcePath.startsWith('/')) {
                normalizedResourcePath = "/" + normalizedResourcePath;
            }
            return normalizedResourcePath;
        };
        /**
         * Convert the given API Headers into HttpHeaders.
         * @param headers The API headers to be converted.
         * @returns The Http headers converted from the given API headers.
         */
        ApiClientService.prototype.convertHttpHeaders = function (headers) {
            var e_1, _a;
            var httpHeaders = new http.HttpHeaders();
            if (headers) {
                try {
                    for (var headers_1 = __values(headers), headers_1_1 = headers_1.next(); !headers_1_1.done; headers_1_1 = headers_1.next()) {
                        var header = headers_1_1.value;
                        httpHeaders = httpHeaders.set(header.headerName, header.headerValue);
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (headers_1_1 && !headers_1_1.done && (_a = headers_1.return)) _a.call(headers_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            return httpHeaders;
        };
        /**
         * Convert the given API Params into HttpParams.
         * @param params The API parameters to be converted.
         * @returns The Http parameters converted from the given API parameters.
         */
        ApiClientService.prototype.convertHttpParams = function (params) {
            var e_2, _a;
            var httpParams = new http.HttpParams();
            if (params) {
                try {
                    for (var params_1 = __values(params), params_1_1 = params_1.next(); !params_1_1.done; params_1_1 = params_1.next()) {
                        var param = params_1_1.value;
                        httpParams = httpParams.set(param.paramName, param.paramValue);
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (params_1_1 && !params_1_1.done && (_a = params_1.return)) _a.call(params_1);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
            }
            return httpParams;
        };
        return ApiClientService;
    }());
    ApiClientService.decorators = [
        { type: i0.Injectable }
    ];
    ApiClientService.ctorParameters = function () { return [
        { type: http.HttpClient }
    ]; };

    /**
     * @license @harpalabs/ng-core
     * (c) 2018 Harpa Labs, LTDA.
     * Licence: MIT.
     */
    /**
     * Cache Config definition for the Angular (NG) Harpa Framework.
     *
     * @author Denis Pinheiro
     */
    var CacheConfig = /** @class */ (function () {
        function CacheConfig() {
            /**
             * The prefix for the all key in the cache service to avoid colisions.
             */
            this.prefix = '@harpalabs/ng-core/';
            /**
             * Specify if the cached item is transient or not.
             */
            this.transient = true;
            /**
             * The expiration time (in minutes) for the cached item life time (default is 0).
             */
            this.expiration = 0;
        }
        /**
         * Sets new cache configuration values. Any parameter not defined will
         * remains with the default value.
         * @param config the cache configuration object.
         */
        CacheConfig.prototype.set = function (config) {
            this.prefix = (config.prefix != null) ? config.prefix : this.prefix;
            this.transient = (config.transient != null) ? config.transient : this.transient;
            this.expiration = (config.expiration != null) ? config.expiration : this.expiration;
        };
        return CacheConfig;
    }());

    /**
     * Storage Cache Service definition for the Angular (NG) Harpa Framework,
     * based on Session and Local Web Storage.
     *
     * @author Denis Pinheiro
     */
    var WebCacheService = /** @class */ (function () {
        /**
         * Constructs the Storage Cache Service object with the initial default values
         * only if the Web Storage is available for the application.
         */
        function WebCacheService() {
            this.initStorageCacheAvailability();
            this.config = new CacheConfig();
        }
        WebCacheService.prototype.configCache = function (config) {
            /* Implements CacheService.configCache(..) definition. */
            this.initStorageCacheAvailability();
            this.config.set(config);
        };
        WebCacheService.prototype.set = function (key, value, transient, expiration) {
            /* Implements CacheService.set(..) definition. */
            this.initStorageCacheAvailability();
            transient = transient != null ? transient : this.config.transient;
            if (transient) {
                this.setTransientEntry(key, value);
            }
            else {
                this.setPersistentEntry(key, value, expiration);
            }
        };
        WebCacheService.prototype.get = function (key) {
            /* Implements CacheService.get(..) definition. */
            this.initStorageCacheAvailability();
            var value = this.sessionStorage.getItem(this.config.prefix + key);
            if (!value) {
                value = this.localStorage.getItem(this.config.prefix + key);
            }
            return value;
        };
        WebCacheService.prototype.remove = function (key) {
            /* Implements CacheService.remove(..) definition. */
            this.initStorageCacheAvailability();
            var value = this.sessionStorage.getItem(this.config.prefix + key);
            if (value) {
                this.sessionStorage.removeItem(this.config.prefix + key);
            }
            else {
                value = this.localStorage.getItem(this.config.prefix + key);
                if (value) {
                    this.localStorage.removeItem(this.config.prefix + key);
                    this.localStorage.removeItem(this.config.prefix + key + '_expiration_timestamp');
                }
            }
            return value;
        };
        /**
         * Sets a transient entry in the sessionStorage object.
         * @param key the transient item key.
         * @param value the transient item value.
         */
        WebCacheService.prototype.setTransientEntry = function (key, value) {
            this.sessionStorage.setItem(this.config.prefix + key, value);
        };
        /**
         * Sets a not transient entry in the localStorage object.
         * @param key the persistent item key.
         * @param value the persistent item value.
         * @param expiration the number of days for the expiration deadline.
         */
        WebCacheService.prototype.setPersistentEntry = function (key, value, expiration) {
            this.localStorage.setItem(this.config.prefix + key, value);
            if (!expiration) {
                expiration = this.config.expiration;
            }
            var expiration_timestamp = (expiration /* minutes */ * 60 /* seconds */ * 1000 /* millis */);
            if (expiration_timestamp > 0) {
                this.localStorage.setItem(this.config.prefix + key + '_expiration_timestamp', String(expiration_timestamp + Date.now() /* millis since 1/1/1970*/));
            }
        };
        WebCacheService.prototype.cleanExpiratedPersistentEntries = function () {
            var e_1, _a;
            var keysToRemove = [];
            for (var i = 0; i < this.localStorage.length; i++) {
                var key = this.localStorage.key(i);
                if (key && key.endsWith('_expiration_timestamp')) {
                    var timestamp = this.localStorage.getItem(key);
                    if (Date.now() > Number(timestamp)) {
                        var keySubs = key.substring(0, key.indexOf('_expiration_timestamp'));
                        keysToRemove.push(key);
                        keysToRemove.push(keySubs);
                    }
                }
            }
            try {
                for (var keysToRemove_1 = __values(keysToRemove), keysToRemove_1_1 = keysToRemove_1.next(); !keysToRemove_1_1.done; keysToRemove_1_1 = keysToRemove_1.next()) {
                    var key = keysToRemove_1_1.value;
                    this.localStorage.removeItem(key);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (keysToRemove_1_1 && !keysToRemove_1_1.done && (_a = keysToRemove_1.return)) _a.call(keysToRemove_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        };
        WebCacheService.prototype.initStorageCacheAvailability = function () {
            if (this.storageAvailable) {
                return;
            }
            /* Availability verification */
            this.storageAvailable = this.checkStorageAvailability('localStorage') && this.checkStorageAvailability('sessionStorage');
            if (!this.storageAvailable) {
                throw new Error('Storage Cache Service (sessionStorage or localStorage) not available.');
            }
            else {
                this.localStorage = window.localStorage;
                this.sessionStorage = window.sessionStorage;
                /** clean the localStorage - the persistent entries*/
                this.cleanExpiratedPersistentEntries();
            }
        };
        /**
         * Checks the availability of Local or Session Storage.
         * Ref: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
         */
        WebCacheService.prototype.checkStorageAvailability = function (type) {
            try {
                var storage = window[type];
                var x = '__storage_test__';
                storage.setItem(x, x);
                storage.removeItem(x);
                return true;
            }
            catch (e) {
                return e instanceof DOMException && (
                // everything except Firefox
                e.code === 22 ||
                    // Firefox
                    e.code === 1014 ||
                    // test name field too, because code might not be present
                    // everything except Firefox
                    e.name === 'QuotaExceededError' ||
                    // Firefox
                    e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
                    // acknowledge QuotaExceededError only if there's something already stored
                    storage.length !== 0;
            }
        };
        return WebCacheService;
    }());
    WebCacheService.ɵprov = i0.ɵɵdefineInjectable({ factory: function WebCacheService_Factory() { return new WebCacheService(); }, token: WebCacheService, providedIn: "root" });
    WebCacheService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    WebCacheService.ctorParameters = function () { return []; };

    /**
     * @license @harpalabs/ng-core
     * (c) 2018 Harpa Labs, LTDA.
     * Licence: MIT.
     */
    var SystemContextService = /** @class */ (function () {
        function SystemContextService() {
        }
        Object.defineProperty(SystemContextService.prototype, "applicationId", {
            get: function () {
                return this._applicationId;
            },
            set: function (id) {
                this._applicationId = id;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(SystemContextService.prototype, "cacheService", {
            get: function () {
                return this._cacheService;
            },
            set: function (value) {
                this._cacheService = value;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(SystemContextService.prototype, "i18nService", {
            get: function () {
                return this._i18nService;
            },
            set: function (value) {
                this._i18nService = value;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(SystemContextService.prototype, "version", {
            get: function () {
                return this._version;
            },
            set: function (value) {
                this._version = value;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(SystemContextService.prototype, "build", {
            get: function () {
                return this._build;
            },
            set: function (value) {
                this._build = value;
            },
            enumerable: false,
            configurable: true
        });
        return SystemContextService;
    }());
    SystemContextService.ɵprov = i0.ɵɵdefineInjectable({ factory: function SystemContextService_Factory() { return new SystemContextService(); }, token: SystemContextService, providedIn: "root" });
    SystemContextService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    SystemContextService.ctorParameters = function () { return []; };

    // Core Module

    /**
     * Generated bundle index. Do not edit.
     */

    exports.ApiClientService = ApiClientService;
    exports.BusinessService = BusinessService;
    exports.CacheConfig = CacheConfig;
    exports.CoreModule = CoreModule;
    exports.Entity = Entity;
    exports.I18nPipe = I18nPipe;
    exports.I18nService = I18nService;
    exports.SystemContextService = SystemContextService;
    exports.WebCacheService = WebCacheService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=harpalabs-ng-core.umd.js.map
