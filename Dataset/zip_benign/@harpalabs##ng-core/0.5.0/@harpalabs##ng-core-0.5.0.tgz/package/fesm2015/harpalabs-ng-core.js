import { ɵɵdefineInjectable, Injectable, Pipe, NgModule } from '@angular/core';
import { HttpClientModule, HttpHeaders, HttpParams, HttpClient } from '@angular/common/http';

class I18nService {
    constructor() {
        this._locale = '';
        this.i18nCache = new Map();
    }
    getLabel(key, locale) {
        return this.get(key, '/assets/i18n/labels.json', locale);
    }
    getMessage(property, parameters, locale) {
        const msg = this.get(property, '/assets/i18n/messages.json', locale);
        let text = msg;
        if (parameters) {
            Object.keys(parameters).forEach(prop => {
                const value = parameters[prop];
                text = text.replace("{" + prop + "}", value);
            });
        }
        return text;
    }
    get(property, resource, locale) {
        if (!locale) {
            locale = this._locale;
        }
        // console.log('LOCALE: ' + locale);
        if (locale) {
            resource = resource.replace('.json', '-' + locale + '.json');
        }
        // console.log('RESOURCE: ' + resource);
        const props = this.loadJSON(resource);
        if (props[property]) {
            return props[property];
        }
        else {
            return property;
        }
    }
    set locale(locale) {
        // console.log('LOCALE: ' + locale);
        this._locale = locale;
    }
    loadJSON(filePath) {
        let cachedJson = this.i18nCache.get(filePath);
        if (!cachedJson) {
            const json = this.loadTextFileAjaxSync(filePath, 'application/json');
            if (json) {
                cachedJson = JSON.parse(json);
                this.i18nCache.set(filePath, cachedJson);
            }
        }
        return cachedJson;
    }
    loadTextFileAjaxSync(filePath, mimeType) {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.open('GET', filePath, false);
        if (mimeType != null) {
            if (xmlhttp.overrideMimeType) {
                xmlhttp.overrideMimeType(mimeType);
            }
        }
        xmlhttp.send();
        if (xmlhttp.status === 200) {
            return xmlhttp.responseText;
        }
        else {
            return null;
        }
    }
}
I18nService.ɵprov = ɵɵdefineInjectable({ factory: function I18nService_Factory() { return new I18nService(); }, token: I18nService, providedIn: "root" });
I18nService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];

class I18nPipe {
    constructor(i18nService) {
        this.i18nService = i18nService;
    }
    transform(key, type) {
        let translated;
        if (type) {
            if (type === 'msg') {
                translated = this.i18nService.getMessage(key);
            }
            else {
                translated = this.i18nService.getLabel(key);
            }
        }
        else {
            translated = this.i18nService.getLabel(key);
            if (!translated) {
                translated = this.i18nService.getMessage(key);
            }
        }
        return translated;
    }
}
I18nPipe.decorators = [
    { type: Pipe, args: [{ name: 'i18n' },] }
];
I18nPipe.ctorParameters = () => [
    { type: I18nService }
];

/**
 * @license @harpalabs/ng-core v1.0.0
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
/**
 * The Angular Core Module for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
class CoreModule {
}
CoreModule.decorators = [
    { type: NgModule, args: [{
                declarations: [I18nPipe],
                imports: [HttpClientModule],
                exports: [HttpClientModule, I18nPipe]
            },] }
];

/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 *
 * Generic Entity model for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
class Entity {
    constructor() {
        this.id = 0;
    }
}

/**
 * Generic Entity model for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
class BusinessService {
}

/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
/**
 * Generic API Client service for the Angular (NG) Harpa Framework.
 *
 * @author Denis Pinheiro
 */
class ApiClientService {
    constructor(httpClient) {
        this.httpClient = httpClient;
    }
    /**
     * Get the headers for all HTTP requests.
     * This method might be redefined by the concrete
     * API client service if is need to send
     * headers data in all HTTP requests.
     */
    getHeaders() {
        return [];
    }
    /**
     * Get the params for all HTTP requests.
     * This method might be redefined by the concrete
     * API client service if is need to send
     * params data in all HTTP requests.
     */
    getParams() {
        return [];
    }
    /**
     * The GET method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    get(resourcePath, headers = [], params = []) {
        return this.httpClient.get(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * The POST method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param input the input JSON object the be sent as a payload.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    post(resourcePath, input, headers = [], params = []) {
        return this.httpClient.post(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), input, {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * The PUT method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param input the input JSON object the be sent as a payload.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    put(resourcePath, input, headers = [], params = []) {
        return this.httpClient.put(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), input, {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * The DELETE method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    delete(resourcePath, headers = [], params = []) {
        return this.httpClient.delete(this.normalizeApiServerUrl(this.getApiServerUrl()) + this.normalizeResourcePath(resourcePath), {
            headers: this.convertHttpHeaders(this.getHeaders().concat(headers)),
            params: this.convertHttpParams(this.getParams().concat(params))
        });
    }
    /**
     * Defines if the communication should be encripted using SSL/TSL.
     * Whether true, HTTPS should be used, otherwise, it uses HTTP.
     * This method might be redefined by the concrete API client
     * service. The default value is false.
     */
    isEncriptionEnabled() {
        return false;
    }
    /**
     * Normalizes the API Server URL in order to have HTTP/HTTPS and without '/' in the end.
     * @param apiServerUrl The API Server URL.
     */
    normalizeApiServerUrl(apiServerUrl) {
        let normalizedApiServerUrl = apiServerUrl;
        if (!normalizedApiServerUrl.startsWith('http://')
            && !normalizedApiServerUrl.startsWith('https://')) {
            normalizedApiServerUrl = ((this.isEncriptionEnabled()) ? "https://" : "http://") + normalizedApiServerUrl;
        }
        if (normalizedApiServerUrl.endsWith('/')) {
            normalizedApiServerUrl = normalizedApiServerUrl.substr(0, normalizedApiServerUrl.length - 1);
        }
        return normalizedApiServerUrl;
    }
    /**
     * Normalizes the resource path of a REST API call in order to start with '/'.
     * @param resourcePath The resource path.
     * @return The normalized resource path.
     */
    normalizeResourcePath(resourcePath) {
        let normalizedResourcePath = resourcePath;
        if (!normalizedResourcePath.startsWith('/')) {
            normalizedResourcePath = "/" + normalizedResourcePath;
        }
        return normalizedResourcePath;
    }
    /**
     * Convert the given API Headers into HttpHeaders.
     * @param headers The API headers to be converted.
     * @returns The Http headers converted from the given API headers.
     */
    convertHttpHeaders(headers) {
        let httpHeaders = new HttpHeaders();
        if (headers) {
            for (let header of headers) {
                httpHeaders = httpHeaders.set(header.headerName, header.headerValue);
            }
        }
        return httpHeaders;
    }
    /**
     * Convert the given API Params into HttpParams.
     * @param params The API parameters to be converted.
     * @returns The Http parameters converted from the given API parameters.
     */
    convertHttpParams(params) {
        let httpParams = new HttpParams();
        if (params) {
            for (let param of params) {
                httpParams = httpParams.set(param.paramName, param.paramValue);
            }
        }
        return httpParams;
    }
}
ApiClientService.decorators = [
    { type: Injectable }
];
ApiClientService.ctorParameters = () => [
    { type: HttpClient }
];

/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
/**
 * Cache Config definition for the Angular (NG) Harpa Framework.
 *
 * @author Denis Pinheiro
 */
class CacheConfig {
    constructor() {
        /**
         * The prefix for the all key in the cache service to avoid colisions.
         */
        this.prefix = '@harpalabs/ng-core/';
        /**
         * Specify if the cached item is transient or not.
         */
        this.transient = true;
        /**
         * The expiration time (in minutes) for the cached item life time (default is 0).
         */
        this.expiration = 0;
    }
    /**
     * Sets new cache configuration values. Any parameter not defined will
     * remains with the default value.
     * @param config the cache configuration object.
     */
    set(config) {
        this.prefix = (config.prefix != null) ? config.prefix : this.prefix;
        this.transient = (config.transient != null) ? config.transient : this.transient;
        this.expiration = (config.expiration != null) ? config.expiration : this.expiration;
    }
}

/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
/**
 * Storage Cache Service definition for the Angular (NG) Harpa Framework,
 * based on Session and Local Web Storage.
 *
 * @author Denis Pinheiro
 */
class WebCacheService {
    /**
     * Constructs the Storage Cache Service object with the initial default values
     * only if the Web Storage is available for the application.
     */
    constructor() {
        this.initStorageCacheAvailability();
        this.config = new CacheConfig();
    }
    configCache(config) {
        /* Implements CacheService.configCache(..) definition. */
        this.initStorageCacheAvailability();
        this.config.set(config);
    }
    set(key, value, transient, expiration) {
        /* Implements CacheService.set(..) definition. */
        this.initStorageCacheAvailability();
        transient = transient != null ? transient : this.config.transient;
        if (transient) {
            this.setTransientEntry(key, value);
        }
        else {
            this.setPersistentEntry(key, value, expiration);
        }
    }
    get(key) {
        /* Implements CacheService.get(..) definition. */
        this.initStorageCacheAvailability();
        let value = this.sessionStorage.getItem(this.config.prefix + key);
        if (!value) {
            value = this.localStorage.getItem(this.config.prefix + key);
        }
        return value;
    }
    remove(key) {
        /* Implements CacheService.remove(..) definition. */
        this.initStorageCacheAvailability();
        let value = this.sessionStorage.getItem(this.config.prefix + key);
        if (value) {
            this.sessionStorage.removeItem(this.config.prefix + key);
        }
        else {
            value = this.localStorage.getItem(this.config.prefix + key);
            if (value) {
                this.localStorage.removeItem(this.config.prefix + key);
                this.localStorage.removeItem(this.config.prefix + key + '_expiration_timestamp');
            }
        }
        return value;
    }
    /**
     * Sets a transient entry in the sessionStorage object.
     * @param key the transient item key.
     * @param value the transient item value.
     */
    setTransientEntry(key, value) {
        this.sessionStorage.setItem(this.config.prefix + key, value);
    }
    /**
     * Sets a not transient entry in the localStorage object.
     * @param key the persistent item key.
     * @param value the persistent item value.
     * @param expiration the number of days for the expiration deadline.
     */
    setPersistentEntry(key, value, expiration) {
        this.localStorage.setItem(this.config.prefix + key, value);
        if (!expiration) {
            expiration = this.config.expiration;
        }
        const expiration_timestamp = (expiration /* minutes */ * 60 /* seconds */ * 1000 /* millis */);
        if (expiration_timestamp > 0) {
            this.localStorage.setItem(this.config.prefix + key + '_expiration_timestamp', String(expiration_timestamp + Date.now() /* millis since 1/1/1970*/));
        }
    }
    cleanExpiratedPersistentEntries() {
        const keysToRemove = [];
        for (let i = 0; i < this.localStorage.length; i++) {
            const key = this.localStorage.key(i);
            if (key && key.endsWith('_expiration_timestamp')) {
                const timestamp = this.localStorage.getItem(key);
                if (Date.now() > Number(timestamp)) {
                    const keySubs = key.substring(0, key.indexOf('_expiration_timestamp'));
                    keysToRemove.push(key);
                    keysToRemove.push(keySubs);
                }
            }
        }
        for (const key of keysToRemove) {
            this.localStorage.removeItem(key);
        }
    }
    initStorageCacheAvailability() {
        if (this.storageAvailable) {
            return;
        }
        /* Availability verification */
        this.storageAvailable = this.checkStorageAvailability('localStorage') && this.checkStorageAvailability('sessionStorage');
        if (!this.storageAvailable) {
            throw new Error('Storage Cache Service (sessionStorage or localStorage) not available.');
        }
        else {
            this.localStorage = window.localStorage;
            this.sessionStorage = window.sessionStorage;
            /** clean the localStorage - the persistent entries*/
            this.cleanExpiratedPersistentEntries();
        }
    }
    /**
     * Checks the availability of Local or Session Storage.
     * Ref: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
     */
    checkStorageAvailability(type) {
        try {
            var storage = window[type];
            const x = '__storage_test__';
            storage.setItem(x, x);
            storage.removeItem(x);
            return true;
        }
        catch (e) {
            return e instanceof DOMException && (
            // everything except Firefox
            e.code === 22 ||
                // Firefox
                e.code === 1014 ||
                // test name field too, because code might not be present
                // everything except Firefox
                e.name === 'QuotaExceededError' ||
                // Firefox
                e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
                // acknowledge QuotaExceededError only if there's something already stored
                storage.length !== 0;
        }
    }
}
WebCacheService.ɵprov = ɵɵdefineInjectable({ factory: function WebCacheService_Factory() { return new WebCacheService(); }, token: WebCacheService, providedIn: "root" });
WebCacheService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
WebCacheService.ctorParameters = () => [];

/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
class SystemContextService {
    constructor() { }
    set applicationId(id) {
        this._applicationId = id;
    }
    get applicationId() {
        return this._applicationId;
    }
    get cacheService() {
        return this._cacheService;
    }
    set cacheService(value) {
        this._cacheService = value;
    }
    get i18nService() {
        return this._i18nService;
    }
    set i18nService(value) {
        this._i18nService = value;
    }
    get version() {
        return this._version;
    }
    set version(value) {
        this._version = value;
    }
    get build() {
        return this._build;
    }
    set build(value) {
        this._build = value;
    }
}
SystemContextService.ɵprov = ɵɵdefineInjectable({ factory: function SystemContextService_Factory() { return new SystemContextService(); }, token: SystemContextService, providedIn: "root" });
SystemContextService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
SystemContextService.ctorParameters = () => [];

// Core Module

/**
 * Generated bundle index. Do not edit.
 */

export { ApiClientService, BusinessService, CacheConfig, CoreModule, Entity, I18nPipe, I18nService, SystemContextService, WebCacheService };
//# sourceMappingURL=harpalabs-ng-core.js.map
