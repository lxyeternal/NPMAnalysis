/**
 * The Angular Core Module for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
export declare class CoreModule {
}
