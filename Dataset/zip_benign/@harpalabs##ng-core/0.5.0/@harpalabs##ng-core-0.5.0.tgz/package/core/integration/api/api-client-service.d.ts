/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
/**
 * The generic API Header definition, which has the header name and the header value.
 */
export interface ApiHeader {
    headerName: string;
    headerValue: string;
}
/**
 * The generic API Param definition, which has the param name and the param value.
 */
export interface ApiParam {
    paramName: string;
    paramValue: string;
}
/**
 * The generic Api Input definition.
 */
export interface ApiInput {
}
/**
 * The generic Api Output definition.
 */
export interface ApiOutput {
}
/**
 * Generic API Client service for the Angular (NG) Harpa Framework.
 *
 * @author Denis Pinheiro
 */
export declare abstract class ApiClientService<IN extends ApiInput, OUT extends ApiOutput> {
    protected httpClient: HttpClient;
    constructor(httpClient: HttpClient);
    /**
     * The API Server Url definition.
     * This method should be implemented by the generic
     * API client service of the application project.
     */
    abstract getApiServerUrl(): string;
    /**
     * Get the headers for all HTTP requests.
     * This method might be redefined by the concrete
     * API client service if is need to send
     * headers data in all HTTP requests.
     */
    protected getHeaders(): ApiHeader[];
    /**
     * Get the params for all HTTP requests.
     * This method might be redefined by the concrete
     * API client service if is need to send
     * params data in all HTTP requests.
     */
    protected getParams(): ApiParam[];
    /**
     * The GET method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    get(resourcePath: string, headers?: ApiHeader[], params?: ApiParam[]): Observable<OUT>;
    /**
     * The POST method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param input the input JSON object the be sent as a payload.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    post(resourcePath: string, input: IN, headers?: ApiHeader[], params?: ApiParam[]): Observable<OUT>;
    /**
     * The PUT method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param input the input JSON object the be sent as a payload.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    put(resourcePath: string, input: IN, headers?: ApiHeader[], params?: ApiParam[]): Observable<OUT>;
    /**
     * The DELETE method in the REST/HTTP request.
     * @param resourcePath the context path of the resource.
     * @param headers the HTTP headers to be sent in the request.
     * @param params the HTTP params to be sent in the request.
     * @returns An Observable/Promise of the Output.
     */
    delete(resourcePath: string, headers?: ApiHeader[], params?: ApiParam[]): Observable<OUT>;
    /**
     * Defines if the communication should be encripted using SSL/TSL.
     * Whether true, HTTPS should be used, otherwise, it uses HTTP.
     * This method might be redefined by the concrete API client
     * service. The default value is false.
     */
    protected isEncriptionEnabled(): boolean;
    /**
     * Normalizes the API Server URL in order to have HTTP/HTTPS and without '/' in the end.
     * @param apiServerUrl The API Server URL.
     */
    private normalizeApiServerUrl;
    /**
     * Normalizes the resource path of a REST API call in order to start with '/'.
     * @param resourcePath The resource path.
     * @return The normalized resource path.
     */
    private normalizeResourcePath;
    /**
     * Convert the given API Headers into HttpHeaders.
     * @param headers The API headers to be converted.
     * @returns The Http headers converted from the given API headers.
     */
    private convertHttpHeaders;
    /**
     * Convert the given API Params into HttpParams.
     * @param params The API parameters to be converted.
     * @returns The Http parameters converted from the given API parameters.
     */
    private convertHttpParams;
}
