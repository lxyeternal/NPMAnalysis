/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 *
 * Generic Entity model for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
export declare abstract class Entity {
    id: number;
}
