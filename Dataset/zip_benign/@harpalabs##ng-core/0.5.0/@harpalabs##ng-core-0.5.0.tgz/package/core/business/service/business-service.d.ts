/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { Entity } from "../model/entity-model";
/**
 * Generic Entity model for the Angular (NG) Harpa Framework.
 * @author Denis Pinheiro
 */
export declare abstract class BusinessService<E extends Entity> {
}
