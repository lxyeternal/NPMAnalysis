/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { ICacheService } from './i.cache.service';
import { CacheConfig } from './cache.config';
/**
 * Storage Cache Service definition for the Angular (NG) Harpa Framework,
 * based on Session and Local Web Storage.
 *
 * @author Denis Pinheiro
 */
export declare class WebCacheService implements ICacheService {
    /**
     * The cache configuration object.
     */
    private config;
    /**
     * The Window.localStorage reference.
     */
    private localStorage;
    /**
     * The Window.sessionStorage reference.
     */
    private sessionStorage;
    /**
     * Indicates if the Web Storage is available.
     */
    private storageAvailable;
    /**
     * Constructs the Storage Cache Service object with the initial default values
     * only if the Web Storage is available for the application.
     */
    constructor();
    configCache(config: CacheConfig): void;
    set(key: string, value: string, transient?: boolean, expiration?: number): void;
    get(key: string): string | null;
    remove(key: string): string | null;
    /**
     * Sets a transient entry in the sessionStorage object.
     * @param key the transient item key.
     * @param value the transient item value.
     */
    private setTransientEntry;
    /**
     * Sets a not transient entry in the localStorage object.
     * @param key the persistent item key.
     * @param value the persistent item value.
     * @param expiration the number of days for the expiration deadline.
     */
    private setPersistentEntry;
    private cleanExpiratedPersistentEntries;
    private initStorageCacheAvailability;
    /**
     * Checks the availability of Local or Session Storage.
     * Ref: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
     */
    private checkStorageAvailability;
}
