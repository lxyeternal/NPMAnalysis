/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { CacheConfig } from './cache.config';
/**
 * Cache Service interface defines the Local cache for Angular (NG) applications.
 * This cache stores transient and persistent items which are be managed by
 * the client application.
 *
 * @author Denis Pinheiro
 */
export interface ICacheService {
    /**
     * Configures the cache service.
     * @param config the config parameters.
     */
    configCache(config: CacheConfig): void;
    /**
     * Sets a value item to the cache refered by the key. If the item is
     * transient (default), it will be in cache during the user navigation,
     * that is, if user closes the browser this values is removed from the
     * cache. Otherwise, the value will be in cache until it be removed or
     * the expiration time (in minutes) is reached.
     * @param key the key of the item.
     * @param value the value of the item.
     * @param transient indicates that the value is transient.
     * @param expiration the expiration time if the item is not transient
     * (default 0, which indicates that the value will be in the cache
     * forever, that is, until it be removed).
     */
    set(key: string, value: string, transient?: boolean, expiration?: number): void;
    /**
     * Retrieves the cached value, transient or not.
     * @param key the key of the value to be retrieved.
     */
    get(key: string): string | null;
    /**
     * Removes the cached value, transient or not and return it.
     * @param key the key of the value to be removed.
     */
    remove(key: string): string | null;
}
