/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
/**
 * Cache Config definition for the Angular (NG) Harpa Framework.
 *
 * @author Denis Pinheiro
 */
export declare class CacheConfig {
    /**
     * The prefix for the all key in the cache service to avoid colisions.
     */
    prefix: string;
    /**
     * Specify if the cached item is transient or not.
     */
    transient: boolean;
    /**
     * The expiration time (in minutes) for the cached item life time (default is 0).
     */
    expiration: number;
    /**
     * Sets new cache configuration values. Any parameter not defined will
     * remains with the default value.
     * @param config the cache configuration object.
     */
    set(config: CacheConfig): void;
}
