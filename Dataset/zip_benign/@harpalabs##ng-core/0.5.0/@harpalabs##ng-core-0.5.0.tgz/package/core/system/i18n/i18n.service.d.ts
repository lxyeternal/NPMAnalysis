import { II18nService } from './i.i18n.service';
export declare class I18nService implements II18nService {
    private _locale;
    private i18nCache;
    getLabel(key: string, locale?: string): string;
    getMessage(property: string, parameters?: any, locale?: string): string;
    get(property: string, resource: string, locale?: string): string;
    set locale(locale: string);
    private loadJSON;
    private loadTextFileAjaxSync;
}
