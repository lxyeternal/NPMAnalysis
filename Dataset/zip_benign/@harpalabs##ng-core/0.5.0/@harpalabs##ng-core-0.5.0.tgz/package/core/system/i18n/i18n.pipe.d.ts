import { PipeTransform } from '@angular/core';
import { I18nService } from './i18n.service';
export declare class I18nPipe implements PipeTransform {
    private i18nService;
    constructor(i18nService: I18nService);
    transform(key: string, type?: string): string;
}
