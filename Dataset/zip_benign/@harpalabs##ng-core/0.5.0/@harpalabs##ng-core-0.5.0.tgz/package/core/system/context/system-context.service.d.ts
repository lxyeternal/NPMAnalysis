/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
import { ICacheService } from './../cache/i.cache.service';
import { II18nService } from '../i18n/i.i18n.service';
export declare class SystemContextService {
    constructor();
    private _applicationId;
    private _cacheService;
    private _i18nService;
    private _version;
    private _build;
    set applicationId(id: number);
    get applicationId(): number;
    get cacheService(): ICacheService;
    set cacheService(value: ICacheService);
    get i18nService(): II18nService;
    set i18nService(value: II18nService);
    get version(): string;
    set version(value: string);
    get build(): number;
    set build(value: number);
}
