/**
 * @license @harpalabs/ng-core
 * (c) 2018 Harpa Labs, LTDA.
 * Licence: MIT.
 */
export interface II18nService {
    /**
     * Returns an i18n value for a given property key.
     * @param key the key required to get the i18n property value.
     * @param locale an opitonal locale.
     */
    getLabel(key: string, locale?: string): string;
    /**
     * Returns an i18n message given the property key and the message parameters.
     * @param key the key required to get the i18n property value.
     * @param parameters an object with parameters which might be used in the message ({key}).
     * @param locale ths opitonal locale
     */
    getMessage(key: string, parameters?: any, locale?: string): string;
}
