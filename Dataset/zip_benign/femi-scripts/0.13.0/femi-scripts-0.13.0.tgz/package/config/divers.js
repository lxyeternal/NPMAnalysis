const fs = require("fs")
const path = require("path")
const webpack = require("webpack")
const shell = require("shelljs")
const chalk = require("chalk")
const styledComponentsTransformer = require("typescript-plugin-styled-components").default
const tsImportPluginFactory = require("ts-import-plugin")
const ForkTsCheckerWebpackPlugin = require("fork-ts-checker-webpack-plugin")
const TerserJSPlugin = require("terser-webpack-plugin")
const CssMinimizerPlugin = require("css-minimizer-webpack-plugin")
const MiniCssExtractPlugin = require("mini-css-extract-plugin")
const HtmlWebpackPlugin = require("html-webpack-plugin")
const InterpolateHtmlPlugin = require("interpolate-html-plugin")
const TsconfigPathsPlugin = require("tsconfig-paths-webpack-plugin")
const DefinePlugin = webpack.DefinePlugin
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer").BundleAnalyzerPlugin

const paths = require("./paths")
const userConfig = require(paths.userConfig)

module.exports = function (env) {
  const { appReady, isSystem, isEnvProduction } = env
  const { entry: appEntry, alias = {} } = userConfig

  // app
  const hasApps = userConfig.apps && Array.isArray(userConfig.apps)
  // imports
  const hasImports = userConfig.imports
  // public
  const hasHtml = fs.existsSync(paths.html)
  const hasContainer = fs.existsSync(paths.container)
  const hasPublic = userConfig.public
  const hasPublicTitle = hasPublic && userConfig.public.title
  const hasPublicFavicon = hasPublic && userConfig.public.favicon
  // output
  const useOutputHash = userConfig.output && userConfig.output.hash === false ? false : true
  // vue
  const hasVue3Compiler = fs.existsSync(path.resolve("node_modules/@vue/compiler-sfc"))
  const hasVue2Compiler = fs.existsSync(path.resolve("node_modules/vue-template-compiler"))
  const useVueVersion = hasVue3Compiler ? 3 : hasVue2Compiler ? 2 : 0
  // tsconfig
  const hasTsConfig = fs.existsSync(paths.tsconfig)

  const entry = () => {
    if (!appEntry) {
      console.log(chalk.red('Please add { ..."entry": "your entry path" ... } in "femi.json"'))
      process.exit(0)
    }

    const hasNoAppReady = appReady.length === 0

    const e = {}
    if (appReady && Array.isArray(appReady) && !hasNoAppReady) {
      console.log(chalk.blue(`Current Env:`, env.NODE_ENV))
      console.log(chalk.blue(`Current App:`, appReady))
      appReady.forEach(appName => {
        if (appEntry[appName]) {
          e[appName] = {
            import: appEntry[appName],
          }
        }
      })
      return e
    } else if (hasNoAppReady) {
      if (appEntry.default) {
        console.log(chalk.blue(`Current Env:`, env.NODE_ENV))
        console.log(chalk.blue(`Current App:`, "default"))
        console.log(chalk.blue(`Current Entry:`, appEntry.default))
        e.main = {
          import: appEntry.default,
        }
        return e
      } else if (typeof appEntry === "string") {
        return appEntry
      } else {
        console.log(chalk.red("You have not assign default entry."))
        return
      }
    } else {
      throw new Error(`${appReady} entry not found`)
    }
  }

  const output = () => {
    const appHash = isEnvProduction && useOutputHash ? ".[chunkhash:8]" : ""
    return Object.assign(
      {
        publicPath: process.env.PUBLIC_URL ? process.env.PUBLIC_URL + "/" : "",
        filename: `${isSystem ? "js" : "normal"}/[name]${appHash}.js`,
        chunkFilename: `${isSystem ? "js" : "normal"}/[name]${appHash}.chunk.js`,
        path: paths.output,
      },
      isSystem
        ? {
            libraryTarget: "system",
          }
        : {}
    )
  }

  const loaders = () => {
    // less
    const useModifyVars = userConfig.less && userConfig.less.modifyVars
    // common style loader
    const makeStyleLoaders = cssOptions => {
      const loaders = [
        // style-loader or extract
        isEnvProduction
          ? MiniCssExtractPlugin.loader
          : {
              loader: "style-loader",
              options: {
                insert: function insertAtTop(element) {
                  // 插入到 head 标签的最前面
                  const parent = document.querySelector("head")
                  const lastInsertedElement = window._lastElementInsertedByStyleLoader
                  if (!lastInsertedElement) {
                    parent.insertBefore(element, parent.firstChild)
                  } else if (lastInsertedElement.nextSibling) {
                    parent.insertBefore(element, lastInsertedElement.nextSibling)
                  } else {
                    parent.appendChild(element)
                  }
                  window._lastElementInsertedByStyleLoader = element
                },
              },
            },
        // css-loader
        {
          loader: "css-loader",
          options: cssOptions,
        },
        // postcss-loader
        {
          loader: "postcss-loader",
        },
      ]
      return loaders
    }

    const ts = {
      test: /\.tsx?$/,
      // exclude: /(node_modules\/)/,
      use: [
        {
          loader: "ts-loader",
          options: {
            transpileOnly: true,
            getCustomTransformers: () => ({
              before: [
                tsImportPluginFactory({
                  libraryName: "antd",
                  style: true,
                }),
                tsImportPluginFactory({
                  libraryName: "@ali/stars-components",
                }),
                styledComponentsTransformer({
                  getDisplayName: (filename, bindingName) => {
                    return bindingName
                  },
                }),
              ].filter(Boolean),
            }),
          },
        },
      ],
    }

    const js = {
      test: /\.(t|j)sx?$/,
      include: paths.appSrc,
      use: {
        loader: "babel-loader",
        options: {
          presets: ["@babel/preset-env", "@babel/preset-typescript", "@babel/preset-react"],
          plugins: [
            [
              "babel-plugin-styled-components",
              {
                displayName: true,
              },
            ],
            [
              "import",
              {
                libraryName: "antd",
                style: true,
              },
              "antd",
            ],
          ],
          cacheDirectory: true,
          compact: env.isEnvProduction,
        },
      },
    }

    const vue =
      useVueVersion === 3
        ? { test: /\.vue$/, loader: "vue-loader-v16" }
        : {
            test: /\.vue$/,
            loader: "vue-loader",
          }

    const css = {
      test: /\.css$/,
      use: makeStyleLoaders({
        sourceMap: env.isEnvDevelopment,
      }),
    }

    const less = {
      test: /\.less$/,
      use: [
        ...makeStyleLoaders({
          sourceMap: env.isEnvDevelopment,
        }),
        {
          loader: "less-loader",
          options: {
            lessOptions: {
              modifyVars: useModifyVars,
              javascriptEnabled: true,
            },
          },
        },
      ],
    }

    const sass = {
      test: /\.s[ac]ss$/,
      exclude: /\.module\.(scss|sass)$/,
      use: [
        ...makeStyleLoaders({
          sourceMap: env.isEnvDevelopment,
        }),
        {
          loader: "sass-loader",
          options: {
            sassOptions: {
              includePaths: ["src/style"],
            },
            // Prefer `dart-sass`
            implementation: require("sass"),
          },
        },
      ],
    }

    const sassModule = {
      test: /\.module\.(scss|sass)$/,
      use: [
        ...makeStyleLoaders({
          sourceMap: env.isEnvDevelopment,
          modules: {
            mode: "local",
            localIdentName: "[local]_[hash:base64:6]",
            exportLocalsConvention: "camelCase",
          },
        }),
        {
          loader: "sass-loader",
          options: {
            sassOptions: {
              includePaths: ["src/style"],
            },
            // Prefer `dart-sass`
            implementation: require("sass"),
          },
        },
      ],
    }

    const file = {
      loader: "file-loader",
      exclude: [/\.(js|jsx|mjs)$/, /\.html$/, /\.json$/],
      options: {
        name: "media/[name].[hash:8].[ext]",
      },
    }

    const url = {
      test: /\.(bmp|gif|jpe?g|png|svg)$/,
      loader: "url-loader",
      options: {
        limit: 10000,
        name: "media/[name].[hash:8].[ext]",
      },
    }

    return { js, ts, vue, css, less, sass, sassModule, file, url }
  }

  const plugins = () => {
    const terserJSPlugin = new TerserJSPlugin({
      extractComments: false,
      terserOptions: {
        parse: {
          // We want terser to parse ecma 8 code. However, we don't want it
          // to apply any minification steps that turns valid ecma 5 code
          // into invalid ecma 5 code. This is why the 'compress' and 'output'
          // sections only apply transformations that are ecma 5 safe
          // https://github.com/facebook/create-react-app/pull/4234
          ecma: 8,
        },
        compress: {
          ecma: 5,
          warnings: false,
          // Disabled because of an issue with Uglify breaking seemingly valid code:
          // https://github.com/facebook/create-react-app/issues/2376
          // Pending further investigation:
          // https://github.com/mishoo/UglifyJS2/issues/2011
          comparisons: false,
          // Disabled because of an issue with Terser breaking valid code:
          // https://github.com/facebook/create-react-app/issues/5250
          // Pending further investigation:
          // https://github.com/terser-js/terser/issues/120
          inline: 2,
        },
        mangle: {
          safari10: true,
        },
        output: {
          ecma: 5,
          comments: false,
          // Turned on because emoji and regex is not minified properly using default
          // https://github.com/facebook/create-react-app/issues/2488
          ascii_only: true,
        },
      },
    })

    const cssMinimizerPlugin = new CssMinimizerPlugin()

    const forkTsCheckerWebpackPlugin = new ForkTsCheckerWebpackPlugin({
      async: env.isEnvDevelopment,
      typescript: {
        // typescriptPath: resolve.sync("typescript", {
        //   basedir: paths.appNodeModules,
        // }),
        configOverwrite: {
          compilerOptions: {
            skipLibCheck: true,
            sourceMap: false,
            inlineSourceMap: false,
            declarationMap: false,
            noEmit: true,
            incremental: true,
            tsBuildInfoFile: paths.appTsBuildInfoFile,
          },
        },
        diagnosticOptions: {
          semantic: true,
          syntactic: true,
        },
        mode: "write-references",
      },
      logger: {
        infrastructure: "silent",
      },
    })

    const htmlWebpackPlugin = (() => {
      const { public, apps } = userConfig
      // public
      const useTitle = hasPublicTitle ? `<title>${public.title}</title>` : ""
      const useFavicon = hasPublicFavicon
        ? `<link rel="shortcut icon" href="${public.favicon}" />`
        : ""
      const useHeadTagsBefore = hasPublic && (public.headTagsBefore || "")
      const useHeadTagsAfter = hasPublic && (public.headTagsAfter || "")
      const useBodyTagsBefore = hasPublic && (public.bodyTagsBefore || "")
      const useBodyTagsAfter = hasPublic && (public.bodyTagsAfter || "")

      const importMap = Object.assign(
        {},
        hasImports && userConfig.imports,
        hasApps && [{}, ...apps].reduce((pre, cur) => Object.assign(pre, { [cur.key]: cur.entry }))
      )

      // app dom container
      const makeAppContainer = apps => {
        let str = ""
        apps.forEach(app => {
          str += `<div id=${app.key}></div>`
        })
        return str
      }
      const useAppContainers = hasContainer
        ? fs.readFileSync(paths.container, "utf8")
        : hasApps && makeAppContainer(apps)

      return new HtmlWebpackPlugin(
        Object.assign(
          {
            inject: true,
            template: paths.html,
          },
          !hasHtml && {
            inject: false,
            templateParameters: (compilation, assets, assetTags, options) => {
              assetTags.headTags.unshift(
                Object.assign(
                  {
                    tagName: "script",
                    voidTag: false,
                    meta: { plugin: "html-webpack-plugin" },
                    attributes: {
                      type: "systemjs-importmap",
                    },
                    toString: assetTags.headTags[0].toString,
                  },
                  {
                    innerHTML: `
                      {
                        "imports": ${JSON.stringify(importMap)}
                      }
                    `,
                  }
                )
              )

              return {
                compilation,
                webpackConfig: compilation.options,
                htmlWebpackPlugin: {
                  tags: assetTags,
                  files: assets,
                  options,
                },
              }
            },
          },
          !hasHtml && {
            templateContent: ({ htmlWebpackPlugin }) => {
              return `
              <!DOCTYPE html>
              <html>
                <head>
                  <meta charset="utf-8" />
                  <meta name="viewport" content="width=device-width, initial-scale=1" />
                  ${useTitle}
                  ${useFavicon}
                  ${useHeadTagsBefore}
                  ${htmlWebpackPlugin.tags.headTags}
                  ${useHeadTagsAfter}
                </head>
                <body>
                  ${useAppContainers}
                  ${useBodyTagsBefore}
                  ${htmlWebpackPlugin.tags.bodyTags}
                  ${useBodyTagsAfter}
                </body>
              </html>
            `
            },
          },
          isEnvProduction
            ? {
                minify: {
                  removeComments: true,
                  collapseWhitespace: true,
                  removeRedundantAttributes: true,
                  useShortDoctype: true,
                  removeEmptyAttributes: true,
                  removeStyleLinkTypeAttributes: true,
                  keepClosingSlash: true,
                  minifyJS: true,
                  minifyCSS: true,
                  minifyURLs: true,
                },
              }
            : undefined
        )
      )
    })()

    const interpolateHtmlPlugin = new InterpolateHtmlPlugin(env)

    /* 分离出css */
    const miniExtractPlugin = new MiniCssExtractPlugin({
      filename: isEnvProduction && useOutputHash ? "css/[name].[hash].css" : "css/[name].css",
      chunkFilename:
        isEnvProduction && useOutputHash ? "css/[name].[hash].chunk.css" : "css/[name].css",
      ignoreOrder: false, // Enable to remove warnings about conflicting order
    })

    const definePlugin = new DefinePlugin(env.stringify)

    const VueLoaderPlugin = require(useVueVersion === 3
      ? "vue-loader-v16"
      : "vue-loader").VueLoaderPlugin

    const bundleAnalyzerPlugin = new BundleAnalyzerPlugin()

    return {
      forkTsCheckerWebpackPlugin,
      htmlWebpackPlugin: !isSystem && htmlWebpackPlugin,
      interpolateHtmlPlugin: !isSystem && interpolateHtmlPlugin,
      miniExtractPlugin: miniExtractPlugin,
      vueLoaderPlugin: useVueVersion !== 0 && new VueLoaderPlugin(),
      tsconfigPathsPlugin: hasTsConfig && new TsconfigPathsPlugin(),
      terserJSPlugin,
      cssMinimizerPlugin,
      definePlugin,
      bundleAnalyzerPlugin: isEnvProduction && bundleAnalyzerPlugin,
    }
  }

  return {
    userConfig,
    entry: entry(),
    output: output(),
    alias: {
      ...alias,
      "@": paths.resolveApp("src"),
    },
    loaders: loaders(),
    plugins: plugins(),
    devtool: env.isEnvDevelopment ? "eval-source-map" : false,
    externals: isSystem ? userConfig.externals : [],
  }
}
