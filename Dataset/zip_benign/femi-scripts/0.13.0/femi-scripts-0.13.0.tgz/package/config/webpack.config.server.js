const envFac = require("./env")
const divers = require("./divers")

module.exports = function configFac(envConfig) {
  const env = envFac(envConfig)
  const { alias, entry, output, loaders, plugins, splitChunks, devtool, externals } = divers(env)

  return {
    target: "node",
    mode: env.NODE_ENV,
    entry: entry,
    output: output,
    module: {
      rules: [loaders.ts],
    },
    resolve: {
      plugins: [plugins.tsconfigPathsPlugin].filter(Boolean),
      alias,
      extensions: [".js", ".jsx", ".ts", ".tsx"],
    },
    plugins: [].filter(Boolean),
    devtool,
    externals,
  }
}
