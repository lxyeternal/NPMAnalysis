const path = require("path")
const fs = require("fs")

const appDirectory = fs.realpathSync(process.cwd())
const resolveApp = relativePath => path.resolve(appDirectory, relativePath)

module.exports = Object.assign({
  dockerfileServer: path.resolve(__dirname, "../docker/server/Dockerfile"),
  dockerfileClient: path.resolve(__dirname, "../docker/client/Dockerfile"),
  tsconfig: resolveApp("tsconfig.json"),
  userConfig: resolveApp("femi.json"),
  output: resolveApp("dist"),
  public: resolveApp("public"),
  appSrc: resolveApp("src"),
  html: resolveApp("public/index.html"),
  container: resolveApp("public/container.html"),
  appNodeModules: resolveApp("node_modules"),
  appTsBuildInfoFile: resolveApp("node_modules/.cache/tsconfig.tsbuildinfo"),
  appDirectory,
  resolveApp,
})
