# Femi-Scripts

All In One Builder

## Todo

### rollup

- 组件库编译模式

### webpack

#### webpack 4 to 5

- vue
- server 版本

#### babel-loader

- 编译速度提升：目前远不及 ts-loader + fork-ts-checker-webpack-plugin

### scripts

- 编译进度
- 编译结果
- 编译错误提示

### 依赖

```
// typescript - 0.3
ts-loader
typescript
tsconfig-paths-webpack-plugin

// react - 0.3
@types/react
@types/react-dom
@types/react-router-dom
react
react-dom
react-router-dom

// sc - 0.3
styled-components
@types/styled-components
typescript-plugin-styled-components

// vue
vue-loader
vue-loader-v16: vue-loader@16.1.0
vue-router
@vue/compiler-sfc
vue-template-compiler

// antd - 0.3
ts-import-plugin

// project - 0.3
single-spa
normalize.css

// commit - 0.3
commitlint
@commitlint/cli
@commitlint/config-conventional
husky
lint-staged

// eslint - 0.3
@typescript-eslint/eslint-plugin
@typescript-eslint/parser
eslint
eslint-config-prettier
eslint-plugin-prettier
eslint-plugin-react
eslint-plugin-react-hooks
prettier

// webpack - 0.3
babel-loader
css-loader
file-loader
less-loader
style-loader
url-loader
less
html-webpack-plugin
interpolate-html-plugin
mini-css-extract-plugin
css-minimizer-webpack-plugin
terser-webpack-plugin
webpack
webpack-dev-server

// scripts
commander
cross-spawn
shelljs
```
