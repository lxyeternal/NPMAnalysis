const Webpack = require("webpack")
const WebpackDevServer = require("webpack-dev-server")
const paths = require("../config/paths")
const configFac = require("../config/webpack.config")

module.exports = function (config) {
  process.env.NODE_ENV = "development"
  const userConfig = require(paths.userConfig)

  try {
    var compiler = Webpack(configFac(config))
  } catch (e) {
    console.log("Compiler Error", e)
  }

  const devServer = new WebpackDevServer(
    {
      historyApiFallback: true,
      proxy: userConfig.dev && userConfig.dev.proxy,
      port: (userConfig.dev && userConfig.dev.port) || 4000,
      https: (userConfig.dev && userConfig.dev.https) || false,
      allowedHosts: "all",
      headers: {
        "access-control-allow-origin": "*",
      },
    },
    compiler
  )

  devServer.start().catch(err => {
    if (err && err.message) {
      console.log(err.message)
    }
  })
}
