const Webpack = require("webpack")
const configFac = require("../config/webpack.config.server")

module.exports = function (config) {
  process.env.NODE_ENV = "production"

  try {
    var compiler = Webpack(configFac(config))
  } catch (e) {
    console.log("Compiler Error", e)
  }

  compiler.run((err, stats) => {
    if (err) {
      console.log(err)
    }
  })
}
