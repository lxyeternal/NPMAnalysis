const Webpack = require("webpack")
const numeral = require("numeral")
const chalk = require("chalk")
const fs = require("fs-extra")
const paths = require("../config/paths")
const configFac = require("../config/webpack.config")

module.exports = function (config) {
  process.env.NODE_ENV = "production"

  try {
    var compiler = Webpack([
      configFac({ appReady: ["system"], isSystem: true }),
      configFac({ appReady: ["normal"], isSystem: false }),
    ])
  } catch (e) {
    console.log("Compiler Error", e)
  }

  fs.emptyDirSync(paths.output)
  copyPublicFolder()

  compiler.run((err, stats) => {
    if (err) {
      console.log(err)
    } else {
      const statsJson = stats.toJson({ all: false, errors: true, warnings: true })
      if (statsJson.errors.length) {
        reportMessage(statsJson)
        process.exit()
      }

      console.log(chalk.green("🎉 Build Success 🎉"))
      PrintFilesSize(CalcSize(paths.output))
    }
  })
}

function CalcSize(path) {
  let arr = []

  const fileOrDir = fs.statSync(path)

  if (fileOrDir.isFile()) {
    arr.push({
      path: path,
      size: numeral(fileOrDir.size).format("0,0.00 b"),
    })
  } else if (fileOrDir.isDirectory()) {
    fs.readdirSync(path).forEach(child => {
      const childPath = path + "/" + child
      arr = [...arr, ...CalcSize(childPath)]
    })
  }

  return arr
}

function PrintFilesSize(files) {
  let maxLength = 0
  files.forEach(item => {
    const pathRemoveHash = RemoveHash(item.path)
    if (pathRemoveHash.length > maxLength) {
      maxLength = pathRemoveHash.length
    }
  })
  files.forEach(item => {
    const pathRemoveHash = RemoveHash(item.path)
    let spaceBefore = " ".repeat(5)
    let spaceAfter = " ".repeat(maxLength + 3 - pathRemoveHash.length)
    console.log(chalk.green(`${spaceBefore + pathRemoveHash + spaceAfter}:${"   "}${item.size}`))
  })
}

function RemoveHash(path) {
  return path
    .split(paths.appDirectory)[1]
    .replace(/\/?(.*)(\.[0-9a-f]+)(\.chunk)?(\.js|\.css)/, (match, p1, p2, p3, p4) => p1 + p4)
    .slice(1)
}

function copyPublicFolder() {
  if (fs.existsSync(paths.public)) {
    fs.copySync(paths.public, paths.output, {
      dereference: true,
      filter: file => file !== paths.html && file !== paths.container,
    })
  }
}

function reportMessage(json) {
  function formatMessage(item, index, type) {
    console.log(chalk.red(`${type}: ${item.file || ""}`))

    if (item.message) {
      console.log(item.message)
      console.log("\n")
    }
  }

  json.errors.forEach((item, index) => formatMessage(item, index, "Error"))
  json.warnings.forEach((item, index) => formatMessage(item, index, "Warning"))
}
