import { useCallback, useEffect, useMemo, useRef } from 'react';
import type {
  FlatListProps,
  NativeScrollEvent,
  NativeSyntheticEvent,
  ScrollViewProps,
} from 'react-native';
import type { LoadMoreFn } from 'react-relay';
import type { OperationType } from 'relay-runtime';

interface LoadProps {
  hasNext: boolean;
  isLoadingNext: boolean;
  loadNext: LoadMoreFn<OperationType>;
}

interface Options {
  count?: number;
  threshold?: number;
}

type UseFlatListLoadNextRes = Pick<
  FlatListProps<any>, // eslint-disable-line @typescript-eslint/no-explicit-any
  'onEndReached' | 'onEndReachedThreshold'
>;

export const useFlatListLoadNext = (
  loadProps: LoadProps,
  options: Options = {}
): UseFlatListLoadNextRes => {
  const { hasNext, isLoadingNext, loadNext } = loadProps;
  const { count = 60, threshold = 2 } = options;

  const onEndReachedRef = useRef(() => {});

  useEffect(() => {
    onEndReachedRef.current = () => {
      if (hasNext && !isLoadingNext) loadNext(count);
    };
  }, [count, hasNext, isLoadingNext, loadNext]);

  const endReachedHandler = useCallback(() => {
    onEndReachedRef.current();
  }, []);

  return useMemo(
    () => ({
      onEndReached: endReachedHandler,
      onEndReachedThreshold: threshold,
    }),
    [endReachedHandler, threshold]
  );
};

type UseScrollViewLoadNextRes = Pick<
  ScrollViewProps,
  'onScroll' | 'scrollEventThrottle'
>;

export const useScrollViewLoadNext = (
  loadProps: LoadProps,
  options: Options = {}
): UseScrollViewLoadNextRes => {
  const { hasNext, isLoadingNext, loadNext } = loadProps;
  const { count = 60, threshold = 500 } = options;

  const onScrollRef = useRef<
    (e: NativeSyntheticEvent<NativeScrollEvent>) => void
  >(() => {});

  useEffect(() => {
    onScrollRef.current = (e) => {
      const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
      const maxScrollTopBeforeLoad =
        contentSize.height - layoutMeasurement.height - threshold;
      if (
        contentOffset.y >= maxScrollTopBeforeLoad &&
        hasNext &&
        !isLoadingNext
      ) {
        loadNext(count);
      }
    };
  }, [count, hasNext, isLoadingNext, loadNext, threshold]);

  const scrollHandler = useCallback(
    (e: NativeSyntheticEvent<NativeScrollEvent>) => {
      onScrollRef.current(e);
    },
    []
  );

  return {
    onScroll: scrollHandler,
    scrollEventThrottle: 200,
  };
};
