/**
 * Copyright (C) 2018 ATOS
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Luis Collar Salas (luis.collar@atos.net)
 */


/**
 * Default config
 */

var autoRefresh = false;
var refreshPeriod = 1*60*1000;

var token;
var refreshToken;

const SERVER_URL = 'https://connect.myaeolix.eu';
var REST_SERVER_URL = SERVER_URL + ":3456";
var SOCKET_SERVER_URL = SERVER_URL + ":5002";

var socketCollection = {};
var socketServiceRequestCollection = {};
var socketServiceResponseCollection = {};

var crypto = window.crypto || window.msCrypto;

if (!crypto) {
  console.error("crypto NOT supported");
}

var ownRSAKey;
var ownPublicRSAKey;
var ownPrivateRSAKey;

const rsaPublicKey = '-----BEGIN PUBLIC KEY-----\n\
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAszaKYEpbqzoR3VtQIZ3h\n\
eTE6WpkcQXEasKWxkMr2MVzx8OFPz5j6918Y9s28digReLizkdOFnrbs0LctpBwA\n\
7tHKNt7/1cpQQ6dJDhA8k624QtBA2CRXIh6zLVfMdfqbFHW5iwxJgDz2vpdbRd7L\n\
1uIvsrzVHU/6lsqDw3ndQayPYMCSIqq3TeurmZ2zO2PR/D3hr2V5HrNRl6687shI\n\
GB6QM0huBIfYpZIEbPmnZD5Q4EnEI/Fzx9AseYmvgHfNvPm0P1aYS/GDiYPXSBxC\n\
p0tMuJVdd7G2RDiFM86/EV7DuBpOWLU75SsY8mi+rk4eiins+B3Kdwfaq6oBRlhJ\n\
GQIDAQAB\n\
-----END PUBLIC KEY-----';
var serverRSAKey;

var UNKNWON_ERROR = {};
UNKNWON_ERROR.error = true;
UNKNWON_ERROR.code = 0;
UNKNWON_ERROR.msg = "Unknwon error.";

var OK = {};
OK.error = false;
OK.code = 200;
OK.msg = "OK.";

var LOGIN_OK = {};
LOGIN_OK.error = false;
LOGIN_OK.code = 200;
LOGIN_OK.msg = "Logged in.";

var LOGOUT_OK = {};
LOGOUT_OK.error = false;
LOGOUT_OK.code = 200;
LOGOUT_OK.msg = "Logged out.";

var SET_TOKEN_OK = {};
SET_TOKEN_OK.error = false;
SET_TOKEN_OK.code = 200;
SET_TOKEN_OK.msg = "Token set.";

var REFRESH_TOKEN_OK = {};
REFRESH_TOKEN_OK.error = false;
REFRESH_TOKEN_OK.code = 200;
REFRESH_TOKEN_OK.msg = "Token refresh.";

var PUBLISH_OK = {};
PUBLISH_OK.error = false;
PUBLISH_OK.code = 200;
PUBLISH_OK.msg = "Data published.";

var SERVICE_REQUEST_OK = {};
SERVICE_REQUEST_OK.error = false;
SERVICE_REQUEST_OK.code = 200;
SERVICE_REQUEST_OK.msg = "Request sent.";

var SERVICE_RESPONSE_OK = {};
SERVICE_RESPONSE_OK.error = false;
SERVICE_RESPONSE_OK.code = 200;
SERVICE_RESPONSE_OK.msg = "Response sent.";

var UNSUBSCRIBED = {};
UNSUBSCRIBED.error = false;
UNSUBSCRIBED.code = 200;
UNSUBSCRIBED.msg = "Unsubscribed.";

var UNSUBSCRIBE_SENT = {};
UNSUBSCRIBE_SENT.error = false;
UNSUBSCRIBE_SENT.code = 200;
UNSUBSCRIBE_SENT.msg = "Unsubscribe datasource request sent.";

var UNSUBSCRIBE_REQUEST_SENT = {};
UNSUBSCRIBE_REQUEST_SENT.error = false;
UNSUBSCRIBE_REQUEST_SENT.code = 200;
UNSUBSCRIBE_REQUEST_SENT.msg = "Unsubscribe service request request sent.";

var UNSUBSCRIBE_RESPONSE_SENT = {};
UNSUBSCRIBE_RESPONSE_SENT.error = false;
UNSUBSCRIBE_RESPONSE_SENT.code = 200;
UNSUBSCRIBE_RESPONSE_SENT.msg = "Unsubscribe service response request sent.";

var NO_CONTENT = {};
NO_CONTENT.error = false;
NO_CONTENT.code = 204;
NO_CONTENT.msg = "No content.";

var NOT_MODIFIED = {};
NOT_MODIFIED.error = false;
NOT_MODIFIED.code = 304;
NOT_MODIFIED.msg = "Not modified.";

var BAD_REQUEST = {};
BAD_REQUEST.error = true;
BAD_REQUEST.code = 400;
BAD_REQUEST.msg = "Bad Request";

var REFRESH_TOKEN_REQUEST_ERROR = {};
REFRESH_TOKEN_REQUEST_ERROR.error = true;
REFRESH_TOKEN_REQUEST_ERROR.code = 400;
REFRESH_TOKEN_REQUEST_ERROR.msg = "Bad Refresh Request";

var UNAUTHORIZED = {};
UNAUTHORIZED.error = true;
UNAUTHORIZED.code = 401;
UNAUTHORIZED.msg = "Unauthorized";

var FORBIDDEN = {};
FORBIDDEN.error = true;
FORBIDDEN.code = 403;
FORBIDDEN.msg = "Forbidden";

var NOT_FOUND = {};
NOT_FOUND.error = true;
NOT_FOUND.code = 404;
NOT_FOUND.msg = "Not Found";

var INTERNAL_SERVER_ERROR = {};
INTERNAL_SERVER_ERROR.error = true;
INTERNAL_SERVER_ERROR.code = 500;
INTERNAL_SERVER_ERROR.msg = "Internal server error.";

var CIPHER_ERROR = {};
CIPHER_ERROR.error = true;
CIPHER_ERROR.code = 500;
CIPHER_ERROR.msg = "SDK cipher data error.";

var DECIPHER_ERROR = {};
DECIPHER_ERROR.error = true;
DECIPHER_ERROR.code = 500;
DECIPHER_ERROR.msg = "SDK decipher data error.";

var SERVICE_UNAVAILABLE = {};
SERVICE_UNAVAILABLE.error = true;
SERVICE_UNAVAILABLE.code = 503;
SERVICE_UNAVAILABLE.msg = "Service Unavailable";


function handleHTTPError(response) {

  if (!response) {

    return UNKNWON_ERROR;

  }

  var code;

  try {
    code = response.status;

    switch (code) {
      case 400:
        return BAD_REQUEST;
      case 401:
        return UNAUTHORIZED;
      case 403:
        return FORBIDDEN;
      case 404:
        return NOT_FOUND;
      case 500:
        return INTERNAL_SERVER_ERROR;
      case 503:
        return SERVICE_UNAVAILABLE;
      default:
        return UNKNWON_ERROR;
    }

  } catch (e) {
    console.error(e);
    return UNKNWON_ERROR;
  }
}


/**
 * Aeolix SDK.
 * @constructor
 * @param {object} options
 */
function AeolixSDK(args) {

  if(args){
    autoRefresh = args.autoRefresh ? args.autoRefresh : false;
  }

  console.debug("SDK instanciated");

}


var generateRandomRSAKeys = function () {
  return new Promise(function (resolve, reject) {
    crypto.subtle.generateKey(
      { name: "RSA-OAEP", modulusLength: 2048, publicExponent: new Uint8Array([0x01, 0x00, 0x01]), hash: { name: "SHA-1" } },
      true,
      ["encrypt", "decrypt"]
    ).then(function (keyPair) {

      ownRSAKey = keyPair;

      crypto.subtle.exportKey("spki", keyPair.publicKey).then(function (publicKey) {
        ownPublicRSAKey = toPublicPem(publicKey);
        crypto.subtle.exportKey("pkcs8", keyPair.privateKey).then(function (privatecKey) {
          ownPrivateRSAKey = toPrivatePem(privatecKey);
          resolve();
        });
      });
    });
  });

}


function arrayBufferToBase64(arrayBuffer) {
  var byteArray = new Uint8Array(arrayBuffer);
  var byteString = '';
  for (var i = 0; i < byteArray.byteLength; i++) {
    byteString += String.fromCharCode(byteArray[i]);
  }
  var b64 = window.btoa(byteString);

  return b64;
}

function addNewLines(str) {
  var finalString = '';
  while (str.length > 0) {
    finalString += str.substring(0, 64) + '\n';
    str = str.substring(64);
  }

  return finalString;
}

function toPrivatePem(privateKey) {
  var b64 = addNewLines(arrayBufferToBase64(privateKey));
  var pem = "-----BEGIN PRIVATE KEY-----\n" + b64 + "-----END PRIVATE KEY-----";

  return pem;
}

function toPublicPem(publicKey) {
  var b64 = addNewLines(arrayBufferToBase64(publicKey));
  var pem = "-----BEGIN PUBLIC KEY-----\n" + b64 + "-----END PUBLIC KEY-----";

  return pem;
}


/**
 * login.
 * @param {object} userData - user data to log in, {type, user, password}.
 * @param {function} next - next response handler.
 */
AeolixSDK.prototype.login = function (userData, next) {

  if ((userData.type == "user") && ("username" in userData) && ("password" in userData)) {
    try {
      doHTTPRequest(REST_SERVER_URL + '/sdkAPI/login', 'POST', userData, function (httpResponse) {

        if (httpResponse.status == 200) {

          var response = JSON.parse(httpResponse.responseText);

          token = response.access_token;
          refreshToken = response.refresh_token;

          //if autoRefresh
          if (autoRefresh) {
            setInterval(
              function(){
                AeolixSDK.prototype.refreshToken(
                  function(control){
                    console.log(control);
                  }
                );
              },
              refreshPeriod
            );
          }

          generateRSAKeys().then(function () {
            generateRandomRSAKeys().then(function () {
              next(LOGIN_OK);
            });
          });



        } else {

          next(handleHTTPError(httpResponse));

        }
      });
    } catch (e) {

      next(SERVICE_UNAVAILABLE);

    }
  } else {

    next(BAD_REQUEST);

  }
}


/**
 * 
 */
AeolixSDK.prototype.refreshToken = function (next) {
  if (refreshToken) {

    var body = { "refreshToken": refreshToken };

    try {
      doHTTPRequestToken(REST_SERVER_URL + '/sdkAPI/refresh', 'POST', body, token, function (httpResponse) {

        if (httpResponse.status == 200) {

          var response = JSON.parse(httpResponse.responseText);

          token = response.access_token;
          refreshToken = response.refresh_token;

          next(REFRESH_TOKEN_OK);

        } else {

          next(httpResponse);

        }
      });
    } catch (e) {

      next(e);

    }
  } else {

    next(REFRESH_TOKEN_REQUEST_ERROR);

  }
}


/**
 * 
 */
var generateRSAKeys = function () {
  return new Promise(function (resolve) {
    var importer = crypto.subtle.importKey("spki", convertPemToBinary(rsaPublicKey), { name: "RSA-OAEP", hash: { name: "SHA-1" } }, false, ["encrypt"]);
    importer.then(function (key) {
      serverRSAKey = key;
      resolve();
    });
  });
}


var convertPemToBinary = function (pem) {
  var lines = pem.split('\n');
  var encoded = '';
  for (var i = 0; i < lines.length; i++) {
    if (lines[i].trim().length > 0 &&
      lines[i].indexOf('-BEGIN RSA PRIVATE KEY-') < 0 &&
      lines[i].indexOf('-BEGIN RSA PUBLIC KEY-') < 0 &&
      lines[i].indexOf('-BEGIN PUBLIC KEY-') < 0 &&
      lines[i].indexOf('-END PUBLIC KEY-') < 0 &&
      lines[i].indexOf('-END RSA PRIVATE KEY-') < 0 &&
      lines[i].indexOf('-END RSA PUBLIC KEY-') < 0) {
      encoded += lines[i].trim();
    }
  }
  return base64StringToArrayBuffer(encoded);
}

var base64StringToArrayBuffer = function (b64str) {
  var byteStr = atob(b64str);
  var bytes = new Uint8Array(byteStr.length);
  for (var i = 0; i < byteStr.length; i++) {
    bytes[i] = byteStr.charCodeAt(i);
  }
  return bytes.buffer;
}


/**
 * logout.
 * @param {function} next - next response handler.
 */
AeolixSDK.prototype.logout = function (next) {

  if (token && refreshToken) {

    var body = { "refresh_token": refreshToken };

    try {

      doHTTPRequestToken(REST_SERVER_URL + '/sdkAPI/logout', 'POST', body, token, function (httpResponse) {

        if (httpResponse.status == 200) {

          next(LOGOUT_OK);

        } else {

          next(handleHTTPError(httpResponse));

        }
      });
    } catch (e) {

      next(SERVICE_UNAVAILABLE);

    }

  } else {

    token = null;
    refreshToken = null;

    next(LOGOUT_OK);

  }
}


/**
 * setToken.
 * @param {string} newToken - jwt.
 * @param {function} next - next response handler.
 */
AeolixSDK.prototype.setToken = function (newToken, next) {

  if (newToken) {
    var body = { "token": newToken };

    try {
      doHTTPRequestToken(REST_SERVER_URL + '/sdkAPI/exchangeToken', 'POST', body, newToken, function (httpResponse) {

        if (httpResponse.status == 200) {

          var response = JSON.parse(httpResponse.responseText);

          token = response.access_token;
          refreshToken = response.refresh_token;

          //if autoRefresh
          if (autoRefresh) {
            setInterval(
              function(){
                AeolixSDK.prototype.refreshToken(
                  function(control){
                    console.log(control);
                  }
                );
              },
              refreshPeriod
            );
          }

          generateRSAKeys().then(function () {
            generateRandomRSAKeys().then(function () {
              next(SET_TOKEN_OK);
            });
          });

        } else {

          next(handleHTTPError(httpResponse));

        }

      });
    } catch (e) {

      next(SERVICE_UNAVAILABLE);

    }
  } else {

    next(BAD_REQUEST)

  }
}


/**
 * 
 * @param {string} datasourceID 
 * @param {string} data 
 * @param {function} next 
 */
AeolixSDK.prototype.publish = function (datasourceID, data, next) {
  if (token) {

    var AESKey = generateRandomAESKey();
    var AESKeyBuff = str2buffer(AESKey);

    crypto.subtle.importKey("raw", AESKeyBuff, { "name": "AES-CBC", "length": 256 }, true, ["encrypt", "decrypt"]).then(function (key) {

      var cryptoAESKey = key;
      var iv = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
      var dataBuff = str2buffer(data);

      crypto.subtle.encrypt({ "name": "AES-CBC", "iv": iv }, cryptoAESKey, dataBuff).then(function (encryptedData) {

        var requestData = ab2hexStr(encryptedData);

        crypto.subtle.encrypt({ name: "RSA-OAEP", hash: { name: "SHA-1" } }, serverRSAKey, AESKeyBuff).then(function (encryptedKey) {

          var requestKey = ab2hexStr(encryptedKey);

          var requestBody = { "data": requestData, "key": requestKey };

          try {

            doHTTPRequestToken(REST_SERVER_URL + '/sdkAPI/publish/' + datasourceID, 'POST', requestBody, token, function (httpResponse) {

              if (httpResponse.status == 200) {

                next(PUBLISH_OK);

              } else {

                next(handleHTTPError(httpResponse));

              }

            });

          } catch (e) {

            next(SERVICE_UNAVAILABLE);

          }

        });

      });

    });


  } else {

    next(UNAUTHORIZED);

  }
}


var generateRandomAESKey = function () {

  var arrayKey = new Uint8Array(16);
  crypto.getRandomValues(arrayKey);

  var stringKey = ab2hexStr(arrayKey);

  return stringKey;

}

function ab2hexStr(buf) {
  return Array.prototype.map.call(new Uint8Array(buf), x => ('00' + x.toString(16)).slice(-2)).join('');
}

function str2buffer(str) {
  var buf = new ArrayBuffer(str.length); // 2 bytes for each char
  var bufView = new Uint8Array(buf);
  for (var i = 0, strLen = str.length; i < strLen; i++) {
    bufView[i] = str.charCodeAt(i);
  }
  return buf;
}


AeolixSDK.prototype.subscribe = function (datasourceID, callback, next) {

  var socket = io.connect(SOCKET_SERVER_URL, { "query": { "token": token }, "reconnection": false });

  var unsubscribeFlag = false;

  socket.on('control', function(controlResponse){

    if(controlResponse.error || (controlResponse.status && controlResponse.status == 404)) {
      unsubscribeFlag = true;
    }
    
    if(controlResponse.error || controlResponse.code == 252 || controlResponse.code == 202 || (controlResponse.status && controlResponse.status == 404)) {
      //error or unsubscribed
      socket.close();
    }

    next(controlResponse);

  });

  socket.on('connected', function (data) {

    socket.on('message-' + datasourceID, function manageDataMessages(data) {

      var responseData;

      if (data.key) {

        decryptData(data).then(function (decryptedData) {
          callback(decryptedData);
        });

      } else {
        callback(data);
      }

    })

    var subscriptionData = {
      userToken: token,
      datasourceID: datasourceID,
      key: ownPublicRSAKey
    };

    socket.emit('subscribeDatasource', subscriptionData);

    socketCollection[datasourceID] = socket;

  });

  socket.on('unsubscribedDataSource', (response) => {
    
    unsubscribeFlag = true;
 
    next(response);

  });

  socket.on('disconnect', (reason) => {

    delete socketCollection[datasourceID];

    var disconnectMessage = {
      error: true,
      code: 410,
      msg:reason
    }

    if(!unsubscribeFlag) {
      next(disconnectMessage);
    }

  });

}


/**
 * 
 * @param {string} datasourceID 
 * @param {function} next 
 */
AeolixSDK.prototype.unsubscribe = function (datasourceID, next) {
  var socket = socketCollection[datasourceID];

  if(socket) {
    socket.emit('unsubscribeDatasource', {datasourceID: datasourceID});
    next(UNSUBSCRIBE_SENT);
  } else {
    next(NOT_MODIFIED);
  }

}


var decryptData = function (data) {

  return new Promise(function (resolve, reject) {
    var encryptedAESKey = data.key;
    var encrypteAESKeydBuff = hexStr2ab(encryptedAESKey);

    crypto.subtle.decrypt({ name: "RSA-OAEP", hash: { name: "SHA-1" } }, ownRSAKey.privateKey, encrypteAESKeydBuff).then(function (decryptedKey) {

      crypto.subtle.importKey("raw", decryptedKey, { "name": "AES-CBC", "length": 256 }, true, ["encrypt", "decrypt"]).then(function (key) {

        var cryptoAESKey = key;
        var iv = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
        var dataBuff = hexStr2ab(data.data);

        crypto.subtle.decrypt({ "name": "AES-CBC", "iv": iv }, cryptoAESKey, dataBuff).then(function (decriptedData) {

          var hexData = ab2hexStr(decriptedData);
          var responseData = hexStr2utf8(hexData);

          resolve(responseData);
        })

      })

    }, function (error) {
      console.error("Decrypt AES Key error ", error);
      reject(error);
    });

  });

}


/**
 * 
 * @param {string} serviceID 
 * @param {string} payload 
 * @param {function} next 
 */
AeolixSDK.prototype.sendServiceRequest = function (serviceID, payload, next) {
  if (token) {

    var AESKey = generateRandomAESKey();
    var AESKeyBuff = str2buffer(AESKey);

    crypto.subtle.importKey("raw", AESKeyBuff, { "name": "AES-CBC", "length": 256 }, true, ["encrypt", "decrypt"]).then(function (key) {

      var cryptoAESKey = key;
      var iv = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
      var dataBuff = str2buffer(payload);

      crypto.subtle.encrypt({ "name": "AES-CBC", "iv": iv }, cryptoAESKey, dataBuff).then(function (encryptedData) {

        var requestData = ab2hexStr(encryptedData);

        crypto.subtle.encrypt({ name: "RSA-OAEP", hash: { name: "SHA-1" } }, serverRSAKey, AESKeyBuff).then(function (encryptedKey) {

          var requestKey = ab2hexStr(encryptedKey);

          var requestBody = { "data": requestData, "key": requestKey };

          try {

            doHTTPRequestToken(REST_SERVER_URL + '/sdkAPI/services/' + serviceID + '/requests', 'POST', requestBody, token, function (httpResponse) {

              if (httpResponse.status == 200) {

                next(SERVICE_REQUEST_OK);

              } else {

                next(handleHTTPError(httpResponse));

              }

            });

          } catch (e) {

            next(SERVICE_UNAVAILABLE);

          }

        });

      });

    });


  } else {

    next(UNAUTHORIZED);

  }
}


AeolixSDK.prototype.subscribe2ServiceRequest = function (serviceID, callback, next) {

  var socket = io.connect(SOCKET_SERVER_URL, { "query": { "token": token }, "reconnection": false });

  var unsubscribeFlag = false;

  socket.on('control', function(controlResponse){
    
    if(controlResponse.error || (controlResponse.status && controlResponse.status == 404)) {
      unsubscribeFlag = true;
    }
    
    if(controlResponse.error || controlResponse.code == 252 || controlResponse.code == 202 || (controlResponse.status && controlResponse.status == 404)) {
      //error or unsubscribed
      socket.close();
    }

    next(controlResponse);
    
  });

  socket.on('connected', function (data) {

    socket.on('serviceRequest-' + serviceID, function manageDataMessages(data) {

      if (data.key) {

        decryptData(data).then(function (decryptedData) {
          callback(decryptedData);
        });

      } else {
        callback(data);
      }

    })

    var subscriptionData = {
      userToken: token,
      serviceID: serviceID,
      key: ownPublicRSAKey
    };

    socket.emit('subscribeServiceRequest', subscriptionData);

    socketServiceRequestCollection[serviceID] = socket;

  });

  socket.on('unsubscribedServiceRequest', (response) => {
  
    unsubscribeFlag = true;

    next(response);

  });

  socket.on('disconnect', (reason) => {

    delete socketServiceRequestCollection[serviceID];

    var disconnectMessage = {
      error: true,
      code: 410,
      msg:reason
    }

    if(!unsubscribeFlag) {
      next(disconnectMessage);     
    }

  });

}


/**
 * 
 * @param {string} serviceID 
 * @param {function} next 
 */
AeolixSDK.prototype.unsubscribeServiceRequest = function (serviceID, next) {
  var socket = socketServiceRequestCollection[serviceID];

  if(socket) {
    socket.emit('unsubscribeServiceRequest', {serviceID: serviceID});
    next(UNSUBSCRIBE_REQUEST_SENT);
  } else {
    next(NOT_MODIFIED);
  }

}


/**
 * 
 * @param {string} serviceID 
 * @param {string} userID 
 * @param {string} payload 
 * @param {function} next 
 */
AeolixSDK.prototype.sendServiceResponse = function (serviceID, userID, payload, next) {
  if (token) {

    var AESKey = generateRandomAESKey();
    var AESKeyBuff = str2buffer(AESKey);

    crypto.subtle.importKey("raw", AESKeyBuff, { "name": "AES-CBC", "length": 256 }, true, ["encrypt", "decrypt"]).then(function (key) {

      var cryptoAESKey = key;
      var iv = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
      var dataBuff = str2buffer(payload);

      crypto.subtle.encrypt({ "name": "AES-CBC", "iv": iv }, cryptoAESKey, dataBuff).then(function (encryptedData) {

        var requestData = ab2hexStr(encryptedData);

        crypto.subtle.encrypt({ name: "RSA-OAEP", hash: { name: "SHA-1" } }, serverRSAKey, AESKeyBuff).then(function (encryptedKey) {

          var requestKey = ab2hexStr(encryptedKey);

          var requestBody = { "user": userID, "data": requestData, "key": requestKey };

          try {

            doHTTPRequestToken(REST_SERVER_URL + '/sdkAPI/services/' + serviceID + '/response', 'POST', requestBody, token, function (httpResponse) {

              if (httpResponse.status == 200) {

                next(SERVICE_RESPONSE_OK);

              } else {

                next(handleHTTPError(httpResponse));

              }

            });

          } catch (e) {

            next(SERVICE_UNAVAILABLE);

          }

        });

      });

    });


  } else {

    next(UNAUTHORIZED);

  }
}


AeolixSDK.prototype.subscribe2ServiceResponse = function (serviceID, callback, next) {

  var socket = io.connect(SOCKET_SERVER_URL, { "query": { "token": token }, "reconnection": false });

  var unsubscribeFlag = false;

  socket.on('control', function(controlResponse){
    
    if(controlResponse.error || (controlResponse.status && controlResponse.status == 404)) {
      unsubscribeFlag = true;
    }
    
    if(controlResponse.error || controlResponse.code == 252 || controlResponse.code == 202 || (controlResponse.status && controlResponse.status == 404)) {
      //error or unsubscribed
      socket.close();
    }

    next(controlResponse);
    
  });

  socket.on('connected', function (data) {

    socket.on('serviceResponse-' + serviceID, function manageDataMessages(data) {


      if (data.key) {

        decryptData(data).then(function (decryptedData) {
          callback(decryptedData);
        });

      } else {
        callback(data);
      }

    })

    var subscriptionData = {
      userToken: token,
      serviceID: serviceID,
      key: ownPublicRSAKey
    };

    socket.emit('subscribeServiceResponse', subscriptionData);

    socketServiceResponseCollection[serviceID] = socket;

  });

  socket.on('unsubscribedServiceResponse', (response) => {
    
    unsubscribeFlag = true;

    next(response);

  });

  socket.on('disconnect', (reason) => {

    delete socketServiceResponseCollection[serviceID];

    var disconnectMessage = {
      error: true,
      code: 410,
      msg:reason
    }

    if(!unsubscribeFlag) {
      next(disconnectMessage);
    }

  });

}


/**
 * 
 * @param {string} serviceID 
 * @param {function} next 
 */
AeolixSDK.prototype.unsubscribeServiceResponse = function (serviceID, next) {
  var socket = socketServiceResponseCollection[serviceID];

  if(socket) {
    socket.emit('unsubscribeServiceResponse', {serviceID: serviceID});
    next(UNSUBSCRIBE_RESPONSE_SENT);
  } else {
    next(NOT_MODIFIED);
  }

}


var hexStr2ab = function (hex) {
  return new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
    return parseInt(h, 16)
  }));
}

var hexStr2utf8 = function (hex) {
  var str = '';
  for (var i = 0; (i < hex.length && hex.substr(i, 2) !== '00'); i += 2)
    str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
  return str;
}


var doHTTPRequest = function doHTTPRequest(url, method, data, next) {
  var http = null;

  http = new XMLHttpRequest();

  http.addEventListener('error', function (error) {

    console.error(error);

    next(SERVICE_UNAVAILABLE);

  }, false);

  if (method == 'GET' || method == 'DELETE') {
    http.open(method, url, true);
    http.onreadystatechange = function () {
      if (http.readyState == 4 && http.status == 200) {
        next(JSON.parse(http.responseText));
      }
      if (http.readyState == 4 && http.status != 200) {
        next(UNKNWON_ERROR);
      }
    }

    http.send(null);

  }

  if (method == 'POST' || method == 'PUT') {
    http.open(method, url, true);

    http.setRequestHeader("Content-Type", "application/json");
    http.onreadystatechange = function () {
      if (http.readyState == 4) {

        next(http);

      }
    }

    http.send(JSON.stringify(data));

  }
}


var doHTTPRequestToken = function doHTTPRequestToken(url, method, data, token, next) {
  var http = null;

  http = new XMLHttpRequest();

  http.addEventListener('error', function (error) {

    console.error(error);
    next(SERVICE_UNAVAILABLE);

  }, false);

  if (method == 'GET' || method == 'DELETE') {
    http.open(method, url, true);
    http.setRequestHeader("Authorization", "Bearer " + token);
    http.onreadystatechange = function () {
      if (http.readyState == 4 && http.status == 200) {
        next(JSON.parse(http.responseText));
      }
      if (http.readyState == 4 && http.status != 200) {
        next(UNKNWON_ERROR);
      }
    }

    http.send(null);

  }

  if (method == 'POST' || method == 'PUT') {
    http.open(method, url, true);

    http.setRequestHeader("Content-Type", "application/json");
    http.setRequestHeader("Authorization", "Bearer " + token);
    http.onreadystatechange = function () {
      if (http.readyState == 4) {

        next(http);

      }
    }

    if (data) {

      http.send(JSON.stringify(data));

    } else {

      http.send();

    }
  }
}

