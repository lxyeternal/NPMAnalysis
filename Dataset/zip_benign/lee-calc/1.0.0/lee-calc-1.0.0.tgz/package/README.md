
### js 浮点运算方法
> how to use it ?

import * as calc from "long-calc";

// 加
calc.add(0.1, 0.2);

// 减
calc.sub(0.29, 0.1);

// 乘
calc.mul(7.99, 0.8);

// 除
calc.div(2.1, 0.3);