import React, { FC, useState, useEffect, useRef } from 'react'
import { Tooltip } from 'antd'
import _ from 'lodash-es'
import './index.scss'
import configers from '../../configer'

Date.prototype.format = function (format) {
  var o = {
    "M+": this.getMonth() + 1, //month
    "d+": this.getDate(),    //day
    "h+": this.getHours(),   //hour
    "m+": this.getMinutes(), //minute
    "s+": this.getSeconds(), //second
    "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
    "S": this.getMilliseconds() //millisecond
  }
  if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
    (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o) if (new RegExp("(" + k + ")").test(format))
    format = format.replace(RegExp.$1,
      RegExp.$1.length == 1 ? o[k] :
        ("00" + o[k]).substr(("" + o[k]).length));
  return format;
}

const CList: FC = ({
  draggable = true,
  configer = configers
}) => {
  const {
    x,
    y,
    clazz,
    data,

    width,
    height,

    title,
    columnWidth,
    headerFontSize,
    headerFontColor,
    headerHeight,

    headerBGUrl,
    headerBGColor,

    bodyFontSize,
    bodyFontColor,
    bodyRowHeight,

    rowBGColor,
    isScroll,
    showHeader,
    tooltipColor
  } = configer
  const [oddRowBGColor, evenRowBGColor] = rowBGColor?.indexOf('/') > 0 ? rowBGColor.split('/') : []
  const [isScrolle, setIsScrolle] = useState(isScroll);

  const handleDrag = (e) => {
    // antdI本来应该是个数组的，因为一个组件可能包含多个antd的组件，外面可以扁平化啊
    const params = JSON.stringify({ type: 'other', id: 'CList', antdI: '', relate: 'in' })
    e.dataTransfer.setData('Text', params)
  }

  useEffect(() => {
    setIsScrolle(isScroll)
    // 对于第二个参数是对象的问题，可以是string化，也可以是md5化
  }, [JSON.stringify(configer)])

  const speed = 100;
  const warper = useRef();
  const childDom1 = useRef();
  const hoverHandler = (flag) => {
    isScroll === '是' ?
      setIsScrolle(flag) : null
  };

  const handleColor = (val) => {
    if (Number(val) < 0) {
      return 'red'
    } else {
      return 'green'
    }
  }
  useEffect(() => {
    let timer;
    if (isScrolle === '是') {
      timer = setInterval(
        () =>
          warper.current.scrollTop >= childDom1.current.scrollHeight - warper.current.clientHeight
            ? (warper.current.scrollTop = 0)
            : warper.current.scrollTop++,
        speed
      );
    } else {
      clearInterval(timer);
    }
    return () => {
      clearInterval(timer);
    };
  }, [isScrolle])

  return (
    <>
      <div
        draggable={draggable}
        className={`dragor ${clazz}`}
        onDragStart={(e) => { handleDrag(e) }}
        style={{ width: width, height: height }}
      >
        <div className='cz-list'>
          {
            showHeader === '是' ?
              <table className='cz-list-title' style={{ height: headerHeight }}>
                <tbody>
                  <tr style={{ background: `${headerBGColor} url(${headerBGUrl}) no-repeat left 32px` }}>
                    {
                      title.length ? title.map((item, index) => {
                        if(item.show) {
                          let titlestr = typeof Object.values(item)[0] === 'string' ? Object.values(item)[0] : Object.values(item)[1]
                          return (
                            <th key={index} style={{ fontSize: headerFontSize, color: headerFontColor, width: columnWidth[index] }}>{titlestr}</th>
                          )
                        }
                      }) : null
                    }
                  </tr>
                </tbody>
              </table> : null
          }
          <div className='bodycontainer' ref={warper}>
            <table className='cz-list-body' ref={childDom1}>
              <tbody onMouseOver={() => hoverHandler('否')} onMouseLeave={() => hoverHandler('是')}>
                {
                  data.length ? data.map((item, index) => {
                    return (
                      <tr key={index} style={{ height: bodyRowHeight, background: index % 2 === 0 ? oddRowBGColor : evenRowBGColor }}
                        className={`type-${item.type}`}>
                        {
                          item.map((itm, inde) => {
                            if(title[inde].show) {
                              return (
                                <Tooltip color={tooltipColor ? tooltipColor : 'rgba(0,0,0,0.75)'} title={itm} key={index + '-' + inde}>
                                  <td key={index + '-' + inde} style={{
                                    fontSize: bodyFontSize, height: bodyRowHeight, lineHeight: bodyRowHeight, width: columnWidth[inde],
                                    color: bodyFontColor
                                  }} > {itm}
                                  </td>
                                </Tooltip>
                              )
                            }
                          })
                        }
                      </tr>
                    )
                  }) : <tr><td><span style={{ position: 'absolute', top: '50%', left: '50%', color: 'rgba(255, 255, 255, 0.5)', fontSize: '12px', transform: 'translate(-50%,-50%)' }}>暂无数据</span></td></tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

export default CList