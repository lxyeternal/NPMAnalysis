import axios, { AxiosRequestConfig, AxiosResponse } from 'axios'

const service = axios.create({
  baseURL: '',
  timeout: 10000
})

service.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    return config
  },
  (error) => {
    console.log(error)
    return Promise.reject(error)
  }
)

// 访问接口成功后的code码需要全公司统一，用来统一处理每个code对应的策略
service.interceptors.response.use(
  (response: AxiosResponse) => {
    const { code } = response.data
    if (code && code !== 200) {
      console.log('error')
      return Promise.reject(new Error(response.data.msg || 'Error'))
    }
    return response
  },
  (error) => {
    return Promise.reject(error)
  }
)

export default service.request