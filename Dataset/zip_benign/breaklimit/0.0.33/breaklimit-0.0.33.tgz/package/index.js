#!/usr/bin/env node

// process.env.BREAKLIMIT_WEBSITE_URL = 'http://localhost:8080';
process.env.BREAKLIMIT_WEBSITE_URL = 'https://breaklimit.vercel.app';

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
process.env.CLI_ROOT_DIRECTORY = __dirname;

import "@colors/colors";

import { menuMode } from './modes/menuMode.js';
import { menuModeWithDotEnvDefined } from './modes/menuModeWithDotEnvDefined.js';
import { cliMode } from './modes/cliMode.js';
import { validateProvidedCorrectGroupOfArgs, validateArgTypes } from "./util/validateArgs.js";


process.on('uncaughtException', (error) => {
  // in case the user exits the program with Ctrl+C, then don't show the inquirer.js error to the user
  if (error instanceof Error && error.name === 'ExitPromptError') {
    const terminalWidth = process.stdout.columns || 80;
    console.log(''.padEnd(terminalWidth, '-'));
    console.log('Taking a break from breaklimit? How meta!'.rainbow);
  } else {
    // Rethrow unknown errors
    throw error;
  }
});

import { Command } from 'commander';
const program = new Command();

const packageJson = await fs.readFile(path.join(__dirname, 'package.json'), 'utf8');
const versionNumber = JSON.parse(packageJson).version;

program
  .name('breaklimit')
  .description('Schedule a timer for a break and open a website with a countdown timer.')  
  .version(versionNumber);


program
  .option('--open', 'Opens the timer website in your chosen browser.')
  .option('--time <type>', 'Provide the time until the break ends in the format HH:MM or H:MM.')
  .option('--minutes <number>', 'Provide the length of the break in minutes.')
  .option('--seconds <number>', 'Provide the length of the break in seconds.')
  .option('--get-timer', 'Gets the timer if active and displays it in the terminal.')
  .option('--stop-timer', 'Resets the timer if active.')
  .option('--theme <type>', 'Change the theme of the stopwatch just once. Otherwise, consider changing your preferences.')
  .option('--themes', 'Get a list of available themes.');


const dotEnvPath = path.join(__dirname, '.env');
import dotenv from 'dotenv';
dotenv.config({ path: dotEnvPath });

const foundEnvironmentFile = await fs.access(dotEnvPath).then(() => true).catch(() => false);
if (!foundEnvironmentFile) {
    await menuMode();
    process.exit(0);
}


program.parse(process.argv);

const options = program.opts();

const anyFlagsSpecified = validateProvidedCorrectGroupOfArgs(options);

if (anyFlagsSpecified === false) {
  await menuModeWithDotEnvDefined();
  process.exit(0);
}

validateArgTypes(options);
cliMode(options);
