import { getTimeDifferenceInMilliseconds } from "../util/timeUtil.js";
import { handleProgressBar, printTimerSetMessage } from "../util/terminalUtil.js";
import { getTimerFetch, setTimerFetch, resetTimerFetch } from "../api/timersAPI.js";
import { getThemesFetch } from "../api/miscAPI.js";
import { macSay, openBrowser } from "../util/osAndBrowserUtil.js";

export async function cliMode(options) {
    try {
        
        if (options.getTimer) {

            const { remainingMiliseconds, timerEndTimestamp } =  await getTimerFetch(process.env.BREAKLIMIT_ENDPOINT);

            if (remainingMiliseconds > 0) {        
                if (options.open) {

                    openBrowser();
                }

                const endTime = new Date(timerEndTimestamp);

                printTimerSetMessage(remainingMiliseconds, endTime);
                await handleProgressBar(remainingMiliseconds);

            } else {
                console.log('Time has run out'.zebra);
            }
                
        } else if (options.stopTimer) {
            await resetTimerFetch();
            console.log('Timer Finished'.rainbow);
        } else if (options.themes) {
            const themes = await getThemesFetch();

            const terminalWidth = process.stdout.columns || 80;

            console.log('Available Themes:'.rainbow);
            console.log('Specify a theme by name or id `--theme <name or id>`'.green);
            themes.data.forEach((theme, index) => {
                const bgColor = index % 2 === 0 ? 'bgBlue' : 'bgCyan';
                console.log(theme.id, theme.name.padEnd(terminalWidth - 2)[bgColor]);
            });

            // if only open is passed, only open the browser
        } else if (JSON.stringify(options) === '{"open":true}') {
            openBrowser();
        } else {

            if (options.theme) {
                const possibleThemes = await getThemesFetch();

                const foundThemeName = possibleThemes.data.find(
                    (theme) =>
                        theme.name.toLowerCase() === options.theme.trim().toLowerCase() 
                    || theme.id == options.theme
                )?.name;

                if (foundThemeName) {
                    process.env.BREAKLIMIT_THEME = foundThemeName;
                } else {
                    console.log('Theme not found'.red, 'Going by a', 'random'.rainbow, 'theme'.green);
                    process.env.BREAKLIMIT_THEME = 'random';
                }
            }

            const breakLengthInMilliseconds = getTimeDifferenceInMilliseconds(options); 
            const endTime = new Date(Date.now() + breakLengthInMilliseconds);
            await setTimerFetch({ breakLengthInMilliseconds });

            if (process.env.BREAKLIMIT_SAY) {
                const hour = endTime.getHours().toString().padStart(2, '0');
                const minutes = endTime.getMinutes().toString().padStart(2, '0');
            
                macSay(`Break until ${hour}:${minutes}.`);
            }

            if (options.open) {
                openBrowser();
            }

            printTimerSetMessage(breakLengthInMilliseconds, endTime);
            handleProgressBar(breakLengthInMilliseconds);

        }
    } catch (error) {
        console.error(error.message.red);
        console.log(error.stack.blue)
        process.exit(1);
    }
}
