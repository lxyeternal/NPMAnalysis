import { input } from '@inquirer/prompts';
import { saveDotEnvFile } from '../util/dotEnvUtil.js';
import { resetTokenFetch, promoteResetTokenFetch } from '../api/usersAPI.js';
import { codifyPreferences } from './codifyPreferences.js';

export async function setToken() {
    const token = await input({
        name: 'token',
        message: 'Enter your token:',
        validate: (value) => {
            if (!value) {
                return 'Please type something.';
            }
            return true;
        }
    });

    const email = await input({
        type: 'text',
        name: 'email',
        message: 'Enter your ' + 'email address'.italic + '. A token will be sent to you. \n You will ' 
                    + 'need'.italic + ' this token to sign up. ' + 'Email'.bgGrey + ' 📧:',
        validate: (input) => {
            if (input.includes('@') && input.includes('.')) {
                return true;
            }
            return 'Please enter a valid email address.';
        }
    });


    const endpoint = await input({
        name: 'endpoint',
        message: 'Enter your endpoint:',
        validate: (value) => {
            if (!value) {
                return 'Please type something.';
            }
            return true;
        }
    });

    const { isPublic, theme, browserCommand, say } = await codifyPreferences({ token, endpoint, email });

    await saveDotEnvFile({ token, endpoint, isPublic, theme, browserCommand, say });
}

export async function resetToken() {
    const email = await input({
        type: 'text',
        name: 'email',
        message: 'Enter your ' + 'email address'.italic + '. A token will be sent to you. \n You will ' 
                    + 'need'.italic + ' this token to sign up. ' + 'Email'.bgGrey + ' 📧:',
        validate: (input) => {
            if (input.includes('@') && input.includes('.')) {
                return true;
            }
            return 'Please enter a valid email address.';
        }
    });

    let endpoint = process.env.BREAKLIMIT_ENDPOINT;

    if (!endpoint) {
        endpoint = await input({
            type: 'text',
            name: 'endpoint',
            message: 'Enter your endpoint. 🌐',
            validate: async (value) => {
                if (!value) {
                    return 'Please type something.';
                }
                return true;
            }
        });
    }

    const body = { email, endpoint };
    try {
        await resetTokenFetch(body);
    } catch (error) {
        console.error(error);
        throw new Error("Failed to send reset token. Please check your details.");
    }

    const token = await input({
        type: 'text',
        name: 'token',
        message: 'Enter the token you received in your email. 🔑',
        validate: async (token) => {
            const isTokenValid = await promoteResetTokenFetch({ endpoint: process.env.BREAKLIMIT_ENDPOINT, token });

            return isTokenValid || 'Token is invalid. Please try again.';
        }
    });


    const { isPublic, theme, browserCommand, say } = await codifyPreferences({ token, endpoint, email });

    await saveDotEnvFile({ token, endpoint, isPublic, theme, browserCommand, say });
}