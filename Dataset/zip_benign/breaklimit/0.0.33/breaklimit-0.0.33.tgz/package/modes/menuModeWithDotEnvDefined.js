import { select } from '@inquirer/prompts';
import { handleProgressBar, printTimerSetMessage } from "../util/terminalUtil.js";
import { getTimerFetch, resetTimerFetch } from "../api/timersAPI.js";
import { deleteUserFetch } from "../api/usersAPI.js";
import { codifyPreferences } from "./codifyPreferences.js";
import { deleteDotEnvFile, saveDotEnvFile } from '../util/dotEnvUtil.js';
import { setToken, resetToken } from './tokenSetReset.js';

export async function menuModeWithDotEnvDefined() {
    const terminalWidth = process.stdout.columns || 80;

    console.log(''.padEnd(terminalWidth).bgGrey);
    console.log("Did you forget to pass flags?".padEnd(terminalWidth).bgGrey);
    console.log(''.padEnd(terminalWidth).bgGrey);
    const message = "Try out this command:";
    const command = "breaklimit --minutes 1 --open";
    console.log(message.bgBlack, command.padEnd(terminalWidth - message.length - 1).bgBlue);
    console.log();

    let timerIsActive = false;
    const { remainingMiliseconds, timerEndTimestamp } =  await getTimerFetch(process.env.BREAKLIMIT_ENDPOINT);
    if (remainingMiliseconds > 0) {
        timerIsActive = true;
    }

    

    const menuChoice = await select({
        message: 'Otherwise,'.italic + ' here are some ' + 'options'.zebra.bgGrey,
        choices: [
            timerIsActive && { name: '1. Get Remaining Time ⏳', value: 1 },
            timerIsActive && { name: '2. Stop Timer ⏹️', value: 2 },
            { name: '3. Reset Token', value: 3 },
            { name: '4. Set Token', value: 4 },
            { name: '5. Delete User 🛑', value: 5 },
            { name: '6. Update Preferences ⚙️', value: 6 }
        ].filter(Boolean)
    });

    if (menuChoice === 1) {
        // Get Remaining Time
        console.clear();

        const endTime = new Date(timerEndTimestamp);

        printTimerSetMessage(remainingMiliseconds, endTime);
        await handleProgressBar(remainingMiliseconds);

    } else if (menuChoice === 2) {
        // Stop Timer
        await resetTimerFetch();
        console.log('Timer Reset'.america);
    } else if (menuChoice === 3) {
        // Reset Token
        await resetToken();
    } else if (menuChoice === 4) {
        // Set Token
        await setToken();
    } else if (menuChoice === 5) {
        // Delete User
        await deleteUser();
    } else if (menuChoice === 6) {
        // Update Preferences
        const preferences = {
            endpoint: process.env.BREAKLIMIT_ENDPOINT,
            token: process.env.BREAKLIMIT_TOKEN,
            email: undefined
        };
        const result = await codifyPreferences(preferences);
        await saveDotEnvFile({ ...result, ...preferences });
        console.log('Preferences Updated'.america);
    }
}

async function deleteUser() {
    console.clear();
    console.log('Delete User');
    console.log('Are you sure you want to delete your user?'.bgRed);

    const confirm = await select({
        message: 'This action cannot be undone'.bgRed,
        choices: [
            { name: 'Yes', value: true },
            { name: 'No', value: false }
        ]
    });

    if (confirm) {
        console.log('Deleting user...'.bgRed);

        const body = {
            endpoint: process.env.BREAKLIMIT_ENDPOINT,
            token: process.env.BREAKLIMIT_TOKEN
        };

        await deleteUserFetch(body);
        
        await deleteDotEnvFile();

        console.log('Sad to see you go, but you can always come back!'.bgGreen);

    } else {
        console.log('Pheeew!'.italic, 'User not deleted'.bgGreen);
    }
}