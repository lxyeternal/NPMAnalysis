import { select } from '@inquirer/prompts';
import { getThemesFetch } from '../api/miscAPI.js';
import { isMac, macSay, getInstalledBrowsers, getBrowserCommand } from '../util/osAndBrowserUtil.js';
import { updateUserPreferencesFetch } from '../api/usersAPI.js';

export async function codifyPreferences({ endpoint, email, token }) {
    const terminalWidth = process.stdout.columns || 80;

    console.log("Time".rainbow, "to select some preferences.")
    console.log(''.padEnd(terminalWidth).bgGrey);
    console.log('You can always change your preferences later.'.padEnd(terminalWidth).bgGrey);
    console.log(''.padEnd(terminalWidth).bgGrey);
    console.log();

    const isPublic = await select({
        message: 'Would you like to make the timers public? \n Public timers will appear on the frontpage of the website when active.',
        choices: [
            { name: 'Yes'.green, value: true },
            { name: 'No'.red, value: false }
        ]
    });


    const possibleThemes = await getThemesFetch();

    console.log();
    console.log('Choose a default theme for your stopwatch.');
    console.log('Choosing the', 'random'.rainbow, 'theme selects a random theme every time');
    console.log('You can always overwrite the theme with the', '--theme <name>'.underline, ' flag');

    const selectTheme = await select({
        message: "Theme: ",
        choices: possibleThemes.data.map((themeOption) => 
            ({ name: themeOption.name, value: themeOption })
        )
    });

    const theme = selectTheme.name;

    await updateUserPreferencesFetch({ endpoint, email, token, isPublic, theme });


    const installedBrowsers = await getInstalledBrowsers();

    const selectedBrowser = await select({
        message: 'When you run breaklimit with the ' + '--open'.underline + ' flag \n which browser would you like to open the timer in?',
        choices: installedBrowsers.map((browser) => 
            ({ name: browser, value: browser })
        )
    });

    const browserCommand = await getBrowserCommand(selectedBrowser);

    let say;
    if (isMac()) {
        macSay('Break until 10:15.');
        say = await select({
            message: 'Would you like to hear ' + 'this voice '.italic + '(Example: Break until 10:15) '.underline + 'every time the timer is set? 🔊',
            choices: [
                { name: 'Yes'.green, value: 'yes' },
                { name: 'No'.red, value: undefined }
            ]
        });
    }

    return {
        isPublic,
        theme,
        browserCommand,
        say
    };
}