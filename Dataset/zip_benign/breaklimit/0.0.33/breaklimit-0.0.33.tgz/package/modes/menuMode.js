import { select } from '@inquirer/prompts';
import { codifyPreferences } from './codifyPreferences.js';
import { getUnusedEndpoint, getEmailAndCreateUser, getTokenAndVerify } from './miscMenuOptions.js';
import { saveDotEnvFile } from '../util/dotEnvUtil.js';
import { setToken, resetToken } from './tokenSetReset.js';

export async function menuMode() {
    const menuChoice = await select({
        message: 'What would you like to do?',
        choices: [
            { name: '1. Sign Up ' + '(Get Started)'.green, value: 1 },
            { name: '2. Reset User Token', value: 2 },
            { name: '3. Set User Token', value: 3 }
        ]
    });
    
    if (menuChoice === 1) {
        await menuSignUp();
    } else if (menuChoice === 2) {
        await resetToken();
    } else if (menuChoice === 3) {
        await setToken();
    }
}

async function menuSignUp() {
    const endpoint = await getUnusedEndpoint();
    const email = await getEmailAndCreateUser({ endpoint });
    const token = await getTokenAndVerify({ endpoint, email });

    const terminalWidth = process.stdout.columns || 80;

    console.log();
    console.log(''.padEnd(terminalWidth, '=').zebra);
    console.log();

    const preferences = await codifyPreferences({ endpoint, email, token });


    await saveDotEnvFile({ ...preferences, token, endpoint });

    console.log();
    console.log('You are good to go!'.america);
    console.log('Try out this command:', "breaklimit --minutes 1 --open".bgBlue.red);
}

