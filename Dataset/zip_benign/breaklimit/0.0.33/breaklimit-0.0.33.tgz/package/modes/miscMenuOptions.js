import { input } from '@inquirer/prompts';
import { isEndpointAvailableFetch } from '../api/timersAPI.js';
import { registerUserFetch, verifyTokenFetch } from '../api/usersAPI.js';

export async function getUnusedEndpoint() {
    console.log('The endpoint is your personal URL path where your timer will be accessible.'.blue);
    const endpoint = await input({
        type: 'text',
        name: 'endpoint',
        message: 'Enter the endpoint you would like to use. ' + '(e.g. "mytimer")'.bgBlack + ' 🌐',
        validate: async (input) => {
            if (!input) {
                return 'Please type something.';
            }

            const isEndpointAvailable = await isEndpointAvailableFetch(input);
            if (!isEndpointAvailable) {
                return 'Endpoint is already in use. Please choose another one.';
            } else {
                return true;
            }

        }
    });

    console.log('The endpoint is now yours.'.green);

    return endpoint;
}

export async function getEmailAndCreateUser(body) {
    const email = await input({
        type: 'text',
        name: 'email',
        message: 'Enter your ' + 'email address'.italic + '. A token will be sent to you. \n You will ' 
                    + 'need'.italic + ' this token to sign up. ' + 'Email'.bgGrey + ' 📧:',
        validate: (input) => {
            if (input?.includes('@') && input?.includes('.')) {
                return true;
            }
            return 'Please enter a valid email address.';
        }
    });

    body.email = email;
    const response = await registerUserFetch(body);
    console.log('A token has been sent to', email.underline);

    return email;
}

export async function getTokenAndVerify(body) {
    const token = await input({
        type: 'text',
        name: 'token',
        message: 'Enter the token you received in your email. 🔑',
        validate: async (token) => {
            if (!token) {
                return 'Please type something.';
            }
            const isTokenValid = await verifyTokenFetch({ endpoint: body.endpoint, token });

            return isTokenValid || 'Token is invalid. Please try again.';
        }
    });

    console.log('Token verified.'.green);

    return token;
}


