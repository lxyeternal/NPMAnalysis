import { platform } from 'os';
import { exec } from 'child_process';
import { access } from 'fs/promises';

import defaultBrowser from 'default-browser';


function getOS() {
    // posibilities: 'aix', 'darwin', 'freebsd', 'linux', 'openbsd', 'sunos', 'win32'
    return platform();
}

export function isMac() {
    return getOS() === 'darwin';
}

export function macSay(text) {
    const safeText = text.replace(/"/g, '\\"');

    try {
        exec(`say "${safeText}"`);
    } catch (error) {
        console.error('Could not run `say` on Mac'.red);
    }
}

// Browser functions

async function getDefaultBrowser() {
    try {
        return (await defaultBrowser()).name;
    } catch {
        throw new Error('Failed to get default browser');
    }
}

async function isBrowserInstalled(path) {
    try {
        await access(path);
        return true;
    } catch {
        return false;
    }
}

export async function getInstalledBrowsers() {
    const currentOS = getOS();
    const browserPaths = {
        win32: {
            "Google Chrome": 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
            Firefox: 'C:\\Program Files\\Mozilla Firefox\\firefox.exe',
            "Microsoft Edge": 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
        },
        darwin: {
            "Google Chrome": '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
            Firefox: '/Applications/Firefox.app/Contents/MacOS/firefox',
            Safari: '/Applications/Safari.app/Contents/MacOS/Safari',
            LibreWolf: '/Applications/LibreWolf.app/Contents/MacOS/LibreWolf',
        },
    };

    const paths = browserPaths[currentOS] || {};
    const installedBrowsers = [];

    if (currentOS === 'win32' || currentOS === 'darwin') {
        const checks = Object.entries(paths).map(async ([browser, path]) => {
            if (await isBrowserInstalled(path)) {
                installedBrowsers.push(browser);
            }
        });
        await Promise.all(checks);
    } else {
        throw new Error(`Unsupported OS: ${currentOS} for getting installed browsers.`);
    }

    if (installedBrowsers.length === 0) {
        installedBrowsers.push(await getDefaultBrowser());
    }

    return installedBrowsers;
}

export function getBrowserCommand(browser) {
    const currentOS = getOS();

    if (currentOS === 'win32') {
        const browserPaths = {
            "Google Chrome": '"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"',
            "Firefox": '"C:\\Program Files\\Mozilla Firefox\\firefox.exe"',
            "Microsoft Edge": '"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"',
        };

        return browserPaths[browser] || `start "" "${browser}"`;
    } else if (currentOS === 'darwin') {
        return `open -a '${browser}'`;
    } else if (currentOS === 'linux') {
        return `xdg-open`;
    } else {
        throw new Error(`Unsupported OS: ${currentOS} for opening browser.`);
    }
}

export async function openBrowser() {
    try {
        const browserCommand = process.env.BREAKLIMIT_BROWSER_COMMAND;
        const urlToOpen = process.env.BREAKLIMIT_WEBSITE_URL + "/timer/" + process.env.BREAKLIMIT_ENDPOINT;

        exec(`${browserCommand} "${urlToOpen}"`, (error) => {
            if (error) {
                throw new Error(`Failed to open browser: ${browserCommand}`);
            }
        });
    } catch {
        throw new Error(`Failed to open browser: ${browserCommand}`);
    }
}
