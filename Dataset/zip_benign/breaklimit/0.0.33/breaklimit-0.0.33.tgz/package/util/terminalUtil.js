import cliProgress from "cli-progress";
import { resetTimerFetch } from "../api/timersAPI.js";

export function handleProgressBar(durationMilliseconds) {
    return new Promise((resolve, reject) => {
        const progressBar = new cliProgress.SingleBar({
            barCompleteChar: '\u2588',
            barIncompleteChar: '\u2591',
            format: '{bar}',
            barsize: process.stdout.columns // Set the bar size to the full width of the terminal
        }, cliProgress.Presets.shades_classic);
        
        const progressBarUpdateRate = 100; 
        const totalSteps = durationMilliseconds / progressBarUpdateRate;
        progressBar.start(totalSteps, 0);

        const progressBarInterval = setInterval(() => {
            progressBar.increment();        
        }, progressBarUpdateRate);
        
        setTimeout(async () => {
            clearInterval(progressBarInterval);
            progressBar.update(totalSteps);
            progressBar.stop();
            await resetTimerFetch();
            console.log("Timer Finished".rainbow);
        }, durationMilliseconds);
    });
}

export function printTimerSetMessage(durationMilliseconds, endTime) {
    const seconds = durationMilliseconds / 1000;
    const durationMinutes = Math.floor(seconds / 60);
    const durationSeconds = Math.round(seconds % 60); 
    
    const endTimeString = endTime.toLocaleTimeString();

    const timerSetForText = "Time remaining ".green;
    const durationText = (`${durationMinutes}m ${durationSeconds}s. `).yellow;
    const endingAtText = "Timer ending at ".green;
    const endTimeText = (`${endTimeString}.`).blue;
    
    const message = timerSetForText + durationText + endingAtText + endTimeText;

    console.log(message);   
}