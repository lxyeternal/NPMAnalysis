export function getTimeDifferenceInMilliseconds(options) {
    let diffMilliseconds = 0;

    if (options.minutes) {
        diffMilliseconds += Number(options.minutes) * 60 * 1000;
    }

    if (options.seconds) {
        diffMilliseconds += Number(options.seconds) * 1000;
    }

    if (options.time) {
        const milliseconds = getHHMMTimeDifferenceInMilliseconds(options.time);
        diffMilliseconds = milliseconds;
    }

    return diffMilliseconds;
}


function getHHMMTimeDifferenceInMilliseconds(time) {
    const now = new Date();

    const timeParts = time.split(":");

    const hours = Number(timeParts[0], 10);
    const minutes = Number(timeParts[1], 10);
  
    // Create a date object for the given time on today's date
    const targetTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes, 0, 0);

    // Calculate difference
    let diffMilliseconds = targetTime.getTime() - now.getTime();
  
    // No negative time diff should be possible so move it to the next day (add 24 hours)
    if (diffMilliseconds < 0) {
        diffMilliseconds += 24 * 60 * 60 * 1000; 
    }


    return diffMilliseconds;
}


