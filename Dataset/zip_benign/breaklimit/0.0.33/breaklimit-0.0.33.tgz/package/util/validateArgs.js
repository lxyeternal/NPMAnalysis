export function validateProvidedCorrectGroupOfArgs(options) {
    // Check if the user provided the correct options
    const group1 = options.time !== undefined;
    const group2 = options.minutes !== undefined || options.seconds !== undefined;
    const group3 = options.getTimer !== undefined || options.stopTimer !== undefined;
    const group4 = options.theme !== undefined;
    const group5 = options.themes !== undefined;
    const group6 = options.open !== undefined;

    if (!(group1 || group2 || group3 || group4 || group5 || group6)) {
        // console.error('Error: Specify --time, --minutes/--seconds or --reset.'.red);
        // no flags specified, return false so that the menu mode is run
        return false;
    }

    // Ensure `--theme` is not used alone
    if (group4 && !(group1 || group2 || group3 || group5)) {
        console.error('Error: --theme must be used with --time, --minutes/--seconds, --reset, or --themes.'.red);
        process.exit(1);
    }
    
    // If attempting to set time, ensure that there aren't conflicting flags
    if ((group1 && group2) || (group1 && group3) || (group2 && group3)) {
        console.error('Error: Specify only one group of options.'.red);
        process.exit(1);
    }
}

export function validateArgTypes(options) {
    // Validate minutes and seconds are numbers
    if (options.minutes && isNaN(options.minutes)) {
        console.error('Error: --minutes must be a number.');
        process.exit(1);
    } 

    if (options.seconds && isNaN(options.seconds)) {
        console.error('Error: --seconds must be a number.');
        process.exit(1);
    }

    // Validate time format HH:MM or H:MM
    if (options.time && !/^(\d{1,2}):\d{2}$/.test(options.time)) {
        console.error('Error: --time must be in format HH:MM or H:MM.');
        process.exit(1);
    }
}
