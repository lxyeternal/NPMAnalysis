import fs from 'fs';
import path from 'path';

export function saveDotEnvFile(preferences) {

    let additionalPreferences = '';
    if (preferences.say) {
        additionalPreferences += `BREAKLIMIT_SAY="${preferences.say}"\n`;
    }
    
    const dotEnvFileContents = 
`BREAKLIMIT_TOKEN="${preferences.token || process.env.BREAKLIMIT_TOKEN}"
BREAKLIMIT_ENDPOINT="${preferences.endpoint || process.env.BREAKLIMIT_ENDPOINT}"
BREAKLIMIT_BROWSER_COMMAND="${preferences.browserCommand || process.env.BREAKLIMIT_BROWSER_COMMAND}"
BREAKLIMIT_THEME="${preferences.theme || process.env.BREAKLIMIT_THEME}"
${additionalPreferences}

`;

    const outputPath = path.join(process.env.CLI_ROOT_DIRECTORY, '.env');

    fs.writeFileSync(outputPath, dotEnvFileContents);
}

export function deleteDotEnvFile() {
    const outputPath = path.join(process.env.CLI_ROOT_DIRECTORY, '.env');

    if (fs.existsSync(outputPath)) {
        fs.unlinkSync(outputPath);
    } else {
        console.log('No .env file found.');
    }
}
