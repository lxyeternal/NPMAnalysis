export async function registerUserFetch(body) {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+"/users", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    })
    const result = await response.json();
    return result;
}

export async function verifyTokenFetch(body) {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+"/tokens/verify", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });

    if (response.status === 200) {
        return true;
    } else {
        return false;
    }
}

export async function resetTokenFetch(body) {
    // body: email, endpoint
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+"/tokens/reset", {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok) {
        throw new Error(result.errorMessage);
    }
}


export async function promoteResetTokenFetch(body) {
    // body: email, endpoint
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+"/tokens/reset/promote", {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        return false;
    }
    return true;
}


export async function updateUserPreferencesFetch(body) {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL + "/users", {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        throw new Error("Error updating user preferences", response.statusText);
    }
}

export async function deleteUserFetch(body) {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL + "/users", {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        throw new Error("Error deleting user preferences", response.statusText);
    }
}
