export async function getThemesFetch() {
    const response = await fetch(`${process.env.BREAKLIMIT_WEBSITE_URL}/themes`);
    const themes = await response.json();
    return themes;
}