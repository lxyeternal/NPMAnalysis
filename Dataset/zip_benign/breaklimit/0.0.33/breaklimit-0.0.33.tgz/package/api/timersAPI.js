
export async function isEndpointAvailableFetch(endpoint) {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+`/endpointavailable/${endpoint}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        }
    });
 
    if (response.status === 200) {
        // Endpoint is available
        return true;
    } else if (response.status === 409) {
        // Endpoint is in use
        return false;
    }
    throw new Error("Error in isEndpointAvailableFetch");
}

export async function getTimerFetch(endpoint) {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+`/timers/${endpoint}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        }
    });
    const result = await response.json();
    return result;
}

export async function setTimerFetch({ breakLengthInMilliseconds }) {
    
    const body = JSON.stringify({
        breakLengthInMilliseconds,
        endpoint: process.env.BREAKLIMIT_ENDPOINT.trim(),
        token: process.env.BREAKLIMIT_TOKEN.trim(),
        theme: process.env.BREAKLIMIT_THEME.trim(),
    });
    
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+"/timers", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body,
    });

    if (!response.ok) {
        console.log("Error in setTimerFetch".red);
        console.log(response.statusText);
        console.log();
        throw new Error(response);

    }
    const result = await response.json();
    return result;
}

export async function resetTimerFetch() {
    const response = await fetch(process.env.BREAKLIMIT_WEBSITE_URL+"/timers", {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            token: process.env.BREAKLIMIT_TOKEN,
            endpoint: process.env.BREAKLIMIT_ENDPOINT,
        }),
    });
    const result = await response.json();
    return result;
}
