# breaklimit

The CLI to interact with https://breaklimit.vercel.app/.

*Enjoy the [Break Limit theme song](https://suno.com/song/7ee1e166-d7bc-4043-830d-bb2b5c3d0102) while you get started.*

---

## Get Started

```bash
$ npm install -g breaklimit
```

Then choose the first option to sign up:


```bash
$ breaklimit
```

**Read all the text carefully and follow the instructions.**

---

## Post Sign-Up Menu

You can run the CLI again without any flags to get additional options:

```bash
$ breaklimit
```

This will give you the following options:

```text
❯ 1. Get Remaining Time
  2. Stop Timer
  3. Reset Token
  4. Set Token
  5. Delete User
  6. Update Preferences
  7. Exit
```

1. **Get Remaining Time**: Will appear if a timer is active. Since `CTRL+C` will cancel the CLI but not the timer on the website, this way you can get the progress bar back to visualize the remaining time.

2. **Stop Timer**: Will appear if a timer is active. It will reset the timer.

3. **Reset Token**: Will reset the token and send a new token to your email. Use this if you've lost your token.

4. **Set Token**: Will allow you to set an existing token. Use this if you want to use the CLI on a different device with the same user.

5. **Delete User**: Will delete your user and all associated data.

6. **Update Preferences**: Will allow you to update your preferences which will remember your preferences when you start a timer.

---

## Start a timer

Example commands:

```bash
$ breaklimit --time 11:55 
$ breaklimit --minutes 0.5 --open
$ breaklimit --seconds 1500 --theme classic
$ breaklimit --minutes 15 --seconds 30
```

You can always run the following to get an overview of the flags:

```bash
$ breaklimit --help
```

Overview of commands:

| Command             | Description                                                                                     |
|---------------------|-------------------------------------------------------------------------------------------------|
| `--open`            | Opens the timer website in your chosen browser.                                                 |
| `--time <type>`     | Provide the time until the break ends in the format `HH:MM` or `H:MM`.                          |
| `--minutes <number>`| Provide the length of the break in minutes.                                                     |
| `--seconds <number>`| Provide the length of the break in seconds.                                                     |
| `--get-timer`       | Gets the timer if active and displays it in the terminal.                                       |
| `--stop-timer`      | Resets the timer if active.                                                                     |
| `--theme <type>`    | Change the theme of the stopwatch just once. Otherwise, consider changing your preferences.     |
| `--themes`          | Get a list of available themes.                                                                 |


---

## Menu Options Scenarios

These menu options can be invoked simply by running `breaklimit`:

| Scenario                                                      | Menu Option                           |
|---------------------------------------------------------------|---------------------------------------|
| I don't have a user                                           | Sign up                               |
| I have lost my token                                          | Reset token                           |
| I want to use the CLI on a different device                   | Set token                             |
| I uninstalled/reinstalled breaklimit and the token is no longer set but I have it in an email | Get it from the email -> Set token    |
| I want to delete my user and my token is set                  | Delete user                           |
| I want to delete my user and I have lost my token             | Reset token -> Delete user            |
| I want a different endpoint                                   | Delete user -> Sign up                |
| I want to change my preferences (public/private timer, default theme, voice) | Update preferences             |

You will know if the token is set after running `breaklimit` and if you see a **Sign Up** option, the token is not set.

---

## Permission errors

If you see an `erno -13: EACCESS: Permission Denied` error when trying to install the CLI, you do not have the right to install packages globally. There are three solutions:

1. **Use `sudo`**: You only need to do this for operations that require write operations to your filesystem: installing, creating user, setting token and updating preferences. Running the CLI to start a timer does not require `sudo`.

2. Change the default global directory for NPM.

3. Fix permissions for the global directory:

```bash
$ sudo chown -R $(whoami) $(npm config get prefix)/{lib/node_modules,bin,share}
```

---

## Tips for Website Usage

The `classic` theme contains a QR code for your custom endpoint. It can be clicked to expand it for easy scanning. 

---

## Issues and Feature Requests

Feel free to open an issue on the [GitHub repository](https://github.com/anderslatif/breaklimit/issues).
