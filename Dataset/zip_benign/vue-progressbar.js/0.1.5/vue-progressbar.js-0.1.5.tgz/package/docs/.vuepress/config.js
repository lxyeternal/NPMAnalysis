module.exports = {
  base: '/vue-progressbar/',
  ga:'UA-122319353-1',
  docsDir: 'docs',
  title: 'vue-progress.js',
  description: ''
}
