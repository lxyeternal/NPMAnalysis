import ProgressBar from '@/components/ProgressBar.vue'

const VueProgressBar = {
  install (Vue, options) {
    Vue.component('vue-progress-bar', ProgressBar)
  }
}

if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(VueProgressBar)
}

export default VueProgressBar
