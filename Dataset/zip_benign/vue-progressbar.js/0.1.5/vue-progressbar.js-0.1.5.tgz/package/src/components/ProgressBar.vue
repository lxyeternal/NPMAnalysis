<template>
  <div class="vue-progress-bar">
    <slot v-if="shape === 'path'"></slot>
  </div>
</template>

<script>
// import { Line, Circle, SemiCircle, Path } from 'progressbar.js'
const ProgressBar = require('progressbar.js')

export default {
  name: 'ProgressBar',
  props: {
    shape: {
      type: String,
      default: 'Line'
    },
    options: {
      type: Object,
      default: function () {
        return {}
      }
    }
  },
  data () {
    return {
      progressbar: null
    }
  },
  computed: {
    normalizedOptions () {
      return Object.assign({
        color: '#555',
        strokeWidth: 1.0,
        trailColor: '#eee',
        trailWidth: 1.0,
        duration: 800,
        easing: 'linear',
        warnings: false
      }, this.options)
    }
  },
  methods: {
    /* eslint-disable */
    svg () {
      this.progressbar.svg
    },
    path () {
      this.progressbar.path
    },
    trail () {
      this.progressbar.trail
    },
    text () {
      this.progressbar.text
    },
    animate (progress, options, callback) {
      this.progressbar.animate(progress, options, callback)
    },
    set (progress) {
      this.progressbar.set(progress)
    },
    stop () {
      this.progressbar.stop()
    },
    value () {
      this.progressbar.value()
    },
    setText (text) {
      this.progressbar.setText(text)
    },
    destroy () {
      this.progressbar.destroy()
    }
  },
  mounted () {
    let shape = this.shape === 'semiCircle' ? 'SemiCircle' : this.shape.charAt(0).toUpperCase() + this.shape.substr(1)
    if(shape === 'Path') {
      if(this.$slots.default.length !== 1 || this.$slots.default[0].tag !== 'svg') throw new Error('[VueProgressBar Error] Svg is not setup correctly.')
      let path = this.$el.querySelectorAll('path')
      if(path.length !== 2) throw new Error('[VueProgressBar Error] Path is not setup correctly.')
      this.progressbar = new ProgressBar[shape](path[1], this.normalizedOptions)
    } else {
      this.progressbar = new ProgressBar[shape](this.$el, this.normalizedOptions)
    }
  }
}
</script>
