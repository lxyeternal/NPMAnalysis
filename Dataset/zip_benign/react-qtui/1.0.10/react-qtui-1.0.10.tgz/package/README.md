# React-QtUI [![npm version](https://img.shields.io/npm/v/react-qtui.svg)](https://www.npmjs.org/package/react-qtui)

[QtUI](https://github.com/zyxdick6/qtui) Components build with [React](http://facebook.github.io/react/).


## Docs

1.0.x [documentation](https://qtui.github.io/react-qtui/docs/) with live examples.

0.4.x [documentation](https://n7best.github.io/react-qtui-doc-0.4.0) with live examples.

## Installation (0.4.x)

With [npm](http://npmjs.com/):

If React is not installed

```
npm install --save react react-dom
npm install --save qtui@1.1.2 react-qtui
```

With React Installed

```
npm install qtui@1.1.2 react-qtui --save
```

To use the development version (`API might changes on realese version`)

```
npm install react-qtui@alpha --save
```

## Example

We have several examples on the documentation. Here is the first one to get you started:
```javascript
// app.js

import React, { Component } from 'react';
import ReactDOM from 'react-dom';

//import using commonJS Module *Require Plugins
//import { Button } from 'react-qtui'

//import Using ES6 syntax
import QtUI from 'react-qtui';

//import styles
import 'qtui';
import 'react-qtui/lib/react-qtui.min.css';

const {Button} = QtUI;

class App extends Component {
    render() {
        return (
            <Button>hello qingtui</Button>
        );
    }
}

ReactDOM.render((
    <App/>
), document.getElementById('container'));

```

## Contributing

Welcome and send the PR in! Development of components will happen in this github repo.

See the [contributing guidelines](https://github.com/n7best/react-qtui-1/blob/master/CONTRIBUTING.md) for details.


## License

The MIT License([http://opensource.org/licenses/MIT](http://opensource.org/licenses/MIT))
