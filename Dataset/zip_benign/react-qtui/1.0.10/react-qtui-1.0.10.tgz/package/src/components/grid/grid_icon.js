import React from 'react';
import classNames from 'classnames';

/**
 * QtUI Grid Icon Wrapper
 *
 */
export default class GridIcon extends React.Component {
    render() {
        const {children, className, ...others} = this.props;
        const cls = classNames({
            'qtui-grid__icon': true
        }, className);

        return (
            <div className={cls} {...others}>{children}</div>
        );
    }
};