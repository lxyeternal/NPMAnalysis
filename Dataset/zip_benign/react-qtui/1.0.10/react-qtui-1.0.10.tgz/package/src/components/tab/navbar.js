import React from 'react';
import classNames from 'classnames';

/**
 *  wrapper for navbar
 *
 */
export default class NavBar extends React.Component {

    render() {

        const {children, className, ...others} = this.props;
        const cls = classNames({
            'qtui-navbar': true
        }, className);

        return (
            <div className={cls} {...others}>
                {children}
            </div>
        );
    }
}