import React from 'react';
import classNames from 'classnames';

/**
 * QtUI Input wrapper for `input`
 *
 */
const Input = (props) => {
    const { className, ...others } = props;
    const cls = classNames({
        'qtui-input': true,
        [className]: className
    });

    return (
        <div>
            <input className={cls} {...others}/>
            <span className="qtui-icon-checked"></span>
        </div>
    );
};

Input.propTypes = {
    defaultValue: React.PropTypes.string
};

Input.defaultProps = {
    defaultValue: undefined
};

export default Input;
