import React from 'react';
import classNames from 'classnames';
import Icon from '../icon';

/**
 * Wrapper for Gallery Delete Button
 *
 */
const GalleryDelete = (props) => {
    const { className, ...others } = props;
    const cls = classNames({
        'qtui-gallery__del': true,
        [className]: className
    });

    return (
        <a className={cls} {...others}>
            <Icon value="delete" className="qtui-icon_gallery-delete" />
        </a>
    );
};

export default GalleryDelete;

