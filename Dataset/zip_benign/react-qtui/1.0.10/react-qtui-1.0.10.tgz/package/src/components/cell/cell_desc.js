import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

/**
 * Footer of `Cell`
 *
 */
const CellDesc = (props) => {
    const { className, children, primary, error, ...others } = props;
    const cls = classNames({
        'qtui-cell__desc': true,
        'qtui-cell_primary': primary,
        'error': error,
        [className]: className
    });

    return (
        <div className={ cls } { ...others }>{ children }</div>
    );
};

CellDesc.propTypes = {
    /**
     * if cell body is the primary block
     *
     */
    primary: PropTypes.bool,
    /**
     * if cell body is the primary block
     *
     */
    error: PropTypes.bool,
};

CellDesc.defaultProps = {
    primary: false,
    error: false,
};

export default CellDesc;
