import React from 'react';
import classNames from 'classnames';

/**
 * Agreement style checkbox
 *
 */
const Agreement = (props) => {
    const { className, children, id, ...others } = props;
    const cls = classNames({
        'qtui-agree': true,
        [className]: className
    });

    return (
        <label className={cls} htmlFor={id}>
            <input id={id} type="checkbox" className="qtui-agree__checkbox" {...others}/>
            <span className="qtui-agree__text">
                {children}
            </span>
        </label>
    );
};

export default Agreement;