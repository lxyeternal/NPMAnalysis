import React from 'react';
import classNames from 'classnames';

/**
 * qtui wrapper for checkbox
 *
 */
const Checkbox = (props) => {
    const { className, ...others } = props;
    const cls = classNames({
        'qtui-check': true,
        [className]: className
    });

    return (
        <div>
            <input className={cls} type="checkbox" {...others}/>
            <span className="qtui-icon-checked"></span>
        </div>
    );
};

export default Checkbox;