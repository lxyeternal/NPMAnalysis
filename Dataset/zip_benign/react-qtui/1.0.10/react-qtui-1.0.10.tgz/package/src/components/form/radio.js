import React from 'react';
import classNames from 'classnames';

/**
 * qtui wrapper for radio
 *
 */
const Radio = (props) => {
    const { className, ...others } = props;
    const cls = classNames({
        'qtui-check': true,
        [className]: className
    });

    return (
        <div>
            <input className={cls} type="radio" {...others}/>
            <span className="qtui-icon-checked"></span>
        </div>
    );
};

export default Radio;