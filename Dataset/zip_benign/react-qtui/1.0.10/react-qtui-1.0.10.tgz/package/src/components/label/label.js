import React from 'react';
import classNames from 'classnames';

/**
 * QtUI Label Wrapper
 *
 */
const Label = (props) => {
    const { className, ...others } = props;
    const cls = classNames({
        'qtui-label': true,
        [className]: className
    });

    return (
        <div>
            <label className={cls} {...others}/>
        </div>
    );
};

export default Label;