//1.0.0 components

import React from 'react';

/**
 * FlexItem Container
 *
 */
const Flex = (props) => (
    <div className="qtui-flex" {...props}>
        { props.children }
    </div>
);

export default Flex;