import React from 'react';
import classNames from 'classnames';
import deprecationWarning from '../../utils/deprecationWarning';

const deprecateValue = {
    'safe_success': 'safe-success',
    'safe_warn': 'safe-warn',
    'success_circle': 'success-circle',
    'success_no_circle': 'success-no-circle',
    'waiting_circle': 'waiting-circle',
    'info_circle': 'info-circle'
};

/**
 * QtUI Icons
 *
 */
class Icon extends React.Component {
    static propTypes = {
        /**
         * types of [qtui icons](https://github.com/qtui/qtui/wiki/Icon)
         *
         */
        value: React.PropTypes.string,
        /**
         * size of icon, options: small/large
         *
         */
        size: React.PropTypes.string
    };

    static defaultProps = {
        value: 'success',
        size: 'small'
    };

    render() {
        const {value, size, className, primary, ...others} = this.props;

        if (Object.keys(deprecateValue).indexOf(value) !== -1){
            deprecationWarning(`Icon ${value}`, `Icon ${deprecateValue[value]}`);
        }

        const cls = classNames({
            ['qtui-icon-' + value]: value !== 'loading',
            'qtui-icon_msg': size === 'large' && !primary,
            'qtui-icon_msg-primary': size === 'large' && primary,
            'qtui-loading': value === 'loading',
            [className]: className
        });

        return (
            <i {...others} className={cls}/>
        );
    }
}

export default Icon;