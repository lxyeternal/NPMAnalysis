import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

/**
 * Cell consist of `CellBody`, `CellHeader` and `CellFooter` for flexible reason
 *
 */
const Cell = (props) => {
    const { className, children, access, href, link, desc, component, htmlFor, ...others } = props;
    const DefaultComponent = href ? 'a' : htmlFor ? 'label' : 'div';
    var CellComponent = component ? component : DefaultComponent;

    const cls = classNames({
        'qtui-cell': true,
        'qtui-cell_access': access,
        'qtui-cell_link': link,
        'qtui-cell_desc': desc,
        [className]: className
    });

    return (
        <CellComponent
            className={cls}
            href={href}
            htmlFor={htmlFor}
            { ...others }
        >
            { children }
        </CellComponent>
    );
};

Cell.propTypes = {
    /**
     * if cell should have arrow or link
     *
     */
    access: PropTypes.bool,
    /**
     * if this cell body is link
     *
     */
    link: PropTypes.bool,
    /**
     * if this cell body has desc
     *
     */
    desc: PropTypes.bool,
    /**
     * pass in an component to replace Cell but apply same style
     *
     */
    component: PropTypes.func
};

Cell.defaultProps = {
    access: false,
    link: false,
    desc: false,
};

export default Cell;
