import React from 'react';
import classNames from 'classnames';

/**
 * Media Object, Typically use with `Panel` to display pictures and text, consists of `MediaBoxBody`, `MediaBoxDescription`, `MediaBoxHeader`
 *
 */
export default class MediaBox extends React.Component {
    static propTypes = {
        /**
         * The layout of media box, Options: appmsg/text/small_appmsg
         *
         */
        type: React.PropTypes.string
    };

    static defaultProps = {
        type: 'text'
    };

    render() {
        const {children, type, className, ...others} = this.props;
        const Component = this.props.href ? 'a' : 'div';
        const cls = classNames({
            'qtui-media-box': true,
            'qtui-media-box_appmsg': type === 'appmsg',
            'qtui-media-box_text': type === 'text',
            'qtui-media-box_small-appmsg': type === 'small_appmsg',
        }, className);

        return (
            <Component className={cls} {...others}>{children}</Component>
        );
    }
};