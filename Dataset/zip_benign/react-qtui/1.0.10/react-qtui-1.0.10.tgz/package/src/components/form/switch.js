import React from 'react';
import classNames from 'classnames';

/**
 * qtui switch style for checkbox
 *
 */
const Switch = (props) => {
    const { className, ...others } = props;
    const cls = classNames({
        'qtui-switch': true,
        [className]: className
    });

    return (
        <div>
            <input className={cls} type="checkbox" {...others}/>
            <span className="qtui-icon-checked"></span>
        </div>
    );
};

export default Switch;