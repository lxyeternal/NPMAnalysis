import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import './touch_fix.less';

/**
 * form wrapper for `Cell`
 *
 */
export default class FormCell extends Component {
    static propTypes = {
        /**
         * if cell use for vcode
         *
         */
        vcode: PropTypes.bool,
        /**
         * display warn style of cell
         *
         */
        warn: PropTypes.bool,
        /**
         * if cell use for radio
         *
         */
        radio: PropTypes.bool,
        /**
         * if cell use for checkbox
         *
         */
        checkbox: PropTypes.bool,
        /**
         * if cell use for switch checkbox
         *
         */
        'switch': PropTypes.bool,
        /**
         * if cell use for select
         *
         */
        select: PropTypes.bool,
        /**
         * if cell has desc
         *
         */
        desc: PropTypes.bool,
        /**
         * select position, options: before, after
         *
         */
        selectPos: PropTypes.string,
    };

    static defaultProps = {
        vcode: false,
        warn: false,
        radio: false,
        checkbox: false,
        select: false,
        'switch': false,
        desc: false,
        selectPos: undefined
    };

    render() {
        const {
          className, children,
          radio, checkbox, vcode, warn,
          select, selectPos, desc,
          ...others,
        } = this.props;
        const cellDomProps = Object.assign({}, others);
        delete cellDomProps.switch;
        const cls = classNames({
            'qtui-cell': true,
            'qtui-cell_vcode': vcode,
            'qtui-cell_warn': warn,
            'qtui-cell_switch': this.props.switch,
            'qtui-cell_select': select,
            'qtui-cell_select-before': selectPos === 'before',
            'qtui-cell_select-after': selectPos === 'after',
            'qtui-check__label': radio || checkbox,
            'qtui-cell_desc': desc,
            [className]: className
        });

        if (radio || checkbox) {
            return (
                <label className={cls} {...cellDomProps}>{children}</label>
            );
        } else {
            return (
                <div className={cls} {...cellDomProps}>{children}</div>
            );
        }
    }
};
