import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

/**
 * qtui wrapper for form
 *
 */
class Form extends Component {
    static propTypes = {
        /**
         * if this form is use for radios
         *
         */
        radio: PropTypes.bool,
        /**
         * if this form is use for checkbox
         *
         */
        checkbox: PropTypes.bool
    };

    static defaultProps = {
        radio: false,
        checkbox: false
    };

    render() {
        const { children, className, radio, checkbox, ...others } = this.props;
        const cls = classNames({
            'qtui-cells': true,
            'qtui-cells_form': !radio && !checkbox,
            'qtui-cells_radio': radio,
            'qtui-cells_checkbox': checkbox,
            [className]: className
        });

        return (
            <div className={cls} {...others}>{children}</div>
        );
    }
};


export default Form;
