export declare type TRconBaseRequestParams = {
    server: string;
    rconpassword: string;
    cmd: string;
    timeout?: number;
};
export declare function rconBasicRequest(params: TRconBaseRequestParams): Promise<string>;
