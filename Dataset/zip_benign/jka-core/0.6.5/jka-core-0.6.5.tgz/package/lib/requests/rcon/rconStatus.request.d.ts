import { TRconStatusBaseResponse } from "../../utils/parsers/rconStatus/rconStatusBase.parser";
import { TRconStatusJaproResponse } from "../../utils/parsers/rconStatus/rconStatusJapro.parser";
import { TRconStatusYbeproxyResponse } from "../../utils/parsers/rconStatus/rconStatusYbeproxy.parser";
import { TRconStatusOpenjkResponse } from "../../utils/parsers/rconStatus/rconStatusOpenjk.parser";
export declare type TRconStatusResponse = TRconStatusBaseResponse | TRconStatusYbeproxyResponse | TRconStatusOpenjkResponse | TRconStatusJaproResponse;
export declare function rconStatus(server: string, rconpassword: string, timeout?: number): Promise<TRconStatusResponse>;
