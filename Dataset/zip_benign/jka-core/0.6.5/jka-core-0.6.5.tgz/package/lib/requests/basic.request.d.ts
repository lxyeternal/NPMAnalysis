export declare type TBaseRequestParams = {
    server: string;
    request: string;
    timeout?: number;
};
/**
 *
 * @param params Object with keys:
 * request - request to the server,
 * ip - ip or domain name of the server
 * port - port (number 1-65534)
 * timeout - timer in secs after which request would be interrupted (min: 2, default: 10)
 * @returns string with server response or throws an error
 */
export declare const basicRequest: (params: TBaseRequestParams) => Promise<string>;
