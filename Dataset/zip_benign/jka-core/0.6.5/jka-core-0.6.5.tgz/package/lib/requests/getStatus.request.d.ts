import { TGetStatusSmartResponse } from "../utils/parsers/getStatus/getStatus.parser";
export declare function getStatusSmart(server: string, timeout?: number): Promise<TGetStatusSmartResponse>;
