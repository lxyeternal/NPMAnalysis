import { TGetStatusRawResponse } from "../utils/parsers/getStatus/getStatusRaw.parser";
export declare function getStatusRaw(server: string, timeout?: number): Promise<TGetStatusRawResponse>;
