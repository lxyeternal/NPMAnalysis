export declare function getPlayersNumRequest(server: string, timeout?: number): Promise<number>;
