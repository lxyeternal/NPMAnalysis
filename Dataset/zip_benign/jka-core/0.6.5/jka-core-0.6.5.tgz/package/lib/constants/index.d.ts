export declare enum EGametypes {
    FFA = "FFA",
    DUEL = "DUEL",
    POWER_DUEL = "POWER_DUEL",
    TFFA = "TFFA",
    CTF = "CTF",
    SIEGE = "SIEGE"
}
export declare enum EServerTypes {
    JAPRO = "JAPRO",
    YBEPROXY = "YBEPROXY",
    BASE = "BASE",
    OPENJK = "OPENJK"
}
export declare enum EGetStatusFields {
    SV_HOSTNAME = "sv_hostname",
    SV_MAXCLIENTS = "sv_maxclients",
    MAPNAME = "mapname",
    TIMELIMIT = "timelimit",
    FRAGLIMIT = "fraglimit",
    DUEL_FRAGLIMIT = "duel_fraglimit",
    G_GAMETYPE = "g_gametype",
    G_DEBUGMELEE = "g_debugmelee",
    G_MAX_GAME_CLIENTS = "g_maxGameClients",
    SV_PRIVATE_CLIENTS = "sv_privateClients",
    GAMENAME = "gamename",
    VERSION = "version",
    G_FORCEPOWERDISABLE = "g_forcepowerdisable",
    G_WEAPONDISABLE = "g_weapondisable",
    G_DUEL_WEAPON_DISABLE = "g_duelWeaponDisable",
    G_JEDI_VMERC = "g_jediVmerc",
    G_SIEGE_TEAM1 = "g_siegeTeam1",
    G_SIEGE_TEAM2 = "g_siegeTeam2",
    G_SIEGE_TEAM_SWITCH = "g_siegeTeamSwitch",
    G_SIEGE_RESPAWN = "g_siegeRespawn",
    G_STEPSLIDEFIX = "g_stepslidefix",
    G_SABERWALLDAMAGESCALE = "g_saberwalldamagescale",
    G_FORCEREGENTIME = "g_forceregentime",
    BG_FIGHTERALTCONTROL = "bg_fighteraltcontrol",
    SV_ALLOW_DOWNLOAD = "sv_allowDownload",
    SV_FLOOD_PROTECT = "sv_floodProtect",
    SV_MAX_PING = "sv_maxPing",
    SV_MIN_PING = "sv_minPing",
    SV_MAX_RATE = "sv_maxRate",
    G_NEEDPASS = "g_needpass",
    G_FORCE_BASED_TEAMS = "g_forceBasedTeams",
    G_MAX_FORCE_RANK = "g_maxForceRank",
    G_SABER_LOCKING = "g_saberLocking",
    G_PRIVATE_DUEL = "g_privateDuel",
    CAPTURELIMIT = "capturelimit",
    DMFLAGS = "dmflags",
    G_MAX_HOLOCRON_CARRY = "g_maxHolocronCarry",
    PROTOCOL = "protocol",
    BOT_MINPLAYERS = "bot_minplayers",
    G_NO_SPEC_MOVE = "g_noSpecMove",
    G_ALLOW_NPC = "g_allowNPC",
    G_SHOW_DUEL_HEALTHS = "g_showDuelHealths"
}
export declare const WEAPON_DISABLE_VALUES: string[];
export declare const FORCEPOWER_DISABLE_VALUES: string[];
export declare const DEFAULT_REQUEST_TIMEOUT = 10;
export declare const MIN_REQUEST_TIMEOUT = 2;
