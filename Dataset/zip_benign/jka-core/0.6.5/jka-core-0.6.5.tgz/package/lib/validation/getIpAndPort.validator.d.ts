export declare const errors: {
    incorrectFormatErrorMessage: string;
};
export declare function getIpAndPort(server: string): {
    ip: string;
    port: number;
};
