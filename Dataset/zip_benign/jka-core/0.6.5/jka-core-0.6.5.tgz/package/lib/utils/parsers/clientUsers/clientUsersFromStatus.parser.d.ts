export declare type TGetStatusClientUser = {
    name: string;
    ping: string;
    score: string;
};
export declare function parseClientUsersFromStatus(strToParse: string): TGetStatusClientUser[];
