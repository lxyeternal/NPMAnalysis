/**
 *
 * @param promise Promise to execute
 * @param timeout Time in secs after which execution is interrupted (default: 1)
 * @param errorMessage Message for error in case of timeout
 * @returns promise or throws error
 */
export declare function executeOrTimeout<T>(promise: Promise<T>, timeout?: number, errorMessage?: string): Promise<Awaited<T>>;
export declare function snakeToCamel(str: string): string;
export declare function kebabToCamel(str: string): string;
export declare const parseIntOtherwiseZero: (str: string) => number;
export declare const parseIntOtherwiseNull: (str: string) => number | null;
export declare const parseFloatOtherwiseNull: (str: string) => number | null;
export declare const parseBooleanOtherwiseNull: (str: string) => boolean | null;
