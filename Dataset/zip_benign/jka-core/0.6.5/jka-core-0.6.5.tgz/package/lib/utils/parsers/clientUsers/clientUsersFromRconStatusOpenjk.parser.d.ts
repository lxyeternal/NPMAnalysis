export declare type TRconStatusOpenjkClientUser = {
    id: number;
    name: string;
    address: string | null;
    isBot: boolean;
    score: number;
    ping: number | null;
    rate: number;
};
export declare function clientUsersFromRconStatusOpenjk(clientsInfoStrArray: string[]): TRconStatusOpenjkClientUser[];
