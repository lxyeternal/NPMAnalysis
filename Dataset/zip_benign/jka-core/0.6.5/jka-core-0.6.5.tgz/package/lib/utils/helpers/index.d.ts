export { removeColorCodes } from './removeColorCodes';
