export declare enum EGetStatusParseValueType {
    STRING = "string",
    NUMBER = "number",
    GAMETYPE = "gametype"
}
export declare function parseCvarValueFromStatus(strToParse: string, cvarName: string, type: EGetStatusParseValueType): string | number | null;
