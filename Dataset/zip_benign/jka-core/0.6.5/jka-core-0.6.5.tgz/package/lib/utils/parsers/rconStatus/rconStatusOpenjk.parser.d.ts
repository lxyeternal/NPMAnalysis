import { EGametypes, EServerTypes } from "../../../index";
import { TRconStatusOpenjkClientUser } from "../clientUsers/clientUsersFromRconStatusOpenjk.parser";
export declare type TRconStatusOpenjkResponse = {
    type: EServerTypes.OPENJK;
    hostname: string;
    ip: string;
    port: string;
    os: string;
    version: string;
    protocol: string;
    gamename: string;
    map: string;
    uptime: string;
    gametype: EGametypes;
    players: TRconStatusOpenjkClientUser[];
};
export declare function rconStatusOpenjkParser(strToParse: string): TRconStatusOpenjkResponse;
