import { TRconStatusYbeproxyClientUser } from "./clientUsersFromRconStatusYbeproxy.parser";
export declare type TRconStatusJaproClientUser = TRconStatusYbeproxyClientUser;
export declare function clientUsersFromRconStatusJapro(clientsInfoStrArray: string[]): TRconStatusJaproClientUser[];
