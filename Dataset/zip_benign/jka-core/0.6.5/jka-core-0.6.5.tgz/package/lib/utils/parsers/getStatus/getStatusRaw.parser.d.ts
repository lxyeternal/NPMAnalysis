import { EGetStatusFields } from "../../../index";
import { TGetStatusClientUser } from "../clientUsers/clientUsersFromStatus.parser";
export declare type TGetStatusRawResponse = {
    cvars: Record<EGetStatusFields, string>;
    clients: TGetStatusClientUser[];
};
export declare function getStatusRawParser(strToParse: string): TGetStatusRawResponse;
