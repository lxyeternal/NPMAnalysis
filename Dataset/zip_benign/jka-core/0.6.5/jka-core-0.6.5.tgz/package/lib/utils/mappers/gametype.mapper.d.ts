import { EGametypes } from "../../constants";
export declare const gametypeNumToNamesMapper: (gametypeNum: string) => EGametypes;
