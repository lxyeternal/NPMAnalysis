import { EServerTypes } from "../../../index";
import { TRconStatusBaseClientUser } from "../clientUsers/clientUsersFromRconStatusBase.parser";
export declare type TRconStatusBaseResponse = {
    type: EServerTypes.BASE;
    map: string;
    players: TRconStatusBaseClientUser[];
};
export declare function rconStatusBaseParser(strToParse: string): TRconStatusBaseResponse;
