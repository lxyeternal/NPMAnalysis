import { EGametypes, EServerTypes } from "../../../index";
import { TRconStatusYbeproxyClientUser } from "../clientUsers/clientUsersFromRconStatusYbeproxy.parser";
export declare type TRconStatusYbeproxyResponse = {
    type: EServerTypes.YBEPROXY;
    hostname: string;
    ip: string;
    port: string;
    os: string;
    version: string;
    protocol: string;
    gamename: string;
    map: string;
    gametype: EGametypes;
    players: TRconStatusYbeproxyClientUser[];
};
export declare function rconStatusYbeproxyParser(strToParse: string): TRconStatusYbeproxyResponse;
