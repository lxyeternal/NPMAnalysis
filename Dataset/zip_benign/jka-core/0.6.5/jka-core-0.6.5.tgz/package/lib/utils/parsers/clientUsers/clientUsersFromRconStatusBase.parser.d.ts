export declare type TRconStatusBaseClientUser = {
    id: number;
    score: number | null;
    ping: number | null;
    name: string | null;
    lastmsg: number | null;
    address: string | null;
    isBot: boolean;
    qport: number | null;
    rate: number | null;
};
export declare function clientUsersFromRconStatusBase(clientsInfoStrArray: string[]): TRconStatusBaseClientUser[];
