export declare const removeColorCodes: (str: string) => string;
