export declare class Bitfield {
    private _bits;
    private _keys;
    constructor(num: number, size: number, keys: string[]);
    get decimal(): number;
    get binary(): string;
    get list(): object;
    /**
     * Sets key of bitfield to specific parameter
     * @param key The key which should be set
     * @param value The value which should be used for setting up
     * @returns True if succeed, false if there is no such key
     */
    set(key: string, value: boolean): boolean;
    /**
     * Gets the current value of the key of the bitfield
     * @param key The key which should be taken
     * @returns The value of the key or null, if there is no such key
     */
    get(key: string): boolean | null;
}
