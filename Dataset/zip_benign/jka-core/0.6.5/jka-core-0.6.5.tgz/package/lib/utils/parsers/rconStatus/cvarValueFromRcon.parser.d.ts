/**
 * Parses cvarName from rcon response
 * @param str String with rcon response
 * @param cvarName cvarName which needs to be parsed
 * @returns value of the cvarName
 */
export declare function getCvarValue(str: string, cvarName: string): string;
