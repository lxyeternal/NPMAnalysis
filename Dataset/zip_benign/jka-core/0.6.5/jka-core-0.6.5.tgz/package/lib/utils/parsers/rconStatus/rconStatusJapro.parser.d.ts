import { EGametypes, EServerTypes } from "../../../index";
import { TRconStatusJaproClientUser } from "../clientUsers/clientUsersFromRconStatusJapro.parser";
export declare type TRconStatusJaproResponse = {
    type: EServerTypes.JAPRO;
    hostname: string;
    ip: string;
    port: string;
    os: string;
    version: string;
    protocol: string;
    gamename: string;
    map: string;
    gametype: EGametypes;
    uptime: string;
    players: TRconStatusJaproClientUser[];
};
export declare function rconStatusJaproParser(strToParse: string): TRconStatusJaproResponse;
