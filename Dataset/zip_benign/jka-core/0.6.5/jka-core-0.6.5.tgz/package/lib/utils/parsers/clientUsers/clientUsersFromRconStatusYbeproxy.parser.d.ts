export declare type TRconStatusYbeproxyClientUser = {
    id: number;
    name: string;
    address: string | null;
    isBot: boolean;
    score: number;
    ping: number | null;
    rate: number;
};
export declare function clientUsersFromRconStatusYbeproxy(clientsInfoStrArray: string[]): TRconStatusYbeproxyClientUser[];
