# Database Manager Microfrontend

Digital Enabler Database Manager Microfrontend

### Digital Enabler Database Manager Microfrontend

The Database Manager microfrontend shows a list of databases created using the Database Manager backend and enables the user to create or delete new databases.

It uses direct Keycloak authentication which is configurable through the sidebar microfrontend.

## Pre-requisites
Before you continue you need to

- have [NPM](https://www.npmjs.com/) installed
- have [NodeJS](https://nodejs.org/) installed
- have [VueJS](https://v2.vuejs.org/v2/guide/) and [Vue-CLI](https://cli.vuejs.org/guide/installation.html) installed
- have a [GitHub](https://github.com/) account
- use VisualStudio Code or IntelliJ Idea as your development IDE

## Project management

### Installation

Open a **Terminal** window in the project folder and go inside the app folder, then launch the command:

```
npm install
```

> NOTE: When install finished, do not care about the warnings on the versions and vulnerability problems reported, and DO NOT launch the `npm audit fix` or `npm audit fix –force commands`

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

> NOTE: Alternatively to the command indicated above you can use the VueUI browser interface

## Configs file

To function properly, it is necessary to have a database-list-config.json file with following fields:

```json
{
  "mf": "Database List",
  "api": "https://[generic_api_location]/api/v1/",
  "mapMarkerScale": 0.4, // Optional, default value provided
  "mapMarkerSource": "https://assets.website-files.com/6262b3a41e132da7361cba0c/6262b3a41e132d62241cbc22_icons8-location-100.png" // Optional, default value provided
}
```