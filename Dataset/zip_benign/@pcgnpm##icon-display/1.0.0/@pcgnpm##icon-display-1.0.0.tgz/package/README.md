<!-- @format -->

#icon-display

## Usage

Default icon
<IconDisplay
metricValue={5454555}
metricLabel="Out-of-Stocks"
metricType="currency"
iconComponent={() => {
return (
<FontAwesome5Icon
name="box"
size={30}
color="#fff"
style={{ opacity: 0.5, paddingTop: 14, position: "absolute" }}
/>
);
}}
/>

Store level icon
<IconDisplay
metricValue={5454555}
metricLabel="Out-of-Stocks"
metricType="currency"
iconComponent={() => {
return (
<FontAwesomeIcon
name="dollar"
size={30}
color="#fff"
style={{ opacity: 0.5, paddingTop: 14, position: "absolute" }}
/>
);
}}
/>
