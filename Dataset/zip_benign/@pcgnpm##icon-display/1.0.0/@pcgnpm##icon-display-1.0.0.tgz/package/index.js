/** @format */

import React, { useState, useEffect } from "react";
import { StyleSheet, View, Text } from "react-native";

import AnimateNumber from "@pcgnpm/rn-animate-number";

const IconDisplay = ({
  metricValue,
  metricType,
  metricLabel,
  component: Component,
  disableAnimation = false,
  iconComponent: IconComponent,
  iconSize = 60,
}) => {
  return (
    <>
      <View style={styles.mainContainer}>
        <View style={{ flex: 1 }}>
          {Component ? (
            <Component />
          ) : (
            <>
              <Text style={styles.smallText}>{metricLabel}</Text>
            </>
          )}
        </View>
        <View
          style={{
            justifyContent: "flex-start",
            alignItems: "center",
            opacity: 1,
          }}
        >
          <View
            style={{
              backgroundColor: "grey",
              width: iconSize,
              height: iconSize,
              borderRadius: iconSize / 2,
              justifyContent: "center",
              alignItems: "center",
              opacity: 0.1,
            }}
          ></View>
          <IconComponent />
          <Text style={styles.dollarIconText}>
            <AnimateNumber
              disable={disableAnimation}
              value={metricValue}
              type={metricType}
            />
          </Text>
        </View>
      </View>
    </>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flexDirection: "column",
    justifyContent: "flex-start",
    width: "33%",
  },
  smallText: {
    fontWeight: "400",
    fontSize: 12,
    textAlign: "center",
  },
  dollarIconText: {
    position: "absolute",
    color: "black",
    fontWeight: "800",
    fontSize: 16,
    minWidth: 100,
    paddingTop: 19,
    alignSelf: "center",
    textAlign: "center",
  },
});

export default IconDisplay;
