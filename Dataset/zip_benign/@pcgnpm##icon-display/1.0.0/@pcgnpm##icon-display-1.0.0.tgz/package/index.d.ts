/** @format */

declare module "icon-display";
