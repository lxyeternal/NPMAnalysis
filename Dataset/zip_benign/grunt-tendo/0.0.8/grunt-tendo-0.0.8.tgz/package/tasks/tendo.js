module.exports = function (grunt) {
    var tendo = require('tendo');

    grunt.registerMultiTask('tendo', 'Upload files using tendo', function () {
        var options = this.options({
            executable: tendo.getPathToTendo(),  // the path to grunt executable (can be overridden)
            login: {},          // login credentials:  TENTENGW, TENTENUID, TENTENPW  or any other args supportewd via env variables
            table: 'default.lonely',          // the table to execute against
            args: '',           // additional tendo cmd line args such as -K -y etc.
            logTenDoCmd: false, // log the full tendo command to the console
            logResults: false,  // log any query results to the console
            src: [],            // any standard grunt file matching patterns
            inlineQuery: null,   // an inline query to run (it does not use a file)
            resultsAsJson: false  // transform the results into json
        }, this.data);

        if (!this.data.src && !options.inlineQuery)
            return grunt.fail.fatal("Requires 'src' or 'inlineQuery'");

        if (this.data.src && options.inlineQuery)
            return grunt.fail.fatal("Cannot specify both 'src' or 'inlineQuery'");

        var files = (this.data.src) ? grunt.file.expand(this.data.src).map(tendo.asFileParam) : [];

        if (options.inlineQuery)
            files = [options.inlineQuery];

        var done = this.async();
        tendo.execute(options, files, function (status, results) {
            if (status === false) {
                grunt.fail.fatal(results);
                return done(false);
            }

            if (options.logResults === true)
                grunt.log.writeln(results);

            done();
        });
    });
};
