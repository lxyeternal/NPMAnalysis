# grunt-tendo v0.0.0 

> Execute tendo commands



## Getting Started

If you haven't used [Grunt](http://gruntjs.com/) before, be sure to check out the [Getting Started](http://gruntjs.com/getting-started) guide, as it explains how to create a [Gruntfile](http://gruntjs.com/sample-gruntfile) as well as install and use Grunt plugins. Once you're familiar with that process, you may install this plugin with this command:

```shell
npm install grunt-tendo --save-dev
```

Once the plugin has been installed, it may be enabled inside your Gruntfile with this line of JavaScript:

```js
grunt.loadNpmTasks('grunt-tendo');
```

*This plugin was designed to work with Grunt 0.4.x. If you're still using grunt v0.3.x it's strongly recommended that [you upgrade](http://gruntjs.com/upgrading-from-0.3-to-0.4), but in case you can't please use [v0.3.2](https://github.com/gruntjs/grunt-contrib-clean/tree/grunt-0.3-stable).*



## tendo task
_Run this task with the `grunt tendo` command._

Task targets, files and options may be specified according to the grunt [Configuring tasks](http://gruntjs.com/configuring-tasks) guide.

### Options

#### executable
Type: `String`  
Default: `Calls tendo.getPathToTendo`

This overrides the default value for the location of the tendo executable.

#### login
Type: `Object`  
Default: `none`

An object containing any valid login credentials based on tendo environment variable names.
[TENTENGW, TENTENUID, TENTENPW, etc]

#### table
Type: `String`  
Default: `default.lonely`

The table to execute against.

#### args
Type: `String`  
Default: `none`

Additional command line args to pass to the tendo executable.

#### logTenDoCmd
Type: `Boolean`  
Default: `false`

Log the full command (including all args) used to execute each tendo cmd.

#### logResults
Type: `Boolean`  
Default: `false`

Log the results to executed commands (useful to see query results).  

#### src
Type: `Array[String]`  
Default: `none`

The src files (queries, quickapps, etc) to execute. Files and options may be specified according to the grunt [Configuring tasks](http://gruntjs.com/configuring-tasks) guide.  

#### inlineQuery
Type: `String`  
Default: `none`

an inline query to run (it does not use a file).   

### Usage Examples

TODO