# Welcome to  bogofunctions

**This package have 3 different functions:**

1st: hezka()-This function basically solves numbers for us strongly, holding can be negative or positive.

2nd:Qurdratic_qeuation()-This function basically solves a quadratic equation.

3rd:Mortgage()-This function calculates your monthly payments of a mortgage you have taken according to the size of the mortgage, its period and the percentage of interest.

# How to install
npm install bogofunctions

## Usage
**1st function:**
var  ng = require("bogofunctions");
console.log(ng.hezka(num1, num2));
*explanation:*
Num1 is the number you want to increase by a power and num2 is the power itself. 
so for example console.log(ng.hezka(5, 2));
the function will return 25.

**2nd function:**
var  aa = require("bogofunctions");
console.log(aa.Qurdratic_qeuation(a, b, c));
*explanation:*
for example if you have 1x**2+4x-12c=0
so a=1, b=4, c= -12
so you go to the function and solve it like this:
console.log(aa.Qurdratic_qeuation(1, 4, -12));
 the function will return x1=2 , x2= -6.
 **note:** a cannot be equal to 0 in this function, a must be =! 0 !! also if there is a negative number in the sqrt the function will return that there is no solution for this equation.

**3rd function:**
var  bb = require("bogofunctions");
console.log(bb.Mortgage(pv, n, i));
*explanation:*
for example you took 700k Mortgage for the next 20 years by 0.5% per month. so what you have to do, is to insert pv as 700,000, n as 20 and i as 0.5, the function change by itself years to months and the 0.5% to a number by doing 0.5/100.
so you go to the function and solve it like this:
console.log(bb.Mortgage(700000, 20, 0.5));
the function will return 5015.017409347209.

