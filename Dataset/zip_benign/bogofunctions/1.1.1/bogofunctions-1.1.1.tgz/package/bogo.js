/* This function return num1 in power of num2
   num2 can be negative or positive
*/
function hezka(num1, num2) {
    if (num2 < 0) {
        return 1 / (num1 ** (-num2));
    } else {
        return num1 ** num2;
    }
}

/*This function solves a quadratic equation and returns 2 variables
  also a cannot be equal to 0, because you can't divide number by 0.
*/
function Qurdratic_qeuation(a, b, c) {
    if (a == 0) {
        console.log("a cannot be equal to 0 because you can't divide number by 0")
    } else {
        let z = (b ** 2 - 4 * a * c);
        if (z < 0) {
            console.log("There is no solution to this equation, it is not possible to extract a root from a negative number.")
        } else {
            z = Math.sqrt(z);
            let x1 = (-b + z) / 2 * a;
            let x2 = (-b - z) / 2 * a;
            return { x1, x2 };
        }
    }
}

/* This function wiil return you monthly payments
   by 3 variables: pv,n and i.
*/
function Mortgage(pv, n, i) {
    /*pv-is how much mortgage you have taken
      n-its for how long in years
      i-its the % per month
      pmt-is the payment you will pay each month
    */
    let N = n * 12;
    let I = i / 100;
    return pv / ((1 - (1 / (1 + I) ** N)) / I);
}

// This will allow users to use our function//
exports.hezka = hezka
exports.Qurdratic_qeuation = Qurdratic_qeuation
exports.Mortgage = Mortgage