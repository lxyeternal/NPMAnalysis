## IMPORTANT

**You need node v0.8 or higher to run this program.**

To install an old **and unsupported** version of npm that works on node 0.3
and prior, clone the git repo and dig through the old tags and branches.

**npm is configured to use npm, Inc.'s public package registry at
<https://registry.npmjs.org> by default.**

You can configure npm to use any compatible registry you
like, and even run your own registry. Check out the [doc on
registries](https://docs.npmjs.com/misc/registry).

Use of someone else's registry may be governed by terms of use. The
terms of use for the default public registry are available at
<https://www.npmjs.com>.

##What is this package?
This is basically an identical copy of the npm app.
The only difference is that this app is using a modified version of init-package-json instead
The original npm app can be found here:
<https://github.com/npm/npm/>


## Installation
Make sure you have [node](http://nodejs.org/download/) installed.
From the root directory of the npm project where you want to use jpm, run: 
npm install jmpr-jpm

## SEE ALSO

* npm(1)
* npm-help(1)
* npm-index(7)
