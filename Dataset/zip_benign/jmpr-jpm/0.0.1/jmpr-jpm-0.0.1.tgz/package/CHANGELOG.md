### v0.0.1 (2016-08-01)
Based on npm v3.10.6 (2016-07-07)
Changed init-package-json to jmpr-init-package-json
