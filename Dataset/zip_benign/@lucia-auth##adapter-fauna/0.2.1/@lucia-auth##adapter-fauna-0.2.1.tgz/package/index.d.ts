import { type Client } from "faunadb";
import type { Adapter, AdapterFunction } from "lucia-auth";
type AdapterConfig = {
    userTable?: string;
    sessionTable?: string;
};
declare const adapter: (faunaClient: Client, config?: AdapterConfig) => AdapterFunction<Adapter>;
export default adapter;
