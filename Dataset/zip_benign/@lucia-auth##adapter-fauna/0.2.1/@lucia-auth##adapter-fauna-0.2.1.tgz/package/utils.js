export const convertUserResponse = (res) => {
    const { id, hashed_password, provider_id, ...attributes } = res.data;
    return {
        id,
        provider_id,
        hashed_password: hashed_password ?? null,
        ...attributes
    };
};
export const convertMultipleUsersResponse = (res) => {
    const data = [];
    res.data.forEach((row) => {
        const { id, hashed_password, provider_id, ...attributes } = row.data;
        data.push({
            id,
            provider_id,
            hashed_password: hashed_password ?? null,
            ...attributes
        });
    });
    return data;
};
export const convertMultipleSessionResponse = (res) => {
    const data = [];
    res.data.forEach((row) => {
        const { id, user_id, idle_expires, expires, ...attributes } = row.data;
        data.push({
            id,
            user_id,
            idle_expires,
            expires,
            ...attributes
        });
    });
    return data;
};
