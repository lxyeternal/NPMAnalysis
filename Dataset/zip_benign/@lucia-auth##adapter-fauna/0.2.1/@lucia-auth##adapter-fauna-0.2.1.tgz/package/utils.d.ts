import { SessionSchema, UserSchema } from "lucia-auth";
export type MultiResponse<T> = {
    data: {
        data: T;
    }[];
};
export type SingleResponse<T> = {
    data: T;
};
export type FaunaUserSchema = {
    id: string;
    hashed_password?: string;
    provider_id: string;
    [k: string]: any;
};
export type FaunaSessionSchema = {
    id: string;
    user_id: string;
    expires: number;
    idle_expires: number;
};
export declare const convertUserResponse: (res: SingleResponse<FaunaUserSchema>) => UserSchema;
export declare const convertMultipleUsersResponse: (res: MultiResponse<FaunaUserSchema>) => UserSchema[];
export declare const convertMultipleSessionResponse: (res: MultiResponse<FaunaSessionSchema>) => SessionSchema[];
