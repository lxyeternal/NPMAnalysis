export default MarkerCanvasWrapper;
declare function MarkerCanvasWrapper(props: any): any;
