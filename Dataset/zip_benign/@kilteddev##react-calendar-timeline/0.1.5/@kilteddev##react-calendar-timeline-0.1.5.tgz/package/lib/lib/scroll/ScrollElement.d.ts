export default ScrollElement;
declare class ScrollElement {
    static propTypes: {
        children: any;
        width: any;
        height: any;
        traditionalZoom: any;
        scrollRef: any;
        isInteractingWithItem: any;
        onZoom: any;
        onWheelZoom: any;
        onScroll: any;
    };
    state: {
        isDragging: boolean;
    };
    /**
     * needed to handle scrolling with trackpad
     */
    handleScroll: () => void;
    refHandler: (el: any) => void;
    scrollComponent: any;
    handleWheel: (e: any) => void;
    handleMouseDown: (e: any) => void;
    dragStartPosition: any;
    dragLastPosition: any;
    handleMouseMove: (e: any) => void;
    handleMouseUp: () => void;
    handleMouseLeave: () => void;
    handleTouchStart: (e: any) => void;
    lastTouchDistance: number;
    singleTouchStart: {
        x: any;
        y: any;
        screenY: number;
    };
    lastSingleTouch: {
        x: any;
        y: any;
        screenY: number;
    } | {
        x: any;
        y: any;
        screenY?: undefined;
    };
    handleTouchMove: (e: any) => void;
    handleTouchEnd: () => void;
    componentWillUnmount(): void;
    render(): any;
}
