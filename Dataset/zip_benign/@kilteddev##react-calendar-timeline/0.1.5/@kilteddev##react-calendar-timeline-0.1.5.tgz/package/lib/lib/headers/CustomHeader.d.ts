export class CustomHeader {
    static propTypes: {
        children: any;
        unit: any;
        timeSteps: any;
        visibleTimeStart: any;
        visibleTimeEnd: any;
        canvasTimeStart: any;
        canvasTimeEnd: any;
        canvasWidth: any;
        showPeriod: any;
        headerData: any;
        getLeftOffsetFromDate: any;
        height: any;
    };
    static getDerivedStateFromProps(props: any, state: any): {
        intervals: any[];
    };
    constructor(props: any);
    state: {
        intervals: any[];
    };
    shouldComponentUpdate(nextProps: any): boolean;
    getRootProps: (props?: {}) => {
        style: any;
    };
    getIntervalProps: (props?: {}) => {
        style: any;
        key: string;
    };
    getIntervalStyle: ({ left, labelWidth, style }: {
        left: any;
        labelWidth: any;
        style: any;
    }) => any;
    getStateAndHelpers: () => {
        timelineContext: {
            timelineWidth: any;
            visibleTimeStart: any;
            visibleTimeEnd: any;
            canvasTimeStart: any;
            canvasTimeEnd: any;
        };
        headerContext: {
            unit: any;
            intervals: any[];
        };
        getRootProps: (props?: {}) => {
            style: any;
        };
        getIntervalProps: (props?: {}) => {
            style: any;
            key: string;
        };
        showPeriod: any;
        data: any;
    };
    render(): any;
}
export default CustomHeaderWrapper;
declare function CustomHeaderWrapper({ children, unit, headerData, height }: {
    children: any;
    unit: any;
    headerData: any;
    height: any;
}): any;
declare namespace CustomHeaderWrapper {
    namespace propTypes {
        const children: any;
        const unit: any;
        const headerData: any;
        const height: any;
    }
    namespace defaultProps {
        const height_1: number;
        export { height_1 as height };
    }
}
