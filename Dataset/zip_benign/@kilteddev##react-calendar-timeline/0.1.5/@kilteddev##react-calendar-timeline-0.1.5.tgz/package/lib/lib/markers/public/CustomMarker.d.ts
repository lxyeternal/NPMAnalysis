export default CustomMarkerWrapper;
declare function CustomMarkerWrapper(props: any): any;
declare namespace CustomMarkerWrapper {
    const displayName: string;
}
