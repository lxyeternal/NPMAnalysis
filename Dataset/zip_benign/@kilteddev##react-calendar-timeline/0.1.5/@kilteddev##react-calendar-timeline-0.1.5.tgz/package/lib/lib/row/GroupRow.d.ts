export default GroupRow;
declare class GroupRow {
    static propTypes: {
        onClick: any;
        onDoubleClick: any;
        onContextMenu: any;
        isEvenRow: any;
        style: any;
        clickTolerance: any;
        group: any;
        horizontalLineClassNamesForGroup: any;
    };
    render(): any;
}
