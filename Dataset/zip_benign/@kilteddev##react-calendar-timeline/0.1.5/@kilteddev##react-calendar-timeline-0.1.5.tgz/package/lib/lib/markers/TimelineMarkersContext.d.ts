export class TimelineMarkersProvider {
    static propTypes: {
        children: any;
    };
    handleSubscribeToMarker: (newMarker: any) => {
        unsubscribe: () => void;
        getMarker: () => any;
    };
    handleUpdateMarker: (updateMarker: any) => void;
    state: {
        markers: any[];
        subscribeMarker: (newMarker: any) => {
            unsubscribe: () => void;
            getMarker: () => any;
        };
        updateMarker: (updateMarker: any) => void;
    };
    render(): any;
}
export const TimelineMarkersConsumer: any;
