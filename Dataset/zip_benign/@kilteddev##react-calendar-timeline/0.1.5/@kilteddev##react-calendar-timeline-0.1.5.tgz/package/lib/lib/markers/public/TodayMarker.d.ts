export default TodayMarkerWrapper;
declare function TodayMarkerWrapper(props: any): any;
declare namespace TodayMarkerWrapper {
    const displayName: string;
}
