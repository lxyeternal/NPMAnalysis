export default ColumnsWrapper;
declare function ColumnsWrapper({ ...props }: {
    [x: string]: any;
}): any;
declare namespace ColumnsWrapper {
    namespace defaultProps {
        const canvasTimeStart: any;
        const canvasTimeEnd: any;
        const canvasWidth: any;
        const lineCount: any;
        const minUnit: any;
        const timeSteps: any;
        const height: any;
        const verticalLineClassNamesForTime: any;
    }
}
