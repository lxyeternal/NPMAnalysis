export default TimelineHeadersWrapper;
declare function TimelineHeadersWrapper({ children, style, className, calendarHeaderStyle, calendarHeaderClassName }: {
    children: any;
    style: any;
    className: any;
    calendarHeaderStyle: any;
    calendarHeaderClassName: any;
}): any;
declare namespace TimelineHeadersWrapper {
    namespace propTypes {
        const style: any;
        const children: any;
        const className: any;
        const calendarHeaderStyle: any;
        const calendarHeaderClassName: any;
    }
    const secretKey: string;
}
