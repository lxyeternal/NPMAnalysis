export default PreventClickOnDrag;
declare class PreventClickOnDrag {
    static propTypes: {
        children: any;
        onClick: any;
        clickTolerance: any;
    };
    handleMouseDown: (evt: any) => void;
    originClickX: any;
    handleMouseUp: (evt: any) => void;
    cancelClick: boolean;
    handleClick: (evt: any) => void;
    render(): any;
}
