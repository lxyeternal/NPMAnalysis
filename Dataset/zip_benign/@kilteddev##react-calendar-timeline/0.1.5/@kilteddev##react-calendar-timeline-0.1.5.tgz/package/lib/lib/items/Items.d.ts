export default class Items {
    static propTypes: {
        groups: any;
        items: any;
        canvasTimeStart: any;
        canvasTimeEnd: any;
        canvasWidth: any;
        dragSnap: any;
        minResizeWidth: any;
        selectedItem: any;
        canChangeGroup: any;
        canMove: any;
        canResize: any;
        canSelect: any;
        keys: any;
        moveResizeValidator: any;
        itemSelect: any;
        itemDrag: any;
        itemDrop: any;
        itemResizing: any;
        itemResized: any;
        onItemDoubleClick: any;
        onItemContextMenu: any;
        itemRenderer: any;
        selected: any;
        dimensionItems: any;
        groupTops: any;
        useResizeHandle: any;
        scrollRef: any;
    };
    static defaultProps: {
        selected: any[];
    };
    shouldComponentUpdate(nextProps: any): boolean;
    isSelected(item: any, itemIdKey: any): any;
    getVisibleItems(canvasTimeStart: any, canvasTimeEnd: any): any;
    render(): any;
}
