export const MarkerCanvasProvider: any;
export const MarkerCanvasConsumer: any;
