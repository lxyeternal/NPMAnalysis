export default CustomMarker;
/**
 * CustomMarker that is placed based on passed in date prop
 */
declare class CustomMarker {
    static propTypes: {
        getLeftOffsetFromDate: any;
        renderer: any;
        date: any;
    };
    static defaultProps: {
        renderer: ({ styles }: {
            styles: any;
        }) => any;
    };
    render(): any;
}
