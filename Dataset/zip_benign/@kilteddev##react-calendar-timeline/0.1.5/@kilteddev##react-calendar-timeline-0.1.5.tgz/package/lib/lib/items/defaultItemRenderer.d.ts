export function defaultItemRenderer({ item, itemContext, getItemProps, getResizeProps }: {
    item: any;
    itemContext: any;
    getItemProps: any;
    getResizeProps: any;
}): any;
export namespace defaultItemRenderer {
    namespace propTypes {
        const item: any;
        const itemContext: any;
        const getItemProps: any;
        const getResizeProps: any;
    }
}
