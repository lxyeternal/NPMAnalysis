export default class Item {
    static propTypes: {
        canvasTimeStart: any;
        canvasTimeEnd: any;
        canvasWidth: any;
        order: any;
        dragSnap: any;
        minResizeWidth: any;
        selected: any;
        canChangeGroup: any;
        canMove: any;
        canResizeLeft: any;
        canResizeRight: any;
        keys: any;
        item: any;
        onSelect: any;
        onDrag: any;
        onDrop: any;
        onResizing: any;
        onResized: any;
        onContextMenu: any;
        itemRenderer: any;
        itemProps: any;
        canSelect: any;
        dimensions: any;
        groupTops: any;
        useResizeHandle: any;
        moveResizeValidator: any;
        onItemDoubleClick: any;
        scrollRef: any;
    };
    static defaultProps: {
        selected: boolean;
        itemRenderer: {
            ({ item, itemContext, getItemProps, getResizeProps }: {
                item: any;
                itemContext: any;
                getItemProps: any;
                getResizeProps: any;
            }): any;
            propTypes: {
                item: any;
                itemContext: any;
                getItemProps: any;
                getResizeProps: any;
            };
        };
    };
    static contextTypes: {
        getTimelineContext: any;
    };
    constructor(props: any);
    state: {
        interactMounted: boolean;
        dragging: any;
        dragStart: any;
        preDragPosition: any;
        dragTime: any;
        dragGroupDelta: any;
        resizing: any;
        resizeEdge: any;
        resizeStart: any;
        resizeTime: any;
    };
    shouldComponentUpdate(nextProps: any, nextState: any): boolean;
    cacheDataFromProps(props: any): void;
    itemId: any;
    itemTitle: any;
    itemDivTitle: any;
    itemTimeStart: any;
    itemTimeEnd: any;
    getTimeRatio(): number;
    dragTimeSnap(dragTime: any, considerOffset: any): any;
    resizeTimeSnap(dragTime: any): any;
    dragTime(e: any): any;
    timeFor(e: any): any;
    dragGroupDelta(e: any): number;
    resizeTimeDelta(e: any, resizeEdge: any): any;
    mountInteract(): void;
    canResizeLeft(props?: any): boolean;
    canResizeRight(props?: any): boolean;
    canMove(props?: any): boolean;
    componentDidUpdate(prevProps: any): void;
    onMouseDown: (e: any) => void;
    startedClicking: boolean;
    onMouseUp: (e: any) => void;
    onTouchStart: (e: any) => void;
    startedTouching: boolean;
    onTouchEnd: (e: any) => void;
    handleDoubleClick: (e: any) => void;
    handleContextMenu: (e: any) => void;
    actualClick(e: any, clickType: any): void;
    getItemRef: (el: any) => any;
    item: any;
    getDragLeftRef: (el: any) => any;
    dragLeft: any;
    getDragRightRef: (el: any) => any;
    dragRight: any;
    getItemProps: (props?: {}) => {
        key: any;
        ref: (el: any) => any;
        title: any;
        className: string;
        onMouseDown: (event: any, ...args: any[]) => void;
        onMouseUp: (event: any, ...args: any[]) => void;
        onTouchStart: (event: any, ...args: any[]) => void;
        onTouchEnd: (event: any, ...args: any[]) => void;
        onDoubleClick: (event: any, ...args: any[]) => void;
        onContextMenu: (event: any, ...args: any[]) => void;
        style: any;
    };
    getResizeProps: (props?: {}) => {
        left: {
            ref: (el: any) => any;
            className: string;
            style: any;
        };
        right: {
            ref: (el: any) => any;
            className: string;
            style: any;
        };
    };
    getItemStyle(props: any): any;
    render(): any;
}
