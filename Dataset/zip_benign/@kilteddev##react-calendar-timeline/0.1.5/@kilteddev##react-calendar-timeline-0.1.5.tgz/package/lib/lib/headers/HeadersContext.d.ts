export class TimelineHeadersProvider {
    static propTypes: {
        children: any;
        rightSidebarWidth: any;
        leftSidebarWidth: any;
        timeSteps: any;
        registerScroll: any;
    };
    render(): any;
}
export const TimelineHeadersConsumer: any;
