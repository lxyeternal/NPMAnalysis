export default class Sidebar {
    static propTypes: {
        groups: any;
        width: any;
        height: any;
        groupHeights: any;
        keys: any;
        groupRenderer: any;
        isRightSidebar: any;
    };
    shouldComponentUpdate(nextProps: any): boolean;
    renderGroupContent(group: any, isRightSidebar: any, groupTitleKey: any, groupRightTitleKey: any): any;
    render(): any;
}
