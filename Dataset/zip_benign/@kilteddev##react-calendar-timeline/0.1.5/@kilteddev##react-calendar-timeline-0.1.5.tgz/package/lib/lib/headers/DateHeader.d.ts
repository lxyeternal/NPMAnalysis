export default DateHeaderWrapper;
declare function DateHeaderWrapper({ unit, labelFormat, style, className, intervalRenderer, headerData, height }: {
    unit: any;
    labelFormat: any;
    style: any;
    className: any;
    intervalRenderer: any;
    headerData: any;
    height: any;
}): any;
declare namespace DateHeaderWrapper {
    namespace propTypes {
        const style: any;
        const className: any;
        const unit: any;
        const labelFormat: any;
        const intervalRenderer: any;
        const headerData: any;
        const height: any;
    }
    namespace defaultProps {
        export { formatLabel as labelFormat };
    }
}
declare function formatLabel([timeStart, timeEnd]: [any, any], unit: any, labelWidth: any, formatOptions?: {
    year: {
        long: string;
        mediumLong: string;
        medium: string;
        short: string;
    };
    month: {
        long: string;
        mediumLong: string;
        medium: string;
        short: string;
    };
    week: {
        long: string;
        mediumLong: string;
        medium: string;
        short: string;
    };
    day: {
        long: string;
        mediumLong: string;
        medium: string;
        short: string;
    };
    hour: {
        long: string;
        mediumLong: string;
        medium: string;
        short: string;
    };
    minute: {
        long: string;
        mediumLong: string;
        medium: string;
        short: string;
    };
}): any;
