export default CursorMarkerWrapper;
declare function CursorMarkerWrapper(props: any): any;
declare namespace CursorMarkerWrapper {
    const displayName: string;
}
