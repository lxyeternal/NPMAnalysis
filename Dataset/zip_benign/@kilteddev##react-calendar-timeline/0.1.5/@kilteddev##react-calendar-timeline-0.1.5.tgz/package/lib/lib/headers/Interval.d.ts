export default Interval;
declare class Interval {
    static propTypes: {
        intervalRenderer: any;
        unit: any;
        interval: any;
        showPeriod: any;
        intervalText: any;
        primaryHeader: any;
        getIntervalProps: any;
        headerData: any;
    };
    onIntervalClick: () => void;
    getIntervalProps: (props?: {}) => any;
    render(): any;
}
