export default SidebarWrapper;
declare function SidebarWrapper({ children, variant, headerData }: {
    children: any;
    variant: any;
    headerData: any;
}): any;
declare namespace SidebarWrapper {
    namespace propTypes {
        const children: any;
        const variant: any;
        const headerData: any;
    }
    namespace defaultProps {
        export { LEFT_VARIANT as variant };
        export function children_1({ getRootProps }: {
            getRootProps: any;
        }): any;
        export { children_1 as children };
    }
    const secretKey: string;
}
import { LEFT_VARIANT } from "./constants";
