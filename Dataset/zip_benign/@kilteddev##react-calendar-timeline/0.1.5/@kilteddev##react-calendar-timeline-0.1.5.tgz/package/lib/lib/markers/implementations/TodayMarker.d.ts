export default TodayMarker;
/** Marker that is placed based on current date.  This component updates itself on
 * a set interval, dictated by the 'interval' prop.
 */
declare class TodayMarker {
    static propTypes: {
        getLeftOffsetFromDate: any;
        renderer: any;
        interval: any;
    };
    static defaultProps: {
        renderer: ({ styles }: {
            styles: any;
        }) => any;
    };
    state: {
        date: number;
    };
    componentDidMount(): void;
    intervalToken: NodeJS.Timer;
    componentDidUpdate(prevProps: any): void;
    createIntervalUpdater(interval: any): NodeJS.Timer;
    componentWillUnmount(): void;
    render(): any;
}
