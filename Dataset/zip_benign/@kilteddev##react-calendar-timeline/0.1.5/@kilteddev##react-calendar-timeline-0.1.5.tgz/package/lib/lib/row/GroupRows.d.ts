export default class GroupRows {
    static propTypes: {
        canvasWidth: any;
        lineCount: any;
        groupHeights: any;
        onRowClick: any;
        onRowDoubleClick: any;
        clickTolerance: any;
        groups: any;
        horizontalLineClassNamesForGroup: any;
        onRowContextClick: any;
    };
    shouldComponentUpdate(nextProps: any): boolean;
    render(): any;
}
