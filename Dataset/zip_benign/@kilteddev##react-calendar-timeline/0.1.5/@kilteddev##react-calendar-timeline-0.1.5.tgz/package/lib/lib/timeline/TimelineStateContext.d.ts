export class TimelineStateProvider {
    static propTypes: {
        children: any;
        visibleTimeStart: any;
        visibleTimeEnd: any;
        canvasTimeStart: any;
        canvasTimeEnd: any;
        canvasWidth: any;
        showPeriod: any;
        timelineUnit: any;
        timelineWidth: any;
    };
    constructor(props: any);
    state: {
        timelineContext: {
            getTimelineState: () => {
                visibleTimeStart: any;
                visibleTimeEnd: any;
                canvasTimeStart: any;
                canvasTimeEnd: any;
                canvasWidth: any;
                timelineUnit: any;
                timelineWidth: any;
            };
            getLeftOffsetFromDate: (date: any) => number;
            getDateFromLeftOffsetPosition: (leftOffset: any) => number;
            showPeriod: any;
        };
    };
    getTimelineState: () => {
        visibleTimeStart: any;
        visibleTimeEnd: any;
        canvasTimeStart: any;
        canvasTimeEnd: any;
        canvasWidth: any;
        timelineUnit: any;
        timelineWidth: any;
    };
    getLeftOffsetFromDate: (date: any) => number;
    getDateFromLeftOffsetPosition: (leftOffset: any) => number;
    render(): any;
}
export const TimelineStateConsumer: any;
