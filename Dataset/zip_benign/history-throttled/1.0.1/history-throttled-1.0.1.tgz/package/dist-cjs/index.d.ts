declare const replaceState: typeof history.replaceState;
declare const pushState: typeof history.pushState;
declare function setDelay(newDelay: number | null): void;
export { replaceState, pushState, setDelay };
//# sourceMappingURL=index.d.ts.map