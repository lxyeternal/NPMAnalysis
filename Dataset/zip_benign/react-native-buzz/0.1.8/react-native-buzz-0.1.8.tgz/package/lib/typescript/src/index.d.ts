declare const Buzz: any;
export default Buzz;
//# sourceMappingURL=index.d.ts.map