import { __decorate } from "tslib";
import { customElement } from "lit/decorators.js";
import Button from "./internal/button";
let ScrollBackButton = class ScrollBackButton extends Button {
};
ScrollBackButton = __decorate([
    customElement('scroll-button')
], ScrollBackButton);
export default ScrollBackButton;
//# sourceMappingURL=scroll-button.js.map