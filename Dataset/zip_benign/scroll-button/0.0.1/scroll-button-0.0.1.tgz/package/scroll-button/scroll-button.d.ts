import Button from "./internal/button";
export default class ScrollBackButton extends Button {
}
