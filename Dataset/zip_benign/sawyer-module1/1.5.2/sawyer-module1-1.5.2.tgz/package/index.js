module.exports.area = radius => Math.PI*radius*radius
module.exports.perimeter = radius => 2*Math.PI*radius

module.exports.add = function(a, b){
  var n1;
  var n2
  var sum;
  this.a = n1;
  this.b = n2;
  sum = eval(n1 + n2);
  console.log(sum);
}

module.exports.greetings = function(){
  console.log('Hello World');
}
