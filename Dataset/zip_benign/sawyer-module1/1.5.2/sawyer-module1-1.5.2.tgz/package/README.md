# SAWYER-MODULE 1
> A simple test module.

**HOW TO**
```bash
$ npm i sawyer-module1 --save
```

```js
const Smodule = require('sawyer-module1');

// Greetings

Smodule.greetings();

// Math

Smodule.add(3,2);

console.log(Smodule.area(1));
console.log(Smodule.perimeter(0.5));

```
Output
```bash
Hello World
5
3.141592653589793
3.141592653589793
```
