require('../io/hsluv');
const interpolate_hsx = require('./_hsx');

const hsluv = (col1, col2, f) => {
  return interpolate_hsx(col1, col2, f, 'hsluv');
};

require('./index').hsluv = hsluv;

module.exports = hsluv;
