require('../io/hpluv');
const interpolate_hsx = require('./_hsx');

const hpluv = (col1, col2, f) => {
  return interpolate_hsx(col1, col2, f, 'hpluv');
};

require('./index').hpluv = hpluv;

module.exports = hpluv;
