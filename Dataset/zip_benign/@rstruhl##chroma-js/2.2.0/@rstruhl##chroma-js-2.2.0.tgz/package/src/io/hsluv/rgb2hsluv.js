const { unpack } = require('../../utils');
const rgb2lch = require('../lch/rgb2lch');
const lch2hsluv = require('./lch2hsluv');

const rgb2hsluv = (...args) => {
  const [r, g, b] = unpack(args, 'rgb');
  const [l, c, h] = rgb2lch(r, g, b);
  return lch2hsluv(l, c, h);
};

module.exports = rgb2hsluv;
