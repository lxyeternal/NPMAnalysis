const { unpack } = require('../../utils');

const util = require('../hsluv/hsluv-util');
const maxSafeChromaForL = util.maxSafeChromaForL;

const hpluv2lch = (...args) => {
  const [h, s, l] = unpack(args, 'hsl');
  if (l > 99.9999999) {
    return [100, 0, h];
  }

  if (l < 0.00000001) {
    return [0, 0, h];
  }

  const max = maxSafeChromaForL(l);
  const c = max / 100 * s;

  return [l, c, h];
};

module.exports = hpluv2lch;
