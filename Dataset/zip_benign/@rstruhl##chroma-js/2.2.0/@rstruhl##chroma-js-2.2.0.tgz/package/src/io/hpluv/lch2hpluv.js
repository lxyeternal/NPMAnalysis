const { unpack } = require('../../utils');

const util = require('../hsluv/hsluv-util');
const maxSafeChromaForL = util.maxSafeChromaForL;

const lch2hpluv = (...args) => {
  const [l, c, h] = unpack(args, 'lch');
  if (l > 99.9999999) {
    return [h, 0, 100];
  }

  if (l < 0.00000001) {
    return [h, 0, 0];
  }

  const max = maxSafeChromaForL(l);
  const s = Math.min(c / max * 100, 100);

  return [h, s, l];
};

module.exports = lch2hpluv;
