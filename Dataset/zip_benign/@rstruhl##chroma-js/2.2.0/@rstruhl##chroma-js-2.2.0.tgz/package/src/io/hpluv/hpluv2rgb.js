const { unpack } = require('../../utils');
const lch2rgb = require('../lch/lch2rgb');

const hpluv2lch = require('./hpluv2lch');

const hpluv2rgb = (...args) => {
  const [H, S, L] = unpack(args, 'hsl');
  const [l, c, h] = hpluv2lch(H, S, L);
  const [r, g, b] = lch2rgb(l, c, h);
  return [r, g, b, args.length > 3 ? args[3] : 1];
};

module.exports = hpluv2rgb;
