const { unpack } = require('../../utils');
const util = require('./hsluv-util');
const maxChromaForLH = util.maxChromaForLH;

const lch2hsluv = (...args) => {
  const [l, c, h] = unpack(args, 'lch');
  if (l > 99.9999999) {
    return [h, 0, 100];
  }

  if (l < 0.00000001) {
    return [h, 0, 0];
  }

  const max = maxChromaForLH(l, h);
  const s = c / max * 100;

  return [h, s, l];
};

module.exports = lch2hsluv;
