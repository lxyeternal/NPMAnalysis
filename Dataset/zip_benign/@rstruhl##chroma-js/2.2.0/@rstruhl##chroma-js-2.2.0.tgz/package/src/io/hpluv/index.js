const chroma = require('../../chroma');
const Color = require('../../Color');
const input = require('../input');

const rgb2hpluv = require('./rgb2hpluv');

Color.prototype.hpluv = function() {
  return rgb2hpluv(this._rgb);
};

chroma.hpluv = (...args) => new Color(...args, 'hpluv');

input.format.hpluv = require('./hpluv2rgb');
