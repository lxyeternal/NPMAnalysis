const { unpack } = require('../../utils');
const util = require('./hsluv-util');
const maxChromaForLH = util.maxChromaForLH;

const hsluv2lch = (...args) => {
  const [h, s, l] = unpack(args, 'hsl');

  if (l > 99.9999999) {
    return [100, 0, h];
  }

  if (l < 0.00000001) {
    return [0, 0, h];
  }

  const max = maxChromaForLH(l, h);
  const c = max / 100 * s;

  return [l, c, h];
};

module.exports = hsluv2lch;
