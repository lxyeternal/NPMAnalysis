const { unpack } = require('../../utils');
const rgb2lch = require('../lch/rgb2lch');
const lch2hpluv = require('./lch2hpluv');

const rgb2hpluv = (...args) => {
  const [r, g, b] = unpack(args, 'rgb');
  const [l, c, h] = rgb2lch(r, g, b);
  return lch2hpluv(l, c, h);
};

module.exports = rgb2hpluv;
