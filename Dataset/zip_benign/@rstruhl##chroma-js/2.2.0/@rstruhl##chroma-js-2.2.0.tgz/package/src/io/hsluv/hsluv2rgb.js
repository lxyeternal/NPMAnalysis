const { unpack } = require('../../utils');
const lch2rgb = require('../lch/lch2rgb');

const hsluv2lch = require('./hsluv2lch');

const hsluv2rgb = (...args) => {
  const [H, S, L] = unpack(args, 'hsl');
  const [l, c, h] = hsluv2lch(H, S, L);
  const [r, g, b] = lch2rgb(l, c, h);
  return [r, g, b, args.length > 3 ? args[3] : 1];
};

module.exports = hsluv2rgb;
