const { PI, pow, sin, cos, min } = Math;

const m = [
  [3.240969941904521, -1.537383177570093, -0.498610760293],
  [-0.96924363628087, 1.87596750150772, 0.041555057407175],
  [0.055630079696993, -0.20397695888897, 1.056971514242878]
];

const epsilon = 0.0088564516;
const kappa = 903.2962962;

const lengthUntilIntersect = (angle, line) => {
  return line.intercept / (sin(angle) - line.slope * cos(angle));
};

const lengthFromOrigin = line => {
  return Math.abs(line.intercept) / Math.sqrt(pow(line.slope, 2) + 1);
};

const maxChromaForLH = (l, h) => {
  const hrad = h / 360 * PI * 2;
  const bounds = getBounds(l);
  let minimum = Infinity;
  bounds.forEach(bound => {
    const length = lengthUntilIntersect(hrad, bound);
    if (length >= 0) {
      minimum = min(minimum, length);
    }
  });

  return minimum;
};

const maxSafeChromaForL = l => {
  const bounds = getBounds(l);
  let minimum = Infinity;
  bounds.forEach(bound => {
    const length = lengthFromOrigin(bound);
    minimum = min(minimum, length);
  });
  return minimum;
};

const getBounds = l => {
  let result = [];
  const sub1 = pow(l + 16, 3) / 1560896;
  const sub2 = sub1 > epsilon ? sub1 : l / kappa;
  for (let c = 0; c < 3; c += 1) {
    const [m1, m2, m3] = m[c];
    for (let t = 0; t < 2; t += 1) {
      const top1 = (284517 * m1 - 94839 * m3) * sub2;
      const top2 =
        (838422 * m3 + 769860 * m2 + 731718 * m1) * l * sub2 - 769860 * t * l;

      const bottom = (632260 * m3 - 126452 * m2) * sub2 + 126452 * t;
      result.push({
        slope: top1 / bottom,
        intercept: top2 / bottom
      });
    }
  }
  return result;
};

module.exports = {
  maxChromaForLH: maxChromaForLH,
  maxSafeChromaForL: maxSafeChromaForL,
  getBounds: getBounds
};
