const chroma = require('../../chroma');
const Color = require('../../Color');
const input = require('../input');

const rgb2hsluv = require('./rgb2hsluv');

Color.prototype.hsluv = function() {
  return rgb2hsluv(this._rgb);
};

chroma.hsluv = (...args) => new Color(...args, 'hsluv');

input.format.hsluv = require('./hsluv2rgb');
