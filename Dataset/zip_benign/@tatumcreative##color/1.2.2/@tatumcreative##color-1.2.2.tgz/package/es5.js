'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/*
	Allow color calls to be called two different ways:

	fn( a, b, c, optionalTarget )
	fn( color, optionalTarget )
*/

function routeCalls4dFn (fn) {
  return function routeCalls4d (a, b, c, d, e) {
    var target
    // fn( color, optionalTarget )
    if (Array.isArray(a)) {
      var color = a
      target = Array.isArray(b) ? b : []

      return fn(color[0], color[1], color[2], color[3], target)
    } else {
      // fn( a, b, c, optionalTarget )
      if (Array.isArray(d)) {
        return fn(a, b, c, undefined, d)
      } else {
        // fn( a, b, c, optionalTarget )
        // fn( a, b, c, d, optionalTarget )
        target = Array.isArray(e) ? e : []
        return fn(a, b, c, d, target)
      }
    }
  }
}

function _hueToRgb (p, q, t) {
  if (t < 0) t += 1
  if (t > 1) t -= 1
  if (t < 1 / 6) return p + (q - p) * 6 * t
  if (t < 1 / 2) return q
  if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
  return p
}

function _hslToRgb (h, s, l, a, results) {
  var r, g, b

  // achromatic
  if (s === 0) {
    r = g = b = l
  } else {
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s
    var p = 2 * l - q
    r = _hueToRgb(p, q, h + 1 / 3)
    g = _hueToRgb(p, q, h)
    b = _hueToRgb(p, q, h - 1 / 3)
  }

  results[0] = r
  results[1] = g
  results[2] = b

  if (a >= 0) {
    results[3] = a
  }

  return results
}

var HslToRgb = routeCalls4dFn(_hslToRgb)

function _rgbToHex (r, g, b) {
  var r255 = parseInt(r * 255, 10)
  var g255 = parseInt(g * 255, 10)
  var b255 = parseInt(b * 255, 10)

  return (r255 << 16) | (g255 << 8) | b255
}

function routeRgbToHex (a, b, c) {
  // _rgbToHex( color )
  if (Array.isArray(a)) {
    return _rgbToHex(a[0], a[1], a[2])

  // _rgbToHex( a, b, c, optionalTarget )
  } else {
    return _rgbToHex(a, b, c)
  }
}

var Scratch = []

function _hslToHex (h, s, l, a) {
  return routeRgbToHex(HslToRgb(h, s, l, a, Scratch))
}

function routeCalls (a, b, c) {
  if (Array.isArray(a)) {
    var color = a
    return _hslToHex(color[0], color[1], color[2])
  } else {
    return _hslToHex(a, b, c)
  }
}

function _rgbFillStyle (h, s, l) {
  h = parseInt(h * 360, 10)
  s = parseInt(s * 100, 10)
  l = parseInt(l * 100, 10)

  return ['hsl(', h, ',', s, '%,', l, '%)'].join('')
}

function _rgbaFillStyle (h, s, l, a) {
  h = parseInt(h * 360, 10)
  s = parseInt(s * 100, 10)
  l = parseInt(l * 100, 10)

  // Round to 0.000
  a = parseInt(a * 1000, 10) / 1000

  return ['hsla(', h, ',', s, '%,', l, '%,', a, ')'].join('')
}

function hslToStyle (a, b, c, d) {
  if (Array.isArray(a)) {
    var array = a
    a = array[0]
    b = array[1]
    c = array[2]
    d = array[3]
  }

  if (typeof d === 'undefined') {
    return _rgbFillStyle(a, b, c)
  } else {
    return _rgbaFillStyle(a, b, c, d)
  }
}

function _hexToRgb (hex, target) {
  var r = (0xff0000 & hex) >> 16
  var g = (0x00ff00 & hex) >> 8
  var b = (0x0000ff & hex)

  target[0] = r / 255
  target[1] = g / 255
  target[2] = b / 255

  return target
}

function routeHexToRgb (hex, target) {
  target = target || []
  return _hexToRgb(hex, target)
}

function hexToString (hex) {
  return '#' + (0xf000000 | hex).toString(16).substr(1)
}

function _rgbToHsl (r, g, b, a, result) {
  var max = Math.max(r, g, b)
  var min = Math.min(r, g, b)
  var h
  var s
  var l = (max + min) / 2

  // achromatic
  if (max === min) {
    h = s = 0
  } else {
    var d = max - min
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)

    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0)
        break
      case g:
        h = (b - r) / d + 2
        break
      case b:
        h = (r - g) / d + 4
        break
    }

    h /= 6
  }

  result[0] = h
  result[1] = s
  result[2] = l

  if (a >= 0) {
    result[3] = a
  }

  return result
}

var rgbToHsl = routeCalls4dFn(_rgbToHsl)

function _rgbFillStyle$1 (r, g, b) {
  r = parseInt(r * 255, 10)
  g = parseInt(g * 255, 10)
  b = parseInt(b * 255, 10)

  return ['rgb(', r, ',', g, ',', b, ')'].join('')
}

function _rgbaFillStyle$1 (r, g, b, a) {
  r = parseInt(r * 255, 10)
  g = parseInt(g * 255, 10)
  b = parseInt(b * 255, 10)

  // Round to 0.000
  a = parseInt(a * 1000, 10) / 1000

  return ['rgba(', r, ',', g, ',', b, ',', a, ')'].join('')
}

function rgbToStyle (a, b, c, d) {
  if (Array.isArray(a)) {
    var array = a
    a = array[0]
    b = array[1]
    c = array[2]
    d = array[3]
  }

  if (typeof d === 'undefined') {
    return _rgbFillStyle$1(a, b, c)
  } else {
    return _rgbaFillStyle$1(a, b, c, d)
  }
}

function stringToHex (string) {
  return parseInt(string.substr(1), 16)
}

exports.hslToRgb = HslToRgb;
exports.hslToHex = routeCalls;
exports.hslToStyle = hslToStyle;
exports.hexToRgb = routeHexToRgb;
exports.hexToString = hexToString;
exports.rgbToHex = routeRgbToHex;
exports.rgbToHsl = rgbToHsl;
exports.rgbToStyle = rgbToStyle;
exports.stringToHex = stringToHex;