import { EventEmitter, OnInit, TemplateRef, OnDestroy } from '@angular/core';
import { CalendarService } from './calendar.service';
export interface IBooking {
    endDate: Date;
    startDate: Date;
    name: string;
    room: number;
    phone: string;
}
export interface IRange {
    startTime: Date;
    endTime: Date;
}
export interface IView {
}
export interface IWeekView extends IView {
    roomData: IWeekViewRow[][];
    dayHeaderRow: IWeekViewDayHeaderRow[];
}
export interface IWeekViewDayHeaderRow {
    date: Date;
    dayHeaderString: string;
}
export interface IWeekViewRow {
    roomEvents: IDisplayBooking[];
    roomName: string;
}
export interface IDisplayBooking {
    startedPreviousWeek: boolean;
    event: IBooking;
    days: number;
}
export interface IDisplayWeekViewHeader {
    viewDate: IWeekViewDayHeaderRow;
}
export interface ICalendarComponent {
    currentViewIndex: number;
    direction: number;
    bookingsSource: IBooking[];
    getRange: {
        (date: Date): IRange;
    };
    getViewData: {
        (date: Date): IView;
    };
    mode: CalendarMode;
    range: IRange;
    views: IView[];
    onDataLoaded: {
        (): void;
    };
    onRangeChanged: EventEmitter<IRange>;
}
export interface IWeekViewNormalEventSectionTemplateContext {
    roomDayData: IWeekViewRow;
    dayIndex: number;
    eventTemplate: TemplateRef<IBooking>;
}
export interface IDateFormatter {
    formatWeekViewDayHeader?: {
        (date: Date): string;
    };
    formatWeekViewTitle?: {
        (date: Date): string;
    };
}
export declare type CalendarMode = 'week';
export declare type QueryMode = 'local' | 'remote';
export declare enum Step {
    Hour = 60
}
export declare class CalendarComponent implements OnInit, OnDestroy {
    private calendarService;
    private appLocale;
    currentDate: Date;
    bookingsSource: IBooking[];
    roomNamesSource: string[];
    calendarMode: CalendarMode;
    formatWeekTitle: string;
    formatWeekViewDayHeader: string;
    step: Step;
    weekviewHeaderTemplate: TemplateRef<IDisplayWeekViewHeader>;
    weekviewNormalEventTemplate: TemplateRef<IDisplayBooking>;
    weekviewNormalEventSectionTemplate: TemplateRef<IWeekViewNormalEventSectionTemplateContext>;
    dateFormatter: IDateFormatter;
    locale: string;
    onCurrentDateChanged: EventEmitter<Date>;
    onRangeChanged: EventEmitter<IRange>;
    onEventSelected: EventEmitter<IBooking>;
    onTitleChanged: EventEmitter<string>;
    private _currentDate;
    private currentDateChangedFromChildrenSubscription;
    constructor(calendarService: CalendarService, appLocale: string);
    ngOnInit(): void;
    ngOnDestroy(): void;
    rangeChanged(range: IRange): void;
    eventSelected(event: IBooking): void;
    titleChanged(title: string): void;
    loadEvents: () => void;
    getBackgroundColor(status: string): "#d50000" | "#ffd600" | "#00c853";
    getTextColor(status: string): "#ffffff" | "#000000";
    getEventWidth(displayBooking: IDisplayBooking, dayIndex: number): string;
}
