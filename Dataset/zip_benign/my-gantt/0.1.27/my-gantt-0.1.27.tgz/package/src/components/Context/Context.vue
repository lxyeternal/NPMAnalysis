<template>
  <div class="context" v-if="active" ref="context">
    <slot />
  </div>
</template>

<script>
export default {
  name: "Context",
  data() {
    return {
      active: false,
      layerX: 0,
      layerY: 0,
      documentEventListener: null,
    };
  },
  methods: {
    show: function (e, left, top) {
      this.layerX = `${e.layerX + left}px`;
      this.layerY = `${e.layerY + top}px`;

      this.$nextTick(() => {
        this.active = true;
      });

      document.addEventListener("click", () => {
        this.active = false;
      });
    },
  },
};
</script>

<style>
.context {
  position: absolute;
  background-color: #333;
  z-index: 10;
  left: v-bind(layerX);
  top: v-bind(layerY);
  border-radius: 4px;
  color: #f1f1f1;
  padding: 0.4rem 0.5rem;
  min-width: 200px;
}

.context > button {
  margin-top: 0.4rem;
  background-color: #444;
  padding: 0.3rem;
  border: none;
  color: inherit;
  cursor: pointer;
  text-align: left;
  font-size: 0.75rem;
  border-radius: 4px;
  display: inline-block;
}

/* .con}ztext > button:hover { */
/* background-color: #eff2f8; */
/* } */
</style>
