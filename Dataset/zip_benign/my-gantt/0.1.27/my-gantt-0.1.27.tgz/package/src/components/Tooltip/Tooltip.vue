<template>
  <div class="tooltip" v-if="active" ref="tooltip">
    <slot />
  </div>
</template>

<script>
export default {
  name: "Tooltip",
  props: {
    left: Number,
    top: Number,
  },
  data() {
    return {
      active: false,
      layerX: 0,
      layerY: 0,
      clickEventListenner: null,
    };
  },
  methods: {
    show: function (e) {
      this.layerX = `${e.layerX + this.left}px`;
      this.layerY = `${e.layerY + this.top}px`;

      this.$nextTick(() => {
        setTimeout(() => {
          this.active = true;
        }, 50);
      });

      document.addEventListener("click", (e) => {
        if (e.targe !== this.$refs.tooltip) {
          this.active = false;
        }
      });
    },
  },
};
</script>

<style>
.tooltip {
  left: v-bind(layerX);
  background-color: #333;
  align-self: center;
  position: absolute;
  padding: 0.4rem 0.5rem;
  border-radius: 4px;
  z-index: 100000000000000;
  color: #f1f1f1;
}

.tooltip > p {
  margin: 0;
}
</style>
