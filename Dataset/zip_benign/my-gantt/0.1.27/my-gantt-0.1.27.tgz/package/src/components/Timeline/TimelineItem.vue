<template>
  <div
    class="task"
    @dblclick="handleResizeOpen"
    @click.right.prevent="handleShowContext"
    draggable="true"
    @dragstart="handleDragStart"
    @drag.stop="handleDrag"
    @drop.prevent.stop=""
    @dragend="handleUpdateDate"
    ref="task"
  >
    <div class="task__container">
      <div
        class="task__resize task_resize--left"
        v-if="showResizes"
        draggable="true"
        @drag.stop="handleResizeLeft"
        @dragend="handleUpdateDate"
        @dragover.prevent=""
        @dragleave.prevent=""
      />

      <div class="task__content" :class="`task__state--${state}`">
        <slot />
      </div>

      <div
        class="task__resize task_resize--right"
        v-if="showResizes"
        draggable="true"
        @drag.stop="handleResizeRight"
        @dragend="handleUpdateDate"
        @dragover.prevent=""
        @dragleave.prevent=""
      />
    </div>
  </div>

  <Tooltip
    ref="tooltip"
    :left="this.cellSize * this.initPostion"
    :top="this.cellHeight * this.topPosition"
  >
    <small>Title: {{ title }}</small> <br />
    <small>Creation: {{ creation }}</small>
  </Tooltip>

  <span class="task__aux">
    <span
      class="task__scroll-action"
      :class="`task__state--${state}`"
      @click="handleScrollLeftToItem"
    />
  </span>

  <span class="task__aux--right">
    <span
      class="task__scroll-action--right"
      :class="`task__state--${state}`"
      @click="handleScrollRightToItem"
    />
  </span>

  <ItemContext ref="context">
    <small>
      <b>{{ title }}</b>
    </small>
    <br />
    <small>Creation: {{ creation }}</small> <br />
    <small>Due: {{ creation }}</small>

    <button @click="handleCutOrder" class="context__button">Cut</button>
  </ItemContext>
</template>

<script>
import { Context as ItemContext } from "@/components/Context";
import { Tooltip } from "@/components/Tooltip";

import {
  reduceCellSize,
  increaseCellSize,
  resetCellSize,
  cellSize,
  cellSizeInPx,
  cellHeight,
  cellHeightInPx,
} from "@/contexts/CellSizeContext";
import { calendarInit } from "@/contexts/CalendarContext";
import { getDiffDays, addDays, dateFormated } from "@/utils/date";
import { clickOutside } from "@/utils/listener";
import { getOrderStateBg } from "@/utils/ui";

export default {
  name: "TimelineItem",
  inheritAttrs: false,
  props: {
    id: String,
    title: String,
    creationDate: Number,
    duedate: Number,
    progress: Number,
    groupName: String,
    priority: Number,
    orderState: String,
  },
  inject: {
    reduceCellSize,
    increaseCellSize,
    resetCellSize,
    cellSize,
    cellSizeInPx,
    cellHeight,
    cellHeightInPx,
    calendarInit,
    updateTask: { from: "updateTask" },
    rows: { from: "rows" },
    setRows: { from: "setRows" },
    cutTask: { from: "cutTask" },
  },
  data: function () {
    return {
      initPostion: null,
      endPosition: null,
      topPosition: this.priority - 1,
      showResizes: false,
      width: null,
      dragLayerX: null,
      dragLayerY: null,
      topLimit: null,
      bottomLimit: 0,
      taskPriority: this.priority,
      taskGroupName: this.groupName,
      currentRowIndex: null,
      documentEventListener: null,
      currentRows: this.rows,
    };
  },
  computed: {
    creation: function () {
      return dateFormated(this.creationDate);
    },
    due: function () {
      return dateFormated(this.duedate);
    },
    taskTopPosition: function () {
      return `${this.cellHeight * this.topPosition}px`;
    },
    taskWidth: function () {
      return `${this.cellSize * this.width}px`;
    },
    taskLeftPosition: function () {
      return `${this.cellSize * this.initPostion}px`;
    },
    state: function () {
      return getOrderStateBg({
        orderState: this.orderState,
        duedate: this.duedate,
        progress: this.progress,
      });
    },
  },
  methods: {
    getTaskPositions: function () {
      this.initPostion = getDiffDays(this.creationDate, this.calendarInit);
      this.endPosition = getDiffDays(this.duedate, this.calendarInit);

      const taskElement = this.$refs.task;
      const row = taskElement.closest(".calendar__row");
      this.currentRowIndex = Array.from(row.parentNode.children).indexOf(row);

      this.getTopLimit();
      this.getBottomLimit();

      this.width = getDiffDays(this.creationDate, this.duedate) + 1;
    },
    getTopLimit: function () {
      const taskElement = this.$refs.task;
      const row = taskElement.closest(".calendar__row");
      const rowIndex = Array.from(row.parentNode.children).indexOf(row);

      const timelineGroups = Array.from(row.parentNode.children);
      const prevTimelineGroups = timelineGroups.slice(0, rowIndex);

      this.$nextTick(() => {
        const prevRowsLimit = prevTimelineGroups.reduce((prev, curr) => {
          return prev + curr.offsetHeight / this.cellHeight;
        }, 0);

        this.topLimit = prevRowsLimit + this.priority - 1;
      });
    },
    getBottomLimit: function () {
      const taskElement = this.$refs.task;
      const row = taskElement.closest(".calendar__row");
      const rowIndex = Array.from(row.parentNode.children).indexOf(row);

      const timelineGroups = Array.from(row.parentNode.children);
      const nextTimelineRows = timelineGroups.slice(
        rowIndex + 1,
        timelineGroups.length
      );

      this.$nextTick(() => {
        const prevRowsLimit = nextTimelineRows.reduce((prev, curr) => {
          return prev + curr.offsetHeight / this.cellHeight;
        }, 0);

        this.bottomLimit = prevRowsLimit + this.currentRows - this.priority;
      });
    },
    handleResizeOpen: function () {
      this.showResizes = true;

      this.documentEventListener = clickOutside(this.$refs.task, () => {
        this.handleResizeClose();
      });
    },
    handleResizeClose: function () {
      this.showResizes = false;
    },
    handleDragStart: function (e) {
      this.dragLayerX = e.layerX;
      this.dragLayerY = e.layerY;
    },
    handleDrag: function (e) {
      const { layerX, clientX, layerY } = e;
      if (!clientX && layerX) return;

      const cellsToMove = Math.round(
        (this.dragLayerX - layerX) / this.cellSize
      );

      if (cellsToMove > 5 || cellsToMove < -5) return;

      const rowToMove = Math.round(
        (this.dragLayerY - layerY) / this.cellHeight
      );

      this.initPostion -= cellsToMove;
      this.endPosition -= cellsToMove;

      if (rowToMove > 0 && this.topLimit - rowToMove >= 0) {
        this.topLimit -= rowToMove;
        this.bottomLimit += rowToMove;
        this.topPosition -= rowToMove;
        this.handlePriorityAndGroup(rowToMove);
      }

      if (rowToMove < 0 && this.bottomLimit + rowToMove >= 0) {
        this.topLimit -= rowToMove;
        this.bottomLimit += rowToMove;
        this.topPosition -= rowToMove;
        this.handlePriorityAndGroup(rowToMove);
      }

      this.width = this.endPosition - this.initPostion + 1;
    },
    handlePriorityAndGroup: function (rowToMove) {
      this.taskPriority -= rowToMove;

      if (this.taskPriority <= 0) {
        const taskElement = this.$refs.task;
        const row = taskElement.closest(".calendar__row");

        this.currentRowIndex -= 1;

        const prevGroup = row.parentNode.children[this.currentRowIndex];
        const prevGroupPriorities = prevGroup.offsetHeight / this.cellHeight;

        const newRowName = prevGroup.getAttribute("rowid");
        const prevRowPriorities = Array.from(
          prevGroup.querySelectorAll(".calendar__inner-row")
        ).length;
        const newPriority = prevGroupPriorities;

        this.taskPriority = newPriority;
        this.taskGroupName = newRowName;
        this.currentRows = prevRowPriorities;
      } else if (this.taskPriority > this.currentRows) {
        const taskElement = this.$refs.task;
        const row = taskElement.closest(".calendar__row");

        this.currentRowIndex += 1;

        const newtGroup = row.parentNode.children[this.currentRowIndex];
        const nextRowPriorities = Array.from(
          newtGroup.querySelectorAll(".calendar__inner-row")
        ).length;
        const nextRowName = newtGroup.getAttribute("rowid");

        this.taskPriority = 1;
        this.taskGroupName = nextRowName;
        this.currentRows = nextRowPriorities;
      }
    },
    handleResizeLeft: function (e) {
      const { layerX, clientX } = e;
      if (!clientX && layerX) return;

      const resize = Math.round(layerX / this.cellSize);

      if (resize > 1 || resize < -1) return;

      if (this.width >= 2 || resize < 0) {
        this.initPostion += resize;
        this.width = this.endPosition - this.initPostion + 1;
      }
    },
    handleResizeRight: function (e) {
      const { layerX, clientX } = e;
      if (!clientX && layerX) return;

      const resize = Math.round(layerX / this.cellSize);

      if (resize > 10 || resize < -10) return;

      if (this.width + resize > 0) {
        this.endPosition += resize;
        this.width = this.endPosition - this.initPostion + 1;
      }
    },
    handleUpdateDate: function () {
      const initDay = addDays(this.calendarInit, this.initPostion);
      const endDay = addDays(this.calendarInit, this.endPosition);

      const taskData = {
        ...this.$props,
        creationDate: initDay,
        duedate: endDay,
        priority: this.taskPriority,
      };

      delete taskData.groupName;

      this.updateTask({
        updatedTask: taskData,
        newRow: this.taskGroupName,
        oldRow: this.groupName,
      });
    },
    handleScrollLeftToItem: function () {
      const scrollPosition = this.cellSize * this.initPostion - 20;
      window.scrollTo({ left: scrollPosition, behavior: "smooth" });
    },
    handleScrollRightToItem: function () {
      const MAGIC_NUMBER = 510;
      const scrollPosition =
        this.cellSize * this.initPostion - window.innerWidth + MAGIC_NUMBER;

      window.scrollTo({ left: scrollPosition, behavior: "smooth" });
    },
    handleShowContext: function (e) {
      // console.log(e);
      const leftPosition = this.cellSize * this.initPostion;
      const topPosition = this.cellHeight * this.topPosition;

      this.$refs.context.show(e, leftPosition, topPosition);
    },
    handleCutOrder: function () {
      this.cutTask({ group: this.groupName, taskId: this.id });
    },
    handleShowTooltip: function (e) {
      this.$refs.tooltip.show(e);
    },
  },
  watch: {
    calendarInit: function () {
      this.getTaskPositions();
    },
    creationDate: function () {
      this.getTaskPositions();
    },
    duedate: function () {
      this.getTaskPositions();
    },
    rows: function () {
      this.currentRows = this.rows;
    },
  },
  mounted() {
    this.getTaskPositions();

    if (this.priority > this.currentRows) {
      this.setRows(this.priority);
    }
  },
  beforeUnmount() {
    document.removeEventListener("click", this.documentEventListener);
  },
  components: {
    ItemContext,
    Tooltip,
  },
};
</script>

<style>
.task {
  position: absolute;
  border-radius: 5px;
  height: v-bind(cellHeightInPx);
  top: v-bind(taskTopPosition);
  width: v-bind(taskWidth);
  left: v-bind(taskLeftPosition);
  z-index: 3;
}

.task__container {
  position: relative;
  align-items: center;
  color: white;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
}

.task__content {
  padding: 0rem 1rem;
  display: flex;
  align-items: center;
  position: relative;
  z-index: 3;
  white-space: nowrap;
  text-overflow: ellipsis;
  height: 62%;
  background-color: tomato;
  border-radius: 4px;
  width: 100%;
}

.task__content::after {
  content: "";
  position: absolute;
  right: 0;
  top: 0;
  display: block;
  height: 100%;
  width: calc(100% * (1 - v-bind(progress)));
  background-color: rgba(255, 255, 255, 0.25);
  z-index: 2;
}

.task__content:active {
  box-shadow: 0px 0px 5px 0px #000;
  pointer-events: none;
  z-index: 100;
}

.task__content > * {
  position: sticky;
  left: 210px;
}

.task__resize {
  position: absolute;
  margin: 1px 0;
  top: 6px;
  height: 70%;
  width: 14px;
  display: flex;
  align-items: center;
  z-index: 10;
  cursor: ew-resize;
  background-color: rgba(160, 160, 160, 0.7);
  border-radius: 2px;
}

.task__resize:hover {
  background-color: rgba(160, 160, 160, 0.85);
}

.task__resize::after,
.task__resize::before {
  content: "";
  position: absolute;
  width: 0.1rem;
  height: 50%;
  background-color: #fff;
  margin: 1rem 0.2rem;
  border-radius: 100px;
}

.task__resize::after {
  left: 0;
}

.task__resize::before {
  right: 0;
}

.task_resize--left {
  left: -16px;
}

.task_resize--right {
  right: -16px;
}

.task__scroll-action {
  position: sticky;
  left: 195px;
  right: 0;
  height: 62%;
  border-radius: 5px;
  width: 15px;
  cursor: pointer;
}

.task__aux {
  position: absolute;
  z-index: 2;
  height: v-bind(cellHeightInPx);
  top: v-bind(taskTopPosition);
  left: v-bind(taskLeftPosition);
  width: calc(100% - v-bind(taskLeftPosition));
  display: flex;
  align-items: center;
}

.task__scroll-action--right {
  position: sticky;
  right: -5px;
  height: 62%;
  border-radius: 5px;
  width: 15px;
  cursor: pointer;
}

.task__aux--right {
  position: absolute;
  z-index: 1;
  height: v-bind(cellHeightInPx);
  top: v-bind(taskTopPosition);
  left: 0;
  width: calc(v-bind(taskLeftPosition) + v-bind(taskWidth));
  display: flex;
  align-items: center;
  justify-content: end;
}

.task__state--info {
  background-color: #3c8dbc;
}

.task__state--success {
  background-color: #00a85d;
}

.task__state--warning {
  background-color: #ffb311;
}

.task__state--danger {
  background-color: #ff3636;
}

.task__state--dark {
  background-color: #343a40;
}

.context__button {
  position: absolute;
  right: -31px;
  top: -6px;
  margin-top: 0;
  font-size: 0.8rem;
}

.context__button:hover {
  background-color: #555;
}
</style>
