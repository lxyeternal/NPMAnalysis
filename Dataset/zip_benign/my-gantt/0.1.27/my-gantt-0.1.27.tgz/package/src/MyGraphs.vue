<template>
  <div class="my-graph">
    <CalendarContext>
      <CellSizeContext>
        <MyGantt :groups="groups" v-if="Object.keys(groups).length">
          <slot />
        </MyGantt>
      </CellSizeContext>
    </CalendarContext>
  </div>
</template>

<script>
import { CellSizeContext, CalendarContext } from "@/contexts";
import { mouseDragScroll } from "@/utils/mouseDragScroll";
import MyGantt from "./MyGantt";

export const emitUpdatedTasks = Symbol();
export const emitCutTasks = Symbol();

export default {
  name: "MyGraphs",
  emits: ["update"],
  props: {
    groups: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      unsubscribeMouseDragScroll: null,
    };
  },
  methods: {
    emitUpdatedTasks: function (updatedTasks) {
      this.$emit("update", updatedTasks);
    },
    emitCutTasks: function ([firstTask, seconTask]) {
      this.$emit("cut", [firstTask, seconTask]);
    },
  },
  provide: function () {
    return {
      emitUpdatedTasks: this.emitUpdatedTasks,
      emitCutTasks: this.emitCutTasks,
    };
  },
  mounted() {
    // can send selector with props
    this.unsubscribeMouseDragScroll = mouseDragScroll("html");
  },
  beforeUnmount() {
    this.unsubscribeMouseDragScroll();
  },
  components: {
    CellSizeContext,
    CalendarContext,
    MyGantt,
  },
};
</script>

<style>
.my-graph {
  position: relative;
  width: max-content;
}
</style>
