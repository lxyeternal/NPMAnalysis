<template>
  <template v-if="materials">
    <!-- <MyGraphs :groups="groups" @cut="handleCutTasks" /> -->
    <MyGraphs :groups="materials" @update="handleUpdatedTasks" />
  </template>
</template>

<script>
import { dateFormated } from "@/utils/date";
import MyGraphs from "./MyGraphs";
import { getOrdersByMaterials } from "@/services";

export default {
  name: "App",
  data() {
    return {
      materials: null,
      groups: [
        {
          name: "group 01",
          id: "1",
          tasks: [
            {
              id: "01",
              title: "Test task 01",
              creationDate: 1641437099,
              duedate: 1651805099,
              progress: 0.8,
              priority: 1,
            },
            {
              id: "02",
              title: "Test task 02",
              creationDate: 1643856299,
              duedate: 1649126699,
              progress: 0.5,
              priority: 2,
            },
          ],
        },
        {
          name: "group 02",
          id: "2",
          tasks: [
            {
              id: "03",
              title: "Test task 03",
              creationDate: 1649041200,
              duedate: 1650510000,
              progress: 0.8,
              priority: 1,
            },
            {
              id: "04",
              title: "Test task 04",
              creationDate: 1650596400,
              duedate: 1651374000,
              progress: 0.5,
              priority: 2,
            },
            {
              id: "05",
              title: "Test task 05",
              creationDate: 1651719600,
              duedate: 1651892400,
              progress: 0.5,
              priority: 2,
            },
            {
              id: "06",
              title: "Test task 06",
              creationDate: 1652151600,
              duedate: 1652324400,
              progress: 0.5,
              priority: 1,
            },
          ],
        },
      ],
    };
  },
  methods: {
    handleUpdatedTasks: function ({ tasksUpdated }) {
      tasksUpdated.forEach((task) => {
        console.log("title: ", task.title);
        console.log("priority: ", task.priority);
        console.log("group: ", task.newGroup);
        console.log("creation: ", dateFormated(task.creationDate));
        console.log("due", dateFormated(task.duedate));
        console.log("\n");
      });
    },
    handleCutTasks: function ([firstTask, secondTask]) {
      console.log(firstTask);
      console.log(secondTask);
    },
  },
  mounted() {
    getOrdersByMaterials().then((materials) => (this.materials = materials));
  },
  components: {
    MyGraphs,
  },
};
</script>

<style>
#app {
  width: max-content;
}

* {
  box-sizing: border-box;
}
body {
  margin: 0;
}
</style>
