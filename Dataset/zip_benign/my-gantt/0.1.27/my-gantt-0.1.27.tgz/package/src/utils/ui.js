import { addDays, initDay } from "./date";

export const getOrderStateBg = ({ orderState, duedate, progress }) => {
  const diffDays = addDays(duedate, 2) > initDay(new Date().getTime() / 1000);

  if (orderState === "PRODUCTION" && progress !== 1 && diffDays <= 0) {
    return "danger";
  }

  return orderState === "PRODUCTION" ? "success" : "info";
};
