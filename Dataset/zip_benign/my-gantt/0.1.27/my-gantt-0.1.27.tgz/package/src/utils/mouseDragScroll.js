let isDown;
let spceKeyPress;

let pos = { top: 0, left: 0, x: 0, y: 0 };

export const mouseDragScroll = (elementSector) => {
  const element = document.querySelector(elementSector);

  const documentKeypressEvent = (e) => {
    if (e.keyCode == 32) {
      e.preventDefault();
      spceKeyPress = true;
      element.style.cursor = "move";
    }
  };

  const documentKeyupEvent = (e) => {
    if (e.keyCode == 32) {
      spceKeyPress = false;
      element.style.cursor = "initial";
    }
  };

  const elementMouseupEvent = () => {
    isDown = false;
  };

  const elementMousedownEvent = (e) => {
    isDown = true;

    pos = {
      // The current scroll
      left: element.scrollLeft,
      top: element.scrollTop,
      // Get the current mouse position
      x: e.clientX,
      y: e.clientY,
    };
  };

  const elementMousemoveEvent = (e) => {
    if (isDown && spceKeyPress) {
      e.preventDefault();

      const dx = e.clientX - pos.x;
      const dy = e.clientY - pos.y;

      element.scroll({
        top: pos.top - dy,
        left: pos.left - dx,
      });
    }
  };

  element.addEventListener("mouseup", elementMouseupEvent);
  element.addEventListener("mouseleave", elementMouseupEvent);

  document.addEventListener("keypress", documentKeypressEvent);
  document.addEventListener("keyup", documentKeyupEvent);

  element.addEventListener("mousedown", elementMousedownEvent);
  element.addEventListener("mousemove", elementMousemoveEvent);

  return () => {
    element.removeEventListener("mouseup", elementMouseupEvent);
    element.removeEventListener("mouseleave", elementMouseupEvent);

    document.removeEventListener("keypress", documentKeypressEvent);
    document.removeEventListener("keyup", documentKeyupEvent);

    element.removeEventListener("mousedown", elementMousedownEvent);
    element.removeEventListener("mousemove", elementMousemoveEvent);
  };
};
