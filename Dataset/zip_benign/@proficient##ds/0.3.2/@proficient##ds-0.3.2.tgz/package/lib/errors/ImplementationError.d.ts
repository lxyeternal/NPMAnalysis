export declare class ImplementationError extends Error {
    constructor();
}
