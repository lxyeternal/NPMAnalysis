export declare class IndexOutOfBoundsError extends Error {
}
