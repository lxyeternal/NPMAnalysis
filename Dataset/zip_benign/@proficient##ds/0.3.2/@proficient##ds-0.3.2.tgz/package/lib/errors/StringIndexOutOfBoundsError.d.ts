import { IndexOutOfBoundsError } from './IndexOutOfBoundsError';
export declare class StringIndexOutOfBoundsError extends IndexOutOfBoundsError {
    constructor(index: number, stringLength: number);
}
