export declare class NoSuchElementError extends Error {
}
