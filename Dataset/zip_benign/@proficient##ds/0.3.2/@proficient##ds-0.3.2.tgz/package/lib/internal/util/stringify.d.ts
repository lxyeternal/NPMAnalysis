import type { CharSequenceLike } from '../../types';
export declare function stringify(seq: CharSequenceLike): string;
