import type { Collection } from '../types';
export declare abstract class AbstractCollection<E> implements Collection<E> {
    get isEmpty(): boolean;
    /**
     * Converts the collection into a plain array.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(_N_)
     * - Space complexity: _O_(_N_)
     *
     * where:
     *
     * - _N_: number of items in the collection
     *
     * @returns A new array containing all the items in the collection.
     */
    toArray(): E[];
    protected throwNoSuchElementError(): void;
    protected throwImplementationError(): void;
    abstract count: number;
    abstract [Symbol.iterator](): Iterator<E>;
    abstract clear(): void;
}
