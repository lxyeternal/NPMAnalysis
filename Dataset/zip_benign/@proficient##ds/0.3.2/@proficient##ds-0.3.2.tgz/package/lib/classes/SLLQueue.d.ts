import type { Queue } from '../types';
import { AbstractCollection } from '../internal/AbstractCollection';
/**
 * A FIFO queue implemented with a singly-linked list.
 */
export declare class SLLQueue<E> extends AbstractCollection<E> implements Queue<E> {
    #private;
    get count(): number;
    constructor();
    [Symbol.iterator](): Iterator<E>;
    /**
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     */
    clear(): void;
    /**
     * Pushes an item to the queue.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     */
    enqueue(element: E): void;
    /**
     * Removes an item from the queue.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     *
     * @returns The dequeued item.
     *
     * @throws {@link NoSuchElementError} Thrown if the queue is empty.
     */
    dequeue(): E;
    /**
     * Retrieves, but does not remove, the head of this queue i.e. then item that will be
     * removed if `dequeue()` is called.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     *
     * @returns The head element.
     *
     * @throws {@link NoSuchElementError} Thrown if the queue is empty.
     */
    peek(): E;
}
