import { AbstractCollection } from '../internal';
/**
 * An object that can be used to efficiently store and manage the frequencies of
 * the specified keys.
 */
export declare class FrequencyTable<K extends string | number> extends AbstractCollection<[K, number]> {
    #private;
    /**
     * The sum of the frequencies of all the keys in the table.
     */
    get total(): number;
    /**
     * The number of keys whose frequency is positive.
     */
    get count(): number;
    constructor();
    [Symbol.iterator](): Iterator<[K, number]>;
    /**
     * Empties the table.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     */
    clear(): void;
    /**
     * Increases the frequency of the specified key by 1.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     *
     * @param key - The key whose frequency to increment.
     */
    increment(key: K): void;
    /**
     * If the frequency of the specified key is positive, decreases it by 1. Otherwise (if it's 0),
     * doesn't do anything.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     *
     * @param key - The key whose frequency to decrement.
     */
    decrement(key: K): void;
    /**
     * Retrieves the frequency of the specified key. Returns 0, if the key doesn't exist in the table.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     *
     * @param key - The key whose frequency to decrement.
     * @returns A non-negative integer indicating the frequency of the specified key.
     */
    frequencyOf(key: K): number;
}
