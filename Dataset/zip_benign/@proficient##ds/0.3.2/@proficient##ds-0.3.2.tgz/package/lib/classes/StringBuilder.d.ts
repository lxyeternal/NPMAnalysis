import type { CharSequenceLike } from '../types';
/**
 * An object that represents a mutable sequence of characters.
 */
export declare class StringBuilder {
    #private;
    /**
     * The number of characters in this sequence.
     */
    get count(): number;
    constructor();
    constructor(seq: string);
    /**
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     */
    clear(): void;
    /**
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     */
    charAt(index: number): string;
    /**
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(1)
     * - Space complexity: _O_(1)
     */
    setCharAt(index: number, char: string): this;
    /**
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(_N_) (worst case)
     * - Space complexity: _O_(1)
     *
     * where:
     *
     * - _N_: character count of this sequence
     */
    deleteCharAt(index: number): this;
    /**
     * @param startIndex - The beginning index, inclusive.
     * @param endIndex - The ending index, exclusive.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(_N_) (worst case)
     * - Space complexity: _O_(1)
     *
     * where:
     *
     * - _N_: character count of this sequence
     */
    delete(startIndex: number, endIndex: number): this;
    /**
     * Appends a sequence of characters to this sequence.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(_S_) (amortized)
     * - Space complexity: _O_(1) (amortized)
     *
     * where:
     *
     * - _S_: character count of the new sequence to be appended
     */
    append(seq: CharSequenceLike): this;
    /**
     * Inserts a sequence of characters into this sequence at the specified index.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(_N_ + _S_)
     * - Space complexity: _O_(1) (amortized)
     *
     * where:
     *
     * - _N_: character count of this sequence
     * - _S_: character count of the new sequence to be inserted
     */
    insert(index: number, seq: CharSequenceLike): this;
    /**
     * Builds and returns the character sequence represented by this object.
     *
     * @remarks
     *
     * **Complexity**:
     *
     * - Time complexity: _O_(_N_)
     * - Space complexity: _O_(_N_)
     *
     * where:
     *
     * - _N_: character count of this sequence
     */
    toString(): string;
}
