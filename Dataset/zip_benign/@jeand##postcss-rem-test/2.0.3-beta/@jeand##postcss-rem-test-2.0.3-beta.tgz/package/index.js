const { convert } = require('startijenn-rem');
const valueParser = require("postcss-value-parser");

const defaults = {
  name: "rem",
  fallback: false,
  convert: "rem",
  baseline: 16,
  precision: 5,
};
const processed = Symbol("postcss-rem-processed");

const convertValue = (node, convertFn) => {
  // If one of the node is a function, we cannot do anything until it has been resolved
  if (node.nodes.some(({ type }) => type === "function")) {
    return node;
  }

  const newValue = node.nodes
    .map(({ value, type }) => {
      const { number, unit } = valueParser.unit(value);
      if (type === "div") {
        return `${value} `;
      }
      if (number && ["px", "rem", "em"].includes(unit)) {
        return convertFn(value);
      }
      if (number && !unit && number !== "0") {
        return convertFn(parseFloat(number));
      }
      return value;
    })
    .join("");

  node.type = "word";
  node.value = newValue;
  return node;
};

const makeConvertValues = (convertFn, nameToTransform) => (parsedValue) =>
  parsedValue.walk((node) => {
    if (node.type !== "function") {
      return node;
    }
    if (node.value === nameToTransform) {
      return convertValue(node, convertFn);
    }
    return node;
  });

module.exports = (options = {}) => {
  const {
    name,
    fallback,
    convert: to,
    ...convertOptions
  } = { ...defaults, ...options };

  return {
    postcssPlugin: "postcss-rem",
    Declaration(decl) {
      if (
        decl[processed] ||
        (decl.value && decl.value.indexOf(`${name}(`) === -1)
      ) {
        return;
      }

      const parsedValue = valueParser(decl.value);
      const convertToRemValues = makeConvertValues(
        (value) => convert(value, "rem", convertOptions),
        name
      );
      const convertToPxValues = makeConvertValues(
        (value) => convert(value, "px", convertOptions),
        name
      );
      const convertFromOptions =
        to === "px" ? convertToPxValues : convertToRemValues;
      let newValue;
      try {
        newValue = valueParser.stringify(convertFromOptions(parsedValue));
      } catch (error) {
        throw decl.error(error.message);
      }

      if (newValue !== decl.value) {
        if (fallback && to !== "px") {
          decl.cloneAfter({ value: newValue });
          decl.value = valueParser.stringify(
            convertToPxValues(valueParser(decl.value))
          );
        } else {
          decl.value = newValue;
        }
        decl[processed] = true;
      }
    },
  };
};

module.exports.postcss = true;
