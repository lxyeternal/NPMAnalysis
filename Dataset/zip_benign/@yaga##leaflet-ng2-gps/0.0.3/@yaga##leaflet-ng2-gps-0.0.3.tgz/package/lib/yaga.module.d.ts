export declare class YagaGpsModule {
}
