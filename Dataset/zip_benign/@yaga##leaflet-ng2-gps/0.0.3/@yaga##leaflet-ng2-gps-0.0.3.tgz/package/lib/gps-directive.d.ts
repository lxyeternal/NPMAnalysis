import { AfterContentInit, QueryList } from "@angular/core";
import { CircleDirective, CircleMarkerDirective, MarkerDirective } from "@yaga/leaflet-ng2";
import { GpsService } from "./gps-service";
/**
 * GPS component
 * TODO: @example https://leaflet-ng2.yagajs.org/latest/examples/tile-layer-directive
 */
export declare class GpsDirective implements AfterContentInit {
    gpsService: GpsService;
    /**
     * Available content children of Circle directives
     */
    circleDirectives: QueryList<CircleDirective<any>>;
    /**
     * Available content children of CircleMarker directives
     */
    circleMarkerDirectives: QueryList<CircleMarkerDirective<any>>;
    /**
     * Available content children of Marker directives
     */
    markerDirectives: QueryList<MarkerDirective>;
    /**
     * Display state of all directives (Circle, CircleMarker, Marker) under the yaga-gps directive
     */
    display: boolean;
    /**
     * GPS state for this directive
     */
    active: boolean;
    /**
     * Internally stored value for the active state
     */
    private activeState;
    /**
     * Internally stored value for the display state
     */
    private displayState;
    constructor(gpsService: GpsService);
    /**
     * This function gets called from Angular after initializing the html-component.
     * @link https://angular.io/docs/ts/latest/api/core/index/AfterContentInit-interface.html
     */
    ngAfterContentInit(): void;
}
