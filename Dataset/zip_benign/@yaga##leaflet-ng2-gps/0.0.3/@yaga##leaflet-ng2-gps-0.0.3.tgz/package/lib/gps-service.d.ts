import { EventEmitter } from "@angular/core";
export declare class GpsService {
    /**
     * Last returned position
     */
    position: Position;
    /**
     * EventEmitter that fires the current geo position
     */
    positionChange: EventEmitter<Position>;
    /**
     * EventEmitter that fires the error if some occurs during observing
     */
    error: EventEmitter<PositionError>;
    /**
     * Internal stored value of the highAccuracy state
     */
    protected highAccuracy: boolean;
    /**
     * Internal stored value for maximumAge
     */
    protected maximumAge: number;
    /**
     * Internal stored value for timeout
     */
    protected timeout: number;
    /**
     * Internal stored identifier for watchPosition
     * @link https://www.w3.org/TR/geolocation-API/#watch-position
     */
    private watchId;
    /**
     * Startobseriving the geolocation
     */
    start(): Promise<Position>;
    /**
     * Stops observing geo-location. Returns false in promise when it was not watching
     */
    stop(): Promise<boolean>;
    /**
     * Enables the GPS high accuracy mode
     * @link https://www.w3.org/TR/geolocation-API/#position_options_interface
     */
    enableHighAccuracy(): void;
    /**
     * Disables the GPS high accuracy mode
     * @link https://www.w3.org/TR/geolocation-API/#position_options_interface
     */
    disableHighAccuracy(): void;
    /**
     * The timeout attribute denotes the maximum length of time (expressed in milliseconds) that is allowed to pass from
     * the request until the corresponding retrieval of coordinates is invoked.
     * @link https://www.w3.org/TR/geolocation-API/#position_options_interface
     */
    setTimeout(val: number): void;
    /**
     * The maximumAge attribute indicates that the application is willing to accept a cached position whose age is no
     * greater than the specified time in milliseconds.
     * @link https://www.w3.org/TR/geolocation-API/#position_options_interface
     */
    setMaximumAge(val: number): void;
    /**
     * Reinitialize the Geolocation-API after changing its options
     */
    protected reload(): Promise<Position>;
}
