import * as i0 from '@angular/core';
import * as i1 from './yaga.module';
export declare const YagaGpsModuleNgFactory: i0.NgModuleFactory<i1.YagaGpsModule>;
