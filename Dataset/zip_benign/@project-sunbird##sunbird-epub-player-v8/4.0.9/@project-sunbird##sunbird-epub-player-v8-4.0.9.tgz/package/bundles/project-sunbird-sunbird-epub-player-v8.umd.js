(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@project-sunbird/client-services/telemetry'), require('@angular/common/http'), require('@project-sunbird/sunbird-player-sdk-v8'), require('epubjs'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@project-sunbird/sunbird-epub-player-v8', ['exports', '@angular/core', '@project-sunbird/client-services/telemetry', '@angular/common/http', '@project-sunbird/sunbird-player-sdk-v8', 'epubjs', '@angular/common'], factory) :
    (global = global || self, factory((global['project-sunbird'] = global['project-sunbird'] || {}, global['project-sunbird']['sunbird-epub-player-v8'] = {}), global.ng.core, global.telemetry, global.ng.common.http, global.sunbirdPlayerSdkV8, global.Epub, global.ng.common));
}(this, (function (exports, core, telemetry, http, sunbirdPlayerSdkV8, Epub, common) { 'use strict';

    Epub = Epub && Epub.hasOwnProperty('default') ? Epub['default'] : Epub;

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __createBinding(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
    }

    function __exportStar(m, exports) {
        for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/sunbird-epub.constant.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @enum {string} */
    var epubPlayerConstants = {
        LOADING: "LOADING",
        START: "START",
        END: "END",
        EPUBLOADED: "epubLoaded",
        PAGECHANGE: "pageChange",
        NEXT: "NEXT",
        PREVIOUS: "PREVIOUS",
        ERROR: "error",
        UNABLE_TO_FETCH_URL_ONLINE: "Internet is avialable but unable to fetch the url",
    };
    /** @enum {string} */
    var telemetryType = {
        INTERACT: "INTERACT",
        IMPRESSION: "IMPRESSION",
    };

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/services/utilService/util.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var UtilService = /** @class */ (function () {
        function UtilService() {
            this.fromConst = epubPlayerConstants;
        }
        /**
         * @param {?=} length
         * @return {?}
         */
        UtilService.prototype.uniqueId = /**
         * @param {?=} length
         * @return {?}
         */
        function (length) {
            if (length === void 0) { length = 32; }
            /** @type {?} */
            var result = '';
            /** @type {?} */
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            /** @type {?} */
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            return result;
        };
        /**
         * @param {?} pdfPlayerStartTime
         * @return {?}
         */
        UtilService.prototype.getTimeSpentText = /**
         * @param {?} pdfPlayerStartTime
         * @return {?}
         */
        function (pdfPlayerStartTime) {
            /** @type {?} */
            var duration = new Date().getTime() - pdfPlayerStartTime;
            /** @type {?} */
            var minutes = Math.floor(duration / 60000);
            /** @type {?} */
            var seconds = Number(((duration % 60000) / 1000).toFixed(0));
            return (minutes + ':' + (seconds < 10 ? '0' : '') + seconds);
        };
        /**
         * @param {?} event
         * @param {?} currentPageIndex
         * @return {?}
         */
        UtilService.prototype.getCurrentIndex = /**
         * @param {?} event
         * @param {?} currentPageIndex
         * @return {?}
         */
        function (event, currentPageIndex) {
            if (event['interaction'] === this.fromConst.NEXT) {
                return currentPageIndex + 1;
            }
            if (event['interaction'] === this.fromConst.PREVIOUS) {
                return currentPageIndex - 1 == 0 ? 1 : currentPageIndex - 1;
            }
        };
        UtilService.decorators = [
            { type: core.Injectable, args: [{
                        providedIn: 'root'
                    },] }
        ];
        /** @nocollapse */
        UtilService.ctorParameters = function () { return []; };
        /** @nocollapse */ UtilService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function UtilService_Factory() { return new UtilService(); }, token: UtilService, providedIn: "root" });
        return UtilService;
    }());
    if (false) {
        /** @type {?} */
        UtilService.prototype.fromConst;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/sunbird-epub-player.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var EpubPlayerService = /** @class */ (function () {
        function EpubPlayerService(utilService) {
            this.utilService = utilService;
            this.contentSessionId = this.utilService.uniqueId();
        }
        /**
         * @param {?} __0
         * @return {?}
         */
        EpubPlayerService.prototype.initialize = /**
         * @param {?} __0
         * @return {?}
         */
        function (_a) {
            var context = _a.context, config = _a.config, metadata = _a.metadata;
            this.context = context;
            this.config = config;
            this.playSessionId = this.utilService.uniqueId();
            this.channel = this.context.channel;
            this.pdata = this.context.pdata;
            this.sid = this.context.sid;
            this.uid = this.context.uid;
            this.rollup = this.context.rollup;
            if (!telemetry.CsTelemetryModule.instance.isInitialised) {
                telemetry.CsTelemetryModule.instance.init({});
                /** @type {?} */
                var telemetryConfig = {
                    config: {
                        pdata: context.pdata,
                        env: 'contentplayer',
                        channel: context.channel,
                        did: context.did,
                        authtoken: context.authToken || '',
                        uid: context.uid || '',
                        sid: context.sid,
                        batchsize: 20,
                        mode: context.mode,
                        host: context.host || '',
                        endpoint: context.endpoint || '/data/v3/telemetry',
                        tags: context.tags,
                        cdata: (context.cdata || []).concat([{ id: this.contentSessionId, type: 'ContentSession' },
                            { id: this.playSessionId, type: 'PlaySession' },
                            { id: "2.0", type: "PlayerVersion" }])
                    },
                    userOrgDetails: {}
                };
                if (context.dispatcher) {
                    telemetryConfig.config.dispatcher = context.dispatcher;
                }
                telemetry.CsTelemetryModule.instance.telemetryService.initTelemetry(telemetryConfig);
            }
            this.telemetryObject = {
                id: metadata.identifier,
                type: 'Content',
                ver: metadata.pkgVersion + '' || '1.0',
                rollup: context.objectRollup || {}
            };
        };
        /**
         * @param {?} duration
         * @return {?}
         */
        EpubPlayerService.prototype.start = /**
         * @param {?} duration
         * @return {?}
         */
        function (duration) {
            telemetry.CsTelemetryModule.instance.telemetryService.raiseStartTelemetry({
                options: this.getEventOptions(),
                edata: { type: 'content', mode: 'play', pageid: '', duration: Number((duration / 1e3).toFixed(2)) }
            });
        };
        /**
         * @param {?} id
         * @param {?} currentPage
         * @return {?}
         */
        EpubPlayerService.prototype.interact = /**
         * @param {?} id
         * @param {?} currentPage
         * @return {?}
         */
        function (id, currentPage) {
            telemetry.CsTelemetryModule.instance.telemetryService.raiseInteractTelemetry({
                options: this.getEventOptions(),
                edata: { type: 'TOUCH', subtype: '', id: id, pageid: currentPage + '' }
            });
        };
        /**
         * @param {?} currentPage
         * @return {?}
         */
        EpubPlayerService.prototype.impression = /**
         * @param {?} currentPage
         * @return {?}
         */
        function (currentPage) {
            telemetry.CsTelemetryModule.instance.telemetryService.raiseImpressionTelemetry({
                options: this.getEventOptions(),
                edata: { type: 'workflow', subtype: '', pageid: currentPage + '', uri: '' }
            });
        };
        /**
         * @param {?} duration
         * @param {?} percentage
         * @param {?} curentPage
         * @param {?} endpageseen
         * @return {?}
         */
        EpubPlayerService.prototype.end = /**
         * @param {?} duration
         * @param {?} percentage
         * @param {?} curentPage
         * @param {?} endpageseen
         * @return {?}
         */
        function (duration, percentage, curentPage, endpageseen) {
            /** @type {?} */
            var durationSec = Number((duration / 1e3).toFixed(2));
            telemetry.CsTelemetryModule.instance.telemetryService.raiseEndTelemetry({
                edata: {
                    type: 'content',
                    mode: 'play',
                    pageid: 'sunbird-player-Endpage',
                    summary: [
                        {
                            progress: percentage
                        },
                        {
                            totallength: (percentage === 100 ? curentPage : 1)
                        },
                        {
                            visitedlength: curentPage
                        },
                        {
                            visitedcontentend: (percentage === 100)
                        },
                        {
                            totalseekedlength: 0
                        },
                        {
                            endpageseen: endpageseen
                        }
                    ],
                    duration: durationSec
                },
                options: this.getEventOptions()
            });
        };
        /**
         * @param {?} errorCode
         * @param {?} errorType
         * @param {?} pageid
         * @param {?} stacktrace
         * @return {?}
         */
        EpubPlayerService.prototype.error = /**
         * @param {?} errorCode
         * @param {?} errorType
         * @param {?} pageid
         * @param {?} stacktrace
         * @return {?}
         */
        function (errorCode, errorType, pageid, stacktrace) {
            telemetry.CsTelemetryModule.instance.telemetryService.raiseErrorTelemetry({
                options: this.getEventOptions(),
                edata: {
                    err: errorCode,
                    errtype: errorType,
                    stacktrace: stacktrace.toString(),
                    pageid: pageid || ''
                }
            });
        };
        /**
         * @private
         * @return {?}
         */
        EpubPlayerService.prototype.getEventOptions = /**
         * @private
         * @return {?}
         */
        function () {
            return ({
                object: this.telemetryObject,
                context: {
                    channel: this.channel,
                    pdata: this.pdata,
                    env: 'contentplayer',
                    sid: this.sid,
                    uid: this.uid,
                    cdata: (this.context.cdata || []).concat([{ id: this.contentSessionId, type: 'ContentSession' },
                        { id: this.playSessionId, type: 'PlaySession' },
                        { id: "2.0", type: "PlayerVersion" }]),
                    rollup: this.rollup || {}
                }
            });
        };
        EpubPlayerService.decorators = [
            { type: core.Injectable, args: [{
                        providedIn: 'root'
                    },] }
        ];
        /** @nocollapse */
        EpubPlayerService.ctorParameters = function () { return [
            { type: UtilService }
        ]; };
        /** @nocollapse */ EpubPlayerService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function EpubPlayerService_Factory() { return new EpubPlayerService(core.ɵɵinject(UtilService)); }, token: EpubPlayerService, providedIn: "root" });
        return EpubPlayerService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        EpubPlayerService.prototype.contentSessionId;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerService.prototype.playSessionId;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerService.prototype.telemetryObject;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerService.prototype.context;
        /** @type {?} */
        EpubPlayerService.prototype.config;
        /** @type {?} */
        EpubPlayerService.prototype.channel;
        /** @type {?} */
        EpubPlayerService.prototype.pdata;
        /** @type {?} */
        EpubPlayerService.prototype.sid;
        /** @type {?} */
        EpubPlayerService.prototype.uid;
        /** @type {?} */
        EpubPlayerService.prototype.rollup;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerService.prototype.utilService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/services/viewerService/viwer-service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ViwerService = /** @class */ (function () {
        function ViwerService(utilService, epubPlayerService, http) {
            this.utilService = utilService;
            this.epubPlayerService = epubPlayerService;
            this.http = http;
            this.currentIndex = 0;
            this.totalNumberOfPages = 0;
            this.endPageSeen = false;
            this.timeSpent = '0:0';
            this.version = '1.0';
            this.playerEvent = new core.EventEmitter();
            this.isAvailableLocally = false;
        }
        /**
         * @param {?} __0
         * @return {?}
         */
        ViwerService.prototype.initialize = /**
         * @param {?} __0
         * @return {?}
         */
        function (_a) {
            var context = _a.context, config = _a.config, metadata = _a.metadata;
            this.epubPlayerStartTime = this.epubLastPageTime = new Date().getTime();
            this.totalNumberOfPages = 0;
            this.currentIndex = 0;
            this.contentName = metadata.name;
            this.identifier = metadata.identifier;
            this.artifactUrl = metadata.artifactUrl;
            this.isAvailableLocally = metadata.isAvailableLocally;
            if (this.isAvailableLocally) {
                /** @type {?} */
                var basePath = (metadata.streamingUrl) ? (metadata.streamingUrl) : (metadata.basePath || metadata.baseDir);
                this.src = basePath + "/" + metadata.artifactUrl;
            }
            else {
                this.src = metadata.streamingUrl || metadata.artifactUrl;
            }
            if (context.userData) {
                var _b = context.userData, firstName = _b.firstName, lastName = _b.lastName;
                this.userName = firstName === lastName ? firstName : firstName + " " + lastName;
            }
            this.metaData = {
                pagesVisited: [],
                totalPages: 0,
                duration: [],
                zoom: [],
                rotation: []
            };
            this.showDownloadPopup = false;
            this.endPageSeen = false;
        };
        /**
         * @param {?} event
         * @return {?}
         */
        ViwerService.prototype.raiseStartEvent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.currentIndex = event.items[0].index;
            /** @type {?} */
            var duration = new Date().getTime() - this.epubPlayerStartTime;
            /** @type {?} */
            var startEvent = {
                eid: 'START',
                ver: this.version,
                edata: {
                    type: 'START',
                    currentPage: this.currentIndex,
                    duration: duration
                },
                metaData: this.metaData
            };
            this.playerEvent.emit(startEvent);
            this.epubLastPageTime = this.epubPlayerStartTime = new Date().getTime();
            this.epubPlayerService.start(duration);
        };
        /**
         * @param {?} event
         * @param {?=} teleType
         * @return {?}
         */
        ViwerService.prototype.raiseHeartBeatEvent = /**
         * @param {?} event
         * @param {?=} teleType
         * @return {?}
         */
        function (event, teleType) {
            if (event.data) {
                this.currentIndex = event.data.index;
            }
            /** @type {?} */
            var eventType = event.type ? event.type : event;
            /** @type {?} */
            var heartBeatEvent = {
                eid: 'HEARTBEAT',
                ver: this.version,
                edata: {
                    type: eventType,
                    currentPage: this.currentIndex
                },
                metaData: this.metaData
            };
            this.playerEvent.emit(heartBeatEvent);
            if (telemetryType.IMPRESSION === teleType) {
                this.epubPlayerService.impression(this.currentIndex);
            }
            if (telemetryType.INTERACT === teleType) {
                this.epubPlayerService.interact(eventType.toLowerCase(), this.currentIndex);
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        ViwerService.prototype.raiseEndEvent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.currentIndex = event.data.index;
            /** @type {?} */
            var percentage = event.data.percentage || 0;
            if (event.data.percentage) {
                this.endPageSeen = true;
            }
            /** @type {?} */
            var duration = new Date().getTime() - this.epubPlayerStartTime;
            /** @type {?} */
            var endEvent = {
                eid: 'END',
                ver: this.version,
                edata: {
                    type: 'END',
                    currentPage: event.data.index,
                    totalPages: this.currentIndex,
                    duration: duration
                },
                metaData: this.metaData
            };
            this.playerEvent.emit(endEvent);
            /** @type {?} */
            var visitedlength = this.currentIndex;
            this.timeSpent = this.utilService.getTimeSpentText(this.epubPlayerStartTime);
            this.epubPlayerService.end(duration, percentage, this.currentIndex, this.endPageSeen);
        };
        /**
         * @param {?} errorCode
         * @param {?} pageIndex
         * @param {?} errorType
         * @param {?} traceId
         * @param {?} stacktrace
         * @return {?}
         */
        ViwerService.prototype.raiseExceptionLog = /**
         * @param {?} errorCode
         * @param {?} pageIndex
         * @param {?} errorType
         * @param {?} traceId
         * @param {?} stacktrace
         * @return {?}
         */
        function (errorCode, pageIndex, errorType, traceId, stacktrace) {
            /** @type {?} */
            var exceptionLogEvent = {
                eid: "ERROR",
                edata: {
                    err: errorCode,
                    errtype: errorType,
                    requestid: traceId || '',
                    stacktrace: stacktrace
                }
            };
            this.playerEvent.emit(exceptionLogEvent);
            this.epubPlayerService.error(errorCode, errorType, pageIndex, stacktrace);
        };
        /**
         * @param {?} src
         * @return {?}
         */
        ViwerService.prototype.isValidEpubSrc = /**
         * @param {?} src
         * @return {?}
         */
        function (src) {
            var _this = this;
            return new Promise((/**
             * @param {?} resolve
             * @param {?} reject
             * @return {?}
             */
            function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    this.http.get(src, { responseType: 'blob' }).toPromise().then((/**
                     * @param {?} res
                     * @return {?}
                     */
                    function (res) {
                        resolve(res);
                    })).catch((/**
                     * @param {?} error
                     * @return {?}
                     */
                    function (error) {
                        reject(error);
                    }));
                    return [2 /*return*/];
                });
            }); }));
        };
        ViwerService.decorators = [
            { type: core.Injectable, args: [{
                        providedIn: 'root'
                    },] }
        ];
        /** @nocollapse */
        ViwerService.ctorParameters = function () { return [
            { type: UtilService },
            { type: EpubPlayerService },
            { type: http.HttpClient }
        ]; };
        /** @nocollapse */ ViwerService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function ViwerService_Factory() { return new ViwerService(core.ɵɵinject(UtilService), core.ɵɵinject(EpubPlayerService), core.ɵɵinject(http.HttpClient)); }, token: ViwerService, providedIn: "root" });
        return ViwerService;
    }());
    if (false) {
        /** @type {?} */
        ViwerService.prototype.currentIndex;
        /** @type {?} */
        ViwerService.prototype.totalNumberOfPages;
        /** @type {?} */
        ViwerService.prototype.epubPlayerStartTime;
        /** @type {?} */
        ViwerService.prototype.epubLastPageTime;
        /** @type {?} */
        ViwerService.prototype.endPageSeen;
        /** @type {?} */
        ViwerService.prototype.timeSpent;
        /**
         * @type {?}
         * @private
         */
        ViwerService.prototype.version;
        /** @type {?} */
        ViwerService.prototype.playerEvent;
        /** @type {?} */
        ViwerService.prototype.contentName;
        /** @type {?} */
        ViwerService.prototype.loadingProgress;
        /** @type {?} */
        ViwerService.prototype.showDownloadPopup;
        /** @type {?} */
        ViwerService.prototype.src;
        /** @type {?} */
        ViwerService.prototype.userName;
        /**
         * @type {?}
         * @private
         */
        ViwerService.prototype.metaData;
        /** @type {?} */
        ViwerService.prototype.identifier;
        /** @type {?} */
        ViwerService.prototype.artifactUrl;
        /** @type {?} */
        ViwerService.prototype.isAvailableLocally;
        /**
         * @type {?}
         * @private
         */
        ViwerService.prototype.utilService;
        /**
         * @type {?}
         * @private
         */
        ViwerService.prototype.epubPlayerService;
        /**
         * @type {?}
         * @private
         */
        ViwerService.prototype.http;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/sunbird-epub-player.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var EpubPlayerComponent = /** @class */ (function () {
        function EpubPlayerComponent(viwerService, epubPlayerService, errorService, utilService, renderer2) {
            this.viwerService = viwerService;
            this.epubPlayerService = epubPlayerService;
            this.errorService = errorService;
            this.utilService = utilService;
            this.renderer2 = renderer2;
            this.fromConst = epubPlayerConstants;
            this.headerActionsEvent = new core.EventEmitter();
            this.telemetryEvent = new core.EventEmitter();
            this.showControls = true;
            this.sideMenuConfig = {
                showShare: true,
                showDownload: true,
                showReplay: false,
                showExit: false,
                showPrint: true
            };
            this.viewState = this.fromConst.LOADING;
            this.progress = 0;
            this.currentPageIndex = 1;
            this.headerConfiguration = {
                rotation: false,
                goto: false,
                navigation: true,
                zoom: false
            };
            this.playerEvent = this.viwerService.playerEvent;
        }
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.onTelemetryEvent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.telemetryEvent.emit(event.detail);
        };
        /**
         * @return {?}
         */
        EpubPlayerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            return __awaiter(this, void 0, void 0, function () {
                var contentCompabilityLevel, checkContentCompatible;
                return __generator(this, function (_a) {
                    // initializing services
                    this.viwerService.initialize(this.playerConfig);
                    this.epubPlayerService.initialize(this.playerConfig);
                    this.traceId = this.playerConfig.config['traceId'];
                    // checks online error while loading epub
                    if (!navigator.onLine && !this.viwerService.isAvailableLocally) {
                        this.viwerService.raiseExceptionLog(sunbirdPlayerSdkV8.errorCode.internetConnectivity, this.currentPageIndex, sunbirdPlayerSdkV8.errorMessage.internetConnectivity, this.traceId, new Error(sunbirdPlayerSdkV8.errorMessage.internetConnectivity));
                    }
                    // checks content compatibility error
                    contentCompabilityLevel = this.playerConfig.metadata['compatibilityLevel'];
                    if (contentCompabilityLevel) {
                        checkContentCompatible = this.errorService.checkContentCompatibility(contentCompabilityLevel);
                        if (!checkContentCompatible['isCompitable']) {
                            this.viwerService.raiseExceptionLog(sunbirdPlayerSdkV8.errorCode.contentCompatibility, this.currentPageIndex, sunbirdPlayerSdkV8.errorCode.contentCompatibility, this.traceId, checkContentCompatible['error']);
                        }
                    }
                    this.showEpubViewer = true;
                    this.sideMenuConfig = __assign({}, this.sideMenuConfig, this.playerConfig.config.sideMenu);
                    this.getEpubLoadingProgress();
                    return [2 /*return*/];
                });
            });
        };
        /**
         * @return {?}
         */
        EpubPlayerComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var epubPlayerElement = this.epubPlayerRef.nativeElement;
            this.unlistenMouseEnter = this.renderer2.listen(epubPlayerElement, 'mouseenter', (/**
             * @return {?}
             */
            function () {
                _this.showControls = true;
            }));
            this.unlistenMouseLeave = this.renderer2.listen(epubPlayerElement, 'mouseleave', (/**
             * @return {?}
             */
            function () {
                _this.showControls = false;
            }));
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.headerActions = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.headerActionsEvent.emit(event.type);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.viewerEvent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            if (event.type === this.fromConst.EPUBLOADED) {
                this.onEpubLoaded(event);
            }
            if (event.type === this.fromConst.PAGECHANGE) {
                this.onPageChange(event);
            }
            if (event.type === this.fromConst.END) {
                this.onEpubEnded(event);
            }
            if (event.type === this.fromConst.ERROR) {
                this.onEpubLoadFailed(event);
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.onEpubLoaded = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            clearInterval(this.intervalRef);
            this.viewState = this.fromConst.START;
            this.viwerService.raiseStartEvent(event.data);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.onPageChange = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.currentPageIndex = this.utilService.getCurrentIndex(event, this.currentPageIndex);
            this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
            this.viwerService.raiseHeartBeatEvent(event, telemetryType.IMPRESSION);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.onEpubEnded = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.viewState = this.fromConst.END;
            this.showEpubViewer = false;
            event.data.index = this.currentPageIndex;
            this.viwerService.raiseEndEvent(event);
        };
        /**
         * @param {?} error
         * @return {?}
         */
        EpubPlayerComponent.prototype.onEpubLoadFailed = /**
         * @param {?} error
         * @return {?}
         */
        function (error) {
            this.showContentError = true;
            this.viewState = this.fromConst.LOADING;
            this.viwerService.raiseExceptionLog(error.errorCode, this.currentPageIndex, error.errorMessage, this.traceId, new Error(error.errorMessage));
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.replayContent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.currentPageIndex = 1;
            this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
            this.viewState = this.fromConst.START;
            this.ngOnInit();
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.exitContent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.sideBarEvents = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
            if (event === 'DOWNLOAD') {
                this.downloadEpub();
            }
        };
        /**
         * @param {?} event
         * @return {?}
         */
        EpubPlayerComponent.prototype.sidebarMenuEvent = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
        };
        /**
         * @return {?}
         */
        EpubPlayerComponent.prototype.getEpubLoadingProgress = /**
         * @return {?}
         */
        function () {
            var _this = this;
            this.intervalRef = setInterval((/**
             * @return {?}
             */
            function () {
                if (_this.progress < 95) {
                    _this.progress = _this.progress + 5;
                }
            }), 10);
        };
        /**
         * @return {?}
         */
        EpubPlayerComponent.prototype.downloadEpub = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var a = document.createElement('a');
            a.href = this.viwerService.artifactUrl;
            a.download = this.viwerService.contentName;
            a.target = '_blank';
            document.body.appendChild(a);
            a.click();
            a.remove();
            this.viwerService.raiseHeartBeatEvent('DOWNLOAD');
        };
        /**
         * @return {?}
         */
        EpubPlayerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var EndEvent = {
                type: this.fromConst.END,
                data: {
                    index: this.currentPageIndex
                }
            };
            this.viwerService.raiseEndEvent(EndEvent);
            this.unlistenMouseEnter();
            this.unlistenMouseLeave();
        };
        EpubPlayerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'sunbird-epub-player',
                        template: "<div class=\"sunbird-epub-container\" #epubPlayer>\n<div *ngIf=\"viewState === fromConst.LOADING\">\n    <sb-player-start-page [title]=\"viwerService.contentName\" [progress]=\"progress\"></sb-player-start-page>\n</div>\n<div class=\"epub-container\" *ngIf=\"showEpubViewer\">\n    <ng-container *ngIf=\"viewState === fromConst.START\">\n        <sb-player-header class=\"notVisible\" [config]=\"headerConfiguration\" (actions)=\"headerActions($event)\" [ngClass]=\"{'isVisible': showControls}\"></sb-player-header>\n        <sb-player-side-menu-icon class=\"notVisible\"  [ngClass]=\"{'isVisible': showControls}\" (sidebarMenuEvent)=\"sidebarMenuEvent($event)\">\n        </sb-player-side-menu-icon>\n        <sb-player-sidebar [title]=\"viwerService.contentName\" (sidebarEvent)=\"sideBarEvents($event)\"\n            [config]=\"sideMenuConfig\"></sb-player-sidebar>\n        <div class=\"sb-epub-reading-status\">\n            Location {{currentPageIndex}} \n        </div>\n        \n    </ng-container>\n    <epub-viewer  [actions]=\"headerActionsEvent\" [epubSrc]=\"viwerService.src\" [identifier]=\"viwerService.identifier\"\n        (viewerEvent)=\"viewerEvent($event)\">\n    </epub-viewer>\n</div>\n<sb-player-end-page *ngIf=\"viewState === fromConst.END\" [contentName]=\"viwerService.contentName\"\n    [outcomeLabel]=\"'Pages read: '\" [outcome]=\"(currentPageIndex -1)\" [showExit]=\"sideMenuConfig.showExit\" [userName]=\"viwerService.userName\"\n    [timeSpentLabel]=\"viwerService.timeSpent\" (replayContent)=\"replayContent($event)\" (exitContent)=\"exitContent($event)\">\n</sb-player-end-page>\n<sb-player-contenterror *ngIf=\"showContentError\"></sb-player-contenterror>\n</div>\n",
                        styles: [".sunbird-epub-container{height:100%;width:100%;background-color:#fff}.sunbird-epub-palyer-container{width:100%;height:100%;overflow:hidden;position:relative}.sb-epub-reading-status{color:var(--gray-800);font-size:.75rem;position:absolute;left:1rem;bottom:.75rem;display:flex;align-items:center;background:var(--white);border-radius:.5rem;padding:.25em .5rem;z-index:5;line-height:normal}.BtmNotVisible,.notVisible{transition:.3s ease-in-out;position:absolute;width:100%}.notVisible{top:-10rem}.notVisible.isVisible{top:0}.BtmNotVisible{bottom:-10rem}.BtmNotVisible.isVisible{bottom:0}:host::ng-deep .sb-player-splash-container{height:100vh!important}:host::ng-deep epub-viewer{position:absolute;top:48px;width:100%;height:calc(100% - 48px);overflow-y:auto;overflow-x:hidden;left:0;background-color:#fff}:host::ng-deep .epub-container{height:100%;position:relative;overflow-x:hidden!important}"]
                    }] }
        ];
        /** @nocollapse */
        EpubPlayerComponent.ctorParameters = function () { return [
            { type: ViwerService },
            { type: EpubPlayerService },
            { type: sunbirdPlayerSdkV8.ErrorService },
            { type: UtilService },
            { type: core.Renderer2 }
        ]; };
        EpubPlayerComponent.propDecorators = {
            epubPlayerRef: [{ type: core.ViewChild, args: ['epubPlayer', { static: true },] }],
            playerConfig: [{ type: core.Input }],
            headerActionsEvent: [{ type: core.Output }],
            telemetryEvent: [{ type: core.Output }],
            playerEvent: [{ type: core.Output }],
            onTelemetryEvent: [{ type: core.HostListener, args: ['document:TelemetryEvent', ['$event'],] }],
            ngOnDestroy: [{ type: core.HostListener, args: ['window:beforeunload',] }]
        };
        return EpubPlayerComponent;
    }());
    if (false) {
        /** @type {?} */
        EpubPlayerComponent.prototype.fromConst;
        /** @type {?} */
        EpubPlayerComponent.prototype.epubPlayerRef;
        /** @type {?} */
        EpubPlayerComponent.prototype.playerConfig;
        /** @type {?} */
        EpubPlayerComponent.prototype.headerActionsEvent;
        /** @type {?} */
        EpubPlayerComponent.prototype.telemetryEvent;
        /** @type {?} */
        EpubPlayerComponent.prototype.playerEvent;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerComponent.prototype.unlistenMouseEnter;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerComponent.prototype.unlistenMouseLeave;
        /** @type {?} */
        EpubPlayerComponent.prototype.showControls;
        /** @type {?} */
        EpubPlayerComponent.prototype.showContentError;
        /** @type {?} */
        EpubPlayerComponent.prototype.sideMenuConfig;
        /** @type {?} */
        EpubPlayerComponent.prototype.viewState;
        /** @type {?} */
        EpubPlayerComponent.prototype.intervalRef;
        /** @type {?} */
        EpubPlayerComponent.prototype.progress;
        /** @type {?} */
        EpubPlayerComponent.prototype.showEpubViewer;
        /** @type {?} */
        EpubPlayerComponent.prototype.traceId;
        /** @type {?} */
        EpubPlayerComponent.prototype.currentPageIndex;
        /** @type {?} */
        EpubPlayerComponent.prototype.headerConfiguration;
        /** @type {?} */
        EpubPlayerComponent.prototype.viwerService;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerComponent.prototype.epubPlayerService;
        /** @type {?} */
        EpubPlayerComponent.prototype.errorService;
        /** @type {?} */
        EpubPlayerComponent.prototype.utilService;
        /**
         * @type {?}
         * @private
         */
        EpubPlayerComponent.prototype.renderer2;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/epub-viewer/epub-viewer.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var EpubViewerComponent = /** @class */ (function () {
        function EpubViewerComponent(viwerService) {
            this.viwerService = viwerService;
            this.actions = new core.EventEmitter();
            this.viewerEvent = new core.EventEmitter();
        }
        /**
         * @return {?}
         */
        EpubViewerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.idForRendition = this.identifier + "-content";
        };
        /**
         * @return {?}
         */
        EpubViewerComponent.prototype.ngAfterViewInit = /**
         * @return {?}
         */
        function () {
            return __awaiter(this, void 0, void 0, function () {
                var _a, spine_1, error_1;
                var _this = this;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            _b.trys.push([0, 5, , 6]);
                            if (!!this.viwerService.isAvailableLocally) return [3 /*break*/, 2];
                            _a = this;
                            return [4 /*yield*/, this.viwerService.isValidEpubSrc(this.epubSrc)];
                        case 1:
                            _a.epubBlob = _b.sent();
                            this.eBook = Epub(this.epubBlob);
                            return [3 /*break*/, 3];
                        case 2:
                            if (this.viwerService.isAvailableLocally) {
                                this.eBook = Epub(this.epubSrc);
                            }
                            _b.label = 3;
                        case 3:
                            this.rendition = this.eBook.renderTo(this.idForRendition, {
                                flow: "paginated",
                                width: this.epubViewer.nativeElement.offsetWidth,
                                height: this.epubViewer.nativeElement.offsetHeight
                            });
                            this.rendition.display();
                            this.rendition.on("layout", (/**
                             * @param {?} layout
                             * @return {?}
                             */
                            function (layout) {
                                if (_this.eBook.navigation.length > 2) {
                                    _this.rendition.spread("none");
                                    _this.rendition.flow("scrolled");
                                    _this.scrolled = true;
                                }
                                else {
                                    _this.rendition.spread("auto");
                                    _this.scrolled = false;
                                }
                            }));
                            this.rendition.on('displayError', (/**
                             * @param {?} error
                             * @return {?}
                             */
                            function (error) {
                                _this.viewerEvent.emit({
                                    type: epubPlayerConstants.ERROR,
                                    errorCode: sunbirdPlayerSdkV8.errorCode.contentLoadFails,
                                    errorMessage: sunbirdPlayerSdkV8.errorMessage.contentLoadFails
                                });
                            }));
                            return [4 /*yield*/, this.eBook.loaded.spine];
                        case 4:
                            spine_1 = _b.sent();
                            this.lastSection = spine_1.last();
                            if (!this.scrolled) {
                            }
                            this.viewerEvent.emit({
                                type: epubPlayerConstants.EPUBLOADED,
                                data: spine_1
                            });
                            this.actions.subscribe((/**
                             * @param {?} type
                             * @return {?}
                             */
                            function (type) {
                                /** @type {?} */
                                var data = _this.rendition.location.start;
                                if (_this.scrolled && data.href === _this.lastSection.href) {
                                    _this.viewerEvent.emit({
                                        type: epubPlayerConstants.END,
                                        data: {
                                            percentage: 100
                                        }
                                    });
                                }
                                else {
                                    if (_this.rendition.location.atEnd || (spine_1.length === 1 && (_this.rendition.location.end.displayed.page + 1 >= _this.rendition.location.end.displayed.total))) {
                                        _this.viewerEvent.emit({
                                            type: epubPlayerConstants.END,
                                            data: {
                                                percentage: 100
                                            }
                                        });
                                    }
                                }
                                if (type === epubPlayerConstants.NEXT) {
                                    _this.rendition.next();
                                    _this.viewerEvent.emit({
                                        type: epubPlayerConstants.PAGECHANGE,
                                        data: data,
                                        interaction: epubPlayerConstants.NEXT
                                    });
                                }
                                if (type === epubPlayerConstants.PREVIOUS) {
                                    _this.rendition.prev();
                                    _this.viewerEvent.emit({
                                        type: epubPlayerConstants.PAGECHANGE,
                                        data: data,
                                        interaction: epubPlayerConstants.PREVIOUS
                                    });
                                }
                            }));
                            return [3 /*break*/, 6];
                        case 5:
                            error_1 = _b.sent();
                            this.viewerEvent.emit({
                                type: epubPlayerConstants.ERROR,
                                errorCode: sunbirdPlayerSdkV8.errorCode.contentLoadFails,
                                errorMessage: sunbirdPlayerSdkV8.errorMessage.contentLoadFails
                            });
                            return [3 /*break*/, 6];
                        case 6: return [2 /*return*/];
                    }
                });
            });
        };
        /**
         * @return {?}
         */
        EpubViewerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
        function () {
            this.eBook && this.eBook.destroy();
        };
        EpubViewerComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'epub-viewer',
                        template: "<div class=\"rendition\" [id]=\"idForRendition\" #epubViewer></div>",
                        styles: [""]
                    }] }
        ];
        /** @nocollapse */
        EpubViewerComponent.ctorParameters = function () { return [
            { type: ViwerService }
        ]; };
        EpubViewerComponent.propDecorators = {
            epubViewer: [{ type: core.ViewChild, args: ['epubViewer', { static: true },] }],
            epubSrc: [{ type: core.Input }],
            identifier: [{ type: core.Input }],
            actions: [{ type: core.Input }],
            viewerEvent: [{ type: core.Output }]
        };
        return EpubViewerComponent;
    }());
    if (false) {
        /** @type {?} */
        EpubViewerComponent.prototype.eBook;
        /** @type {?} */
        EpubViewerComponent.prototype.rendition;
        /** @type {?} */
        EpubViewerComponent.prototype.lastSection;
        /** @type {?} */
        EpubViewerComponent.prototype.scrolled;
        /** @type {?} */
        EpubViewerComponent.prototype.epubViewer;
        /** @type {?} */
        EpubViewerComponent.prototype.epubSrc;
        /** @type {?} */
        EpubViewerComponent.prototype.identifier;
        /** @type {?} */
        EpubViewerComponent.prototype.actions;
        /** @type {?} */
        EpubViewerComponent.prototype.viewerEvent;
        /** @type {?} */
        EpubViewerComponent.prototype.idForRendition;
        /** @type {?} */
        EpubViewerComponent.prototype.epubBlob;
        /** @type {?} */
        EpubViewerComponent.prototype.viwerService;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/sunbird-epub-player.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var SunbirdEpubPlayerModule = /** @class */ (function () {
        function SunbirdEpubPlayerModule() {
        }
        SunbirdEpubPlayerModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [EpubPlayerComponent, EpubViewerComponent],
                        imports: [
                            common.CommonModule,
                            sunbirdPlayerSdkV8.SunbirdPlayerSdkModule,
                            http.HttpClientModule
                        ],
                        exports: [EpubPlayerComponent]
                    },] }
        ];
        return SunbirdEpubPlayerModule;
    }());

    exports.EpubPlayerComponent = EpubPlayerComponent;
    exports.EpubPlayerService = EpubPlayerService;
    exports.SunbirdEpubPlayerModule = SunbirdEpubPlayerModule;
    exports.ɵa = UtilService;
    exports.ɵb = ViwerService;
    exports.ɵc = EpubViewerComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=project-sunbird-sunbird-epub-player-v8.umd.js.map
