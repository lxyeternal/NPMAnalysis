/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { EpubViewerComponent as ɵc } from './lib/epub-viewer/epub-viewer.component';
export { UtilService as ɵa } from './lib/services/utilService/util.service';
export { ViwerService as ɵb } from './lib/services/viewerService/viwer-service';
