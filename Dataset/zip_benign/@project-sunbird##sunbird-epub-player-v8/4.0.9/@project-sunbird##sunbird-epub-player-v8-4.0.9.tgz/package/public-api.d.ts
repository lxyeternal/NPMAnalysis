export * from './lib/sunbird-epub-player.service';
export * from './lib/sunbird-epub-player.component';
export * from './lib/sunbird-epub-player.module';
