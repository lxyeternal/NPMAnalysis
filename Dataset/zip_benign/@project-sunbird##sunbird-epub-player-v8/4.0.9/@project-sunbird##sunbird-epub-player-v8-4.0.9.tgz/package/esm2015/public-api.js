/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of epub-player
 */
export { EpubPlayerService } from './lib/sunbird-epub-player.service';
export { EpubPlayerComponent } from './lib/sunbird-epub-player.component';
export { SunbirdEpubPlayerModule } from './lib/sunbird-epub-player.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bwcm9qZWN0LXN1bmJpcmQvc3VuYmlyZC1lcHViLXBsYXllci12OC8iLCJzb3VyY2VzIjpbInB1YmxpYy1hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFJQSxrQ0FBYyxtQ0FBbUMsQ0FBQztBQUNsRCxvQ0FBYyxxQ0FBcUMsQ0FBQztBQUNwRCx3Q0FBYyxrQ0FBa0MsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgZXB1Yi1wbGF5ZXJcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9zdW5iaXJkLWVwdWItcGxheWVyLnNlcnZpY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc3VuYmlyZC1lcHViLXBsYXllci5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc3VuYmlyZC1lcHViLXBsYXllci5tb2R1bGUnO1xuIl19