import { epubPlayerConstants } from '../../sunbird-epub.constant';
export declare class UtilService {
    fromConst: typeof epubPlayerConstants;
    constructor();
    uniqueId(length?: number): string;
    getTimeSpentText(pdfPlayerStartTime: any): string;
    getCurrentIndex(event: any, currentPageIndex: any): any;
}
