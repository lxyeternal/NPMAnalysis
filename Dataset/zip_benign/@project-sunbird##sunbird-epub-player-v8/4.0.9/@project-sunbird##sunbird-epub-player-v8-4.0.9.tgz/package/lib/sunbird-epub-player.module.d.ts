export declare class SunbirdEpubPlayerModule {
}
