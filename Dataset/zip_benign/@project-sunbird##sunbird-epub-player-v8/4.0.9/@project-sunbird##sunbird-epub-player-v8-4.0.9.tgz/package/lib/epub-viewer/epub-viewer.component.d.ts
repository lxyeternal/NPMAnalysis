import { AfterViewInit, ElementRef, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { ViwerService } from '../services/viewerService/viwer-service';
export declare class EpubViewerComponent implements OnInit, AfterViewInit, OnDestroy {
    viwerService: ViwerService;
    eBook: any;
    rendition: any;
    lastSection: any;
    scrolled: boolean;
    epubViewer: ElementRef;
    epubSrc: string;
    identifier: string;
    actions: EventEmitter<any>;
    viewerEvent: EventEmitter<any>;
    idForRendition: any;
    epubBlob: Object;
    constructor(viwerService: ViwerService);
    ngOnInit(): void;
    ngAfterViewInit(): Promise<void>;
    ngOnDestroy(): void;
}
