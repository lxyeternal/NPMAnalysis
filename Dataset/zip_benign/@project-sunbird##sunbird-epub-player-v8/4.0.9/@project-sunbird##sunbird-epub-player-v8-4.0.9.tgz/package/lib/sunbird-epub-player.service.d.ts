import { UtilService } from './services/utilService/util.service';
import { PlayerConfig } from './sunbird-epub-player.interface';
export declare class EpubPlayerService {
    private utilService;
    private contentSessionId;
    private playSessionId;
    private telemetryObject;
    private context;
    config: any;
    channel: string;
    pdata: string;
    sid: string;
    uid: string;
    rollup: string;
    constructor(utilService: UtilService);
    initialize({ context, config, metadata }: PlayerConfig): void;
    start(duration: any): void;
    interact(id: any, currentPage: any): void;
    impression(currentPage: any): void;
    end(duration: any, percentage: any, curentPage: any, endpageseen: any): void;
    error(errorCode: string, errorType: string, pageid: any, stacktrace: any): void;
    private getEventOptions;
}
