import { Injectable, ɵɵdefineInjectable, ɵɵinject, EventEmitter, Component, Renderer2, ViewChild, Input, Output, HostListener, NgModule } from '@angular/core';
import { CsTelemetryModule } from '@project-sunbird/client-services/telemetry';
import { __awaiter, __generator, __assign } from 'tslib';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { errorCode, errorMessage, ErrorService, SunbirdPlayerSdkModule } from '@project-sunbird/sunbird-player-sdk-v8';
import Epub from 'epubjs';
import { CommonModule } from '@angular/common';

/**
 * @fileoverview added by tsickle
 * Generated from: lib/sunbird-epub.constant.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @enum {string} */
var epubPlayerConstants = {
    LOADING: "LOADING",
    START: "START",
    END: "END",
    EPUBLOADED: "epubLoaded",
    PAGECHANGE: "pageChange",
    NEXT: "NEXT",
    PREVIOUS: "PREVIOUS",
    ERROR: "error",
    UNABLE_TO_FETCH_URL_ONLINE: "Internet is avialable but unable to fetch the url",
};
/** @enum {string} */
var telemetryType = {
    INTERACT: "INTERACT",
    IMPRESSION: "IMPRESSION",
};

/**
 * @fileoverview added by tsickle
 * Generated from: lib/services/utilService/util.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var UtilService = /** @class */ (function () {
    function UtilService() {
        this.fromConst = epubPlayerConstants;
    }
    /**
     * @param {?=} length
     * @return {?}
     */
    UtilService.prototype.uniqueId = /**
     * @param {?=} length
     * @return {?}
     */
    function (length) {
        if (length === void 0) { length = 32; }
        /** @type {?} */
        var result = '';
        /** @type {?} */
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        /** @type {?} */
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    };
    /**
     * @param {?} pdfPlayerStartTime
     * @return {?}
     */
    UtilService.prototype.getTimeSpentText = /**
     * @param {?} pdfPlayerStartTime
     * @return {?}
     */
    function (pdfPlayerStartTime) {
        /** @type {?} */
        var duration = new Date().getTime() - pdfPlayerStartTime;
        /** @type {?} */
        var minutes = Math.floor(duration / 60000);
        /** @type {?} */
        var seconds = Number(((duration % 60000) / 1000).toFixed(0));
        return (minutes + ':' + (seconds < 10 ? '0' : '') + seconds);
    };
    /**
     * @param {?} event
     * @param {?} currentPageIndex
     * @return {?}
     */
    UtilService.prototype.getCurrentIndex = /**
     * @param {?} event
     * @param {?} currentPageIndex
     * @return {?}
     */
    function (event, currentPageIndex) {
        if (event['interaction'] === this.fromConst.NEXT) {
            return currentPageIndex + 1;
        }
        if (event['interaction'] === this.fromConst.PREVIOUS) {
            return currentPageIndex - 1 == 0 ? 1 : currentPageIndex - 1;
        }
    };
    UtilService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    /** @nocollapse */
    UtilService.ctorParameters = function () { return []; };
    /** @nocollapse */ UtilService.ngInjectableDef = ɵɵdefineInjectable({ factory: function UtilService_Factory() { return new UtilService(); }, token: UtilService, providedIn: "root" });
    return UtilService;
}());
if (false) {
    /** @type {?} */
    UtilService.prototype.fromConst;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/sunbird-epub-player.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var EpubPlayerService = /** @class */ (function () {
    function EpubPlayerService(utilService) {
        this.utilService = utilService;
        this.contentSessionId = this.utilService.uniqueId();
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    EpubPlayerService.prototype.initialize = /**
     * @param {?} __0
     * @return {?}
     */
    function (_a) {
        var context = _a.context, config = _a.config, metadata = _a.metadata;
        this.context = context;
        this.config = config;
        this.playSessionId = this.utilService.uniqueId();
        this.channel = this.context.channel;
        this.pdata = this.context.pdata;
        this.sid = this.context.sid;
        this.uid = this.context.uid;
        this.rollup = this.context.rollup;
        if (!CsTelemetryModule.instance.isInitialised) {
            CsTelemetryModule.instance.init({});
            /** @type {?} */
            var telemetryConfig = {
                config: {
                    pdata: context.pdata,
                    env: 'contentplayer',
                    channel: context.channel,
                    did: context.did,
                    authtoken: context.authToken || '',
                    uid: context.uid || '',
                    sid: context.sid,
                    batchsize: 20,
                    mode: context.mode,
                    host: context.host || '',
                    endpoint: context.endpoint || '/data/v3/telemetry',
                    tags: context.tags,
                    cdata: (context.cdata || []).concat([{ id: this.contentSessionId, type: 'ContentSession' },
                        { id: this.playSessionId, type: 'PlaySession' },
                        { id: "2.0", type: "PlayerVersion" }])
                },
                userOrgDetails: {}
            };
            if (context.dispatcher) {
                telemetryConfig.config.dispatcher = context.dispatcher;
            }
            CsTelemetryModule.instance.telemetryService.initTelemetry(telemetryConfig);
        }
        this.telemetryObject = {
            id: metadata.identifier,
            type: 'Content',
            ver: metadata.pkgVersion + '' || '1.0',
            rollup: context.objectRollup || {}
        };
    };
    /**
     * @param {?} duration
     * @return {?}
     */
    EpubPlayerService.prototype.start = /**
     * @param {?} duration
     * @return {?}
     */
    function (duration) {
        CsTelemetryModule.instance.telemetryService.raiseStartTelemetry({
            options: this.getEventOptions(),
            edata: { type: 'content', mode: 'play', pageid: '', duration: Number((duration / 1e3).toFixed(2)) }
        });
    };
    /**
     * @param {?} id
     * @param {?} currentPage
     * @return {?}
     */
    EpubPlayerService.prototype.interact = /**
     * @param {?} id
     * @param {?} currentPage
     * @return {?}
     */
    function (id, currentPage) {
        CsTelemetryModule.instance.telemetryService.raiseInteractTelemetry({
            options: this.getEventOptions(),
            edata: { type: 'TOUCH', subtype: '', id: id, pageid: currentPage + '' }
        });
    };
    /**
     * @param {?} currentPage
     * @return {?}
     */
    EpubPlayerService.prototype.impression = /**
     * @param {?} currentPage
     * @return {?}
     */
    function (currentPage) {
        CsTelemetryModule.instance.telemetryService.raiseImpressionTelemetry({
            options: this.getEventOptions(),
            edata: { type: 'workflow', subtype: '', pageid: currentPage + '', uri: '' }
        });
    };
    /**
     * @param {?} duration
     * @param {?} percentage
     * @param {?} curentPage
     * @param {?} endpageseen
     * @return {?}
     */
    EpubPlayerService.prototype.end = /**
     * @param {?} duration
     * @param {?} percentage
     * @param {?} curentPage
     * @param {?} endpageseen
     * @return {?}
     */
    function (duration, percentage, curentPage, endpageseen) {
        /** @type {?} */
        var durationSec = Number((duration / 1e3).toFixed(2));
        CsTelemetryModule.instance.telemetryService.raiseEndTelemetry({
            edata: {
                type: 'content',
                mode: 'play',
                pageid: 'sunbird-player-Endpage',
                summary: [
                    {
                        progress: percentage
                    },
                    {
                        totallength: (percentage === 100 ? curentPage : 1)
                    },
                    {
                        visitedlength: curentPage
                    },
                    {
                        visitedcontentend: (percentage === 100)
                    },
                    {
                        totalseekedlength: 0
                    },
                    {
                        endpageseen: endpageseen
                    }
                ],
                duration: durationSec
            },
            options: this.getEventOptions()
        });
    };
    /**
     * @param {?} errorCode
     * @param {?} errorType
     * @param {?} pageid
     * @param {?} stacktrace
     * @return {?}
     */
    EpubPlayerService.prototype.error = /**
     * @param {?} errorCode
     * @param {?} errorType
     * @param {?} pageid
     * @param {?} stacktrace
     * @return {?}
     */
    function (errorCode, errorType, pageid, stacktrace) {
        CsTelemetryModule.instance.telemetryService.raiseErrorTelemetry({
            options: this.getEventOptions(),
            edata: {
                err: errorCode,
                errtype: errorType,
                stacktrace: stacktrace.toString(),
                pageid: pageid || ''
            }
        });
    };
    /**
     * @private
     * @return {?}
     */
    EpubPlayerService.prototype.getEventOptions = /**
     * @private
     * @return {?}
     */
    function () {
        return ({
            object: this.telemetryObject,
            context: {
                channel: this.channel,
                pdata: this.pdata,
                env: 'contentplayer',
                sid: this.sid,
                uid: this.uid,
                cdata: (this.context.cdata || []).concat([{ id: this.contentSessionId, type: 'ContentSession' },
                    { id: this.playSessionId, type: 'PlaySession' },
                    { id: "2.0", type: "PlayerVersion" }]),
                rollup: this.rollup || {}
            }
        });
    };
    EpubPlayerService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    /** @nocollapse */
    EpubPlayerService.ctorParameters = function () { return [
        { type: UtilService }
    ]; };
    /** @nocollapse */ EpubPlayerService.ngInjectableDef = ɵɵdefineInjectable({ factory: function EpubPlayerService_Factory() { return new EpubPlayerService(ɵɵinject(UtilService)); }, token: EpubPlayerService, providedIn: "root" });
    return EpubPlayerService;
}());
if (false) {
    /**
     * @type {?}
     * @private
     */
    EpubPlayerService.prototype.contentSessionId;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerService.prototype.playSessionId;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerService.prototype.telemetryObject;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerService.prototype.context;
    /** @type {?} */
    EpubPlayerService.prototype.config;
    /** @type {?} */
    EpubPlayerService.prototype.channel;
    /** @type {?} */
    EpubPlayerService.prototype.pdata;
    /** @type {?} */
    EpubPlayerService.prototype.sid;
    /** @type {?} */
    EpubPlayerService.prototype.uid;
    /** @type {?} */
    EpubPlayerService.prototype.rollup;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerService.prototype.utilService;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/services/viewerService/viwer-service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ViwerService = /** @class */ (function () {
    function ViwerService(utilService, epubPlayerService, http) {
        this.utilService = utilService;
        this.epubPlayerService = epubPlayerService;
        this.http = http;
        this.currentIndex = 0;
        this.totalNumberOfPages = 0;
        this.endPageSeen = false;
        this.timeSpent = '0:0';
        this.version = '1.0';
        this.playerEvent = new EventEmitter();
        this.isAvailableLocally = false;
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    ViwerService.prototype.initialize = /**
     * @param {?} __0
     * @return {?}
     */
    function (_a) {
        var context = _a.context, config = _a.config, metadata = _a.metadata;
        this.epubPlayerStartTime = this.epubLastPageTime = new Date().getTime();
        this.totalNumberOfPages = 0;
        this.currentIndex = 0;
        this.contentName = metadata.name;
        this.identifier = metadata.identifier;
        this.artifactUrl = metadata.artifactUrl;
        this.isAvailableLocally = metadata.isAvailableLocally;
        if (this.isAvailableLocally) {
            /** @type {?} */
            var basePath = (metadata.streamingUrl) ? (metadata.streamingUrl) : (metadata.basePath || metadata.baseDir);
            this.src = basePath + "/" + metadata.artifactUrl;
        }
        else {
            this.src = metadata.streamingUrl || metadata.artifactUrl;
        }
        if (context.userData) {
            var _b = context.userData, firstName = _b.firstName, lastName = _b.lastName;
            this.userName = firstName === lastName ? firstName : firstName + " " + lastName;
        }
        this.metaData = {
            pagesVisited: [],
            totalPages: 0,
            duration: [],
            zoom: [],
            rotation: []
        };
        this.showDownloadPopup = false;
        this.endPageSeen = false;
    };
    /**
     * @param {?} event
     * @return {?}
     */
    ViwerService.prototype.raiseStartEvent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.currentIndex = event.items[0].index;
        /** @type {?} */
        var duration = new Date().getTime() - this.epubPlayerStartTime;
        /** @type {?} */
        var startEvent = {
            eid: 'START',
            ver: this.version,
            edata: {
                type: 'START',
                currentPage: this.currentIndex,
                duration: duration
            },
            metaData: this.metaData
        };
        this.playerEvent.emit(startEvent);
        this.epubLastPageTime = this.epubPlayerStartTime = new Date().getTime();
        this.epubPlayerService.start(duration);
    };
    /**
     * @param {?} event
     * @param {?=} teleType
     * @return {?}
     */
    ViwerService.prototype.raiseHeartBeatEvent = /**
     * @param {?} event
     * @param {?=} teleType
     * @return {?}
     */
    function (event, teleType) {
        if (event.data) {
            this.currentIndex = event.data.index;
        }
        /** @type {?} */
        var eventType = event.type ? event.type : event;
        /** @type {?} */
        var heartBeatEvent = {
            eid: 'HEARTBEAT',
            ver: this.version,
            edata: {
                type: eventType,
                currentPage: this.currentIndex
            },
            metaData: this.metaData
        };
        this.playerEvent.emit(heartBeatEvent);
        if (telemetryType.IMPRESSION === teleType) {
            this.epubPlayerService.impression(this.currentIndex);
        }
        if (telemetryType.INTERACT === teleType) {
            this.epubPlayerService.interact(eventType.toLowerCase(), this.currentIndex);
        }
    };
    /**
     * @param {?} event
     * @return {?}
     */
    ViwerService.prototype.raiseEndEvent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.currentIndex = event.data.index;
        /** @type {?} */
        var percentage = event.data.percentage || 0;
        if (event.data.percentage) {
            this.endPageSeen = true;
        }
        /** @type {?} */
        var duration = new Date().getTime() - this.epubPlayerStartTime;
        /** @type {?} */
        var endEvent = {
            eid: 'END',
            ver: this.version,
            edata: {
                type: 'END',
                currentPage: event.data.index,
                totalPages: this.currentIndex,
                duration: duration
            },
            metaData: this.metaData
        };
        this.playerEvent.emit(endEvent);
        /** @type {?} */
        var visitedlength = this.currentIndex;
        this.timeSpent = this.utilService.getTimeSpentText(this.epubPlayerStartTime);
        this.epubPlayerService.end(duration, percentage, this.currentIndex, this.endPageSeen);
    };
    /**
     * @param {?} errorCode
     * @param {?} pageIndex
     * @param {?} errorType
     * @param {?} traceId
     * @param {?} stacktrace
     * @return {?}
     */
    ViwerService.prototype.raiseExceptionLog = /**
     * @param {?} errorCode
     * @param {?} pageIndex
     * @param {?} errorType
     * @param {?} traceId
     * @param {?} stacktrace
     * @return {?}
     */
    function (errorCode, pageIndex, errorType, traceId, stacktrace) {
        /** @type {?} */
        var exceptionLogEvent = {
            eid: "ERROR",
            edata: {
                err: errorCode,
                errtype: errorType,
                requestid: traceId || '',
                stacktrace: stacktrace
            }
        };
        this.playerEvent.emit(exceptionLogEvent);
        this.epubPlayerService.error(errorCode, errorType, pageIndex, stacktrace);
    };
    /**
     * @param {?} src
     * @return {?}
     */
    ViwerService.prototype.isValidEpubSrc = /**
     * @param {?} src
     * @return {?}
     */
    function (src) {
        var _this = this;
        return new Promise((/**
         * @param {?} resolve
         * @param {?} reject
         * @return {?}
         */
        function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                this.http.get(src, { responseType: 'blob' }).toPromise().then((/**
                 * @param {?} res
                 * @return {?}
                 */
                function (res) {
                    resolve(res);
                })).catch((/**
                 * @param {?} error
                 * @return {?}
                 */
                function (error) {
                    reject(error);
                }));
                return [2 /*return*/];
            });
        }); }));
    };
    ViwerService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    /** @nocollapse */
    ViwerService.ctorParameters = function () { return [
        { type: UtilService },
        { type: EpubPlayerService },
        { type: HttpClient }
    ]; };
    /** @nocollapse */ ViwerService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ViwerService_Factory() { return new ViwerService(ɵɵinject(UtilService), ɵɵinject(EpubPlayerService), ɵɵinject(HttpClient)); }, token: ViwerService, providedIn: "root" });
    return ViwerService;
}());
if (false) {
    /** @type {?} */
    ViwerService.prototype.currentIndex;
    /** @type {?} */
    ViwerService.prototype.totalNumberOfPages;
    /** @type {?} */
    ViwerService.prototype.epubPlayerStartTime;
    /** @type {?} */
    ViwerService.prototype.epubLastPageTime;
    /** @type {?} */
    ViwerService.prototype.endPageSeen;
    /** @type {?} */
    ViwerService.prototype.timeSpent;
    /**
     * @type {?}
     * @private
     */
    ViwerService.prototype.version;
    /** @type {?} */
    ViwerService.prototype.playerEvent;
    /** @type {?} */
    ViwerService.prototype.contentName;
    /** @type {?} */
    ViwerService.prototype.loadingProgress;
    /** @type {?} */
    ViwerService.prototype.showDownloadPopup;
    /** @type {?} */
    ViwerService.prototype.src;
    /** @type {?} */
    ViwerService.prototype.userName;
    /**
     * @type {?}
     * @private
     */
    ViwerService.prototype.metaData;
    /** @type {?} */
    ViwerService.prototype.identifier;
    /** @type {?} */
    ViwerService.prototype.artifactUrl;
    /** @type {?} */
    ViwerService.prototype.isAvailableLocally;
    /**
     * @type {?}
     * @private
     */
    ViwerService.prototype.utilService;
    /**
     * @type {?}
     * @private
     */
    ViwerService.prototype.epubPlayerService;
    /**
     * @type {?}
     * @private
     */
    ViwerService.prototype.http;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/sunbird-epub-player.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var EpubPlayerComponent = /** @class */ (function () {
    function EpubPlayerComponent(viwerService, epubPlayerService, errorService, utilService, renderer2) {
        this.viwerService = viwerService;
        this.epubPlayerService = epubPlayerService;
        this.errorService = errorService;
        this.utilService = utilService;
        this.renderer2 = renderer2;
        this.fromConst = epubPlayerConstants;
        this.headerActionsEvent = new EventEmitter();
        this.telemetryEvent = new EventEmitter();
        this.showControls = true;
        this.sideMenuConfig = {
            showShare: true,
            showDownload: true,
            showReplay: false,
            showExit: false,
            showPrint: true
        };
        this.viewState = this.fromConst.LOADING;
        this.progress = 0;
        this.currentPageIndex = 1;
        this.headerConfiguration = {
            rotation: false,
            goto: false,
            navigation: true,
            zoom: false
        };
        this.playerEvent = this.viwerService.playerEvent;
    }
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.onTelemetryEvent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.telemetryEvent.emit(event.detail);
    };
    /**
     * @return {?}
     */
    EpubPlayerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        return __awaiter(this, void 0, void 0, function () {
            var contentCompabilityLevel, checkContentCompatible;
            return __generator(this, function (_a) {
                // initializing services
                this.viwerService.initialize(this.playerConfig);
                this.epubPlayerService.initialize(this.playerConfig);
                this.traceId = this.playerConfig.config['traceId'];
                // checks online error while loading epub
                if (!navigator.onLine && !this.viwerService.isAvailableLocally) {
                    this.viwerService.raiseExceptionLog(errorCode.internetConnectivity, this.currentPageIndex, errorMessage.internetConnectivity, this.traceId, new Error(errorMessage.internetConnectivity));
                }
                // checks content compatibility error
                contentCompabilityLevel = this.playerConfig.metadata['compatibilityLevel'];
                if (contentCompabilityLevel) {
                    checkContentCompatible = this.errorService.checkContentCompatibility(contentCompabilityLevel);
                    if (!checkContentCompatible['isCompitable']) {
                        this.viwerService.raiseExceptionLog(errorCode.contentCompatibility, this.currentPageIndex, errorCode.contentCompatibility, this.traceId, checkContentCompatible['error']);
                    }
                }
                this.showEpubViewer = true;
                this.sideMenuConfig = __assign({}, this.sideMenuConfig, this.playerConfig.config.sideMenu);
                this.getEpubLoadingProgress();
                return [2 /*return*/];
            });
        });
    };
    /**
     * @return {?}
     */
    EpubPlayerComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var epubPlayerElement = this.epubPlayerRef.nativeElement;
        this.unlistenMouseEnter = this.renderer2.listen(epubPlayerElement, 'mouseenter', (/**
         * @return {?}
         */
        function () {
            _this.showControls = true;
        }));
        this.unlistenMouseLeave = this.renderer2.listen(epubPlayerElement, 'mouseleave', (/**
         * @return {?}
         */
        function () {
            _this.showControls = false;
        }));
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.headerActions = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.headerActionsEvent.emit(event.type);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.viewerEvent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        if (event.type === this.fromConst.EPUBLOADED) {
            this.onEpubLoaded(event);
        }
        if (event.type === this.fromConst.PAGECHANGE) {
            this.onPageChange(event);
        }
        if (event.type === this.fromConst.END) {
            this.onEpubEnded(event);
        }
        if (event.type === this.fromConst.ERROR) {
            this.onEpubLoadFailed(event);
        }
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.onEpubLoaded = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        clearInterval(this.intervalRef);
        this.viewState = this.fromConst.START;
        this.viwerService.raiseStartEvent(event.data);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.onPageChange = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.currentPageIndex = this.utilService.getCurrentIndex(event, this.currentPageIndex);
        this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
        this.viwerService.raiseHeartBeatEvent(event, telemetryType.IMPRESSION);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.onEpubEnded = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.viewState = this.fromConst.END;
        this.showEpubViewer = false;
        event.data.index = this.currentPageIndex;
        this.viwerService.raiseEndEvent(event);
    };
    /**
     * @param {?} error
     * @return {?}
     */
    EpubPlayerComponent.prototype.onEpubLoadFailed = /**
     * @param {?} error
     * @return {?}
     */
    function (error) {
        this.showContentError = true;
        this.viewState = this.fromConst.LOADING;
        this.viwerService.raiseExceptionLog(error.errorCode, this.currentPageIndex, error.errorMessage, this.traceId, new Error(error.errorMessage));
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.replayContent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.currentPageIndex = 1;
        this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
        this.viewState = this.fromConst.START;
        this.ngOnInit();
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.exitContent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.sideBarEvents = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
        if (event === 'DOWNLOAD') {
            this.downloadEpub();
        }
    };
    /**
     * @param {?} event
     * @return {?}
     */
    EpubPlayerComponent.prototype.sidebarMenuEvent = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.viwerService.raiseHeartBeatEvent(event, telemetryType.INTERACT);
    };
    /**
     * @return {?}
     */
    EpubPlayerComponent.prototype.getEpubLoadingProgress = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.intervalRef = setInterval((/**
         * @return {?}
         */
        function () {
            if (_this.progress < 95) {
                _this.progress = _this.progress + 5;
            }
        }), 10);
    };
    /**
     * @return {?}
     */
    EpubPlayerComponent.prototype.downloadEpub = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var a = document.createElement('a');
        a.href = this.viwerService.artifactUrl;
        a.download = this.viwerService.contentName;
        a.target = '_blank';
        document.body.appendChild(a);
        a.click();
        a.remove();
        this.viwerService.raiseHeartBeatEvent('DOWNLOAD');
    };
    /**
     * @return {?}
     */
    EpubPlayerComponent.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var EndEvent = {
            type: this.fromConst.END,
            data: {
                index: this.currentPageIndex
            }
        };
        this.viwerService.raiseEndEvent(EndEvent);
        this.unlistenMouseEnter();
        this.unlistenMouseLeave();
    };
    EpubPlayerComponent.decorators = [
        { type: Component, args: [{
                    selector: 'sunbird-epub-player',
                    template: "<div class=\"sunbird-epub-container\" #epubPlayer>\n<div *ngIf=\"viewState === fromConst.LOADING\">\n    <sb-player-start-page [title]=\"viwerService.contentName\" [progress]=\"progress\"></sb-player-start-page>\n</div>\n<div class=\"epub-container\" *ngIf=\"showEpubViewer\">\n    <ng-container *ngIf=\"viewState === fromConst.START\">\n        <sb-player-header class=\"notVisible\" [config]=\"headerConfiguration\" (actions)=\"headerActions($event)\" [ngClass]=\"{'isVisible': showControls}\"></sb-player-header>\n        <sb-player-side-menu-icon class=\"notVisible\"  [ngClass]=\"{'isVisible': showControls}\" (sidebarMenuEvent)=\"sidebarMenuEvent($event)\">\n        </sb-player-side-menu-icon>\n        <sb-player-sidebar [title]=\"viwerService.contentName\" (sidebarEvent)=\"sideBarEvents($event)\"\n            [config]=\"sideMenuConfig\"></sb-player-sidebar>\n        <div class=\"sb-epub-reading-status\">\n            Location {{currentPageIndex}} \n        </div>\n        \n    </ng-container>\n    <epub-viewer  [actions]=\"headerActionsEvent\" [epubSrc]=\"viwerService.src\" [identifier]=\"viwerService.identifier\"\n        (viewerEvent)=\"viewerEvent($event)\">\n    </epub-viewer>\n</div>\n<sb-player-end-page *ngIf=\"viewState === fromConst.END\" [contentName]=\"viwerService.contentName\"\n    [outcomeLabel]=\"'Pages read: '\" [outcome]=\"(currentPageIndex -1)\" [showExit]=\"sideMenuConfig.showExit\" [userName]=\"viwerService.userName\"\n    [timeSpentLabel]=\"viwerService.timeSpent\" (replayContent)=\"replayContent($event)\" (exitContent)=\"exitContent($event)\">\n</sb-player-end-page>\n<sb-player-contenterror *ngIf=\"showContentError\"></sb-player-contenterror>\n</div>\n",
                    styles: [".sunbird-epub-container{height:100%;width:100%;background-color:#fff}.sunbird-epub-palyer-container{width:100%;height:100%;overflow:hidden;position:relative}.sb-epub-reading-status{color:var(--gray-800);font-size:.75rem;position:absolute;left:1rem;bottom:.75rem;display:flex;align-items:center;background:var(--white);border-radius:.5rem;padding:.25em .5rem;z-index:5;line-height:normal}.BtmNotVisible,.notVisible{transition:.3s ease-in-out;position:absolute;width:100%}.notVisible{top:-10rem}.notVisible.isVisible{top:0}.BtmNotVisible{bottom:-10rem}.BtmNotVisible.isVisible{bottom:0}:host::ng-deep .sb-player-splash-container{height:100vh!important}:host::ng-deep epub-viewer{position:absolute;top:48px;width:100%;height:calc(100% - 48px);overflow-y:auto;overflow-x:hidden;left:0;background-color:#fff}:host::ng-deep .epub-container{height:100%;position:relative;overflow-x:hidden!important}"]
                }] }
    ];
    /** @nocollapse */
    EpubPlayerComponent.ctorParameters = function () { return [
        { type: ViwerService },
        { type: EpubPlayerService },
        { type: ErrorService },
        { type: UtilService },
        { type: Renderer2 }
    ]; };
    EpubPlayerComponent.propDecorators = {
        epubPlayerRef: [{ type: ViewChild, args: ['epubPlayer', { static: true },] }],
        playerConfig: [{ type: Input }],
        headerActionsEvent: [{ type: Output }],
        telemetryEvent: [{ type: Output }],
        playerEvent: [{ type: Output }],
        onTelemetryEvent: [{ type: HostListener, args: ['document:TelemetryEvent', ['$event'],] }],
        ngOnDestroy: [{ type: HostListener, args: ['window:beforeunload',] }]
    };
    return EpubPlayerComponent;
}());
if (false) {
    /** @type {?} */
    EpubPlayerComponent.prototype.fromConst;
    /** @type {?} */
    EpubPlayerComponent.prototype.epubPlayerRef;
    /** @type {?} */
    EpubPlayerComponent.prototype.playerConfig;
    /** @type {?} */
    EpubPlayerComponent.prototype.headerActionsEvent;
    /** @type {?} */
    EpubPlayerComponent.prototype.telemetryEvent;
    /** @type {?} */
    EpubPlayerComponent.prototype.playerEvent;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerComponent.prototype.unlistenMouseEnter;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerComponent.prototype.unlistenMouseLeave;
    /** @type {?} */
    EpubPlayerComponent.prototype.showControls;
    /** @type {?} */
    EpubPlayerComponent.prototype.showContentError;
    /** @type {?} */
    EpubPlayerComponent.prototype.sideMenuConfig;
    /** @type {?} */
    EpubPlayerComponent.prototype.viewState;
    /** @type {?} */
    EpubPlayerComponent.prototype.intervalRef;
    /** @type {?} */
    EpubPlayerComponent.prototype.progress;
    /** @type {?} */
    EpubPlayerComponent.prototype.showEpubViewer;
    /** @type {?} */
    EpubPlayerComponent.prototype.traceId;
    /** @type {?} */
    EpubPlayerComponent.prototype.currentPageIndex;
    /** @type {?} */
    EpubPlayerComponent.prototype.headerConfiguration;
    /** @type {?} */
    EpubPlayerComponent.prototype.viwerService;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerComponent.prototype.epubPlayerService;
    /** @type {?} */
    EpubPlayerComponent.prototype.errorService;
    /** @type {?} */
    EpubPlayerComponent.prototype.utilService;
    /**
     * @type {?}
     * @private
     */
    EpubPlayerComponent.prototype.renderer2;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/epub-viewer/epub-viewer.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var EpubViewerComponent = /** @class */ (function () {
    function EpubViewerComponent(viwerService) {
        this.viwerService = viwerService;
        this.actions = new EventEmitter();
        this.viewerEvent = new EventEmitter();
    }
    /**
     * @return {?}
     */
    EpubViewerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.idForRendition = this.identifier + "-content";
    };
    /**
     * @return {?}
     */
    EpubViewerComponent.prototype.ngAfterViewInit = /**
     * @return {?}
     */
    function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a, spine_1, error_1;
            var _this = this;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 5, , 6]);
                        if (!!this.viwerService.isAvailableLocally) return [3 /*break*/, 2];
                        _a = this;
                        return [4 /*yield*/, this.viwerService.isValidEpubSrc(this.epubSrc)];
                    case 1:
                        _a.epubBlob = _b.sent();
                        this.eBook = Epub(this.epubBlob);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.viwerService.isAvailableLocally) {
                            this.eBook = Epub(this.epubSrc);
                        }
                        _b.label = 3;
                    case 3:
                        this.rendition = this.eBook.renderTo(this.idForRendition, {
                            flow: "paginated",
                            width: this.epubViewer.nativeElement.offsetWidth,
                            height: this.epubViewer.nativeElement.offsetHeight
                        });
                        this.rendition.display();
                        this.rendition.on("layout", (/**
                         * @param {?} layout
                         * @return {?}
                         */
                        function (layout) {
                            if (_this.eBook.navigation.length > 2) {
                                _this.rendition.spread("none");
                                _this.rendition.flow("scrolled");
                                _this.scrolled = true;
                            }
                            else {
                                _this.rendition.spread("auto");
                                _this.scrolled = false;
                            }
                        }));
                        this.rendition.on('displayError', (/**
                         * @param {?} error
                         * @return {?}
                         */
                        function (error) {
                            _this.viewerEvent.emit({
                                type: epubPlayerConstants.ERROR,
                                errorCode: errorCode.contentLoadFails,
                                errorMessage: errorMessage.contentLoadFails
                            });
                        }));
                        return [4 /*yield*/, this.eBook.loaded.spine];
                    case 4:
                        spine_1 = _b.sent();
                        this.lastSection = spine_1.last();
                        if (!this.scrolled) {
                        }
                        this.viewerEvent.emit({
                            type: epubPlayerConstants.EPUBLOADED,
                            data: spine_1
                        });
                        this.actions.subscribe((/**
                         * @param {?} type
                         * @return {?}
                         */
                        function (type) {
                            /** @type {?} */
                            var data = _this.rendition.location.start;
                            if (_this.scrolled && data.href === _this.lastSection.href) {
                                _this.viewerEvent.emit({
                                    type: epubPlayerConstants.END,
                                    data: {
                                        percentage: 100
                                    }
                                });
                            }
                            else {
                                if (_this.rendition.location.atEnd || (spine_1.length === 1 && (_this.rendition.location.end.displayed.page + 1 >= _this.rendition.location.end.displayed.total))) {
                                    _this.viewerEvent.emit({
                                        type: epubPlayerConstants.END,
                                        data: {
                                            percentage: 100
                                        }
                                    });
                                }
                            }
                            if (type === epubPlayerConstants.NEXT) {
                                _this.rendition.next();
                                _this.viewerEvent.emit({
                                    type: epubPlayerConstants.PAGECHANGE,
                                    data: data,
                                    interaction: epubPlayerConstants.NEXT
                                });
                            }
                            if (type === epubPlayerConstants.PREVIOUS) {
                                _this.rendition.prev();
                                _this.viewerEvent.emit({
                                    type: epubPlayerConstants.PAGECHANGE,
                                    data: data,
                                    interaction: epubPlayerConstants.PREVIOUS
                                });
                            }
                        }));
                        return [3 /*break*/, 6];
                    case 5:
                        error_1 = _b.sent();
                        this.viewerEvent.emit({
                            type: epubPlayerConstants.ERROR,
                            errorCode: errorCode.contentLoadFails,
                            errorMessage: errorMessage.contentLoadFails
                        });
                        return [3 /*break*/, 6];
                    case 6: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * @return {?}
     */
    EpubViewerComponent.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        this.eBook && this.eBook.destroy();
    };
    EpubViewerComponent.decorators = [
        { type: Component, args: [{
                    selector: 'epub-viewer',
                    template: "<div class=\"rendition\" [id]=\"idForRendition\" #epubViewer></div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    EpubViewerComponent.ctorParameters = function () { return [
        { type: ViwerService }
    ]; };
    EpubViewerComponent.propDecorators = {
        epubViewer: [{ type: ViewChild, args: ['epubViewer', { static: true },] }],
        epubSrc: [{ type: Input }],
        identifier: [{ type: Input }],
        actions: [{ type: Input }],
        viewerEvent: [{ type: Output }]
    };
    return EpubViewerComponent;
}());
if (false) {
    /** @type {?} */
    EpubViewerComponent.prototype.eBook;
    /** @type {?} */
    EpubViewerComponent.prototype.rendition;
    /** @type {?} */
    EpubViewerComponent.prototype.lastSection;
    /** @type {?} */
    EpubViewerComponent.prototype.scrolled;
    /** @type {?} */
    EpubViewerComponent.prototype.epubViewer;
    /** @type {?} */
    EpubViewerComponent.prototype.epubSrc;
    /** @type {?} */
    EpubViewerComponent.prototype.identifier;
    /** @type {?} */
    EpubViewerComponent.prototype.actions;
    /** @type {?} */
    EpubViewerComponent.prototype.viewerEvent;
    /** @type {?} */
    EpubViewerComponent.prototype.idForRendition;
    /** @type {?} */
    EpubViewerComponent.prototype.epubBlob;
    /** @type {?} */
    EpubViewerComponent.prototype.viwerService;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/sunbird-epub-player.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var SunbirdEpubPlayerModule = /** @class */ (function () {
    function SunbirdEpubPlayerModule() {
    }
    SunbirdEpubPlayerModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [EpubPlayerComponent, EpubViewerComponent],
                    imports: [
                        CommonModule,
                        SunbirdPlayerSdkModule,
                        HttpClientModule
                    ],
                    exports: [EpubPlayerComponent]
                },] }
    ];
    return SunbirdEpubPlayerModule;
}());

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: project-sunbird-sunbird-epub-player-v8.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { EpubPlayerComponent, EpubPlayerService, SunbirdEpubPlayerModule, UtilService as ɵa, ViwerService as ɵb, EpubViewerComponent as ɵc };
//# sourceMappingURL=project-sunbird-sunbird-epub-player-v8.js.map
