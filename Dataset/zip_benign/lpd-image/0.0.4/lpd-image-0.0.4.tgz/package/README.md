# vue_directive ，图片放大

## vue_directive  图片放大


## vue 自定义指令 -- 图片预览

### 安装
```
npm i lpd-image --save
```

### 使用
在 main.js 中
```
import xxxx from 'lpd-image'
```

在组件中：
```
 <img alt="Vue logo" src="./assets/logo.png" v-lpd-image>  默认scale ：1 ，opacity：0.5
 <img alt="Vue logo" src="./assets/logo.png" v-lpd-image="{scale:'1.5',opacity:'0.3'}">  定义缩放倍数,背景透明度
```

