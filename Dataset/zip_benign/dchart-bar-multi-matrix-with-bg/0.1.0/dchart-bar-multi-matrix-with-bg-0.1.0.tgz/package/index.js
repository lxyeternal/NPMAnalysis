'use strict';
var Bar = require('dchart-core/bar/barMatrix');
var _ = require('dchart-core/util');
var d3 = require('d3');
var textures = require('textures');

function BarMultiWithBG(container, options) {
  var opt = {
    margin: {top: 20, right: 20, bottom: 30, left: 20},
    xaxis: {
      type: 'category',
      padding: 0.5,
      dy: 10,
    },
    yaxis: {
      min: 0
    }
  };
  _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}
BarMultiWithBG = Bar.extend(BarMultiWithBG, {
  beforeRender: function () {
    Bar.prototype.beforeRender.call(this);
    var data = this.data();
    var opt = this.options.yaxis;
    var ykey = opt.key;
    var union = [];
    data.forEach(function (obj) {
      union = _.union(union, obj[ykey]);
    });
    var max = _.maxBy(union);
    var min = _.minBy(union);
    opt.max = (max - min) + max;
    opt.min = min - (max - min);
  },
  afterRender: function () {
    Bar.prototype.afterRender.call(this);
    var opt = this.options;
    var x = this.getComs('axis', 'xaxis').getX();

    var updateBgAttr = function (d, i) {
      var that = d3.select(this);
      that.attr({
        x: function (d) {
          return x(d[opt.xaxis.key]);
        },
        y: -1,
        width: x.rangeBand(),
        height: opt.innerHeight + 2
      });
    };
    var bgs = this.series.selectAll('.serie-bg');
    this.series.selectAll('.series-group').each(function (d, i) {
      bgs[0][i] && updateBgAttr.call(bgs[0][i], d, i);
    });

    this.enterSeries.each(function (d, i) {
      var that = d3.select(this);
      var bg = that.insert('rect', '.serie')
        .attr({
          class: 'serie-bg'
        });
      updateBgAttr.call(bg[0][0], d, i);
    });

    this.outerSeries.each(function (d, i) {
      d3.select(this).select('.serie-bg').remove();
    });

    var svg = this.svg;
    svg.selectAll('.axis1 .tick text')
      .style({
        'writing-mode': 'tb',
        'glyph-orientation-vertical': 0
      });

    var axis = svg.select('.axis1');
    axis.selectAll('.tick:nth-child(2n+1) text')
      .attr('transform', 'translate(0,' + -16 * 3.5 + ')');

    axis.selectAll('.tick:nth-child(2n) text')
      .attr('transform', 'translate(0,' + (-opt.innerHeight + 8 * 0.5) + ')');

    svg[0][0].appendChild(axis[0][0]);
  },
  updateAfterRender: function () {
    this.afterRender();
  }
});

module.exports = BarMultiWithBG;
