dchart-bar-multi-matrix-with-bg

符合dchart规范的矩阵柱状图

### 安装

```
npm install dchart-bar-multi-matrix-with-bg
```

### 用法
```
var Bar = require('dchart-bar-multi-matrix-with-bg');
var bar = new Bar(container, {
  yaxis: {
    padding: [0, 0],          //柱状子间的间距[innerPadding, outerPadding],默认[0.9, 0.4]
    dy: 12,                   //位移
  },
  xaxis: {
    min: null                 //默认null会自动计算数据中的最小值
    max: null                 //默认null会自动计算数据中的最大值
  }
});
bar.render([
        {"x": "山东", "y": 100},
        {"x": "山西", "y": 52},
        {"x": "河北", "y": 49}
      ]);
```
