import { PublicKey } from "@solana/web3.js";
import { LuckySwapParams } from "./types";
import { LuckyswapsProgram } from ".";
export declare function knownReserveAsset(mint: PublicKey, program: LuckyswapsProgram): Promise<boolean>;
export declare function amSwappingFromReserve(params: LuckySwapParams): Promise<boolean>;
export declare function getVaultPda(params: LuckySwapParams): Promise<PublicKey>;
export declare function getReservePda(params: LuckySwapParams): Promise<PublicKey>;
/**
 * Converts an object (dictionary) to a query string
 * @param params - An object containing key-value pairs to convert
 * @returns A query string starting with '?', or an empty string if no params
 */
export declare function convertToQueryString(params: Record<string, string | number | boolean>): string;
//# sourceMappingURL=utils.d.ts.map