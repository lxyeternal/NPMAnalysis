/// <reference types="node" />
import { PublicKey } from "@solana/web3.js";
export declare const SEED_STATE: Buffer;
export declare const SEED_RESERVE: Buffer;
export declare function deriveStatePda(programId: PublicKey): [PublicKey, number];
export declare function deriveReservePda(mint: PublicKey, programId: PublicKey): [PublicKey, number];
export declare function deriveVaultPda(mint: PublicKey, owner: PublicKey): PublicKey;
//# sourceMappingURL=pda.d.ts.map