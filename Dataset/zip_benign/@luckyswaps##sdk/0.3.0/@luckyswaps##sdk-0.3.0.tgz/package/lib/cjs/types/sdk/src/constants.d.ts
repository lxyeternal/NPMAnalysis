export declare const LUCKIFY_PROGRAM_ID_STRING = "Lucky7RXZNtywxBXrGibRqrC3FcJYdvr34nFpU6DJVX";
export declare const LUCKIFY_PROGRAM_ID_LOCALNET_STRING = "D665VLt9rdGpwBuUGQuRqCK2FhA9nYXBdYewWexFwcFj";
export declare const JUPITER_PROGRAM_ID_STRING = "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4";
export declare const NUM_LUCKYSWAP_ACCOUNTS = 11;
export declare const MULTIPLIER_PRECISION = 1000;
export declare const U32_MAX = 4294967295;
export declare const MAX_THRESHOLD = 4294967295;
//# sourceMappingURL=constants.d.ts.map