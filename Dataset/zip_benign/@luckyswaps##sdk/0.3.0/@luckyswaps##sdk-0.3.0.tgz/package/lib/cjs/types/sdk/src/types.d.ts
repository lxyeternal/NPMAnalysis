import { PublicKey } from "@solana/web3.js";
export interface LuckySwapParams {
    payerAccount: PublicKey;
    inputMint: PublicKey;
    outputMint: PublicKey;
    userSourceAccount?: PublicKey;
    userTargetAccount?: PublicKey;
    program: any;
    amount: number;
    threshold: number;
    jupiterQuoteParams?: any;
    jupiterSwapParams?: any;
}
//# sourceMappingURL=types.d.ts.map