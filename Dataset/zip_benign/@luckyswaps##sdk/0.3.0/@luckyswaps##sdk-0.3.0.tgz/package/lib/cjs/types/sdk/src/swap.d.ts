import { LuckySwapParams } from "./types";
export declare function getQuote(params: LuckySwapParams): Promise<any>;
export declare function getJupiterInstructions(params: LuckySwapParams): Promise<any>;
export declare function getJupiterInstructionsForLuckySwap(params: LuckySwapParams): Promise<any>;
export declare function swap(params: LuckySwapParams): Promise<any>;
export declare function luckifyJupiterSwap(params: LuckySwapParams, instructions: any, cluster?: string): Promise<any>;
//# sourceMappingURL=swap.d.ts.map