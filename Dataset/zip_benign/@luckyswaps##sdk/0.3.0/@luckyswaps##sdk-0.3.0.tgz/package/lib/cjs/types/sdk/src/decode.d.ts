export declare function extractInAmount(data_base64: string): BigInt;
export declare function extractThreshold(data_base64: string): number;
//# sourceMappingURL=decode.d.ts.map