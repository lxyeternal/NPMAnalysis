import { Program, Wallet } from "@coral-xyz/anchor";
import { Connection, Keypair } from "@solana/web3.js";
import type { Luckyswaps } from "../../contract/target/types/luckyswaps";
declare const IDL: Luckyswaps;
export type LuckyswapsProgram = Program<Luckyswaps>;
export { IDL };
export declare function getProgram(connection: string | Connection, wallet?: Keypair | Wallet): Program<Luckyswaps>;
//# sourceMappingURL=program.d.ts.map