/**
 * Calculates fair multiplier using fixed-point arithmetic
 * @param threshold - The winning threshold (must be a positive integer less than or equal to UINT32_MAX)
 * @returns The multiplier scaled by MULTIPLIER_PRECISION
 * @example
 * // If fair multiplier is 2.5x, returns 2500 (for MULTIPLIER_PRECISION = 1000)
 * calculateFairMultiplier(2147483648) // returns 2000 (2x multiplier)
 * @throws Error if threshold is invalid or calculation would overflow
 */
export declare function calculateFairMultiplier(threshold: number): number;
//# sourceMappingURL=math.d.ts.map