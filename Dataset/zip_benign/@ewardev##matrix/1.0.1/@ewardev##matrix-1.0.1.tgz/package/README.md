# Extension for array like matrix

## Methods
### isVector - Determines whether an array is a vector
    console.log([1, 2, 3].isVector()); // true

### isMatrix - Determines whether an array is a matrix
    console.log([1, 2, 3].isMatrix()); // false

### transp - Еransposed matrix
    console.log([[1, 2, 3]].transp()); // [ [ 1 ], [ 2 ], [ 3 ] ]

### mul [NUMBER] - Multiplies the matrix by the number
    console.log([[1, 2, 3]].mul(2)); // [ [ 2, 4, 6 ] ]

### mul [MATRIX] or [VECTOR] - Multiplies the matrix by the matrix
    console.log([[1, 2, 3], [2, 3, 4]].mul([[1, 2, 3], [4, 5, 6],[7, 8, 9]])); // [ [ 30, 36, 42 ], [ 42, 51, 60 ] ]

### pow - Raises the matrix to the power
    console.log([[1, 2], [2, 3]].pow(10)); // [ [ 514229, 832040 ], [ 832040, 1346269 ] ]

### sum - Sums of the matrix
    console.log([[1, 2, 3], [2, 3, 4]].sum([[1, 2, 3], [4, 5, 6]])); // [ [ 2, 4, 6 ], [ 6, 8, 10 ] ]

### sub - Subs of the matrix
    console.log([[1, 2, 3], [2, 3, 4]].sub([[1, 2, 3], [4, 5, 6]])); // [ [ 0, 0, 0 ], [ -2, -2, -2 ] ]

### det - Finds the determinant of a matrix
    console.log([[1, 2, 3], [2, 3, 4], [7, 2, 3]].det()); // -6

### rank - Finds the rank of a matrix
    console.log([[1, 2, 3], [2, 3, 4]].rank()); // 2

### adjugate - Finds the adjugate of a matrix
    console.log([[1, 2, 3], [2, 3, 4], [7, 2, 3]].adjugate()); // [ [ 1, -0, -1 ], [ 22, -18, 2 ], [ -17, 12, -1 ] ]

### inverse - Finds the inverse of a matrix
    console.log([[1, 2], [3, 4]].inverse()); // [ [ -2, 1 ], [ 1.5, -0.5 ] ]

### E - Generates a single matrix of size n, m or the size of the original matrix
    console.log([[1, 2], [3, 4]].E()); // [ [ 1, 0 ], [ 0, 1 ] ]
    console.log([[1, 2], [3, 4]].E(3, 3)); // [ [ 1, 0, 0 ], [ 0, 1, 0 ], [ 0, 0, 1] ]

## Import to project
    require("@ewardev/matrix"); or import "@ewardev/matrix";

## Example
    require("./index");

    console.log([1, 2, 3].isVector()); // true

    console.log([1, 2, 3].isMatrix()); // false

    console.log([[1, 2, 3]].transp()); // [ [ 1 ], [ 2 ], [ 3 ] ]

    console.log([[1, 2, 3]].mul(2)); // [ [ 2, 4, 6 ] ]

    console.log([[1, 2, 3], [2, 3, 4]].mul([[1, 2, 3], [4, 5, 6],[7, 8, 9]])); // [ [ 30, 36, 42 ], [ 42, 51, 60 ] ]

    console.log([[1, 2], [2, 3]].pow(10)); // [ [ 514229, 832040 ], [ 832040, 1346269 ] ]

    console.log([[1, 2, 3], [2, 3, 4]].sum([[1, 2, 3], [4, 5, 6]])); // [ [ 2, 4, 6 ], [ 6, 8, 10 ] ]

    console.log([[1, 2, 3], [2, 3, 4]].sub([[1, 2, 3], [4, 5, 6]])); // [ [ 0, 0, 0 ], [ -2, -2, -2 ] ]

    console.log([[1, 2, 3], [2, 3, 4], [7, 2, 3]].det()); // -6

    console.log([[1, 2, 3], [2, 3, 4]].rank()); // 2

    console.log([[1, 2, 3], [2, 3, 4], [7, 2, 3]].adjugate()); // [ [ 1, -0, -1 ], [ 22, -18, 2 ], [ -17, 12, -1 ] ]

    console.log([[1, 2], [3, 4]].inverse()); // [ [ -2, 1 ], [ 1.5, -0.5 ] ]

    console.log([[1, 2], [3, 4]].E()); // [ [ 1, 0 ], [ 0, 1 ] ]
