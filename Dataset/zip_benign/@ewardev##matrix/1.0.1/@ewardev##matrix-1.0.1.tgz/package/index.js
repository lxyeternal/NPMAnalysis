const matrixOps = require("./matrix.js");

Array.prototype.isVector = function(array) {
  array = array || this;
  return Array.isArray(array) && !Array.isArray(array[0]);
};

Array.prototype.isMatrix = function(array) {
  array = array || this;
  return (
    Array.isArray(array) &&
    Array.isArray(array[0]) &&
    !Array.isArray(array[0][0])
  );
};

Array.prototype.transp = function() {
  if (this.isVector()) {
    throw new Error("Сan't transpose a vector");
  }
  return matrixOps.transp(this);
};

Array.prototype.mul = function(matrix) {
  if (typeof matrix === "number") {
    let A = this.isVector() ? [this] : this;
    return matrixOps.mulByNumber(matrix, A);
  }

  let A = this.isVector() ? [this] : this;
  let B = this.isVector(matrix) ? [matrix] : matrix;
  let result = matrixOps.mul(A, B);

  if (result === null) {
    throw new Error(
      `Can't multiply a matrix of dimension ${A.length}x${A[0].length} and ${
        B.length
      }x${B[0].length}`
    );
  }
  return result;
};

Array.prototype.sum = function(matrix) {
  let A = this.isVector() ? [this] : this;
  let B = this.isVector(matrix) ? [matrix] : matrix;
  return matrixOps.sum(A, B);
};

Array.prototype.sub = function(matrix) {
  let A = this.isVector() ? [this] : this;
  let B = this.isVector(matrix) ? [matrix] : matrix;
  return matrixOps.sub(A, B);
};

Array.prototype.pow = function(pow) {
  if (!this.isMatrix() || this.length !== this[0].length) {
    throw new Error("Can't pow not squericle matrix");
  }
  let A = this.isVector() ? [this] : this;
  return matrixOps.pow(pow, A);
};

Array.prototype.det = function() {
  if (!this.isMatrix() || this.length !== this[0].length) {
    throw new Error("Can't found determinant for matrix");
  }
  return matrixOps.det(this);
};

Array.prototype.rank = function() {
  if (!this.isMatrix()) {
    throw new Error("Can't found rank for non matrix");
  }
  return matrixOps.rank(this);
};

Array.prototype.adjugate = function() {
  if (!this.isMatrix()) {
    throw new Error("Can't found adjugate for non matrix");
  }
  return matrixOps.adjugate(this);
};

Array.prototype.inverse = function() {
  if (!this.isMatrix()) {
    throw new Error("Can't found inverse for non matrix");
  }
  let result = matrixOps.inverse(this);
  if (result === null) {
    throw new Error("Can't inverse matrux with determinant = 0");
  }
  return result;
};

Array.prototype.E = function(i, j) {
  if (!this.isMatrix() && i !== undefined && j !== undefined) {
    throw new Error("Can't generate once matrix for matrix");
  }
  i = i || this.length;
  j = j || this[0].length;
  let A = [];
  for (let k = 0; k < i; k++) {
    A[k] = [];
    for (let l = 0; l < j; l++) {
      A[k][l] = k === l ? 1 : 0;
    }
  }
  return A;
};
