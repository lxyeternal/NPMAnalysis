const transp = A => {
  let m = A.length,
    n = A[0].length,
    AT = [];

  for (let i = 0; i < n; i++) {
    AT[i] = [];
    for (let j = 0; j < m; j++) AT[i][j] = A[j][i];
  }
  return AT.map(x => x.map(y => y === 0 ? 0 : y));
};

const sum = (A, B) => {
  let m = A.length,
    n = A[0].length,
    C = [];
  for (let i = 0; i < m; i++) {
    C[i] = [];
    for (let j = 0; j < n; j++) C[i][j] = A[i][j] + B[i][j];
  }
  return C.map(x => x.map(y => y === 0 ? 0 : y));;
};

const sub = (A, B) => {
  let m = A.length,
    n = A[0].length,
    C = [];
  for (let i = 0; i < m; i++) {
    C[i] = [];
    for (let j = 0; j < n; j++) C[i][j] = A[i][j] - B[i][j];
  }
  return C.map(x => x.map(y => y === 0 ? 0 : y));;
};

const mulByNumber = (a, A) => {
  let m = A.length,
    n = A[0].length,
    B = [];
  for (let i = 0; i < m; i++) {
    B[i] = [];
    for (let j = 0; j < n; j++) B[i][j] = a * A[i][j];
  }
  return B.map(x => x.map(y => y === 0 ? 0 : y));;
};

const mul = (A, B) => {
  let rowsA = A.length,
    colsA = A[0].length,
    rowsB = B.length,
    colsB = B[0].length,
    C = [];
  if (colsA != rowsB) return null;
  for (let i = 0; i < rowsA; i++) C[i] = [];
  for (let k = 0; k < colsB; k++) {
    for (let i = 0; i < rowsA; i++) {
      let t = 0;
      for (let j = 0; j < rowsB; j++) t += A[i][j] * B[j][k];
      C[i][k] = t;
    }
  }
  return C.map(x => x.map(y => y === 0 ? 0 : y));;
};

const pow = (n, A) => {
  if (n == 1) return A.map(x => x.map(y => y === 0 ? 0 : y));
  else return mul(A, pow(n - 1, A));
};

const det = A => {
  let N = A.length,
    B = [],
    denom = 1,
    exchanges = 0;
  for (let i = 0; i < N; ++i) {
    B[i] = [];
    for (let j = 0; j < N; ++j) B[i][j] = A[i][j];
  }
  for (let i = 0; i < N - 1; ++i) {
    let maxN = i,
      maxValue = Math.abs(B[i][i]);
    for (let j = i + 1; j < N; ++j) {
      let value = Math.abs(B[j][i]);
      if (value > maxValue) {
        maxN = j;
        maxValue = value;
      }
    }
    if (maxN > i) {
      let temp = B[i];
      B[i] = B[maxN];
      B[maxN] = temp;
      ++exchanges;
    } else {
      if (maxValue == 0) return maxValue;
    }
    let value1 = B[i][i];
    for (let j = i + 1; j < N; ++j) {
      let value2 = B[j][i];
      B[j][i] = 0;
      for (let k = i + 1; k < N; ++k)
        B[j][k] = (B[j][k] * value1 - B[i][k] * value2) / denom;
    }
    denom = value1;
  }
  if (exchanges % 2) return -B[N - 1][N - 1] === 0 ? 0 : -B[N - 1][N - 1];
  else return B[N - 1][N - 1] === 0 ? 0 : B[N - 1][N - 1];
};

const rank = A => {
  let m = A.length,
    n = A[0].length,
    k = m < n ? m : n,
    r = 1,
    rank = 0;
  while (r <= k) {
    let B = [];
    for (let i = 0; i < r; i++) B[i] = [];
    for (let a = 0; a < m - r + 1; a++) {
      for (let b = 0; b < n - r + 1; b++) {
        for (let c = 0; c < r; c++) {
          for (let d = 0; d < r; d++) B[c][d] = A[a + c][b + d];
        }
        if (det(B) != 0) rank = r;
      }
    }
    r++;
  }
  return rank === 0 ? 0 : rank;
};

const adjugate = A => {
  let N = A.length,
    adjA = [];
  for (let i = 0; i < N; i++) {
    adjA[i] = [];
    for (let j = 0; j < N; j++) {
      let B = [],
        sign = (i + j) % 2 == 0 ? 1 : -1;
      for (let m = 0; m < j; m++) {
        B[m] = [];
        for (let n = 0; n < i; n++) B[m][n] = A[m][n];
        for (let n = i + 1; n < N; n++) B[m][n - 1] = A[m][n];
      }
      for (let m = j + 1; m < N; m++) {
        B[m - 1] = [];
        for (let n = 0; n < i; n++) B[m - 1][n] = A[m][n];
        for (let n = i + 1; n < N; n++) B[m - 1][n - 1] = A[m][n];
      }
      adjA[i][j] = sign * det(B);
    }
  }
  return adjA.map(x => x.map(y => y === 0 ? 0 : y));
};

const inverse = A => {
  let d = det(A);
  if (d == 0) return null;
  let N = A.length;
  A = adjugate(A);
  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) A[i][j] /= d;
  }
  return A.map(x => x.map(y => y === 0 ? 0 : y));
};

module.exports = {
  transp,
  sum,
  sub,
  mulByNumber,
  mul,
  pow,
  det,
  rank,
  adjugate,
  inverse
}
