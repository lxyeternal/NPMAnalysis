/**
 * getParams 获取参数的值
 * @param params 必选(可以是完整的url地址,正常的param参数(a=5&b=5))
 * @param name  可选(得到其中的某个指定的name值)
 * @returns { null|string|{} }
 * eg: 当找不到值时返回null
 * let params = 'a=5&b=6';
 * let val = getParams(params);
 * console.log(val, 'c'); // 结果null
 */
export default function (params = "", name = "") {
  let regx = /([^&?=]+)=([^&?=]+)/g;
  let obj = {};
  params.replace(regx, (...args) => {
    if (obj[args[1]]) {
      obj[args[1]] = Array.isArray(obj[args[1]])
        ? obj[args[1]]
        : [obj[args[1]]];
      obj[args[1]].push(args[2]);
    } else {
      obj[args[1]] = args[2];
    }
  });
  if (JSON.stringify(obj) === "{}") {
    return null;
  } else if (name) {
    return obj[name] === undefined ? null : obj[name];
  } else {
    return obj;
  }
};
