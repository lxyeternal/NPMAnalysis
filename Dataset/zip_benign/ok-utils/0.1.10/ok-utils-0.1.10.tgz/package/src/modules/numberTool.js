/**
 * 随机指定范围的整数
 * @param min 开始值（包含）
 * @param max 结束值（不包含）
 */
export const randomNum = function (min = 1, max = 100){
  const num = Math.random() * (max - min) + min;
  return parseInt(num + "");
};

export default {
  randomNum,
}
