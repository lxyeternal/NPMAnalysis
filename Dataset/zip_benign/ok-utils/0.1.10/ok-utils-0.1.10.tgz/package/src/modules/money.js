/**
 * 将数字转化成货币
 * @param num   传入的值
 * @param format   千位分割符 默认没有
 * @param isDecimals    是否保留两位00小数 默认是
 * eg:utils.money(8.379999999999999) 结果 8.38
 * eg:utils.money(8.780000000000001) 结果 8.78
 * @returns {*}
 */
let money = function (num, format = '', isDecimals = true) {
  let sign, cents
  if (isNaN(num)) num = '0'
  let reg = new RegExp('\$|', 'g')
  num = num.toString().replace(reg, '')
  sign = (num == (num = Math.abs(num)))
  num = Math.floor(num * 100 + 0.50000000001)
  cents = num % 100
  num = Math.floor(num / 100).toString()
  if (cents < 10) {
    cents = '.0' + cents
  } else {
    cents = '.' + cents
  }
  if (format) { // 千位分割符
    for (let i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
      num = num.substring(0, num.length - (4 * i + 3)) + format + num.substring(num.length - (4 * i + 3))
    }
  }
  if (isDecimals) { // 当小数位数不为2的时候去掉后边的0
    cents = cents.replace(/0*$/g, '').replace(/\.*$/, '')
  }

  return ((sign) ? '' : '-') + num + cents
};

export default money;
