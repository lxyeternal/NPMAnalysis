/**
* 防抖函数
*/
export default function (callback, wait) {
	wait = wait || 300;//默认防抖300毫秒触发
    let timer = null;
    return function(){
        //清除上一次的延时器
        clearTimeout(timer);
        //重新设置新的延时器
        timer = setTimeout(function(args) {
            callback.apply(this, args);
        }.bind(this, arguments), wait);
    }
}