/**
 * 自定义正则验证规则判断
 */
import typeOf from "./typeOf.js";
import stringTools from "./stringTool.js";
import regexp from "./regexpHelper.js";

/**
 * @param vali
 * @param val
 * @returns {*|boolean}
 */
function patternBool(vali, val) {
	let globalMsg = vali.msg;
	return (function patternInit(pattern, msg) {
		switch (typeOf(pattern)) { //regexp,array,object
			case "regexp":
				if (!pattern.test(val)) {
					return msg || globalMsg || ("请输入正确的" + vali.name);
				}
				break;
			case "array":
				for (let i = 0; i < pattern.length; i++) {
					if (typeOf(pattern[i]) === "object") {
						let temp = patternInit(pattern[i]);
						if (temp) {
							return temp;
						}
					} else if (!pattern[i].test(val)) {
						return msg || globalMsg || ("请输入正确的" + vali.name);
					}
				}
				break;
			case "object":
				if (typeOf(pattern.value) === "array") { //判断一次减少自身调用
					return patternInit(pattern.value, pattern.msg || msg);
				} else if (!pattern.value.test(val)) {
					return pattern.msg || globalMsg || ("请输入正确的" + vali.name);
				}
				break;
		}
		return false;
	}(vali.pattern, vali.pattern.msg));
}

/**
 * 自定义type规则验证
 * @param vali
 * @param val
 * @returns {boolean|*|string}
 */
function typeBool(vali, val) {
	let globalMsg = vali.msg, //全局提示消息
		isAndOr = "&",  //默认全验证
		msg = vali.msg,   //提示信息
		value = "",     //验证器
		values = "";    //验证器组
	return (function patternInit(pattern, msg) {
		switch (typeOf(pattern)) { //string, array, object
			case "string":
				value = pattern;
				if (!value) return false;
				isAndOr = value.indexOf("|") >= 0 ? '|' : '&';
				values = value.split(isAndOr);
				for (let i = 0; i < values.length; i++) {
					if (isAndOr === "&" && !regexp[values[i]].test(val)) {
						return msg || globalMsg || ("请输入正确的" + vali.name);
					} else if (isAndOr === "|" && regexp[values[i]].test(val)) {
						return false;
					}
				}
				return isAndOr === "&" ? false : msg || ("请输入正确的" + vali.name);
				break;
			case "array":
				let temp = false;
				for (let k = 0; k < pattern.length; k++) {
					if (typeOf(pattern[k]) === "object") {
						temp = patternInit(pattern[k]);
						if (temp) {
							return temp;
						}
					} else {
						temp = patternInit(pattern[k], msg);
						if (temp) {
							return temp;
						}
					}
				}
				break;
			case "object":
				return patternInit(pattern.value, pattern.msg || msg);
				break;
			default:
				return msg;
		}
	}(vali.type, vali.msg));
}

/**
 * 表单验证器
 * @param  {Object} data      [description]
 * @param  {Object} validator [description]
 * @param  {this} self 当前上下文对象
 * @return {Object|Boolean}           [description]
 */
let formValidator = function (data, validator, self) {
	let keys = Object.keys(validator);
	let key = "", //validator验证的key
		message = "", //验证未通过返回的值
		val = "", //验证的值
		vali = ""; //验证对象
	for (let i = 0; i < keys.length; i++) {
		key = keys[i];
		message = {
			key: keys[i],
			msg: "",
		};
		val = data[keys[i]];
		vali = validator[keys[i]]; //验证对象
		vali.name = vali.name || keys[i];
		if (vali) {
			if (vali.required !== false) { //必填的
				if (val === undefined || val === null || val === "") {
					message.msg = vali.required === true
						? (vali.msg || ("请输入" + vali.name))
						: vali.required;
					return message;
				} else if (stringTools.trimAll(val, true) === "") {
					message.msg = "输入的" + vali.name + "不能只有空格";
					return message;
				}
			}
			if (val !== undefined && val !== null && val !== "") { //选填的
				if (stringTools.trimAll(val, true) === "") {
					message.msg = "输入的" + vali.name + "不能只有空格";
					return message;
				} else if (vali.type) { //内置验证器
					let verifyVal = typeBool(vali, val);
					if (verifyVal) {
						message.msg = verifyVal;
						return message;
					}
				} else if (vali.pattern) { //自定义正则验证
					let verifyVal = patternBool(vali, val);
					if (verifyVal) {
						message.msg = verifyVal;
						return message;
					}
				} else if (vali.minLength && val.length < vali.minLength) {
					message.msg = vali.name + "长度最小" + vali.minLength + "个字符";
					return message;
				} else if (vali.maxLength && val.length > vali.maxLength) {
					message.msg = vali.name + "长度最大" + vali.maxLength + "个字符";
					return message;
				} else if (vali.min && val < vali.min) {
					message.msg = vali.name + "最小为" + vali.min;
					return message;
				} else if (vali.max && val > vali.max) {
					message.msg = vali.name + "最大不超过" + vali.max;
					return message;
				} else if (vali.callback) { //自定义方法验证
					let temp = vali.callback(val, data, self);
					if (temp) {
						message.msg = temp;
						return message;
					}
				}
			}
		}
	}
	return false;
};

export default formValidator;
