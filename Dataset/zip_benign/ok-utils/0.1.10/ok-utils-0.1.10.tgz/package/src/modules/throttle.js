/**
* 函数节流
*/
export default function (callback, wait) {
	wait = wait || 300;//默认节流300毫秒触发
    let lastTime = 0;//记录上一次函数触发的时间
    return function () {
        let nowTime = Date.now();
        if (lastTime < 1 || nowTime - lastTime >= wait) {
            callback.apply(this, arguments);
            lastTime = nowTime;
        }
    }
}