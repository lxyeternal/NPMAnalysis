let dateFormat = function (timestamp, format) {
  format = format.replace(/d/gi, 'D');
  const _timestamp = timestamp ? Number(timestamp) : 0;
  if (!isNaN(_timestamp) && _timestamp.toString().length === 10) {
    timestamp = Number(timestamp) * 1000;
  }
  const date = timestamp ? new Date(timestamp) : new Date();

  const o = {
    "M+": date.getMonth() + 1,                 //月份
    "D+": date.getDate(),                    //日
    "h+": date.getHours(),                   //小时
    "m+": date.getMinutes(),                 //分
    "s+": date.getSeconds(),                 //秒
    "q+": Math.floor((date.getMonth() + 3) / 3), //季度
    "S": date.getMilliseconds()             //毫秒
  };
  if (/(y+)/i.test(format)) {
    format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  for (const k in o) {
    if (new RegExp("(" + k + ")").test(format)) {
      format = format.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return format;
};

let dateTool = {
  /**
   * 时间戳格式化
   * eg: date.format("YYYY年MM月DD")
   * eg: date.format("yyyy年MM月dd")
   * eg: date.format("yyyy年MM月DD hh:mm:ss")
   * eg: date.format(1597228752352)
   * eg: date.format(1597228752,"YY年MM月DD")
   * eg: date.format(1597228752,"YYYY年MM月DD")
   * eg: date.format(1597228752,"yy年MM月DD")
   * eg: date.format(1597228752,"yyyy年MM月DD")
   * @param timestamp 传入的时间戳(不传为当前时间，可传format格式,时间戳可以使秒或者毫秒)
   * @param format    格式化（默认yyyy年MM年dd）
   * @returns String
   */
  format: function (timestamp, format) {
    format = format || 'YYYY年MM月DD';
    timestamp = timestamp || new Date() * 1;
    if (typeof timestamp == "string" && isNaN(timestamp * 1)) {
      let temp = timestamp.toLocaleLowerCase();
      if (temp.indexOf("y") >= 0 || temp.indexOf("m") || temp.indexOf("d") || temp.indexOf("h") || temp.indexOf("n")) {
        format = timestamp;
      }
      timestamp = new Date() * 1;
    }
    return dateFormat(timestamp, format);
  },
  time: function () { //返回当前以秒为单位的时间戳
    return parseInt(new Date() / 1000);
  }
};
export default dateTool;
