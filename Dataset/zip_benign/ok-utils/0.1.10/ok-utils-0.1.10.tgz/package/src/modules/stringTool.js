
/**
 * 字符串工具类
 */
const strHandle = function (str) {
	if(str === undefined || str === null){
		str = str || "";
	}
	if (typeof str == "object") {
		return JSON.stringify(str);
	} else {
		str += "";
		return str;
	}
}

export default {
	/**
	 * 比较两个值是否一致
	 * @param {object} str
	 * @param {object} val
	 * @returns {boolean}
	 */
	equals: function (str, val) {
		str = strHandle(str);
		return str === val;
	},

	/**
	 * 清除两边所有的空格
	 * @param {string} str
	 * @param {boolean} isTab 是否清除所有的回车，tab符
	 * @returns string
	 */
	trim(str, isTab) {
		str = strHandle(str);
		if (isTab) {
			return str.replace(/(^\s+|\s+$|\t|\n|\r)/g, "");
		} else {
			return str.replace(/(^\s+|\s+$)/g, "");
		}
	},

	/**
	 * 清除左边所有的空格
	 * @param {string} str
	 * @param {boolean} isTab 是否清除所有的回车，tab符
	 * @returns string
	 */
	trimL: function (str, isTab) {
		str = strHandle(str);
		if (isTab) {
			return str.replace(/(^\s*|\t|\n|\r)/g, "");
		} else {
			return str.replace(/(^\s*)/g, "");
		}
	},

	/**
	 * 清除右边所有的空格
	 * @param {string} str
	 * @param {boolean} isTab 是否清除所有的回车，tab符
	 * @returns string
	 */
	trimR: function (str, isTab) {
		str = strHandle(str);
		if (isTab) {
			return str.replace(/(\s*$|\t|\n|\r)/g, "");
		} else {
			return str.replace(/(\s*$)/g, "");
		}
	},

	/**
	 * 清除所有的空格
	 * @param {string} str
	 * @param {boolean} isTab 是否清除所有的回车，tab符
	 * @returns string
	 */
	trimAll: function (str, isTab) {
		str = strHandle(str);
		if (isTab) {
			return str.replace(/(\s*|\t|\n|\r)/g, "");
		} else {
			return str.replace(/(\s*)/g, "");
		}
	}
}
