/**
 * 判断文件类型
 */
import typeOf from "./typeof.js";

const FILE_BOOL = {
  "PNG": '89 50 4E 47 0D 0A 1A 0A',
  "GIF": '47 49 46 38',
  "PDF": '25 50 44 46',
  "XLS_DOC": 'D0 CF 11 E0',
  "XLSX_DOCX": '50 4B 03 04 14 00 06 00 08 00 00 00 21 00',
  "ZIP": [
    '50 4B 03 04',
    '50 4B 05 06',
    '50 4B 07 08',
  ],
  "RAR": '52 61 72 21 1A 07 00',
  "7Z": '37 7A BC AF 27 1C',
  "BZ": '42 5A 68',
  "TAR": '1F 8B 08',
  "MP3": '49 44 33 03 00 00 00 00 21 76',
  "FLV": '46 4C 56 01 05 00 00 00 09 00',
  "MP4": '00 00 00 20 66 74 79 70 6D 70',
};

const fileTool = {
  /**
   * 将File对象转成16进制
   * @param file <File|Blob>
   * @returns {Promise<string>}
   * @private
   */
  _hexdump: function (file) {
    return new Promise(resolve => {
      const fr = new FileReader();
      fr.readAsArrayBuffer(file);
      fr.addEventListener("loadend", (e) => {
        const res = e.target.result;
        let tempStr = [];
        (new Uint8Array(res)).forEach(item => {
          let temp = (item.toString(16)).toLocaleUpperCase();
          temp = temp.length < 2 ? 0 + temp : temp;
          tempStr.push(temp);
        });
        resolve(tempStr.join(" "));
      }, false);
    });
  },

  /**清除字符串中所有的空格*/
  _trimAll: function (str, isTab) {
    if (isTab) {
      return str.replace(/(\s*|\t|\n|\r)/g, "");
    } else {
      return str.replace(/(\s*)/g, "");
    }
  },

  /**
   * 得到文件的base64
   * @param file
   * @returns {Promise<{base64: '', name: ''}>}
   */
  fileBase64: function (file) {
    const data = {
      base64: '',
      name: file.name
    };
    return new Promise(resolve => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        data.base64 = e.target['result'];
        resolve(data);
      };
    });
  },

  /**
   * 判断文件 类型
   * @param file File
   * @param key String
   * @returns {Promise<boolean>}
   */
  async isFile(file, key) {
    const hex = FILE_BOOL[key];
    let len = 0;
    // return new Promise(resolve => {});
    if (typeOf(hex) === "array") {
      for (let i = 0; i < hex.length; i++) {
        len = parseInt((fileTool._trimAll(hex[i]).length / 2) + "");
        let fileHex = await fileTool._hexdump(file.slice(0, len));
        if (hex[i] === fileHex) {
          return true;
        }
      }
      return false;
    } else {
      len = parseInt((fileTool._trimAll(hex).length / 2) + "");
      let fileHex = await fileTool._hexdump(file.slice(0, len));
      return hex === fileHex;
    }
  },

  /**
   * 判断文件是否是JPG文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isJPG(file) {
    let len = file.size;
    let start = await this._hexdump(file.slice(0, 2));//FF D8
    let end = await this._hexdump(file.slice(-2, len));//FF D9

    return start === "FF D8" && end === "FF D9";
  },

  /**
   * 判断文件是否是PNG文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isPNG(file) {
    return this.isFile(file, 'PNG');
  },

  /**
   * 判断文件是否是GIF文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isGIF(file) {
    return this.isFile(file, 'GIF');
  },

  /**
   * 判断文件是否是PDF文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isPDF(file) {
    return this.isFile(file, 'PDF');
  },

  /**
   * 判断文件是否是zip文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isZIP(file) {
    return this.isFile(file, 'ZIP');
  },

  /**
   * 判断文件是否是7z文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async is7Z(file) {
    return this.isFile(file, '7Z');
  },

  /**
   * 判断文件是否是rar文件
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isRAR(file) {
    return this.isFile(file, 'RAR');
  },

  /**
   * 判断是否是图片 '.png', '.jpg', '.jpeg', '.gif'
   * @param file
   * @returns {Promise<boolean>}
   */
  async isImg(file) {
    const _suffix = (file.name.substring(file.name.lastIndexOf('.'))).toLowerCase();
    switch (_suffix) {
      case '.png':
        return this.isPNG(file);
      case '.gif':
        return this.isGIF(file);
      default:
        if (_suffix === '.jpg' || _suffix === '.jpeg') {
          return this.isJPG(file);
        } else {
          return false;
        }
    }
  },

  /**
   * 判断文件是否是压缩文件 '.zip', '.7z', '.rar'
   * @param file File
   * @returns {Promise<boolean>}
   */
  async isArchive(file) {
    const _suffix = (file.name.substring(file.name.lastIndexOf('.'))).toLowerCase();
    switch (_suffix) {
      case '.zip':
        return this.isZIP(file);
      case '.7z':
        return this.is7Z(file);
      case '.rar':
        return this.isRAR(file);
      default:
        return false;
    }
  }

}

export default fileTool;
