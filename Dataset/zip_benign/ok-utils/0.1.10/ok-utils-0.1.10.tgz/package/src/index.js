
// export {default as formValidator} from "./modules/formValidator";
export const formValidator = require('./modules/formValidator')['default'];
export const typeOf = require('./modules/typeOf')['default'];
export const throttle = require('./modules/throttle')['default'];
export const debounce = require('./modules/debounce')['default'];
export const money = require('./modules/money')['default'];
export const getParams = require('./modules/getParams')['default'];

export const dateTool = require('./modules/dateTool')['default'];
export const fileTool = require('./modules/fileTool')['default'];
export const stringTool = require('./modules/stringTool')['default'];
export const numberTool = require('./modules/numberTool')['default'];

let okUtils = {
  formValidator,
  typeOf,
  throttle,
  debounce,
  money,
  getParams,
  dateTool,
  stringTool,
  numberTool,
  fileTool
}

export default okUtils;

