# `ok-utils`

> 一些js常用的工具类（时间戳格式化，函数节流/防抖，文件类型判断，表单验证...）

## Usage
1. 添加依赖

```
$ yarn add ok-utils
or
$ npm install ok-utils -S
```

2. 应用

```js
import { 
  money, 
  dateTool
} from 'ok-utils';

const price = money(0.1+0.2); // 结果0.3
const fmt = dateTool.format('YYYY-MM-DD'); //返回当前年月日
const fmtdate = dateTool.format('YYYY-MM-DD hh:mm:ss', 1616397831); //返回指定时间戳的时间
const timestamp = dateTool.time(); //得到当前以秒为单位的时间戳
```

3. 演示部分表单验证器的使用

```js
import { formValidator } from 'ok-utils';
const formData = {
  username: '》？',
  password: '',
  passwordYes: '',
};
const validator = {
  username: {
    name: "用户名",
    required: "用户名不能为空",
    type: {
      value: "userName",
      msg: "用户名格式有误",
    }
  },
  password: {
    name: "密码",
    required: "密码不能为空",

    type: {
      value: "password|chinese",
      msg: "密码格式有误",
    },
  },
  passwordYes: {
    name: "确认密码",
    required: "请输入确认密码",
    callback: function (val, data){
      if(val !== data.password){
        return "两次密码不一致"
      }
    }
  }
}
let bool = formValidator(formData, validator);
console.log(bool); // 结果：{key: "username", msg: "用户名格式有误"}

```
