'use strict';

var core = require('@tauri-apps/api/core');

/**
  * Scan for BLE devices
  * @param handler - A function that will be called with an array of devices found during the scan
  * @param timeout - The scan timeout in milliseconds
*/
async function startScan(handler, timeout) {
    if (!timeout) {
        timeout = 10000;
    }
    let onDevices = new core.Channel();
    onDevices.onmessage = handler;
    await core.invoke('plugin:blec|scan', {
        timeout,
        onDevices
    });
}
/**
  * Stop scanning for BLE devices
*/
async function stopScan() {
    console.log('stop scan');
    await core.invoke('plugin:blec|stop_scan');
}
/**
  * Check if necessary permissions are granted
  * @returns true if permissions are granted, false otherwise
  */
async function checkPermissions() {
    return await core.invoke('plugin:blec|check_permissions');
}
/**
  * Register a handler to receive updates when the connection state changes
*/
async function getConnectionUpdates(handler) {
    let connection_chan = new core.Channel();
    connection_chan.onmessage = handler;
    await core.invoke('plugin:blec|connection_state', { update: connection_chan });
}
/**
 * Register a handler to receive updates when the scanning state changes
 */
async function getScanningUpdates(handler) {
    let scanning_chan = new core.Channel();
    scanning_chan.onmessage = handler;
    await core.invoke('plugin:blec|scanning_state', { update: scanning_chan });
}
/**
  * Disconnect from the currently connected device
*/
async function disconnect() {
    await core.invoke('plugin:blec|disconnect');
}
/**
  * Connect to a BLE device
  * @param address - The address of the device to connect to
  * @param onDisconnect - A function that will be called when the device disconnects
*/
async function connect(address, onDisconnect) {
    console.log('connect', address);
    let disconnectChannel = new core.Channel();
    if (onDisconnect) {
        disconnectChannel.onmessage = onDisconnect;
    }
    try {
        await core.invoke('plugin:blec|connect', {
            address: address,
            onDisconnect: disconnectChannel
        });
    }
    catch (e) {
        console.error(e);
    }
}
/**
 * Write a Uint8Array to a BLE characteristic
 * @param characteristic UUID of the characteristic to write to
 * @param data Data to write to the characteristic
 */
async function send(characteristic, data, writeType = 'withResponse') {
    await core.invoke('plugin:blec|send', {
        characteristic,
        data,
        writeType,
    });
}
/**
 * Write a string to a BLE characteristic
 * @param characteristic UUID of the characteristic to write to
 * @param data Data to write to the characteristic
 */
async function sendString(characteristic, data, writeType = 'withResponse') {
    await core.invoke('plugin:blec|send_string', {
        characteristic,
        data,
        writeType,
    });
}
/**
 * Read bytes from a BLE characteristic
 * @param characteristic UUID of the characteristic to read from
 */
async function read(characteristic) {
    let res = await core.invoke('plugin:blec|recv', {
        characteristic
    });
    return res;
}
/**
 * Read a string from a BLE characteristic
 * @param characteristic UUID of the characteristic to read from
 */
async function readString(characteristic) {
    let res = await core.invoke('plugin:blec|recv_string', {
        characteristic
    });
    return res;
}
/**
 * Unsubscribe from a BLE characteristic
 * @param characteristic UUID of the characteristic to unsubscribe from
 */
async function unsubscribe(characteristic) {
    await core.invoke('plugin:blec|unsubscribe', {
        characteristic
    });
}
/**
 * Subscribe to a BLE characteristic
 * @param characteristic UUID of the characteristic to subscribe to
 * @param handler Callback function that will be called with the data received for every notification
 */
async function subscribe(characteristic, handler) {
    let onData = new core.Channel();
    onData.onmessage = handler;
    await core.invoke('plugin:blec|subscribe', {
        characteristic,
        onData
    });
}
/**
 * Subscribe to a BLE characteristic. Converts the received data to a string
 * @param characteristic UUID of the characteristic to subscribe to
 * @param handler Callback function that will be called with the data received for every notification
 */
async function subscribeString(characteristic, handler) {
    let onData = new core.Channel();
    onData.onmessage = handler;
    await core.invoke('plugin:blec|subscribe_string', {
        characteristic,
        onData
    });
}

exports.checkPermissions = checkPermissions;
exports.connect = connect;
exports.disconnect = disconnect;
exports.getConnectionUpdates = getConnectionUpdates;
exports.getScanningUpdates = getScanningUpdates;
exports.read = read;
exports.readString = readString;
exports.send = send;
exports.sendString = sendString;
exports.startScan = startScan;
exports.stopScan = stopScan;
exports.subscribe = subscribe;
exports.subscribeString = subscribeString;
exports.unsubscribe = unsubscribe;
