export type BleDevice = {
    address: string;
    name: string;
    rssi: number;
    isConnected: boolean;
    services: string[];
    manufacturerData: Record<number, Uint8Array>;
    serviceData: Record<string, Uint8Array>;
};
/**
  * Scan for BLE devices
  * @param handler - A function that will be called with an array of devices found during the scan
  * @param timeout - The scan timeout in milliseconds
*/
export declare function startScan(handler: (devices: BleDevice[]) => void, timeout: Number): Promise<void>;
/**
  * Stop scanning for BLE devices
*/
export declare function stopScan(): Promise<void>;
/**
  * Check if necessary permissions are granted
  * @returns true if permissions are granted, false otherwise
  */
export declare function checkPermissions(): Promise<boolean>;
/**
  * Register a handler to receive updates when the connection state changes
*/
export declare function getConnectionUpdates(handler: (connected: boolean) => void): Promise<void>;
/**
 * Register a handler to receive updates when the scanning state changes
 */
export declare function getScanningUpdates(handler: (scanning: boolean) => void): Promise<void>;
/**
  * Disconnect from the currently connected device
*/
export declare function disconnect(): Promise<void>;
/**
  * Connect to a BLE device
  * @param address - The address of the device to connect to
  * @param onDisconnect - A function that will be called when the device disconnects
*/
export declare function connect(address: string, onDisconnect: (() => void) | null): Promise<void>;
/**
 * Write a Uint8Array to a BLE characteristic
 * @param characteristic UUID of the characteristic to write to
 * @param data Data to write to the characteristic
 */
export declare function send(characteristic: string, data: Uint8Array, writeType?: 'withResponse' | 'withoutResponse'): Promise<void>;
/**
 * Write a string to a BLE characteristic
 * @param characteristic UUID of the characteristic to write to
 * @param data Data to write to the characteristic
 */
export declare function sendString(characteristic: string, data: string, writeType?: 'withResponse' | 'withoutResponse'): Promise<void>;
/**
 * Read bytes from a BLE characteristic
 * @param characteristic UUID of the characteristic to read from
 */
export declare function read(characteristic: string): Promise<Uint8Array>;
/**
 * Read a string from a BLE characteristic
 * @param characteristic UUID of the characteristic to read from
 */
export declare function readString(characteristic: string): Promise<string>;
/**
 * Unsubscribe from a BLE characteristic
 * @param characteristic UUID of the characteristic to unsubscribe from
 */
export declare function unsubscribe(characteristic: string): Promise<void>;
/**
 * Subscribe to a BLE characteristic
 * @param characteristic UUID of the characteristic to subscribe to
 * @param handler Callback function that will be called with the data received for every notification
 */
export declare function subscribe(characteristic: string, handler: (data: Uint8Array) => void): Promise<void>;
/**
 * Subscribe to a BLE characteristic. Converts the received data to a string
 * @param characteristic UUID of the characteristic to subscribe to
 * @param handler Callback function that will be called with the data received for every notification
 */
export declare function subscribeString(characteristic: string, handler: (data: string) => void): Promise<void>;
