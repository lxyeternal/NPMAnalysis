export declare function useLockScroll(rootRef: any, shouldLock: any): void;
