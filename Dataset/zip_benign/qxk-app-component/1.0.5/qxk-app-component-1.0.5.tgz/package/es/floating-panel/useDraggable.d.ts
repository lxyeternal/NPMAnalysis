/**
 * Make elements draggable.
 *
 * @see https://vueuse.org/useDraggable
 * @param target
 * @param options
 */
export declare function useDraggable(target: any, options?: any): {
    position: any;
    isDragging: import("vue").ComputedRef<boolean>;
    style: import("vue").ComputedRef<string>;
};
