export declare const FloatingPanel: import("vue").DefineComponent<{
    anchors: {
        type: ArrayConstructor;
        default: () => never[];
    };
    isFollowScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    height: {
        type: NumberConstructor;
        default: number;
    };
}, () => JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "heightChange"[], "heightChange", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    anchors: {
        type: ArrayConstructor;
        default: () => never[];
    };
    isFollowScroll: {
        type: BooleanConstructor;
        default: boolean;
    };
    height: {
        type: NumberConstructor;
        default: number;
    };
}>> & {
    onHeightChange?: ((...args: any[]) => any) | undefined;
}, {
    anchors: unknown[];
    isFollowScroll: boolean;
    height: number;
}, {}>;
export default FloatingPanel;
