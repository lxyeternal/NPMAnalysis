export declare function useEventListener(target: any, events: any, listeners: any, options: any): void;
