export declare function useTouch(): {
    move: (event: any) => void;
    start: (event: any) => void;
    reset: () => void;
    startX: import("vue").Ref<number>;
    startY: import("vue").Ref<number>;
    deltaX: import("vue").Ref<number>;
    deltaY: import("vue").Ref<number>;
    offsetX: import("vue").Ref<number>;
    offsetY: import("vue").Ref<number>;
    direction: import("vue").Ref<string>;
    isVertical: () => boolean;
    isHorizontal: () => boolean;
};
