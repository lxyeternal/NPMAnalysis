declare namespace _default {
    export { install };
    export { version };
}
export default _default;
export function install(app: any): void;
export const version: "1.0.4";
import FloatingPanel from './floating-panel';
import Keyboard from './keyboard';
export { FloatingPanel, Keyboard };
