import './index-sfc.css';
declare const __vue_sfc__: import("vue").DefineComponent<{
    length: {
        type: NumberConstructor;
        default: number;
    };
    licenseList: {
        type: ArrayConstructor;
        default: () => never[];
    };
    city: {
        type: StringConstructor;
        default: string;
    };
    defaultLicense: {
        type: StringConstructor;
        default: string;
    };
    show: {
        type: BooleanConstructor;
        default: boolean;
    };
}, {
    defaultCity: import("vue").Ref<string>;
    visible: import("vue").Ref<boolean>;
    list: any;
    keyboardType: import("vue").ComputedRef<"cn" | "en">;
    carNolist: import("vue").Ref<any[]>;
    isPass: import("vue").ComputedRef<boolean>;
    keyboardActive: import("vue").Ref<string>;
    carActive: import("vue").Ref<number>;
    handleTag: (item: any) => void;
    handleClick: (item: any) => void;
    deleteCard: () => void;
    close: () => void;
    ok: () => void;
    onTouchStart: (index: any, subIdx: any, subItem: any) => void;
    onTouchEnd: () => void;
    hideKeyboard: (event: any) => void;
    handleLicense: (idx: any) => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("close" | "confirm")[], "close" | "confirm", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    length: {
        type: NumberConstructor;
        default: number;
    };
    licenseList: {
        type: ArrayConstructor;
        default: () => never[];
    };
    city: {
        type: StringConstructor;
        default: string;
    };
    defaultLicense: {
        type: StringConstructor;
        default: string;
    };
    show: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & {
    onClose?: ((...args: any[]) => any) | undefined;
    onConfirm?: ((...args: any[]) => any) | undefined;
}, {
    length: number;
    licenseList: unknown[];
    city: string;
    defaultLicense: string;
    show: boolean;
}, {}>;
export default __vue_sfc__;
