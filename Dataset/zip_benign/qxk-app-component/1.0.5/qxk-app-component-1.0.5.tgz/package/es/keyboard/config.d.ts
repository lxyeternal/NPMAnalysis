export declare const areaOptions: {
    text: string;
    disabled: boolean;
}[];
export declare const engKeyBoardOptions: ({
    text: number;
    disabled: boolean;
} | {
    text: string;
    disabled: boolean;
})[];
