import { UxlAutocomplete } from "./uxl-autocomplete";
export declare const template: (props: UxlAutocomplete) => import("lit-element").TemplateResult;
