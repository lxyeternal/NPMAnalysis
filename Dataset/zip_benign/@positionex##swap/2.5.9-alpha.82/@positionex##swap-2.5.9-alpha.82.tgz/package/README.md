# `swap`

> TODO: description

## Usage

```
const swap = require('@positionex/swap');

// TODO: DEMONSTRATE API
```
# Calculate swap data

```typescript
import {SwapCalculation} from '@positionex/swap'
const instance = new SwapCalculation(56, ApiENV.PROD)

const tokenIn = '0x...'
const tokenOut = '0x...'

// BREACK CHANGE: Since v2.0.0
await instance.init(['pancake'])

// call fetch data first
await instance.fetchData(tokenIn, tokenOut)

// then call computeOutput every user input quantity
const result = instance.computeOutput(tokenIn, tokenOut)

// interface


export interface ExchangeOutput {
    receiveAmount: string
    // eg. 0.004 means 0.4%
    slippage: number
    fee: string
    minimumReceive?: number
}

interface CompetitorOutput {
    [exchangeName: string]: ExchangeOutput
}

export interface SwapCalculationOutputs {
    PositionExchange: ExchangeOutput
    competitor: CompetitorOutput
}

```

Given data
```
// WBNB
const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'
// CAKE
const cake = '0x0E09FaBB73Bd3Ade0a17ECC321fD13a19e81cE82'
await instance.fetchData(WBNB, cake, ['pancake', 'biswap'])
console.log(instance.computeOutput('1000000000000000000000000', WBNB, cake))
console.log(instance.computeOutput('2522950000000000000000000', cake, WBNB))
```

Result: 

```
    {
      PositionExchange: {
        receiveAmount: '1.5639393563054695390914051e+25',
        slippage: 0.7847823161194251,
        fee: '2.5e+21'
      },
      competitor: {
        pancake: {
          receiveAmount: '1.5639393563054695390914051e+25',
          slippage: 0.7847823161194251,
          fee: '2.5e+21'
        },
        biswap: {
          receiveAmount: '3.06034048154717559040375e+23',
          slippage: 0.9958041592823518,
          fee: '1e+21'
        }
      }
    }
        {
      PositionExchange: {
        receiveAmount: '3.0672155698230522096569e+22',
        slippage: 0.11212505026623062,
        fee: '6.307375e+21'
      },
      competitor: {
        pancake: {
          receiveAmount: '3.0672155698230522096569e+22',
          slippage: 0.11212505026623062,
          fee: '6.307375e+21'
        },
        biswap: {
          receiveAmount: '3.751833678024379700454e+21',
          slippage: 0.891318728376647,
          fee: '2.52295e+21'
        }
      }
    }
```

Given data:

```
// USDT
const tokenIn = '0x55d398326f99059fF775485246999027B3197955'
// BUSD
const tokenOut = '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56'
await instance.fetchData(tokenIn, tokenOut, ['pancake', 'biswap'])
console.log(instance.computeOutput('1000000000000000000000', tokenIn, tokenOut))
console.log(instance.computeOutput('1000000000000000000000', tokenOut, tokenIn))
console.log(instance.computeOutput('10000000000000000000', tokenIn, tokenOut))
```

Result:

```
{
  PositionExchange: {
    receiveAmount: '999959999999999999999.998',
    slippage: 0,
    fee: '1999920000000000000'
  },
  competitor: {
    pancake: {
      receiveAmount: '996207693251576656813',
      slippage: 0.00000732803667205296,
      fee: '2500000000000000000'
    },
    biswap: {
      receiveAmount: '998281768519403611804',
      slippage: 0.00003717064880874459,
      fee: '1000000000000000000'
    }
  }
}
 {
  PositionExchange: {
    receiveAmount: '999999999999999999999.998',
    slippage: 0,
    fee: '2000000000000000000'
  },
  competitor: {
    pancake: {
      receiveAmount: '998779335377581318028',
      slippage: 0.00000733748895428598,
      fee: '2500000000000000000'
    },
    biswap: {
      receiveAmount: '999644403865803805103',
      slippage: 0.00003719600829517948,
      fee: '1000000000000000000'
    }
  }
}
 {
      PositionExchange: {
        receiveAmount: '9999599999999999999.998',
        slippage: 0,
        fee: '19999200000000000'
      },
      competitor: {
        pancake: {
          receiveAmount: '9962149205480529690',
          slippage: 7.328089835564e-8,
          fee: '25000000000000000'
        },
        biswap: {
          receiveAmount: '9983185055845082608',
          slippage: 3.7172016699639e-7,
          fee: '10000000000000000'
        }
      }
    }
    
```

### test

`yarn test`
