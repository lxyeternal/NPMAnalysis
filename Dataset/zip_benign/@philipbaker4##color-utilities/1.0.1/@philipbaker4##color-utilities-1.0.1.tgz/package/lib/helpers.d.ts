export declare function processValue(val: string | number[]): number[] | undefined;
export declare function pad(n: string, width: number, z?: string): string;
export declare function getInterpolatedColor(minColorRGB: number[], maxColorRGB: number[], percent: number): number[];
export declare function getFormatFunc(returnType: string): typeof _getHex | typeof _getRGBArray;
export declare function _getRGBString(color: number[]): string;
export declare function _getRGBArray(color: number[]): number[];
export declare function _getHex(color: number[]): string;
export declare function getMinMaxColorArrays(minColor: string | number[], maxColor: string | number[]): {
    minColorRGB: number[];
    maxColorRGB: number[];
};
