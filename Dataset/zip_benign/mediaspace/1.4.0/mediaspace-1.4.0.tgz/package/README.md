# About

This is a package that directly displays photos available in spaces created on [mediaspaces app](https://www.mediaspaces.app). It makes it possible to share pictures uploaded by you, or shared by your audience directly 
on your website. With this, you can decide to automatically update photos shown on your website based on certain metrics including how happy the people taking the photos are, the quality of the photos, their popularity (in terms of how many times they have been shared, and interacted with on social media), etc.

# Running the project

## Step 1: Install the package;

```
npm install mediaspace
```

## Step 2: Use it in your web app

```
import Mediaspace from 'mediaspace'

const M = new Mediaspace(<element>, {apiKey: <api_key>})
```

Checkout the video tutorial below to see how to use this package; </br>

[![YouTube Thumbnail](https://img.youtube.com/vi/kldVLwh6w-U/hqdefault.jpg)](https://www.youtube.com/watch?v=kldVLwh6w-U)
