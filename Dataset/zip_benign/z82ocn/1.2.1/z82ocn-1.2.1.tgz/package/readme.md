# (ePUB) Download Surge (The Taking, #0.5) by Melissa  West (mdvaq)

<p>Do you want to <b>download epub Surge (The Taking, #0.5) by Melissa  West</b>?  Today, we have got this Melissa  West's ebook available to download for free: Surge (The Taking, #0.5) epub.

<br>➡️➡️ <b>Click here: <a href="https://shrtly.cc/25664462">https://shrtly.cc/25664462</a></b>⬅️ ⬅️
<br>
<br>
<img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1442145161i/25664462.jpg" alt="ebook download Surge (The Taking, #0.5)" style="max-width: 100%;" />
<br>
<br>