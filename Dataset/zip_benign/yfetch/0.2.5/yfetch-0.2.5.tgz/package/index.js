"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = exports.yfetch = exports.transformFetchStatusError = exports.transformFetchResult = exports.transformFetchOptions = exports.JSON_HEADER = exports.YfetchError = void 0;

var _queryString = require("query-string");

var _debug = _interopRequireDefault(require("debug"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _wrapNativeSuper(Class) { var _cache = typeof Map === "function" ? new Map() : undefined; _wrapNativeSuper = function _wrapNativeSuper(Class) { if (Class === null || !_isNativeFunction(Class)) return Class; if (typeof Class !== "function") { throw new TypeError("Super expression must either be null or a function"); } if (typeof _cache !== "undefined") { if (_cache.has(Class)) return _cache.get(Class); _cache.set(Class, Wrapper); } function Wrapper() { return _construct(Class, arguments, _getPrototypeOf(this).constructor); } Wrapper.prototype = Object.create(Class.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } }); return _setPrototypeOf(Wrapper, Class); }; return _wrapNativeSuper(Class); }

function isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _construct(Parent, args, Class) { if (isNativeReflectConstruct()) { _construct = Reflect.construct; } else { _construct = function _construct(Parent, args, Class) { var a = [null]; a.push.apply(a, args); var Constructor = Function.bind.apply(Parent, a); var instance = new Constructor(); if (Class) _setPrototypeOf(instance, Class.prototype); return instance; }; } return _construct.apply(null, arguments); }

function _isNativeFunction(fn) { return Function.toString.call(fn).indexOf("[native code]") !== -1; }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var debugStart = (0, _debug["default"])('yfetch:start');
var debugRaw = (0, _debug["default"])('yfetch:raw');
var debugResult = (0, _debug["default"])('yfetch:result');
var debugError = (0, _debug["default"])('yfetch:error');

var YfetchError =
/*#__PURE__*/
function (_Error) {
  _inherits(YfetchError, _Error);

  function YfetchError() {
    _classCallCheck(this, YfetchError);

    return _possibleConstructorReturn(this, _getPrototypeOf(YfetchError).apply(this, arguments));
  }

  return YfetchError;
}(_wrapNativeSuper(Error));

exports.YfetchError = YfetchError;
var JSON_HEADER = {
  Accept: 'application/json',
  'Content-Type': 'application/json'
}; // Support simple opts.query , opts.base and opts.url logic
// Support opts.json headers
// return fetch() arguments

exports.JSON_HEADER = JSON_HEADER;

var transformFetchOptions = function transformFetchOptions(_ref) {
  var query = _ref.query,
      headers = _ref.headers,
      _ref$base = _ref.base,
      base = _ref$base === void 0 ? '' : _ref$base,
      _ref$url = _ref.url,
      url = _ref$url === void 0 ? '' : _ref$url,
      opts = _objectWithoutProperties(_ref, ["query", "headers", "base", "url"]);

  var queryString = (0, _queryString.stringify)(query);
  var urlString = base + url + (queryString ? "?".concat(queryString) : '');
  var H = opts.json ? JSON_HEADER : {};
  return [urlString, _objectSpread({
    headers: _objectSpread({}, H, {}, headers)
  }, opts)];
}; // Support opts.json, send debug yfetch:result


exports.transformFetchOptions = transformFetchOptions;

var transformFetchResult = function transformFetchResult(_ref2) {
  var fetchArgs = _ref2.fetchArgs,
      response = _objectWithoutProperties(_ref2, ["fetchArgs"]);

  if (fetchArgs[1].json) {
    try {
      response.body = JSON.parse(response.body);
      response.parsed = true;
    } catch (E) {
      if (!fetchArgs[1].ignoreJsonError) {
        throw new Error("Can not JSON parse response body: \"".concat(response.body, "\""));
      }
    }
  }

  debugResult('url: %s - status: %s - body: %O', response.url, response.status, response.body);
  return _objectSpread({}, response, {
    fetchArgs: fetchArgs
  });
}; // Support opts.error


exports.transformFetchResult = transformFetchResult;

var transformFetchStatusError = function transformFetchStatusError(_ref3) {
  var fetchArgs = _ref3.fetchArgs,
      response = _objectWithoutProperties(_ref3, ["fetchArgs"]);

  if (fetchArgs[1].error && fetchArgs[1].error.indexOf && fetchArgs[1].error.indexOf(response.status) > -1) {
    throw new YfetchError("Response Code ".concat(response.status, " means Error (includes: ").concat(fetchArgs[1].error.join(','), ")"));
  }

  return _objectSpread({}, response, {
    fetchArgs: fetchArgs
  });
}; // handle response.text() promise, make response simple, keep response.fetchArgs
// send debug yfetch:raw


exports.transformFetchStatusError = transformFetchStatusError;

var transformForContext = function transformForContext(fetchArgs) {
  return function () {
    var response = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var url = response.url,
        status = response.status,
        statusText = response.statusText,
        _response$headers = response.headers,
        headers = _response$headers === void 0 ? [] : _response$headers,
        ok = response.ok,
        size = response.size;
    var H = {};
    headers.forEach(function (v, k) {
      H[k] = v;
    });
    var job = response.text ? response.text() : fetchArgs[1].jsonp ? response.json() : Promise.resolve();
    return job.then(function (body) {
      debugRaw('url: %s - status: %s - size: %s - header: %o - body: %s', url, status, size, H, body);
      return {
        url: url,
        status: status,
        statusText: statusText,
        ok: ok,
        size: size,
        body: body,
        fetchArgs: fetchArgs,
        headers: H
      };
    });
  };
}; // keep error.fetchArgs and error.response , send debug yfetch:error
// const transformFetchError = (fetchArgs, { response = {} }) => (error) => {


var transformFetchError = function transformFetchError(fetchArgs, R) {
  return function (error) {
    var response = R.response || {};
    debugError('url: %s - status: %s - size: %s - body: %s - %O', fetchArgs[0], response.status, response.size, response.body, error);
    error.fetchArgs = fetchArgs;
    error.response = response;
    throw error;
  };
}; // The main yfetch function


var yfetch = function yfetch() {
  var _global, _global2;

  var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var fetchArgs = transformFetchOptions(opts);
  var R = {};

  var storeResponse = function storeResponse(response) {
    R.response = response;
    return response;
  };

  debugStart('url: %s - args: %O', fetchArgs[0], fetchArgs[1]);
  return (global.fetchJsonp && fetchArgs[1].jsonp ? (_global = global).fetchJsonp.apply(_global, _toConsumableArray(fetchArgs)) : (_global2 = global).fetch.apply(_global2, _toConsumableArray(fetchArgs))).then(transformForContext(fetchArgs)).then(storeResponse).then(transformFetchResult).then(storeResponse).then(transformFetchStatusError)["catch"](transformFetchError(fetchArgs, R));
}; // as default


exports.yfetch = yfetch;
var _default = yfetch;
exports["default"] = _default;
