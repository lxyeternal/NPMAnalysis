const Promise = require('promise');
const debug = require('debug')('bulk writer');
const winston = require('winston');

const BulkWriter = function BulkWriter(client, options) {
    this.client = client;
    this.interval = options.interval || 5000;
    this.waitForActiveShards = options.waitForActiveShards;
    this.pipeline = options.pipeline;
    this.maxMessageBuffer = options.maxMessageBuffer || 5000;

    this.bulk = []; // bulk to be flushed
    this.running = false;
    this.timer = false;
    debug('created', this);
};

BulkWriter.prototype.start = function start() {
    this.stop();
    this.running = true;
    this.tick();
    debug('started');
};

BulkWriter.prototype.stop = function stop() {
    this.running = false;
    if (!this.timer) { return; }
    clearTimeout(this.timer);
    this.timer = null;
    debug('stopped');
};

BulkWriter.prototype.schedule = function schedule() {
    const thiz = this;
    this.timer = setTimeout(() => {
        thiz.tick();
    }, this.interval);
};

BulkWriter.prototype.tick = function tick() {
    debug('tick');
    const thiz = this;
    if (!this.running) { return; }
    /*eslint-disable*/
    this.flush()
        .catch((e) => {
            throw e;
        })
        .then(() => {
            thiz.schedule();
        });
    /*eslint-enabled*/
};

BulkWriter.prototype.flush = function flush() {
    // write bulk to elasticsearch
    const thiz = this;
    if (this.bulk.length === 0) {
        debug('nothing to flush');

        return new Promise((resolve) => {
            return resolve();
        });
    }

    const bulk = this.bulk.concat();
    this.bulk = [];
    debug('going to write', bulk);
    return this.client.bulk({
        body: bulk,
        waitForActiveShards: this.waitForActiveShards,
        timeout: this.interval + 'ms',
        type: this.type
    }).catch((e) => {
        debug('Could not write, rolling back.');
        // rollback this.bulk array
        thiz.bulk = bulk.concat(thiz.bulk);
        if (thiz.bulk.length > thiz.maxMessageBuffer) {
            debug('Message buffer above threshold, dumping buffer');
            this.bulk.forEach(winston.info);
            this.bulk = [];
            throw e;
        }
    });
};

BulkWriter.prototype.append = function append(index, type, doc) {
    this.bulk.push({
        index: {
            _index: index, _type: type, pipeline: this.pipeline
        }
    });
    this.bulk.push(doc);
};

module.exports = BulkWriter;
