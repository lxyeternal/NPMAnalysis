"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _objectSpread2 = _interopRequireDefault(require("@babel/runtime/helpers/objectSpread"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime/helpers/getPrototypeOf"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime/helpers/inherits"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _react = _interopRequireWildcard(require("react"));

var _propTypes = _interopRequireDefault(require("prop-types"));

var _d3Shape = require("d3-shape");

var _d3Scale = require("d3-scale");

var _d3Array = require("d3-array");

var curveFunction = _d3Shape.curveMonotoneX;
var defaultColors = {
  area: 'rgba(199, 228, 255, 0.5)',
  line: '#004585'
};

var Sparkline =
/*#__PURE__*/
function (_PureComponent) {
  (0, _inherits2["default"])(Sparkline, _PureComponent);

  function Sparkline() {
    (0, _classCallCheck2["default"])(this, Sparkline);
    return (0, _possibleConstructorReturn2["default"])(this, (0, _getPrototypeOf2["default"])(Sparkline).apply(this, arguments));
  }

  (0, _createClass2["default"])(Sparkline, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          lines = _this$props.lines,
          width = _this$props.width,
          height = _this$props.height;
      var maxX = (0, _d3Array.max)(lines, function (s) {
        return s.values.length - 1;
      });
      var maxY = (0, _d3Array.max)(lines, function (s) {
        return (0, _d3Array.max)(s.values);
      });
      var x = (0, _d3Scale.scaleLinear)().domain([0, maxX]).range([0, width]); // Set range to 1 to make room for the line stroke

      var y = (0, _d3Scale.scaleLinear)().domain([0, maxY]).range([height, 1]);
      var areaFunction = (0, _d3Shape.area)().x(function (d, i) {
        return x(i);
      }).y0(height).y1(function (d) {
        return y(d);
      }).curve(curveFunction);
      var lineFunction = (0, _d3Shape.line)().x(function (d, i) {
        return x(i);
      }).y(function (d) {
        return y(d);
      }).curve(curveFunction);
      return _react["default"].createElement("svg", {
        width: width,
        height: height,
        viewBox: "0 0 ".concat(width, " ").concat(height)
      }, lines.map(function (line, index) {
        var colors = (0, _objectSpread2["default"])({}, defaultColors, line.colors);
        return _react["default"].createElement("g", {
          key: line.key || index
        }, _react["default"].createElement("path", {
          d: areaFunction(line.values),
          fill: colors.area
        }, line.title && _react["default"].createElement("title", null, line.title)), _react["default"].createElement("path", {
          d: lineFunction(line.values),
          stroke: colors.line,
          fill: "none"
        }));
      }));
    }
  }]);
  return Sparkline;
}(_react.PureComponent);

exports["default"] = Sparkline;
(0, _defineProperty2["default"])(Sparkline, "displayName", 'Sparkline');
(0, _defineProperty2["default"])(Sparkline, "propTypes", {
  lines: _propTypes["default"].arrayOf(_propTypes["default"].shape({
    values: _propTypes["default"].arrayOf(_propTypes["default"].number.isRequired).isRequired,
    colors: _propTypes["default"].shape({
      area: _propTypes["default"].string.isRequired,
      line: _propTypes["default"].string.isRequired
    }),
    title: _propTypes["default"].string,
    key: _propTypes["default"].any
  })).isRequired,
  width: _propTypes["default"].number.isRequired,
  height: _propTypes["default"].number.isRequired
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9pbmRleC5qcyJdLCJuYW1lcyI6WyJjdXJ2ZUZ1bmN0aW9uIiwiY3VydmVNb25vdG9uZVgiLCJkZWZhdWx0Q29sb3JzIiwiYXJlYSIsImxpbmUiLCJTcGFya2xpbmUiLCJwcm9wcyIsImxpbmVzIiwid2lkdGgiLCJoZWlnaHQiLCJtYXhYIiwicyIsInZhbHVlcyIsImxlbmd0aCIsIm1heFkiLCJ4IiwiZG9tYWluIiwicmFuZ2UiLCJ5IiwiYXJlYUZ1bmN0aW9uIiwiZCIsImkiLCJ5MCIsInkxIiwiY3VydmUiLCJsaW5lRnVuY3Rpb24iLCJtYXAiLCJpbmRleCIsImNvbG9ycyIsImtleSIsInRpdGxlIiwiUHVyZUNvbXBvbmVudCIsIlByb3BUeXBlcyIsImFycmF5T2YiLCJzaGFwZSIsIm51bWJlciIsImlzUmVxdWlyZWQiLCJzdHJpbmciLCJhbnkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFFQSxJQUFNQSxhQUFhLEdBQUdDLHVCQUF0QjtBQUNBLElBQU1DLGFBQWEsR0FBRztBQUNwQkMsRUFBQUEsSUFBSSxFQUFFLDBCQURjO0FBRXBCQyxFQUFBQSxJQUFJLEVBQUU7QUFGYyxDQUF0Qjs7SUFLcUJDLFM7Ozs7Ozs7Ozs7Ozs2QkFtQlY7QUFBQSx3QkFDd0IsS0FBS0MsS0FEN0I7QUFBQSxVQUNBQyxLQURBLGVBQ0FBLEtBREE7QUFBQSxVQUNPQyxLQURQLGVBQ09BLEtBRFA7QUFBQSxVQUNjQyxNQURkLGVBQ2NBLE1BRGQ7QUFFUCxVQUFNQyxJQUFJLEdBQUcsa0JBQUlILEtBQUosRUFBVyxVQUFBSSxDQUFDO0FBQUEsZUFBSUEsQ0FBQyxDQUFDQyxNQUFGLENBQVNDLE1BQVQsR0FBa0IsQ0FBdEI7QUFBQSxPQUFaLENBQWI7QUFDQSxVQUFNQyxJQUFJLEdBQUcsa0JBQUlQLEtBQUosRUFBVyxVQUFBSSxDQUFDO0FBQUEsZUFBSSxrQkFBSUEsQ0FBQyxDQUFDQyxNQUFOLENBQUo7QUFBQSxPQUFaLENBQWI7QUFDQSxVQUFNRyxDQUFDLEdBQUcsNEJBQWNDLE1BQWQsQ0FBcUIsQ0FBQyxDQUFELEVBQUlOLElBQUosQ0FBckIsRUFBZ0NPLEtBQWhDLENBQXNDLENBQUMsQ0FBRCxFQUFJVCxLQUFKLENBQXRDLENBQVYsQ0FKTyxDQUtQOztBQUNBLFVBQU1VLENBQUMsR0FBRyw0QkFBY0YsTUFBZCxDQUFxQixDQUFDLENBQUQsRUFBSUYsSUFBSixDQUFyQixFQUFnQ0csS0FBaEMsQ0FBc0MsQ0FBQ1IsTUFBRCxFQUFTLENBQVQsQ0FBdEMsQ0FBVjtBQUVBLFVBQU1VLFlBQVksR0FDaEIscUJBQ0dKLENBREgsQ0FDSyxVQUFDSyxDQUFELEVBQUlDLENBQUo7QUFBQSxlQUFVTixDQUFDLENBQUNNLENBQUQsQ0FBWDtBQUFBLE9BREwsRUFFR0MsRUFGSCxDQUVNYixNQUZOLEVBR0djLEVBSEgsQ0FHTSxVQUFBSCxDQUFDO0FBQUEsZUFBSUYsQ0FBQyxDQUFDRSxDQUFELENBQUw7QUFBQSxPQUhQLEVBSUdJLEtBSkgsQ0FJU3hCLGFBSlQsQ0FERjtBQU9BLFVBQU15QixZQUFZLEdBQ2hCLHFCQUNHVixDQURILENBQ0ssVUFBQ0ssQ0FBRCxFQUFJQyxDQUFKO0FBQUEsZUFBVU4sQ0FBQyxDQUFDTSxDQUFELENBQVg7QUFBQSxPQURMLEVBRUdILENBRkgsQ0FFSyxVQUFBRSxDQUFDO0FBQUEsZUFBSUYsQ0FBQyxDQUFDRSxDQUFELENBQUw7QUFBQSxPQUZOLEVBR0dJLEtBSEgsQ0FHU3hCLGFBSFQsQ0FERjtBQU1BLGFBQ0U7QUFBSyxRQUFBLEtBQUssRUFBRVEsS0FBWjtBQUFtQixRQUFBLE1BQU0sRUFBRUMsTUFBM0I7QUFBbUMsUUFBQSxPQUFPLGdCQUFTRCxLQUFULGNBQWtCQyxNQUFsQjtBQUExQyxTQUNHRixLQUFLLENBQUNtQixHQUFOLENBQVUsVUFBQ3RCLElBQUQsRUFBT3VCLEtBQVAsRUFBaUI7QUFDMUIsWUFBTUMsTUFBTSxzQ0FDUDFCLGFBRE8sRUFFUEUsSUFBSSxDQUFDd0IsTUFGRSxDQUFaO0FBSUEsZUFDRTtBQUFHLFVBQUEsR0FBRyxFQUFFeEIsSUFBSSxDQUFDeUIsR0FBTCxJQUFZRjtBQUFwQixXQUNFO0FBQU0sVUFBQSxDQUFDLEVBQUVSLFlBQVksQ0FBQ2YsSUFBSSxDQUFDUSxNQUFOLENBQXJCO0FBQW9DLFVBQUEsSUFBSSxFQUFFZ0IsTUFBTSxDQUFDekI7QUFBakQsV0FDR0MsSUFBSSxDQUFDMEIsS0FBTCxJQUFjLCtDQUFRMUIsSUFBSSxDQUFDMEIsS0FBYixDQURqQixDQURGLEVBSUU7QUFBTSxVQUFBLENBQUMsRUFBRUwsWUFBWSxDQUFDckIsSUFBSSxDQUFDUSxNQUFOLENBQXJCO0FBQW9DLFVBQUEsTUFBTSxFQUFFZ0IsTUFBTSxDQUFDeEIsSUFBbkQ7QUFBeUQsVUFBQSxJQUFJLEVBQUM7QUFBOUQsVUFKRixDQURGO0FBUUQsT0FiQSxDQURILENBREY7QUFrQkQ7OztFQTFEb0MyQixvQjs7O2lDQUFsQjFCLFMsaUJBQ0UsVztpQ0FERkEsUyxlQUdBO0FBQ2pCRSxFQUFBQSxLQUFLLEVBQUV5QixzQkFBVUMsT0FBVixDQUNMRCxzQkFBVUUsS0FBVixDQUFnQjtBQUNkdEIsSUFBQUEsTUFBTSxFQUFFb0Isc0JBQVVDLE9BQVYsQ0FBa0JELHNCQUFVRyxNQUFWLENBQWlCQyxVQUFuQyxFQUErQ0EsVUFEekM7QUFFZFIsSUFBQUEsTUFBTSxFQUFFSSxzQkFBVUUsS0FBVixDQUFnQjtBQUN0Qi9CLE1BQUFBLElBQUksRUFBRTZCLHNCQUFVSyxNQUFWLENBQWlCRCxVQUREO0FBRXRCaEMsTUFBQUEsSUFBSSxFQUFFNEIsc0JBQVVLLE1BQVYsQ0FBaUJEO0FBRkQsS0FBaEIsQ0FGTTtBQU1kTixJQUFBQSxLQUFLLEVBQUVFLHNCQUFVSyxNQU5IO0FBT2RSLElBQUFBLEdBQUcsRUFBRUcsc0JBQVVNO0FBUEQsR0FBaEIsQ0FESyxFQVVMRixVQVhlO0FBWWpCNUIsRUFBQUEsS0FBSyxFQUFFd0Isc0JBQVVHLE1BQVYsQ0FBaUJDLFVBWlA7QUFhakIzQixFQUFBQSxNQUFNLEVBQUV1QixzQkFBVUcsTUFBVixDQUFpQkM7QUFiUixDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7UHVyZUNvbXBvbmVudH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5pbXBvcnQge2FyZWEsIGxpbmUsIGN1cnZlTW9ub3RvbmVYfSBmcm9tICdkMy1zaGFwZSdcbmltcG9ydCB7c2NhbGVMaW5lYXJ9IGZyb20gJ2QzLXNjYWxlJ1xuaW1wb3J0IHttYXh9IGZyb20gJ2QzLWFycmF5J1xuXG5jb25zdCBjdXJ2ZUZ1bmN0aW9uID0gY3VydmVNb25vdG9uZVhcbmNvbnN0IGRlZmF1bHRDb2xvcnMgPSB7XG4gIGFyZWE6ICdyZ2JhKDE5OSwgMjI4LCAyNTUsIDAuNSknLFxuICBsaW5lOiAnIzAwNDU4NSdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU3BhcmtsaW5lIGV4dGVuZHMgUHVyZUNvbXBvbmVudCB7XG4gIHN0YXRpYyBkaXNwbGF5TmFtZSA9ICdTcGFya2xpbmUnXG5cbiAgc3RhdGljIHByb3BUeXBlcyA9IHtcbiAgICBsaW5lczogUHJvcFR5cGVzLmFycmF5T2YoXG4gICAgICBQcm9wVHlwZXMuc2hhcGUoe1xuICAgICAgICB2YWx1ZXM6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5udW1iZXIuaXNSZXF1aXJlZCkuaXNSZXF1aXJlZCxcbiAgICAgICAgY29sb3JzOiBQcm9wVHlwZXMuc2hhcGUoe1xuICAgICAgICAgIGFyZWE6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICAgICAgICBsaW5lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWRcbiAgICAgICAgfSksXG4gICAgICAgIHRpdGxlOiBQcm9wVHlwZXMuc3RyaW5nLFxuICAgICAgICBrZXk6IFByb3BUeXBlcy5hbnlcbiAgICAgIH0pXG4gICAgKS5pc1JlcXVpcmVkLFxuICAgIHdpZHRoOiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWQsXG4gICAgaGVpZ2h0OiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWRcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7bGluZXMsIHdpZHRoLCBoZWlnaHR9ID0gdGhpcy5wcm9wc1xuICAgIGNvbnN0IG1heFggPSBtYXgobGluZXMsIHMgPT4gcy52YWx1ZXMubGVuZ3RoIC0gMSlcbiAgICBjb25zdCBtYXhZID0gbWF4KGxpbmVzLCBzID0+IG1heChzLnZhbHVlcykpXG4gICAgY29uc3QgeCA9IHNjYWxlTGluZWFyKCkuZG9tYWluKFswLCBtYXhYXSkucmFuZ2UoWzAsIHdpZHRoXSlcbiAgICAvLyBTZXQgcmFuZ2UgdG8gMSB0byBtYWtlIHJvb20gZm9yIHRoZSBsaW5lIHN0cm9rZVxuICAgIGNvbnN0IHkgPSBzY2FsZUxpbmVhcigpLmRvbWFpbihbMCwgbWF4WV0pLnJhbmdlKFtoZWlnaHQsIDFdKVxuXG4gICAgY29uc3QgYXJlYUZ1bmN0aW9uID1cbiAgICAgIGFyZWEoKVxuICAgICAgICAueCgoZCwgaSkgPT4geChpKSlcbiAgICAgICAgLnkwKGhlaWdodClcbiAgICAgICAgLnkxKGQgPT4geShkKSlcbiAgICAgICAgLmN1cnZlKGN1cnZlRnVuY3Rpb24pXG5cbiAgICBjb25zdCBsaW5lRnVuY3Rpb24gPVxuICAgICAgbGluZSgpXG4gICAgICAgIC54KChkLCBpKSA9PiB4KGkpKVxuICAgICAgICAueShkID0+IHkoZCkpXG4gICAgICAgIC5jdXJ2ZShjdXJ2ZUZ1bmN0aW9uKVxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxzdmcgd2lkdGg9e3dpZHRofSBoZWlnaHQ9e2hlaWdodH0gdmlld0JveD17YDAgMCAke3dpZHRofSAke2hlaWdodH1gfT5cbiAgICAgICAge2xpbmVzLm1hcCgobGluZSwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb25zdCBjb2xvcnMgPSB7XG4gICAgICAgICAgICAuLi5kZWZhdWx0Q29sb3JzLFxuICAgICAgICAgICAgLi4ubGluZS5jb2xvcnNcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxnIGtleT17bGluZS5rZXkgfHwgaW5kZXh9PlxuICAgICAgICAgICAgICA8cGF0aCBkPXthcmVhRnVuY3Rpb24obGluZS52YWx1ZXMpfSBmaWxsPXtjb2xvcnMuYXJlYX0+XG4gICAgICAgICAgICAgICAge2xpbmUudGl0bGUgJiYgPHRpdGxlPntsaW5lLnRpdGxlfTwvdGl0bGU+fVxuICAgICAgICAgICAgICA8L3BhdGg+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9e2xpbmVGdW5jdGlvbihsaW5lLnZhbHVlcyl9IHN0cm9rZT17Y29sb3JzLmxpbmV9IGZpbGw9XCJub25lXCIvPlxuICAgICAgICAgICAgPC9nPlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG4gICAgICA8L3N2Zz5cbiAgICApXG4gIH1cbn1cbiJdfQ==