import _objectSpread from "@babel/runtime/helpers/objectSpread";
import _classCallCheck from "@babel/runtime/helpers/classCallCheck";
import _createClass from "@babel/runtime/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime/helpers/getPrototypeOf";
import _inherits from "@babel/runtime/helpers/inherits";
import _defineProperty from "@babel/runtime/helpers/defineProperty";
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { area, line, curveMonotoneX } from 'd3-shape';
import { scaleLinear } from 'd3-scale';
import { max } from 'd3-array';
var curveFunction = curveMonotoneX;
var defaultColors = {
  area: 'rgba(199, 228, 255, 0.5)',
  line: '#004585'
};

var Sparkline =
/*#__PURE__*/
function (_PureComponent) {
  _inherits(Sparkline, _PureComponent);

  function Sparkline() {
    _classCallCheck(this, Sparkline);

    return _possibleConstructorReturn(this, _getPrototypeOf(Sparkline).apply(this, arguments));
  }

  _createClass(Sparkline, [{
    key: "render",
    value: function render() {
      var _this$props = this.props,
          lines = _this$props.lines,
          width = _this$props.width,
          height = _this$props.height;
      var maxX = max(lines, function (s) {
        return s.values.length - 1;
      });
      var maxY = max(lines, function (s) {
        return max(s.values);
      });
      var x = scaleLinear().domain([0, maxX]).range([0, width]); // Set range to 1 to make room for the line stroke

      var y = scaleLinear().domain([0, maxY]).range([height, 1]);
      var areaFunction = area().x(function (d, i) {
        return x(i);
      }).y0(height).y1(function (d) {
        return y(d);
      }).curve(curveFunction);
      var lineFunction = line().x(function (d, i) {
        return x(i);
      }).y(function (d) {
        return y(d);
      }).curve(curveFunction);
      return React.createElement("svg", {
        width: width,
        height: height,
        viewBox: "0 0 ".concat(width, " ").concat(height)
      }, lines.map(function (line, index) {
        var colors = _objectSpread({}, defaultColors, line.colors);

        return React.createElement("g", {
          key: line.key || index
        }, React.createElement("path", {
          d: areaFunction(line.values),
          fill: colors.area
        }, line.title && React.createElement("title", null, line.title)), React.createElement("path", {
          d: lineFunction(line.values),
          stroke: colors.line,
          fill: "none"
        }));
      }));
    }
  }]);

  return Sparkline;
}(PureComponent);

_defineProperty(Sparkline, "displayName", 'Sparkline');

_defineProperty(Sparkline, "propTypes", {
  lines: PropTypes.arrayOf(PropTypes.shape({
    values: PropTypes.arrayOf(PropTypes.number.isRequired).isRequired,
    colors: PropTypes.shape({
      area: PropTypes.string.isRequired,
      line: PropTypes.string.isRequired
    }),
    title: PropTypes.string,
    key: PropTypes.any
  })).isRequired,
  width: PropTypes.number.isRequired,
  height: PropTypes.number.isRequired
});

export { Sparkline as default };
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL3NyYy9pbmRleC5qcyJdLCJuYW1lcyI6WyJSZWFjdCIsIlB1cmVDb21wb25lbnQiLCJQcm9wVHlwZXMiLCJhcmVhIiwibGluZSIsImN1cnZlTW9ub3RvbmVYIiwic2NhbGVMaW5lYXIiLCJtYXgiLCJjdXJ2ZUZ1bmN0aW9uIiwiZGVmYXVsdENvbG9ycyIsIlNwYXJrbGluZSIsInByb3BzIiwibGluZXMiLCJ3aWR0aCIsImhlaWdodCIsIm1heFgiLCJzIiwidmFsdWVzIiwibGVuZ3RoIiwibWF4WSIsIngiLCJkb21haW4iLCJyYW5nZSIsInkiLCJhcmVhRnVuY3Rpb24iLCJkIiwiaSIsInkwIiwieTEiLCJjdXJ2ZSIsImxpbmVGdW5jdGlvbiIsIm1hcCIsImluZGV4IiwiY29sb3JzIiwia2V5IiwidGl0bGUiLCJhcnJheU9mIiwic2hhcGUiLCJudW1iZXIiLCJpc1JlcXVpcmVkIiwic3RyaW5nIiwiYW55Il0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsT0FBT0EsS0FBUCxJQUFlQyxhQUFmLFFBQW1DLE9BQW5DO0FBQ0EsT0FBT0MsU0FBUCxNQUFzQixZQUF0QjtBQUNBLFNBQVFDLElBQVIsRUFBY0MsSUFBZCxFQUFvQkMsY0FBcEIsUUFBeUMsVUFBekM7QUFDQSxTQUFRQyxXQUFSLFFBQTBCLFVBQTFCO0FBQ0EsU0FBUUMsR0FBUixRQUFrQixVQUFsQjtBQUVBLElBQU1DLGFBQWEsR0FBR0gsY0FBdEI7QUFDQSxJQUFNSSxhQUFhLEdBQUc7QUFDcEJOLEVBQUFBLElBQUksRUFBRSwwQkFEYztBQUVwQkMsRUFBQUEsSUFBSSxFQUFFO0FBRmMsQ0FBdEI7O0lBS3FCTSxTOzs7Ozs7Ozs7Ozs7OzZCQW1CVjtBQUFBLHdCQUN3QixLQUFLQyxLQUQ3QjtBQUFBLFVBQ0FDLEtBREEsZUFDQUEsS0FEQTtBQUFBLFVBQ09DLEtBRFAsZUFDT0EsS0FEUDtBQUFBLFVBQ2NDLE1BRGQsZUFDY0EsTUFEZDtBQUVQLFVBQU1DLElBQUksR0FBR1IsR0FBRyxDQUFDSyxLQUFELEVBQVEsVUFBQUksQ0FBQztBQUFBLGVBQUlBLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxNQUFULEdBQWtCLENBQXRCO0FBQUEsT0FBVCxDQUFoQjtBQUNBLFVBQU1DLElBQUksR0FBR1osR0FBRyxDQUFDSyxLQUFELEVBQVEsVUFBQUksQ0FBQztBQUFBLGVBQUlULEdBQUcsQ0FBQ1MsQ0FBQyxDQUFDQyxNQUFILENBQVA7QUFBQSxPQUFULENBQWhCO0FBQ0EsVUFBTUcsQ0FBQyxHQUFHZCxXQUFXLEdBQUdlLE1BQWQsQ0FBcUIsQ0FBQyxDQUFELEVBQUlOLElBQUosQ0FBckIsRUFBZ0NPLEtBQWhDLENBQXNDLENBQUMsQ0FBRCxFQUFJVCxLQUFKLENBQXRDLENBQVYsQ0FKTyxDQUtQOztBQUNBLFVBQU1VLENBQUMsR0FBR2pCLFdBQVcsR0FBR2UsTUFBZCxDQUFxQixDQUFDLENBQUQsRUFBSUYsSUFBSixDQUFyQixFQUFnQ0csS0FBaEMsQ0FBc0MsQ0FBQ1IsTUFBRCxFQUFTLENBQVQsQ0FBdEMsQ0FBVjtBQUVBLFVBQU1VLFlBQVksR0FDaEJyQixJQUFJLEdBQ0RpQixDQURILENBQ0ssVUFBQ0ssQ0FBRCxFQUFJQyxDQUFKO0FBQUEsZUFBVU4sQ0FBQyxDQUFDTSxDQUFELENBQVg7QUFBQSxPQURMLEVBRUdDLEVBRkgsQ0FFTWIsTUFGTixFQUdHYyxFQUhILENBR00sVUFBQUgsQ0FBQztBQUFBLGVBQUlGLENBQUMsQ0FBQ0UsQ0FBRCxDQUFMO0FBQUEsT0FIUCxFQUlHSSxLQUpILENBSVNyQixhQUpULENBREY7QUFPQSxVQUFNc0IsWUFBWSxHQUNoQjFCLElBQUksR0FDRGdCLENBREgsQ0FDSyxVQUFDSyxDQUFELEVBQUlDLENBQUo7QUFBQSxlQUFVTixDQUFDLENBQUNNLENBQUQsQ0FBWDtBQUFBLE9BREwsRUFFR0gsQ0FGSCxDQUVLLFVBQUFFLENBQUM7QUFBQSxlQUFJRixDQUFDLENBQUNFLENBQUQsQ0FBTDtBQUFBLE9BRk4sRUFHR0ksS0FISCxDQUdTckIsYUFIVCxDQURGO0FBTUEsYUFDRTtBQUFLLFFBQUEsS0FBSyxFQUFFSyxLQUFaO0FBQW1CLFFBQUEsTUFBTSxFQUFFQyxNQUEzQjtBQUFtQyxRQUFBLE9BQU8sZ0JBQVNELEtBQVQsY0FBa0JDLE1BQWxCO0FBQTFDLFNBQ0dGLEtBQUssQ0FBQ21CLEdBQU4sQ0FBVSxVQUFDM0IsSUFBRCxFQUFPNEIsS0FBUCxFQUFpQjtBQUMxQixZQUFNQyxNQUFNLHFCQUNQeEIsYUFETyxFQUVQTCxJQUFJLENBQUM2QixNQUZFLENBQVo7O0FBSUEsZUFDRTtBQUFHLFVBQUEsR0FBRyxFQUFFN0IsSUFBSSxDQUFDOEIsR0FBTCxJQUFZRjtBQUFwQixXQUNFO0FBQU0sVUFBQSxDQUFDLEVBQUVSLFlBQVksQ0FBQ3BCLElBQUksQ0FBQ2EsTUFBTixDQUFyQjtBQUFvQyxVQUFBLElBQUksRUFBRWdCLE1BQU0sQ0FBQzlCO0FBQWpELFdBQ0dDLElBQUksQ0FBQytCLEtBQUwsSUFBYyxtQ0FBUS9CLElBQUksQ0FBQytCLEtBQWIsQ0FEakIsQ0FERixFQUlFO0FBQU0sVUFBQSxDQUFDLEVBQUVMLFlBQVksQ0FBQzFCLElBQUksQ0FBQ2EsTUFBTixDQUFyQjtBQUFvQyxVQUFBLE1BQU0sRUFBRWdCLE1BQU0sQ0FBQzdCLElBQW5EO0FBQXlELFVBQUEsSUFBSSxFQUFDO0FBQTlELFVBSkYsQ0FERjtBQVFELE9BYkEsQ0FESCxDQURGO0FBa0JEOzs7O0VBMURvQ0gsYTs7Z0JBQWxCUyxTLGlCQUNFLFc7O2dCQURGQSxTLGVBR0E7QUFDakJFLEVBQUFBLEtBQUssRUFBRVYsU0FBUyxDQUFDa0MsT0FBVixDQUNMbEMsU0FBUyxDQUFDbUMsS0FBVixDQUFnQjtBQUNkcEIsSUFBQUEsTUFBTSxFQUFFZixTQUFTLENBQUNrQyxPQUFWLENBQWtCbEMsU0FBUyxDQUFDb0MsTUFBVixDQUFpQkMsVUFBbkMsRUFBK0NBLFVBRHpDO0FBRWROLElBQUFBLE1BQU0sRUFBRS9CLFNBQVMsQ0FBQ21DLEtBQVYsQ0FBZ0I7QUFDdEJsQyxNQUFBQSxJQUFJLEVBQUVELFNBQVMsQ0FBQ3NDLE1BQVYsQ0FBaUJELFVBREQ7QUFFdEJuQyxNQUFBQSxJQUFJLEVBQUVGLFNBQVMsQ0FBQ3NDLE1BQVYsQ0FBaUJEO0FBRkQsS0FBaEIsQ0FGTTtBQU1kSixJQUFBQSxLQUFLLEVBQUVqQyxTQUFTLENBQUNzQyxNQU5IO0FBT2ROLElBQUFBLEdBQUcsRUFBRWhDLFNBQVMsQ0FBQ3VDO0FBUEQsR0FBaEIsQ0FESyxFQVVMRixVQVhlO0FBWWpCMUIsRUFBQUEsS0FBSyxFQUFFWCxTQUFTLENBQUNvQyxNQUFWLENBQWlCQyxVQVpQO0FBYWpCekIsRUFBQUEsTUFBTSxFQUFFWixTQUFTLENBQUNvQyxNQUFWLENBQWlCQztBQWJSLEM7O1NBSEE3QixTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7UHVyZUNvbXBvbmVudH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5pbXBvcnQge2FyZWEsIGxpbmUsIGN1cnZlTW9ub3RvbmVYfSBmcm9tICdkMy1zaGFwZSdcbmltcG9ydCB7c2NhbGVMaW5lYXJ9IGZyb20gJ2QzLXNjYWxlJ1xuaW1wb3J0IHttYXh9IGZyb20gJ2QzLWFycmF5J1xuXG5jb25zdCBjdXJ2ZUZ1bmN0aW9uID0gY3VydmVNb25vdG9uZVhcbmNvbnN0IGRlZmF1bHRDb2xvcnMgPSB7XG4gIGFyZWE6ICdyZ2JhKDE5OSwgMjI4LCAyNTUsIDAuNSknLFxuICBsaW5lOiAnIzAwNDU4NSdcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgU3BhcmtsaW5lIGV4dGVuZHMgUHVyZUNvbXBvbmVudCB7XG4gIHN0YXRpYyBkaXNwbGF5TmFtZSA9ICdTcGFya2xpbmUnXG5cbiAgc3RhdGljIHByb3BUeXBlcyA9IHtcbiAgICBsaW5lczogUHJvcFR5cGVzLmFycmF5T2YoXG4gICAgICBQcm9wVHlwZXMuc2hhcGUoe1xuICAgICAgICB2YWx1ZXM6IFByb3BUeXBlcy5hcnJheU9mKFByb3BUeXBlcy5udW1iZXIuaXNSZXF1aXJlZCkuaXNSZXF1aXJlZCxcbiAgICAgICAgY29sb3JzOiBQcm9wVHlwZXMuc2hhcGUoe1xuICAgICAgICAgIGFyZWE6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICAgICAgICBsaW5lOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWRcbiAgICAgICAgfSksXG4gICAgICAgIHRpdGxlOiBQcm9wVHlwZXMuc3RyaW5nLFxuICAgICAgICBrZXk6IFByb3BUeXBlcy5hbnlcbiAgICAgIH0pXG4gICAgKS5pc1JlcXVpcmVkLFxuICAgIHdpZHRoOiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWQsXG4gICAgaGVpZ2h0OiBQcm9wVHlwZXMubnVtYmVyLmlzUmVxdWlyZWRcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7bGluZXMsIHdpZHRoLCBoZWlnaHR9ID0gdGhpcy5wcm9wc1xuICAgIGNvbnN0IG1heFggPSBtYXgobGluZXMsIHMgPT4gcy52YWx1ZXMubGVuZ3RoIC0gMSlcbiAgICBjb25zdCBtYXhZID0gbWF4KGxpbmVzLCBzID0+IG1heChzLnZhbHVlcykpXG4gICAgY29uc3QgeCA9IHNjYWxlTGluZWFyKCkuZG9tYWluKFswLCBtYXhYXSkucmFuZ2UoWzAsIHdpZHRoXSlcbiAgICAvLyBTZXQgcmFuZ2UgdG8gMSB0byBtYWtlIHJvb20gZm9yIHRoZSBsaW5lIHN0cm9rZVxuICAgIGNvbnN0IHkgPSBzY2FsZUxpbmVhcigpLmRvbWFpbihbMCwgbWF4WV0pLnJhbmdlKFtoZWlnaHQsIDFdKVxuXG4gICAgY29uc3QgYXJlYUZ1bmN0aW9uID1cbiAgICAgIGFyZWEoKVxuICAgICAgICAueCgoZCwgaSkgPT4geChpKSlcbiAgICAgICAgLnkwKGhlaWdodClcbiAgICAgICAgLnkxKGQgPT4geShkKSlcbiAgICAgICAgLmN1cnZlKGN1cnZlRnVuY3Rpb24pXG5cbiAgICBjb25zdCBsaW5lRnVuY3Rpb24gPVxuICAgICAgbGluZSgpXG4gICAgICAgIC54KChkLCBpKSA9PiB4KGkpKVxuICAgICAgICAueShkID0+IHkoZCkpXG4gICAgICAgIC5jdXJ2ZShjdXJ2ZUZ1bmN0aW9uKVxuXG4gICAgcmV0dXJuIChcbiAgICAgIDxzdmcgd2lkdGg9e3dpZHRofSBoZWlnaHQ9e2hlaWdodH0gdmlld0JveD17YDAgMCAke3dpZHRofSAke2hlaWdodH1gfT5cbiAgICAgICAge2xpbmVzLm1hcCgobGluZSwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb25zdCBjb2xvcnMgPSB7XG4gICAgICAgICAgICAuLi5kZWZhdWx0Q29sb3JzLFxuICAgICAgICAgICAgLi4ubGluZS5jb2xvcnNcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxnIGtleT17bGluZS5rZXkgfHwgaW5kZXh9PlxuICAgICAgICAgICAgICA8cGF0aCBkPXthcmVhRnVuY3Rpb24obGluZS52YWx1ZXMpfSBmaWxsPXtjb2xvcnMuYXJlYX0+XG4gICAgICAgICAgICAgICAge2xpbmUudGl0bGUgJiYgPHRpdGxlPntsaW5lLnRpdGxlfTwvdGl0bGU+fVxuICAgICAgICAgICAgICA8L3BhdGg+XG4gICAgICAgICAgICAgIDxwYXRoIGQ9e2xpbmVGdW5jdGlvbihsaW5lLnZhbHVlcyl9IHN0cm9rZT17Y29sb3JzLmxpbmV9IGZpbGw9XCJub25lXCIvPlxuICAgICAgICAgICAgPC9nPlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG4gICAgICA8L3N2Zz5cbiAgICApXG4gIH1cbn1cbiJdfQ==