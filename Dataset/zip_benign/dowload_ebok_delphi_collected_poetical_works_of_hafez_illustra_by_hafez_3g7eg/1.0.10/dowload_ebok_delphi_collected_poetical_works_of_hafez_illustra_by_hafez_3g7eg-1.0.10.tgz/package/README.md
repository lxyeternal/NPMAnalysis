# DOWNLOAD EBOOK Delphi Collected Poetical Works of Hafez (Illustra by Hafez PDF EPUB MOBI (pbxms)

### Download Ebook + Delphi Collected Poetical Works of Hafez (Illustra by Hafez in pdf - mobi - epub format



➡️ ➡️ <b>CLICK HERE:</b> <a href="http://tinybit.cc/4e1acedc">http://tinybit.cc/4e1acedc</a> ⬅️ ⬅️

<img src="https://is3-ssl.mzstatic.com/image/thumb/Publication122/v4/b0/54/2f/b0542f9b-7d90-c4fe-8281-16a134d46718/Hafez_-_Delphi_Poets_Series_Large.jpg/600x600bb.png" style="width:300px;" />

The collected works of Hafez, the fourteenth century poet of Shiraz, are regarded as a pinnacle of Persian literature. The extraordinary popularity of Ḥafeẓ’ poetry in all Persian-speaking lands stems from his concise, often colloquial, yet musical language, free from artificial virtuosity. The Delphi Poets Series offers readers the works of the world’s finest poets, with superior formatting. This volume presents Hafez’ collected poetical works, with numerous translations, beautiful illustrations and the usual Delphi bonus material. (Version 1) * Beautifully illustrated with images relating to Hafez’ life and works * Concise introduction to Hafez’ life and poetry * Images of how the poetry books were first printed, giving your eReader a taste of the original texts * Excellent formatting of the poems * Easily locate the poems you want to read * Includes four different translations of Hafez’ poetry - John Haddon Hindley, Herman Bicknell, Gertrude Lowthian Bell and Elizabeth Bridges * Features a bonus biography - explore Hafez’ mystical life * Scholarly ordering of texts into chronological order and literary genres Please visit www.delphiclassics.com to see our wide range of poet titles CONTENTS: The Life and Poetry of Hafez BRIEF INTRODUCTION: HAFEZ PERSIAN LYRICS THE DIVAN POEMS FROM THE DIVAN OF HAFIZ SONNETS FROM HAFEZ AND OTHER VERSES The Biography INTRODUCTION TO HAFEZ by Getrude Lowthian Bell Please visit www.delphiclassics.com to browse through our range of poetry titles or buy the entire Delphi Poets Series as a Super Set

Now you can download Delphi Collected Poetical Works of Hafez (Illustra epub by Hafez from this link:

👉👉👉 <b>DOWNLOAD EBOOK HERE: <a href="http://tinybit.cc/4e1acedc">http://tinybit.cc/4e1acedc</a></b>

