export class PainlessError extends Error {
  constructor() {
    super()
    this._constructor(...arguments)
  }
  _constructor(...args) {
    this.separator = '/'

    let name, message
    this.name = name = args[0]
    if (name.indexOf(':') != -1) {
      [this.name, this.message] = this.cmdParse(name)
      if (args.length > 1) this.cause = args[1]
    }
    else if (typeof args[1] == 'string') {
      this.message = args[1]
      if (args.length > 2) this.cause = args[2]
    }
    else if (args.length > 1) this.cause = args[1]
    
    const tag = this.constructor.tagMap.get(this.name)
    if (tag) this.tag = tag
  }
  // test-error/example-error: a test error with tag
  cmdParse(m) {
    const scan = m.match(/^(\S+?):?\s/)
    const name = scan[1]
    const message = m.slice(scan[0].length)
    return [name, message]
  }
  static tagMap = new Map()
  static tagName(cmd) {
    const scan = cmd.match(/^(\S+?):?\s/)
    const name = scan[1]
    const tagStr = cmd.slice(scan[0].length)
    const map = this.tagMap
    const taga = tagStr.split(/\s+/)
    const tag = map.get(name)
    if (tag) tag.push(...taga)
    else map.set(name, taga)
  }
  is(tag) {
    let match = this.name.slice(0, tag.length) == tag
    if (match) {
      const c = this.name.charAt(tag.length)
      match = c == '' || c == this.separator
    }
    if (!match && this.tag) match = this.tag.some(t => t == tag)
    return match
  }
  static wrap(error, nest = false) {
    if (!nest && error instanceof this) return error
    const name = error.name || this.name
    const message = error.message || ''
    const w = new this(name, message, error)
    return w
  }
  unwrap() {
    if (this.cause instanceof Error) return this.cause
    return null
  }
  static of() {
    return new this(...arguments)
  }
  *walkTag() {
    const e = this
    const path = e.name.split('/')
    for (let i=0; i<path.length; i++) {
      yield path.slice(0, path.length-i).join('/')
    }
    for (const tag of e.tag || []) {
      yield tag
    }
    yield 'default'
  }
  match(route) {
    const e = this
    const o = {tag: null, result: null, error: e}
    for (const tag of e.walkTag()) {
      if (tag in route) {
        o.tag = tag
        o.result = route[tag](o)
        return o
      }
    }
    return o
  }
}
