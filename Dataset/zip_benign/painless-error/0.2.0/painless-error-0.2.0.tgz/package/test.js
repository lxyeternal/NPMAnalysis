#!/usr/bin/env node

import {PainlessError} from './index.js'
const Oerr = PainlessError
const Perr = PainlessError
import assert from 'assert'
const as = assert
const eq = as.equal
const ok = as.ok
const nok = x => ok(!x)
const deq = as.deepEqual
const neq = (a, b) => ok(a != b)

function dontcall() {
    throw Oerr.of('never: this should not be call')
}

let err

// of
err = Oerr.of('test-err: a test error')
ok(err.is('test-err'))
eq(err.name, 'test-err')
eq(err.message, 'a test error')

// constructor
let err2
err2 = new Oerr('test-err', 'a test error')
deq(err, err2)

// tag name would not influent existing error
Oerr.tagName('test-err: a-test')
nok(err.is('a-test'))

// tag name will influent new error
err = Oerr.of('test-err: new test error')
ok(err.is('a-test'))

// match error
let result = null
let ctx
ctx = err.match({
    nothing() {
        throw Oerr.of('never: nothing should not match')
    },
    'test-err'(ctx) {
        eq(ctx.error, err)
        result = 1
        ctx.x = 3
        return 2
    }
})
ok(ctx.tag == 'test-err')
ok(ctx.result == 2)
ok(ctx.x == 3)
eq(result, 1)

// match nothing
ctx = err.match({})
nok(ctx.tag || ctx.result)

ctx = err.match({
    nothing() {
        throw Oerr.of('never: nothing should not match')
    },
    default(ctx) {
        eq(ctx.error, err)
        result = 3
    }
})
ok(ctx.tag == 'default', ctx.result === undefined)
eq(result, 3)

// wrap error
err2 = new Error('some msg')
err = Oerr.wrap(err2)
eq(err2.name, err.name)
eq(err2.message, err.message)
eq(err2, err.cause)
ctx = err.match({
    Error() {
        return 1
    },
    nothing() {
        dontcall()
    },
    default() {
        dontcall()
    }
})
deq(ctx, {tag: 'Error', result: 1, error: err})

// wrap smart
eq(Perr.wrap(err), err)
neq(Perr.wrap(err, true), err)

// unwrap
eq(err.unwrap(), err2)
err.cause = null
nok(err.unwrap())

// multiple tag
Oerr.tagName('test-err: tag-2 tag-3')
err = Oerr.of('test-err: multi tag err')
ok(err.is('test-err') && err.is('tag-2') && err.is('tag-3'))

// try block
for (const i of [1,2,3,4]) {
    try {
        throw Oerr.of(`throwe-type-${i}: a throw error`)
    }
    catch (err) { err.match({
        'throwe-type-1'() {
            eq(i, 1)
        },
        'throwe-type-2'() {
            eq(i, 2)
        },
        'throwe-type-3'() {
            eq(i, 3)
        },
        default() {
            eq(i, 4)
        }})
    }
}

// is no match substring
err = new Oerr('name-p1/name-p2: a p2 error')
ok(err.is('name-p1'))
ok(err.is('name-p1/name-p2'))
nok(err.is('name'))
nok(err.is('name-p2'))
