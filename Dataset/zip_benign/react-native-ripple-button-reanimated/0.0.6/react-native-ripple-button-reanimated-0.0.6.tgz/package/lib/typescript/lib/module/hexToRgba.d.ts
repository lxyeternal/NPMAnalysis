export function hexToRgbA(hex: any, opacity: any): string;
