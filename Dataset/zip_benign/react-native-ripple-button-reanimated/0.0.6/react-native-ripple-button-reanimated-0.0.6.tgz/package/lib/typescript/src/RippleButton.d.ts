import * as React from 'react';
interface RippleButtonProps {
    children: React.ReactElement;
    color: string;
    borderRadius?: number;
    onPress?: () => void;
    rippleScale?: number;
    duration?: number;
    overflow?: boolean;
    rippleColor?: string;
    rippleOpacity?: number;
}
declare function RippleButton({ children, color, borderRadius, onPress, rippleScale, duration, overflow, rippleColor, rippleOpacity, }: RippleButtonProps): JSX.Element;
export default RippleButton;
