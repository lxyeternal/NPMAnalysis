export declare function hexToRgbA(hex: string, opacity: number): string;
