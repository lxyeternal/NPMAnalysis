export default RippleButton;
declare function RippleButton({ children, color, borderRadius, onPress, rippleScale, duration, overflow, rippleColor, rippleOpacity }: {
    children: any;
    color: any;
    borderRadius: any;
    onPress?: (() => void) | undefined;
    rippleScale?: number | undefined;
    duration?: number | undefined;
    overflow?: boolean | undefined;
    rippleColor?: string | undefined;
    rippleOpacity?: number | undefined;
}): React.ReactElement<import("react-native-gesture-handler").TapGestureHandlerProps & React.RefAttributes<any>, string | React.JSXElementConstructor<any>>;
import * as React from "react";
