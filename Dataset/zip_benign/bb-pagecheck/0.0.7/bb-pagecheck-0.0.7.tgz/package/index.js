"use strict";
var Nightmare = require('nightmare');
var _ = require('underscore');
/**
 * @desc 对underscore的扩展,判断是否存粹的对象
 * @param obj
 * @returns {boolean}
 */
_.isPlainObject = function(obj){
    //return Object.prototype.toString.call(obj) === '[object Object]';
    if ( (obj === null || typeof obj !== "object") || obj.nodeType ) {
        return false;
    }
    if ( obj.constructor && !{}.hasOwnProperty.call( obj.constructor.prototype, "isPrototypeOf" )) {
        return false;
    }
    return true;
}
/**
 * @desc 对象深拷贝第二个之后的参数都会被拷贝进入第一个参数
 * @returns {*|{}}
 */
_.deepClone = function(){
    let target = arguments[0] || {},
        length = arguments.length,
        options,src,copyIsArray,clone;
    if(length <= 1){
        return target;
    }else{
        for (let i = 1; i < length; i++){
            if((options = arguments[i]) != null){
                _.each(options,(value,key) => {
                    src = target[key];
                    if(target ===  value){
                        return;
                    }
                    if(value && (_.isPlainObject(value) || (copyIsArray = _.isArray(value)))){
                        if(copyIsArray){
                            copyIsArray = false;
                            clone = src && _.isArray(src) ? src : [];
                        }else{
                            clone = src && _.isPlainObject(src) ? src : {};
                        }
                        target[key] = _.deepClone(clone,value);
                    }else if(value !== undefined){
                        target[key] = value;
                    }
                });
            }
        }
        return target;
    }
}
/**
 * @desc 得到图片资源大小与图片面积的大小比例 传入符合要求的图片url返回比例,注意:目前只能检测类似'...200x200.jpg'的图片,不符合规则的图片将直接返回0
 * @param url:string , size:number
 * @return number
 * @private
 */
function _getImageRatio(imageUrl,size){
    if(typeof imageUrl !== 'string' || typeof size !== 'number' || size === 0) return 0;
    var match = imageUrl.match(/(?:\_|!)(\d+)x(\d+)\.(?:png|jpg|gif|jpeg)$/i);
    if(match && /\d+/.test(match[1]) && /\d+/.test(match[2])){
        return Math.round(size / match[1] / match[2] * 100) / 100;//四舍五入两位
    }else{
        return 0;
    }
}

function check(url, option){
    //默认配置
    var defaultConfig = {
        port : 12301,//端口
        interval : 100,//检查页面的频率
        timeout : 5000,//等待页面加载时间
        userAgent : 'weixin',//'beibei',//mizhe //weixin
        device : {
            width : 750,//设备宽高,考虑到lazyload的作用范围所以需要设置,否则图片会加载更多
            height : 1206
        },
        check : {
            page : {
                pageTitle : true,//检查页面是否有设置title
                links : true,//检查页面链接是否符合hmp规范
                shareConf : true//检查是否填写分享配置
            },
            console : {
                consoleMessage : true,//检查控制台在刚载入时是否有console输出
                error : true,//检查控制台在刚载入时是否有error输出
                alert : true,//检查页面在刚载入时是否有alert输出
                resourceError : true//检查页面是否存在资源加载错误
            },
            resource : {
                resourceReceived : true,//检查页面资源加载如果在进入页面的一小段时间内(不可控)有pending的请求都会去接收
                resourceRequested : false//检查页面发起的资源请求,与上面非常相似,目前暂不支持
            }
        },
        returnData : false,//考虑到原始数据可能过大,为了减少传输可以关闭
        reviewLevel : 3,//页面审核级别,当检测页面的级别小于该值的时候允许通过有1,2,3个级别
        rule : {
            hasError : 3,
            hasConsole : 2,
            hasAlert : 3,
            hasResourceError : 1,
            //overPageSize : [1, 2, 3],
            //overImageSize : [1, 2, 3],
            //overImageRatio : [1, 2, 3],
            hasLinkError : 2,
            loseAppInfo : 2,
            unknownLink : 1,
            noTitle : 3,
            noShareConf : 2,
            unCompleteShareConf : 1,
            //如果超出最大尺寸限定的时候level就等于其超出的最大范围的key值
            maxImageSize : {
                '1' : 0.3 * 1024 * 1024,//如果单张图片超过0.3m则level=1
                '2' : 0.5 * 1024 * 1024,//如果单张图片超过0.5m则level=2
                '3' : 0.8 * 1024 * 1024//如果单张图片超过0.5m则level=3
            },//单张图片最大尺寸限定
            maxImageRatio : {
                '1' : 1,
                '2' : 2,
                '3' : 3
            },//单位面积内的图片大小,经过测试tinypng的压缩普遍低于0.5这个值
            maxPageSize : {
                '1' : 3 * 1024 * 1024,
                '2' : 5 * 1024 * 1024,
                '3' : 8 * 1024 * 1024
            }//最大页面尺寸限定
        },
        pageType : 'hmp',//测试页面属性,当前只支持hmp
        phantomPath : undefined,//支持谨慎使用,示范 '/Users/liyizhi/bin/'  phantomjs文件在bin文件夹之类的使用方法
        loadImages : true,//测试时是否加载图片,目前不支持修改
        screenshot : false,//测试时是否截图,目前不支持修改
        screenshotPath : './test.png'//截图的文件存放路径,目前不支持
    };
    //原始数据格式
    var originData = {
        error : [],
        alert : [],
        consoleMessage : [],
        resourceError : [],
        links : [],
        shareConf : '',
        resourceReceived : [],
        resourceRequested : [],
        pageTitle: '',
        loadTime : 0
    };
    //返回的数据
    var returnData = {
        success : true,
        result : [],
        launchSuggestion : true,
        originData : {}
    };

    //获取配置
    var config = _.deepClone(defaultConfig, option);

    //getInstace
    var nightmare = new Nightmare({
        webSecurity : false,
        port : config.port,
        interval : config.interval,
        phantomPath : config.phantomPath,
        timeout : config.timeout
    });


    //监听事件
    var eventType = ['consoleMessage', 'error', 'alert', 'resourceReceived', 'resourceRequested','resourceError'];
    if(nightmare instanceof Nightmare){
        if(config.check){
            _.each(config.check, value => {
                if(_.isObject(value)){
                    _.each(value, (v, k) => {
                        if(v && ~eventType.indexOf(k)){
                            nightmare.on(k, (msg, other) => {
                                var obj = {};
                                if(k === 'error'){
                                    //针对error做特殊处理
                                    obj.msg = msg;
                                    obj.trace = other;
                                }else{
                                    obj = msg
                                }
                                Array.isArray(originData[k]) && originData[k].push(obj);
                            });
                        }
                    });
                }
            });
        }
        nightmare.on('initialized', () => {
            originData.loadTime = _.now();
        });
        nightmare.on('loadFinished', () => {
            originData.loadTime = _.now() - originData.loadTime;
        });
    }

    //设置视口宽高
    if(config.device && config.device.width && config.device.height){
        nightmare.viewport(config.device.width, config.device.height);
    }else{
        nightmare.viewport(750, 1206);
    }

    //设置用户agent
    var userAgent = {
        beibei : 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Mobile/11D167 Beibei/1.0.0',
        beibeiAndroid : 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Mobile/11D167 Beibei/1.0.0',
        mizhe : 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Mobile/11D167 MizheHD/3.0.0 (iPad like mizhe_client)',
        mizheAndroid : 'Mozilla/5.0 (iPhone; CPU iPhone OS 7_1 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Mobile/11D167 Mizhe/3.0.0 (Android like mizhe_client)',
        weixin : 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_1_3 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Mobile/10B329 MicroMessenger/5.0.1',
        weixinAndroid : 'Mozilla/5.0 (Linux; U; Android 2.3.6; zh-cn; GT-S5660 Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1 MicroMessenger/4.5.255'
    };
    if(config.userAgent && userAgent[config.userAgent]){
        nightmare.useragent(userAgent[config.userAgent]);
    }

    //Promise
    return new Promise((resolve, reject) => {
        nightmare
            .goto(url)
            .evaluate(function(config){
                //定义数据存储对象
                var browserData = {
                    links : [],
                    shareConf : '',
                    pageTitle : ''
                };

                /**
                 * @desc 定义一个查找模块编号的方法 hmp专用
                 * @param node(a标签)
                 */
                function getAid(node){
                    if(node.nodeType !== 1 || node === document.body){
                        return null;
                    }
                    if(typeof node.getAttribute('module') === 'string' && node.getAttribute('aid')){
                        return node.getAttribute('aid');
                    }else{
                        return getAid(node.parentNode);
                    }
                }

                /**
                 * @desc 收集链接,并且根据链接找到所属模块ID
                 */
                function collectLinks(){
                    [].forEach.call(document.querySelectorAll('a'), function(value){
                        var linkData = {};
                        linkData.outerHTML =  value.outerHTML.replace(/^(<a.+?>)[\s\S]*(<\/a>)$/g,'$1$2');
                        linkData.link = value.href;
                        linkData.aid = config.pageType === 'hmp' ? getAid(value) : '';
                        browserData.links.push(linkData);
                    });
                }

                /**
                 * @desc 收集分享链接配置字符串,到处理数据的时候再进行验证
                 */
                function collectShareConf(){
                    browserData.shareConf = document.getElementById('app_share_conf') ? document.getElementById('app_share_conf').value : '';
                }

                function collectPageTitle(){
                    browserData.pageTitle = document.title;
                }
                if(config.check && config.check.page){
                    config.check.page.links && collectLinks();
                    config.check.page.shareConf && collectShareConf();
                    config.check.page.pageTitle && collectPageTitle();
                }
                return browserData;
            }, function(objectFromBrowser){
                //数据回来了
                originData.links = objectFromBrowser.links;
                originData.shareConf = objectFromBrowser.shareConf;
                originData.pageTitle = objectFromBrowser.pageTitle;
            }, config)
            .run((err, nightmare) => {
                if(err){
                    reject({
                        success : false,
                        error : 2,
                        desc : 'phantomJS错误:' + err,
                        data : {}
                    });
                }else{
                    //这里要进行数据处理
                    //_checkConsole(config);//检查控制台

                    var consoleResult = {};
                    consoleResult.type = 'console';
                    consoleResult.desc = '';
                    if(originData.consoleMessage.length){
                        consoleResult.desc += '页面控制台出现console:' + originData.consoleMessage.length + '次(请联系开发人员处理)\n';
                    }
                    if(originData.error.length){
                        consoleResult.desc += '页面控制台出现error:' + originData.error.length + '次(请联系开发人员处理)\n';
                    }
                    if(originData.alert.length){
                        consoleResult.desc += '页面出现alert:' + originData.alert.length + '次(请联系开发人员处理)\n';
                    }
                    if(originData.resourceError.length){
                        consoleResult.desc += '页面出现加载失败resourceError:' + originData.resourceError.length + '次(请联系开发人员处理)';
                    }
                    if(originData.alert.length > 0){
                        consoleResult.level = config.rule.hasAlert;
                    }else if(originData.error.length > 0){
                        consoleResult.level = config.rule.hasError;
                    }else if(originData.resourceError.length > 0){
                        consoleResult.level = config.rule.hasResourceError;
                    }else if(originData.consoleMessage.length > 0){
                        consoleResult.level = config.rule.hasConsole;
                    }else{
                        consoleResult.level = 0;
                    }
                    returnData.result.push(consoleResult);



                    //_checkResource(config);//检查资源,包括图片大小,页面大小

                    var images = [],details = [],
                        totalSize = 0,totalImageSize = 0,notUseGzip = [],
                        allowGzipContentType = ['text/html','text/plain','text/css','application/x-javascript','application/json; charset=utf-8','application/json'];

                    var resourceSize = {};
                    //下面采用了很奇葩的方法,因为每一个资源加载有两个状态 start和end,两者基本一样,但是有些资源加载的大小存放在start的bodySize里面,有些则在end里面,所以需要根据唯一id先进行统计
                    _.each(originData.resourceReceived, value => {
                        if(typeof value.id !== 'number'){
                            return;
                        }
                        if(value.stage === 'start'){
                            if(value.bodySize != undefined){
                                resourceSize[value.id] = value.bodySize - 0;
                            }else{
                                _.each(value.headers, v => {
                                    if(v.name === 'Content-Length'){
                                        if(/\d+/.test(v.value)){
                                            resourceSize[value.id] = v.value - 0;
                                        }
                                        return;
                                    }
                                });
                            }
                        }else if(value.stage === 'end'){
                            if(value.bodySize != undefined){
                                resourceSize[value.id] = value.bodySize - 0;
                            }else{
                                _.each(value.headers, v => {
                                    if(v.name === 'Content-Length'){
                                        if(/\d+/.test(v.value)){
                                            resourceSize[value.id] = v.value - 0;
                                        }
                                        return;
                                    }
                                });
                            }
                        }
                    });
                    //将统计结果放入中依据加载资源的唯一id作为索引 resourceSize
                    _.each(originData.resourceReceived, value => {
                        if(value.stage = 'end'){
                            var resourceObj = {};
                            resourceObj.url = value.url;
                            resourceObj.type = value.contentType;
                            resourceObj.size = resourceSize[value.id] || 0;//根据之前统计结果 //打点统计没有大小返回默认为0
                            totalSize += resourceObj.size;
                            if(resourceObj.type && ~resourceObj.type.indexOf('image')){//防止页面content-type是null
                                totalImageSize += resourceObj.size;//计算总图片大小
                                resourceObj.ratio = _getImageRatio(resourceObj.url, resourceObj.size);
                                images.push(resourceObj);
                            }else{
                                //判断是否可以使用gzip
                                if(~allowGzipContentType.indexOf(resourceObj.type)){
                                    value.headers && _.each(value.headers, v => {
                                        if(v.name === 'Content-Encoding' && v.value === 'gzip'){
                                            resourceObj.hasGzip = true;
                                        }
                                    });
                                    !resourceObj.hasGzip && notUseGzip.push(resourceObj);
                                }
                                details.push(resourceObj);
                            }

                        }

                    });

                    //图片检测
                    var imageSizeObj = {
                        type : 'imageSize',
                        level : 0,
                        desc : ''
                    };
                    var imageRatioObj = {
                        type : 'imageRatio',
                        level : 0,
                        desc : ''
                    };
                    _.each(images, value => {
                        var size, sizeLevel, ratio, ratioLevel;
                        _.each(config.rule.maxImageSize, (v, k) => {
                            if(value.size > v){
                                size = v;
                                sizeLevel = k;
                                imageSizeObj.level = imageSizeObj.level < k ? k : imageSizeObj.level;
                            }
                        });
                        if(typeof size !== 'undefined'){
                            imageSizeObj.desc += `页面中链接为:${value.url}的图片尺寸超过了限定的${(size / 1024 / 1024).toFixed(2)}M,达到了${sizeLevel}级,目前图片大小为${(value.size / 1024 / 1024).toFixed(2)}M,请尝试进行压缩\n`;
                        }

                        _.each(config.rule.maxImageRatio, (v, k) => {
                            if(value.ratio > v){
                                ratio = v;
                                ratioLevel = v;
                                imageRatioObj.level = imageRatioObj.level < k ? k : imageRatioObj.level;
                            }
                        });
                        if(typeof ratio !== 'undefined'){
                            imageRatioObj.desc += `页面中链接为:${value.url}的图片密度超过了限定的${(ratio)}字节/像素,达到了${ratioLevel}级,目前图片密度为${value.ratio},请尝试使用tinypng压缩\n`
                        }
                    });
                    returnData.result.push(imageSizeObj);
                    returnData.result.push(imageRatioObj);
                    //检测gzip压缩
                    var gzipObj = {
                        type : 'gzip',
                        level : 0,
                        desc : ''
                    };
                    if(notUseGzip.length > 0){
                        _.each(notUseGzip, value => {
                            gzipObj.desc += '资源链接为' + value.url + '未使用Gzip压缩,可以尝试使用\n';
                        });
                    }
                    returnData.result.push(gzipObj);
                    //检测pagesize
                    var pageSizeObj = {
                        type : 'pageSize',
                        level : 0,
                        desc : `页面总大小为:${(totalSize / 1024 / 1024).toFixed(2)}M,其中首屏加载的图片总大小为:${(totalImageSize / 1024 / 1024).toFixed(2)}M.`
                    };
                    _.each(config.rule.maxPageSize, (value, key) => {
                        if(totalSize > value){
                            pageSizeObj.level = key;
                            pageSizeObj.desc += `页面大小已经超出了尺寸限制,达到了${key}级`;
                        }
                    });
                    returnData.result.push(pageSizeObj);


                    if(config.check && config.check.page){
                        //检查链接
                        if(config.check.page.links){
                            var linksResult = {},
                                linkType = {
                                    otherLinks : [],//其他链接,不属于贝贝
                                    javascriptScheme : [],//javascript:;协议
                                    errorLinks : [],//错误链接,包括PC链接
                                    shortLinks : [],//短链接
                                    hmpLinks : [],//hmp链接
                                    loseAppInfoLinks : [],//缺失APPinfo或者appinfo配置错误的链接
                                    schemeLinks : [],//scheme协议
                                    unknownLinks : [],
                                    beibeiLinks : [],//贝贝的链接
                                    mizheLinks : []//mizhe的链接
                                };
                            //存储链接功能函数
                            //function _storeLink(value, type, desc){
                            //    if(Array.isArray(linkType[desc])){
                            //        linkType[desc].push({
                            //            link : value.link,
                            //            outerHTML : value.outerHTML,
                            //            desc : desc,
                            //            aid : value.aid
                            //        });
                            //    }
                            //}
                            _.each(originData.links, value => {
                                if(typeof value.link === 'string'){
                                    return ;
                                }
                                value.link = decodeURI(value.link);
                                value.outerHTML = decodeURI(value.outerHTML);
                                //先判断协议
                                if(/^https?:\/\//.test(value.link)){
                                    if(~value.link.indexOf('beibei')){
                                        if(/(mp|m|t)\.beibei/.test(value.link)){
                                            if(/(list\/list|detail\/detail|oversea\/oversea\-list|wego\/moment\-detail)/.test(value.link)){
                                                var type = RegExp.$1,
                                                    match = value.link.match(/beibeiapp_info=(\{.+?\})/),
                                                    beibeiapp_info;
                                                if(!match){
                                                    //_storeLink(value, 'loseAppInfoLinks', '缺失beibeiapp_info');
                                                    if(Array.isArray(linkType['loseAppInfoLinks'])){
                                                        linkType['loseAppInfoLinks'].push({
                                                            link : value.link,
                                                            outerHTML : value.outerHTML,
                                                            desc : '缺失beibeiapp_info',
                                                            aid : value.aid
                                                        });
                                                    }
                                                }else{
                                                    try{
                                                        beibeiapp_info = JSON.parse(match[1]);
                                                        switch (type) {
                                                            case 'list/list':
                                                                if(!beibeiapp_info.martshow || !/\d+/.test(beibeiapp_info.mid)){
                                                                    //_storeLink(value, 'loseAppInfoLinks', '专场appinfo配置错误');
                                                                    linkType['loseAppInfoLinks'].push({
                                                                        link : value.link,
                                                                        outerHTML : value.outerHTML,
                                                                        desc : '专场appinfo配置错误',
                                                                        aid : value.aid
                                                                    });
                                                                }
                                                                break;
                                                            case 'detail/detail':
                                                                if(beibeiapp_info.target !== 'detail' || !/\d+/.test(beibeiapp_info.iid)){
                                                                    //_storeLink(value, 'loseAppInfoLinks', '商品详情appinfo配置错误');
                                                                    linkType['loseAppInfoLinks'].push({
                                                                        link : value.link,
                                                                        outerHTML : value.outerHTML,
                                                                        desc : '商品详情appinfo配置错误',
                                                                        aid : value.aid
                                                                    });
                                                                }
                                                                break;
                                                            case 'oversea/oversea-list':
                                                                if(beibeiapp_info.target !== 'oversea_martshow' || !/\d+/.test(beibeiapp_info.desc)){
                                                                    //_storeLink(value, 'loseAppInfoLinks', '海外购专场appinfo配置错误');
                                                                    linkType['loseAppInfoLinks'].push({
                                                                        link : value.link,
                                                                        outerHTML : value.outerHTML,
                                                                        desc : '海外购专场appinfo配置错误',
                                                                        aid : value.aid
                                                                    });
                                                                }
                                                                break;
                                                            case 'wego/moment-detail':
                                                                if(beibeiapp_info.target !== 'wego_moment_detail' || !/\d+/.test(beibeiapp_info.data)){
                                                                    //_storeLink(value, 'loseAppInfoLinks', '圈儿商品appinfo配置错误');
                                                                    linkType['loseAppInfoLinks'].push({
                                                                        link : value.link,
                                                                        outerHTML : value.outerHTML,
                                                                        desc : '圈儿商品appinfo配置错误',
                                                                        aid : value.aid
                                                                    });
                                                                }
                                                                break;
                                                            default:
                                                                //_storeLink(value, 'unknownLinks', '未知的appinfo规则');
                                                                linkType['unknownLinks'].push({
                                                                    link : value.link,
                                                                    outerHTML : value.outerHTML,
                                                                    desc : '未知的appinfo规则',
                                                                    aid : value.aid
                                                                });
                                                                break;
                                                        }
                                                    }catch(e){
                                                        //_storeLink(value, 'loseAppInfoLinks', 'beibeiapp_info存在但是解析错误');
                                                        linkType['loseAppInfoLinks'].push({
                                                            link : value.link,
                                                            outerHTML : value.outerHTML,
                                                            desc : 'beibeiapp_info存在但是解析错误',
                                                            aid : value.aid
                                                        });
                                                    }
                                                }
                                            }else if(/^http:\/\/t\.beibei\.com\//.test(value.link)){
                                                //_storeLink(value, 'shortLinks', '贝贝短链接,无法进行详细检测');
                                                linkType['shortLinks'].push({
                                                    link : value.link,
                                                    outerHTML : value.outerHTML,
                                                    desc : '贝贝短链接,无法进行详细检测',
                                                    aid : value.aid
                                                });
                                            }else if(~value.link.indexOf('hms2_page')){
                                                //_storeLink(value, 'hmpLinks', '贝贝HMP线上页面');
                                                linkType['hmpLinks'].push({
                                                    link : value.link,
                                                    outerHTML : value.outerHTML,
                                                    desc : '贝贝HMP线上页面',
                                                    aid : value.aid
                                                });
                                            }else{
                                                //_storeLink(value, 'unknownLinks', '位置的贝贝链接,以后会分类');
                                                linkType['unknownLinks'].push({
                                                    link : value.link,
                                                    outerHTML : value.outerHTML,
                                                    desc : '位置的贝贝链接,以后会分类',
                                                    aid : value.aid
                                                });
                                            }
                                        }else if(~value.link.indexOf('quick') || /(www|you|global)\.beibei/.test(value.link)){
                                            //_storeLink(value, 'errorLinks', 'PC端链接');
                                            linkType['errorLinks'].push({
                                                link : value.link,
                                                outerHTML : value.outerHTML,
                                                desc : 'PC端链接',
                                                aid : value.aid
                                            });
                                        }else if(/hmp2\.fi\.bibei\.com/.test(value.link)){
                                            //_storeLink(value, 'errorLinks', '贝贝HMP测试页面链接');
                                            linkType['errorLinks'].push({
                                                link : value.link,
                                                outerHTML : value.outerHTML,
                                                desc : '贝贝HMP测试页面链接',
                                                aid : value.aid
                                            });
                                        }else{
                                            //_storeLink(value, 'unknownLinks', '未知的链接');
                                            linkType['unknownLinks'].push({
                                                link : value.link,
                                                outerHTML : value.outerHTML,
                                                desc : '未知的链接',
                                                aid : value.aid
                                            });
                                        }
                                    }else if(~value.link.indexOf('mizhe')){
                                        //_storeLink(value, 'mizheLinks', '米折链接');
                                        linkType['mizheLinks'].push({
                                            link : value.link,
                                            outerHTML : value.outerHTML,
                                            desc : '米折链接',
                                            aid : value.aid
                                        });
                                    }else{
                                        //_storeLink(value, 'otherLinks', '其他链接');
                                        linkType['otherLinks'].push({
                                            link : value.link,
                                            outerHTML : value.outerHTML,
                                            desc : '其他链接',
                                            aid : value.aid
                                        });
                                    }
                                }else if(/^javascript:/.test(value.link)){
                                    //_storeLink(value, 'javascriptScheme', 'javascrip协议');
                                    linkType['javascriptScheme'].push({
                                        link : value.link,
                                        outerHTML : value.outerHTML,
                                        desc : 'javascrip协议',
                                        aid : value.aid
                                    });
                                }else if(/^(beibei|mizhe)app:\/\//.test(value.link)){
                                    //_storeLink(value, 'schemeLinks', '贝贝协议或者米折协议');
                                    linkType['schemeLinks'].push({
                                        link : value.link,
                                        outerHTML : value.outerHTML,
                                        desc : '贝贝协议或者米折协议',
                                        aid : value.aid
                                    });
                                }else{
                                    //_storeLink(value, 'unknownLinks', '位置的错误的链接');
                                    linkType['unknownLinks'].push({
                                        link : value.link,
                                        outerHTML : value.outerHTML,
                                        desc : '位置的错误的链接',
                                        aid : value.aid
                                    });
                                }
                            });
                            linksResult.type = 'link';
                            linksResult.desc = '对链接错误的判断如有异议请联系开发人员\n';
                            _.each(linkType.errorLinks, value => {
                                linksResult.desc += '模块编号' + value.aid + '里的链接：' + value.link + '存在链接错误,错误理由：' + value.desc + '．\n';
                            });
                            _.each(linkType.loseAppInfoLinks, value => {
                                linksResult.desc += '模块编号' + value.aid + '里的链接：' + value.link + '存在链接错误,错误理由：' + value.desc + '．\n';
                            });
                            _.each(linkType.unknownLinks, value => {
                                linksResult.desc += '模块编号' + value.aid + '里的链接：' + value.link + '存在未能识别的链接,如果对该链接的分类有异议,请协助开发人员改正,谢谢^.^\n'
                            });
                            if(linkType.errorLinks.length > 0){
                                linksResult.level = config.rule.hasLinkError;
                            }else if(linkType.loseAppInfoLinks > 0){
                                linksResult.level = config.rule.loseAppInfo;
                            }else if(linkType.unknownLinks.length > 0){
                                linksResult.level = config.rule.unknownLink;
                            }else{
                                linksResult.level = 0;
                            }
                            returnData.result.push(linksResult);
                        }

                        //检查分享配置
                        if(config.check.page.shareConf){
                            var shareConfResult = {
                                type : 'shareConf'
                            };
                            if(typeof originData.shareConf === 'string' && originData.shareConf !== ''){
                                try{
                                    var shareObj = JSON.parse(originData.shareConf);
                                    if(!shareObj.url || !shareObj.image || !shareObj.title || !shareObj.platform || !shareObj.desc){
                                        shareConfResult.desc = '你有些配置信息貌似没有配置,这样不要紧么';
                                        if(!shareObj.url){
                                            shareConfResult.desc += '链接缺失,将使用默认链接';
                                        }
                                        if(!shareObj.image){
                                            shareConfResult.desc += '没有配置分享图片';
                                        }
                                        if(!shareObj.title){
                                            shareConfResult.desc += '没有配置标题';
                                        }
                                        if(!shareObj.platform){
                                            shareConfResult.desc += '分享平台未配置,将分享到所有平台';
                                        }
                                        if(!shareObj.desc){
                                            shareConfResult.desc += '没有配置描述';
                                        }
                                        shareConfResult.level = config.rule.unCompleteShareConf;
                                    }else{
                                        shareConfResult.desc = '一切正常';
                                        shareConfResult.level = 0;
                                    }
                                }catch(e){
                                    shareConfResult.desc = '分享配置解析错误,请检查配置并联系开发人员';
                                    shareConfResult.level = config.rule.noShareConf;
                                }
                            }else{
                                shareConfResult.desc = '没有配置分享信息';
                                shareConfResult.level = config.rule.noShareConf;
                            }
                            returnData.result.push(shareConfResult);
                        }

                        //检查title
                        if(config.check.page.pageTitle){
                            var level = 0,desc = '';
                            if(originData.pageTitle){
                                level = 0;
                                desc = '标题已填写为:' + originData.pageTitle;
                            }else{
                                level = config.rule.noTitle;
                                desc = '页面没有标题'
                            }
                            returnData.result.push({
                                type : 'pageTitle',
                                desc : desc,
                                level : level
                            });
                        }

                        //config.check.page.links && _checkLinks(config);
                        //config.check.page.shareConf && _checkShareConf(config);//检查分享
                        //config.check.page.pageTitle && _checkTitle(config);//检查title
                    }

                    //_review(config);//当上面都执行完成之后在此处做最终审核
                    //终审
                    var levels = [];
                    _.each(returnData.result, value => {
                        levels.push(value.level);
                    });
                    var maxLevel = _.max(_.uniq(_.filter(levels, v => v)));
                    if(maxLevel >= config.reviewLevel){
                        returnData.launchSuggestion = false;
                    }
                    console.log(originData.resourceReceived.length);
                    config.returnData && (returnData.originData = originData);//把原始数据返回
                    returnData.url = url;
                    resolve(returnData);
                }
            });
    });
}
module.exports  = {
    check : check
};