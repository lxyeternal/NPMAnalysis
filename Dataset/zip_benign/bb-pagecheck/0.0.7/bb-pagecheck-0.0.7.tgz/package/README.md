使用说明
=========

该模块是为HMP系统开发的插件，负责页面审核功能．

###安装(需要提前安装phantomjs 2.0+版本)
```
npm install bb-pagecheck --save
```

###使用
```
var check = require('bb-pagecheck');
var option = {};
check('http://m.beibei.com',option)
	.then(data => {
    	//....
	});
```

###其中option允许进行如下配置,下面是默认配置,用户可以对其进行覆盖
```
var _defaultConfig = {
        port : 12301,//端口
        interval : 50,//检查页面的频率
        timeout : 5000,//等待页面加载时间
        userAgent : 'weixin',//'beibei',//mizhe //weixin
        device : {
            width : 750,//设备宽高,考虑到lazyload的作用范围所以需要设置,否则图片会加载更多
            height : 1206
        },
        check : {
            page : {
                pageTitle : true,//检查页面是否有设置title
                links : true,//检查页面链接是否符合hmp规范
                shareConf : true//检查是否填写分享配置
            },
            console : {
                consoleMessage : true,//检查控制台在刚载入时是否有console输出
                error : true,//检查控制台在刚载入时是否有error输出
                alert : true,//检查页面在刚载入时是否有alert输出
                resourceError : true//检查页面是否存在资源加载错误
            },
            resource : {
                resourceReceived : true,//检查页面资源加载如果在进入页面的一小段时间内(不可控)有pending的请求都会去接收
                resourceRequested : false//检查页面发起的资源请求,与上面非常相似,目前暂不支持
            }
        },
        returnData : false,//考虑到原始数据可能过大,为了减少传输可以关闭
        reviewLevel : 3,//页面审核级别,当检测页面的级别小于该值的时候允许通过有1,2,3个级别
        rule : {
            hasError : 3,
            hasConsole : 2,
            hasAlert : 3,
            hasResourceError : 1,
            hasLinkError : 2,
            loseAppInfo : 2,
            unknownLink : 1,
            noTitle : 3,
            noShareConf : 2,
            unCompleteShareConf : 1,
            //如果超出最大尺寸限定的时候level就等于其超出的最大范围的key值
            maxImageSize : {
                '1' : 0.3 * 1024 * 1024,//如果单张图片超过0.3m则level=1
                '2' : 0.5 * 1024 * 1024,//如果单张图片超过0.5m则level=2
                '3' : 0.8 * 1024 * 1024//如果单张图片超过0.5m则level=3
            },//单张图片最大尺寸限定
            maxImageRatio : {
                '1' : 1,
                '2' : 2,
                '3' : 3
            },//单位面积内的图片大小,经过测试tinypng的压缩普遍低于0.5这个值
            maxPageSize : {
                '1' : 3 * 1024 * 1024,
                '2' : 5 * 1024 * 1024,
                '3' : 8 * 1024 * 1024
            }//最大页面尺寸限定
        },
        pageType : 'hmp',//测试页面属性,当前只支持hmp
        phantomPath : undefined,//支持谨慎使用,示范 '/Users/liyizhi/bin/'  phantomjs文件在bin文件夹之类的使用方法
        loadImages : true,//测试时是否加载图片,目前不支持修改
        screenshot : false,//测试时是否截图,目前不支持修改
        screenshotPath : './test.png'//截图的文件存放路径,目前不支持
    };
```

###调用成功后返回的数据格式(接收失败是success为false)
```
{
    success : true,//成功接收之后的参数,失败则没有这个字段
    result : [{
    	type : '检查的种类',
    	desc : '对检查的错误描述(描述语句能看懂)',
    	level : 3//错误评级
    }],
    launchSuggestion : true,//根据传入的rule定义,给予发布建议
    originData : {//存放了从phantom浏览器中收集的原始数据(未加工)
        error : [],
        alert : [],
        consoleMessage : [],
        resourceError : [],
        links : [],
        shareConf : '',
        resourceReceived : [],
        resourceRequested : [],
        pageTitle: '',
        pageSize : 0,
        loadTime : 0
    }
}
```

###下面是一些功能的解读
1. 模块只有一个check方法成功后通过.then(function(data){})方法得到回调
2. 所有的目前可以测试的内容都允许关闭与打开,目前resourceRequested功能可以进行统计(在返回的原始数据中能查询到),但是没有对其拿到的数据进行检测,所以目前处于默认关闭状态,如果有需要可以自行在配置中打开
3. 目前已知的一个问题是 如果在使用贝贝UA,在某些网页中会直接发起beibei://协议,这会导致测试浏览器直接认为资源加载失败,并且引起对其他资源加载的误判,所以默认UA设置成了在wx环境下,在确定页面不会自动发起beibei://协议时可以把UA设置成贝贝的UA.如果想使用普通UA,请直接配置为false或者null
4. 如果一切正确,在操作时会其中reuslt字段存放对数据的分析结果,originData中放入了页面测试的原始数据 launchSuggestion 是开发者对该页面是否可以上线的意见,可以作为使用者的参考
如有疑问,请联系模块作者