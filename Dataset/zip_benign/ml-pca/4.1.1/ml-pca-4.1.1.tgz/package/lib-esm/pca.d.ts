import { Matrix, AbstractMatrix } from 'ml-matrix';
declare type MaybeMatrix = AbstractMatrix | number[][];
export interface PCAOptions {
    isCovarianceMatrix?: boolean;
    method?: 'SVD' | 'NIPALS' | 'covarianceMatrix';
    center?: boolean;
    scale?: boolean;
    nCompNIPALS?: number;
    ignoreZeroVariance?: boolean;
}
export interface PCAModel {
    name: 'PCA';
    center: boolean;
    scale: boolean;
    means: number[];
    stdevs: number[];
    U: Matrix;
    S: number[];
    R?: any;
    excludedFeatures?: number[];
}
export interface PredictOptions {
    nComponents?: number;
}
/**
 * Creates new PCA (Principal Component Analysis) from the dataset
 * @param {MaybeMatrix} dataset - dataset or covariance matrix.
 * @param {PCAOptions} [options]
 * @param {boolean} [options.isCovarianceMatrix=false] - true if the dataset is a covariance matrix.
 * @param {string} [options.method='SVD'] - select which method to use: SVD (default), covarianceMatrirx or NIPALS.
 * @param {number} [options.nCompNIPALS=2] - number of components to be computed with NIPALS.
 * @param {boolean} [options.center=true] - should the data be centered (subtract the mean).
 * @param {boolean} [options.scale=false] - should the data be scaled (divide by the standard deviation).
 * @param {boolean} [options.ignoreZeroVariance=false] - ignore columns with zero variance if `scale` is `true`.
 * */
export declare class PCA {
    private center;
    private scale;
    private excludedFeatures;
    private U;
    private S;
    private R;
    private means;
    private stdevs;
    constructor(dataset?: MaybeMatrix, options?: PCAOptions, model?: PCAModel);
    /**
     * Load a PCA model from JSON
     * @param {PCAModel} model
     * @return {PCA}
     */
    static load(model: PCAModel): PCA;
    /**
     * Project the dataset into the PCA space
     * @param {MaybeMatrix} dataset
     * @param {PredictOptions} options
     * @return {Matrix} dataset projected in the PCA space
     */
    predict(dataset: MaybeMatrix, options?: PredictOptions): Matrix;
    /**
     * Calculates the inverse PCA transform
     * @param {Matrix} dataset
     * @return {Matrix} dataset projected in the PCA space
     */
    invert(dataset: Matrix): Matrix;
    /**
     * Returns the proportion of variance for each component
     * @return {[number]}
     */
    getExplainedVariance(): number[];
    /**
     * Returns the cumulative proportion of variance
     * @return {[number]}
     */
    getCumulativeVariance(): number[];
    /**
     * Returns the Eigenvectors of the covariance matrix
     * @returns {Matrix}
     */
    getEigenvectors(): Matrix;
    /**
     * Returns the Eigenvalues (on the diagonal)
     * @returns {[number]}
     */
    getEigenvalues(): number[];
    /**
     * Returns the standard deviations of the principal components
     * @returns {[number]}
     */
    getStandardDeviations(): number[];
    /**
     * Returns the loadings matrix
     * @return {Matrix}
     */
    getLoadings(): Matrix;
    /**
     * Export the current model to a JSON object
     * @return {Object} model
     */
    toJSON(): PCAModel;
    private _adjust;
    private _computeFromCovarianceMatrix;
    private _computeWithNIPALS;
}
export {};
//# sourceMappingURL=pca.d.ts.map