# Trigonometry
#### This project contains a special class for calculating trigonometric functions, with the possibility of automatic conversion to degrees.

## Install

```
npm install trigonometry-ts
```

## Usage

```ts
const { Trigonometry } = require("trigonometry-ts");

// Calculate the cosine of 45 degrees
const cos45 = Trigonometry.cos(45, true);

// Calculate the inverse sine of 0.5
const asin05 = Trigonometry.asin(0.5, false);

// Convert radians to degrees
const radian = Math.PI / 4;
const degree = Trigonometry.conversioToDegrees(radian);
```

Or if you use modern imports in node.js

```ts
import { Trigonometry } from "trigonometry-ts";

const cos45 = Trigonometry.cos(45, true);

const asin05 = Trigonometry.asin(0.5, false);

const radian = Math.PI / 4;
const degree = Trigonometry.conversioToDegrees(radian);
```

# API

### Trigonometry class includes the following functions:

```
cosine (cos), sine (sin), tangent (tan), cotangent (ctg).

It also includes inverse trigonometric functions, and they all start with *a*:
asin, acos, etc.

Hyperbolic functions end with the letter *h*:
asinh, tanh, cosh, actgh, etc.

All these functions take in 1 mandatory argument (value), and 1 optional (inDegress).

If the second argument is passed to true, the result of executing the method will be degrees.

There is also a method for converting radians to degrees:
"conversioRadianToDegrees"
```

## Contributing
Please write your feedback about my "creation".

This is my first experience in writing a library, and if you point out mistakes to me or give me advice, I will be very happy.