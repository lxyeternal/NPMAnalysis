export class Trigonometry {
	private static inDegressRatio = 57.29577951308232;

	public static cos(value: number, inDegress = false): number {
		const res = Math.cos(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res
	}

	public static acos(value: number, inDegress = false): number {
		const res = Math.acos(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static sin(value: number, inDegress = false): number {
		const res = Math.sin(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static asin(value: number, inDegress = false): number {
		const res = Math.asin(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static tan(value: number, inDegress = false): number {
		const res = Math.tan(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static atan(value: number, inDegress = false): number {
		const res = Math.atan(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static ctg(value: number, inDegress = false): number {
		const res = 1 / Math.tan(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static actg(value: number, inDegress = false): number {
		const res = Math.atan(1 / value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static cosh(value: number, inDegress = false): number {
		const res = Math.cosh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static acosh(value: number, inDegress = false): number {
		const res = Math.acosh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static sinh(value: number, inDegress = false): number {
		const res = Math.sinh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static asinh(value: number, inDegress = false): number {
		const res = Math.asinh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static tanh(value: number, inDegress = false): number {
		const res = Math.tanh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static atanh(value: number, inDegress = false): number {
		const res = Math.atanh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static ctgh(value: number, inDegress = false) {
		const res = Math.cosh(value) / Math.sinh(value);

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static actgh(value: number, inDegress = false) {
		const res = 0.5 * Math.log((value + 1) / (value - 1));

		return inDegress ? this.conversioRadianToDegrees(res) : res;
	}

	public static conversioRadianToDegrees(radian: number) {
		return radian * this.inDegressRatio;
	}
}

