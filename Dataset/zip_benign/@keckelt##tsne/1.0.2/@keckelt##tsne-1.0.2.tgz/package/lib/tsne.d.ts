export declare class TSNE {
    private assert;
    private getopt;
    private returnV;
    private vValue;
    gaussRandom(): any;
    private randn;
    private zeros;
    private randn2d;
    private L2;
    private xtod;
    private d2p;
    private sign;
    private perplexity;
    private dim;
    private epsilon;
    private iter;
    constructor(opt: any);
    private N;
    private P;
    initDataRaw(X: Array<Array<any>>): void;
    initDataDist(D: any): void;
    private Y;
    private gains;
    private ystep;
    initSolution(): void;
    getSolution(): any[];
    step(): number;
    debugGrad(): void;
    costGrad(Y: any): {
        cost: number;
        grad: any[];
    };
}
