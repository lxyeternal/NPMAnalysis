# game-mi5

# 游戏

##### 安装

```
npm install game-mi5
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-mi5/index"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: {
      baseOps: {
        activeNum: 10,//超过了10，显示有颜色数字
        aniSpeed: {
          clickSpeed: 0.5,//点击时候的速度（配置了此速度，速度则不递增）
          max: 1,//动画最大速度
          step: 0.1,//动画点击递增速度
        }
      },
      djsObj: {
        total: 10,
        endTail: "s",
        sourceName: "time1",
        x: 215,
        y: 430,
        align: "right"
      },
      defObj: {
        startTail: "k",
        sourceName: "defNum",
        destoryName: "activeNum",
        x: 234,
        y: 250,
        align: "left"
      },
      activeObj: {
        startTail: "k",
        sourceName: "activeNum",
        destoryName: "defNum",
        x: 234,
        y: 266,
        align: "left"
      },
      progress: {
        x: 220,
        y: 430,
        src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01XXStun1FJvhiTJSOm_!!1080040467.png",
        endTail: {
          src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ip2haA1FJvhpre7zI_!!1080040467.png"
        }
      },
      // 点击动画
      ani: {
        type: "animate",
        width: 690,
        height: 946,
        boomSpeed: 0.04,//速度
        loop: !true,
        scale: { x: 0.3, y: 0.3 },
        anchor: { x: 0.5, y: 0.5 },
        x: 750 / 2,
        y: 600,
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ESXGpn1FJvfZ5wPmu_!!1080040467.png", "name": "cat_00000.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01UNwznc1FJvfl1Hrse_!!1080040467.png", "name": "cat_00001.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Ac7l7l1FJvfoLiJeB_!!1080040467.png", "name": "cat_00002.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LwnJN01FJvfieIELA_!!1080040467.png", "name": "cat_00003.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012pEKor1FJvfq1PugQ_!!1080040467.png", "name": "cat_00004.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01iAy5mW1FJvfm1p9IE_!!1080040467.png", "name": "cat_00005.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014HKY041FJvffJsJx4_!!1080040467.png", "name": "cat_00006.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wy9ji51FJvffJpZSr_!!1080040467.png", "name": "cat_00007.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01mR8BR71FJvfieIQpR_!!1080040467.png", "name": "cat_00008.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RxQxa91FJvfpKBZaS_!!1080040467.png", "name": "cat_00009.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01hTQFcG1FJvfmWu78Y_!!1080040467.png", "name": "cat_00010.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01xCiYrW1FJvfi3jMgX_!!1080040467.png", "name": "cat_00011.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN011AtYll1FJvfnd8egI_!!1080040467.png", "name": "cat_00012.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01WiWFMt1FJvfZ5wPnl_!!1080040467.png", "name": "cat_00013.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01R38bOt1FJvffJtKKz_!!1080040467.png", "name": "cat_00014.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ilkedG1FJvfdnyhAy_!!1080040467.png", "name": "cat_00015.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01HZk3lt1FJvfjZGJC7_!!1080040467.png", "name": "cat_00016.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01YmqeN51FJvffunsSg_!!1080040467.png", "name": "cat_00017.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wKKvTa1FJvfm1lf5e_!!1080040467.png", "name": "cat_00018.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ofraLs1FJvfq1QJeX_!!1080040467.png", "name": "cat_00019.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jSv2nF1FJvfZ5ubX3_!!1080040467.png", "name": "cat_00020.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01YOOidF1FJvfl1HjZV_!!1080040467.png", "name": "cat_00021.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01MJdDHY1FJvfpKCJJK_!!1080040467.png", "name": "cat_00022.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ssHZbO1FJvfoLkb3I_!!1080040467.png", "name": "cat_00023.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01y9n10w1FJvfoLmbpY_!!1080040467.png", "name": "cat_00024.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015QjHa41FJvfZ5wLeN_!!1080040467.png", "name": "cat_00025.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01dz3D5t1FJvfi5WCne_!!1080040467.png", "name": "cat_00026.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01KGMZwY1FJvffuqlI8_!!1080040467.png", "name": "cat_00027.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012Moq8n1FJvfl1GG5x_!!1080040467.png", "name": "cat_00028.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cp5cq01FJvfoLmXfP_!!1080040467.png", "name": "cat_00029.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01JMieO31FJvfi3lqa0_!!1080040467.png", "name": "cat_00030.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Eua2yF1FJvfq1OuNw_!!1080040467.png", "name": "cat_00031.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01sMUPK71FJvfjs8jTh_!!1080040467.png", "name": "cat_00032.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01LvtC021FJvfdo0yXe_!!1080040467.png", "name": "cat_00033.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01wbZ0ip1FJvfi3kElk_!!1080040467.png", "name": "cat_00034.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01sISAxo1FJvfZ5vXl0_!!1080040467.png", "name": "cat_00035.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01y0rdYl1FJvfdnzIcj_!!1080040467.png", "name": "cat_00036.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R7zPK91FJvfi5USjm_!!1080040467.png", "name": "cat_00037.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01bcVHvB1FJvfpKEj2I_!!1080040467.png", "name": "cat_00038.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01BVfAQ41FJvfdo1FBY_!!1080040467.png", "name": "cat_00039.png", "width": "690", "height": "946" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01AVX8Bb1FJvfpKDv8w_!!1080040467.png", "name": "cat_00040.png", "width": "690", "height": "946" },
        ]
      },
      // 倒计时图片
      time1: [
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01YRRhDp1FJvhmlzjbv_!!1080040467.png", "val": "0", "width": "12", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zFVA3d1FJvhqdlmgc_!!1080040467.png", "val": "s", "width": "11", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Z64vJn1FJvhiTH6uL_!!1080040467.png", "val": "1", "width": "5", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN018OOAGD1FJvhYOngbr_!!1080040467.png", "val": "2", "width": "10", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wTwyqz1FJvhhoPO2R_!!1080040467.png", "val": "3", "width": "10", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01nB6yjF1FJvhprfT8U_!!1080040467.png", "val": "4", "width": "11", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN014vRZcS1FJvhprdvVc_!!1080040467.png", "val": "5", "width": "10", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Mc1R9f1FJvhprcFYA_!!1080040467.png", "val": "6", "width": "10", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01p9fINq1FJvhprcqyd_!!1080040467.png", "val": "7", "width": "10", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ho5s8Z1FJvhqdkmJT_!!1080040467.png", "val": "8", "width": "10", "height": "16", "offsetX": "0" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01a5QcNq1FJvhejKi1s_!!1080040467.png", "val": "9", "width": "10", "height": "16", "offsetX": "0" },
      ],
      // 激活数字
      activeNum: [
        { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01by4fC61FJvhdEFQql_!!1080040467.png", "val": "0", "width": "114", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN014RvvY61FJvhmm1sgt_!!1080040467.png", "val": "1", "width": "76", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AfHN7N1FJvhmlxzTx_!!1080040467.png", "val": "2", "width": "108", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01kxA4pE1FJvhmm0XVm_!!1080040467.png", "val": "3", "width": "106", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01X6NAce1FJvhhoPWLt_!!1080040467.png", "val": "4", "width": "116", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zAuaXL1FJvhjPuVJK_!!1080040467.png", "val": "5", "width": "105", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01XqojAd1FJvhjPqgH9_!!1080040467.png", "val": "6", "width": "107", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01vsacDr1FJvhdEFACY_!!1080040467.png", "val": "7", "width": "104", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ywX3nS1FJvhdEFACO_!!1080040467.png", "val": "8", "width": "110", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN010W43hM1FJvhhoRSwa_!!1080040467.png", "val": "9", "width": "107", "height": "152", "offsetX": "-25" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yfXGpz1FJvhm4Lg3B_!!1080040467.png", "val": "k", "width": "126", "height": "152", "offsetX": "-25" },
      ],
      // 默认数字
      defNum: [
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yhGvG51FJvhprdWap_!!1080040467.png", "val": "0", "width": "149", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01OjaGU71FJvhjrLMN5_!!1080040467.png", "val": "1", "width": "112", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01wCZQEb1FJvhheJckw_!!1080040467.png", "val": "2", "width": "144", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015ANJLy1FJvhheMdps_!!1080040467.png", "val": "3", "width": "141", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JAMzgo1FJvhm4JSs2_!!1080040467.png", "val": "4", "width": "152", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bl8gvJ1FJvhmlyvi9_!!1080040467.png", "val": "5", "width": "140", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01y6OIAG1FJvhjrLpUc_!!1080040467.png", "val": "6", "width": "142", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Ct7Fbt1FJvhmlzGVY_!!1080040467.png", "val": "7", "width": "140", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PEUM9a1FJvhl8oxPh_!!1080040467.png", "val": "k", "width": "166", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01cdTHxV1FJvhiTKGJV_!!1080040467.png", "val": "8", "width": "145", "height": "169", "offsetX": "-60" },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RkeFLb1FJvhfSIfdq_!!1080040467.png", "val": "9", "width": "143", "height": "169", "offsetX": "-60" },
      ]
    }
  },
  onLoad() {
  },
  beginFun(e) {
    // 开始游戏 必须在游戏初始化完成之后开始
    this.gameComponent.onEvent("start");
  },
  stopFun() {
    this.gameComponent.onEvent("stop");
  },
  resetFun() {
    this.gameComponent.onEvent("init");
  },
  isShowFun() {
    this.setData({
      showGame: !this.data.showGame
    })
  },

  onInitDone(e) {
    this.gameComponent = e.ref;
    /* my.alert({
      content: "游戏初始化完成"
    }) */
  },
  onGameOver(data) {
    console.log(data)
  }
});
```

- xaml

```
<view class="pageBox">
  <view class="gameBox" a:if="{{!showGame}}">
    <game gameSource="{{gameSource}}" onInitDone="onInitDone" onGameOver="onGameOver" />
  </view>
  <!--<view style="position:absolute;width:100%;height:2px;background:red;left:0;top:800rpx;"></view> -->

  <view onTap="beginFun" style="position:relative;z-index: 10;">开始</view>
  <view onTap="stopFun" style="position:relative;z-index: 10;">停止</view>
  <view onTap="resetFun" style="position:relative;z-index: 10;">重置游戏</view>
  <view onTap="isShowFun" style="position:relative;z-index: 10;">切换</view>
</view>
```

-acss

```
.pageBox{
  position: absolute;
  width: 750rpx;
  height: 100vh;
  left: 50%;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}
.gameBox{
  position: relative;
  width: 750rpx;
  height: 1200rpx;
  /* background: #323449; */
  background-color: #ccc;
}
```