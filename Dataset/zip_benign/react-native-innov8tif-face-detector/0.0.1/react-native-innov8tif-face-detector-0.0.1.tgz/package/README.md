
# react-native-innov8tif-face-detector

## Requirements

### Android
- minSdkVersion >= 21

### iOS
- iOS 11+ (arm64)
- Swift 5


## Getting started

`$ react-native install react-native-innov8tif-face-detector`

### Android

Add the code below in app build.gradle file

```
android {
    ```
    aaptOptions {
        noCompress "tflite"
    }
}
```

### iOS

1. Navigate to ios folder
2. Add the following code to Podfile

```
platform :ios, '11.0'
use_frameworks!

    ```

post_install do |installer|
    installer.pods_project.targets.each do |target|
        if target.name == "CryptoSwift"
			puts "Enable module stability for CryptoSwift"
			target.build_configurations.each do |config|
				config.build_settings['BUILD_LIBRARY_FOR_DISTRIBUTION'] = 'YES'
			end
        end
    end
end
```
3. Run command `Pod install`

## License
Apply licenses for Android and iOS SDKs

```
const license = Platform.select({
    android: "",
    ios: ""
})
```

## Configuration

| Property name | Description |Default value
|--|--|--|
|base64|return base64 string as image ouput|false|
|path|image file path|nil|
|faceThreshold|face threshold|0.9|
|eyeThreshold|eye threshold|0.5|

## Usage
```
import { detectFaceWithImage, detectFaceWithVideo } from 'react-native-innov8tif-face-detector';

detectFaceWithVideo({
    license: faceDetectorlLicense,
    base64: true,
    faceThreshold: 0.5,
    eyeThreshold: 0.5
})
    .then(result => {
        console.log(result)
    })
    .catch(error => {
        console.log(error)
    })

detectFaceWithImage({
    license: faceDetectorlLicense,
    base64: true,
    path: <imagePath>
    faceThreshold: 0.5,
    eyeThreshold: 0.5
})
    .then(result => {
        console.log(result)
    })
    .catch(error => {
        console.log(error)
    })
```

### Result
| Result | Description |
|--|--|
|faceImage|face image|
|isFaceDetected|return true if face is detected|
|isEye1Detected|return true if eye 1 is detected|
|isEye2Detected|return true if eye 2 is detected|

## Error Codes

| Error | Description |
| -- | -- |
| invalid license | The license is invalid |
| camera permission denied | The user did not grant the permission to access camera |
| cancel | The user canceled during the scanning process |
| timeout | Timeout due to face not detected within preset timer |
