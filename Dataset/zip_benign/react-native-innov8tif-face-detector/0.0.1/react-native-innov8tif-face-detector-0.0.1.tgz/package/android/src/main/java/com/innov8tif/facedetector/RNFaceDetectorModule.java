package com.innov8tif.facedetector;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.innov8tif.facedetector.listener.FaceDetectorResultListener;
import com.innov8tif.facedetector.model.FaceAttr;
import com.innov8tif.facedetector.model.FaceError;
import com.innov8tif.facedetector.model.config.Config;
import com.innov8tif.facedetector.utils.BitmapUtils;

import org.json.JSONException;
import org.json.JSONObject;

public class RNFaceDetectorModule extends ReactContextBaseJavaModule {

  private final ReactApplicationContext reactContext;

  public RNFaceDetectorModule(ReactApplicationContext reactContext) {
    super(reactContext);
    this.reactContext = reactContext;
  }

  @Override
  public String getName() {
    return "RNFaceDetector";
  }

  @ReactMethod
  public void detectFace(ReadableMap configs, final Promise promise) {
    String licenseKey = configs.getString("license");

    final Boolean base64 = configs.getBoolean("base64");

    String path = configs.getString("path");

    if (path != null) {
      path = path.replace("file://", "");
    }

    Config config = new Config.Builder()
            .setImagePath(path)
            .setFaceThreshold((float) configs.getDouble("faceThreshold"))
            .setEyeThreshold((float) configs.getDouble("eyeThreshold"))
            .build();

    FaceDetectorSDK.startDetection(this.getCurrentActivity(), licenseKey, config, new FaceDetectorResultListener() {
      @Override
      public void onResultReceived(boolean successful, int errorCode, FaceAttr result) {

        if (successful) {
          // handle result
          JSONObject results = new JSONObject();
          try {
            results.put("faceImage", convertImgToBase64(base64, result.getFaceImage()));
            results.put("isFaceDetected", result.isFaceDetected());
            results.put("isEye1Detected", result.isEye1Detected());
            results.put("isEye2Detected", result.isEye2Detected());
            promise.resolve(results.toString());
          } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            promise.reject(new Exception(e.getMessage()));
          }
        }
        else {
          // handle error
          FaceError faceErrorType = new FaceError();

          if  (errorCode == faceErrorType.ERROR_INVALID_LICENSE_KEY) {
            promise.reject(new Exception("Invalid license"));
          }
          else if (errorCode == faceErrorType.ERROR_PERMISSION_DENIED) {
            promise.reject(new Exception("Permission denied"));
          }
          else if (errorCode == faceErrorType.ERROR_USER_CANCEL_ACTION) {
            promise.reject(new Exception("User has cancelled"));
          }
          else if  (errorCode == faceErrorType.ERROR_TIME_OUT) {
            promise.reject(new Exception("Timeout"));
          }

        }
      }
    });
  }

  public String convertImgToBase64(Boolean base64, String image) {
    String result = "file://" + image;

    if (base64) {
      result = BitmapUtils.INSTANCE.convertToBase64(image);
    }

    return result;
  }
}