require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "react-native-innov8tif-face-detector"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.description  = <<-DESC
                    react-native-innov8tif-face-detector
                   DESC
  s.homepage     = "https://gitlab.com/innov8tif-ekyc-product/okaylive/mobile/react-native-innov8tif-face-detector.git"
  # brief license entry:
  s.license      = "MIT"
  # optional - use expanded license entry instead:
  # s.license    = { :type => "MIT", :file => "LICENSE" }
  s.authors      = { "Raymond Lau" => "raymond@innov8tif.com" }
  s.platforms    = { :ios => "9.0" }
  s.source       = { :git => "https://gitlab.com/innov8tif-ekyc-product/okaylive/mobile/react-native-innov8tif-face-detector.git", :tag => "#{s.version}" }

  s.source_files = "ios/**/*.{h,c,m,swift}"
  s.requires_arc = true
  s.static_framework = true
  s.dependency "React"
  s.dependency "FaceDetector", "0.0.3"
end


  