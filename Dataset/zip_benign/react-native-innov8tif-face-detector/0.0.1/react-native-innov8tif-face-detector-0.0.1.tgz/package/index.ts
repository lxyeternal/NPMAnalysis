
import { NativeModules } from 'react-native';

const { RNFaceDetector } = NativeModules;

interface DetecFaceProps {
    license: string,
    base64: boolean,
    path?: string,
    faceThreshold: number,
    eyeThreshold: number
}

type ConfigType = 'Image' | 'Video'

// call native function to detect face with video
export const detectFaceWithVideo = (detecFaceProps: DetecFaceProps) => {
    return detectFace(detecFaceProps, 'Video')
}

// call native function to detect face with image
export const detectFaceWithImage = (detecFaceProps: DetecFaceProps) => {
    return detectFace(detecFaceProps, 'Image')
}

const detectFace = ({ license, base64 = false, path, faceThreshold = 0.9, eyeThreshold = 0.5 }: DetecFaceProps, configType: ConfigType) => {

    return new Promise(function (resolve, reject) {

        if (configType == 'Image' && (path == undefined || path == null)) {
            reject("Path should not be empty")
        }
        else {
            RNFaceDetector.detectFace({
                license: license,
                base64: base64,
                path: path,
                faceThreshold: faceThreshold,
                eyeThreshold: eyeThreshold
            })
                .then(result => {
                    resolve(JSON.parse(result))
                })
                .catch(error => {
                    reject(error)
                })
        }
    })
}


