////
////  RNFaceDetector.swift
////  RNFaceDetector
////
////  Created by Raymond
////  Copyright © 2021 Facebook. All rights reserved.
////

import Foundation
import FaceDetector

@objc(RNFaceDetector)
class RNFaceDetector: NSObject {
    
    var promiseResolve: RCTPromiseResolveBlock?
    var promiseReject: RCTPromiseRejectBlock?
    
    @objc func detectFace(_ configs: NSDictionary, resolver resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
        
        let license = configs.object(forKey: "license")! as! String
        let base64 = configs.object(forKey: "base64") as! Bool
        let path = configs.object(forKey: "path") as? String
        var imagePath: URL? = nil
        
        if (path != nil) {
            imagePath = URL.init(string: path!)
        }

        let faceThreshold = configs.object(forKey: "faceThreshold") as! NSNumber
        let eyeThreshold = configs.object(forKey: "eyeThreshold") as! NSNumber
        
        DispatchQueue.main.async {
            
            var config = Config.Builder()
                    .setPath(imagePath)
                    .setFaceThreshold(faceThreshold.floatValue)
                    .setEyeThreshold(eyeThreshold.floatValue)
                    .build()

            // start the SDK
            let rootViewController = (UIApplication.shared.keyWindow?.rootViewController)!
            
            FaceDetectorSDK.startDetection(
                viewController: rootViewController,
                license: license,
                config: config
            )
            { success, errorCode, result in
                do {
                    if(success) {
                        // handle success
                        let faceDetectorObject:NSMutableDictionary = NSMutableDictionary()
                        
                        faceDetectorObject.setValue(self.convertImgToBase64(base64: base64, image: result!.faceImage!), forKey: "faceImage")
                        
                        faceDetectorObject.setValue(result!.faceDetected, forKey: "isFaceDetected")
                        faceDetectorObject.setValue(result!.eye1Detected, forKey: "isEye1Detected")
                        faceDetectorObject.setValue(result!.eye2Detected, forKey: "isEye2Detected")
                        
                        let jsonData = try JSONSerialization.data(withJSONObject: faceDetectorObject, options: .prettyPrinted)
                        let jsonString = String(data: jsonData, encoding: String.Encoding.ascii)!
                        
                        resolve(jsonString)
                    } else {
                        // handle error
                        self.handleError(errorCode, rejecter: reject)
                    }
                }
                catch {
                    print("Error:", error)
                }

            }
        }
    }

    func convertImgToBase64 (base64: Bool, image:URL) -> String {
        var result = image.absoluteString
        
        if (base64) {
            do {
                result = try convertImageToBase64(fileUrl: image)
            }
            catch {
                print("Error:", error)
            }
        }
        
        return result
    }
    
    func handleError(_ error: FaceError, rejecter reject: @escaping RCTPromiseRejectBlock) {
        switch error {
        case .invalidLicense:
            reject("invalid license", "invalid license", nil)
            return
        case .invalidImage:
            reject("invalid image path", "invalid image path", nil)
            return
        case .cameraPermission:
            reject("camera permission denied", "camera permission denied", nil)
            return
        case .timeout:
            reject("timeout", "timeout", nil)
            return
        case .userCancelled:
            reject("cancel", "cancel", nil)
            return
        case .noError:
            reject("no error", "no error", nil)
            return
        case .miscellaneous(let errorMsg):
            reject(errorMsg, errorMsg, nil)
            return
        case .invalidConfig(let errorMsg):
            reject(errorMsg, errorMsg, nil)
            return
        default:
            reject("unknown error", "unknown error", nil)
            return
        }
    }
}

