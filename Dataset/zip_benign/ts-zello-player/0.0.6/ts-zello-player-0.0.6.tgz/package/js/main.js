"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
const fs_1 = __importDefault(require("fs"));
const ytdl_core_1 = __importDefault(require("ytdl-core"));
const pino_1 = __importDefault(require("pino"));
const path_1 = require("path");
const node_id3_1 = __importDefault(require("node-id3"));
const p_event_1 = __importDefault(require("p-event"));
const node_fetch_1 = __importDefault(require("node-fetch"));
const sharp_1 = __importDefault(require("sharp"));
const ts_zello_1 = __importStar(require("ts-zello"));
const ZELLO_SERVER = 'wss://zello.io/ws';
async function main({ bitrateKbps, volumeFactor, samplingRate, tempoFactor, frameSize, credentials, channel, target, startAt, logLevel, normalizer, compressor, details, }) {
    const pinoLogger = pino_1.default({ ...ts_zello_1.DEFAULT_ZELLO_OPTIONS.logger, level: logLevel });
    // @see: https://stackoverflow.com/a/3726073/1223483
    const youTubeLinkRegEx = /^http(?:s?):\/\/(?:www\.)?(?:music\.)?youtu(?:be\.com\/watch\?v=|\.be\/)([\w\-\_]*)(&(amp;)?‌​[\w\?‌​=]*)?/;
    const urlRegEx = /^http(?:s?):\/\//;
    let stream = undefined;
    let z;
    const cred = credentials;
    // Override channel from the cli
    if (channel != null) {
        cred.channel = channel;
    }
    const fileStreamOptions = {
        samplingRate,
        volumeFactor,
        tempoFactor,
        normalizer,
        compressor,
    };
    async function start() {
        let image;
        let detailsText;
        try {
            if (target.match(youTubeLinkRegEx)) {
                // YouTube Link
                pinoLogger.info('YouTube link detected');
                pinoLogger.debug('Requesting YouTube video metadata');
                const videoInfo = await ytdl_core_1.default.getBasicInfo(target);
                if (details.text) {
                    detailsText = makeInfoLineFromYouTubeInfo(videoInfo);
                }
                if (details.image) {
                    image = await makeYouTubePreview(videoInfo);
                }
                pinoLogger.debug('Requesting YouTube stream');
                // Check to see the length of the video and is offset available.
                // Wait! Maybe it's already there?
                const ytdlOptions = {
                    quality: 'highestaudio',
                    ...(startAt != null ? { begin: startAt } : null),
                };
                const audio = ytdl_core_1.default(target, ytdlOptions);
                stream = audio.pipe(ts_zello_1.getAutoDecodeStream(pinoLogger, fileStreamOptions));
            }
            else if (target.match(urlRegEx)) {
                // Just a link
                pinoLogger.info('URL detected');
                pinoLogger.debug('Requesting URL...');
                const audio = (await node_fetch_1.default(target)).body;
                stream = audio.pipe(ts_zello_1.getAutoDecodeStream(pinoLogger, fileStreamOptions));
            }
            else {
                // File
                pinoLogger.info('Local file detected');
                if (!fs_1.default.existsSync(target)) {
                    throw new Error(`File not found: "${target}"`);
                }
                const tags = node_id3_1.default.read(target);
                if (details.text) {
                    detailsText = makeInfoLineFromTags(tags) || '🎵\u00A0' + path_1.basename(target);
                }
                if (details.image) {
                    if (tags.image != null && typeof tags.image === 'object') {
                        image = tags.image.imageBuffer;
                    }
                }
                stream = fs_1.default.createReadStream(target).pipe(ts_zello_1.getAutoDecodeStream(pinoLogger, { ...fileStreamOptions, startAt }));
            }
        }
        catch (err) {
            pinoLogger.error(err, 'ERROR');
            process.exit(2);
        }
        if (stream == null) {
            pinoLogger.error("Stream couldn't initialize");
            process.exit(3);
        }
        // This part is not required (it's not inside sendAudio macro),
        // but it decreases the delay between now-playing info and the audio transmission.
        pinoLogger.info('Waiting for data...');
        stream = stream.pipe(new ts_zello_1.DataWaitPassThroughStream());
        await p_event_1.default(stream, 'dataIsReady');
        pinoLogger.debug('Data is ready.');
        z = await ts_zello_1.default(ZELLO_SERVER, { logger: pinoLogger, name: 'ts-zello-player' });
        try {
            await z.ctl.run(function* ({ macros, commands }) {
                yield macros.login(cred);
                if (image != null) {
                    yield macros.sendImage(image);
                }
                if (detailsText != null) {
                    yield commands.sendTextMessage({ text: detailsText });
                }
                yield macros.sendAudio(stream, {
                    transcode: { samplingRate, frameSize, bitrateKbps, channels: 1 },
                });
            });
        }
        catch (err) {
            pinoLogger.error(err, 'ERROR');
        }
        pinoLogger.info('==> Closing socket');
        await z.ctl.close();
        pinoLogger.info('==> Socket is closed');
    }
    async function shutdown() {
        if (z && z.ctl.status() === 'OPEN') {
            pinoLogger.warn('Closing...');
            await stream.destroy();
            await z.ctl.close();
        }
    }
    process.on('SIGINT', async function () {
        pinoLogger.warn('Received SIGINT: Stopped by user');
        await shutdown();
        process.exit();
    });
    await start();
    pinoLogger.warn('==> end of main function');
}
exports.main = main;
function makeInfoLineFromTags({ artist, album, year, trackNumber, title }) {
    const _ = '\u00A0';
    return [
        artist ? `${artist}` : null,
        album ? `💿${_}${album} ${year ? `${_}(${year})` : ''}` : null,
        trackNumber || title ? `🎵${_}${trackNumber ? `${trackNumber} ` : ''}${title ? `- ${title}` : ''}` : null,
    ]
        .filter((item) => item != null)
        .join('\n');
}
function secondsToTimeFmt(seconds) {
    const secReminder = seconds % 60;
    const minutes = (seconds - secReminder) / 60;
    const minutesReminder = minutes % 60;
    const hours = (minutes - minutesReminder) / 60;
    let output = '';
    if (hours > 0) {
        output = `${hours.toString().padStart(2, '0')}:`;
    }
    output += `${minutes.toString().padStart(2, '0')}:${secReminder.toString().padStart(2, '0')}`;
    return output;
}
function numberFormat(n) {
    if (n > 1000000000) {
        return `${Math.round(n / 1000000000)}B`;
    }
    if (n > 1000000) {
        return `${Math.round(n / 1000000)}M`;
    }
    if (n > 1000) {
        return `${Math.round(n / 1000)}k`;
    }
    return n.toLocaleString();
}
function makeInfoLineFromYouTubeInfo({ videoDetails: { title, dislikes, likes, ownerChannelName, uploadDate, viewCount, lengthSeconds }, }) {
    const _ = '\u00A0';
    const lengthFmt = secondsToTimeFmt(parseInt(lengthSeconds));
    let viewsFmt = viewCount;
    if (viewCount.match(/^\d+$/)) {
        viewsFmt = numberFormat(parseInt(viewCount));
    }
    const likesFmt = numberFormat(likes ?? 0);
    const dislikesFmt = numberFormat(dislikes ?? 0);
    return [
        title,
        `👁${_}${viewsFmt}${_}${_}👍${_}${likesFmt}${_}${_}👎${_}${dislikesFmt}${_}${_}🕒${_}${lengthFmt}`,
        `ⓘ Channel: ${_}${ownerChannelName}${_}${_}⬆${_}${uploadDate}`,
    ]
        .filter((item) => item != null)
        .join('\n');
}
function findThumbnail(thumbnails) {
    let maxWidth = 0;
    let maxIndex = 0;
    for (let i = 0; i < thumbnails.length; i++) {
        if (thumbnails[i].width > maxWidth) {
            maxWidth = thumbnails[i].width;
            maxIndex = i;
        }
    }
    return thumbnails[maxIndex].url;
}
async function makeYouTubePreview(videoInfo) {
    const { videoDetails: { title, dislikes, likes, ownerChannelName, uploadDate, viewCount, lengthSeconds }, } = videoInfo;
    const lengthFmt = secondsToTimeFmt(parseInt(lengthSeconds));
    let viewsFmt = viewCount;
    if (viewCount.match(/^\d+$/)) {
        viewsFmt = numberFormat(parseInt(viewCount));
    }
    const likesFmt = numberFormat(likes ?? 0);
    const dislikesFmt = numberFormat(dislikes ?? 0);
    const thumbnailUrl = findThumbnail(videoInfo.videoDetails.thumbnails);
    let imageData = await (await node_fetch_1.default(thumbnailUrl)).buffer();
    imageData = await sharp_1.default(imageData).resize({ width: 800, height: 450 }).toBuffer();
    let svgPageData = fs_1.default.readFileSync(__dirname + '/../src/assets/drawing-opt.svg', 'utf8');
    svgPageData = svgPageData.replace('#videoTitle', title);
    svgPageData = svgPageData.replace('#channelName', ownerChannelName);
    svgPageData = svgPageData.replace('#viewsCount', viewsFmt);
    svgPageData = svgPageData.replace('#likes', likesFmt);
    svgPageData = svgPageData.replace('#dislikes', dislikesFmt);
    svgPageData = svgPageData.replace('#uploaded', uploadDate);
    const svgPageBuffer = Buffer.from(svgPageData);
    let svgTimeLabelData = fs_1.default.readFileSync(__dirname + '/../src/assets/time-label-opt.svg', 'utf8');
    svgTimeLabelData = svgTimeLabelData.replace('#time', lengthFmt);
    const svgTimeLabelBuffer = Buffer.from(svgTimeLabelData);
    return await sharp_1.default(svgPageBuffer)
        .composite([
        {
            input: imageData,
            left: 110,
            top: 0,
        },
        {
            input: svgTimeLabelBuffer,
            left: 850,
            top: 380,
        },
    ])
        .jpeg()
        .toBuffer();
}
//# sourceMappingURL=main.js.map