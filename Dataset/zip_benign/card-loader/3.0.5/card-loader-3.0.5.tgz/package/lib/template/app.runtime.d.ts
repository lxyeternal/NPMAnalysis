declare const _default: (modalPath: any) => {
    show(options: any): Promise<unknown>;
};
export default _default;
