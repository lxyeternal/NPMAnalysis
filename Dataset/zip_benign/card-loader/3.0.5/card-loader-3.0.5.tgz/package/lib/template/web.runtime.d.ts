declare const _default: (cardModal: any) => {
    show(options: any): Promise<void>;
};
export default _default;
