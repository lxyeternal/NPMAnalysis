declare function wap(filePath: string, opts?: any): string;
declare function app(cardName: string, opts?: any): string;
declare const _default: {
    wap: typeof wap;
    app: typeof app;
};
export default _default;
