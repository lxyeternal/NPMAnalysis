export declare const ready: (handle: any) => void;
export declare const onRendered: (data?: {}) => Promise<unknown>;
export declare const closeWindow: () => void;
export declare const showWVModal: (data?: {}) => Promise<unknown>;
