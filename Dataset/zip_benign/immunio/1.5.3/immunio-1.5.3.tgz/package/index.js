'use strict';

/**
 * Start the agent
 */
var agent = exports.agent = require('./lib/agent');
agent.start();

/**
 * Expose agent events as top level ones
 */
exports.on = agent.on.bind(agent);

/**
 * Expose the Authentication API
 */
exports.authentication = require('./lib/authentication');

/**
 * Expose the Custom Events API
 */
exports.custom = require('./lib/custom');
