-- Exposes the interface to run hook handlers in the Lua VM.
-- Loaded when a new VM (vm.js) is created.
--
-- Source: https://github.com/webarmor/immunio/wiki/Lua-VM-Interface

local M = {}

M.VM_VERSION = 1

-- Initialize globals used by the hooks
agentdata = agentdata or {}
serverdata = serverdata or {}

-- Initialize the VM with the code from __init__
function M.createContext(code)
  local init = assert(loadstring(code, "__init__"))()

  if init and init._vm_update then
    -- return the VM context table to the agent
    return init._vm_update(DEV_MODE, M.VM_VERSION)
  else
    error('Failed to create VM context.')
  end
end

-- Call a hook
function M.run(context, method, vars)
  if context and context.run then
    -- Call it!
    return context.run(method, vars)
  else
    error("Attempt to run hook '" .. method .. "' before VM code has loaded.")
  end
end

-- Check if a hook is implemented
function M.has(context, method)
  if context and context.has then
    -- Call it!
    return context.has(method, vars)
  else
    error("Attempt to run hook '" .. method .. "' before VM code has loaded.")
  end
end

-- Add a method to the context.
-- This is only used in tests.
function M.add(context, method, code)
  assert(TEST_MODE, "Can only add methods in test mode, set TEST_MODE to true")

  local func = assert(loadstring(code, method))
  assert(context.hooks and context.hooks.hook_handlers)
  
  context.hooks.hook_handlers[method] = { hook_main = func }
end

return M