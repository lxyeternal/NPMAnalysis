{
  "targets": [
    {
      "target_name": "lua",
      "sources": [
        "src/utils.cc",
        "src/luaref.cc",
        "src/luastate.cc",
        "src/nodelua.cc"
      ],
      'actions': [
        {
          'action_name': 'luajit',
          'inputs': [],
          'outputs': [
            'lua-hooks/ext/luajit/src/libluajit.a',
            'lua-hooks/libimmunio.a'
          ],
          'action': ['make', '-Clua-hooks', 'libimmunio.a', 'libluajit.a'],
        }
      ],
      "include_dirs": [
        "<!(node -e \"require('nan')\")",
        "lua-hooks/ext/luajit/src"
      ],
      "libraries": [
        '../lua-hooks/libimmunio.a',
        '../lua-hooks/ext/luajit/src/libluajit.a'
      ]
    }
  ]
}