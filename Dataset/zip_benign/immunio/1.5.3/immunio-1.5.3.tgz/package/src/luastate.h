#ifndef LUASTATE_H
#define LUASTATE_H

#include <map>
#include <node.h>
#include <nan.h>

#include "utils.h"

extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}

class LuaState : public Nan::ObjectWrap {
 public:
  static NAN_MODULE_INIT(Init);

 private:
  LuaState();
  ~LuaState();

  static NAN_METHOD(New);

  static NAN_METHOD(Gc);
  static NAN_METHOD(Status);
  static NAN_GETTER(StackSize);

  static NAN_METHOD(Eval);

  static NAN_METHOD(SetGlobal);
  static NAN_METHOD(GetGlobal);

  lua_State* lua_;
};
#endif
