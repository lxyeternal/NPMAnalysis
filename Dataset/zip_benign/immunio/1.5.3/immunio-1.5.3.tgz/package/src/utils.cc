#include <stdlib.h>
#include <nan.h>
#include "utils.h"
#include "luaref.h"

v8::Local<v8::Value> lua_to_value(lua_State* L, int i, int ref) {
  switch(lua_type(L, i)) {
  case LUA_TNIL:
    return Nan::Null();
  case LUA_TBOOLEAN:
    return Nan::New<v8::Boolean>(lua_toboolean(L, i));
  case LUA_TNUMBER:
    return Nan::New<v8::Number>(lua_tonumber(L, i));
  case LUA_TSTRING:
    {
      size_t len = 0;
      const char* str = lua_tolstring(L, i, &len);
      return Nan::Encode(str, len);
    }
  case LUA_TTABLE:
    if (ref) {
      lua_pushvalue(L, i);
      return LuaRef::Pop(L);
    } else {
      v8::Local<v8::Object> obj = Nan::New<v8::Object>();
      lua_pushnil(L);
      while(lua_next(L, -2) != 0){
        v8::Local<v8::Value> key = lua_to_value(L, -2, ref);
        v8::Local<v8::Value> value = lua_to_value(L, -1, ref);
        Nan::Set(obj, key, value);
        lua_pop(L, 1);
      }
      return obj;
    }
  case LUA_TFUNCTION:
    if (ref) {
      lua_pushvalue(L, i);
      return LuaRef::Pop(L);
    }
    break;
  }

  char buf[1000];
  sprintf(buf, "Unsupported Lua type: %s", luaL_typename(L, i));
  Nan::ThrowTypeError(buf);
  return Nan::Undefined();
}

void push_value_to_lua(lua_State* L, v8::Local<v8::Value> value) {
  if (value->IsString()) {
    Nan::Utf8String str(value);
    lua_pushlstring(L, *str, str.length());
  } else if (value->IsNumber()) {
    double n = Nan::To<double>(value).FromJust();
    lua_pushnumber(L, n);
  } else if (value->IsBoolean()) {
    int b_value = (int) Nan::To<bool>(value).FromJust();
    lua_pushboolean(L, b_value);
  } else if (value->IsObject()) {
    v8::Local<v8::Object> obj = Nan::To<v8::Object>(value).ToLocalChecked();

    // Check for lua.Ref objects
    if (LuaRef::IsRef(obj)) {
      LuaRef* ref = Nan::ObjectWrap::Unwrap<LuaRef>(obj);
      ref->Load();
      return;
    }

    // Array or Map-like object
    lua_newtable(L);

    v8::Local<v8::Array> keys = Nan::GetOwnPropertyNames(obj).ToLocalChecked();

    for(uint32_t i = 0; i < keys->Length(); ++i) {
      v8::Local<v8::Value> key = Nan::Get(keys, i).ToLocalChecked();
      v8::Local<v8::Value> val = Nan::Get(obj, key).ToLocalChecked();
      if (value->IsArray()) {
        push_value_to_lua(L, Nan::New(i + 1));
      } else {
        push_value_to_lua(L, key);
      }
      push_value_to_lua(L, val);
      lua_settable(L, -3);
    }
    
  } else {
    lua_pushnil(L);
  }
}
