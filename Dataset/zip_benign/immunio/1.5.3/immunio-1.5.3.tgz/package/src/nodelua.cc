#include <node.h>
#include <v8.h>

#include "luastate.h"
#include "luaref.h"

extern "C"{
#include <lua.h>
}

using namespace v8;

#define SYM(s)  Nan::New(s).ToLocalChecked()

NAN_MODULE_INIT(InitInfoConstants) {
  Local<Object> constants = Nan::New<Object>();
  Nan::Set(constants, SYM("VERSION"), SYM(LUA_VERSION));
  Nan::Set(constants, SYM("VERSION_NUM"), Nan::New(LUA_VERSION_NUM));
  Nan::Set(constants, SYM("COPYRIGHT"), SYM(LUA_COPYRIGHT));
  Nan::Set(constants, SYM("AUTHORS"), SYM(LUA_AUTHORS));
  Nan::Set(target, SYM("INFO"), constants);
}


NAN_MODULE_INIT(InitStatusConstants) {
  Local<Object> constants = Nan::New<Object>();
  Nan::Set(constants, SYM("YIELD"), Nan::New(LUA_YIELD));
  Nan::Set(constants, SYM("ERRRUN"), Nan::New(LUA_ERRRUN));
  Nan::Set(constants, SYM("ERRSYNTAX"), Nan::New(LUA_ERRSYNTAX));
  Nan::Set(constants, SYM("ERRMEM"), Nan::New(LUA_ERRMEM));
  Nan::Set(constants, SYM("ERRERR"), Nan::New(LUA_ERRERR));
  Nan::Set(target, SYM("STATUS"), constants);
}


NAN_MODULE_INIT(InitGcConstants) {
  Local<Object> constants = Nan::New<Object>();
  Nan::Set(constants, SYM("STOP"), Nan::New(LUA_GCSTOP));
  Nan::Set(constants, SYM("RESTART"), Nan::New(LUA_GCRESTART));
  Nan::Set(constants, SYM("COLLECT"), Nan::New(LUA_GCCOLLECT));
  Nan::Set(constants, SYM("COUNT"), Nan::New(LUA_GCCOUNT));
  Nan::Set(constants, SYM("COUNTB"), Nan::New(LUA_GCCOUNTB));
  Nan::Set(constants, SYM("STEP"), Nan::New(LUA_GCSTEP));
  Nan::Set(constants, SYM("SETPAUSE"), Nan::New(LUA_GCSETPAUSE));
  Nan::Set(constants, SYM("SETSTEPMUL"), Nan::New(LUA_GCSETSTEPMUL));
  Nan::Set(target, SYM("GC"), constants);
}


NAN_MODULE_INIT(InitAll) {
  LuaState::Init(target);
  LuaRef::Init(target);
  InitGcConstants(target);
  InitStatusConstants(target);
  InitInfoConstants(target);
}

NODE_MODULE(nodelua, InitAll)
