#define BUILDING_NODELUA
#include "luastate.h"

using namespace v8;

#define UNWRAP_LUA_STATE() Nan::ObjectWrap::Unwrap<LuaState>(info.Holder())


LuaState::LuaState() {};

LuaState::~LuaState() {};


NAN_MODULE_INIT(LuaState::Init) {
  Local<FunctionTemplate> tpl = Nan::New<FunctionTemplate>(New);
  tpl->SetClassName(Nan::New("State").ToLocalChecked());
  tpl->InstanceTemplate()->SetInternalFieldCount(1);
  
  Nan::SetAccessor(tpl->InstanceTemplate(), Nan::New("stackSize").ToLocalChecked(), StackSize);

  Nan::SetPrototypeMethod(tpl, "eval", Eval);

  Nan::SetPrototypeMethod(tpl, "setGlobal", SetGlobal);
  Nan::SetPrototypeMethod(tpl, "getGlobal", GetGlobal);

  Nan::SetPrototypeMethod(tpl, "status", Status);
  Nan::SetPrototypeMethod(tpl, "gc", Gc);

  Nan::Set(target, Nan::New("State").ToLocalChecked(), Nan::GetFunction(tpl).ToLocalChecked());
}


NAN_METHOD(LuaState::New) {
  if (!info.IsConstructCall()) {
    return Nan::ThrowTypeError("Use new to create an instance");
  }

  LuaState* obj = new LuaState();
  obj->lua_ = luaL_newstate();
  luaL_openlibs(obj->lua_);
  obj->Wrap(info.This());
}


NAN_METHOD(LuaState::Eval) {
  if (info.Length() < 1) {
    Nan::ThrowTypeError("One argument required");
    return info.GetReturnValue().SetUndefined();
  }

  Nan::Utf8String lua_code(info[0]);

  LuaState* obj = UNWRAP_LUA_STATE();
  if (luaL_dostring(obj->lua_, *lua_code)) {
    char buf[1000];
    sprintf(buf, "Lua error: %s", lua_tostring(obj->lua_, -1));
    Nan::ThrowError(buf);
    info.GetReturnValue().SetUndefined();
    return;
  }

  if (lua_gettop(obj->lua_)) {
    info.GetReturnValue().Set(lua_to_value(obj->lua_, -1, 1));
    lua_pop(obj->lua_, 1);
  } else{
    info.GetReturnValue().SetUndefined();
  }
}


NAN_METHOD(LuaState::SetGlobal) {
  if (info.Length() < 2) {
    Nan::ThrowTypeError("Two arguments required");
    return info.GetReturnValue().SetUndefined();
  }

  if (!info[0]->IsString()) {
    Nan::ThrowTypeError("First argument must be a string");
    return;
  }

  Nan::Utf8String global_name(info[0]);

  LuaState* obj = UNWRAP_LUA_STATE();

  push_value_to_lua(obj->lua_, info[1]);
  lua_setglobal(obj->lua_, *global_name);

  info.GetReturnValue().SetUndefined();
}


NAN_METHOD(LuaState::GetGlobal) {
  if (info.Length() < 1) {
    Nan::ThrowTypeError("Argument required");
    return info.GetReturnValue().SetUndefined();
  }

  if (!info[0]->IsString()) {
    Nan::ThrowTypeError("First argument must be a string");
    return;
  }

  Nan::Utf8String global_name(info[0]);

  LuaState* obj = UNWRAP_LUA_STATE();
  lua_getglobal(obj->lua_, *global_name);

  Local<Value> val = lua_to_value(obj->lua_, -1, 1);
  lua_pop(obj->lua_, 1);

  info.GetReturnValue().Set(val);
}


NAN_METHOD(LuaState::Status) {
  LuaState* obj = UNWRAP_LUA_STATE();
  int status = lua_status(obj->lua_);

  info.GetReturnValue().Set(Nan::New(status));
}


NAN_METHOD(LuaState::Gc) {
  if (info.Length() < 1) {
    Nan::ThrowTypeError("Argument required");
    info.GetReturnValue().SetUndefined();
    return;
  }

  if (!info[0]->IsNumber()) {
    Nan::ThrowTypeError("Argument must be a number, try lua.GC.[TYPE]");
    info.GetReturnValue().SetUndefined();
    return;
  }

  LuaState* obj = UNWRAP_LUA_STATE();
  int type = Nan::To<int>(info[0]).FromJust();
  int gc = lua_gc(obj->lua_, type, 0);

  info.GetReturnValue().Set(Nan::New(gc));
}


NAN_GETTER(LuaState::StackSize) {
  LuaState* obj = UNWRAP_LUA_STATE();
  int n = lua_gettop(obj->lua_);

  info.GetReturnValue().Set(Nan::New(n));
}
