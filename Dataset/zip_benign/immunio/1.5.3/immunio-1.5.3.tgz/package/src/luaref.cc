#include "luaref.h"

using namespace v8;

#define UNWRAP_OBJ() Nan::ObjectWrap::Unwrap<LuaRef>(info.Holder())


LuaRef::LuaRef(lua_State* lua) : lua_(lua) {
  ref_ = luaL_ref(lua_, LUA_REGISTRYINDEX);
}

LuaRef::~LuaRef() {
  luaL_unref(lua_, LUA_REGISTRYINDEX, ref_);
}


Nan::Persistent<Function> LuaRef::constructor;
Nan::Persistent<FunctionTemplate> LuaRef::constructorTemplate;


NAN_MODULE_INIT(LuaRef::Init) {
  Local<FunctionTemplate> tpl = Nan::New<FunctionTemplate>();
  tpl->SetClassName(Nan::New("Ref").ToLocalChecked());
  tpl->InstanceTemplate()->SetInternalFieldCount(1);

  Nan::SetPrototypeMethod(tpl, "toObject", ToObject);
  Nan::SetAccessor(tpl->InstanceTemplate(), Nan::New("length").ToLocalChecked(), Length);
  Nan::SetPrototypeMethod(tpl, "get", Get);
  Nan::SetCallAsFunctionHandler(tpl->InstanceTemplate(), Call);
  Nan::SetNamedPropertyHandler(tpl->InstanceTemplate(), GetProperty);
  Nan::SetIndexedPropertyHandler(tpl->InstanceTemplate(), GetIndex);
  Nan::SetAccessor(tpl->InstanceTemplate(), Nan::New("type").ToLocalChecked(), Type);

  constructor.Reset(Nan::GetFunction(tpl).ToLocalChecked());
  constructorTemplate.Reset(tpl);

  Nan::Set(target, Nan::New("Ref").ToLocalChecked(), Nan::GetFunction(tpl).ToLocalChecked());
}


// Pops the object on top of the stack, stores it in a Lua ref and return a new Ref instance representing it.
v8::Local<v8::Value> LuaRef::Pop(lua_State* lua) {
  Local<Function> cons = Nan::New(constructor);
  Local<Object> val = Nan::NewInstance(cons).ToLocalChecked();

  LuaRef* obj = new LuaRef(lua);
  obj->Wrap(val);

  return val;
}


bool LuaRef::IsRef(v8::Local<v8::Object> obj) {
  return Nan::New(constructorTemplate)->HasInstance(obj);
}


// Loads the ref onto the stack
void LuaRef::Load() {
  lua_rawgeti(lua_, LUA_REGISTRYINDEX, ref_);
}

Local<Value> LuaRef::Get(Local<Value> key) {
  Load(); // Push the table at [-2]

  // Make sure it's a table
  if (!lua_istable(lua_, -1)) {
    Nan::ThrowTypeError("Not a table");
    lua_pop(lua_, 1);
    return Nan::Undefined();
  }

  // Push the key at [-1]
  push_value_to_lua(lua_, key);

  lua_gettable(lua_, -2);
  Local<Value> val = lua_to_value(lua_, -1, 1);
  lua_pop(lua_, 2); // Pop the table and value

  return val;
}


// JS Methods

NAN_METHOD(LuaRef::ToObject) {
  LuaRef* obj = UNWRAP_OBJ();

  obj->Load();
  Local<Value> val = lua_to_value(obj->lua_, -1, 0);
  lua_pop(obj->lua_, 1);

  info.GetReturnValue().Set(val);
}


NAN_METHOD(LuaRef::Call) {
  LuaRef* obj = UNWRAP_OBJ();

  obj->Load();

  int nargs = info.Length();

  for (int i = 0; i < nargs; i++) {
    push_value_to_lua(obj->lua_, info[i]);
  }

  int ret = lua_pcall(obj->lua_, nargs, 1, 0);

  switch (ret) {
  case 0: // Success!
    {
      Local<Value> val = lua_to_value(obj->lua_, -1, 1);
      lua_pop(obj->lua_, 1);
      info.GetReturnValue().Set(val);
    }
    break;
  case LUA_ERRRUN:
    {
      char msg[1000];
      sprintf(msg, "Lua runtime error: %s", lua_tostring(obj->lua_, -1));
      lua_pop(obj->lua_, 1);
      Nan::ThrowError(msg);
    }
    break;
  case LUA_ERRMEM:
    Nan::ThrowError("Lua memory allocation error");
    break;
  case LUA_ERRERR:
    Nan::ThrowError("Error in Lua error handler");
    break;
  }
}


NAN_GETTER(LuaRef::Length) {
  LuaRef* obj = UNWRAP_OBJ();
  obj->Load();

  Local<Value> len = Nan::New<Number>(lua_objlen(obj->lua_, -1));

  info.GetReturnValue().Set(len);

  lua_pop(obj->lua_, 1);
}

NAN_METHOD(LuaRef::Get) {
  if (info.Length() != 1) {
    return Nan::ThrowTypeError("get requires one argument");
  }

  LuaRef* obj = UNWRAP_OBJ();
  info.GetReturnValue().Set(obj->Get(info[0]));
}

NAN_PROPERTY_GETTER(LuaRef::GetProperty) {
  // Check if the property already exists on the JS object.
  // Note: HasRealNamedProperty doesn't work here, no idea why...
  if (!Nan::GetRealNamedProperty(info.This(), property).IsEmpty()) {
    // Fallback to calling to original behavior.
    return;
  }

  LuaRef* obj = UNWRAP_OBJ();
  info.GetReturnValue().Set(obj->Get(property));
}

NAN_INDEX_GETTER(LuaRef::GetIndex) {
  LuaRef* obj = UNWRAP_OBJ();
  info.GetReturnValue().Set(obj->Get(Nan::New(index + 1)));
}

NAN_GETTER(LuaRef::Type) {
  LuaRef* obj = UNWRAP_OBJ();
  obj->Load();

  Local<Value> type = Nan::New(luaL_typename(obj->lua_, -1)).ToLocalChecked();

  info.GetReturnValue().Set(type);
  lua_pop(obj->lua_, 1);
}