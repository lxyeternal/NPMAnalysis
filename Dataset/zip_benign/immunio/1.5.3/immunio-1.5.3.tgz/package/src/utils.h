#ifndef LUAUTILS_H
#define LUAUTILS_H

#include <string.h>
#include <node.h>

extern "C"{
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
}

v8::Local<v8::Value> lua_to_value(lua_State* L, int, int);
void push_value_to_lua(lua_State* L, v8::Local<v8::Value> value);
#endif
