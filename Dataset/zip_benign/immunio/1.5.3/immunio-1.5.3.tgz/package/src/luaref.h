#ifndef LUAREF_H
#define LUAREF_H

#include <node.h>
#include <nan.h>

#include "utils.h"

extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}

class LuaRef : public Nan::ObjectWrap {
 public:

  static NAN_MODULE_INIT(Init);

  static v8::Local<v8::Value> Pop(lua_State* lua);
  static bool IsRef(v8::Local<v8::Object> obj);

  void Load();
  v8::Local<v8::Value> Get(v8::Local<v8::Value> key);

 private:
  LuaRef(lua_State* lua);
  ~LuaRef();

  static NAN_GETTER(Length);
  static NAN_METHOD(ToObject);
  static NAN_METHOD(Call);
  static NAN_METHOD(Get);
  static NAN_PROPERTY_GETTER(GetProperty);
  static NAN_INDEX_GETTER(GetIndex);
  static NAN_GETTER(Type);

  static Nan::Persistent<v8::Function> constructor;
  static Nan::Persistent<v8::FunctionTemplate> constructorTemplate;

  lua_State* lua_;
  int ref_;
};

#endif
