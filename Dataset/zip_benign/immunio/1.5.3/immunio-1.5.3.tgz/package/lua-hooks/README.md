# Lua Hook Handlers

Code in this project is shared by all agents.

## Testing

To compile our custom Lua interpreter:

```
make
./lua -h
```

To run the tests:

```
make test
```

## Directories

### `hooks` directory

These are legacy hook handlers, used prior to Nov 2015. Ignore them until we can kill them.

### `lib` directory

Utility functions and libraries.

`lib/boot.lua` is a legacy bootstrap to start the interpreter in agents that haven't phased it out yet.

`lib/hooks.lua` id the entrypoint for calls from the agent into the Lua interpreter.

### `lib/hooks` directory

These are the hooks the agents call to do interesting security type things...

### `ext` directory

Custom Lua interpreter with bundled extensions. Each extension is in it's own directory.

The file `all.c` includes all the required files and is compiled into the `lua-hooks.so` shared library used in the agents.

### `etc` directory

Tools and utility scripts for testing this project.
