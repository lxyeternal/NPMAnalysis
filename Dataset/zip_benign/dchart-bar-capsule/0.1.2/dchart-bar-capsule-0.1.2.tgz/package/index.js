'use strict';
// var Bar = require('../../bar');
var Bar = require('dchart-core/bar/bar');
var d3 = require('d3');
var _ = require('dchart-core/util');

/**
 * @param container
 * @param options
 * @constructor
 */
function BarCapsule(container, options) {
  var opt = {
    margin: {top: 40, right: 20, bottom: 35, left: 25},
    xaxis: {
      type: 'category',
      padding: [0.95, 0.4],
      groupPadding: [0, 0],
      dy: 40,
      key: 'x'
    },
    yaxis: {},
    hullPadding: 4,
    percent: 0.15
  };
  _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}
BarCapsule = Bar.extend(BarCapsule, {
  afterRender: function () {
    Bar.prototype.afterRender.call(this);
    var opt = this.options;

    var xaxis = this.getComs('axis', 'xaxis');
    var x = xaxis.getX();
    var yaxis = this.getComs('axis', 'yaxis');
    var y = yaxis.getX();
    var bars = this.series.selectAll('.series-group');

    var ykey = opt.yaxis.key;
    var xkey = opt.xaxis.key;
    var pad = opt.hullPadding;
    bars.each(function (data) {
      var that = d3.select(this);
      that.select('.serie').attr({
        rx: x.rangeBand() / 2,
        ry: x.rangeBand() / 2
      });
      var bg = that.select('.serie-bg')[0][0] ? that.select('.serie-bg') : that.append('rect')
        .attr({
          class: 'serie-bg'
        }).style('fill', 'none');

      bg.attr({
        y: -pad,
        width: x.rangeBand() + pad * 2,
        height: opt.innerHeight + pad * 2,
        rx: x.rangeBand() / 2 + pad,
        ry: x.rangeBand() / 2 + pad,
        x: x(data[xkey]) - pad
      });

      var label = that.select('.serie-label')[0][0] ? that.select('.serie-label') : that.insert('text')
        .attr({
          class: 'serie-label'
        });

      label.attr({
        x: x(data[xkey]) + x.rangeBand() * 0.82,
        y: opt.innerHeight + opt.xaxis.dy,
      }).text(function (d) {
        return data[ykey];
      }).style('text-anchor', 'middle');
    });
  },
  updateAfterRender: function () {
    BarCapsule.prototype.afterRender.call(this);
  }
});

module.exports = BarCapsule;
