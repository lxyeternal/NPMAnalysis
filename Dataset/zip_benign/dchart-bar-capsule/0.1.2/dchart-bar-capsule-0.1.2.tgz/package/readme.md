dchart-bar-capsule

符合dchart规范的胶囊图

### 安装

```
npm install dchart-bar-capsule
```

### 用法
```
var Bar = require('dchart-bar-capsule');
var bar = new Bar(container, {
  xaxis: {
    padding: [0.8, 0.3],      //柱状子间的间距[innerPadding, outerPadding],默认[0.9, 0.4]
    dy: 12,                   //位移
  },
  yaxis: {
    min: null,                 //默认null会自动计算数据中的最小值
    max: null,                 //默认null会自动计算数据中的最大值
    ticks: 4                   //显示4个刻度
  },
  hullPadding: 4,              //外壳间隙
  percent: 0.15                //装饰性隔断占1/4扇形的百分比
});
bar.render([
        {"x": "山东", "y": 100},
        {"x": "山西", "y": 52},
        {"x": "河北", "y": 49}
      ]);
```
