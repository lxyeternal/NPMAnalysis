options = require 'commander'
https = require 'https'
GitHubApi = require 'github'
temp = require 'temp'
fs = require 'fs'
child = require 'child_process'
pack = require "#{__dirname}/../package"
path = require 'path-extra'
mkdirp = require 'mkdirp'
async = require 'async'
crypto = require 'crypto'
readline = require 'readline'
clc = require 'cli-color'
findHotspots = require 'hotspots'

configTemplate =
  pivotalToken: ''
  githubAccessToken: ''
  githubOwner: ''
  editor: ''
  flowdockApiToken: ''
  flowdockFlowId: ''
  reviewThresholdHigh: 0.5
  reviewThresholdMid: 0.1

exitWithError = (message) ->
  console.log message
  process.exit 1

configDir = path.resolve path.homedir(), '.gus'
configPath = "#{configDir}/config.json"

# Load config
if mkdirp.sync configDir
  fs.writeFileSync configPath, JSON.stringify(configTemplate, null, '\t')
  exitWithError "Please modify your config '#{configPath}'"
else
  try
    config = require configPath
  catch err
    console.log err.message
    exitWithError 'Could not load config.'

temp.track()

# Init Arguments
options
  .version pack.version
  .option '-c, --create', 'Checkout Branch'
  .option '-s, --subject [type]', 'Subject of Branch'
  .option '-i, --pivotal-story-id <id>', 'Pivotal Story ID'
  .option '-p, --deliver', 'Add/Commit/Push Changes and Create/Update Pull Request'
  .option '-m, --message [type]', 'Commit message'
  .option '-o, --open', 'Open Github pull request page upon creation'
  .option '-u, --update', 'Update current branch to origin using pull'
  .option '-f, --find-hotspots', 'Force find hotspots'
  .option '-r, --review-last-commit', 'Force review last commit for hotspots'
  .option '-v, --verbose', 'Verbose Mode'
  .parse process.argv

log = (message) -> console.log message if options.verbose

github = new GitHubApi
  version: '3.0.0'

createExec = (options, cb) ->
  child.exec options.command, (err, stdOut, stdErr) ->
    if err
      log err.message
      cb err
    else
      log stdErr if stdErr
      log options.successMessageFn(stdOut) if options.successMessageFn
      cb null, if options.stdOutFn then options.stdOutFn stdOut else stdOut

openPullRequest = (repo, number, cb) ->
  createExec
      command: "open https://github.com/#{config.githubOwner}/#{repo}/pull/#{number}"
      successMessageFn: -> "Opened pull request page."
    ,cb

pivotal =

  getStory: (storyId, cb) ->
    if storyId? and storyId[0] is '#'
      storyId = storyId.substring(1)
    headers =
      'X-TrackerToken': config.pivotalToken or config.token
    options =
      host: 'www.pivotaltracker.com'
      path: "/services/v5/stories/#{storyId}"
      headers: headers
    data = ''
    https.get options, (res) ->
      res
      .on "data", (chunk) ->
        data += chunk + ''
      .on "end", (chunk) ->
        cb null, JSON.parse data
      .on "error", (error) ->
        cb error, null

git =

  checkoutTrackingBranch: (name, cb) ->
    createExec
      command: "git checkout -tb #{name}"
      successMessageFn: -> "Created and checked out branch '#{name}'."
    ,cb

  checkoutBranch: (name, cb) ->
    createExec
      command: "git checkout #{name}"
      successMessageFn: -> "Checked out branch '#{name}'."
    ,cb

  getTrackingBranch: (cb) ->
    log 'Getting tracking branch'
    createExec
      command: 'git rev-parse --abbrev-ref --symbolic-full-name @{u}'
      stdOutFn: (out) -> out.trim()
    ,cb

  getLastFilesCommitted: (cb) ->
    log 'Getting last files committed'
    createExec
      command: 'git log --name-only --pretty=format: -1'
      stdOutFn: (out) -> out.trim().split('\n').filter (name) -> name.length
    ,cb

  getCurrentRepo: (cb) ->
    log 'Getting current repo'
    createExec
      command: "git remote -vv | head -1 | cut -d'/' -f2 | cut -d'.' -f1"
      stdOutFn: (out) -> out.trim()
    ,cb

  getCurrentBranch: (cb) ->
    log 'Getting current branch'
    createExec
      command: 'git rev-parse --abbrev-ref HEAD'
      stdOutFn: (out) -> out.trim()
    ,cb

  getStatus: (cb) ->
    createExec
      command: 'git status'
      stdOutFn: (out) -> out.trim()
    ,cb

  addChanges: (cb) ->
    createExec
      command: "git add -A ."
      successMessageFn: -> "Added changes."
    ,cb

  commitChanges: (message, cb) ->
    log "Committing - #{message}"
    createExec
      command: "git commit -m \"#{message}\""
      successMessageFn: -> "Committed Changes."
    ,cb

  pushChanges: (head, cb) ->
    log "Pushing - #{head}"
    createExec
      command: "git push origin #{head}:#{head}"
      successMessageFn: -> "Pushed Changes."
    ,cb

  pullOrigin: (head, cb) ->
    log "Pulling - #{head}"
    createExec
      command: "git pull origin #{head}"
      successMessageFn: -> "Pulled Changes."
    ,cb

getPivotalStory = (id, cb) ->
  pivotal.getStory id, (err, story) ->
    if err
      log "Could not get pivotal story with id '#{id}'"
      cb err
    else
      cb null, story

pullRequestExists = (repo, ref, cb) ->
  github.pullRequests.getAll
    repo: repo
    user: config.githubOwner
    (err, pulls) ->
      if err
        cb err
      else
        cb null, ref in (pull.head.ref for pull in pulls)

getPivotalIdFromBranch = (name) ->
  temp = name.split '/'
  if temp.length > 1 then temp[1] else false

getTitleFromMessage = (message) ->
  lineIndex = message.indexOf '\n'
  if lineIndex isnt -1 then message.substring 0, lineIndex else message

convertToSlug = (text) -> text.trim().toLowerCase().replace(/[^\w ]+/g, '').replace RegExp(' +', 'g'), '-'

createBranch = (pivotalStoryId, subject, cb) ->
  getPivotalStory pivotalStoryId, (err, story) ->
    if err or story.error
      cb err or desc: story.error if cb
    else
      name = convertToSlug (subject or story.name).trim()
      git.checkoutTrackingBranch "#{story.story_type}/#{story.id}/#{name}", cb

buildCommitMessage = (id, message) -> "#{message}\n(#{id})"

buildPullRequestTitle = (id, message) -> "[##{id}] #{getTitleFromMessage message}"

getLocalInfo = (message, callback) ->
  async.parallel(
    (
      head: (cb) -> git.getCurrentBranch cb
      base: (cb) -> git.getTrackingBranch cb
    ),
    (err, prOptions) ->
      if err
        callback err
      else
        pivotalId = getPivotalIdFromBranch prOptions.head
        commitMessage = buildCommitMessage pivotalId, message
        prOptions.title = buildPullRequestTitle pivotalId, message
        prOptions.user = config.githubOwner
        callback null, prOptions, commitMessage, pivotalId
  )

createPullRequest = (options, cb) ->
  github.pullRequests.create options, (err, pr) ->
    if err
      log err.message
      cb err
    else
      log "Created Pull Request."
      cb null, pr

getHotspotsDir = () -> path.join(configDir, 'hotspots', crypto.createHash('md5').update(process.cwd()).digest('hex'))

getReview = (files, scoresByFile) ->
  fileScores = files.map (file) ->
    file: file
    score: scoresByFile[file] or 0
  fileScores.forEach (e) ->
    if e.score >= (config.reviewThresholdHigh or configTemplate.reviewThresholdHigh)
      e.color = 'red'
    else if e.score < (config.reviewThresholdMid or configTemplate.reviewThresholdMid)
      e.color = 'white'
    else
      e.color = 'yellow'
  fileScores.sort (a, b) -> b.score - a.score
  fileScores

printReview = (files, scoresByFile) ->
  console.log clc.underline('Code Review')
  getReview(files, scoresByFile).forEach (item) -> console.log clc[item.color]("#{item.file} (#{item.score})")

reviewFiles = (files, cb) ->
  try
    scoresByFile = require path.join(getHotspotsDir(), 'data.json')
    printReview files, scoresByFile
    cb null
  catch e
    saveHotspots (err) ->
      if err
        cb err
      else
        scoresByFile = require path.join(getHotspotsDir(), 'data.json')
        printReview files, scoresByFile
        cb null

deliverChanges = (message, local, shouldOpenPullRequest, callback) ->
  getLocalInfo message, (err, pr, commitMessage) ->
    if err
      callback err
    else if pr.base is 'master'
      callback new Error('You should not push directly to master.')
    else
      async.waterfall [
        ((cb) -> git.addChanges cb)
        ((res, cb) -> git.commitChanges commitMessage, cb)
        ((res, cb) -> git.getLastFilesCommitted cb)
        ((files, cb) ->
          if local
            callback()
          else unless config.enableFileReviewing
            cb()
          else
            reviewFiles files, cb
        )
        ((cb) ->
          if local
            callback()
          else
            git.pushChanges pr.head, cb
        )
        ((res, cb) -> git.getCurrentRepo cb)
        ((repo, cb) ->
          pr.repo = repo
          pullRequestExists pr.repo, pr.head, cb
        )
        ((exists, cb) ->
          if exists
            callback()
          else
            createPullRequest pr, cb
        )
        ((created, cb) ->
          if shouldOpenPullRequest
            openPullRequest pr.repo, created.number, (err) ->
              if err
                cb err
              else
                cb null
          else
            callback()
        )
      ], callback

getInputFromEditor = (cb) ->
  temp.open {suffix: '.txt'}, (err, info) ->
    if err
      cb err
    else
      editor = child.spawn config.editor or 'nano', [info.path], {stdio: 'inherit'}
      editor.on 'close', ->
        fs.readFile info.path, 'utf8', cb

saveHotspots = (cb) ->
  rl = readline.createInterface
    input: process.stdin
    output: process.stdout
  rl.question 'What pivotal project id should I use? ', (pivotalProject) ->
    rl.close()
    cwd = process.cwd()
    console.log 'Finding hotspots in project...'
    findHotspots (config.pivotalToken or config.token), pivotalProject, cwd, (err, data) ->
      if err
        cb err
      else
        hotspotsDir = getHotspotsDir()
        mkdirp.sync hotspotsDir
        fs.writeFile path.join(hotspotsDir, 'data.json'), JSON.stringify(data), (err) ->
          console.log 'Saved Hotspots' if not err
          cb err

# Auth libs
github.authenticate
  type: 'oauth',
  token: config.githubAccessToken

if process.argv.length <= 2
  options.help()

if options.reviewLastCommit
  git.getLastFilesCommitted (err, files) ->
    if err or files.length is 0
      console.log err or 'No files need review.'
    else
      reviewFiles files, (err) ->
        console.log 'Done.'

if options.findHotspots
  saveHotspots (err) ->
    console.log err if err

if options.create
  if not options.pivotalStoryId
    exitWithError 'Please specify a pivotal story id (--pivotal-story-id or -i).'
  else
    createBranch options.pivotalStoryId, options.subject, (err) ->
      exitWithError err if err

if options.update
  git.getCurrentBranch (err, head) ->
    if err
      exitWithError 'Could not get HEAD'
    else
      git.pullOrigin head, (err) ->
        if err then exitWithError err

if options.deliver
  if not options.message
    getInputFromEditor (err, message) ->
      if not err then deliverChanges message, false, options.open, (err) ->
        exitWithError err if err
  else
      deliverChanges options.message, false, options.open, (err) ->
        exitWithError err if err

module.exports.git = git
module.exports.pivotal = pivotal
module.exports.createBranch = createBranch
module.exports.pullRequestExists = pullRequestExists
module.exports.getTitleFromMessage = getTitleFromMessage
module.exports.getPivotalIdFromBranch = getPivotalIdFromBranch
module.exports.convertToSlug = convertToSlug
module.exports.buildCommitMessage = buildCommitMessage
module.exports.buildPullRequestTitle = buildPullRequestTitle
module.exports.getLocalInfo = getLocalInfo
module.exports.deliverChanges = deliverChanges
module.exports.getHotspotsDir = getHotspotsDir
module.exports.getReview = getReview
