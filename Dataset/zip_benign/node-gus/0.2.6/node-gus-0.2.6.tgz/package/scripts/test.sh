#!/bin/sh
rm -f -R test-temp;
mkdir test-temp;
cd test-temp;
git init;
echo 'First!' >> hello.txt;
git add .;
git commit -m 'initial';
echo 'Hello World!' >> hello.txt;
mocha ../test;
