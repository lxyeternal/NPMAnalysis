#!/bin/sh

mkdir -p bin
rm -f bin/gus
echo '#!/usr/bin/env node' > bin/gus
cat build/index.js >> bin/gus
chmod 755 bin/gus
