var fs = require("fs");
var gus = require(__dirname + "/../bin/gus");
var path = require("path");
var assert = require("assert");

describe("gus |", function() {

    describe("hotspots | ", function() {

        it("should get directory", function(done) {
            var dir = gus.getHotspotsDir();
            assert.equal(dir.substring(dir.indexOf('hotspots')), 'hotspots/5ff8a7ca1feaa2c14441afab35f702ab');
            done();
        });

        it("should get reviews", function(done) {
            var data = {};
            data['a/b.js'] = 0.9;
            data['c.html'] = 0.2;
            var review = gus.getReview(['a/b.js', 'c.html', 'd.css'], data);
            assert.equal(review[0].color, 'red');
            assert.equal(review[1].color, 'yellow');
            assert.equal(review[2].color, 'white');
            done();
        });

    });

    describe("create |", function() {

        it("should identify current branch", function(done) {
            gus.git.getCurrentBranch(function(err, name) {
                assert.equal(name, "master");
                done();
            });
        });

        it("should create tracking branch with custom subject", function(done) {
            gus.createBranch("65499790", "hello world", function(err) {
                assert(!err);
                gus.git.getCurrentBranch(function(err, name) {
                    assert.equal(name, "feature/65499790/hello-world");
                    done();
                });
            });
        });

        it("should create tracking branch from pivotal story", function(done) {
            gus.createBranch("65499790", null, function(err) {
                assert(!err);
                gus.git.getCurrentBranch(function(err, name) {
                    assert.equal(name, "feature/65499790/responsive-product");
                    done();
                });
            });
        });

        it("should try to create tracking branch from pivotal id with hash", function(done) {
            gus.createBranch("#65499790", null, function(err) {
              assert(err.message.trim().indexOf("A branch named 'feature/65499790/responsive-product' already exists") !== -1);
              done();
            });
        });

        it("should not create a tracking branch if one exists", function(done) {
            gus.createBranch("65499790", null, function(err) {
                assert(err.message.trim().indexOf("A branch named 'feature/65499790/responsive-product' already exists") !== -1);
                done();
            });
        });

        it("should not create a tracking branch if pivotal story doesn't exist", function(done) {
            gus.createBranch("123456789", null, function(err) {
                assert.equal(err.desc, "The object you tried to access could not be found.  It may have been removed by another user, you may be using the ID of another object type, or you may be trying to access a sub-resource at the wrong point in a tree.");
                done();
            });
        });

    });

    describe("deliver |", function() {

        var id, message = "Hello world!";

        it("should get pivotal id from branch name", function(done) {
            gus.git.getCurrentBranch(function(err, name) {
                assert.equal(name, "feature/65499790/responsive-product");
                id = gus.getPivotalIdFromBranch(name);
                assert.equal(id, "65499790");
                done();
            });
        });

        it("should get repo from git", function(done) {
            gus.git.getCurrentRepo(function(err, name) {
                assert.equal(name, "");
                done();
            });
        });

        it("should build commit message", function() {
            message = gus.buildCommitMessage(id, message);
            assert.equal(message, "Hello world!\n(65499790)");
        });

        it("should build pull request title properly", function() {
            assert.equal("[#65499790] Hello world!", gus.buildPullRequestTitle('65499790', "Hello world!\nSomething else"));
        });

        it("should get tracking branch", function(done) {
            gus.git.getTrackingBranch(function(err, name) {
                assert.equal(name, "feature/65499790/hello-world");
                done();
            });
        });

        it("should add/commit with deliver", function(done) {
            gus.deliverChanges("fine", true, false, function(err) {
                assert(!err);
                gus.git.getStatus(function(err, status) {
                    assert(status.indexOf("Your branch is ahead of 'feature/65499790/hello-world' by 1 commit.") !== -1);
                    gus.git.getLastFilesCommitted(function(err, files) {
                        assert.equal(files.length, 1);
                        assert.equal(files[0], 'hello.txt');
                        done();
                    });
                });
            });
        });

        it("should check if pull request exists", function(done) {
            gus.pullRequestExists("web", "feature/65499790/hello-world", function(err, there) {
                assert(!there);
                done();
            });
        });

        it("should build pull request options properly", function(done) {
            gus.getLocalInfo("Hello World\nThis is a test message.", function(err, options, message, id) {
                var opts = {
                    "head": "feature/65499790/responsive-product",
                    "base": "feature/65499790/hello-world",
                    "title": "[#65499790] Hello World",
                    "user": "the-container-store"
                };
                assert.equal(JSON.stringify(opts), JSON.stringify(options));
                assert.equal("Hello World\nThis is a test message.\n(65499790)", message);
                assert.equal(65499790, id);
                done();
            });
        });

        it("should not push to master", function(done) {
            gus.git.checkoutBranch("master", function (err1) {
              assert(!err1);
              gus.git.checkoutTrackingBranch("from-master", function (err2) {
                assert(!err2);
                fs.appendFile("../test-temp/goodbye.txt", "bye", function (err3) {
                  assert(!err3);
                  gus.deliverChanges("going to master", true, false, function(err) {
                    assert.equal(err.message, "You should not push directly to master.");
                    done();
                  });
                });
              });
            });
        });

        it("should get title from message", function() {
            assert.equal("Hello world!", gus.getTitleFromMessage(message));
            assert.equal("Hello World", gus.getTitleFromMessage("Hello World\nThis is a test message.\nAnother one."));
        });

        it("should convert a title to slug", function() {
            assert.equal("hello-world-foo-bar", gus.convertToSlug("Hello WORLD! Foo Bar    "));
        });

        it("should iterate over object keys in insertion order", function() {
            var obj = {
                currentBranch: "hello",
                trackingBranch: "goodbye",
                added: true,
                committed: false,
                pushed: true
            };
            assert.equal(Object.keys(obj).toString(), "currentBranch,trackingBranch,added,committed,pushed");
        });

    });

});
