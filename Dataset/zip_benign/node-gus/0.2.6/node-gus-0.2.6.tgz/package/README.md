# GUS
### The Git Usability Service

[![NPM Version](https://img.shields.io/npm/v/node-gus.svg)](https://www.npmjs.com/package/node-gus)

![](http://37.media.tumblr.com/tumblr_lkg9nuYK6e1qhigt0o1_r1_400.gif)

## How to Install

#### From npm (easy)

- Use this to update also
```
sudo npm install -g node-gus
```

#### Build yourself (if you will make changes)
```
git clone git@github.com:the-container-store/gus.git
cd gus
sudo npm install -g
```

## Required config.json file

- Now in your ~/.gus directory
- Note you can change your default message editor

```
{
	"pivotalToken": "<token>",
	"githubAccessToken": "<token>",
	"githubOwner": "<owner>",
	"editor": "vim",
	"reviewThresholdHigh": 0.5,
	"reviewThresholdMid": 0.1
}
```

## How to use

### Create and Checkout Pivotal Story Branch

```
gus -c -i 643456
```

* You can use ```-s``` to customize a branch subject. ```feature/12345/<subject>```

### Add/Commit/Push Changes and Create/Update Pull Request

- Multiline messages are allowed
- First line is title
- Omit ```-m``` option to use default editor
- Use ```-o``` option to open pull request in default web browser after creation
- Use ```-v``` option for verbose output

```
gus -p -m 'Title\n extra message here'
```

### *New* Code Review Feature

When you committ changes, GUS will find the hotspots (buggy areas) in your codebase and analyze your changes against the results. GUS will list out your changed files color coded by code review danger level. Red being dangerous and in need of multiple code reviews and white being not dangerous. You can configure the thresholds in the config file.
