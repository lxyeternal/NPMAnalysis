# @esm-pack/color-string

> library for parsing and generating CSS color strings.

## Install

```sh
npm install @esm-pack/color-string
```

## Usage

### Parsing

```js
import { getColor, getRGB, getHSL, getHWB } from "@esm-pack/color-string";

getColor('#FFF')                          // {model: 'rgb', value: [255, 255, 255, 1]}
getColor('#FFFA')                         // {model: 'rgb', value: [255, 255, 255, 0.67]}
getColor('#FFFFFFAA')                     // {model: 'rgb', value: [255, 255, 255, 0.67]}
getColor('hsl(360, 100%, 50%)')         // {model: 'hsl', value: [0, 100, 50, 1]}
getColor('hsl(360 100% 50%)')             // {model: 'hsl', value: [0, 100, 50, 1]}
getColor('hwb(60, 3%, 60%)')              // {model: 'hwb', value: [60, 3, 60, 1]}

getRGB('#FFF')                      // [255, 255, 255, 1]
getRGB('blue')                      // [0, 0, 255, 1]
getRGB('rgba(200, 60, 60, 0.3)')  // [200, 60, 60, 0.3]
getRGB('rgba(200 60 60 / 0.3)')     // [200, 60, 60, 0.3]
getRGB('rgba(200 60 60 / 30%)')     // [200, 60, 60, 0.3]
getRGB('rgb(200, 200, 200)')      // [200, 200, 200, 1]
getRGB('rgb(200 200 200)')          // [200, 200, 200, 1]

getHSL('hsl(360, 100%, 50%)')       // [0, 100, 50, 1]
getHSL('hsl(360 100% 50%)')           // [0, 100, 50, 1]
getHSL('hsla(360, 60%, 50%, 0.4)')  // [0, 60, 50, 0.4]
getHSL('hsl(360 60% 50% / 0.4)')      // [0, 60, 50, 0.4]

getHWB('hwb(60, 3%, 60%)')          // [60, 3, 60, 1]
getHWB('hwb(60, 3%, 60%, 0.6)')     // [60, 3, 60, 0.6]

getRGB('invalid color string')      // null
```

### Generation

```js
import { toHEX, toRGB, toRGBPercent, toHSL, toHWB } from "@esm-pack/color-string";

toHEX(255, 255, 255)     // "#FFFFFF"
toHEX(0, 0, 255, 0.4)    // "#0000FF66"
toHEX(0, 0, 255, 0.4)    // "#0000FF66"
toRGB(255, 255, 255)     // "rgb(255, 255, 255)"
toRGB(0, 0, 255, 0.4)    // "rgba(0, 0, 255, 0.4)"
toRGB(0, 0, 255, 0.4)    // "rgba(0, 0, 255, 0.4)"
toRGBPercent(0, 0, 255)  // "rgb(0%, 0%, 100%)"
toHSL(360, 100, 100)     // "hsl(360, 100%, 100%)"
toHWB(50, 3, 15)         // "hwb(50, 3%, 15%)"
```

## License

MIT
