(function() {
  // Nothing to do
})