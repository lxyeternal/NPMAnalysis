/**
 * Copyright (c) 2019-2023, Cloudless Consulting Pty Ltd.
 * All rights reserved.
 * 
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
*/

import { dot, transpose, inverseDiag, isIdentity, isUpperTriangular, apply, isZero, add, min } from '../matrix/utils.mjs'

export { default as backward } from './backward.mjs'
export { default as det } from './det.mjs'
export { default as inverse } from './inverse.mjs'
export { default as lu } from './lu.mjs'
export { default as qr } from './qr.mjs'
export { default as rank } from './rank.mjs'
export { default as svd } from './svd.mjs'
export const matrix = { dot, transpose, inverseDiag, isIdentity, isUpperTriangular, apply, isZero, add, min }
export { dot, transpose, inverseDiag, isIdentity, isUpperTriangular, apply, isZero, add, min }