import svd from './src/linalg/svd.mjs'

const fy = x => 4*x**2 + 5*x + 2

const Xs = [-2,-1,0,0.5,1]
const points = Xs.map(x => ({ x,y:fy(x) }))

const A = points.map(({ x,y }) => ([x,y]))

const [U,V,S] = svd(A)

console.log('U')
console.log(U)
console.log('V')
console.log(V)
console.log('S')
console.log(S)