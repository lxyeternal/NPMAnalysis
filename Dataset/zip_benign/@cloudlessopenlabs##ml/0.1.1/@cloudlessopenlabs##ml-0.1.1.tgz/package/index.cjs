const interpol = require('./dist/interpolation/index.cjs')

console.log(interpol)
console.log(interpol['3d'].bilinear)