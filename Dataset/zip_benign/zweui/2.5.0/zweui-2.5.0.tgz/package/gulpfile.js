var path = require('path');
var fs = require('fs');
var gulp = require('gulp');
var less = require('gulp-less');
var header = require('gulp-header');
var tap = require('gulp-tap');
var nano = require('gulp-cssnano');
var postcss = require('gulp-postcss');
var autoprefixer = require('autoprefixer');
var comments = require('postcss-discard-comments');
var rename = require('gulp-rename');
var sourcemaps = require('gulp-sourcemaps');
var browserSync = require('browser-sync');
var childProcess = require('child_process');
var pkg = require('./package.json');
var convertCssVar = require('gulp-convert-css-var');
var exec = require('child_process').exec;

var yargs = require('yargs').options({
    w: {
        alias: 'watch',
        type: 'boolean',
    },
    s: {
        alias: 'server',
        type: 'boolean',
    },
    p: {
        alias: 'port',
        type: 'number',
    },
}).argv;

var option = { base: 'src' };
var dist = __dirname + '/dist';

function exec(cmd) {
    return new Promise((resolve, reject) => {
        const process = childProcess.exec(cmd, (error) => {
            if (error) {
                reject(error);
            } else {
                resolve();
            }
        });
        process.stdout.on('data', function (data) {
            console.log(data);
        });
    });
}


function build_style(done) {
    var banner = [
        '/*!',
        ' * WeUI v<%= pkg.version %> (<%= pkg.homepage %>)',
        ' * Copyright <%= new Date().getFullYear() %> Tencent, Inc.',
        ' * Licensed under the <%= pkg.license %> license',
        ' */',
        '',
    ].join('\n');
    gulp
        .src('src/style/weui.less', option)
        .pipe(sourcemaps.init())
        .pipe(
            less().on('error', function (e) {
                console.error(e.message);
                this.emit('end');
            }),
        )
        .pipe(postcss([autoprefixer(['iOS >= 7', 'Android >= 4.1']), comments()]))
        .pipe(convertCssVar())
        .pipe(header(banner, {pkg: pkg}))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}))
        .pipe(
            nano({
                zindex: false,
                autoprefixer: false,
                svgo: false,
            }),
        )
        .pipe(
            rename(function (path) {
                path.basename += '.min';
            }),
        )
        .pipe(gulp.dest(dist));
    done();
}

function build_example_assets(done) {
    gulp
        .src('src/example/**/*.?(png|jpg|gif|js)', option)
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}));
    done();
}

function build_example_style(done) {
    gulp
        .src('src/example/example.less', option)
        .pipe(
            less().on('error', function (e) {
                console.error(e.message);
                this.emit('end');
            }),
        )
        .pipe(postcss([autoprefixer(['iOS >= 7', 'Android >= 4.1'])]))
        .pipe(
            nano({
                zindex: false,
                autoprefixer: false,
            }),
        )
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}));
    done();
}

function build_example_html(done) {
    gulp
        .src('src/example/index.html', option)
        .pipe(
            tap(function (file) {
                var dir = path.dirname(file.path);
                var contents = file.contents.toString();
                contents = contents.replace(
                    /<link\s+rel="import"\s+href="(.*)">/gi,
                    function (match, $1) {
                        var filename = path.join(dir, $1);
                        var id = path.basename(filename, '.html');
                        var content = fs.readFileSync(filename, 'utf-8');
                        return (
                            '<script type="text/html" id="tpl_' +
                            id +
                            '">\n' +
                            content +
                            '\n</script>'
                        );
                    },
                );
                file.contents = new Buffer(contents);
            }),
        )
        .pipe(gulp.dest(dist))
        .pipe(browserSync.reload({stream: true}));
    done();
}

gulp.task("build", gulp.series(build_style, build_example_assets, build_example_html, build_example_style));

gulp.task("watch", gulp.series(build_example_html, build_example_style, build_example_assets, function () {
    var list = [
        {
            path: 'src/style/**/*',
            task: build_style,
        },
        {
            path: 'src/example/example.less',
            task: build_example_style,
        },
        {
            path: 'src/example/**/*.?(png|jpg|gif|js)',
            task: build_example_assets,
        },
        {
            path: 'src/**/*.html',
            task: build_example_html,
        },
    ];
    list.forEach((item) => {
        var timeout = null;
        gulp.watch(path.resolve(__dirname, item.path)).on('change', function () {
            clearTimeout(timeout);

            timeout = setTimeout(() => {
                item.task(function () {
                });
            }, 300);
        });
    });
}));


function watch(done) {
    var watcher = gulp.watch([
            paths.src.img,
            paths.src.svg,
            paths.src.slice,
            paths.src.js,
            paths.src.media,
            paths.src.lessAll,
            paths.src.sassAll,
            paths.src.htmlAll
        ],
        {ignored: /[\/\\]\./}
    );

    watcher
        .on('change', function (file) {
            util.log(file + ' has been changed');
            watchHandler('changed', file);
        })
        .on('add', function (file) {
            util.log(file + ' has been added');
            watchHandler('add', file);
        })
        .on('unlink', function (file) {
            util.log(file + ' is deleted');
            watchHandler('removed', file);
        });

    done();
}



//启动 livereload
function startServer() {
    bs.init({
        server: "./dist/example",
        port: config['livereload']['port'] || 8080,
        startPath: config['livereload']['startPath'] || '/',
        reloadDelay: 0,
        notify: {      //自定制livereload 提醒条
            styles: [
                "margin: 0",
                "padding: 5PX",
                "position: fixed",
                "font-size: 10PX",
                "z-index: 9999",
                "bottom: 0PX",
                "right: 0PX",
                "border-radius: 0",
                "border-top-left-radius: 5PX",
                "background-color: rgba(60,197,31,0.5)",
                "color: white",
                "text-align: center"
            ]
        }
    });
}

gulp.task('server', function () {
    yargs.p = yargs.p || 8080;
    browserSync.init({
        server: {
            baseDir: './dist',
        },
        ui: {
            port: yargs.p + 1,
            weinre: {
                port: yargs.p + 2,
            },
        },
        port: yargs.p,
        startPath: '/example',
    });
});

gulp.task('tag', function () {
    const tag = `v${pkg.version}`;
    exec(`git tag ${tag}`);
});

// 参数说明
//  -w: 实时监听
//  -s: 启动服务器
//  -p: 服务器启动端口，默认8080
gulp.task("default", gulp.parallel(gulp.series(build_style, build_example_assets, build_example_html, build_example_style), "watch", "server"));

