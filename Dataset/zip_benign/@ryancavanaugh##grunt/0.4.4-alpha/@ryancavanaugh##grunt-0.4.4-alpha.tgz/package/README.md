# Installation
> `npm install --save-dev @ryancavanaugh/grunt`

# Summary
This package contains type definitions for Grunt 0.4.x.

The project URL or description is http://gruntjs.com

# Credits

These definitions were written by Jeff May <https://github.com/jeffmay/>, Basarat Ali Syed <https://github.com/basarat/>.

# Details
Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the grunt directory.

Additional Details
 * Last updated: Tue, 17 May 2016 00:18:15 GMT
 * Typings kind: Mixed
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: grunt
