export declare class DoubleLinkedList<ItemT> {
    /** This is set to `undefined` on any list mutations and rebuilt when `toArray` is called if needed */
    private allValues;
    private firstNode;
    private lastNode;
    private length;
    constructor(...items: ItemT[]);
    readonly getLength: () => number;
    readonly isEmpty: () => boolean;
    readonly append: (item: ItemT) => Readonly<DoubleLinkedListNode<ItemT>>;
    readonly prepend: (item: ItemT) => Readonly<DoubleLinkedListNode<ItemT>>;
    readonly clear: () => void;
    readonly getHead: () => Readonly<DoubleLinkedListNode<ItemT>> | undefined;
    readonly getTail: () => Readonly<DoubleLinkedListNode<ItemT>> | undefined;
    readonly toArray: () => Readonly<ItemT[]>;
    readonly remove: (node: DoubleLinkedListNode<ItemT>) => boolean;
    readonly insertAfterNode: (node: DoubleLinkedListNode<ItemT>, item: ItemT) => Readonly<DoubleLinkedListNode<ItemT>> | undefined;
    readonly insertBeforeNode: (node: DoubleLinkedListNode<ItemT>, item: ItemT) => Readonly<DoubleLinkedListNode<ItemT>> | undefined;
}
export declare class DoubleLinkedListNode<ItemT> {
    list: DoubleLinkedList<ItemT> | undefined;
    readonly value: ItemT;
    previousNode?: DoubleLinkedListNode<ItemT> | undefined;
    nextNode?: DoubleLinkedListNode<ItemT> | undefined;
    constructor(list: DoubleLinkedList<ItemT> | undefined, value: ItemT, previousNode?: DoubleLinkedListNode<ItemT> | undefined, nextNode?: DoubleLinkedListNode<ItemT> | undefined);
}
//# sourceMappingURL=index.d.ts.map