# kfc

# 游戏

##### 安装

```
npm install game-kfc
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-kfc/kfc"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: JSON.stringify({
      baseOps: {
        speed: { min: 5, max: 15, step: 0.01 },//移动速度
        firstY: 200,//首次加载游戏第一个元素的底部坐标位置
        intervalStep: 1,//两个物体之间的间隔递减值
        intervalStepH: 50,//移动指定距离递减一次
        minIntervalH: 300,//两个物体之间的最小间隔距离
        maxIntervalH: 500,//两个物体之间的间隔距离
      },
      minY: 200,//顶点y轴坐标
      minYnumOffset: 720,//从底部开始计算距离，如果有设置此参数，minY不生效
      minScale: 0.4,//顶点坐标缩放比例
      noAutoRenderBlock: true,//不自动渲染能量，需要手动调用
      sky: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01wRqskp1FJvdrxWhjf_!!1080040467.png", width: 750, height: 1047 },
      energy: [
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN018k4XXj1FJve0GsgPO_!!1080040467.png", width: 200, height: 185, probability: 1, val: 50, ftype: "energy", },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Ae3sfV1FJve15lKd2_!!1080040467.png", width: 200, height: 170, probability: 1, val: 50, ftype: "energy", },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01N49i9l1FJvdy4BUY8_!!1080040467.png", bound: { left: 90, right: 90, bottom: 30, top: 100 }, width: 200, height: 214, probability: 2, val: -10, ftype: "barrier", },
      ],
      playerInfo: {
        src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01YdJNpu1FJvdqKoGuP_!!1080040467.png", width: 109, height: 213, x: 750 / 2, offsetBottom: 280,//offsetBottom:从底部为起点开始计算位置
      },
      bucket: {
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01DdrQqG1FJvdzU8AUC_!!1080040467.png",
        width: 300,
        height: 470,
        x: 750 / 2,
        offsetBottom: 1080,
        animation: {
          step: 20,//桶动画，上下移动的距离
          time: 2,//移动时间
        },
        drop: {
          scale: { x: 0.4, y: 0.4 },
          height: 400, //鸡块抛出h后终点位置高度
          time: 1,//抛出时间
          delayTime: 0.5,//抛出一个之后，下一个鸡块延迟时间
        }
      },
      timePos: {
        align: "left",
        x: 20,
        y: 10,
        time: 20,//倒计时时间
        // 时间数字图片 0 - 9
        before: { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tCqjHA1FJvdzU6xZg_!!1080040467.png", width: 147, height: 52 },
        numOffset: -10,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bubGmn1FJvdxLuRaj_!!1080040467.png", "width": "21", "height": "52", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Py4MSA1FJvdv0Du6S_!!1080040467.png", "width": "7", "height": "52", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DRvX2d1FJvdzU6QHO_!!1080040467.png", "width": "21", "height": "52", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01qRhJhq1FJvdxLvJes_!!1080040467.png", "width": "22", "height": "52", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Z8qVEu1FJvdy1dGkt_!!1080040467.png", "width": "25", "height": "52", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VUvFID1FJvdsMS99K_!!1080040467.png", "width": "22", "height": "52", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01A5yK8K1FJvdsrNRSo_!!1080040467.png", "width": "21", "height": "52", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015xYfUO1FJvdsLcWbF_!!1080040467.png", "width": "18", "height": "52", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ulLTFh1FJvdjhWkDS_!!1080040467.png", "width": "21", "height": "52", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01C4VeeR1FJvdsMRH53_!!1080040467.png", "width": "21", "height": "52", val: 9 },
        ],
      },
      tipScorePos: {
        align: "center",
        fadeTime: 0.5,//消失时间
        x: 750 / 2,
        y: 500,
        offsetBottom: 500,
        numOffset: -10,//数字两边空白太多，增加偏移量
        numArr: [
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Iy6QUO1FJve1j09HG_!!1080040467.png", width: 20, height: 52, val: "+" },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0139Z45E1FJvdvoUCue_!!1080040467.png", width: 26, height: 52, val: "-" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01iRV0iM1FJvdjhmBgn_!!1080040467.png", "width": "30", "height": "52", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dTBzlc1FJvdzUPM1U_!!1080040467.png", "width": "22", "height": "52", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01s15kV61FJvdv0WIbX_!!1080040467.png", "width": "33", "height": "52", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PNfAgY1FJvdoPKWZO_!!1080040467.png", "width": "33", "height": "52", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Qi0Og31FJvdjhmK04_!!1080040467.png", "width": "32", "height": "52", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cWUbwH1FJvdzUOsup_!!1080040467.png", "width": "32", "height": "52", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01YTJovr1FJvdoPMKoy_!!1080040467.png", "width": "33", "height": "52", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EOvUkl1FJvdwJmsKV_!!1080040467.png", "width": "28", "height": "52", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01iL8XnH1FJvdy1xTav_!!1080040467.png", "width": "31", "height": "52", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01o4Jo6D1FJvdtqSIeN_!!1080040467.png", "width": "33", "height": "52", val: 9 },
        ],
      },
      scorePos: {
        align: "right",
        x: 736,
        y: 10,
        // 分数数字图片 0 - 9
        before: { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Ox2Ti81FJvdtqSll1_!!1080040467.png", width: 153, height: 52 },
        numOffset: -10,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01iRV0iM1FJvdjhmBgn_!!1080040467.png", "width": "30", "height": "52", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dTBzlc1FJvdzUPM1U_!!1080040467.png", "width": "22", "height": "52", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01s15kV61FJvdv0WIbX_!!1080040467.png", "width": "33", "height": "52", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PNfAgY1FJvdoPKWZO_!!1080040467.png", "width": "33", "height": "52", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Qi0Og31FJvdjhmK04_!!1080040467.png", "width": "32", "height": "52", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cWUbwH1FJvdzUOsup_!!1080040467.png", "width": "32", "height": "52", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01YTJovr1FJvdoPMKoy_!!1080040467.png", "width": "33", "height": "52", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EOvUkl1FJvdwJmsKV_!!1080040467.png", "width": "28", "height": "52", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01iL8XnH1FJvdy1xTav_!!1080040467.png", "width": "31", "height": "52", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01o4Jo6D1FJvdtqSIeN_!!1080040467.png", "width": "33", "height": "52", val: 9 },
        ],
      },
      bgLoad: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ZOSRfE1FJvdx8AR7T_!!1080040467.png", width: 750, height: 744 },
      loadAniBg: {
        width: 55,
        height: 1350,
        boomSpeed: 0.2,//速度
        offsetBottom: -500,
        anchor: { x: 0, y: 1 },
        x: 346,
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01IlyB0p1FJvdyAV5sp_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01XHCLMg1FJvdwe3h5c_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ALCxhF1FJvdx7smVS_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ctZqAv1FJvdvnuELe_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01vIlCid1FJvdyq2drQ_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016kVg2B1FJvdvnvZUw_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017BrLRe1FJve0IfnWg_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01VgP1im1FJvdtfUHtD_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01qUb2iI1FJvdqcX7nN_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01uiOs1b1FJvdqcbU7e_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Rhie9D1FJvdtfV5me_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01uUK00Q1FJvdyq3eCi_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01TOTaEA1FJvduNye11_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01dxBTpu1FJvdx7uexR_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01SsKAM51FJvdqcawrW_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN014aLVxu1FJve0IfSlZ_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pKnyA61FJvduO1vkC_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01bHtaI91FJvdr8xnnT_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01stEF8Y1FJve0IhsPr_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01lOKrbc1FJvdqcYw73_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0176DGqE1FJvdtAAYZP_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tzNzhg1FJvdtfU5P9_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01p6hqiE1FJvdtAToxx_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NG1SJf1FJvdueFg4K_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Wsrgvw1FJvdr8yCj3_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN019ThUt41FJvdvnvAYt_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RMU7pL1FJvdtfRsAE_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GPhD261FJvdyq2VZp_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01MfjTDG1FJvdqcZsMM_!!1080040467.png", "width": "55", "height": "1350" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01K0p3jX1FJve0IfKTP_!!1080040467.png", "width": "55", "height": "1350" },
        ]
      },
      leftBg: {
        width: 400,
        height: 900,
        boomSpeed: 0.2,
        anchor: { x: 0, y: 1 },
        x: 0,
        offsetBottom: 328,
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NcgKBL1FJvdqcb9M7_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yuV9ox1FJvdpD9dwU_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01n7yF8D1FJvduO0zZn_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01If0QlL1FJvdtfS0VI_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ByyWN51FJvdtfTPt8_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01HCXs1s1FJvdr8zgCD_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01F0cKeM1FJvdwe3taC_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN019JJeNZ1FJvdyATowj_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01UgbmcX1FJvdtfRsBH_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015Mswg61FJvdtfVxt3_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01oLum5C1FJvdpD8q3T_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011GSVqY1FJvdr8wjGf_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01N34knc1FJvdtAX2aw_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GxFf9Q1FJvdwe52GR_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN0137ui4F1FJve0Igfce_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ST6mqm1FJve0Ig8Mp_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ngx51H1FJvdyq2ZkC_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tFG2eB1FJvdzfLbbx_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PJ7wpb1FJvdpDBzWp_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01azpfuc1FJvdueG0se_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01MhhnH91FJvdr8zXuy_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jRGm3p1FJvdkVX8zB_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wI3fit1FJve0IgXL5_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011TWIRH1FJvdr8yftI_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Wtja1z1FJvdvnvRFV_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01H1Ytuo1FJvdx7w8TZ_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01VwRMFM1FJvdkVU3hM_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BJpOZG1FJvduO28KM_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ppYges1FJvdpDC3hs_!!1080040467.png", "width": "400", "height": "900" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AD79Lb1FJvdvnuhXK_!!1080040467.png", "width": "400", "height": "900" },
        ]
      },
      rightBg: {
        width: 400,
        height: 950,
        boomSpeed: 0.2,
        anchor: { x: 0, y: 1 },
        x: 350,
        offsetBottom: 302,
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01E8Rvn51FJvdvntMEz_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01snG8IX1FJvduO1BxA_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN017568Up1FJvdtATU5A_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BeAAdp1FJvdtAAHux_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01kpMqlL1FJvdx7rN8w_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01bycZtx1FJvdvnudFm_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01YYMu5M1FJvdwe217i_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01HPl5Ap1FJvdwe2Lsy_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01dkGtIF1FJvdx7unDY_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vlqYTC1FJvdx7tqzx_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019Y3unh1FJvdtAVlV5_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01qKzDTO1FJvdtATLmm_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01pkfVl41FJvdkVUf1Z_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012eVEEL1FJvdx7sVpc_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ukiELc1FJvdqcac36_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jr8TL31FJvdtARL1l_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01XrBB9Z1FJvdqcYX74_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016lDwT41FJvdtfT9A6_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Vz5ppn1FJvdkVW4Lp_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ktfsYu1FJvdr8xCHy_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01QXKpeV1FJvdpD8IlH_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01buwHNu1FJvdr8vJqU_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Pd9PLZ1FJve0IffCd_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ty82IW1FJvdx7uevb_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GJPclP1FJvduNyAs7_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PaHnOP1FJvdtfRwKk_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01peDd3C1FJve0IdW69_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01hCVY2O1FJvdzfIBRr_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01O0dDTt1FJvdvnuAC5_!!1080040467.png", "width": "400", "height": "950" },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01O6hrs91FJvdzfHeCZ_!!1080040467.png", "width": "400", "height": "950" },
        ]
      }
    })
  },
  onLoad(query) {
  },
  onError(e) {
    console.log("错误：", e)
  },

  playFun() {
    this.gameComponent.onEvent("start", { maxScore: 618 });
  },
  resetFun() {
    this.gameComponent.onEvent("reset");
  },
  addFun() {
    this.gameComponent.onEvent("renderBlock");
  },
  addFun1() {
    this.gameComponent.onEvent("renderBlock", { ftype: "barrier", col: 1 });
  },
  overFun() {
    this.gameComponent.onEvent("gameOver");
  },
  diuFun() {
    // 丢鸡块
    this.gameComponent.onEvent("dropChickenFun");
  },

  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // this.playFun();
  },
  onUpdate(ops) {
    // { totalScore: 0, imgObj: { } }
    console.log(ops)
  },
  onGameOver(totalScore) {
    console.log(totalScore)
  }
})
```

- xaml

```
  <view class="pageBox">
    <game gameSource="{{gameSource}}" 
      onRef="onRef"
      onInitDone="onInitDone" 
      onUpdate="onUpdate" 
      onGameOver="onGameOver"
      />
  </view>

  <view onTap="addFun" style="position:absolute;left: 20%;bottom: 100rpx;">添加能量</view>
  <view onTap="playFun" style="position:absolute;left: 40%;bottom: 100rpx;">开始</view>
  <view onTap="overFun" style="position:absolute;left: 40%;bottom: 50rpx;">结束</view>
  <view onTap="resetFun" style="position:absolute;left: 50%;bottom: 100rpx;">重置</view>
  <view onTap="diuFun" style="position:absolute;left: 50%;bottom: 50rpx;">丢鸡块</view>
  <view onTap="addFun1" style="position:absolute;left: 60%;bottom: 100rpx;">添加障碍物</view>
```