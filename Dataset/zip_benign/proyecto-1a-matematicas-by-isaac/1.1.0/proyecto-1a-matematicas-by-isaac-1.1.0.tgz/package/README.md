# Operaciones matemáticas

Módulo para realizar operaciones matemáticas simples.

## Instalación
Seguir estas instrucciones.

```
npm i proyecto-1a-matematicas-by-isaac
```

# Uso
Seguir estas instrucciones.

```
// Importar el módulo
const m = require('.');

// Sumas

console.log(m.suma(1,2)); => 3
console.log(m.suma(8,2)); => 10
console.log(m.suma(1,3)); => 4
console.log(m.suma(5,2)); => 7
console.log(m.suma(1,1)); => 2

// Restas

console.log(m.resta(1,2)); => -1
console.log(m.resta(8,2)); => 6
console.log(m.resta(1,3)); => -2
console.log(m.resta(5,2)); => -3
console.log(m.resta(1,1)); => 0

// Multiplicación

console.log(m.multiplicacion(1,2)); => 3
console.log(m.multiplicacion(8,2)); => 16
console.log(m.multiplicacion(1,3)); => 3
console.log(m.multiplicacion(5,2)); => 10
console.log(m.multiplicacion(1,1)); => 1

// Division

console.log(m.division(1,2)); => 0.5
console.log(m.division(8,2)); => 4
console.log(m.division(1,3)); => 0.333
console.log(m.division(5,2)); => 2.5
console.log(m.division(1,1)); => 0
```

