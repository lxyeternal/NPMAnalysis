const m = require('.');

console.log(m.suma(3,2));
console.log(m.suma(8,2));
console.log(m.suma(1,3));
console.log(m.suma(5,2));
console.log(m.suma(4,1));
console.log(m.division(0,0));