module.exports = {
    
    /**
     * suma de dos números
     * @example
     * n1 = 1, n2 = 6 => resultado = 7
     * @param {*} n1 primer dígito de suma
     * @param {*} n2 segundo dígito de suma
     */
    suma: function(n1, n2) {
        return this._esNumero(n1, n2)? (n1 + n2): this._mensajeError();
    },
    /**
     * resta de dos números
     * @example
     * n1 = 1, n2 = 4 => resultado = -3
     * @param {*} n1 primer dígito de resta
     * @param {*} n2 segundo dígito de resta
     */
    resta: function(n1, n2) {
        return this._esNumero(n1, n2)? (n1 - n2): this._mensajeError();
    },
    /**
     * multiplicacion de dos números
     * @example
     * n1 = 1, n2 = 4 => resultado = 4
     * @param {*} n1 primer dígito de multiplicacion
     * @param {*} n2 segundo dígito de multiplicacion
     */
    multiplicacion: function(n1, n2) {
        return this._esNumero(n1, n2)? (n1 * n2): this._mensajeError();
    },
    /**
     * división de dos números
     * @example
     * n1 = 1, n2 = 4 => resultado = 0.25
     * @param {*} n1 primer dígito de división
     * @param {*} n2 segundo dígito de división
     */
    division: function(n1, n2) {
        try {
            return this._esNumero(n1, n2)? (n1 / n2): this._mensajeError();
        } catch (error) {
            this.mensajeError();
        }
    },
    /**
     * Mensaje que se ejecuta cuando no tengamos valores numéricos.
     */
    _mensajeError: function(){
        console.log("ERROR: Número inválido.");
    },
    /**
     * Comprueba que números ingresados sean números.
     * @param {*} n1 primer número ingresado.
     * @param {*} n2 segundo número ingresado.
     */
    _esNumero: function(n1, n2){
        return typeof n1 === 'number' && typeof n2 === 'number';
    }

}