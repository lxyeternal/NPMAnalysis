import {DAYS_IN_MONTH} from './constants'
/**
 * 根据年月 获取当月的总天数
 *
 * @param {*} year
 * @param {*} month
 * @returns
 */
export function getDays(year, month) {
  if (month === 2) {
    // 判断闰年
    return ((year % 4 === 0) && ((year % 100) !== 0)) || (year % 400 === 0) ? 29 : 28
  } else {
    return DAYS_IN_MONTH[month - 1]
  }
}

/**
 * 根据当前年份获取年份列表
 *
 * @param {*} nowYear
 * @param {*} range 年份上下范围
 * @param {*} isShowTotal 是否展示正常日历年份，显示1950-至今年份列表
 * @returns
 */
export function setYearsList(nowYear, range, isShowTotal) {
  let years = []
  let i = isShowTotal ? 1950 : nowYear - range
  let topYear = isShowTotal ? nowYear : nowYear + range
  for (i; i <= topYear; i++) {
    years.push(i)
  }
  return years
}

/**
 * 获取月份列表
 *
 * @param {*} monthsNum
 * @returns
 */
export function setMonthsList(monthsNum) {
  let months = []
  for (let i = 1; i <= monthsNum; i++) {
    months.push(i)
  }
  return months
}

/**
 * 获取天数列表
 *
 * @param {*} daysNum
 * @returns
 */
export function setDaysList(daysNum) {
  let days = []
  for (let i = 1; i <= daysNum; i++) {
    days.push(i)
  }
  return days
}

/**
 * 获取当前选中项的索引
 *
 * @param {*} list
 * @returns
 */
export function getActivedIndex(list = [], activedItem) {
  let result
  list.forEach((item, index) => {
    if (item === activedItem) {
      result = index
    }
  })
  return result
}

/**
 * 深拷贝，同时去掉前三项
 * 
 * @param {*} obj
 * @returns
 */
export function deepClone(obj) {
  let cloneValue = JSON.parse(JSON.stringify(obj))
  cloneValue.splice(0, 3)
  return cloneValue
}
