<template>
  <div class="hlj-picker" v-if="visible">
    <div class="hlj-picker-body hlj-animate-slide-up">
      <div class="hlj-picker-control">
        <a class="hlj-picker__action hlj-picker-cancel" @click="handlePickerCancle">取消</a>
        <span class="hlj-picker-title">{{title}}</span>
        <a class="hlj-picker__action hlj-picker-select" @click="handlePickerSelect">确定</a>
      </div>
      <div class="hlj-picker-content">
        <picker-view
          :value="currentValue"
          :indicator-style="'height: 34px;' + indicatorStyle"
          :indicator-class="indicatorClass"
          :mask-style="maskStyle"
          :imask-class="maskClass"
          style="width: 100%; height: 300px;"
          @change="handlePickerChange">
          <picker-view-column>
            <div v-for="(item, index) in years" class="picker-view-column" :key="index">{{item}}年</div>
          </picker-view-column>
          <picker-view-column>
            <div v-for="(item, index) in months" class="picker-view-column" :key="index">{{item}}月</div>
          </picker-view-column>
          <picker-view-column>
            <div v-for="(item, index) in days" class="picker-view-column" :key="index">{{item}}日</div>
          </picker-view-column>
          <picker-view-column v-for="(optionsList, index) in otherOptions" :key="index">
            <div v-for="(item, childIndex) in optionsList" class="picker-view-column" :key="childIndex">{{item}}</div>
          </picker-view-column>
        </picker-view>
      </div>
    </div>
    <div class="hlj-mark hlj-animate-fade-in" @click="handlePickerCancle"></div>
  </div>
</template>

<script>
import {
  getDays,
  setYearsList,
  setMonthsList,
  setDaysList,
  getActivedIndex,
  deepClone
} from './utils.js'
import {NOW_YEAR, NOW_MONTH, NOW_DAY} from './constants.js'
export default {
  name: "hlj-picker",
  props: {
    visible: {
      require: true,
      type: Boolean,
      default: false
    },
    otherOptions: {
      type: Array,
      default: []
    },
    value: {
      type: Array,
      default: []
    },
    title: {
      type: String,
      default: "请选择日期"
    },
    indicatorStyle: {
      type: String,
      default: ""
    },
    indicatorClass: {
      type: String,
      default: ""
    },
    maskStyle: {
      type: String,
      default: ""
    },
    maskClass: {
      type: String,
      default: ""
    },
    showYearsRange: {
      type: Number,
      default: 3
    },
    isShowNormalDatePicker: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      years: [],
      months: [],
      days: [],
      activedYear: this.value[0] || NOW_YEAR, // 选中年份
      activedMonth: this.value[1] || NOW_MONTH, // 选中月份
      activedDay: this.value[2] || NOW_DAY, // 选中日期
      currentValue: this.value
    }
  },
  watch: {
    value(newVal) {
      if (newVal.length) {
        this.handleCurrentValueInit(newVal[0], newVal[1], newVal[2])
      }
    }
  },
  methods: {
    // 处理日期时间更新
    handleUpdate(year, month, day) {
      const daysNum = (year === NOW_YEAR && month === NOW_MONTH)
        ? this.isShowNormalDatePicker 
          ? NOW_DAY
          : getDays(year, month)
        : getDays(year, month)
      // const monthsNum = year === NOW_YEAR ? NOW_MONTH : 12
      const monthsNum = 12
      const activedDay = day > daysNum ? 1 : day

      this.years = setYearsList(NOW_YEAR, this.showYearsRange, this.isShowNormalDatePicker)
      this.months = setMonthsList(monthsNum)
      this.days = setDaysList(daysNum)
    },
    handlePickerCancle() {
      this.$emit('close')
    },
    handlePickerSelect() {
      this.$emit('close')
      const callbackValue = this.handleCallbackDataFormat(this.currentValue)
      this.$emit('confirm', callbackValue)
    },
    // 回调数据处理
    handleCallbackDataFormat(value) {
      // console.log('回调value', value)
      let callbackValue = [this.years[value[0]], this.months[value[1]], this.days[value[2]]]
      if (this.otherOptions.length) {
        let cloneValue = deepClone(value)
        this.otherOptions.forEach((options, index) => {
          const currentItem = options[cloneValue[index]]
          callbackValue.push(currentItem)
        })
      }
      // console.log('回调callbackValue', callbackValue)
      return callbackValue
    },
    // 默认数据初始化
    handleCurrentValueInit(year, month, day) {
      const yearIndex = getActivedIndex(this.years, year)
      const monthIndex = getActivedIndex(this.months, month)
      const dayIndex = getActivedIndex(this.days, day)
      let currentValue = [yearIndex, monthIndex, dayIndex]
      // 处理额外添加的选项的索引
      if (this.otherOptions.length && this.value.length) {
        // cloneValue：获取额外添加的值
        let cloneValue = deepClone(this.value)
        this.otherOptions.forEach((options, index) => {
          const currentItem = getActivedIndex(options, cloneValue[index])
          currentValue.push(currentItem)
        })
      } else if (this.otherOptions.length) {
        let addArr = []
        this.otherOptions.forEach((item, index) => {
          addArr[index] = 0
        })
        // console.log('addArr', addArr)
        currentValue = [...currentValue, ...addArr]
      }
      console.log(currentValue, '>>>>>>>>>')
      this.currentValue = currentValue
    },
    // 监听选项变化
    handlePickerChange(e) {
      const value = e.mp.detail.value
      this.currentValue = e.mp.detail.value
      this.handleUpdate(this.years[value[0]], this.months[value[1]], this.days[value[2]])
    }
  },
  mounted() {
    console.log(this.activedYear, this.activedMonth, this.activedDay)
    this.handleUpdate(this.activedYear, this.activedMonth, this.activedDay)
    this.handleCurrentValueInit(this.activedYear, this.activedMonth, this.activedDay)
  }
}
</script>

<style lang="less">
.hlj-picker {
  .hlj-picker-body {
    position: fixed;
    width: 100%;
    left: 0;
    bottom: 0;
    z-index: 5000;
    backface-visibility: hidden;
    transform: translate(0, 100%);
    transition: transform 0.3s;
    .hlj-picker-control {
      position: relative;
      display: flex;
      padding: 9px 15px;
      background-color: #fff;
      text-align: center;
      font-size: 17px;
      &::after {
        content: " ";
        position: absolute;
        left: 0;
        bottom: 0;
        right: 0;
        height: 1px;
        border-bottom: 1px solid #E5E5E5;
        color: #E5E5E5;
        transform-origin: 0 100%;
        transform: scaleY(0.5);
      }
      .hlj-picker__action {
        display: block;
        flex: 1;
      }
      .hlj-picker-cancel {
        text-align: left;
        color: #888;
      }
      .hlj-picker-title {
        color: #666;
      }
      .hlj-picker-select {
        text-align: right;
        color: #1aad19;
      }
    }
    .hlj-picker-content {
      display: flex;
      position: relative;
      background-color: #fff;
      height: 238px;
      overflow: hidden;
      .picker-view-column {
        line-height: 34px;
        text-align: center;
      }
    }
  }
  .hlj-mark {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1000;
    background: rgba(0, 0, 0, 0.6);
  }
}
.hlj-animate-fade-in {
  animation: fadeIn ease 0.3s forwards;
}
.hlj-animate-slide-up {
  animation: slideUp ease 0.3s forwards;
}
@keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes slideUp {
  0% {
    transform: translate3d(0, 100%, 0);
  }
  100% {
    transform: translate3d(0, 0, 0);
  }
}
</style>
