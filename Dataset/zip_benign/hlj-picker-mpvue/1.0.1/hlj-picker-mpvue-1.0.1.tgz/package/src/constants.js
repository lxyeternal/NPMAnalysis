// 当前时间
export const DATE = new Date()
// 当前年份
export const NOW_YEAR = DATE.getFullYear()
// 当前月份
export const NOW_MONTH = DATE.getMonth() + 1
// 当前日期
export const NOW_DAY = DATE.getDate()
// 每个月份对应的天数
export const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
