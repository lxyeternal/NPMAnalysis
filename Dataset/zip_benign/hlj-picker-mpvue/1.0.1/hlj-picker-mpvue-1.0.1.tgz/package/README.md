## 婚礼纪小程序picker定制组件（mpvue）


### 安装

> npm install hlj-picker-mpvue -save

### 示例

![](https://qnm.hunliji.com/o_1coibl5l712jl1bgpamv16hc14e59.png)


![](https://qnm.hunliji.com/o_1coibnr7f13bu15no1sd39hg3e8e.png)

### API
| 属性名 | 类型 | 默认值 | 必填 | 说明 |
| ------------- | ------------- | -------- | ------ | ------ |
| visible | Boolean | `false` | 是 | 是否展示picker |
| value | Array | [] | 是 | 默认值，如 `[2018, 9, 27, '中午', 'gogogo']` |
| title | String | '请选择日期' | 否 | picker名称 |
| otherOptions | Array | [] | 是 | 除年月日外额外的选项，如`[['早上', '中午', '晚上'], ['hello', 'world', 'gogogo']]`；建议最多加两项 |
| showYearsRange | Number | 3 | 否 | 展示年份范围，若当前为2018年，`showYearsRange`为3时，则展示2015-2021之间的年份 |
| isShowNormalDatePicker | Boolean | `false` | 否 | 是否展示正常年份选择，为true时展示1950年至今的日期  |
| @close | Function | 无 | 是 | 点击遮罩层或取消按钮的回调，用来关闭弹框 |
| @confirm | Function | 无 | 是 | 点击确定后回调，回调参数格式`[2018, 9, 27, '中午', 'gogogo']` |
| indicatorStyle |  String | `"height: 50px"` | 否 | 设置选择器中间选中框的样式：如 `"background: #fff; opacity: 0.5"` |
| indicatorClass | String | 无 | 否 | 设置选择器中间选中框的类名：如 `"indicator-class"` |
| maskStyle | String | 无 | 否 | 设置选择器蒙层的样式：如 `"background: #fff; opacity: 0.5"` |
| maskClass | String | 无 | 否 | 设置选择器蒙层的类名：如 `"mask-class"` |
