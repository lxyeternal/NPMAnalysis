## API

| 参数名                | 类型               | 说明                         | 默认值 | 是否必填 | 备注                                                                                       |
| --------------------- | ------------------ | ---------------------------- | ------ | -------- | ------------------------------------------------------------------------------------------ |
| className             | string             | css 类名                     | -      | false    | -                                                                                          |
| photoPoseConfig       | IPhotoPoseItem[]   | 拍照角色                     | -      | false    | -                                                                                          |
| onExit                | () => void         | 退出拍照回调                 | -      | false    | -                                                                                          |
| shareConfig           | ISharePosterConfig | 分享组件配置                 | -      | false    | -                                                                                          |
| actionTextStyle       | CSSProperties      | 动作文案元素样式设置         | -      | false    | “动作”这两文字的样式设置                                                                   |
| actionItemStyle       | CSSProperties      | 动作选择元素样式设置         | -      | false    | -                                                                                          |
| activeActionItemStyle | CSSProperties      | 动作选择元素选中状态样式设置 | -      | false    | -                                                                                          |
| isGroupMode           | boolean            | 是否是多人合照               | -      | false    | 默认是单人模式                                                                             |
| unSelectedImgOpacity  | number             | 未选中动作的图片透明度       | 0.5    | false    | 大于 0 小于 1 的小数                                                                       |
| isPlayIdleWhenExit    | boolean            | 退出时是否播放 idle 动作     | true   | false    | 设置为 false 不播 idle,其他退出动作播放可在事件中配置（该处需要设置为 false，不然会抖动）; |
| exCludeTurnPaths      | string[]           | 不被转向镜头的 path          | -      | false    | 当用户进入这个 path 的时候 就不被拍照镜头旋转                                              |
| exitBtnStyle          | CSSProperties      | 退出拍照按钮的样式             | -      | false    | -                                                                                          |
