import { ISnippet } from '@xverse/matrix-shared-types';
import { CSSProperties } from 'react';
import { ISharePosterConfig } from 'xverse-components-share-poster';
export declare const snippet: ISnippet;
interface IPoseItem {
    /**
     * @title pose图片
     * @setter ImageSetter
     */
    imageUrl: string;
    /**
     * @title pose ID
     * @setter AvatarAnimationSetter
     */
    pose: string;
}
export interface IPhotoPoseItem {
    /**
     * @title 当前动作属于哪个性别的avatar
     * @setter AvatarIdSetter
     */
    avatarId: string;
    /**
     * @title 动作列表
     */
    poseList: IPoseItem[];
}
/**
 * @componentName PhotoGraph
 * @title 拍照组件
 * @type 3D
 * @contributor 时猛 甘晶
 * @imgLink https://appasset.xverse.cn/20/image/279c55c71a2344bfb7e78c55317cd564/photo-graph.png
 */
export interface IPhotoGraph {
    /**
     * @title css类名
     * @notExternal
     */
    className?: string;
    /**
     * @title 拍照角色
     */
    photoPoseConfig?: IPhotoPoseItem[];
    /**
     * @title 退出拍照回调
     */
    onExit?: () => void;
    /**
     * @title 分享组件配置
     * @slot SharePoster
     * @excludeKeys isScreenShotMode
     */
    shareConfig?: ISharePosterConfig;
    /**
     * @title 动作文案元素样式设置
     * @setter StyleSetter
     * @description “动作”这两文字的样式设置
     */
    actionTextStyle?: CSSProperties;
    /**
     * @title 动作选择元素样式设置
     * @setter StyleSetter
     */
    actionItemStyle?: CSSProperties;
    /**
     * @title 动作选择元素选中状态样式设置
     * @setter StyleSetter
     */
    activeActionItemStyle?: CSSProperties;
    /**
     * @title 是否是多人合照
     * @default false
     * @description 默认是单人模式
     * @notExternal
     */
    isGroupMode?: boolean;
    /**
     * @title 未选中动作的图片透明度
     * @default 0.5
     * @description 大于0小于1的小数
     * @notExternal
     */
    unSelectedImgOpacity?: number;
    /**
     * @title 退出时是否播放idle动作
     * @default true
     * @description 设置为false不播idle,其他退出动作播放可在事件中配置（该处需要设置为false，不然会抖动）;
     * @notExternal
     */
    isPlayIdleWhenExit?: boolean;
    /**
     * @title  不被转向镜头的path
     * @description 当用户进入这个path的时候 就不被拍照镜头旋转
     * @setter PathIdSetter
     * @notExternal
     */
    exCludeTurnPaths?: string[];
    /**
     * @title  出拍照按钮的样式
     * @setter StyleSetter
     */
    exitBtnStyle?: CSSProperties;
}
export {};
