/// <reference types="react" />
import { IPhotoGraph } from './types';
import './style.less';
export declare const PhotoGraph: import("react").MemoExoticComponent<(props: IPhotoGraph) => import("react").JSX.Element>;
