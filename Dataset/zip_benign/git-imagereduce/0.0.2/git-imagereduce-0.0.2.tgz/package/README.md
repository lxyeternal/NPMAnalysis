# git-imagereduce

## 介绍

图片压缩，支持多图。默认压缩比例为0.5

## 添加

npm i git-imagereduce —save

npm link git-imagereduce

## 示例

    import GitImageReduce from 'git-imagereduce'
    
     GitImageReduce.savePhotoToFile(this.state.photos, {width:100,height:100}).then((files)=>{
                    console.log(files)
                }).catch((error)=>{
       				console.log(error)
                })



 
