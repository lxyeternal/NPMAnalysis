var music = [
    1200, 600, 1200, 800, 1200, 1100, 1200, 500, 1200, 1000, 1400, 900
];
var xs = [ 20, 10, 30, 7, 11, 13, 18, 33, 22, 9 ];
var ys = [ 15, 1.5, 30, 0.5, 12, 0.125 ];

var modifiers = [
    // sine
    function (n) { return n },
    
    // square
    function (n) { return Math.floor(n * 2) },
];

return function (t, i) {
    var f = music[Math.floor(t * 2) % music.length] / 17;
    var x = xs[Math.floor(t) % xs.length] / 10;
    var y = ys[Math.floor(t * 4) % ys.length] / 10;
    
    if (t % 3 > 1) return 0;
    if (t % 0.125 > 0.1) return 0;
    
    var ix = Math.floor(t / 2) % modifiers.length;
    return modifiers[ix](2 * Math.sin(t * f * Math.PI)
        //* Math.pow(Math.sin(t * (x + y) * Math.PI), 2)
        * Math.sin(t * 1600 * Math.PI
            + t * Math.sin(t * x) * Math.cos(t * y)
        )
    );
}
