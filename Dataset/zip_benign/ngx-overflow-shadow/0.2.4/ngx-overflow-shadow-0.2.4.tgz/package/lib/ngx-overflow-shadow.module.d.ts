import * as i0 from "@angular/core";
import * as i1 from "./ngx-overflow-shadow.directive";
export declare class NgxOverflowShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxOverflowShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxOverflowShadowModule, [typeof i1.NgxOverflowShadowDirective], never, [typeof i1.NgxOverflowShadowDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxOverflowShadowModule>;
}
