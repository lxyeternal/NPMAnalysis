import { AfterViewInit, ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NgxOverflowShadowDirective implements AfterViewInit, OnDestroy {
    private readonly renderer;
    private readonly elementRef;
    top: boolean;
    bottom: boolean;
    shadowStyle: string;
    topShadowDiv: HTMLElement;
    bottomShadowDiv: HTMLElement;
    private topIntersectionObserver;
    private bottomIntersectionObserver;
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private init;
    private initTopShadow;
    private initBottomShadow;
    private createTopShadowDiv;
    private createBottomShadowDiv;
    private createTopIntersectionObserver;
    private createBottomIntersectionObserver;
    private createTopPlaceholderDiv;
    private createBottomPlaceholderDiv;
    private callback;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxOverflowShadowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgxOverflowShadowDirective, "[ngxOverflowShadow]", never, { "top": { "alias": "top"; "required": false; }; "bottom": { "alias": "bottom"; "required": false; }; "shadowStyle": { "alias": "shadowStyle"; "required": false; }; }, {}, never, never, false, never>;
}
