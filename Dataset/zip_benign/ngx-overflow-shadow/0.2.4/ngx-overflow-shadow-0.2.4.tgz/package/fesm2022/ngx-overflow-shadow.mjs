import * as i0 from '@angular/core';
import { Directive, Input, NgModule } from '@angular/core';

class NgxOverflowShadowDirective {
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.top = false;
        this.bottom = true;
        this.shadowStyle = '0 0 8px 1px rgba(0, 0, 0, 0.5)';
    }
    ngAfterViewInit() {
        this.init();
    }
    ngOnDestroy() {
        if (this.top) {
            this.topIntersectionObserver.disconnect();
        }
        if (this.bottom) {
            this.bottomIntersectionObserver.disconnect();
        }
    }
    init() {
        if (this.top) {
            this.initTopShadow();
        }
        if (this.bottom) {
            this.initBottomShadow();
        }
    }
    initTopShadow() {
        const { nativeElement } = this.elementRef;
        this.createTopShadowDiv(nativeElement);
        this.createTopIntersectionObserver(nativeElement);
        this.createTopPlaceholderDiv(nativeElement);
    }
    initBottomShadow() {
        const { nativeElement } = this.elementRef;
        this.createBottomShadowDiv(nativeElement);
        this.createBottomIntersectionObserver(nativeElement);
        this.createBottomPlaceholderDiv(nativeElement);
    }
    createTopShadowDiv(nativeElement) {
        this.topShadowDiv = this.renderer.createElement('div');
        this.renderer.setStyle(this.topShadowDiv, 'position', 'sticky');
        this.renderer.setStyle(this.topShadowDiv, 'top', 0);
        this.renderer.insertBefore(nativeElement, this.topShadowDiv, nativeElement.firstChild);
    }
    createBottomShadowDiv(nativeElement) {
        this.bottomShadowDiv = this.renderer.createElement('div');
        this.renderer.setStyle(this.bottomShadowDiv, 'position', 'sticky');
        this.renderer.setStyle(this.bottomShadowDiv, 'bottom', 0);
        this.renderer.appendChild(nativeElement, this.bottomShadowDiv);
    }
    createTopIntersectionObserver(nativeElement) {
        this.topIntersectionObserver = new IntersectionObserver(this.callback.bind(this, this.topShadowDiv), { root: nativeElement });
    }
    createBottomIntersectionObserver(nativeElement) {
        this.bottomIntersectionObserver = new IntersectionObserver(this.callback.bind(this, this.bottomShadowDiv), { root: nativeElement });
    }
    createTopPlaceholderDiv(nativeElement) {
        const topPlaceholderDiv = this.renderer.createElement('div');
        this.renderer.insertBefore(nativeElement, topPlaceholderDiv, nativeElement.firstChild);
        this.topIntersectionObserver.observe(topPlaceholderDiv);
    }
    createBottomPlaceholderDiv(nativeElement) {
        const bottomPlaceholderDiv = this.renderer.createElement('div');
        this.renderer.appendChild(nativeElement, bottomPlaceholderDiv);
        this.bottomIntersectionObserver.observe(bottomPlaceholderDiv);
    }
    callback(shadowDiv, entries) {
        const isIntersecting = entries.find((entry) => entry.isIntersecting);
        if (isIntersecting) {
            this.renderer.removeStyle(shadowDiv, 'boxShadow');
        }
        else {
            this.renderer.setStyle(shadowDiv, 'boxShadow', this.shadowStyle);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: NgxOverflowShadowDirective, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.11", type: NgxOverflowShadowDirective, selector: "[ngxOverflowShadow]", inputs: { top: "top", bottom: "bottom", shadowStyle: "shadowStyle" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: NgxOverflowShadowDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngxOverflowShadow]'
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { top: [{
                type: Input
            }], bottom: [{
                type: Input
            }], shadowStyle: [{
                type: Input
            }] } });

class NgxOverflowShadowModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: NgxOverflowShadowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "17.3.11", ngImport: i0, type: NgxOverflowShadowModule, declarations: [NgxOverflowShadowDirective], exports: [NgxOverflowShadowDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: NgxOverflowShadowModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: NgxOverflowShadowModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [NgxOverflowShadowDirective],
                    exports: [NgxOverflowShadowDirective]
                }]
        }] });

/*
 * Public API Surface of ngx-overflow-shadow
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxOverflowShadowDirective, NgxOverflowShadowModule };
//# sourceMappingURL=ngx-overflow-shadow.mjs.map
