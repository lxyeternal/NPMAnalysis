/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-overflow-shadow" />
export * from './public-api';
