export * from './lib/ngx-overflow-shadow.directive';
export * from './lib/ngx-overflow-shadow.module';
