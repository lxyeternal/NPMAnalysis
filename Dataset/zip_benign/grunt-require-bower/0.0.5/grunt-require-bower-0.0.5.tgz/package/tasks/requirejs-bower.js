module.exports = function(grunt) {
    'use strict';

    var fs = require('fs-extra');

    grunt.registerMultiTask('requirejsBower', 'Copy files.', function() {

        var requireFilePath = this.data.requirePath;
        var bowerFolderPath = this.data.bowerFolderPath;
        var destFolder = this.data.destFolder;

        var bowerFolderName = bowerFolderPath.match(/([^\/]*)\/*$/)[1];

        fs.readFile('requireFilePath', 'utf8', function (err, data) {
            if (err) {
                return console.log(err);
            }

            var indexOfPath = data.indexOf("paths: {");
            var open;
            var close;
            for(var i = indexOfPath; i < data.length; i++) {
                if(data[i] === "{") {
                    open = i;
                    continue;
                }

                if(data[i] === "}") {
                    close = i;
                    break;
                }
            }

            data = data.substring(open, close + 1); //focus on paths
            data = data.replace(/(\/\*([\s\S]*?)\*\/)|(\/\/(.*)$)/gm, ''); //remove comments
            data = data.replace(/(\r\n|\n|\r)/gm, ''); //remove line breaks
            data = data.replace(/\s/g, ''); //remove spaces
            data = data.replace(/'/gm, '"'); //replace ' with ""

            //remove last semi column if exists
            var lastSemiColumn;
            for(var j = data.length; j >= 0; j--) {
                if(data[j] === "}") {
                    if(j - 1 >= 0 && data[j - 1] === ",") {
                        lastSemiColumn = j - 1;
                        break;
                    }
                }
            }

            if(lastSemiColumn) {
                data = data.substring(0, lastSemiColumn);
                data += "}";
            }
            var paths = JSON.parse(data);
            var obj = {};

            for(var path in paths) {
                var suffix = ".js";
                var prefix = bowerFolderName + "/";

                if(paths[path].substr(0, 4) !== prefix) {
                    continue;
                }

                if(paths[path].substr(paths[path].length - 3, paths[path].length).toLowerCase() != suffix) {
                    paths[path] += suffix;
                }

                var fullPath = paths[path];
                var fileName = paths[path].replace(/^.*[\\\/]/, '');
                //var destination: paths[path].replace(/[^\/]*$/, '')

                fs.copy(bowerFolderPath + fullPath, destFolder + fullPath, function(err){
                    if (err) {
                        return console.error(err);
                    }

                    console.log(fileName + " moved");
                });
            }
        });
    });
}

