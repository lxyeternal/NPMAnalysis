declare const useSnap: (opacity?: number) => {
    snap: (opacity_?: number) => {
        onMouseDown: (e: any) => void;
        onMouseUp: (e: any) => void;
        onMouseLeave: (e: any) => void;
    };
};
export default useSnap;
