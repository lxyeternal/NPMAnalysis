declare const useToggle: () => (boolean | (() => void))[];
export default useToggle;
