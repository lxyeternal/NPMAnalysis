declare const useTheme: (options: any) => any[];
export default useTheme;
