import { TextEditorDecorationType, OverviewRulerLane, ThemeColor, Uri } from "vscode";
declare function createLineDecoration(lineBackground: string | ThemeColor, lineBorder?: string | ThemeColor, overviewRulerLane?: OverviewRulerLane, overviewRulerColor?: string | ThemeColor, gutterIconPath?: string | Uri): TextEditorDecorationType;
declare function createGutterDecoration(gutterIconPath: string): TextEditorDecorationType;
export { createLineDecoration, createGutterDecoration };
