import React, { Component } from 'react';
import './style.css';
export class Tour extends Component {
  constructor() {
    super();
    this.state = {
      current: 1
    };
    this.next = this.next.bind(this);
    this.finish = this.finish.bind(this);
    this.close = this.close.bind(this);
  }
  next() {
    this.setState({
      current: this.state.current + 1
    });
  }
  finish() {
    this.setState({current: -1});
    if (this.props.onFinish) {
      this.props.onFinish();
    }
  }
  close () {
    this.setState({current: -1});
    if (this.props.onClose) {
      this.props.onClose();
    }
  }
  render() {
    if (this.props.active) {
      return (
        <div style={{zIndex: this.props.zIndex ? this.props.zIndex : 999}} className="pt-onboarding-container">
          {Object.keys(this.props.steps).map((key) => {
            const step = this.props.steps[key];
            return (
              <div
                key={key}
                style={{top: step.top, left: step.left}}
                className={`pt-info-box ${this.state.current === parseInt(key, 10) && 'active'}`}
              >
                <div
                  style={{backgroundColor: this.props.color ? this.props.color : '#048dbe'}}
                  className="pt-info-header"
                >
                  {step.title}
                  <div className="pt-close-info" onClick={this.close}>&times;</div>
                </div>
                <div className="pt-info-text">{step.text}</div>
                <div className="pt-ob-action">
                  <div className="pt-count">{this.state.current} / {Object.keys(this.props.steps).length}</div>
                    {Object.keys(this.props.steps).length === parseInt(key, 10) ?
                      (
                        <div className="pt-btn" onClick={this.finish}>
                          {this.props.finishLabel ? this.props.finishLabel :  'finish'}
                        </div>
                      ) : (
                        <div className="pt-btn" onClick={this.next}>
                          {this.props.nextLabel ? this.props.nextLabel :  'next'}
                        </div>
                      )
                    }
                </div>
                <div
                  style={{borderColor: this.props.color ? this.props.color : '#048dbe'}}
                  className={`pt-caret ${step.caretPosition ? step.caretPosition : 'top-center'}`}
                />
              </div>
            );
          })}
          {this.state.current > 0 && (
            <div
              style={{backgroundColor: this.props.background ? this.props.background : 'rgba(255,255,255,0.5)'}}
              className="pt-onboarding-bg"
            />
          )}
        </div>
      );
    } else {
      return null;
    }
  }
}
