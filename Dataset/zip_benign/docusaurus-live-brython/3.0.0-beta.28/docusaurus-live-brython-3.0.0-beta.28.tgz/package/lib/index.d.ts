/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { HtmlTags, Plugin } from '@docusaurus/types';
import { type ThemeOptions, type Options } from './options';
export declare const NAME: "docusaurus-live-brython";
export declare const DEFAULT_LIB_DIR: "bry-libs";
declare const theme: Plugin<{
    remoteHeadTags: HtmlTags[];
}>;
export default theme;
export { validateThemeConfig } from './options';
export { ThemeOptions, Options };
//# sourceMappingURL=index.d.ts.map