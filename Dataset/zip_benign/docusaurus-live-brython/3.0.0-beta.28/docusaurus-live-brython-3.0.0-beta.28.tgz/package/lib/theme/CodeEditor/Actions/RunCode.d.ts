import * as React from 'react';
export interface Props {
    title: string;
    slim: boolean;
}
declare const RunCode: (props: Props) => React.JSX.Element;
export default RunCode;
//# sourceMappingURL=RunCode.d.ts.map