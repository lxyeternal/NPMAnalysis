import * as React from 'react';
declare const Canvas: () => React.JSX.Element;
export default Canvas;
//# sourceMappingURL=Canvas.d.ts.map