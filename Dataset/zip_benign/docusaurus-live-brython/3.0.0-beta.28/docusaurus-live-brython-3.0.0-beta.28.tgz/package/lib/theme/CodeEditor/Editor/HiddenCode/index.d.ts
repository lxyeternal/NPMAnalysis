import * as React from 'react';
interface Props {
    type: 'pre' | 'post';
    code: string;
}
declare const HiddenCode: (props: Props) => React.JSX.Element;
export default HiddenCode;
//# sourceMappingURL=index.d.ts.map