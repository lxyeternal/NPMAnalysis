import * as React from 'react';
declare const Reset: () => React.JSX.Element;
export default Reset;
//# sourceMappingURL=Reset.d.ts.map