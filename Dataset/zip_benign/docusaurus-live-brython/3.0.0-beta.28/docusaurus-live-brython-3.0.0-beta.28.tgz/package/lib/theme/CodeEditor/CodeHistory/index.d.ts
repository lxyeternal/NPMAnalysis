import * as React from 'react';
import 'rc-slider/assets/index.css';
declare const CodeHistory: () => React.JSX.Element;
export default CodeHistory;
//# sourceMappingURL=index.d.ts.map