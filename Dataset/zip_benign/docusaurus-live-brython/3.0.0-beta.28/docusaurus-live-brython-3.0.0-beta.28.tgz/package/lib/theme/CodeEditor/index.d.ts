import * as React from 'react';
export interface MetaProps {
    reference?: boolean;
    live_jsx?: boolean;
    live_py?: boolean;
    id?: string;
    slim?: boolean;
    readonly?: boolean;
    noReset?: boolean;
    noDownload?: boolean;
    versioned?: boolean;
    noHistory?: boolean;
    noCompare?: boolean;
    maxLines?: string;
    title?: string;
}
export interface Props {
    slim: boolean;
    readonly: boolean;
    noCompare: boolean;
    title: string;
    versioned: boolean;
    resettable: boolean;
    download: boolean;
    showLineNumbers: boolean;
    lang: string;
    preCode: string;
    postCode: string;
    code: string;
    maxLines?: number;
    noHistory: boolean;
    className?: string;
    onChange?: (code: string) => void;
}
declare const CodeEditor: (props: Props) => React.JSX.Element;
export default CodeEditor;
//# sourceMappingURL=index.d.ts.map