declare const removeAnimations: (svg: string, svgProps: Record<string, string | number>) => string;
export { removeAnimations };
//# sourceMappingURL=svgWithoutAnimations.d.ts.map