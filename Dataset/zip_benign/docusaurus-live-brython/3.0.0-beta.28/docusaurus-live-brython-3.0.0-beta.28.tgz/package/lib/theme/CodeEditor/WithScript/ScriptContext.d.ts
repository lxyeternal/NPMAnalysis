import React from 'react';
import { type InitState, type Document } from '@theme/CodeEditor/WithScript/Types';
export declare const Context: React.Context<Document<import("@theme/CodeEditor/WithScript/Types").Script>>;
declare const ScriptContext: (props: InitState & {
    children: React.ReactNode;
}) => React.JSX.Element;
export default ScriptContext;
//# sourceMappingURL=ScriptContext.d.ts.map