import * as React from 'react';
import * as Icons from '@theme/CodeEditor/Icon/icons';
export declare enum Color {
    Primary = "button--primary",
    Secondary = "button--secondary",
    Success = "button--success",
    Info = "button--info",
    Warning = "button--warning",
    Danger = "button--danger",
    Link = "button--link"
}
export declare enum Size {
    Small = "button--sm",
    Large = "button--lg"
}
export interface Props {
    icon: keyof typeof Icons;
    title?: string;
    onClick?: React.MouseEventHandler<HTMLButtonElement>;
    size?: Size;
    iconSize?: string;
    spin?: boolean;
    color?: Color;
    className?: string;
}
declare const Button: (props: Props) => React.JSX.Element;
export default Button;
//# sourceMappingURL=index.d.ts.map