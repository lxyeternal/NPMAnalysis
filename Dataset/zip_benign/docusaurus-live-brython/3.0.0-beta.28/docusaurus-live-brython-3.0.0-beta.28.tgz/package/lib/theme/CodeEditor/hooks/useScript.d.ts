import { type Script, type Document } from '@theme/CodeEditor/WithScript/Types';
export declare const useScript: <T extends keyof Script>(store: Document, selector: T) => Script[T];
//# sourceMappingURL=useScript.d.ts.map