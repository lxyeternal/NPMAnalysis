import * as React from 'react';
declare const DownloadCode: (props: {
    title: string;
}) => React.JSX.Element;
export default DownloadCode;
//# sourceMappingURL=DownloadCode.d.ts.map