import * as React from 'react';
declare const BrythonCommunicator: () => React.JSX.Element;
export default BrythonCommunicator;
//# sourceMappingURL=BrythonCommunicator.d.ts.map