declare const saveSvg: (svgEl: SVGSVGElement, name: string, code?: string, animated?: boolean) => void;
export { saveSvg };
//# sourceMappingURL=saveSvg.d.ts.map