export declare const checkGraphicsOutput: (raw: string) => boolean;
export declare const checkTurtleOutput: (raw: string) => boolean;
export declare const checkCanvasOutput: (raw: string) => boolean;
/**
 * The python script is transformed to a string by embedding it with """ characters.
 * So we must prevent the script itself to contain this sequence of characters.
 * @param {String} script
 */
export declare const sanitizePyScript: (script: string) => string;
//# sourceMappingURL=helpers.d.ts.map