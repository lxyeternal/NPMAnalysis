import * as React from 'react';
declare const ShowSyncStatus: () => React.JSX.Element;
export default ShowSyncStatus;
//# sourceMappingURL=ShowSyncStatus.d.ts.map