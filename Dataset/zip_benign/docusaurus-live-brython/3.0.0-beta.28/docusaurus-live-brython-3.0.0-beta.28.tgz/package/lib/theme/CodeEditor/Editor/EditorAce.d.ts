/// <reference types="ace-builds/ace-modules" />
import * as React from 'react';
import 'ace-builds/src-noconflict/ext-searchbox';
import 'ace-builds/src-noconflict/mode-python';
import 'ace-builds/src-noconflict/mode-sql';
import 'ace-builds/src-noconflict/mode-svg';
import 'ace-builds/src-noconflict/theme-dracula';
import 'ace-builds/src-noconflict/ext-language_tools';
import 'ace-builds/webpack-resolver';
export interface Props {
    versioned?: boolean;
    showLineNumbers: boolean;
    maxLines?: number;
    onChange?: (code: string) => void;
}
declare const EditorAce: (props: Props) => React.JSX.Element;
export default EditorAce;
//# sourceMappingURL=EditorAce.d.ts.map