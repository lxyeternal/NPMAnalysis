import { DraggableEvent } from 'react-draggable';
/**
 * When using react-draggable, the click-event is not propagated
 * to the button on touch devices. Fix this by clicking the button
 * programmatically.
 */
declare const checkForButtonClick: (event: DraggableEvent) => void;
export { checkForButtonClick };
//# sourceMappingURL=checkForButtonClick.d.ts.map