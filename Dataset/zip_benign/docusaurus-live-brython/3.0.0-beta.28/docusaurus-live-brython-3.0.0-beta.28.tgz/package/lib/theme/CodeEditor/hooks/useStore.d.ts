import { type Document } from '@theme/CodeEditor/WithScript/Types';
export declare function useStore(): Document;
//# sourceMappingURL=useStore.d.ts.map