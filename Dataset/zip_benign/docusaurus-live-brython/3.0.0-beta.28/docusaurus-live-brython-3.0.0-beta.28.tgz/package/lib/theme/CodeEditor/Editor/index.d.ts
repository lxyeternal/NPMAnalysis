import * as React from 'react';
export interface Props {
    slim: boolean;
    title: string;
    resettable: boolean;
    showLineNumbers: boolean;
    download: boolean;
    lang: string;
    noCompare: boolean;
    preCode: string;
    postCode: string;
    maxLines?: number;
    versioned?: boolean;
    onChange?: (code: string) => void;
}
declare const Editor: (props: Props) => React.JSX.Element;
export default Editor;
//# sourceMappingURL=index.d.ts.map