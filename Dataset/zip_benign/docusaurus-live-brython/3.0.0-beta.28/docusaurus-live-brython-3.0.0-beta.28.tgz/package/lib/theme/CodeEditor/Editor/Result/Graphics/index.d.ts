import * as React from 'react';
export interface Props {
    controls?: JSX.Element;
    main?: JSX.Element;
}
declare const Graphics: (props: Props) => React.JSX.Element;
export default Graphics;
//# sourceMappingURL=index.d.ts.map