import { type InitState, type Document } from '@theme/CodeEditor/WithScript/Types';
import { RouterType } from '@docusaurus/types';
export declare const createStore: (props: InitState, libDir: string, syncMaxOnceEvery: number, router: RouterType) => Document;
//# sourceMappingURL=createStore.d.ts.map