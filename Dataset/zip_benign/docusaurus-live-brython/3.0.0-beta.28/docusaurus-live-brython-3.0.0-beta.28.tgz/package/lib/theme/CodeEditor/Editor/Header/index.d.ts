import * as React from 'react';
export interface Props {
    slim: boolean;
    title: string;
    resettable: boolean;
    download: boolean;
    noCompare: boolean;
}
declare const Header: (props: Props) => React.JSX.Element;
export default Header;
//# sourceMappingURL=index.d.ts.map