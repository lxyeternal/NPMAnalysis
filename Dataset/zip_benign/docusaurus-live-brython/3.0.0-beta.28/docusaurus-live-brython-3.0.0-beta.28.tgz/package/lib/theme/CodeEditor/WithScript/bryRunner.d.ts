import { RouterType } from '@docusaurus/types';
export declare const runCode: (code: string, preCode: string, postCode: string, codeId: string, libDir: string, router: RouterType, cache?: boolean) => string;
//# sourceMappingURL=bryRunner.d.ts.map