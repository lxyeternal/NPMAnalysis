import * as React from 'react';
declare const Result: () => React.JSX.Element;
export default Result;
//# sourceMappingURL=index.d.ts.map