import * as React from 'react';
declare const ShowRaw: () => React.JSX.Element;
export default ShowRaw;
//# sourceMappingURL=ShowRaw.d.ts.map