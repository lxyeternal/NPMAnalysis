/// <reference types="react" />
/// <reference types="@docusaurus/module-type-aliases" />
import { type Props as CodeBlockType } from '@theme-init/CodeBlock';
import type { WrapperProps } from '@docusaurus/types';
type Props = WrapperProps<typeof CodeBlockType>;
export default function CodeBlockWrapper(props: Props): JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map