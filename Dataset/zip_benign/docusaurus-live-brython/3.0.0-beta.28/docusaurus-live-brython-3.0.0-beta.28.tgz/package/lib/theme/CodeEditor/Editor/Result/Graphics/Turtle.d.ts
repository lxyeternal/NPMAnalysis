import * as React from 'react';
declare const Turtle: () => React.JSX.Element;
export default Turtle;
//# sourceMappingURL=Turtle.d.ts.map