import * as React from 'react';
import * as Icons from '@theme/CodeEditor/Icon/icons';
export declare enum Color {
    Primary = "var(--ifm-color-primary)",
    Secondary = "var(--ifm-color-secondary)",
    Success = "var(--ifm-color-success)",
    Info = "var(--ifm-color-info)",
    Warning = "var(--ifm-color-warning)",
    Danger = "var(--ifm-color-danger)",
    Link = "var(--ifm-color-link)"
}
export interface Props {
    icon: keyof typeof Icons;
    size?: number | string;
    spin?: boolean;
    rotate?: number;
    color?: string;
    className?: string;
}
declare const Icon: (props: Props) => React.JSX.Element;
export default Icon;
//# sourceMappingURL=index.d.ts.map