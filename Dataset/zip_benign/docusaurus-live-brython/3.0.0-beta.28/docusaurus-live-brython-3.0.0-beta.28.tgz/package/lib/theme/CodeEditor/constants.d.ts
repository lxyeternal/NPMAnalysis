declare const DOM_ELEMENT_IDS: {
    communicator: (codeId: string) => string;
    graphicsResult: (codeId: string) => string;
    outputDiv: (codeId: string) => string;
    aceEditor: (codeId: string) => string;
    turtleSvgContainer: (codeId: string) => string;
    canvasContainer: (codeId: string) => string;
};
declare const BRYTHON_NOTIFICATION_EVENT = "bry_notify";
declare const CLOSE_TURTLE_MODAL_EVENT = "close_turtle_modal";
declare const TURTLE_IMPORTS_TESTER: RegExp;
declare const TURTLE3D_IMPORTS_TESTER: RegExp;
declare const GRID_IMPORTS_TESTER: RegExp;
declare const GRAPHICS_OUTPUT_TESTER: RegExp;
declare const CANVAS_OUTPUT_TESTER: RegExp;
export { DOM_ELEMENT_IDS, BRYTHON_NOTIFICATION_EVENT, CLOSE_TURTLE_MODAL_EVENT, TURTLE_IMPORTS_TESTER, GRAPHICS_OUTPUT_TESTER, CANVAS_OUTPUT_TESTER, GRID_IMPORTS_TESTER, TURTLE3D_IMPORTS_TESTER };
//# sourceMappingURL=constants.d.ts.map