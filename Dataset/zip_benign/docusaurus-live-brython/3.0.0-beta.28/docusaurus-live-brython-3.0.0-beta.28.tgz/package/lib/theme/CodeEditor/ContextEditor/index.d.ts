import React from 'react';
import { type MetaProps } from '@theme/CodeEditor';
interface Props extends MetaProps {
    className?: string;
    title?: string;
    children: string | React.ReactNode;
    onChange?: (code: string) => void;
}
export declare const splitCode: (rawCode: string) => {
    pre: string;
    code: string;
    post: string;
};
/**
 * Use this component when you want a working CodeEditor.
 * The CodeEditor must be wrapped in a ScriptContext - this component does that.
 * wraps it in a ScriptContext and initializes the CodeEditor with the given
 * params.
 */
declare const ContextEditor: (props: Props) => React.JSX.Element;
export default ContextEditor;
//# sourceMappingURL=index.d.ts.map