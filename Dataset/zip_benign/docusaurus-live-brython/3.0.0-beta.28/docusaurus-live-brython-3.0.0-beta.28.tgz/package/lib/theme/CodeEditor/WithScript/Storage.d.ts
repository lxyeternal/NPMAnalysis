import type { StorageSlot, StoredScript } from '@theme/CodeEditor/WithScript/Types';
export declare const getStorageScript: (storage: StorageSlot) => StoredScript | undefined;
export declare const syncStorageScript: (script: StoredScript, storage: StorageSlot) => boolean;
//# sourceMappingURL=Storage.d.ts.map