type PinchZoomAllEventHandler = (target: PinchZoomAll, event: TouchEvent) => void;

interface IPinchZoomAllOptions {
    tapZoomFactor?: number;
    zoomOutFactor?: number;
    animationDuration?: number;
    maxZoom?: number;
    minZoom?: number;
    draggableUnzoomed?: boolean;
    lockDragAxis?: boolean;
    setOffsetsOnce?: boolean;
    use2d?: boolean;
    isPreventDefault?: boolean;
    isDoubleTapZoomIn?: boolean;
    verticalPadding?: number;
    horizontalPadding?: number;

    onZoomStart?: PinchZoomAllEventHandler;
    onZoomEnd?: PinchZoomAllEventHandler;
    onZoomUpdate?: PinchZoomAllEventHandler;
    onDragStart?: PinchZoomAllEventHandler;
    onDragEnd?: PinchZoomAllEventHandler;
    onDragUpdate?: PinchZoomAllEventHandler;
    onDoubleTap?: PinchZoomAllEventHandler;

    zoomStartEventName?: string;
    zoomUpdateEventName?: string;
    zoomEndEventName?: string;
    dragStartEventName?: string;
    dragUpdateEventName?: string;
    dragEndEventName?: string;
    doubleTapEventName?: string;
}

declare class PinchZoomAll {
    constructor(element: HTMLElement, options?: IPinchZoomAllOptions);
    public enable(): void;
    public disable(): void;
}

export default PinchZoomAll;
