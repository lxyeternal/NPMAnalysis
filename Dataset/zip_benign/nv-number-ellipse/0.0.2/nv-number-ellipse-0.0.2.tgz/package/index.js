//https://stackoverflow.com/questions/197649/how-to-calculate-center-of-an-ellipse-by-two-points-and-radius-sizes
const {Vector,Matrix} = require("sylvester");

const $M = Matrix.create;
const $V = Vector.create;

function rad_to_deg(r) {
    const d = Math.acos(r) * 180 / Math.PI;
    return(d)
}

function deg_to_rad(deg) {
    const r = Math.cos( deg * Math.PI /180);
    return(r)
}


function calc_cxcy(
    start_x,start_y,
    rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
    end_x,end_y
) {
    let x1 = start_x; 
    let y1 = start_y;
    let x2 = end_x;
    let y2 = end_y;
    ////
    let fA  = large_arc_flag;
    let fS  = sweep_flag;
    let phi = x_axis_rotation;
    ////
    let M = $M([
        [ Math.cos(phi), Math.sin(phi)],
        [-Math.sin(phi), Math.cos(phi)]
    ]);
    ////
    let V = $V( [ (x1-x2)/2, (y1-y2)/2 ] );
    let P = M.multiply(V);
    let x1p = P.e(1);
    let y1p = P.e(2);
    ////Ensure radii are large enough
    rx = Math.abs(rx);
    ry = Math.abs(ry);
    ////Step (c): Ensure radii are large enough
    let lambda = ( (x1p * x1p) / (rx * rx) ) + ( (y1p * y1p) / (ry * ry) );
    if(lambda > 1)
    {
        rx = Math.sqrt(lambda) * rx;
        ry = Math.sqrt(lambda) * ry;
    }
    ////Compute (cx′, cy′)
    let sign = (fA == fS)? -1 : 1;
    let co;
    if((( (rx*rx*ry*ry) - (rx*rx*y1p*y1p) - (ry*ry*x1p*x1p) ) / ( (rx*rx*y1p*y1p) + (ry*ry*x1p*x1p) )) < 1e-7) {
         co = 0;
    } else {
         co = sign * Math.sqrt( ( (rx*rx*ry*ry) - (rx*rx*y1p*y1p) - (ry*ry*x1p*x1p) ) / ( (rx*rx*y1p*y1p) + (ry*ry*x1p*x1p) ) );
    }
    ////
    V = $V( [rx*y1p/ry, -ry*x1p/rx] );
    let Cp = V.multiply(co);
    // Step 3: Compute (cx, cy) from (cx′, cy′)
    M = $M([
               [ Math.cos(phi), -Math.sin(phi)],
               [ Math.sin(phi),  Math.cos(phi)]
            ]);
    V = $V( [ (x1+x2)/2, (y1+y2)/2 ] );
    C = M.multiply(Cp).add(V);
    Cx = C.e(1);
    Cy = C.e(2);
    return([Cx,Cy])
}

function _sample_eng(
    via,
    cx,cy,
    start_x,start_y,
    rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
    end_x,end_y
) {
    let rxrx = (rx**2);
    let ryry = (ry**2);
    let A = rxrx * ryry;
    let _f;
    if(via==='x') {
        _f = (x)=> {
            let B = A-((x-cx)**2)*ryry;
            B = B / rxrx;
            B = Math.abs(B);
            B = Math.sqrt(B);
            let pB =  B;
            let nB = -B;
            let py = pB+cy;
            let ny = nB+cy;
            if(sweep_flag===1) {
                return(ny)
            } else {
                return(py)
            }
        }
    } else if(via==='y') {
        _f = (y)=> {
            let B = A-((y-cy)**2)*rxrx;
            B = B / ryry;
            B = Math.abs(B);
            B = Math.sqrt(B);
            let pB =  B;
            let nB = -B;
            let px = pB+cx;
            let nx = nB+cx;
            if(sweep_flag===1) {
                return(nx)
            } else {
                return(px)
            }
        }
    } else {
    }
    return(_f)
}

function _sample_via_x(
    count,
    cx,cy,
    start_x,start_y,
    rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
    end_x,end_y
) {
    let xs = Array.from({length:count});
    let diff = (end_x - start_x)/count;
    xs = xs.map((r,i)=>start_x+diff*i);
    let _f = _sample_eng(
        'x',
        cx,cy,
        start_x,start_y,
        rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
        end_x,end_y
    );
    let ys = xs.map(x=>_f(x));
    let pts = xs.map((x,i)=>[x,ys[i]]);
    pts.push([end_x,end_y])
    return(pts)
}


function _sample_via_y(
    count,
    cx,cy,
    start_x,start_y,
    rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
    end_x,end_y
) {
    let ys = Array.from({length:count});
    let diff = (end_y - start_y)/count;
    ys = ys.map((r,i)=>start_y+diff*i);
    let _f = _sample_eng(
        'y',
        cx,cy,
        start_x,start_y,
        rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
        end_x,end_y
    );
    let xs = ys.map(y=>_f(y));
    let pts = xs.map((x,i)=>[x,ys[i]]);
    pts.push([end_x,end_y])
    return(pts)
}

function sample(
    count,
    start_x,start_y,
    rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
    end_x,end_y    
) {
    let [cx,cy] = calc_cxcy(
        start_x,start_y,
        rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
        end_x,end_y
    );
    let x_pts = _sample_via_x(
        count,
        cx,cy,
        start_x,start_y,
        rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
        end_x,end_y
    );
    let y_pts = _sample_via_y(
        count,
        cx,cy,
        start_x,start_y,
        rx,ry,x_axis_rotation,large_arc_flag,sweep_flag,
        end_x,end_y
    );
    if(sweep_flag===1) {
        return(y_pts.concat(x_pts))
    } else {
        return(x_pts.concat(y_pts))
    }
}


module.exports = {
   rad_to_deg,
   deg_to_rad,
   calc_cxcy,
   _sample_eng,
   _sample_via_x,
   _sample_via_y, 
   sample, 
}
