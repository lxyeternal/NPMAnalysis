import { BaseElement } from '@emanon/shared/components/base';
import { customElement } from '@emanon/shared/decorators/custom-element';
import { when } from '@emanon/shared/directives/when';
import { html, property } from 'lit-element';
import { style } from './index.gen.css';

const delay = (ms: number) =>
  new window.Promise(resolve => window.setTimeout(resolve, ms));

/**
 * @cssprop [--ema-c-drawer-containerSize=30%] Container size.
 * @cssprop [--ema-c-drawer-containerMaxSize=auto] Container max size.
 * @cssprop [--ema-c-drawer-containerRadius=0] Container Radius.
 * @cssprop [--ema-c-drawer-containerBGColor=#fff] Container background color.
 * @cssprop [--ema-c-drawer-overlayColor=#80888f] Overlay color.
 * @cssprop [--ema-c-drawer-overlayOpacity=0.5] Ovaerlay opacity.
 * @cssprop [--ema-c-drawer-duration=300ms] Length of transition time.
 * @cssprop [--ema-c-drawer-diff=100px] Transform length.
 */

@customElement('ema-drawer')
export class Drawer extends BaseElement {
  /** Whether showing or not. */
  @property({ type: Boolean, reflect: true })
  opened = false;

  /** Position where to show on the window. */
  @property({ type: String, reflect: true })
  placement: 'top' | 'right' | 'bottom' | 'left' = 'left';

  /** Clicking outside of the element will not deactivate it. */
  @property({ type: Boolean, reflect: true })
  persistent = false;

  static get styles() {
    return [super.styles, style];
  }

  constructor() {
    super();
  }

  firstUpdated() {
    if (!this.shadowRoot) {
      return;
    }
    const container = this.shadowRoot.querySelector('.container');
    if (!container) {
      return;
    }
    container.addEventListener('transitionend', (e: Event) => {
      if (!(e instanceof TransitionEvent)) {
        return;
      }
      if (e.propertyName !== 'transform' || !this.opened) {
        return;
      }
      /** Fires when Drawer has opened. */
      this.dispatchEvent(
        new CustomEvent('opened', { detail: {}, bubbles: true, composed: true })
      );
    });
  }

  render() {
    const { placement } = this;
    return html`
      <div class="overlay" @tap=${this.handleOverlayTap}></div>
      <div class="container">
        ${when(
          placement === 'bottom' || placement === 'right',
          () => html`
            <div class="ctrl"><slot name="ctrl"></slot></div>
          `
        )}
        <div class="body"><slot name="body"></slot></div>
        ${when(
          placement === 'top' || placement === 'left',
          () => html`
            <div class="ctrl"><slot name="ctrl"></slot></div>
          `
        )}
      </div>
    `;
  }

  close() {
    window.Promise.resolve()
      .then(() => {
        this.opened = false;
      })
      // TODO: Use custom property's value as delay ms.
      .then(() => delay(300))
      .then(() => {
        /** Fires when the drawer has closed. */
        this.dispatchEvent(
          new CustomEvent('close', {
            detail: {},
            bubbles: true,
            composed: true
          })
        );
      });
  }

  private handleOverlayTap() {
    if (this.persistent) {
      return;
    }
    /**
     * Fires when the drawer want to be closed.
     * Call the function passed to accept.
     */
    this.dispatchEvent(
      new CustomEvent('request-close', {
        detail: {
          accept: () => {
            this.close();
          }
        },
        bubbles: true,
        composed: true
      })
    );
  }
}
