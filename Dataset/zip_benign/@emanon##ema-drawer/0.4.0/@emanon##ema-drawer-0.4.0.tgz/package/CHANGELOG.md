# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.4.0](https://github.com/cam-inc/emanon/compare/@emanon/ema-drawer@0.3.1...@emanon/ema-drawer@0.4.0) (2021-01-28)


### Bug Fixes

* opened ([7183390](https://github.com/cam-inc/emanon/commit/71833907c7902e52fe19591c7b76c663ea09e5d0))


### Features

* persistent property ([8c961f4](https://github.com/cam-inc/emanon/commit/8c961f490deaf29f26af9f4ec01c0ac2d713445d))





# [0.2.0](https://github.com/cam-inc/emanon/compare/@emanon/ema-drawer@0.1.0...@emanon/ema-drawer@0.2.0) (2020-12-01)


### Bug Fixes

* decoraotor ([f736973](https://github.com/cam-inc/emanon/commit/f736973bff29ae39ed30a3122dcb13aa1b395e5a))


### Features

* typescript ([08d1d92](https://github.com/cam-inc/emanon/commit/08d1d9255f0cabe100b3a52637f7faae0466db69))





# [0.1.0](https://github.com/cam-inc/emanon/compare/@emanon/ema-drawer@0.0.19...@emanon/ema-drawer@0.1.0) (2020-11-26)


### Bug Fixes

* property name ([8c3c04e](https://github.com/cam-inc/emanon/commit/8c3c04e73530d81b3797a465272ba4fe7c7dfae8))


### Features

* convert drawer to typescript ([7a98999](https://github.com/cam-inc/emanon/commit/7a98999f92f1f039a09e535d78a0dacd236c9627))





## [0.0.19](https://github.com/cam-inc/emanon/compare/@emanon/ema-drawer@0.0.18...@emanon/ema-drawer@0.0.19) (2020-11-18)


### Bug Fixes

* build settings" ([cc47b20](https://github.com/cam-inc/emanon/commit/cc47b205759cc9e4b644cb7c043cb36f2c241e38))





## [0.0.18](https://github.com/cam-inc/emanon/compare/@emanon/ema-drawer@0.0.17...@emanon/ema-drawer@0.0.18) (2020-11-06)

**Note:** Version bump only for package @emanon/ema-drawer





## 0.0.17 (2020-10-23)


### Bug Fixes

* build settings ([abec4ec](https://github.com/cam-inc/emanon/commit/abec4ec450942920c9e6ce3182d9ee1a88072894))
* readme.md ([d0b5a62](https://github.com/cam-inc/emanon/commit/d0b5a62fa2a1003d65fdaf4b2b9e336dce33eeae))
