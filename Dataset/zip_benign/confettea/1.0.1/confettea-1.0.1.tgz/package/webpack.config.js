const path = require('path');

module.exports = {
  entry: './src/confettea.js',
  output: {
    filename: 'confettea.js',
    path: path.resolve(__dirname, 'dist'),
    library: 'confettea',
    libraryTarget: 'umd',
    globalObject: 'this'
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      }
    ]
  }
};