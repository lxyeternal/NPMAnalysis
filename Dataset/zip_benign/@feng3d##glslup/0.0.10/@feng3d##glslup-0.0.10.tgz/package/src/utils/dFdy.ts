export function dFdy(code: string)
{
    let newCode = code;

    // 替换 'dFdy(' 为 '-dFdy('。 GLSL中'dFdy'翻译为WGSL中为'dpdy',结果正好相反，需要添加负号。
    newCode = newCode.replace(/\bdFdy\s*\(/g, '-$&');

    return newCode;
}
