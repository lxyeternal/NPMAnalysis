export function getCodeVersion(code: string): '100' | '300' | '450'
{
    if (code.includes(`#version 300`)) return '300';
    if (code.includes(`#version 450`)) return '450';

    return '100';
}
