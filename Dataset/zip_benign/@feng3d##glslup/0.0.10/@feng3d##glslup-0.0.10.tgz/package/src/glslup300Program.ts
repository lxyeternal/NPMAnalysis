import { IGlslProgram } from './IGlslProgram';
import { glslup300 } from './glslup300';

/**
 * 升级 glsl100 着色程序到 glsl300，包含顶点与片元着色器源码。
 */
export function glslup300Program(program: IGlslProgram)
{
    const vertex = glslup300(program.vertex);
    const fragment = glslup300(program.fragment);

    return { vertex: vertex.code, fragment: fragment.code };
}
