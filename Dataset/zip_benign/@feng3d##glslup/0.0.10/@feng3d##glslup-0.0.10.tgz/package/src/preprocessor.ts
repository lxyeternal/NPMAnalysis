import { preprocessor as compile } from '@feng3d/c-preprocessor';

/**
 * 预处理 GLSL 代码。
 *
 * 将会处理 #define #ifdef #if 等宏定义
 *
 * @param glsl GLSL代码
 * @returns 处理后的GLSL代码。
 */
export function preprocessor(glsl: string)
{
    const nameMatch = glsl.match(shaderNameReg);

    let result = compile(glsl);

    // 保留着色器定义宏
    if (nameMatch)
    {
        result = `${nameMatch[0]}\n${result}`;
    }

    return result;
}

/** 着色器名称匹配 */
const shaderNameReg = new RegExp(/#define\s+SHADER_NAME\s+[\w:]+/);
