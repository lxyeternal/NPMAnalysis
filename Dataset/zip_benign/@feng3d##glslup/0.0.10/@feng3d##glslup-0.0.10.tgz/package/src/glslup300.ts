import { getCodeVersion } from './getCodeVersion';
import { glsl100ToGlsl300 } from './glsl100ToGlsl300';

/**
 * Upgrade GLSL 100 to GLSL 300.
 *
 * @param code - The GLSL100 code.
 *
 */
export function glslup300(code: string)
{
    const version = getCodeVersion(code);

    if (version !== '100') return { code };

    const result = glsl100ToGlsl300(code);

    return { code: result };
}
