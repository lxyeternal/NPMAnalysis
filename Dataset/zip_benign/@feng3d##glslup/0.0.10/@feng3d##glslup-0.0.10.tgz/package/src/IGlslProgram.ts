import { IShaderLayoutInfo } from './IShaderLayoutInfo';

/**
 * GLSL 着色程序
 */
export interface IGlslProgram
{
    /**
     * 顶点着色器。
     */
    vertex: string;

    /**
     * 片元着色器。
     */
    fragment: string;

    /**
     * layout 信息。
     */
    layoutInfo?: IShaderLayoutInfo;
}
