/**
 * 判断是否为 glsl100 顶点着色器代码。
*
* @param code glsl100 着色器代码。
*/
export function isGlslVertex(code: string)
{
    const regExpMatchArray = code.match(glslVertexRegExp);

    return !!regExpMatchArray;
}

const glslVertexRegExp = new RegExp(/gl_Position/);

