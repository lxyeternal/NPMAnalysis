import { IGlslProgram } from './IGlslProgram';
import { glslup450 } from './glslup450';

/**
 * 升级 glsl100/glsl300 着色程序到 glsl450，包含顶点与片元着色器源码。
 *
 * @param program glsl100/glsl300 格式的着色程序。
 * @returns
 */
export function glslup450Program(program: IGlslProgram)
{
    const vertex = glslup450(program.vertex, program.layoutInfo);
    const fragment = glslup450(program.fragment, vertex.layoutInfo);

    return { vertex: vertex.code, fragment: fragment.code, layoutInfo: fragment.layoutInfo };
}
