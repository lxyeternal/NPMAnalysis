import { IShaderLayoutInfo } from './IShaderLayoutInfo';
import { getCodeVersion } from './getCodeVersion';
import { glsl100ToGlsl300 } from './glsl100ToGlsl300';
import { glsl300ToGlsl450 } from './glsl300ToGlsl450';

/**
 * 默认把 glsl100 或者 glsl300 升级为 glsl450.
 *
 * @param code glsl着色器代码。
 * @returns 升级后的glsl450着色器代码。
 */
export function glslup450(code: string, layoutInfo?: IShaderLayoutInfo)
{
    const version = getCodeVersion(code);

    if (version === '450') return { code } as { code: string; layoutInfo: IShaderLayoutInfo; };

    let glsl300 = code;

    if (version === '100')
    {
        glsl300 = glsl100ToGlsl300(glsl300);
    }

    const result = glsl300ToGlsl450(glsl300, undefined, layoutInfo, true);

    return result;
}

