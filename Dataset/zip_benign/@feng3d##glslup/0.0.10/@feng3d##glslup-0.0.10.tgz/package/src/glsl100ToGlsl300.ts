import { isGlslVertex } from './isGlsl100';
import { preprocessor } from './preprocessor';

/**
 * 顶点着色器 glsl100 转换 glsl300。
 */
const vertexHead = `
#define attribute in
#define varying out
#define textureCube texture
#define texture2D texture
`;

/**
 * 片段着色器 glsl100 转换 glsl300。
 */
const fragmentHead = `
#define varying in
out highp vec4 pc_fragColor;
#define gl_FragColor pc_fragColor
#define gl_FragDepthEXT gl_FragDepth
#define texture2D texture
#define textureCube texture
#define texture2DProj textureProj
#define texture2DLodEXT textureLod
#define texture2DProjLodEXT textureProjLod
#define textureCubeLodEXT textureLod
#define texture2DGradEXT textureGrad
#define texture2DProjGradEXT textureProjGrad
#define textureCubeGradEXT textureGrad
`;

/**
 * glsl100 升级 glsl300 需要的改动
 *
*
* @see https://www.cnblogs.com/OctoptusLian/p/9909170.html
*/

/**
 * 升级 glsl100 版本的着色器代码为 glsl300。
 *
 * 1. 顶点着色器
 *      1. 关键字 `attribute` 替换为 `in` 。
 *      2. 关键字 `varying` 替换为 `out`。
 *
 * 2. 片元着色器
 *      1. 关键字 `varying` 替换为 `in` 。
 *
 * @param code100 glsl100版本着色器代码。
 */
export function glsl100ToGlsl300(code100: string)
{
    let code300: string;
    if (isGlslVertex(code100))
    {
        code300 = preprocessor(vertexHead + code100);
    }
    else
    {
        code300 = preprocessor(fragmentHead + code100);
    }

    code300 = `#version 300 es\n${code300}`;

    return code300;
}

