import { Program } from '@shaderfrog/glsl-parser/ast';
/**
 * 删除未被使用的 函数、Uniform、属性。
 *
 * @param program
 */
export declare function removeUnuse(program: Program): Program;
//# sourceMappingURL=removeUnuse.d.ts.map