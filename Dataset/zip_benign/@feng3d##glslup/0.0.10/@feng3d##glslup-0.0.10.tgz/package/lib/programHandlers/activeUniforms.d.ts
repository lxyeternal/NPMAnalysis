import { Program } from '@shaderfrog/glsl-parser/ast';
import { IShaderLayoutInfo } from '../IShaderLayoutInfo';
/**
 * 获取 activeUniforms 。
 *
 * @param program 语法树。
 */
export declare function activeUniforms(program: Program, options: IShaderLayoutInfo): void;
//# sourceMappingURL=activeUniforms.d.ts.map