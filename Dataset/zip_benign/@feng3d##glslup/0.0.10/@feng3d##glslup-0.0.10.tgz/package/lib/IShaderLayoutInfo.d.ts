/**
 * 顶点输入属性名称与 location 对应关系。
 */
export type IVertexInLayout = {
    locations: string[];
    vertexIns: {
        [name: string]: number;
    };
};
/**
 * 顶点着色器到片元着色器变量布局信息。
 */
export type IVaryingLayout = {
    locations: string[];
    varyings: {
        [name: string]: number;
    };
};
/**
 * 片元着色器输出属性布局信息。
 */
export type IFagmentOutLayout = {
    locations: string[];
    fagmentOuts: {
        [name: string]: number;
    };
};
/**
 * Unifrom 与 set/bingding 对应关系。
 */
export type IUniformLayout = {
    /**
     * 默认把收集到的 Uniform 放置 set 位置。
     */
    defaultSet: number;
    /**
     * set/bingding 存储的 Unifrom 名称。
     */
    set: string[][];
    /**
     * Unifrom 名称 对应 set/bingding 值。
     */
    map: {
        [name: string]: {
            set: number;
            binding: number;
        };
    };
    /**
     * 结构体类型与名称映射。
     */
    structType: {
        [StructType: string]: string;
    };
};
/**
 * 着色器布局信息。
 */
export interface IShaderLayoutInfo {
    /**
     * 顶点着色器输入属性布局信息。
     */
    vertexIn: IVertexInLayout;
    /**
     * 顶点着色器到片元着色器变量布局信息。
     */
    varying: IVaryingLayout;
    /**
     * 片元着色器输出属性布局信息。
     */
    fagmentOut: IFagmentOutLayout;
    /**
     * Uniform 布局信息。
     */
    uniform: IUniformLayout;
    /**
     * 把顶点着色器单独的 Unifrom 放入该名称的 UBO 中。
     */
    LeftOverVSUBOName: string;
    /**
     * 把片元着色器单独的 Unifrom 放入该名称的 UBO 中。
     */
    LeftOverFSUBOName: string;
    /**
     * 激活的 Uniform 列表。
     */
    activeUniforms: {
        name: string;
        size: number;
        type: 'texture2D' | 'bool' | 'int' | 'float' | 'vec2' | 'vec3' | 'vec4' | 'mat4';
    }[];
}
//# sourceMappingURL=IShaderLayoutInfo.d.ts.map