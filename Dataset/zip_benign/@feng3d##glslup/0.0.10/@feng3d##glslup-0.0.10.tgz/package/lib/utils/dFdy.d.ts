export declare function dFdy(code: string): string;
//# sourceMappingURL=dFdy.d.ts.map