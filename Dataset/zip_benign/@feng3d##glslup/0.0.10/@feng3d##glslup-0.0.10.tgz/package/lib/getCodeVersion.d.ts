export declare function getCodeVersion(code: string): '100' | '300' | '450';
//# sourceMappingURL=getCodeVersion.d.ts.map