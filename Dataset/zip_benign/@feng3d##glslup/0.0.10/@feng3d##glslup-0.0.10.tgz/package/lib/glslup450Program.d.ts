import { IGlslProgram } from './IGlslProgram';
/**
 * 升级 glsl100/glsl300 着色程序到 glsl450，包含顶点与片元着色器源码。
 *
 * @param program glsl100/glsl300 格式的着色程序。
 * @returns
 */
export declare function glslup450Program(program: IGlslProgram): {
    vertex: string;
    fragment: string;
    layoutInfo: import("./IShaderLayoutInfo").IShaderLayoutInfo;
};
//# sourceMappingURL=glslup450Program.d.ts.map