import { IShaderLayoutInfo } from './IShaderLayoutInfo';
/**
 * 默认把 glsl100 或者 glsl300 升级为 glsl450.
 *
 * @param code glsl着色器代码。
 * @returns 升级后的glsl450着色器代码。
 */
export declare function glslup450(code: string, layoutInfo?: IShaderLayoutInfo): {
    code: string;
    layoutInfo: IShaderLayoutInfo;
};
//# sourceMappingURL=glslup450.d.ts.map