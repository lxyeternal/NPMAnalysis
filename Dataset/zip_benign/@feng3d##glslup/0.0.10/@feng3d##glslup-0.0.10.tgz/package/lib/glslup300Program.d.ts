import { IGlslProgram } from './IGlslProgram';
/**
 * 升级 glsl100 着色程序到 glsl300，包含顶点与片元着色器源码。
 */
export declare function glslup300Program(program: IGlslProgram): {
    vertex: string;
    fragment: string;
};
//# sourceMappingURL=glslup300Program.d.ts.map