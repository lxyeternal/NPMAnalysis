/**
 * Upgrade GLSL 100 to GLSL 300.
 *
 * @param code - The GLSL100 code.
 *
 */
export declare function glslup300(code: string): {
    code: string;
};
//# sourceMappingURL=glslup300.d.ts.map