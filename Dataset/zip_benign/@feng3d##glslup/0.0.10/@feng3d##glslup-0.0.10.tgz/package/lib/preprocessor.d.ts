/**
 * 预处理 GLSL 代码。
 *
 * 将会处理 #define #ifdef #if 等宏定义
 *
 * @param glsl GLSL代码
 * @returns 处理后的GLSL代码。
 */
export declare function preprocessor(glsl: string): string;
//# sourceMappingURL=preprocessor.d.ts.map