/**
 * glsl100 升级 glsl300 需要的改动
 *
*
* @see https://www.cnblogs.com/OctoptusLian/p/9909170.html
*/
/**
 * 升级 glsl100 版本的着色器代码为 glsl300。
 *
 * 1. 顶点着色器
 *      1. 关键字 `attribute` 替换为 `in` 。
 *      2. 关键字 `varying` 替换为 `out`。
 *
 * 2. 片元着色器
 *      1. 关键字 `varying` 替换为 `in` 。
 *
 * @param code100 glsl100版本着色器代码。
 */
export declare function glsl100ToGlsl300(code100: string): string;
//# sourceMappingURL=glsl100ToGlsl300.d.ts.map