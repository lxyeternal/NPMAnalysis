import { IShaderLayoutInfo } from './IShaderLayoutInfo';
/**
 * 把顶点着色器单独的 Unifrom 放入该名称的 UBO 中。
 */
export declare const LeftOverVSUBOName = "LeftOverVSUBO";
/**
 * 把片元着色器单独的 Unifrom 放入该名称的 UBO 中。
 */
export declare const LeftOverFSUBOName = "LeftOverFSUBO";
/**
 * 升级 glsl300 版本的着色器代码为 glsl450。
 *
 * 1. 顶点片元着色器共同
 *      1. 450版本 绑定资源 只允许 UBO sampler image ，需要把单独的 unifrom 转换为 UBO 结构。
 *      2. 纹理 `samplerCube` `` 需要 纹理采样器分离。
 *          glsl300
 *          ```
 *              uniform samplerCube reflectionSampler;
 *              ...
 *              vec4 reflectionSample = textureCube(reflectionSampler, reflectionCoords);
 *          ```
 *          glsl450
 *          ```
 *              layout(set = 1, binding = 5) uniform sampler reflectionSamplerSampler;
                layout(set = 1, binding = 4) uniform textureCube reflectionSamplerTexture;
 *              ...
 *              vec4 reflectionSample = texture(samplerCube(reflectionSamplerTexture, reflectionSamplerSampler), reflectionCoords);
 *          ```
 *      3. 'sampler constructor must appear at point of use' 采样器构造函数必须在使用时出现。因此在传入采样器的函数需要使用内联方式，在预编译时进行展开来实现`采样器构造函数必须在使用时出现`。
 *
 * 2. 顶点着色器
 *      1. 为输入属性 `in` 添加 `layout` 如果没有的话。例如 `layout(location = 0) in vec3 position;` 。
 *      2. 为输出属性 `out` 添加 `layout` 。 例如 `layout(location = 0)  out vec3 vPositionW;` 。
 *      3. 为 `uniform` 新增 `layout` 。 例如 `layout(set = 0, binding = 0) uniform vec4 vPrimaryColor;` 。
 *
 * 3. 片元着色器
 *      1. 为输入属性 `in` 添加 `layout` 。 例如 `layout(location = 0)  in vec3 vPositionW;`; 注：与顶点着色器`out`的相同属性需要拥有相同的 `location` 值。
 *      2. 为输出颜色属性 `out` 添加 `layout` 如果没有的话。 例如 `layout(location = 0) out vec4 glFragColor;` 。
 *      3. 为 `uniform` 新增 `layout` 。 例如 `layout(set = 0, binding = 0) uniform vec4 vPrimaryColor;` 。注：与顶点着色器`uniform`的相同属性需要拥有相同的`set`与`binding`值。
 *
 *
 * @param code100 glsl100版本着色器代码。
 *
 * @see Babylon.js WebGPUEngine.inlineShaderCode
 */
export declare function glsl300ToGlsl450(code300: string, isVertex?: boolean, layoutInfo?: IShaderLayoutInfo, isDeleteUnuse?: boolean): {
    code: string;
    layoutInfo: IShaderLayoutInfo;
};
//# sourceMappingURL=glsl300ToGlsl450.d.ts.map