/**
 * 判断是否为 glsl100 顶点着色器代码。
*
* @param code glsl100 着色器代码。
*/
export declare function isGlslVertex(code: string): boolean;
//# sourceMappingURL=isGlsl100.d.ts.map