module.exports = function(grunt) {

  // Project configuration.
  //fs.readdirSync(path)
	
  /*var getDirectorys = new function (dirPath)
  {
	dirPath = dirPath ? dirPath : '/';
	var fileSys = require('fs');
	
	return fileSys.readdirSync(dirPath);
  };*/
  
  var handlebarsConfigBuilder = function(existingConfig)
  {
		var thisObj = existingConfig ? existingConfig : {};
		var fileSystem = require('fs');
		var plugins = fileSystem.readdirSync('plugins/');
		var jsDir;
		var handlebarsDir;
		for(var i = 0; i < plugins.length; i++)
		{
				var filesObj = {};
				var parentObj = {};
				jsDir = 'plugins/' + plugins[i] + '/' + plugins[i] + 'Handlebars.js';
				handlebarsDir = 'plugins/' + plugins[i] + '/handlebars/*.handlebars';
				filesObj[jsDir] = handlebarsDir;
				parentObj.files = filesObj
				thisObj[plugins[i]] = parentObj;
		}
		return thisObj;
	  };
	  
	  
 var sassConfigBuilder = function(existingConfig)
 {
		var thisObj = existingConfig ? existingConfig : {};
		var fileSystem = require('fs');
		var plugins = fileSystem.readdirSync('plugins/');
		var cssDir;
		var sassDir;
		var options = {style:'compressed'};
		for(var i = 0; i < plugins.length; i++)
		{
			var filesObj = {};
			var parentObj = {};
			cssDir = 'plugins/' + plugins[i] + '/' + plugins[i] + '.css';
			sassDir = 'plugins/' + plugins[i] + '/*.scss';
			filesObj[cssDir] = sassDir;
			parentObj.files = filesObj;
			parentObj.options = options;
			thisObj[plugins[i]] = parentObj;
		}
		return thisObj;
  };
  
  
  var copyConfigBuilder = function(existingConfig, htdocsPath, isDev, isWatch)
  {
	  	var thisObj = existingConfig ? existingConfig : {};
		var fileSystem = require('fs');
		var plugins = fileSystem.readdirSync('plugins/');
		if(isWatch)
		{
			for(var i = 0; i < plugins.length; i++)
			{
				var configObj = {};
				configObj.cwd = 'plugins/' + plugins[i];
				configObj.src = [ plugins[i] + '.editor.js', 'packageinfo.json'];
				configObj.dest = htdocsPath + '/plugins/' + plugins[i];
				configObj.expand = true;
				thisObj[plugins[i]] = configObj;
			}
		}
		else
		{
			if(isDev)
			{
				thisObj['img'] = {
											cwd: 'img',
											src: ['**'],
											dest: htdocsPath + '/img',
											expand: true
								};
				thisObj['js'] = {
									cwd: 'js',
									src: ['**'],
									dest: htdocsPath + '/js',
									expand: true
								};
				thisObj['localImg'] = {
											cwd: 'img',
											src: ['**'],
											dest: 'bin/img',
											expand: true
									};
				thisObj['localJs'] = {
									cwd: 'js',
									src: ['**'],
									dest: 'bin/js',
									expand: true
								};
				for(var i = 0; i < plugins.length; i++)
				{
					var configObj = {};
					configObj.cwd = 'bin/plugins/' + plugins[i]
					configObj.src = ['**'];
					configObj.dest = htdocsPath + '/plugins/'+plugins[i];
					configObj.expand = true;
					thisObj[plugins[i]+'Dev'] = configObj;
				}
			}
			else
			{
				thisObj['localImg'] = {
											cwd: 'img',
											src: ['**'],
											dest: 'bin/img',
											expand: true
									};
				thisObj['localJs'] = {
										cwd: 'js',
										src: ['**'],
										dest: 'bin/js',
										expand: true
									};
				for(var i = 0; i < plugins.length; i++)
				{
					var configObj = {};
					configObj.cwd = 'plugins/' + plugins[i]
					configObj.src = [ plugins[i] + '.editor.js', 'packageinfo.json'];
					configObj.dest = 'bin/plugins/' + plugins[i];
					configObj.expand = true;
					thisObj[plugins[i]] = configObj;
				}
			}
		}
		return thisObj;
  };
  
  
  var concatConfigBuilder = function(existingConfig, htdocsPath, isWatch, isMocha)
  {
	  var thisObj = existingConfig ? existingConfig : {};
	  var fileSystem = require('fs');
	  var plugins = fileSystem.readdirSync('plugins/');
	  if(isMocha)
	  {
		  	plugins = fileSystem.readdirSync('unittest/');
		  	var configObj = {};
		  	configObj.src = [];
		  	configObj.src.push('js/class.js');
		  	configObj.dest = 'bin/unittest/unittest.js';
			for(var i = 0; i < plugins.length; i++)
			{
				configObj.src.push('plugins/' + plugins[i] + '/' + plugins[i] + '.js');
				configObj.src.push('unittest/' + plugins[i] + '/' + plugins[i] + '.js');
			}
			thisObj['unittest'] = configObj;
		}
		if(isWatch)
		{
			for(var i = 0; i < plugins.length; i++)
			{
				var configObjJS = {};
				var configObjCSS = {};
				
				configObjJS.src = [
				             'plugins/' + plugins[i] + '/lib/js/*.js',
				             'plugins/' + plugins[i] + '/' + plugins[i] + '.js', 
				             'plugins/' + plugins[i] + '/' + plugins[i] + 'Handlebars.js', 
				             'plugins/' + plugins[i] + '/' + plugins[i] + 'Helper.js'
				             ];
				configObjJS.dest = htdocsPath + '/plugins/' + plugins[i] + '/' + plugins[i] + '.js';
				
				configObjCSS.src = [
				              'plugins/' + plugins[i] + '/lib/css/*.css',
				              'plugins/' + plugins[i] + '/' + plugins[i] + '.css'
				              ];
				configObjCSS.dest = htdocsPath + '/plugins/' + plugins[i] + '/' + plugins[i] + '.css';
				
				thisObj[plugins[i] + 'JS'] = configObjJS;
				thisObj[plugins[i] + 'CSS'] = configObjCSS;
				//grunt.log.writeln(existingConfig[plugins[i]+'JS'].dest/*grunt.config.get('concat:addToBagPopupJS')*/);
				
			}
		}
		else
		{
			for(var i = 0; i < plugins.length; i++)
			{
				var configObjJS = {};
				var configObjCSS = {};
				
				configObjJS.src = [
				             'plugins/' + plugins[i] + '/lib/js/*.js',
				             'plugins/' + plugins[i] + '/'+plugins[i] + '.js', 
				             'plugins/' + plugins[i] + '/'+plugins[i] + 'Handlebars.js', 
				             'plugins/' + plugins[i] + '/'+plugins[i] + 'Helper.js'
				             ];
				configObjJS.dest = 'bin/plugins/' + plugins[i] + '/'+plugins[i] + '.js';
				
				configObjCSS.src = [
				              'plugins/' + plugins[i] + '/lib/css/*.css',
				              'plugins/' + plugins[i] + '/' + plugins[i] + '.css'
				              ];
				configObjCSS.dest = 'bin/plugins/' + plugins[i] + '/' + plugins[i] + '.css';
				
				thisObj[plugins[i] + 'JS'] = configObjJS;
				thisObj[plugins[i] + 'CSS'] = configObjCSS;
				//grunt.log.writeln(existingConfig[plugins[i]+'JS'].dest/*grunt.config.get('concat:addToBagPopupJS')*/);
			}
		}
		return thisObj;   
  };
  
  
  var watchFilelistBuilder = function(type)
  {
	var fileSystem = require('fs');
	var plugins = fileSystem.readdirSync('plugins/');
	var outputArray = [];
	switch(type)
	{
		case 'js':
			for(var i = 0; i < plugins.length; i++)
			{
				outputArray.push('plugins/' + plugins[i] + '/lib/js/*.js');
				outputArray.push('plugins/' + plugins[i] + '/' + plugins[i] + '.js');
				outputArray.push('plugins/' + plugins[i] + '/' + plugins[i] + 'Handlebars.js');
				outputArray.push('plugins/' + plugins[i] + '/' + plugins[i] + 'Helper.js');
			}
		break;
		case 'utjs':
			plugins = fileSystem.readdirSync('unittest/');
			for(var i = 0; i < plugins.length; i++)
			{
				outputArray.push('unittest/' + plugins[i] + '/' + plugins[i] + '.js');
			}
		break;
		case 'css':
			for(var i=0; i < plugins.length; i++)
			{
				outputArray.push('plugins/' + plugins[i] + '/' + plugins[i] + '.css');
				outputArray.push('plugins/' + plugins[i] + '/lib/css/*.css');
			}
		break;
		case 'handlebars':
			for(var i=0; i < plugins.length; i++)
			{
				outputArray.push('plugins/' + plugins[i] + '/handlebars/*.handlebars');
			}
		break;
		case 'sass':
			//outputArray.push('compass/*.scss');
			//outputArray.push('randomDirectory/'+client+'/compass/sass/pages/*.scss');
			for(var i=0; i < plugins.length; i++)
			{
				outputArray.push('plugins/' + plugins[i] + '/*.scss');
			}
			
		break;
		case 'others':
			for(var i=0; i < plugins.length; i++)
			{
				outputArray.push('plugins/' + plugins[i] + '/packageinfo.json');
				outputArray.push('plugins/' + plugins[i] + '/' + plugins[i] + '.editor.js');
			}
		break;
	}
	return outputArray;
  };
  
  
  var zipConfigBuilder = function(existingConfig)
  {
	  var thisObj = existingConfig ? existingConfig : {};
	  var fileSystem = require('fs');
	  var plugins = fileSystem.readdirSync('plugins/');
	  //grunt.log.writeln(plugins);
	  for(var i = 0; i < plugins.length; i++)
	  {
		  var configObj = {};
		  configObj.cwd = 'bin/plugins/' + plugins[i] + '/';
		  configObj.dest = 'bin/zips/' + plugins[i] + '.zip';
		  configObj.src = 'bin/plugins/' + plugins[i] + '/**';
		  thisObj[plugins[i]] = configObj;
		  //grunt.log.writeln(obj.src);
	  }
	  return thisObj;
  };
  
  var uglifyConfigBuilder = function(existingConfig)
  {
	  var thisObj = existingConfig ? existingConfig : {};
	  var fileSystem = require('fs');
	  var plugins = fileSystem.readdirSync('plugins/');
	  for(var i = 0; i < plugins.length; i++)
	  {
		  var filesObj = {};
		  var parentObj = {};
		  srcDestDir = 'bin/plugins/' + plugins[i] + '/' + plugins[i] + '.js';
		  filesObj[srcDestDir] = srcDestDir;
		  parentObj.files = filesObj 
		  thisObj[plugins[i]] = parentObj;
	  }
	  return thisObj;
  };
  
  var cleanConfigBuilder = function(existingConfig)
  {
	  var thisObj = {};
	  var plugins = ['bin/plugins/**', 'bin/unittest/**'];
	  thisObj['plugins'] = plugins;
	  return thisObj;
  };
  
  var buildExistance = function()
  {
	  var fileSystem = require('fs');
	  if (fileSystem.existsSync('bin/')) 
	  { 
		  return true;
	  }
	  return false;
  };
  var mochaTestConfigBuilder = function()
  {
	  var fileSystem = require('fs');
	  var plugins = fileSystem.readdirSync('unittest/');
	  var testSrcArray = [];
	  for(i = 0; i < plugins.length ; i++)
	  {
		  testSrcArray[i] = 'bin/unittest/'+plugins[i]+'.js';
	  }
	  return testSrcArray;
  };
  
  var initConfig = {
			pkg: grunt.file.readJSON('package.json'),
			htdocsPath: "D:/Progs/ASF/Apache2.2/htdocs/skavainstoretemplate/v1",
			clean:{
				plugins: ['bin/**/**/**']
			},
			uglify : uglifyConfigBuilder(),
			handlebars: handlebarsConfigBuilder(),
			sass: sassConfigBuilder(),
			copy: copyConfigBuilder(null,'<%= htdocsPath %>',null,true),
			concat:	concatConfigBuilder(null,'<%= htdocsPath %>',true),
			replace: {
				  example: {
				    src: ['bin/unittest/*.js'],
				    dest: 'bin/unittest/',
				    replacements: [{
				      from: 'StudioWidget',
				      to: 'Class'
				    }]
				  }
			},
			mochaTest: {
				/*option: {
					timeout: 100,
					ignoreLeaks: true
				},*/ 
				test: {
				    src: 'bin/unittest/unittest.js'
				  }
			},
			zip: zipConfigBuilder(),
			watch: {
				javascript: {
					files: watchFilelistBuilder('js'),
					tasks: ["newer:concat"] 
				},
				unittestJs: {
					files: watchFilelistBuilder('utjs'),
					tasks: ['mochaUnitTest']
				},
				others: {
					files: watchFilelistBuilder('others'),
					tasks: ["newer:copy"]
				},
				handlebars: {
					files: watchFilelistBuilder('handlebars'),
					tasks: ["newer:handlebars"]
				},
				commonSass: {
					files: ['compass/*.scss'],
					tasks: ['sass'],
					options: {
						livereload: {
							port: 8080
						}
					}
				},
				pluginsSass:
				{
					files: watchFilelistBuilder('sass'),
					tasks: ["newer:sass"]
				},
				css: {
					files: watchFilelistBuilder('css'),
					tasks: ["newer:concat"]
				}
			}
	};
  
	grunt.config.init(initConfig);

	grunt.loadNpmTasks('grunt-contrib-uglify');
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.loadNpmTasks('grunt-newer');
	grunt.loadNpmTasks('grunt-handlebars-compiler');
	grunt.loadNpmTasks('grunt-sass');
	grunt.loadNpmTasks('grunt-contrib-clean');
	grunt.loadNpmTasks('grunt-contrib-copy');
	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-mocha-test');
	grunt.loadNpmTasks('grunt-zip');
	grunt.loadNpmTasks('grunt-text-replace');
	//grunt.loadNpmTasks('grunt-compile-handlebars');
	grunt.registerTask('default', function(){
		
		//grunt.task.run('clean');
		grunt.config.set('concat', concatConfigBuilder());
		grunt.config.set('copy', copyConfigBuilder());
		//grunt.task.run('mochaUnitTest');
		grunt.task.run(['commonBuild', 'uglify','zip']);
		grunt.config.set('clean', cleanConfigBuilder());
		grunt.task.run('clean');
	});
	grunt.registerTask('mochaUnitTest', function(){
		grunt.config.set('concat', concatConfigBuilder(null, null, null, true));
		grunt.task.run(['concat','replace','mochaTest']);	
	});
	grunt.registerTask('cleanup', function(){
		if(buildExistance())
		{
			grunt.task.run('clean');
		}
	});
	grunt.registerTask('commonBuild',['mochaUnitTest','cleanup','handlebars','sass', 'concat','copy']);
	grunt.registerTask('dev', function(){
		var htdocsPath = grunt.config.get('htdocsPath');
		grunt.config.set('concat', concatConfigBuilder());
		grunt.config.set('copy', copyConfigBuilder());
		grunt.config.set('copy', copyConfigBuilder(grunt.config.get('copy'), htdocsPath, true));
		grunt.config.set('clean', cleanConfigBuilder());
		grunt.task.run(['commonBuild', 'zip', 'clean', 'watch']);
		//grunt.task.run('clean');
	});
	
};