# @xinguang-data/bs-amap@0.3

## 使用

## 进度

| 参数名          | 类型   | 说明                                                         | 状态    |
| --------------- | ------ | ------------------------------------------------------------ | ------- |
| mapConfig       | Object | 地图初始所需配置信息                                         | 完成    |
| polygons        | Array  | 多边形覆盖物                                                 | 完成    |
| texts           | Array  | 纯文本标记覆盖物                                             | 完成    |
| markers         | Array  | 点标记覆盖物                                                 | 完成    |
| points          | Object | 海量点数据集                                                 |     |
| satellite       | Object | 卫星图层                                                     |     |
| heatmap         | Object | 热力图                                                       |     |
| infowindow      | Object | 信息窗口（气泡窗口仅支持一次显示一个）                       | 完成    |
| drawtools       | Object | 绘图工具，完成polygon、marker绘制                            |  |
| circles         | Array  | 圆覆盖物                                                     | 完成    |
| contextmenu     | Object | 菜单（通常右键触发）                                         |     |
| geocoder        | Object | 地理编码转换，完成 坐标->地址、地址->坐标                    | 完成    |
| geolocation     | Object | 定位插件，整合了浏览器定位、精确IP定位、sdk辅助定位多种手段  | 完成    |
| rectangles      | Array  | 矩形覆盖物                                                   |     |
| visual          |        |                                                              |         |
| markerclusterer | Object | 点聚合，展示大量的Marker点                                   |         |
| polylines       | Array  | 折线覆盖物                                                   |     |
| autocomplete    | Object | 地点搜索服务，提供某一特定地区的位置查询服务。               | 完成    |
| poipicker       | Object | PoiPicker（POI选点）在给定的输入框上集成输入提示和关键字搜索功能，方便用户选取特定地点。 | 完成    |
