export default revolve;
declare function revolve(path: any, numSteps?: number, angle?: number): {
    positions: any;
    cells: any;
};
