"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
var content_view_1 = require("tns-core-modules/ui/content-view");
var profiling_1 = require("tns-core-modules/profiling");
__export(require("tns-core-modules/ui/content-view"));
var FadingScrollViewBase = (function (_super) {
    __extends(FadingScrollViewBase, _super);
    function FadingScrollViewBase() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._scrollChangeCount = 0;
        return _this;
    }
    FadingScrollViewBase_1 = FadingScrollViewBase;
    FadingScrollViewBase.prototype.addEventListener = function (arg, callback, thisArg) {
        _super.prototype.addEventListener.call(this, arg, callback, thisArg);
        if (arg === FadingScrollViewBase_1.scrollEvent) {
            this._scrollChangeCount++;
            this.attach();
        }
    };
    FadingScrollViewBase.prototype.removeEventListener = function (arg, callback, thisArg) {
        _super.prototype.removeEventListener.call(this, arg, callback, thisArg);
        if (arg === FadingScrollViewBase_1.scrollEvent) {
            this._scrollChangeCount--;
            this.dettach();
        }
    };
    FadingScrollViewBase.prototype.onLoaded = function () {
        _super.prototype.onLoaded.call(this);
        this.attach();
    };
    FadingScrollViewBase.prototype.onUnloaded = function () {
        _super.prototype.onUnloaded.call(this);
        this.dettach();
    };
    FadingScrollViewBase.prototype.attach = function () {
        if (this._scrollChangeCount > 0 && this.isLoaded) {
            this.attachNative();
        }
    };
    FadingScrollViewBase.prototype.dettach = function () {
        if (this._scrollChangeCount === 0 && this.isLoaded) {
            this.dettachNative();
        }
    };
    FadingScrollViewBase.prototype.attachNative = function () {
    };
    FadingScrollViewBase.prototype.dettachNative = function () {
    };
    Object.defineProperty(FadingScrollViewBase.prototype, "horizontalOffset", {
        get: function () {
            return 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollViewBase.prototype, "verticalOffset", {
        get: function () {
            return 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollViewBase.prototype, "scrollableWidth", {
        get: function () {
            return 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollViewBase.prototype, "scrollableHeight", {
        get: function () {
            return 0;
        },
        enumerable: true,
        configurable: true
    });
    var FadingScrollViewBase_1;
    FadingScrollViewBase.scrollEvent = "scroll";
    __decorate([
        profiling_1.profile,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], FadingScrollViewBase.prototype, "onLoaded", null);
    FadingScrollViewBase = FadingScrollViewBase_1 = __decorate([
        content_view_1.CSSType("FadingScrollView")
    ], FadingScrollViewBase);
    return FadingScrollViewBase;
}(content_view_1.ContentView));
exports.FadingScrollViewBase = FadingScrollViewBase;
var converter = content_view_1.makeParser(content_view_1.makeValidator("horizontal", "vertical"));
exports.orientationProperty = new content_view_1.Property({
    name: "orientation", defaultValue: "vertical", affectsLayout: true,
    valueChanged: function (target, oldValue, newValue) {
        target._onOrientationChanged();
    },
    valueConverter: converter
});
exports.orientationProperty.register(FadingScrollViewBase);
exports.fadePercentageProperty = new content_view_1.Property({
    name: "fadePercentage", defaultValue: 0.3, affectsLayout: true,
    valueChanged: function (target, oldValue, newValue) {
        target._onFadePercentageChanged();
    },
    valueConverter: function (v) {
        var x = parseFloat(v);
        if (x < 0 || x > 0.5) {
            throw new Error("fadePercentage accepts values in the range [0, 0.5]. Value: " + v);
        }
        return x;
    }
});
exports.fadePercentageProperty.register(FadingScrollViewBase);
exports.scrollBarIndicatorVisibleProperty = new content_view_1.Property({
    name: "scrollBarIndicatorVisible", defaultValue: true,
    valueConverter: content_view_1.booleanConverter
});
exports.scrollBarIndicatorVisibleProperty.register(FadingScrollViewBase);
exports.isScrollEnabledProperty = new content_view_1.Property({
    name: "isScrollEnabled", defaultValue: true,
    valueConverter: content_view_1.booleanConverter
});
exports.isScrollEnabledProperty.register(FadingScrollViewBase);
//# sourceMappingURL=fading-scroll-view.common.js.map