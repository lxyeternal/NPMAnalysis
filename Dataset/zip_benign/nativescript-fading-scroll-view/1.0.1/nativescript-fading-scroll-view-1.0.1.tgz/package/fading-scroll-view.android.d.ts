import { FadingScrollViewBase } from "./fading-scroll-view.common";
export * from "./fading-scroll-view.common";
export declare class FadingScrollView extends FadingScrollViewBase {
    nativeViewProtected: org.nativescript.widgets.VerticalScrollView | org.nativescript.widgets.HorizontalScrollView;
    private _androidViewId;
    private handler;
    readonly horizontalOffset: number;
    readonly verticalOffset: number;
    readonly scrollableWidth: number;
    readonly scrollableHeight: number;
    scrollToVerticalOffset(value: number, animated: boolean): void;
    scrollToHorizontalOffset(value: number, animated: boolean): void;
    createNativeView(): org.nativescript.widgets.VerticalScrollView | org.nativescript.widgets.HorizontalScrollView;
    initNativeView(): void;
    _onOrientationChanged(): void;
    _onFadePercentageChanged(): void;
    protected attachNative(): void;
    private _lastScrollX;
    private _lastScrollY;
    private _onScrollChanged;
    protected dettachNative(): void;
}
