"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
var fading_scroll_view_common_1 = require("./fading-scroll-view.common");
var utils_1 = require("tns-core-modules/utils/utils");
__export(require("./fading-scroll-view.common"));
var majorVersion = utils_1.ios.MajorVersion;
var UIScrollViewDelegateImpl = (function (_super) {
    __extends(UIScrollViewDelegateImpl, _super);
    function UIScrollViewDelegateImpl() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    UIScrollViewDelegateImpl.initWithOwner = function (owner) {
        var impl = UIScrollViewDelegateImpl.new();
        impl._owner = owner;
        return impl;
    };
    UIScrollViewDelegateImpl.prototype.scrollViewDidScroll = function (sv) {
        var owner = this._owner.get();
        if (owner) {
            owner.notify({
                object: owner,
                eventName: "scroll",
                scrollX: owner.horizontalOffset,
                scrollY: owner.verticalOffset
            });
        }
    };
    UIScrollViewDelegateImpl.ObjCProtocols = [UIScrollViewDelegate];
    return UIScrollViewDelegateImpl;
}(NSObject));
var FadingScrollViewImpl = (function (_super) {
    __extends(FadingScrollViewImpl, _super);
    function FadingScrollViewImpl() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._gradientLayer = null;
        _this._transparentColor = UIColor.clearColor.CGColor;
        _this._opaqueColor = UIColor.blackColor.CGColor;
        return _this;
    }
    FadingScrollViewImpl.prototype.setGradientLayer = function () {
        this._opaqueColor = UIColor.blackColor.CGColor;
        this._transparentColor = UIColor.clearColor.CGColor;
        this._gradientLayer = CAGradientLayer.new();
    };
    FadingScrollViewImpl.prototype.setFadePercentage = function (fadePercentage) {
        this._fadePercentage = fadePercentage;
    };
    FadingScrollViewImpl.prototype.layoutSubviews = function () {
        _super.prototype.layoutSubviews.call(this);
        var scrollViewHeight = this.frame.size.height;
        var scrollContentSizeHeight = this.contentSize.height;
        var scrollOffset = this.contentOffset.y;
        var alphaTop = (scrollViewHeight >= scrollContentSizeHeight || scrollOffset <= 0) ? 1 : 0;
        var alphaBottom = (scrollViewHeight >= scrollContentSizeHeight
            || scrollOffset + scrollViewHeight >= scrollContentSizeHeight) ? 1 : 0;
        var topOpacity = UIColor.alloc().initWithWhiteAlpha(0, alphaTop).CGColor;
        var bottomOpacity = UIColor.alloc().initWithWhiteAlpha(0, alphaBottom).CGColor;
        var maskLayer = CALayer.new();
        maskLayer.frame = this.bounds;
        this._gradientLayer.frame = CGRectMake(this.bounds.origin.x, 0, this.bounds.size.width, this.bounds.size.height);
        this._gradientLayer.colors = NSArray.arrayWithArray([topOpacity, this._opaqueColor, this._opaqueColor, bottomOpacity]);
        this._gradientLayer.locations = NSArray.arrayWithArray([0, this._fadePercentage, 1 - this._fadePercentage, 1]);
        maskLayer.addSublayer(this._gradientLayer);
        this.layer.mask = maskLayer;
    };
    return FadingScrollViewImpl;
}(UIScrollView));
var FadingScrollView = (function (_super) {
    __extends(FadingScrollView, _super);
    function FadingScrollView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._contentMeasuredWidth = 0;
        _this._contentMeasuredHeight = 0;
        return _this;
    }
    FadingScrollView.prototype.createNativeView = function () {
        var view = FadingScrollViewImpl.new();
        return view;
    };
    FadingScrollView.prototype.initNativeView = function () {
        _super.prototype.initNativeView.call(this);
        this.updateScrollBarVisibility(this.scrollBarIndicatorVisible);
        this._setNativeClipToBounds();
        this._setGradientLayer();
        this._setFadePercentage();
    };
    FadingScrollView.prototype._setNativeClipToBounds = function () {
        this.nativeViewProtected.clipsToBounds = true;
    };
    FadingScrollView.prototype._setGradientLayer = function () {
        this.nativeViewProtected.setGradientLayer();
    };
    FadingScrollView.prototype._setFadePercentage = function () {
        this.nativeViewProtected.setFadePercentage(this.fadePercentage);
    };
    FadingScrollView.prototype.attachNative = function () {
        this._delegate = UIScrollViewDelegateImpl.initWithOwner(new WeakRef(this));
        this.nativeViewProtected.delegate = this._delegate;
    };
    FadingScrollView.prototype.dettachNative = function () {
        this.nativeViewProtected.delegate = null;
    };
    FadingScrollView.prototype.updateScrollBarVisibility = function (value) {
        if (!this.nativeViewProtected) {
            return;
        }
        if (this.orientation === "horizontal") {
            this.nativeViewProtected.showsHorizontalScrollIndicator = value;
        }
        else {
            this.nativeViewProtected.showsVerticalScrollIndicator = value;
        }
    };
    Object.defineProperty(FadingScrollView.prototype, "horizontalOffset", {
        get: function () {
            return this.nativeViewProtected ? this.nativeViewProtected.contentOffset.x : 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollView.prototype, "verticalOffset", {
        get: function () {
            return this.nativeViewProtected ? this.nativeViewProtected.contentOffset.y : 0;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollView.prototype, "scrollableWidth", {
        get: function () {
            if (!this.nativeViewProtected || this.orientation !== "horizontal") {
                return 0;
            }
            return Math.max(0, this.nativeViewProtected.contentSize.width - this.nativeViewProtected.bounds.size.width);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollView.prototype, "scrollableHeight", {
        get: function () {
            if (!this.nativeViewProtected || this.orientation !== "vertical") {
                return 0;
            }
            return Math.max(0, this.nativeViewProtected.contentSize.height - this.nativeViewProtected.bounds.size.height);
        },
        enumerable: true,
        configurable: true
    });
    FadingScrollView.prototype[fading_scroll_view_common_1.isScrollEnabledProperty.getDefault] = function () {
        return this.nativeViewProtected.scrollEnabled;
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.isScrollEnabledProperty.setNative] = function (value) {
        this.nativeViewProtected.scrollEnabled = value;
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.scrollBarIndicatorVisibleProperty.getDefault] = function () {
        return true;
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.scrollBarIndicatorVisibleProperty.setNative] = function (value) {
        this.updateScrollBarVisibility(value);
    };
    FadingScrollView.prototype.scrollToVerticalOffset = function (value, animated) {
        if (this.nativeViewProtected && this.orientation === "vertical" && this.isScrollEnabled) {
            var bounds = this.nativeViewProtected.bounds.size;
            this.nativeViewProtected.scrollRectToVisibleAnimated(CGRectMake(0, value, bounds.width, bounds.height), animated);
        }
    };
    FadingScrollView.prototype.scrollToHorizontalOffset = function (value, animated) {
        if (this.nativeViewProtected && this.orientation === "horizontal" && this.isScrollEnabled) {
            var bounds = this.nativeViewProtected.bounds.size;
            this.nativeViewProtected.scrollRectToVisibleAnimated(CGRectMake(value, 0, bounds.width, bounds.height), animated);
        }
    };
    FadingScrollView.prototype.onMeasure = function (widthMeasureSpec, heightMeasureSpec) {
        var width = fading_scroll_view_common_1.layout.getMeasureSpecSize(widthMeasureSpec);
        var widthMode = fading_scroll_view_common_1.layout.getMeasureSpecMode(widthMeasureSpec);
        var height = fading_scroll_view_common_1.layout.getMeasureSpecSize(heightMeasureSpec);
        var heightMode = fading_scroll_view_common_1.layout.getMeasureSpecMode(heightMeasureSpec);
        var child = this.layoutView;
        this._contentMeasuredWidth = this.effectiveMinWidth;
        this._contentMeasuredHeight = this.effectiveMinHeight;
        if (child) {
            var childSize = void 0;
            if (this.orientation === "vertical") {
                childSize = fading_scroll_view_common_1.View.measureChild(this, child, widthMeasureSpec, fading_scroll_view_common_1.layout.makeMeasureSpec(0, fading_scroll_view_common_1.layout.UNSPECIFIED));
            }
            else {
                childSize = fading_scroll_view_common_1.View.measureChild(this, child, fading_scroll_view_common_1.layout.makeMeasureSpec(0, fading_scroll_view_common_1.layout.UNSPECIFIED), heightMeasureSpec);
            }
            this._contentMeasuredWidth = Math.max(childSize.measuredWidth, this.effectiveMinWidth);
            this._contentMeasuredHeight = Math.max(childSize.measuredHeight, this.effectiveMinHeight);
        }
        var widthAndState = fading_scroll_view_common_1.View.resolveSizeAndState(this._contentMeasuredWidth, width, widthMode, 0);
        var heightAndState = fading_scroll_view_common_1.View.resolveSizeAndState(this._contentMeasuredHeight, height, heightMode, 0);
        this.setMeasuredDimension(widthAndState, heightAndState);
    };
    FadingScrollView.prototype.onLayout = function (left, top, right, bottom) {
        var insets = this.getSafeAreaInsets();
        var width = (right - left - insets.right - insets.left);
        var height = (bottom - top - insets.bottom - insets.top);
        var nativeView = this.nativeViewProtected;
        if (majorVersion > 10) {
            nativeView.contentInsetAdjustmentBehavior = 2;
        }
        var scrollWidth = width + insets.left + insets.right;
        var scrollHeight = height + insets.top + insets.bottom;
        if (this.orientation === "horizontal") {
            scrollWidth = Math.max(this._contentMeasuredWidth + insets.left + insets.right, scrollWidth);
            width = Math.max(this._contentMeasuredWidth, width);
        }
        else {
            scrollHeight = Math.max(this._contentMeasuredHeight + insets.top + insets.bottom, scrollHeight);
            height = Math.max(this._contentMeasuredHeight, height);
        }
        nativeView.contentSize = CGSizeMake(fading_scroll_view_common_1.layout.toDeviceIndependentPixels(scrollWidth), fading_scroll_view_common_1.layout.toDeviceIndependentPixels(scrollHeight));
        fading_scroll_view_common_1.View.layoutChild(this, this.layoutView, insets.left, insets.top, insets.left + width, insets.top + height);
    };
    FadingScrollView.prototype._onOrientationChanged = function () {
        this.updateScrollBarVisibility(this.scrollBarIndicatorVisible);
    };
    FadingScrollView.prototype._onFadePercentageChanged = function () {
        if (this.nativeViewProtected) {
            this._setFadePercentage();
        }
    };
    return FadingScrollView;
}(fading_scroll_view_common_1.FadingScrollViewBase));
exports.FadingScrollView = FadingScrollView;
//# sourceMappingURL=fading-scroll-view.ios.js.map