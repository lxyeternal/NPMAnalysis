"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
var fading_scroll_view_common_1 = require("./fading-scroll-view.common");
__export(require("./fading-scroll-view.common"));
var FadingScrollView = (function (_super) {
    __extends(FadingScrollView, _super);
    function FadingScrollView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._androidViewId = -1;
        _this._lastScrollX = -1;
        _this._lastScrollY = -1;
        return _this;
    }
    Object.defineProperty(FadingScrollView.prototype, "horizontalOffset", {
        get: function () {
            var nativeView = this.nativeViewProtected;
            if (!nativeView) {
                return 0;
            }
            return nativeView.getScrollX() / fading_scroll_view_common_1.layout.getDisplayDensity();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollView.prototype, "verticalOffset", {
        get: function () {
            var nativeView = this.nativeViewProtected;
            if (!nativeView) {
                return 0;
            }
            return nativeView.getScrollY() / fading_scroll_view_common_1.layout.getDisplayDensity();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollView.prototype, "scrollableWidth", {
        get: function () {
            var nativeView = this.nativeViewProtected;
            if (!nativeView || this.orientation !== "horizontal") {
                return 0;
            }
            return nativeView.getScrollableLength() / fading_scroll_view_common_1.layout.getDisplayDensity();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FadingScrollView.prototype, "scrollableHeight", {
        get: function () {
            var nativeView = this.nativeViewProtected;
            if (!nativeView || this.orientation !== "vertical") {
                return 0;
            }
            return nativeView.getScrollableLength() / fading_scroll_view_common_1.layout.getDisplayDensity();
        },
        enumerable: true,
        configurable: true
    });
    FadingScrollView.prototype[fading_scroll_view_common_1.isUserInteractionEnabledProperty.setNative] = function (value) {
        this.nativeViewProtected.setClickable(value);
        this.nativeViewProtected.setFocusable(value);
        this.nativeViewProtected.setScrollEnabled(value);
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.isScrollEnabledProperty.getDefault] = function () {
        return this.nativeViewProtected.getScrollEnabled();
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.isScrollEnabledProperty.setNative] = function (value) {
        this.nativeViewProtected.setScrollEnabled(value);
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.scrollBarIndicatorVisibleProperty.getDefault] = function () {
        return true;
    };
    FadingScrollView.prototype[fading_scroll_view_common_1.scrollBarIndicatorVisibleProperty.setNative] = function (value) {
        if (this.orientation === "horizontal") {
            this.nativeViewProtected.setHorizontalScrollBarEnabled(value);
        }
        else {
            this.nativeViewProtected.setVerticalScrollBarEnabled(value);
        }
    };
    FadingScrollView.prototype.scrollToVerticalOffset = function (value, animated) {
        var nativeView = this.nativeViewProtected;
        if (nativeView && this.orientation === "vertical" && this.isScrollEnabled) {
            value *= fading_scroll_view_common_1.layout.getDisplayDensity();
            if (animated) {
                nativeView.smoothScrollTo(0, value);
            }
            else {
                nativeView.scrollTo(0, value);
            }
        }
    };
    FadingScrollView.prototype.scrollToHorizontalOffset = function (value, animated) {
        var nativeView = this.nativeViewProtected;
        if (nativeView && this.orientation === "horizontal" && this.isScrollEnabled) {
            value *= fading_scroll_view_common_1.layout.getDisplayDensity();
            if (animated) {
                nativeView.smoothScrollTo(value, 0);
            }
            else {
                nativeView.scrollTo(value, 0);
            }
        }
    };
    FadingScrollView.prototype.createNativeView = function () {
        return this.orientation === "horizontal" ? new org.nativescript.widgets.HorizontalScrollView(this._context) : new org.nativescript.widgets.VerticalScrollView(this._context);
    };
    FadingScrollView.prototype.initNativeView = function () {
        _super.prototype.initNativeView.call(this);
        if (this._androidViewId < 0) {
            this._androidViewId = android.view.View.generateViewId();
        }
        this.nativeViewProtected.setId(this._androidViewId);
        if (this.orientation === "horizontal") {
            this.nativeViewProtected.setHorizontalFadingEdgeEnabled(true);
        }
        else {
            this.nativeViewProtected.setVerticalFadingEdgeEnabled(true);
        }
        var fadeLegnth = this.fadePercentage * fading_scroll_view_common_1.layout.getDisplayDensity() * this.height;
        this.nativeViewProtected.setFadingEdgeLength(300000);
    };
    FadingScrollView.prototype._onOrientationChanged = function () {
        if (this.nativeViewProtected) {
            var parent_1 = this.parent;
            if (parent_1) {
                parent_1._removeView(this);
                parent_1._addView(this);
            }
        }
    };
    FadingScrollView.prototype._onFadePercentageChanged = function () {
        if (this.nativeViewProtected) {
            var fadeLegnth = this.fadePercentage * fading_scroll_view_common_1.layout.getDisplayDensity() * this.height;
            this.nativeViewProtected.setFadingEdgeLength(fadeLegnth);
        }
    };
    FadingScrollView.prototype.attachNative = function () {
        var that = new WeakRef(this);
        this.handler = new android.view.ViewTreeObserver.OnScrollChangedListener({
            onScrollChanged: function () {
                var owner = that.get();
                if (owner) {
                    owner._onScrollChanged();
                }
            }
        });
        this.nativeViewProtected.getViewTreeObserver().addOnScrollChangedListener(this.handler);
    };
    FadingScrollView.prototype._onScrollChanged = function () {
        var nativeView = this.nativeViewProtected;
        if (nativeView) {
            var newScrollX = nativeView.getScrollX();
            var newScrollY = nativeView.getScrollY();
            if (newScrollX !== this._lastScrollX || newScrollY !== this._lastScrollY) {
                this.notify({
                    object: this,
                    eventName: FadingScrollView.scrollEvent,
                    scrollX: newScrollX / fading_scroll_view_common_1.layout.getDisplayDensity(),
                    scrollY: newScrollY / fading_scroll_view_common_1.layout.getDisplayDensity()
                });
                this._lastScrollX = newScrollX;
                this._lastScrollY = newScrollY;
            }
        }
    };
    FadingScrollView.prototype.dettachNative = function () {
        this.nativeViewProtected.getViewTreeObserver().removeOnScrollChangedListener(this.handler);
        this.handler = null;
    };
    return FadingScrollView;
}(fading_scroll_view_common_1.FadingScrollViewBase));
exports.FadingScrollView = FadingScrollView;
//# sourceMappingURL=fading-scroll-view.android.js.map