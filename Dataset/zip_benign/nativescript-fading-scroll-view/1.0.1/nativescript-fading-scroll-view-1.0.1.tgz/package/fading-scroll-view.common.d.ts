import { FadingScrollView as FadingScrollViewDefinition, Orientation, ScrollEventData } from "./fading-scroll-view";
import { ContentView, Property, EventData } from "tns-core-modules/ui/content-view";
export * from "tns-core-modules/ui/content-view";
export declare abstract class FadingScrollViewBase extends ContentView implements FadingScrollViewDefinition {
    private _scrollChangeCount;
    static scrollEvent: string;
    fadePercentage: number;
    orientation: Orientation;
    scrollBarIndicatorVisible: boolean;
    isScrollEnabled: boolean;
    addEventListener(arg: string, callback: any, thisArg?: any): void;
    removeEventListener(arg: string, callback: any, thisArg?: any): void;
    onLoaded(): void;
    onUnloaded(): void;
    private attach;
    private dettach;
    protected attachNative(): void;
    protected dettachNative(): void;
    readonly horizontalOffset: number;
    readonly verticalOffset: number;
    readonly scrollableWidth: number;
    readonly scrollableHeight: number;
    abstract scrollToVerticalOffset(value: number, animated: boolean): any;
    abstract scrollToHorizontalOffset(value: number, animated: boolean): any;
    abstract _onOrientationChanged(): any;
    abstract _onFadePercentageChanged(): any;
}
export interface FadingScrollViewBase {
    on(eventNames: string, callback: (data: EventData) => void, thisArg?: any): any;
    on(event: "scroll", callback: (args: ScrollEventData) => void, thisArg?: any): any;
}
export declare const orientationProperty: Property<FadingScrollViewBase, Orientation>;
export declare const fadePercentageProperty: Property<FadingScrollViewBase, number>;
export declare const scrollBarIndicatorVisibleProperty: Property<FadingScrollViewBase, boolean>;
export declare const isScrollEnabledProperty: Property<FadingScrollViewBase, boolean>;
