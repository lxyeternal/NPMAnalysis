import { FadingScrollViewBase } from "./fading-scroll-view.common";
export * from "./fading-scroll-view.common";
declare class FadingScrollViewImpl extends UIScrollView {
    private _fadePercentage;
    private _gradientLayer;
    private _transparentColor;
    private _opaqueColor;
    setGradientLayer(): void;
    setFadePercentage(fadePercentage: number): void;
    layoutSubviews(): void;
}
export declare class FadingScrollView extends FadingScrollViewBase {
    nativeViewProtected: FadingScrollViewImpl;
    private _contentMeasuredWidth;
    private _contentMeasuredHeight;
    private _delegate;
    createNativeView(): UIScrollView;
    initNativeView(): void;
    _setNativeClipToBounds(): void;
    _setGradientLayer(): void;
    _setFadePercentage(): void;
    protected attachNative(): void;
    protected dettachNative(): void;
    protected updateScrollBarVisibility(value: any): void;
    readonly horizontalOffset: number;
    readonly verticalOffset: number;
    readonly scrollableWidth: number;
    readonly scrollableHeight: number;
    scrollToVerticalOffset(value: number, animated: boolean): void;
    scrollToHorizontalOffset(value: number, animated: boolean): void;
    onMeasure(widthMeasureSpec: number, heightMeasureSpec: number): void;
    onLayout(left: number, top: number, right: number, bottom: number): void;
    _onOrientationChanged(): void;
    _onFadePercentageChanged(): void;
}
