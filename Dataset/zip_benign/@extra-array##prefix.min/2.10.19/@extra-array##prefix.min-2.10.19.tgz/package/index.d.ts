declare module "@extra-array/prefix.min" {


/**
 * Picks an arbitrary prefix.
 * @param x an array
 * @param n number of values (-1 => any)
 * @param r random seed 0->1
 */
declare function prefix<T>(x: T[], n?: number, r?: number): T[];
export = prefix;
//# sourceMappingURL=prefix.d.ts.map}
