(function(){
    return "hello";
});