(function(){
    return "world";
});