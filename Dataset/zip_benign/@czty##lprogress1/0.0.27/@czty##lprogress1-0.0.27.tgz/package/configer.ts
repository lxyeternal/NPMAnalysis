import { reduce } from "lodash"

export const cfgItem = [{
  label: 'x',
  name: 'x',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'y',
  name: 'y',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'clazz',
  name: 'clazz',
  value: '',
  placeholder: '例如：cz-title',
  type: []
},{
  label: '请求参数',
  name: 'params',
  value: '',
  placeholder: '例如：{id: 2}',
  type: []
},{
  label: '请求方式',
  name: 'method',
  value: 'get',
  placeholder: '例如：get',
  type: [{
    id: 'get',
    name: 'get'
  }, {
    id: 'post',
    name: 'post'
  }, {
    id: 'put',
    name: 'put'
  }, {
    id: 'delete',
    name: 'delete'
  }]
},{
  label: '请求地址',
  name: 'url',
  value: '',
  placeholder: '例如：',
  type: []
},{
  label: '数据',
  name: 'data',
  value: [10, 20, 30, 40, 50, 60, 70, 80],
  placeholder: '例如：[]',
  type: []
},{
  label: '数据单位',
  name: 'dataUnit',
  value: '',
  placeholder: '例如：人',
  type: []
}, {
  label: '名称数据',
  name: 'title',
  value: ['杭州市', '湖州市', '宁波市', '温州市', '丽水市', '台州市', '绍兴市', '金华市'],
  placeholder: '例如：[]',
  type: []
}, {
  label: 'Total值',
  name: 'total',
  placeholder: '例如：10',
  value: 100,
  type: []
},{
  label: '宽度',
  name: 'width',
  value: '400px',
  placeholder: '例如：400px',
  type: []
}, {
  label: '高度',
  name: 'height',
  value: '704px',
  placeholder: '例如：704px',
  type: []
}, {
  label: '下边距',
  name: 'liMarginBot',
  value: '24px',
  placeholder: '例如：24px',
  type: []
}, {
  label: '文字说明',
  name: 'rankText',
  placeholder: '例如：NO.',
  value: 'NO.',
  type: []
}, {
  label: '前几排名',
  name: 'rankNum',
  placeholder: '例如：3',
  value: '3',
  type: []
},{
  label: '是否取消排名',
  name: 'unrank',
  placeholder: '例如：是',
  value: '是',
  type: [{
    id: '是',
    name: '是'
  }, {
    id: '否',
    name: '否'
  }]
},{
  label: '隔行变色',
  name: 'cross',
  value: '',
  placeholder: '例如：[‘red’, ‘yellow’]',
  type: []
}, {
  label: '图标url',
  name: 'rankIcon',
  placeholder: '例如：[./images/sft/progressbg.png, ./images/sft/progressbg.png]',
  value: ['', ''],
  type: []
},{
  label: '图标背景',
  name: 'rankBackground',
  placeholder: '例如：[#FF6E23, #20FDFF]',
  value: ['', ''],
  type: []
}, {
  label: '外条高度',
  name: 'progressOutHeight',
  value: '14px',
  placeholder: '例如：10px',
  type: []
}, {
  label: '内条高度',
  name: 'progressInHeight',
  value: '7px',
  placeholder: '例如：7px',
  type: []
}, {
  label: '进度条圆角',
  name: 'pBorderRadius',
  value: '0px',
  placeholder: '例如：4px',
  type: []
}, {
  label: '进度条底色',
  name: 'progressOutColor',
  value: 'rgba(55, 95, 144, 0.5)',
  placeholder: '例如：rgba(55, 95, 144, 0.5)',
  type: []
}, {
  label: '进度颜色',
  name: 'progressInColor',
  value: ['linear-gradient(90deg, #1A293B, #FF7723)','linear-gradient(90deg, #1A293B, #1CE5FF)'],
  placeholder: '例如：[linear-gradient(90deg, #1A293B, #FF7723), linear-gradient(90deg, #1A293B, #FF7723)]',
  type: []
}, {
  label: '进度背景Url',
  name: 'progressBg',
  value: './images/sft/progressbg.png',
  placeholder: '例如：./images/sft/progressbg.png',
  type: []
}, {
  label: '字体大小',
  name: 'textSize',
  placeholder: '例如：12px',
  value: '12px',
  type: []
}, {
  label: '字体颜色',
  name: 'textColor',
  placeholder: '例如：#fff',
  value: '#fff',
  type: ['color']
}, {
  label: '字体样式',
  name: 'textStyle',
  placeholder: '例如：italic',
  value: 'italic',
  type: []
},{
  label: '字体背景',
  name: 'textBgUrl',
  placeholder: '例如：[./images/sft/progressbg.png, ./images/sft/progressbg.png]',
  value: ['./images/sft/progressbg.png', 'none'],
  type: [],
}, {
  label: '名称大小',
  name: 'nameSize',
  placeholder: '例如：12px',
  value: '12px',
  type: []
}, {
  label: '名称颜色',
  name: 'nameColor',
  placeholder: '例如：#fff',
  value: '#fff',
  type: ['color']
}, {
  label: '数据大小',
  name: 'numSize',
  placeholder: '例如：12px',
  value: '12px',
  type: []
}, {
  label: '数据颜色',
  name: 'numColor',
  placeholder: '例如：[#FF6E23, #20FDFF]',
  value: ['#FF6E23', '#20FDFF'],
  type: []
}, {
  label: '是否滚动',
  name: 'isScroll',
  placeholder: '例如：是',
  value: '是',
  type: [{
    id: '是',
    name: '是'
  }, {
    id: '否',
    name: '否'
  }]
},{
  label: '排行小于10补零',
  name: 'makeUpZero',
  placeholder: '例如：是',
  value: '否',
  type: []
}]

export default  {
  x: 0,
  y: 0,
  clazz : '',
  params : {},
  url : '',
  method : 'get',
  data: [10, 20, 30, 40, 50, 60, 70, 80],
  dataUnit: '',
  title: ['杭州市', '湖州市', '宁波市', '温州市', '丽水市', '台州市', '绍兴市', '金华市'],
  total: 100,

  width: '400px',
  height: '704px',
  liMarginBot: '24px',
  
  rankText: 'NO.',
  rankNum: 3,
  rankIcon: ['', ''],
  rankBackground: ['', ''],

  progressBg: './images/sft/progressbg.png',
  progressOutHeight: '14px',
  progressInHeight: '7px',
  pBorderRadius: '0px',

  progressOutColor: 'rgba(55, 95, 144, 0.5)',
  progressInColor: ['linear-gradient(90deg, #1A293B, #FF7723)','linear-gradient(90deg, #1A293B, #1CE5FF)'],

  textColor: '#fff',
  textSize: '14px',
  textStyle: 'italic',
  textBgUrl: ['./images/sft/progressbg.png', 'none'],

  nameColor: '#fff',
  nameSize: '14px',

  numSize: '14px',
  numColor: ['#FF6E23', '#20FDFF'],
  isScroll: '是',
  unrank: '是',
  makeUpZero: '否',
  cross:['#FF6E23','#1CE5FF']
}