import React, { FC } from 'react'
import 'antd/dist/antd.css'
import LProgress1 from '@/component'


const App: FC = () => {
  return (
    <div className="app">
      <LProgress1 /> 
    </div>
  )
}

export default App