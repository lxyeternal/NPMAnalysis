import { display } from 'html2canvas/dist/types/css/property-descriptors/display'
import React, { FC, useState, useEffect, useRef } from 'react'
import configers from '../../configer'
import './index.scss'

const LProgress1: FC = ({
  draggable = true,
  configer = configers
}) => {
  const {
    clazz,
    data,
    dataUnit,
    title,

    width,
    height,

    liMarginBot,

    rankText,
    rankNum,
    rankIcon,
    rankBackground,
    
    progressBg,
    pBorderRadius,
    progressOutHeight,
    progressInHeight,
  
    progressOutColor,
    progressInColor,
  
    textColor,
    textSize,
    textStyle,
    textBgUrl,
  
    nameColor,
    nameSize,
  
    numSize,
    numColor,
    isScroll,
    unrank,
    total,
    cross,
    makeUpZero
  } = configer
 
  const [isScrolle, setIsScrolle] = useState(isScroll);
  const [unranks, setunranks] = useState(unrank);
  const handleDrag = (e) => {
    // antdI本来应该是个数组的，因为一个组件可能包含多个antd的组件，外面可以扁平化啊
    const params = JSON.stringify({ type: 'other', id: 'LProgress1', antdI: '', relate: 'in' })
    e.dataTransfer.setData('Text', params)
  }

  useEffect(() => {
    setIsScrolle(isScroll)
    setunranks(unrank)
    // 对于第二个参数是对象的问题，可以是string化，也可以是md5化
  }, [JSON.stringify(configer)])

  const speed = 100;
  const warper = useRef();
  const childDom1 = useRef();
  const hoverHandler = (flag) => {
    isScroll === '是' ?
      setIsScrolle(flag) : null
  };

  useEffect(() => {
    let timer;
    if (isScrolle === '是') {
      timer = setInterval(
        () =>
        warper.current && (warper.current.scrollTop >= childDom1.current.scrollHeight - warper.current.clientHeight)
            ? (warper.current.scrollTop = 0)
            : warper.current.scrollTop++,
        speed
      );
    } else {
      clearInterval(timer);
    }
    return () => {
      clearInterval(timer);
    };
  }, [isScrolle])

  return (
    <>
      <div
        draggable={draggable}
        className={`dragor ${clazz} cz-progress-2`}
        onDragStart={(e) => { handleDrag(e) }}
        style={{ width: width, height: height }}
      >
        <div ref={warper} className="progress-2-container">
          <ul className='progress-2' ref={childDom1} onMouseOver={() => hoverHandler('否')} onMouseLeave={() => hoverHandler('是')}>
            {
              data.length ? data.map((item, index) =>
              (
                <li key={index} style={{marginBottom: liMarginBot}}>
                  <p>
                    {unranks === '否' ? null
                      : <span className='p-text' style={{ fontStyle: textStyle, fontSize: textSize, color: textColor, background: index < rankNum ? `url(${textBgUrl[0]}) no-repeat center center` : `url(${textBgUrl[1]}) no-repeat center center` }}>{`${rankText + ((makeUpZero==='是' && index < 9) ? '0':'') + (index + 1)}`}</span> }
                    <span style={{display:unranks === '否'? 'none' :''}} className='p-rank'>
                      {
                        rankIcon[0] || rankBackground[0] ?
                        <span className='p-icon' style={{ background: index < rankNum ? `${numColor[0]} url(${rankBackground[0]}) no-repeat center center` : `${numColor[1]}  url(${rankBackground[1]}) no-repeat center center`,
                      boxShadow: index < rankNum ? `0 0 5px ${numColor[0]}` : `0 0 5px ${numColor[1]}`}}></span> : null
                      }
                    </span>
                    <span className='p-name' style={{ fontSize: nameSize, color: nameColor }}>{title[index]}</span>
                    {
                      rankNum && rankNum > 0 || !cross ? 
                      <span className='p-num' style={{ fontSize: numSize, color: index < rankNum ? numColor[0] : numColor[1] }}>{item+(dataUnit?dataUnit:'')}</span>
                      :
                      <span className='p-num' style={{ fontSize: numSize, color: (index%2)===0 && cross ? cross[0]:cross[1] }}>{item+(dataUnit?dataUnit:'')}</span>
                    }
                  </p>
                  <span className='p-outin'>
                    <span className='p-outer' style={{ height: progressOutHeight, background: progressOutColor, borderRadius: pBorderRadius }}>
                      {
                        rankNum && rankNum > 0 || !cross?
                          <span className='p-inner' style={{ height: progressInHeight, background: index < rankNum ? progressInColor[0] : progressInColor[1], borderRadius: pBorderRadius, width: item < 0 ? '0%' : (Number(item) / Number(total)) * 100 + '%' }}>
                          {progressBg ? <img src={progressBg} /> : null}
                          </span> 
                        : 
                          <span className='p-inner' style={{ height: progressInHeight, background:(index%2)===0 && cross ? cross[0]:cross[1], borderRadius: pBorderRadius, width: item < 0 ? '0%' : (Number(item) / Number(total)) * 100 + '%' }}>
                            {progressBg ? <img src={progressBg} /> : null}
                          </span>
                      }
                    </span>
                  </span>
                </li>
              )
              ) : <span style={{position: 'absolute', top: '46%', left: '42%', color: 'rgba(255, 255, 255, 0.5)'}}>暂无数据</span>
            }
          </ul>
        </div>
      </div>
    </>
  )
}

export default LProgress1