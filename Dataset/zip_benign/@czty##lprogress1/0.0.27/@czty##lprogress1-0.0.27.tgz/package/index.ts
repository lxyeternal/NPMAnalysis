import LProgress1 from './src/component'
import configer, { cfgItem } from './configer'

export default { configer, cfgItem }

export { LProgress1 }