# No-code development platform

No-code development platforms (NCDPs) allow creating application software through graphical user interfaces and configuration instead of traditional computer programming. No-code development platforms are closely related to low-code development platforms as both are designed to expedite the application development process.[1] However, unlike low-code, no-code development platforms require no code writing at all, generally offering prebuilt templates that businesses can build apps with.[2] These platforms have both increased in popularity as companies deal with the parallel trends of an increasingly mobile workforce and a limited supply of competent software developers.[3]

No-code development platforms are closely related to visual programming languages.[4]

See more @ https://en.wikipedia.org/wiki/No-code_development_platform