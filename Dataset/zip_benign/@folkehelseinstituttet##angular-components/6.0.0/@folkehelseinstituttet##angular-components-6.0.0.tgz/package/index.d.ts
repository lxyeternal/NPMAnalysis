/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@folkehelseinstituttet/angular-components" />
export * from './public-api';
