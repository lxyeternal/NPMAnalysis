import * as i0 from '@angular/core';
import { EventEmitter, Component, ViewEncapsulation, Input, Output, ChangeDetectionStrategy, ViewChild, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i3 from '@ng-select/ng-select';
import { NgSelectModule } from '@ng-select/ng-select';
import * as i2$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import { Subject, debounceTime, switchMap, of } from 'rxjs';
import { cloneDeep } from 'lodash-es';
import * as i1$1 from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';

class FhiAutosuggestComponent {
    constructor() {
        this.notFoundText = 'Ingen elementer funnet';
        this.selectedItemChange = new EventEmitter();
    }
    onChange() {
        if (this.selectedItem) {
            this.selectedItemChange.emit(this.selectedItem);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiAutosuggestComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiAutosuggestComponent, isStandalone: true, selector: "fhi-autosuggest", inputs: { items: "items", labelForId: "labelForId", placeholder: "placeholder", description: "description", label: "label", selectedItem: "selectedItem", notFoundText: "notFoundText" }, outputs: { selectedItemChange: "selectedItemChange" }, ngImport: i0, template: "<div class=\"fhi-ng-select-wrapper fhi-autosuggest\">\n  <label class=\"form-label\" for=\"{{ labelForId }}\">{{ label }}</label>\n  <p class=\"form-text\" *ngIf=\"description !== undefined\">{{ description }}</p>\n\n  <ng-select\n    [items]=\"items\"\n    [editableSearchTerm]=\"true\"\n    [(ngModel)]=\"selectedItem\"\n    bindLabel=\"name\"\n    bindValue=\"id\"\n    labelForId=\"{{ labelForId }}\"\n    notFoundText=\"{{ notFoundText }}\"\n    placeholder=\"{{ placeholder }}\"\n    (change)=\"onChange()\"\n  >\n    <ng-option *ngFor=\"let item of items\" [value]=\"item.id\">{{ item.name }}</ng-option>\n  </ng-select>\n</div>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: NgSelectModule }, { kind: "component", type: i3.NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "bindLabel", "bindValue", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "appearance", "dropdownPosition", "appendTo", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "isOpen", "items", "compareWith", "clearSearchOnAdd", "deselectOnClick", "keyDownFn"], outputs: ["blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"] }, { kind: "component", type: i3.NgOptionComponent, selector: "ng-option", inputs: ["value", "disabled"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiAutosuggestComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-autosuggest', imports: [CommonModule, NgSelectModule, FormsModule], encapsulation: ViewEncapsulation.None, template: "<div class=\"fhi-ng-select-wrapper fhi-autosuggest\">\n  <label class=\"form-label\" for=\"{{ labelForId }}\">{{ label }}</label>\n  <p class=\"form-text\" *ngIf=\"description !== undefined\">{{ description }}</p>\n\n  <ng-select\n    [items]=\"items\"\n    [editableSearchTerm]=\"true\"\n    [(ngModel)]=\"selectedItem\"\n    bindLabel=\"name\"\n    bindValue=\"id\"\n    labelForId=\"{{ labelForId }}\"\n    notFoundText=\"{{ notFoundText }}\"\n    placeholder=\"{{ placeholder }}\"\n    (change)=\"onChange()\"\n  >\n    <ng-option *ngFor=\"let item of items\" [value]=\"item.id\">{{ item.name }}</ng-option>\n  </ng-select>\n</div>\n" }]
        }], propDecorators: { items: [{
                type: Input,
                args: [{ required: true }]
            }], labelForId: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], description: [{
                type: Input
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], selectedItem: [{
                type: Input,
                args: [{ required: true }]
            }], notFoundText: [{
                type: Input
            }], selectedItemChange: [{
                type: Output
            }] } });

class FhiMultiselectComponent {
    constructor() {
        this.notFoundText = 'Ingen elementer funnet';
        this.selectedItemsChange = new EventEmitter();
    }
    unselect(id) {
        if (!id) {
            return;
        }
        this.selectedItems = this.selectedItems.filter((item) => item !== id);
        this.selectedItemsChange.emit(this.selectedItems);
    }
    unselectAll() {
        this.selectedItems = [];
        this.selectedItemsChange.emit(this.selectedItems);
    }
    getSelectedName(selected) {
        return this.items?.find((x) => x.id === selected)?.name;
    }
    onChange() {
        this.selectedItemsChange.emit(this.selectedItems);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiMultiselectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiMultiselectComponent, isStandalone: true, selector: "fhi-multiselect", inputs: { items: "items", labelForId: "labelForId", placeholder: "placeholder", disableTags: "disableTags", description: "description", label: "label", notFoundText: "notFoundText", selectedItems: "selectedItems" }, outputs: { selectedItemsChange: "selectedItemsChange" }, ngImport: i0, template: "<div class=\"fhi-ng-select-wrapper fhi-multiselect\">\n  <label class=\"form-label\" for=\"{{ labelForId }}\">{{ label }}</label>\n  <p class=\"form-text\" *ngIf=\"description !== undefined\">{{ description }}</p>\n\n  <ng-select\n    [items]=\"items\"\n    [multiple]=\"true\"\n    [closeOnSelect]=\"false\"\n    [(ngModel)]=\"selectedItems\"\n    bindLabel=\"name\"\n    bindValue=\"id\"\n    labelForId=\"{{ labelForId }}\"\n    notFoundText=\"{{ notFoundText }}\"\n    placeholder=\"{{ placeholder }}\"\n    (change)=\"onChange()\"\n  >\n    <ng-template ng-label-tmp let-item=\"item\"></ng-template>\n    <ng-template ng-option-tmp let-item=\"item\" let-item$=\"item$\" let-index=\"index\">\n      <div class=\"form-check\">\n        <input\n          class=\"form-check-input\"\n          type=\"checkbox\"\n          name=\"item-{{ index }}\"\n          id=\"item-{{ index }}\"\n          [ngModel]=\"item$.selected\"\n        />\n        {{ item.name }}\n      </div>\n    </ng-template>\n  </ng-select>\n  <div class=\"fhi-multiselect__selected\" *ngIf=\"!disableTags\">\n    <button\n      class=\"fhi-tag fhi-tag--filter-option mt-2 me-1\"\n      *ngFor=\"let selected of selectedItems\"\n      (click)=\"unselect(selected)\"\n    >\n      {{ getSelectedName(selected) }}\n      <i class=\"icon-x\"></i>\n    </button>\n    <button type=\"button\" class=\"btn fhi-btn-link\" *ngIf=\"selectedItems?.length > 1\" (click)=\"unselectAll()\">\n      Fjern valgte\n    </button>\n  </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: NgSelectModule }, { kind: "component", type: i3.NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "bindLabel", "bindValue", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "appearance", "dropdownPosition", "appendTo", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "isOpen", "items", "compareWith", "clearSearchOnAdd", "deselectOnClick", "keyDownFn"], outputs: ["blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"] }, { kind: "directive", type: i3.NgOptionTemplateDirective, selector: "[ng-option-tmp]" }, { kind: "directive", type: i3.NgLabelTemplateDirective, selector: "[ng-label-tmp]" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiMultiselectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-multiselect', imports: [CommonModule, FormsModule, NgSelectModule], encapsulation: ViewEncapsulation.None, template: "<div class=\"fhi-ng-select-wrapper fhi-multiselect\">\n  <label class=\"form-label\" for=\"{{ labelForId }}\">{{ label }}</label>\n  <p class=\"form-text\" *ngIf=\"description !== undefined\">{{ description }}</p>\n\n  <ng-select\n    [items]=\"items\"\n    [multiple]=\"true\"\n    [closeOnSelect]=\"false\"\n    [(ngModel)]=\"selectedItems\"\n    bindLabel=\"name\"\n    bindValue=\"id\"\n    labelForId=\"{{ labelForId }}\"\n    notFoundText=\"{{ notFoundText }}\"\n    placeholder=\"{{ placeholder }}\"\n    (change)=\"onChange()\"\n  >\n    <ng-template ng-label-tmp let-item=\"item\"></ng-template>\n    <ng-template ng-option-tmp let-item=\"item\" let-item$=\"item$\" let-index=\"index\">\n      <div class=\"form-check\">\n        <input\n          class=\"form-check-input\"\n          type=\"checkbox\"\n          name=\"item-{{ index }}\"\n          id=\"item-{{ index }}\"\n          [ngModel]=\"item$.selected\"\n        />\n        {{ item.name }}\n      </div>\n    </ng-template>\n  </ng-select>\n  <div class=\"fhi-multiselect__selected\" *ngIf=\"!disableTags\">\n    <button\n      class=\"fhi-tag fhi-tag--filter-option mt-2 me-1\"\n      *ngFor=\"let selected of selectedItems\"\n      (click)=\"unselect(selected)\"\n    >\n      {{ getSelectedName(selected) }}\n      <i class=\"icon-x\"></i>\n    </button>\n    <button type=\"button\" class=\"btn fhi-btn-link\" *ngIf=\"selectedItems?.length > 1\" (click)=\"unselectAll()\">\n      Fjern valgte\n    </button>\n  </div>\n</div>\n" }]
        }], propDecorators: { items: [{
                type: Input,
                args: [{ required: true }]
            }], labelForId: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], disableTags: [{
                type: Input
            }], description: [{
                type: Input
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], notFoundText: [{
                type: Input
            }], selectedItems: [{
                type: Input,
                args: [{ required: true }]
            }], selectedItemsChange: [{
                type: Output
            }] } });

class FhiTreeViewNavigationComponent {
    constructor() {
        this.items = [];
    }
    ngOnChanges(changes) {
        if (changes['items'].currentValue !== undefined) {
            this.createIds(this.items, 1);
        }
    }
    toggleExpanded(item) {
        item.isExpanded = !item.isExpanded;
    }
    createIds(items, id) {
        items.forEach((item) => {
            if (item.id === undefined) {
                item.id = id++;
            }
            if (item.children && item.children.length > 0) {
                this.createIds(item.children, (id - 1) * 10 + 1);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewNavigationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiTreeViewNavigationComponent, isStandalone: true, selector: "fhi-tree-view-navigation", inputs: { items: "items" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"fhi-tree-view-navigation\">\n  <ng-container *ngTemplateOutlet=\"navigationItems; context: { items: items, itemId: null }\"></ng-container>\n</div>\n\n<ng-template #navigationItems let-items=\"items\" let-itemId=\"itemId\">\n  <ul\n    class=\"fhi-tree-view-navigation__list\"\n    role=\"tree\"\n    [attr.id]=\"itemId !== null ? 'list-' + itemId : null\"\n    [attr.aria-labelledby]=\"itemId !== null ? 'label-' + itemId : null\"\n  >\n    <li class=\"fhi-tree-view-navigation__item\" *ngFor=\"let item of items\" role=\"treeitem\">\n      <div class=\"d-flex w-100\">\n        <ng-container *ngIf=\"item.routerLink\">\n          <ng-container *ngTemplateOutlet=\"routerLink; context: { item: item }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item.href\">\n          <ng-container *ngTemplateOutlet=\"href; context: { item: item }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"!item.routerLink && !item.href\">\n          <ng-container *ngTemplateOutlet=\"text; context: { item: item }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item.children\">\n          <ng-container *ngTemplateOutlet=\"expandButton; context: { item: item }\"></ng-container>\n        </ng-container>\n      </div>\n\n      <ng-container *ngIf=\"item.isExpanded && item.children\">\n        <div class=\"fhi-tree-view-navigation__nested-group\">\n          <ng-container\n            *ngTemplateOutlet=\"navigationItems; context: { items: item.children, itemId: item.id }\"\n          ></ng-container>\n        </div>\n      </ng-container>\n    </li>\n  </ul>\n</ng-template>\n\n<ng-template #expandButton let-item=\"item\">\n  <button\n    class=\"fhi-tree-view-navigation__toggler\"\n    [attr.aria-label]=\"'Toggle ' + item.name\"\n    [attr.aria-controls]=\"'list-' + item.id\"\n    [attr.aria-haspopup]=\"'tree'\"\n    [attr.aria-expanded]=\"item.isExpanded\"\n    (click)=\"toggleExpanded(item)\"\n  >\n    <i\n      [ngClass]=\"{\n        'icon-chevron-up': item.isExpanded,\n        'icon-chevron-down': !item.isExpanded\n      }\"\n    >\n    </i>\n  </button>\n</ng-template>\n\n<ng-template #routerLink let-item=\"item\">\n  <a\n    class=\"fhi-tree-view-navigation__link\"\n    [routerLink]=\"item.routerLink\"\n    routerLinkActive=\"active\"\n    [id]=\"'label-' + item.id\"\n  >\n    {{ item.name }}\n  </a>\n</ng-template>\n\n<ng-template #href let-item=\"item\">\n  <a\n    class=\"fhi-tree-view-navigation__link\"\n    [ngClass]=\"{ active: item.hasActiveDescendant }\"\n    href=\"{{ item.href }}\"\n    [id]=\"'label-' + item.id\"\n  >\n    {{ item.name }}\n  </a>\n</ng-template>\n\n<ng-template #text let-item=\"item\">\n  <span\n    class=\"fhi-tree-view-navigation__no-link\"\n    [ngClass]=\"{ active: item.hasActiveDescendant || item.isActive }\"\n    *ngIf=\"!item.link\"\n    [id]=\"'label-' + item.id\"\n  >\n    {{ item.name }}\n  </span>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2$1.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i2$1.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewNavigationComponent, decorators: [{
            type: Component,
            args: [{ imports: [CommonModule, RouterModule], selector: 'fhi-tree-view-navigation', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"fhi-tree-view-navigation\">\n  <ng-container *ngTemplateOutlet=\"navigationItems; context: { items: items, itemId: null }\"></ng-container>\n</div>\n\n<ng-template #navigationItems let-items=\"items\" let-itemId=\"itemId\">\n  <ul\n    class=\"fhi-tree-view-navigation__list\"\n    role=\"tree\"\n    [attr.id]=\"itemId !== null ? 'list-' + itemId : null\"\n    [attr.aria-labelledby]=\"itemId !== null ? 'label-' + itemId : null\"\n  >\n    <li class=\"fhi-tree-view-navigation__item\" *ngFor=\"let item of items\" role=\"treeitem\">\n      <div class=\"d-flex w-100\">\n        <ng-container *ngIf=\"item.routerLink\">\n          <ng-container *ngTemplateOutlet=\"routerLink; context: { item: item }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item.href\">\n          <ng-container *ngTemplateOutlet=\"href; context: { item: item }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"!item.routerLink && !item.href\">\n          <ng-container *ngTemplateOutlet=\"text; context: { item: item }\"></ng-container>\n        </ng-container>\n\n        <ng-container *ngIf=\"item.children\">\n          <ng-container *ngTemplateOutlet=\"expandButton; context: { item: item }\"></ng-container>\n        </ng-container>\n      </div>\n\n      <ng-container *ngIf=\"item.isExpanded && item.children\">\n        <div class=\"fhi-tree-view-navigation__nested-group\">\n          <ng-container\n            *ngTemplateOutlet=\"navigationItems; context: { items: item.children, itemId: item.id }\"\n          ></ng-container>\n        </div>\n      </ng-container>\n    </li>\n  </ul>\n</ng-template>\n\n<ng-template #expandButton let-item=\"item\">\n  <button\n    class=\"fhi-tree-view-navigation__toggler\"\n    [attr.aria-label]=\"'Toggle ' + item.name\"\n    [attr.aria-controls]=\"'list-' + item.id\"\n    [attr.aria-haspopup]=\"'tree'\"\n    [attr.aria-expanded]=\"item.isExpanded\"\n    (click)=\"toggleExpanded(item)\"\n  >\n    <i\n      [ngClass]=\"{\n        'icon-chevron-up': item.isExpanded,\n        'icon-chevron-down': !item.isExpanded\n      }\"\n    >\n    </i>\n  </button>\n</ng-template>\n\n<ng-template #routerLink let-item=\"item\">\n  <a\n    class=\"fhi-tree-view-navigation__link\"\n    [routerLink]=\"item.routerLink\"\n    routerLinkActive=\"active\"\n    [id]=\"'label-' + item.id\"\n  >\n    {{ item.name }}\n  </a>\n</ng-template>\n\n<ng-template #href let-item=\"item\">\n  <a\n    class=\"fhi-tree-view-navigation__link\"\n    [ngClass]=\"{ active: item.hasActiveDescendant }\"\n    href=\"{{ item.href }}\"\n    [id]=\"'label-' + item.id\"\n  >\n    {{ item.name }}\n  </a>\n</ng-template>\n\n<ng-template #text let-item=\"item\">\n  <span\n    class=\"fhi-tree-view-navigation__no-link\"\n    [ngClass]=\"{ active: item.hasActiveDescendant || item.isActive }\"\n    *ngIf=\"!item.link\"\n    [id]=\"'label-' + item.id\"\n  >\n    {{ item.name }}\n  </span>\n</ng-template>\n" }]
        }], propDecorators: { items: [{
                type: Input
            }] } });

class FhiTreeViewSelectionComponent {
    constructor(changeDetector) {
        this.changeDetector = changeDetector;
        this.enableCheckAll = false;
        this.singleSelection = false;
        this.enableFilter = false;
        this.placeholder = 'Søk';
        this.itemsChange = new EventEmitter();
        this.instanceID = crypto.randomUUID();
        this.itemsFilteredIsLoading = false;
        this.itemsFilteredIsLoaded = false;
        this.searchTerm = '';
        this.$searchTerm = new Subject();
        this.resultListHeight = 'auto';
    }
    ngOnInit() {
        if (this.enableCheckAll) {
            this.singleSelection = false;
        }
        if (this.enableFilter) {
            this.getFilteredItems(this.$searchTerm).subscribe((resultItems) => {
                if (this.itemsFilteredIsLoading) {
                    this.itemsFilteredIsLoaded = true;
                    this.itemsFilteredIsLoading = false;
                    this.itemsFiltered = resultItems;
                    this.changeDetector.detectChanges();
                }
                this.resultListHeight = 'auto';
                this.changeDetector.detectChanges();
            });
        }
    }
    ngOnChanges(changes) {
        if (changes['items'].currentValue !== undefined) {
            this.createIds(this.items);
            this.updateDecendantState(this.items, true);
        }
        this.itemsChange.emit(this.items);
    }
    onSearchTermChange(searchTerm) {
        if (searchTerm.length === 0) {
            this.itemsFilteredIsLoaded = false;
            this.itemsFilteredIsLoading = false;
        }
        else {
            this.itemsFilteredIsLoading = true;
            this.updateResultListHeighWhileLoading();
        }
        this.$searchTerm.next(searchTerm);
    }
    toggleExpanded(item) {
        item.isExpanded = !item.isExpanded;
    }
    toggleChecked(id, multiToggle = false, checkAll = false) {
        this.updateCheckedState(id, this.items, multiToggle, checkAll);
        this.updateDecendantState(this.items, false);
        if (!multiToggle) {
            this.itemsChange.emit(this.items);
        }
    }
    checkAll(items) {
        items.forEach((item) => {
            this.toggleChecked(item.internal.id, true, true);
        });
        this.itemsChange.emit(this.items);
    }
    uncheckAll(items) {
        items.forEach((item) => {
            this.toggleChecked(item.internal.id, true);
        });
        this.itemsChange.emit(this.items);
    }
    allItemsChecked(items) {
        return items.every((item) => item.isChecked);
    }
    updateResultListHeighWhileLoading() {
        const heightList = this.checkboxListRef?.nativeElement.offsetHeight;
        const heightWrapper = this.resultListWrapperRef?.nativeElement.offsetHeight;
        if (heightList && !heightWrapper) {
            this.resultListHeight = heightList + 'px';
            this.resultListMaxHeight = heightList > 500 ? heightList + 'px' : '500px';
        }
        else {
            this.resultListHeight = heightWrapper + 'px';
        }
    }
    getFilteredItems($searchTerm) {
        return $searchTerm.pipe(debounceTime(400), switchMap((searchTerm) => this.getItemsFilteredBySearchTerm(searchTerm)));
    }
    getItemsFilteredBySearchTerm(searchTerm) {
        this.itemsFilteredIsLoaded = false;
        if (searchTerm === '') {
            return of(undefined);
        }
        return of(this.filterItemsRecursively(cloneDeep(this.items), searchTerm));
    }
    filterItemsRecursively(items, searchTerm) {
        return items.reduce((itemsFiltered, item) => {
            let filteredChildren;
            const partialMatch = item.name.toLowerCase().includes(searchTerm.toLocaleLowerCase());
            if (item.children?.length > 0) {
                filteredChildren = this.filterItemsRecursively(item.children, searchTerm);
            }
            if (partialMatch) {
                item.name = item.name.replace(RegExp(searchTerm, 'gi'), '<mark class="fhi-tree-view-checkbox__mark">$&</mark>');
                itemsFiltered.push({ ...item, children: filteredChildren });
            }
            if (!partialMatch && item.children && filteredChildren?.length > 0) {
                itemsFiltered.push({ ...item, children: filteredChildren });
            }
            return itemsFiltered;
        }, []);
    }
    updateCheckedState(id, items, multiToggle, checkAll) {
        items.forEach((item) => {
            if (item.internal.id === id) {
                if (multiToggle) {
                    checkAll ? (item.isChecked = true) : (item.isChecked = false);
                }
                else if (!this.singleSelection) {
                    item.isChecked = !item.isChecked;
                }
                else if (this.singleSelection) {
                    item.isChecked = true;
                }
            }
            if (this.singleSelection && item.internal.id !== id) {
                item.isChecked = null;
            }
            if (item.children && item.children.length > 0) {
                this.updateCheckedState(id, item.children, multiToggle, checkAll);
            }
        });
    }
    updateDecendantState(items, expandCheckedItems) {
        const itemsState = {
            hasExpandedDescendant: false,
            hasCheckedDescendant: false,
        };
        if (Array.isArray(items) && items.length > 0) {
            items.forEach((item) => {
                item.isChecked = !!item.isChecked;
                item.isExpanded = !!item.isExpanded;
                item.hasCheckedDescendant = !!item.hasCheckedDescendant;
                let childrenState = {
                    hasExpandedDescendant: false,
                    hasCheckedDescendant: false,
                };
                if (item.children && item.children.length > 0) {
                    childrenState = this.updateDecendantState(item.children, expandCheckedItems);
                }
                // Compute  CHECKED states
                // Update  hasCheckedDescendant for this item and the overall hasCheckedDescendant for all items in this loop that will be returned to caller
                if (item.isChecked) {
                    itemsState.hasCheckedDescendant = true;
                }
                if (childrenState.hasCheckedDescendant) {
                    itemsState.hasCheckedDescendant = true;
                    item.hasCheckedDescendant = true;
                }
                else {
                    item.hasCheckedDescendant = false;
                }
                // Compute  EXPANDED states
                // Update this items expanded and the overall hasExpandedDecendant for all items in this loop
                if (expandCheckedItems && item.isChecked) {
                    itemsState.hasExpandedDescendant = true;
                }
                itemsState.hasExpandedDescendant =
                    itemsState.hasExpandedDescendant || childrenState.hasExpandedDescendant;
                item.isExpanded = item.isExpanded || childrenState.hasExpandedDescendant;
            });
        }
        return itemsState;
    }
    createIds(items, id) {
        id = id ? id : 0;
        items.forEach((item) => {
            item.internal = {
                id: this.instanceID + '-' + ++id,
            };
            if (item.children && item.children.length > 0) {
                id = this.createIds(item.children, id);
            }
        });
        return id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewSelectionComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiTreeViewSelectionComponent, isStandalone: true, selector: "fhi-tree-view-selection", inputs: { enableCheckAll: "enableCheckAll", filterLabel: "filterLabel", singleSelection: "singleSelection", items: "items", name: "name", enableFilter: "enableFilter", placeholder: "placeholder" }, outputs: { itemsChange: "itemsChange" }, viewQueries: [{ propertyName: "checkboxListRef", first: true, predicate: ["checkboxList"], descendants: true }, { propertyName: "resultListWrapperRef", first: true, predicate: ["resultListWrapper"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"fhi-tree-view-checkbox\" *ngIf=\"items\">\n  <ng-container *ngIf=\"enableFilter; else defaultList\">\n    <ng-container *ngTemplateOutlet=\"searchInput\"></ng-container>\n\n    <ng-container *ngIf=\"itemsFilteredIsLoaded || itemsFilteredIsLoading; else defaultList\">\n      <div\n        [ngClass]=\"{ 'fhi-tree-view-checkbox__result-list': itemsFilteredIsLoading || itemsFilteredIsLoaded }\"\n        [ngStyle]=\"{ height: resultListHeight, 'max-height': resultListMaxHeight }\"\n        #resultListWrapper\n      >\n        <ng-container *ngIf=\"!itemsFilteredIsLoading; else loadingIndicator\">\n          <p *ngIf=\"itemsFiltered?.length === 0\">Ingen treff</p>\n          <ng-container\n            *ngTemplateOutlet=\"checkboxItems; context: { items: itemsFiltered, listID: instanceID }\"\n          ></ng-container>\n        </ng-container>\n        <ng-template #loadingIndicator>\n          <div class=\"spinner-border ms-5\" role=\"status\"></div>\n        </ng-template>\n      </div>\n    </ng-container>\n  </ng-container>\n\n  <ng-template #defaultList>\n    <ng-container *ngTemplateOutlet=\"checkboxItems; context: { items: items, listID: null }\"></ng-container>\n  </ng-template>\n</div>\n\n<ng-template #searchInput>\n  <div class=\"fhi-tree-view-checkbox__search fhi-search mb-5\">\n    <label\n      *ngIf=\"filterLabel\"\n      [for]=\"'search-input-' + instanceID\"\n      class=\"form-label\"\n      [id]=\"'search-input-label-' + instanceID\"\n    >\n      {{ filterLabel }}\n    </label>\n\n    <div class=\"d-flex\">\n      <div class=\"w-100 position-relative\">\n        <input\n          [id]=\"'search-input-' + instanceID\"\n          type=\"search\"\n          class=\"form-control fhi-search__form-control\"\n          placeholder=\"{{ placeholder }}\"\n          (ngModelChange)=\"onSearchTermChange($event)\"\n          [ngModel]=\"searchTerm\"\n          [attr.aria-controls]=\"'list-' + instanceID\"\n        />\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #checkboxItems let-items=\"items\" let-listID=\"listID\">\n  <ul\n    #checkboxList\n    class=\"fhi-tree-view-checkbox__list\"\n    role=\"tree\"\n    [attr.id]=\"listID !== null ? 'list-' + listID : null\"\n    aria-live=\"polite\"\n  >\n    <ng-container *ngIf=\"enableCheckAll && !itemsFilteredIsLoaded\">\n      <ng-container *ngTemplateOutlet=\"checkAndUncheckAll; context: { items: items }\"></ng-container>\n    </ng-container>\n\n    <li class=\"fhi-tree-view-checkbox__item\" *ngFor=\"let item of items\" role=\"treeitem\">\n      <ng-container *ngIf=\"item.children && !itemsFilteredIsLoaded\">\n        <ng-container *ngTemplateOutlet=\"expandButton; context: { item: item }\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngIf=\"!singleSelection\">\n        <ng-container *ngTemplateOutlet=\"checkboxItem; context: { item: item }\"></ng-container>\n      </ng-container>\n      <ng-container *ngIf=\"singleSelection\">\n        <ng-container *ngTemplateOutlet=\"radioItem; context: { item: item }\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngIf=\"(item.isExpanded && item.children) || (item.children && itemsFilteredIsLoaded)\">\n        <div class=\"fhi-tree-view-checkbox__nested-group\">\n          <ng-container\n            *ngTemplateOutlet=\"checkboxItems; context: { items: item.children, listID: item.internal?.id }\"\n          ></ng-container>\n        </div>\n      </ng-container>\n    </li>\n  </ul>\n</ng-template>\n\n<ng-template #checkAndUncheckAll let-items=\"items\">\n  <button\n    type=\"button\"\n    class=\"btn fhi-tree-view-checkbox__check-all\"\n    *ngIf=\"items?.length > 1 && !allItemsChecked(items)\"\n    (click)=\"checkAll(items)\"\n  >\n    Velg alle\n  </button>\n  <button\n    type=\"button\"\n    class=\"btn fhi-tree-view-checkbox__check-all\"\n    *ngIf=\"items?.length > 1 && allItemsChecked(items)\"\n    (click)=\"uncheckAll(items)\"\n  >\n    Fjern alle\n  </button>\n</ng-template>\n\n<ng-template #expandButton let-item=\"item\">\n  <button\n    class=\"fhi-tree-view-checkbox__toggler\"\n    [attr.aria-label]=\"'Toggle ' + item.name\"\n    [attr.aria-controls]=\"'list-' + item.internal?.id\"\n    [attr.aria-haspopup]=\"'tree'\"\n    [attr.aria-expanded]=\"item.isExpanded\"\n    (click)=\"toggleExpanded(item)\"\n  >\n    <i\n      [ngClass]=\"{\n        'icon-dash-circle': item.isExpanded && !item.hasCheckedDescendant,\n        'icon-plus-circle': !item.isExpanded && !item.hasCheckedDescendant,\n        'icon-dash-circle-fill': item.isExpanded && item.hasCheckedDescendant,\n        'icon-plus-circle-fill': !item.isExpanded && item.hasCheckedDescendant,\n      }\"\n    >\n    </i>\n  </button>\n</ng-template>\n\n<ng-template #checkboxItem let-item=\"item\">\n  <div class=\"form-check mb-2\">\n    <input\n      class=\"form-check-input\"\n      type=\"checkbox\"\n      value=\"\"\n      [id]=\"'check-input-' + item.internal?.id\"\n      [checked]=\"item.isChecked\"\n      (click)=\"toggleChecked(item.internal?.id)\"\n    />\n    <label\n      class=\"form-check-label\"\n      [for]=\"'check-input-' + item.internal?.id\"\n      [id]=\"'label-' + item.internal?.id\"\n      [innerHTML]=\"item.name\"\n    ></label>\n  </div>\n</ng-template>\n\n<ng-template #radioItem let-item=\"item\">\n  <div class=\"form-check mb-2\">\n    <input\n      class=\"form-check-input\"\n      type=\"radio\"\n      [name]=\"name\"\n      [id]=\"name + '-' + item.internal?.id\"\n      [checked]=\"item.isChecked\"\n      (change)=\"toggleChecked(item.internal?.id, false, false)\"\n    />\n    <label\n      class=\"form-check-label\"\n      [for]=\"name + '-' + item.internal?.id\"\n      [id]=\"'label-' + item.internal?.id\"\n      [innerHTML]=\"item.name\"\n    ></label>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-tree-view-selection', encapsulation: ViewEncapsulation.None, imports: [CommonModule, FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"fhi-tree-view-checkbox\" *ngIf=\"items\">\n  <ng-container *ngIf=\"enableFilter; else defaultList\">\n    <ng-container *ngTemplateOutlet=\"searchInput\"></ng-container>\n\n    <ng-container *ngIf=\"itemsFilteredIsLoaded || itemsFilteredIsLoading; else defaultList\">\n      <div\n        [ngClass]=\"{ 'fhi-tree-view-checkbox__result-list': itemsFilteredIsLoading || itemsFilteredIsLoaded }\"\n        [ngStyle]=\"{ height: resultListHeight, 'max-height': resultListMaxHeight }\"\n        #resultListWrapper\n      >\n        <ng-container *ngIf=\"!itemsFilteredIsLoading; else loadingIndicator\">\n          <p *ngIf=\"itemsFiltered?.length === 0\">Ingen treff</p>\n          <ng-container\n            *ngTemplateOutlet=\"checkboxItems; context: { items: itemsFiltered, listID: instanceID }\"\n          ></ng-container>\n        </ng-container>\n        <ng-template #loadingIndicator>\n          <div class=\"spinner-border ms-5\" role=\"status\"></div>\n        </ng-template>\n      </div>\n    </ng-container>\n  </ng-container>\n\n  <ng-template #defaultList>\n    <ng-container *ngTemplateOutlet=\"checkboxItems; context: { items: items, listID: null }\"></ng-container>\n  </ng-template>\n</div>\n\n<ng-template #searchInput>\n  <div class=\"fhi-tree-view-checkbox__search fhi-search mb-5\">\n    <label\n      *ngIf=\"filterLabel\"\n      [for]=\"'search-input-' + instanceID\"\n      class=\"form-label\"\n      [id]=\"'search-input-label-' + instanceID\"\n    >\n      {{ filterLabel }}\n    </label>\n\n    <div class=\"d-flex\">\n      <div class=\"w-100 position-relative\">\n        <input\n          [id]=\"'search-input-' + instanceID\"\n          type=\"search\"\n          class=\"form-control fhi-search__form-control\"\n          placeholder=\"{{ placeholder }}\"\n          (ngModelChange)=\"onSearchTermChange($event)\"\n          [ngModel]=\"searchTerm\"\n          [attr.aria-controls]=\"'list-' + instanceID\"\n        />\n      </div>\n    </div>\n  </div>\n</ng-template>\n\n<ng-template #checkboxItems let-items=\"items\" let-listID=\"listID\">\n  <ul\n    #checkboxList\n    class=\"fhi-tree-view-checkbox__list\"\n    role=\"tree\"\n    [attr.id]=\"listID !== null ? 'list-' + listID : null\"\n    aria-live=\"polite\"\n  >\n    <ng-container *ngIf=\"enableCheckAll && !itemsFilteredIsLoaded\">\n      <ng-container *ngTemplateOutlet=\"checkAndUncheckAll; context: { items: items }\"></ng-container>\n    </ng-container>\n\n    <li class=\"fhi-tree-view-checkbox__item\" *ngFor=\"let item of items\" role=\"treeitem\">\n      <ng-container *ngIf=\"item.children && !itemsFilteredIsLoaded\">\n        <ng-container *ngTemplateOutlet=\"expandButton; context: { item: item }\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngIf=\"!singleSelection\">\n        <ng-container *ngTemplateOutlet=\"checkboxItem; context: { item: item }\"></ng-container>\n      </ng-container>\n      <ng-container *ngIf=\"singleSelection\">\n        <ng-container *ngTemplateOutlet=\"radioItem; context: { item: item }\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngIf=\"(item.isExpanded && item.children) || (item.children && itemsFilteredIsLoaded)\">\n        <div class=\"fhi-tree-view-checkbox__nested-group\">\n          <ng-container\n            *ngTemplateOutlet=\"checkboxItems; context: { items: item.children, listID: item.internal?.id }\"\n          ></ng-container>\n        </div>\n      </ng-container>\n    </li>\n  </ul>\n</ng-template>\n\n<ng-template #checkAndUncheckAll let-items=\"items\">\n  <button\n    type=\"button\"\n    class=\"btn fhi-tree-view-checkbox__check-all\"\n    *ngIf=\"items?.length > 1 && !allItemsChecked(items)\"\n    (click)=\"checkAll(items)\"\n  >\n    Velg alle\n  </button>\n  <button\n    type=\"button\"\n    class=\"btn fhi-tree-view-checkbox__check-all\"\n    *ngIf=\"items?.length > 1 && allItemsChecked(items)\"\n    (click)=\"uncheckAll(items)\"\n  >\n    Fjern alle\n  </button>\n</ng-template>\n\n<ng-template #expandButton let-item=\"item\">\n  <button\n    class=\"fhi-tree-view-checkbox__toggler\"\n    [attr.aria-label]=\"'Toggle ' + item.name\"\n    [attr.aria-controls]=\"'list-' + item.internal?.id\"\n    [attr.aria-haspopup]=\"'tree'\"\n    [attr.aria-expanded]=\"item.isExpanded\"\n    (click)=\"toggleExpanded(item)\"\n  >\n    <i\n      [ngClass]=\"{\n        'icon-dash-circle': item.isExpanded && !item.hasCheckedDescendant,\n        'icon-plus-circle': !item.isExpanded && !item.hasCheckedDescendant,\n        'icon-dash-circle-fill': item.isExpanded && item.hasCheckedDescendant,\n        'icon-plus-circle-fill': !item.isExpanded && item.hasCheckedDescendant,\n      }\"\n    >\n    </i>\n  </button>\n</ng-template>\n\n<ng-template #checkboxItem let-item=\"item\">\n  <div class=\"form-check mb-2\">\n    <input\n      class=\"form-check-input\"\n      type=\"checkbox\"\n      value=\"\"\n      [id]=\"'check-input-' + item.internal?.id\"\n      [checked]=\"item.isChecked\"\n      (click)=\"toggleChecked(item.internal?.id)\"\n    />\n    <label\n      class=\"form-check-label\"\n      [for]=\"'check-input-' + item.internal?.id\"\n      [id]=\"'label-' + item.internal?.id\"\n      [innerHTML]=\"item.name\"\n    ></label>\n  </div>\n</ng-template>\n\n<ng-template #radioItem let-item=\"item\">\n  <div class=\"form-check mb-2\">\n    <input\n      class=\"form-check-input\"\n      type=\"radio\"\n      [name]=\"name\"\n      [id]=\"name + '-' + item.internal?.id\"\n      [checked]=\"item.isChecked\"\n      (change)=\"toggleChecked(item.internal?.id, false, false)\"\n    />\n    <label\n      class=\"form-check-label\"\n      [for]=\"name + '-' + item.internal?.id\"\n      [id]=\"'label-' + item.internal?.id\"\n      [innerHTML]=\"item.name\"\n    ></label>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { enableCheckAll: [{
                type: Input
            }], filterLabel: [{
                type: Input
            }], singleSelection: [{
                type: Input
            }], items: [{
                type: Input,
                args: [{ required: true }]
            }], name: [{
                type: Input
            }], enableFilter: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], itemsChange: [{
                type: Output
            }], checkboxListRef: [{
                type: ViewChild,
                args: ['checkboxList']
            }], resultListWrapperRef: [{
                type: ViewChild,
                args: ['resultListWrapper']
            }] } });

class FhiTreeViewRadioComponent {
    constructor() {
        this.enableFilter = false;
        this.itemsChange = new EventEmitter();
    }
    onItemsChange(items) {
        this.items = items;
        this.itemsChange.emit(this.items);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewRadioComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiTreeViewRadioComponent, isStandalone: true, selector: "fhi-tree-view-radio", inputs: { enableFilter: "enableFilter", filterLabel: "filterLabel", items: "items", name: "name" }, outputs: { itemsChange: "itemsChange" }, ngImport: i0, template: "<fhi-tree-view-selection\n  [items]=\"items\"\n  [enableFilter]=\"enableFilter\"\n  [filterLabel]=\"filterLabel\"\n  [singleSelection]=\"true\"\n  [name]=\"name\"\n  (itemsChange)=\"onItemsChange($event)\"\n></fhi-tree-view-selection>\n", dependencies: [{ kind: "component", type: FhiTreeViewSelectionComponent, selector: "fhi-tree-view-selection", inputs: ["enableCheckAll", "filterLabel", "singleSelection", "items", "name", "enableFilter", "placeholder"], outputs: ["itemsChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewRadioComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-tree-view-radio', imports: [FhiTreeViewSelectionComponent], template: "<fhi-tree-view-selection\n  [items]=\"items\"\n  [enableFilter]=\"enableFilter\"\n  [filterLabel]=\"filterLabel\"\n  [singleSelection]=\"true\"\n  [name]=\"name\"\n  (itemsChange)=\"onItemsChange($event)\"\n></fhi-tree-view-selection>\n" }]
        }], propDecorators: { enableFilter: [{
                type: Input
            }], filterLabel: [{
                type: Input
            }], items: [{
                type: Input,
                args: [{ required: true }]
            }], name: [{
                type: Input,
                args: [{ required: true }]
            }], itemsChange: [{
                type: Output
            }] } });

class FhiTreeViewCheckboxComponent {
    constructor() {
        this.enableCheckAll = false;
        this.enableFilter = false;
        this.itemsChange = new EventEmitter();
    }
    onItemsChange(items) {
        this.items = items;
        this.itemsChange.emit(this.items);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiTreeViewCheckboxComponent, isStandalone: true, selector: "fhi-tree-view-checkbox", inputs: { enableCheckAll: "enableCheckAll", enableFilter: "enableFilter", filterLabel: "filterLabel", items: "items" }, outputs: { itemsChange: "itemsChange" }, ngImport: i0, template: "<fhi-tree-view-selection\n  [items]=\"items\"\n  [enableCheckAll]=\"enableCheckAll\"\n  [enableFilter]=\"enableFilter\"\n  [filterLabel]=\"filterLabel\"\n  (itemsChange)=\"onItemsChange($event)\"\n></fhi-tree-view-selection>\n", dependencies: [{ kind: "component", type: FhiTreeViewSelectionComponent, selector: "fhi-tree-view-selection", inputs: ["enableCheckAll", "filterLabel", "singleSelection", "items", "name", "enableFilter", "placeholder"], outputs: ["itemsChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiTreeViewCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-tree-view-checkbox', imports: [FhiTreeViewSelectionComponent], template: "<fhi-tree-view-selection\n  [items]=\"items\"\n  [enableCheckAll]=\"enableCheckAll\"\n  [enableFilter]=\"enableFilter\"\n  [filterLabel]=\"filterLabel\"\n  (itemsChange)=\"onItemsChange($event)\"\n></fhi-tree-view-selection>\n" }]
        }], propDecorators: { enableCheckAll: [{
                type: Input
            }], enableFilter: [{
                type: Input
            }], filterLabel: [{
                type: Input
            }], items: [{
                type: Input,
                args: [{ required: true }]
            }], itemsChange: [{
                type: Output
            }] } });

class FhiModalComponent {
    constructor(modal) {
        this.modal = modal;
        this.openModalButtonClass = 'fhi-btn-link';
        this.openModalFromParent = false;
        this.closeModalFromParent = false;
        this.disableCloseOnAction = false;
        this.scrollable = true;
        this.size = 'md';
        this.dismissModal = new EventEmitter();
        this.modalAction = new EventEmitter();
        this.openModal = new EventEmitter();
    }
    ngOnChanges(changes) {
        if (changes['actionButtons']) {
            this.buttons = cloneDeep(this.actionButtons);
            this.buttons[this.buttons.length - 1].primary = true;
        }
        if (changes['openModalFromParent']?.currentValue === true) {
            this.modalOpen(this.modalContentRef);
        }
        if (changes['closeModalFromParent']?.currentValue === true) {
            this.modal.dismissAll();
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    onClickOpenModal(modalContent) {
        this.modalOpen(modalContent);
    }
    onModalAction(button) {
        this.modalAction.emit(button.name);
        if (!this.disableCloseOnAction) {
            this.modal.dismissAll();
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    modalOpen(modalContent) {
        this.openModal.emit();
        this.modal.open(modalContent, {
            backdropClass: 'fhi-modal-backdrop',
            windowClass: 'fhi-modal',
            scrollable: this.scrollable,
            size: this.size,
            beforeDismiss: () => {
                this.dismissModal.emit();
                return true;
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiModalComponent, deps: [{ token: i1$1.NgbModal }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiModalComponent, isStandalone: true, selector: "fhi-modal", inputs: { actionButtons: "actionButtons", modalTitle: "modalTitle", openModalButtonClass: "openModalButtonClass", openModalFromParent: "openModalFromParent", closeModalFromParent: "closeModalFromParent", disableCloseOnAction: "disableCloseOnAction", scrollable: "scrollable", size: "size" }, outputs: { dismissModal: "dismissModal", modalAction: "modalAction", openModal: "openModal" }, providers: [NgbModal], viewQueries: [{ propertyName: "modalContentRef", first: true, predicate: ["modalContent"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<button class=\"btn {{ openModalButtonClass }}\" (click)=\"onClickOpenModal(modalContent)\">\n  <ng-content select=\"[fhi-modal.button]\"></ng-content>\n</button>\n\n<ng-template #modalContent let-modal>\n  <div class=\"modal-header\">\n    <h2 class=\"modal-title\">{{ modalTitle }}</h2>\n    <button type=\"button\" class=\"btn-close\" aria-label=\"Close\" (click)=\"modal.dismiss()\"></button>\n  </div>\n  <div class=\"modal-body\">\n    <ng-content select=\"[fhi-modal.body]\"></ng-content>\n  </div>\n  <div class=\"modal-footer\">\n    <button class=\"btn fhi-btn-secondary\" *ngIf=\"!buttons || buttons.length === 0\" (click)=\"modal.dismiss()\">\n      Lukk\n    </button>\n    <button class=\"btn fhi-btn-link\" *ngIf=\"buttons && buttons.length > 0\" (click)=\"modal.dismiss()\">Avbryt</button>\n    <button\n      class=\"btn fhi-btn-{{ button.primary ? 'primary' : 'secondary' }}\"\n      [disabled]=\"button.disabled\"\n      (click)=\"onModalAction(button)\"\n      *ngFor=\"let button of buttons\"\n    >\n      {{ button.name }}\n    </button>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-modal', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [CommonModule], providers: [NgbModal], template: "<button class=\"btn {{ openModalButtonClass }}\" (click)=\"onClickOpenModal(modalContent)\">\n  <ng-content select=\"[fhi-modal.button]\"></ng-content>\n</button>\n\n<ng-template #modalContent let-modal>\n  <div class=\"modal-header\">\n    <h2 class=\"modal-title\">{{ modalTitle }}</h2>\n    <button type=\"button\" class=\"btn-close\" aria-label=\"Close\" (click)=\"modal.dismiss()\"></button>\n  </div>\n  <div class=\"modal-body\">\n    <ng-content select=\"[fhi-modal.body]\"></ng-content>\n  </div>\n  <div class=\"modal-footer\">\n    <button class=\"btn fhi-btn-secondary\" *ngIf=\"!buttons || buttons.length === 0\" (click)=\"modal.dismiss()\">\n      Lukk\n    </button>\n    <button class=\"btn fhi-btn-link\" *ngIf=\"buttons && buttons.length > 0\" (click)=\"modal.dismiss()\">Avbryt</button>\n    <button\n      class=\"btn fhi-btn-{{ button.primary ? 'primary' : 'secondary' }}\"\n      [disabled]=\"button.disabled\"\n      (click)=\"onModalAction(button)\"\n      *ngFor=\"let button of buttons\"\n    >\n      {{ button.name }}\n    </button>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.NgbModal }], propDecorators: { actionButtons: [{
                type: Input
            }], modalTitle: [{
                type: Input
            }], openModalButtonClass: [{
                type: Input
            }], openModalFromParent: [{
                type: Input
            }], closeModalFromParent: [{
                type: Input
            }], disableCloseOnAction: [{
                type: Input
            }], scrollable: [{
                type: Input
            }], size: [{
                type: Input
            }], dismissModal: [{
                type: Output
            }], modalAction: [{
                type: Output
            }], openModal: [{
                type: Output
            }], modalContentRef: [{
                type: ViewChild,
                args: ['modalContent']
            }] } });

class FhiPopoverMenuComponent {
    constructor() {
        this.triggerIcon = 'three-dots-vertical';
        this.actionEvent = new EventEmitter();
        this.popperOptions = (options) => {
            (options.placement = 'bottom-end'), 'auto';
            options.onFirstUpdate = (state) => {
                if (state.elements?.arrow) {
                    state.elements.arrow.style.display = 'none';
                }
            };
            return options;
        };
    }
    buttonAction(action) {
        this.actionEvent.emit(action);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiPopoverMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.1.2", type: FhiPopoverMenuComponent, isStandalone: true, selector: "fhi-popover-menu", inputs: { items: "items", triggerIcon: "triggerIcon" }, outputs: { actionEvent: "actionEvent" }, ngImport: i0, template: "<button\n  arrow=\"false\"\n  [autoClose]=\"true\"\n  class=\"btn fhi-popover-menu-trigger\"\n  [ngbPopover]=\"popContent\"\n  popoverClass=\"fhi-popover-menu\"\n  [popperOptions]=\"popperOptions\"\n  #popoverId=\"ngbPopover\"\n  type=\"button\"\n>\n  <i [class]=\"'icon-' + triggerIcon + ' icon-md'\"></i>\n</button>\n\n<ng-template #popContent>\n  <ul class=\"fhi-popover-menu__list\">\n    <li class=\"fhi-popover-menu__item\" *ngFor=\"let item of items\">\n      <a class=\"fhi-popover-menu__action\" [routerLink]=\"item.routerLink\" *ngIf=\"item.routerLink\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </a>\n      <a class=\"fhi-popover-menu__action\" [href]=\"item.link.href\" *ngIf=\"item.link && !item.link.download\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </a>\n      <a class=\"fhi-popover-menu__action\" [href]=\"item.link.href\" download *ngIf=\"item.link && item.link.download\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </a>\n      <button class=\"fhi-popover-menu__action\" type=\"button\" (click)=\"buttonAction(item.action)\" *ngIf=\"item.action\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </button>\n    </li>\n  </ul>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: NgbPopoverModule }, { kind: "directive", type: i1$1.NgbPopover, selector: "[ngbPopover]", inputs: ["animation", "autoClose", "ngbPopover", "popoverTitle", "placement", "popperOptions", "triggers", "positionTarget", "container", "disablePopover", "popoverClass", "popoverContext", "openDelay", "closeDelay"], outputs: ["shown", "hidden"], exportAs: ["ngbPopover"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2$1.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiPopoverMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-popover-menu', imports: [CommonModule, NgbPopoverModule, RouterModule], template: "<button\n  arrow=\"false\"\n  [autoClose]=\"true\"\n  class=\"btn fhi-popover-menu-trigger\"\n  [ngbPopover]=\"popContent\"\n  popoverClass=\"fhi-popover-menu\"\n  [popperOptions]=\"popperOptions\"\n  #popoverId=\"ngbPopover\"\n  type=\"button\"\n>\n  <i [class]=\"'icon-' + triggerIcon + ' icon-md'\"></i>\n</button>\n\n<ng-template #popContent>\n  <ul class=\"fhi-popover-menu__list\">\n    <li class=\"fhi-popover-menu__item\" *ngFor=\"let item of items\">\n      <a class=\"fhi-popover-menu__action\" [routerLink]=\"item.routerLink\" *ngIf=\"item.routerLink\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </a>\n      <a class=\"fhi-popover-menu__action\" [href]=\"item.link.href\" *ngIf=\"item.link && !item.link.download\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </a>\n      <a class=\"fhi-popover-menu__action\" [href]=\"item.link.href\" download *ngIf=\"item.link && item.link.download\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </a>\n      <button class=\"fhi-popover-menu__action\" type=\"button\" (click)=\"buttonAction(item.action)\" *ngIf=\"item.action\">\n        <i [class]=\"'icon-' + item.icon + ' icon-sm me-2'\" *ngIf=\"item.icon\"></i>\n        {{ item.name }}\n      </button>\n    </li>\n  </ul>\n</ng-template>\n" }]
        }], propDecorators: { items: [{
                type: Input,
                args: [{ required: true }]
            }], triggerIcon: [{
                type: Input
            }], actionEvent: [{
                type: Output
            }] } });

const FHI_ANGULAR_MODULES_AND_COMPONENTS = [
    FhiAutosuggestComponent,
    FhiMultiselectComponent,
    FhiTreeViewNavigationComponent,
    FhiTreeViewSelectionComponent,
    FhiTreeViewCheckboxComponent,
    FhiTreeViewRadioComponent,
    FhiModalComponent,
    FhiPopoverMenuComponent,
];
class FhiAngularComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiAngularComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.1.2", ngImport: i0, type: FhiAngularComponentsModule, imports: [FhiAutosuggestComponent,
            FhiMultiselectComponent,
            FhiTreeViewNavigationComponent,
            FhiTreeViewSelectionComponent,
            FhiTreeViewCheckboxComponent,
            FhiTreeViewRadioComponent,
            FhiModalComponent,
            FhiPopoverMenuComponent], exports: [FhiAutosuggestComponent,
            FhiMultiselectComponent,
            FhiTreeViewNavigationComponent,
            FhiTreeViewSelectionComponent,
            FhiTreeViewCheckboxComponent,
            FhiTreeViewRadioComponent,
            FhiModalComponent,
            FhiPopoverMenuComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiAngularComponentsModule, imports: [FHI_ANGULAR_MODULES_AND_COMPONENTS] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.2", ngImport: i0, type: FhiAngularComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: FHI_ANGULAR_MODULES_AND_COMPONENTS,
                    exports: FHI_ANGULAR_MODULES_AND_COMPONENTS,
                }]
        }] });

/*
 * Public API Surface of fhi-angular-components
 */

/**
 * Generated bundle index. Do not edit.
 */

export { FhiAngularComponentsModule, FhiAutosuggestComponent, FhiModalComponent, FhiMultiselectComponent, FhiPopoverMenuComponent, FhiTreeViewCheckboxComponent, FhiTreeViewNavigationComponent, FhiTreeViewRadioComponent, FhiTreeViewSelectionComponent };
//# sourceMappingURL=folkehelseinstituttet-angular-components.mjs.map
