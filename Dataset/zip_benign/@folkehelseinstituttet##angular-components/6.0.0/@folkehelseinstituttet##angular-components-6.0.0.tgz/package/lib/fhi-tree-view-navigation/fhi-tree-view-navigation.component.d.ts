import { OnChanges, SimpleChanges } from '@angular/core';
import { FhiTreeViewNavigationItem as Item } from './fhi-tree-view-navigation-item.model';
import * as i0 from "@angular/core";
export declare class FhiTreeViewNavigationComponent implements OnChanges {
    items: Item[];
    ngOnChanges(changes: SimpleChanges): void;
    toggleExpanded(item: Item): void;
    private createIds;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiTreeViewNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiTreeViewNavigationComponent, "fhi-tree-view-navigation", never, { "items": { "alias": "items"; "required": false; }; }, {}, never, never, true, never>;
}
