import { EventEmitter } from '@angular/core';
import { FhiTreeViewSelectionItem as Item } from '../fhi-tree-view-selection-item.model';
import * as i0 from "@angular/core";
export declare class FhiTreeViewRadioComponent {
    enableFilter: boolean;
    filterLabel: string;
    items: Item[];
    name: string;
    itemsChange: EventEmitter<Item[]>;
    onItemsChange(items: Item[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiTreeViewRadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiTreeViewRadioComponent, "fhi-tree-view-radio", never, { "enableFilter": { "alias": "enableFilter"; "required": false; }; "filterLabel": { "alias": "filterLabel"; "required": false; }; "items": { "alias": "items"; "required": true; }; "name": { "alias": "name"; "required": true; }; }, { "itemsChange": "itemsChange"; }, never, never, true, never>;
}
