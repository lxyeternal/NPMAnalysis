import { EventEmitter } from '@angular/core';
import { FhiTreeViewSelectionItem as Item } from '../fhi-tree-view-selection-item.model';
import * as i0 from "@angular/core";
export declare class FhiTreeViewCheckboxComponent {
    enableCheckAll: boolean;
    enableFilter: boolean;
    filterLabel: string;
    items: Item[];
    itemsChange: EventEmitter<Item[]>;
    onItemsChange(items: Item[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiTreeViewCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiTreeViewCheckboxComponent, "fhi-tree-view-checkbox", never, { "enableCheckAll": { "alias": "enableCheckAll"; "required": false; }; "enableFilter": { "alias": "enableFilter"; "required": false; }; "filterLabel": { "alias": "filterLabel"; "required": false; }; "items": { "alias": "items"; "required": true; }; }, { "itemsChange": "itemsChange"; }, never, never, true, never>;
}
