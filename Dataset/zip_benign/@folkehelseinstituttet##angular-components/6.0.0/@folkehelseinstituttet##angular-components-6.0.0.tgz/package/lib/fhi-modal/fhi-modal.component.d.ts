import { EventEmitter, SimpleChanges, OnChanges, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FhiModalActionButton } from './fhi-modal-action-button.model';
import * as i0 from "@angular/core";
export declare class FhiModalComponent implements OnChanges {
    private modal;
    actionButtons: FhiModalActionButton[];
    modalTitle: string;
    openModalButtonClass: string;
    openModalFromParent: boolean;
    closeModalFromParent: boolean;
    disableCloseOnAction: boolean;
    scrollable: boolean;
    size: string;
    dismissModal: EventEmitter<any>;
    modalAction: EventEmitter<string>;
    openModal: EventEmitter<any>;
    modalContentRef: ElementRef;
    buttons: FhiModalActionButton[];
    constructor(modal: NgbModal);
    ngOnChanges(changes: SimpleChanges): void;
    onClickOpenModal(modalContent: any): void;
    onModalAction(button: FhiModalActionButton): void;
    private modalOpen;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiModalComponent, "fhi-modal", never, { "actionButtons": { "alias": "actionButtons"; "required": false; }; "modalTitle": { "alias": "modalTitle"; "required": false; }; "openModalButtonClass": { "alias": "openModalButtonClass"; "required": false; }; "openModalFromParent": { "alias": "openModalFromParent"; "required": false; }; "closeModalFromParent": { "alias": "closeModalFromParent"; "required": false; }; "disableCloseOnAction": { "alias": "disableCloseOnAction"; "required": false; }; "scrollable": { "alias": "scrollable"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "dismissModal": "dismissModal"; "modalAction": "modalAction"; "openModal": "openModal"; }, never, ["[fhi-modal.button]", "[fhi-modal.body]"], true, never>;
}
