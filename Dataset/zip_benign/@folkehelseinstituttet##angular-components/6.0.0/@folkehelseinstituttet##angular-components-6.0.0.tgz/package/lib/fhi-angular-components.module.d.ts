import * as i0 from "@angular/core";
import * as i1 from "./fhi-autosuggest/fhi-autosuggest.component";
import * as i2 from "./fhi-multiselect/fhi-multiselect.component";
import * as i3 from "./fhi-tree-view-navigation/fhi-tree-view-navigation.component";
import * as i4 from "./fhi-tree-view-selection/fhi-tree-view-selection.component";
import * as i5 from "./fhi-tree-view-selection/fhi-tree-view-checkbox/fhi-tree-view-checkbox.component";
import * as i6 from "./fhi-tree-view-selection/fhi-tree-view-radio/fhi-tree-view-radio.component";
import * as i7 from "./fhi-modal/fhi-modal.component";
import * as i8 from "./fhi-popover-menu/fhi-popover-menu.component";
export declare class FhiAngularComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiAngularComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FhiAngularComponentsModule, never, [typeof i1.FhiAutosuggestComponent, typeof i2.FhiMultiselectComponent, typeof i3.FhiTreeViewNavigationComponent, typeof i4.FhiTreeViewSelectionComponent, typeof i5.FhiTreeViewCheckboxComponent, typeof i6.FhiTreeViewRadioComponent, typeof i7.FhiModalComponent, typeof i8.FhiPopoverMenuComponent], [typeof i1.FhiAutosuggestComponent, typeof i2.FhiMultiselectComponent, typeof i3.FhiTreeViewNavigationComponent, typeof i4.FhiTreeViewSelectionComponent, typeof i5.FhiTreeViewCheckboxComponent, typeof i6.FhiTreeViewRadioComponent, typeof i7.FhiModalComponent, typeof i8.FhiPopoverMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FhiAngularComponentsModule>;
}
