import { EventEmitter } from '@angular/core';
import { FhiMultiselectItem } from './fhi-multiselect.model';
import * as i0 from "@angular/core";
export declare class FhiMultiselectComponent {
    items: Array<FhiMultiselectItem>;
    labelForId: string | undefined;
    placeholder: string | undefined;
    disableTags: boolean | undefined;
    description: string | undefined;
    label: string;
    notFoundText: string;
    selectedItems: Array<any>;
    selectedItemsChange: EventEmitter<any[]>;
    unselect(id: string): void;
    unselectAll(): void;
    getSelectedName(selected: string): string;
    onChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiMultiselectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiMultiselectComponent, "fhi-multiselect", never, { "items": { "alias": "items"; "required": true; }; "labelForId": { "alias": "labelForId"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "disableTags": { "alias": "disableTags"; "required": false; }; "description": { "alias": "description"; "required": false; }; "label": { "alias": "label"; "required": true; }; "notFoundText": { "alias": "notFoundText"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": true; }; }, { "selectedItemsChange": "selectedItemsChange"; }, never, never, true, never>;
}
