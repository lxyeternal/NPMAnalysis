import { EventEmitter } from '@angular/core';
import { FhiAutosuggestItem } from './fhi-autosuggest.model';
import * as i0 from "@angular/core";
export declare class FhiAutosuggestComponent {
    items: Array<FhiAutosuggestItem>;
    labelForId: string | undefined;
    placeholder: string | undefined;
    description: string | undefined;
    label: string;
    selectedItem: number;
    notFoundText: string;
    selectedItemChange: EventEmitter<number>;
    onChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiAutosuggestComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiAutosuggestComponent, "fhi-autosuggest", never, { "items": { "alias": "items"; "required": true; }; "labelForId": { "alias": "labelForId"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "description": { "alias": "description"; "required": false; }; "label": { "alias": "label"; "required": true; }; "selectedItem": { "alias": "selectedItem"; "required": true; }; "notFoundText": { "alias": "notFoundText"; "required": false; }; }, { "selectedItemChange": "selectedItemChange"; }, never, never, true, never>;
}
