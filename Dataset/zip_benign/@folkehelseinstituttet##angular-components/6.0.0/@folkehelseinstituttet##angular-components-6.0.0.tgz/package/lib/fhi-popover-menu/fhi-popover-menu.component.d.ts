import { EventEmitter } from '@angular/core';
import { Options } from '@popperjs/core';
import { FhiPopoverItem } from './fhi-popover-menu.model';
import * as i0 from "@angular/core";
export declare class FhiPopoverMenuComponent {
    items: Array<FhiPopoverItem>;
    triggerIcon: string;
    actionEvent: EventEmitter<string>;
    popperOptions: (options: Partial<Options>) => Partial<Options>;
    buttonAction(action: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiPopoverMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiPopoverMenuComponent, "fhi-popover-menu", never, { "items": { "alias": "items"; "required": true; }; "triggerIcon": { "alias": "triggerIcon"; "required": false; }; }, { "actionEvent": "actionEvent"; }, never, never, true, never>;
}
