import { __decorate } from "tslib";
import { LitElement, customElement, property, query, html } from 'lit-element';
let TypeWriter = class TypeWriter extends LitElement {
    constructor() {
        super(...arguments);
        /**
         * speed multiplier
         * e.g. set "2" to make the speed 2 times faster than the initial behavior)
         * or "0.5" to make it two times slower
         */
        this.speedMultiplier = 1;
        /**
         * The speed of the caret blink (milliseconds)
         */
        this.caretBlinkingSpeed = 600;
        /**
         * Interval between the lines (in seconds)
         */
        this.timeBetween = 3;
        /**
         * loop when all the line were written ?
         */
        this.loop = false;
        this._lines = [];
        this._currentLine = '';
        this._typing = false;
        this._caretBlinkingInterval = undefined;
    }
    render() {
        return html `
    <style>
      :host {
        display: inline-flex;
        --caret-color: #424242;
      }
      #caret {
        display:inline-block;
        width: 2px;
        margin-left: 0px;
        background: var(--caret-color);
        transition: opacity .1s linear;
        opacity: 1;
        color: transparent
      }
    </style>
    <slot name="line" style="display:none"></slot>
    <span>
    <span id="line-container"></span><span id="caret">a</span>
    </span>
    `;
    }
    resetCaretBlink() {
        this.caret.style.opacity = '1';
        if (this._caretBlinkingInterval) {
            clearInterval(this._caretBlinkingInterval);
            this._caretBlinkingInterval = undefined;
        }
        this._caretBlinkingInterval = setInterval(() => this.toggleCaret(), this.caretBlinkingSpeed);
    }
    toggleCaret() {
        if (this.caret.style.opacity !== '1') {
            this.caret.style.opacity = '1';
        }
        else {
            this.caret.style.opacity = '0';
        }
    }
    /**
     * Returns a random number between from and to (both included)
     */
    random(from, to) {
        return Math.floor(Math.random() * ((to + 1) - from) + from);
    }
    sleep(milliseconds) {
        return new Promise(resolve => setTimeout(resolve, milliseconds));
    }
    async throwLetters() {
        this.resetCaretBlink();
        const typeCount = this.lineContainer.textContent.length;
        const lettersLength = this.random(1, 7);
        const nextLetters = this._currentLine.substr(typeCount, lettersLength);
        for (const letter of nextLetters) {
            // waiting between each stroke
            await this.sleep(this.random(50, 120) / this.speedMultiplier);
            this.lineContainer.textContent += letter;
        }
        // returns an indicator are there more letters to throw
        return typeCount + lettersLength < this._currentLine.length;
    }
    async start() {
        this._typing = true;
        let still;
        while (this._typing) {
            // we wait between throwing lettes to mimic someone thinking between strokes
            await this.sleep(this.random(500, 800) / this.speedMultiplier);
            still = await this.throwLetters();
            if (!still) {
                // Should jump on the next line if there is one 
                // or jump on the first line if "loop" is true
                const currentLineIndex = this._lines.indexOf(this._currentLine);
                if (currentLineIndex + 1 < this._lines.length) {
                    this._currentLine = this._lines[currentLineIndex + 1];
                }
                else if (this.loop) {
                    this._currentLine = this._lines[0];
                }
                else {
                    this.stop();
                    return;
                }
                await this.sleep(this.timeBetween * 1000);
                this.lineContainer.textContent = '';
            }
        }
    }
    stop() {
        this._typing = false;
    }
    firstUpdated() {
        this.lineSlot.addEventListener('slotchange', () => () => {
            this.stop();
            this._init();
        });
        // first init
        this._init();
    }
    _init() {
        this._lines = [...this.querySelectorAll('[slot=line]')].map(element => element.textContent.trim());
        this._currentLine = this._lines[0];
        this.start();
    }
};
__decorate([
    property({ type: Number })
], TypeWriter.prototype, "speedMultiplier", void 0);
__decorate([
    property({ type: Number })
], TypeWriter.prototype, "caretBlinkingSpeed", void 0);
__decorate([
    property({ type: Number })
], TypeWriter.prototype, "timeBetween", void 0);
__decorate([
    property({ type: Boolean })
], TypeWriter.prototype, "loop", void 0);
__decorate([
    query('#line-container')
], TypeWriter.prototype, "lineContainer", void 0);
__decorate([
    query('#caret')
], TypeWriter.prototype, "caret", void 0);
__decorate([
    query('slot[name=line]')
], TypeWriter.prototype, "lineSlot", void 0);
TypeWriter = __decorate([
    customElement('type-writer')
], TypeWriter);
