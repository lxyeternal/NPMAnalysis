# kadiya

# 游戏

##### 安装

```
npm install game-kadiya
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-kadiya/kadiya"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    imgSrc: "",
    gameSource: JSON.stringify({
      // renderType: "webgl",
      checkBound: !!true,//校验编辑不能超出容器
      baseOps: {
        width: 148,
        height: 140
      },
      items: [
        {
          scale1: { x: 0.5, y: 0.5 },
          boomSpeed: 0.8,//速度
          defaultIdx: 0,//默认显示第几张图片
          borderPadding: { left: 22, right: 22, top: 22, bottom: 22 },//虚线内边距
          scaleRange: { min: 0.5, max: 10 },//缩放范围
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01G91SMl1FJvegdPi3W_!!1080040467.png", "name": "COEUR0000.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01LXqDz71FJveaS7rC3_!!1080040467.png", "name": "COEUR0001.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01I9H4GJ1FJveaizLS4_!!1080040467.png", "name": "COEUR0002.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jogSG01FJvebtL43a_!!1080040467.png", "name": "COEUR0003.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01BemcWH1FJvef26L1d_!!1080040467.png", "name": "COEUR0004.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01R21mWh1FJveV2MjoE_!!1080040467.png", "name": "COEUR0005.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01D0X3u61FJvegdPNHJ_!!1080040467.png", "name": "COEUR0006.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01iwLs9u1FJvefsXrbr_!!1080040467.png", "name": "COEUR0007.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01CyELkF1FJveQNFivn_!!1080040467.png", "name": "COEUR0008.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zn15tj1FJvefsZsMB_!!1080040467.png", "name": "COEUR0009.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KrqUlb1FJvedJ9ffl_!!1080040467.png", "name": "COEUR0010.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jpS6B41FJvecmy1vy_!!1080040467.png", "name": "COEUR0011.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN018Kr6dy1FJvegdNxyL_!!1080040467.png", "name": "COEUR0012.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN012HXYGz1FJvebtLfUW_!!1080040467.png", "name": "COEUR0013.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN018DSfQJ1FJvegdNpgC_!!1080040467.png", "name": "COEUR0014.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01JJrBLw1FJveX5Z1SQ_!!1080040467.png", "name": "COEUR0015.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01vkwtL91FJvedJ9wK6_!!1080040467.png", "name": "COEUR0016.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012LltwK1FJveV2Lne1_!!1080040467.png", "name": "COEUR0017.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01nYORkl1FJveZ5IKoD_!!1080040467.png", "name": "COEUR0018.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01IPJwwV1FJveeKZX6w_!!1080040467.png", "name": "COEUR0019.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01FuIru01FJveaizc5X_!!1080040467.png", "name": "COEUR0020.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01HbZo5r1FJveX5ZlBO_!!1080040467.png", "name": "COEUR0021.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01GGGCSz1FJveZebWld_!!1080040467.png", "name": "COEUR0022.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01uTFrwQ1FJveWUwGQQ_!!1080040467.png", "name": "COEUR0023.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ISClFn1FJveZ5J4YD_!!1080040467.png", "name": "COEUR0024.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN0164FHmO1FJvebtMk3M_!!1080040467.png", "name": "COEUR0025.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Ltjb6M1FJveaSA4Pr_!!1080040467.png", "name": "COEUR0026.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PIjbqS1FJvecmzm1p_!!1080040467.png", "name": "COEUR0027.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lVwZ2s1FJvecmzZYO_!!1080040467.png", "name": "COEUR0028.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016C9P9C1FJvecmxd1A_!!1080040467.png", "name": "COEUR0029.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01AijGXv1FJveWUvOOM_!!1080040467.png", "name": "COEUR0030.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01BxYBb41FJveZ9zyAa_!!1080040467.png", "name": "COEUR0031.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01uTmmZa1FJveaS8awe_!!1080040467.png", "name": "COEUR0032.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01j8fRWY1FJveZA02Kf_!!1080040467.png", "name": "COEUR0033.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01cmRKQE1FJveWUxKxk_!!1080040467.png", "name": "COEUR0034.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DNWNON1FJveQNEqsy_!!1080040467.png", "name": "COEUR0035.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01chQ6L31FJveZ5JsSQ_!!1080040467.png", "name": "COEUR0036.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pngaDC1FJveQNGKOD_!!1080040467.png", "name": "COEUR0037.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01UYpWx81FJvef26L47_!!1080040467.png", "name": "COEUR0038.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01O4mulj1FJveZ5Ijlh_!!1080040467.png", "name": "COEUR0039.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01apowS21FJveeKasK7_!!1080040467.png", "name": "COEUR0040.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016ct2I11FJvebtLT2k_!!1080040467.png", "name": "COEUR0041.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Nvbdtr1FJveeKZnlO_!!1080040467.png", "name": "COEUR0042.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01E02S7K1FJveZ5HriX_!!1080040467.png", "name": "COEUR0043.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01e1TMcr1FJveV2P1Dl_!!1080040467.png", "name": "COEUR0044.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gcHFiR1FJveZ5IbT8_!!1080040467.png", "name": "COEUR0045.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZBWQmB1FJvef27HJE_!!1080040467.png", "name": "COEUR0046.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CerKxW1FJveQNIPIB_!!1080040467.png", "name": "COEUR0047.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PAY6cH1FJveZeaeki_!!1080040467.png", "name": "COEUR0048.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01t14S8f1FJveaS9w7s_!!1080040467.png", "name": "COEUR0049.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017xQEL31FJveZ9zQus_!!1080040467.png", "name": "COEUR0050.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01VbWKu11FJveaj1UZO_!!1080040467.png", "name": "COEUR0051.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013l3jXC1FJveZ5JTYV_!!1080040467.png", "name": "COEUR0052.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01s5caO81FJvegdOR7W_!!1080040467.png", "name": "COEUR0053.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01vrKHZN1FJveQNGjMk_!!1080040467.png", "name": "COEUR0054.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01QTCzrn1FJveaS8OWW_!!1080040467.png", "name": "COEUR0055.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01PFe24a1FJveaSACm5_!!1080040467.png", "name": "COEUR0056.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01AIDU0T1FJvebtNocN_!!1080040467.png", "name": "COEUR0057.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YiKgY11FJvefsbxIq_!!1080040467.png", "name": "COEUR0058.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01d1yY4B1FJveX5blvC_!!1080040467.png", "name": "COEUR0059.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01YvUycA1FJveaSBPaT_!!1080040467.png", "name": "COEUR0060.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01la9B0Y1FJvedJBolK_!!1080040467.png", "name": "COEUR0061.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Wlq4xT1FJvedJCgoI_!!1080040467.png", "name": "COEUR0062.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01h7tW4E1FJveWUxo7F_!!1080040467.png", "name": "COEUR0063.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012hbqfa1FJvef260Kd_!!1080040467.png", "name": "COEUR0064.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01t7UrJf1FJveeKZbL4_!!1080040467.png", "name": "COEUR0065.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01JSEHBh1FJveX5blvl_!!1080040467.png", "name": "COEUR0066.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01yLJPzy1FJveQNITUD_!!1080040467.png", "name": "COEUR0067.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN017yM2411FJvegdQ76M_!!1080040467.png", "name": "COEUR0068.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cf3Haq1FJveX5b6OQ_!!1080040467.png", "name": "COEUR0069.png" },
          ]
        },
        {
          scale1: { x: 0.5, y: 0.5 },
          boomSpeed: 0.8,
          defaultIdx: 0,
          borderPadding: { left: 22, right: 22, top: 22, bottom: 22 },//虚线内边距
          scaleRange: { min: 0.5, max: 10 },//缩放范围
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aZZ5Ij1FJveX5evgr_!!1080040467.png", "name": "PYRAMYDEpsb0000.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DeREPY1FJveaSDYzC_!!1080040467.png", "name": "PYRAMYDEpsb0001.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01NRPiNJ1FJvecn4g1O_!!1080040467.png", "name": "PYRAMYDEpsb0002.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01I0xQRc1FJveQNMq5v_!!1080040467.png", "name": "PYRAMYDEpsb0003.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01V7TjTW1FJvebtSmeF_!!1080040467.png", "name": "PYRAMYDEpsb0004.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01U85ITC1FJvef29paj_!!1080040467.png", "name": "PYRAMYDEpsb0005.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015is9dC1FJveaj7ni9_!!1080040467.png", "name": "PYRAMYDEpsb0006.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gTwZOb1FJveV2V3of_!!1080040467.png", "name": "PYRAMYDEpsb0007.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01a5qxHV1FJveZeglSB_!!1080040467.png", "name": "PYRAMYDEpsb0008.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qKdEG71FJveeKf2Rq_!!1080040467.png", "name": "PYRAMYDEpsb0009.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TsA2MW1FJvebtQyPk_!!1080040467.png", "name": "PYRAMYDEpsb0010.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ExWTqB1FJvefsfiWo_!!1080040467.png", "name": "PYRAMYDEpsb0011.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01SSc7uG1FJveQNLpkX_!!1080040467.png", "name": "PYRAMYDEpsb0012.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01zvNgB01FJvegdU4j9_!!1080040467.png", "name": "PYRAMYDEpsb0013.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01slXDSj1FJveZA3rhY_!!1080040467.png", "name": "PYRAMYDEpsb0014.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01damsoP1FJveaSFZk9_!!1080040467.png", "name": "PYRAMYDEpsb0015.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01p5efyc1FJvedJHahH_!!1080040467.png", "name": "PYRAMYDEpsb0016.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zREMdW1FJvefsfiXW_!!1080040467.png", "name": "PYRAMYDEpsb0017.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uu79co1FJveaSDxxI_!!1080040467.png", "name": "PYRAMYDEpsb0018.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01HUkiW91FJveeKfEx1_!!1080040467.png", "name": "PYRAMYDEpsb0019.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01OfMUNc1FJvegdVcKX_!!1080040467.png", "name": "PYRAMYDEpsb0020.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01LVTbst1FJveX5gCih_!!1080040467.png", "name": "PYRAMYDEpsb0021.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cd3l1r1FJveaSGFK4_!!1080040467.png", "name": "PYRAMYDEpsb0022.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01avm59V1FJveV2UWZE_!!1080040467.png", "name": "PYRAMYDEpsb0023.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yY9QXw1FJveaj8o7h_!!1080040467.png", "name": "PYRAMYDEpsb0024.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Mh6RHb1FJvebtSJam_!!1080040467.png", "name": "PYRAMYDEpsb0025.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jkaB331FJveZeiyi2_!!1080040467.png", "name": "PYRAMYDEpsb0026.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01oZ4Rw21FJvef2BqMI_!!1080040467.png", "name": "PYRAMYDEpsb0027.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01kfhCvG1FJveX5i9I6_!!1080040467.png", "name": "PYRAMYDEpsb0028.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01dSp56n1FJveaSFuYk_!!1080040467.png", "name": "PYRAMYDEpsb0029.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gFyoIb1FJvedJGS1v_!!1080040467.png", "name": "PYRAMYDEpsb0030.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Ysc9wz1FJveWV3eEh_!!1080040467.png", "name": "PYRAMYDEpsb0031.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN010YViot1FJveaSGFKn_!!1080040467.png", "name": "PYRAMYDEpsb0032.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01vxc0x31FJvef2AEZK_!!1080040467.png", "name": "PYRAMYDEpsb0033.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01lBjskz1FJvefsgO73_!!1080040467.png", "name": "PYRAMYDEpsb0034.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01wla6JL1FJvef2D3DB_!!1080040467.png", "name": "PYRAMYDEpsb0035.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gWxKPP1FJvefsgFoZ_!!1080040467.png", "name": "PYRAMYDEpsb0036.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YcTNYq1FJvedJH3Tm_!!1080040467.png", "name": "PYRAMYDEpsb0037.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CgKjXo1FJveeKgVze_!!1080040467.png", "name": "PYRAMYDEpsb0038.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN011NPQns1FJveQNNe2l_!!1080040467.png", "name": "PYRAMYDEpsb0039.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN011ow46z1FJveZA48Mu_!!1080040467.png", "name": "PYRAMYDEpsb0040.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01FJTq0g1FJveV2Sqas_!!1080040467.png", "name": "PYRAMYDEpsb0041.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01r2XZsZ1FJvef2D3Dl_!!1080040467.png", "name": "PYRAMYDEpsb0042.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01f8pH2p1FJveZefYes_!!1080040467.png", "name": "PYRAMYDEpsb0043.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01USf2gv1FJvedJGNug_!!1080040467.png", "name": "PYRAMYDEpsb0044.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vIHXIc1FJvefsfBIt_!!1080040467.png", "name": "PYRAMYDEpsb0045.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01FpJ20s1FJvebtS79C_!!1080040467.png", "name": "PYRAMYDEpsb0046.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01qE8SIs1FJveQNO75r_!!1080040467.png", "name": "PYRAMYDEpsb0047.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01rRbRPC1FJvefsh7tf_!!1080040467.png", "name": "PYRAMYDEpsb0048.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01jD7TJR1FJveZegtq5_!!1080040467.png", "name": "PYRAMYDEpsb0049.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gALD9G1FJvebtTSGb_!!1080040467.png", "name": "PYRAMYDEpsb0050.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vprSCS1FJvecn7QY1_!!1080040467.png", "name": "PYRAMYDEpsb0051.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01R4vLyd1FJveV2TzKa_!!1080040467.png", "name": "PYRAMYDEpsb0052.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01b7kczA1FJvecn7MOj_!!1080040467.png", "name": "PYRAMYDEpsb0053.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qBZYxi1FJvefsfBJZ_!!1080040467.png", "name": "PYRAMYDEpsb0054.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ETqlbk1FJveV2USRv_!!1080040467.png", "name": "PYRAMYDEpsb0055.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gTIdNw1FJvefshGDn_!!1080040467.png", "name": "PYRAMYDEpsb0056.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015icbdO1FJvef2C2sf_!!1080040467.png", "name": "PYRAMYDEpsb0057.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Bn2KZj1FJvegdUoVQ_!!1080040467.png", "name": "PYRAMYDEpsb0058.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IW2uRX1FJveZA3ncW_!!1080040467.png", "name": "PYRAMYDEpsb0059.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01fNHK3U1FJvegdWgtt_!!1080040467.png", "name": "PYRAMYDEpsb0060.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xEkUmb1FJveZegQj5_!!1080040467.png", "name": "PYRAMYDEpsb0061.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01dmWc3J1FJveeKgNhg_!!1080040467.png", "name": "PYRAMYDEpsb0062.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01lDyYdo1FJvefsfv58_!!1080040467.png", "name": "PYRAMYDEpsb0063.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01nbrro91FJveZehuEB_!!1080040467.png", "name": "PYRAMYDEpsb0064.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jej74c1FJveeKiKHI_!!1080040467.png", "name": "PYRAMYDEpsb0065.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01qe18h31FJveV2Tiie_!!1080040467.png", "name": "PYRAMYDEpsb0066.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jLxpGB1FJveZA54cg_!!1080040467.png", "name": "PYRAMYDEpsb0067.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gGt3rh1FJvef2BNJR_!!1080040467.png", "name": "PYRAMYDEpsb0068.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01mmf0Hp1FJveZA4fgK_!!1080040467.png", "name": "PYRAMYDEpsb0069.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01uPEOqz1FJveX5hPcP_!!1080040467.png", "name": "PYRAMYDEpsb0070.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01piK3Xt1FJveX5iLpc_!!1080040467.png", "name": "PYRAMYDEpsb0071.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN011pw2Uu1FJveeKhzVN_!!1080040467.png", "name": "PYRAMYDEpsb0072.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01MaKfsI1FJveX5gwWo_!!1080040467.png", "name": "PYRAMYDEpsb0073.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vaGSG51FJveZehdbY_!!1080040467.png", "name": "PYRAMYDEpsb0074.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01sjJ9G21FJveZA4CZq_!!1080040467.png", "name": "PYRAMYDEpsb0075.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01cTXrw01FJvedJGS67_!!1080040467.png", "name": "PYRAMYDEpsb0076.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jykDE71FJveX5gPI5_!!1080040467.png", "name": "PYRAMYDEpsb0077.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011hvHY91FJveaSGuxj_!!1080040467.png", "name": "PYRAMYDEpsb0078.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01wUMuSb1FJveZegpia_!!1080040467.png", "name": "PYRAMYDEpsb0079.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01FDniOd1FJvegdVgZz_!!1080040467.png", "name": "PYRAMYDEpsb0080.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aU3rtY1FJvef2Cqo6_!!1080040467.png", "name": "PYRAMYDEpsb0081.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01eht10m1FJvegdUoXd_!!1080040467.png", "name": "PYRAMYDEpsb0082.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01fYBWQO1FJvecn8EUz_!!1080040467.png", "name": "PYRAMYDEpsb0083.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01WcjkZL1FJveeKh7TZ_!!1080040467.png", "name": "PYRAMYDEpsb0084.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01CMKvpH1FJveZA4bXd_!!1080040467.png", "name": "PYRAMYDEpsb0085.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01j69C1P1FJveZA5oNA_!!1080040467.png", "name": "PYRAMYDEpsb0086.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01SKESl71FJvecn5t0h_!!1080040467.png", "name": "PYRAMYDEpsb0087.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01dHMJGe1FJvefsj4V7_!!1080040467.png", "name": "PYRAMYDEpsb0088.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XmcCuA1FJveV2SiMu_!!1080040467.png", "name": "PYRAMYDEpsb0089.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017wZ79d1FJveZA7tHF_!!1080040467.png", "name": "PYRAMYDEpsb0090.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN0160J8Jr1FJveZA6kbv_!!1080040467.png", "name": "PYRAMYDEpsb0091.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01HzZkiV1FJvegdWHzi_!!1080040467.png", "name": "PYRAMYDEpsb0092.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010iX8Qf1FJveV2WfiQ_!!1080040467.png", "name": "PYRAMYDEpsb0093.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01JCg1C31FJveZ5PS0N_!!1080040467.png", "name": "PYRAMYDEpsb0094.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01SF3QhZ1FJveZA69B6_!!1080040467.png", "name": "PYRAMYDEpsb0095.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Un9DWu1FJveX5g8ed_!!1080040467.png", "name": "PYRAMYDEpsb0096.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01TQTBYC1FJveaSG2yp_!!1080040467.png", "name": "PYRAMYDEpsb0097.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CA6mr11FJveZejaDv_!!1080040467.png", "name": "PYRAMYDEpsb0098.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01vLKmTi1FJveX5gfwv_!!1080040467.png", "name": "PYRAMYDEpsb0099.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01UK4dIF1FJveajA5Es_!!1080040467.png", "name": "PYRAMYDEpsb0100.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gxyH3M1FJvebtSeUr_!!1080040467.png", "name": "PYRAMYDEpsb0101.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01OCRBYt1FJvef2CW3T_!!1080040467.png", "name": "PYRAMYDEpsb0102.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01phwjNu1FJvegdX5v4_!!1080040467.png", "name": "PYRAMYDEpsb0103.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ULSyXp1FJveaj78HW_!!1080040467.png", "name": "PYRAMYDEpsb0104.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01bUxAU81FJveeKgJby_!!1080040467.png", "name": "PYRAMYDEpsb0105.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015RLx2d1FJvegdWYf1_!!1080040467.png", "name": "PYRAMYDEpsb0106.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01t15iuL1FJvefsi4AK_!!1080040467.png", "name": "PYRAMYDEpsb0107.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01vSTxsh1FJveZ5Oyx6_!!1080040467.png", "name": "PYRAMYDEpsb0108.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01O12T1Q1FJvefshC8K_!!1080040467.png", "name": "PYRAMYDEpsb0109.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01aiRR0m1FJveX5h92q_!!1080040467.png", "name": "PYRAMYDEpsb0110.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015M0kwM1FJveQNQWvX_!!1080040467.png", "name": "PYRAMYDEpsb0111.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01SGMPoI1FJveaj90j1_!!1080040467.png", "name": "PYRAMYDEpsb0112.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014M2DiG1FJvef2CBH4_!!1080040467.png", "name": "PYRAMYDEpsb0113.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01460Xc11FJvebtVnuP_!!1080040467.png", "name": "PYRAMYDEpsb0114.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01rYi3ot1FJveZA7M2J_!!1080040467.png", "name": "PYRAMYDEpsb0115.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01eH4HUz1FJveV2TaSO_!!1080040467.png", "name": "PYRAMYDEpsb0116.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01eRtVtV1FJvegdXZ2E_!!1080040467.png", "name": "PYRAMYDEpsb0117.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01c2g9iA1FJveaSHrEQ_!!1080040467.png", "name": "PYRAMYDEpsb0118.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01V7WlSH1FJveX5jYiM_!!1080040467.png", "name": "PYRAMYDEpsb0119.png" },
          ]
        },
        {
          boomSpeed: 0.8,
          defaultIdx: 78,
          borderPadding: { left: 22, right: 22, top: 22, bottom: 22 },//虚线内边距
          scaleRange: { min: 0.5, max: 10 },//缩放范围
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Rde7v51FJveX5n3As_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0000.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01X2jHs31FJvefsnuDW_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0001.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01K5vTzV1FJveWV8PpV_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0002.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012JnkCO1FJveZ5TTl3_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0003.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dPgXXk1FJvecnAFZl_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0004.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vpTf8m1FJvefslcpy_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0005.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01SgxUBJ1FJveajEB8b_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0006.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zI2DNE1FJvef2Icj7_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0007.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01I1PV8L1FJvefsnR6F_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0008.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01U93V3Z1FJveZACadr_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0009.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0195ixUp1FJvedJMpMs_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0010.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01JrEJAI1FJveQNWlzN_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0011.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0137VCNM1FJvecnAJjh_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0012.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XCzjR11FJvef2Ht01_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0013.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01G4vdHq1FJveX5lAnD_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0014.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RZFAh91FJveZemsJL_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0015.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01bfwTkU1FJvedJNtvb_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0016.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01D7pUyF1FJvef2H0vQ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0017.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mpPNiA1FJveZ5VUWL_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0018.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01W4Eio11FJvedJM5gd_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0019.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01pZPBJc1FJvegdaijt_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0020.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01rH3Aj21FJveZ5SoC4_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0021.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XbmNlx1FJvef2G8sl_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0022.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ukfQ3j1FJveZ5UHgg_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0023.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01WVVea21FJveaSLgTc_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0024.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Lpw1Lg1FJvecnDs8C_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0025.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01m5KPv11FJvebtXYKC_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0026.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01NWkgw81FJveZAAe5E_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0027.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN011cSz8K1FJveZA9ZYC_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0028.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01x1rDrw1FJveZ5SsM8_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0029.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Qwt4SE1FJveWV9M3m_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0030.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN018s4fr71FJvef2K6FQ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0031.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01lr2lfY1FJveQNTp24_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0032.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01I4dSOh1FJveaSLgUA_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0033.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01KWvzxr1FJvecnAaNZ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0034.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EKrtLU1FJveWV9pAE_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0035.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN018Nuyx21FJvedJNUyq_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0036.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01j0Yo1O1FJveZABFXF_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0037.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01QXz9t61FJveZeo9JJ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0038.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EEIMgG1FJvefsm1pY_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0039.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01VMfUWR1FJveZ5VUXw_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0040.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01fLRhGb1FJveZeoorl_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0041.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011ekS8a1FJvefsllCf_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0042.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01bew7Oq1FJveaSJjx2_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0043.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01og2Sfv1FJveZACODd_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0044.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01kNaPsB1FJveZAAysz_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0045.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013FwQh71FJveX5kq1F_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0046.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01o4swPN1FJvecnD8Pf_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0047.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bre9uR1FJveX5mqlD_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0048.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01QnsrRN1FJvefsmpj4_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0049.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01orXMN41FJveZABeUh_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0050.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ANkPAT1FJveQNXytx_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0051.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dtgIr01FJveZep9eE_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0052.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Y3wrlI1FJveWVB1zJ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0053.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01miWDh11FJvebtY5ch_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0054.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Vr0zuZ1FJvebtaq5b_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0055.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mjonaU1FJvegddP6O_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0056.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01PVwB3k1FJveajEuuL_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0057.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aJ46a01FJveWVB69d_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0058.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01hZONeG1FJvedJLYQU_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0059.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nYKkty1FJveQNWEmV_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0060.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016LQUWV1FJveZepDnF_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0061.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01liFlzq1FJveQNXNU8_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0062.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01NgPb461FJveZenLT3_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0063.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01li2ZTI1FJveX5ldv8_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0064.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RY4ziV1FJvefsmlam_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0065.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nGe37Y1FJveZeoDUi_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0066.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01vPTplU1FJvefsomLm_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0067.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01tTFuHT1FJvegdb7jZ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0068.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ffuW9w1FJveWV8gXL_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0069.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ykRlHn1FJveWV9HxT_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0070.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01feOBwf1FJvef2I5XH_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0071.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01bm5SZj1FJveQNVIZZ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0072.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01oSSm8k1FJvef2H9J4_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0073.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XZAvLZ1FJveWV9YaJ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0074.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012kLmOQ1FJveeKnIMk_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0075.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01hN8SWF1FJveZAAJLo_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0076.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01SbIMwJ1FJvegdd0AG_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0077.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01yBe7CW1FJvef2JMZE_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0078.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01TyTNUO1FJveX5mmdN_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0079.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mmZXS81FJvecnC3uh_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0080.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01WZOAJ71FJveeKlkki_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0081.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ralZjh1FJveZABaMn_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0082.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN013bXiFu1FJveZeoPzT_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0083.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jgP9Ml1FJveWV8khK_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0084.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dqrDuZ1FJvef2IMBb_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0085.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Vup5Ce1FJveQNWN8D_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0086.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dXpApI1FJvef2KEdI_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0087.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lIFNdj1FJvegdd4LG_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0088.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ElwE021FJveZ5VDy7_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0089.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cRUWdW1FJveV2bIyN_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0090.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vWUhZG1FJveZACBoV_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0091.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01GrlXVJ1FJveeKolpq_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0092.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01L3tBMs1FJveeKopzg_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0093.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ZMboh91FJveX5mz7P_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0094.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Wsnnl31FJvebtadg3_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0095.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01eOmdJs1FJvecnDo3j_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0096.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xy8Lyh1FJveV2adP8_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0097.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ky8ZBg1FJveZ5Todx_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0098.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01B431zs1FJveeKlxGi_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0099.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01kyOtVV1FJvef2I9iN_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0100.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Szm43Y1FJveWV9M8o_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0101.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01oXxVTc1FJvecnCrpQ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0102.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01NS4vf21FJvecnBzmE_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0103.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01QGiIJN1FJveeKoEaY_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0104.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0192oItx1FJveZepDq7_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0105.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01iXDvEZ1FJveeKnQhq_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0106.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01v1jscE1FJvecnDo4W_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0107.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01V0bM5H1FJveeKohh4_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0108.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ZDAF0X1FJveWVBV9O_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0109.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010tsv121FJveX5nJvj_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0110.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01DXzfJZ1FJvefsoe4I_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0111.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012gDpOF1FJveQNWm6U_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0112.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN018pDM951FJveZ5TTtB_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0113.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01yQaA7g1FJvef2LRTz_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0114.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01xJ9eck1FJvef2Jtsq_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0115.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Txp5aW1FJveZeqMYU_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0116.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01pLNgSr1FJveQNYzMa_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0117.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Bqbpt01FJveeKnZ0y_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0118.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01B40qEK1FJvecnC3xX_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0119.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN010LZVmv1FJveX5ldz5_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0120.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gk8QDb1FJvedJOEqf_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0121.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01BHKoUH1FJveZACziX_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0122.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jLCluv1FJveV2aAMQ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0123.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010iAbbi1FJveZ5XAZw_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0124.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01BAuwPv1FJveZeqZ2h_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0125.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PWlrq91FJveajFSEV_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0126.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01mRQ7fB1FJveZ5U9TS_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0127.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01OeOqLU1FJveX5nSFs_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0128.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01u7UjQb1FJvebtayUK_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0129.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01qiMrSq1FJveWVAlS9_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0130.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01c1AloY1FJvedJNV5F_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0131.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013yTBxe1FJvef2KhmL_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0132.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01sTiXxD1FJvef2J1ol_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0133.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01c8ICAr1FJveZ5VE10_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0134.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01L75ksy1FJvecnF9FZ_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0135.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01SRcc5Y1FJveajHKiT_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0136.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN014AmFXJ1FJvefsoNSj_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0137.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01N56hX11FJvedJPa0E_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0138.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ov2nt21FJveZACvYz_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0139.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN0144mxGR1FJveZADGLO_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0140.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xZvYG01FJveeKmMC4_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0141.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0187XHUP1FJvegdcw4W_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0142.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01954lsY1FJveajG7qb_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0143.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0124y4ax1FJvecnF9Fy_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0144.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Z9BPdA1FJveV2byZn_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0145.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN010LcMbp1FJveZeplAE_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0146.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01zUHTDX1FJvefsnRGX_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0147.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018dezmU1FJvefsn2Jf_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0148.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01npxBjM1FJveQNWuSW_!!1080040467.png", "name": "COUCHE-DE-SOLEIL0149.png" },
          ]
        },
        {
          boomSpeed: 0.8,
          defaultIdx: 55,
          borderPadding: { left: 22, right: 22, top: 22, bottom: 22 },//虚线内边距
          scaleRange: { min: 0.5, max: 10 },//缩放范围
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01xZJ2gL1FJvehiNHGY_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0000.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DFU9eN1FJvee3thSq_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0001.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NuTuFL1FJveZuyJGJ_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0002.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01LeZ27N1FJvegolr7a_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0003.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01PdJDUi1FJvejyGW1c_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0004.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xM00MB1FJvekpSE7k_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0005.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Mvk9UN1FJveeZNq87_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0006.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01N0636w1FJveeZPzAI_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0007.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010vDMAX1FJveVGnpwI_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0008.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01hwuhRE1FJveVGoNCv_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0009.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ivuFT01FJvebyqkfG_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0010.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dxrt881FJvebyoGpM_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0011.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01hQqJ7B1FJvebObUXn_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0012.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CAUs4T1FJvefNG7Mq_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0013.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01BoRCV21FJvehiLfUa_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0014.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BfmFVj1FJveeZNItw_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0015.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018eEO6a1FJvedyyyV5_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0016.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01GWZ6x71FJvebOYk4Z_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0017.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01sF8oWu1FJvedyyltH_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0018.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Sr9Oja1FJvefND1xt_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0019.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01SbpdIP1FJvekpScyb_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0020.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Datlq71FJveZuxMwb_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0021.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Yf5oSq1FJvejG0C2V_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0022.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01XFaUDm1FJveiDr0m8_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0023.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01V9JcMk1FJvedyxEIR_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0024.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01rIWlym1FJvebOaDQU_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0025.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01HcCfat1FJvehiK7jD_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0026.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01THUhsa1FJveVGpB5H_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0027.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01m5g7XI1FJveeZN2FF_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0028.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Pe4y9Q1FJvejG4LvU_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0029.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01h9spLh1FJveVGoNBT_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0030.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01g6n1EV1FJveZuwUu6_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0031.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018bgcXd1FJvegoiQyv_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0032.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0157QUCw1FJvehiIB6k_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0033.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01HWuyfP1FJvehiLngR_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0034.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01WbT9rs1FJvekpQLZy_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0035.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RPTYuD1FJvejG18Eg_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0036.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Pimswq1FJvee3s5ZN_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0037.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Uxs3H81FJvebyrDmn_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0038.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RNJwbr1FJvegoj2Tx_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0039.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN010GPuE71FJvefebcKp_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0040.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pM31t61FJvelZGkdo_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0041.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015TZUnD1FJvedz02yQ_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0042.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ryIZg71FJveiDq4dR_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0043.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01JxmLkJ1FJvehiMo4b_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0044.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tSlhfG1FJvelZH9ay_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0045.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jvVWYq1FJvejyHink_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0046.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01LTnEUm1FJvejyHJqm_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0047.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01dIThNa1FJveiDq0VO_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0048.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tgQPrY1FJvee3qLYS_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0049.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01JTikhx1FJvefeabvZ_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0050.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015Kb6qS1FJveZuwQls_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0051.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01oE0Pfq1FJveVGoJ4A_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0052.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN014qVWW71FJvefebgQk_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0053.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01No03Qh1FJvejyFAoQ_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0054.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jYyFdQ1FJvebyp8oH_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0055.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01uCLuTe1FJveVGoZja_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0056.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN014UMevV1FJvehiN8tV_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0057.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aiBsrB1FJveiDpKvB_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0058.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01776JmZ1FJvekpPoMK_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0059.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01cLY5Ti1FJvee3sYkY_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0060.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xdxs1w1FJvebypLJw_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0061.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Kie3kp1FJvegojRRT_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0062.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01FFRPV01FJvebynbG0_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0063.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01D2Ezny1FJvedz0RwN_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0064.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01LYGQF71FJveVGouXh_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0065.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BmDXhh1FJvegoji2S_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0066.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01eFPjlJ1FJvekpTQvf_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0067.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01hC3fNw1FJvejyGz52_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0068.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01I0xjvb1FJvejG0Wst_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0069.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qt02L81FJvehiKrWc_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0070.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01YP6WJT1FJvefNEAkr_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0071.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01mqoRO91FJvebypCzZ_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0072.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZEHaEo1FJveiDrka0_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0073.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01QbEKb61FJvefND6E1_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0074.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01rlRGEM1FJvegolimo_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0075.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012ZlWgM1FJvebOa5DX_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0076.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01oaoFTa1FJveeZNVKx_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0077.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01boQJS21FJvelZFwjh_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0078.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01CpA5De1FJvefeasZb_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0079.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ztvH2p1FJvebypXm2_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0080.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Db8ExX1FJveiDs1Bt_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0081.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Rf63up1FJvejG1XDj_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0082.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01gyLgEQ1FJveiDrY56_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0083.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PlmRqh1FJvefNEqGZ_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0084.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01v6vGwU1FJvee3rUCM_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0085.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ufitaq1FJvelZGHWs_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0086.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Er7RIi1FJvehiLKaL_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0087.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01TyKD9G1FJvekpRxTq_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0088.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01t2eFN31FJvebOZTn3_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0089.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01kll6mx1FJveeZN6Id_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0090.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aNXMZO1FJvelZE4Kb_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0091.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018npqHe1FJvefecxRA_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0092.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN014RKiLE1FJvehiLKaT_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0093.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01z44YSK1FJvehiM4Mj_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0094.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010nmczR1FJvekpRcdN_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0095.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN018f4PSK1FJvebypbuc_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0096.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01COJKkX1FJvebypsYL_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0097.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010v14jm1FJveiDs5Mu_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0098.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01NTjNGB1FJvedyx1sV_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0099.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01MXLEAG1FJvefNDANP_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0100.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01sxdHTi1FJvekpSpWn_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0101.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01iTai1Y1FJveVGr3an_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0102.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01FvxLIV1FJvehiJvLm_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0103.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01TDzsvo1FJvejyHaXO_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0104.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN019gS5ac1FJveiDp06t_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0105.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Cqxo71FJvebOYoAg_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0106.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mWHnQV1FJvedz0FSm_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0107.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN010UwqTx1FJvedz0Nl9_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0108.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jh8zGS1FJvegokuqX_!!1080040467.png", "name": "ECRIN-OUVERT_NOIR0109.png" },
          ]
        },
        {
          boomSpeed: 0.6,
          defaultIdx: 0,
          borderPadding: { left: 22, right: 22, top: 22, bottom: 22 },//虚线内边距
          scaleRange: { min: 0.5, max: 10 },//缩放范围
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014iPybp1FJveZANKrt_!!1080040467.png", "name": "3-ECRINS20000.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN0132Czza1FJvebtnvuo_!!1080040467.png", "name": "3-ECRINS20001.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zecCQv1FJveV2obBA_!!1080040467.png", "name": "3-ECRINS20002.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Zl16lw1FJveaSaFlW_!!1080040467.png", "name": "3-ECRINS20003.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01efxlK11FJvef2WejI_!!1080040467.png", "name": "3-ECRINS20004.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01o4P3dY1FJveZ5kfOu_!!1080040467.png", "name": "3-ECRINS20005.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PKq1vw1FJveZARd14_!!1080040467.png", "name": "3-ECRINS20006.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01oZYgMh1FJveX5ybIb_!!1080040467.png", "name": "3-ECRINS20007.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01NufaUW1FJveZf47yN_!!1080040467.png", "name": "3-ECRINS20008.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017CFw1Z1FJvegdqZ5Q_!!1080040467.png", "name": "3-ECRINS20009.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01galVux1FJveZ5mLJ5_!!1080040467.png", "name": "3-ECRINS20010.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TUshlQ1FJveeL1KLa_!!1080040467.png", "name": "3-ECRINS20011.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01hScYRS1FJveeL3k3O_!!1080040467.png", "name": "3-ECRINS20012.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN013bX0Fk1FJveWVQbhM_!!1080040467.png", "name": "3-ECRINS20013.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01UEGHpS1FJveQNmkf5_!!1080040467.png", "name": "3-ECRINS20014.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AVpME21FJveZAOTaG_!!1080040467.png", "name": "3-ECRINS20015.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01YgCahS1FJveZ5m0YG_!!1080040467.png", "name": "3-ECRINS20016.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RVNQw11FJveWVPT1N_!!1080040467.png", "name": "3-ECRINS20017.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN016J3G7y1FJveeL1azJ_!!1080040467.png", "name": "3-ECRINS20018.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZtGj2Q1FJveQNlgAp_!!1080040467.png", "name": "3-ECRINS20019.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01HOMzwl1FJveZAPgQC_!!1080040467.png", "name": "3-ECRINS20020.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN0101THwR1FJvecnSROm_!!1080040467.png", "name": "3-ECRINS20021.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01OjtuxB1FJveZf5CUf_!!1080040467.png", "name": "3-ECRINS20022.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01MQFoHq1FJveV2qkFU_!!1080040467.png", "name": "3-ECRINS20023.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PJ5rJq1FJveX62I2C_!!1080040467.png", "name": "3-ECRINS20024.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Px8OiQ1FJveQNkwS3_!!1080040467.png", "name": "3-ECRINS20025.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Nt67eA1FJveV2ojWP_!!1080040467.png", "name": "3-ECRINS20026.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015wYhpX1FJveeL1zwQ_!!1080040467.png", "name": "3-ECRINS20027.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN0128qDso1FJveZf5T7n_!!1080040467.png", "name": "3-ECRINS20028.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qnMSRf1FJvecnQd9v_!!1080040467.png", "name": "3-ECRINS20029.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018jalW01FJveV2nzmI_!!1080040467.png", "name": "3-ECRINS20030.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01C2A3by1FJveZf43qE_!!1080040467.png", "name": "3-ECRINS20031.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010F5lUF1FJveajT9Vr_!!1080040467.png", "name": "3-ECRINS20032.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01729uh21FJvebtoXO5_!!1080040467.png", "name": "3-ECRINS20033.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ahaQgD1FJvedJcGrg_!!1080040467.png", "name": "3-ECRINS20034.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN016eTdED1FJvef2WvPu_!!1080040467.png", "name": "3-ECRINS20035.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01b1S0v61FJveZ5m4ir_!!1080040467.png", "name": "3-ECRINS20036.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014gMBYn1FJveajVdLP_!!1080040467.png", "name": "3-ECRINS20037.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01KcQRme1FJveaSbKKj_!!1080040467.png", "name": "3-ECRINS20038.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01cnWTJA1FJveft4cd3_!!1080040467.png", "name": "3-ECRINS20039.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01OxvQzC1FJvef2Vv37_!!1080040467.png", "name": "3-ECRINS20040.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01SOM1Vr1FJveX608yu_!!1080040467.png", "name": "3-ECRINS20041.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uTQ3HC1FJveajWhtz_!!1080040467.png", "name": "3-ECRINS20042.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01MBjdom1FJveZAOkG1_!!1080040467.png", "name": "3-ECRINS20043.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01XhhWjV1FJveajWVR3_!!1080040467.png", "name": "3-ECRINS20044.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Ipya8B1FJveZf4Ods_!!1080040467.png", "name": "3-ECRINS20045.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017fkj1O1FJvedJfDoX_!!1080040467.png", "name": "3-ECRINS20046.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01t8C4VE1FJveZf4jPf_!!1080040467.png", "name": "3-ECRINS20047.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01kNnVxh1FJveZARpX7_!!1080040467.png", "name": "3-ECRINS20048.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01VRUWQE1FJvecnSmEU_!!1080040467.png", "name": "3-ECRINS20049.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01u4O85H1FJveX60kQ9_!!1080040467.png", "name": "3-ECRINS20050.png" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN0127QiCz1FJveaSbjJ9_!!1080040467.png", "name": "3-ECRINS20051.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN013RAyP81FJvef2XvoG_!!1080040467.png", "name": "3-ECRINS20052.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01R2J2Wr1FJveft4go7_!!1080040467.png", "name": "3-ECRINS20053.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gpRq7n1FJvedJcjzA_!!1080040467.png", "name": "3-ECRINS20054.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01BN0hzi1FJvecnR28r_!!1080040467.png", "name": "3-ECRINS20055.png" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nm4a941FJvegdsufY_!!1080040467.png", "name": "3-ECRINS20056.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Tefi3U1FJveft30sm_!!1080040467.png", "name": "3-ECRINS20057.png" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01BLWf1f1FJvedJfUSh_!!1080040467.png", "name": "3-ECRINS20058.png" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013LWkK51FJveeL3TU1_!!1080040467.png", "name": "3-ECRINS20059.png" },
          ]
        },
      ],
      play: [
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aUKV1u1FJvefu0E8n_!!1080040467.png", type: "rotate" },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qsMp5d1FJvea05LaN_!!1080040467.png", type: "scale" },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zlvzge1FJvea06cb9_!!1080040467.png", type: "close" },
        // { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GZenR61FJveeJ1nmO_!!1080040467.png", type: "border", shu: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mNzpgS1FJvegV4Ala_!!1080040467.png" }, heng: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01sKWmH51FJveZ1n9sG_!!1080040467.png" } },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012z7eJi1FJvegVR408_!!1080040467.png", type: "border", shu: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mNzpgS1FJvegV4Ala_!!1080040467.png" }, heng: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01sKWmH51FJveZ1n9sG_!!1080040467.png" } },
      ]
    }),
    imgs: [],
  },
  onLoad(query) {
  },
  playAni() {
    this.gameComponent.onEvent("playAni");
  },
  stopAni() {
    this.gameComponent.onEvent("stopAni");
  },
  addSprite(e) {
    let { currentTarget: { dataset: { idx } } } = e;
    this.gameComponent.onEvent("renderSprite", idx)
  },
  reset() {
    this.gameComponent.onEvent("reset");
  },
  selectOrCreate() {
    this.gameComponent.onEvent("selectOrCreate", 0);
  },
  clearAll(){
    this.gameComponent.onEvent("clearAll");
  },
  async exportImg() {
    // this.gameComponent.onEvent("stopAni");//停止动画播放
    this.gameComponent.onEvent("changePlay");//隐藏操作按钮
    // let base64 = await this.gameComponent.onEvent("getCanvasImg", { x: 0, y: 0, width: 100, height: 100 });
    // let base64 = this.gameComponent.onEvent("capture");
    let base64 = await this.gameComponent.onEvent("getCanvasImg");
    this.setData({
      imgSrc: base64
    })
  },
  getPos() {
    let arr = this.gameComponent.onEvent("getPos");
    arr.forEach(item => {
      item.rotation = item.otherInfo.rotation / Math.PI * 180
    })
    this.setData({
      imgs: arr
    })
    console.log(arr)
  },

  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone(canvas) {
    my.alert({ content: !!canvas.toTempFilePath })
    // console.log(canvas)
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // 参数传入 gameSource.items 数组下标
    // this.gameComponent.onEvent("renderSprite", 0);
    // this.gameComponent.onEvent("renderSprite", 1);
    // this.gameComponent.onEvent("renderSprite", 2);
    // this.gameComponent.onEvent("renderSprite", 3);
    this.gameComponent.onEvent("renderSprite", 4);
  },
  onSelect(data) {
    console.log(data)
  },
  onRemove(data) {
    // 删除回调
    console.log(data)
  },
  renderImg() {
    this.gameComponent.onEvent("renderImg", {
      src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01XJcsgi1FJvZ6cJH0i_!!1080040467.jpg",
      width: 580,
      height: 340,
      x: 0,
      y: 0,
    });
  },
  backLog() {
    this.gameComponent.onEvent("backLog");
  }
})
```

- xaml

```
  <game gameSource="{{gameSource}}" 
    onRef="onRef"
    onInitDone="onInitDone" 
    onSelect="onSelect"
    onUpdate="onUpdate" 
    onGameOver="onGameOver"
    onRemove="onRemove"
    />

  <text onTap="playAni">播放动画</text>
  <text onTap="stopAni">停止动画</text>
  <text onTap="reset">重置</text>
  <text onTap="exportImg">导出图片</text>
  <text onTap="getPos">获取位置</text>
  <text onTap="renderImg">渲染图片</text>
  <text onTap="backLog">撤销</text>
  <text onTap="selectOrCreate">选中或创建</text>
  <text onTap="clearAll">清空</text>
  <text onTap="addSprite" data-idx="0">添加元素1</text>
  <text onTap="addSprite" data-idx="1">添加元素2</text>
  <text onTap="addSprite" data-idx="2">添加元素3</text>
  <text onTap="addSprite" data-idx="3">添加元素4</text>
  <text onTap="addSprite" data-idx="4">添加元素5</text>
  <image mode="scaleToFill" src="{{imgSrc}}" a:if="{{!!imgSrc}}"/>
```