/**
 # Module Dependencies
 */
import { ScalableObject, ScalableCollection } from './types';
/**
 # Functions
 */
/**
 * Finds the average of an array of numbers.
 * @param array An array of numbers.
 */
export declare function averageArray(array: number[]): number;
/**
 * Finds the average of an object of number values.
 * @param object An object containing only number values.
 */
export declare function averageObject(object: ScalableObject): number;
/**
 * Finds the average of an array or an object of number values.
 * @param collection An object or an array containing only number values.
 */
export declare function average(collection: ScalableCollection): number;
/**
 * Finds the average of an array or an object of number values.
 * Identical to average().
 * @param collection An object or an array containing only number values.
 */
export declare function mean(collection: ScalableCollection): number;
/**
 * Finds the standard deviation of an array of numbers.
 * @param array An array of numbers.
 */
export declare function standardDeviationArray(array: number[]): number;
/**
 * Finds the standard deviation of an object of number values.
 * @param object An object containing only number values.
 */
export declare function standardDeviationObject(object: ScalableObject): number;
/**
 * Finds the standard deviation of an array or an object of number values.
 * @param collection An object or an array containing only number values.
 */
export declare function standardDeviation(collection: ScalableCollection): number;
/**
 * Finds the standard deviation of an array or an object of number values.
 * Identical to standardDeviation().
 * @param collection An object or an array containing only number values.
 */
export declare function stDev(collection: ScalableCollection): number;
