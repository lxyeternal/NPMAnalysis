import { ScalableCollection, ScalableObject } from './types';
/**
 * Validates whether or not an object of values is normalized.
 * @param object        An object containing only number values.
 * @param scale         Scale that the sum of the array should add up to (default 1).
 * @param tolerance     The tolerable variablity in comparison to account for floating point math.
 *                      Defaults to Number.EPSILON.
 */
export declare function isScaledNormalObject(object: ScalableObject, scale?: number, tolerance?: number): boolean;
/**
 * Validates whether or not an object of values is normalized.
 * @param object        An object containing only number values.
 * @param tolerance     The tolerable variablity in comparison to account for floating point math.
 *                      Defaults to Number.EPSILON.
 */
export declare function isNormalizedObject(object: ScalableObject, tolerance?: number): boolean;
/**
 * Validates whether or not an array or object is scaled to a defined value (default 1).
 * @param collection    An object or an array containing only number values.
 * @param scale         Scale that the sum of the array should add up to (default 1).
 * @param tolerance     The tolerable variablity in comparison to account for floating point math.
 *                      Defaults to Number.EPSILON.
 */
export declare function isScaled(collection: ScalableCollection, scale?: number, tolerance?: number): boolean;
/**
 * Validates whether or not an array or object of values is normalized.
 * @param object        An object or an array containing only number values.
 * @param tolerance     The tolerable variablity in comparison to account for floating point math.
 *                      Defaults to Number.EPSILON.
 */
export declare function isNormalized(collection: ScalableCollection, tolerance?: number): boolean;
