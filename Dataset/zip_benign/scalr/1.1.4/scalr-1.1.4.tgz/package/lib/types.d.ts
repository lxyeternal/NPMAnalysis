/**
 # Declarations
 */
export declare type ScalableObject<T extends string | number = string> = Record<T, number>;
export declare type ScalableCollection = number[] | ScalableObject;
