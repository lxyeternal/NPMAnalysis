/**
 # Module Dependencies
 */
import { ScalableObject, ScalableCollection } from './types';
/**
 # Functions
 */
/**
 * Finds the sum of an array of numbers.
 * @param array An array of numbers.
 */
export declare function sumArray(array: number[]): number;
/**
 * Finds the sum of an object of number values.
 * @param object An array of numbers.
 */
export declare function sumObject(object: ScalableObject): number;
/**
 * Finds the sum of an array or an object of number values.
 * @param collection An object or an array containing only number values.
 */
export declare function sum(collection: ScalableCollection): number;
/**
 * Finds the difference of an array of numbers.
 * The first value populates the initial value, while any subsequent are subtracted.
 * @param array An array of numbers.
 */
export declare function differenceArray(array: number[]): number;
/**
 * Finds the difference of an object of number values.
 * The first value populates the initial value, while any subsequent are subtracted.
 * Sorts the keys before subtraction to determine ordering and ensure consistency.
 * @param object An object containing only number values.
 */
export declare function differenceObject(object: ScalableObject): number;
/**
 * Finds the difference of an array or an object of number values.
 * For objects this sorts the keys before subtraction to ensure consistent result.
 * @param collection An object or an array containing only number values.
 */
export declare function difference(collection: ScalableCollection): number;
/**
 * Finds the product of an array of numbers.
 * @param array An array of numbers.
 */
export declare function productArray(array: number[]): number;
/**
 * Finds the product of an object of number values.
 * @param object An object containing only number values.
 */
export declare function productObject(object: ScalableObject): number;
/**
 * Finds the product of an array or an object of number values.
 * @param collection An object or an array containing only number values.
 */
export declare function product(collection: ScalableCollection): number;
/**
 * Finds the quotient of an array of numbers.
 * @param array An array of numbers.
 */
export declare function quotientArray(array: number[]): number;
/**
 * Finds the quotient of an object of number values.
 * The first value populates the initial value, while any subsequent are used to calculate the quotient.
 * Sorts the keys before division to ensure consistent result.
 * @param object An object containing only number values.
 */
export declare function quotientObject(object: ScalableObject): number;
/**
 * Finds the quotient of an array or an object of number values.
 * The first value populates the initial value, while any subsequent are used to calculate the quotient.
 * For objects this sorts the keys before division to ensure consistent result.
 * @param collection An object or an array containing only number values.
 */
export declare function quotient(collection: ScalableCollection): number;
