import { ScalableObject } from './types';
/**
 * Merges objects and resolves values for identical keys using the provided function.
 * @param fn    The function to resolve values for identical keys.
 * @param args  The objects to merge.
 * @returns     The merged object.
 */
export declare function mergeObjects<T = number, V = T>(fn: (v: T[]) => V, ...args: Record<string | number, T>[]): Record<string, V>;
/**
 * USER FACING APIs
 */
export declare function mergeNormalizeObjects(...args: ScalableObject[]): Record<string, number[]>;
export declare function mergeScaleObjects(scale: number, ...args: ScalableObject[]): Record<string, number[]>;
/**
 * Merges objects, resolving values of identical keys by summing.
 * @param args The objects to sum.
 * @returns The merged sums of the objects.
 */
export declare function mergeSumObjects(...args: ScalableObject[]): ScalableObject;
/**
 * Merges objects, resolving values of identical keys by finding the difference.
 * @param args The objects to subtract.
 * @returns The merged difference of the objects.
 */
export declare function mergeDifferenceObjects(...args: ScalableObject[]): ScalableObject;
/**
 * Merges objects, resolving values of identical keys by multiplying.
 * @param args The objects to multiply.
 * @returns The merged product of the objects.
 */
export declare function mergeProductObjects(...args: ScalableObject[]): ScalableObject;
/**
 * Merges objects, resolving values of identical keys by multiplying.
 * @param args The objects to multiply.
 * @returns The merged product of the objects.
 */
export declare function mergeQuotientObjects(...args: ScalableObject[]): ScalableObject;
/**
 * Merges objects, resolving values of identical keys by averaging.
 * @param args The objects to average.
 * @returns The merged averages of the keys of objects.
 */
export declare function mergeAverageObjects(...args: ScalableObject[]): ScalableObject;
/**
 * Merges objects, resolving values of identical keys by finding the standard deviation.
 * @param args The objects to find the standard deviations of.
 * @returns The merged averages of the keys of objects.
 */
export declare function mergeStandardDeviationObjects(...args: ScalableObject[]): ScalableObject;
