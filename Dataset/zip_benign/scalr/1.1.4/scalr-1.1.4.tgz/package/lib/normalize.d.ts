/**
 # Module Dependencies
 */
import { ScalableObject, ScalableCollection } from './types';
/**
 # Types
 */
/**
 # Functions
 */
/**
 * NORMAL ARRAYS
 */
/**
 * Normalizes an array of values to the defined scaling value (default 1)
 * @param array    An array of numbers.
 * @param scale    Scale that the sum of the array should add up to.
 */
export declare function scaleNormalArray(array: number[], scale?: number): number[];
/**
 * Normalizes an array of values to 1.
 * @param array     An array of numbers.
 */
export declare function normalizeArray(array: number[]): number[];
/**
 * Validates whether or not an array of numbers is normalized to a scaled unit value (default 1).
 * @param array         An array of numbers.
 * @param scale         Scale that the sum of the array should add up to (Default 1).
 * @param tolerance     The tolerable variablity in comparison to account for floating point math.
 *                      Defaults to Number.EPSILON.
 */
export declare function isScaledNormalArray(array: number[], scale?: number, tolerance?: number): boolean;
/**
 * Validates whether or not an array of numbers is normalized.
 * @param array         An array of numbers.
 * @param tolerance     The tolerable variablity in comparison to account for floating point math.
 *                      Defaults to Number.EPSILON.
 */
export declare function isNormalizedArray(array: number[], tolerance?: number): boolean;
/**
 * NORMAL OBJECTS
 */
/**
 * Normalizes an object containing only numerical values to the defined scaling value (default 1)
 * @param object   An object containing only number values.
 * @param scale    Scale that the sum of the values of the object should add up to.
 */
export declare function scaleNormalObject(object: Record<string, number>, scale?: number): Record<string, number>;
/**
 * Normalizes an object of values to 1.
 * @param collection  An object containing only number values.
 */
export declare function normalizeObject(object: ScalableObject): Record<string, number>;
/**
 * USER FACING APIs
 */
/**
 * Normalizes an object or an array of values to the defined scaling value (default 1).
 * @param collection    An object or an array of numbers.
 * @param scale         Scale that the sum of the array or object should add up to.  Defaults to 1.
 */
export declare function scale(collection: ScalableCollection, scale?: number): number[] | ScalableObject<string>;
/**
 * Normalizes an object or an array of values to 1.
 * @param collection  An object or an array of numbers.
 */
export declare function normalize(collection: ScalableCollection): number[] | ScalableObject<string>;
