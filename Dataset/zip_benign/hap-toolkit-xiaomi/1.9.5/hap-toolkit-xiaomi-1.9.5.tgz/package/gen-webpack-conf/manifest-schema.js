module.exports = {
  type: 'object',
  required: ['package', 'name', 'icon', 'versionCode', 'config', 'router'],
  properties: {
    package: {
      type: 'string',
      errorMessage: ' The field must be string type'
    },
    name: {
      // TODO 6个汉字以内
      type: 'string',
      errorMessage: ' The field must be string type'
    },
    icon: {
      type: 'string',
      errorMessage: ' The field must be string type'
    },
    banner: {
      type: 'string',
      errorMessage: ' The field must be string type'
    },
    versionName: {
      type: 'string',
      errorMessage: ' The field must be string type'
    },
    versionCode: {
      type: ['number'],
      errorMessage: ' The field must be Integer type'
    },
    minPlatformVersion: {
      type: ['number'],
      errorMessage: '  The field must be Integer type'
    },
    features: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            errorMessage: ' The field must be string type'
          }
        },
        errorMessage: {
          type: " The field type must be 'object'"
        }
      },
      errorMessage: ' The field must be array type'
    },
    config: {
      type: 'object',
      properties: {
        logLevel: {
          enum: ['off', 'error', 'warn', 'info', 'log', 'debug'],
          errorMessage: ' The field can only be off, error, warn, info, log, debug'
        },
        designWidth: {
          type: 'number',
          errorMessage: ' The field must be number type'
        },
        data: {
          // TODO 全局数据对象，属性名不能以$或_开头，
          type: 'object',
          errorMessage: ' The field must be object type'
        },
        background: {
          // TODO 更详细的后台运行配置信息，
          type: 'object',
          errorMessage: ' The field must be object type'
        },
        network: {
          // TODO 更详细的网络配置信息，
          type: 'object',
          errorMessage: ' The field must be object type'
        }
      },
      errorMessage: {
        type: " The field type must be'object'"
      }
    },
    router: {
      // TODO 更详细的后台运行配置信息，
      type: 'object',
      required: ['entry', 'pages'],
      properties: {
        entry: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        // TODO 看下 key 不确定能否校验值，
        pages: {
          type: 'object',
          errorMessage: ' The field must be object type'
        },
        errorPage: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        // TODO 看下 key 不确定能否校验值，
        widgets: {
          type: 'object',
          errorMessage: ' The field must be object type'
        }
      },
      errorMessage: ' The field must be object type'
    },
    display: {
      type: 'object',
      properties: {
        backgroundColor: {
          // TODO HEXColor
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        fullScreen: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        titleBar: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        titleBarBackgroundColor: {
          // TODO HEXColor
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        titleBarTextColor: {
          // TODO HEXColor
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        menu: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        windowSoftInputMode: {
          enum: ['adjustPan', 'adjustResize'],
          errorMessage: ' The field can only be adjustPan or adjustResize'
        },
        pages: {
          type: 'object',
          errorMessage: {
            type: "The field type must be 'object'"
          }
        },
        orientation: {
          enum: ['portrait', 'landscape'],
          errorMessage: ' The field can only be portrait or landscape'
        },
        statusBarImmersive: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        statusBarTextStyle: {
          enum: ['light', 'dark', 'auto'],
          errorMessage: ' The field can only be light, dark or auto'
        },
        statusBarBackgroundColor: {
          type: 'string',
          errorMessage: '  The field must be string type'
        },
        statusBarBackgroundOpacity: {
          type: 'number',
          errorMessage: ' The field must be number type'
        },
        fitCutout: {
          enum: ['none', 'portrait', 'landscape'],
          errorMessage: ' The field can only be none portrait, landscape'
        },
        textSizeAdjust: {
          enum: ['none', 'auto'],
          errorMessage: ' The field can only be none or auto'
        },
        themeMode: {
          enum: [-1, 0, 1],
          errorMessage: ' The field can only be -1, 0 or 1'
        },
        menuBarData: {
          // TODO 详细校验
          type: 'object',
          errorMessage: ' The field must be object type'
        },
        forceDark: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        pageCache: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        cacheDuration: {
          type: 'number',
          errorMessage: ' The field must be number type'
        }
      },
      errorMessage: {
        type: "The field type must be 'object'"
      }
    },
    subpackages: {
      // TODO 与后面的分包校验融合
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            errorMessage: '  The field must be string type'
          },
          // TODO 详细的规则校验
          resource: {
            type: 'string',
            errorMessage: ' The field must be string type'
          }
        },
        // 是否必须?
        required: ['name', 'resource'],
        errorMessage: {
          type: 'tabBar.list[n] must be string type',
          required: ' Must contain name and resource fields'
        }
      },
      errorMessage: {
        type: ' The field must be an array of length 2 to 5'
      }
    },
    menuBarData: {
      type: 'object',
      properties: {
        menuBar: {
          type: 'boolean',
          errorMessage: ' The field must be boolean type'
        },
        menuBarStyle: {
          enum: ['dark', 'light'],
          errorMessage: ' The field can only be adjustPan or adjustResize'
        },
        shareTitle: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        shareDescription: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        shareIcon: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        shareCurrentPage: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        shareParams: {
          type: 'string',
          errorMessage: ' The field must be string type'
        },
        shareUrl: {
          type: 'string',
          errorMessage: ' The field must be string type'
        }
      },
      errorMessage: {
        type: " The field type must be 'object'"
      }
    },
    deviceTypeList: {
      type: 'array',
      items: {
        type: 'string',
        errorMessage: {
          type: " The field type must be'string'"
        }
      },
      errorMessage: 'The field must be array type'
    }
  },
  errorMessage: {
    type: ' Type must be object',
    required:
      "Must contain 'package'、'name'、'versionName'、'versionCode'、'minPlatformVersion'、'icon'、'pages' fields"
  }
}
