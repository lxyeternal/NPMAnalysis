const fs = require('fs')
const path = require('path')
const Ajv = require('ajv')
const AjvErrors = require('ajv-errors')
const manifestSchema = require('./manifest-schema')
const { colorconsole, KnownError } = require('@hap-toolkit-xiaomi/shared-utils')
const { compileOptionsMeta } = require('@hap-toolkit-xiaomi/shared-utils/compilation-config')
const { getSkeletonConfig } = require('@hap-toolkit-xiaomi/packager/lib/common/info')

// 主包保留名
const MAIN_PKG_NAME = compileOptionsMeta.MAIN_PKG_NAME
// 能使用rpks能力的调试器最低版本
const RPKS_SUPPORT_VERSION_FROM = 1040

/**
 * 验证项目配置正确
 */
exports.validateProject = function validateProject(manifestFile, sourceRoot) {
  if (!fs.existsSync(manifestFile)) {
    colorconsole.throw(
      `Please confirm the existence of manifest.json file ${manifestFile} under project %projectDir%/${sourceRoot}/`
    )
    throw new KnownError(`Could not find ${sourceRoot}/manifest.json`)
  }
}

const docSrc = 'https://doc.quickapp.cn/framework/manifest.html'
/**
 * 校验 app/page/component.json
 *
 * @param {AppInfo} jsonInfo - json 文件内容
 * @param {AppInfo} filePath - json 文件地址
 * @return {Array<Error>}  error 数组
 */
function validateJson(jsonInfo, filePath) {
  const ajv = new Ajv({ allErrors: true, jsonPointers: true })
  AjvErrors(ajv)
  ajv.validate(manifestSchema, jsonInfo)
  if (!ajv.errors) {
    return []
  }

  const errors = ajv.errors.map(error => {
    const message =
      `Check error ${filePath} \n` +
      error.dataPath
        .split('/')
        .filter(Boolean)
        .join('.') +
      error.message +
      `\nrefer to: ${docSrc}`
    return new Error(message)
  })

  return errors
}
exports.validateJson = validateJson

/**
 * 验证项目的应用全局配置
 * @param {String} src - 项目src
 * @param {Object} manifest - manifest 对象
 * @param {Object} options - compileOptionsObject
 */
exports.validateManifest = function validateManifest(src, manifest, options) {
  const errors = validateJson(manifest, 'manifest.json')
  errors.forEach(error => {
    colorconsole.error(error.message)
  })
  const { subpackages } = manifest
  // 验证分包规则
  if (!options.disableSubpackages && subpackages && subpackages.length > 0) {
    validateManifestSubpackages(src, subpackages)
  }
}

/**
 * 检查subpackages字段配置。
 * 除subpackages字段指定的文件是打进非主包外，剩余文件都打进主包
 * 主包与是独立包的非主包，都需要manifest文件
 * @param {object[]} subpackages 分包列表: [{ name, resource, standalone, icon }]
 * @param {string} subpackages[].name 分包名字，必填，不能重复，且不能是"base"（这是主包保留名），只能是 数字字母_ 组成
 * @param {string} subpackages[].resource 分包资源路径，必须为src下文件目录，不能重复，分包间不能有包含关系，只能是 数字字母_ 开头，数字字母_-/ 组成
 * @param {boolean} subpackages[].standalone 是否独立包标识，是独立包则需要manifest文件，缺省为false；
 * @param {boolean} subpackages[].icon 分包icon，是独立包则需要icon，缺省则为应用的icon；
 */
function validateManifestSubpackages(src, subpackages) {
  // 分包名的校验规则
  const nameReg = /^\w+$/
  // 资源名的校验规则
  const resourceReg = /^\w[\w-/]*$/
  // 用以检测分包名是否重复
  const nameList = []
  // 用以检测分包资源路径是否重复
  const resList = []
  // i18n文件目录地址，不能作为分包
  const i18nPath = path.join(src, 'i18n')
  // lottie文件目录地址，不能作为分包
  const lottiePath = path.join(src, 'lottie')
  // 骨架屏文件目录地址，不能作为分包
  const skeletonPath = path.join(src, 'skeleton')
  let name = ''
  let resource = ''

  // 资源路径的具体文件路径
  let resPath = ''
  let index = 0

  /**
   * 检查当前资源路径与已校验过的资源路径是否有包含关系。
   *
   * @param {string} resource - 当前要校验的资源
   * @param {number} index - 当前要校验资源的序号
   * @return {boolean} true/false - 存在/不存在
   */
  function checkPathInclusion(resource, currentIndex) {
    for (let i = 0, l = resList.length; i < l; i++) {
      const _res = resList[i]
      if (resource.startsWith(_res) || _res.startsWith(resource)) {
        colorconsole.throw(
          `The resource '${resource}' of the ${currentIndex}th subcontracting and the resource '${_res}' of the ${i +
            1}th subcontracting have an inclusive relationship, please modify`
        )
        return true
      }
    }
    return false
  }

  subpackages.forEach((subpkg, i) => {
    name = subpkg.name
    resource = subpkg.resource
    resPath = resource && path.join(src, resource)
    index = i + 1

    if (!name) {
      colorconsole.throw(`The name of the ${index}th subpackage cannot be empty, please add it`)
    } else if (!nameReg.test(name)) {
      colorconsole.throw(`The name '${name}' of the ${index}th subpackage is illegal, it can only be composed of letters and underscores, please modify it`)
    } else if (name === MAIN_PKG_NAME) {
      colorconsole.throw(`The name '${name}' of the ${index}th subpackage is the reserved name of the main package, please modify it`)
    } else if (nameList.indexOf(name) > -1) {
      colorconsole.throw(`The name '${name}' of the ${index}th subpackage already exists, please modify it`)
    } else {
      nameList.push(name)
    }

    if (!resource) {
      colorconsole.throw(`The resource name of the ${index}th subpackage cannot be empty, please add it`)
    } else if (!resourceReg.test(resource)) {
      colorconsole.throw(
        `The resource name '${resource}' of the ${index}th subpackage is illegal, it can only start with 'numbers'、'letters'、'_' and composed of 'numbers letters _-/', please modify it`
      )
    } else if (resList.indexOf(resource) > -1) {
      colorconsole.throw(`Resource '${resource}' of the ${index}th subpackage has been used, please modify it`)
    } else if (!fs.existsSync(resPath)) {
      colorconsole.throw(`Resource '${resource}' of the ${index}th subpackage, file directory '${resPath}' does not exist, please modify it`)
    } else if (resPath === i18nPath) {
      colorconsole.throw(
        `Resource '${resource}' of the ${index}th subpackage, file directory is '${resPath}',the i18n file directory cannot be used as subpackage, please modify it`
      )
    } else if (resPath === lottiePath) {
      colorconsole.throw(
        `Resource '${resource}' of the ${index}th subpackage, file directory is '${resPath}', the lottie file directory cannot be used as a subpackage, please modify it`
      )
    } else if (resPath === skeletonPath) {
      colorconsole.throw(
        `Resource '${resource}' of the ${index}th subpackage, file directory is '${resPath}',the skeleton screen file directory cannot be used as a subpackage, please modify it`
      )
    } else if (!checkPathInclusion(resource, index)) {
      resList.push(resource)
    }

    if (subpkg.standalone && subpkg.icon && !fs.existsSync(path.join(src, subpkg.icon))) {
      colorconsole.throw(`The icon of the ${index}th subpackage's configuration does not exist, please modify it`)
    }

    if (subpkg.standalone && subpkg.banner && !fs.existsSync(path.join(src, subpkg.banner))) {
      colorconsole.throw(`The banner of the ${index}th subpackage's configuration does not exist, please modify it`)
    }
  })
  colorconsole.warn(
    `The project has configured subpackage. If you want to use the subpackage function, please ensure that the platform version >= ${RPKS_SUPPORT_VERSION_FROM}`
  )
}

/**
 * sitemap校验。
 * @param {String} src - 项目src路径
 * @param {Object} manifest - manifest内容
 */
exports.valiedateSitemap = function valiedateSitemap(src, manifest) {
  const sitemap = path.join(src, 'sitemap.json')
  if (fs.existsSync(sitemap)) {
    const rules = require(sitemap).rules
    const pages = Object.keys(manifest.router.pages || {})
    rules.forEach((i, idx) => {
      const page = i.page
      if (page !== '*' && !pages.includes(page)) {
        colorconsole.throw(`The ${idx + 1}th item of sitemap rules is configured incorrectly, the page ${page} does not exist`)
      }
      return page
    })
  }
}

/**
 * 骨架屏文件校验。
 * @param {String} src - 项目src路径packages/hap-toolkit/gen-webpack-conf/validate.js
 * @param {Object} manifest - manifest内容
 */
exports.valiedateSkeleton = function valiedateSkeleton(src, manifest) {
  const configJson = getSkeletonConfig(src)
  const manifestPages = manifest.router.pages || {}

  if (configJson) {
    const pageDir = path.join(src, 'skeleton/page')
    const singleMap = configJson.singleMap || {}
    const anchorMaps = configJson.anchorMaps || []

    Object.keys(singleMap).forEach(page => {
      if (!manifestPages[page]) {
        colorconsole.throw(`The configuration page ${page} of the skeleton screen singleMapd is not defined in the manifest, please check`)
      }
      const file = path.join(pageDir, configJson.singleMap[page])
      if (!fs.existsSync(file)) {
        colorconsole.throw(`The sk file ${file} in the configuration page ${page} of the skeleton screen singleMapd does not exist, please check`)
      }
    })

    if (!Array.isArray(anchorMaps)) {
      colorconsole.throw(`The value of the anchorMaps field of the skeleton screen must be an array, please check`)
    }
    anchorMaps.forEach((mapJson, index) => {
      const { page, skeletonMap } = mapJson
      if (!page) {
        colorconsole.throw(
          `The page value of the ${index + 1}th configuration of the skeleton screen anchorMaps cannot be empty, please check`
        )
      }
      if (!manifestPages[page]) {
        colorconsole.throw(
          `The page value ${page} of the ${index + 1}th configuration of the skeleton screen anchorMaps is not defined in the manifest, please check`
        )
      }
      Object.keys(skeletonMap || {}).forEach(anchor => {
        const file = path.join(pageDir, skeletonMap[anchor])
        if (!fs.existsSync(file)) {
          colorconsole.throw(
            `The sk file ${file} of skeleton screen anchorMap's ${index + 1}th configuration anchor does not exist, please check`
          )
        }
      })
    })
  }
}
