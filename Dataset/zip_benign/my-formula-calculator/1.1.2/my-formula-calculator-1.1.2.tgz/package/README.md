# My Formula Calculator

A Node.js module for parsing and evaluating arithmetic formula strings.

## Installation

You can install this package via npm:

```bash
npm install my-formula-calculator
```

## Usage
```js
const calculateFormula = require('my-formula-calculator');

const input = {
    formula: '(x + y) * z',
    data: {
        x: 0.1,
        y: 0.2,
        z: 1
    }
};

const result = calculateFormula(input.formula, input.data);
console.log('Result:', result);  // Output should be 0.3
```
