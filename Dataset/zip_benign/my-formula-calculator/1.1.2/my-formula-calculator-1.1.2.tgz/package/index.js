// 导入处理大数运算的模块，用于解决精度问题
const Decimal = require('decimal.js');

// 定义公式中的字符类型
const TOKEN_TYPE = {
    NUMBER: 'NUMBER', // 数字
    OPERATOR: 'OPERATOR', // 运算符
    LPAREN: 'LPAREN', // 左括号
    RPAREN: 'RPAREN' // 右括号
}

// 定义 Token 类
class Token {
    constructor(type, value) {
        this.type = type;
        this.value = value;
    }
}

// 计算公式
function calculateFormula(formula, data) {
    // 将公式中的变量替换为实际值
    const replacedFormula = formula.replace(/[a-zA-Z]+/g, match => {
        // 判断 data 中是否有该符号
        if (data.hasOwnProperty(match)) {
            return data[match];
        }
        else {
            throw new Error('Variable '+ match + ' is not defined in data');
        }
    });


    // 执行计算
    const tokens = tokenize(replacedFormula); // 获得 token 数组
    const ast = parseAST(tokens); // 获得 AST
    return calculate(ast, data); // 返回计算值
}

// 将公式字符串进行解析，获得各个字符的类型和值
function tokenize(formula) {
    const tokens = [];
    let index = 0;

    while (index < formula.length) {
        let char = formula[index];

        // 数字（包含小数）
        if (/[0-9.]/.test(char)) {
            let number = '';
            while (/[0-9.]/.test(char)) {
                number += char;
                char = formula[++index];
            }
            tokens.push(new Token(TOKEN_TYPE.NUMBER, new Decimal(parseFloat(number))));
        }

        // '-' 单独判断是作为 负数前缀 还是 减法运算符
        else if (char === '-') {
            // 表示负数
            if (tokens.length === 0 || tokens[tokens.length - 1].type === TOKEN_TYPE.LPAREN
                || tokens[tokens.length - 1].type === TOKEN_TYPE.OPERATOR) {
                let number = '-';
                char = formula[++index];
                while (/[0-9.]/.test(char)) {
                    number += char;
                    char = formula[++index];
                }
                tokens.push(new Token(TOKEN_TYPE.NUMBER, new Decimal(parseFloat(number))));
            }
            // 表示运算符
            else {
                tokens.push(new Token(TOKEN_TYPE.OPERATOR, char));
                index++;
            }
        }

        // 运算符（+*/）
        else if (/[+*/]/.test(char)) {
            tokens.push(new Token(TOKEN_TYPE.OPERATOR, char));
            index++;
        }

        // 左括号
        else if (char === '(') {
            tokens.push(new Token(TOKEN_TYPE.LPAREN, char));
            index++;
        }

        // 右括号
        else if (char === ')') {
            tokens.push(new Token(TOKEN_TYPE.RPAREN, char));
            index++;
        }

        // 空格不做处理
        else if (/\s/.test(char)) {
            index++;
        }

        // 无效字符
        else {
            throw new Error('Unknown char: ' + char);
        }
    }

    return tokens;
}

// 获得公式字符串的 AST（深度越深，优先级越高）
function parseAST(tokens) {
    let index = 0;

    // 处理加法和减法（优先级最低）
    function parseExpression() {
        let node = parseTerm();

        while (tokens[index] && tokens[index].type === TOKEN_TYPE.OPERATOR && (tokens[index].value === '+' || tokens[index].value === '-')) {
            const operator = tokens[index++];
            node = {
                type: 'BinaryExpression',
                operator: operator.value,
                left: node,
                right: parseTerm()
            };
        }

        return node;
    }

    // 处理乘法和除法（优先级次高）
    function parseTerm() {
        let node = parseFactor();

        while (tokens[index] && tokens[index].type === TOKEN_TYPE.OPERATOR && (tokens[index].value === '*' || tokens[index].value === '/')) {
            const operator = tokens[index++];
            node = {
                type: 'BinaryExpression',
                operator: operator.value,
                left: node,
                right: parseFactor()
            };
        }

        return node;
    }

    // 处理数字和括号表达式（优先级最高）
    function parseFactor() {
        const token = tokens[index];

        // 数字
        if (token.type === TOKEN_TYPE.NUMBER) {
            index++;
            return {
                type: 'Literal',
                value: token.value
            };
        }

        // 左括号
        else if (token.type === TOKEN_TYPE.LPAREN) {
            index++;
            const node = parseExpression(); // 处理括号内的表达式

            // 没有右括号
            if (tokens[index].type !== TOKEN_TYPE.RPAREN) {
                throw new Error('Expected closing parenthesis');
            }

            index++;
            return node;
        }

        // 其他类型
        else {
            throw new Error('Unexpected token: ' + token.value);
        }
    }

    return parseExpression();
}

// 根据 AST 来计算值
function calculate(ast, data) {
    if (ast.type === 'Literal') {
        return ast.value;
    }
    else if (ast.type === 'BinaryExpression') {
        const leftValue = calculate(ast.left, data);
        const rightValue = calculate(ast.right, data);

        switch (ast.operator) {
            case '+':
                return leftValue.plus(rightValue);
            case '-':
                return leftValue.minus(rightValue);
            case '*':
                return leftValue.times(rightValue);
            case "/":
                return leftValue.dividedBy(rightValue);
            default:
                throw new Error('Unexpected operator: ' + ast.operator);
        }
    }
    else {
        throw new Error('Unknown AST node type: ' + ast.type);
    }
}

module.exports = calculateFormula;