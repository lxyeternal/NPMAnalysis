import QRCodeStyling from "./core/QRCodeStyling";
declare const _default: import("vue").DefineComponent<{
    width: {
        type: NumberConstructor;
        default: number;
    };
    imgclass: {
        type: StringConstructor;
        default: string;
    };
    myclass: {
        type: StringConstructor;
        default: string;
    };
    downloadButton: {
        type: StringConstructor;
        default: string;
    };
    buttonName: {
        type: StringConstructor;
        default: string;
    };
    height: {
        type: NumberConstructor;
        default: number;
    };
    margin: {
        type: NumberConstructor;
        default: number;
    };
    value: {
        type: StringConstructor;
        required: true;
    };
    image: {
        type: StringConstructor;
        default: string;
    };
    qrOptions: {
        type: ObjectConstructor;
        default: () => {
            typeNumber: number;
            mode: string;
            errorCorrectionLevel: string;
        };
    };
    imageOptions: {
        type: ObjectConstructor;
        default: () => {
            hideBackgroundDots: boolean;
            imageSize: number;
            margin: number;
        };
    };
    dotsOptions: {
        type: ObjectConstructor;
        default: () => {
            type: string;
            color: string;
            gradient: {
                type: string;
                rotation: number;
                colorStops: {
                    offset: number;
                    color: string;
                }[];
            };
        };
    };
    backgroundOptions: {
        type: ObjectConstructor;
        default: () => {
            color: string;
        };
    };
    cornersSquareOptions: {
        type: ObjectConstructor;
        default: () => {
            type: string;
            color: string;
        };
    };
    cornersDotOptions: {
        type: ObjectConstructor;
        default: () => {
            type: undefined;
            color: string;
        };
    };
    fileExt: {
        type: StringConstructor;
        default: string;
    };
    download: {
        type: BooleanConstructor;
        default: boolean;
    };
    downloadOptions: {
        type: ObjectConstructor;
        default: () => {
            name: string;
            extension: string;
        };
    };
}, unknown, {
    imageUrl: string;
    qrCode: QRCodeStyling;
}, {}, {
    onDownloadClick(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, Record<string, any>, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<{
    value: string;
    width: number;
    imgclass: string;
    myclass: string;
    downloadButton: string;
    buttonName: string;
    height: number;
    margin: number;
    image: string;
    qrOptions: Record<string, any>;
    imageOptions: Record<string, any>;
    dotsOptions: Record<string, any>;
    backgroundOptions: Record<string, any>;
    cornersSquareOptions: Record<string, any>;
    cornersDotOptions: Record<string, any>;
    fileExt: string;
    download: boolean;
    downloadOptions: Record<string, any>;
} & {}>, {
    width: number;
    imgclass: string;
    myclass: string;
    downloadButton: string;
    buttonName: string;
    height: number;
    margin: number;
    image: string;
    qrOptions: Record<string, any>;
    imageOptions: Record<string, any>;
    dotsOptions: Record<string, any>;
    backgroundOptions: Record<string, any>;
    cornersSquareOptions: Record<string, any>;
    cornersDotOptions: Record<string, any>;
    fileExt: string;
    download: boolean;
    downloadOptions: Record<string, any>;
}>;
export default _default;
