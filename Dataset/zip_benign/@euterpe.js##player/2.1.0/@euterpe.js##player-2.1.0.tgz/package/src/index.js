var _MusicPlayer_instances, _MusicPlayer_volume_cache, _MusicPlayer_pub_sub, _MusicPlayer_emit_time, _MusicPlayer_emit_duration_fmt, _MusicPlayer_emit_time_fmt, _MusicPlayerBuilder_audio_context, _MusicPlayerBuilder_gain, _MusicPlayerBuilder_track, _MusicPlayerBuilder_volume, _MusicPlayerBuilder_prev_node, _MusicPlayerBuilder_is_gain_connected;
import { __awaiter, __classPrivateFieldGet, __classPrivateFieldSet } from "tslib";
export var SubscribeEvents;
(function (SubscribeEvents) {
    SubscribeEvents[SubscribeEvents["CurrentTimeTick"] = 0] = "CurrentTimeTick";
    SubscribeEvents[SubscribeEvents["FormattedDurationTick"] = 1] = "FormattedDurationTick";
    SubscribeEvents[SubscribeEvents["FormattedCurrentTimeTick"] = 2] = "FormattedCurrentTimeTick";
})(SubscribeEvents || (SubscribeEvents = {}));
class PubSub {
    constructor() {
        //el = event listener
        this.el_current_time_tick = [];
        this.el_formatted_duration_tick = [];
        this.el_formatted_current_time_tick = [];
    }
    subscribe(event_name, func) {
        switch (event_name) {
            case SubscribeEvents.CurrentTimeTick: {
                this.el_current_time_tick.push(func);
                break;
            }
            case SubscribeEvents.FormattedDurationTick: {
                this.el_formatted_duration_tick.push(func);
                break;
            }
            case SubscribeEvents.FormattedCurrentTimeTick: {
                this.el_formatted_current_time_tick.push(func);
                break;
            }
        }
    }
    unsubscribe(event_name, func) {
        switch (event_name) {
            case SubscribeEvents.CurrentTimeTick: {
                if (this.el_current_time_tick.includes(func)) {
                    this.el_current_time_tick.splice(this.el_current_time_tick.indexOf(func), 1);
                }
                break;
            }
            case SubscribeEvents.FormattedDurationTick: {
                if (this.el_formatted_duration_tick.includes(func)) {
                    this.el_formatted_duration_tick.splice(this.el_formatted_duration_tick.indexOf(func), 1);
                }
                break;
            }
            case SubscribeEvents.FormattedCurrentTimeTick: {
                if (this.el_formatted_duration_tick.includes(func)) {
                    this.el_formatted_duration_tick.splice(this.el_formatted_duration_tick.indexOf(func), 1);
                }
                break;
            }
        }
    }
    emit(event_name, data) {
        switch (event_name) {
            case SubscribeEvents.CurrentTimeTick: {
                this.el_current_time_tick.forEach((func) => {
                    func(data);
                });
                break;
            }
            case SubscribeEvents.FormattedDurationTick: {
                this.el_formatted_duration_tick.forEach((func) => {
                    func(data);
                });
                break;
            }
            case SubscribeEvents.FormattedCurrentTimeTick: {
                this.el_formatted_current_time_tick.forEach((func) => {
                    func(data);
                });
                break;
            }
        }
    }
}
export class MusicPlayer {
    constructor(audio_context, audio_element, track, gain, volume, current_song_path) {
        _MusicPlayer_instances.add(this);
        this.audio_context = audio_context;
        this.audio_element = audio_element;
        this.track = track;
        this.gain = gain;
        this.volume = volume;
        this.current_song_path = current_song_path;
        this.current_song_duration = 0;
        _MusicPlayer_volume_cache.set(this, void 0);
        this.is_playing = false;
        this.time = 0;
        _MusicPlayer_pub_sub.set(this, new PubSub());
        __classPrivateFieldSet(this, _MusicPlayer_volume_cache, volume, "f");
    }
    mute_toggle() {
        if (this.gain.gain.value == 0) {
            this.unmute();
        }
        else {
            this.mute();
        }
    }
    mute() {
        __classPrivateFieldSet(this, _MusicPlayer_volume_cache, this.gain.gain.value, "f");
        /* Gentler mute, doesn't pop
        gain.gain.linearRampToValueAtTime(
            0,
            audio_context.currentTime + 0.1
        );*/
        this.volume = this.gain.gain.value = 0;
    }
    unmute() {
        this.volume = this.gain.gain.value = __classPrivateFieldGet(this, _MusicPlayer_volume_cache, "f");
    }
    change_volume(volume_i) {
        this.volume = this.gain.gain.value = volume_i;
    }
    /**
     * Safer seek. Normal seek will try to start the player even if the track hasn't started yet, or was previously suspended/closed.
     * will not resume playback
     * @throws if "Can't seek - Audiocontext is not running"
     */
    try_seek(new_time) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.audio_context.state !== "running") {
                this.is_playing = false;
                throw new Error("Can't seek - audioContext not running, audio_context.state : " + this.audio_context.state);
            }
            this.audio_element.currentTime = new_time;
        });
    }
    /**
     * Unsafe, throws error if failed. Use try_seek or seek unless you don't care about the result.
     */
    seek(new_time) {
        this.audio_element.currentTime = new_time;
    }
    /**
     * Safer play_toggle. Normal play_toggle will try to start the player even if the track hasn't started yet, or was previously suspended/closed
     * @throws Error if playback failed
     */
    try_play_toggle() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.audio_context.state !== "running") {
                yield this.audio_context.resume();
            }
            if (this.audio_element.paused) {
                try {
                    yield this.audio_element.play();
                    this.is_playing = true;
                }
                catch (e) {
                    this.is_playing = false;
                    throw e;
                }
            }
            else {
                this.audio_element.pause();
                this.is_playing = false;
            }
        });
    }
    /**
     * Unsafe, can just fail. Use try_play_toggle unless you don't care about the result.
     */
    play_toggle() {
        if (this.audio_element.paused) {
            this.is_playing = true;
            this.audio_element.play().catch((r) => {
                this.is_playing = false;
                throw r;
            });
        }
        else {
            this.is_playing = false;
            this.audio_element.pause();
        }
    }
    /**
     * Safer play. Normal play will try to start the player even if the track hasn't started yet, or was previously suspended/closed
     * @throws Error if playback failed
     */
    try_play() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.is_playing)
                return;
            if (this.audio_context.state !== "running") {
                yield this.audio_context.resume();
            }
            if (this.audio_element.paused) {
                try {
                    yield this.audio_element.play();
                    this.is_playing = true;
                }
                catch (e) {
                    this.is_playing = false;
                    throw e;
                }
            }
        });
    }
    /**
     * Unsafe, can just fail. Use play or try_play unless you don't care about the result.
     */
    play() {
        if (this.is_playing)
            return;
        this.audio_element.play().catch(() => {
            this.is_playing = false;
        });
    }
    /**
     * Safe technically. Even if audioContext is suspended or closed it will pretend that it paused.
     */
    pause() {
        this.audio_element.pause();
        this.is_playing = false;
    }
    /**
     * Will only load metadata of the upcoming song and change audio dom elements url. Need to call try_play() afterwards to start the playback
     * @throws Error if adding element throwed Error or Stalled
     */
    try_new_song(path) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.audio_context.state !== "running") {
                try {
                    yield this.audio_context.resume();
                }
                catch (e) {
                    console.log("loading new song - couldn't resume context before hand", e);
                }
            }
            return new Promise((resolve, reject) => {
                this.audio_element.src = this.current_song_path = path;
                //Found out today about this. Such a nice new way to mass remove event listeners!
                const controller = new AbortController();
                this.audio_element.addEventListener("canplaythrough", function canplay_listener() {
                    controller.abort();
                }, { signal: controller.signal });
                this.audio_element.addEventListener("error", function error_listener() {
                    controller.abort("new src error");
                }, { signal: controller.signal });
                this.audio_element.addEventListener("stalled", function stalled_listener() {
                    controller.abort("new src stalled");
                }, { signal: controller.signal });
                //once aborted, try to set current_song_duration
                controller.signal.addEventListener("abort", () => {
                    this.current_song_duration = this.audio_element.duration;
                    if (typeof controller.signal.reason == "string")
                        reject(new Error(controller.signal.reason));
                    resolve();
                });
                this.is_playing = false;
            });
        });
    }
    /**
     * Won't tell if you if the song actually got loaded or if it failed. For a safer version use try_new_song() unless you don't care about the result
     */
    new_song(path) {
        this.audio_element.src = this.current_song_path = path;
        this.current_song_duration = this.audio_element.duration;
    }
    /**
     * Will parse the duration of the song to make it easy to display in UI
     * If somethings undefined it returns "0:00"
     */
    get_formatted_duration() {
        const dur = this.audio_element.duration;
        this.current_song_duration = this.audio_element.duration;
        if (dur == 0 || !dur)
            return "0:00";
        // ~ is Bitwise NOT, equivalent to Math.floor()
        const hrs = ~~(dur / 3600);
        const mins = ~~((dur % 3600) / 60);
        const secs = ~~dur % 60;
        let ret = "";
        if (hrs > 0) {
            ret += "" + hrs + ":" + (mins < 10 ? "0" : "");
        }
        ret += "" + mins + ":" + (secs < 10 ? "0" : "");
        ret += "" + secs;
        return ret;
    }
    /**
     * Will parse the current time of the song to make it easy to display in UI
     * If somethings undefined it returns "0:00"
     */
    get_formatted_current_time() {
        const curr = this.audio_element.currentTime;
        if (curr == 0 || !curr)
            return "0:00";
        // ~~ is Bitwise OR, equivalent to Math.floor()
        const hrs = ~~(curr / 3600);
        const mins = ~~((curr % 3600) / 60);
        const secs = ~~curr % 60;
        let ret = "";
        if (hrs > 0) {
            ret += "" + hrs + ":" + (mins < 10 ? "0" : "");
        }
        ret += "" + mins + ":" + (secs < 10 ? "0" : "");
        ret += "" + secs;
        return ret;
    }
    /**
     * Will give current time every animation frame
     */
    on_time_tick(callback) {
        __classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").subscribe(SubscribeEvents.CurrentTimeTick, callback);
        __classPrivateFieldGet(this, _MusicPlayer_instances, "m", _MusicPlayer_emit_time).call(this);
    }
    /**
     * Will give formatted current time via get_formatted_current_time() every animation frame
     */
    on_time_tick_formatted(callback) {
        __classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").subscribe(SubscribeEvents.FormattedCurrentTimeTick, callback);
        __classPrivateFieldGet(this, _MusicPlayer_instances, "m", _MusicPlayer_emit_time_fmt).call(this);
    }
    /**
     * Will give formatted duration time via get_formatted_duration() every animation frame
     */
    on_duration_formatted(callback) {
        __classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").subscribe(SubscribeEvents.FormattedDurationTick, callback);
        __classPrivateFieldGet(this, _MusicPlayer_instances, "m", _MusicPlayer_emit_duration_fmt).call(this);
    }
}
_MusicPlayer_volume_cache = new WeakMap(), _MusicPlayer_pub_sub = new WeakMap(), _MusicPlayer_instances = new WeakSet(), _MusicPlayer_emit_time = function _MusicPlayer_emit_time() {
    const request_id = requestAnimationFrame(__classPrivateFieldGet(this, _MusicPlayer_instances, "m", _MusicPlayer_emit_time).bind(this));
    if (this.audio_element.ended)
        this.is_playing = false;
    if (this.audio_element.paused)
        this.is_playing == false;
    // if use reactively changes volume directly
    this.gain.gain.value = this.volume;
    this.time = this.audio_element.currentTime;
    if (__classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").el_current_time_tick.length == 0)
        cancelAnimationFrame(request_id);
    __classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").emit(SubscribeEvents.CurrentTimeTick, this.time);
}, _MusicPlayer_emit_duration_fmt = function _MusicPlayer_emit_duration_fmt() {
    const request_id = requestAnimationFrame(__classPrivateFieldGet(this, _MusicPlayer_instances, "m", _MusicPlayer_emit_duration_fmt).bind(this));
    const time = this.get_formatted_duration();
    if (__classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").el_formatted_duration_tick.length == 0)
        cancelAnimationFrame(request_id);
    __classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").emit(SubscribeEvents.FormattedDurationTick, time);
}, _MusicPlayer_emit_time_fmt = function _MusicPlayer_emit_time_fmt() {
    const request_id = requestAnimationFrame(__classPrivateFieldGet(this, _MusicPlayer_instances, "m", _MusicPlayer_emit_time_fmt).bind(this));
    const time = this.get_formatted_current_time();
    if (__classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").el_formatted_current_time_tick.length == 0)
        cancelAnimationFrame(request_id);
    __classPrivateFieldGet(this, _MusicPlayer_pub_sub, "f").emit(SubscribeEvents.FormattedCurrentTimeTick, time);
};
export class MusicPlayerBuilder {
    /**
     * Creates a context and #gain( Gets connected at the end )
     * will throw if audio_element is undefined (stupid vue setup amirite?)
     * will throw if user has not interacted with the page yet (Can't initiate AudioContext)
     */
    constructor(audio_element) {
        this.audio_element = audio_element;
        _MusicPlayerBuilder_audio_context.set(this, void 0);
        _MusicPlayerBuilder_gain.set(this, void 0);
        _MusicPlayerBuilder_track.set(this, void 0);
        _MusicPlayerBuilder_volume.set(this, 1);
        _MusicPlayerBuilder_prev_node.set(this, void 0);
        _MusicPlayerBuilder_is_gain_connected.set(this, false
        /**
         * Creates a context and #gain( Gets connected at the end )
         * will throw if audio_element is undefined (stupid vue setup amirite?)
         * will throw if user has not interacted with the page yet (Can't initiate AudioContext)
         */
        );
        if (audio_element === undefined)
            throw Error("audio_element was undefined");
        //                                          ↓ For old browsers
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        __classPrivateFieldSet(this, _MusicPlayerBuilder_audio_context, new AudioContext(), "f");
        __classPrivateFieldSet(this, _MusicPlayerBuilder_track, __classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f").createMediaElementSource(audio_element), "f");
        __classPrivateFieldSet(this, _MusicPlayerBuilder_gain, __classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f").createGain(), "f");
    }
    /**
     * For external use, not kept inside player after connection.
     * @returns {AnalyserNode}
     */
    add_analyser() {
        const analyser = __classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f").createAnalyser();
        !__classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f") ? __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f").connect(analyser) : __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(analyser);
        __classPrivateFieldSet(this, _MusicPlayerBuilder_prev_node, analyser, "f");
        return analyser;
    }
    /**
     * For external use, not kept inside player after connection.
     * @returns {StereoPannerNode}
     */
    add_stereo_panner_node() {
        const panner = __classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f").createStereoPanner();
        !__classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f") ? __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f").connect(panner) : __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(panner);
        __classPrivateFieldSet(this, _MusicPlayerBuilder_prev_node, panner, "f");
        return panner;
    }
    /**
     * For external use, not kept inside player after connection.
     * @returns {StereoPannerNode}
     */
    add_wave_shaper_node() {
        const shaper = __classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f").createWaveShaper();
        !__classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f") ? __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f").connect(shaper) : __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(shaper);
        __classPrivateFieldSet(this, _MusicPlayerBuilder_prev_node, shaper, "f");
        return shaper;
    }
    /**
     * For additional trickery, you can connect your own node.
     */
    connect_custom_node(node) {
        !__classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f") ? __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f").connect(node) : __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(node);
        __classPrivateFieldSet(this, _MusicPlayerBuilder_prev_node, node, "f");
    }
    /**
     * Only use if you need to connect the #gain before another node,
     * eg. if you want the analyser nodes output to be affected by user #gain
     */
    connect_gain() {
        !__classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f") ? __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f").connect(__classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f")) : __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(__classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f"));
        __classPrivateFieldSet(this, _MusicPlayerBuilder_prev_node, __classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f"), "f");
        __classPrivateFieldSet(this, _MusicPlayerBuilder_is_gain_connected, true, "f");
    }
    /**
     * Finishes the build
     * @returns {Euterpe}
     */
    build() {
        if (!__classPrivateFieldGet(this, _MusicPlayerBuilder_is_gain_connected, "f")) {
            !__classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f") ? __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f").connect(__classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f")) : __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(__classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f"));
            __classPrivateFieldSet(this, _MusicPlayerBuilder_prev_node, __classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f"), "f");
        }
        __classPrivateFieldGet(this, _MusicPlayerBuilder_prev_node, "f").connect(__classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f").destination);
        return new MusicPlayer(__classPrivateFieldGet(this, _MusicPlayerBuilder_audio_context, "f"), this.audio_element, __classPrivateFieldGet(this, _MusicPlayerBuilder_track, "f"), __classPrivateFieldGet(this, _MusicPlayerBuilder_gain, "f"), __classPrivateFieldGet(this, _MusicPlayerBuilder_volume, "f"));
    }
}
_MusicPlayerBuilder_audio_context = new WeakMap(), _MusicPlayerBuilder_gain = new WeakMap(), _MusicPlayerBuilder_track = new WeakMap(), _MusicPlayerBuilder_volume = new WeakMap(), _MusicPlayerBuilder_prev_node = new WeakMap(), _MusicPlayerBuilder_is_gain_connected = new WeakMap();
//# sourceMappingURL=index.js.map