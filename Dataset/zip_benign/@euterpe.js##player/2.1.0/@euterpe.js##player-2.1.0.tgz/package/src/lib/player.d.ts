export declare function player(): string;
