export declare enum SubscribeEvents {
    CurrentTimeTick = 0,
    FormattedDurationTick = 1,
    FormattedCurrentTimeTick = 2
}
declare global {
    interface Window {
        webkitAudioContext: typeof AudioContext;
    }
}
export declare class MusicPlayer {
    #private;
    audio_context: AudioContext;
    private audio_element;
    track: MediaElementAudioSourceNode;
    gain: GainNode;
    volume: number;
    private current_song_path?;
    current_song_duration: number;
    is_playing: boolean;
    time: number;
    constructor(audio_context: AudioContext, audio_element: HTMLAudioElement, track: MediaElementAudioSourceNode, gain: GainNode, volume: number, current_song_path?: string | undefined);
    mute_toggle(): void;
    mute(): void;
    unmute(): void;
    change_volume(volume_i: number): void;
    /**
     * Safer seek. Normal seek will try to start the player even if the track hasn't started yet, or was previously suspended/closed.
     * will not resume playback
     * @throws if "Can't seek - Audiocontext is not running"
     */
    try_seek(new_time: number): Promise<void>;
    /**
     * Unsafe, throws error if failed. Use try_seek or seek unless you don't care about the result.
     */
    seek(new_time: number): void;
    /**
     * Safer play_toggle. Normal play_toggle will try to start the player even if the track hasn't started yet, or was previously suspended/closed
     * @throws Error if playback failed
     */
    try_play_toggle(): Promise<void>;
    /**
     * Unsafe, can just fail. Use try_play_toggle unless you don't care about the result.
     */
    play_toggle(): void;
    /**
     * Safer play. Normal play will try to start the player even if the track hasn't started yet, or was previously suspended/closed
     * @throws Error if playback failed
     */
    try_play(): Promise<void>;
    /**
     * Unsafe, can just fail. Use play or try_play unless you don't care about the result.
     */
    play(): void;
    /**
     * Safe technically. Even if audioContext is suspended or closed it will pretend that it paused.
     */
    pause(): void;
    /**
     * Will only load metadata of the upcoming song and change audio dom elements url. Need to call try_play() afterwards to start the playback
     * @throws Error if adding element throwed Error or Stalled
     */
    try_new_song(path: string): Promise<void>;
    /**
     * Won't tell if you if the song actually got loaded or if it failed. For a safer version use try_new_song() unless you don't care about the result
     */
    new_song(path: string): void;
    /**
     * Will parse the duration of the song to make it easy to display in UI
     * If somethings undefined it returns "0:00"
     */
    get_formatted_duration(): string;
    /**
     * Will parse the current time of the song to make it easy to display in UI
     * If somethings undefined it returns "0:00"
     */
    get_formatted_current_time(): string;
    /**
     * Will give current time every animation frame
     */
    on_time_tick(callback: (data: any) => void): void;
    /**
     * Will give formatted current time via get_formatted_current_time() every animation frame
     */
    on_time_tick_formatted(callback: (data: any) => void): void;
    /**
     * Will give formatted duration time via get_formatted_duration() every animation frame
     */
    on_duration_formatted(callback: (data: any) => void): void;
}
export declare class MusicPlayerBuilder {
    #private;
    private audio_element;
    /**
     * Creates a context and #gain( Gets connected at the end )
     * will throw if audio_element is undefined (stupid vue setup amirite?)
     * will throw if user has not interacted with the page yet (Can't initiate AudioContext)
     */
    constructor(audio_element: HTMLAudioElement);
    /**
     * For external use, not kept inside player after connection.
     * @returns {AnalyserNode}
     */
    add_analyser(): AnalyserNode;
    /**
     * For external use, not kept inside player after connection.
     * @returns {StereoPannerNode}
     */
    add_stereo_panner_node(): StereoPannerNode;
    /**
     * For external use, not kept inside player after connection.
     * @returns {StereoPannerNode}
     */
    add_wave_shaper_node(): WaveShaperNode;
    /**
     * For additional trickery, you can connect your own node.
     */
    connect_custom_node(node: AudioNode): void;
    /**
     * Only use if you need to connect the #gain before another node,
     * eg. if you want the analyser nodes output to be affected by user #gain
     */
    connect_gain(): void;
    /**
     * Finishes the build
     * @returns {Euterpe}
     */
    build(): MusicPlayer;
}
