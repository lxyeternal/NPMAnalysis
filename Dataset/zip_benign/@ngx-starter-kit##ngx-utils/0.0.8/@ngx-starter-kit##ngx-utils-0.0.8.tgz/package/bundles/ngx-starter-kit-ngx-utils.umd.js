(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@angular/router'), require('rxjs'), require('rxjs/operators'), require('@angular/forms'), require('@angular/platform-browser'), require('date-fns')) :
    typeof define === 'function' && define.amd ? define('@ngx-starter-kit/ngx-utils', ['exports', '@angular/core', '@angular/common', '@angular/router', 'rxjs', 'rxjs/operators', '@angular/forms', '@angular/platform-browser', 'date-fns'], factory) :
    (global = global || self, factory((global['ngx-starter-kit'] = global['ngx-starter-kit'] || {}, global['ngx-starter-kit']['ngx-utils'] = {}), global.ng.core, global.ng.common, global.ng.router, global.rxjs, global.rxjs.operators, global.ng.forms, global.ng.platformBrowser, global['date-fns']));
}(this, function (exports, core, common, router, rxjs, operators, forms, platformBrowser, dateFns) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m) return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    var NgLetContext = /** @class */ (function () {
        function NgLetContext() {
            this.$implicit = null;
            this.ngLet = null;
        }
        return NgLetContext;
    }());
    var NgLetDirective = /** @class */ (function () {
        function NgLetDirective(vcr, templateRef) {
            this.vcr = vcr;
            this.templateRef = templateRef;
            this.context = new NgLetContext();
        }
        Object.defineProperty(NgLetDirective.prototype, "ngLet", {
            set: function (value) {
                this.context.$implicit = this.context.ngLet = value;
            },
            enumerable: true,
            configurable: true
        });
        NgLetDirective.prototype.ngOnInit = function () {
            this.vcr.createEmbeddedView(this.templateRef, this.context);
        };
        NgLetDirective.ctorParameters = function () { return [
            { type: core.ViewContainerRef },
            { type: core.TemplateRef }
        ]; };
        __decorate([
            core.Input(),
            __metadata("design:type", Object),
            __metadata("design:paramtypes", [Object])
        ], NgLetDirective.prototype, "ngLet", null);
        NgLetDirective = __decorate([
            core.Directive({
                selector: '[ngLet]',
            }),
            __metadata("design:paramtypes", [core.ViewContainerRef, core.TemplateRef])
        ], NgLetDirective);
        return NgLetDirective;
    }());

    var NgLetModule = /** @class */ (function () {
        function NgLetModule() {
        }
        NgLetModule = __decorate([
            core.NgModule({
                imports: [common.CommonModule],
                declarations: [NgLetDirective],
                exports: [NgLetDirective],
            })
        ], NgLetModule);
        return NgLetModule;
    }());

    // create a symbol identify the observable I add to
    // the component so it doesn't conflict with anything.
    // I need this so I'm able to add the desired behaviour to the component.
    var destroy$ = Symbol('destroy$');
    /**
     * An operator that takes until destroy it takes a components this a parameter
     * returns a pipeable RxJS operator.
     */
    var untilDestroy = function (component) {
        if (component[destroy$] === undefined) {
            // only hookup each component once.
            addDestroyObservableToComponent(component);
        }
        // pipe in the takeUntil destroy$ and return the source unaltered
        return operators.takeUntil(component[destroy$]);
    };
    /**
     * @internal
     */
    function addDestroyObservableToComponent(component) {
        component[destroy$] = new rxjs.Observable(function (observer) {
            // keep track of the original destroy function,
            // the user might do something in there
            var orignalDestroy = component.ngOnDestroy;
            if (orignalDestroy == null) {
                // Angular does not support dynamic added destroy methods
                // so make sure there is one.
                throw new Error('untilDestroy operator needs the component to have an ngOnDestroy method');
            }
            // replace the ngOndestroy
            component.ngOnDestroy = function () {
                // fire off the destroy observable
                observer.next();
                // complete the observable
                observer.complete();
                // and at last, call the original destroy
                orignalDestroy.call(component);
            };
            // return cleanup function.
            return function (_) { return (component[destroy$] = undefined); };
        });
    }

    function pluck() {
        var props = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            props[_i] = arguments[_i];
        }
        return operators.pluck.apply(void 0, __spread(props));
    }

    var RouterLinkMatchDirective = /** @class */ (function () {
        function RouterLinkMatchDirective(router$1, renderer, ngEl) {
            var _this = this;
            this.renderer = renderer;
            this.ngEl = ngEl;
            this.onChangesHook = new rxjs.Subject();
            rxjs.combineLatest([router$1.events, this.onChangesHook])
                .pipe(operators.map(function (_a) {
                var _b = __read(_a, 1), e = _b[0];
                return e;
            }), operators.filter(function (e) { return e instanceof router.NavigationEnd; }), untilDestroy(this))
                .subscribe(function (e) {
                _this.curRoute = e.urlAfterRedirects;
                _this._updateClass(_this.matchExp);
            });
        }
        Object.defineProperty(RouterLinkMatchDirective.prototype, "routerLinkMatch", {
            set: function (v) {
                if (v && typeof v === 'object') {
                    this.matchExp = v;
                }
                else {
                    throw new TypeError("Unexpected type '" + typeof v + "' of value for " + "input of routerLinkMatch directive, expected 'object'");
                }
            },
            enumerable: true,
            configurable: true
        });
        RouterLinkMatchDirective.prototype.ngOnChanges = function (changes) {
            if (changes.routerLinkMatch) {
                this.onChangesHook.next(changes.routerLinkMatch.currentValue);
            }
        };
        RouterLinkMatchDirective.prototype._updateClass = function (v) {
            var _this = this;
            Object.keys(v).forEach(function (cls) {
                if (v[cls] && typeof v[cls] === 'string') {
                    var regexp = new RegExp(v[cls]);
                    if (_this.curRoute.match(regexp)) {
                        _this._toggleClass(cls, true);
                    }
                    else {
                        _this._toggleClass(cls, false);
                    }
                }
                else {
                    throw new TypeError("Could not convert match value to Regular Expression. " +
                        ("Unexpected type '" + typeof v[cls] + "' for value of key '" + cls + "' ") +
                        "in routerLinkMatch directive match expression, expected 'non-empty string'");
                }
            });
        };
        RouterLinkMatchDirective.prototype._toggleClass = function (classes, enabled) {
            var _this = this;
            classes = classes.trim();
            classes.split(/\s+/g).forEach(function (cls) {
                if (enabled) {
                    _this.renderer.addClass(_this.ngEl.nativeElement, cls);
                }
                else {
                    _this.renderer.removeClass(_this.ngEl.nativeElement, cls);
                }
            });
        };
        RouterLinkMatchDirective.prototype.ngOnDestroy = function () { };
        RouterLinkMatchDirective.ctorParameters = function () { return [
            { type: router.Router },
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.Input('routerLinkMatch'),
            __metadata("design:type", Object),
            __metadata("design:paramtypes", [Object])
        ], RouterLinkMatchDirective.prototype, "routerLinkMatch", null);
        RouterLinkMatchDirective = __decorate([
            core.Directive({
                selector: '[routerLinkMatch]',
            }),
            __metadata("design:paramtypes", [router.Router, core.Renderer2, core.ElementRef])
        ], RouterLinkMatchDirective);
        return RouterLinkMatchDirective;
    }());

    var RouterLinkMatchModule = /** @class */ (function () {
        function RouterLinkMatchModule() {
        }
        RouterLinkMatchModule = __decorate([
            core.NgModule({
                imports: [common.CommonModule],
                declarations: [RouterLinkMatchDirective],
                exports: [RouterLinkMatchDirective],
            })
        ], RouterLinkMatchModule);
        return RouterLinkMatchModule;
    }());

    var ViewportService = /** @class */ (function () {
        function ViewportService() {
            this.options = {
                rootMargin: '0px 0px 0px 0px',
                threshold: [0.5],
            };
            this.callback$ = new rxjs.Subject();
            this.observer = new IntersectionObserver(this.handler.bind(this), this.options);
        }
        ViewportService.prototype.observe = function (element) {
            var _this = this;
            this.observer.observe(element);
            return this.callback$.asObservable().pipe(operators.filter(function (entry) { return entry.target === element; }), operators.finalize(function () { return _this.observer.unobserve(element); }));
        };
        ViewportService.prototype.handler = function (entries) {
            var _this = this;
            entries.forEach(function (entry) { return _this.callback$.next(entry); });
        };
        ViewportService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function ViewportService_Factory() { return new ViewportService(); }, token: ViewportService, providedIn: "root" });
        ViewportService = __decorate([
            core.Injectable({
                providedIn: 'root',
            }),
            __metadata("design:paramtypes", [])
        ], ViewportService);
        return ViewportService;
    }());

    var InViewportDirective = /** @class */ (function () {
        function InViewportDirective(elementRef, viewportService, 
        // tslint:disable-next-line: ban-types
        platformId) {
            this.elementRef = elementRef;
            this.viewportService = viewportService;
            this.platformId = platformId;
            this.preRender = true;
            this.oneTime = false;
            this.inViewport = new core.EventEmitter();
        }
        InViewportDirective.prototype.ngOnInit = function () {
            var _this = this;
            if (common.isPlatformBrowser(this.platformId)) {
                if (this.oneTime) {
                    this.viewportService
                        .observe(this.elementRef.nativeElement)
                        .pipe(untilDestroy(this), operators.filter(function (entry) { return entry.intersectionRatio >= 0.5; }), operators.take(1))
                        .subscribe(function (entry) {
                        _this.inViewport.emit(entry);
                    });
                }
                else {
                    this.viewportService
                        .observe(this.elementRef.nativeElement)
                        .pipe(untilDestroy(this))
                        .subscribe(function (entry) {
                        _this.inViewport.emit(entry);
                    });
                }
            }
            else {
                if (this.preRender) {
                    this.inViewport.emit({ isIntersecting: true, intersectionRatio: 1 });
                }
            }
        };
        InViewportDirective.prototype.ngOnDestroy = function () { };
        InViewportDirective.ctorParameters = function () { return [
            { type: core.ElementRef },
            { type: ViewportService },
            { type: Object, decorators: [{ type: core.Inject, args: [core.PLATFORM_ID,] }] }
        ]; };
        __decorate([
            core.Input(),
            __metadata("design:type", Object)
        ], InViewportDirective.prototype, "preRender", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", Object)
        ], InViewportDirective.prototype, "oneTime", void 0);
        __decorate([
            core.Output(),
            __metadata("design:type", Object)
        ], InViewportDirective.prototype, "inViewport", void 0);
        InViewportDirective = __decorate([
            core.Directive({
                selector: '[inViewport]',
            }),
            __param(2, core.Inject(core.PLATFORM_ID)),
            __metadata("design:paramtypes", [core.ElementRef,
                ViewportService,
                Object])
        ], InViewportDirective);
        return InViewportDirective;
    }());

    var InViewportModule = /** @class */ (function () {
        function InViewportModule() {
        }
        InViewportModule = __decorate([
            core.NgModule({
                imports: [common.CommonModule],
                declarations: [InViewportDirective],
                exports: [InViewportDirective],
            })
        ], InViewportModule);
        return InViewportModule;
    }());

    var ClickOutsideDirective = /** @class */ (function () {
        function ClickOutsideDirective(elementRef) {
            this.elementRef = elementRef;
            this.ngxClickOutside = new core.EventEmitter();
        }
        ClickOutsideDirective.prototype.onClick = function (event, targetElement) {
            if (!targetElement) {
                return;
            }
            var clickedInside = this.elementRef.nativeElement.contains(targetElement);
            if (!clickedInside) {
                this.ngxClickOutside.emit(event);
            }
        };
        ClickOutsideDirective.ctorParameters = function () { return [
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.Output(),
            __metadata("design:type", Object)
        ], ClickOutsideDirective.prototype, "ngxClickOutside", void 0);
        __decorate([
            core.HostListener('document:click', ['$event', '$event.target']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [MouseEvent, HTMLElement]),
            __metadata("design:returntype", void 0)
        ], ClickOutsideDirective.prototype, "onClick", null);
        ClickOutsideDirective = __decorate([
            core.Directive({
                selector: '[ngxClickOutside]',
            }),
            __metadata("design:paramtypes", [core.ElementRef])
        ], ClickOutsideDirective);
        return ClickOutsideDirective;
    }());

    var ClickOutsideModule = /** @class */ (function () {
        function ClickOutsideModule() {
        }
        ClickOutsideModule = __decorate([
            core.NgModule({
                declarations: [ClickOutsideDirective],
                imports: [common.CommonModule],
                exports: [ClickOutsideDirective],
            })
        ], ClickOutsideModule);
        return ClickOutsideModule;
    }());

    var MinValidatorDirective = /** @class */ (function () {
        function MinValidatorDirective() {
        }
        MinValidatorDirective_1 = MinValidatorDirective;
        MinValidatorDirective.prototype.validate = function (control) {
            return this.min ? forms.Validators.min(this.min)(control) : null;
        };
        var MinValidatorDirective_1;
        __decorate([
            core.Input(),
            __metadata("design:type", Number)
        ], MinValidatorDirective.prototype, "min", void 0);
        MinValidatorDirective = MinValidatorDirective_1 = __decorate([
            core.Directive({
                selector: '[appMin],[formControlName],[formControl],[ngModel]',
                providers: [{ provide: forms.NG_VALIDATORS, useExisting: MinValidatorDirective_1, multi: true }],
                exportAs: 'min',
            })
        ], MinValidatorDirective);
        return MinValidatorDirective;
    }());

    var MinModule = /** @class */ (function () {
        function MinModule() {
        }
        MinModule = __decorate([
            core.NgModule({
                declarations: [MinValidatorDirective],
                imports: [common.CommonModule],
                exports: [MinValidatorDirective],
            })
        ], MinModule);
        return MinModule;
    }());

    var MASK_FLAGS = ['C', '&', 'a', 'A', '?', 'L', '9', '0', '#'];
    var KEYS = {
        Ctrl: 17,
        Z: 90,
        Y: 89,
        X: 88,
        BACKSPACE: 8,
        DELETE: 46,
    };
    var MaskHelper = /** @class */ (function () {
        function MaskHelper() {
        }
        Object.defineProperty(MaskHelper.prototype, "cursor", {
            get: function () {
                return this.cursorPrivate;
            },
            enumerable: true,
            configurable: true
        });
        MaskHelper.prototype.parseValueByMask = function (value, maskOptions, cursor) {
            var inputValue = value;
            var mask = maskOptions.format;
            var literals = this.getMaskLiterals(mask);
            var literalKeys = Array.from(literals.keys());
            var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
            if (inputValue.length < mask.length) {
                // BACKSPACE, DELETE
                if (inputValue === '' && cursor === -1) {
                    this.cursorPrivate = 0;
                    return this.parseValueByMaskOnInit(value, maskOptions);
                } // workaround for IE 'x' button
                if (nonLiteralIndeces.indexOf(cursor + 1) !== -1) {
                    inputValue = this.insertCharAt(inputValue, cursor + 1, maskOptions.promptChar);
                    this.cursorPrivate = cursor + 1;
                }
                else {
                    inputValue = this.insertCharAt(inputValue, cursor + 1, mask[cursor + 1]);
                    this.cursorPrivate = cursor + 1;
                    for (var i = this.cursorPrivate; i < 0; i--) {
                        if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                            this.cursorPrivate--;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
            else {
                var char = inputValue[cursor];
                var isCharValid = this.validateCharOnPostion(char, cursor, mask);
                if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                    inputValue = this.replaceCharAt(inputValue, cursor, '');
                    if (isCharValid) {
                        inputValue = this.replaceCharAt(inputValue, cursor, char);
                        this.cursorPrivate = cursor + 1;
                    }
                    else {
                        this.cursorPrivate = cursor;
                    }
                }
                else {
                    inputValue = this.replaceCharAt(inputValue, cursor, '');
                    this.cursorPrivate = ++cursor;
                    for (var i = cursor; i < mask.length; i++) {
                        if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                            this.cursorPrivate = ++cursor;
                        }
                        else {
                            isCharValid = this.validateCharOnPostion(char, cursor, mask);
                            if (isCharValid) {
                                inputValue = this.replaceCharAt(inputValue, cursor, char);
                                this.cursorPrivate = ++cursor;
                                break;
                            }
                            else {
                                break;
                            }
                        }
                    }
                }
            }
            return inputValue;
        };
        MaskHelper.prototype.parseMask = function (maskOptions) {
            var e_1, _a;
            var _this = this;
            var outputVal = '';
            var mask = maskOptions.format;
            var literals = this.getMaskLiterals(mask);
            try {
                for (var mask_1 = __values(mask), mask_1_1 = mask_1.next(); !mask_1_1.done; mask_1_1 = mask_1.next()) {
                    var maskSym = mask_1_1.value;
                    outputVal += maskOptions.promptChar;
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (mask_1_1 && !mask_1_1.done && (_a = mask_1.return)) _a.call(mask_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            literals.forEach(function (val, key) {
                outputVal = _this.replaceCharAt(outputVal, key, val);
            });
            return outputVal;
        };
        MaskHelper.prototype.parseValueByMaskOnInit = function (inputVal, maskOptions) {
            var e_2, _a, e_3, _b;
            var _this = this;
            var outputVal = '';
            var value = '';
            var mask = maskOptions.format;
            var literals = this.getMaskLiterals(mask);
            var literalKeys = Array.from(literals.keys());
            var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
            var literalValues = Array.from(literals.values());
            if (inputVal != null) {
                value = inputVal.toString();
            }
            try {
                for (var mask_2 = __values(mask), mask_2_1 = mask_2.next(); !mask_2_1.done; mask_2_1 = mask_2.next()) {
                    var maskSym = mask_2_1.value;
                    outputVal += maskOptions.promptChar;
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (mask_2_1 && !mask_2_1.done && (_a = mask_2.return)) _a.call(mask_2);
                }
                finally { if (e_2) throw e_2.error; }
            }
            literals.forEach(function (val, key) {
                outputVal = _this.replaceCharAt(outputVal, key, val);
            });
            if (!value) {
                return outputVal;
            }
            var nonLiteralValues = this.getNonLiteralValues(value, literalValues);
            for (var i = 0; i < nonLiteralValues.length; i++) {
                var char = nonLiteralValues[i];
                var isCharValid = this.validateCharOnPostion(char, nonLiteralIndeces[i], mask);
                if (!isCharValid && char !== maskOptions.promptChar) {
                    nonLiteralValues[i] = maskOptions.promptChar;
                }
            }
            if (nonLiteralValues.length > nonLiteralIndeces.length) {
                nonLiteralValues.splice(nonLiteralIndeces.length);
            }
            var pos = 0;
            try {
                for (var nonLiteralValues_1 = __values(nonLiteralValues), nonLiteralValues_1_1 = nonLiteralValues_1.next(); !nonLiteralValues_1_1.done; nonLiteralValues_1_1 = nonLiteralValues_1.next()) {
                    var nonLiteralValue = nonLiteralValues_1_1.value;
                    var char = nonLiteralValue;
                    outputVal = this.replaceCharAt(outputVal, nonLiteralIndeces[pos++], char);
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (nonLiteralValues_1_1 && !nonLiteralValues_1_1.done && (_b = nonLiteralValues_1.return)) _b.call(nonLiteralValues_1);
                }
                finally { if (e_3) throw e_3.error; }
            }
            return outputVal;
        };
        MaskHelper.prototype.restoreValueFromMask = function (value, maskOptions) {
            var e_4, _a;
            var outputVal = '';
            var mask = maskOptions.format;
            var literals = this.getMaskLiterals(mask);
            var literalValues = Array.from(literals.values());
            try {
                for (var value_1 = __values(value), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
                    var val = value_1_1.value;
                    if (literalValues.indexOf(val) === -1) {
                        if (val !== maskOptions.promptChar) {
                            outputVal += val;
                        }
                    }
                }
            }
            catch (e_4_1) { e_4 = { error: e_4_1 }; }
            finally {
                try {
                    if (value_1_1 && !value_1_1.done && (_a = value_1.return)) _a.call(value_1);
                }
                finally { if (e_4) throw e_4.error; }
            }
            return outputVal;
        };
        MaskHelper.prototype.parseValueByMaskUponSelection = function (value, maskOptions, cursor, selection) {
            var isCharValid;
            var inputValue = value;
            var char = inputValue[cursor];
            var mask = maskOptions.format;
            var literals = this.getMaskLiterals(mask);
            var literalKeys = Array.from(literals.keys());
            var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
            if (!this.data) {
                this.cursorPrivate = cursor < 0 ? ++cursor : cursor;
                if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                    isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                    inputValue = isCharValid
                        ? this.replaceCharAt(inputValue, this.cursorPrivate++, char)
                        : (inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar));
                    selection--;
                    if (selection > 0) {
                        for (var i = 0; i < selection; i++) {
                            cursor++;
                            inputValue =
                                nonLiteralIndeces.indexOf(cursor) !== -1
                                    ? this.insertCharAt(inputValue, cursor, maskOptions.promptChar)
                                    : this.insertCharAt(inputValue, cursor, mask[cursor]);
                        }
                    }
                }
                else {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate, mask[this.cursorPrivate]);
                    this.cursorPrivate++;
                    selection--;
                    var isMarked = false;
                    if (selection > 0) {
                        cursor = this.cursorPrivate;
                        for (var i = 0; i < selection; i++) {
                            if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                                isCharValid = this.validateCharOnPostion(char, cursor, mask);
                                if (isCharValid && !isMarked) {
                                    inputValue = this.insertCharAt(inputValue, cursor, char);
                                    cursor++;
                                    this.cursorPrivate++;
                                    isMarked = true;
                                }
                                else {
                                    inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                                    cursor++;
                                }
                            }
                            else {
                                inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                                if (cursor === this.cursorPrivate) {
                                    this.cursorPrivate++;
                                }
                                cursor++;
                            }
                        }
                    }
                }
            }
            else {
                if (inputValue === '' && cursor === -1) {
                    this.cursorPrivate = 0;
                    return this.parseValueByMaskOnInit(value, maskOptions);
                } // workaround for IE 'x' button
                if (this.cursorPrivate < 0) {
                    this.cursorPrivate++;
                    cursor++;
                }
                cursor++;
                this.cursorPrivate = cursor;
                for (var i = 0; i < selection; i++) {
                    if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                        inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                        cursor++;
                    }
                    else {
                        inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                        cursor++;
                    }
                }
            }
            return inputValue;
        };
        MaskHelper.prototype.parseValueByMaskUponCopyPaste = function (value, maskOptions, cursor, clipboardData, selection) {
            var e_5, _a;
            var inputValue = value;
            var mask = maskOptions.format;
            var literals = this.getMaskLiterals(mask);
            var literalKeys = Array.from(literals.keys());
            var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
            var selectionEnd = cursor + selection;
            this.cursorPrivate = cursor;
            try {
                for (var clipboardData_1 = __values(clipboardData), clipboardData_1_1 = clipboardData_1.next(); !clipboardData_1_1.done; clipboardData_1_1 = clipboardData_1.next()) {
                    var clipboardSym = clipboardData_1_1.value;
                    var char = clipboardSym;
                    if (this.cursorPrivate > mask.length) {
                        return inputValue;
                    }
                    if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                        var isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                        }
                    }
                    else {
                        for (var i = cursor; i < mask.length; i++) {
                            if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                                this.cursorPrivate++;
                            }
                            else {
                                var isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                                if (isCharValid) {
                                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                                }
                                break;
                            }
                        }
                    }
                    selection--;
                }
            }
            catch (e_5_1) { e_5 = { error: e_5_1 }; }
            finally {
                try {
                    if (clipboardData_1_1 && !clipboardData_1_1.done && (_a = clipboardData_1.return)) _a.call(clipboardData_1);
                }
                finally { if (e_5) throw e_5.error; }
            }
            if (selection > 0) {
                for (var i = this.cursorPrivate; i < selectionEnd; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate++;
                    }
                    else {
                        inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                    }
                }
            }
            return inputValue;
        };
        MaskHelper.prototype.validateCharOnPostion = function (inputChar, position, mask) {
            var regex;
            var isValid;
            var letterOrDigitRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
            var letterDigitOrSpaceRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
            var letterRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
            var letteSpaceRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
            var digitRegEx = '[\\d]';
            var digitSpaceRegEx = '[\\d\\u0020]';
            var digitSpecialRegEx = '[\\d-\\+]';
            switch (mask.charAt(position)) {
                case 'C':
                    isValid = inputChar !== '';
                    break;
                case '&':
                    regex = new RegExp('[\\u0020]');
                    isValid = !regex.test(inputChar);
                    break;
                case 'a':
                    regex = new RegExp(letterDigitOrSpaceRegEx);
                    isValid = regex.test(inputChar);
                    break;
                case 'A':
                    regex = new RegExp(letterOrDigitRegEx);
                    isValid = regex.test(inputChar);
                    break;
                case '?':
                    regex = new RegExp(letteSpaceRegEx);
                    isValid = regex.test(inputChar);
                    break;
                case 'L':
                    regex = new RegExp(letterRegEx);
                    isValid = regex.test(inputChar);
                    break;
                case '0':
                    regex = new RegExp(digitRegEx);
                    isValid = regex.test(inputChar);
                    break;
                case '9':
                    regex = new RegExp(digitSpaceRegEx);
                    isValid = regex.test(inputChar);
                    break;
                case '#':
                    regex = new RegExp(digitSpecialRegEx);
                    isValid = regex.test(inputChar);
                    break;
                default: {
                    isValid = null;
                }
            }
            return isValid;
        };
        MaskHelper.prototype.replaceCharAt = function (strValue, index, char) {
            if (strValue !== undefined) {
                return strValue.substring(0, index) + char + strValue.substring(index + 1);
            }
        };
        MaskHelper.prototype.insertCharAt = function (strValue, index, char) {
            if (strValue !== undefined) {
                return strValue.substring(0, index) + char + strValue.substring(index);
            }
        };
        MaskHelper.prototype.getMaskLiterals = function (mask) {
            var literals = new Map();
            for (var i = 0; i < mask.length; i++) {
                var char = mask.charAt(i);
                if (MASK_FLAGS.indexOf(char) === -1) {
                    literals.set(i, char);
                }
            }
            return literals;
        };
        MaskHelper.prototype.getNonLiteralIndeces = function (mask, literalKeys) {
            var nonLiteralsIndeces = new Array();
            for (var i = 0; i < mask.length; i++) {
                if (literalKeys.indexOf(i) === -1) {
                    nonLiteralsIndeces.push(i);
                }
            }
            return nonLiteralsIndeces;
        };
        MaskHelper.prototype.getNonLiteralValues = function (value, literalValues) {
            var e_6, _a;
            var nonLiteralValues = new Array();
            try {
                for (var value_2 = __values(value), value_2_1 = value_2.next(); !value_2_1.done; value_2_1 = value_2.next()) {
                    var val = value_2_1.value;
                    if (literalValues.indexOf(val) === -1) {
                        nonLiteralValues.push(val);
                    }
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (value_2_1 && !value_2_1.done && (_a = value_2.return)) _a.call(value_2);
                }
                finally { if (e_6) throw e_6.error; }
            }
            return nonLiteralValues;
        };
        return MaskHelper;
    }());

    function isIE() {
        return navigator.appVersion.indexOf('Trident/') > 0;
    }
    var noop = function () { };
    var ɵ0 = noop;
    var MaskDirective = /** @class */ (function () {
        function MaskDirective(elementRef) {
            this.elementRef = elementRef;
            this.valueChange = new core.EventEmitter();
            this.maskOptions = {
                format: '',
                promptChar: '',
            };
            this.onTouchedCallback = noop;
            this.onChangeCallback = noop;
            this.maskHelper = new MaskHelper();
        }
        MaskDirective_1 = MaskDirective;
        Object.defineProperty(MaskDirective.prototype, "value", {
            get: function () {
                return this.nativeElement.value;
            },
            set: function (val) {
                this.nativeElement.value = val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MaskDirective.prototype, "nativeElement", {
            get: function () {
                return this.elementRef.nativeElement;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MaskDirective.prototype, "selectionStart", {
            get: function () {
                return this.nativeElement.selectionStart;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(MaskDirective.prototype, "selectionEnd", {
            get: function () {
                return this.nativeElement.selectionEnd;
            },
            enumerable: true,
            configurable: true
        });
        MaskDirective.prototype.ngOnInit = function () {
            if (this.promptChar && this.promptChar.length > 1) {
                this.maskOptions.promptChar = this.promptChar = this.promptChar.substring(0, 1);
            }
            this.maskOptions.format = this.mask ? this.mask : 'CCCCCCCCCC';
            this.maskOptions.promptChar = this.promptChar ? this.promptChar : '_';
            this.nativeElement.setAttribute('placeholder', this.placeholder ? this.placeholder : this.maskOptions.format);
        };
        MaskDirective.prototype.onKeydown = function (event) {
            var key = event.keyCode || event.charCode;
            if (isIE() && this.stopPropagation) {
                this.stopPropagation = false;
            }
            if (key === KEYS.Ctrl) {
                this.ctrlDown = true;
            }
            if ((this.ctrlDown && key === KEYS.Z) || (this.ctrlDown && key === KEYS.Y)) {
                event.preventDefault();
            }
            this.key = key;
            this.selection = Math.abs(this.selectionEnd - this.selectionStart);
        };
        MaskDirective.prototype.onKeyup = function (event) {
            var key = event.keyCode || event.charCode;
            if (key === KEYS.Ctrl) {
                this.ctrlDown = false;
            }
        };
        MaskDirective.prototype.onPaste = function (event) {
            this.paste = true;
            this.valOnPaste = this.value;
            this.cursorOnPaste = this.getCursorPosition();
        };
        MaskDirective.prototype.onInputChanged = function (event) {
            if (isIE() && this.stopPropagation) {
                this.stopPropagation = false;
                return;
            }
            if (this.paste) {
                this.paste = false;
                var clipboardData = this.value.substring(this.cursorOnPaste, this.getCursorPosition());
                this.value = this.maskHelper.parseValueByMaskUponCopyPaste(this.valOnPaste, this.maskOptions, this.cursorOnPaste, clipboardData, this.selection);
                this.setCursorPosition(this.maskHelper.cursor);
            }
            else {
                var currentCursorPos = this.getCursorPosition();
                this.maskHelper.data = this.key === KEYS.BACKSPACE || this.key === KEYS.DELETE;
                this.value =
                    this.selection && this.selection !== 0
                        ? this.maskHelper.parseValueByMaskUponSelection(this.value, this.maskOptions, currentCursorPos - 1, this.selection)
                        : this.maskHelper.parseValueByMask(this.value, this.maskOptions, currentCursorPos - 1);
                this.setCursorPosition(this.maskHelper.cursor);
            }
            var rawVal = this.maskHelper.restoreValueFromMask(this.value, this.maskOptions);
            this.dataValue = this.includeLiterals ? this.value : rawVal;
            this.onChangeCallback(this.dataValue);
            this.valueChange.emit({ rawValue: rawVal, formattedValue: this.value });
        };
        MaskDirective.prototype.onFocus = function (value) {
            if (this.focusedValuePipe) {
                if (isIE()) {
                    this.stopPropagation = true;
                }
                this.value = this.focusedValuePipe.transform(value);
            }
            else {
                this.value = this.maskHelper.parseValueByMaskOnInit(this.value, this.maskOptions);
            }
        };
        MaskDirective.prototype.onBlur = function (value) {
            if (this.displayValuePipe) {
                this.value = this.displayValuePipe.transform(value);
            }
            else if (value === this.maskHelper.parseMask(this.maskOptions)) {
                this.value = '';
            }
        };
        MaskDirective.prototype.getCursorPosition = function () {
            return this.nativeElement.selectionStart;
        };
        MaskDirective.prototype.setCursorPosition = function (start, end) {
            if (end === void 0) { end = start; }
            this.nativeElement.setSelectionRange(start, end);
        };
        MaskDirective.prototype.writeValue = function (value) {
            if (this.promptChar && this.promptChar.length > 1) {
                this.maskOptions.promptChar = this.promptChar.substring(0, 1);
            }
            this.value = value ? this.maskHelper.parseValueByMaskOnInit(value, this.maskOptions) : '';
            if (this.displayValuePipe) {
                this.value = this.displayValuePipe.transform(this.value);
            }
            this.dataValue = this.includeLiterals ? this.value : value;
            this.onChangeCallback(this.dataValue);
            this.valueChange.emit({ rawValue: value, formattedValue: this.value });
        };
        MaskDirective.prototype.registerOnChange = function (fn) {
            this.onChangeCallback = fn;
        };
        MaskDirective.prototype.registerOnTouched = function (fn) {
            this.onTouchedCallback = fn;
        };
        var MaskDirective_1;
        MaskDirective.ctorParameters = function () { return [
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.Input('ngxMask'),
            __metadata("design:type", String)
        ], MaskDirective.prototype, "mask", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", String)
        ], MaskDirective.prototype, "promptChar", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", Boolean)
        ], MaskDirective.prototype, "includeLiterals", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", String)
        ], MaskDirective.prototype, "placeholder", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", Object)
        ], MaskDirective.prototype, "displayValuePipe", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", Object)
        ], MaskDirective.prototype, "focusedValuePipe", void 0);
        __decorate([
            core.Input(),
            __metadata("design:type", String)
        ], MaskDirective.prototype, "dataValue", void 0);
        __decorate([
            core.Output(),
            __metadata("design:type", Object)
        ], MaskDirective.prototype, "valueChange", void 0);
        __decorate([
            core.HostListener('keydown', ['$event']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [Object]),
            __metadata("design:returntype", void 0)
        ], MaskDirective.prototype, "onKeydown", null);
        __decorate([
            core.HostListener('keyup', ['$event']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [Object]),
            __metadata("design:returntype", void 0)
        ], MaskDirective.prototype, "onKeyup", null);
        __decorate([
            core.HostListener('paste', ['$event']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [Object]),
            __metadata("design:returntype", void 0)
        ], MaskDirective.prototype, "onPaste", null);
        __decorate([
            core.HostListener('input', ['$event']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [Object]),
            __metadata("design:returntype", void 0)
        ], MaskDirective.prototype, "onInputChanged", null);
        __decorate([
            core.HostListener('focus', ['$event.target.value']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [Object]),
            __metadata("design:returntype", void 0)
        ], MaskDirective.prototype, "onFocus", null);
        __decorate([
            core.HostListener('blur', ['$event.target.value']),
            __metadata("design:type", Function),
            __metadata("design:paramtypes", [Object]),
            __metadata("design:returntype", void 0)
        ], MaskDirective.prototype, "onBlur", null);
        MaskDirective = MaskDirective_1 = __decorate([
            core.Directive({
                providers: [{ provide: forms.NG_VALUE_ACCESSOR, useExisting: MaskDirective_1, multi: true }],
                selector: '[ngxMask]',
            }),
            __metadata("design:paramtypes", [core.ElementRef])
        ], MaskDirective);
        return MaskDirective;
    }());

    var MaskModule = /** @class */ (function () {
        function MaskModule() {
        }
        MaskModule = __decorate([
            core.NgModule({
                declarations: [MaskDirective],
                imports: [common.CommonModule],
                exports: [MaskDirective],
            })
        ], MaskModule);
        return MaskModule;
    }());

    var FilterPipe = /** @class */ (function () {
        function FilterPipe() {
        }
        FilterPipe.prototype.transform = function (itemList, filterTerm, filterBy) {
            if (!filterBy) {
                return itemList;
            }
            if (filterTerm === '') {
                return itemList;
            }
            filterBy = filterBy.toString();
            return itemList.filter(function (item) {
                if (item[filterBy]) {
                    return item[filterBy]
                        .toString()
                        .toLowerCase()
                        .includes(filterTerm.toLowerCase());
                }
            });
        };
        FilterPipe = __decorate([
            core.Pipe({ name: 'filter' })
        ], FilterPipe);
        return FilterPipe;
    }());

    /**
     * <ul>
     *   <li *ngFor="let object of myArray | groupBy:'color'"></li>
     * </ul>
     */
    var GroupByPipe = /** @class */ (function () {
        function GroupByPipe() {
        }
        GroupByPipe.prototype.transform = function (collection, property) {
            // prevents the application from breaking if the array of objects doesn't exist yet
            if (!collection) {
                return null;
            }
            var groupedCollection = collection.reduce(function (previous, current) {
                if (!previous[current[property]]) {
                    previous[current[property]] = [current];
                }
                else {
                    previous[current[property]].push(current);
                }
                return previous;
            }, {});
            // this will return an array of objects, each object containing a group of objects
            return Object.keys(groupedCollection).map(function (key) { return ({
                key: key,
                value: groupedCollection[key],
            }); });
        };
        GroupByPipe = __decorate([
            core.Pipe({ name: 'groupBy' })
        ], GroupByPipe);
        return GroupByPipe;
    }());

    var SafeHtmlPipe = /** @class */ (function () {
        function SafeHtmlPipe(sanitizer) {
            this.sanitizer = sanitizer;
        }
        SafeHtmlPipe.prototype.transform = function (value, args) {
            return this.sanitizer.bypassSecurityTrustHtml(value);
        };
        SafeHtmlPipe.ctorParameters = function () { return [
            { type: platformBrowser.DomSanitizer }
        ]; };
        SafeHtmlPipe = __decorate([
            core.Pipe({ name: 'safeHtml' }),
            __metadata("design:paramtypes", [platformBrowser.DomSanitizer])
        ], SafeHtmlPipe);
        return SafeHtmlPipe;
    }());

    var HelperModule = /** @class */ (function () {
        function HelperModule() {
        }
        HelperModule = __decorate([
            core.NgModule({
                imports: [common.CommonModule],
                declarations: [FilterPipe, GroupByPipe, SafeHtmlPipe],
                exports: [FilterPipe, GroupByPipe, SafeHtmlPipe],
            })
        ], HelperModule);
        return HelperModule;
    }());

    var CharactersPipe = /** @class */ (function () {
        function CharactersPipe() {
        }
        CharactersPipe.prototype.transform = function (value, limit, trail) {
            if (limit === void 0) { limit = 40; }
            if (trail === void 0) { trail = '…'; }
            if (!value) {
                value = '';
            }
            if (limit < 0) {
                limit *= -1;
                return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
            }
            else {
                return value.length > limit ? value.substring(0, limit) + trail : value;
            }
        };
        CharactersPipe = __decorate([
            core.Pipe({
                pure: true,
                name: 'characters',
            })
        ], CharactersPipe);
        return CharactersPipe;
    }());

    var WordsPipe = /** @class */ (function () {
        function WordsPipe() {
        }
        WordsPipe.prototype.transform = function (value, limit, trail) {
            if (limit === void 0) { limit = 40; }
            if (trail === void 0) { trail = '…'; }
            var result = value || '';
            if (value) {
                var words = value.split(/\s+/);
                if (words.length > Math.abs(limit)) {
                    if (limit < 0) {
                        limit *= -1;
                        result = trail + words.slice(words.length - limit, words.length).join(' ');
                    }
                    else {
                        result = words.slice(0, limit).join(' ') + trail;
                    }
                }
            }
            return result;
        };
        WordsPipe = __decorate([
            core.Pipe({
                pure: true,
                name: 'words',
            })
        ], WordsPipe);
        return WordsPipe;
    }());

    var TruncateModule = /** @class */ (function () {
        function TruncateModule() {
        }
        TruncateModule = __decorate([
            core.NgModule({
                imports: [common.CommonModule],
                declarations: [CharactersPipe, WordsPipe],
                exports: [CharactersPipe, WordsPipe],
            })
        ], TruncateModule);
        return TruncateModule;
    }());

    var defaultConfig = { addSuffix: true };
    /**
     * impure pipe, which in general can lead to bad performance
     * but the backoff function limits the frequency the pipe checks for updates
     * so the performance is close to that of a pure pipe
     * the downside of this is that if you change the value of the input, the pipe might not notice for a while
     * so this pipe is intended for static data
     *
     * expected input is a time (number, string or Date)
     * output is a string expressing distance from that time to now, plus the suffix 'ago'
     * output refreshes at dynamic intervals, with refresh rate slowing down as the input time gets further away from now
     */
    var FormatTimeInWordsPipe = /** @class */ (function () {
        function FormatTimeInWordsPipe(cdr) {
            this.cdr = cdr;
            this.isDestroyed = false;
            this.async = new common.AsyncPipe(this.cdr);
        }
        FormatTimeInWordsPipe_1 = FormatTimeInWordsPipe;
        FormatTimeInWordsPipe.prototype.ngOnDestroy = function () {
            this.isDestroyed = true; // pipe will stop executing after next iteration
        };
        FormatTimeInWordsPipe.prototype.transform = function (date, options) {
            if (date == null) {
                throw new Error(FormatTimeInWordsPipe_1.NO_ARGS_ERROR);
            }
            // set the pipe to the Observable if not yet done, and return an async pipe
            if (!this.agoExpression) {
                this.agoExpression = this.timeAgo(date, __assign({}, defaultConfig, options));
            }
            return this.async.transform(this.agoExpression);
        };
        FormatTimeInWordsPipe.prototype.timeAgo = function (date, options) {
            var _this = this;
            var nextBackoff = this.backoff(date);
            return rxjs.of(true).pipe(
            // will not recheck input until delay completes
            operators.repeatWhen(function (notify) { return notify.pipe(operators.delayWhen(function () { return rxjs.interval(nextBackoff); })); }), operators.takeWhile(function (_) { return !_this.isDestroyed; }), operators.map(function (_) { return dateFns.formatDistance(_this.stringToDate(date), new Date(), options); }), operators.tap(function (_) { return (nextBackoff = _this.backoff(date)); }));
        };
        FormatTimeInWordsPipe.prototype.backoff = function (date) {
            var minutesElapsed = Math.abs(dateFns.differenceInMinutes(new Date(), this.stringToDate(date))); // this will always be positive
            var backoffAmountInSeconds;
            if (minutesElapsed < 2) {
                backoffAmountInSeconds = 5;
            }
            else if (minutesElapsed >= 2 && minutesElapsed < 5) {
                backoffAmountInSeconds = 15;
            }
            else if (minutesElapsed >= 5 && minutesElapsed < 60) {
                backoffAmountInSeconds = 30;
            }
            else if (minutesElapsed >= 60) {
                backoffAmountInSeconds = 300; // 5 minutes
            }
            return backoffAmountInSeconds * 1000; // return an amount of milliseconds
        };
        FormatTimeInWordsPipe.prototype.stringToDate = function (date) {
            function isString(x) {
                return Object.prototype.toString.call(x) === '[object String]';
            }
            return isString(date) ? dateFns.parseISO(date) : date;
        };
        var FormatTimeInWordsPipe_1;
        FormatTimeInWordsPipe.NO_ARGS_ERROR = 'formatTimeInWords: missing required arguments';
        FormatTimeInWordsPipe.ctorParameters = function () { return [
            { type: core.ChangeDetectorRef }
        ]; };
        FormatTimeInWordsPipe = FormatTimeInWordsPipe_1 = __decorate([
            core.Pipe({ name: 'formatTimeInWords', pure: false }),
            __metadata("design:paramtypes", [core.ChangeDetectorRef])
        ], FormatTimeInWordsPipe);
        return FormatTimeInWordsPipe;
    }());

    var PIPES = [FormatTimeInWordsPipe];
    var DateFnsModule = /** @class */ (function () {
        function DateFnsModule() {
        }
        DateFnsModule = __decorate([
            core.NgModule({
                declarations: [PIPES],
                imports: [common.CommonModule],
                exports: [PIPES],
            })
        ], DateFnsModule);
        return DateFnsModule;
    }());

    exports.ClickOutsideModule = ClickOutsideModule;
    exports.DateFnsModule = DateFnsModule;
    exports.HelperModule = HelperModule;
    exports.InViewportModule = InViewportModule;
    exports.MaskModule = MaskModule;
    exports.MinModule = MinModule;
    exports.NgLetModule = NgLetModule;
    exports.RouterLinkMatchModule = RouterLinkMatchModule;
    exports.TruncateModule = TruncateModule;
    exports.ViewportService = ViewportService;
    exports.pluck = pluck;
    exports.untilDestroy = untilDestroy;
    exports.ɵa = NgLetContext;
    exports.ɵb = NgLetDirective;
    exports.ɵc = RouterLinkMatchDirective;
    exports.ɵd = InViewportDirective;
    exports.ɵdestroy$ = destroy$;
    exports.ɵe = ClickOutsideDirective;
    exports.ɵf = MinValidatorDirective;
    exports.ɵg = MaskDirective;
    exports.ɵh = FilterPipe;
    exports.ɵi = GroupByPipe;
    exports.ɵj = SafeHtmlPipe;
    exports.ɵk = CharactersPipe;
    exports.ɵl = WordsPipe;
    exports.ɵm = FormatTimeInWordsPipe;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=ngx-starter-kit-ngx-utils.umd.js.map
