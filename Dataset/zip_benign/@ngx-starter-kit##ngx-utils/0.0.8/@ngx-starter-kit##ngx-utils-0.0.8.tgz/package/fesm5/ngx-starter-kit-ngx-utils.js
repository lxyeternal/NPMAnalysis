import { __decorate, __metadata, __spread, __read, __param, __values, __assign } from 'tslib';
import { ViewContainerRef, TemplateRef, Input, Directive, NgModule, Renderer2, ElementRef, ɵɵdefineInjectable, Injectable, EventEmitter, Inject, PLATFORM_ID, Output, HostListener, Pipe, ChangeDetectorRef } from '@angular/core';
import { CommonModule, isPlatformBrowser, AsyncPipe } from '@angular/common';
import { NavigationEnd, Router } from '@angular/router';
import { Observable, Subject, combineLatest, of, interval } from 'rxjs';
import { takeUntil, pluck as pluck$1, map, filter, finalize, take, repeatWhen, delayWhen, takeWhile, tap } from 'rxjs/operators';
import { Validators, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { formatDistance, differenceInMinutes, parseISO } from 'date-fns';

var NgLetContext = /** @class */ (function () {
    function NgLetContext() {
        this.$implicit = null;
        this.ngLet = null;
    }
    return NgLetContext;
}());
var NgLetDirective = /** @class */ (function () {
    function NgLetDirective(vcr, templateRef) {
        this.vcr = vcr;
        this.templateRef = templateRef;
        this.context = new NgLetContext();
    }
    Object.defineProperty(NgLetDirective.prototype, "ngLet", {
        set: function (value) {
            this.context.$implicit = this.context.ngLet = value;
        },
        enumerable: true,
        configurable: true
    });
    NgLetDirective.prototype.ngOnInit = function () {
        this.vcr.createEmbeddedView(this.templateRef, this.context);
    };
    NgLetDirective.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: TemplateRef }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], NgLetDirective.prototype, "ngLet", null);
    NgLetDirective = __decorate([
        Directive({
            selector: '[ngLet]',
        }),
        __metadata("design:paramtypes", [ViewContainerRef, TemplateRef])
    ], NgLetDirective);
    return NgLetDirective;
}());

var NgLetModule = /** @class */ (function () {
    function NgLetModule() {
    }
    NgLetModule = __decorate([
        NgModule({
            imports: [CommonModule],
            declarations: [NgLetDirective],
            exports: [NgLetDirective],
        })
    ], NgLetModule);
    return NgLetModule;
}());

// create a symbol identify the observable I add to
// the component so it doesn't conflict with anything.
// I need this so I'm able to add the desired behaviour to the component.
var destroy$ = Symbol('destroy$');
/**
 * An operator that takes until destroy it takes a components this a parameter
 * returns a pipeable RxJS operator.
 */
var untilDestroy = function (component) {
    if (component[destroy$] === undefined) {
        // only hookup each component once.
        addDestroyObservableToComponent(component);
    }
    // pipe in the takeUntil destroy$ and return the source unaltered
    return takeUntil(component[destroy$]);
};
/**
 * @internal
 */
function addDestroyObservableToComponent(component) {
    component[destroy$] = new Observable(function (observer) {
        // keep track of the original destroy function,
        // the user might do something in there
        var orignalDestroy = component.ngOnDestroy;
        if (orignalDestroy == null) {
            // Angular does not support dynamic added destroy methods
            // so make sure there is one.
            throw new Error('untilDestroy operator needs the component to have an ngOnDestroy method');
        }
        // replace the ngOndestroy
        component.ngOnDestroy = function () {
            // fire off the destroy observable
            observer.next();
            // complete the observable
            observer.complete();
            // and at last, call the original destroy
            orignalDestroy.call(component);
        };
        // return cleanup function.
        return function (_) { return (component[destroy$] = undefined); };
    });
}

function pluck() {
    var props = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        props[_i] = arguments[_i];
    }
    return pluck$1.apply(void 0, __spread(props));
}

var RouterLinkMatchDirective = /** @class */ (function () {
    function RouterLinkMatchDirective(router, renderer, ngEl) {
        var _this = this;
        this.renderer = renderer;
        this.ngEl = ngEl;
        this.onChangesHook = new Subject();
        combineLatest([router.events, this.onChangesHook])
            .pipe(map(function (_a) {
            var _b = __read(_a, 1), e = _b[0];
            return e;
        }), filter(function (e) { return e instanceof NavigationEnd; }), untilDestroy(this))
            .subscribe(function (e) {
            _this.curRoute = e.urlAfterRedirects;
            _this._updateClass(_this.matchExp);
        });
    }
    Object.defineProperty(RouterLinkMatchDirective.prototype, "routerLinkMatch", {
        set: function (v) {
            if (v && typeof v === 'object') {
                this.matchExp = v;
            }
            else {
                throw new TypeError("Unexpected type '" + typeof v + "' of value for " + "input of routerLinkMatch directive, expected 'object'");
            }
        },
        enumerable: true,
        configurable: true
    });
    RouterLinkMatchDirective.prototype.ngOnChanges = function (changes) {
        if (changes.routerLinkMatch) {
            this.onChangesHook.next(changes.routerLinkMatch.currentValue);
        }
    };
    RouterLinkMatchDirective.prototype._updateClass = function (v) {
        var _this = this;
        Object.keys(v).forEach(function (cls) {
            if (v[cls] && typeof v[cls] === 'string') {
                var regexp = new RegExp(v[cls]);
                if (_this.curRoute.match(regexp)) {
                    _this._toggleClass(cls, true);
                }
                else {
                    _this._toggleClass(cls, false);
                }
            }
            else {
                throw new TypeError("Could not convert match value to Regular Expression. " +
                    ("Unexpected type '" + typeof v[cls] + "' for value of key '" + cls + "' ") +
                    "in routerLinkMatch directive match expression, expected 'non-empty string'");
            }
        });
    };
    RouterLinkMatchDirective.prototype._toggleClass = function (classes, enabled) {
        var _this = this;
        classes = classes.trim();
        classes.split(/\s+/g).forEach(function (cls) {
            if (enabled) {
                _this.renderer.addClass(_this.ngEl.nativeElement, cls);
            }
            else {
                _this.renderer.removeClass(_this.ngEl.nativeElement, cls);
            }
        });
    };
    RouterLinkMatchDirective.prototype.ngOnDestroy = function () { };
    RouterLinkMatchDirective.ctorParameters = function () { return [
        { type: Router },
        { type: Renderer2 },
        { type: ElementRef }
    ]; };
    __decorate([
        Input('routerLinkMatch'),
        __metadata("design:type", Object),
        __metadata("design:paramtypes", [Object])
    ], RouterLinkMatchDirective.prototype, "routerLinkMatch", null);
    RouterLinkMatchDirective = __decorate([
        Directive({
            selector: '[routerLinkMatch]',
        }),
        __metadata("design:paramtypes", [Router, Renderer2, ElementRef])
    ], RouterLinkMatchDirective);
    return RouterLinkMatchDirective;
}());

var RouterLinkMatchModule = /** @class */ (function () {
    function RouterLinkMatchModule() {
    }
    RouterLinkMatchModule = __decorate([
        NgModule({
            imports: [CommonModule],
            declarations: [RouterLinkMatchDirective],
            exports: [RouterLinkMatchDirective],
        })
    ], RouterLinkMatchModule);
    return RouterLinkMatchModule;
}());

var ViewportService = /** @class */ (function () {
    function ViewportService() {
        this.options = {
            rootMargin: '0px 0px 0px 0px',
            threshold: [0.5],
        };
        this.callback$ = new Subject();
        this.observer = new IntersectionObserver(this.handler.bind(this), this.options);
    }
    ViewportService.prototype.observe = function (element) {
        var _this = this;
        this.observer.observe(element);
        return this.callback$.asObservable().pipe(filter(function (entry) { return entry.target === element; }), finalize(function () { return _this.observer.unobserve(element); }));
    };
    ViewportService.prototype.handler = function (entries) {
        var _this = this;
        entries.forEach(function (entry) { return _this.callback$.next(entry); });
    };
    ViewportService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ViewportService_Factory() { return new ViewportService(); }, token: ViewportService, providedIn: "root" });
    ViewportService = __decorate([
        Injectable({
            providedIn: 'root',
        }),
        __metadata("design:paramtypes", [])
    ], ViewportService);
    return ViewportService;
}());

var InViewportDirective = /** @class */ (function () {
    function InViewportDirective(elementRef, viewportService, 
    // tslint:disable-next-line: ban-types
    platformId) {
        this.elementRef = elementRef;
        this.viewportService = viewportService;
        this.platformId = platformId;
        this.preRender = true;
        this.oneTime = false;
        this.inViewport = new EventEmitter();
    }
    InViewportDirective.prototype.ngOnInit = function () {
        var _this = this;
        if (isPlatformBrowser(this.platformId)) {
            if (this.oneTime) {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this), filter(function (entry) { return entry.intersectionRatio >= 0.5; }), take(1))
                    .subscribe(function (entry) {
                    _this.inViewport.emit(entry);
                });
            }
            else {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this))
                    .subscribe(function (entry) {
                    _this.inViewport.emit(entry);
                });
            }
        }
        else {
            if (this.preRender) {
                this.inViewport.emit({ isIntersecting: true, intersectionRatio: 1 });
            }
        }
    };
    InViewportDirective.prototype.ngOnDestroy = function () { };
    InViewportDirective.ctorParameters = function () { return [
        { type: ElementRef },
        { type: ViewportService },
        { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], InViewportDirective.prototype, "preRender", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], InViewportDirective.prototype, "oneTime", void 0);
    __decorate([
        Output(),
        __metadata("design:type", Object)
    ], InViewportDirective.prototype, "inViewport", void 0);
    InViewportDirective = __decorate([
        Directive({
            selector: '[inViewport]',
        }),
        __param(2, Inject(PLATFORM_ID)),
        __metadata("design:paramtypes", [ElementRef,
            ViewportService,
            Object])
    ], InViewportDirective);
    return InViewportDirective;
}());

var InViewportModule = /** @class */ (function () {
    function InViewportModule() {
    }
    InViewportModule = __decorate([
        NgModule({
            imports: [CommonModule],
            declarations: [InViewportDirective],
            exports: [InViewportDirective],
        })
    ], InViewportModule);
    return InViewportModule;
}());

var ClickOutsideDirective = /** @class */ (function () {
    function ClickOutsideDirective(elementRef) {
        this.elementRef = elementRef;
        this.ngxClickOutside = new EventEmitter();
    }
    ClickOutsideDirective.prototype.onClick = function (event, targetElement) {
        if (!targetElement) {
            return;
        }
        var clickedInside = this.elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.ngxClickOutside.emit(event);
        }
    };
    ClickOutsideDirective.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    __decorate([
        Output(),
        __metadata("design:type", Object)
    ], ClickOutsideDirective.prototype, "ngxClickOutside", void 0);
    __decorate([
        HostListener('document:click', ['$event', '$event.target']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [MouseEvent, HTMLElement]),
        __metadata("design:returntype", void 0)
    ], ClickOutsideDirective.prototype, "onClick", null);
    ClickOutsideDirective = __decorate([
        Directive({
            selector: '[ngxClickOutside]',
        }),
        __metadata("design:paramtypes", [ElementRef])
    ], ClickOutsideDirective);
    return ClickOutsideDirective;
}());

var ClickOutsideModule = /** @class */ (function () {
    function ClickOutsideModule() {
    }
    ClickOutsideModule = __decorate([
        NgModule({
            declarations: [ClickOutsideDirective],
            imports: [CommonModule],
            exports: [ClickOutsideDirective],
        })
    ], ClickOutsideModule);
    return ClickOutsideModule;
}());

var MinValidatorDirective = /** @class */ (function () {
    function MinValidatorDirective() {
    }
    MinValidatorDirective_1 = MinValidatorDirective;
    MinValidatorDirective.prototype.validate = function (control) {
        return this.min ? Validators.min(this.min)(control) : null;
    };
    var MinValidatorDirective_1;
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], MinValidatorDirective.prototype, "min", void 0);
    MinValidatorDirective = MinValidatorDirective_1 = __decorate([
        Directive({
            selector: '[appMin],[formControlName],[formControl],[ngModel]',
            providers: [{ provide: NG_VALIDATORS, useExisting: MinValidatorDirective_1, multi: true }],
            exportAs: 'min',
        })
    ], MinValidatorDirective);
    return MinValidatorDirective;
}());

var MinModule = /** @class */ (function () {
    function MinModule() {
    }
    MinModule = __decorate([
        NgModule({
            declarations: [MinValidatorDirective],
            imports: [CommonModule],
            exports: [MinValidatorDirective],
        })
    ], MinModule);
    return MinModule;
}());

var MASK_FLAGS = ['C', '&', 'a', 'A', '?', 'L', '9', '0', '#'];
var KEYS = {
    Ctrl: 17,
    Z: 90,
    Y: 89,
    X: 88,
    BACKSPACE: 8,
    DELETE: 46,
};
var MaskHelper = /** @class */ (function () {
    function MaskHelper() {
    }
    Object.defineProperty(MaskHelper.prototype, "cursor", {
        get: function () {
            return this.cursorPrivate;
        },
        enumerable: true,
        configurable: true
    });
    MaskHelper.prototype.parseValueByMask = function (value, maskOptions, cursor) {
        var inputValue = value;
        var mask = maskOptions.format;
        var literals = this.getMaskLiterals(mask);
        var literalKeys = Array.from(literals.keys());
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (inputValue.length < mask.length) {
            // BACKSPACE, DELETE
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (nonLiteralIndeces.indexOf(cursor + 1) !== -1) {
                inputValue = this.insertCharAt(inputValue, cursor + 1, maskOptions.promptChar);
                this.cursorPrivate = cursor + 1;
            }
            else {
                inputValue = this.insertCharAt(inputValue, cursor + 1, mask[cursor + 1]);
                this.cursorPrivate = cursor + 1;
                for (var i = this.cursorPrivate; i < 0; i--) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate--;
                    }
                    else {
                        break;
                    }
                }
            }
        }
        else {
            var char = inputValue[cursor];
            var isCharValid = this.validateCharOnPostion(char, cursor, mask);
            if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                if (isCharValid) {
                    inputValue = this.replaceCharAt(inputValue, cursor, char);
                    this.cursorPrivate = cursor + 1;
                }
                else {
                    this.cursorPrivate = cursor;
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                this.cursorPrivate = ++cursor;
                for (var i = cursor; i < mask.length; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate = ++cursor;
                    }
                    else {
                        isCharValid = this.validateCharOnPostion(char, cursor, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, cursor, char);
                            this.cursorPrivate = ++cursor;
                            break;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }
        return inputValue;
    };
    MaskHelper.prototype.parseMask = function (maskOptions) {
        var e_1, _a;
        var _this = this;
        var outputVal = '';
        var mask = maskOptions.format;
        var literals = this.getMaskLiterals(mask);
        try {
            for (var mask_1 = __values(mask), mask_1_1 = mask_1.next(); !mask_1_1.done; mask_1_1 = mask_1.next()) {
                var maskSym = mask_1_1.value;
                outputVal += maskOptions.promptChar;
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (mask_1_1 && !mask_1_1.done && (_a = mask_1.return)) _a.call(mask_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        literals.forEach(function (val, key) {
            outputVal = _this.replaceCharAt(outputVal, key, val);
        });
        return outputVal;
    };
    MaskHelper.prototype.parseValueByMaskOnInit = function (inputVal, maskOptions) {
        var e_2, _a, e_3, _b;
        var _this = this;
        var outputVal = '';
        var value = '';
        var mask = maskOptions.format;
        var literals = this.getMaskLiterals(mask);
        var literalKeys = Array.from(literals.keys());
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        var literalValues = Array.from(literals.values());
        if (inputVal != null) {
            value = inputVal.toString();
        }
        try {
            for (var mask_2 = __values(mask), mask_2_1 = mask_2.next(); !mask_2_1.done; mask_2_1 = mask_2.next()) {
                var maskSym = mask_2_1.value;
                outputVal += maskOptions.promptChar;
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (mask_2_1 && !mask_2_1.done && (_a = mask_2.return)) _a.call(mask_2);
            }
            finally { if (e_2) throw e_2.error; }
        }
        literals.forEach(function (val, key) {
            outputVal = _this.replaceCharAt(outputVal, key, val);
        });
        if (!value) {
            return outputVal;
        }
        var nonLiteralValues = this.getNonLiteralValues(value, literalValues);
        for (var i = 0; i < nonLiteralValues.length; i++) {
            var char = nonLiteralValues[i];
            var isCharValid = this.validateCharOnPostion(char, nonLiteralIndeces[i], mask);
            if (!isCharValid && char !== maskOptions.promptChar) {
                nonLiteralValues[i] = maskOptions.promptChar;
            }
        }
        if (nonLiteralValues.length > nonLiteralIndeces.length) {
            nonLiteralValues.splice(nonLiteralIndeces.length);
        }
        var pos = 0;
        try {
            for (var nonLiteralValues_1 = __values(nonLiteralValues), nonLiteralValues_1_1 = nonLiteralValues_1.next(); !nonLiteralValues_1_1.done; nonLiteralValues_1_1 = nonLiteralValues_1.next()) {
                var nonLiteralValue = nonLiteralValues_1_1.value;
                var char = nonLiteralValue;
                outputVal = this.replaceCharAt(outputVal, nonLiteralIndeces[pos++], char);
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (nonLiteralValues_1_1 && !nonLiteralValues_1_1.done && (_b = nonLiteralValues_1.return)) _b.call(nonLiteralValues_1);
            }
            finally { if (e_3) throw e_3.error; }
        }
        return outputVal;
    };
    MaskHelper.prototype.restoreValueFromMask = function (value, maskOptions) {
        var e_4, _a;
        var outputVal = '';
        var mask = maskOptions.format;
        var literals = this.getMaskLiterals(mask);
        var literalValues = Array.from(literals.values());
        try {
            for (var value_1 = __values(value), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
                var val = value_1_1.value;
                if (literalValues.indexOf(val) === -1) {
                    if (val !== maskOptions.promptChar) {
                        outputVal += val;
                    }
                }
            }
        }
        catch (e_4_1) { e_4 = { error: e_4_1 }; }
        finally {
            try {
                if (value_1_1 && !value_1_1.done && (_a = value_1.return)) _a.call(value_1);
            }
            finally { if (e_4) throw e_4.error; }
        }
        return outputVal;
    };
    MaskHelper.prototype.parseValueByMaskUponSelection = function (value, maskOptions, cursor, selection) {
        var isCharValid;
        var inputValue = value;
        var char = inputValue[cursor];
        var mask = maskOptions.format;
        var literals = this.getMaskLiterals(mask);
        var literalKeys = Array.from(literals.keys());
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (!this.data) {
            this.cursorPrivate = cursor < 0 ? ++cursor : cursor;
            if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                inputValue = isCharValid
                    ? this.replaceCharAt(inputValue, this.cursorPrivate++, char)
                    : (inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar));
                selection--;
                if (selection > 0) {
                    for (var i = 0; i < selection; i++) {
                        cursor++;
                        inputValue =
                            nonLiteralIndeces.indexOf(cursor) !== -1
                                ? this.insertCharAt(inputValue, cursor, maskOptions.promptChar)
                                : this.insertCharAt(inputValue, cursor, mask[cursor]);
                    }
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, this.cursorPrivate, mask[this.cursorPrivate]);
                this.cursorPrivate++;
                selection--;
                var isMarked = false;
                if (selection > 0) {
                    cursor = this.cursorPrivate;
                    for (var i = 0; i < selection; i++) {
                        if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                            isCharValid = this.validateCharOnPostion(char, cursor, mask);
                            if (isCharValid && !isMarked) {
                                inputValue = this.insertCharAt(inputValue, cursor, char);
                                cursor++;
                                this.cursorPrivate++;
                                isMarked = true;
                            }
                            else {
                                inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                                cursor++;
                            }
                        }
                        else {
                            inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                            if (cursor === this.cursorPrivate) {
                                this.cursorPrivate++;
                            }
                            cursor++;
                        }
                    }
                }
            }
        }
        else {
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (this.cursorPrivate < 0) {
                this.cursorPrivate++;
                cursor++;
            }
            cursor++;
            this.cursorPrivate = cursor;
            for (var i = 0; i < selection; i++) {
                if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                    inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                    cursor++;
                }
                else {
                    inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                    cursor++;
                }
            }
        }
        return inputValue;
    };
    MaskHelper.prototype.parseValueByMaskUponCopyPaste = function (value, maskOptions, cursor, clipboardData, selection) {
        var e_5, _a;
        var inputValue = value;
        var mask = maskOptions.format;
        var literals = this.getMaskLiterals(mask);
        var literalKeys = Array.from(literals.keys());
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        var selectionEnd = cursor + selection;
        this.cursorPrivate = cursor;
        try {
            for (var clipboardData_1 = __values(clipboardData), clipboardData_1_1 = clipboardData_1.next(); !clipboardData_1_1.done; clipboardData_1_1 = clipboardData_1.next()) {
                var clipboardSym = clipboardData_1_1.value;
                var char = clipboardSym;
                if (this.cursorPrivate > mask.length) {
                    return inputValue;
                }
                if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                    var isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                    if (isCharValid) {
                        inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                    }
                }
                else {
                    for (var i = cursor; i < mask.length; i++) {
                        if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                            this.cursorPrivate++;
                        }
                        else {
                            var isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                            if (isCharValid) {
                                inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                            }
                            break;
                        }
                    }
                }
                selection--;
            }
        }
        catch (e_5_1) { e_5 = { error: e_5_1 }; }
        finally {
            try {
                if (clipboardData_1_1 && !clipboardData_1_1.done && (_a = clipboardData_1.return)) _a.call(clipboardData_1);
            }
            finally { if (e_5) throw e_5.error; }
        }
        if (selection > 0) {
            for (var i = this.cursorPrivate; i < selectionEnd; i++) {
                if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                    this.cursorPrivate++;
                }
                else {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                }
            }
        }
        return inputValue;
    };
    MaskHelper.prototype.validateCharOnPostion = function (inputChar, position, mask) {
        var regex;
        var isValid;
        var letterOrDigitRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        var letterDigitOrSpaceRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        var letterRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        var letteSpaceRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        var digitRegEx = '[\\d]';
        var digitSpaceRegEx = '[\\d\\u0020]';
        var digitSpecialRegEx = '[\\d-\\+]';
        switch (mask.charAt(position)) {
            case 'C':
                isValid = inputChar !== '';
                break;
            case '&':
                regex = new RegExp('[\\u0020]');
                isValid = !regex.test(inputChar);
                break;
            case 'a':
                regex = new RegExp(letterDigitOrSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'A':
                regex = new RegExp(letterOrDigitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '?':
                regex = new RegExp(letteSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'L':
                regex = new RegExp(letterRegEx);
                isValid = regex.test(inputChar);
                break;
            case '0':
                regex = new RegExp(digitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '9':
                regex = new RegExp(digitSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case '#':
                regex = new RegExp(digitSpecialRegEx);
                isValid = regex.test(inputChar);
                break;
            default: {
                isValid = null;
            }
        }
        return isValid;
    };
    MaskHelper.prototype.replaceCharAt = function (strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index + 1);
        }
    };
    MaskHelper.prototype.insertCharAt = function (strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index);
        }
    };
    MaskHelper.prototype.getMaskLiterals = function (mask) {
        var literals = new Map();
        for (var i = 0; i < mask.length; i++) {
            var char = mask.charAt(i);
            if (MASK_FLAGS.indexOf(char) === -1) {
                literals.set(i, char);
            }
        }
        return literals;
    };
    MaskHelper.prototype.getNonLiteralIndeces = function (mask, literalKeys) {
        var nonLiteralsIndeces = new Array();
        for (var i = 0; i < mask.length; i++) {
            if (literalKeys.indexOf(i) === -1) {
                nonLiteralsIndeces.push(i);
            }
        }
        return nonLiteralsIndeces;
    };
    MaskHelper.prototype.getNonLiteralValues = function (value, literalValues) {
        var e_6, _a;
        var nonLiteralValues = new Array();
        try {
            for (var value_2 = __values(value), value_2_1 = value_2.next(); !value_2_1.done; value_2_1 = value_2.next()) {
                var val = value_2_1.value;
                if (literalValues.indexOf(val) === -1) {
                    nonLiteralValues.push(val);
                }
            }
        }
        catch (e_6_1) { e_6 = { error: e_6_1 }; }
        finally {
            try {
                if (value_2_1 && !value_2_1.done && (_a = value_2.return)) _a.call(value_2);
            }
            finally { if (e_6) throw e_6.error; }
        }
        return nonLiteralValues;
    };
    return MaskHelper;
}());

function isIE() {
    return navigator.appVersion.indexOf('Trident/') > 0;
}
var noop = function () { };
var ɵ0 = noop;
var MaskDirective = /** @class */ (function () {
    function MaskDirective(elementRef) {
        this.elementRef = elementRef;
        this.valueChange = new EventEmitter();
        this.maskOptions = {
            format: '',
            promptChar: '',
        };
        this.onTouchedCallback = noop;
        this.onChangeCallback = noop;
        this.maskHelper = new MaskHelper();
    }
    MaskDirective_1 = MaskDirective;
    Object.defineProperty(MaskDirective.prototype, "value", {
        get: function () {
            return this.nativeElement.value;
        },
        set: function (val) {
            this.nativeElement.value = val;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MaskDirective.prototype, "nativeElement", {
        get: function () {
            return this.elementRef.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MaskDirective.prototype, "selectionStart", {
        get: function () {
            return this.nativeElement.selectionStart;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MaskDirective.prototype, "selectionEnd", {
        get: function () {
            return this.nativeElement.selectionEnd;
        },
        enumerable: true,
        configurable: true
    });
    MaskDirective.prototype.ngOnInit = function () {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar = this.promptChar.substring(0, 1);
        }
        this.maskOptions.format = this.mask ? this.mask : 'CCCCCCCCCC';
        this.maskOptions.promptChar = this.promptChar ? this.promptChar : '_';
        this.nativeElement.setAttribute('placeholder', this.placeholder ? this.placeholder : this.maskOptions.format);
    };
    MaskDirective.prototype.onKeydown = function (event) {
        var key = event.keyCode || event.charCode;
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
        }
        if (key === KEYS.Ctrl) {
            this.ctrlDown = true;
        }
        if ((this.ctrlDown && key === KEYS.Z) || (this.ctrlDown && key === KEYS.Y)) {
            event.preventDefault();
        }
        this.key = key;
        this.selection = Math.abs(this.selectionEnd - this.selectionStart);
    };
    MaskDirective.prototype.onKeyup = function (event) {
        var key = event.keyCode || event.charCode;
        if (key === KEYS.Ctrl) {
            this.ctrlDown = false;
        }
    };
    MaskDirective.prototype.onPaste = function (event) {
        this.paste = true;
        this.valOnPaste = this.value;
        this.cursorOnPaste = this.getCursorPosition();
    };
    MaskDirective.prototype.onInputChanged = function (event) {
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
            return;
        }
        if (this.paste) {
            this.paste = false;
            var clipboardData = this.value.substring(this.cursorOnPaste, this.getCursorPosition());
            this.value = this.maskHelper.parseValueByMaskUponCopyPaste(this.valOnPaste, this.maskOptions, this.cursorOnPaste, clipboardData, this.selection);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        else {
            var currentCursorPos = this.getCursorPosition();
            this.maskHelper.data = this.key === KEYS.BACKSPACE || this.key === KEYS.DELETE;
            this.value =
                this.selection && this.selection !== 0
                    ? this.maskHelper.parseValueByMaskUponSelection(this.value, this.maskOptions, currentCursorPos - 1, this.selection)
                    : this.maskHelper.parseValueByMask(this.value, this.maskOptions, currentCursorPos - 1);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        var rawVal = this.maskHelper.restoreValueFromMask(this.value, this.maskOptions);
        this.dataValue = this.includeLiterals ? this.value : rawVal;
        this.onChangeCallback(this.dataValue);
        this.valueChange.emit({ rawValue: rawVal, formattedValue: this.value });
    };
    MaskDirective.prototype.onFocus = function (value) {
        if (this.focusedValuePipe) {
            if (isIE()) {
                this.stopPropagation = true;
            }
            this.value = this.focusedValuePipe.transform(value);
        }
        else {
            this.value = this.maskHelper.parseValueByMaskOnInit(this.value, this.maskOptions);
        }
    };
    MaskDirective.prototype.onBlur = function (value) {
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(value);
        }
        else if (value === this.maskHelper.parseMask(this.maskOptions)) {
            this.value = '';
        }
    };
    MaskDirective.prototype.getCursorPosition = function () {
        return this.nativeElement.selectionStart;
    };
    MaskDirective.prototype.setCursorPosition = function (start, end) {
        if (end === void 0) { end = start; }
        this.nativeElement.setSelectionRange(start, end);
    };
    MaskDirective.prototype.writeValue = function (value) {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar.substring(0, 1);
        }
        this.value = value ? this.maskHelper.parseValueByMaskOnInit(value, this.maskOptions) : '';
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(this.value);
        }
        this.dataValue = this.includeLiterals ? this.value : value;
        this.onChangeCallback(this.dataValue);
        this.valueChange.emit({ rawValue: value, formattedValue: this.value });
    };
    MaskDirective.prototype.registerOnChange = function (fn) {
        this.onChangeCallback = fn;
    };
    MaskDirective.prototype.registerOnTouched = function (fn) {
        this.onTouchedCallback = fn;
    };
    var MaskDirective_1;
    MaskDirective.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    __decorate([
        Input('ngxMask'),
        __metadata("design:type", String)
    ], MaskDirective.prototype, "mask", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], MaskDirective.prototype, "promptChar", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], MaskDirective.prototype, "includeLiterals", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], MaskDirective.prototype, "placeholder", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], MaskDirective.prototype, "displayValuePipe", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], MaskDirective.prototype, "focusedValuePipe", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], MaskDirective.prototype, "dataValue", void 0);
    __decorate([
        Output(),
        __metadata("design:type", Object)
    ], MaskDirective.prototype, "valueChange", void 0);
    __decorate([
        HostListener('keydown', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], MaskDirective.prototype, "onKeydown", null);
    __decorate([
        HostListener('keyup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], MaskDirective.prototype, "onKeyup", null);
    __decorate([
        HostListener('paste', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], MaskDirective.prototype, "onPaste", null);
    __decorate([
        HostListener('input', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], MaskDirective.prototype, "onInputChanged", null);
    __decorate([
        HostListener('focus', ['$event.target.value']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], MaskDirective.prototype, "onFocus", null);
    __decorate([
        HostListener('blur', ['$event.target.value']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], MaskDirective.prototype, "onBlur", null);
    MaskDirective = MaskDirective_1 = __decorate([
        Directive({
            providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: MaskDirective_1, multi: true }],
            selector: '[ngxMask]',
        }),
        __metadata("design:paramtypes", [ElementRef])
    ], MaskDirective);
    return MaskDirective;
}());

var MaskModule = /** @class */ (function () {
    function MaskModule() {
    }
    MaskModule = __decorate([
        NgModule({
            declarations: [MaskDirective],
            imports: [CommonModule],
            exports: [MaskDirective],
        })
    ], MaskModule);
    return MaskModule;
}());

var FilterPipe = /** @class */ (function () {
    function FilterPipe() {
    }
    FilterPipe.prototype.transform = function (itemList, filterTerm, filterBy) {
        if (!filterBy) {
            return itemList;
        }
        if (filterTerm === '') {
            return itemList;
        }
        filterBy = filterBy.toString();
        return itemList.filter(function (item) {
            if (item[filterBy]) {
                return item[filterBy]
                    .toString()
                    .toLowerCase()
                    .includes(filterTerm.toLowerCase());
            }
        });
    };
    FilterPipe = __decorate([
        Pipe({ name: 'filter' })
    ], FilterPipe);
    return FilterPipe;
}());

/**
 * <ul>
 *   <li *ngFor="let object of myArray | groupBy:'color'"></li>
 * </ul>
 */
var GroupByPipe = /** @class */ (function () {
    function GroupByPipe() {
    }
    GroupByPipe.prototype.transform = function (collection, property) {
        // prevents the application from breaking if the array of objects doesn't exist yet
        if (!collection) {
            return null;
        }
        var groupedCollection = collection.reduce(function (previous, current) {
            if (!previous[current[property]]) {
                previous[current[property]] = [current];
            }
            else {
                previous[current[property]].push(current);
            }
            return previous;
        }, {});
        // this will return an array of objects, each object containing a group of objects
        return Object.keys(groupedCollection).map(function (key) { return ({
            key: key,
            value: groupedCollection[key],
        }); });
    };
    GroupByPipe = __decorate([
        Pipe({ name: 'groupBy' })
    ], GroupByPipe);
    return GroupByPipe;
}());

var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (value, args) {
        return this.sanitizer.bypassSecurityTrustHtml(value);
    };
    SafeHtmlPipe.ctorParameters = function () { return [
        { type: DomSanitizer }
    ]; };
    SafeHtmlPipe = __decorate([
        Pipe({ name: 'safeHtml' }),
        __metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());

var HelperModule = /** @class */ (function () {
    function HelperModule() {
    }
    HelperModule = __decorate([
        NgModule({
            imports: [CommonModule],
            declarations: [FilterPipe, GroupByPipe, SafeHtmlPipe],
            exports: [FilterPipe, GroupByPipe, SafeHtmlPipe],
        })
    ], HelperModule);
    return HelperModule;
}());

var CharactersPipe = /** @class */ (function () {
    function CharactersPipe() {
    }
    CharactersPipe.prototype.transform = function (value, limit, trail) {
        if (limit === void 0) { limit = 40; }
        if (trail === void 0) { trail = '…'; }
        if (!value) {
            value = '';
        }
        if (limit < 0) {
            limit *= -1;
            return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
        }
        else {
            return value.length > limit ? value.substring(0, limit) + trail : value;
        }
    };
    CharactersPipe = __decorate([
        Pipe({
            pure: true,
            name: 'characters',
        })
    ], CharactersPipe);
    return CharactersPipe;
}());

var WordsPipe = /** @class */ (function () {
    function WordsPipe() {
    }
    WordsPipe.prototype.transform = function (value, limit, trail) {
        if (limit === void 0) { limit = 40; }
        if (trail === void 0) { trail = '…'; }
        var result = value || '';
        if (value) {
            var words = value.split(/\s+/);
            if (words.length > Math.abs(limit)) {
                if (limit < 0) {
                    limit *= -1;
                    result = trail + words.slice(words.length - limit, words.length).join(' ');
                }
                else {
                    result = words.slice(0, limit).join(' ') + trail;
                }
            }
        }
        return result;
    };
    WordsPipe = __decorate([
        Pipe({
            pure: true,
            name: 'words',
        })
    ], WordsPipe);
    return WordsPipe;
}());

var TruncateModule = /** @class */ (function () {
    function TruncateModule() {
    }
    TruncateModule = __decorate([
        NgModule({
            imports: [CommonModule],
            declarations: [CharactersPipe, WordsPipe],
            exports: [CharactersPipe, WordsPipe],
        })
    ], TruncateModule);
    return TruncateModule;
}());

var defaultConfig = { addSuffix: true };
/**
 * impure pipe, which in general can lead to bad performance
 * but the backoff function limits the frequency the pipe checks for updates
 * so the performance is close to that of a pure pipe
 * the downside of this is that if you change the value of the input, the pipe might not notice for a while
 * so this pipe is intended for static data
 *
 * expected input is a time (number, string or Date)
 * output is a string expressing distance from that time to now, plus the suffix 'ago'
 * output refreshes at dynamic intervals, with refresh rate slowing down as the input time gets further away from now
 */
var FormatTimeInWordsPipe = /** @class */ (function () {
    function FormatTimeInWordsPipe(cdr) {
        this.cdr = cdr;
        this.isDestroyed = false;
        this.async = new AsyncPipe(this.cdr);
    }
    FormatTimeInWordsPipe_1 = FormatTimeInWordsPipe;
    FormatTimeInWordsPipe.prototype.ngOnDestroy = function () {
        this.isDestroyed = true; // pipe will stop executing after next iteration
    };
    FormatTimeInWordsPipe.prototype.transform = function (date, options) {
        if (date == null) {
            throw new Error(FormatTimeInWordsPipe_1.NO_ARGS_ERROR);
        }
        // set the pipe to the Observable if not yet done, and return an async pipe
        if (!this.agoExpression) {
            this.agoExpression = this.timeAgo(date, __assign({}, defaultConfig, options));
        }
        return this.async.transform(this.agoExpression);
    };
    FormatTimeInWordsPipe.prototype.timeAgo = function (date, options) {
        var _this = this;
        var nextBackoff = this.backoff(date);
        return of(true).pipe(
        // will not recheck input until delay completes
        repeatWhen(function (notify) { return notify.pipe(delayWhen(function () { return interval(nextBackoff); })); }), takeWhile(function (_) { return !_this.isDestroyed; }), map(function (_) { return formatDistance(_this.stringToDate(date), new Date(), options); }), tap(function (_) { return (nextBackoff = _this.backoff(date)); }));
    };
    FormatTimeInWordsPipe.prototype.backoff = function (date) {
        var minutesElapsed = Math.abs(differenceInMinutes(new Date(), this.stringToDate(date))); // this will always be positive
        var backoffAmountInSeconds;
        if (minutesElapsed < 2) {
            backoffAmountInSeconds = 5;
        }
        else if (minutesElapsed >= 2 && minutesElapsed < 5) {
            backoffAmountInSeconds = 15;
        }
        else if (minutesElapsed >= 5 && minutesElapsed < 60) {
            backoffAmountInSeconds = 30;
        }
        else if (minutesElapsed >= 60) {
            backoffAmountInSeconds = 300; // 5 minutes
        }
        return backoffAmountInSeconds * 1000; // return an amount of milliseconds
    };
    FormatTimeInWordsPipe.prototype.stringToDate = function (date) {
        function isString(x) {
            return Object.prototype.toString.call(x) === '[object String]';
        }
        return isString(date) ? parseISO(date) : date;
    };
    var FormatTimeInWordsPipe_1;
    FormatTimeInWordsPipe.NO_ARGS_ERROR = 'formatTimeInWords: missing required arguments';
    FormatTimeInWordsPipe.ctorParameters = function () { return [
        { type: ChangeDetectorRef }
    ]; };
    FormatTimeInWordsPipe = FormatTimeInWordsPipe_1 = __decorate([
        Pipe({ name: 'formatTimeInWords', pure: false }),
        __metadata("design:paramtypes", [ChangeDetectorRef])
    ], FormatTimeInWordsPipe);
    return FormatTimeInWordsPipe;
}());

var PIPES = [FormatTimeInWordsPipe];
var DateFnsModule = /** @class */ (function () {
    function DateFnsModule() {
    }
    DateFnsModule = __decorate([
        NgModule({
            declarations: [PIPES],
            imports: [CommonModule],
            exports: [PIPES],
        })
    ], DateFnsModule);
    return DateFnsModule;
}());

// export * from './lib/decorators/index';

/**
 * Generated bundle index. Do not edit.
 */

export { ClickOutsideModule, DateFnsModule, HelperModule, InViewportModule, MaskModule, MinModule, NgLetModule, RouterLinkMatchModule, TruncateModule, ViewportService, pluck, untilDestroy, NgLetContext as ɵa, NgLetDirective as ɵb, RouterLinkMatchDirective as ɵc, InViewportDirective as ɵd, destroy$ as ɵdestroy$, ClickOutsideDirective as ɵe, MinValidatorDirective as ɵf, MaskDirective as ɵg, FilterPipe as ɵh, GroupByPipe as ɵi, SafeHtmlPipe as ɵj, CharactersPipe as ɵk, WordsPipe as ɵl, FormatTimeInWordsPipe as ɵm };
//# sourceMappingURL=ngx-starter-kit-ngx-utils.js.map
