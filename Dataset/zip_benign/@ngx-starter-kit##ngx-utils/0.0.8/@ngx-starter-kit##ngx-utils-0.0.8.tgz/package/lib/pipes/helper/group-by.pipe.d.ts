import { PipeTransform } from '@angular/core';
/**
 * <ul>
 *   <li *ngFor="let object of myArray | groupBy:'color'"></li>
 * </ul>
 */
export declare class GroupByPipe<T> implements PipeTransform {
    transform(collection: Array<T>, property: string): Array<{
        key: string;
        value: [T];
    }>;
}
