export declare class DateFnsModule {
}
