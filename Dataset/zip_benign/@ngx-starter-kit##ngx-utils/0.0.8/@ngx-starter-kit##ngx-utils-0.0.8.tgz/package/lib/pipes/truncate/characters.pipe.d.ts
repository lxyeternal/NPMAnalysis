import { PipeTransform } from '@angular/core';
export declare class CharactersPipe implements PipeTransform {
    transform(value: string, limit?: number, trail?: string): string;
}
