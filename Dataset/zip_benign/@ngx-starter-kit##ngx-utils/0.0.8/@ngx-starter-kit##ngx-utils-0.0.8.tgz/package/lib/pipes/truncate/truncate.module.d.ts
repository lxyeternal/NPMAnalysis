export declare class TruncateModule {
}
