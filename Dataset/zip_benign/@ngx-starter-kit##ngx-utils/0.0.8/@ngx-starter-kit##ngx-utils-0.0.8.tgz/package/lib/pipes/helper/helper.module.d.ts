export declare class HelperModule {
}
