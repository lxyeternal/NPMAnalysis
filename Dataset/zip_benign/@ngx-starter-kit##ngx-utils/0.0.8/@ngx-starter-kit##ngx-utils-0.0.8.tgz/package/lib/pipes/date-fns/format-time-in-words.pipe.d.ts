import { ChangeDetectorRef, OnDestroy, PipeTransform } from '@angular/core';
/**
 * impure pipe, which in general can lead to bad performance
 * but the backoff function limits the frequency the pipe checks for updates
 * so the performance is close to that of a pure pipe
 * the downside of this is that if you change the value of the input, the pipe might not notice for a while
 * so this pipe is intended for static data
 *
 * expected input is a time (number, string or Date)
 * output is a string expressing distance from that time to now, plus the suffix 'ago'
 * output refreshes at dynamic intervals, with refresh rate slowing down as the input time gets further away from now
 */
export declare class FormatTimeInWordsPipe implements PipeTransform, OnDestroy {
    private cdr;
    static readonly NO_ARGS_ERROR = "formatTimeInWords: missing required arguments";
    private readonly async;
    private isDestroyed;
    private agoExpression;
    constructor(cdr: ChangeDetectorRef);
    ngOnDestroy(): void;
    transform(date: string | number | Date, options?: any): string;
    private timeAgo;
    private backoff;
    private stringToDate;
}
