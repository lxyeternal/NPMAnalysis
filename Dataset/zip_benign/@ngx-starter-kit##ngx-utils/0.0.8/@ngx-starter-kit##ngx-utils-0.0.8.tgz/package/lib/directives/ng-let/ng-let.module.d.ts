export declare class NgLetModule {
}
