export declare class ClickOutsideModule {
}
