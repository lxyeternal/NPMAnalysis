export declare class RouterLinkMatchModule {
}
