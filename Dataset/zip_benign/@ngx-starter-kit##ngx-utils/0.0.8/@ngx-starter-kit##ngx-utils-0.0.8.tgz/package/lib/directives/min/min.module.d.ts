export declare class MinModule {
}
