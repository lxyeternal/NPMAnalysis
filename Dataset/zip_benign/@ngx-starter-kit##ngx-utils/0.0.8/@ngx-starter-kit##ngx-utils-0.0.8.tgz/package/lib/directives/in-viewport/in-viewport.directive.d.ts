import { ElementRef, EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { ViewportService } from './viewport.service';
export declare class InViewportDirective implements OnInit, OnDestroy {
    private readonly elementRef;
    private viewportService;
    private platformId;
    preRender: boolean;
    oneTime: boolean;
    readonly inViewport: EventEmitter<Partial<IntersectionObserverEntry>>;
    constructor(elementRef: ElementRef, viewportService: ViewportService, platformId: Object);
    ngOnInit(): void;
    ngOnDestroy(): void;
}
