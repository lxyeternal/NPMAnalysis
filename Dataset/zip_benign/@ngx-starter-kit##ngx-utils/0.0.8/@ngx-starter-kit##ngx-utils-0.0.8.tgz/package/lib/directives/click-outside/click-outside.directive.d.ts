import { ElementRef, EventEmitter } from '@angular/core';
export declare class ClickOutsideDirective {
    private elementRef;
    ngxClickOutside: EventEmitter<MouseEvent>;
    constructor(elementRef: ElementRef);
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
}
