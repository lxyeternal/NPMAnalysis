export declare class InViewportModule {
}
