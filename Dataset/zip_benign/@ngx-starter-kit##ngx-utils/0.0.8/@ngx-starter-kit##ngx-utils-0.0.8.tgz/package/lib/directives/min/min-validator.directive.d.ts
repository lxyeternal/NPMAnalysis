import { AbstractControl, Validator } from '@angular/forms';
export declare class MinValidatorDirective implements Validator {
    min: number;
    validate(control: AbstractControl): {
        [key: string]: any;
    };
}
