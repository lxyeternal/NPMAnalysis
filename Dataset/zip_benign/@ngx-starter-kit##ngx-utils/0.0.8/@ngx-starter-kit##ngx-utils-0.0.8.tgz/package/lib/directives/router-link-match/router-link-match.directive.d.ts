import { ElementRef, OnChanges, OnDestroy, Renderer2, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
export interface MatchExp {
    [classes: string]: string;
}
export declare class RouterLinkMatchDirective implements OnDestroy, OnChanges {
    private renderer;
    private ngEl;
    private curRoute;
    private matchExp;
    private onChangesHook;
    routerLinkMatch: MatchExp;
    constructor(router: Router, renderer: Renderer2, ngEl: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    private _updateClass;
    private _toggleClass;
    ngOnDestroy(): void;
}
