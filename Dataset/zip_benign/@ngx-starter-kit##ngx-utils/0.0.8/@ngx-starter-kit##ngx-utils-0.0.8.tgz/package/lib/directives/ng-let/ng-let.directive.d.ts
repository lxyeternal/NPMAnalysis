import { TemplateRef, ViewContainerRef, OnInit } from '@angular/core';
export declare class NgLetContext {
    $implicit: any;
    ngLet: any;
}
export declare class NgLetDirective implements OnInit {
    private vcr;
    private templateRef;
    private context;
    ngLet: any;
    constructor(vcr: ViewContainerRef, templateRef: TemplateRef<NgLetContext>);
    ngOnInit(): void;
}
