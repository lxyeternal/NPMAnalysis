export declare class MaskModule {
}
