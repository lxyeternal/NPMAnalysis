import Matrix from '../entities/Matrix';
import { dataTypes } from '../types';
interface ArithmeticProps {
    fixed?: number;
}
interface GenerateMatrixProps {
    x: number;
    y: number;
    fixed?: number;
    dataType?: dataTypes;
    scala: {
        max: number;
        min: number;
    };
}
export default abstract class MatrixProcess {
    /**
    * It provides subtraction and summation for matrix args
    * @param process 'sub' | 'sum'
    */
    private static process;
    static constArithmeticProcess(matrix: Matrix, num: number, process: "mul" | "div" | "sub" | "sum", fixed?: number): Matrix;
    static multiply(matrixFirst: Matrix, matrixSecond: Matrix, options?: ArithmeticProps): Matrix;
    static sum(matrixFirst: Matrix, matrixSecond: Matrix, options?: ArithmeticProps): Matrix;
    static sub(matrixFirst: Matrix, matrixSecond: Matrix, options?: ArithmeticProps): Matrix;
    /**
     *
     * @param options
     * @returns Matrix
     */
    static generateMatrix(options: GenerateMatrixProps): Matrix;
    static eye(y: number, x: number): Matrix;
    static fill(x: number, y: number, number: number): Matrix;
    static ifso(matrix: Matrix, queryFunc: (value: number) => boolean, doFunc: (value: number) => number, doFalseFunc?: (value: number) => number): Matrix;
}
export {};
