import { dataTypes } from "../types";
import MatrixProcess from "../utils/MatrixProcess";
interface IMatrix {
    transpose(): Matrix;
}
interface Filter {
    rows?: {
        start?: number;
        end?: number;
    };
    cols?: {
        start?: number;
        end?: number;
    };
}
declare class Matrix extends MatrixProcess implements IMatrix {
    private matrix;
    private dataType;
    private x;
    private y;
    private typedMatrix;
    constructor(matrix: number[][], dataType?: dataTypes);
    set(x: number, y: number, number: number): void;
    convertNumberToDataType(number: number, dataType: dataTypes): number;
    /**
   * You can convert but lose the matrices' numbers
   */
    convertDataType(dataType: dataTypes): number[][] | undefined;
    transpose(): Matrix;
    ravel(): Matrix;
    getX(): number;
    getY(): number;
    get type(): string;
    clone(): number[][];
    write(options?: Filter): void;
    filter(options?: Filter): Matrix;
}
export default Matrix;
