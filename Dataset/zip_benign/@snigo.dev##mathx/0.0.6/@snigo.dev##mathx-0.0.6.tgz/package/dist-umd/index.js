(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = global || self, factory(global.manifest = {}));
}(this, (function (exports) { 'use strict';

  function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
  }

  function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
  }

  function _iterableToArrayLimit(arr, i) {
    if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = undefined;

    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);

        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && _i["return"] != null) _i["return"]();
      } finally {
        if (_d) throw _e;
      }
    }

    return _arr;
  }

  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }

  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;

    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

    return arr2;
  }

  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  /**
   * Calculates precision of number
   *
   * @param {number} number Number to be checked
   *
   * @returns {number} Precision of the number
   */
  function precision(number) {
    var _n = +number;

    if (Number.isNaN(_n)) return NaN;
    var sciRe = /^[+-]?\d+(?:\.(\d+))?e([+-]?\d+)$/;
    var numRe = /^[+-]?\d+(?:\.(\d+))?$/;
    var zerosRe = /^[+-]?\d+?(0+)$/;

    var _s = _n.toString();

    if (zerosRe.test(_s)) {
      var _s$match;

      var group = (_s$match = _s.match(zerosRe)) === null || _s$match === void 0 ? void 0 : _s$match[1];
      return group ? -group.length : 0;
    }

    if (numRe.test(_s)) {
      var _s$match2;

      var _group = (_s$match2 = _s.match(numRe)) === null || _s$match2 === void 0 ? void 0 : _s$match2[1];

      return _group ? _group.length : 0;
    }

    if (sciRe.test(_s)) {
      var _Array$from = Array.from(_s.match(sciRe) || []),
          _Array$from2 = _slicedToArray(_Array$from, 3),
          _Array$from2$ = _Array$from2[1],
          numGroup = _Array$from2$ === void 0 ? '' : _Array$from2$,
          _Array$from2$2 = _Array$from2[2],
          expGroup = _Array$from2$2 === void 0 ? 0 : _Array$from2$2;

      return numGroup.length - +expGroup;
    }

    return 0;
  }

  /* eslint-disable no-redeclare */

  /* eslint-disable no-unused-vars */
  function __incString(s, amount) {
    return String(+s > Number.MAX_SAFE_INTEGER ? BigInt(s) + BigInt(amount) : +s + amount);
  }

  function __padNumber(n, p) {
    if (p >= 0) return n;

    var _str = String(n);

    var _neg = _str.startsWith('-');

    var _dlen = _str.length - +_neg;

    var _sign = +!_neg || -1;

    var _up = +_str[_str.length + p] > 4 + +_neg;

    var _slice = _str.slice(+_neg, p);

    var _padded = (_neg ? '-' : '') + __incString(_slice, +_up * _sign).padEnd(_dlen, '0');

    return typeof n === 'bigint' ? BigInt(_padded) : Number(_padded);
  }

  function __absZero(z) {
    return z === 0 && !Math.sign(z) ? 0 : z;
  }

  function round(num) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 12;
    if (precision < -100 || precision > 100) throw RangeError('Precision value should be in -100..100 range.');
    if (typeof num === 'bigint') return precision < 0 ? __padNumber(num, precision) : num;
    var f1 = Math.pow(10, precision);
    var f2 = Math.pow(10, Math.sign(precision));
    var product = Math.round(num * (f1 * f2) / f2);
    return precision > 0 ? __absZero(product / f1) : __absZero(Math.round(product / f1));
  }

  /**
   * Checks if the first argument approximately equals
   * to the second argument within delta
   *
   * @param {number} a Number to be checked
   * @param {number} b Number to be checked
   * @param {number} delta Acceptable difference between a and b
   *
   * @returns {boolean} True or False
   */

  function approx(a, b) {
    var delta = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

    var _p = Math.max(precision(a), precision(b), precision(delta));

    return round(+Math.abs(a - b), _p) <= delta;
  }

  /**
   * Calculates modulo in the correct way including negative numbers.
   * Fixes so called JavaScript modulo bug:
   * https://web.archive.org/web/20090717035140if_/javascript.about.com/od/problemsolving/a/modulobug.htm
   *
   * @param {number} a Left operand
   * @param {number} b Right operand
   *
   * @returns {number} Modulo of a mod b
   */
  function mod(a, b) {
    return (+a % +b + +b) % +b;
  }

  /**
   * Converts string or number to a certain precision
   * NOTE! This function will not coerce values to number, so
   * ```
   * num(false) => NaN
   * num(null) => NaN
   * ```
   *
   * @param {string | number} numberLike Number to be converted
   * @param {number} precision Precision, the number to be rounded to
   */

  function num(numberLike) {
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 12;
    if (numberLike == null || Array.isArray(numberLike)) return NaN;

    var _s = numberLike.toString();

    var _n = /%$/.test(_s) ? +_s.slice(0, -1) / 100 : +_s;

    return precision !== undefined ? round(_n, precision) : _n;
  }

  /**
   * Generates random number within range with certain precision
   *
   * @param {number[]} range Array of min and max values of the range
   * @param {number} precision Precision, the generated number to be rounded to
   */

  function random() {
    var range = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [0, 1];
    var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 12;

    var _range = _slicedToArray(range, 2),
        min = _range[0],
        max = _range[1];

    return round(min + Math.random() * (max - min), precision);
  }

  exports.approx = approx;
  exports.mod = mod;
  exports.num = num;
  exports.precision = precision;
  exports.random = random;
  exports.round = round;

  Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=index.js.map
