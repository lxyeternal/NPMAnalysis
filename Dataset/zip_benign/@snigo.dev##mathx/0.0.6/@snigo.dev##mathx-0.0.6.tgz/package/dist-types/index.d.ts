/**
 * Checks if the first argument approximately equals
 * to the second argument within delta
 *
 * @param {number} a Number to be checked
 * @param {number} b Number to be checked
 * @param {number} delta Acceptable difference between a and b
 *
 * @returns {boolean} True or False
 */
declare function approx(a: number, b: number, delta?: number): boolean;

/**
 * Calculates modulo in the correct way including negative numbers.
 * Fixes so called JavaScript modulo bug:
 * https://web.archive.org/web/20090717035140if_/javascript.about.com/od/problemsolving/a/modulobug.htm
 *
 * @param {number} a Left operand
 * @param {number} b Right operand
 *
 * @returns {number} Modulo of a mod b
 */
declare function mod(a: number, b: number): number;

/**
 * Converts string or number to a certain precision
 * NOTE! This function will not coerce values to number, so
 * ```
 * num(false) => NaN
 * num(null) => NaN
 * ```
 *
 * @param {string | number} numberLike Number to be converted
 * @param {number} precision Precision, the number to be rounded to
 */
declare function num(numberLike: any, precision?: number): number;

/**
 * Calculates precision of number
 *
 * @param {number} number Number to be checked
 *
 * @returns {number} Precision of the number
 */
declare function precision(number: number): number;

/**
 * Generates random number within range with certain precision
 *
 * @param {number[]} range Array of min and max values of the range
 * @param {number} precision Precision, the generated number to be rounded to
 */
declare function random(range?: [number, number], precision?: number): number;

/**
 * Rounds number to a certain precision.
 * Negative precision will work as well:
 * ```
 * round(1234, -2) => 1200
 * ```
 *
 * @param {number} num Number to be rounded
 * @param {number} precision Precision, the number to be rounded to
 *
 * @returns {number} Rounded number
 */
declare function round(num: number, precision?: number): number;
declare function round(num: bigint, precision?: number): bigint;

export { approx, mod, num, precision, random, round };
