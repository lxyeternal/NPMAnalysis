"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cyclicGradient = exports.gradient = exports.cyclicUniform = exports.uniform = exports.resetToken = exports.colourFGToken = exports.colourBGToken = void 0;
/** generates the token used in a console message to colour the background */
function colourBGToken(colour) {
    return `\u001B[48;2;${colour.r_8b};${colour.g_8b};${colour.b_8b}m`;
}
exports.colourBGToken = colourBGToken;
/** generates the token used in a console message to colour the message text */
function colourFGToken(colour) {
    return `\u001B[38;2;${colour.r_8b};${colour.g_8b};${colour.b_8b}m`;
}
exports.colourFGToken = colourFGToken;
/** constant for resetting the console colour */
exports.resetToken = "\x1b[0m";
/** calculates the number of characters within the given string that may be coloured */
function getColourableCount(text) {
    let colourableCount = 0;
    for (let i = 0; i < text.length; i++) {
        if (text[i] == '\u001B') {
            do {
                i++;
            } while (text[i] != 'm');
            i++;
        }
        colourableCount++;
    }
    return colourableCount;
}
/** colour a given string of text a given colour */
function uniform(text, colour, isBg = false) {
    text = text.replace(exports.resetToken, "");
    return (isBg ? colourBGToken(colour) : colourFGToken(colour)) + text + exports.resetToken;
}
exports.uniform = uniform;
/** colour a given string a given sequence of colours in a cyclical order */
function cyclicUniform(text, segmentLength, isBg = false, ...colours) {
    text = text.replace(exports.resetToken, "");
    let result = "";
    let c = 0;
    let getToken = isBg ? colourBGToken : colourFGToken;
    for (let i = 0; i < text.length; i++) {
        // skip characters used for recolouring
        if (text[i] == '\u001B') {
            do {
                result += text[i];
                i++;
            } while (text[i] != 'm');
            result += text[i];
            i++;
        }
        result += getToken(colours[Math.floor(c / segmentLength) % colours.length]) + text[i];
        c++;
    }
    return result + exports.resetToken;
}
exports.cyclicUniform = cyclicUniform;
/** colour a given string according to a given gradient */
function gradient(text, gradient, isBg = false) {
    text = text.replace(exports.resetToken, "");
    let colourableCount = getColourableCount(text);
    let result = "";
    let t = 0;
    // we walk through the message, skipping any already existing colour modifiers
    for (let i = 0; i < text.length; i++) {
        if (text[i] == '\u001B') {
            do {
                result += text[i];
                i++;
            } while (text[i] != 'm');
            result += text[i];
            i++;
        }
        // generate the colour using the functions we got in the arguments
        const colour = gradient.getAt(t / colourableCount);
        // add the current character coloured with the colour we created earlier
        result += isBg ? colourBGToken(colour) : colourFGToken(colour);
        result += text[i];
        t++;
    }
    return result + exports.resetToken;
}
exports.gradient = gradient;
/** colour a given string a given sequence of gradients in a cyclical order */
function cyclicGradient(text, segmentLength, isBg = false, ...gradients) {
    text = text.replace(exports.resetToken, "");
    let result = "";
    let c = 0;
    let getToken = isBg ? colourBGToken : colourFGToken;
    for (let i = 0; i < text.length; i++) {
        // skip characters used for recolouring
        if (text[i] == '\u001B') {
            do {
                result += text[i];
                i++;
            } while (text[i] != 'm');
            result += text[i];
            i++;
        }
        let prop = c / segmentLength;
        let index = Math.floor(prop) % gradients.length;
        let t = prop % 1;
        result += getToken(gradients[index].getAt(t)) + text[i];
        c++;
    }
    return result + exports.resetToken;
}
exports.cyclicGradient = cyclicGradient;
//# sourceMappingURL=console.js.map