"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ColorSpace = exports.Color = void 0;
const mathExt_1 = require("./mathExt");
class Color extends Object {
    _r;
    _g;
    _b;
    _a;
    /** class representing a digital presentable color */
    constructor(r, g, b, a = 1) {
        super();
        this._r = Math.min(Math.max(r, 0), 1);
        this._g = Math.min(Math.max(g, 0), 1);
        this._b = Math.min(Math.max(b, 0), 1);
        this._a = Math.min(Math.max(a, 0), 1);
    }
    /** export this color into RGB format */
    toRGB() {
        return [this._r, this._g, this._b];
    }
    /** export this color into RGBA format */
    toRGBA() {
        return [this._r, this._g, this._b, this._a];
    }
    /** export this color into 24-bit RGB */
    to24BitRGB() {
        return [this.r_8b, this.g_8b, this.b_8b];
    }
    /** export this color into 32-bit RGBA */
    to32BitRGBA() {
        return [this.r_8b, this.g_8b, this.b_8b, this.a_8b];
    }
    /** export this color into HSV format */
    toHSV() {
        return [this.hue, this.saturation_V, this.value];
    }
    /** export this color into HSL format */
    toHSL() {
        return [this.hue, this.saturation_L, this.lightness];
    }
    /** export this color into HSI format */
    toHSI() {
        return [this.hue, this.saturation_I, this.intensity];
    }
    toString() {
        return `Color(r: ${this.red}, g: ${this.green}, b: ${this.blue})`;
    }
    /** the red component of this color in RGB format */
    get red() {
        return this._r;
    }
    set red(r) {
        this._r = Math.min(Math.max(r, 0), 1);
    }
    /** the green component of this color in RGB format */
    get green() {
        return this._g;
    }
    set green(g) {
        this._g = Math.min(Math.max(g, 0), 1);
    }
    /** the blue component of this color in RGB format */
    get blue() {
        return this._b;
    }
    set blue(b) {
        this._b = Math.min(Math.max(b, 0), 1);
    }
    /** the alpha channel of this color */
    get alpha() {
        return this._a;
    }
    set alpha(a) {
        this._a = Math.min(Math.max(a, 0), 1);
    }
    get r_8b() { return Math.floor(this._r * 0xFF); }
    get g_8b() { return Math.floor(this._g * 0xFF); }
    get b_8b() { return Math.floor(this._b * 0xFF); }
    get a_8b() { return Math.floor(this._a * 0xFF); }
    /** the chroma of this color */
    get chroma() {
        return Math.max(this._r, this._g, this._b) - Math.min(this._r, this._g, this._b);
    }
    set chroma(c) {
        if (c < 0)
            c = 0;
        let i = this.intensity;
        let oc = this.chroma;
        this._r = (this._r - i) * c / oc + i;
        this._g = (this._g - i) * c / oc + i;
        this._b = (this._b - i) * c / oc + i;
    }
    /** the hue of this color */
    get hue() {
        if (this.chroma == 0)
            return 0;
        let hprime;
        switch (Math.max(this._r, this._g, this._b)) {
            case this._r:
                hprime = ((this._g - this._b) / this.chroma + 6) % 6;
                break;
            case this._g:
                hprime = (this._b - this._r) / this.chroma + 2;
                break;
            case this._b:
                hprime = (this._r - this._g) / this.chroma + 4;
                break;
            default:
                hprime = 0;
                break;
        }
        return hprime / 6;
    }
    set hue(h) {
        let replacements = Color.fromHSV(h, this.saturation_V, this.value);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the brightness of this color in HSI format */
    get intensity() {
        return (0, mathExt_1.avg)(this._r, this._g, this._b);
    }
    set intensity(i) {
        let replacements = Color.fromHSI(this.hue, this.saturation_I, i);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the brightness of this color in HSV format */
    get value() {
        return Math.max(this._r, this._g, this._b);
    }
    set value(v) {
        let replacements = Color.fromHSV(this.hue, this.saturation_V, v);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the brightness of this color in HSL format */
    get lightness() {
        return (0, mathExt_1.mid)(this._r, this._g, this._b);
    }
    set lightness(l) {
        let replacements = Color.fromHSL(this.hue, this.saturation_L, l);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the saturation of this color in HSV format */
    get saturation_V() {
        return this.value == 0 ? 0 : this.chroma / this.value;
    }
    set saturation_V(s) {
        let replacements = Color.fromHSV(this.hue, s, this.value);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the saturation of this color in HSL format */
    get saturation_L() {
        return this.lightness % 1 == 0 ? 0 : this.chroma / (1 - Math.abs(2 * this.lightness - 1));
    }
    set saturation_L(s) {
        let replacements = Color.fromHSL(this.hue, s, this.lightness);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the saturation of this color in HSI format */
    get saturation_I() {
        return this.intensity == 0 ? 0 : 1 - Math.min(this._r, this._g, this._b) / this.intensity;
    }
    set saturation_I(s) {
        let replacements = Color.fromHSI(this.hue, s, this.intensity);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    //#region defaults
    static ALICEBLUE = Color.fromHex("#F0F8FF");
    static ANTIQUEWHITE = Color.fromHex("#FAEBD7");
    static AQUA = Color.fromHex("#00FFFF");
    static AQUAMARINE = Color.fromHex("#7FFFD4");
    static AZURE = Color.fromHex("#F0FFFF");
    static BEIGE = Color.fromHex("#F5F5DC");
    static BISQUE = Color.fromHex("#FFE4C4");
    static BLACK = Color.fromHex("#000000");
    static BLANCHEDALMOND = Color.fromHex("#FFEBCD");
    static BLUE = Color.fromHex("#0000FF");
    static BLUEVIOLET = Color.fromHex("#8A2BE2");
    static BROWN = Color.fromHex("#A52A2A");
    static BURLYWOOD = Color.fromHex("#DEB887");
    static CADETBLUE = Color.fromHex("#5F9EA0");
    static CHARTREUSE = Color.fromHex("#7FFF00");
    static CHOCOLATE = Color.fromHex("#D2691E");
    static CORAL = Color.fromHex("#FF7F50");
    static CORNFLOWERBLUE = Color.fromHex("#6495ED");
    static CORNSILK = Color.fromHex("#FFF8DC");
    static CRIMSON = Color.fromHex("#DC143C");
    static CYAN = Color.fromHex("#00FFFF");
    static DARKBLUE = Color.fromHex("#00008B");
    static DARKCYAN = Color.fromHex("#008B8B");
    static DARKGOLDENROD = Color.fromHex("#B8860B");
    static DARKGRAY = Color.fromHex("#A9A9A9");
    static DARKGREY = Color.fromHex("#A9A9A9");
    static DARKGREEN = Color.fromHex("#006400");
    static DARKKHAKI = Color.fromHex("#BDB76B");
    static DARKMAGENTA = Color.fromHex("#8B008B");
    static DARKOLIVEGREEN = Color.fromHex("#556B2F");
    static DARKORANGE = Color.fromHex("#FF8C00");
    static DARKORCHID = Color.fromHex("#9932CC");
    static DARKRED = Color.fromHex("#8B0000");
    static DARKSALMON = Color.fromHex("#E9967A");
    static DARKSEAGREEN = Color.fromHex("#8FBC8F");
    static DARKSLATEBLUE = Color.fromHex("#483D8B");
    static DARKSLATEGRAY = Color.fromHex("#2F4F4F");
    static DARKSLATEGREY = Color.fromHex("#2F4F4F");
    static DARKTURQUOISE = Color.fromHex("#00CED1");
    static DARKVIOLET = Color.fromHex("#9400D3");
    static DEEPPINK = Color.fromHex("#FF1493");
    static DEEPSKYBLUE = Color.fromHex("#00BFFF");
    static DIMGRAY = Color.fromHex("#696969");
    static DIMGREY = Color.fromHex("#696969");
    static DODGERBLUE = Color.fromHex("#1E90FF");
    static FIREBRICK = Color.fromHex("#B22222");
    static FLORALWHITE = Color.fromHex("#FFFAF0");
    static FORESTGREEN = Color.fromHex("#228B22");
    static FUCHSIA = Color.fromHex("#FF00FF");
    static GAINSBORO = Color.fromHex("#DCDCDC");
    static GHOSTWHITE = Color.fromHex("#F8F8FF");
    static GOLD = Color.fromHex("#FFD700");
    static GOLDENROD = Color.fromHex("#DAA520");
    static GRAY = Color.fromHex("#808080");
    static GREY = Color.fromHex("#808080");
    static GREEN = Color.fromHex("#008000");
    static GREENYELLOW = Color.fromHex("#ADFF2F");
    static HONEYDEW = Color.fromHex("#F0FFF0");
    static HOTPINK = Color.fromHex("#FF69B4");
    static INDIANRED = Color.fromHex("#CD5C5C");
    static INDIGO = Color.fromHex("#4B0082");
    static IVORY = Color.fromHex("#FFFFF0");
    static KHAKI = Color.fromHex("#F0E68C");
    static LAVENDER = Color.fromHex("#E6E6FA");
    static LAVENDERBLUSH = Color.fromHex("#FFF0F5");
    static LAWNGREEN = Color.fromHex("#7CFC00");
    static LEMONCHIFFON = Color.fromHex("#FFFACD");
    static LIGHTBLUE = Color.fromHex("#ADD8E6");
    static LIGHTCORAL = Color.fromHex("#F08080");
    static LIGHTCYAN = Color.fromHex("#E0FFFF");
    static LIGHTGOLDENRODYELLOW = Color.fromHex("#FAFAD2");
    static LIGHTGRAY = Color.fromHex("#D3D3D3");
    static LIGHTGREY = Color.fromHex("#D3D3D3");
    static LIGHTGREEN = Color.fromHex("#90EE90");
    static LIGHTPINK = Color.fromHex("#FFB6C1");
    static LIGHTSALMON = Color.fromHex("#FFA07A");
    static LIGHTSEAGREEN = Color.fromHex("#20B2AA");
    static LIGHTSKYBLUE = Color.fromHex("#87CEFA");
    static LIGHTSLATEGRAY = Color.fromHex("#778899");
    static LIGHTSLATEGREY = Color.fromHex("#778899");
    static LIGHTSTEELBLUE = Color.fromHex("#B0C4DE");
    static LIGHTYELLOW = Color.fromHex("#FFFFE0");
    static LIME = Color.fromHex("#00FF00");
    static LIMEGREEN = Color.fromHex("#32CD32");
    static LINEN = Color.fromHex("#FAF0E6");
    static MAGENTA = Color.fromHex("#FF00FF");
    static MAROON = Color.fromHex("#800000");
    static MEDIUMAQUAMARINE = Color.fromHex("#66CDAA");
    static MEDIUMBLUE = Color.fromHex("#0000CD");
    static MEDIUMORCHID = Color.fromHex("#BA55D3");
    static MEDIUMPURPLE = Color.fromHex("#9370DB");
    static MEDIUMSEAGREEN = Color.fromHex("#3CB371");
    static MEDIUMSLATEBLUE = Color.fromHex("#7B68EE");
    static MEDIUMSPRINGGREEN = Color.fromHex("#00FA9A");
    static MEDIUMTURQUOISE = Color.fromHex("#48D1CC");
    static MEDIUMVIOLETRED = Color.fromHex("#C71585");
    static MIDNIGHTBLUE = Color.fromHex("#191970");
    static MINTCREAM = Color.fromHex("#F5FFFA");
    static MISTYROSE = Color.fromHex("#FFE4E1");
    static MOCCASIN = Color.fromHex("#FFE4B5");
    static NAVAJOWHITE = Color.fromHex("#FFDEAD");
    static NAVY = Color.fromHex("#000080");
    static OLDLACE = Color.fromHex("#FDF5E6");
    static OLIVE = Color.fromHex("#808000");
    static OLIVEDRAB = Color.fromHex("#6B8E23");
    static ORANGE = Color.fromHex("#FFA500");
    static ORANGERED = Color.fromHex("#FF4500");
    static ORCHID = Color.fromHex("#DA70D6");
    static PALEGOLDENROD = Color.fromHex("#EEE8AA");
    static PALEGREEN = Color.fromHex("#98FB98");
    static PALETURQUOISE = Color.fromHex("#AFEEEE");
    static PALEVIOLETRED = Color.fromHex("#DB7093");
    static PAPAYAWHIP = Color.fromHex("#FFEFD5");
    static PEACHPUFF = Color.fromHex("#FFDAB9");
    static PERU = Color.fromHex("#CD853F");
    static PINK = Color.fromHex("#FFC0CB");
    static PLUM = Color.fromHex("#DDA0DD");
    static POWDERBLUE = Color.fromHex("#B0E0E6");
    static PURPLE = Color.fromHex("#800080");
    static REBECCAPURPLE = Color.fromHex("#663399");
    static RED = Color.fromHex("#FF0000");
    static ROSYBROWN = Color.fromHex("#BC8F8F");
    static ROYALBLUE = Color.fromHex("#4169E1");
    static SADDLEBROWN = Color.fromHex("#8B4513");
    static SALMON = Color.fromHex("#FA8072");
    static SANDYBROWN = Color.fromHex("#F4A460");
    static SEAGREEN = Color.fromHex("#2E8B57");
    static SEASHELL = Color.fromHex("#FFF5EE");
    static SIENNA = Color.fromHex("#A0522D");
    static SILVER = Color.fromHex("#C0C0C0");
    static SKYBLUE = Color.fromHex("#87CEEB");
    static SLATEBLUE = Color.fromHex("#6A5ACD");
    static SLATEGRAY = Color.fromHex("#708090");
    static SLATEGREY = Color.fromHex("#708090");
    static SNOW = Color.fromHex("#FFFAFA");
    static SPRINGGREEN = Color.fromHex("#00FF7F");
    static STEELBLUE = Color.fromHex("#4682B4");
    static TAN = Color.fromHex("#D2B48C");
    static TEAL = Color.fromHex("#008080");
    static THISTLE = Color.fromHex("#D8BFD8");
    static TOMATO = Color.fromHex("#FF6347");
    static TURQUOISE = Color.fromHex("#40E0D0");
    static VIOLET = Color.fromHex("#EE82EE");
    static WHEAT = Color.fromHex("#F5DEB3");
    static WHITE = Color.fromHex("#FFFFFF");
    static WHITESMOKE = Color.fromHex("#F5F5F5");
    static YELLOW = Color.fromHex("#FFFF00");
    static YELLOWGREEN = Color.fromHex("#9ACD32");
    //#endregion
    /** create a color from a corresponding hex value */
    static fromHex(hex) {
        // remove any leading formatting characters
        hex = hex.replace("#", "").replace("0x", "");
        const colorValue = Number.parseInt(hex, 16);
        let r;
        let g;
        let b;
        switch (hex.length) {
            // 8-bit color
            case 2:
                r = (colorValue & 0b1110_0000) / 0b1110_0000;
                g = (colorValue & 0b0001_1100) / 0b0001_1100;
                b = (colorValue & 0b0000_0011) / 0b0000_0011;
                break;
            // 12-bit color
            case 3:
                r = (colorValue & 0xF00) / 0xF00;
                g = (colorValue & 0x0F0) / 0x0F0;
                b = (colorValue & 0x00F) / 0x00F;
                break;
            // 16-bit color
            case 4:
                r = (colorValue & 0xF800) / 0xF800;
                g = (colorValue & 0x07E0) / 0x07E0;
                b = (colorValue & 0x001F) / 0x001F;
                break;
            // 24-bit color
            case 6:
                r = (colorValue & 0xFF_00_00) / 0xFF_00_00;
                g = (colorValue & 0x00_FF_00) / 0x00_FF_00;
                b = (colorValue & 0x00_00_FF) / 0x00_00_FF;
                break;
            // 36-bit color
            case 9:
                r = (colorValue & 0xFFF_000_000) / 0xFFF_000_000;
                g = (colorValue & 0x000_FFF_000) / 0x000_FFF_000;
                b = (colorValue & 0x000_000_FFF) / 0x000_000_FFF;
                break;
            // 48-bit color
            case 12:
                r = (colorValue & 0xFFFF_0000_0000) / 0xFFFF_0000_0000;
                g = (colorValue & 0x0000_FFFF_0000) / 0x0000_FFFF_0000;
                b = (colorValue & 0x0000_0000_FFFF) / 0x0000_0000_FFFF;
                break;
            default:
                throw new Error("Invalid color format");
        }
        return new Color(r, g, b);
    }
    /** create a color from HSV format */
    static fromHSV(hue, saturation, value, alpha = 1) {
        const chroma = value * saturation;
        const scaledHue = hue * 6;
        // integer to isolate the 6 separate cases for hue
        const hueRegion = Math.floor(scaledHue);
        // intermediate value for second largest component
        const X = chroma * (1 - Math.abs(scaledHue % 2 - 1));
        // constant to add to all colour components
        const m = value - chroma;
        return Color.fromCXM(hueRegion, chroma, X, m, alpha);
    }
    /** create a color from HSL format */
    static fromHSL(hue, saturation, lightness, alpha = 1) {
        const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation;
        const scaledHue = hue * 6;
        // integer to isolate the 6 separate cases for hue
        const hueRegion = Math.floor(scaledHue);
        // intermediate value for second largest component
        const X = chroma * (1 - Math.abs(scaledHue % 2 - 1));
        // constant to add to all colour components
        const m = lightness - chroma * 0.5;
        return Color.fromCXM(hueRegion, chroma, X, m, alpha);
    }
    /** create a color from HSI format */
    static fromHSI(hue, saturation, intensity, alpha = 1) {
        const scaledHue = hue * 6;
        // integer to isolate the 6 separate cases for hue
        const hueRegion = Math.floor(scaledHue);
        const Z = 1 - Math.abs(scaledHue % 2 - 1);
        const chroma = 3 * intensity * saturation / (1 + Z);
        // intermediate value for second largest component
        const X = chroma * Z;
        // constant to add to all colour components
        const m = intensity * (1 - saturation);
        return Color.fromCXM(hueRegion, chroma, X, m, alpha);
    }
    static fromCXM(hueRegion, chroma, X, m, alpha) {
        switch (hueRegion) {
            case 0: // red to yellow
                return new Color(chroma + m, X + m, m, alpha);
            case 1: // yellow to green
                return new Color(X + m, chroma + m, m, alpha);
            case 2: // green to cyan
                return new Color(m, chroma + m, X + m, alpha);
            case 3: // cyan to blue
                return new Color(m, X + m, chroma + m, alpha);
            case 4: // blue to magenta
                return new Color(X + m, m, chroma + m, alpha);
            case 5: // magenta to red
                return new Color(chroma + m, m, X + m, alpha);
            default:
                return Color.BLACK;
        }
    }
}
exports.Color = Color;
/** the available color spaces supported by the library */
var ColorSpace;
(function (ColorSpace) {
    ColorSpace[ColorSpace["RGB"] = 0] = "RGB";
    ColorSpace[ColorSpace["HSV"] = 1] = "HSV";
    ColorSpace[ColorSpace["HSL"] = 2] = "HSL";
    ColorSpace[ColorSpace["HSI"] = 3] = "HSI";
})(ColorSpace = exports.ColorSpace || (exports.ColorSpace = {}));
//# sourceMappingURL=color.js.map