export declare class Colour extends Object {
    private _r;
    private _g;
    private _b;
    private _a;
    /** class representing a digital presentable colour */
    constructor(r: number | bigint, g: number | bigint, b: number | bigint, a?: number | bigint);
    /** export this colour into RGB format */
    toRGB(): number[];
    /** export this colour into RGBA format */
    toRGBA(): number[];
    /** export this colour into 24-bit RGB */
    to24BitRGB(): number[];
    /** export this colour into 32-bit RGBA */
    to32BitRGBA(): number[];
    /** export this colour into HSV format */
    toHSV(): number[];
    /** export this colour into HSL format */
    toHSL(): number[];
    /** export this colour into HSI format */
    toHSI(): number[];
    toString(): string;
    /** the red component of this colour in RGB format */
    get red(): number;
    set red(r: number);
    /** the green component of this colour in RGB format */
    get green(): number;
    set green(g: number);
    /** the blue component of this colour in RGB format */
    get blue(): number;
    set blue(b: number);
    /** the alpha channel of this colour */
    get alpha(): number;
    set alpha(a: number);
    get r_8b(): number;
    get g_8b(): number;
    get b_8b(): number;
    get a_8b(): number;
    /** the chroma of this colour */
    get chroma(): number;
    set chroma(c: number);
    /** the hue of this colour */
    get hue(): number;
    set hue(h: number);
    /** the brightness of this colour in HSI format */
    get intensity(): number;
    set intensity(i: number);
    /** the brightness of this colour in HSV format */
    get value(): number;
    set value(v: number);
    /** the brightness of this colour in HSL format */
    get lightness(): number;
    set lightness(l: number);
    /** the saturation of this colour in HSV format */
    get saturation_V(): number;
    set saturation_V(s: number);
    /** the saturation of this colour in HSL format */
    get saturation_L(): number;
    set saturation_L(s: number);
    /** the saturation of this colour in HSI format */
    get saturation_I(): number;
    set saturation_I(s: number);
    static readonly ALICEBLUE: Colour;
    static readonly ANTIQUEWHITE: Colour;
    static readonly AQUA: Colour;
    static readonly AQUAMARINE: Colour;
    static readonly AZURE: Colour;
    static readonly BEIGE: Colour;
    static readonly BISQUE: Colour;
    static readonly BLACK: Colour;
    static readonly BLANCHEDALMOND: Colour;
    static readonly BLUE: Colour;
    static readonly BLUEVIOLET: Colour;
    static readonly BROWN: Colour;
    static readonly BURLYWOOD: Colour;
    static readonly CADETBLUE: Colour;
    static readonly CHARTREUSE: Colour;
    static readonly CHOCOLATE: Colour;
    static readonly CORAL: Colour;
    static readonly CORNFLOWERBLUE: Colour;
    static readonly CORNSILK: Colour;
    static readonly CRIMSON: Colour;
    static readonly CYAN: Colour;
    static readonly DARKBLUE: Colour;
    static readonly DARKCYAN: Colour;
    static readonly DARKGOLDENROD: Colour;
    static readonly DARKGRAY: Colour;
    static readonly DARKGREY: Colour;
    static readonly DARKGREEN: Colour;
    static readonly DARKKHAKI: Colour;
    static readonly DARKMAGENTA: Colour;
    static readonly DARKOLIVEGREEN: Colour;
    static readonly DARKORANGE: Colour;
    static readonly DARKORCHID: Colour;
    static readonly DARKRED: Colour;
    static readonly DARKSALMON: Colour;
    static readonly DARKSEAGREEN: Colour;
    static readonly DARKSLATEBLUE: Colour;
    static readonly DARKSLATEGRAY: Colour;
    static readonly DARKSLATEGREY: Colour;
    static readonly DARKTURQUOISE: Colour;
    static readonly DARKVIOLET: Colour;
    static readonly DEEPPINK: Colour;
    static readonly DEEPSKYBLUE: Colour;
    static readonly DIMGRAY: Colour;
    static readonly DIMGREY: Colour;
    static readonly DODGERBLUE: Colour;
    static readonly FIREBRICK: Colour;
    static readonly FLORALWHITE: Colour;
    static readonly FORESTGREEN: Colour;
    static readonly FUCHSIA: Colour;
    static readonly GAINSBORO: Colour;
    static readonly GHOSTWHITE: Colour;
    static readonly GOLD: Colour;
    static readonly GOLDENROD: Colour;
    static readonly GRAY: Colour;
    static readonly GREY: Colour;
    static readonly GREEN: Colour;
    static readonly GREENYELLOW: Colour;
    static readonly HONEYDEW: Colour;
    static readonly HOTPINK: Colour;
    static readonly INDIANRED: Colour;
    static readonly INDIGO: Colour;
    static readonly IVORY: Colour;
    static readonly KHAKI: Colour;
    static readonly LAVENDER: Colour;
    static readonly LAVENDERBLUSH: Colour;
    static readonly LAWNGREEN: Colour;
    static readonly LEMONCHIFFON: Colour;
    static readonly LIGHTBLUE: Colour;
    static readonly LIGHTCORAL: Colour;
    static readonly LIGHTCYAN: Colour;
    static readonly LIGHTGOLDENRODYELLOW: Colour;
    static readonly LIGHTGRAY: Colour;
    static readonly LIGHTGREY: Colour;
    static readonly LIGHTGREEN: Colour;
    static readonly LIGHTPINK: Colour;
    static readonly LIGHTSALMON: Colour;
    static readonly LIGHTSEAGREEN: Colour;
    static readonly LIGHTSKYBLUE: Colour;
    static readonly LIGHTSLATEGRAY: Colour;
    static readonly LIGHTSLATEGREY: Colour;
    static readonly LIGHTSTEELBLUE: Colour;
    static readonly LIGHTYELLOW: Colour;
    static readonly LIME: Colour;
    static readonly LIMEGREEN: Colour;
    static readonly LINEN: Colour;
    static readonly MAGENTA: Colour;
    static readonly MAROON: Colour;
    static readonly MEDIUMAQUAMARINE: Colour;
    static readonly MEDIUMBLUE: Colour;
    static readonly MEDIUMORCHID: Colour;
    static readonly MEDIUMPURPLE: Colour;
    static readonly MEDIUMSEAGREEN: Colour;
    static readonly MEDIUMSLATEBLUE: Colour;
    static readonly MEDIUMSPRINGGREEN: Colour;
    static readonly MEDIUMTURQUOISE: Colour;
    static readonly MEDIUMVIOLETRED: Colour;
    static readonly MIDNIGHTBLUE: Colour;
    static readonly MINTCREAM: Colour;
    static readonly MISTYROSE: Colour;
    static readonly MOCCASIN: Colour;
    static readonly NAVAJOWHITE: Colour;
    static readonly NAVY: Colour;
    static readonly OLDLACE: Colour;
    static readonly OLIVE: Colour;
    static readonly OLIVEDRAB: Colour;
    static readonly ORANGE: Colour;
    static readonly ORANGERED: Colour;
    static readonly ORCHID: Colour;
    static readonly PALEGOLDENROD: Colour;
    static readonly PALEGREEN: Colour;
    static readonly PALETURQUOISE: Colour;
    static readonly PALEVIOLETRED: Colour;
    static readonly PAPAYAWHIP: Colour;
    static readonly PEACHPUFF: Colour;
    static readonly PERU: Colour;
    static readonly PINK: Colour;
    static readonly PLUM: Colour;
    static readonly POWDERBLUE: Colour;
    static readonly PURPLE: Colour;
    static readonly REBECCAPURPLE: Colour;
    static readonly RED: Colour;
    static readonly ROSYBROWN: Colour;
    static readonly ROYALBLUE: Colour;
    static readonly SADDLEBROWN: Colour;
    static readonly SALMON: Colour;
    static readonly SANDYBROWN: Colour;
    static readonly SEAGREEN: Colour;
    static readonly SEASHELL: Colour;
    static readonly SIENNA: Colour;
    static readonly SILVER: Colour;
    static readonly SKYBLUE: Colour;
    static readonly SLATEBLUE: Colour;
    static readonly SLATEGRAY: Colour;
    static readonly SLATEGREY: Colour;
    static readonly SNOW: Colour;
    static readonly SPRINGGREEN: Colour;
    static readonly STEELBLUE: Colour;
    static readonly TAN: Colour;
    static readonly TEAL: Colour;
    static readonly THISTLE: Colour;
    static readonly TOMATO: Colour;
    static readonly TURQUOISE: Colour;
    static readonly VIOLET: Colour;
    static readonly WHEAT: Colour;
    static readonly WHITE: Colour;
    static readonly WHITESMOKE: Colour;
    static readonly YELLOW: Colour;
    static readonly YELLOWGREEN: Colour;
    /** create a colour from a corresponding hex value */
    static fromHex(hex: string): Colour;
    /** create a colour from HSV format */
    static fromHSV(hue: number, saturation: number, value: number, alpha?: number): Colour;
    /** create a colour from HSL format */
    static fromHSL(hue: number, saturation: number, lightness: number, alpha?: number): Colour;
    /** create a colour from HSI format */
    static fromHSI(hue: number, saturation: number, intensity: number, alpha?: number): Colour;
    /** create a colour from 24-bit RGB format */
    static from24BitRGB(r: number, g: number, b: number): Colour;
    /** create a colour from 32-bit RGBA format */
    static from32BitRGBA(r: number, g: number, b: number, a?: number): Colour;
    private static fromCXM;
}
export declare class Color extends Colour {
}
/** the available colour spaces supported by the library */
export declare enum ColourSpace {
    RGB = 0,
    HSV = 1,
    HSL = 2,
    HSI = 3
}
export declare const ColorSpace: typeof ColourSpace;
