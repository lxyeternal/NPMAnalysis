import { Colour } from "./colour";
import { Gradient } from "./gradient";
/** generates the token used in a console message to colour the background */
export declare function colourBGToken(colour: Colour): string;
/** generates the token used in a console message to colour the message text */
export declare function colourFGToken(colour: Colour): string;
/** constant for resetting the console colour */
export declare const resetToken = "\u001B[0m";
/** colour a given string of text a given colour */
export declare function uniform(text: string, colour: Colour, isBg?: boolean): string;
/** colour a given string a given sequence of colours in a cyclical order */
export declare function cyclicUniform(text: string, segmentLength: number, isBg?: boolean, ...colours: Colour[]): string;
/** colour a given string according to a given gradient */
export declare function gradient(text: string, gradient: Gradient, isBg?: boolean): string;
/** colour a given string a given sequence of gradients in a cyclical order */
export declare function cyclicGradient(text: string, segmentLength: number, isBg?: boolean, ...gradients: Gradient[]): string;
