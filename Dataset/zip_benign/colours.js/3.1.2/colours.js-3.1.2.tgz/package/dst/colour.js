"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ColorSpace = exports.ColourSpace = exports.Color = exports.Colour = void 0;
const mathExt_1 = require("./mathExt");
class Colour extends Object {
    _r;
    _g;
    _b;
    _a;
    /** class representing a digital presentable colour */
    constructor(r, g, b, a = 1) {
        super();
        this._r = typeof r == "number" ? Math.min(Math.max(r, 0), 1) : Number(r) / 255;
        this._g = typeof g == "number" ? Math.min(Math.max(g, 0), 1) : Number(g) / 255;
        this._b = typeof b == "number" ? Math.min(Math.max(b, 0), 1) : Number(b) / 255;
        this._a = typeof a == "number" ? Math.min(Math.max(a, 0), 1) : Number(a) / 255;
    }
    /** export this colour into RGB format */
    toRGB() {
        return [this._r, this._g, this._b];
    }
    /** export this colour into RGBA format */
    toRGBA() {
        return [this._r, this._g, this._b, this._a];
    }
    /** export this colour into 24-bit RGB */
    to24BitRGB() {
        return [this.r_8b, this.g_8b, this.b_8b];
    }
    /** export this colour into 32-bit RGBA */
    to32BitRGBA() {
        return [this.r_8b, this.g_8b, this.b_8b, this.a_8b];
    }
    /** export this colour into HSV format */
    toHSV() {
        return [this.hue, this.saturation_V, this.value];
    }
    /** export this colour into HSL format */
    toHSL() {
        return [this.hue, this.saturation_L, this.lightness];
    }
    /** export this colour into HSI format */
    toHSI() {
        return [this.hue, this.saturation_I, this.intensity];
    }
    toString() {
        return `Colour(r: ${this.red}, g: ${this.green}, b: ${this.blue})`;
    }
    /** the red component of this colour in RGB format */
    get red() {
        return this._r;
    }
    set red(r) {
        this._r = Math.min(Math.max(r, 0), 1);
    }
    /** the green component of this colour in RGB format */
    get green() {
        return this._g;
    }
    set green(g) {
        this._g = Math.min(Math.max(g, 0), 1);
    }
    /** the blue component of this colour in RGB format */
    get blue() {
        return this._b;
    }
    set blue(b) {
        this._b = Math.min(Math.max(b, 0), 1);
    }
    /** the alpha channel of this colour */
    get alpha() {
        return this._a;
    }
    set alpha(a) {
        this._a = Math.min(Math.max(a, 0), 1);
    }
    get r_8b() { return Math.round(this._r * 0xFF); }
    get g_8b() { return Math.round(this._g * 0xFF); }
    get b_8b() { return Math.round(this._b * 0xFF); }
    get a_8b() { return Math.round(this._a * 0xFF); }
    /** the chroma of this colour */
    get chroma() {
        return Math.max(this._r, this._g, this._b) - Math.min(this._r, this._g, this._b);
    }
    set chroma(c) {
        if (c < 0)
            c = 0;
        let i = this.intensity;
        let oc = this.chroma;
        this._r = (this._r - i) * c / oc + i;
        this._g = (this._g - i) * c / oc + i;
        this._b = (this._b - i) * c / oc + i;
    }
    /** the hue of this colour */
    get hue() {
        if (this.chroma == 0)
            return 0;
        let hprime;
        switch (Math.max(this._r, this._g, this._b)) {
            case this._r:
                hprime = ((this._g - this._b) / this.chroma + 6) % 6;
                break;
            case this._g:
                hprime = (this._b - this._r) / this.chroma + 2;
                break;
            case this._b:
                hprime = (this._r - this._g) / this.chroma + 4;
                break;
            default:
                hprime = 0;
                break;
        }
        return hprime / 6;
    }
    set hue(h) {
        let replacements = Colour.fromHSV(h, this.saturation_V, this.value);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the brightness of this colour in HSI format */
    get intensity() {
        return (0, mathExt_1.avg)(this._r, this._g, this._b);
    }
    set intensity(i) {
        let replacements = Colour.fromHSI(this.hue, this.saturation_I, i);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the brightness of this colour in HSV format */
    get value() {
        return Math.max(this._r, this._g, this._b);
    }
    set value(v) {
        let replacements = Colour.fromHSV(this.hue, this.saturation_V, v);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the brightness of this colour in HSL format */
    get lightness() {
        return (0, mathExt_1.mid)(this._r, this._g, this._b);
    }
    set lightness(l) {
        let replacements = Colour.fromHSL(this.hue, this.saturation_L, l);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the saturation of this colour in HSV format */
    get saturation_V() {
        return this.value == 0 ? 0 : this.chroma / this.value;
    }
    set saturation_V(s) {
        let replacements = Colour.fromHSV(this.hue, s, this.value);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the saturation of this colour in HSL format */
    get saturation_L() {
        return this.lightness % 1 == 0 ? 0 : this.chroma / (1 - Math.abs(2 * this.lightness - 1));
    }
    set saturation_L(s) {
        let replacements = Colour.fromHSL(this.hue, s, this.lightness);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    /** the saturation of this colour in HSI format */
    get saturation_I() {
        return this.intensity == 0 ? 0 : 1 - Math.min(this._r, this._g, this._b) / this.intensity;
    }
    set saturation_I(s) {
        let replacements = Colour.fromHSI(this.hue, s, this.intensity);
        this._r = replacements._r;
        this._g = replacements._g;
        this._b = replacements._b;
    }
    //#region defaults
    static ALICEBLUE = Colour.fromHex("#F0F8FF");
    static ANTIQUEWHITE = Colour.fromHex("#FAEBD7");
    static AQUA = Colour.fromHex("#00FFFF");
    static AQUAMARINE = Colour.fromHex("#7FFFD4");
    static AZURE = Colour.fromHex("#F0FFFF");
    static BEIGE = Colour.fromHex("#F5F5DC");
    static BISQUE = Colour.fromHex("#FFE4C4");
    static BLACK = Colour.fromHex("#000000");
    static BLANCHEDALMOND = Colour.fromHex("#FFEBCD");
    static BLUE = Colour.fromHex("#0000FF");
    static BLUEVIOLET = Colour.fromHex("#8A2BE2");
    static BROWN = Colour.fromHex("#A52A2A");
    static BURLYWOOD = Colour.fromHex("#DEB887");
    static CADETBLUE = Colour.fromHex("#5F9EA0");
    static CHARTREUSE = Colour.fromHex("#7FFF00");
    static CHOCOLATE = Colour.fromHex("#D2691E");
    static CORAL = Colour.fromHex("#FF7F50");
    static CORNFLOWERBLUE = Colour.fromHex("#6495ED");
    static CORNSILK = Colour.fromHex("#FFF8DC");
    static CRIMSON = Colour.fromHex("#DC143C");
    static CYAN = Colour.fromHex("#00FFFF");
    static DARKBLUE = Colour.fromHex("#00008B");
    static DARKCYAN = Colour.fromHex("#008B8B");
    static DARKGOLDENROD = Colour.fromHex("#B8860B");
    static DARKGRAY = Colour.fromHex("#A9A9A9");
    static DARKGREY = Colour.fromHex("#A9A9A9");
    static DARKGREEN = Colour.fromHex("#006400");
    static DARKKHAKI = Colour.fromHex("#BDB76B");
    static DARKMAGENTA = Colour.fromHex("#8B008B");
    static DARKOLIVEGREEN = Colour.fromHex("#556B2F");
    static DARKORANGE = Colour.fromHex("#FF8C00");
    static DARKORCHID = Colour.fromHex("#9932CC");
    static DARKRED = Colour.fromHex("#8B0000");
    static DARKSALMON = Colour.fromHex("#E9967A");
    static DARKSEAGREEN = Colour.fromHex("#8FBC8F");
    static DARKSLATEBLUE = Colour.fromHex("#483D8B");
    static DARKSLATEGRAY = Colour.fromHex("#2F4F4F");
    static DARKSLATEGREY = Colour.fromHex("#2F4F4F");
    static DARKTURQUOISE = Colour.fromHex("#00CED1");
    static DARKVIOLET = Colour.fromHex("#9400D3");
    static DEEPPINK = Colour.fromHex("#FF1493");
    static DEEPSKYBLUE = Colour.fromHex("#00BFFF");
    static DIMGRAY = Colour.fromHex("#696969");
    static DIMGREY = Colour.fromHex("#696969");
    static DODGERBLUE = Colour.fromHex("#1E90FF");
    static FIREBRICK = Colour.fromHex("#B22222");
    static FLORALWHITE = Colour.fromHex("#FFFAF0");
    static FORESTGREEN = Colour.fromHex("#228B22");
    static FUCHSIA = Colour.fromHex("#FF00FF");
    static GAINSBORO = Colour.fromHex("#DCDCDC");
    static GHOSTWHITE = Colour.fromHex("#F8F8FF");
    static GOLD = Colour.fromHex("#FFD700");
    static GOLDENROD = Colour.fromHex("#DAA520");
    static GRAY = Colour.fromHex("#808080");
    static GREY = Colour.fromHex("#808080");
    static GREEN = Colour.fromHex("#008000");
    static GREENYELLOW = Colour.fromHex("#ADFF2F");
    static HONEYDEW = Colour.fromHex("#F0FFF0");
    static HOTPINK = Colour.fromHex("#FF69B4");
    static INDIANRED = Colour.fromHex("#CD5C5C");
    static INDIGO = Colour.fromHex("#4B0082");
    static IVORY = Colour.fromHex("#FFFFF0");
    static KHAKI = Colour.fromHex("#F0E68C");
    static LAVENDER = Colour.fromHex("#E6E6FA");
    static LAVENDERBLUSH = Colour.fromHex("#FFF0F5");
    static LAWNGREEN = Colour.fromHex("#7CFC00");
    static LEMONCHIFFON = Colour.fromHex("#FFFACD");
    static LIGHTBLUE = Colour.fromHex("#ADD8E6");
    static LIGHTCORAL = Colour.fromHex("#F08080");
    static LIGHTCYAN = Colour.fromHex("#E0FFFF");
    static LIGHTGOLDENRODYELLOW = Colour.fromHex("#FAFAD2");
    static LIGHTGRAY = Colour.fromHex("#D3D3D3");
    static LIGHTGREY = Colour.fromHex("#D3D3D3");
    static LIGHTGREEN = Colour.fromHex("#90EE90");
    static LIGHTPINK = Colour.fromHex("#FFB6C1");
    static LIGHTSALMON = Colour.fromHex("#FFA07A");
    static LIGHTSEAGREEN = Colour.fromHex("#20B2AA");
    static LIGHTSKYBLUE = Colour.fromHex("#87CEFA");
    static LIGHTSLATEGRAY = Colour.fromHex("#778899");
    static LIGHTSLATEGREY = Colour.fromHex("#778899");
    static LIGHTSTEELBLUE = Colour.fromHex("#B0C4DE");
    static LIGHTYELLOW = Colour.fromHex("#FFFFE0");
    static LIME = Colour.fromHex("#00FF00");
    static LIMEGREEN = Colour.fromHex("#32CD32");
    static LINEN = Colour.fromHex("#FAF0E6");
    static MAGENTA = Colour.fromHex("#FF00FF");
    static MAROON = Colour.fromHex("#800000");
    static MEDIUMAQUAMARINE = Colour.fromHex("#66CDAA");
    static MEDIUMBLUE = Colour.fromHex("#0000CD");
    static MEDIUMORCHID = Colour.fromHex("#BA55D3");
    static MEDIUMPURPLE = Colour.fromHex("#9370DB");
    static MEDIUMSEAGREEN = Colour.fromHex("#3CB371");
    static MEDIUMSLATEBLUE = Colour.fromHex("#7B68EE");
    static MEDIUMSPRINGGREEN = Colour.fromHex("#00FA9A");
    static MEDIUMTURQUOISE = Colour.fromHex("#48D1CC");
    static MEDIUMVIOLETRED = Colour.fromHex("#C71585");
    static MIDNIGHTBLUE = Colour.fromHex("#191970");
    static MINTCREAM = Colour.fromHex("#F5FFFA");
    static MISTYROSE = Colour.fromHex("#FFE4E1");
    static MOCCASIN = Colour.fromHex("#FFE4B5");
    static NAVAJOWHITE = Colour.fromHex("#FFDEAD");
    static NAVY = Colour.fromHex("#000080");
    static OLDLACE = Colour.fromHex("#FDF5E6");
    static OLIVE = Colour.fromHex("#808000");
    static OLIVEDRAB = Colour.fromHex("#6B8E23");
    static ORANGE = Colour.fromHex("#FFA500");
    static ORANGERED = Colour.fromHex("#FF4500");
    static ORCHID = Colour.fromHex("#DA70D6");
    static PALEGOLDENROD = Colour.fromHex("#EEE8AA");
    static PALEGREEN = Colour.fromHex("#98FB98");
    static PALETURQUOISE = Colour.fromHex("#AFEEEE");
    static PALEVIOLETRED = Colour.fromHex("#DB7093");
    static PAPAYAWHIP = Colour.fromHex("#FFEFD5");
    static PEACHPUFF = Colour.fromHex("#FFDAB9");
    static PERU = Colour.fromHex("#CD853F");
    static PINK = Colour.fromHex("#FFC0CB");
    static PLUM = Colour.fromHex("#DDA0DD");
    static POWDERBLUE = Colour.fromHex("#B0E0E6");
    static PURPLE = Colour.fromHex("#800080");
    static REBECCAPURPLE = Colour.fromHex("#663399");
    static RED = Colour.fromHex("#FF0000");
    static ROSYBROWN = Colour.fromHex("#BC8F8F");
    static ROYALBLUE = Colour.fromHex("#4169E1");
    static SADDLEBROWN = Colour.fromHex("#8B4513");
    static SALMON = Colour.fromHex("#FA8072");
    static SANDYBROWN = Colour.fromHex("#F4A460");
    static SEAGREEN = Colour.fromHex("#2E8B57");
    static SEASHELL = Colour.fromHex("#FFF5EE");
    static SIENNA = Colour.fromHex("#A0522D");
    static SILVER = Colour.fromHex("#C0C0C0");
    static SKYBLUE = Colour.fromHex("#87CEEB");
    static SLATEBLUE = Colour.fromHex("#6A5ACD");
    static SLATEGRAY = Colour.fromHex("#708090");
    static SLATEGREY = Colour.fromHex("#708090");
    static SNOW = Colour.fromHex("#FFFAFA");
    static SPRINGGREEN = Colour.fromHex("#00FF7F");
    static STEELBLUE = Colour.fromHex("#4682B4");
    static TAN = Colour.fromHex("#D2B48C");
    static TEAL = Colour.fromHex("#008080");
    static THISTLE = Colour.fromHex("#D8BFD8");
    static TOMATO = Colour.fromHex("#FF6347");
    static TURQUOISE = Colour.fromHex("#40E0D0");
    static VIOLET = Colour.fromHex("#EE82EE");
    static WHEAT = Colour.fromHex("#F5DEB3");
    static WHITE = Colour.fromHex("#FFFFFF");
    static WHITESMOKE = Colour.fromHex("#F5F5F5");
    static YELLOW = Colour.fromHex("#FFFF00");
    static YELLOWGREEN = Colour.fromHex("#9ACD32");
    //#endregion
    /** create a colour from a corresponding hex value */
    static fromHex(hex) {
        // remove any leading formatting characters
        hex = hex.replace("#", "").replace("0x", "");
        const colourValue = Number.parseInt(hex, 16);
        let r;
        let g;
        let b;
        switch (hex.length) {
            // 8-bit colour
            case 2:
                r = (colourValue & 0b1110_0000) / 0b1110_0000;
                g = (colourValue & 0b0001_1100) / 0b0001_1100;
                b = (colourValue & 0b0000_0011) / 0b0000_0011;
                break;
            // 12-bit colour
            case 3:
                r = (colourValue & 0xF00) / 0xF00;
                g = (colourValue & 0x0F0) / 0x0F0;
                b = (colourValue & 0x00F) / 0x00F;
                break;
            // 16-bit colour
            case 4:
                r = (colourValue & 0xF800) / 0xF800;
                g = (colourValue & 0x07E0) / 0x07E0;
                b = (colourValue & 0x001F) / 0x001F;
                break;
            // 24-bit colour
            case 6:
                r = (colourValue & 0xFF_00_00) / 0xFF_00_00;
                g = (colourValue & 0x00_FF_00) / 0x00_FF_00;
                b = (colourValue & 0x00_00_FF) / 0x00_00_FF;
                break;
            // 36-bit colour
            case 9:
                r = (colourValue & 0xFFF_000_000) / 0xFFF_000_000;
                g = (colourValue & 0x000_FFF_000) / 0x000_FFF_000;
                b = (colourValue & 0x000_000_FFF) / 0x000_000_FFF;
                break;
            // 48-bit colour
            case 12:
                r = (colourValue & 0xFFFF_0000_0000) / 0xFFFF_0000_0000;
                g = (colourValue & 0x0000_FFFF_0000) / 0x0000_FFFF_0000;
                b = (colourValue & 0x0000_0000_FFFF) / 0x0000_0000_FFFF;
                break;
            default:
                throw new Error("Invalid colour format");
        }
        return new Colour(r, g, b);
    }
    /** create a colour from HSV format */
    static fromHSV(hue, saturation, value, alpha = 1) {
        const chroma = value * saturation;
        const scaledHue = hue * 6;
        // integer to isolate the 6 separate cases for hue
        const hueRegion = Math.floor(scaledHue);
        // intermediate value for second largest component
        const X = chroma * (1 - Math.abs(scaledHue % 2 - 1));
        // constant to add to all colour components
        const m = value - chroma;
        return Colour.fromCXM(hueRegion, chroma, X, m, alpha);
    }
    /** create a colour from HSL format */
    static fromHSL(hue, saturation, lightness, alpha = 1) {
        const chroma = (1 - Math.abs(2 * lightness - 1)) * saturation;
        const scaledHue = hue * 6;
        // integer to isolate the 6 separate cases for hue
        const hueRegion = Math.floor(scaledHue);
        // intermediate value for second largest component
        const X = chroma * (1 - Math.abs(scaledHue % 2 - 1));
        // constant to add to all colour components
        const m = lightness - chroma * 0.5;
        return Colour.fromCXM(hueRegion, chroma, X, m, alpha);
    }
    /** create a colour from HSI format */
    static fromHSI(hue, saturation, intensity, alpha = 1) {
        const scaledHue = hue * 6;
        // integer to isolate the 6 separate cases for hue
        const hueRegion = Math.floor(scaledHue);
        const Z = 1 - Math.abs(scaledHue % 2 - 1);
        const chroma = 3 * intensity * saturation / (1 + Z);
        // intermediate value for second largest component
        const X = chroma * Z;
        // constant to add to all colour components
        const m = intensity * (1 - saturation);
        return Colour.fromCXM(hueRegion, chroma, X, m, alpha);
    }
    /** create a colour from 24-bit RGB format */
    static from24BitRGB(r, g, b) {
        return this.from32BitRGBA(r, g, b);
    }
    /** create a colour from 32-bit RGBA format */
    static from32BitRGBA(r, g, b, a) {
        return new Colour(r / 0xFF, g / 0xFF, b / 0xFF, a ? a / 0xFF : 1);
    }
    static fromCXM(hueRegion, chroma, X, m, alpha) {
        switch (hueRegion) {
            case 0: // red to yellow
                return new Colour(chroma + m, X + m, m, alpha);
            case 1: // yellow to green
                return new Colour(X + m, chroma + m, m, alpha);
            case 2: // green to cyan
                return new Colour(m, chroma + m, X + m, alpha);
            case 3: // cyan to blue
                return new Colour(m, X + m, chroma + m, alpha);
            case 4: // blue to magenta
                return new Colour(X + m, m, chroma + m, alpha);
            case 5: // magenta to red
                return new Colour(chroma + m, m, X + m, alpha);
            default:
                return Colour.BLACK;
        }
    }
}
exports.Colour = Colour;
class Color extends Colour {
}
exports.Color = Color;
;
/** the available colour spaces supported by the library */
var ColourSpace;
(function (ColourSpace) {
    ColourSpace[ColourSpace["RGB"] = 0] = "RGB";
    ColourSpace[ColourSpace["HSV"] = 1] = "HSV";
    ColourSpace[ColourSpace["HSL"] = 2] = "HSL";
    ColourSpace[ColourSpace["HSI"] = 3] = "HSI";
})(ColourSpace = exports.ColourSpace || (exports.ColourSpace = {}));
exports.ColorSpace = ColourSpace;
//# sourceMappingURL=colour.js.map