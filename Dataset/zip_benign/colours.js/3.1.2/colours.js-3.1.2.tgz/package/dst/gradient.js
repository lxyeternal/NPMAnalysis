"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JoinedGradient = exports.DirectGradient = exports.Interpolation = void 0;
const colour_1 = require("./colour");
const mathExt = require("./mathExt");
/** the available interpolation methods supported by the library */
var Interpolation;
(function (Interpolation) {
    Interpolation[Interpolation["linear"] = 0] = "linear";
    Interpolation[Interpolation["inc_quadratic"] = 1] = "inc_quadratic";
    Interpolation[Interpolation["dec_quadratic"] = 2] = "dec_quadratic";
    Interpolation[Interpolation["cubic"] = 3] = "cubic";
})(Interpolation = exports.Interpolation || (exports.Interpolation = {}));
class DirectGradient extends Object {
    cycles;
    // start colour in easy to interpolate form
    s1;
    s2;
    s3;
    // end colour in easy to interpolate form
    e1;
    e2;
    e3;
    cyclicArg;
    fromColour;
    toColour;
    interpFtn;
    cyclicInterpFtn;
    colourSpace;
    interpMethod;
    _longRoute;
    /** represents a smooth gradient between two colours */
    constructor(startColour, endColour, space = colour_1.ColourSpace.RGB, interpolation = Interpolation.linear, longRoute = false, cycles = 0) {
        super();
        this.colourSpace = space;
        this.interpMethod = interpolation;
        let { fromColour, toColour } = getCastingFtns(space);
        let { interpFtn, cyclicInterpFtn } = getInterpFtns(interpolation, longRoute);
        this._longRoute = longRoute;
        this.toColour = toColour;
        this.fromColour = fromColour;
        this.interpFtn = interpFtn;
        this.cyclicInterpFtn = cyclicInterpFtn;
        [this.s1, this.s2, this.s3] = fromColour(startColour);
        [this.e1, this.e2, this.e3] = fromColour(endColour);
        this.cyclicArg = getCyclicArg(space);
        this.cycles = cycles;
    }
    getAt(t) {
        return this.toColour(0b100 & this.cyclicArg ? this.cyclicInterpFtn(t, this.s1, this.e1, this.cycles) : this.interpFtn(t, this.s1, this.e1), 0b010 & this.cyclicArg ? this.cyclicInterpFtn(t, this.s2, this.e2, this.cycles) : this.interpFtn(t, this.s2, this.e2), 0b001 & this.cyclicArg ? this.cyclicInterpFtn(t, this.s3, this.e3, this.cycles) : this.interpFtn(t, this.s3, this.e3));
    }
    get startColour() {
        return this.toColour(this.s1, this.s2, this.s3);
    }
    get endColour() {
        return this.toColour(this.e1, this.e2, this.e3);
    }
    set startColour(c) {
        [this.s1, this.s2, this.s3] = this.fromColour(c);
    }
    set endColour(c) {
        [this.e1, this.e2, this.e3] = this.fromColour(c);
    }
    get interpolation() {
        return this.interpMethod;
    }
    get space() {
        return this.colourSpace;
    }
    set interpolation(interpolation) {
        this.interpMethod = interpolation;
        let { interpFtn, cyclicInterpFtn } = getInterpFtns(interpolation, this._longRoute);
        this.interpFtn = interpFtn;
        this.cyclicInterpFtn = cyclicInterpFtn;
    }
    set space(space) {
        this.colourSpace = space;
        let s = this.startColour, e = this.endColour;
        let { fromColour, toColour } = getCastingFtns(space);
        this.fromColour = fromColour;
        this.toColour = toColour;
        this.cyclicArg = getCyclicArg(space);
        this.startColour = s, this.endColour = e;
    }
    get longRoute() {
        return this._longRoute;
    }
    set longRoute(longRoute) {
        this._longRoute = longRoute;
        let { interpFtn, cyclicInterpFtn } = getInterpFtns(this.interpMethod, longRoute);
        this.interpFtn = interpFtn;
        this.cyclicInterpFtn = cyclicInterpFtn;
    }
    toString() {
        return `DirectGradient(${this.startColour}, ${this.endColour})`;
    }
}
exports.DirectGradient = DirectGradient;
class JoinedGradient extends Object {
    colours;
    colourSpaces;
    interpMethods;
    lengths;
    longRoutes;
    cycles;
    factor;
    /** represents a gradient between many colours, travelling an abstract route through colour space. */
    constructor(startColour, ...segments) {
        super();
        this.colours = [startColour];
        this.colourSpaces = [];
        this.interpMethods = [];
        this.longRoutes = [];
        this.cycles = [];
        let lengths = [];
        for (const segment of segments) {
            if (segment.colour)
                this.colours.push(segment.colour);
            else if (segment.color)
                this.colours.push(segment.color);
            else
                throw new Error("A colour must be specified in all segments.");
            this.colourSpaces.push(segment.space ?? colour_1.ColourSpace.RGB);
            this.interpMethods.push(segment.interpolation ?? Interpolation.linear);
            this.longRoutes.push(segment.longRoute ?? false);
            this.cycles.push(segment.cycles ?? 0);
            lengths.push(segment.length ?? 1);
        }
        this.factor = mathExt.sum(...lengths);
        this.lengths = mathExt.normalize_1D(lengths);
    }
    getAt(t) {
        let lt = t;
        let i = 0;
        for (; lt > this.lengths[i]; i++)
            lt -= this.lengths[i];
        lt /= this.lengths[i];
        let g = new DirectGradient(this.colours[i], this.colours[i + 1], this.colourSpaces[i], this.interpMethods[i], this.longRoutes[i], this.cycles[i]);
        return g.getAt(lt);
    }
    /** get the contained gradient at index i */
    getGradient(i) {
        return new DirectGradient(this.colours[i], this.colours[i + 1], this.colourSpaces[i], this.interpMethods[i], this.longRoutes[i], this.cycles[i]);
    }
    /** set the contained gradient at index i */
    setGradient(i, gradient) {
        this.colours[i] = gradient.startColour;
        this.colours[i + 1] = gradient.endColour;
        this.colourSpaces[i] = gradient.space;
        this.interpMethods[i] = gradient.interpolation;
        this.longRoutes[i] = gradient.longRoute;
        this.cycles[i] = gradient.cycles;
    }
    /** get the length of the contained gradient at index i */
    getGradientLength(i) {
        return this.lengths[i] * this.factor;
    }
    /** set the length of the contained gradient at index i */
    setGradientLength(i, length) {
        let originalLengths = this.lengths;
        originalLengths.forEach((v, i) => originalLengths[i] = v * this.factor);
        originalLengths[i] = length;
        this.factor = mathExt.sum(...originalLengths);
        this.lengths = mathExt.normalize_1D(originalLengths);
    }
    toString() {
        return `JoinedGradient(${this.colours[0], this.colours[this.colours.length - 1]})`;
    }
}
exports.JoinedGradient = JoinedGradient;
/** collects the appropriate casting functions for a given colour space */
function getCastingFtns(space) {
    let fromColour;
    let toColour;
    switch (space) {
        case colour_1.ColourSpace.RGB:
            fromColour = (c) => c.toRGB();
            toColour = (r, g, b) => new colour_1.Colour(r, g, b);
            break;
        case colour_1.ColourSpace.HSV:
            fromColour = (c) => c.toHSV();
            toColour = (h, s, v) => colour_1.Colour.fromHSV(h, s, v);
            break;
        case colour_1.ColourSpace.HSL:
            fromColour = (c) => c.toHSL();
            toColour = (h, s, l) => colour_1.Colour.fromHSL(h, s, l);
            break;
        case colour_1.ColourSpace.HSI:
            fromColour = (c) => c.toHSI();
            toColour = (h, s, i) => colour_1.Colour.fromHSI(h, s, i);
            break;
        default:
            throw new Error("That colour space is not yet supported within in this function.");
    }
    return { toColour, fromColour };
}
/** collects the appropriate interpolation functions for a given interpolation method */
function getInterpFtns(interpolation, longRoute = false) {
    let interpFtn;
    let cyclicInterpFtn;
    switch (interpolation) {
        case Interpolation.linear:
            interpFtn = mathExt.lerp;
            cyclicInterpFtn = longRoute ? mathExt.cyclicLerp_long : mathExt.cyclicLerp_short;
            break;
        case Interpolation.inc_quadratic:
            interpFtn = mathExt.qerp_0;
            cyclicInterpFtn = longRoute ? mathExt.cyclicQerp_0_long : mathExt.cyclicQerp_0_short;
            break;
        case Interpolation.dec_quadratic:
            interpFtn = mathExt.qerp_1;
            cyclicInterpFtn = longRoute ? mathExt.cyclicQerp_1_long : mathExt.cyclicQerp_1_short;
            break;
        case Interpolation.cubic:
            interpFtn = mathExt.cubicInterp_deriv;
            cyclicInterpFtn = longRoute ? (t, a, b, cycles) => mathExt.cyclicCubicInterp_deriv_long(t, a, b, 0, 0, cycles) : (t, a, b, cycles) => mathExt.cyclicCubicInterp_deriv_short(t, a, b, 0, 0, cycles);
            break;
        default:
            throw new Error("That interpolation method is not yet supported within this function");
    }
    return { interpFtn, cyclicInterpFtn };
}
/** returns a number which indicates which components of a given colour system are cyclical */
function getCyclicArg(space) {
    return space == colour_1.ColourSpace.RGB ? 0 : 0b100;
}
//# sourceMappingURL=gradient.js.map