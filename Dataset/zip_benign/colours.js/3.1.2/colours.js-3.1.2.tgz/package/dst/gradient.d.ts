import { Colour, Color, ColourSpace } from "./colour";
/** the available interpolation methods supported by the library */
export declare enum Interpolation {
    linear = 0,
    inc_quadratic = 1,
    dec_quadratic = 2,
    cubic = 3
}
/** any form of 1 dimensional gradient */
export interface Gradient {
    /** get the colour at a specific point along the gradient, range [0, 1] */
    getAt(t: number): Colour;
}
export declare class DirectGradient extends Object implements Gradient {
    cycles: number;
    private s1;
    private s2;
    private s3;
    private e1;
    private e2;
    private e3;
    private cyclicArg;
    private fromColour;
    private toColour;
    private interpFtn;
    private cyclicInterpFtn;
    private colourSpace;
    private interpMethod;
    private _longRoute;
    /** represents a smooth gradient between two colours */
    constructor(startColour: Colour, endColour: Colour, space?: ColourSpace, interpolation?: Interpolation, longRoute?: boolean, cycles?: number);
    getAt(t: number): Colour;
    get startColour(): Colour;
    get endColour(): Colour;
    set startColour(c: Colour);
    set endColour(c: Colour);
    get interpolation(): Interpolation;
    get space(): ColourSpace;
    set interpolation(interpolation: Interpolation);
    set space(space: ColourSpace);
    get longRoute(): boolean;
    set longRoute(longRoute: boolean);
    toString(): string;
}
export declare class JoinedGradient extends Object implements Gradient {
    private colours;
    private colourSpaces;
    private interpMethods;
    private lengths;
    private longRoutes;
    private cycles;
    private factor;
    /** represents a gradient between many colours, travelling an abstract route through colour space. */
    constructor(startColour: Colour, ...segments: GradientSegment[]);
    getAt(t: number): Colour;
    /** get the contained gradient at index i */
    getGradient(i: number): DirectGradient;
    /** set the contained gradient at index i */
    setGradient(i: number, gradient: DirectGradient): void;
    /** get the length of the contained gradient at index i */
    getGradientLength(i: number): number;
    /** set the length of the contained gradient at index i */
    setGradientLength(i: number, length: number): void;
    toString(): string;
}
/** used for segmented gradients */
export interface GradientSegment {
    colour?: Colour;
    color?: Color;
    length?: number;
    space?: ColourSpace;
    interpolation?: Interpolation;
    longRoute?: boolean;
    cycles?: number;
}
