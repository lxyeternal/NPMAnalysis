# math-ext

## API

	var m = require('math-ext');

	m.clamp(1, 2, 3) // => 2
	m.clamp(1, 2, 0.5) // => 1
	m.clamp(1, 2, 1.5) // => 1.5

	m.lerp(0, 2, 0.75) // => 1.5

	var c = m.clamper(1, 2)
	c(4) // => 2
	c(0.2) // => 1

	var l = m.lerper(0, 10)
	l(0.5) // => 5

## Expose globally

	require('math-ext').expose();

	typeof Math.clamp // => "function"
	typeof Math.lerp // => "function"
	// you get the idea.

