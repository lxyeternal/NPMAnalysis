/**
 * @param inputText: text to be measured
 * @param backupRatio: if something goes wrong, this number will be used to give a width estimate, the average open-sans font height-width ratio is 0.5
 *
 * @returns {number} numeric value of width in pixels
 */
export declare const getTextWidth: (inputText?: string | number | null | undefined, backupRatio?: number) => number;
