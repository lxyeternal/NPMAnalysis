import karas from 'karas';

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _possibleConstructorReturn(self, call) {
  if (call && (typeof call === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

var version = "0.2.3";

var ParticleBoom = /*#__PURE__*/function (_karas$Component) {
  _inherits(ParticleBoom, _karas$Component);

  var _super = _createSuper(ParticleBoom);

  function ParticleBoom() {
    _classCallCheck(this, ParticleBoom);

    return _super.apply(this, arguments);
  }

  _createClass(ParticleBoom, [{
    key: "shouldComponentUpdate",
    value: function shouldComponentUpdate() {
      return false;
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var props = this.props,
          width = this.width,
          height = this.height;
      var list = props.list,
          _props$num = props.num,
          num = _props$num === void 0 ? 0 : _props$num,
          _props$duration = props.duration,
          duration = _props$duration === void 0 ? 1000 : _props$duration,
          _props$delay = props.delay,
          delay = _props$delay === void 0 ? 0 : _props$delay,
          autoPlay = props.autoPlay,
          _props$playbackRate = props.playbackRate,
          playbackRate = _props$playbackRate === void 0 ? 1 : _props$playbackRate;
      var dataList = [];

      var _loop = function _loop(i) {
        var j = i % list.length;
        var item = list[j];
        var o = {};

        if (Array.isArray(item.x)) {
          o.x = item.x[0] + Math.random() * (item.x[1] - item.x[0]) * width;
        } else {
          o.x = item.x * width;
        }

        if (Array.isArray(item.y)) {
          o.y = item.y[0] + Math.random() * (item.y[1] - item.y[0]) * height;
        } else {
          o.y = item.y * height;
        }

        if (Array.isArray(item.width)) {
          o.width = item.width[0] + Math.random() * (item.width[1] - item.width[0]);
        } else {
          o.width = item.width;
        }

        if (item.ar) {
          o.height = o.width * item.ar;
        } else {
          if (Array.isArray(item.height)) {
            o.height = item.height[0] + Math.random() * (item.height[1] - item.height[0]);
          } else {
            o.height = item.height;
          }
        }

        var deg = 0;

        if (Array.isArray(item.deg)) {
          deg = item.deg[0] + Math.random() * (item.deg[1] - item.deg[0]);
        } else {
          deg = item.deg;
        }

        var distance = 0;

        if (Array.isArray(item.distance)) {
          distance = (item.distance[0] + Math.random() * (item.distance[1] - item.distance[0])) * width;
        } else {
          distance = item.distance * width;
        }

        if (deg >= 270) {
          deg = 360 - deg;
          deg = karas.math.geom.d2r(deg);
          o.tx = o.x + distance * Math.cos(deg);
          o.ty = o.y - distance * Math.sin(deg);
        } else if (deg >= 180) {
          deg = deg - 180;
          deg = karas.math.geom.d2r(deg);
          o.tx = o.x - distance * Math.cos(deg);
          o.ty = o.y - distance * Math.sin(deg);
        } else if (deg >= 90) {
          deg = 180 - deg;
          deg = karas.math.geom.d2r(deg);
          o.tx = o.x - distance * Math.cos(deg);
          o.ty = o.y + distance * Math.sin(deg);
        } else {
          deg = karas.math.geom.d2r(deg);
          o.tx = o.x + distance * Math.cos(deg);
          o.ty = o.y + distance * Math.sin(deg);
        }

        o.dx = o.tx - o.x;
        o.dy = o.ty - o.y;

        if (item.blink) {
          var _item$blink = item.blink,
              from = _item$blink.from,
              to = _item$blink.to,
              _duration = _item$blink.duration;

          if (Array.isArray(_duration)) {
            _duration = _duration[0] + Math.random() * (_duration[1] - _duration[0]);
          }

          if (Array.isArray(from) && Array.isArray(to)) {
            o.blink = {
              from: from[0] + (Math.random() * from[1] - from[0]),
              to: to[0] + (Math.random() * to[1] - to[0]),
              duration: _duration
            };
          }
        }

        if (item.easing) {
          item.easing = karas.animate.easing.getEasing(item.easing);
        }

        if (item.url) {
          karas.inject.measureImg(item.url, function (res) {
            if (res.success) {
              o.source = res.source;
            }
          });
        }

        dataList.push(o);
      };

      for (var i = 0; i < (num || 1); i++) {
        _loop(i);
      }

      var fake = this.ref.fake;
      var a = this.animation = fake.animate([{
        opacity: 1
      }, {
        opacity: 0
      }], {
        duration: duration,
        delay: delay,
        autoPlay: autoPlay,
        playbackRate: playbackRate
      });

      fake.render = function (renderMode, lv, ctx) {
        var sx = fake.sx,
            sy = fake.sy;
        var alpha = ctx.globalAlpha;
        var time = a.currentTime - delay;

        if (time < 0) {
          return;
        }

        dataList.forEach(function (item) {
          if (item.source) {
            var x = sx + item.x;
            var y = sy + item.y;
            var percent = time / duration;

            if (item.easing) {
              percent = item.easing(percent);
            }

            x += item.dx * percent;
            y += item.dy * percent;
            x -= item.width * 0.5;
            y -= item.height * 0.5;
            var blink = item.blink;
            var opacity = alpha;

            if (blink) {
              var _num = Math.floor(time / blink.duration);

              var diff = time % blink.duration; // 偶数from2to，奇数to2from

              if (_num % 2 === 0) {
                opacity *= blink.from - (blink.from - blink.to) * diff / blink.duration;
              } else {
                opacity *= blink.to + (blink.from - blink.to) * diff / blink.duration;
              }
            }

            ctx.globalAlpha = opacity;
            ctx.drawImage(item.source, x, y, item.width, item.height);
          }
        });
        ctx.globalAlpha = alpha;
      };
    }
  }, {
    key: "pause",
    value: function pause() {
      if (this.animation) {
        this.animation.pause();
      }
    }
  }, {
    key: "resume",
    value: function resume() {
      if (this.animation) {
        this.animation.resume();
      }
    }
  }, {
    key: "play",
    value: function play() {
      if (this.animation) {
        this.animation.play();
      }
    }
  }, {
    key: "playbackRate",
    get: function get() {
      return this.animation.playbackRate;
    },
    set: function set(v) {
      this.animation.playbackRate = v;
    }
  }, {
    key: "render",
    value: function render() {
      return karas.createElement("div", null, karas.createElement("$polyline", {
        ref: "fake"
      }));
    }
  }]);

  return ParticleBoom;
}(karas.Component);

ParticleBoom.version = version;

export { ParticleBoom as default };
//# sourceMappingURL=index.es.js.map
