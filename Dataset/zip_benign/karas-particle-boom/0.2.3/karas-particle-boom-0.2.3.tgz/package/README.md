# karas-particular-boom
ParticularBoom component for karas.

---
karas粒子爆炸组件。

[![NPM version](https://img.shields.io/npm/v/karas-particular-boom.svg)](https://npmjs.org/package/karas-particular-boom)

## Install
```
npm install karas
npm install karas-particular-boom
```

## Usage

```jsx
import ParticleBoom from 'karas-particular-boom';

karas.render(
  <canvas width="720" height="720">
    <ParticleBoom style={{
                    width: 300,
                    height: 300,
                  }}
                  list={[{
                    url: 'https://gw.alipayobjects.com/mdn/rms_5922c1/afts/img/A*lW6mQ46eA0MAAAAAAAAAAAAAARQnAQ',
                    x: 0.5,
                    y: 0.5,
                    distance: [0.2, 1.2],
                    deg: [0, 360],
                    width: 5,
                    height: 5,
                    easing: 'ease-out',
                    blink: {
                      from: [0.6, 0.8],
                      to: [0.2, 0.4],
                      duration: [200, 300],
                    },
                  }]} // 粒子随机选择位图
                  num={100} // 粒子数量
                  delay={500} // 播放延迟
                  duration={2000} // 时长
                  playbackRate={1} // 播放速率
                  autoPlay={false} // 自动播放，非false则为自动
    />
  </canvas>
);
```

### method
* pause()
* resume()
* play()

### get/set
* playbackRate 播放速率

# License
[MIT License]
