import * as CANNON from "cannon-es";
import { ShapeType, threeToCannon } from "/three-to-cannon/dist/three-to-cannon.esm.js";
import CannonDebugger from "/cannon-es-debugger/dist/cannon-es-debugger.js";

class PhysicsEngine {
    /**
     * 构造函数，创建物理引擎实例
     */
    constructor(scene) {
        // 创建 CANNON.World 对象和刚体数组
        this.world = new CANNON.World();
        this.bodies = [];

        this.scene = scene;

        // 设置默认的时间步长为 1/60 秒
        this.timeStep = 1 / 60;

        // 初始化物理引擎
        this.init();
    }

    /**
     * 初始化物理引擎
     */
    init() {
        // 设置默认的重力加速度为 y 负方向上的 9.82 m/s^2
        this.world.gravity.set(0, -10, 0);

        // 使用 NaiveBroadphase 算法进行碰撞检测
        this.world.broadphase = new CANNON.NaiveBroadphase();

        // 设置解决器的迭代次数为 10
        this.world.solver.iterations = 2;
    }

    /**
     * 开启debug
     */
    debug(open = true) {
        this.cannonDebugger = open
            ? new CannonDebugger(this.scene, this.world, {})
            : null;
    }

    /**
     * 添加刚体到物理引擎中
     * @param {CANNON.Body} body 要添加的刚体对象
     */
    addBody(body) {
        // 将刚体添加到 CANNON.World 对象中，并将其存储到刚体数组中
        this.world.addBody(body.cannonBody);
        // 保存对Three.js对象及其对应的CANNON的引用
        this.bodies.push(body);
    }

    /**
     * 应用一个力到指定的刚体上
     * @param {CANNON.Body} body 要应用力的刚体对象
     * @param {CANNON.Vec3} force 要应用的力的大小和方向
     */
    applyForce(body, force) {
        // 将力应用于刚体的位置上
        body.applyForce(force, body.position);
    }

    /**
     * 更新物理引擎状态
     */
    update() {
        // 使用指定的时间步长更新 CANNON.World 对象中的所有刚体
        this.world.step(this.timeStep);
        if (this.cannonDebugger) this.cannonDebugger.update();

        // 根据Three.js的CANNON更新其位置和旋转
        this.bodies.forEach(({ threeObject, cannonBody }) => {
            const { position, quaternion } = cannonBody;
            threeObject.position.copy(position);
            threeObject.quaternion.copy(quaternion);
        });
    }

    /**
     * 添加一个平面刚体到物理引擎中
     * @param {CANNON.Vec3} position 平面刚体的位置
     * @param {CANNON.Quaternion} rotation 平面刚体的旋转
     * @param { number } friction 摩擦系数
     * @param { number } restitution 弹性系数
     * @returns { CANNON.Body } 创建的球体刚体对象
     * @returns {CANNON.Body} 创建的平面刚体对象
     */
    addPlane(position, rotation, friction = 0.5, restitution = 0) {
        const planeMaterial = new CANNON.Material({
            friction: friction,
            restitution: restitution,
        });
        const planeShape = new CANNON.Plane();
        const planeBody = new CANNON.Body({
            mass: 0,
            material: planeMaterial,
        });
        planeBody.addShape(planeShape);

        // 设置平面刚体的位置和旋转
        planeBody.position.copy(position);
        planeBody.quaternion.copy(rotation);

        // 将平面刚体添加到 CANNON.World 对象中，并返回创建的刚体对象
        this.world.addBody(planeBody);

        return planeBody;
    }

    /**
     * 添加一个盒子刚体到物理引擎中
     * @param {Array<number>} size 盒子刚体的尺寸（三个方向的半轴长度）
     * @param {CANNON.Vec3} position 盒子刚体的位置
     * @param {CANNON.Quaternion} rotation 盒子刚体的旋转
     * @param {number} mass 盒子刚体的质量
     * @param {number} friction 摩擦系数
     * @param {number} restitution 弹性系数
     * @returns {CANNON.Body} 创建的盒子刚体对象
     */
    addBox(size, position, rotation, mass = 1, friction = 0.5, restitution = 0) {
        const boxMaterial = new CANNON.Material({
            friction: friction,
            restitution: restitution,
        });
        const boxShape = new CANNON.Box(new CANNON.Vec3(...size));
        const boxBody = new CANNON.Body({
            mass: mass,
            material: boxMaterial,
        });
        boxBody.addShape(boxShape);

        // 设置盒子刚体的位置、旋转和质量
        boxBody.position.copy(position);
        boxBody.quaternion.copy(rotation);

        // 将盒子刚体添加到 CANNON.World 对象中，并返回创建的刚体对象
        this.world.addBody(boxBody);
        return boxBody;
    }

    /**
     * 添加一个球体刚体到物理引擎中
     * @param {number} radius 球体半径
     * @param {CANNON.Vec3} position 球体位置
     * @param {CANNON.Quaternion} rotation 球体旋转
     * @param {number} mass 球体质量
     * @param {number} friction 摩擦系数
     * @param {number} restitution 弹性系数
     * @returns {CANNON.Body} 创建的球体刚体对象
     */
    addSphere(radius, position, rotation, mass = 1, friction = 0.5, restitution = 0) {
        const sphereMaterial = new CANNON.Material({
            friction: friction,
            restitution: restitution,
        });
        const sphereShape = new CANNON.Sphere(radius);
        const sphereBody = new CANNON.Body({
            mass: mass,
            material: sphereMaterial,
        });
        sphereBody.addShape(sphereShape);

        // 设置球体刚体的位置、旋转和质量
        sphereBody.position.copy(position);
        sphereBody.quaternion.copy(rotation);

        // 将球体刚体添加到 CANNON.World 对象中，并返回创建的刚体对象
        this.world.addBody(sphereBody);
        return sphereBody;
    }

    /**
     * 应用冲量到指定的刚体上
     * @param {CANNON.Body} body 要应用冲量的刚体对象
     * @param {CANNON.Vec3} impulse 冲量的大小和方向
     * @param {CANNON.Vec3} contactPoint 冲量作用点的位置
     */
    applyImpulse(body, impulse, contactPoint) {
        body.applyImpulse(impulse, contactPoint);
    }

    /**
     * 应用扭矩到指定的刚体上
     * @param {CANNON.Body} body 要应用扭矩的刚体对象
     * @param {CANNON.Vec3} torque 扭矩的大小和方向
     */
    applyTorque(body, torque) {
        body.applyTorque(torque);
    }

    /**
     * 在刚体的本地坐标系下应用一个力
     * @param {CANNON.Body} body 要应用力的刚体对象
     * @param {CANNON.Vec3} force 要应用的力的大小和方向
     * @param {CANNON.Vec3} position 力作用点在刚体本地坐标系下的位置
     */
    applyLocalForce(body, force, position) {
        body.applyLocalForce(force, position);
    }

    /**
     * 在刚体的本地坐标系下应用一个冲量
     * @param {CANNON.Body} body 要应用冲量的刚体对象
     * @param {CANNON.Vec3} impulse 冲量的大小和方向
     * @param {CANNON.Vec3} position 冲量作用点在刚体本地坐标系下的位置
     */
    applyLocalImpulse(body, impulse, position) {
        body.applyLocalImpulse(impulse, position);
    }

    /**
     * 添加 Three.js 对象到物理世界中
     * @param {THREE.Object3D} object3D - 待添加的 Three.js 对象
     */
    addObject(object3D, mass = 1) {
        // 将 Three.js 对象转换为 CANNON 形状
        const { shape, offset, quaternion } = threeToCannon(object3D, {
            type: ShapeType.HULL,
        });

        // 创建一个用于物体的 CANNON body
        const body = new CANNON.Body({
            mass: mass,
        });

        body.addShape(shape, offset, quaternion);

        let pack = {
            threeObject: object3D,
            cannonBody: body,
        };

        // 将 body 添加到物理世界
        this.addBody(pack);
        return pack;
    }

    /**
     * 异步加载 GLTF 模型并添加到物理引擎中
     * @param {GLTFLoader} loader loader配置
     * @param {string} url GLTF 模型的 URL 地址
     * @param {CANNON.Vec3} position 模型的初始位置
     * @param {CANNON.Quaternion} quaternion 模型的初始旋转
     * @param {number} mass 模型的质量（如果不想受到重力影响可以设置为 0）
     * @param {number} scale 模型的缩放比例
     * @param {number} friction 模型的摩擦系数
     * @param {number} restitution 弹性系数
     * @returns {Promise<Object>} 加载完成后返回的 Promise 对象，解析值为创建的刚体对象
     */
    loadGLTF(loader, url, position, quaternion, mass = 1, scale = 1, friction = 0.5, restitution = 0.5, type = "HULL") {
        // 创建一个新材质，并为其指定摩擦系数
        const material = new CANNON.Material({
            friction: friction,
            restitution: restitution,
        });

        // 加载 GLTF 模型
        return new Promise((resolve) => {
            loader.load(url, (gltf) => {
                // 获取模型的 Three.js Scene 对象
                const modelScene = gltf.scene;
                this.scene.add(modelScene);
                // 将每个子网格（submesh）都转换为 CANNON 形状，并将其添加到刚体中
                const shapes = [];
                modelScene.traverse((child) => {
                    if (child.isMesh) {
                        child.scale.set(scale, scale, scale);
                        const { shape, offset, quaternion } = threeToCannon(child, {
                            type: ShapeType[type],
                        });
                        shapes.push({
                            shape,
                            offset,
                            quaternion,
                        });
                    }
                });

                // 创建一个用于物体的 CANNON body，并将所有的形状添加到该 body 中
                const body = new CANNON.Body({
                    mass: mass,
                    material: material,
                });
                for (const { shape, offset, quaternion } of shapes) {
                    body.addShape(shape, offset, quaternion);
                }

                // 将 body 添加到物理世界
                this.world.addBody(body);
                body.position.copy(position);
                body.quaternion.copy(quaternion);

                let pack = {
                    threeObject: modelScene,
                    cannonBody: body,
                };

                // 保存对Three.js对象及其对应的CANNON的引用
                this.bodies.push(pack);

                resolve(pack);
            });
        });
    }
}

export { PhysicsEngine };
