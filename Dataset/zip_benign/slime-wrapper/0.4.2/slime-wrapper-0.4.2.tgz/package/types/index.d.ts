/**
 * `Matcher` is an `Object` that contains callback function for pattern matching pattern
 * @remarks See {@link Wrapper.match | `Wrapper<T>.match`}
 */
interface Matcher$2<U> {
    [key: string]: ((value: any) => U) | (() => U);
}
/**
 * `Wrapper<T>` represents an abstract wrapper class type for wrapping a value
 */
declare abstract class Wrapper<T> {
    /**
     * Unwraps contained `Wrapper<T>` value.
     * @returns A value in `Wrapper<T>`
     */
    abstract unwrap(): T;
    /**
     * Maps a `Wrapper<T>` to `Wrapper<U>` by applying a callback function that receive contained `Wrapper<T>` value and return a result
     * @param callbackFn - A function that accept contained `Wrapper<T>` value and return a result
     * @returns A `Wrapper<U>` that contains a result of calling callbackFn
     */
    abstract map<U>(callbackFn: (value: T) => U): Wrapper<U>;
    /**
     * Maps a `Wrapper<T>` to `Wrapper<U>` by applying a callback function that receive contained `Wrapper<T>` value, then flatten the result
     * @param callbackFn - A function that accept contained `Wrapper<T>` value and return a new `Wrapper<U>`
     * @returns A `Wrapper<U>` that contains a result of calling callbackFn and flatten it
     */
    abstract flatMap<U>(callbackFn: (value: T) => Wrapper<U>): Wrapper<U>;
    /**
     * Inspired from pattern matching pattern
     * @remarks See {@link https://doc.rust-lang.org/book/ch18-03-pattern-syntax.html}
    */
    abstract match<U>(matcher: Matcher$2<U>): U;
    /**
     * Inspects contained `Wrapper<T>` value
     * @remarks Uses for development propose only. Should not use for production.
     * @param callbackFn - A function that accept contained `Wrapper<T>` value
     */
    abstract inspect(callbackFn: (value: T) => void): this;
}

interface Matcher$1<T, U> extends Matcher$2<U> {
    some: (value: T) => U;
    none: () => U;
}
/**
 * `Option<T>` represents an optional value. Every `Option<T>` is either `Some<T>` and contains a value,
 * or `None<T>` which represents an empty value (`undefined`, `NaN`, `null`)
 */
declare abstract class Option<T> extends Wrapper<T> {
    /**
     * Unwraps contained `Some<T>` value. Throws error if the `Option` is `None`
     * @returns A value in `Some<T>`
     * @throws { ReferenceError }
     * Thrown if the `Option` is `None`
     */
    abstract unwrap(): T;
    /**
     * Returns the contained `Some<T>` value or a provided default
     * @param defaultValue A default value to return in case the `Option` is `None`
     * @returns A value in `Some<T>` or a default value
     */
    abstract unwrapOr(defaultValue: T): T;
    /**
     * Inspired from pattern matching patterns
     * @remarks See {@link https://doc.rust-lang.org/book/ch18-03-pattern-syntax.html}
     * @param matcher Object that contains call back function for `Some` and `None`
     * @returns value (or void) from matcher's callback function
     * @example
     * Here's a simple example
     * ```ts
     * const some = new Some(2);
     * const result = some.match({
     *  some: (value) => `Result: ${value}`,
     *  none: () => 'Result: None',
     * });
     *
     * console.log(result); // 'Result: 2'
     * ```
     */
    abstract match<U>(matcher: Matcher$1<T, U>): U;
    /**
     * Maps a `Option<T>` to `Option<U>` by applying a callback function that receive contained `Some<T>` value and return a result
     * @param callbackFn - A function that accept contained `Some<T>` value and return a result
     * @returns A `Option<U>` that contains a result of calling callbackFn
     */
    abstract map<U>(callbackFn: (value: T) => U): Option<U>;
    /**
     * Maps a `Option<T>` to `Option<U>` by applying a callback function that receive contained `Some<T>` value, then flatten the result
     * @param callbackFn - A function that accept contained `Some<T>` value and return a new `Option<U>`
     * @returns A `Option<U>` that contains a result of calling callbackFn and flatten it
     */
    abstract flatMap<U>(callbackFn: (value: T) => Option<U>): Option<U>;
    /**
     * Catch Maps to `Option<T>` when `Option` is `None`
     * @param callbackFn - A function that return a new `Option<T>`
     * @returns A `Option<T>`
     */
    abstract catchMap(callbackFn: () => Option<T>): Option<T>;
    /**
     * Returns true if the `Option` is `Some`
     * @returns A boolean
     */
    abstract isSome(): boolean;
    /**
     * Returns true if the `Option` is `None`
     * @returns A boolean
     */
    abstract isNone(): boolean;
    /**
     * Inspects contained `Some<T>` value. Do nothing if `Option` is `None`
     * @remarks Uses for development propose only. Should not use for production.
     * @param callbackFn - A function that accept contained `Some<T>` value
     */
    abstract inspect(callbackFn: (value: T) => void): this;
}
declare class Some<T> extends Option<T> {
    private readonly value;
    constructor(value: T);
    isSome(): boolean;
    isNone(): boolean;
    match<U>(matcher: Matcher$1<T, U>): U;
    map<U>(callbackFn: (value: T) => U): Some<U>;
    flatMap<U>(callbackFn: (value: T) => Option<U>): Option<U>;
    catchMap(callbackFn: () => Some<T>): Some<T>;
    unwrap(): T;
    unwrapOr(value: T): T;
    inspect(callbackFn: (value: T) => void): this;
}
declare class None<T> extends Option<T> {
    isSome(): boolean;
    isNone(): boolean;
    match<U>(matcher: Matcher$1<T, U>): U;
    map<U>(callbackFn: (value: T) => U): None<U>;
    flatMap<U>(callbackFn: (value: T) => Option<U>): None<U>;
    catchMap(callbackFn: () => Option<T>): Option<T>;
    unwrap(): T;
    unwrapOr(value: T): T;
    inspect(callbackFn: (value: T) => void): this;
}

interface Matcher<T, E, U> extends Matcher$2<U> {
    ok: (value: T) => U;
    err: (value: E) => U;
}
/**
 * `Result<T, E>` represents either success (`Ok<T, E>`) or failure (`Err<T, E>`)
 */
declare abstract class Result<T, E = Error> extends Wrapper<T> {
    /**
     * Unwraps contained `Ok<T, E>` value. Throws error if the `Result` is `Err`
     * @returns A value in `Ok<T, E>`
     * @throws { ReferenceError }
     * Thrown if the `Result` is `Err`
     */
    abstract unwrap(): T;
    /**
     * Returns the contained `Ok<T, E>` value or a provided default
     * @param defaultValue A default value to return in case the `Result` is `Err`
     * @returns A value in `Ok<T, E>` or a default value
     */
    abstract unwrapOr(defaultValue: T): T;
    /**
     * Unwraps contained `Err<T, E>` value. Throws error if the `Result` is `Ok`
     * @returns A value in `Err<T, E>`
     * @throws { ReferenceError }
     * Thrown if the `Result` is `Ok`
     */
    abstract unwrapErr(): E;
    /**
     * Returns the contained `Err<T, E>` value or a provided default
     * @param defaultValue A default value to return in case the `Result` is `Ok`
     * @returns A value in `Err<T, E>` or a default value
     */
    abstract unwrapErrOr(defaultValue: E): E;
    /**
     * Inspired from pattern matching patterns
     * @remarks See {@link https://doc.rust-lang.org/book/ch18-03-pattern-syntax.html}
     * @param matcher Object that contains call back function for `Some` and `None`
     * @returns value (or void) from matcher's callback function
     * @example
     * Here's a simple example
     * ```ts
     * const ok = new Ok<number, Error>(2);
     * const result = ok.match({
     *  ok: (value) => `Result: ${value}`,
     *  err: (value) => `Error: ${error.message}`,
     * });
     *
     * console.log(result); // 'Result: 2'
     * ```
     */
    abstract match<U>(matcher: Matcher<T, E, U>): U;
    /**
     * Maps a `Result<T, E>` to `Result<U, E>` by applying a callback function that receive contained `Ok<T, E>` value and return a result, Leave an `Err<T, E>` untouched
     * @param callbackFn - A function that accept contained `Ok<T, E>` value and return a result
     * @returns A `Result<U, E>` that contains a result of calling callbackFn
     */
    abstract map<U>(callbackFn: (value: T) => U): Result<U, E>;
    /**
     * Maps a `Result<T, E>` to `Result<T, U>` by applying a callback function that receive contained `Err<T, E>` value and return a result, Leave an `Ok<T, E>` untouched
     * @param callbackFn - A function that accept contained `Err<T, E>` value and return a result
     * @returns A `Result<T, U>` that contains a result of calling callbackFn
     */
    abstract mapErr<U>(callbackFn: (value: E) => U): Result<T, U>;
    /**
     * Maps a `Result<T, E>` to `Result<U, E>` by applying a callback function that receive contained `Ok<T, E>` value, then flatten the result
     * @param callbackFn - A function that accept contained `Ok<T, E>` value and return a new `Result<U, E>`
     * @returns A `Result<U, E>` that contains a result of calling callbackFn and flatten it
     */
    abstract flatMap<U>(callbackFn: (value: T) => Result<U, E>): Result<U, E>;
    /**
     * Maps a `Result<T, E>` to `Result<T, U>` by applying a callback function that receive contained `Err<T, E>` value, then flatten the result
     * @param callbackFn - A function that accept contained `Err<T, E>` value and return a new `Result<T, U>`
     * @returns A `Result<T, U>` that contains a result of calling callbackFn and flatten it
     */
    abstract flatMapErr<U>(callbackFn: (value: E) => Result<T, U>): Result<T, U>;
    /**
     * Catch Maps to `Result<T, E>` when `Result` is `None`
     * @param callbackFn - A function that return a new `Result<T, E>`
     * @returns A `Result<T, E>`
     */
    abstract catchMap(callbackFn: () => Result<T, E>): Result<T, E>;
    /**
     * Returns true if the `Result` is `Ok`
     * @returns A boolean
     */
    abstract isOk(): boolean;
    /**
     * Returns true if the `Result` is `Err`
     * @returns A boolean
     */
    abstract isErr(): boolean;
    /**
     * Converts from `Result<T, E>` to {@link Option | `Option<T>`}.
     * @returns Returns `Some<T>` with contained `Ok<T, E>` value. Otherwise returns `None`
     * @example
     * Here's a simple example
     * ```ts
     * const ok = new Ok<string, number>('Success');
     * const err = new Err<string, number>(404);
     *
     * console.log(ok.ok()); // Some('Success')
     * console.log(err.ok()); // None
     * ```
     */
    abstract ok(): Option<T>;
    /**
     * Converts from `Result<T, E>` to {@link Option | `Option<E>`}.
     * @returns Returns `Some<T>` with contained `Err<T, E>` value. Otherwise returns `None`
     * * @example
     * Here's a simple example
     * ```ts
     * const ok = new Ok<string, number>('Success');
     * const err = new Err<string, number>(404);
     *
     * console.log(ok.err()); // None
     * console.log(err.err()); // Some(404)
     * ```
     */
    abstract err(): Option<E>;
    /**
     * Inspects contained `Ok<T, E>` value. Do nothing if `Result` is `Err`
     * @remarks Uses for development propose only. Should not use for production.
     * @param callbackFn - A function that accept contained `Ok<T, E>` value
     */
    abstract inspect(callbackFn: (value: T) => void): this;
    /**
     * Inspects contained `Err<T, E>` value. Do nothing if `Result` is `Ok`
     * @remarks Uses for development propose only. Should not use for production.
     * @param callbackFn - A function that accept contained `Err<T, E>` value
     */
    abstract inspectErr(callbackFn: (value: E) => void): this;
}
declare class Ok<T, E> extends Result<T, E> {
    private readonly value;
    constructor(value: T);
    unwrap(): T;
    unwrapOr(value: T): T;
    unwrapErr(): E;
    unwrapErrOr(value: E): E;
    match<U>(matcher: Matcher<T, E, U>): U;
    map<U>(callbackFn: (value: T) => U): Ok<U, E>;
    mapErr<U>(callbackFn: (value: E) => U): Ok<T, U>;
    flatMap<U>(callbackFn: (value: T) => Result<U, E>): Result<U, E>;
    flatMapErr<U>(callbackFn: (value: E) => Result<T, U>): Result<T, U>;
    catchMap(callbackFn: () => Result<T, E>): Ok<T, E>;
    isOk(): boolean;
    isErr(): boolean;
    ok(): Option<T>;
    err(): Option<E>;
    inspect(callbackFn: (value: T) => void): this;
    inspectErr(callbackFn: (value: E) => void): this;
}
declare class Err<T, E> extends Result<T, E> {
    private readonly value;
    constructor(value: E);
    unwrap(): T;
    unwrapOr(value: T): T;
    unwrapErr(): E;
    unwrapErrOr(value: E): E;
    match<U>(matcher: Matcher<T, E, U>): U;
    map<U>(callbackFn: (value: T) => U): Err<U, E>;
    mapErr<U>(callbackFn: (value: E) => U): Err<T, U>;
    flatMap<U>(callbackFn: (value: T) => Result<U, E>): Err<U, E>;
    flatMapErr<U>(callbackFn: (value: E) => Result<T, U>): Result<T, U>;
    catchMap(callbackFn: () => Result<T, E>): Result<T, E>;
    isOk(): boolean;
    isErr(): boolean;
    ok(): Option<T>;
    err(): Option<E>;
    inspect(callbackFn: (value: T) => void): this;
    inspectErr(callbackFn: (value: E) => void): this;
}

/**
 * Wraps value with `Option<T>`
 * @param value A value need to be wrapped by `Option<T>`
 * @returns Returns `Some<T>` if value is not one of `undefined`, `NaN` or `null`.
 * Otherwise, return `None`
 */
declare function from$1<T>(value?: T): Option<T>;
/**
 * Wraps value with `Some<T>`
 * @param value A value need to be wrapped by `Some<T>`
 * @returns Returns `Some<T>`
 * @throws Thrown if value is one of `undefined`, `NaN` or `null`
 */
declare function some<T>(value: T): Some<T>;
/**
 * Initiates `None`
 * @returns Returns `None<T>`
 */
declare function none<T>(): None<T>;
/**
 * Wraps a result of `Promise<T>` with `Option<T>`
 * @param promise A promise
 * @returns Promise of `Some<T>` if Promise is resolved. If it rejected, returns `None`
 */
declare function fromPromise$1<T>(promise: Promise<T>): Promise<Option<T>>;

type option_Option<T> = Option<T>;
declare const option_Option: typeof Option;
type option_Some<T> = Some<T>;
declare const option_Some: typeof Some;
type option_None<T> = None<T>;
declare const option_None: typeof None;
declare const option_some: typeof some;
declare const option_none: typeof none;
declare namespace option {
  export {
    option_Option as Option,
    option_Some as Some,
    option_None as None,
    from$1 as from,
    option_some as some,
    option_none as none,
    fromPromise$1 as fromPromise,
  };
}

/**
 * Wraps value with `Result<T,Error>`
 * @param value A value need to be wrapped by `Result<T,E>`
 * @returns Returns `Ok<T,Error>` if value is not one of `undefined`, `NaN` or `null`.
 * Otherwise, return `Err<T,Error>`
 */
declare function from<T>(value?: T): Result<T, Error>;
/**
 * Wraps value with `Ok<T, E>`
 * @param value A value need to be wrapped by `Ok<T, E>`
 * @returns Returns `Ok<T, E>`
 * @throws Thrown if value is one of `undefined`, `NaN` or `null`
 */
declare function ok<T, E = Error>(value: T): Ok<T, E>;
/**
 * Wraps value with `Err<T, E>`
 * @param value A value need to be wrapped by `Err<T, E>`
 * @returns Returns `Err<T, E>`
 * @throws Thrown if value is one of `undefined`, `NaN` or `null`
 */
declare function err<T, E>(value: E): Err<T, E>;
/**
 * Wraps a result of `Promise<T>` with `Result<T, Error>`
 * @param promise A promise
 * @returns Promise of `Ok<T, Error>` if Promise is resolved. If it rejected, returns `Err<T, Error>`
 */
declare function fromPromise<T>(promise: Promise<T>): Promise<Result<T, Error>>;

type result_Result<T, E = Error> = Result<T, E>;
declare const result_Result: typeof Result;
type result_Ok<T, E> = Ok<T, E>;
declare const result_Ok: typeof Ok;
type result_Err<T, E> = Err<T, E>;
declare const result_Err: typeof Err;
declare const result_from: typeof from;
declare const result_ok: typeof ok;
declare const result_err: typeof err;
declare const result_fromPromise: typeof fromPromise;
declare namespace result {
  export {
    result_Result as Result,
    result_Ok as Ok,
    result_Err as Err,
    result_from as from,
    result_ok as ok,
    result_err as err,
    result_fromPromise as fromPromise,
  };
}

export { Err, Matcher$2 as Matcher, None, Ok, Option, Result, Some, Wrapper, option, result };
