import React, { useEffect } from "react";
import "./Modal.css";

const Modal = ({
  isOpen,
  onClose,
  children,
  overlayColor = "rgba(0, 0, 0, 0.5)",
  modalWidth = "500px",
  modalHeight = "auto",
  modalBackgroundColor = "#ffffff",
  closeButtonColor = "#000000",
  closeButtonSize = "24px",
  closeButtonPosition = { top: "10px", right: "10px" },
  showCloseButton = true,
  closeOnEscape = true,
  closeOnOverlayClick = true,
  customStyles = {},
}) => {
  useEffect(() => {
    const handleEscape = (event) => {
      if (closeOnEscape && event.key === "Escape") {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener("keydown", handleEscape);
    }

    return () => {
      document.removeEventListener("keydown", handleEscape);
    };
  }, [isOpen, onClose, closeOnEscape]);

  if (!isOpen) {
    return null;
  }

  const handleOverlayClick = (e) => {
    if (closeOnOverlayClick) {
      onClose();
    }
  };

  const modalStyles = {
    width: modalWidth,
    height: modalHeight,
    backgroundColor: modalBackgroundColor,
    ...customStyles,
  };

  return (
    <div
      className="modal-overlay"
      style={{ backgroundColor: overlayColor }}
      onClick={handleOverlayClick}
    >
      <div
        className="modal-content"
        style={modalStyles}
        onClick={(e) => e.stopPropagation()}
      >
        {showCloseButton && (
          <button
            className="modal-close"
            onClick={onClose}
            style={{
              color: closeButtonColor,
              fontSize: closeButtonSize,
              ...closeButtonPosition,
            }}
          >
            &times;
          </button>
        )}
        {children}
      </div>
    </div>
  );
};

export default Modal;
