# Softbinator Plugin Gas Estimator

A Hardhat plugin that estimate the deployment gas for contracts.

## What

This plugin will help you to estimate the cost of deployment for a contract, based on its size. It can return the estimated value of the deployment cost on several networks and display the value both in dollars and in the native currency of the network. This plugin also works with multiple contracts.

## Installation

To install this plugin use:

```bash
npm install --save-dev @softbinator/hardhat-gas-estimator hardhat-contract-sizer

```

Import the plugin in your `hardhat.config.js`:

```js
require("@softbinator/hardhat-gas-estimator");
```

Or if you are using TypeScript, in your `hardhat.config.ts`:

```ts
import "@softbinator/hardhat-gas-estimator";
```

Also, please read the documentation from hardhat-contract-sizer.

## Required plugins

- [hardhat-contract-sizer](https://github.com/ItsNickBarry/hardhat-contract-sizer#readme)

## Tasks

This plugin adds a task to estimate the deployment gas for contracts according to their size.

```
npx hardhat estimate-gas <sizeOfContracts>
```

Example:

```
npx hardhat estimate-gas 0.5
```

You can also specify the size of several contracts:
```
npx hardhat estimate-gas 5 2
```
In the example above, 5 is the size in KB of the first contract, and 2 is the size of the second.

You can specify the size of the contracts as a parameter for the task or you can configure your hardhat.config file according to the hardhat-contract-sizer documentation. By doing this, hardhat-contract-sizer will automatically generate size for your contracts and then our task will return the estimated cost for each of them.

Example without parameter:

```
npx hardhat estimate-gas
```

## Environment extensions

This plugin adds the function to estimate the deployment gas for your contracts to the Hardhat Runtime Environment.

```
hre.estimateGas(hre, contractSize?)
```

## Configuration

This plugin extends the HardhatUserConfig with a new object, named gasEstimator, with an optional `outputFile` field. You also have to add configuration from hardhat-contract-sizer if you want it to automatically calculate the size of the contracts.

This is an example of how to set it:

```js
const config: HardhatUserConfig = {
  gasEstimator: {
    outputFile: "./yourOutputFile.txt",
  },
};
```

## Usage

There are no additional steps you need to take for this plugin to work.

Install it and access the provided functions and the provided tasks through the Hardhat Runtime Environment anywhere you need it.
