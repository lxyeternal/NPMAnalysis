import { extendConfig, extendEnvironment } from "hardhat/config";
import { HardhatConfig, HardhatUserConfig } from "hardhat/types";
import { estimateGas } from "./estiamteGasFunction";
import "./tasks/estimate-gas";
import "./type-extensions";

extendConfig(
  (config: HardhatConfig, userConfig: Readonly<HardhatUserConfig>) => {
    config.gasEstimator = Object.assign(
      {
        outputFile: null,
      },
      userConfig.gasEstimator
    );
  }
);

extendEnvironment((hre) => {
  hre.estimateGas = estimateGas;
});
