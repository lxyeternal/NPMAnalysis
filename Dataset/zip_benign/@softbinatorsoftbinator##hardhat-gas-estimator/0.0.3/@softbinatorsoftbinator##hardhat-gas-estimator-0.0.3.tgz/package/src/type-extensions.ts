// If your plugin extends types from another plugin, you should import the plugin here.

// To extend one of Hardhat's types, you need to import the module where it has been defined, and redeclare it.
import "hardhat/types/config";
import "hardhat/types/runtime";

declare module "hardhat/types/config" {
  export interface HardhatUserConfig {
    gasEstimator?: {
      outputFile?: string;
    };
  }

  export interface HardhatConfig {
    gasEstimator: {
      outputFile: string;
    };
  }
}

declare module "hardhat/types/runtime" {
  export interface HardhatRuntimeEnvironment {
    estimateGas: (
      hre: HardhatRuntimeEnvironment,
      contractSize?: any
    ) => Promise<any>;
  }
}
