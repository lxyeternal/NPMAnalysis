import fs from "fs";
import { HardhatRuntimeEnvironment } from "hardhat/types";
import axios from "axios";

export const estimateGas = async (
  hre: HardhatRuntimeEnvironment,
  contractSize?: any
): Promise<any> => {
  let sizes: any[] = [];
  let names: any;

  if (contractSize !== undefined) {
    for (let i = 0; i < contractSize.length; i++) {
      sizes.push(Number(contractSize[i]));
    }
  } else {
    await hre.run("size-contracts");

    const result = fs.readFileSync("./outputs.txt", "utf8");

    const lineByLine = result.split("\n");
    const lineWithoutIntro = lineByLine.slice(5);

    let linesWithContractName: any[] = [];
    for (let i = 0; i < lineWithoutIntro.length; i++) {
      if (lineWithoutIntro[i].charAt(1) === "|") {
        linesWithContractName.push(lineWithoutIntro[i]);
      }
    }

    let resultOfContractSizer: any[] = [];
    for (let i = 0; i < linesWithContractName.length; i++) {
      const line = linesWithContractName[i].split("·");

      line.map((line: any) => {
        const lineWithoutSpaces = line.replace(/\s/g, "");
        const correctLine = lineWithoutSpaces.replace("|", "").replace("│", "");

        resultOfContractSizer.push(correctLine);
      });
    }

    let nameOfContracts: string[] = [];
    for (let i = 0; i < linesWithContractName.length; i++) {
      const nameOfContract = resultOfContractSizer[i * 3];
      nameOfContracts.push(nameOfContract);
    }

    names = nameOfContracts;

    let sizesInKB: string[] = [];
    for (let i = 0; i < linesWithContractName.length; i++) {
      const size = Number(resultOfContractSizer[i * 3 + 1]);
      const sizeInKB = ((size * 1000) / 1024).toFixed(3);

      sizesInKB.push(sizeInKB);
    }

    sizes = sizesInKB;
  }

  let estimateGasResult: any[] = [];
  for (let i = 0; i < sizes.length; i++) {
    const baseURL = `https://api-gas-estimator.softbinator.com/getGasEstimatedFromSizeOfContract?size=${sizes[i]}`;
    try {
      const response = await axios.get(baseURL, {
        headers: { "Content-Type": "application/json" },
      });

      const newResponse: any = {
        contractName: names !== undefined ? names[i] : `Contract ${i + 1}`,
        prices: response.data,
      };

      estimateGasResult.push(newResponse);
    } catch (error) {
      throw new Error(`Error: ${error}`);
    }
  }

  return estimateGasResult;
};
