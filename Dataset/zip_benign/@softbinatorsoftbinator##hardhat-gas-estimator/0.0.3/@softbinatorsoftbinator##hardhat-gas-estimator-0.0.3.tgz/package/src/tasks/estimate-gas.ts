import Table from "cli-table3";
import fs from "fs";
import { TASK_COMPILE } from "hardhat/builtin-tasks/task-names";
import { task } from "hardhat/config";
import { HardhatPluginError } from "hardhat/plugins";
import path from "path";
import stripAnsi from "strip-ansi";
import chalk from "chalk";

task("estimate-gas", "Output the gas from the size of compiled contracts")
  .addOptionalVariadicPositionalParam(
    "contractsize",
    "Set the size of the contract"
  )
  .setAction(async function (args, hre) {
    try {
      let pricesResponse: any;
      const config = hre.config.gasEstimator;

      if (args.contractsize) {
        pricesResponse = await hre.estimateGas(hre, args.contractsize);
      } else {
        pricesResponse = await hre.estimateGas(hre);
      }

      const table = new Table({
        style: { head: [], border: [], "padding-left": 2, "padding-right": 2 },
        chars: {
          mid: "·",
          "top-mid": "|",
          "left-mid": " ·",
          "mid-mid": "|",
          "right-mid": "·",
          left: " |",
          "top-left": " ·",
          "top-right": "·",
          "bottom-left": " ·",
          "bottom-right": "·",
          middle: "·",
          top: "-",
          bottom: "-",
          "bottom-mid": "|",
        },
      });

      table.push([
        {
          content: chalk.bold("ContractName"),
        },
        {
          content: chalk.bold("Network"),
        },
        {
          content: chalk.bold("Price in Native Currency"),
        },
        {
          content: chalk.bold("Price in Dollars"),
        },
      ]);

      for (let i = 0; i < pricesResponse.length; i++) {
        for (let j = 0; j < pricesResponse[i].prices.length; j++) {
          table.push([
            j % 7 === 0
              ? { content: chalk.bold(pricesResponse[i].contractName) }
              : { content: "" },
            { content: chalk.yellow(pricesResponse[i].prices[j].network) },
            {
              content: chalk.green(
                `${pricesResponse[i].prices[j].priceInNativeCurrency} ${pricesResponse[i].prices[j].nativeCurrency}`
              ),
              hAlign: "right",
            },
            {
              content: chalk.green(
                `${pricesResponse[i].prices[j].priceInDollar} $`
              ),
              hAlign: "right",
            },
          ]);
        }
      }

      console.log(table.toString());

      if (config.outputFile) {
        fs.writeFileSync(config.outputFile, `${stripAnsi(table.toString())}\n`);
      }
    } catch (err) {
      console.log(`Failed to estiamte gas: ${err}`);
    }
  });
