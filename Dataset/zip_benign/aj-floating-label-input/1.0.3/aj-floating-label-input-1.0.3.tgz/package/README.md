### Floating Label Input with customization and default props
# Installation

For react native project..

```sh
$ npm install aj-floating-label-input
```

# Usage
For react native project follow the following steps
### 1) Import Library
```sh
import FloatingLabelInput from 'aj-floating-label-input'
```
### 2) add the Input Field as following
```sh
 <FloatingLabel
                        onChangeText={value => setPassword(value)} 
                        focusBorderColor={ThemeColors.ThemeColorPrimary}
                        focusLabelColor={ThemeColors.ThemeColorPrimary}
                        blurBorderColor="#AAA"
                        blurLabelColor="#AAA"
                        floatingLabel="Password"
                        secureTextEntry={true}
                        inputStyle={{}}
                        labelStyle={{}}
                        floatedStyle={{ fontSize: 10, top: 3, }}
                        unfloatedStyle={{ fontSize: 11, top: 12, }}
                        containerStyle={{ borderRadius: 50, borderWidth: 0.5 }}
                    />
```
## Demo

<img src="https://i.ibb.co/NTmpTnY/ajfloatinglabelinput.gif" width="400"/>

## Contributions 
Contributions, issues and feature requests are welcome.
Feel free to check [issues](https://github.com/abidjamil/Floating-Label-Input/issues "issues") page if you want to contribute.

## About Me
My name is Abid Jamil from Pakistan, I am Senior Software Engineer at Nextbridge Ltd Pakistan. I have expertise in Native Android | React - Native | IOS | Android | Java | Kotlin | Javascript | MVVM | MVP | RxJava | Dagger | Material Design | Live Data | Data Binding. Futhermore, I am open source contribution and computer science researcher. I have published 17 research paper which is avaiable on [Google Scholar Profile](https://scholar.google.com/citations?user=sl7oXNsAAAAJ&hl=en "Google Scholar Profile").  I have delivered many talks in different national and International universities around the globe. 

- Github : [abidjamil ](https://github.com/abidjamil "abidjamil ")
- Youtube : [Abid Jamil](https://www.youtube.com/c/abidjamil "Abid Jamil")
- Facebook : [Abid Jamil](http://www.facebook.com/chabidgill "Abid Jamil")
