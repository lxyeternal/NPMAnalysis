import React, { Component } from 'react';
import PropTypes from 'prop-types';
import createReactClass from 'create-react-class';

import {
    StyleSheet,
    TextInput,
    Animated,
    Easing,
    Text,
    View,
    Platform,
    ViewPropTypes
} from 'react-native';

var labelProps = Text.propTypes || ViewPropTypes
var inputProps = TextInput.propTypes || labelProps
var propTypes = {
    ...inputProps,
    inputStyle: inputProps.style,
    labelStyle: labelProps.style,
    disabled: PropTypes.bool,
    style: ViewPropTypes.style,

}

var FloatingLabelInput = createReactClass({
    propTypes: propTypes,

    getInitialState() {
        var state = {
            text: this.props.value,
            floated: (this.props.value || this.props.placeholder)
        };

        var style = state.floated ? floatedStyle : unfloatedStyle
        state.labelStyle = {
            fontSize: new Animated.Value(style.fontSize),
            top: new Animated.Value(style.top)
        }

        return state
    },

    UNSAFE_componentWillReceiveProps(props) {
        if (typeof props.value !== 'undefined' && props.value !== this.state.text) {
            this.setState({ text: props.value, floated: !!props.value })
            this._animate(!!props.value)

        }
    },

    _animate(floated) {
        var nextStyle = floated ? this.props.floatedStyle || floatedStyle : this.props.unfloatedStyle || unfloatedStyle
        var labelStyle = this.state.labelStyle
        var anims = Object.keys(nextStyle).map(prop => {
            return Animated.timing(
                labelStyle[prop],
                {
                    toValue: nextStyle[prop],
                    duration: 200,
                    useNativeDriver: false,
                },
                Easing.ease
            )
        })

        Animated.parallel(anims).start()
    },

    _onFocus() {
        this._animate(true)
        this.setState({ floated: true, borderColor: this.props.focusBorderColor, labelColor: this.props.focusLabelColor })
        if (this.props.onFocus) {
            this.props.onFocus(arguments);
        }
    },

    _onBlur() {
        if (!this.state.text) {
            this._animate(false)
            this.setState({ floated: false, borderColor: this.props.blurBorderColor, labelColor: this.props.blurLabelColor });
        }

        if (this.props.onBlur) {
            this.props.onBlur(arguments);
        }
    },

    onChangeText(text) {
        this.setState({ text })
        if (this.props.onChangeText) {
            this.props.onChangeText(text)
        }
    },

    updateText(event) {
        var text = event.nativeEvent.text
        this.setState({ text })

        if (this.props.onEndEditing) {
            this.props.onEndEditing(event)
        }
    },

    _renderLabel() {
        return (
            <Animated.Text
                ref='label'
                style={{ ...this.state.labelStyle, ...styles.label, ...this.props.labelStyle, color: this.state.labelColor }}>
                {this.props.floatingLabel}
            </Animated.Text >
        )
    },

    render() {
        var props = {
            autoCapitalize: this.props.autoCapitalize,
            autoCorrect: this.props.autoCorrect,
            autoFocus: this.props.autoFocus,
            bufferDelay: this.props.bufferDelay,
            clearButtonMode: this.props.clearButtonMode,
            clearTextOnFocus: this.props.clearTextOnFocus,
            controlled: this.props.controlled,
            editable: this.props.editable,
            enablesReturnKeyAutomatically: this.props.enablesReturnKeyAutomatically,
            keyboardType: this.props.keyboardType,
            multiline: this.props.multiline,
            numberOfLines: this.props.numberOfLines,
            onBlur: this._onBlur,
            onChange: this.props.onChange,
            onChangeText: this.onChangeText,
            onEndEditing: this.updateText,
            onFocus: this._onFocus,
            onSubmitEditing: this.props.onSubmitEditing,
            password: this.props.secureTextEntry || this.props.password, // Compatibility
            placeholder: this.props.placeholder,
            secureTextEntry: this.props.secureTextEntry || this.props.password, // Compatibility
            returnKeyType: this.props.returnKeyType,
            selectTextOnFocus: this.props.selectTextOnFocus,
            selectionState: this.props.selectionState,
            style: [styles.input, this.props.inputStyle],
            testID: this.props.testID,
            value: this.state.text,
            underlineColorAndroid: this.props.underlineColorAndroid, // android TextInput will show the default bottom border
            onKeyPress: this.props.onKeyPress,
            focusBorderColor: this.props.focusBorderColor,
            blurBorderColor: this.props.blurBorderColor,
        },
            elementStyles = [styles.element];

        if (this.props.inputStyle) {
            props.style.push(this.props.inputStyle);
        }

        if (this.props.style) {
            elementStyles.push(this.props.style);
        }

        return (
            <View style={{ ...elementStyles, ...this.props.containerStyle, borderColor: this.state.borderColor }}>
                {this._renderLabel()}
                <TextInput
                    {...props}
                />



            </View>
        );
    },
});

var labelStyleObj = {
    marginTop: 4.5,
    paddingLeft: 20,
    color: '#AAA',
    position: 'absolute'
}

if (Platform.OS === 'web') {
    labelStyleObj.pointerEvents = 'none'
}

var styles = StyleSheet.create({
    element: {
        position: 'relative'
    },
    input: {
        borderColor: 'gray',
        backgroundColor: 'transparent',
        borderWidth: 0,
        color: '#AAA',
        fontSize: 10,
        borderRadius: 50,
        paddingLeft: 20,
        marginTop: 6,
        marginBottom: -2,
    },
    label: labelStyleObj
})

var unfloatedStyle = {
    fontSize: 11,
    top: 12,

}

var floatedStyle = {
    fontSize: 8,
    top: 3,
}

module.exports = FloatingLabelInput;
