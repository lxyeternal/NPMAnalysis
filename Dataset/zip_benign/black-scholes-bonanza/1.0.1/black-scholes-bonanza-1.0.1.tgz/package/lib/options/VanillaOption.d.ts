import { BaseOption } from './BaseOption';
/**
 * Vanilla call or put option
 * At expiry, a call pays `max(0, spot - strike)` while a put pays `max(0, strike - spot)`
 */
export declare class VanillaOption extends BaseOption {
    getPayoff(spot: number): number;
    getPrice(spot: number): number;
    getDelta(spot: number): number;
    getGamma(spot: number): number;
    getVega(spot: number): number;
    getTheta(spot: number): number;
    getRho(spot: number): number;
}
