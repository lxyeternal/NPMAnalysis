import { BaseOption } from './BaseOption';
/**
 * Digital call or put option, also known as Binary option or Cash-or-Nothing option.
 * At expiry, a digital call pays `spot >= strike ? 1 : 0` while a digital put pays `spot <  strike ? 1 : 0`
 * For convention, the `=` is paid only for the call
 */
export declare class DigitalOption extends BaseOption {
    getPayoff(spot: number): number;
    getPrice(spot: number): number;
    getDelta(spot: number): number;
    getGamma(spot: number): number;
    getVega(spot: number): number;
    getTheta(spot: number): number;
    getRho(spot: number): number;
}
