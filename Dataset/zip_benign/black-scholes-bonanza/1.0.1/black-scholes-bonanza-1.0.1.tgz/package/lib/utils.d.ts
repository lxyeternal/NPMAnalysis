/**
 * Sum all the elements in the array
 * @param arr an array of numbers
 * @return the sum
 */
export declare const sumArray: (arr: number[]) => number;
/**
 * Sum product of arrays.
 * First multiplies elements with the same index and then sums all the results.
 * @param arr1 an array
 * @param arr2 another array
 * @returns the sum product of the arrays
 */
export declare const sumProduct: (arr1: number[], arr2: number[]) => number;
