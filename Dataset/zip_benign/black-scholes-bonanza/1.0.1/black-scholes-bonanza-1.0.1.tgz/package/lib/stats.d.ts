/**
 * Computes the PDF of a standard normal distribution
 * @param x a real number
 * @returns the PDF of x
 */
export declare const normalPdf: (x: number) => number;
/**
 * Computes the DF of a standard normal distribution
 * @param x a real number
 * @returns the CDF of x
 */
export declare const normalCdf: (x: number) => number;
/**
 * Computes the inverse CDF of a standard normal distribution
 * @param p the probability, between (0, 1)
 * @returns x such that CDF(x) = p
 */
export declare const inverseNormalCdf: (p: number) => number;
