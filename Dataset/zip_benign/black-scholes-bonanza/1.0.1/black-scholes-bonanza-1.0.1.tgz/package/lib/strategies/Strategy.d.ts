import { BaseOption } from '../options';
/**
 * A strategy is a linear combination of options
 */
export declare abstract class Strategy {
    protected abstract options: BaseOption[];
    protected abstract weights: number[];
    getPayoff(spot: number): number;
    getPrice(spot: number): number;
    getDelta(spot: number): number;
    getGamma(spot: number): number;
    getVega(spot: number): number;
    getTheta(spot: number): number;
    getRho(spot: number): number;
}
