import { VanillaOption } from '../options';
import { Strategy } from './Strategy';
export declare class Butterfly extends Strategy {
    options: [VanillaOption, VanillaOption, VanillaOption];
    weights: [number, number, number];
    /**
     * A butterfly (or "fly") is a strategy which combines two long positions at the tails and a 2x short position in the middle
     * @param vols an array with three volatilies
     * @param rate the interest rate
     * @param time time to expiry in years
     * @param strikes an array with three strikes
     * @param isCall whether is a call fly (`true`) or put fly (`false`)
     */
    constructor(vols: number[], rate: number, time: number, strikes: number[], isCall: boolean);
}
