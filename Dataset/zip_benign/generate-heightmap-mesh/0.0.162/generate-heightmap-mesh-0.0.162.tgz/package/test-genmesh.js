
var gen = require('./index.js');

var resolution = 256;
var size = 64;
var boundingBox_XZ = [[-size,0,-size],[size,0,size]];
var df = gen.dfHillsWorld2D; //default distance function - see also dfHillsWorld2D_smooth
var yCoordinate=-10.0; //y-coord to use in 3d distance function sampler
var df_scaleXZ=100.0; //scale df along x-z, default 100 -- you can leave this constant to have the bounding box reveal more land as it expands, OR make this value proportional to the bounding box, to have the result expand to the same size as the bounding box
var df_scaleY=4; //scale result height, default 4
var postSimplifyFactor=0.25;//0.25; //default 1 [no simplify] -- if less than 1, decimate triangles to the fraction indicated



var fs = require('fs');
var stl = require('stl');
var t2o = require('./triangles2Object.js');
var doAddSkirt = true;
var skirtY = -10;
var triangles = gen.generateHeightmapMeshXZ(resolution, boundingBox_XZ, df, yCoordinate, df_scaleXZ, df_scaleY, postSimplifyFactor, doAddSkirt, skirtY);

var objectToSave = t2o.convertTrianglesToObject(triangles, "mesh output");
var isBinary = true;
var fname = `heightmap_mesh.stl`;
fs.writeFileSync(fname, stl.fromObject(objectToSave, isBinary));
console.log('wrote mesh', fname);
