//reduced memory load
function convertTrianglesToObject(triangles, description = "") {
    const facets = [];
    for (let i = 0; i < triangles.length; i++) {
        const triangle = triangles[i];
        const facet = {
            normal: calculateTriangleNormal(triangle),
            verts: triangle,
            // attributeByteCount: 0 // Set the attribute byte count here if applicable
        };
        facets.push(facet);
    }

    const obj = {
        description: description,
        facets: facets
    };

    return obj;
}

function calculateTriangleNormal(triangle) {
    const u0 = triangle[1][0] - triangle[0][0];
    const u1 = triangle[1][1] - triangle[0][1];
    const u2 = triangle[1][2] - triangle[0][2];

    const v0 = triangle[2][0] - triangle[0][0];
    const v1 = triangle[2][1] - triangle[0][1];
    const v2 = triangle[2][2] - triangle[0][2];

    const normal = [
        u1 * v2 - u2 * v1,
        u2 * v0 - u0 * v2,
        u0 * v1 - u1 * v0
    ];

    return normal;
}


function flipTriangleNormal(triangle) {
    const flippedTriangle = [
        triangle[2],
        triangle[1],
        triangle[0]
    ];

    return flippedTriangle;
}

module.exports = {convertTrianglesToObject, calculateTriangleNormal, flipTriangleNormal};

//var stl = require('stl');
//var objectToSave = convertTrianglesToObject(simplifiedTriangles, "earth");
//var isBinary = true;
//require('fs').writeFileSync(`object.stl`, stl.fromObject(objectToSave, isBinary));