import { node, raw, TimeStamp } from "../../../models";
export declare class Project implements node.IProject {
    static slug: 'project';
    readonly slug: "project";
    created_at: TimeStamp;
    group: string;
    name: string;
    notes: string;
    private _files;
    private _materials;
    private _collections;
    public: boolean;
    uid: string;
    updated_at: TimeStamp;
    url: string;
    get collections(): string;
    get files(): string;
    get materials(): string;
    constructor(raw?: Partial<raw.Project>);
    loadState(raw: Partial<raw.Project>): void;
    saveState(): Required<raw.Project>;
}
