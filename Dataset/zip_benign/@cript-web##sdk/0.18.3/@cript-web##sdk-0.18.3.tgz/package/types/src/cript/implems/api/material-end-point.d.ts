import { IClient, node, raw } from "../../models";
import { IMaterialEndPoint } from "../../models/api/material-end-point";
import { GenericEndPoint } from "./generic-end-point";
export declare class MaterialEndPoint extends GenericEndPoint<node.IMaterial, raw.Material> implements IMaterialEndPoint {
    constructor(api: IClient);
    setMolBlock(node: node.IMaterial, _molblock: string | null): Promise<any>;
    getMolBlock(node: node.IMaterial): Promise<string | null>;
}
