import { IEndPoint, IClient, node, IExperimentEndPoint } from "../../models";
import { IMaterialEndPoint } from "../../models/api/material-end-point";
/**
 * End point factory to create easily an endpoint for a given node type.
 */
export declare class EndPointFactory {
    static createCollectionEndPoint(api: IClient): IEndPoint<node.ICollection>;
    static createDataEndPoint(api: IClient): IEndPoint<node.IData>;
    static createExperimentEndPoint(api: IClient): IExperimentEndPoint;
    static createFileEndPoint(api: IClient): IEndPoint<node.IFile>;
    static createGroupEndPoint(api: IClient): IEndPoint<node.IGroup>;
    static createInventoryEndPoint(api: IClient): IEndPoint<node.IInventory>;
    static createMaterialEndPoint(api: IClient): IMaterialEndPoint;
    static createProcessEndPoint(api: IClient): IEndPoint<node.IProcess>;
    static createProjectEndPoint(api: IClient): IEndPoint<node.IProject>;
    static createReferenceEndPoint(api: IClient): IEndPoint<node.IReference>;
    static createUserEndPoint(api: IClient): IEndPoint<node.IUser>;
}
