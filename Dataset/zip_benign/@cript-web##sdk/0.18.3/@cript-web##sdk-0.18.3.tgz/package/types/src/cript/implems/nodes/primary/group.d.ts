import { node, raw, TimeStamp } from "../../../models";
export declare class Group implements node.IGroup {
    static slug: 'group';
    readonly slug: "group";
    created_at: TimeStamp;
    email: string;
    name: string;
    public: boolean;
    uid: string;
    url: string;
    updated_at: TimeStamp;
    users: string[];
    constructor(raw?: Partial<raw.Group>);
    hasUser(_userUrl: string): boolean;
    loadState(raw: Partial<raw.Group>): void;
    saveState(): Required<raw.Group>;
    add_user(data: raw.User | node.IUser): Promise<node.IUser>;
    remove_user(data: number | node.IUser): Promise<number>;
}
