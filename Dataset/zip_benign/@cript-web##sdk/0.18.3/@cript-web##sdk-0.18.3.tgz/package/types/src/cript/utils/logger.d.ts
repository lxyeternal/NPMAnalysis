/**
 * WebSDK logger, to format and handle all logs at the same place.
 *
 * For now this class wrapps console.xxx() functions, but might be used to
 * send log to a server.
 */
declare class Logger {
    private prefix;
    constructor(prefix: string);
    info(...args: any[]): void;
    log(...args: any[]): void;
    warn(...args: any[]): void;
    error(...args: any[]): void;
}
/** Logger factory to create a logger with a specific name */
export declare function getLogger(name: string): Logger;
/** General logger */
export declare const logger: Logger;
export {};
