import { raw } from "../raw";
import { APIVersion } from "../types";
import { ControlledVocabulary } from "./vocab";
/**
 * To document.
 */
export declare type StorageInfo = {
    provider: string;
    path: string;
    max_file_size: number;
    endpoint_id: string;
    native_client_id: string;
};
/**
 * Data sent by the api for the /api/session-info/ endpoint
 */
export declare type SessionInfo = {
    /** predefined warning message, to display in case there is a version mismatch */
    version_warning: string;
    /** @deprecated Controlled vocabulary, renamed "vocab" in 0.6.0 */
    keys: ControlledVocabulary;
    /** Controlled vocabulary, known as "keys" before 0.6.0 */
    vocab: ControlledVocabulary;
    /** The current user logged */
    user_info: raw.User;
    /** The version available on the backend */
    latest_version: APIVersion;
    storage_info: StorageInfo;
    content: unknown;
    status_code: number;
};
