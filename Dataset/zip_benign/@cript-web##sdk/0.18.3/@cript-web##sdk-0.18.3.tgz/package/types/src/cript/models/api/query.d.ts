/**
 * Define a search (query and optionnal params)
 * Items returned will be [offset, offset+limit]
 */
export declare type PaginationParams = {
    /** Index of the first item to return */
    offset: number;
    /** Item max count to return */
    limit: number;
};
/**
 * Base query
 */
export declare type IQuery = {
    /** Optionnal pagination parameters  */
    params: PaginationParams;
    /** Optionnal body */
    body?: {
        [key: string]: any;
    };
};
