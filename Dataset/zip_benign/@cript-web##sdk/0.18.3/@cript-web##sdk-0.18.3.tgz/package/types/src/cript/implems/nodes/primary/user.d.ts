import { node, raw, TimeStamp } from "../../../models";
export declare class User implements node.IUser {
    static slug: 'user';
    readonly slug: "user";
    created_at: TimeStamp;
    email: string;
    name: string;
    orcid_id: string;
    public: boolean;
    uid: string;
    updated_at: TimeStamp;
    url: string;
    username: string;
    constructor(raw?: Partial<raw.User>);
    loadState(raw: Partial<raw.User>): void;
    saveState(): Required<raw.User>;
}
