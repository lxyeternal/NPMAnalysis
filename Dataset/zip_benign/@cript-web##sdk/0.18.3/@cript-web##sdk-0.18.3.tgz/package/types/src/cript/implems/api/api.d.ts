import { IClient, Config, ClientStatus, ControlledVocabulary, StorageInfo, IEndPoint, Slug, node, APIVersion, IMaterialEndPoint, IExperimentEndPoint } from "../../models";
import { http } from "../../utils";
import { User } from "../nodes/primary/user";
/**
 * Default APIClient implementation.
 */
export declare class APIClient implements IClient {
    #private;
    baseUrl: string;
    config: Config;
    status: ClientStatus;
    controlledVocabulary: ControlledVocabulary | null;
    storageInfo: StorageInfo | null;
    latestVersion: APIVersion;
    supportedVersion: APIVersion;
    user: User | null;
    readonly httpClient: http.IClient;
    readonly collections: IEndPoint<node.ICollection>;
    readonly data: IEndPoint<node.IData>;
    readonly files: IEndPoint<node.IFile>;
    readonly groups: IEndPoint<node.IGroup>;
    readonly inventories: IEndPoint<node.IInventory>;
    readonly materials: IMaterialEndPoint;
    readonly processes: IEndPoint<node.IProcess>;
    readonly projects: IEndPoint<node.IProject>;
    readonly references: IEndPoint<node.IReference>;
    readonly users: IEndPoint<node.IUser>;
    readonly experiments: IExperimentEndPoint;
    constructor(config: Config);
    getEndPoint(slug: Slug): IEndPoint<node.AnyPrimary>;
    canEdit(_node: {
        group: string;
    }, _user?: node.IUser | null): Promise<boolean>;
    connect(): Promise<void>;
    /**
     * Try to fix any mismatch version
     * @param _connectionResponse
     */
    private try_fix_mismatch_version;
    /**
     * starting v0.6.0 the "keys" is named "vocab"
     * @param _connectionResponse
     */
    private try_fix_keys_renamed_vocab;
}
