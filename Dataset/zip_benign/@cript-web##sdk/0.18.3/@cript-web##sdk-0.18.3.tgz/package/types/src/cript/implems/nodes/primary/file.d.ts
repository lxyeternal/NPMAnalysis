import { node, raw } from "../../../..";
import { TimeStamp } from "../../../models/types";
export declare class File implements node.IFile {
    static slug: 'file';
    readonly slug: "file";
    checksum: string;
    created_at: TimeStamp;
    data: string | string[];
    extension: string;
    group: string;
    name: string;
    project: string;
    public: boolean;
    type: string;
    uid: string;
    unique_name: string;
    updated_at: TimeStamp;
    url: string;
    constructor(raw?: Partial<raw.File>);
    loadState(raw: Partial<raw.File>): void;
    saveState(): Required<raw.File>;
    add_data(data: raw.Data | node.IData): Promise<node.IData>;
    remove_data(data: number | node.IData): Promise<void>;
}
