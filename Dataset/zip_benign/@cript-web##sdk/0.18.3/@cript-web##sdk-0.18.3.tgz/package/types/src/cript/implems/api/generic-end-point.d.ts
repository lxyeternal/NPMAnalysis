import { IPaginator, PaginationParams, SearchParams, IEndPoint, node, raw } from "../../models";
import { http } from "../../utils";
/**
 * This class allows to get/save/refresh/detAll/search/... any primary node class
 * @param rawT is the type expected to get from the server
 * @param T is the class that will returned o the user
 */
export declare class GenericEndPoint<T extends node.IPrimary, rawT extends raw.IPrimary> implements IEndPoint<T> {
    /** Abstract layer to perform http requests */
    readonly httpClient: http.IClient;
    /** Base URL for this endpoint */
    readonly baseUrl: `${string}/`;
    /** Search URL specific to this endpoint */
    readonly searchUrl: `${string}/`;
    /** The mapper arrow function takes a raw type and return a class instance */
    private factory;
    /** Default pagination parameters applied when none are specified */
    private defaultPaginationParams;
    /**
     *
     * @param factory arrow function to build a T from a rawT
     * @param httpClient http client
     * @param baseUrl base URL for requests (do not include '/')
     * @param slug node slug (ex: 'project' | 'collection' | ...)
     */
    constructor(factory: (state: rawT) => Promise<T>, httpClient: http.IClient, baseUrl: string, slug: T['slug'], defaultPaginationParams?: PaginationParams);
    getAllFromUrl(url: string, params?: PaginationParams): Promise<IPaginator<T>>;
    refresh(node: T): Promise<T>;
    getAll(params?: PaginationParams): Promise<IPaginator<T>>;
    search(searchParams: SearchParams, paginationParams?: PaginationParams): Promise<IPaginator<T>>;
    /**
     * Make a paginator
     * @param callback function to get a page from a given query
     * @param query initial query
     * @returns
     */
    private makePaginator;
    /**
     * Get an instance from its uid
     * @param uid the uniaue id of an existing instance
     * @returns
     */
    getFromUid(uid: T['uid']): Promise<T>;
    /**
     * Get an instance from its uid
     * @param url the URL of the node
     * @returns
     */
    getFromUrl(url: T['url']): Promise<T>;
    /**
     * Get an array of instances from their URL.
     * Requests are made in parallel
     * @param urls the URL of the node
     * @returns
     */
    getArrayFromUrls(urls: T['url'][]): Promise<T[]>;
    delete(uid: string): Promise<boolean>;
    save(node: T): Promise<T>;
    nameExists(name: string): Promise<boolean>;
}
