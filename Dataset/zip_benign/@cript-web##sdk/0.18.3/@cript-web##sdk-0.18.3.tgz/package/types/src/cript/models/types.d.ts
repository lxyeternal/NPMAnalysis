/**
 * This file contains basic types (no interfaces)
 */
/** Type for CRIPT's API version (major.minor.patch) */
export declare type APIVersion = `${number}.${number}.${number}`;
/** TimeStamp using ISO_8601 notation (@see https://en.wikipedia.org/wiki/ISO_8601, example "2022-05-09T19:58:55.388248Z") */
export declare type TimeStamp = `${number}-${number}-${number}T${number}:${number}:${number}.${number}Z` | '';
/** Alias for string, just to help reading code */
export declare type URL = string;
/** Alias for string, just to help reading code */
export declare type Unit = string;
