/**
 * Helper for http related stuff.
 */
export declare namespace http {
    /**
     * Structure to store an http response
     */
    type Response<T> = {
        status_code: number;
        body?: T;
    };
    /**
     * Common interface for any http client
     */
    interface IClient {
        /** To set the Json Web Token, will be added to the headers automatically for each request */
        setJwtAccessToken(accessToken: string): void;
        /** Global headers, used for each request */
        headers?: HeadersInit;
        /**
         * Perform a GET request with an optionnal body
         * @param url  an absolute url
         * @param body an object able to be converted to JSON
         * @returns a response of the expected type T
         */
        get<T>(url: string, body?: {
            [key: string]: any;
        }): Promise<Response<T>>;
        /**
        * Perform a POST request with an optionnal body
        * @param url an absolute url
        * @param body an object able to be converted to JSON
        * @returns a response of the expected type T
        */
        post<T>(url: string, body?: {
            [key: string]: any;
        }): Promise<Response<T>>;
        /**
         * Perform a DELETE request with an optionnal body
         * @param url an absolute url
         * @param body an object able to be converted to JSON
         * @returns a response of the expected type T
         */
        delete<T>(url: string): Promise<Response<T>>;
        /**
         * Perform a PATCH (update) request with an optionnal body
         * @param url an absolute url
         * @param body an object able to be converted to JSON
         * @returns a response of the expected type T
         */
        patch<T>(url: string, body?: {
            [key: string]: any;
        }): Promise<Response<T>>;
        /**
         * Perform a PUT (first time data is sent) request with an optionnal body
         * @param url an absolute url
         * @param body an object able to be converted to JSON
         * @returns a response of the expected type T
         */
        put<T>(url: string, body?: {
            [key: string]: any;
        }): Promise<Response<T>>;
    }
    /**
     * Factory to create a new http client
     * @returns an IClient implementation
     */
    function newClient(): IClient;
}
