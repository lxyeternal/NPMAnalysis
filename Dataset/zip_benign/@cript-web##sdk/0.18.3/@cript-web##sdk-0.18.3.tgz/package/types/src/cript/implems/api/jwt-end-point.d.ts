import { http } from "../../utils";
/**
 * Data model for refreshing the JWT
 */
export declare type JWTPayload = {
    /** Refresh token*/
    refresh: string;
    /** Access token */
    readonly access?: string;
};
export declare class JWTEndPoint {
    #private;
    /** Access token, is received from server after calling refresh() */
    accessToken: string;
    constructor(httpClient: http.IClient, baseUrl: string);
    /**
     * Start automatic refresh given a certain delay
     * @param payload
     * @param delayInMs delay in milliseconds (default is 4min)
     * @returns
     */
    startAutoRefresh(payload: JWTPayload, delayInMs?: number): Promise<boolean>;
    /**
     * Refresh JWT once
     * @param payload
     * @returns
     */
    private refresh;
}
