import { PaginationParams } from "../models/api";
/**
 * Namespace to access URL related utility
 */
export declare namespace UrlUtils {
    /**
     * Clean the hostname provided by the user and generate a URL.
     * @param host Hostname of the endpoint
     * @param tls Indicates whether to use TLS encryption for the API connection
     * @param path specify an extra path to be added and the end of the url
     * @returns An url like `${protocol}://${cleanHost}${path}`
     */
    function makeApiUrl(host: string, tls: boolean, path?: `/${string}` | ''): string;
    /**
    * Make a paginated URL from a base URL and pagination parameters
    * @param url
    * @param params
    */
    function makePaginatedUrl(url: string, params: PaginationParams): string;
}
