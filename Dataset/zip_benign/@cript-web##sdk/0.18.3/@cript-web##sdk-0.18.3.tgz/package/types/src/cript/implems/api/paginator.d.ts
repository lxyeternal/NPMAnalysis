import { IPaginator, IQuery, Page, SearchQuery, node } from "../../models";
/**
 * Type of a function able to return a Page<T> from a given SearchQuery
 */
export declare type GetPageCallback<T> = (query: SearchQuery) => Promise<Page<T>>;
/**
 * Node paginator implementation
 * Can handle any primary node implementation's instances.
 */
export declare class NodePaginator<T extends node.IPrimary> implements IPaginator<T> {
    #private;
    /**
     * @param initState object containing a callback able to get a new page, the current page and the query
     */
    constructor(initState: {
        getPage: GetPageCallback<T>;
        currentPage: Page<T>;
        query: Required<IQuery>;
    });
    /** @deprecated use pageCount instead */
    get count(): number;
    get itemCount(): number;
    refresh(): Promise<Page<T>>;
    get pageCount(): number;
    get hasNext(): boolean;
    get hasPrevious(): boolean;
    setCurrentPageIndex(pageIndex: number): Promise<Page<T>>;
    get currentPage(): Page<T>;
    next(): Promise<Page<T>>;
    previous(): Promise<Page<T>>;
    get currentPageIndex(): number;
}
