import { node } from "../models";
/**
 * Util functions to play with Nodes
 */
export declare namespace NodeUtils {
    /** Shortcut to get nodes having a direct parent */
    type AnyNodeWithParent = node.ICollection | node.IMaterial | node.IData | node.IProcess | node.IExperiment | node.IInventory;
    /** Set node's parent URL */
    export function set_parent(node: AnyNodeWithParent, url: string): void;
    /** Get node's parent URL */
    export function get_parent(node: any): string | undefined;
    /** Return true if two nodes share the same parent, false otherwise */
    export function has_same_parent(node1: AnyNodeWithParent, node2: AnyNodeWithParent): boolean;
    export {};
}
