import { node, IEndPoint } from "..";
/**
 * End point specific for Materials.
 * Provide methods such as getMolfile and getGraph
 */
export interface IMaterialEndPoint extends IEndPoint<node.IMaterial> {
    /**
     * Get a molfile for a given material (compatible with RDKit)
     * @see https://docs.rdkitjs.com/interfaces/RDKitModule.html
    */
    getMolBlock(node: node.IMaterial): Promise<string | null>;
    /**
    * Set a molfile on a given material
    * @see https://docs.rdkitjs.com/interfaces/RDKitModule.html
   */
    setMolBlock(node: node.IMaterial, molfile: string | null): Promise<any>;
}
