import { node, raw, TimeStamp } from "../../../models";
/**
 * Implementation of node.IReference
 */
export declare class Reference implements node.IReference {
    static slug: 'reference';
    readonly slug: "reference";
    arxiv_id: string;
    authors: string[];
    created_at: TimeStamp;
    doi: string;
    group: string;
    issn: string;
    issue: string;
    journal: string;
    name: string;
    notes: string;
    pages: string[];
    pmid: string;
    public: boolean;
    publisher: string;
    title: string;
    uid: string;
    updated_at: TimeStamp;
    url: string;
    volume: string;
    website: string;
    year: string;
    constructor(raw?: Partial<raw.Reference>);
    loadState(raw: Partial<raw.Reference>): void;
    saveState(): Required<raw.Reference>;
}
