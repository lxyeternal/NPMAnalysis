import { node } from "../../../models/nodes";
import { raw } from "../../../models/raw";
import { TimeStamp } from "../../../models/types";
export declare class Collection implements node.ICollection {
    static slug: 'collection';
    readonly slug: "collection";
    citations: string[];
    created_at: TimeStamp;
    experiments: string;
    group: string;
    inventories: string;
    name: string;
    notes: string;
    project: string;
    public: boolean;
    uid: string;
    updated_at: TimeStamp;
    url: string;
    constructor(raw?: Partial<raw.Collection>);
    loadState(rawData?: Partial<raw.Collection>): void;
    saveState(): Required<raw.Collection>;
    add_citation(citation: raw.Citation | node.ICitation): Promise<void>;
    remove_citation(citation: number | raw.Citation): Promise<void>;
}
