/**
 * Define the struture of an Page.
 */
export interface Page<T> {
    /** total result count (!= result's length) */
    count: number;
    /** URL to the next result */
    next: string | null;
    /** URL to the previous result */
    previous: string | null;
    /** page */
    results: Array<T>;
}
/**
 * Interface for any Paginator implementation
 */
export interface IPaginator<T> {
    /** Get the page count */
    get pageCount(): number;
    /** Get the total item count (short hand of currentPage.count ) */
    get itemCount(): number;
    /** Get the page count @deprecated use pageCount instead */
    get count(): number;
    /** Get current page */
    get currentPage(): Page<T>;
    /** Get current page index */
    get currentPageIndex(): number;
    /** Returns true if has a next page, false otherwise */
    get hasNext(): boolean;
    /** Returns true if has a previous page, false otherwise */
    get hasPrevious(): boolean;
    /** Set current page by specifying its index and returns it, pageIndex must be defined is [0, count[ */
    setCurrentPageIndex(pageIndex: number): Promise<Page<T>>;
    /** Set current page to next page and returns it */
    next(): Promise<Page<T>>;
    /** Set current page to previous page and returns it */
    previous(): Promise<Page<T>>;
    /** Refresh the current page */
    refresh(): Promise<Page<T>>;
}
