import { raw, node, Slug } from "../../models";
/**
 * Node factory to create easily a node without knowing its implementation.
 */
export declare class NodeFactory {
    /**
     * Create a new node from a given slug and raw data.
     * Static type checking is disabled for raw data, be sure to send correct data.
     * @param slug
     * @param raw
     * @returns
     */
    static create(slug: Slug, raw?: {
        [key: string]: any;
    }): node.AnyPrimary;
    /**
   * Create a new node from a given slug and raw data.
   * Static type checking is disabled for raw data, be sure to send correct data.
   * @param slug
   * @param raw
   * @returns
   */
    static asyncCreate(slug: Slug, raw?: {
        [key: string]: any;
    }): Promise<node.AnyPrimary>;
    static asyncCreateCollection(raw?: Partial<raw.Collection>): Promise<node.ICollection>;
    static asyncCreateData(raw?: Partial<raw.Data>): Promise<node.IData>;
    static asyncCreateExperiment(raw?: Partial<raw.Experiment>): Promise<node.IExperiment>;
    static asyncCreateFile(raw?: Partial<raw.File>): Promise<node.IFile>;
    static asyncCreateGroup(raw?: Partial<raw.Group>): Promise<node.IGroup>;
    static asyncCreateInventory(raw?: Partial<raw.Inventory>): Promise<node.IInventory>;
    static asyncCreateMaterial(raw?: Partial<raw.Material>): Promise<node.IMaterial>;
    static asyncCreateProcess(raw?: Partial<raw.Process>): Promise<node.IProcess>;
    static asyncCreateProject(raw?: Partial<raw.Project>): Promise<node.IProject>;
    static asyncCreateReference(raw?: Partial<raw.Reference>): Promise<node.IReference>;
    static asyncCreateUser(raw?: Partial<raw.User>): Promise<node.IUser>;
    static createCollection(raw?: Partial<raw.Collection>): node.ICollection;
    static createData(raw?: Partial<raw.Data>): node.IData;
    static createExperiment(raw?: Partial<raw.Experiment>): node.IExperiment;
    static createFile(raw?: Partial<raw.File>): node.IFile;
    static createGroup(raw?: Partial<raw.Group>): node.IGroup;
    static createInventory(raw?: Partial<raw.Inventory>): node.IInventory;
    static createMaterial(raw?: Partial<raw.Material>): node.IMaterial;
    static createProcess(raw?: Partial<raw.Process>): node.IProcess;
    static createProject(raw?: Partial<raw.Project>): node.IProject;
    static createReference(raw?: Partial<raw.Reference>): node.IReference;
    static createUser(raw?: Partial<raw.User>): node.IUser;
}
