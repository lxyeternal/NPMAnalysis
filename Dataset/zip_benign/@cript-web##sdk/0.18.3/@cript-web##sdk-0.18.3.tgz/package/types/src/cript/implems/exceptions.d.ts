/**
 * Raised for errors with API authentication.
 */
export declare class APIAuthError extends Error {
    statusCode: number;
    constructor(message: string);
}
