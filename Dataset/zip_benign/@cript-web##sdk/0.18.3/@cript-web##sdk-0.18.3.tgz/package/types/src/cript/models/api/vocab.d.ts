/**
 * Simplest controlled vocabulary
 */
export interface CVBase {
    name: string;
    description: string;
}
export interface CVIdentifier extends CVBase {
    names: string[];
    value_type: "string" | "integer" | "number" | "list[number]";
    value_length: number;
}
export interface CVQuantity extends CVIdentifier {
    range: [number, number];
    si_unit: string;
    prefer_unit: string;
}
export interface CVProperty extends CVQuantity {
    methods: string;
}
/**
 * Controlled vocabulary
 *
 * This type hold data sent by the back-end when IClient connects.
 * It contains all base vocabulary to prefill input fields.
 */
export declare type ControlledVocabulary = {
    ['material-identifier-key']: CVIdentifier[];
    ['material-property-key']: CVProperty[];
    ['process-property-key']: CVProperty[];
    ['condition-key']: CVQuantity[];
    ['quantity-key']: CVQuantity[];
    ['process-type']: CVBase[];
    ['computational-process-type']: CVBase[];
    ["computational-process-property-key"]: CVProperty[];
    ["computation-type"]: CVBase[];
    ["computational-forcefield-key"]: CVBase[];
    ['file-type']: CVBase[];
    ['data-type']: CVBase[];
    ['set-type']: CVBase[];
    ['uncertainty-type']: CVBase[];
    ['property-method']: CVBase[];
    ['material-keyword']: CVBase[];
    ['process-keyword']: CVBase[];
    ['ingredient-keyword']: CVBase[];
    ['equipment-key']: CVBase[];
    ['citation-type']: CVBase[];
};
