/**
 * This file contains data model matching with the raw data returned by the CRIPT's API.
 *
 * Rules:
 * - Declare only interfaces (no types)
 * - No methods are allowed there
 */
import { URL, TimeStamp, Unit } from "./types";
/**
 * raw namespace contains interfaces related to the raw data returned by the CRIPT's API.
 * Raw data is not a Node: raw.Project != node.Project
 */
export declare namespace raw {
    /**********************************************************
     * Common
     */
    /**
     * Base for every node.
     */
    interface IBase {
    }
    /**
     * Base for every primary node
     */
    interface IPrimary extends IBase {
        created_at?: TimeStamp;
        name: string;
        /** public / non-public flag. Cannot be modified, require usage of a specific endpoint */
        readonly public: boolean;
        uid?: string;
        updated_at?: TimeStamp;
        url?: URL;
    }
    /**********************************************************
     * Secondary
     *
     * Please respect alphabetic order
     */
    interface Identifier extends IBase {
        key: string;
        value: string | number | string[] | number[];
    }
    interface Citation extends IBase {
        /** Context of citation */
        type: string;
        /** Reference to a book, paper, or scholarly work */
        reference: Reference;
        /** Miscellaneous information, or custom data structure (e.g.; JSON) */
        notes?: string;
    }
    /**
     * TODO: unsure of it. Needs to be tested
     */
    interface Equipment extends IBase {
        key: string;
        description: string;
        conditions?: Condition[];
        citations?: Citation[];
    }
    interface Condition extends IBase {
        /** Type of condition */
        key: string;
        /** Type of value stored, 'value' is just the number, 'min', 'max', 'avg', etc. for series */
        type: string;
        /** Piece of information of quantity */
        value: string | number;
        /** Unit for quantity */
        unit: Unit;
        /** uncertainty of value */
        uncertainty: number | null;
        /** type of uncertainty */
        uncertainty_type: string | null;
        /** Id of set (used to link measurements in as series) */
        material: string;
        /** Id for a single measurement (used to link multiple condition at a single instance) */
        descriptor: string;
        /** type of uncertainty */
        data: string;
    }
    interface Computation extends IBase {
    }
    interface Ingredient extends IBase {
        material: string;
        keyword: string;
        quantities: Array<Quantity>;
    }
    interface Property extends IBase {
        citations: Array<Citation>;
        components: Array<URL>;
        components_relative: Array<URL>;
        computations: Array<URL>;
        conditions: Array<Condition>;
        data: URL;
        key: string;
        method: string;
        notes: string;
        sample_preparation: string;
        set_id: string | null;
        structure: string;
        type: string;
        uncertainty: number | null;
        uncertainty_type: string | null;
        unit: Unit;
        value: string | number;
    }
    interface Quantity extends IBase {
        key: string;
        value: number;
        unit: Unit;
        uncertainty: number | null;
        uncertainty_type: string | null;
    }
    /***********************************************************************
     * Primary
     *
     * to devs: please respect alphabetic order
     */
    /**
     * Interface for every Collection data/implementation
     */
    interface Collection extends IPrimary {
        citations: Array<URL>;
        experiments: URL;
        group: URL;
        inventories: URL;
        notes?: string;
        project: URL;
    }
    /**
     * Interface for every Data data/implementation
     */
    interface Data extends IPrimary {
        calibration: string;
        citations: Array<Citation>;
        /** Array of computations' URL */
        computations: string[];
        /** Computational process' URL */
        computational_process: string;
        configuration: string;
        /** Parent experiment */
        experiment: URL;
        files: Array<URL>;
        group: URL;
        materials: Array<URL>;
        notes?: string;
        processes: Array<URL>;
        sample_preparation: unknown;
        type: string;
    }
    interface Experiment extends IPrimary {
        /** Parent collection */
        collection: URL;
        /** URL pointing to the child data (a Data page precisely) */
        data: URL;
        funding: Array<string>;
        group: URL;
        notes?: string;
        /** URL pointing to the child processes (a Process page precisely) */
        processes: URL;
    }
    interface File extends IPrimary {
        group: URL;
        project: URL;
        data: Array<URL> | URL;
        checksum: string;
        extension: string;
        unique_name: string;
        type: string;
    }
    interface Group extends IPrimary {
        email: string;
        /** List of user's url */
        users: URL[];
    }
    interface Inventory extends IPrimary {
        collection: URL;
        notes: string;
        group: URL;
        materials: Array<URL>;
    }
    interface Material extends IPrimary {
        group: URL;
        project: URL;
        identifiers: Array<Identifier>;
        /** Array of Material URL */
        components: Array<string>;
        keywords: Array<string>;
        notes: string;
        properties: Array<Property>;
        process: URL;
    }
    interface Process extends IPrimary {
        group: URL;
        experiment: URL;
        type: string;
        keywords: Array<string>;
        description: string;
        prerequisite_processes: Array<URL>;
        ingredients: Array<Ingredient>;
        equipment: Array<Equipment>;
        set_id: number | null;
        properties: Array<Property>;
        conditions: Array<Condition>;
        products: Array<URL>;
        waste: Array<URL>;
        citations: Array<URL>;
    }
    interface Project extends IPrimary {
        /** URL pointing to the group */
        group: URL;
        /** URL to get a collection page */
        collections: string;
        /** URL to get a material page */
        materials: string;
        /** URL to get a file page */
        files: string;
        /** Notes, also called description */
        notes: string;
    }
    interface Reference extends IPrimary {
        group: URL;
        title: string;
        authors: Array<URL>;
        journal: string;
        publisher: string;
        year: string;
        volume: string;
        issue: string;
        pages: string[];
        doi?: string;
        issn: string;
        arxiv_id?: string;
        pmid: string;
        website: string;
        notes: string;
    }
    interface User extends IPrimary {
        username: string;
        email: string;
        orcid_id: string;
    }
}
