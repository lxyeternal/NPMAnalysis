/**
 * APIClient configuration
 */
export declare type Config = {
    /** host of your deployed CRIPT app */
    host: string;
    /** Transport Layer Secure */
    tls: boolean;
    /** Refresh JsonWebToken (JWT) */
    refreshJWT: string;
    /** Refresh JsonwebToken (JWT) delay in milliseconds (default: 4000ms) */
    refreshJWTDelay?: number;
    /** Fake browser cookie. DO NOT use in production, wont't work in a browser (will be erased) */
    cookie?: string;
};
