import { IClient, node, raw } from "../../models";
import { ExperimentGraph, IExperimentEndPoint } from "../../models/api/experiment-end-point";
import { GenericEndPoint } from "./generic-end-point";
export declare class ExperimentEndPoint extends GenericEndPoint<node.IExperiment, raw.Experiment> implements IExperimentEndPoint {
    constructor(api: IClient);
    getGraph(node: node.IExperiment): Promise<ExperimentGraph>;
}
