import { node, IEndPoint } from "..";
/** Structure to store an experiment graph (to help to feed GraphViz) */
export declare type ExperimentGraph = {
    graph: any[];
    /** orphaned nodes (not present in the graph) */
    orphaned: any[];
};
/**
 * End point specific for Experiments.
 * Provide methods such as getGraph
 */
export interface IExperimentEndPoint extends IEndPoint<node.IExperiment> {
    /**
     * Get the experiment graph for a given material.
     * This object has to be trasformed before to be passed to GraphViz
     *
     *  TODO: this should return a ready-to-use object to feed graphviz.
     *        A style parameter could be provided to adapt to the context (mini or large view).
    */
    getGraph(node: node.IExperiment): Promise<ExperimentGraph>;
}
