import { node } from "../../../models/nodes";
import { raw } from "../../../models/raw";
import { TimeStamp } from "../../../models/types";
export declare class Experiment implements node.IExperiment {
    static slug: 'experiment';
    readonly slug: "experiment";
    collection: string;
    created_at: TimeStamp;
    funding: string[];
    group: string;
    name: string;
    notes: string;
    public: boolean;
    data: string;
    processes: string;
    uid: string;
    updated_at: TimeStamp;
    url: string;
    constructor(raw?: Partial<raw.Experiment>);
    loadState(raw: Partial<raw.Experiment>): void;
    saveState(): Required<raw.Experiment>;
}
