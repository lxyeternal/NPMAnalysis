/** Union of any possible slug */
export declare type Slug = 'project' | 'collection' | 'group' | 'user' | 'material' | 'process' | 'data' | 'file' | 'inventory' | 'user' | 'reference' | 'experiment';
