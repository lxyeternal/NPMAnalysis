/** */
export declare namespace NumberUtils {
    /**
     * Return a value or a default value if the value is not strictly positive  (]0, inf[)
     * @param _value
     * @param _default
     * @returns
     */
    function strictlyPositiveOr(_value: number, _default: number): number;
    /**
     * Return a value or a default value if the value is not positive ([0, inf[)
     * @param _value
     * @param _default
     * @returns
     */
    function positiveOr(_value: number, _default: number): number;
}
