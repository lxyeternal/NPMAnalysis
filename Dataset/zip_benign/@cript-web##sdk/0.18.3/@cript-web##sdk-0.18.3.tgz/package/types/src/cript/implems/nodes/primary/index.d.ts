/**
 * Shortcut to import all Primary node implems
 */
import { Collection } from "./collection";
import { Data } from "./data";
import { Experiment } from "./experiment";
import { File } from "./file";
import { Group } from "./group";
import { Inventory } from "./inventory";
import { Material } from "./material";
import { Process } from "./process";
import { Project } from "./project";
export { Collection, Data, Experiment, File, Group, Inventory, Material, Process, Project };
