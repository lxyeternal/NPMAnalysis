/**
 * CRIPT WebSDK public API
 */
import { Slug, ClientStatus, Config, ControlledVocabulary, CVBase, CVIdentifier, CVProperty, CVQuantity, IClient, IPaginator, IQuery, PaginationParams, SearchParams, SearchQuery } from './cript/models/api';
import { raw } from './cript/models/raw';
import { node } from './cript/models/nodes';
import * as internal from './internal';
import { NodeFactory } from './cript/implems/api/node-factory';
import { UrlUtils, logger, NumberUtils, http, NodeUtils } from './cript/utils';
/**
 * Differenciate each client implementation.
 */
declare enum ClientImplType {
    DEFAULT = "DEFAULT"
}
/**
 * Extra configuration required by the newClient factory
 */
declare type ExtraConfig = {
    type?: ClientImplType;
};
/**
 * Create a new Client to query CRIPT's API
 * @param type the instance type to create
 * @returns an IClient's implemented instance
 */
declare function newClient(_config: Config & ExtraConfig): IClient;
export { newClient, NodeFactory, IPaginator, Config, ClientImplType, IClient, ClientStatus, SearchQuery, SearchParams, Slug, raw, node, IQuery, PaginationParams, http, NumberUtils, UrlUtils, NodeUtils, logger, internal };
export { ControlledVocabulary, CVIdentifier, CVProperty, CVQuantity, CVBase, };
