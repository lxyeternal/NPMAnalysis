import { node, raw, TimeStamp } from '../../../models';
export declare class Material implements node.IMaterial {
    static slug: 'material';
    readonly slug: "material";
    components: string[];
    created_at: TimeStamp;
    group: string;
    identifiers: raw.Identifier[];
    keywords: string[];
    name: string;
    notes: string;
    process: string;
    project: string;
    properties: raw.Property[];
    public: boolean;
    uid: string;
    updated_at: TimeStamp;
    url: string;
    constructor(raw?: Partial<raw.Material>);
    loadState(raw: Partial<raw.Material>): void;
    saveState(): Required<raw.Material>;
    add_component(component: raw.IPrimary | node.IPrimary<raw.IPrimary>): Promise<node.IPrimary<raw.IPrimary>>;
    add_identifier(identifier: raw.Identifier | node.IIdentifier): Promise<node.IIdentifier>;
    add_property(property: raw.Property | node.IProperty): Promise<node.IProperty>;
    remove_component(component: number | node.IPrimary<raw.IPrimary>): Promise<number>;
    remove_identifier(identifier: number | node.IIdentifier): Promise<number>;
    remove_property(property: number | node.IProperty): Promise<number>;
}
