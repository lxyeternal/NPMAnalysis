import { http } from "../../utils/http";
import { node } from "../nodes";
import { APIVersion } from "../types";
import { Config } from "./config";
import { IEndPoint } from "./end-point";
import { IExperimentEndPoint } from "./experiment-end-point";
import { IMaterialEndPoint } from "./material-end-point";
import { StorageInfo } from "./session-info";
import { Slug } from "./slug";
import { ControlledVocabulary } from "./vocab";
/**
 * Enumeration to distinguish the states of a Client
 */
export declare enum ClientStatus {
    NOT_CONNECTED = "NOT_CONNECTED",
    CONNECTING = "CONNECTING",
    CONNECTED = "CONNECTED",
    UNABLE_TO_CONNECT = "UNABLE_TO_CONNECT"
}
/**
 * Interface for any API Client implementation
 */
export interface IClient {
    /** Associative array, keys can be anything (Array, Objects, etc.). TODO: detail the type */
    readonly controlledVocabulary: ControlledVocabulary | null;
    readonly storageInfo: StorageInfo | null;
    /** Latest version available (the one deployed) */
    readonly latestVersion: APIVersion;
    /** Version supported by the Client */
    readonly supportedVersion: APIVersion;
    /** Current user */
    readonly user: node.IUser | null;
    /** Get client's configuration (returned value is a copy)*/
    readonly config: Config;
    readonly status: ClientStatus;
    readonly httpClient: http.IClient;
    /**
     * API base url
     * like: protocol//host[:port]/path/to/api/
    */
    readonly baseUrl: string;
    /** Project end point */
    readonly projects: IEndPoint<node.IProject>;
    /** Collection end point */
    readonly collections: IEndPoint<node.ICollection>;
    /** Group end point */
    readonly groups: IEndPoint<node.IGroup>;
    /** User end point */
    readonly users: IEndPoint<node.IUser>;
    /** Material end point */
    readonly materials: IMaterialEndPoint;
    /** Data end point */
    readonly data: IEndPoint<node.IData>;
    /** File end point */
    readonly files: IEndPoint<node.IFile>;
    /** Inventory end point */
    readonly inventories: IEndPoint<node.IInventory>;
    /** Process end point */
    get processes(): IEndPoint<node.IProcess>;
    /** Reference end point */
    get references(): IEndPoint<node.IReference>;
    /** Experiments end point */
    readonly experiments: IExperimentEndPoint;
    /**
     * Establishes a session with a CRIPT API endpoint.
     * Use this method after IClient instantiation before to use it.
     */
    connect(): Promise<void>;
    /**
     * Check if a node can be edited by a given user.
     * @param _node
     * @param _user optionnal, by default will be the current logged user
     */
    canEdit(_node: {
        group: string;
    }, _user?: node.IUser): Promise<boolean>;
    /**
     * Get a endpoint from its slug
     * Usefull for generic programming.
     * @param slug
     */
    getEndPoint(slug: Slug): IEndPoint<node.AnyPrimary>;
}
