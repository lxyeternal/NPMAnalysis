import { IPaginator, PaginationParams, SearchParams } from ".";
import { node } from "../nodes";
/**
 * Abstract class to define a new endpoint for a give node type.
 * T is the node class, rawT is inferred from T's state.
 */
export interface IEndPoint<T extends node.IPrimary> {
    /**
     * Overwrite a node's attributes with the latest values from the database.
     * The node object reference is preserved.
     * @param node The node to refresh.
     * @param max_level Max depth to recursively generate nested nodes.
     */
    refresh(node: T, max_level?: number): Promise<T>;
    /**
     * Create or update a node in the database
     * The node object reference is NOT preserved.
     *
     * @param node The node to be saved.
     * @return the updated node
     */
    save(node: T /** , max_level: number, update_existing: boolean */): Promise<T>;
    /**
     * Delete a node from a given uid
     * @param uid The unique identifier of the node to delete
     * @return a Promise resolving true if node has beed deleted, false otherwise.
     */
    delete(uid: string): Promise<boolean>;
    /**
     * Get a node from its URL
     * @param url the node's URL
     */
    getFromUrl(url: string): Promise<T>;
    /**
     * Get all nodes from a given URL array
     * @param url
     * @returns
     */
    getArrayFromUrls(urls: T['url'][]): Promise<T[]>;
    /**
     * Get a node from its unique identifier
     * @param uid the node's uniaue identifier
     */
    getFromUid(uid: string): Promise<T>;
    /**
     * Get all elements as a paginator object
     * @param params
     */
    getAll(params?: PaginationParams): Promise<IPaginator<T>>;
    /**
     * Get all nodes from a given URL
     * @param url
     * @param params pagination parameters
     * @returns
     */
    getAllFromUrl(url: string, params?: PaginationParams): Promise<IPaginator<T>>;
    /**
     * Search elements and get the result as a paginator.
     * @param params
     */
    search(searchParams: SearchParams, paginationParams?: PaginationParams): Promise<IPaginator<T>>;
    /**
     * Checks if a node with a given name already exists
     * @param name
     */
    nameExists(name: string): Promise<boolean>;
}
