import { node, raw, TimeStamp } from "../../../models";
export declare class Inventory implements node.IInventory {
    static slug: 'inventory';
    readonly slug: "inventory";
    collection: string;
    created_at: TimeStamp;
    notes: string;
    group: string;
    materials: string[];
    materials_url: string;
    name: string;
    public: boolean;
    uid: string;
    updated_at: TimeStamp;
    private _url;
    constructor(raw?: Partial<raw.Inventory>);
    set url(_url: string);
    get url(): string;
    loadState(raw: Partial<raw.Inventory>): void;
    saveState(): Required<raw.Inventory>;
    add_material(material: raw.Material | node.IMaterial): Promise<node.IMaterial>;
    remove_material(material: number | node.IMaterial): Promise<number>;
}
