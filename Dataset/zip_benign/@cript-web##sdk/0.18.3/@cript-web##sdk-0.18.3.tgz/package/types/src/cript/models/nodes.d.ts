import { Slug } from "./api";
import { raw } from "./raw";
/**
 * This namespace defines all node interfaces.
 * We only have primary nodes here, the secondary are contained in the primary node's state.
 */
export declare namespace node {
    /** Any node type (Primary and Secondary) */
    type Any = AnyPrimary & AnySecondary;
    /** Any Primary node */
    type AnyPrimary = IPrimary & (ICitation | ICollection | IMaterial | IUser | IInventory | IProcess | IProject | IExperiment | IData | IFile | IGroup | IReference);
    /** Any Secondary node */
    type AnySecondary = ISecondary & (ICitation | ICondition | IEquipment | IIdentifier | IIngredient | IProperty);
    /**
     * Interface for every primary Node.
     */
    type IPrimary<T extends raw.IPrimary = raw.IPrimary> = Required<T> & // must expose all raw data fields
    {
        /** String identifying this not type
         * This is used in the url, ex: /api/<slug>/<uid>
         */
        readonly slug: Slug;
        /** Load node state from a raw data type */
        loadState(rawData: Partial<T>): void;
        /** Save node state as raw data type */
        saveState(): Required<T>;
    };
    interface ICollection extends IPrimary<raw.Collection> {
        readonly slug: 'collection';
        add_citation(citation: raw.Citation | ICitation): Promise<void>;
        remove_citation(citation: raw.Citation | number): Promise<void>;
    }
    interface IData extends IPrimary<raw.Data> {
        readonly slug: 'data';
        add_citation(citation: raw.Citation | ICitation): Promise<void>;
        remove_citation(citation: ICitation | number): Promise<void>;
    }
    interface IExperiment extends IPrimary<raw.Experiment> {
        readonly slug: 'experiment';
    }
    interface IFile extends IPrimary<raw.File> {
        readonly slug: 'file';
        add_data(data: raw.Data | IData): Promise<IData>;
        remove_data(data: IData | number): Promise<void>;
    }
    interface IGroup extends IPrimary<raw.Group> {
        readonly slug: 'group';
        /**
         * Check if this group has a given user.
         * @param _userUrl
         */
        hasUser(_userUrl: string): boolean;
    }
    interface IInventory extends IPrimary<raw.Inventory> {
        readonly slug: 'inventory';
        /** URL to related materials, see materials if you only need materials' URL  */
        readonly materials_url: string;
        add_material(material: raw.Material | IMaterial): Promise<IMaterial>;
        remove_material(material: IMaterial | number): Promise<number>;
    }
    interface IMaterial extends IPrimary<raw.Material> {
        readonly slug: 'material';
        add_component(component: raw.IPrimary | IPrimary): Promise<IPrimary>;
        add_identifier(identifier: raw.Identifier | IIdentifier): Promise<IIdentifier>;
        add_property(property: raw.Property | IProperty): Promise<IProperty>;
        remove_component(component: IPrimary | number): Promise<number>;
        remove_identifier(identifier: IIdentifier | number): Promise<number>;
        remove_property(property: IProperty | number): Promise<number>;
    }
    interface IProcess extends IPrimary<raw.Process> {
        readonly slug: 'process';
        add_citation(citation: raw.Citation | ICitation): Promise<ICitation>;
        add_condition(condition: raw.Condition | ICondition): Promise<ICondition>;
        add_equipment(piece: raw.Equipment | IEquipment): Promise<IEquipment>;
        add_ingredient(ingredient: raw.Ingredient | IIngredient): Promise<IIngredient>;
        add_prerequisite_process(process: raw.Process | IProcess): Promise<IProcess>;
        add_product(material: raw.Material | IMaterial): Promise<IMaterial>;
        add_property(property: raw.Property | IProperty): Promise<IProperty>;
        add_waste(material: raw.Material | IMaterial): Promise<IMaterial>;
        remove_citation(citation: ICitation | number): Promise<number>;
        remove_condition(condition: ICondition | number): Promise<number>;
        remove_equipment(equipmen: IEquipment | number): Promise<number>;
        remove_ingredient(ingredient: IIngredient | number): Promise<number>;
        remove_prerequisite_process(process: IProcess | number): Promise<number>;
        remove_product(material: IMaterial | number): Promise<number>;
        remove_property(property: IProperty | number): Promise<number>;
        remove_waste(material: IMaterial | number): Promise<number>;
    }
    interface IProject extends IPrimary<raw.Project> {
        readonly slug: 'project';
    }
    interface IReference extends IPrimary<raw.Reference> {
        readonly slug: 'reference';
    }
    interface IUser extends IPrimary<raw.User> {
        readonly slug: 'user';
    }
    /**
     * Secondary nodes
     */
    /**
     * Interface for every primary Node.
     */
    type ISecondary<T extends raw.IBase = raw.IBase> = Required<T>;
    type ICitation = ISecondary<raw.Citation>;
    type ICondition = ISecondary<raw.Condition>;
    type IEquipment = ISecondary<raw.Equipment>;
    type IIdentifier = ISecondary<raw.Identifier>;
    interface IIngredient extends ISecondary<raw.Ingredient> {
        add_citation(citation: raw.Citation | ICitation): Promise<ICitation>;
        remove_citation(citation: ICitation | number): Promise<number>;
    }
    type IProperty = ISecondary<raw.Property>;
}
