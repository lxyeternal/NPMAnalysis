import { IQuery, PaginationParams } from "./query";
/**
 * Optionnal suffix
 *
 * __exact (case-sensitive exact match)
 * __iexact (case-insensitive exact match)
 * __contains (case-sensitive contains)
 * __icontains  (case-insensitive contains)
 * __gt (greater than)
 * __gte (greater than or equal to)
 * __lt (less than)
 * __lte (less than or equal to)
 *
 */
declare type Options = 'exact' | 'iexact' | 'contains' | 'icontains' | 'gt' | 'gte' | 'lt' | 'lte';
declare type Option = '' | `__${Options}`;
declare type SearchKeyBase = 'name' | 'project' | 'collection' | 'data' | 'experiment' | 'process' | 'file' | 'reference' | 'inventory';
declare type SearchKey = `${SearchKeyBase}${Option}`;
/**
 * Search data structure
 *
 * note: node type style keys (eg project, collection) refers to an uid.
 */
export declare type SearchParams = {
    uid?: string;
    url?: string;
} & {
    [key in SearchKey]?: string;
} & {};
/**
 * Define a search query
 */
export interface SearchQuery extends IQuery {
    /** Optionnal pagination parameters  */
    params: PaginationParams;
    /** Search query's body */
    body: SearchParams;
}
export {};
