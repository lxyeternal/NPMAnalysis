import postcss = require("postcss");
interface Options {
    [key: string]: any;
    "px": number;
    "vw": number;
    "vh": number;
    "rpx": number;
    "rem": number;
    "cm": number;
    "mm": number;
    "in": number;
    "pc": number;
    "pt": number;
    "targets": {
        [key: string]: string;
    };
    "props": string[];
    "precision": number;
}
declare const _default: postcss.Plugin<Partial<Options>>;
export = _default;
