"use strict";
const postcss = require("postcss");
const defaults = {
    "px": 1,
    "vw": 3.75,
    "vh": 6.67,
    "rpx": 0.5,
    "rem": 10,
    "cm": 96 / 2.54,
    "mm": 96 / 25.4,
    "in": 96,
    "pc": 16,
    "pt": 96 / 72,
    "targets": {
        "*": "rpx",
    },
    "props": [],
    "precision": 6,
};
function fround(input, precision) {
    const tmp = Math.pow(10, precision);
    return Math.floor(input * tmp) / tmp;
}
module.exports = postcss.plugin('postcss-uint-convert', (opts = {}) => {
    opts = Object.assign(defaults, opts);
    const blacklist = ["targets", "props", "precision"];
    const units = Object.keys(opts).filter((v) => {
        return typeof opts[v] === "number" && blacklist.indexOf(v) === -1;
    });
    const sizeMap = {};
    units.forEach((unit) => {
        sizeMap[unit] = opts[unit];
    });
    const reg = new RegExp(`(\\d+)(${units.join("|")})`, "g");
    const targets = opts.targets;
    const props = opts.props;
    const precision = opts.precision || 6;
    return (root) => {
        if (!targets)
            return;
        root.walkRules((rule) => {
            rule.walkDecls((decl) => {
                if (props && props.length > 0 && props.indexOf(decl.prop) === -1) {
                    return;
                }
                decl.value = decl.value.replace(reg, (origin, size, unit) => {
                    const targetUint = targets[unit] || targets["*"];
                    const targetSize = sizeMap[targetUint];
                    if (opts[unit] && targetSize) {
                        return fround(size * opts[unit] / targetSize, precision) + targetUint;
                    }
                    return origin;
                });
            });
        });
    };
});
