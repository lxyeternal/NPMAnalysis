# postcss-uint-convert

## 安装

```bash
npm install postcss-uint-convert --save-dev
```

## 配置 postcss.config.js

```js
module.expoers = {
    plugins: {
        //
        // 默认配置
        // 不需要的可以设为 null
        //
        "postcss-uint-convert": {
            "px": 1,
            "vw": 3.75,
            "vh": 6.67,
            "rpx": 0.5,
            "rem": 10,
            "cm": 96 / 2.54,
            "mm": 96 / 25.4,
            "in": 96,
            "pc": 16,
            "pt": 96 / 72,
            "targets": {
                "*": "rpx",
            },
            "props": [],
            "precision": 6,
        }
    }
}
```
