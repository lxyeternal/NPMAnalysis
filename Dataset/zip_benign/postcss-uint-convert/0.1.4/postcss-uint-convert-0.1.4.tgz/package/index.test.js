let fs = require('fs');
let postcss = require('postcss');

let plugin = require('./')

async function run(input, output, opts) {
    let result = await postcss([plugin(opts)]).process(input, { from: undefined });
    console.log(result.css);
}

(async function () {
    const input = fs.readFileSync("./input.css");
    await run(input, 'a{ }', {
        vw: 10.80,
        vh: 19.20,
        pt: null,
        "%": 10.80,
        props: ["width", "background-size"],
    });
    await run(fs.readFileSync("./input.css"), 'a{ }', {
        pt: null,
        props: ["height", "background-size"],
        targets: {
            "px": "in",
            "vw": "mm",
            "vh": "mm",
            "cm": "in",
            "mm": "in",
        },
    });
})();