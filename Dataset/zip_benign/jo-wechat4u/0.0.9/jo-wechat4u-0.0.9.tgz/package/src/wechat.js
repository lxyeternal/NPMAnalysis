import WechatCore from './core'
import EventEmitter from 'events'
import * as un from 'underscore';
import _ from 'lodash'
import {
  getCONF,
  isStandardBrowserEnv
} from './util'

import ContactFactory from './interface/contact'
import MessageFactory from './interface/message'

import _debug from 'debug'
const debug = _debug('wechat')

if (!isStandardBrowserEnv) {
  process.on('uncaughtException', err => {
    console.log('uncaughtException', err)
  })
}

class Wechat extends WechatCore {

  constructor(inst={cookie:'{}', obj:'{}'}) {
    super(JSON.parse(inst.cookie));
    _.extend(this, new EventEmitter())
    this.state = this.CONF.STATE.init
    this.contacts = {} // 所有联系人
    this.Contact = ContactFactory(this)
    this.Message = MessageFactory(this)
    this.lastReportTime = 0
    this.syncErrorCount = 0
    _.extend(this, JSON.parse(inst.obj));
    console.log(this.serialObj());
  }
  serialObj() {
    let nthis = un.pick(this, 'PROP', 'user', 'state', 'lastReportTime', 'rediUri');
    nthis.user.userAvatar = 'avatar...';
    console.log('keys:', un.keys(nthis));
    return {uuid: this.PROP.uuid,
      cookie: JSON.stringify(this.request_.cm.list),
      obj: JSON.stringify(nthis)
    };
  }
  get friendList() {
    let members = []

    for (let key in this.contacts) {
      let member = this.contacts[key]
      members.push({
        username: member['UserName'],
        nickname: this.Contact.getDisplayName(member),
        py: member['RemarkPYQuanPin'] ? member['RemarkPYQuanPin'] : member['PYQuanPin'],
        avatar: member.AvatarUrl
      })
    }

    return members
  }

  syncPolling(callback) {
    this.syncCheck().then(selector => {
      debug('Sync Check Selector: ', selector)
      if (selector != this.CONF.SYNCCHECK_SELECTOR_NORMAL) {
        return this.sync().then(data => {
          this.syncErrorCount = 0
          callback(data)
        })
      }
    }).then(() => {
      this.syncPolling(callback)
      this.emit('save');
      if (+new Date() - this.lastReportTime > 5 * 60 * 1000) {
        debug('Status Report')
        this.notifyMobile(this.user.UserName)
        this.statReport()
        this.sendText('心跳：' + new Date().toLocaleString(), 'filehelper')
        this.lastReportTime = +new Date()
      }
    }).catch(err => {
     /* this.emit('error', err)
      if (this.syncErrorCount++ > 5) {
        debug(err)
        this.logout()
        this.state = this.CONF.STATE.logout
        callback()
      } else {
        setTimeout(() => {
          this.syncPolling(callback)
        }, 1000 * this.syncErrorCount)
      }*/
      if (this.syncErrorCount++ < 2) {
        this.emit('logout');
        this.logout();
        this.state = this.CONF.STATE.logout;
      }
    });
  }

  async start() {
    // return;
    let ret = undefined
    try {
      if (this.state != this.CONF.STATE.login) {
        ret = await this.getUUID()
        debug('getUUID: ', ret)
        this.emit('uuid', ret)
        this.state = this.CONF.STATE.uuid
        do {
          ret = await this.checkLogin()
          debug('checkLogin: ', ret)
          if (ret.code == 201 && ret.userAvatar) {
            this.emit('user-avatar', ret.userAvatar)
          }
        } while (ret.code !== 200)
        await this.login()
      }
      let result = await this.init()
      if(result=="initFailed") { 
        this.emit('logout');
        return;
      }
      await this.notifyMobile()
      ret = await this.getContact()
      debug('getContact data length: ', ret.length)
      this.updateContacts(ret)
      this.syncPolling(msg => {
        if (!msg) {
          this.emit('logout')
          this.state = this.CONF.STATE.logout
        } else if (msg.AddMsgCount) {
          debug('syncPolling messages count: ', msg.AddMsgCount)
          this.handleMsg(msg.AddMsgList)
        }
      })
      if (this.state != this.CONF.STATE.login)
        this.emit('login')
      this.state = this.CONF.STATE.login
    } catch (err) {
      this.emit('error', err)
      debug(err)
      this.stop()
    }
  }

  stop() {
    this.logout()
  }

  handleMsg(data) {
    data.forEach(msg => {
      Promise.resolve().then(() => {
        if (!this.contacts[msg.FromUserName]) {
          return this.batchGetContact([{
            UserName: msg.FromUserName
          }]).catch(err => {
            debug(err)
            return [{
              UserName: msg.FromUserName
            }]
          }).then(contacts => {
            this.updateContacts(contacts)
          })
        }
      }).then(() => {
        msg = this.Message.extend(msg)
        this.emit('message', msg)
        if (msg.MsgType == this.CONF.MSGTYPE_STATUSNOTIFY) {
          let userList = msg.StatusNotifyUserName.split(',').map(UserName => {
            return {
              UserName: UserName
            }
          })
          Promise.all(_.chunk(userList, 50).map(list => {
            return this.batchGetContact(list).then(res => {
              debug('batchGetContact data length: ', res.length)
              this.updateContacts(res)
            })
          })).catch(err => {
            debug(err)
          })
        }
      }).catch(err => {
        this.emit('error', err)
        debug(err)
      })
    })
  }

  updateContacts(contacts) {
    contacts.forEach(contact => {
      this.contacts[contact.UserName] = this.Contact.extend(contact)
    })
    this.emit('contacts-updated', contacts)
  }
}

Wechat.STATE = getCONF().STATE

exports = module.exports = Wechat
