import axios from 'axios'
import CM from 'cookie-manager'
import sCookie from 'simple-cookie'
import {isStandardBrowserEnv} from './global'
import * as _ from 'underscore';

const paramsSerializer = params => {
  let qs = []
  for (let key in params) {
    qs.push(`${key}=${params[key]}`)
  }
  return encodeURI(qs.join('&'))
}

const getPgv = c => {
  return (c || "") + Math.round(2147483647 * (Math.random() || .5)) * +new Date % 1E10
}

export function Request (defaults, opt, onerror) {
  defaults = defaults || {}
  defaults.headers = defaults.headers || {}
  if (!isStandardBrowserEnv) {
    defaults.headers['user-agent'] = defaults.headers['user-agent'] || 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36'
    // defaults.headers['connection'] = defaults.headers['connection'] || 'close'
  }
  // 好像不需要了
  // defaults.paramsSerializer = defaults.paramsSerializer || paramsSerializer
  defaults.httpAgent = false
  defaults.httpsAgent = false

  this.axios = axios.create(defaults)
  if (!isStandardBrowserEnv) {
    this.cm = new CM()
    this.cm.store('', ['pgv_pvi=' + getPgv() + '; Domain=.qq.com; Path=/', 'pgv_si=' + getPgv('s') + '; Domain=.qq.com; Path=/'])
    if (opt) {
      for (let domain in opt) {
        for (let k in opt[domain]) {
          let s = sCookie.stringify(opt[domain][k]);
          console.log(domain, ':', s);
          this.cm.store(domain, s);
        }
      }
      // console.log('result cookie is:', this.cm.list);
    }
    this.axios.interceptors.request.use(config => {
      config.headers['cookie'] = config.url ? decodeURIComponent(this.cm.prepare(config.url)) : ''
      return config
    }, err => {
      console.log('request use error:', err);
      onerror&&onerror();
      return Promise.reject(err)
    })
    this.axios.interceptors.response.use(res => {
      let setCookie = res.headers['set-cookie']
      if (setCookie) {
        this.cm.store(res.config.url, setCookie.filter(f=>f).map(item => {
          console.log('set cookie:', item);
          return item.replace(/\=\s*?(?=(\w+\.)*(wx\d?\.qq\.com|wechat\.com))/, '=.')
        }))
      }
      return res
    }, err => {
      console.log('response use error:', err);
      onerror && onerror();
      return Promise.reject(err)
    })
  }

  this.request = options => {
    // console.log('requesting:', options);
    return this.axios.request(options)
  }

  // return this.request
}
