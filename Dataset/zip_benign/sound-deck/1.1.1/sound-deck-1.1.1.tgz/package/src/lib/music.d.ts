import { AbstractSoundDeck } from "./AbstractSoundDeck";
import { ToneConfig, NoiseConfig } from "./input-types";
export type StaveNote = {
    pitch?: number;
    beats: number;
    atBeat: number;
};
export type TonalInstrument = {
    soundType: 'tone';
} & Omit<ToneConfig, 'duration' | 'frequency' | 'endFrequency'>;
export type PercussiveInstrument = {
    soundType: 'noise';
} & Omit<NoiseConfig, 'duration' | 'frequency' | 'endFrequency'>;
export type Instrument = PercussiveInstrument | TonalInstrument;
export declare const parseStaveNotes: (input: string) => StaveNote[];
type Stave = {
    instrument: Instrument;
    notes: StaveNote[];
    volume?: number;
};
type BeatCallback = {
    (beat: number): void;
};
type VoidCallback = {
    (): void;
};
export type MusicControl = {
    stop: {
        (): void;
    };
    whenEnded: Promise<boolean>;
    pause: {
        (): number;
    };
    resume: {
        (): void;
    };
    fadeOut: {
        (seconds: number): void;
    };
    musicDuration: number;
    currentBeat: number;
    isPaused: boolean;
    tempo: number;
    onBeat: {
        (callback: BeatCallback): void;
    };
    onFinish: {
        (callback: VoidCallback): void;
    };
    isFading: boolean;
};
export declare const playMusic: (soundDeck: AbstractSoundDeck) => (staves: Stave[], tempo?: number, loop?: boolean) => MusicControl;
export {};
