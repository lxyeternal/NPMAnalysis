export declare const notes: Partial<Record<string, number>>;
export type Note = 'C' | 'C#' | 'Db' | 'D' | 'D#' | 'Eb' | 'E' | 'F' | 'F#' | 'Gb' | 'G' | 'G#' | 'Ab' | 'A' | 'A#' | 'Bb' | 'B';
export type Octive = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
export declare const isOctive: (value: number) => value is Octive;
export declare const isNote: (value: string) => value is Note;
export declare class PitchedNote {
    note: Note;
    octive: Octive;
    constructor(note: Note, octive?: Octive);
    get name(): string;
    get pitch(): number;
    transpose(semiTones: number): PitchedNote | undefined;
    get majorTriad(): PitchedNote[];
    get minorTriad(): PitchedNote[];
}
