import { NoiseConfig, ToneConfig } from "./input-types";
declare class PresetTones {
    get NEUTRAL_BELL(): ToneConfig;
    get SPRINGY_BOUNCE(): ToneConfig;
    get NEGATIVE_BEEP(): ToneConfig;
    get SLOW_PULSE(): ToneConfig;
}
export declare const presetTones: PresetTones;
declare class PresetNoises {
    get SNAP(): NoiseConfig;
    get TAP(): NoiseConfig;
    get HISS(): NoiseConfig;
    get WHOOSH(): NoiseConfig;
}
export declare const presetNoises: PresetNoises;
export {};
