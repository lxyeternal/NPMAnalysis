type SupportedAudioNode = AudioBufferSourceNode | OscillatorNode;
export declare class SoundControl {
    sourceNode: Readonly<SupportedAudioNode | HTMLAudioElement>;
    gainNode?: Readonly<GainNode>;
    whenEnded: Promise<SoundControl>;
    constructor(sourceNode: SupportedAudioNode | HTMLAudioElement, gainNode?: GainNode);
    stop(): void;
    set volume(value: number);
    get volume(): number;
    set loop(value: boolean);
    get loop(): boolean;
}
export {};
