import { AbstractSoundDeck } from "./AbstractSoundDeck";
import { NoiseConfig, PlayOptions, ToneConfig } from "./input-types";
import { SoundControl } from "./SoundControl";
/**
 * A class that presents a convenient API for producing sounds.
 *
 * Intended for browsers that do not support Audio context. Provides
 * imperfect implementations of the SoundDeck's methods
 */
export declare class LegacySoundDeck extends AbstractSoundDeck {
    protected currentVolume: number;
    protected enabled: boolean;
    audioElements: Map<string, HTMLAudioElement>;
    fallbackToneAudioElement: HTMLAudioElement;
    fallbackNoiseAudioElement: HTMLAudioElement;
    /**
     * Note that the AudioContext for the SoundDeck may start in a 'suspended' state
     * depening on the policy of the browser.
     *
     * E.G. on chrome, an AudioContext cannot resume before the user has interacted with the document.
     * https://developer.chrome.com/blog/autoplay/
     *
     * It may be necessary to call `SoundDeck.enable` to resume the AudioContext
     * before sounds can be played. You **can** do this by attaching event listeners to the document
     * to enable sound as soon as the user interacts in a relevant way, **but** it may be better to
     * add an explicit "enable sound" button so the user can decide it they want sound or not.
    */
    constructor();
    defineSampleBuffer(
    /** the name used to access to sample in calls to `playSample` */
    name: string, 
    /** the URL of the audio file to be loaded*/
    src: string): Promise<boolean>;
    defineCustomWaveForm(): PeriodicWave | undefined;
    playSample(
    /** the name assigned to sample in a prior call to `defineSampleBuffer`*/
    soundName: string, 
    /** the options for this particular playing of the sample. */
    options?: PlayOptions): SoundControl | null;
    private playFallbackSample;
    playNoise(config?: NoiseConfig): SoundControl | null;
    playTone(config: ToneConfig): SoundControl | null;
    get isEnabled(): boolean;
    /**Set the masterGain for the SoundDeck to 0. */
    mute(): void;
    /**Restore the masterGain for the SoundDeck the value is was before the call to mute. */
    unmute(): void;
    get isMuted(): boolean;
    get masterVolume(): number;
    set masterVolume(value: number);
    get masterVolumnIfNotMuted(): number;
    enable(): Promise<Awaited<this>>;
    disable(): Promise<Awaited<this>>;
}
