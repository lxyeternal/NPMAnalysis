import { AbstractSoundDeck } from "./AbstractSoundDeck";
import { NoiseConfig, PlayOptions, ToneConfig } from "./input-types";
import { SoundControl } from "./SoundControl";
/**
 * A class that presents a convenient API for producing sounds.
 *
 * Uses the AudioContext interface. Some features have a fallback to
 * work in envirornements where the AudioContext is not available.
 */
export declare class SoundDeck extends AbstractSoundDeck {
    audioCtx: AudioContext;
    protected masterGain: GainNode;
    sampleBuffers: Map<string, AudioBuffer>;
    /**
     * Note that the AudioContext for the SoundDeck may start in a 'suspended' state
     * depening on the policy of the browser.
     *
     * E.G. on chrome, an AudioContext cannot resume before the user has interacted with the document.
     * https://developer.chrome.com/blog/autoplay/
     *
     * It may be necessary to call `SoundDeck.enable` to resume the AudioContext
     * before sounds can be played. You **can** do this by attaching event listeners to the document
     * to enable sound as soon as the user interacts in a relevant way, **but** it may be better to
     * add an explicit "enable sound" button so the user can decide it they want sound or not.
    */
    constructor(audioCtx?: AudioContext, startEnabled?: boolean);
    private loadAudioBuffer;
    defineSampleBuffer(
    /** the name used to access to sample in calls to `playSample` */
    name: string, 
    /** the URL of the audio file to be loaded*/
    src: string): Promise<boolean>;
    defineCustomWaveForm(name: string, real: Float32Array, imag: Float32Array): PeriodicWave | undefined;
    playSample(
    /** the name assigned to sample in a prior call to `defineSampleBuffer`*/
    soundName: string, 
    /** the options for this particular playing of the sample. */
    options?: PlayOptions): SoundControl | null;
    private makeNoiseSourceNodeAndFilter;
    private makeGainWithPattern;
    playNoise(config?: NoiseConfig): SoundControl | null;
    playTone(config: ToneConfig): SoundControl | null;
    get isEnabled(): boolean;
    /**Set the masterGain for the SoundDeck to 0. */
    mute(): void;
    /**Restore the masterGain for the SoundDeck the value is was before the call to mute. */
    unmute(): void;
    get isMuted(): boolean;
    get masterVolume(): number;
    set masterVolume(value: number);
    get masterVolumnIfNotMuted(): number;
    /**
     * Resume the SoundDeck's audio context, allowing any sounds to be produced.
     */
    enable(): Promise<this>;
    /**
     * Suspend the SoundDeck's audio context, preventing any sounds being produced until it
     * is resumed with the `enable` or `toggle`
     */
    disable(): Promise<this>;
}
