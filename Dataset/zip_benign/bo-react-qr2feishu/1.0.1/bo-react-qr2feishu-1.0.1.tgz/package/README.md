# React + TypeScript + feishu SDK
- [feishu SDK](https://open.feishu.cn/document/common-capabilities/sso/web-application-sso/qr-sdk-documentation) 
- [实战指南](https://open.feishu.cn/community/articles/7317091221654224898#article_c5)

```js
export interface IProps {
    clientId: string;
    redirectUri: string;
    handleMessage?: (event: MessageEvent<{ tmp_code: string }>) => void;
}
```
# feishu sdk生成的二维码是嵌套在iframe里的，二维码固定大小250*250，不支持修改，如需要调整二维码大小，可以通过类似transform: scale(0.5)的方式调整;
