import type { Element } from "./crank.js";
export declare function jsx(spans: TemplateStringsArray, ...expressions: Array<unknown>): Element;
