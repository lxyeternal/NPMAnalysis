declare function jsxAdapter(tag: any, props: Record<string, any>, key: any): import("./crank.js").Element<any>;
export declare const Fragment = "";
export declare const jsx: typeof jsxAdapter;
export declare const jsxs: typeof jsxAdapter;
export declare const jsxDEV: typeof jsxAdapter;
export {};
