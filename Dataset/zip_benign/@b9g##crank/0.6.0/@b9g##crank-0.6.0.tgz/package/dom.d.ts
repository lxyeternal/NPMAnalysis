import { Children, Context, ElementValue, Renderer, RendererImpl } from "./crank.js";
export declare const impl: Partial<RendererImpl<Node, string>>;
export declare class DOMRenderer extends Renderer<Node, string> {
    constructor();
    render(children: Children, root: Node, ctx?: Context): Promise<ElementValue<Node>> | ElementValue<Node>;
    hydrate(children: Children, root: Node, ctx?: Context): Promise<ElementValue<Node>> | ElementValue<Node>;
}
export declare const renderer: DOMRenderer;
declare global {
    namespace Crank {
        interface EventMap extends GlobalEventHandlersEventMap {
        }
    }
}
