'use strict';

var crank = require('./crank.cjs');

const voidTags = new Set([
    "area",
    "base",
    "br",
    "col",
    "command",
    "embed",
    "hr",
    "img",
    "input",
    "keygen",
    "link",
    "meta",
    "param",
    "source",
    "track",
    "wbr",
]);
function escape(text) {
    return text.replace(/[&<>"']/g, (match) => {
        switch (match) {
            case "&":
                return "&amp;";
            case "<":
                return "&lt;";
            case ">":
                return "&gt;";
            case '"':
                return "&quot;";
            case "'":
                return "&#039;";
            default:
                return "";
        }
    });
}
function printStyleObject(style) {
    const cssStrings = [];
    for (const [name, value] of Object.entries(style)) {
        if (value != null) {
            cssStrings.push(`${name}:${value};`);
        }
    }
    return cssStrings.join("");
}
function printAttrs(props) {
    const attrs = [];
    for (const [name, value] of Object.entries(props)) {
        switch (true) {
            case name === "children":
            case name === "innerHTML":
            case name === "key":
            case name === "ref":
            case name === "static":
            case name === "crank-key":
            case name === "crank-ref":
            case name === "crank-static":
            case name === "c-key":
            case name === "c-ref":
            case name === "c-static":
            case name === "$key":
            case name === "$ref":
            case name === "$static":
                // TODO: Remove deprecated special props
                break;
            case name === "style": {
                if (typeof value === "string") {
                    attrs.push(`style="${escape(value)}"`);
                }
                else if (typeof value === "object") {
                    attrs.push(`style="${escape(printStyleObject(value))}"`);
                }
                break;
            }
            case name === "className": {
                if ("class" in props || typeof value !== "string") {
                    continue;
                }
                attrs.push(`class="${escape(value)}"`);
                break;
            }
            case typeof value === "string":
                attrs.push(`${escape(name)}="${escape(value)}"`);
                break;
            case typeof value === "number":
                attrs.push(`${escape(name)}="${value}"`);
                break;
            case value === true:
                attrs.push(`${escape(name)}`);
                break;
        }
    }
    return attrs.join(" ");
}
function join(children) {
    let result = "";
    for (let i = 0; i < children.length; i++) {
        const child = children[i];
        result += typeof child === "string" ? child : child.value;
    }
    return result;
}
const impl = {
    create() {
        return { value: "" };
    },
    text(text) {
        return escape(text);
    },
    read(value) {
        if (Array.isArray(value)) {
            return join(value);
        }
        else if (typeof value === "undefined") {
            return "";
        }
        else if (typeof value === "string") {
            return value;
        }
        else {
            return value.value;
        }
    },
    arrange(tag, node, props, children) {
        if (tag === crank.Portal) {
            return;
        }
        else if (typeof tag !== "string") {
            throw new Error(`Unknown tag: ${tag.toString()}`);
        }
        const attrs = printAttrs(props);
        const open = `<${tag}${attrs.length ? " " : ""}${attrs}>`;
        let result;
        if (voidTags.has(tag)) {
            result = open;
        }
        else {
            const close = `</${tag}>`;
            const contents = "innerHTML" in props ? props["innerHTML"] : join(children);
            result = `${open}${contents}${close}`;
        }
        node.value = result;
    },
};
class HTMLRenderer extends crank.Renderer {
    constructor() {
        super(impl);
    }
}
const renderer = new HTMLRenderer();

exports.HTMLRenderer = HTMLRenderer;
exports.impl = impl;
exports.renderer = renderer;
//# sourceMappingURL=html.cjs.map
