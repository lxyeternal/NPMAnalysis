'use strict';

var crank = require('./crank.cjs');

// This file is provided for compatibility reasons with the JSX automatic
// runtime. Besides automatic imports, the JSX automatic runtime provides no
// actual advantage over the createElement transform.
function jsxAdapter(tag, props, key) {
    // The new JSX transform extracts the key from props for performance reasons,
    // but key is not a special property in Crank.
    props.key = key;
    return crank.createElement(tag, props);
}
const Fragment = "";
const jsx = jsxAdapter;
const jsxs = jsxAdapter;
const jsxDEV = jsxAdapter;

exports.Fragment = Fragment;
exports.jsx = jsx;
exports.jsxDEV = jsxDEV;
exports.jsxs = jsxs;
//# sourceMappingURL=jsx-runtime.cjs.map
