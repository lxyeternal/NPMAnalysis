import { Renderer } from "./crank.js";
import type { RendererImpl } from "./crank.js";
interface Node {
    value: string;
}
export declare const impl: Partial<RendererImpl<Node, undefined, any, string>>;
export declare class HTMLRenderer extends Renderer<Node, undefined, any, string> {
    constructor();
}
export declare const renderer: HTMLRenderer;
declare global {
    namespace Crank {
        interface EventMap extends GlobalEventHandlersEventMap {
        }
    }
}
export {};
