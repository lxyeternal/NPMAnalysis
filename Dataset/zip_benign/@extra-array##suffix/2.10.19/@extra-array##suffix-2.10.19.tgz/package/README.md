Picks an arbitrary suffix.
[:package:](https://www.npmjs.com/package/@extra-array/suffix)
[:smiley_cat:](https://github.com/orgs/nodef/packages?repo_name=extra-array)
[:running:](https://npm.runkit.com/@extra-array/suffix)
[:vhs:](https://asciinema.org/a/332140)
[:moon:](https://www.npmjs.com/package/@extra-array/suffix.min)
[:scroll:](https://unpkg.com/@extra-array/suffix/)
[:newspaper:](https://nodef.github.io/extra-array/)
[:blue_book:](https://github.com/nodef/extra-array/wiki/)

> Similar: [suffix], [suffixes], [hasSuffix].

> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

<br>

```javascript
array.suffix(x, [n], [r]);
// x: an array
// n: number of values (-1 => any)
// r: random seed 0->1
```

```javascript
const array = require("extra-array");

var x = [1, 2, 3];
array.suffix(x);
// [ 2, 3 ]

array.suffix(x, 1);
// [ 3 ]

array.suffix(x, -1, 0.5);
// [ 2, 3 ]
```

[suffix]: https://github.com/nodef/extra-array/wiki/suffix
[suffixes]: https://github.com/nodef/extra-array/wiki/suffixes
[hasSuffix]: https://github.com/nodef/extra-array/wiki/hasSuffix
