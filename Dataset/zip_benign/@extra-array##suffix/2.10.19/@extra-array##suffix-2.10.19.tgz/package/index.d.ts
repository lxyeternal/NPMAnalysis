declare module "@extra-array/suffix" {
/**
 * Picks an arbitrary suffix.
 * @param x an array
 * @param n number of values (-1 => any)
 * @param r random seed 0->1
 */
declare function suffix<T>(x: T[], n?: number, r?: number): T[];
export = suffix;
//# sourceMappingURL=suffix.d.ts.map}
