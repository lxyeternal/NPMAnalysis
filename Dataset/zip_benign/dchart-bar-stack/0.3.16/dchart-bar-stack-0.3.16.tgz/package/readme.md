dchart-bar-stack

符合dchart规范的堆叠图

### 安装

```
npm install dchart-bar-stack
```

### 用法
```
var Bar = require('dchart-bar-stack');
var bar = new Bar(container, {
  margin: {left:14, top:30, right: 16, bottom: 98},
  "xaxis" : {
  "type" : "category",
  "padding" : [0.4, 0.8],
  "dy" : 10
},
"yaxis" : {
},
});
bar.render([
       {x: '电子', y : [55, 24]},
       {x: '服装', y : [13, 15]},
       {x: '数码', y : [2, 77]},
       {x: '医药', y : [9, 7]},
       {x: '家装', y : [5, 3]}
      ]);
```
