'use strict';
// var Bar = require('../../barMultiVerti');
var Bar = require('dchart-core/bar/barMultiVerti');
var _ = require('dchart-core/util');
var d3 = require('d3');
var textures = require('textures');

function BarMultiVertiOneColumn(container, options) {
  var opt = {
    xaxis: {
      type: 'category',
      dy: 10,
      key: 'x'
    },
    yaxis: {
      key: 'y'
    },
    background: {
      show: true,
      color: '#444'
    }
  };
  opt = _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}
BarMultiVertiOneColumn = Bar.extend(BarMultiVertiOneColumn, {
  renderAxis: function (id, container, options) {
    this.getExtent();
    return Bar.prototype.renderAxis.call(this, id, container, options);
  },
  getExtent: function () {
    var opt = this.options;
    var data = this._data;
    var ykey = opt.yaxis.key;
    var union = [];
    data.length && data.forEach(function (obj, i) {
      obj.minSum = 0;
      obj.maxSum = 0;
      if (!union[i]) {
        union[i] = {max: 0, min: 0};
      }
      obj[ykey].forEach((n) => {
        const v = n.value;
        if (v >= 0) {
          union[i].max += v;
        }
        if (v < 0) {
          union[i].min += v;
        }
      });
    });
    var dataMaxValue = Math.max.apply(Math, union.map(d => d.max));
    var dataMinValue = Math.min.apply(Math, union.map(d => d.min));

    if (!opt.yaxis.maxNeedNice && isFinite(opt.yaxis.maxAmount)) {
      opt.yaxis.max = opt.yaxis.maxAmount;
    } else {
      opt.yaxis.max = dataMaxValue;
    }
    if (!opt.yaxis.minNeedNice && isFinite(opt.yaxis.minAmount)) {
      opt.yaxis.min = opt.yaxis.minAmount;
    } else {
      opt.yaxis.min = dataMinValue;
    }
  },
  afterCore: function () {
    var opt = this.options;
    var axis = this.getComs('axis', 'xaxis');
    var x = axis.getX();
    var bars = this.series.selectAll('.series-group');
    bars.each(function (data) {
      var that = d3.select(this);
      var bg = that.select('.serie-bg')[0][0] && that.select('.serie-bg') || that.insert('rect', '.serie').attr('class', 'serie-bg');
      bg.attr({
        x: function (d) {
          return x(data[opt.xaxis.key]);
        },
        y: 0,
        width: x.rangeBand(),
        height: opt.innerHeight
      }).style({
        fill: opt.background.color || '#000',
        display: opt.background.show && 'block' || 'none'
      });
    });
  },
  afterRender: function () {
    Bar.prototype.afterRender.call(this);
    this.afterCore();
  },
  updateAfterRender: function () {
    Bar.prototype.updateAfterRender.call(this);
    this.afterCore();
  },
  updateBeforeRender: function () {
    this.getExtent();
    Bar.prototype.updateBeforeRender.call(this);
  }
});

module.exports = BarMultiVertiOneColumn;
