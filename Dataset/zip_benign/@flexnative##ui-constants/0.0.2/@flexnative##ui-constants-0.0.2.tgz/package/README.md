# 🛠 Utilities

**FlexNative Utilities** are part of **FlexNatives framework** witch provides some utilities methods.

- ui-constants
- local-storage

## UI Constants

`ui-constants` Packages is part of **FlexNative**, that provides core constants related with UI Components.

### Values

|  Name   | Type | Value |
| ------- | ---- | ----- |
| <span id='basesize'>BASE_SIZE</span> | `number` | 16 |
| DISABLED_OPACITY | `number` | 0.4 |
| GHOST_TRANSPARENCY | `string` | 40 |
| GHOST_ACTIVE_TRANSPARENCY | `string` | 73 |
| WHITE_TEXT_COLOR | [`ColorValue`](https://reactnative.dev/docs/colors) | <ColorView color={'#FFFFFF'}/> #FFFFFF |
| BLACK_TEXT_COLOR | [`ColorValue`](https://reactnative.dev/docs/colors) | <ColorView color={'#424242'}/> #424242 |
| DARK_OVERLAY | [`ColorValue`](https://reactnative.dev/docs/colors) | <ColorView color={'#00000021'}/> #00000021 |
| LIGHT_OVERLAY | [`ColorValue`](https://reactnative.dev/docs/colors) | <ColorView color={'#FFFFFF21'}/> #FFFFFF21 |
| BUTTON_PADDING_VERTICAL_MULTIPLIER | `number` | 0.16 |
| BUTTON_PADDING_HORIZONTAL_MULTIPLIER | `number` | 1 |
| [FONT_SIZE](#font_size) | `Enum` | |
| [BORDER_RADIUS](#border_radius) | `Enum` | |
| [BORDER_WIDTH](#border_width) | `Enum` | |

#### FONT_SIZE
|  Name   | Type | Value |
| ------- | ---- | ----- |
| small | `number` | [BASE_SIZE](#basesize) * 0.75 |
| default | `number` | [BASE_SIZE](#basesize) |
| medium | `number` | [BASE_SIZE](#basesize) * 1.25 |
| large | `number` | [BASE_SIZE](#basesize) * 1.5 |

#### BORDER_RADIUS
|  Name   | Type | Value |
| ------- | ---- | ----- |
| none | `number` | 0 |
| small | `number` | 2 |
| medium | `number` | 4 |
| large | `number` | 6 |
| full | `number` | 99999 |


#### BORDER_WIDTH
|  Name  | Type | Value |
| ------- | ---- | ----- |
| none | `number` | 0 |
| hairline | `number` | [`StyleSheet.hairlineWidth`](https://reactnative.dev/docs/stylesheet#hairlinewidth) |
| thin | `number` | 1 |
| base | `number` | 2 |
| thick | `number` | 3 |

For more details on how to start and how to use read the [documentation](https://redonalla.github.io/ra-framework-docks/).

## Local Storage

The Local Storage Packages is part of **FlexNative**, that provides an asynchronous, unencrypted, persistent, key-value storage API.

Local Storage can only store string data. In order to store object data, you need to serialize it first.
For data that can be serialized to JSON, you can use JSON.stringify() when saving the data and JSON.parse() when loading the data.

With `@flexnative/local-storage` you don't needs to serialize and deserialize strings to save or get object from local storage,
`@flexnative/local-storage` does it for you.

### Dependencies
- [`@react-native-async-storage/async-storage`](https://docs.expo.dev/versions/latest/sdk/async-storage/)

For more details on how to start and how to use read the [documentation](https://redonalla.github.io/ra-framework-docks/).