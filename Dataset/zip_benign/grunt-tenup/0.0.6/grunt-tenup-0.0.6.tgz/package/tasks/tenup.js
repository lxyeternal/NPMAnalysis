module.exports = function (grunt) {
    var tenup = require('tenup');

    grunt.registerMultiTask('tenup', 'Upload datasets using tenup', function () {
        var options = this.options({
            executable: tenup.getPathToTenup(), // the path to tenup executable (can be overridden)
            login: {TENTENGW: '', TENTENUID: '', TENTENPW: ''}, // login credentials:  TENTENGW, TENTENUID, TENTENPW  or any other args supported via env variables
            table: '',              // the path to the new table
            table_tree_file: '',    // XML file with information about the columns of the uploaded table
            flat_file: '',          // the name of the flat file to upload
            query_file: '',         // a query file containing sql to run against the source table
            sql: '',                // inline sql to run against the source table (used instead a query file)
            connection_string: '',  // odbc connection to use
            title: '',              // optional title for the new table
            args: '',               // additional tenup cmd line args such as -K -y etc.
            logTenUpCmd: false,     // log the full tenup command to the console,
            logResults: false       // log any query results to the console
        }, this.data);

        var done = this.async();
        tenup.execute(options, function (status, results) {
            if (status === false) {
                grunt.fail.fatal(results);
                return done(false);
            }

            if (options.logResults === true)
                grunt.log.writeln(results);

            done();
        });
    });
};
