# grunt-tenup

> Execute tenup commands


## Getting Started

If you haven't used [Grunt](http://gruntjs.com/) before, be sure to check out the [Getting Started](http://gruntjs.com/getting-started) guide, as it explains how to create a [Gruntfile](http://gruntjs.com/sample-gruntfile) as well as install and use Grunt plugins. Once you're familiar with that process, you may install this plugin with this command:

```shell
npm install grunt-tenup --save-dev
```

Once the plugin has been installed, it may be enabled inside your Gruntfile with this line of JavaScript:

```js
grunt.loadNpmTasks('grunt-tenup');
```

*This plugin was designed to work with Grunt 0.4.x. If you're still using grunt v0.3.x it's strongly recommended that [you upgrade](http://gruntjs.com/upgrading-from-0.3-to-0.4), but in case you can't please use [v0.3.2](https://github.com/gruntjs/grunt-contrib-clean/tree/grunt-0.3-stable).*



## tenup task
_Run this task with the `grunt tenup` command._

Task targets, files and options may be specified according to the grunt [Configuring tasks](http://gruntjs.com/configuring-tasks) guide.

### Options
For full definitions and documentation of the TenUp executable visit the [TenUp Documentation](https://www2.1010data.com/documentationcenter/beta/TenupUsersGuide/index_frames.html)   


### executable
Type: `String`  
Default: `Calls tenup.getPathToTenup`

This overrides the default value for the location of the tenup executable.

#### login
Type: `Object`  
Default: `none`

An object containing any valid login credentials based on tenup environment variable names.
[TENTENGW, TENTENUID, TENTENPW, etc]

#### table
Type: `String`  
Default: `none`

The path to the new table.

#### table_tree_file
Type: `String`  
Default: `none`

XML file with information about the columns of the uploaded table.

#### flat_file
Type: `String`  
Default: `none`

The name of the flat file to upload.

#### query_file
Type: `String`  
Default: `none`

A query file containing sql to run against the source table.

#### sql
Type: `String`  
Default: `none`

Inline sql to run against the source table (used instead a query file).

#### connection_string
Type: `String`  
Default: `none`

An odbc connection to use.

#### title
Type: `String`  
Default: `none`

Title for the new table.

#### args
Type: `String`  
Default: `none`

Additional command line args to pass to the tenup executable.

#### logTenUpCmd
Type: `Boolean`  
Default: `false`

Log the full command (including all args) used to execute the tenup cmd.

### Usage Examples

TODO

##Loading from ODBC-compliant databases with a query file
```
var options = {
    connection_string: 'DSN=sql1010odbc',
    table: 'path.to.my.new.table',
    query_file: 'queries/my_query.xml'
}
```

##Loading from ODBC-compliant databases with a sql command
```
var options = {
    connection_string: 'DSN=sql1010odbc',
    table: 'path.to.my.new.table',
    sql: 'SELECT * FROM my_src_table'
}
```

##Loading with a Flat File

```
var options = {
    table_tree_file: 'my_schema.xml',
    flat_file: 'my_data_file'
}
```