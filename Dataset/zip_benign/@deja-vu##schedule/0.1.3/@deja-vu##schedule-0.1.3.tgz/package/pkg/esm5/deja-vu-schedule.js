import { __awaiter, __extends, __generator, __read } from 'tslib';
import { CalendarDateFormatter, CalendarEventTitleFormatter, CalendarModule } from 'angular-calendar';
import { DatePipe, CommonModule } from '@angular/common';
import { getISOWeek, format, addHours, endOfDay, startOfDay } from 'date-fns';
import { pull, map, isNil, remove, uniq } from 'lodash';
import { InjectionToken, ChangeDetectorRef, Component, ElementRef, Inject, Input, EventEmitter, Output, ViewChild, NgModule } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { DvServiceFactory, DvModule } from '@deja-vu/core';
import { FormBuilder, FormControl, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as momentImported from 'moment';
import { MatButtonModule, MatDatepickerModule, MatFormFieldModule, MatInputModule, MatSelectModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CalendarWeekHoursViewModule } from 'angular-calendar-week-hours-view';

var CustomDateFormatterProvider = /** @class */ (function (_super) {
    __extends(CustomDateFormatterProvider, _super);
    function CustomDateFormatterProvider() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomDateFormatterProvider.prototype.dayViewHour = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new DatePipe(locale).transform(date, 'HH:mm', locale);
    };
    CustomDateFormatterProvider.prototype.weekViewTitle = function (_a) {
        var date = _a.date, locale = _a.locale;
        var year = new DatePipe(locale).transform(date, 'y', locale);
        var weekNumber = getISOWeek(date);
        return "Week " + weekNumber + " in " + year;
    };
    CustomDateFormatterProvider.prototype.weekViewColumnHeader = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new DatePipe(locale).transform(date, 'E', locale);
    };
    CustomDateFormatterProvider.prototype.weekViewColumnSubHeader = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new DatePipe(locale).transform(date, 'MM/dd', locale);
    };
    return CustomDateFormatterProvider;
}(CalendarDateFormatter));
var CustomEventTitleFormatterProvider = /** @class */ (function (_super) {
    __extends(CustomEventTitleFormatterProvider, _super);
    function CustomEventTitleFormatterProvider() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomEventTitleFormatterProvider.prototype.monthTooltip = function (event) {
        return;
    };
    CustomEventTitleFormatterProvider.prototype.weekTooltip = function (event) {
        return;
    };
    CustomEventTitleFormatterProvider.prototype.dayTooltip = function (event) {
        return;
    };
    return CustomEventTitleFormatterProvider;
}(CalendarEventTitleFormatter));
function timeRange(start, end) {
    return format(start, 'h[:]mm A') + " - " + format(end, 'h[:]mm A');
}
function dateTimeRange(start, end) {
    var formatString = 'dddd do MM Mh[:]mm A';
    return format(start, formatString) + " - " + format(end, formatString);
}
function createNewCalendarEvent(start, end, editable) {
    return {
        start: start,
        end: end,
        title: timeRange(start, end),
        cssClass: 'custom-event',
        color: {
            primary: '#488aff',
            secondary: '#bbd0f5'
        },
        resizable: {
            beforeStart: editable,
            afterEnd: editable
        },
        draggable: editable
    };
}
function slotToCalendarEvent(slot, editable) {
    var start = new Date(slot.startDate);
    var end = new Date(slot.endDate);
    return {
        id: slot.id,
        start: start,
        end: end,
        title: timeRange(start, end),
        cssClass: 'custom-event',
        color: {
            primary: '#488aff',
            secondary: '#bbd0f5'
        },
        resizable: {
            beforeStart: editable,
            afterEnd: editable
        },
        draggable: editable
    };
}
function slotsToCalendarEvents(slots, editable) {
    return map(slots, function (slot) { return slotToCalendarEvent(slot, editable); });
}
function calendarEventToSlot(event) {
    return {
        startDate: event.start.toISOString(),
        endDate: event.end.toISOString()
    };
}
function calendarEventsToSlots(events) {
    return map(events, calendarEventToSlot);
}
var API_PATH = new InjectionToken('api.path');
var SAVED_MSG_TIMEOUT = 3000;
var DRAG_TIMEOUT = 1000;
var CreateScheduleComponent = /** @class */ (function () {
    function CreateScheduleComponent(elem, dvf, cd, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.cd = cd;
        this.apiPath = apiPath;
        this.showOptionToSubmit = true;
        this.showOptionToChangeView = true;
        this.buttonLabel = 'Create Schedule';
        this.newScheduleSavedText = 'New schedule saved';
        this.removeSlotText = 'Do you want to remove the following slot:';
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.viewDate = new Date();
        this.isDragging = false;
        this.refresh = new Subject();
        this.newScheduleSaved = false;
        this.events = [];
    }
    CreateScheduleComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    CreateScheduleComponent.prototype.ngAfterViewInit = function () {
        this.cd.detectChanges();
    };
    CreateScheduleComponent.prototype.handleEvent = function (event) {
        if (confirm(this.removeSlotText + "\n    " + dateTimeRange(event.start, event.end) + "?")) {
            pull(this.events, event);
            this.refresh.next();
        }
    };
    CreateScheduleComponent.prototype.eventTimesChanged = function (_a) {
        var _this = this;
        var event = _a.event, newStart = _a.newStart, newEnd = _a.newEnd;
        if (this.isDragging) {
            return;
        }
        this.isDragging = true;
        event.start = newStart;
        event.end = newEnd;
        event.title = timeRange(newStart, newEnd);
        this.refresh.next();
        setTimeout(function () {
            _this.isDragging = false;
        }, DRAG_TIMEOUT);
    };
    CreateScheduleComponent.prototype.hourSegmentClicked = function (event) {
        var start = event.date;
        var end = addHours(event.date, this.eventLength);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.refresh.next();
    };
    CreateScheduleComponent.prototype.dayClicked = function (event) {
        var start = startOfDay(event.day.date);
        var end = endOfDay(event.day.date);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.refresh.next();
    };
    CreateScheduleComponent.prototype.onSubmit = function () {
        this.dvs.exec();
    };
    CreateScheduleComponent.prototype.dvOnExec = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dvs.post(this.apiPath, {
                            inputs: {
                                input: {
                                    id: this.id,
                                    slots: calendarEventsToSlots(this.events)
                                }
                            },
                            extraInfo: {
                                returnFields: 'id, availability { id, startDate, endDate }'
                            }
                        })];
                    case 1:
                        res = _a.sent();
                        if (res.errors) {
                            throw new Error(map(res.errors, 'message')
                                .join());
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateScheduleComponent.prototype.dvOnExecSuccess = function () {
        var _this = this;
        this.newScheduleSaved = true;
        window.setTimeout(function () {
            _this.newScheduleSaved = false;
        }, SAVED_MSG_TIMEOUT);
        this.events = [];
    };
    CreateScheduleComponent.prototype.dvOnExecFailure = function (reason) {
        this.newScheduleError = reason.message;
    };
    return CreateScheduleComponent;
}());
CreateScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-create-schedule',
                template: "<div *ngIf=\"showOptionToSubmit\">\n  <div *ngIf=\"newScheduleSaved\" class=\"create-schedule-success\">\n    <i class=\"material-icons\">done</i>\n    {{newScheduleSavedText}}\n  </div>\n  <mat-error *ngIf=\"newScheduleError\">\n    <i class=\"material-icons\">report_problem</i>\n    {{newScheduleError}}\n  </mat-error>\n</div>\n\n<div class=\"create-schedule\">\n  <div class=\"row text-center\">\n    <div class=\"col-md-6\">\n      <div class=\"btn-group\">\n        <div class=\"btn btn-primary\"\n          mwlCalendarPreviousView\n          [view]=\"view\"\n          [(viewDate)]=\"viewDate\">\n          Previous\n        </div>\n        <div class=\"btn btn-outline-secondary\"\n          mwlCalendarToday\n          [(viewDate)]=\"viewDate\">\n          Today\n        </div>\n        <div class=\"btn btn-primary\"\n          mwlCalendarNextView\n          [view]=\"view\"\n          [(viewDate)]=\"viewDate\">\n          Next\n        </div>\n      </div>\n    </div>\n\n    <div class=\"col-md-6\">\n      <div *ngIf=\"showOptionToChangeView\" class=\"btn-group\">\n        <div class=\"btn btn-primary\"\n          (click)=\"view = 'month'\"\n          [class.active]=\"view === 'month'\">\n          Month\n        </div>\n        <div class=\"btn btn-primary\"\n          (click)=\"view = 'week'\"\n          [class.active]=\"view === 'week'\">\n          Week\n        </div>\n        <div class=\"btn btn-primary\"\n          (click)=\"view = 'day'\"\n          [class.active]=\"view === 'day'\">\n          Day\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"row text-center view-info\">\n    <div class=\"col-md-12\">\n      <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>\n    </div>\n  </div>\n\n  <br />\n\n  <mwl-calendar-month-view\n    *ngIf=\"view === 'month'\"\n    [viewDate]=\"viewDate\"\n    [events]=\"events\"\n    (eventClicked)=\"handleEvent($event.event)\"\n    (eventTimesChanged)=\"eventTimesChanged($event)\"\n    (dayClicked)=\"dayClicked($event)\"\n    [refresh]=\"refresh\"\n    [locale]=\"locale\">\n  </mwl-calendar-month-view>\n\n  <iq-calendar-week-hours-view\n    *ngIf=\"view === 'week'\"\n    [viewDate]=\"viewDate\"\n    [events]=\"events\"\n    [hourSegments]=\"hourSegments\"\n    [dayStartHour]=\"dayStartHour\"\n    [dayEndHour]=\"dayEndHour\"\n    (eventClicked)=\"handleEvent($event.event)\"\n    (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n    (eventTimesChanged)=\"eventTimesChanged($event)\"\n    [refresh]=\"refresh\"\n    [locale]=\"locale\">\n  </iq-calendar-week-hours-view>\n\n  <mwl-calendar-day-view\n    *ngIf=\"view === 'day'\"\n    [viewDate]=\"viewDate\"\n    [events]=\"events\"\n    [hourSegments]=\"hourSegments\"\n    [dayStartHour]=\"dayStartHour\"\n    [dayEndHour]=\"dayEndHour\"\n    (eventClicked)=\"handleEvent($event.event)\"\n    (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n    (eventTimesChanged)=\"eventTimesChanged($event)\"\n    [refresh]=\"refresh\"\n    [locale]=\"locale\">\n  </mwl-calendar-day-view>\n</div>\n\n<div *ngIf=\"showOptionToSubmit\" class=\"form-group\">\n  <br />\n  <div class=\"dv-mat-button\">\n    <button mat-button class=\"create-schedule-submit-button\"\n      type=\"submit\" (click)=\"onSubmit()\">\n      {{buttonLabel}}\n    </button>\n  </div>\n</div>\n",
                styles: [".create-schedule-submit-button{float:right}.create-schedule-success{color:green}.view-info{margin-top:15px}"],
                providers: [
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
CreateScheduleComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: ChangeDetectorRef, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
CreateScheduleComponent.propDecorators = {
    "id": [{ type: Input },],
    "showOptionToSubmit": [{ type: Input },],
    "showOptionToChangeView": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "newScheduleSavedText": [{ type: Input },],
    "removeSlotText": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
};
var DeleteScheduleComponent = /** @class */ (function () {
    function DeleteScheduleComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
    }
    DeleteScheduleComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    DeleteScheduleComponent.prototype.deleteSchedule = function () {
        this.dvs.exec();
    };
    DeleteScheduleComponent.prototype.dvOnExec = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dvs.post(this.apiPath, {
                            inputs: {
                                id: this.id
                            }
                        })];
                    case 1:
                        res = _a.sent();
                        if (res.errors) {
                            throw new Error(map(res.errors, 'message')
                                .join());
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    return DeleteScheduleComponent;
}());
DeleteScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-delete-schedule',
                template: "<div class=\"dv-mat-button\">\n  <button mat-button (click)=\"deleteSchedule()\">\n    <i class=\"material-icons\">delete</i>\n  </button>\n</div>\n",
                styles: [""]
            },] },
];
DeleteScheduleComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
DeleteScheduleComponent.propDecorators = {
    "id": [{ type: Input },],
};
var ShowScheduleComponent = /** @class */ (function () {
    function ShowScheduleComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.scheduleWasGiven = false;
        this.loadedSchedule = new EventEmitter();
        this.showId = true;
        this.showAvailability = true;
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.viewDate = new Date();
        this.events = [];
    }
    Object.defineProperty(ShowScheduleComponent.prototype, "schedule", {
        get: function () { return this._schedule; },
        set: function (value) {
            if (!isNil(value)) {
                this.scheduleWasGiven = true;
                this.events = slotsToCalendarEvents(value.availability, false);
                this._schedule = value;
            }
        },
        enumerable: true,
        configurable: true
    });
    ShowScheduleComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dvs = this.dvf.forComponent(this)
            .withDefaultWaiter()
            .withRefreshCallback(function () { _this.load(); })
            .build();
    };
    ShowScheduleComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowScheduleComponent.prototype.ngOnChanges = function (changes) {
        if (this.dvs && this.dvs.waiter.processChanges(changes)) {
            this.load();
        }
    };
    ShowScheduleComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowScheduleComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var res, schedule;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.waitAndGet(this.apiPath, function () { return ({
                                params: {
                                    inputs: {
                                        id: _this.id
                                    },
                                    extraInfo: {
                                        returnFields: "\n                " + (_this.showId ? 'id' : '') + "\n                " + (_this.showAvailability ? 'availability { startDate, endDate }'
                                            : '') + "\n              "
                                    }
                                }
                            }); })];
                    case 1:
                        res = _a.sent();
                        schedule = res.data.schedule;
                        this.events = slotsToCalendarEvents(schedule.availability, false);
                        this._schedule = schedule;
                        this.loadedSchedule.emit(schedule);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowScheduleComponent.prototype.ngOnDestroy = function () {
        this.dvs.onDestroy();
    };
    ShowScheduleComponent.prototype.canEval = function () {
        return !!(this.dvs && !this.scheduleWasGiven);
    };
    return ShowScheduleComponent;
}());
ShowScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-schedule',
                template: "<span *ngIf=\"_schedule\">\n  <div *ngIf=\"showId\">\n    {{_schedule.id}}\n  </div>\n\n  <div *ngIf=\"showAvailability\">\n    <div class=\"row text-center\">\n      <div class=\"col-md-4\">\n        <div class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            mwlCalendarPreviousView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Previous\n          </div>\n          <div class=\"btn btn-outline-secondary\"\n            mwlCalendarToday\n            [(viewDate)]=\"viewDate\">\n            Today\n          </div>\n          <div class=\"btn btn-primary\"\n            mwlCalendarNextView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Next\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-4\">\n        <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>\n      </div>\n\n      <div class=\"col-md-4\">\n        <div class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'month'\"\n            [class.active]=\"view === 'month'\">\n            Month\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'week'\"\n            [class.active]=\"view === 'week'\">\n            Week\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'day'\"\n            [class.active]=\"view === 'day'\">\n            Day\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <br />\n\n    <mwl-calendar-month-view\n      *ngIf=\"view === 'month'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-month-view>\n\n    <iq-calendar-week-hours-view\n      *ngIf=\"view === 'week'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </iq-calendar-week-hours-view>\n\n    <mwl-calendar-day-view\n      *ngIf=\"view === 'day'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-day-view>\n  </div>\n</span>\n",
                styles: [".custom-event a{color:#fff!important;font-weight:700;text-decoration:none}.cal-day-view .cal-event{white-space:normal}.cal-day-view .cal-event-container{width:100%!important}.cal-day-view .cal-time{width:40px!important;font-size:smaller!important}.cal-week-hours-view .cal-day-container:first-child{width:40px!important;-webkit-box-flex:0;-ms-flex:none;flex:none}.cal-week-hours-view .cal-header:first-child{width:40px!important;-webkit-box-flex:0;-ms-flex:none;flex:none;border:none}.cal-header{border-left:1px solid #e1e1e1}.cal-today{color:pink}"],
                providers: [
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
ShowScheduleComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
ShowScheduleComponent.propDecorators = {
    "waitOn": [{ type: Input },],
    "id": [{ type: Input },],
    "schedule": [{ type: Input },],
    "loadedSchedule": [{ type: Output },],
    "showId": [{ type: Input },],
    "showAvailability": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
};
var SAVED_MSG_TIMEOUT$1 = 3000;
var DRAG_TIMEOUT$1 = 1000;
var UpdateScheduleComponent = /** @class */ (function () {
    function UpdateScheduleComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.waitOn = [];
        this.showOptionToSubmit = true;
        this.showOptionToChangeView = true;
        this.buttonLabel = 'Update Schedule';
        this.updateScheduleSavedText = 'Schedule updated';
        this.deleteSlotText = 'Do you want to delete the following slot:';
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.viewDate = new Date();
        this.isDragging = false;
        this.refresh = new Subject();
        this.updateScheduleSaved = false;
        this.events = [];
        this.newEvents = [];
        this.deletedEventIds = [];
    }
    UpdateScheduleComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .withDefaultWaiter()
            .build();
    };
    UpdateScheduleComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    UpdateScheduleComponent.prototype.ngOnChanges = function (changes) {
        if (this.dvs && this.dvs.waiter.processChanges(changes)) {
            this.load();
        }
    };
    UpdateScheduleComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    UpdateScheduleComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.waitAndGet(this.apiPath, function () { return ({
                                params: {
                                    inputs: { id: _this.id },
                                    extraInfo: {
                                        action: 'load',
                                        returnFields: 'id, availability { id, startDate, endDate }'
                                    }
                                }
                            }); })];
                    case 1:
                        res = _a.sent();
                        if (!isNil(res.data.schedule)) {
                            this.schedule = res.data.schedule;
                            this.events = slotsToCalendarEvents(this.schedule.availability, true);
                        }
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    UpdateScheduleComponent.prototype.handleEvent = function (event) {
        if (confirm(this.deleteSlotText + "\n    " + dateTimeRange(event.start, event.end) + "?")) {
            pull(this.events, event);
            this.deletedEventIds.push(event.id.toString());
            this.refresh.next();
        }
    };
    UpdateScheduleComponent.prototype.eventTimesChanged = function (_a) {
        var _this = this;
        var event = _a.event, newStart = _a.newStart, newEnd = _a.newEnd;
        if (this.isDragging) {
            return;
        }
        this.isDragging = true;
        this.deletedEventIds.push(event.id.toString());
        remove(this.newEvents, function (e) { return e.id === event.id; });
        event.start = newStart;
        event.end = newEnd;
        event.title = timeRange(newStart, newEnd);
        this.newEvents.push(event);
        this.refresh.next();
        setTimeout(function () {
            _this.isDragging = false;
        }, DRAG_TIMEOUT$1);
    };
    UpdateScheduleComponent.prototype.hourSegmentClicked = function (event) {
        var start = event.date;
        var end = addHours(event.date, this.eventLength);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.newEvents.push(newEvent);
        this.refresh.next();
    };
    UpdateScheduleComponent.prototype.dayClicked = function (event) {
        var start = startOfDay(event.day.date);
        var end = endOfDay(event.day.date);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.newEvents.push(newEvent);
        this.refresh.next();
    };
    UpdateScheduleComponent.prototype.onSubmit = function () {
        this.dvs.exec();
    };
    UpdateScheduleComponent.prototype.dvOnExec = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dvs.post(this.apiPath, {
                            inputs: {
                                input: {
                                    id: this.id,
                                    add: calendarEventsToSlots(this.newEvents),
                                    delete: uniq(this.deletedEventIds)
                                }
                            },
                            extraInfo: {
                                action: 'update'
                            }
                        })];
                    case 1:
                        res = _a.sent();
                        if (res.errors) {
                            throw new Error(map(res.errors, 'message')
                                .join());
                        }
                        return [2 /*return*/, res.data.updateSchedule];
                }
            });
        });
    };
    UpdateScheduleComponent.prototype.dvOnExecSuccess = function () {
        var _this = this;
        this.updateScheduleSaved = true;
        this.updateScheduleError = '';
        window.setTimeout(function () {
            _this.updateScheduleSaved = false;
        }, SAVED_MSG_TIMEOUT$1);
    };
    UpdateScheduleComponent.prototype.dvOnExecFailure = function (reason) {
        this.updateScheduleError = reason.message;
    };
    UpdateScheduleComponent.prototype.canEval = function () {
        return !!(this.dvs && this.id);
    };
    return UpdateScheduleComponent;
}());
UpdateScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-update-schedule',
                template: "<div *ngIf=\"schedule\">\n  <div *ngIf=\"showOptionToSubmit\">\n    <div *ngIf=\"updateScheduleSaved\" class=\"update-schedule-success\">\n      <i class=\"material-icons\">done</i>\n      {{updateScheduleSavedText}}\n    </div>\n    <mat-error *ngIf=\"updateScheduleError\">\n      <i class=\"material-icons\">report_problem</i>\n      {{updateScheduleError}}\n    </mat-error>\n  </div>\n\n  <div class=\"update-schedule\">\n    <div class=\"row text-center\">\n      <div class=\"col-md-6\">\n        <div class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            mwlCalendarPreviousView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Previous\n          </div>\n          <div class=\"btn btn-outline-secondary\"\n            mwlCalendarToday\n            [(viewDate)]=\"viewDate\">\n            Today\n          </div>\n          <div class=\"btn btn-primary\"\n            mwlCalendarNextView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Next\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-6\">\n        <div *ngIf=\"showOptionToChangeView\" class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'month'\"\n            [class.active]=\"view === 'month'\">\n            Month\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'week'\"\n            [class.active]=\"view === 'week'\">\n            Week\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'day'\"\n            [class.active]=\"view === 'day'\">\n            Day\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"row text-center view-info\">\n      <div class=\"col-md-4\">\n        <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>\n      </div>\n    </div>\n\n    <br />\n\n    <mwl-calendar-month-view\n      *ngIf=\"view === 'month'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      (eventClicked)=\"handleEvent($event.event)\"\n      (eventTimesChanged)=\"eventTimesChanged($event)\"\n      (dayClicked)=\"dayClicked($event)\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-month-view>\n\n    <iq-calendar-week-hours-view\n      *ngIf=\"view === 'week'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      (eventClicked)=\"handleEvent($event.event)\"\n      (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n      (eventTimesChanged)=\"eventTimesChanged($event)\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </iq-calendar-week-hours-view>\n\n    <mwl-calendar-day-view\n      *ngIf=\"view === 'day'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      (eventClicked)=\"handleEvent($event.event)\"\n      (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n      (eventTimesChanged)=\"eventTimesChanged($event)\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-day-view>\n  </div>\n  <div *ngIf=\"showOptionToSubmit\" class=\"form-group\">\n    <br />\n    <div class=\"dv-mat-button\">\n      <button mat-raised-button class=\"update-schedule-submit-button\"\n        type=\"submit\" (click)=\"onSubmit()\">\n        {{buttonLabel}}\n      </button>\n    </div>\n  </div>\n</div>\n",
                styles: [".update-schedule-submit-button{float:right}.update-schedule-success{color:green}.view-info{margin-top:15px}"],
                providers: [
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
UpdateScheduleComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
UpdateScheduleComponent.propDecorators = {
    "waitOn": [{ type: Input },],
    "id": [{ type: Input },],
    "showOptionToSubmit": [{ type: Input },],
    "showOptionToChangeView": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "updateScheduleSavedText": [{ type: Input },],
    "deleteSlotText": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
};
var ShowSlotComponent = /** @class */ (function () {
    function ShowSlotComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.loadedSlot = new EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
    }
    ShowSlotComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowSlotComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowSlotComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowSlotComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowSlotComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: {
                                        id: this.id
                                    },
                                    extraInfo: {
                                        returnFields: "\n              " + (this.showId ? 'id' : '') + "\n              " + (this.showStartDate ? 'startDate' : '') + "\n              " + (this.showEndDate ? 'endDate' : '') + "\n            "
                                    }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.slot = res.data.slot;
                        this.loadedSlot.emit(this.slot);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowSlotComponent.prototype.canEval = function () {
        return !!(!this.slot && this.id && this.dvs);
    };
    return ShowSlotComponent;
}());
ShowSlotComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-slot',
                template: "<span *ngIf=\"slot\">\n  <div *ngIf=\"showId\">\n    {{ slot.id }}\n  </div>\n\n  <div *ngIf=\"showStartDate\">\n    {{ slot.startDate | date: dateTimeFormatString }}\n  </div>\n\n  <div *ngIf=\"showEndDate\">\n    {{ slot.endDate | date: dateTimeFormatString }}\n  </div>\n</span>\n",
                styles: [""]
            },] },
];
ShowSlotComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
ShowSlotComponent.propDecorators = {
    "id": [{ type: Input },],
    "slot": [{ type: Input },],
    "loadedSlot": [{ type: Output },],
    "showId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
};
function endDateValidator(getStartDate) {
    return function (control) {
        var startDate = getStartDate();
        var endDate = control.value;
        if (!(startDate && endDate)) {
            return null;
        }
        if (endDate.isBefore(startDate)) {
            return { endDateBeforeStartDate: true };
        }
        return null;
    };
}
function endTimeValidator(getStartTime) {
    return function (control) {
        var startTime = getStartTime();
        var endTime = control.value;
        if (!(startTime && endTime)) {
            return null;
        }
        var _a = __read(startTime.split(':'), 2), startHh = _a[0], startMm = _a[1];
        var _b = __read(endTime.split(':'), 2), endHh = _b[0], endMm = _b[1];
        if (startHh > endHh || (startHh === endHh && startMm >= endMm)) {
            return { endTimeBeforeStartTime: true };
        }
        return null;
    };
}
var moment = momentImported;
var ShowSlotsComponent = /** @class */ (function () {
    function ShowSlotsComponent(elem, dvf, builder, apiPath) {
        var _this = this;
        this.elem = elem;
        this.dvf = dvf;
        this.builder = builder;
        this.apiPath = apiPath;
        this.showDateTimePicker = true;
        this.buttonLabel = 'Filter Availability';
        this.sortByStartDate = 'asc';
        this.sortByEndDate = 'asc';
        this.loadedSlots = new EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
        this.showSlot = {
            type: (ShowSlotComponent)
        };
        this.startDateControl = new FormControl('');
        this.endDateControl = new FormControl('', [
            endDateValidator(function () { return _this.startDateControl.value; })
        ]);
        this.startTimeControl = new FormControl('');
        this.endTimeControl = new FormControl('', [
            endTimeValidator(function () { return _this.startTimeControl.value; })
        ]);
        this.dateTimeFilterForm = this.builder.group({
            startsOn: this.startDateControl,
            endsOn: this.endDateControl,
            startTime: this.startTimeControl,
            endTime: this.endTimeControl
        });
        this.showSlots = this;
    }
    Object.defineProperty(ShowSlotsComponent.prototype, "startDate", {
        set: function (value) {
            this.startDateControl.setValue(moment(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowSlotsComponent.prototype, "endDate", {
        set: function (value) {
            this.endDateControl.setValue(moment(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowSlotsComponent.prototype, "startTime", {
        set: function (value) {
            this.startTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowSlotsComponent.prototype, "endTime", {
        set: function (value) {
            this.endTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    ShowSlotsComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowSlotsComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowSlotsComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowSlotsComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowSlotsComponent.prototype.filterSlots = function () {
        this.dvs.eval();
    };
    ShowSlotsComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var startDate, endDate, res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        startDate = this.startDateControl.value ?
                            this.startDateControl.value.format('YYYY-MM-DD') : '';
                        endDate = this.endDateControl.value ?
                            this.endDateControl.value.format('YYYY-MM-DD') : '';
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: JSON.stringify({
                                        input: {
                                            scheduleId: this.scheduleId,
                                            startDate: startDate,
                                            endDate: endDate,
                                            startTime: this.startTimeControl.value,
                                            endTime: this.endTimeControl.value,
                                            sortByStartDate: this.sortByStartDate === 'asc' ? 1 : -1,
                                            sortByEndDate: this.sortByEndDate === 'asc' ? 1 : -1
                                        }
                                    }),
                                    extraInfo: {
                                        returnFields: "\n                " + (this.showId ? 'id' : '') + "\n                " + (this.showStartDate ? 'startDate' : '') + "\n                " + (this.showEndDate ? 'endDate' : '') + "\n              "
                                    }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.slots = res.data.slots;
                        this.loadedSlots.emit(this.slots);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowSlotsComponent.prototype.canEval = function () {
        return !!(!this.slots && this.scheduleId && this.dvs);
    };
    return ShowSlotsComponent;
}());
ShowSlotsComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-slots',
                template: "<div *ngIf=\"showDateTimePicker\">\n  <form (ngSubmit)=\"filterSlots()\" [formGroup]=\"dateTimeFilterForm\"\n    class=\"form-horizontal\">\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Date</mat-label>\n        <input matInput [matDatepicker]=\"startDatePicker\"\n         [formControl]=\"startDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"startDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #startDatePicker></mat-datepicker>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"startTimeControl\">\n      </mat-form-field>\n    </div>\n\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Date</mat-label>\n        <input matInput [matDatepicker]=\"endDatePicker\"\n          [formControl]=\"endDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"endDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #endDatePicker></mat-datepicker>\n        <mat-error *ngIf=\"endDateControl.hasError('endDateBeforeStartDate')\">\n          End Date should be <strong>after</strong> Start Date\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"endTimeControl\">\n        <mat-error *ngIf=\"endTimeControl.hasError('endTimeBeforeStartTime')\">\n          End Time should be <strong>after</strong> Start Time\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <button mat-button type=\"submit\">\n        {{buttonLabel}}\n      </button>\n    </div>\n  </form>\n</div>\n\n<ul *ngIf=\"slots && slots.length > 0\" class=\"list-group\">\n  <li *ngFor=\"let slot of slots\" class=\"list-group-item\">\n    <dv-include\n      [component]=\"showSlot\"\n      default-showSlot=\"{ tag: schedule-show-slot }\"\n      [inputs]=\"{\n        slot: slot, showId: showId,\n        showStartDate: showStartDate,\n        showEndDate: showEndDate,\n        dateTimeFormatString: dateTimeFormatString\n      }\"\n      [parent]=\"showSlots\">\n    </dv-include>\n  </li>\n</ul>\n\n<div *ngIf=\"!slots || slots.length === 0\">\n  <span>{{noSlotsToShowText}}</span>\n</div>\n",
                styles: [""]
            },] },
];
ShowSlotsComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: FormBuilder, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
ShowSlotsComponent.propDecorators = {
    "scheduleId": [{ type: Input },],
    "slots": [{ type: Input },],
    "showDateTimePicker": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "startDate": [{ type: Input },],
    "endDate": [{ type: Input },],
    "startTime": [{ type: Input },],
    "endTime": [{ type: Input },],
    "sortByStartDate": [{ type: Input },],
    "sortByEndDate": [{ type: Input },],
    "loadedSlots": [{ type: Output },],
    "showId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
    "showSlot": [{ type: Input },],
    "form": [{ type: ViewChild, args: [FormGroupDirective,] },],
};
var ShowNextAvailabilityComponent = /** @class */ (function () {
    function ShowNextAvailabilityComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.loadedNextAvailability = new EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
        this.showSlot = {
            type: (ShowSlotComponent)
        };
        this.showNextAvailability = this;
    }
    ShowNextAvailabilityComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowNextAvailabilityComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowNextAvailabilityComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowNextAvailabilityComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowNextAvailabilityComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: JSON.stringify({
                                        input: {
                                            scheduleIds: this.scheduleIds
                                        }
                                    }),
                                    extraInfo: {
                                        returnFields: "\n              " + (this.showId ? 'id' : '') + "\n              " + (this.showStartDate ? 'startDate' : '') + "\n              " + (this.showEndDate ? 'endDate' : '') + "\n            "
                                    }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.nextAvailability = res.data.nextAvailability;
                        this.loadedNextAvailability.emit(this.nextAvailability);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowNextAvailabilityComponent.prototype.canEval = function () {
        return !!(!this.nextAvailability && this.scheduleIds && this.dvs);
    };
    return ShowNextAvailabilityComponent;
}());
ShowNextAvailabilityComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-next-availability',
                template: "<span *ngIf=\"nextAvailability\">\n  <dv-include\n    [component]=\"showSlot\"\n    default-showSlot=\"{ tag: schedule-show-slot }\"\n    [inputs]=\"{\n      slot: nextAvailability, showId: showId,\n      showStartDate: showStartDate,\n      showEndDate: showEndDate,\n      dateTimeFormatString: dateTimeFormatString\n    }\"\n    [parent]=\"showNextAvailability\">\n  </dv-include>\n</span>\n",
                styles: [""]
            },] },
];
ShowNextAvailabilityComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
ShowNextAvailabilityComponent.propDecorators = {
    "scheduleIds": [{ type: Input },],
    "loadedNextAvailability": [{ type: Output },],
    "showId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
    "showSlot": [{ type: Input },],
};
var moment$1 = momentImported;
var ShowAllAvailabilityComponent = /** @class */ (function () {
    function ShowAllAvailabilityComponent(elem, dvf, builder, apiPath) {
        var _this = this;
        this.elem = elem;
        this.dvf = dvf;
        this.builder = builder;
        this.apiPath = apiPath;
        this.showDateTimePicker = true;
        this.buttonLabel = 'Filter Slots';
        this.sortByStartDate = 'asc';
        this.sortByEndDate = 'asc';
        this.loadedAllAvailability = new EventEmitter();
        this.showScheduleView = true;
        this.showScheduleId = false;
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.showSchedule = {
            type: (ShowScheduleComponent)
        };
        this.showSlotsView = true;
        this.showSlotId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
        this.showSlots = {
            type: (ShowSlotsComponent)
        };
        this.showSlot = {
            type: (ShowSlotComponent)
        };
        this.startDateControl = new FormControl('');
        this.endDateControl = new FormControl('', [
            endDateValidator(function () { return _this.startDateControl.value; })
        ]);
        this.startTimeControl = new FormControl('');
        this.endTimeControl = new FormControl('', [
            endTimeValidator(function () { return _this.startTimeControl.value; })
        ]);
        this.dateTimeFilterForm = this.builder.group({
            startsOn: this.startDateControl,
            endsOn: this.endDateControl,
            startTime: this.startTimeControl,
            endTime: this.endTimeControl
        });
        this.showSlotsDateTimePicker = false;
        this.showAllAvailability = this;
    }
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "startDate", {
        set: function (value) {
            this.startDateControl.setValue(moment$1(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "endDate", {
        set: function (value) {
            this.endDateControl.setValue(moment$1(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "startTime", {
        set: function (value) {
            this.startTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "endTime", {
        set: function (value) {
            this.endTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    ShowAllAvailabilityComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowAllAvailabilityComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowAllAvailabilityComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowAllAvailabilityComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowAllAvailabilityComponent.prototype.filterSlots = function () {
        this.dvs.eval();
    };
    ShowAllAvailabilityComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var startDate, endDate, res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        startDate = this.startDateControl.value ?
                            this.startDateControl.value.format('YYYY-MM-DD') : '';
                        endDate = this.endDateControl.value ?
                            this.endDateControl.value.format('YYYY-MM-DD') : '';
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: JSON.stringify({
                                        input: {
                                            scheduleIds: this.scheduleIds,
                                            startDate: startDate,
                                            endDate: endDate,
                                            startTime: this.startTimeControl.value,
                                            endTime: this.endTimeControl.value,
                                            sortByStartDate: this.sortByStartDate === 'asc' ? 1 : -1,
                                            sortByEndDate: this.sortByEndDate === 'asc' ? 1 : -1
                                        }
                                    }),
                                    extraInfo: { returnFields: 'id, startDate, endDate' }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.allAvailability = res.data.allAvailability;
                        this.schedule = {
                            id: 'all-availability',
                            availability: this.allAvailability
                        };
                        this.loadedAllAvailability.emit(this.allAvailability);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowAllAvailabilityComponent.prototype.canEval = function () {
        return !!(!this.allAvailability && this.scheduleIds && this.dvs);
    };
    return ShowAllAvailabilityComponent;
}());
ShowAllAvailabilityComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-all-availability',
                template: "<div *ngIf=\"showDateTimePicker\">\n  <form (ngSubmit)=\"filterSlots()\" [formGroup]=\"dateTimeFilterForm\"\n    class=\"form-horizontal\">\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Date</mat-label>\n        <input matInput [matDatepicker]=\"startDatePicker\"\n         [formControl]=\"startDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"startDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #startDatePicker></mat-datepicker>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"startTimeControl\">\n      </mat-form-field>\n    </div>\n\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Date</mat-label>\n        <input matInput [matDatepicker]=\"endDatePicker\"\n          [formControl]=\"endDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"endDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #endDatePicker></mat-datepicker>\n        <mat-error *ngIf=\"endDateControl.hasError('endDateBeforeStartDate')\">\n          End Date should be <strong>after</strong> Start Date\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"endTimeControl\">\n        <mat-error *ngIf=\"endTimeControl.hasError('endTimeBeforeStartTime')\">\n          End Time should be <strong>after</strong> Start Time\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <div class=\"dv-mat-button\">\n        <button mat-button type=\"submit\">\n          {{buttonLabel}}\n        </button>\n      </div>\n    </div>\n  </form>\n</div>\n\n<span *ngIf=\"allAvailability\">\n  <span *ngIf=\"showScheduleView\">\n    <dv-include\n      [component]=\"showSchedule\"\n      default-showSchedule=\"{ tag: schedule-show-schedule }\"\n      [inputs]=\"{\n        schedule: schedule, showId: showScheduleId,\n        view: view, locale: locale, hourSegments: hourSegments,\n        dayStartHour: dayStartHour, dayEndHour: dayEndHour,\n        eventLength: eventLength\n      }\"\n      [parent]=\"showAllAvailability\">\n    </dv-include>\n  </span>\n\n  <span *ngIf=\"showSlotsView\">\n    <dv-include\n      [component]=\"showSlots\"\n      default-showSlots=\"{ tag: schedule-show-slots }\"\n      [inputs]=\"{\n        slots: allAvailability, showId: showSlotId,\n        showStartDate: showStartDate, showEndDate: showEndDate,\n        showDateTimePicker: showSlotsDateTimePicker,\n        dateTimeFormatString: dateTimeFormatString,\n        showSlot: showSlot\n      }\"\n      [parent]=\"showAllAvailability\">\n    </dv-include>\n  </span>\n</span>\n",
                styles: [""]
            },] },
];
ShowAllAvailabilityComponent.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: FormBuilder, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
]; };
ShowAllAvailabilityComponent.propDecorators = {
    "scheduleIds": [{ type: Input },],
    "showDateTimePicker": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "startDate": [{ type: Input },],
    "endDate": [{ type: Input },],
    "startTime": [{ type: Input },],
    "endTime": [{ type: Input },],
    "sortByStartDate": [{ type: Input },],
    "sortByEndDate": [{ type: Input },],
    "loadedAllAvailability": [{ type: Output },],
    "showScheduleView": [{ type: Input },],
    "showScheduleId": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
    "showSchedule": [{ type: Input },],
    "showSlotsView": [{ type: Input },],
    "showSlotId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
    "showSlots": [{ type: Input },],
    "showSlot": [{ type: Input },],
    "form": [{ type: ViewChild, args: [FormGroupDirective,] },],
};
var allComponents = [
    CreateScheduleComponent, DeleteScheduleComponent,
    ShowScheduleComponent, UpdateScheduleComponent,
    ShowSlotComponent, ShowSlotsComponent, ShowNextAvailabilityComponent,
    ShowAllAvailabilityComponent
];
var metadata = {
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        DvModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule, MatInputModule, MatFormFieldModule,
        MatSelectModule, MatDatepickerModule, MatMomentDateModule,
        CalendarModule.forRoot(),
        CalendarWeekHoursViewModule
    ],
    declarations: allComponents,
    entryComponents: allComponents,
    exports: allComponents
};
var ScheduleModule = /** @class */ (function () {
    function ScheduleModule() {
    }
    return ScheduleModule;
}());
ScheduleModule.decorators = [
    { type: NgModule, args: [Object.assign({}, metadata, { providers: [{ provide: API_PATH, useValue: '/graphql' }] }),] },
];

export { ScheduleModule, CreateScheduleComponent, DeleteScheduleComponent, ShowScheduleComponent, UpdateScheduleComponent, ShowSlotComponent, ShowSlotsComponent, ShowNextAvailabilityComponent, ShowAllAvailabilityComponent, metadata, API_PATH as ɵa, CustomDateFormatterProvider as ɵb, CustomEventTitleFormatterProvider as ɵc };
//# sourceMappingURL=deja-vu-schedule.js.map
