import { AbstractControl, ValidationErrors } from '@angular/forms';
export declare function endDateValidator(getStartDate: () => any): ((control: AbstractControl) => ValidationErrors);
export declare function endTimeValidator(getStartTime: () => string): ((control: AbstractControl) => ValidationErrors);
