import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnInit } from '@angular/core';
import { DvServiceFactory, OnEval } from '@deja-vu/core';
import { Slot } from '../shared/schedule.model';
export declare class ShowSlotComponent implements AfterViewInit, OnChanges, OnEval, OnInit {
    private elem;
    private dvf;
    private apiPath;
    id: string | undefined;
    slot: Slot | undefined;
    loadedSlot: EventEmitter<{}>;
    showId: boolean;
    showStartDate: boolean;
    showEndDate: boolean;
    dateTimeFormatString: string;
    private dvs;
    constructor(elem: ElementRef, dvf: DvServiceFactory, apiPath: any);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    load(): void;
    dvOnEval(): Promise<void>;
    private canEval();
}
