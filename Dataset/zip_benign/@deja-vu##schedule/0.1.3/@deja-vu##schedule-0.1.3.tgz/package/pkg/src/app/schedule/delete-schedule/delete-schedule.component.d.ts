import { ElementRef, OnInit } from '@angular/core';
import { DvServiceFactory, OnExec } from '@deja-vu/core';
export declare class DeleteScheduleComponent implements OnInit, OnExec {
    private elem;
    private dvf;
    private apiPath;
    id: string;
    private dvs;
    constructor(elem: ElementRef, dvf: DvServiceFactory, apiPath: any);
    ngOnInit(): void;
    deleteSchedule(): void;
    dvOnExec(): Promise<void>;
}
