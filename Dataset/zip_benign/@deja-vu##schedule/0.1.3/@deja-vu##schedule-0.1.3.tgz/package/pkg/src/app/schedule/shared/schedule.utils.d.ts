import { CalendarEvent } from 'calendar-utils';
import { Slot } from './schedule.model';
export declare function timeRange(start: Date, end: Date): string;
export declare function dateTimeRange(start: Date, end: Date): string;
export declare function createNewCalendarEvent(start: Date, end: Date, editable: boolean): CalendarEvent;
export declare function slotToCalendarEvent(slot: Slot, editable: boolean): CalendarEvent;
export declare function slotsToCalendarEvents(slots: Slot[], editable: boolean): CalendarEvent[];
export declare function calendarEventToSlot(event: CalendarEvent): Slot;
export declare function calendarEventsToSlots(events: CalendarEvent[]): Slot[];
