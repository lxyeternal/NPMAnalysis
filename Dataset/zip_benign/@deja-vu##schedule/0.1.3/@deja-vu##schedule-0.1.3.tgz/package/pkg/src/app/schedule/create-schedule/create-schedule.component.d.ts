import { AfterViewInit, ChangeDetectorRef, ElementRef, OnInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { CalendarEvent, CalendarEventTimesChangedEvent } from 'angular-calendar';
import { MonthViewDay } from 'calendar-utils';
import { DvServiceFactory, OnExec, OnExecFailure, OnExecSuccess } from '@deja-vu/core';
export declare class CreateScheduleComponent implements AfterViewInit, OnInit, OnExec, OnExecFailure, OnExecSuccess {
    private elem;
    private dvf;
    private cd;
    private apiPath;
    id: string | undefined;
    showOptionToSubmit: boolean;
    showOptionToChangeView: boolean;
    buttonLabel: string;
    newScheduleSavedText: string;
    removeSlotText: string;
    view: 'day' | 'week' | 'month';
    locale: string;
    hourSegments: number;
    dayStartHour: number;
    dayEndHour: number;
    eventLength: number;
    viewDate: Date;
    isDragging: boolean;
    refresh: Subject<any>;
    newScheduleSaved: boolean;
    newScheduleError: string;
    events: CalendarEvent[];
    private dvs;
    constructor(elem: ElementRef, dvf: DvServiceFactory, cd: ChangeDetectorRef, apiPath: any);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    handleEvent(event: CalendarEvent): void;
    eventTimesChanged({event, newStart, newEnd}: CalendarEventTimesChangedEvent): void;
    hourSegmentClicked(event: {
        date: Date;
    }): void;
    dayClicked(event: {
        day: MonthViewDay;
    }): void;
    onSubmit(): void;
    dvOnExec(): Promise<void>;
    dvOnExecSuccess(): void;
    dvOnExecFailure(reason: Error): void;
}
