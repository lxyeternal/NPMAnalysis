import { CalendarDateFormatter, CalendarEventTitleFormatter, DateFormatterParams } from 'angular-calendar';
import { CalendarEvent } from 'calendar-utils';
export declare class CustomDateFormatterProvider extends CalendarDateFormatter {
    dayViewHour({date, locale}: DateFormatterParams): string;
    weekViewTitle({date, locale}: DateFormatterParams): string;
    weekViewColumnHeader({date, locale}: DateFormatterParams): string;
    weekViewColumnSubHeader({date, locale}: DateFormatterParams): string;
}
export declare class CustomEventTitleFormatterProvider extends CalendarEventTitleFormatter {
    monthTooltip(event: CalendarEvent): string;
    weekTooltip(event: CalendarEvent): string;
    dayTooltip(event: CalendarEvent): string;
}
