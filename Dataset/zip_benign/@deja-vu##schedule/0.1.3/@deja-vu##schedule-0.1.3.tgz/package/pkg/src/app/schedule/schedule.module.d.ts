export declare class ScheduleModule {
}
