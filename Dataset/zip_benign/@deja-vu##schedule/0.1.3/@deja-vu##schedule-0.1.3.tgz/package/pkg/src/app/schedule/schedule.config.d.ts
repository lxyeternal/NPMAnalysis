import { InjectionToken } from '@angular/core';
export declare const API_PATH: InjectionToken<string>;
