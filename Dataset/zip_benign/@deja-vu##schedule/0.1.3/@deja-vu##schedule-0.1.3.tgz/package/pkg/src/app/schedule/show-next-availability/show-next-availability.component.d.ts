import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnInit } from '@angular/core';
import { ComponentValue, DvServiceFactory, OnEval } from '@deja-vu/core';
import { Slot } from '../shared/schedule.model';
export declare class ShowNextAvailabilityComponent implements AfterViewInit, OnChanges, OnEval, OnInit {
    private elem;
    private dvf;
    private apiPath;
    scheduleIds: string[];
    loadedNextAvailability: EventEmitter<{}>;
    showId: boolean;
    showStartDate: boolean;
    showEndDate: boolean;
    dateTimeFormatString: string;
    showSlot: ComponentValue;
    nextAvailability: Slot;
    showNextAvailability: any;
    private dvs;
    constructor(elem: ElementRef, dvf: DvServiceFactory, apiPath: any);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    load(): void;
    dvOnEval(): Promise<void>;
    private canEval();
}
