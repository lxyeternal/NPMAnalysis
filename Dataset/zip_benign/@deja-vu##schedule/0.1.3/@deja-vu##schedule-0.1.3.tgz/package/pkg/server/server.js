"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const concept_server_1 = require("@deja-vu/concept-server");
const date_fns_1 = require("date-fns");
const _ = require("lodash");
const uuid_1 = require("uuid");
// each component should be mapped to its corresponding GraphQl request here
const componentRequestTable = {
    'create-schedule': (extraInfo) => `
    mutation CreateSchedule($input: CreateScheduleInput!) {
      createSchedule(input: $input) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'delete-schedule': (extraInfo) => `
    mutation DeleteSchedule($id: ID!) {
      deleteSchedule(id: $id) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'show-all-availability': (extraInfo) => `
    query ShowAllAvailability($input: AllAvailabilityInput!) {
      allAvailability(input: $input) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'show-next-availability': (extraInfo) => `
    query ShowNextAvailability($input: NextAvailabilityInput!) {
      nextAvailability(input: $input) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'show-schedule': (extraInfo) => `
    query ShowSchedule($id: ID!) {
      schedule(id: $id) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'show-slot': (extraInfo) => `
    query ShowSlot($id: ID!) {
      slot(id: $id) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'show-slots': (extraInfo) => `
    query ShowSlots($input: SlotsInput!) {
      slots(input: $input) ${concept_server_1.getReturnFields(extraInfo)}
    }
  `,
    'update-schedule': (extraInfo) => {
        switch (extraInfo.action) {
            case 'update':
                return `
          mutation UpdateSchedule($input: UpdateScheduleInput!) {
            updateSchedule (input: $input) ${concept_server_1.getReturnFields(extraInfo)}
          }
        `;
            case 'load':
                return `
          query Schedule($id: ID!) {
            schedule(id: $id) ${concept_server_1.getReturnFields(extraInfo)}
          }
        `;
            default:
                throw new Error('Need to specify extraInfo.action');
        }
    }
};
function intersection(setA, setB) {
    const _intersection = new Set();
    for (const elem of setB) {
        if (setA.has(elem)) {
            _intersection.add(elem);
        }
    }
    return _intersection;
}
function combineFilterConditions(condition) {
    if (condition['$gte'] && condition['$lte']) {
        return {
            $and: [
                { $gte: condition['$gte'] },
                { $lte: condition['$lte'] }
            ]
        };
    }
    return condition;
}
// Reference: https://bit.ly/2ZTmOWu
function getOverlappingAvailabilities(schedules, input, pipeline, next = false) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield schedules.aggregate(pipeline)
            .toArray();
        let points = [];
        res.forEach((schedule, i) => {
            schedule.availability.forEach((slot) => {
                points.push({ time: slot.startDate, isStart: true, sId: i });
                points.push({ time: slot.endDate, isStart: false, sId: i });
            });
        });
        points = _.sortBy(points, (p) => p.time);
        const activeSpans = {};
        const intersections = [];
        points.forEach((point) => {
            const lastIndex = intersections.length - 1;
            if (intersections.length !== 0 &&
                intersections[lastIndex]['time'] === point.time) {
                intersections[lastIndex]['sIds'].add(point.sId.toString());
            }
            else {
                const sIds = new Set(_.keys(activeSpans));
                sIds.add(point.sId.toString());
                intersections.push({ time: point.time, sIds: sIds });
            }
            if (!point.isStart) {
                activeSpans[point.sId] -= 1;
                if (activeSpans[point.sId] === 0) {
                    delete activeSpans[point.sId];
                }
            }
            else {
                if (point.sId in activeSpans) {
                    activeSpans[point.sId] += 1;
                }
                else {
                    activeSpans[point.sId] = 1;
                }
            }
        });
        const result = [];
        for (let i = 1; i < intersections.length; i++) {
            const start = intersections[i - 1];
            const end = intersections[i];
            const overlaps = intersection(start.sIds, end.sIds);
            if (overlaps.size >= input.scheduleIds.length) {
                result.push({
                    id: uuid_1.v4(),
                    startDate: start.time,
                    endDate: end.time
                });
                if (next) {
                    return result;
                }
            }
        }
        return result;
    });
}
function filterByStartTime(slots, startTime) {
    if (!_.isEmpty(startTime)) {
        const [startHh, startMm] = startTime.split(':');
        slots = _.filter(slots, (slot) => {
            if (date_fns_1.getHours(slot.startDate) < parseInt(startHh, 10)) {
                return false;
            }
            if ((date_fns_1.getHours(slot.startDate) === parseInt(startHh, 10)) &&
                (date_fns_1.getMinutes(slot.startDate) < parseInt(startMm, 10))) {
                return false;
            }
            return true;
        });
    }
    return slots;
}
function filterByEndTime(slots, endTime) {
    if (!_.isEmpty(endTime)) {
        const [endHh, endMm] = endTime.split(':');
        slots = _.filter(slots, (slot) => {
            if (date_fns_1.getHours(slot.endDate) > parseInt(endHh, 10)) {
                return false;
            }
            if ((date_fns_1.getHours(slot.endDate) === parseInt(endHh, 10)) &&
                (date_fns_1.getMinutes(slot.endDate) > parseInt(endMm, 10))) {
                return false;
            }
            return true;
        });
    }
    return slots;
}
function getSlotsPipeline(matchQuery, filterCondition, sortByStartDate, sortByEndDate) {
    return [
        { $match: matchQuery },
        {
            $project: {
                availability: {
                    $filter: {
                        input: '$availability',
                        as: 'slot',
                        cond: filterCondition
                    }
                }
            }
        },
        {
            $sort: {
                'availability.startDate': sortByStartDate,
                'availability.endDate': sortByEndDate
            }
        }
    ];
}
function resolvers(db, _config) {
    const schedules = db.collection('schedules');
    return {
        Query: {
            schedule: (_root, { id }) => __awaiter(this, void 0, void 0, function* () { return yield schedules.findOne({ id }); }),
            slot: (_root, { id }) => __awaiter(this, void 0, void 0, function* () {
                const schedule = yield schedules.findOne({ 'availability.id': id }, { projection: { 'availability.$': 1 } });
                if (_.isEmpty(schedule.availability)) {
                    throw new Error(`Slot ${id} does not exist`);
                }
                return schedule.availability[0];
            }),
            slots: (_root, { input }) => __awaiter(this, void 0, void 0, function* () {
                const filter = { id: input.scheduleId };
                const condition = {};
                if (!_.isEmpty(input.startDate)) {
                    condition['$gte'] = ['$$slot.startDate', new Date(input.startDate)];
                }
                if (!_.isEmpty(input.endDate)) {
                    condition['$lte'] = ['$$slot.endDate', new Date(input.endDate)];
                }
                const res = yield schedules
                    .aggregate(getSlotsPipeline(filter, combineFilterConditions(condition), input.sortByStartDate, input.sortByEndDate))
                    .next();
                let filteredByTime = res ? res.availability : [];
                filteredByTime = filterByStartTime(filteredByTime, input.startTime);
                filteredByTime = filterByEndTime(filteredByTime, input.endTime);
                return filteredByTime;
            }),
            nextAvailability: (_root, { input }) => __awaiter(this, void 0, void 0, function* () {
                const matchQuery = { id: { $in: input.scheduleIds } };
                const filterCondition = { $gte: ['$$slot.startDate', new Date()] };
                const pipeline = getSlotsPipeline(matchQuery, filterCondition, 1, 1);
                const overlaps = yield getOverlappingAvailabilities(schedules, input, pipeline, true);
                return !_.isEmpty(overlaps) ? overlaps : undefined;
            }),
            allAvailability: (_root, { input }) => __awaiter(this, void 0, void 0, function* () {
                const matchQuery = { id: { $in: input.scheduleIds } };
                const condition = {
                    $gte: [
                        '$$slot.startDate',
                        input.startDate ? new Date(input.startDate) : new Date()
                    ]
                };
                if (!_.isEmpty(input.endDate)) {
                    condition['$lte'] = ['$$slot.endDate', new Date(input.endDate)];
                }
                const pipeline = getSlotsPipeline(matchQuery, combineFilterConditions(condition), input.sortByStartDate, input.sortByEndDate);
                return yield getOverlappingAvailabilities(schedules, input, pipeline);
            })
        },
        Schedule: {
            id: (schedule) => schedule.id,
            availability: (schedule) => schedule.availability
        },
        Slot: {
            id: (slot) => slot.id,
            startDate: (slot) => slot.startDate.toISOString(),
            endDate: (slot) => slot.endDate.toISOString()
        },
        Mutation: {
            createSchedule: (_root, { input }, context) => __awaiter(this, void 0, void 0, function* () {
                let availability = [];
                if (!_.isEmpty(input.slots)) {
                    availability = _.map(input.slots, (slot) => {
                        const dateSlot = {
                            id: uuid_1.v4(),
                            startDate: new Date(slot.startDate),
                            endDate: new Date(slot.endDate)
                        };
                        return dateSlot;
                    });
                }
                const schedule = {
                    id: input.id ? input.id : uuid_1.v4(),
                    availability: availability
                };
                return yield schedules.insertOne(context, schedule);
            }),
            updateSchedule: (_root, { input }, context) => __awaiter(this, void 0, void 0, function* () {
                const filter = { id: input.id };
                let addSlotsSuccess = true;
                let deleteSlotsSuccess = true;
                // Reason for two separate updates: https://bit.ly/2IJIVZR
                // add slots
                if (!_.isEmpty(input.add)) {
                    const availability = _.map(input.add, (slot) => {
                        const newSlot = {
                            id: uuid_1.v4(),
                            startDate: new Date(slot.startDate),
                            endDate: new Date(slot.endDate)
                        };
                        return newSlot;
                    });
                    const updateOp = { $push: { availability: { $each: availability } } };
                    addSlotsSuccess = yield schedules
                        .updateOne(context, filter, updateOp);
                }
                // delete slots
                if (!_.isEmpty(input.delete)) {
                    const updateOp = {
                        $pull: { availability: { id: { $in: input.delete } } }
                    };
                    deleteSlotsSuccess = yield schedules
                        .updateOne(context, filter, updateOp);
                }
                return addSlotsSuccess && deleteSlotsSuccess;
            }),
            deleteSchedule: (_root, { id }, context) => __awaiter(this, void 0, void 0, function* () { return yield schedules.deleteOne(context, { id }); })
        }
    };
}
const scheduleConcept = new concept_server_1.ConceptServerBuilder('schedule')
    .initDb((db, _config) => {
    const schedules = db.collection('schedules');
    return schedules.createIndex({ id: 1 }, { unique: true, sparse: true });
})
    .componentRequestTable(componentRequestTable)
    .resolvers(resolvers)
    .build();
scheduleConcept.start();
//# sourceMappingURL=server.js.map