import { CalendarDateFormatter, CalendarEventTitleFormatter, CalendarModule } from 'angular-calendar';
import { DatePipe, CommonModule } from '@angular/common';
import { getISOWeek, format, addHours, endOfDay, startOfDay } from 'date-fns';
import { pull, map, isNil, remove, uniq } from 'lodash';
import { InjectionToken, ChangeDetectorRef, Component, ElementRef, Inject, Input, EventEmitter, Output, ViewChild, NgModule } from '@angular/core';
import { __awaiter } from 'tslib';
import { Subject } from 'rxjs/Subject';
import { DvServiceFactory, DvModule } from '@deja-vu/core';
import { FormBuilder, FormControl, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as momentImported from 'moment';
import { MatButtonModule, MatDatepickerModule, MatFormFieldModule, MatInputModule, MatSelectModule } from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CalendarWeekHoursViewModule } from 'angular-calendar-week-hours-view';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class CustomDateFormatterProvider extends CalendarDateFormatter {
    /**
     * @param {?} __0
     * @return {?}
     */
    dayViewHour({ date, locale }) {
        return new DatePipe(locale).transform(date, 'HH:mm', locale);
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    weekViewTitle({ date, locale }) {
        const /** @type {?} */ year = new DatePipe(locale).transform(date, 'y', locale);
        const /** @type {?} */ weekNumber = getISOWeek(date);
        return `Week ${weekNumber} in ${year}`;
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    weekViewColumnHeader({ date, locale }) {
        return new DatePipe(locale).transform(date, 'E', locale);
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    weekViewColumnSubHeader({ date, locale }) {
        return new DatePipe(locale).transform(date, 'MM/dd', locale);
    }
}
class CustomEventTitleFormatterProvider extends CalendarEventTitleFormatter {
    /**
     * @param {?} event
     * @return {?}
     */
    monthTooltip(event) {
        return;
    }
    /**
     * @param {?} event
     * @return {?}
     */
    weekTooltip(event) {
        return;
    }
    /**
     * @param {?} event
     * @return {?}
     */
    dayTooltip(event) {
        return;
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} start
 * @param {?} end
 * @return {?}
 */
function timeRange(start, end) {
    return `${format(start, 'h[:]mm A')} - ${format(end, 'h[:]mm A')}`;
}
/**
 * @param {?} start
 * @param {?} end
 * @return {?}
 */
function dateTimeRange(start, end) {
    const /** @type {?} */ formatString = 'dddd do MM Mh[:]mm A';
    return `${format(start, formatString)} - ${format(end, formatString)}`;
}
/**
 * @param {?} start
 * @param {?} end
 * @param {?} editable
 * @return {?}
 */
function createNewCalendarEvent(start, end, editable) {
    return {
        start: start,
        end: end,
        title: timeRange(start, end),
        cssClass: 'custom-event',
        color: {
            primary: '#488aff',
            secondary: '#bbd0f5'
        },
        resizable: {
            beforeStart: editable,
            afterEnd: editable
        },
        draggable: editable
    };
}
/**
 * @param {?} slot
 * @param {?} editable
 * @return {?}
 */
function slotToCalendarEvent(slot, editable) {
    const /** @type {?} */ start = new Date(slot.startDate);
    const /** @type {?} */ end = new Date(slot.endDate);
    return {
        id: slot.id,
        start: start,
        end: end,
        title: timeRange(start, end),
        cssClass: 'custom-event',
        color: {
            primary: '#488aff',
            secondary: '#bbd0f5'
        },
        resizable: {
            beforeStart: editable,
            afterEnd: editable
        },
        draggable: editable
    };
}
/**
 * @param {?} slots
 * @param {?} editable
 * @return {?}
 */
function slotsToCalendarEvents(slots, editable) {
    return map(slots, (slot) => slotToCalendarEvent(slot, editable));
}
/**
 * @param {?} event
 * @return {?}
 */
function calendarEventToSlot(event) {
    return {
        startDate: event.start.toISOString(),
        endDate: event.end.toISOString()
    };
}
/**
 * @param {?} events
 * @return {?}
 */
function calendarEventsToSlots(events) {
    return map(events, calendarEventToSlot);
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const API_PATH = new InjectionToken('api.path');

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const SAVED_MSG_TIMEOUT = 3000;
const DRAG_TIMEOUT = 1000;
class CreateScheduleComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} cd
     * @param {?} apiPath
     */
    constructor(elem, dvf, cd, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.cd = cd;
        this.apiPath = apiPath;
        this.showOptionToSubmit = true;
        this.showOptionToChangeView = true;
        // Presentation inputs
        this.buttonLabel = 'Create Schedule';
        this.newScheduleSavedText = 'New schedule saved';
        this.removeSlotText = 'Do you want to remove the following slot:';
        this.view = 'week';
        this.locale = 'en';
        // The number of 60/num minute segments in an hour. Must be <= 6
        this.hourSegments = 2;
        // The day start hours in 24 hour time. Must be 0-23
        this.dayStartHour = 9;
        // The day end hours in 24 hour time. Must be 0-23
        this.dayEndHour = 17;
        // The default length of a newly added event (in hours)
        this.eventLength = 1;
        this.viewDate = new Date();
        this.isDragging = false;
        this.refresh = new Subject();
        this.newScheduleSaved = false;
        this.events = [];
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.cd.detectChanges();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    handleEvent(event) {
        if (confirm(`${this.removeSlotText}
    ${dateTimeRange(event.start, event.end)}?`)) {
            pull(this.events, event);
            this.refresh.next();
        }
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    eventTimesChanged({ event, newStart, newEnd }) {
        if (this.isDragging) {
            return;
        }
        this.isDragging = true;
        event.start = newStart;
        event.end = newEnd;
        event.title = timeRange(newStart, newEnd);
        this.refresh.next();
        setTimeout(() => {
            this.isDragging = false;
        }, DRAG_TIMEOUT);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    hourSegmentClicked(event) {
        const /** @type {?} */ start = event.date;
        const /** @type {?} */ end = addHours(event.date, this.eventLength);
        const /** @type {?} */ newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.refresh.next();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    dayClicked(event) {
        const /** @type {?} */ start = startOfDay(event.day.date);
        const /** @type {?} */ end = endOfDay(event.day.date);
        const /** @type {?} */ newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.refresh.next();
    }
    /**
     * @return {?}
     */
    onSubmit() {
        this.dvs.exec();
    }
    /**
     * @return {?}
     */
    dvOnExec() {
        return __awaiter(this, void 0, void 0, function* () {
            const /** @type {?} */ res = yield this.dvs.post(this.apiPath, {
                inputs: {
                    input: {
                        id: this.id,
                        slots: calendarEventsToSlots(this.events)
                    }
                },
                extraInfo: {
                    returnFields: 'id, availability { id, startDate, endDate }'
                }
            });
            if (res.errors) {
                throw new Error(map(res.errors, 'message')
                    .join());
            }
        });
    }
    /**
     * @return {?}
     */
    dvOnExecSuccess() {
        this.newScheduleSaved = true;
        window.setTimeout(() => {
            this.newScheduleSaved = false;
        }, SAVED_MSG_TIMEOUT);
        this.events = [];
    }
    /**
     * @param {?} reason
     * @return {?}
     */
    dvOnExecFailure(reason) {
        this.newScheduleError = reason.message;
    }
}
CreateScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-create-schedule',
                template: `<div *ngIf="showOptionToSubmit">
  <div *ngIf="newScheduleSaved" class="create-schedule-success">
    <i class="material-icons">done</i>
    {{newScheduleSavedText}}
  </div>
  <mat-error *ngIf="newScheduleError">
    <i class="material-icons">report_problem</i>
    {{newScheduleError}}
  </mat-error>
</div>

<div class="create-schedule">
  <div class="row text-center">
    <div class="col-md-6">
      <div class="btn-group">
        <div class="btn btn-primary"
          mwlCalendarPreviousView
          [view]="view"
          [(viewDate)]="viewDate">
          Previous
        </div>
        <div class="btn btn-outline-secondary"
          mwlCalendarToday
          [(viewDate)]="viewDate">
          Today
        </div>
        <div class="btn btn-primary"
          mwlCalendarNextView
          [view]="view"
          [(viewDate)]="viewDate">
          Next
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div *ngIf="showOptionToChangeView" class="btn-group">
        <div class="btn btn-primary"
          (click)="view = 'month'"
          [class.active]="view === 'month'">
          Month
        </div>
        <div class="btn btn-primary"
          (click)="view = 'week'"
          [class.active]="view === 'week'">
          Week
        </div>
        <div class="btn btn-primary"
          (click)="view = 'day'"
          [class.active]="view === 'day'">
          Day
        </div>
      </div>
    </div>
  </div>

  <div class="row text-center view-info">
    <div class="col-md-12">
      <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>
    </div>
  </div>

  <br />

  <mwl-calendar-month-view
    *ngIf="view === 'month'"
    [viewDate]="viewDate"
    [events]="events"
    (eventClicked)="handleEvent($event.event)"
    (eventTimesChanged)="eventTimesChanged($event)"
    (dayClicked)="dayClicked($event)"
    [refresh]="refresh"
    [locale]="locale">
  </mwl-calendar-month-view>

  <iq-calendar-week-hours-view
    *ngIf="view === 'week'"
    [viewDate]="viewDate"
    [events]="events"
    [hourSegments]="hourSegments"
    [dayStartHour]="dayStartHour"
    [dayEndHour]="dayEndHour"
    (eventClicked)="handleEvent($event.event)"
    (hourSegmentClicked)="hourSegmentClicked($event)"
    (eventTimesChanged)="eventTimesChanged($event)"
    [refresh]="refresh"
    [locale]="locale">
  </iq-calendar-week-hours-view>

  <mwl-calendar-day-view
    *ngIf="view === 'day'"
    [viewDate]="viewDate"
    [events]="events"
    [hourSegments]="hourSegments"
    [dayStartHour]="dayStartHour"
    [dayEndHour]="dayEndHour"
    (eventClicked)="handleEvent($event.event)"
    (hourSegmentClicked)="hourSegmentClicked($event)"
    (eventTimesChanged)="eventTimesChanged($event)"
    [refresh]="refresh"
    [locale]="locale">
  </mwl-calendar-day-view>
</div>

<div *ngIf="showOptionToSubmit" class="form-group">
  <br />
  <div class="dv-mat-button">
    <button mat-button class="create-schedule-submit-button"
      type="submit" (click)="onSubmit()">
      {{buttonLabel}}
    </button>
  </div>
</div>
`,
                styles: [`.create-schedule-submit-button{float:right}.create-schedule-success{color:green}.view-info{margin-top:15px}`],
                providers: [
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
/** @nocollapse */
CreateScheduleComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: ChangeDetectorRef, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
CreateScheduleComponent.propDecorators = {
    "id": [{ type: Input },],
    "showOptionToSubmit": [{ type: Input },],
    "showOptionToChangeView": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "newScheduleSavedText": [{ type: Input },],
    "removeSlotText": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class DeleteScheduleComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} apiPath
     */
    constructor(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .build();
    }
    /**
     * @return {?}
     */
    deleteSchedule() {
        this.dvs.exec();
    }
    /**
     * @return {?}
     */
    dvOnExec() {
        return __awaiter(this, void 0, void 0, function* () {
            const /** @type {?} */ res = yield this.dvs.post(this.apiPath, {
                inputs: {
                    id: this.id
                }
            });
            if (res.errors) {
                throw new Error(map(res.errors, 'message')
                    .join());
            }
        });
    }
}
DeleteScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-delete-schedule',
                template: `<div class="dv-mat-button">
  <button mat-button (click)="deleteSchedule()">
    <i class="material-icons">delete</i>
  </button>
</div>
`,
                styles: [``]
            },] },
];
/** @nocollapse */
DeleteScheduleComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
DeleteScheduleComponent.propDecorators = {
    "id": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class ShowScheduleComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} apiPath
     */
    constructor(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.scheduleWasGiven = false;
        this.loadedSchedule = new EventEmitter();
        this.showId = true;
        this.showAvailability = true;
        this.view = 'week';
        this.locale = 'en';
        // The number of 60/num minute segments in an hour. Must be <= 6
        this.hourSegments = 2;
        // The day start hours in 24 hour time. Must be 0-23
        this.dayStartHour = 9;
        // The day end hours in 24 hour time. Must be 0-23
        this.dayEndHour = 17;
        // The default length of a newly added event (in hours)
        this.eventLength = 1;
        this.viewDate = new Date();
        this.events = [];
    }
    /**
     * @return {?}
     */
    get schedule() { return this._schedule; }
    /**
     * @param {?} value
     * @return {?}
     */
    set schedule(value) {
        if (!isNil(value)) {
            this.scheduleWasGiven = true;
            this.events = slotsToCalendarEvents(value.availability, false);
            this._schedule = value;
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .withDefaultWaiter()
            .withRefreshCallback(() => { this.load(); })
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.load();
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (this.dvs && this.dvs.waiter.processChanges(changes)) {
            this.load();
        }
    }
    /**
     * @return {?}
     */
    load() {
        if (this.canEval()) {
            this.dvs.eval();
        }
    }
    /**
     * @return {?}
     */
    dvOnEval() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.canEval()) {
                const /** @type {?} */ res = yield this.dvs.waitAndGet(this.apiPath, () => ({
                    params: {
                        inputs: {
                            id: this.id
                        },
                        extraInfo: {
                            returnFields: `
                ${this.showId ? 'id' : ''}
                ${this.showAvailability ? 'availability { startDate, endDate }'
                                : ''}
              `
                        }
                    }
                }));
                const /** @type {?} */ schedule = res.data.schedule;
                this.events = slotsToCalendarEvents(schedule.availability, false);
                this._schedule = schedule;
                this.loadedSchedule.emit(schedule);
            }
            else if (this.dvs) {
                this.dvs.noRequest();
            }
        });
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.dvs.onDestroy();
    }
    /**
     * @return {?}
     */
    canEval() {
        return !!(this.dvs && !this.scheduleWasGiven);
    }
}
ShowScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-schedule',
                template: `<span *ngIf="_schedule">
  <div *ngIf="showId">
    {{_schedule.id}}
  </div>

  <div *ngIf="showAvailability">
    <div class="row text-center">
      <div class="col-md-4">
        <div class="btn-group">
          <div class="btn btn-primary"
            mwlCalendarPreviousView
            [view]="view"
            [(viewDate)]="viewDate">
            Previous
          </div>
          <div class="btn btn-outline-secondary"
            mwlCalendarToday
            [(viewDate)]="viewDate">
            Today
          </div>
          <div class="btn btn-primary"
            mwlCalendarNextView
            [view]="view"
            [(viewDate)]="viewDate">
            Next
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>
      </div>

      <div class="col-md-4">
        <div class="btn-group">
          <div class="btn btn-primary"
            (click)="view = 'month'"
            [class.active]="view === 'month'">
            Month
          </div>
          <div class="btn btn-primary"
            (click)="view = 'week'"
            [class.active]="view === 'week'">
            Week
          </div>
          <div class="btn btn-primary"
            (click)="view = 'day'"
            [class.active]="view === 'day'">
            Day
          </div>
        </div>
      </div>
    </div>

    <br />

    <mwl-calendar-month-view
      *ngIf="view === 'month'"
      [viewDate]="viewDate"
      [events]="events"
      [refresh]="refresh"
      [locale]="locale">
    </mwl-calendar-month-view>

    <iq-calendar-week-hours-view
      *ngIf="view === 'week'"
      [viewDate]="viewDate"
      [events]="events"
      [hourSegments]="hourSegments"
      [dayStartHour]="dayStartHour"
      [dayEndHour]="dayEndHour"
      [refresh]="refresh"
      [locale]="locale">
    </iq-calendar-week-hours-view>

    <mwl-calendar-day-view
      *ngIf="view === 'day'"
      [viewDate]="viewDate"
      [events]="events"
      [hourSegments]="hourSegments"
      [dayStartHour]="dayStartHour"
      [dayEndHour]="dayEndHour"
      [refresh]="refresh"
      [locale]="locale">
    </mwl-calendar-day-view>
  </div>
</span>
`,
                styles: [`.custom-event a{color:#fff!important;font-weight:700;text-decoration:none}.cal-day-view .cal-event{white-space:normal}.cal-day-view .cal-event-container{width:100%!important}.cal-day-view .cal-time{width:40px!important;font-size:smaller!important}.cal-week-hours-view .cal-day-container:first-child{width:40px!important;-webkit-box-flex:0;-ms-flex:none;flex:none}.cal-week-hours-view .cal-header:first-child{width:40px!important;-webkit-box-flex:0;-ms-flex:none;flex:none;border:none}.cal-header{border-left:1px solid #e1e1e1}.cal-today{color:pink}`],
                providers: [
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
/** @nocollapse */
ShowScheduleComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
ShowScheduleComponent.propDecorators = {
    "waitOn": [{ type: Input },],
    "id": [{ type: Input },],
    "schedule": [{ type: Input },],
    "loadedSchedule": [{ type: Output },],
    "showId": [{ type: Input },],
    "showAvailability": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const SAVED_MSG_TIMEOUT$1 = 3000;
const DRAG_TIMEOUT$1 = 1000;
class UpdateScheduleComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} apiPath
     */
    constructor(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        // A list of fields to wait for
        this.waitOn = [];
        this.showOptionToSubmit = true;
        this.showOptionToChangeView = true;
        // Presentation inputs
        this.buttonLabel = 'Update Schedule';
        this.updateScheduleSavedText = 'Schedule updated';
        this.deleteSlotText = 'Do you want to delete the following slot:';
        this.view = 'week';
        this.locale = 'en';
        // The number of 60/num minute segments in an hour. Must be <= 6
        this.hourSegments = 2;
        // The day start hours in 24 hour time. Must be 0-23
        this.dayStartHour = 9;
        // The day end hours in 24 hour time. Must be 0-23
        this.dayEndHour = 17;
        // The default length of a newly added event (in hours)
        this.eventLength = 1;
        this.viewDate = new Date();
        this.isDragging = false;
        this.refresh = new Subject();
        this.updateScheduleSaved = false;
        this.events = [];
        this.newEvents = [];
        this.deletedEventIds = [];
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .withDefaultWaiter()
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.load();
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (this.dvs && this.dvs.waiter.processChanges(changes)) {
            this.load();
        }
    }
    /**
     * @return {?}
     */
    load() {
        if (this.canEval()) {
            this.dvs.eval();
        }
    }
    /**
     * @return {?}
     */
    dvOnEval() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.canEval()) {
                const /** @type {?} */ res = yield this.dvs.waitAndGet(this.apiPath, () => ({
                    params: {
                        inputs: { id: this.id },
                        extraInfo: {
                            action: 'load',
                            returnFields: 'id, availability { id, startDate, endDate }'
                        }
                    }
                }));
                if (!isNil(res.data.schedule)) {
                    this.schedule = res.data.schedule;
                    this.events = slotsToCalendarEvents(this.schedule.availability, true);
                }
            }
        });
    }
    /**
     * @param {?} event
     * @return {?}
     */
    handleEvent(event) {
        if (confirm(`${this.deleteSlotText}
    ${dateTimeRange(event.start, event.end)}?`)) {
            pull(this.events, event);
            this.deletedEventIds.push(event.id.toString());
            this.refresh.next();
        }
    }
    /**
     * @param {?} __0
     * @return {?}
     */
    eventTimesChanged({ event, newStart, newEnd }) {
        if (this.isDragging) {
            return;
        }
        this.isDragging = true;
        this.deletedEventIds.push(event.id.toString());
        remove(this.newEvents, (e) => e.id === event.id);
        event.start = newStart;
        event.end = newEnd;
        event.title = timeRange(newStart, newEnd);
        this.newEvents.push(event);
        this.refresh.next();
        setTimeout(() => {
            this.isDragging = false;
        }, DRAG_TIMEOUT$1);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    hourSegmentClicked(event) {
        const /** @type {?} */ start = event.date;
        const /** @type {?} */ end = addHours(event.date, this.eventLength);
        const /** @type {?} */ newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.newEvents.push(newEvent);
        this.refresh.next();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    dayClicked(event) {
        const /** @type {?} */ start = startOfDay(event.day.date);
        const /** @type {?} */ end = endOfDay(event.day.date);
        const /** @type {?} */ newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.newEvents.push(newEvent);
        this.refresh.next();
    }
    /**
     * @return {?}
     */
    onSubmit() {
        this.dvs.exec();
    }
    /**
     * @return {?}
     */
    dvOnExec() {
        return __awaiter(this, void 0, void 0, function* () {
            const /** @type {?} */ res = yield this.dvs.post(this.apiPath, {
                inputs: {
                    input: {
                        id: this.id,
                        add: calendarEventsToSlots(this.newEvents),
                        delete: uniq(this.deletedEventIds)
                    }
                },
                extraInfo: {
                    action: 'update'
                }
            });
            if (res.errors) {
                throw new Error(map(res.errors, 'message')
                    .join());
            }
            return res.data.updateSchedule;
        });
    }
    /**
     * @return {?}
     */
    dvOnExecSuccess() {
        this.updateScheduleSaved = true;
        this.updateScheduleError = '';
        window.setTimeout(() => {
            this.updateScheduleSaved = false;
        }, SAVED_MSG_TIMEOUT$1);
    }
    /**
     * @param {?} reason
     * @return {?}
     */
    dvOnExecFailure(reason) {
        this.updateScheduleError = reason.message;
    }
    /**
     * @return {?}
     */
    canEval() {
        return !!(this.dvs && this.id);
    }
}
UpdateScheduleComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-update-schedule',
                template: `<div *ngIf="schedule">
  <div *ngIf="showOptionToSubmit">
    <div *ngIf="updateScheduleSaved" class="update-schedule-success">
      <i class="material-icons">done</i>
      {{updateScheduleSavedText}}
    </div>
    <mat-error *ngIf="updateScheduleError">
      <i class="material-icons">report_problem</i>
      {{updateScheduleError}}
    </mat-error>
  </div>

  <div class="update-schedule">
    <div class="row text-center">
      <div class="col-md-6">
        <div class="btn-group">
          <div class="btn btn-primary"
            mwlCalendarPreviousView
            [view]="view"
            [(viewDate)]="viewDate">
            Previous
          </div>
          <div class="btn btn-outline-secondary"
            mwlCalendarToday
            [(viewDate)]="viewDate">
            Today
          </div>
          <div class="btn btn-primary"
            mwlCalendarNextView
            [view]="view"
            [(viewDate)]="viewDate">
            Next
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div *ngIf="showOptionToChangeView" class="btn-group">
          <div class="btn btn-primary"
            (click)="view = 'month'"
            [class.active]="view === 'month'">
            Month
          </div>
          <div class="btn btn-primary"
            (click)="view = 'week'"
            [class.active]="view === 'week'">
            Week
          </div>
          <div class="btn btn-primary"
            (click)="view = 'day'"
            [class.active]="view === 'day'">
            Day
          </div>
        </div>
      </div>
    </div>

    <div class="row text-center view-info">
      <div class="col-md-4">
        <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>
      </div>
    </div>

    <br />

    <mwl-calendar-month-view
      *ngIf="view === 'month'"
      [viewDate]="viewDate"
      [events]="events"
      (eventClicked)="handleEvent($event.event)"
      (eventTimesChanged)="eventTimesChanged($event)"
      (dayClicked)="dayClicked($event)"
      [refresh]="refresh"
      [locale]="locale">
    </mwl-calendar-month-view>

    <iq-calendar-week-hours-view
      *ngIf="view === 'week'"
      [viewDate]="viewDate"
      [events]="events"
      [hourSegments]="hourSegments"
      [dayStartHour]="dayStartHour"
      [dayEndHour]="dayEndHour"
      (eventClicked)="handleEvent($event.event)"
      (hourSegmentClicked)="hourSegmentClicked($event)"
      (eventTimesChanged)="eventTimesChanged($event)"
      [refresh]="refresh"
      [locale]="locale">
    </iq-calendar-week-hours-view>

    <mwl-calendar-day-view
      *ngIf="view === 'day'"
      [viewDate]="viewDate"
      [events]="events"
      [hourSegments]="hourSegments"
      [dayStartHour]="dayStartHour"
      [dayEndHour]="dayEndHour"
      (eventClicked)="handleEvent($event.event)"
      (hourSegmentClicked)="hourSegmentClicked($event)"
      (eventTimesChanged)="eventTimesChanged($event)"
      [refresh]="refresh"
      [locale]="locale">
    </mwl-calendar-day-view>
  </div>
  <div *ngIf="showOptionToSubmit" class="form-group">
    <br />
    <div class="dv-mat-button">
      <button mat-raised-button class="update-schedule-submit-button"
        type="submit" (click)="onSubmit()">
        {{buttonLabel}}
      </button>
    </div>
  </div>
</div>
`,
                styles: [`.update-schedule-submit-button{float:right}.update-schedule-success{color:green}.view-info{margin-top:15px}`],
                providers: [
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
/** @nocollapse */
UpdateScheduleComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
UpdateScheduleComponent.propDecorators = {
    "waitOn": [{ type: Input },],
    "id": [{ type: Input },],
    "showOptionToSubmit": [{ type: Input },],
    "showOptionToChangeView": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "updateScheduleSavedText": [{ type: Input },],
    "deleteSlotText": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class ShowSlotComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} apiPath
     */
    constructor(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.loadedSlot = new EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        // See https://angular.io/api/common/DatePipe
        this.dateTimeFormatString = 'medium';
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.load();
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        this.load();
    }
    /**
     * @return {?}
     */
    load() {
        if (this.canEval()) {
            this.dvs.eval();
        }
    }
    /**
     * @return {?}
     */
    dvOnEval() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.canEval()) {
                const /** @type {?} */ res = yield this.dvs.get(this.apiPath, {
                    params: {
                        inputs: {
                            id: this.id
                        },
                        extraInfo: {
                            returnFields: `
              ${this.showId ? 'id' : ''}
              ${this.showStartDate ? 'startDate' : ''}
              ${this.showEndDate ? 'endDate' : ''}
            `
                        }
                    }
                });
                this.slot = res.data.slot;
                this.loadedSlot.emit(this.slot);
            }
            else if (this.dvs) {
                this.dvs.noRequest();
            }
        });
    }
    /**
     * @return {?}
     */
    canEval() {
        return !!(!this.slot && this.id && this.dvs);
    }
}
ShowSlotComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-slot',
                template: `<span *ngIf="slot">
  <div *ngIf="showId">
    {{ slot.id }}
  </div>

  <div *ngIf="showStartDate">
    {{ slot.startDate | date: dateTimeFormatString }}
  </div>

  <div *ngIf="showEndDate">
    {{ slot.endDate | date: dateTimeFormatString }}
  </div>
</span>
`,
                styles: [``]
            },] },
];
/** @nocollapse */
ShowSlotComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
ShowSlotComponent.propDecorators = {
    "id": [{ type: Input },],
    "slot": [{ type: Input },],
    "loadedSlot": [{ type: Output },],
    "showId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} getStartDate
 * @return {?}
 */
function endDateValidator(getStartDate) {
    return (control) => {
        const /** @type {?} */ startDate = getStartDate();
        const /** @type {?} */ endDate = control.value;
        if (!(startDate && endDate)) {
            return null;
        }
        if (endDate.isBefore(startDate)) {
            return { endDateBeforeStartDate: true };
        }
        return null;
    };
}
/**
 * @param {?} getStartTime
 * @return {?}
 */
function endTimeValidator(getStartTime) {
    return (control) => {
        const /** @type {?} */ startTime = getStartTime();
        const /** @type {?} */ endTime = control.value;
        if (!(startTime && endTime)) {
            return null;
        }
        const [startHh, startMm] = startTime.split(':');
        const [endHh, endMm] = endTime.split(':');
        if (startHh > endHh || (startHh === endHh && startMm >= endMm)) {
            return { endTimeBeforeStartTime: true };
        }
        return null;
    };
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const moment = momentImported;
class ShowSlotsComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} builder
     * @param {?} apiPath
     */
    constructor(elem, dvf, builder, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.builder = builder;
        this.apiPath = apiPath;
        this.showDateTimePicker = true;
        this.buttonLabel = 'Filter Availability';
        // Choose how to sort the slots
        this.sortByStartDate = 'asc';
        this.sortByEndDate = 'asc';
        this.loadedSlots = new EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        // See https://angular.io/api/common/DatePipe
        this.dateTimeFormatString = 'medium';
        this.showSlot = {
            type: /** @type {?} */ (ShowSlotComponent)
        };
        this.startDateControl = new FormControl('');
        this.endDateControl = new FormControl('', [
            endDateValidator(() => this.startDateControl.value)
        ]);
        this.startTimeControl = new FormControl('');
        this.endTimeControl = new FormControl('', [
            endTimeValidator(() => this.startTimeControl.value)
        ]);
        this.dateTimeFilterForm = this.builder.group({
            startsOn: this.startDateControl,
            endsOn: this.endDateControl,
            startTime: this.startTimeControl,
            endTime: this.endTimeControl
        });
        this.showSlots = this;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set startDate(value) {
        this.startDateControl.setValue(moment(value));
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set endDate(value) {
        this.endDateControl.setValue(moment(value));
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set startTime(value) {
        this.startTimeControl.setValue(value);
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set endTime(value) {
        this.endTimeControl.setValue(value);
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.load();
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        this.load();
    }
    /**
     * @return {?}
     */
    load() {
        if (this.canEval()) {
            this.dvs.eval();
        }
    }
    /**
     * @return {?}
     */
    filterSlots() {
        this.dvs.eval();
    }
    /**
     * @return {?}
     */
    dvOnEval() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.canEval()) {
                const /** @type {?} */ startDate = this.startDateControl.value ?
                    this.startDateControl.value.format('YYYY-MM-DD') : '';
                const /** @type {?} */ endDate = this.endDateControl.value ?
                    this.endDateControl.value.format('YYYY-MM-DD') : '';
                const /** @type {?} */ res = yield this.dvs.get(this.apiPath, {
                    params: {
                        inputs: JSON.stringify({
                            input: {
                                scheduleId: this.scheduleId,
                                startDate: startDate,
                                endDate: endDate,
                                startTime: this.startTimeControl.value,
                                endTime: this.endTimeControl.value,
                                sortByStartDate: this.sortByStartDate === 'asc' ? 1 : -1,
                                sortByEndDate: this.sortByEndDate === 'asc' ? 1 : -1
                            }
                        }),
                        extraInfo: {
                            returnFields: `
                ${this.showId ? 'id' : ''}
                ${this.showStartDate ? 'startDate' : ''}
                ${this.showEndDate ? 'endDate' : ''}
              `
                        }
                    }
                });
                this.slots = res.data.slots;
                this.loadedSlots.emit(this.slots);
            }
            else if (this.dvs) {
                this.dvs.noRequest();
            }
        });
    }
    /**
     * @return {?}
     */
    canEval() {
        return !!(!this.slots && this.scheduleId && this.dvs);
    }
}
ShowSlotsComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-slots',
                template: `<div *ngIf="showDateTimePicker">
  <form (ngSubmit)="filterSlots()" [formGroup]="dateTimeFilterForm"
    class="form-horizontal">
    <div class="form-group">
      <mat-form-field>
        <mat-label>Start Date</mat-label>
        <input matInput [matDatepicker]="startDatePicker"
         [formControl]="startDateControl">
        <mat-datepicker-toggle matSuffix [for]="startDatePicker">
        </mat-datepicker-toggle>
        <mat-datepicker #startDatePicker></mat-datepicker>
      </mat-form-field>
    </div>
    <div class="form-group">
      <mat-form-field>
        <mat-label>Start Time</mat-label>
        <input matInput type="time" [formControl]="startTimeControl">
      </mat-form-field>
    </div>

    <div class="form-group">
      <mat-form-field>
        <mat-label>End Date</mat-label>
        <input matInput [matDatepicker]="endDatePicker"
          [formControl]="endDateControl">
        <mat-datepicker-toggle matSuffix [for]="endDatePicker">
        </mat-datepicker-toggle>
        <mat-datepicker #endDatePicker></mat-datepicker>
        <mat-error *ngIf="endDateControl.hasError('endDateBeforeStartDate')">
          End Date should be <strong>after</strong> Start Date
        </mat-error>
      </mat-form-field>
    </div>
    <div class="form-group">
      <mat-form-field>
        <mat-label>End Time</mat-label>
        <input matInput type="time" [formControl]="endTimeControl">
        <mat-error *ngIf="endTimeControl.hasError('endTimeBeforeStartTime')">
          End Time should be <strong>after</strong> Start Time
        </mat-error>
      </mat-form-field>
    </div>
    <div class="form-group">
      <button mat-button type="submit">
        {{buttonLabel}}
      </button>
    </div>
  </form>
</div>

<ul *ngIf="slots && slots.length > 0" class="list-group">
  <li *ngFor="let slot of slots" class="list-group-item">
    <dv-include
      [component]="showSlot"
      default-showSlot="{ tag: schedule-show-slot }"
      [inputs]="{
        slot: slot, showId: showId,
        showStartDate: showStartDate,
        showEndDate: showEndDate,
        dateTimeFormatString: dateTimeFormatString
      }"
      [parent]="showSlots">
    </dv-include>
  </li>
</ul>

<div *ngIf="!slots || slots.length === 0">
  <span>{{noSlotsToShowText}}</span>
</div>
`,
                styles: [``]
            },] },
];
/** @nocollapse */
ShowSlotsComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: FormBuilder, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
ShowSlotsComponent.propDecorators = {
    "scheduleId": [{ type: Input },],
    "slots": [{ type: Input },],
    "showDateTimePicker": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "startDate": [{ type: Input },],
    "endDate": [{ type: Input },],
    "startTime": [{ type: Input },],
    "endTime": [{ type: Input },],
    "sortByStartDate": [{ type: Input },],
    "sortByEndDate": [{ type: Input },],
    "loadedSlots": [{ type: Output },],
    "showId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
    "showSlot": [{ type: Input },],
    "form": [{ type: ViewChild, args: [FormGroupDirective,] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class ShowNextAvailabilityComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} apiPath
     */
    constructor(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.loadedNextAvailability = new EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        // See https://angular.io/api/common/DatePipe
        this.dateTimeFormatString = 'medium';
        this.showSlot = {
            type: /** @type {?} */ (ShowSlotComponent)
        };
        this.showNextAvailability = this;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.load();
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        this.load();
    }
    /**
     * @return {?}
     */
    load() {
        if (this.canEval()) {
            this.dvs.eval();
        }
    }
    /**
     * @return {?}
     */
    dvOnEval() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.canEval()) {
                const /** @type {?} */ res = yield this.dvs.get(this.apiPath, {
                    params: {
                        inputs: JSON.stringify({
                            input: {
                                scheduleIds: this.scheduleIds
                            }
                        }),
                        extraInfo: {
                            returnFields: `
              ${this.showId ? 'id' : ''}
              ${this.showStartDate ? 'startDate' : ''}
              ${this.showEndDate ? 'endDate' : ''}
            `
                        }
                    }
                });
                this.nextAvailability = res.data.nextAvailability;
                this.loadedNextAvailability.emit(this.nextAvailability);
            }
            else if (this.dvs) {
                this.dvs.noRequest();
            }
        });
    }
    /**
     * @return {?}
     */
    canEval() {
        return !!(!this.nextAvailability && this.scheduleIds && this.dvs);
    }
}
ShowNextAvailabilityComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-next-availability',
                template: `<span *ngIf="nextAvailability">
  <dv-include
    [component]="showSlot"
    default-showSlot="{ tag: schedule-show-slot }"
    [inputs]="{
      slot: nextAvailability, showId: showId,
      showStartDate: showStartDate,
      showEndDate: showEndDate,
      dateTimeFormatString: dateTimeFormatString
    }"
    [parent]="showNextAvailability">
  </dv-include>
</span>
`,
                styles: [``]
            },] },
];
/** @nocollapse */
ShowNextAvailabilityComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
ShowNextAvailabilityComponent.propDecorators = {
    "scheduleIds": [{ type: Input },],
    "loadedNextAvailability": [{ type: Output },],
    "showId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
    "showSlot": [{ type: Input },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const moment$1 = momentImported;
class ShowAllAvailabilityComponent {
    /**
     * @param {?} elem
     * @param {?} dvf
     * @param {?} builder
     * @param {?} apiPath
     */
    constructor(elem, dvf, builder, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.builder = builder;
        this.apiPath = apiPath;
        this.showDateTimePicker = true;
        this.buttonLabel = 'Filter Slots';
        // Choose how to sort the slots
        this.sortByStartDate = 'asc';
        this.sortByEndDate = 'asc';
        this.loadedAllAvailability = new EventEmitter();
        this.showScheduleView = true;
        this.showScheduleId = false;
        this.view = 'week';
        this.locale = 'en';
        // The number of 60/num minute segments in an hour. Must be <= 6
        this.hourSegments = 2;
        // The day start hours in 24 hour time. Must be 0-23
        this.dayStartHour = 9;
        // The day end hours in 24 hour time. Must be 0-23
        this.dayEndHour = 17;
        // The default length of a newly added event (in hours)
        this.eventLength = 1;
        this.showSchedule = {
            type: /** @type {?} */ (ShowScheduleComponent)
        };
        this.showSlotsView = true;
        this.showSlotId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        // See https://angular.io/api/common/DatePipe
        this.dateTimeFormatString = 'medium';
        this.showSlots = {
            type: /** @type {?} */ (ShowSlotsComponent)
        };
        this.showSlot = {
            type: /** @type {?} */ (ShowSlotComponent)
        };
        this.startDateControl = new FormControl('');
        this.endDateControl = new FormControl('', [
            endDateValidator(() => this.startDateControl.value)
        ]);
        this.startTimeControl = new FormControl('');
        this.endTimeControl = new FormControl('', [
            endTimeValidator(() => this.startTimeControl.value)
        ]);
        this.dateTimeFilterForm = this.builder.group({
            startsOn: this.startDateControl,
            endsOn: this.endDateControl,
            startTime: this.startTimeControl,
            endTime: this.endTimeControl
        });
        this.showSlotsDateTimePicker = false;
        this.showAllAvailability = this;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set startDate(value) {
        this.startDateControl.setValue(moment$1(value));
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set endDate(value) {
        this.endDateControl.setValue(moment$1(value));
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set startTime(value) {
        this.startTimeControl.setValue(value);
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set endTime(value) {
        this.endTimeControl.setValue(value);
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.dvs = this.dvf.forComponent(this)
            .build();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.load();
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        this.load();
    }
    /**
     * @return {?}
     */
    load() {
        if (this.canEval()) {
            this.dvs.eval();
        }
    }
    /**
     * @return {?}
     */
    filterSlots() {
        this.dvs.eval();
    }
    /**
     * @return {?}
     */
    dvOnEval() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.canEval()) {
                const /** @type {?} */ startDate = this.startDateControl.value ?
                    this.startDateControl.value.format('YYYY-MM-DD') : '';
                const /** @type {?} */ endDate = this.endDateControl.value ?
                    this.endDateControl.value.format('YYYY-MM-DD') : '';
                const /** @type {?} */ res = yield this.dvs.get(this.apiPath, {
                    params: {
                        inputs: JSON.stringify({
                            input: {
                                scheduleIds: this.scheduleIds,
                                startDate: startDate,
                                endDate: endDate,
                                startTime: this.startTimeControl.value,
                                endTime: this.endTimeControl.value,
                                sortByStartDate: this.sortByStartDate === 'asc' ? 1 : -1,
                                sortByEndDate: this.sortByEndDate === 'asc' ? 1 : -1
                            }
                        }),
                        extraInfo: { returnFields: 'id, startDate, endDate' }
                    }
                });
                this.allAvailability = res.data.allAvailability;
                this.schedule = {
                    id: 'all-availability',
                    availability: this.allAvailability
                };
                this.loadedAllAvailability.emit(this.allAvailability);
            }
            else if (this.dvs) {
                this.dvs.noRequest();
            }
        });
    }
    /**
     * @return {?}
     */
    canEval() {
        return !!(!this.allAvailability && this.scheduleIds && this.dvs);
    }
}
ShowAllAvailabilityComponent.decorators = [
    { type: Component, args: [{
                selector: 'schedule-show-all-availability',
                template: `<div *ngIf="showDateTimePicker">
  <form (ngSubmit)="filterSlots()" [formGroup]="dateTimeFilterForm"
    class="form-horizontal">
    <div class="form-group">
      <mat-form-field>
        <mat-label>Start Date</mat-label>
        <input matInput [matDatepicker]="startDatePicker"
         [formControl]="startDateControl">
        <mat-datepicker-toggle matSuffix [for]="startDatePicker">
        </mat-datepicker-toggle>
        <mat-datepicker #startDatePicker></mat-datepicker>
      </mat-form-field>
    </div>
    <div class="form-group">
      <mat-form-field>
        <mat-label>Start Time</mat-label>
        <input matInput type="time" [formControl]="startTimeControl">
      </mat-form-field>
    </div>

    <div class="form-group">
      <mat-form-field>
        <mat-label>End Date</mat-label>
        <input matInput [matDatepicker]="endDatePicker"
          [formControl]="endDateControl">
        <mat-datepicker-toggle matSuffix [for]="endDatePicker">
        </mat-datepicker-toggle>
        <mat-datepicker #endDatePicker></mat-datepicker>
        <mat-error *ngIf="endDateControl.hasError('endDateBeforeStartDate')">
          End Date should be <strong>after</strong> Start Date
        </mat-error>
      </mat-form-field>
    </div>
    <div class="form-group">
      <mat-form-field>
        <mat-label>End Time</mat-label>
        <input matInput type="time" [formControl]="endTimeControl">
        <mat-error *ngIf="endTimeControl.hasError('endTimeBeforeStartTime')">
          End Time should be <strong>after</strong> Start Time
        </mat-error>
      </mat-form-field>
    </div>
    <div class="form-group">
      <div class="dv-mat-button">
        <button mat-button type="submit">
          {{buttonLabel}}
        </button>
      </div>
    </div>
  </form>
</div>

<span *ngIf="allAvailability">
  <span *ngIf="showScheduleView">
    <dv-include
      [component]="showSchedule"
      default-showSchedule="{ tag: schedule-show-schedule }"
      [inputs]="{
        schedule: schedule, showId: showScheduleId,
        view: view, locale: locale, hourSegments: hourSegments,
        dayStartHour: dayStartHour, dayEndHour: dayEndHour,
        eventLength: eventLength
      }"
      [parent]="showAllAvailability">
    </dv-include>
  </span>

  <span *ngIf="showSlotsView">
    <dv-include
      [component]="showSlots"
      default-showSlots="{ tag: schedule-show-slots }"
      [inputs]="{
        slots: allAvailability, showId: showSlotId,
        showStartDate: showStartDate, showEndDate: showEndDate,
        showDateTimePicker: showSlotsDateTimePicker,
        dateTimeFormatString: dateTimeFormatString,
        showSlot: showSlot
      }"
      [parent]="showAllAvailability">
    </dv-include>
  </span>
</span>
`,
                styles: [``]
            },] },
];
/** @nocollapse */
ShowAllAvailabilityComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: DvServiceFactory, },
    { type: FormBuilder, },
    { type: undefined, decorators: [{ type: Inject, args: [API_PATH,] },] },
];
ShowAllAvailabilityComponent.propDecorators = {
    "scheduleIds": [{ type: Input },],
    "showDateTimePicker": [{ type: Input },],
    "buttonLabel": [{ type: Input },],
    "startDate": [{ type: Input },],
    "endDate": [{ type: Input },],
    "startTime": [{ type: Input },],
    "endTime": [{ type: Input },],
    "sortByStartDate": [{ type: Input },],
    "sortByEndDate": [{ type: Input },],
    "loadedAllAvailability": [{ type: Output },],
    "showScheduleView": [{ type: Input },],
    "showScheduleId": [{ type: Input },],
    "view": [{ type: Input },],
    "locale": [{ type: Input },],
    "hourSegments": [{ type: Input },],
    "dayStartHour": [{ type: Input },],
    "dayEndHour": [{ type: Input },],
    "eventLength": [{ type: Input },],
    "showSchedule": [{ type: Input },],
    "showSlotsView": [{ type: Input },],
    "showSlotId": [{ type: Input },],
    "showStartDate": [{ type: Input },],
    "showEndDate": [{ type: Input },],
    "dateTimeFormatString": [{ type: Input },],
    "showSlots": [{ type: Input },],
    "showSlot": [{ type: Input },],
    "form": [{ type: ViewChild, args: [FormGroupDirective,] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
// add all concept components here
const allComponents = [
    CreateScheduleComponent, DeleteScheduleComponent,
    ShowScheduleComponent, UpdateScheduleComponent,
    ShowSlotComponent, ShowSlotsComponent, ShowNextAvailabilityComponent,
    ShowAllAvailabilityComponent
];
const metadata = {
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        DvModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule, MatInputModule, MatFormFieldModule,
        MatSelectModule, MatDatepickerModule, MatMomentDateModule,
        CalendarModule.forRoot(),
        CalendarWeekHoursViewModule
    ],
    declarations: allComponents,
    entryComponents: allComponents,
    exports: allComponents
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class ScheduleModule {
}
ScheduleModule.decorators = [
    { type: NgModule, args: [Object.assign({}, metadata, { providers: [{ provide: API_PATH, useValue: '/graphql' }] }),] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { ScheduleModule, CreateScheduleComponent, DeleteScheduleComponent, ShowScheduleComponent, UpdateScheduleComponent, ShowSlotComponent, ShowSlotsComponent, ShowNextAvailabilityComponent, ShowAllAvailabilityComponent, metadata, API_PATH as ɵa, CustomDateFormatterProvider as ɵb, CustomEventTitleFormatterProvider as ɵc };
//# sourceMappingURL=deja-vu-schedule.js.map
