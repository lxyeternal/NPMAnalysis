/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { API_PATH as ɵa } from './src/app/schedule/schedule.config';
export { CustomDateFormatterProvider as ɵb, CustomEventTitleFormatterProvider as ɵc } from './src/app/schedule/shared/schedule.provider';
