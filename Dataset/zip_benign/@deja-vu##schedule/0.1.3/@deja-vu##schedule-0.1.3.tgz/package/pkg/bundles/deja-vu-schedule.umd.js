(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('angular-calendar'), require('@angular/common'), require('date-fns'), require('lodash'), require('@angular/core'), require('rxjs/Subject'), require('@deja-vu/core'), require('@angular/forms'), require('moment'), require('@angular/material'), require('@angular/material-moment-adapter'), require('@angular/platform-browser/animations'), require('angular-calendar-week-hours-view')) :
	typeof define === 'function' && define.amd ? define('@deja-vu/schedule', ['exports', 'angular-calendar', '@angular/common', 'date-fns', 'lodash', '@angular/core', 'rxjs/Subject', '@deja-vu/core', '@angular/forms', 'moment', '@angular/material', '@angular/material-moment-adapter', '@angular/platform-browser/animations', 'angular-calendar-week-hours-view'], factory) :
	(factory((global['deja-vu'] = global['deja-vu'] || {}, global['deja-vu'].schedule = {}),global.angularCalendar,global.ng.common,global.dateFns,global.lodash,global.ng.core,global.Rx,global.core$1,global.ng.forms,global.momentImported,global.ng.material,global.ng['material-moment-adapter'],global.ng.platformBrowser.animations,global.angularCalendarWeekHoursView));
}(this, (function (exports,angularCalendar,common,dateFns,lodash,core,Subject,core$1,forms,momentImported,material,materialMomentAdapter,animations,angularCalendarWeekHoursView) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0
THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.
See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */
var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};
function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}





function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}


function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

var CustomDateFormatterProvider = /** @class */ (function (_super) {
    __extends(CustomDateFormatterProvider, _super);
    function CustomDateFormatterProvider() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomDateFormatterProvider.prototype.dayViewHour = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new common.DatePipe(locale).transform(date, 'HH:mm', locale);
    };
    CustomDateFormatterProvider.prototype.weekViewTitle = function (_a) {
        var date = _a.date, locale = _a.locale;
        var year = new common.DatePipe(locale).transform(date, 'y', locale);
        var weekNumber = dateFns.getISOWeek(date);
        return "Week " + weekNumber + " in " + year;
    };
    CustomDateFormatterProvider.prototype.weekViewColumnHeader = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new common.DatePipe(locale).transform(date, 'E', locale);
    };
    CustomDateFormatterProvider.prototype.weekViewColumnSubHeader = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new common.DatePipe(locale).transform(date, 'MM/dd', locale);
    };
    return CustomDateFormatterProvider;
}(angularCalendar.CalendarDateFormatter));
var CustomEventTitleFormatterProvider = /** @class */ (function (_super) {
    __extends(CustomEventTitleFormatterProvider, _super);
    function CustomEventTitleFormatterProvider() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomEventTitleFormatterProvider.prototype.monthTooltip = function (event) {
        return;
    };
    CustomEventTitleFormatterProvider.prototype.weekTooltip = function (event) {
        return;
    };
    CustomEventTitleFormatterProvider.prototype.dayTooltip = function (event) {
        return;
    };
    return CustomEventTitleFormatterProvider;
}(angularCalendar.CalendarEventTitleFormatter));
function timeRange(start, end) {
    return dateFns.format(start, 'h[:]mm A') + " - " + dateFns.format(end, 'h[:]mm A');
}
function dateTimeRange(start, end) {
    var formatString = 'dddd do MM Mh[:]mm A';
    return dateFns.format(start, formatString) + " - " + dateFns.format(end, formatString);
}
function createNewCalendarEvent(start, end, editable) {
    return {
        start: start,
        end: end,
        title: timeRange(start, end),
        cssClass: 'custom-event',
        color: {
            primary: '#488aff',
            secondary: '#bbd0f5'
        },
        resizable: {
            beforeStart: editable,
            afterEnd: editable
        },
        draggable: editable
    };
}
function slotToCalendarEvent(slot, editable) {
    var start = new Date(slot.startDate);
    var end = new Date(slot.endDate);
    return {
        id: slot.id,
        start: start,
        end: end,
        title: timeRange(start, end),
        cssClass: 'custom-event',
        color: {
            primary: '#488aff',
            secondary: '#bbd0f5'
        },
        resizable: {
            beforeStart: editable,
            afterEnd: editable
        },
        draggable: editable
    };
}
function slotsToCalendarEvents(slots, editable) {
    return lodash.map(slots, function (slot) { return slotToCalendarEvent(slot, editable); });
}
function calendarEventToSlot(event) {
    return {
        startDate: event.start.toISOString(),
        endDate: event.end.toISOString()
    };
}
function calendarEventsToSlots(events) {
    return lodash.map(events, calendarEventToSlot);
}
var API_PATH = new core.InjectionToken('api.path');
var SAVED_MSG_TIMEOUT = 3000;
var DRAG_TIMEOUT = 1000;
var CreateScheduleComponent = /** @class */ (function () {
    function CreateScheduleComponent(elem, dvf, cd, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.cd = cd;
        this.apiPath = apiPath;
        this.showOptionToSubmit = true;
        this.showOptionToChangeView = true;
        this.buttonLabel = 'Create Schedule';
        this.newScheduleSavedText = 'New schedule saved';
        this.removeSlotText = 'Do you want to remove the following slot:';
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.viewDate = new Date();
        this.isDragging = false;
        this.refresh = new Subject.Subject();
        this.newScheduleSaved = false;
        this.events = [];
    }
    CreateScheduleComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    CreateScheduleComponent.prototype.ngAfterViewInit = function () {
        this.cd.detectChanges();
    };
    CreateScheduleComponent.prototype.handleEvent = function (event) {
        if (confirm(this.removeSlotText + "\n    " + dateTimeRange(event.start, event.end) + "?")) {
            lodash.pull(this.events, event);
            this.refresh.next();
        }
    };
    CreateScheduleComponent.prototype.eventTimesChanged = function (_a) {
        var _this = this;
        var event = _a.event, newStart = _a.newStart, newEnd = _a.newEnd;
        if (this.isDragging) {
            return;
        }
        this.isDragging = true;
        event.start = newStart;
        event.end = newEnd;
        event.title = timeRange(newStart, newEnd);
        this.refresh.next();
        setTimeout(function () {
            _this.isDragging = false;
        }, DRAG_TIMEOUT);
    };
    CreateScheduleComponent.prototype.hourSegmentClicked = function (event) {
        var start = event.date;
        var end = dateFns.addHours(event.date, this.eventLength);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.refresh.next();
    };
    CreateScheduleComponent.prototype.dayClicked = function (event) {
        var start = dateFns.startOfDay(event.day.date);
        var end = dateFns.endOfDay(event.day.date);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.refresh.next();
    };
    CreateScheduleComponent.prototype.onSubmit = function () {
        this.dvs.exec();
    };
    CreateScheduleComponent.prototype.dvOnExec = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dvs.post(this.apiPath, {
                            inputs: {
                                input: {
                                    id: this.id,
                                    slots: calendarEventsToSlots(this.events)
                                }
                            },
                            extraInfo: {
                                returnFields: 'id, availability { id, startDate, endDate }'
                            }
                        })];
                    case 1:
                        res = _a.sent();
                        if (res.errors) {
                            throw new Error(lodash.map(res.errors, 'message')
                                .join());
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    CreateScheduleComponent.prototype.dvOnExecSuccess = function () {
        var _this = this;
        this.newScheduleSaved = true;
        window.setTimeout(function () {
            _this.newScheduleSaved = false;
        }, SAVED_MSG_TIMEOUT);
        this.events = [];
    };
    CreateScheduleComponent.prototype.dvOnExecFailure = function (reason) {
        this.newScheduleError = reason.message;
    };
    return CreateScheduleComponent;
}());
CreateScheduleComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-create-schedule',
                template: "<div *ngIf=\"showOptionToSubmit\">\n  <div *ngIf=\"newScheduleSaved\" class=\"create-schedule-success\">\n    <i class=\"material-icons\">done</i>\n    {{newScheduleSavedText}}\n  </div>\n  <mat-error *ngIf=\"newScheduleError\">\n    <i class=\"material-icons\">report_problem</i>\n    {{newScheduleError}}\n  </mat-error>\n</div>\n\n<div class=\"create-schedule\">\n  <div class=\"row text-center\">\n    <div class=\"col-md-6\">\n      <div class=\"btn-group\">\n        <div class=\"btn btn-primary\"\n          mwlCalendarPreviousView\n          [view]=\"view\"\n          [(viewDate)]=\"viewDate\">\n          Previous\n        </div>\n        <div class=\"btn btn-outline-secondary\"\n          mwlCalendarToday\n          [(viewDate)]=\"viewDate\">\n          Today\n        </div>\n        <div class=\"btn btn-primary\"\n          mwlCalendarNextView\n          [view]=\"view\"\n          [(viewDate)]=\"viewDate\">\n          Next\n        </div>\n      </div>\n    </div>\n\n    <div class=\"col-md-6\">\n      <div *ngIf=\"showOptionToChangeView\" class=\"btn-group\">\n        <div class=\"btn btn-primary\"\n          (click)=\"view = 'month'\"\n          [class.active]=\"view === 'month'\">\n          Month\n        </div>\n        <div class=\"btn btn-primary\"\n          (click)=\"view = 'week'\"\n          [class.active]=\"view === 'week'\">\n          Week\n        </div>\n        <div class=\"btn btn-primary\"\n          (click)=\"view = 'day'\"\n          [class.active]=\"view === 'day'\">\n          Day\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"row text-center view-info\">\n    <div class=\"col-md-12\">\n      <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>\n    </div>\n  </div>\n\n  <br />\n\n  <mwl-calendar-month-view\n    *ngIf=\"view === 'month'\"\n    [viewDate]=\"viewDate\"\n    [events]=\"events\"\n    (eventClicked)=\"handleEvent($event.event)\"\n    (eventTimesChanged)=\"eventTimesChanged($event)\"\n    (dayClicked)=\"dayClicked($event)\"\n    [refresh]=\"refresh\"\n    [locale]=\"locale\">\n  </mwl-calendar-month-view>\n\n  <iq-calendar-week-hours-view\n    *ngIf=\"view === 'week'\"\n    [viewDate]=\"viewDate\"\n    [events]=\"events\"\n    [hourSegments]=\"hourSegments\"\n    [dayStartHour]=\"dayStartHour\"\n    [dayEndHour]=\"dayEndHour\"\n    (eventClicked)=\"handleEvent($event.event)\"\n    (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n    (eventTimesChanged)=\"eventTimesChanged($event)\"\n    [refresh]=\"refresh\"\n    [locale]=\"locale\">\n  </iq-calendar-week-hours-view>\n\n  <mwl-calendar-day-view\n    *ngIf=\"view === 'day'\"\n    [viewDate]=\"viewDate\"\n    [events]=\"events\"\n    [hourSegments]=\"hourSegments\"\n    [dayStartHour]=\"dayStartHour\"\n    [dayEndHour]=\"dayEndHour\"\n    (eventClicked)=\"handleEvent($event.event)\"\n    (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n    (eventTimesChanged)=\"eventTimesChanged($event)\"\n    [refresh]=\"refresh\"\n    [locale]=\"locale\">\n  </mwl-calendar-day-view>\n</div>\n\n<div *ngIf=\"showOptionToSubmit\" class=\"form-group\">\n  <br />\n  <div class=\"dv-mat-button\">\n    <button mat-button class=\"create-schedule-submit-button\"\n      type=\"submit\" (click)=\"onSubmit()\">\n      {{buttonLabel}}\n    </button>\n  </div>\n</div>\n",
                styles: [".create-schedule-submit-button{float:right}.create-schedule-success{color:green}.view-info{margin-top:15px}"],
                providers: [
                    {
                        provide: angularCalendar.CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: angularCalendar.CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
CreateScheduleComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: core.ChangeDetectorRef, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
CreateScheduleComponent.propDecorators = {
    "id": [{ type: core.Input },],
    "showOptionToSubmit": [{ type: core.Input },],
    "showOptionToChangeView": [{ type: core.Input },],
    "buttonLabel": [{ type: core.Input },],
    "newScheduleSavedText": [{ type: core.Input },],
    "removeSlotText": [{ type: core.Input },],
    "view": [{ type: core.Input },],
    "locale": [{ type: core.Input },],
    "hourSegments": [{ type: core.Input },],
    "dayStartHour": [{ type: core.Input },],
    "dayEndHour": [{ type: core.Input },],
    "eventLength": [{ type: core.Input },],
};
var DeleteScheduleComponent = /** @class */ (function () {
    function DeleteScheduleComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
    }
    DeleteScheduleComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    DeleteScheduleComponent.prototype.deleteSchedule = function () {
        this.dvs.exec();
    };
    DeleteScheduleComponent.prototype.dvOnExec = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dvs.post(this.apiPath, {
                            inputs: {
                                id: this.id
                            }
                        })];
                    case 1:
                        res = _a.sent();
                        if (res.errors) {
                            throw new Error(lodash.map(res.errors, 'message')
                                .join());
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    return DeleteScheduleComponent;
}());
DeleteScheduleComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-delete-schedule',
                template: "<div class=\"dv-mat-button\">\n  <button mat-button (click)=\"deleteSchedule()\">\n    <i class=\"material-icons\">delete</i>\n  </button>\n</div>\n",
                styles: [""]
            },] },
];
DeleteScheduleComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
DeleteScheduleComponent.propDecorators = {
    "id": [{ type: core.Input },],
};
var ShowScheduleComponent = /** @class */ (function () {
    function ShowScheduleComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.scheduleWasGiven = false;
        this.loadedSchedule = new core.EventEmitter();
        this.showId = true;
        this.showAvailability = true;
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.viewDate = new Date();
        this.events = [];
    }
    Object.defineProperty(ShowScheduleComponent.prototype, "schedule", {
        get: function () { return this._schedule; },
        set: function (value) {
            if (!lodash.isNil(value)) {
                this.scheduleWasGiven = true;
                this.events = slotsToCalendarEvents(value.availability, false);
                this._schedule = value;
            }
        },
        enumerable: true,
        configurable: true
    });
    ShowScheduleComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dvs = this.dvf.forComponent(this)
            .withDefaultWaiter()
            .withRefreshCallback(function () { _this.load(); })
            .build();
    };
    ShowScheduleComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowScheduleComponent.prototype.ngOnChanges = function (changes) {
        if (this.dvs && this.dvs.waiter.processChanges(changes)) {
            this.load();
        }
    };
    ShowScheduleComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowScheduleComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var res, schedule;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.waitAndGet(this.apiPath, function () { return ({
                                params: {
                                    inputs: {
                                        id: _this.id
                                    },
                                    extraInfo: {
                                        returnFields: "\n                " + (_this.showId ? 'id' : '') + "\n                " + (_this.showAvailability ? 'availability { startDate, endDate }'
                                            : '') + "\n              "
                                    }
                                }
                            }); })];
                    case 1:
                        res = _a.sent();
                        schedule = res.data.schedule;
                        this.events = slotsToCalendarEvents(schedule.availability, false);
                        this._schedule = schedule;
                        this.loadedSchedule.emit(schedule);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowScheduleComponent.prototype.ngOnDestroy = function () {
        this.dvs.onDestroy();
    };
    ShowScheduleComponent.prototype.canEval = function () {
        return !!(this.dvs && !this.scheduleWasGiven);
    };
    return ShowScheduleComponent;
}());
ShowScheduleComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-show-schedule',
                template: "<span *ngIf=\"_schedule\">\n  <div *ngIf=\"showId\">\n    {{_schedule.id}}\n  </div>\n\n  <div *ngIf=\"showAvailability\">\n    <div class=\"row text-center\">\n      <div class=\"col-md-4\">\n        <div class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            mwlCalendarPreviousView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Previous\n          </div>\n          <div class=\"btn btn-outline-secondary\"\n            mwlCalendarToday\n            [(viewDate)]=\"viewDate\">\n            Today\n          </div>\n          <div class=\"btn btn-primary\"\n            mwlCalendarNextView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Next\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-4\">\n        <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>\n      </div>\n\n      <div class=\"col-md-4\">\n        <div class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'month'\"\n            [class.active]=\"view === 'month'\">\n            Month\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'week'\"\n            [class.active]=\"view === 'week'\">\n            Week\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'day'\"\n            [class.active]=\"view === 'day'\">\n            Day\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <br />\n\n    <mwl-calendar-month-view\n      *ngIf=\"view === 'month'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-month-view>\n\n    <iq-calendar-week-hours-view\n      *ngIf=\"view === 'week'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </iq-calendar-week-hours-view>\n\n    <mwl-calendar-day-view\n      *ngIf=\"view === 'day'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-day-view>\n  </div>\n</span>\n",
                styles: [".custom-event a{color:#fff!important;font-weight:700;text-decoration:none}.cal-day-view .cal-event{white-space:normal}.cal-day-view .cal-event-container{width:100%!important}.cal-day-view .cal-time{width:40px!important;font-size:smaller!important}.cal-week-hours-view .cal-day-container:first-child{width:40px!important;-webkit-box-flex:0;-ms-flex:none;flex:none}.cal-week-hours-view .cal-header:first-child{width:40px!important;-webkit-box-flex:0;-ms-flex:none;flex:none;border:none}.cal-header{border-left:1px solid #e1e1e1}.cal-today{color:pink}"],
                providers: [
                    {
                        provide: angularCalendar.CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: angularCalendar.CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
ShowScheduleComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
ShowScheduleComponent.propDecorators = {
    "waitOn": [{ type: core.Input },],
    "id": [{ type: core.Input },],
    "schedule": [{ type: core.Input },],
    "loadedSchedule": [{ type: core.Output },],
    "showId": [{ type: core.Input },],
    "showAvailability": [{ type: core.Input },],
    "view": [{ type: core.Input },],
    "locale": [{ type: core.Input },],
    "hourSegments": [{ type: core.Input },],
    "dayStartHour": [{ type: core.Input },],
    "dayEndHour": [{ type: core.Input },],
    "eventLength": [{ type: core.Input },],
};
var SAVED_MSG_TIMEOUT$1 = 3000;
var DRAG_TIMEOUT$1 = 1000;
var UpdateScheduleComponent = /** @class */ (function () {
    function UpdateScheduleComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.waitOn = [];
        this.showOptionToSubmit = true;
        this.showOptionToChangeView = true;
        this.buttonLabel = 'Update Schedule';
        this.updateScheduleSavedText = 'Schedule updated';
        this.deleteSlotText = 'Do you want to delete the following slot:';
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.viewDate = new Date();
        this.isDragging = false;
        this.refresh = new Subject.Subject();
        this.updateScheduleSaved = false;
        this.events = [];
        this.newEvents = [];
        this.deletedEventIds = [];
    }
    UpdateScheduleComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .withDefaultWaiter()
            .build();
    };
    UpdateScheduleComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    UpdateScheduleComponent.prototype.ngOnChanges = function (changes) {
        if (this.dvs && this.dvs.waiter.processChanges(changes)) {
            this.load();
        }
    };
    UpdateScheduleComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    UpdateScheduleComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.waitAndGet(this.apiPath, function () { return ({
                                params: {
                                    inputs: { id: _this.id },
                                    extraInfo: {
                                        action: 'load',
                                        returnFields: 'id, availability { id, startDate, endDate }'
                                    }
                                }
                            }); })];
                    case 1:
                        res = _a.sent();
                        if (!lodash.isNil(res.data.schedule)) {
                            this.schedule = res.data.schedule;
                            this.events = slotsToCalendarEvents(this.schedule.availability, true);
                        }
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    UpdateScheduleComponent.prototype.handleEvent = function (event) {
        if (confirm(this.deleteSlotText + "\n    " + dateTimeRange(event.start, event.end) + "?")) {
            lodash.pull(this.events, event);
            this.deletedEventIds.push(event.id.toString());
            this.refresh.next();
        }
    };
    UpdateScheduleComponent.prototype.eventTimesChanged = function (_a) {
        var _this = this;
        var event = _a.event, newStart = _a.newStart, newEnd = _a.newEnd;
        if (this.isDragging) {
            return;
        }
        this.isDragging = true;
        this.deletedEventIds.push(event.id.toString());
        lodash.remove(this.newEvents, function (e) { return e.id === event.id; });
        event.start = newStart;
        event.end = newEnd;
        event.title = timeRange(newStart, newEnd);
        this.newEvents.push(event);
        this.refresh.next();
        setTimeout(function () {
            _this.isDragging = false;
        }, DRAG_TIMEOUT$1);
    };
    UpdateScheduleComponent.prototype.hourSegmentClicked = function (event) {
        var start = event.date;
        var end = dateFns.addHours(event.date, this.eventLength);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.newEvents.push(newEvent);
        this.refresh.next();
    };
    UpdateScheduleComponent.prototype.dayClicked = function (event) {
        var start = dateFns.startOfDay(event.day.date);
        var end = dateFns.endOfDay(event.day.date);
        var newEvent = createNewCalendarEvent(start, end, true);
        this.events.push(newEvent);
        this.newEvents.push(newEvent);
        this.refresh.next();
    };
    UpdateScheduleComponent.prototype.onSubmit = function () {
        this.dvs.exec();
    };
    UpdateScheduleComponent.prototype.dvOnExec = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.dvs.post(this.apiPath, {
                            inputs: {
                                input: {
                                    id: this.id,
                                    add: calendarEventsToSlots(this.newEvents),
                                    delete: lodash.uniq(this.deletedEventIds)
                                }
                            },
                            extraInfo: {
                                action: 'update'
                            }
                        })];
                    case 1:
                        res = _a.sent();
                        if (res.errors) {
                            throw new Error(lodash.map(res.errors, 'message')
                                .join());
                        }
                        return [2 /*return*/, res.data.updateSchedule];
                }
            });
        });
    };
    UpdateScheduleComponent.prototype.dvOnExecSuccess = function () {
        var _this = this;
        this.updateScheduleSaved = true;
        this.updateScheduleError = '';
        window.setTimeout(function () {
            _this.updateScheduleSaved = false;
        }, SAVED_MSG_TIMEOUT$1);
    };
    UpdateScheduleComponent.prototype.dvOnExecFailure = function (reason) {
        this.updateScheduleError = reason.message;
    };
    UpdateScheduleComponent.prototype.canEval = function () {
        return !!(this.dvs && this.id);
    };
    return UpdateScheduleComponent;
}());
UpdateScheduleComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-update-schedule',
                template: "<div *ngIf=\"schedule\">\n  <div *ngIf=\"showOptionToSubmit\">\n    <div *ngIf=\"updateScheduleSaved\" class=\"update-schedule-success\">\n      <i class=\"material-icons\">done</i>\n      {{updateScheduleSavedText}}\n    </div>\n    <mat-error *ngIf=\"updateScheduleError\">\n      <i class=\"material-icons\">report_problem</i>\n      {{updateScheduleError}}\n    </mat-error>\n  </div>\n\n  <div class=\"update-schedule\">\n    <div class=\"row text-center\">\n      <div class=\"col-md-6\">\n        <div class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            mwlCalendarPreviousView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Previous\n          </div>\n          <div class=\"btn btn-outline-secondary\"\n            mwlCalendarToday\n            [(viewDate)]=\"viewDate\">\n            Today\n          </div>\n          <div class=\"btn btn-primary\"\n            mwlCalendarNextView\n            [view]=\"view\"\n            [(viewDate)]=\"viewDate\">\n            Next\n          </div>\n        </div>\n      </div>\n\n      <div class=\"col-md-6\">\n        <div *ngIf=\"showOptionToChangeView\" class=\"btn-group\">\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'month'\"\n            [class.active]=\"view === 'month'\">\n            Month\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'week'\"\n            [class.active]=\"view === 'week'\">\n            Week\n          </div>\n          <div class=\"btn btn-primary\"\n            (click)=\"view = 'day'\"\n            [class.active]=\"view === 'day'\">\n            Day\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"row text-center view-info\">\n      <div class=\"col-md-4\">\n        <h5>{{ viewDate | calendarDate:(view + 'ViewTitle'):'en' }}</h5>\n      </div>\n    </div>\n\n    <br />\n\n    <mwl-calendar-month-view\n      *ngIf=\"view === 'month'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      (eventClicked)=\"handleEvent($event.event)\"\n      (eventTimesChanged)=\"eventTimesChanged($event)\"\n      (dayClicked)=\"dayClicked($event)\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-month-view>\n\n    <iq-calendar-week-hours-view\n      *ngIf=\"view === 'week'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      (eventClicked)=\"handleEvent($event.event)\"\n      (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n      (eventTimesChanged)=\"eventTimesChanged($event)\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </iq-calendar-week-hours-view>\n\n    <mwl-calendar-day-view\n      *ngIf=\"view === 'day'\"\n      [viewDate]=\"viewDate\"\n      [events]=\"events\"\n      [hourSegments]=\"hourSegments\"\n      [dayStartHour]=\"dayStartHour\"\n      [dayEndHour]=\"dayEndHour\"\n      (eventClicked)=\"handleEvent($event.event)\"\n      (hourSegmentClicked)=\"hourSegmentClicked($event)\"\n      (eventTimesChanged)=\"eventTimesChanged($event)\"\n      [refresh]=\"refresh\"\n      [locale]=\"locale\">\n    </mwl-calendar-day-view>\n  </div>\n  <div *ngIf=\"showOptionToSubmit\" class=\"form-group\">\n    <br />\n    <div class=\"dv-mat-button\">\n      <button mat-raised-button class=\"update-schedule-submit-button\"\n        type=\"submit\" (click)=\"onSubmit()\">\n        {{buttonLabel}}\n      </button>\n    </div>\n  </div>\n</div>\n",
                styles: [".update-schedule-submit-button{float:right}.update-schedule-success{color:green}.view-info{margin-top:15px}"],
                providers: [
                    {
                        provide: angularCalendar.CalendarDateFormatter,
                        useClass: CustomDateFormatterProvider
                    },
                    {
                        provide: angularCalendar.CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatterProvider
                    }
                ]
            },] },
];
UpdateScheduleComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
UpdateScheduleComponent.propDecorators = {
    "waitOn": [{ type: core.Input },],
    "id": [{ type: core.Input },],
    "showOptionToSubmit": [{ type: core.Input },],
    "showOptionToChangeView": [{ type: core.Input },],
    "buttonLabel": [{ type: core.Input },],
    "updateScheduleSavedText": [{ type: core.Input },],
    "deleteSlotText": [{ type: core.Input },],
    "view": [{ type: core.Input },],
    "locale": [{ type: core.Input },],
    "hourSegments": [{ type: core.Input },],
    "dayStartHour": [{ type: core.Input },],
    "dayEndHour": [{ type: core.Input },],
    "eventLength": [{ type: core.Input },],
};
var ShowSlotComponent = /** @class */ (function () {
    function ShowSlotComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.loadedSlot = new core.EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
    }
    ShowSlotComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowSlotComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowSlotComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowSlotComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowSlotComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: {
                                        id: this.id
                                    },
                                    extraInfo: {
                                        returnFields: "\n              " + (this.showId ? 'id' : '') + "\n              " + (this.showStartDate ? 'startDate' : '') + "\n              " + (this.showEndDate ? 'endDate' : '') + "\n            "
                                    }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.slot = res.data.slot;
                        this.loadedSlot.emit(this.slot);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowSlotComponent.prototype.canEval = function () {
        return !!(!this.slot && this.id && this.dvs);
    };
    return ShowSlotComponent;
}());
ShowSlotComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-show-slot',
                template: "<span *ngIf=\"slot\">\n  <div *ngIf=\"showId\">\n    {{ slot.id }}\n  </div>\n\n  <div *ngIf=\"showStartDate\">\n    {{ slot.startDate | date: dateTimeFormatString }}\n  </div>\n\n  <div *ngIf=\"showEndDate\">\n    {{ slot.endDate | date: dateTimeFormatString }}\n  </div>\n</span>\n",
                styles: [""]
            },] },
];
ShowSlotComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
ShowSlotComponent.propDecorators = {
    "id": [{ type: core.Input },],
    "slot": [{ type: core.Input },],
    "loadedSlot": [{ type: core.Output },],
    "showId": [{ type: core.Input },],
    "showStartDate": [{ type: core.Input },],
    "showEndDate": [{ type: core.Input },],
    "dateTimeFormatString": [{ type: core.Input },],
};
function endDateValidator(getStartDate) {
    return function (control) {
        var startDate = getStartDate();
        var endDate = control.value;
        if (!(startDate && endDate)) {
            return null;
        }
        if (endDate.isBefore(startDate)) {
            return { endDateBeforeStartDate: true };
        }
        return null;
    };
}
function endTimeValidator(getStartTime) {
    return function (control) {
        var startTime = getStartTime();
        var endTime = control.value;
        if (!(startTime && endTime)) {
            return null;
        }
        var _a = __read(startTime.split(':'), 2), startHh = _a[0], startMm = _a[1];
        var _b = __read(endTime.split(':'), 2), endHh = _b[0], endMm = _b[1];
        if (startHh > endHh || (startHh === endHh && startMm >= endMm)) {
            return { endTimeBeforeStartTime: true };
        }
        return null;
    };
}
var moment = momentImported;
var ShowSlotsComponent = /** @class */ (function () {
    function ShowSlotsComponent(elem, dvf, builder, apiPath) {
        var _this = this;
        this.elem = elem;
        this.dvf = dvf;
        this.builder = builder;
        this.apiPath = apiPath;
        this.showDateTimePicker = true;
        this.buttonLabel = 'Filter Availability';
        this.sortByStartDate = 'asc';
        this.sortByEndDate = 'asc';
        this.loadedSlots = new core.EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
        this.showSlot = {
            type: (ShowSlotComponent)
        };
        this.startDateControl = new forms.FormControl('');
        this.endDateControl = new forms.FormControl('', [
            endDateValidator(function () { return _this.startDateControl.value; })
        ]);
        this.startTimeControl = new forms.FormControl('');
        this.endTimeControl = new forms.FormControl('', [
            endTimeValidator(function () { return _this.startTimeControl.value; })
        ]);
        this.dateTimeFilterForm = this.builder.group({
            startsOn: this.startDateControl,
            endsOn: this.endDateControl,
            startTime: this.startTimeControl,
            endTime: this.endTimeControl
        });
        this.showSlots = this;
    }
    Object.defineProperty(ShowSlotsComponent.prototype, "startDate", {
        set: function (value) {
            this.startDateControl.setValue(moment(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowSlotsComponent.prototype, "endDate", {
        set: function (value) {
            this.endDateControl.setValue(moment(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowSlotsComponent.prototype, "startTime", {
        set: function (value) {
            this.startTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowSlotsComponent.prototype, "endTime", {
        set: function (value) {
            this.endTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    ShowSlotsComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowSlotsComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowSlotsComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowSlotsComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowSlotsComponent.prototype.filterSlots = function () {
        this.dvs.eval();
    };
    ShowSlotsComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var startDate, endDate, res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        startDate = this.startDateControl.value ?
                            this.startDateControl.value.format('YYYY-MM-DD') : '';
                        endDate = this.endDateControl.value ?
                            this.endDateControl.value.format('YYYY-MM-DD') : '';
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: JSON.stringify({
                                        input: {
                                            scheduleId: this.scheduleId,
                                            startDate: startDate,
                                            endDate: endDate,
                                            startTime: this.startTimeControl.value,
                                            endTime: this.endTimeControl.value,
                                            sortByStartDate: this.sortByStartDate === 'asc' ? 1 : -1,
                                            sortByEndDate: this.sortByEndDate === 'asc' ? 1 : -1
                                        }
                                    }),
                                    extraInfo: {
                                        returnFields: "\n                " + (this.showId ? 'id' : '') + "\n                " + (this.showStartDate ? 'startDate' : '') + "\n                " + (this.showEndDate ? 'endDate' : '') + "\n              "
                                    }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.slots = res.data.slots;
                        this.loadedSlots.emit(this.slots);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowSlotsComponent.prototype.canEval = function () {
        return !!(!this.slots && this.scheduleId && this.dvs);
    };
    return ShowSlotsComponent;
}());
ShowSlotsComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-show-slots',
                template: "<div *ngIf=\"showDateTimePicker\">\n  <form (ngSubmit)=\"filterSlots()\" [formGroup]=\"dateTimeFilterForm\"\n    class=\"form-horizontal\">\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Date</mat-label>\n        <input matInput [matDatepicker]=\"startDatePicker\"\n         [formControl]=\"startDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"startDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #startDatePicker></mat-datepicker>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"startTimeControl\">\n      </mat-form-field>\n    </div>\n\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Date</mat-label>\n        <input matInput [matDatepicker]=\"endDatePicker\"\n          [formControl]=\"endDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"endDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #endDatePicker></mat-datepicker>\n        <mat-error *ngIf=\"endDateControl.hasError('endDateBeforeStartDate')\">\n          End Date should be <strong>after</strong> Start Date\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"endTimeControl\">\n        <mat-error *ngIf=\"endTimeControl.hasError('endTimeBeforeStartTime')\">\n          End Time should be <strong>after</strong> Start Time\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <button mat-button type=\"submit\">\n        {{buttonLabel}}\n      </button>\n    </div>\n  </form>\n</div>\n\n<ul *ngIf=\"slots && slots.length > 0\" class=\"list-group\">\n  <li *ngFor=\"let slot of slots\" class=\"list-group-item\">\n    <dv-include\n      [component]=\"showSlot\"\n      default-showSlot=\"{ tag: schedule-show-slot }\"\n      [inputs]=\"{\n        slot: slot, showId: showId,\n        showStartDate: showStartDate,\n        showEndDate: showEndDate,\n        dateTimeFormatString: dateTimeFormatString\n      }\"\n      [parent]=\"showSlots\">\n    </dv-include>\n  </li>\n</ul>\n\n<div *ngIf=\"!slots || slots.length === 0\">\n  <span>{{noSlotsToShowText}}</span>\n</div>\n",
                styles: [""]
            },] },
];
ShowSlotsComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: forms.FormBuilder, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
ShowSlotsComponent.propDecorators = {
    "scheduleId": [{ type: core.Input },],
    "slots": [{ type: core.Input },],
    "showDateTimePicker": [{ type: core.Input },],
    "buttonLabel": [{ type: core.Input },],
    "startDate": [{ type: core.Input },],
    "endDate": [{ type: core.Input },],
    "startTime": [{ type: core.Input },],
    "endTime": [{ type: core.Input },],
    "sortByStartDate": [{ type: core.Input },],
    "sortByEndDate": [{ type: core.Input },],
    "loadedSlots": [{ type: core.Output },],
    "showId": [{ type: core.Input },],
    "showStartDate": [{ type: core.Input },],
    "showEndDate": [{ type: core.Input },],
    "dateTimeFormatString": [{ type: core.Input },],
    "showSlot": [{ type: core.Input },],
    "form": [{ type: core.ViewChild, args: [forms.FormGroupDirective,] },],
};
var ShowNextAvailabilityComponent = /** @class */ (function () {
    function ShowNextAvailabilityComponent(elem, dvf, apiPath) {
        this.elem = elem;
        this.dvf = dvf;
        this.apiPath = apiPath;
        this.loadedNextAvailability = new core.EventEmitter();
        this.showId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
        this.showSlot = {
            type: (ShowSlotComponent)
        };
        this.showNextAvailability = this;
    }
    ShowNextAvailabilityComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowNextAvailabilityComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowNextAvailabilityComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowNextAvailabilityComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowNextAvailabilityComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: JSON.stringify({
                                        input: {
                                            scheduleIds: this.scheduleIds
                                        }
                                    }),
                                    extraInfo: {
                                        returnFields: "\n              " + (this.showId ? 'id' : '') + "\n              " + (this.showStartDate ? 'startDate' : '') + "\n              " + (this.showEndDate ? 'endDate' : '') + "\n            "
                                    }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.nextAvailability = res.data.nextAvailability;
                        this.loadedNextAvailability.emit(this.nextAvailability);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowNextAvailabilityComponent.prototype.canEval = function () {
        return !!(!this.nextAvailability && this.scheduleIds && this.dvs);
    };
    return ShowNextAvailabilityComponent;
}());
ShowNextAvailabilityComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-show-next-availability',
                template: "<span *ngIf=\"nextAvailability\">\n  <dv-include\n    [component]=\"showSlot\"\n    default-showSlot=\"{ tag: schedule-show-slot }\"\n    [inputs]=\"{\n      slot: nextAvailability, showId: showId,\n      showStartDate: showStartDate,\n      showEndDate: showEndDate,\n      dateTimeFormatString: dateTimeFormatString\n    }\"\n    [parent]=\"showNextAvailability\">\n  </dv-include>\n</span>\n",
                styles: [""]
            },] },
];
ShowNextAvailabilityComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
ShowNextAvailabilityComponent.propDecorators = {
    "scheduleIds": [{ type: core.Input },],
    "loadedNextAvailability": [{ type: core.Output },],
    "showId": [{ type: core.Input },],
    "showStartDate": [{ type: core.Input },],
    "showEndDate": [{ type: core.Input },],
    "dateTimeFormatString": [{ type: core.Input },],
    "showSlot": [{ type: core.Input },],
};
var moment$1 = momentImported;
var ShowAllAvailabilityComponent = /** @class */ (function () {
    function ShowAllAvailabilityComponent(elem, dvf, builder, apiPath) {
        var _this = this;
        this.elem = elem;
        this.dvf = dvf;
        this.builder = builder;
        this.apiPath = apiPath;
        this.showDateTimePicker = true;
        this.buttonLabel = 'Filter Slots';
        this.sortByStartDate = 'asc';
        this.sortByEndDate = 'asc';
        this.loadedAllAvailability = new core.EventEmitter();
        this.showScheduleView = true;
        this.showScheduleId = false;
        this.view = 'week';
        this.locale = 'en';
        this.hourSegments = 2;
        this.dayStartHour = 9;
        this.dayEndHour = 17;
        this.eventLength = 1;
        this.showSchedule = {
            type: (ShowScheduleComponent)
        };
        this.showSlotsView = true;
        this.showSlotId = true;
        this.showStartDate = true;
        this.showEndDate = true;
        this.dateTimeFormatString = 'medium';
        this.showSlots = {
            type: (ShowSlotsComponent)
        };
        this.showSlot = {
            type: (ShowSlotComponent)
        };
        this.startDateControl = new forms.FormControl('');
        this.endDateControl = new forms.FormControl('', [
            endDateValidator(function () { return _this.startDateControl.value; })
        ]);
        this.startTimeControl = new forms.FormControl('');
        this.endTimeControl = new forms.FormControl('', [
            endTimeValidator(function () { return _this.startTimeControl.value; })
        ]);
        this.dateTimeFilterForm = this.builder.group({
            startsOn: this.startDateControl,
            endsOn: this.endDateControl,
            startTime: this.startTimeControl,
            endTime: this.endTimeControl
        });
        this.showSlotsDateTimePicker = false;
        this.showAllAvailability = this;
    }
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "startDate", {
        set: function (value) {
            this.startDateControl.setValue(moment$1(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "endDate", {
        set: function (value) {
            this.endDateControl.setValue(moment$1(value));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "startTime", {
        set: function (value) {
            this.startTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ShowAllAvailabilityComponent.prototype, "endTime", {
        set: function (value) {
            this.endTimeControl.setValue(value);
        },
        enumerable: true,
        configurable: true
    });
    ShowAllAvailabilityComponent.prototype.ngOnInit = function () {
        this.dvs = this.dvf.forComponent(this)
            .build();
    };
    ShowAllAvailabilityComponent.prototype.ngAfterViewInit = function () {
        this.load();
    };
    ShowAllAvailabilityComponent.prototype.ngOnChanges = function () {
        this.load();
    };
    ShowAllAvailabilityComponent.prototype.load = function () {
        if (this.canEval()) {
            this.dvs.eval();
        }
    };
    ShowAllAvailabilityComponent.prototype.filterSlots = function () {
        this.dvs.eval();
    };
    ShowAllAvailabilityComponent.prototype.dvOnEval = function () {
        return __awaiter(this, void 0, void 0, function () {
            var startDate, endDate, res;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.canEval()) return [3 /*break*/, 2];
                        startDate = this.startDateControl.value ?
                            this.startDateControl.value.format('YYYY-MM-DD') : '';
                        endDate = this.endDateControl.value ?
                            this.endDateControl.value.format('YYYY-MM-DD') : '';
                        return [4 /*yield*/, this.dvs.get(this.apiPath, {
                                params: {
                                    inputs: JSON.stringify({
                                        input: {
                                            scheduleIds: this.scheduleIds,
                                            startDate: startDate,
                                            endDate: endDate,
                                            startTime: this.startTimeControl.value,
                                            endTime: this.endTimeControl.value,
                                            sortByStartDate: this.sortByStartDate === 'asc' ? 1 : -1,
                                            sortByEndDate: this.sortByEndDate === 'asc' ? 1 : -1
                                        }
                                    }),
                                    extraInfo: { returnFields: 'id, startDate, endDate' }
                                }
                            })];
                    case 1:
                        res = _a.sent();
                        this.allAvailability = res.data.allAvailability;
                        this.schedule = {
                            id: 'all-availability',
                            availability: this.allAvailability
                        };
                        this.loadedAllAvailability.emit(this.allAvailability);
                        return [3 /*break*/, 3];
                    case 2:
                        if (this.dvs) {
                            this.dvs.noRequest();
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    ShowAllAvailabilityComponent.prototype.canEval = function () {
        return !!(!this.allAvailability && this.scheduleIds && this.dvs);
    };
    return ShowAllAvailabilityComponent;
}());
ShowAllAvailabilityComponent.decorators = [
    { type: core.Component, args: [{
                selector: 'schedule-show-all-availability',
                template: "<div *ngIf=\"showDateTimePicker\">\n  <form (ngSubmit)=\"filterSlots()\" [formGroup]=\"dateTimeFilterForm\"\n    class=\"form-horizontal\">\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Date</mat-label>\n        <input matInput [matDatepicker]=\"startDatePicker\"\n         [formControl]=\"startDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"startDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #startDatePicker></mat-datepicker>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>Start Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"startTimeControl\">\n      </mat-form-field>\n    </div>\n\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Date</mat-label>\n        <input matInput [matDatepicker]=\"endDatePicker\"\n          [formControl]=\"endDateControl\">\n        <mat-datepicker-toggle matSuffix [for]=\"endDatePicker\">\n        </mat-datepicker-toggle>\n        <mat-datepicker #endDatePicker></mat-datepicker>\n        <mat-error *ngIf=\"endDateControl.hasError('endDateBeforeStartDate')\">\n          End Date should be <strong>after</strong> Start Date\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <mat-form-field>\n        <mat-label>End Time</mat-label>\n        <input matInput type=\"time\" [formControl]=\"endTimeControl\">\n        <mat-error *ngIf=\"endTimeControl.hasError('endTimeBeforeStartTime')\">\n          End Time should be <strong>after</strong> Start Time\n        </mat-error>\n      </mat-form-field>\n    </div>\n    <div class=\"form-group\">\n      <div class=\"dv-mat-button\">\n        <button mat-button type=\"submit\">\n          {{buttonLabel}}\n        </button>\n      </div>\n    </div>\n  </form>\n</div>\n\n<span *ngIf=\"allAvailability\">\n  <span *ngIf=\"showScheduleView\">\n    <dv-include\n      [component]=\"showSchedule\"\n      default-showSchedule=\"{ tag: schedule-show-schedule }\"\n      [inputs]=\"{\n        schedule: schedule, showId: showScheduleId,\n        view: view, locale: locale, hourSegments: hourSegments,\n        dayStartHour: dayStartHour, dayEndHour: dayEndHour,\n        eventLength: eventLength\n      }\"\n      [parent]=\"showAllAvailability\">\n    </dv-include>\n  </span>\n\n  <span *ngIf=\"showSlotsView\">\n    <dv-include\n      [component]=\"showSlots\"\n      default-showSlots=\"{ tag: schedule-show-slots }\"\n      [inputs]=\"{\n        slots: allAvailability, showId: showSlotId,\n        showStartDate: showStartDate, showEndDate: showEndDate,\n        showDateTimePicker: showSlotsDateTimePicker,\n        dateTimeFormatString: dateTimeFormatString,\n        showSlot: showSlot\n      }\"\n      [parent]=\"showAllAvailability\">\n    </dv-include>\n  </span>\n</span>\n",
                styles: [""]
            },] },
];
ShowAllAvailabilityComponent.ctorParameters = function () { return [
    { type: core.ElementRef, },
    { type: core$1.DvServiceFactory, },
    { type: forms.FormBuilder, },
    { type: undefined, decorators: [{ type: core.Inject, args: [API_PATH,] },] },
]; };
ShowAllAvailabilityComponent.propDecorators = {
    "scheduleIds": [{ type: core.Input },],
    "showDateTimePicker": [{ type: core.Input },],
    "buttonLabel": [{ type: core.Input },],
    "startDate": [{ type: core.Input },],
    "endDate": [{ type: core.Input },],
    "startTime": [{ type: core.Input },],
    "endTime": [{ type: core.Input },],
    "sortByStartDate": [{ type: core.Input },],
    "sortByEndDate": [{ type: core.Input },],
    "loadedAllAvailability": [{ type: core.Output },],
    "showScheduleView": [{ type: core.Input },],
    "showScheduleId": [{ type: core.Input },],
    "view": [{ type: core.Input },],
    "locale": [{ type: core.Input },],
    "hourSegments": [{ type: core.Input },],
    "dayStartHour": [{ type: core.Input },],
    "dayEndHour": [{ type: core.Input },],
    "eventLength": [{ type: core.Input },],
    "showSchedule": [{ type: core.Input },],
    "showSlotsView": [{ type: core.Input },],
    "showSlotId": [{ type: core.Input },],
    "showStartDate": [{ type: core.Input },],
    "showEndDate": [{ type: core.Input },],
    "dateTimeFormatString": [{ type: core.Input },],
    "showSlots": [{ type: core.Input },],
    "showSlot": [{ type: core.Input },],
    "form": [{ type: core.ViewChild, args: [forms.FormGroupDirective,] },],
};
var allComponents = [
    CreateScheduleComponent, DeleteScheduleComponent,
    ShowScheduleComponent, UpdateScheduleComponent,
    ShowSlotComponent, ShowSlotsComponent, ShowNextAvailabilityComponent,
    ShowAllAvailabilityComponent
];
var metadata = {
    imports: [
        animations.BrowserAnimationsModule,
        common.CommonModule,
        core$1.DvModule,
        forms.FormsModule,
        forms.ReactiveFormsModule,
        material.MatButtonModule, material.MatInputModule, material.MatFormFieldModule,
        material.MatSelectModule, material.MatDatepickerModule, materialMomentAdapter.MatMomentDateModule,
        angularCalendar.CalendarModule.forRoot(),
        angularCalendarWeekHoursView.CalendarWeekHoursViewModule
    ],
    declarations: allComponents,
    entryComponents: allComponents,
    exports: allComponents
};
var ScheduleModule = /** @class */ (function () {
    function ScheduleModule() {
    }
    return ScheduleModule;
}());
ScheduleModule.decorators = [
    { type: core.NgModule, args: [Object.assign({}, metadata, { providers: [{ provide: API_PATH, useValue: '/graphql' }] }),] },
];

exports.ScheduleModule = ScheduleModule;
exports.CreateScheduleComponent = CreateScheduleComponent;
exports.DeleteScheduleComponent = DeleteScheduleComponent;
exports.ShowScheduleComponent = ShowScheduleComponent;
exports.UpdateScheduleComponent = UpdateScheduleComponent;
exports.ShowSlotComponent = ShowSlotComponent;
exports.ShowSlotsComponent = ShowSlotsComponent;
exports.ShowNextAvailabilityComponent = ShowNextAvailabilityComponent;
exports.ShowAllAvailabilityComponent = ShowAllAvailabilityComponent;
exports.metadata = metadata;
exports.ɵa = API_PATH;
exports.ɵb = CustomDateFormatterProvider;
exports.ɵc = CustomEventTitleFormatterProvider;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=deja-vu-schedule.umd.js.map
