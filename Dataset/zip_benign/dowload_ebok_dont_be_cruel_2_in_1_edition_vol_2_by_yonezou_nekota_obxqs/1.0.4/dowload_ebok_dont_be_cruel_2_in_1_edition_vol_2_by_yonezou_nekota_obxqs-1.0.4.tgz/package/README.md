# DOWNLOAD EBOOK Don’t Be Cruel: 2-in-1 Edition, Vol. 2 by Yonezou Nekota PDF EPUB MOBI (y2jae)

### Download Ebook + Don’t Be Cruel: 2-in-1 Edition, Vol. 2 by Yonezou Nekota in pdf - mobi - epub format



➡️ ➡️ <b>CLICK HERE:</b> <a href="http://tinybit.cc/a78309ed">http://tinybit.cc/a78309ed</a> ⬅️ ⬅️

<img src="https://is5-ssl.mzstatic.com/image/thumb/Publication114/v4/93/14/a1/9314a155-ca19-ea62-60da-5ba2159312b2/9781421592404.jpg/600x600bb.jpg" style="width:300px;" />

Maya and Nemugasa are now officially lovers, but it’s the summer of their third year of high school, meaning even more studying for college entrance exams. Their relationship is reduced to stealing kisses at lunch and the occasional sleepover. Stressed out and desperately wanting some alone time, the couple winds up having a massive—even dangerous?—misunderstanding! Things only get worse when the two eventually end up attending separate colleges and can no longer see each other every day. How will Nemugasa handle Maya’s continued popularity with the ladies? And what will Maya do when Nemugasa makes a new friend at college?

Now you can download Don’t Be Cruel: 2-in-1 Edition, Vol. 2 epub by Yonezou Nekota from this link:

👉👉👉 <b>DOWNLOAD EBOOK HERE: <a href="http://tinybit.cc/a78309ed">http://tinybit.cc/a78309ed</a></b>

