# ePub Download The Warlord Wants Forever (Immortals After Dark, #0.5) by Kresley Cole (2owez)

<p>Do you want to <b>download epub The Warlord Wants Forever (Immortals After Dark, #0.5) by Kresley Cole</b>?  On this occasion, we bring you this Kresley Cole's ebook available to download for free: The Warlord Wants Forever (Immortals After Dark, #0.5) epub.

<br>➡️➡️ <b>DOWNLOAD HERE: <a href="https://shrtly.cc/6388558">https://shrtly.cc/6388558</a></b>⬅️ ⬅️
<br>
<br>
<img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1641511935i/6388558.jpg" alt="ebook download The Warlord Wants Forever (Immortals After Dark, #0.5)" style="max-width: 100%;" />
<br>
<br>