mobile-pipe-for-tianma
===============

###How to use

1 - 命令行访问到tianma 0.5.x目录下，执行<br />
<pre>
npm install mobile-pipe-for-tianma
</pre>

2 - 修改tianma config.js，新增pipe配置<br />
<pre>
var tianma = require('tianma');
var pipe = tianma.pipe;

// <b>1. 引入mobile 模块</b>
var mobile = require('mobile-pipe-for-tianma');

tianma({ silent: false, log: false })
	.createHost({ port: 80, portssl: 443, key:"./keys/unicorn.key", cert:"./keys/unicorn.cer"})
		.mount('style.aliunicorn.com', [ // unicorn service
			pipe.combo({ source: 'http://style.alibaba.com/' })
		])
		// <b>2. 新增pipe</b>
		.mount('m.alibaba.com', [
			mobile({
				root: './htdocs'
			})
		])
		.mount('/', [ // static service
			pipe.static({ root: './htdocs' }),
			pipe.proxy({
				'http://110.75.216.150/$1': /(?:(?:style|img)\.(?:alibaba|aliexpress)\.com|aliimg\.com)\/(.*)/
			}),
			pipe.beautify()
		])
		.start();
</pre>

3 - 修改hosts指向<br />
<pre>
127.0.0.1 style.aliunicorn.com m.alibaba.com
</pre>

4 - 启动tianma 0.5.x

5 - 使用chrome/safari访问
<pre>http://m.alibaba.com</pre>

### FAQ

- 介个Pipe是干嘛用的？

  - <a href="http://f2e.aliui.com/?tag=%E6%97%A0%E7%BA%BF" target="_blank">pipe和m.alibaba.com介绍 传送（内部链接）</a>

- 什么是天马？

  - <a href="https://github.com/nqdeng/tianma" target="_blank">tianma 0.5.x 传送门</a>