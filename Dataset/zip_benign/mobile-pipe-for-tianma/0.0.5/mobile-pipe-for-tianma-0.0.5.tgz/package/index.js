/**
 * mobile pipe for tianma
 * @author siemenliu
 */
var tianma = require('tianma');
var util = tianma.util;
var fs = require('node-fs');
var http = require('http');
var path = require('path');
var extend = require('node.extend');

var MOD = {
	DEBUG: 'debug',
	PRODUCT: 'product'
};

var config = {
	root: './htdocs',
	unicornPrefix: 'http://style.aliunicorn.com',
	unicornPrefixJS: '/null|run/pool/mobile/',
	unicornPrefixCSS: '/null|5v/sourcing/mobile/',
	dir: {
		prefixJ: 'js/5v/run/pool/mobile/',
		prefixC: 'css/5v/sourcing/mobile/',
		demoRoot: '/mobile-demo'
	},
	reg: {
		uncachedReg: (/\<(script|style) data\-ls\=\".+?\" id\=\"(J|C)_(.+?)\.(.+?)\"\>[\n\w\W]*?\<\/(script|style)\>/igm),
		uncachedFileNameReg: (/\<(script|style) data\-ls\=\".+?\" id\=\"(J|C)_(.+?)\.(.+?)\"\>/),

		cachedReg: (/<(script)\>fd\.ls\.load\(\"(J|C)\_(.+?)\.(.+?)\"\)\<\/script\>/igm),
		cachedFileNameReg: (/<(script)\>fd\.ls\.load\(\"(J|C)\_(.+?)\.(.+?)\"\)\<\/script\>/)
	},
	// 允许后缀
	// 当url带有如下后缀的就进入pipe流处理，其他后缀忽略
	// 没有后缀的会当作index.html处理
	suffix: ['.html', '.json'],
	// mode param
	//  value -> debug
	//   - 停用缓存机制
	//  value -> product
	//   - 启用缓存
	// ps.建议切换成product模式后把unicorn的pipe也压缩输出，模拟生产环境
	// tianma 0.5.x 独角兽输出压缩代码在combo下面增加一个minify的pipe即可
	// .mount('style.aliunicorn.com', [ // unicorn service
	//		pipe.combo({ source: 'http://style.alibaba.com/' }),
	//		pipe.minify()
	// ])
	mod: MOD.PRODUCT
};

var mobile = tianma.createPipe({
	/**
	 * 初始化 天马启动时调用一次
	 */
	_initialize: function(cfg) {
		console.log('init pipe - mobile');

		config = extend(true, config, cfg);
	},
	/**
	 * 判断是否处理 每次请求到调用一次
	 */
	fit: function() {
		var pathname = this.context.request.pathname;

		console.log('fit:', pathname);

		// 允许 以/结尾 || 带"."检查后缀 || 不带点也不以/结尾 
		return pathname.substr(-1) === '/' || (function(){
			if (pathname.indexOf('.') != -1) {
				for (var p in config.suffix) {
					var s = config.suffix[p];
					if (pathname.indexOf(s) !== -1) {
						return true;
					}
				}
			} else {
				this.context.request.pathname += '/';
				return true;
			}

			return false;
		}.bind(this))();
	},
	/**
	 * 主处理流程
	 */
	main: function(request, response) {
		// ===> 判断本地是否有 有则返回本地html source
		// ===> 没有则抓取远程html source
		// ===> 解析html source中的css/js标签 合成独角兽路径
		// ===> 抓取独角兽内容回填源码中
		var sourceCode = this.fetchSouceCode();
	},

	/**
	 * Finish procesing request.
	 * @params data {string}
	 */
	done: function(data) {
		var context = this.context;

		context.response
			.status(200)
			.head('content-type', 'text/html')
			.clear()
			.write(data);

		this.next();
	},

	/**
	 * 抓取html source
	 * 会处理pathname为/的情况都会加上index.html
	 *
	 * @return {String} source code
	 */
	fetchSouceCode: function() {
		var srcCode = '';

		pathname = config.root + config.dir.demoRoot + this.getPathname();

		if (this.hasLocalPath(pathname)) {
			this.fetchSourceCodeByLocal(pathname, this.handleFetchSourceCode.bind(this));
		} else {
			this.fetchURL('http://205.204.112.22' + this.context.request.path, this.handleFetchSourceCode.bind(this));
		}
	},

	/**
	 * 获得pathname
	 * @return {String}
	 */
	getPathname: function() {
		return this.processPathname(this.context.request.pathname);
	},

	/**
	 * 处理pathname为/的情况
	 * @param pathname {String}
	 */
	processPathname: function(pathname) {
		return pathname.substr(-1) === '/' ? pathname + 'index.html' : pathname;
	},

	/**
	 * 本地路径是否存在
	 * @param pathname {String} 本地路径
	 * @return {Boolean}
	 */
	hasLocalPath: function(pathname) {
		var res = false;

		if (fs.existsSync(pathname)) {
			var stat = fs.statSync(pathname);
			res = stat.isFile();
		}
		
		return res;
	},

	/**
	 * 从本地抓取html source
	 * @param pathname {String}
	 * @return {String}
	 */
	fetchSourceCodeByLocal: function(pathname, handle) {
		console.log('Fetch local file: ' + pathname);
		
		fs.readFile(pathname, 'utf-8', function(err, data) {
			handle(data);
		});
	},

	/**
	 * 从线上环境抓取html source
	 * @param url {String}
	 * @param handle {Function} 抓取成功后回调
	 * @param needCache {Boolean} 是否需要缓存 缓存只针对html
	 * @return {String}
	 */
	fetchURL: function(url, handle) {
		console.log('do request: ', url);
		var oriReq = this.context.request;
		var opts = require('url').parse(url);

		opts.headers = oriReq._headers;
		opts.headers.host = opts.host;
		opts.headers.cookie = opts.headers.cookie.replace(/__unicrv=.+?\;\ /i, '');
		// 删除这个头 因为会让buffer转字符串的时候乱码 具体原因未知
		delete opts.headers['accept-encoding'];

		var req = http.request(opts, function(res) {
			console.log("Got response: " + url + ' | ' + res.statusCode);

			if (res.statusCode === 200) {
				var dList = '';
				res.on('data', function(data) {
					dList += data;
				});
				res.on('end', function() {
					handle(dList);
				}.bind(this));
			} else {
				res.on('end', function(data) {
					var response = this.context.response;
					response.status(res.statusCode)
					response._headers = res.headers;
					
					this.next();
				}.bind(this));
			}

		}.bind(this));

		req.on('error', function(e) {
			console.log("Got error: " + e.message);
		});

		req.setHeader('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3')

		req.end();
	},

	cacheContent: function(content) {
		var pathname = config.root + config.dir.demoRoot + this.getPathname();
		fs.mkdir(path.dirname(pathname), 077, true, function(err) {
			if (err) {
				console.log('Got error: ', e);
			} else {
				console.log('Directory created: ', pathname);

				fs.writeFile(pathname, content, 'utf-8', function(err) {
					if (err) throw err;
					console.log('saved ' + pathname);
				});
			}
		});
		
	},

	getUnicrvMap: function() {
		var cookie = this.context.request._headers.cookie;
		var unicrv = cookie.match(/__unicrv=(.*?)\;\ /i);
		var map = {};

		if (unicrv) {
			var unicrvList = unicrv[1].split('~');
			for (var i = 0, ln = unicrvList.length; i < ln; i++) {
				var u = unicrvList[i];
				var cs = u.match(/(J|C)_(.*?)\.(.*)/);
				map[cs[1] + '_' + cs[2]] = cs[3];
			}
		}

		return map;
	},

	parseTagToItemList: function(list, type) {
		// uncached match ["<style data-ls="done" id="C_searchbar.40cf901cd721_0">", "style", "C", "searchbar", "40cf901cd721_0"]

		var res = [];
		var cookieStampMap = this.getUnicrvMap();

		if (list) {
			for (var i = 0, ln = list.length; i < ln; i++) {
				var rec = list[i].match(config.reg[type + 'FileNameReg']);
				var suffix = rec[2] === 'J' ? '.js' : '.css';
				var localPath = config.root + '/' + config.dir['prefix' + rec[2]] + rec[3] + suffix;
				var mtime = this.getStampFromPath(localPath);
				var url = config.unicornPrefix + config['unicornPrefix' + suffix.substr(1).toUpperCase()] + rec[3] + suffix;

				var item = {
					orignal: list[i], // replace original
					result: '', // replace target
					tag: rec[2] === 'J' ? 'script' : 'style',
					type: rec[2],
					name: rec[3],
					stamp: rec[4],
					suffix: suffix,
					mtime: mtime,
					url: url,
					isNeedFetch: mtime != cookieStampMap[rec[2] + '_' + rec[3]],
					isCached: type === 'cached'
				};

				res.push(item);
			}
		}

		return res;
	},

	getStampFromPath: function(localPath) {
		var stat = fs.statSync(localPath);

		return stat.mtime.getTime();
	},

	updateTagContent: function(content, handle) {
		var uncached = [];
		var cached = [];
		var totalItem = [];
		var needProcess = 0;
		// {
		// 	orignal: '',
		// 	result: '',
		// 	stamp: '',
		// 	name: '',
		// 	tagType: ''
		// }

		uncached = this.parseTagToItemList(content.match(config.reg.uncachedReg), 'uncached');
		cached = this.parseTagToItemList(content.match(config.reg.cachedReg), 'cached');
		totalItem = uncached.concat(cached);
		needProcess = totalItem.length;

		console.log('uncached tag:', uncached.length);
		console.log('cached tag:', cached.length);

		if (totalItem.length > 0) {
			// generate tags and replace content
			for (var i = 0, ln = totalItem.length; i < ln; i++) {
				var item = totalItem[i];

				// 需要fetch 和 在debug 模式中的已cached tag需要释出源码
				if (item.isNeedFetch || (config.mod === MOD.DEBUG && item.isCached)) {
					this.fetchURL(item.url, (function(item){
						return function(data) {
							var newTagBefore = '<' + item.tag + ' data-ls="save" id="' + item.type + '_' + item.name + '.' + item.mtime + '">';
							var newTagAfter = '</' + item.tag + '>';
							var target = newTagBefore + data + newTagAfter;
							content = content.replace(item.orignal, target);

							if (--needProcess === 0) {
								handle(content);
							}
						};
					})(item));
				} else {
					//<script>fd.ls.load('C_mod/btn/btn.cc5d732cc5a5_0')</script>
					var target = '<scr' + 'ipt>fd.ls.load("' + item.type + '_' + item.name + '.' + item.mtime + '")</script>';
					content = content.replace(item.orignal, target);

					if (--needProcess === 0) {
						handle(content);
					}
				}
			}

			if (needProcess.length === 0) {
				handle(content);
			}
		} else {
			handle(content);
		}
	},

	/**
	 * 抓取文件成功回调
	 * @handle
	 * @param content {String} html源代码
	 */
	handleFetchSourceCode: function(content) {
		// 匹配标签请求内容
		this.updateTagContent(content, function(content) {
			// content 存到本地对应目录
			this.cacheContent(content);

			// 返回response
			this.done(content);
		}.bind(this));
	}

});

module.exports = mobile;