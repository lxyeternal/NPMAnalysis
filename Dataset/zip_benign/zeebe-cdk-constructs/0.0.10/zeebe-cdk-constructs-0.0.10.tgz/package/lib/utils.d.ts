export declare class ZeebeCdkUtls {
    createZeebeContactPoints(port: number, namespace: string, brokers: number): string;
}
