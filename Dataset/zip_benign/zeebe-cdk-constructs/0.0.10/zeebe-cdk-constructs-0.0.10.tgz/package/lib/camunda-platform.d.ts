import { Construct } from 'constructs';
import { CamundaPlatformProps } from './camunda-platform-props';
/**
 * A construct pattern to create a Camunda 8 cluster comprising of Zeebe, Operate, Tasklist and Elasticsearch deployed on AWS ECS Fargate with an
 * application loadbalancer allowing http access to Operate and Tasklist.
 *
 */
export declare class CamundaPlatformCoreFargate extends Construct {
    private CAMUNDA_VERSION;
    private ELASTIC_VERSION;
    private ECS_CLUSTER_NAME;
    private alb?;
    private readonly props;
    /**
       * A construct pattern to create a Camunda 8 cluster comprising of Zeebe, Operate, Tasklist and Elasticsearch deployed on AWS ECS Fargate with an
       * application loadbalancer allowing http access to Operate and Tasklist.
       *
       */
    constructor(scope: Construct, id: string, properties: CamundaPlatformProps);
    private initProps;
    private camundaCoreFileSystem;
    private zeebeSecurityGroup;
    private esSecurityGroup;
    private operateSecurityGroup;
    private tasklistSecurityGroup;
    private efsSecurityGroup;
    private createLoadBalancer;
    private getCluster;
    private zeebeService;
    private zeebeTaskDefinition;
    private operateService;
    private operateTaskDefinition;
    private elasticsearchTaskDefinition;
    private elasticSearchService;
    private tasklistService;
    private tasklistTaskDefinition;
}
