import { Construct } from 'constructs';
import { CamundaPlatformProps } from './camunda-platform-props';
/**
 * A construct pattern to create a Camunda 8 cluster comprising of Zeebe, Operate, Tasklist and Elasticsearch deployed on AWS ECS Fargate.
 *
 * The simple version creates all components within a single Fargate task definition and service. This simplifies the networking as each
 * component can refer to other components using localhost/127.0.0.1 (instead of using Cloud Map service discovery) - this approach is also cheaper.
 * The drawback is a lack resilience as all components will be restarted if one container fails or needs to be updated.
 *
 *
 */
export declare class CamundaPlatformCoreSimple extends Construct {
    private CAMUNDA_VERSION;
    private ELASTIC_VERSION;
    private ECS_CLUSTER_NAME;
    private efsSecurity;
    private readonly props;
    private logs;
    /**
       * A construct pattern to create a Camunda 8 cluster comprising of Zeebe, Operate, Tasklist and Elasticsearch deployed on AWS ECS Fargate.
       *
       * The simple version creates all components within a single Fargate task definition and service. This simplifies the networking as each
       * component can refer to other components using localhost/127.0.0.1 (instead of using Cloud Map service discovery) - this approach is also cheaper.
       * The drawback is a lack resilience as all components will be restarted if one container fails or needs to be updated.
       *
       */
    constructor(scope: Construct, id: string, properties: CamundaPlatformProps);
    private initProps;
    private camundaCoreFileSystem;
    private zeebeSecurityGroup;
    private esSecurityGroup;
    private operateSecurityGroup;
    private tasklistSecurityGroup;
    private efsSecurityGroup;
    private getCluster;
    private coreSimpleService;
    private camundaCoreSimpleTaskDefinition;
    private tasklistContainer;
    private operateContainer;
    private elasticSearchContainer;
    private zeebeContainer;
}
