import { Construct } from 'constructs';
import { ZeebeStandaloneProps } from './standalone-props';
/**
 * A construct to create a single standalone Zeebe container (gateway and broker) deployed on AWS Fargate
 */
export declare class ZeebeStandaloneFargateCluster extends Construct {
    private CAMUNDA_VERSION;
    private ECS_CLUSTER_NAME;
    private VOLUME_NAME;
    private props;
    /**
       * A construct to creates a single standalone Zeebe node that is both gateway and broker deployed on AWS Fargate
       */
    constructor(scope: Construct, id: string, zeebeProperties: ZeebeStandaloneProps);
    private initProps;
    private defaultSecurityGroups;
    private createStandaloneBroker;
    private standaloneTaskDefinition;
    private addSimpleMonitorContainer;
    private zeebeImage;
    private createZeebeVolume;
    private getCluster;
}
