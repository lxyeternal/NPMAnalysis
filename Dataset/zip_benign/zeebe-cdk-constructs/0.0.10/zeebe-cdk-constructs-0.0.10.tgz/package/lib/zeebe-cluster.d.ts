import { Construct } from 'constructs';
import { ZeebeClusterProps } from './zeebe-cluster-props';
/**
 * A construct to create a Zeebe cluster on AWS Fargate.
 */
export declare class ZeebeFargateCluster extends Construct {
    private CAMUNDA_VERSION;
    private defaultNumberOfBrokers;
    private ECS_CLUSTER_NAME;
    private readonly props;
    private accessPointIds;
    /**
       * A construct to create a Zeebe cluster on AWS Fargate
       *
       * @param scope CDK scope
       * @param id CDK id
       * @param zeebeProperties Zeebe cluster properties
       */
    constructor(scope: Construct, id: string, zeebeProperties: ZeebeClusterProps);
    private initProps;
    private defaultZeebeEfs;
    private defaultSecurityGroups;
    private createGateway;
    private createBroker;
    private gatewayTaskDefinition;
    private getCluster;
    private brokerTaskDefinition;
}
