export default api;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
export type JsonArray = JsonValue[];
export type JsonPrimitive = string | number | boolean | null;
export type JsonObject = {
    [x: string]: JsonValue | undefined;
};
/** @type {{ 'json-encode($data, $quotes: true)': typeof encode, 'json-decode($string)': typeof decode }} */
declare const api: {
    'json-encode($data, $quotes: true)': typeof encode;
    'json-decode($string)': typeof decode;
};
/**
 * @typedef {JsonPrimitive | JsonObject | JsonArray} JsonValue
 * @typedef {JsonValue[]} JsonArray
 * @typedef {string | number | boolean | null} JsonPrimitive
 * @typedef {{[Key in string]?: JsonValue}} JsonObject
 */
/**
 * Encodes (`JSON.stringify`) data and returns Sass string. By default, string is quoted with single quotes so that it can be easily used in standard CSS values.
 *
 * First argument:  `sass.Value` - Data to encode (stringify).
 *
 * Second argument: `sass.SassBoolean` - Should output string be quoted with single quotes.
 *
 * @param {sass.Value[]} encodeArguments
 */
declare function encode(encodeArguments: sass.Value[]): sass.SassString;
/**
 * Decodes (`JSON.parse`) string and returns one of available Sass types.
 *
 * First argument: `sass.SassString` - String to decode (parse).
 *
 * @param {sass.Value[]} decodeArguments
 */
declare function decode(decodeArguments: sass.Value[]): sass.Value;
import * as sass from "sass";
//# sourceMappingURL=index.d.ts.map