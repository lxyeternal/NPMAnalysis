export default setJsonValueToSassValue;
export type CalculationContainer = {
    operator: sass.CalculationOperator | null;
    left: sass.CalculationValue | null;
    right: sass.CalculationValue | null;
};
export type JsonValue = import('../index').JsonValue;
export type JsonObject = import('../index').JsonObject;
export type JsonArray = import('../index').JsonArray;
/**
 * @param {JsonValue} value
 */
declare function setJsonValueToSassValue(value: JsonValue): sass.Value;
import * as sass from "sass";
//# sourceMappingURL=json-to-sass.d.ts.map