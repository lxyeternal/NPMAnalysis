export default getJsonValueFromSassValue;
export type JsonValue = import('../index').JsonValue;
export type JsonObject = import('../index').JsonObject;
export type JsonArray = import('../index').JsonArray;
/**
 * @typedef {import('../index').JsonValue} JsonValue
 * @typedef {import('../index').JsonObject} JsonObject
 * @typedef {import('../index').JsonArray} JsonArray
 */
/**
 * @param {sass.Value|undefined} value
 */
declare function getJsonValueFromSassValue(value: sass.Value | undefined): string | number | boolean | import("../index").JsonObject | import("../index").JsonArray | null;
import * as sass from "sass";
//# sourceMappingURL=sass-to-json.d.ts.map