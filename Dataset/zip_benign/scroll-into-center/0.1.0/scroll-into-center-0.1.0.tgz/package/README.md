# scroll-into-center

This script provides a polyfill to support unstandardised `Element.scrollIntoCenter()`, similar to the standard [`scrollIntoView`][1]. The functionality has been [suggested before][2] as a possible addition to `scrollIntoView`, which always aligns the element with the top of the view.

## Usage

Simply include the script, and every DOM element will have the method `scrollIntoCenter({options})`.

option fields:
- vertical: scalar between 0 and 1. Default = 0.5. The value 0 aligns the
    top of the element with the top of the view, 1 aligns the bottom with the
    bottom, and 0.5 (default) puts the center in the center.

- horizontal: scalar between 0 and 1. Default = 0.5. Functions like vertical.

[1]: https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
[2]: https://www.w3.org/Bugs/Public/show_bug.cgi?id=17152
