/* Polyfill to support unstandardised Element.scrollIntoCenter()
 *
 * Usage: scrollIntoCenter({options});
 * option fields:
 * - vertical: scalar between 0 and 1. Default = 0.5. The value 0 aligns the
 *   top of the element with the top of the view, 1 aligns the bottom with the
 *   bottom, and 0.5 (default) puts the center in the center.
 * - horizontal: scalar between 0 and 1. Default = 0.5. Functions like vertical.
 *
 */


(function () {

// Return if already supported.
if (Element.prototype.scrollIntoCenter !== undefined)  return;

function scrollIntoCenter(options) {

  var window = this.ownerDocument.defaultView;

  // Read options.
  if (options === undefined)  options = {};
  if (options.vertical === undefined)  options.vertical = 0.5;
  if (options.horizontal === undefined)  options.horizontal = 0.5;

  // Fetch positional information.
  var rect = this.getBoundingClientRect();

  // Determine location to scroll to.
  var targetY = window.scrollY + rect.top - (window.innerHeight - this.offsetHeight) * options.vertical;
  var targetX = window.scrollX + rect.left - (window.innerWidth - this.offsetWidth) * options.horizontal;

  // Scroll.
  window.scroll(targetX, targetY);

  // If window is inside a frame, center that frame in the parent window. Recursively.
  if (window.parent !== window) {
    // We are inside a scrollable element.
    var frame = window.frameElement;
    scrollIntoCenter.call(frame, options);
  }
}

// Hook the polyfill.
Element.prototype.scrollIntoCenter = scrollIntoCenter;

})();
