function asserteq (a, b, test) {
  var bool = a === b,
      box = document.createElement('div');
  box.textContent = test;

  if (!bool)  console.error('Assertion error', test || '',
                            a, 'is not', b);
  if (test) {
    if (!bool)  box.className = 'fail';
    else  box.className = 'success';
  }
  document.getElementById('results').appendChild(box);
}


(function () {

  var id = document.getElementById.bind(document),
      some = id('some');

  some.style.top = innerHeight + 'px';
  some.style.left = innerWidth + 'px';
  // The tests start with a black 2x2 pixels square below bottom right.
  // Do not resize the window during the tests.
  // In comments on the right, I am talking about that square box.

  scroll(innerWidth / 2, innerHeight + 2);  // Just above the viewport.
  some._scrollIntoView({});
  asserteq(scrollY, Math.floor(innerHeight / 2) + 1,
           'Test 1: element hidden above.');

  scroll(innerWidth / 2, innerHeight + 2);  // Just above the viewport.
  some._scrollIntoView({vertical:0});
  asserteq(scrollY, innerHeight,
           'Test 2: element hidden above, vertical=0.');

  scroll(innerWidth / 2, innerHeight + 2);  // Just above the viewport.
  some._scrollIntoView({vertical:1});
  asserteq(scrollY, 2,
           'Test 3: element hidden above, vertical=1.');

  scroll(innerWidth / 2, innerHeight + 2);  // Just above the viewport.
  some._scrollIntoView({horizontal:0});
  asserteq(scrollX, innerWidth,
           'Test 4: element hidden above, horizontal=0.');

  scroll(innerWidth / 2, innerHeight + 2);  // Just above the viewport.
  some._scrollIntoView({horizontal:1});
  asserteq(scrollX, 2,
           'Test 5: element hidden above, horizontal=1.');

  scroll(innerWidth / 2, innerHeight + 1);  // Just along the viewport.
  some._scrollIntoView({});
  asserteq(scrollY, innerHeight,
           'Test 6: element partially visible above.');

  scroll(innerWidth / 2, innerHeight - 1);  // In the viewport.
  some._scrollIntoView({vertical:0});
  asserteq(scrollY, innerHeight - 1,
           'Test 7: element visible above.');

  scroll(innerWidth / 2, innerHeight - 1);  // In the viewport.
  some._scrollIntoView({evenIfViewed:true, vertical:0});
  asserteq(scrollY, innerHeight,
           'Test 8: element visible above, evenIfViewed=true.');

  // Huge, window-sized box.
  some.style.width = innerWidth + 'px';
  some.style.height = innerHeight + 'px';
  // Viewport is at the bottom right of the box.
  scroll(2 * innerWidth, 2 * innerHeight);
  some._scrollIntoView({});
  asserteq(scrollX, innerWidth,
           'Test 9: element bigger than viewport (x)');
  asserteq(scrollY, innerHeight,
           'Test 10: element bigger than viewport (y)');

  // Iframe tests.

  some.style.height = '0px';
  scroll(0, 0);

  var frame = id('frame'),
      fwindow = frame.contentWindow;

  frame.style.top = window.innerHeight + 'px';
  frame.style.left = window.innerWidth + 'px';

  fwindow.addEventListener('load', function frameLoad() {
    var some = fwindow.document.getElementById('some');
    some._scrollIntoView({});
    asserteq(window.scrollX, Math.floor(window.innerWidth / 2) + 20,
             'Test 11: scrolling from an iframe (x)');
    asserteq(window.scrollY, Math.floor(window.innerHeight / 2) + 20,
             'Test 12: scrolling from an iframe (y)');
    asserteq(fwindow.scrollX, Math.floor(fwindow.innerWidth / 2) + 1,
             'Test 13: scrolling inside an iframe (x)');
    asserteq(fwindow.scrollY, Math.floor(fwindow.innerHeight / 2) + 1,
             'Test 14: scrolling inside an iframe (y)');

    scroll(0, 0);
  }, false);


}());
