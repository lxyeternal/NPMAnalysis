export * from './lib/ngx-ripple.component';
