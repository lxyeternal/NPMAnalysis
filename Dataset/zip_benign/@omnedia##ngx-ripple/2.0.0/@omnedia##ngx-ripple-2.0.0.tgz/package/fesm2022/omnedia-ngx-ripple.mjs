import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Input } from '@angular/core';

class NgxRippleComponent {
    constructor() {
        this.style = {};
    }
    set rippleColor(color) {
        this.style["--om-ripple-color"] = color;
    }
    set rippleBorderColor(color) {
        this.style["--om-ripple-border-color"] = color;
    }
    set animationDuration(duration) {
        this.style["--om-ripple-animation-duration"] = duration;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.3", ngImport: i0, type: NgxRippleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.0.3", type: NgxRippleComponent, isStandalone: true, selector: "om-ripple", inputs: { styleClass: "styleClass", rippleColor: "rippleColor", rippleBorderColor: "rippleBorderColor", animationDuration: "animationDuration" }, ngImport: i0, template: "<div class=\"om-ripple\" [ngStyle]=\"style\" [ngClass]=\"styleClass\">\n    <div class=\"om-ripple-background\">\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n    </div>\n    <ng-content></ng-content>\n</div>", styles: [".om-ripple{--om-ripple-border-color: rgba(0, 0, 0, .7);--om-ripple-color: rgba(0, 0, 0, .85);--om-ripple-animation-duration: 2s;height:100%;width:100%;position:relative;overflow:hidden}.om-ripple .om-ripple-background{height:100%;width:100%;position:absolute;-webkit-mask-image:linear-gradient(180deg,#fff,transparent);mask-image:linear-gradient(180deg,#fff,transparent)}.om-ripple .om-ripple-background div{position:absolute;top:50%;left:50%;border-style:solid;border-width:1px;transform:translate(-50%,-50%) scale(1);background-color:var(--om-ripple-color);border-radius:100%;border:2px solid var(--om-ripple-border-color);animation-name:om-ripple;animation-duration:var(--om-ripple-animation-duration);animation-timing-function:ease;animation-iteration-count:infinite}.om-ripple-background>div:nth-child(1){width:210px;height:210px;opacity:.24;animation-delay:0s}.om-ripple-background>div:nth-child(2){width:280px;height:280px;opacity:.21;animation-delay:.06s}.om-ripple-background>div:nth-child(3){width:350px;height:350px;opacity:.18;animation-delay:.12s}.om-ripple-background>div:nth-child(4){width:420px;height:420px;opacity:.15;animation-delay:.18s}.om-ripple-background>div:nth-child(5){width:490px;height:490px;opacity:.12;animation-delay:.24s}.om-ripple-background>div:nth-child(6){width:560px;height:560px;opacity:.09;animation-delay:.3s}.om-ripple-background>div:nth-child(7){width:630px;height:630px;opacity:.06;animation-delay:.36s}.om-ripple-background>div:nth-child(8){width:700px;height:700px;opacity:.03;animation-delay:.42s}@keyframes om-ripple{0%,to{transform:translate(-50%,-50%) scale(1)}50%{transform:translate(-50%,-50%) scale(.9)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.3", ngImport: i0, type: NgxRippleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'om-ripple', standalone: true, imports: [CommonModule], template: "<div class=\"om-ripple\" [ngStyle]=\"style\" [ngClass]=\"styleClass\">\n    <div class=\"om-ripple-background\">\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n        <div>\n        </div>\n    </div>\n    <ng-content></ng-content>\n</div>", styles: [".om-ripple{--om-ripple-border-color: rgba(0, 0, 0, .7);--om-ripple-color: rgba(0, 0, 0, .85);--om-ripple-animation-duration: 2s;height:100%;width:100%;position:relative;overflow:hidden}.om-ripple .om-ripple-background{height:100%;width:100%;position:absolute;-webkit-mask-image:linear-gradient(180deg,#fff,transparent);mask-image:linear-gradient(180deg,#fff,transparent)}.om-ripple .om-ripple-background div{position:absolute;top:50%;left:50%;border-style:solid;border-width:1px;transform:translate(-50%,-50%) scale(1);background-color:var(--om-ripple-color);border-radius:100%;border:2px solid var(--om-ripple-border-color);animation-name:om-ripple;animation-duration:var(--om-ripple-animation-duration);animation-timing-function:ease;animation-iteration-count:infinite}.om-ripple-background>div:nth-child(1){width:210px;height:210px;opacity:.24;animation-delay:0s}.om-ripple-background>div:nth-child(2){width:280px;height:280px;opacity:.21;animation-delay:.06s}.om-ripple-background>div:nth-child(3){width:350px;height:350px;opacity:.18;animation-delay:.12s}.om-ripple-background>div:nth-child(4){width:420px;height:420px;opacity:.15;animation-delay:.18s}.om-ripple-background>div:nth-child(5){width:490px;height:490px;opacity:.12;animation-delay:.24s}.om-ripple-background>div:nth-child(6){width:560px;height:560px;opacity:.09;animation-delay:.3s}.om-ripple-background>div:nth-child(7){width:630px;height:630px;opacity:.06;animation-delay:.36s}.om-ripple-background>div:nth-child(8){width:700px;height:700px;opacity:.03;animation-delay:.42s}@keyframes om-ripple{0%,to{transform:translate(-50%,-50%) scale(1)}50%{transform:translate(-50%,-50%) scale(.9)}}\n"] }]
        }], propDecorators: { styleClass: [{
                type: Input,
                args: ["styleClass"]
            }], rippleColor: [{
                type: Input,
                args: ["rippleColor"]
            }], rippleBorderColor: [{
                type: Input,
                args: ["rippleBorderColor"]
            }], animationDuration: [{
                type: Input,
                args: ["animationDuration"]
            }] } });

/*
 * Public API Surface of ngx-ripple
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxRippleComponent };
//# sourceMappingURL=omnedia-ngx-ripple.mjs.map
