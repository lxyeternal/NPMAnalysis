import * as i0 from "@angular/core";
export declare class NgxRippleComponent {
    styleClass?: string;
    set rippleColor(color: string);
    set rippleBorderColor(color: string);
    set animationDuration(duration: string);
    style: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxRippleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxRippleComponent, "om-ripple", never, { "styleClass": { "alias": "styleClass"; "required": false; }; "rippleColor": { "alias": "rippleColor"; "required": false; }; "rippleBorderColor": { "alias": "rippleBorderColor"; "required": false; }; "animationDuration": { "alias": "animationDuration"; "required": false; }; }, {}, never, ["*"], true, never>;
}
