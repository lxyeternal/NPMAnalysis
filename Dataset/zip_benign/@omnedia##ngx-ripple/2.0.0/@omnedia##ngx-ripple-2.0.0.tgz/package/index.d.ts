/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@omnedia/ngx-ripple" />
export * from './public-api';
