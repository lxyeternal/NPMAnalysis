import App from "./src/index.vue";
import _Vue from "vue";

App.install = Vue => {
  if (!Vue) {
    window.Vue = Vue = _Vue;
  }
  Vue.component(App.name, App);
};
export default App;
