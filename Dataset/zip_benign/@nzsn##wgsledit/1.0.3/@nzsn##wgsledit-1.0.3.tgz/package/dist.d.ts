declare module "Parser/WGSLVisitor" {
    import { ParseTreeVisitor } from 'antlr4';
    import { Template_args_startContext } from "Parser/WGSLParser";
    import { Template_args_endContext } from "Parser/WGSLParser";
    import { Additive_operatorContext } from "Parser/WGSLParser";
    import { Multiplicative_operatorContext } from "Parser/WGSLParser";
    import { Argument_expression_listContext } from "Parser/WGSLParser";
    import { Assignment_statementContext } from "Parser/WGSLParser";
    import { Shift_expression_post_unary_expressionContext } from "Parser/WGSLParser";
    import { AttributeContext } from "Parser/WGSLParser";
    import { Bitwise_expression_post_unary_expressionContext } from "Parser/WGSLParser";
    import { Case_selectorContext } from "Parser/WGSLParser";
    import { Component_or_swizzle_specifierContext } from "Parser/WGSLParser";
    import { Compound_statementContext } from "Parser/WGSLParser";
    import { Core_lhs_expressionContext } from "Parser/WGSLParser";
    import { Diagnostic_controlContext } from "Parser/WGSLParser";
    import { Diagnostic_rule_nameContext } from "Parser/WGSLParser";
    import { ExpressionContext } from "Parser/WGSLParser";
    import { Float_literalContext } from "Parser/WGSLParser";
    import { For_initContext } from "Parser/WGSLParser";
    import { For_updateContext } from "Parser/WGSLParser";
    import { Import_statementContext } from "Parser/WGSLParser";
    import { PreambleContext } from "Parser/WGSLParser";
    import { Global_declContext } from "Parser/WGSLParser";
    import { Global_directiveContext } from "Parser/WGSLParser";
    import { Global_value_declContext } from "Parser/WGSLParser";
    import { IdentContext } from "Parser/WGSLParser";
    import { Int_literalContext } from "Parser/WGSLParser";
    import { Lhs_expressionContext } from "Parser/WGSLParser";
    import { LiteralContext } from "Parser/WGSLParser";
    import { Member_identContext } from "Parser/WGSLParser";
    import { Optionally_typed_identContext } from "Parser/WGSLParser";
    import { ParamContext } from "Parser/WGSLParser";
    import { Primary_expressionContext } from "Parser/WGSLParser";
    import { Greater_thanContext } from "Parser/WGSLParser";
    import { Less_thanContext } from "Parser/WGSLParser";
    import { Relational_expression_post_unary_expressionContext } from "Parser/WGSLParser";
    import { StatementContext } from "Parser/WGSLParser";
    import { Switch_clauseContext } from "Parser/WGSLParser";
    import { Template_arg_expressionContext } from "Parser/WGSLParser";
    import { Template_elaborated_ident_post_identContext } from "Parser/WGSLParser";
    import { Translation_unitContext } from "Parser/WGSLParser";
    import { Type_specifierContext } from "Parser/WGSLParser";
    import { Unary_expressionContext } from "Parser/WGSLParser";
    import { Variable_declContext } from "Parser/WGSLParser";
    import { Variable_or_value_statementContext } from "Parser/WGSLParser";
    import { Variable_updating_statementContext } from "Parser/WGSLParser";
    /**
     * This interface defines a complete generic visitor for a parse tree produced
     * by `WGSLParser`.
     *
     * @param <Result> The return type of the visit operation. Use `void` for
     * operations with no return type.
     */
    export default class WGSLVisitor<Result> extends ParseTreeVisitor<Result> {
        /**
         * Visit a parse tree produced by `WGSLParser.template_args_start`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitTemplate_args_start?: (ctx: Template_args_startContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.template_args_end`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitTemplate_args_end?: (ctx: Template_args_endContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.additive_operator`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitAdditive_operator?: (ctx: Additive_operatorContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.multiplicative_operator`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitMultiplicative_operator?: (ctx: Multiplicative_operatorContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.argument_expression_list`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitArgument_expression_list?: (ctx: Argument_expression_listContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.assignment_statement`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitAssignment_statement?: (ctx: Assignment_statementContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.shift_expression_post_unary_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitShift_expression_post_unary_expression?: (ctx: Shift_expression_post_unary_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.attribute`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitAttribute?: (ctx: AttributeContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.bitwise_expression_post_unary_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitBitwise_expression_post_unary_expression?: (ctx: Bitwise_expression_post_unary_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.case_selector`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitCase_selector?: (ctx: Case_selectorContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.component_or_swizzle_specifier`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitComponent_or_swizzle_specifier?: (ctx: Component_or_swizzle_specifierContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.compound_statement`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitCompound_statement?: (ctx: Compound_statementContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.core_lhs_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitCore_lhs_expression?: (ctx: Core_lhs_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.diagnostic_control`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitDiagnostic_control?: (ctx: Diagnostic_controlContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.diagnostic_rule_name`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitDiagnostic_rule_name?: (ctx: Diagnostic_rule_nameContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitExpression?: (ctx: ExpressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.float_literal`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitFloat_literal?: (ctx: Float_literalContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.for_init`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitFor_init?: (ctx: For_initContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.for_update`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitFor_update?: (ctx: For_updateContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.import_statement`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitImport_statement?: (ctx: Import_statementContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.preamble`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitPreamble?: (ctx: PreambleContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.global_decl`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitGlobal_decl?: (ctx: Global_declContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.global_directive`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitGlobal_directive?: (ctx: Global_directiveContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.global_value_decl`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitGlobal_value_decl?: (ctx: Global_value_declContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.ident`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitIdent?: (ctx: IdentContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.int_literal`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitInt_literal?: (ctx: Int_literalContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.lhs_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitLhs_expression?: (ctx: Lhs_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.literal`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitLiteral?: (ctx: LiteralContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.member_ident`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitMember_ident?: (ctx: Member_identContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.optionally_typed_ident`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitOptionally_typed_ident?: (ctx: Optionally_typed_identContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.param`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitParam?: (ctx: ParamContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.primary_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitPrimary_expression?: (ctx: Primary_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.greater_than`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitGreater_than?: (ctx: Greater_thanContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.less_than`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitLess_than?: (ctx: Less_thanContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.relational_expression_post_unary_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitRelational_expression_post_unary_expression?: (ctx: Relational_expression_post_unary_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.statement`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitStatement?: (ctx: StatementContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.switch_clause`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitSwitch_clause?: (ctx: Switch_clauseContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.template_arg_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitTemplate_arg_expression?: (ctx: Template_arg_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.template_elaborated_ident_post_ident`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitTemplate_elaborated_ident_post_ident?: (ctx: Template_elaborated_ident_post_identContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.translation_unit`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitTranslation_unit?: (ctx: Translation_unitContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.type_specifier`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitType_specifier?: (ctx: Type_specifierContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.unary_expression`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitUnary_expression?: (ctx: Unary_expressionContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.variable_decl`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitVariable_decl?: (ctx: Variable_declContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.variable_or_value_statement`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitVariable_or_value_statement?: (ctx: Variable_or_value_statementContext) => Result;
        /**
         * Visit a parse tree produced by `WGSLParser.variable_updating_statement`.
         * @param ctx the parse tree
         * @return the visitor result
         */
        visitVariable_updating_statement?: (ctx: Variable_updating_statementContext) => Result;
    }
}
declare module "Parser/WGSLParser" {
    import { ATN, DFA, FailedPredicateException, Parser, ParserRuleContext, TerminalNode, TokenStream } from 'antlr4';
    import WGSLListener from "Parser/WGSLListener";
    import WGSLVisitor from "Parser/WGSLVisitor";
    export default class WGSLParser extends Parser {
        static readonly T__0 = 1;
        static readonly T__1 = 2;
        static readonly T__2 = 3;
        static readonly T__3 = 4;
        static readonly T__4 = 5;
        static readonly T__5 = 6;
        static readonly T__6 = 7;
        static readonly T__7 = 8;
        static readonly T__8 = 9;
        static readonly T__9 = 10;
        static readonly T__10 = 11;
        static readonly T__11 = 12;
        static readonly T__12 = 13;
        static readonly T__13 = 14;
        static readonly T__14 = 15;
        static readonly T__15 = 16;
        static readonly T__16 = 17;
        static readonly T__17 = 18;
        static readonly T__18 = 19;
        static readonly T__19 = 20;
        static readonly T__20 = 21;
        static readonly T__21 = 22;
        static readonly T__22 = 23;
        static readonly T__23 = 24;
        static readonly T__24 = 25;
        static readonly T__25 = 26;
        static readonly T__26 = 27;
        static readonly T__27 = 28;
        static readonly T__28 = 29;
        static readonly T__29 = 30;
        static readonly T__30 = 31;
        static readonly T__31 = 32;
        static readonly T__32 = 33;
        static readonly T__33 = 34;
        static readonly T__34 = 35;
        static readonly T__35 = 36;
        static readonly T__36 = 37;
        static readonly T__37 = 38;
        static readonly T__38 = 39;
        static readonly T__39 = 40;
        static readonly T__40 = 41;
        static readonly T__41 = 42;
        static readonly T__42 = 43;
        static readonly T__43 = 44;
        static readonly T__44 = 45;
        static readonly T__45 = 46;
        static readonly T__46 = 47;
        static readonly T__47 = 48;
        static readonly T__48 = 49;
        static readonly T__49 = 50;
        static readonly T__50 = 51;
        static readonly T__51 = 52;
        static readonly T__52 = 53;
        static readonly T__53 = 54;
        static readonly T__54 = 55;
        static readonly T__55 = 56;
        static readonly T__56 = 57;
        static readonly T__57 = 58;
        static readonly T__58 = 59;
        static readonly T__59 = 60;
        static readonly T__60 = 61;
        static readonly T__61 = 62;
        static readonly WS = 63;
        static readonly Positive = 64;
        static readonly Minus = 65;
        static readonly Star = 66;
        static readonly Dash = 67;
        static readonly MOD = 68;
        static readonly Left_angle = 69;
        static readonly Right_angle = 70;
        static readonly Sigma_term = 71;
        static readonly Ident_pattern_token = 72;
        static readonly Bool_literal = 73;
        static readonly Compound_assignment_operator = 74;
        static readonly Decimal_float_literal = 75;
        static readonly Decimal_int_literal = 76;
        static readonly Path = 77;
        static readonly Hex_float_literal = 78;
        static readonly Hex_int_literal = 79;
        static readonly Greater_than_equal = 80;
        static readonly Less_than_equal = 81;
        static readonly Shift_left = 82;
        static readonly Shift_right = 83;
        static readonly Break_statement = 84;
        static readonly Continue_statement = 85;
        static readonly Severity_control_name = 86;
        static readonly Swizzle_name = 87;
        static readonly EOF: number;
        static readonly RULE_template_args_start = 0;
        static readonly RULE_template_args_end = 1;
        static readonly RULE_additive_operator = 2;
        static readonly RULE_multiplicative_operator = 3;
        static readonly RULE_argument_expression_list = 4;
        static readonly RULE_assignment_statement = 5;
        static readonly RULE_shift_expression_post_unary_expression = 6;
        static readonly RULE_attribute = 7;
        static readonly RULE_bitwise_expression_post_unary_expression = 8;
        static readonly RULE_case_selector = 9;
        static readonly RULE_component_or_swizzle_specifier = 10;
        static readonly RULE_compound_statement = 11;
        static readonly RULE_core_lhs_expression = 12;
        static readonly RULE_diagnostic_control = 13;
        static readonly RULE_diagnostic_rule_name = 14;
        static readonly RULE_expression = 15;
        static readonly RULE_float_literal = 16;
        static readonly RULE_for_init = 17;
        static readonly RULE_for_update = 18;
        static readonly RULE_import_statement = 19;
        static readonly RULE_preamble = 20;
        static readonly RULE_global_decl = 21;
        static readonly RULE_global_directive = 22;
        static readonly RULE_global_value_decl = 23;
        static readonly RULE_ident = 24;
        static readonly RULE_int_literal = 25;
        static readonly RULE_lhs_expression = 26;
        static readonly RULE_literal = 27;
        static readonly RULE_member_ident = 28;
        static readonly RULE_optionally_typed_ident = 29;
        static readonly RULE_param = 30;
        static readonly RULE_primary_expression = 31;
        static readonly RULE_greater_than = 32;
        static readonly RULE_less_than = 33;
        static readonly RULE_relational_expression_post_unary_expression = 34;
        static readonly RULE_statement = 35;
        static readonly RULE_switch_clause = 36;
        static readonly RULE_template_arg_expression = 37;
        static readonly RULE_template_elaborated_ident_post_ident = 38;
        static readonly RULE_translation_unit = 39;
        static readonly RULE_type_specifier = 40;
        static readonly RULE_unary_expression = 41;
        static readonly RULE_variable_decl = 42;
        static readonly RULE_variable_or_value_statement = 43;
        static readonly RULE_variable_updating_statement = 44;
        static readonly literalNames: (string | null)[];
        static readonly symbolicNames: (string | null)[];
        static readonly ruleNames: string[];
        get grammarFileName(): string;
        get literalNames(): (string | null)[];
        get symbolicNames(): (string | null)[];
        get ruleNames(): string[];
        get serializedATN(): number[];
        protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException;
        constructor(input: TokenStream);
        template_args_start(): Template_args_startContext;
        template_args_end(): Template_args_endContext;
        additive_operator(): Additive_operatorContext;
        multiplicative_operator(): Multiplicative_operatorContext;
        argument_expression_list(): Argument_expression_listContext;
        assignment_statement(): Assignment_statementContext;
        shift_expression_post_unary_expression(): Shift_expression_post_unary_expressionContext;
        attribute(): AttributeContext;
        bitwise_expression_post_unary_expression(): Bitwise_expression_post_unary_expressionContext;
        case_selector(): Case_selectorContext;
        component_or_swizzle_specifier(): Component_or_swizzle_specifierContext;
        compound_statement(): Compound_statementContext;
        core_lhs_expression(): Core_lhs_expressionContext;
        diagnostic_control(): Diagnostic_controlContext;
        diagnostic_rule_name(): Diagnostic_rule_nameContext;
        expression(): ExpressionContext;
        float_literal(): Float_literalContext;
        for_init(): For_initContext;
        for_update(): For_updateContext;
        import_statement(): Import_statementContext;
        preamble(): PreambleContext;
        global_decl(): Global_declContext;
        global_directive(): Global_directiveContext;
        global_value_decl(): Global_value_declContext;
        ident(): IdentContext;
        int_literal(): Int_literalContext;
        lhs_expression(): Lhs_expressionContext;
        literal(): LiteralContext;
        member_ident(): Member_identContext;
        optionally_typed_ident(): Optionally_typed_identContext;
        param(): ParamContext;
        primary_expression(): Primary_expressionContext;
        greater_than(): Greater_thanContext;
        less_than(): Less_thanContext;
        relational_expression_post_unary_expression(): Relational_expression_post_unary_expressionContext;
        statement(): StatementContext;
        switch_clause(): Switch_clauseContext;
        template_arg_expression(): Template_arg_expressionContext;
        template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext;
        translation_unit(): Translation_unitContext;
        type_specifier(): Type_specifierContext;
        unary_expression(): Unary_expressionContext;
        variable_decl(): Variable_declContext;
        variable_or_value_statement(): Variable_or_value_statementContext;
        variable_updating_statement(): Variable_updating_statementContext;
        static readonly _serializedATN: number[];
        private static __ATN;
        static get _ATN(): ATN;
        static DecisionsToDFA: DFA[];
    }
    export class Template_args_startContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Left_angle(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Template_args_endContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Right_angle(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Additive_operatorContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Minus(): TerminalNode;
        Positive(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Multiplicative_operatorContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Star(): TerminalNode;
        Dash(): TerminalNode;
        MOD(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Argument_expression_listContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Assignment_statementContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Compound_assignment_operator(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Shift_expression_post_unary_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        multiplicative_operator_list(): Multiplicative_operatorContext[];
        multiplicative_operator(i: number): Multiplicative_operatorContext;
        unary_expression_list(): Unary_expressionContext[];
        unary_expression(i: number): Unary_expressionContext;
        additive_operator_list(): Additive_operatorContext[];
        additive_operator(i: number): Additive_operatorContext;
        Shift_left(): TerminalNode;
        Shift_right(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class AttributeContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        diagnostic_control(): Diagnostic_controlContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Bitwise_expression_post_unary_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        unary_expression_list(): Unary_expressionContext[];
        unary_expression(i: number): Unary_expressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Case_selectorContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        expression(): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Component_or_swizzle_specifierContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        member_ident(): Member_identContext;
        component_or_swizzle_specifier(): Component_or_swizzle_specifierContext;
        Swizzle_name(): TerminalNode;
        expression(): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Compound_statementContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        attribute_list(): AttributeContext[];
        attribute(i: number): AttributeContext;
        statement_list(): StatementContext[];
        statement(i: number): StatementContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Core_lhs_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        lhs_expression(): Lhs_expressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Diagnostic_controlContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Severity_control_name(): TerminalNode;
        diagnostic_rule_name(): Diagnostic_rule_nameContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Diagnostic_rule_nameContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Ident_pattern_token_list(): TerminalNode[];
        Ident_pattern_token(i: number): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class ExpressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        unary_expression_list(): Unary_expressionContext[];
        unary_expression(i: number): Unary_expressionContext;
        bitwise_expression_post_unary_expression(): Bitwise_expression_post_unary_expressionContext;
        relational_expression_post_unary_expression_list(): Relational_expression_post_unary_expressionContext[];
        relational_expression_post_unary_expression(i: number): Relational_expression_post_unary_expressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Float_literalContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Decimal_float_literal(): TerminalNode;
        Hex_float_literal(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class For_initContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext;
        argument_expression_list(): Argument_expression_listContext;
        variable_or_value_statement(): Variable_or_value_statementContext;
        variable_updating_statement(): Variable_updating_statementContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class For_updateContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext;
        argument_expression_list(): Argument_expression_listContext;
        variable_updating_statement(): Variable_updating_statementContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Import_statementContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Path(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class PreambleContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        import_statement(): Import_statementContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Global_declContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident_list(): IdentContext[];
        ident(i: number): IdentContext;
        attribute_list(): AttributeContext[];
        attribute(i: number): AttributeContext;
        type_specifier_list(): Type_specifierContext[];
        type_specifier(i: number): Type_specifierContext;
        template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext;
        statement_list(): StatementContext[];
        statement(i: number): StatementContext;
        param_list(): ParamContext[];
        param(i: number): ParamContext;
        optionally_typed_ident(): Optionally_typed_identContext;
        template_args_start(): Template_args_startContext;
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        template_args_end(): Template_args_endContext;
        global_value_decl(): Global_value_declContext;
        member_ident_list(): Member_identContext[];
        member_ident(i: number): Member_identContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Global_directiveContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Severity_control_name(): TerminalNode;
        diagnostic_rule_name(): Diagnostic_rule_nameContext;
        Ident_pattern_token_list(): TerminalNode[];
        Ident_pattern_token(i: number): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Global_value_declContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        optionally_typed_ident(): Optionally_typed_identContext;
        attribute_list(): AttributeContext[];
        attribute(i: number): AttributeContext;
        expression(): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class IdentContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Ident_pattern_token(): TerminalNode;
        Sigma_term(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Int_literalContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Decimal_int_literal(): TerminalNode;
        Hex_int_literal(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Lhs_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        core_lhs_expression(): Core_lhs_expressionContext;
        component_or_swizzle_specifier(): Component_or_swizzle_specifierContext;
        lhs_expression(): Lhs_expressionContext;
        Star(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class LiteralContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Bool_literal(): TerminalNode;
        float_literal(): Float_literalContext;
        int_literal(): Int_literalContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Member_identContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Ident_pattern_token(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Optionally_typed_identContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        type_specifier(): Type_specifierContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class ParamContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        type_specifier(): Type_specifierContext;
        attribute_list(): AttributeContext[];
        attribute(i: number): AttributeContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Primary_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext;
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        literal(): LiteralContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Greater_thanContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Right_angle(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Less_thanContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        Left_angle(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Relational_expression_post_unary_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        shift_expression_post_unary_expression_list(): Shift_expression_post_unary_expressionContext[];
        shift_expression_post_unary_expression(i: number): Shift_expression_post_unary_expressionContext;
        greater_than(): Greater_thanContext;
        unary_expression(): Unary_expressionContext;
        Greater_than_equal(): TerminalNode;
        less_than(): Less_thanContext;
        Less_than_equal(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class StatementContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        compound_statement_list(): Compound_statementContext[];
        compound_statement(i: number): Compound_statementContext;
        attribute_list(): AttributeContext[];
        attribute(i: number): AttributeContext;
        for_init(): For_initContext;
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        for_update(): For_updateContext;
        statement_list(): StatementContext[];
        statement(i: number): StatementContext;
        Break_statement(): TerminalNode;
        switch_clause_list(): Switch_clauseContext[];
        switch_clause(i: number): Switch_clauseContext;
        ident(): IdentContext;
        template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext;
        variable_or_value_statement(): Variable_or_value_statementContext;
        variable_updating_statement(): Variable_updating_statementContext;
        Continue_statement(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Switch_clauseContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        case_selector_list(): Case_selectorContext[];
        case_selector(i: number): Case_selectorContext;
        compound_statement(): Compound_statementContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Template_arg_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        expression(): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Template_elaborated_ident_post_identContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        template_args_start(): Template_args_startContext;
        template_arg_expression(): Template_arg_expressionContext;
        template_args_end(): Template_args_endContext;
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Translation_unitContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        preamble_list(): PreambleContext[];
        preamble(i: number): PreambleContext;
        global_directive_list(): Global_directiveContext[];
        global_directive(i: number): Global_directiveContext;
        global_decl_list(): Global_declContext[];
        global_decl(i: number): Global_declContext;
        statement(): StatementContext;
        expression(): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Type_specifierContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        ident(): IdentContext;
        template_args_start(): Template_args_startContext;
        template_arg_expression(): Template_arg_expressionContext;
        template_args_end(): Template_args_endContext;
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Unary_expressionContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        primary_expression(): Primary_expressionContext;
        component_or_swizzle_specifier(): Component_or_swizzle_specifierContext;
        unary_expression(): Unary_expressionContext;
        Star(): TerminalNode;
        Minus(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Variable_declContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        optionally_typed_ident(): Optionally_typed_identContext;
        template_args_start(): Template_args_startContext;
        expression_list(): ExpressionContext[];
        expression(i: number): ExpressionContext;
        template_args_end(): Template_args_endContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Variable_or_value_statementContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        variable_decl(): Variable_declContext;
        expression(): ExpressionContext;
        optionally_typed_ident(): Optionally_typed_identContext;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
    export class Variable_updating_statementContext extends ParserRuleContext {
        constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number);
        lhs_expression(): Lhs_expressionContext;
        expression(): ExpressionContext;
        Compound_assignment_operator(): TerminalNode;
        get ruleIndex(): number;
        enterRule(listener: WGSLListener): void;
        exitRule(listener: WGSLListener): void;
        accept<Result>(visitor: WGSLVisitor<Result>): Result;
    }
}
declare module "Parser/WGSLListener" {
    import { ParseTreeListener } from "antlr4";
    import { Template_args_startContext } from "Parser/WGSLParser";
    import { Template_args_endContext } from "Parser/WGSLParser";
    import { Additive_operatorContext } from "Parser/WGSLParser";
    import { Multiplicative_operatorContext } from "Parser/WGSLParser";
    import { Argument_expression_listContext } from "Parser/WGSLParser";
    import { Assignment_statementContext } from "Parser/WGSLParser";
    import { Shift_expression_post_unary_expressionContext } from "Parser/WGSLParser";
    import { AttributeContext } from "Parser/WGSLParser";
    import { Bitwise_expression_post_unary_expressionContext } from "Parser/WGSLParser";
    import { Case_selectorContext } from "Parser/WGSLParser";
    import { Component_or_swizzle_specifierContext } from "Parser/WGSLParser";
    import { Compound_statementContext } from "Parser/WGSLParser";
    import { Core_lhs_expressionContext } from "Parser/WGSLParser";
    import { Diagnostic_controlContext } from "Parser/WGSLParser";
    import { Diagnostic_rule_nameContext } from "Parser/WGSLParser";
    import { ExpressionContext } from "Parser/WGSLParser";
    import { Float_literalContext } from "Parser/WGSLParser";
    import { For_initContext } from "Parser/WGSLParser";
    import { For_updateContext } from "Parser/WGSLParser";
    import { Import_statementContext } from "Parser/WGSLParser";
    import { PreambleContext } from "Parser/WGSLParser";
    import { Global_declContext } from "Parser/WGSLParser";
    import { Global_directiveContext } from "Parser/WGSLParser";
    import { Global_value_declContext } from "Parser/WGSLParser";
    import { IdentContext } from "Parser/WGSLParser";
    import { Int_literalContext } from "Parser/WGSLParser";
    import { Lhs_expressionContext } from "Parser/WGSLParser";
    import { LiteralContext } from "Parser/WGSLParser";
    import { Member_identContext } from "Parser/WGSLParser";
    import { Optionally_typed_identContext } from "Parser/WGSLParser";
    import { ParamContext } from "Parser/WGSLParser";
    import { Primary_expressionContext } from "Parser/WGSLParser";
    import { Greater_thanContext } from "Parser/WGSLParser";
    import { Less_thanContext } from "Parser/WGSLParser";
    import { Relational_expression_post_unary_expressionContext } from "Parser/WGSLParser";
    import { StatementContext } from "Parser/WGSLParser";
    import { Switch_clauseContext } from "Parser/WGSLParser";
    import { Template_arg_expressionContext } from "Parser/WGSLParser";
    import { Template_elaborated_ident_post_identContext } from "Parser/WGSLParser";
    import { Translation_unitContext } from "Parser/WGSLParser";
    import { Type_specifierContext } from "Parser/WGSLParser";
    import { Unary_expressionContext } from "Parser/WGSLParser";
    import { Variable_declContext } from "Parser/WGSLParser";
    import { Variable_or_value_statementContext } from "Parser/WGSLParser";
    import { Variable_updating_statementContext } from "Parser/WGSLParser";
    /**
     * This interface defines a complete listener for a parse tree produced by
     * `WGSLParser`.
     */
    export default class WGSLListener extends ParseTreeListener {
        /**
         * Enter a parse tree produced by `WGSLParser.template_args_start`.
         * @param ctx the parse tree
         */
        enterTemplate_args_start?: (ctx: Template_args_startContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.template_args_start`.
         * @param ctx the parse tree
         */
        exitTemplate_args_start?: (ctx: Template_args_startContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.template_args_end`.
         * @param ctx the parse tree
         */
        enterTemplate_args_end?: (ctx: Template_args_endContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.template_args_end`.
         * @param ctx the parse tree
         */
        exitTemplate_args_end?: (ctx: Template_args_endContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.additive_operator`.
         * @param ctx the parse tree
         */
        enterAdditive_operator?: (ctx: Additive_operatorContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.additive_operator`.
         * @param ctx the parse tree
         */
        exitAdditive_operator?: (ctx: Additive_operatorContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.multiplicative_operator`.
         * @param ctx the parse tree
         */
        enterMultiplicative_operator?: (ctx: Multiplicative_operatorContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.multiplicative_operator`.
         * @param ctx the parse tree
         */
        exitMultiplicative_operator?: (ctx: Multiplicative_operatorContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.argument_expression_list`.
         * @param ctx the parse tree
         */
        enterArgument_expression_list?: (ctx: Argument_expression_listContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.argument_expression_list`.
         * @param ctx the parse tree
         */
        exitArgument_expression_list?: (ctx: Argument_expression_listContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.assignment_statement`.
         * @param ctx the parse tree
         */
        enterAssignment_statement?: (ctx: Assignment_statementContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.assignment_statement`.
         * @param ctx the parse tree
         */
        exitAssignment_statement?: (ctx: Assignment_statementContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.shift_expression_post_unary_expression`.
         * @param ctx the parse tree
         */
        enterShift_expression_post_unary_expression?: (ctx: Shift_expression_post_unary_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.shift_expression_post_unary_expression`.
         * @param ctx the parse tree
         */
        exitShift_expression_post_unary_expression?: (ctx: Shift_expression_post_unary_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.attribute`.
         * @param ctx the parse tree
         */
        enterAttribute?: (ctx: AttributeContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.attribute`.
         * @param ctx the parse tree
         */
        exitAttribute?: (ctx: AttributeContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.bitwise_expression_post_unary_expression`.
         * @param ctx the parse tree
         */
        enterBitwise_expression_post_unary_expression?: (ctx: Bitwise_expression_post_unary_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.bitwise_expression_post_unary_expression`.
         * @param ctx the parse tree
         */
        exitBitwise_expression_post_unary_expression?: (ctx: Bitwise_expression_post_unary_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.case_selector`.
         * @param ctx the parse tree
         */
        enterCase_selector?: (ctx: Case_selectorContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.case_selector`.
         * @param ctx the parse tree
         */
        exitCase_selector?: (ctx: Case_selectorContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.component_or_swizzle_specifier`.
         * @param ctx the parse tree
         */
        enterComponent_or_swizzle_specifier?: (ctx: Component_or_swizzle_specifierContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.component_or_swizzle_specifier`.
         * @param ctx the parse tree
         */
        exitComponent_or_swizzle_specifier?: (ctx: Component_or_swizzle_specifierContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.compound_statement`.
         * @param ctx the parse tree
         */
        enterCompound_statement?: (ctx: Compound_statementContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.compound_statement`.
         * @param ctx the parse tree
         */
        exitCompound_statement?: (ctx: Compound_statementContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.core_lhs_expression`.
         * @param ctx the parse tree
         */
        enterCore_lhs_expression?: (ctx: Core_lhs_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.core_lhs_expression`.
         * @param ctx the parse tree
         */
        exitCore_lhs_expression?: (ctx: Core_lhs_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.diagnostic_control`.
         * @param ctx the parse tree
         */
        enterDiagnostic_control?: (ctx: Diagnostic_controlContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.diagnostic_control`.
         * @param ctx the parse tree
         */
        exitDiagnostic_control?: (ctx: Diagnostic_controlContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.diagnostic_rule_name`.
         * @param ctx the parse tree
         */
        enterDiagnostic_rule_name?: (ctx: Diagnostic_rule_nameContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.diagnostic_rule_name`.
         * @param ctx the parse tree
         */
        exitDiagnostic_rule_name?: (ctx: Diagnostic_rule_nameContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.expression`.
         * @param ctx the parse tree
         */
        enterExpression?: (ctx: ExpressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.expression`.
         * @param ctx the parse tree
         */
        exitExpression?: (ctx: ExpressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.float_literal`.
         * @param ctx the parse tree
         */
        enterFloat_literal?: (ctx: Float_literalContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.float_literal`.
         * @param ctx the parse tree
         */
        exitFloat_literal?: (ctx: Float_literalContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.for_init`.
         * @param ctx the parse tree
         */
        enterFor_init?: (ctx: For_initContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.for_init`.
         * @param ctx the parse tree
         */
        exitFor_init?: (ctx: For_initContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.for_update`.
         * @param ctx the parse tree
         */
        enterFor_update?: (ctx: For_updateContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.for_update`.
         * @param ctx the parse tree
         */
        exitFor_update?: (ctx: For_updateContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.import_statement`.
         * @param ctx the parse tree
         */
        enterImport_statement?: (ctx: Import_statementContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.import_statement`.
         * @param ctx the parse tree
         */
        exitImport_statement?: (ctx: Import_statementContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.preamble`.
         * @param ctx the parse tree
         */
        enterPreamble?: (ctx: PreambleContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.preamble`.
         * @param ctx the parse tree
         */
        exitPreamble?: (ctx: PreambleContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.global_decl`.
         * @param ctx the parse tree
         */
        enterGlobal_decl?: (ctx: Global_declContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.global_decl`.
         * @param ctx the parse tree
         */
        exitGlobal_decl?: (ctx: Global_declContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.global_directive`.
         * @param ctx the parse tree
         */
        enterGlobal_directive?: (ctx: Global_directiveContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.global_directive`.
         * @param ctx the parse tree
         */
        exitGlobal_directive?: (ctx: Global_directiveContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.global_value_decl`.
         * @param ctx the parse tree
         */
        enterGlobal_value_decl?: (ctx: Global_value_declContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.global_value_decl`.
         * @param ctx the parse tree
         */
        exitGlobal_value_decl?: (ctx: Global_value_declContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.ident`.
         * @param ctx the parse tree
         */
        enterIdent?: (ctx: IdentContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.ident`.
         * @param ctx the parse tree
         */
        exitIdent?: (ctx: IdentContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.int_literal`.
         * @param ctx the parse tree
         */
        enterInt_literal?: (ctx: Int_literalContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.int_literal`.
         * @param ctx the parse tree
         */
        exitInt_literal?: (ctx: Int_literalContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.lhs_expression`.
         * @param ctx the parse tree
         */
        enterLhs_expression?: (ctx: Lhs_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.lhs_expression`.
         * @param ctx the parse tree
         */
        exitLhs_expression?: (ctx: Lhs_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.literal`.
         * @param ctx the parse tree
         */
        enterLiteral?: (ctx: LiteralContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.literal`.
         * @param ctx the parse tree
         */
        exitLiteral?: (ctx: LiteralContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.member_ident`.
         * @param ctx the parse tree
         */
        enterMember_ident?: (ctx: Member_identContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.member_ident`.
         * @param ctx the parse tree
         */
        exitMember_ident?: (ctx: Member_identContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.optionally_typed_ident`.
         * @param ctx the parse tree
         */
        enterOptionally_typed_ident?: (ctx: Optionally_typed_identContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.optionally_typed_ident`.
         * @param ctx the parse tree
         */
        exitOptionally_typed_ident?: (ctx: Optionally_typed_identContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.param`.
         * @param ctx the parse tree
         */
        enterParam?: (ctx: ParamContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.param`.
         * @param ctx the parse tree
         */
        exitParam?: (ctx: ParamContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.primary_expression`.
         * @param ctx the parse tree
         */
        enterPrimary_expression?: (ctx: Primary_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.primary_expression`.
         * @param ctx the parse tree
         */
        exitPrimary_expression?: (ctx: Primary_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.greater_than`.
         * @param ctx the parse tree
         */
        enterGreater_than?: (ctx: Greater_thanContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.greater_than`.
         * @param ctx the parse tree
         */
        exitGreater_than?: (ctx: Greater_thanContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.less_than`.
         * @param ctx the parse tree
         */
        enterLess_than?: (ctx: Less_thanContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.less_than`.
         * @param ctx the parse tree
         */
        exitLess_than?: (ctx: Less_thanContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.relational_expression_post_unary_expression`.
         * @param ctx the parse tree
         */
        enterRelational_expression_post_unary_expression?: (ctx: Relational_expression_post_unary_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.relational_expression_post_unary_expression`.
         * @param ctx the parse tree
         */
        exitRelational_expression_post_unary_expression?: (ctx: Relational_expression_post_unary_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.statement`.
         * @param ctx the parse tree
         */
        enterStatement?: (ctx: StatementContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.statement`.
         * @param ctx the parse tree
         */
        exitStatement?: (ctx: StatementContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.switch_clause`.
         * @param ctx the parse tree
         */
        enterSwitch_clause?: (ctx: Switch_clauseContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.switch_clause`.
         * @param ctx the parse tree
         */
        exitSwitch_clause?: (ctx: Switch_clauseContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.template_arg_expression`.
         * @param ctx the parse tree
         */
        enterTemplate_arg_expression?: (ctx: Template_arg_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.template_arg_expression`.
         * @param ctx the parse tree
         */
        exitTemplate_arg_expression?: (ctx: Template_arg_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.template_elaborated_ident_post_ident`.
         * @param ctx the parse tree
         */
        enterTemplate_elaborated_ident_post_ident?: (ctx: Template_elaborated_ident_post_identContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.template_elaborated_ident_post_ident`.
         * @param ctx the parse tree
         */
        exitTemplate_elaborated_ident_post_ident?: (ctx: Template_elaborated_ident_post_identContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.translation_unit`.
         * @param ctx the parse tree
         */
        enterTranslation_unit?: (ctx: Translation_unitContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.translation_unit`.
         * @param ctx the parse tree
         */
        exitTranslation_unit?: (ctx: Translation_unitContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.type_specifier`.
         * @param ctx the parse tree
         */
        enterType_specifier?: (ctx: Type_specifierContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.type_specifier`.
         * @param ctx the parse tree
         */
        exitType_specifier?: (ctx: Type_specifierContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.unary_expression`.
         * @param ctx the parse tree
         */
        enterUnary_expression?: (ctx: Unary_expressionContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.unary_expression`.
         * @param ctx the parse tree
         */
        exitUnary_expression?: (ctx: Unary_expressionContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.variable_decl`.
         * @param ctx the parse tree
         */
        enterVariable_decl?: (ctx: Variable_declContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.variable_decl`.
         * @param ctx the parse tree
         */
        exitVariable_decl?: (ctx: Variable_declContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.variable_or_value_statement`.
         * @param ctx the parse tree
         */
        enterVariable_or_value_statement?: (ctx: Variable_or_value_statementContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.variable_or_value_statement`.
         * @param ctx the parse tree
         */
        exitVariable_or_value_statement?: (ctx: Variable_or_value_statementContext) => void;
        /**
         * Enter a parse tree produced by `WGSLParser.variable_updating_statement`.
         * @param ctx the parse tree
         */
        enterVariable_updating_statement?: (ctx: Variable_updating_statementContext) => void;
        /**
         * Exit a parse tree produced by `WGSLParser.variable_updating_statement`.
         * @param ctx the parse tree
         */
        exitVariable_updating_statement?: (ctx: Variable_updating_statementContext) => void;
    }
}
declare module "Utility/tree" {
    import { ParserRuleContext, ParseTree, TerminalNode } from 'antlr4';
    import WGSLListener from "Parser/WGSLListener";
    export function equal(lhs: ParserRuleContext, rhs: ParserRuleContext, fn: (lhs: ParserRuleContext, rhs: ParserRuleContext) => boolean): boolean;
    export class Printer extends WGSLListener {
        private seperatorWS;
        private seperatorNewLine;
        private sources_;
        get sources(): string;
        visitTerminal: (node: TerminalNode) => void;
        print(tree: ParseTree): Printer;
    }
}
declare module "Parser/WGSLLexer" {
    import { ATN, CharStream, DFA, Lexer } from "antlr4";
    export default class WGSLLexer extends Lexer {
        static readonly T__0 = 1;
        static readonly T__1 = 2;
        static readonly T__2 = 3;
        static readonly T__3 = 4;
        static readonly T__4 = 5;
        static readonly T__5 = 6;
        static readonly T__6 = 7;
        static readonly T__7 = 8;
        static readonly T__8 = 9;
        static readonly T__9 = 10;
        static readonly T__10 = 11;
        static readonly T__11 = 12;
        static readonly T__12 = 13;
        static readonly T__13 = 14;
        static readonly T__14 = 15;
        static readonly T__15 = 16;
        static readonly T__16 = 17;
        static readonly T__17 = 18;
        static readonly T__18 = 19;
        static readonly T__19 = 20;
        static readonly T__20 = 21;
        static readonly T__21 = 22;
        static readonly T__22 = 23;
        static readonly T__23 = 24;
        static readonly T__24 = 25;
        static readonly T__25 = 26;
        static readonly T__26 = 27;
        static readonly T__27 = 28;
        static readonly T__28 = 29;
        static readonly T__29 = 30;
        static readonly T__30 = 31;
        static readonly T__31 = 32;
        static readonly T__32 = 33;
        static readonly T__33 = 34;
        static readonly T__34 = 35;
        static readonly T__35 = 36;
        static readonly T__36 = 37;
        static readonly T__37 = 38;
        static readonly T__38 = 39;
        static readonly T__39 = 40;
        static readonly T__40 = 41;
        static readonly T__41 = 42;
        static readonly T__42 = 43;
        static readonly T__43 = 44;
        static readonly T__44 = 45;
        static readonly T__45 = 46;
        static readonly T__46 = 47;
        static readonly T__47 = 48;
        static readonly T__48 = 49;
        static readonly T__49 = 50;
        static readonly T__50 = 51;
        static readonly T__51 = 52;
        static readonly T__52 = 53;
        static readonly T__53 = 54;
        static readonly T__54 = 55;
        static readonly T__55 = 56;
        static readonly T__56 = 57;
        static readonly T__57 = 58;
        static readonly T__58 = 59;
        static readonly T__59 = 60;
        static readonly T__60 = 61;
        static readonly T__61 = 62;
        static readonly WS = 63;
        static readonly Positive = 64;
        static readonly Minus = 65;
        static readonly Star = 66;
        static readonly Dash = 67;
        static readonly MOD = 68;
        static readonly Left_angle = 69;
        static readonly Right_angle = 70;
        static readonly Sigma_term = 71;
        static readonly Ident_pattern_token = 72;
        static readonly Bool_literal = 73;
        static readonly Compound_assignment_operator = 74;
        static readonly Decimal_float_literal = 75;
        static readonly Decimal_int_literal = 76;
        static readonly Path = 77;
        static readonly Hex_float_literal = 78;
        static readonly Hex_int_literal = 79;
        static readonly Greater_than_equal = 80;
        static readonly Less_than_equal = 81;
        static readonly Shift_left = 82;
        static readonly Shift_right = 83;
        static readonly Break_statement = 84;
        static readonly Continue_statement = 85;
        static readonly Severity_control_name = 86;
        static readonly Swizzle_name = 87;
        static readonly EOF: number;
        static readonly channelNames: string[];
        static readonly literalNames: (string | null)[];
        static readonly symbolicNames: (string | null)[];
        static readonly modeNames: string[];
        static readonly ruleNames: string[];
        constructor(input: CharStream);
        get grammarFileName(): string;
        get literalNames(): (string | null)[];
        get symbolicNames(): (string | null)[];
        get ruleNames(): string[];
        get serializedATN(): number[];
        get channelNames(): string[];
        get modeNames(): string[];
        static readonly _serializedATN: number[];
        private static __ATN;
        static get _ATN(): ATN;
        static DecisionsToDFA: DFA[];
    }
}
declare module "parser" {
    import { ParseTree } from 'antlr4';
    export class Parser {
        parse(input: string): ParseTree | null;
    }
}
declare module "types" {
    export class ObfIdent {
        private _v;
        get value(): string;
        constructor(s: string);
        next(): ObfIdent;
    }
}
declare module "transformer" {
    import { ParseTree } from 'antlr4';
    export enum Features {
        Obfuscate = 1,
        ExtendedSyntax = 2
    }
    export class Transformer {
        private trans;
        constructor(features?: Features);
        resetFeatures(features: Features): void;
        transform(t: ParseTree): ParseTree;
    }
}
declare module "editor" {
    export class Editor {
        private parser;
        private printer;
        valid(source: string): boolean;
        obfuscate(source: string): string | null;
    }
}
declare module "editor.test" { }
declare module "parser.test" { }
declare module "transformer_test_sources" {
    export const Sources: string[];
}
declare module "transformer.test" { }
declare module "types.test" { }
