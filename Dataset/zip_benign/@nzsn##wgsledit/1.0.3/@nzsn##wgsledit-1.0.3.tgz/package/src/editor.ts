import { ParseTree } from 'antlr4';
import { Printer } from './Utility/tree';
import { Parser } from './parser';
import { Features, Transformer } from './transformer';


export class Editor {
    private parser: Parser = new Parser();
    private printer: Printer = new Printer();

    valid(source: string): boolean {
        return this.parser.parse(source) != undefined;
    }

    obfuscate(source: string): string | null {
        let tr: Transformer =
            new Transformer(Features.Obfuscate);
        let tree: ParseTree | null = this.parser.parse(source);

        return tree == null ? null :
            this.printer.print(tr.transform(tree)).sources;
    }
}
