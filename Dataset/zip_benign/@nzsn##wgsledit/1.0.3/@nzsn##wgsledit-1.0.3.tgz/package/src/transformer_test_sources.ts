
export const Sources: string[] = [
    ///////////////////////////////////////////////////////////////////////////
    //                                 Source                                //
    ///////////////////////////////////////////////////////////////////////////

    `
/* Multiline Comment
 * Multiline Comment
 **/
struct GBufferOutput {
  @location(0) normal : vec4<f32>,
  @location(1) albedo : vec4<f32>,
}

@fragment
fn main(
  @location(0) fragNormal: vec3<f32>,
  @location(1) fragUV : vec2<f32>
) -> GBufferOutput {
  let uv = floor(30.0 * fragUV);
  let c = 0.2 + 0.5 * ((uv.x + uv.y) - 2.0 * floor((uv.x + uv.y) / 2.0));

  var output : GBufferOutput;
  output.normal = vec4(normalize(fragNormal), 1.0);
  output.albedo = vec4(c, c, c, 1.0);

  return output;
}
    `,
    ///////////////////////////////////////////////////////////////////////////
    //                                 Source                                //
    ///////////////////////////////////////////////////////////////////////////

    `
struct ComputeUniforms {
  width: f32,
  height: f32,
  algo: u32,
  blockHeight: u32,
}

struct FragmentUniforms {
  // boolean, either 0 or 1
  highlight: u32,
}

struct VertexOutput {
  @builtin(position) Position: vec4<f32>,
  @location(0) fragUV: vec2<f32>
}

// Uniforms from compute shader
@group(0) @binding(0) var<storage, read> data: array<u32>;
@group(0) @binding(2) var<uniform> uniforms: ComputeUniforms;
// Fragment shader uniforms
@group(1) @binding(0) var<uniform> fragment_uniforms: FragmentUniforms;

@fragment
fn frag_main(input: VertexOutput) -> @location(0) vec4<f32> {
  var uv: vec2<f32> = vec2<f32>(
    input.fragUV.x * uniforms.width,
    input.fragUV.y * uniforms.height
  );

  var pixel: vec2<u32> = vec2<u32>(
    u32(floor(uv.x)),
    u32(floor(uv.y)),
  );

  var elementIndex = u32(uniforms.width) * pixel.y + pixel.x;
  var colorChanger = data[elementIndex];

  var subtracter = f32(colorChanger) / (uniforms.width * uniforms.height);

  if (fragment_uniforms.highlight == 1) {
    return select(
      //If element is above halfHeight, highlight green
      vec4<f32>(vec3<f32>(0.0, 1.0 - subtracter, 0.0).rgb, 1.0),
      //If element is below halfheight, highlight red
      vec4<f32>(vec3<f32>(1.0 - subtracter, 0.0, 0.0).rgb, 1.0),
      elementIndex % uniforms.blockHeight < uniforms.blockHeight / 2
    );
  }

  var color: vec3<f32> = vec3f(
    1.0 - subtracter
  );

  return vec4<f32>(color.rgb, 1.0);
}
    `,
    ///////////////////////////////////////////////////////////////////////////
    //                                 Source                                //
    ///////////////////////////////////////////////////////////////////////////

    `
struct Time {
  value : f32,
}

struct Uniforms {
  scale : f32,
  offsetX : f32,
  offsetY : f32,
  scalar : f32,
  scalarOffset : f32,
}

@binding(0) @group(0) var<uniform> time : Time;
@binding(0) @group(1) var<uniform> uniforms : Uniforms;

struct VertexOutput {
  @builtin(position) Position : vec4<f32>,
  @location(0) v_color : vec4<f32>,
}

@vertex
fn vert_main(
  @location(0) position : vec4<f32>,
  @location(1) color : vec4<f32>
) -> VertexOutput {
  var fade = (uniforms.scalarOffset + time.value * uniforms.scalar / 10.0) % 1.0;
  if (fade < 0.5) {
    fade = fade * 2.0;
  } else {
    fade = (1.0 - fade) * 2.0;
  }
  var xpos = position.x * uniforms.scale;
  var ypos = position.y * uniforms.scale;
  var angle = 3.14159 * 2.0 * fade;
  var xrot = xpos * cos(angle) - ypos * sin(angle);
  var yrot = xpos * sin(angle) + ypos * cos(angle);
  xpos = xrot + uniforms.offsetX;
  ypos = yrot + uniforms.offsetY;

  var output : VertexOutput;
  output.v_color = vec4(fade, 1.0 - fade, 0.0, 1.0) + color;
  output.Position = vec4(xpos, ypos, 0.0, 1.0);
  return output;
}

@fragment
fn frag_main(@location(0) v_color : vec4<f32>) -> @location(0) vec4<f32> {
  return v_color;
}
`
];
