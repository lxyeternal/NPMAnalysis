import { ObfIdent } from './types';

// Suppose ObfIdent.ident :: ObfIdent x {1} -> ObfIdent
// then injectivity is expected otherwise two different
// entities may treat as same things.
test('ObfIdent Injective', () => {
    let ident = new ObfIdent("a");

    let n = 100;
    let results: string[] = [];

    while (n > 0) {
        results.push(ident.value);
        ident = ident.next();

        n = n - 1;
    }

    for (const r of results) {
        const others = results.filter((s:string) => s != r);
        for (const other of others) {
            expect(r != other).toBeTruthy();
        }
    }
});
