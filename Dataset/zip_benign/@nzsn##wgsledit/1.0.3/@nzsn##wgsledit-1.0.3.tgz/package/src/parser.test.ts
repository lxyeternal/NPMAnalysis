import { Parser } from './parser';

test('Parse Success', () => {
  const source = "fn main() { a = b + c; }"
  let p = new Parser();
  const tree = p.parse(source);

  expect(tree != null);
  expect(tree?.getText() == "fnmain(){a=b+c;}").toBeTruthy();
});

test('Parse Failed', () => {
  const source = "fn main() { a = b + c;"
  let p = new Parser();
  const tree = p.parse(source);

  expect(tree == null).toBeTruthy();
});
