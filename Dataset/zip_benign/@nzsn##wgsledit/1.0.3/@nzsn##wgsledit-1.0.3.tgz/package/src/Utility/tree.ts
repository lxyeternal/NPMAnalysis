import { ParserRuleContext, ParseTree, ParseTreeWalker, TerminalNode } from 'antlr4';
import WGSLListener from '../Parser/WGSLListener';

// TRUE: lhs and rhs are at least isomorphic and for
//       every node in lhs the correspond node in rhs
//       should have fn(lhs, rhs) == TRUE.
// FALSE: otherwise.
export function equal(
    lhs: ParserRuleContext, rhs: ParserRuleContext,
    fn: (lhs: ParserRuleContext, rhs: ParserRuleContext) => boolean): boolean {

    if (lhs.children?.length != rhs.children?.length ||
        !fn(lhs, rhs)) {

        return false;
    }

    type RuleCtxTuple = ParserRuleContext[];
    let zipped: Array<RuleCtxTuple> = (() => {
        let length = lhs.children?.length ?? 0;
        let ctxTuples: Array<RuleCtxTuple> = new Array();

        for (let i = 0; i < length; ++i) {

            let pair = [lhs.children?.at(i) as ParserRuleContext,
                        rhs.children?.at(i) as ParserRuleContext];
            ctxTuples.push(pair);
        }

        return ctxTuples;
    })();

    for (var p of zipped) {
        if (p[0] == null && p[1] == null) {
            continue;
        } else if (p[0] != null && p[1] != null) {
            if (!equal(p[0], p[1], fn)) {
                return false;
            }
        } else {
            return false;
        }
    }

    return true;;
}

// Structure to Print antlr4::tree::ParseTree into String
// that can be parse by WGSL Parser.
export class Printer extends WGSLListener {
    private seperatorWS = " ";
    private seperatorNewLine = "\n";
    private sources_: string = "";

    get sources() {
        return this.sources_;
    }

    visitTerminal = (node: TerminalNode) => {
        this.sources_ = this.sources + node.getText() + this.seperatorWS;
    }

    print(tree: ParseTree): Printer {
        ParseTreeWalker.DEFAULT.walk(this, tree);
        return this;
    }
}
