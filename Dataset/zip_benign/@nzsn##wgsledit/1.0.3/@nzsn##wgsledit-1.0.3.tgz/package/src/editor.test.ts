import { Editor } from './editor';

describe("Editor Api Spec", () => {

    test("Obfuscate", () => {
        let editor: Editor = new Editor();

        let source: string = "fn main() { x = y + z; }";

        let obfSource: string | null = editor.obfuscate(source);
        expect(obfSource != null).toBeTruthy();
        expect(obfSource == "fn a ( ) { b = c + d ; } ").toBeTruthy();
    });

    test("Obfuscate invalid", () => {
        let editor: Editor = new Editor();
        let source: string = "fn main() { x = y + z;";
        let obfSource: string | null = editor.obfuscate(source);

        expect(obfSource === null).toBeTruthy();
    });

    test("Syntax Check", () => {
        let editor: Editor = new Editor();

        expect(editor.valid("fn main() { a = b + c; }")).toBeTruthy();
        expect(editor.valid("fn main() { a = b + c; ")).toBeFalsy();
    });
});
