import { ParseTree, ParserRuleContext } from 'antlr4';
import { Transformer, Features } from './transformer';
import { Parser } from './parser';
import { equal, Printer } from './Utility/tree';
import { IdentContext, Type_specifierContext } from './Parser/WGSLParser';
import { Sources } from './transformer_test_sources';

function typeSpecifierNoModified(
  lhs: ParseTree, rhs: ParseTree): boolean {

  return equal(
    lhs as ParserRuleContext,
    rhs as ParserRuleContext,

    (lhs_,rhs_): boolean => {if (lhs_ instanceof Type_specifierContext &&
        rhs_ instanceof Type_specifierContext) {

        return lhs_.getText() == rhs_.getText();
      }

      return true;

    })
}

class ObfuscateConsistentChecker {
  mapping: Map<string, string> =
    new Map<string, string>();

  numOfMaps(): number {
    return this.mapping.size;
  }

  check(
    lhs: ParseTree, rhs: ParseTree): boolean {

    return equal(
      lhs as ParserRuleContext,
      rhs as ParserRuleContext,

      (lhs_, rhs_): boolean => {
        if (lhs_ instanceof IdentContext &&
          rhs_ instanceof IdentContext) {

          if (lhs_.getText() == rhs_.getText()) {
            // This case implies that lhs_ and rhs_
            // indicate identier for types.
            return true;
          } else {
            if (this.mapping.has(lhs_.getText())) {
              return rhs_.getText() == this.mapping.get(lhs_.getText());
            } else {
              this.mapping.set(lhs_.getText(), rhs_.getText());
              return true;
            }
          }
        }

        return true;
      }
    );
  }

}

test('Tree Printer', () => {
  let parser = new Parser();
  let tree: ParseTree | null = parser.parse(Sources[0]);

  expect(tree != null).toBeTruthy();

  let printer: Printer = new Printer();
  printer.print(tree as ParseTree);

  expect(parser.parse(printer.sources) != null);
});

test('Trans Without Type_specifier', () => {
  let tr = new Transformer();

  for (const source of Sources) {
    let parser = new Parser();
    let tree_origin: ParseTree | null = parser.parse(source);
    let tree: ParseTree | null = parser.parse(source);

    expect(tree != null).toBeTruthy();

    tree = tr.transform(tree as ParseTree);

    let checker = new ObfuscateConsistentChecker();

    // Expect that Type_specifier is not modified.
    // TODO: Update this postcond to restrict builtin type only.
    // expect(typeSpecifierNoModified(tree_origin as ParseTree, tree)).toBeTruthy();
    // Expect that obfuscate identifier are consistent.
    expect(checker.check(tree_origin as ParseTree, tree)).toBeTruthy();
    // Expect that identifiers are actual be ofuscated.
    expect(checker.numOfMaps() > 0).toBeTruthy();

    let printer: Printer = new Printer();
    printer.print(tree);
    console.log(printer.sources);

    // Expect that obfuscated sources still parseable
    expect(parser.parse(printer.sources) != null).toBeTruthy();
  }
});
