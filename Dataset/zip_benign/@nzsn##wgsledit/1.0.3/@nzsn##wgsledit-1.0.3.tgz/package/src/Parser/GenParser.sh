#!/bin/bash
antlr4 ./WGSL.g4 -Dlanguage=TypeScript -visitor
