// Generated from ./WGSL.g4 by ANTLR 4.13.1

import {ParseTreeListener} from "antlr4";


import { Template_args_startContext } from "./WGSLParser";
import { Template_args_endContext } from "./WGSLParser";
import { Additive_operatorContext } from "./WGSLParser";
import { Multiplicative_operatorContext } from "./WGSLParser";
import { Argument_expression_listContext } from "./WGSLParser";
import { Assignment_statementContext } from "./WGSLParser";
import { Shift_expression_post_unary_expressionContext } from "./WGSLParser";
import { AttributeContext } from "./WGSLParser";
import { Bitwise_expression_post_unary_expressionContext } from "./WGSLParser";
import { Case_selectorContext } from "./WGSLParser";
import { Component_or_swizzle_specifierContext } from "./WGSLParser";
import { Compound_statementContext } from "./WGSLParser";
import { Core_lhs_expressionContext } from "./WGSLParser";
import { Diagnostic_controlContext } from "./WGSLParser";
import { Diagnostic_rule_nameContext } from "./WGSLParser";
import { ExpressionContext } from "./WGSLParser";
import { Float_literalContext } from "./WGSLParser";
import { For_initContext } from "./WGSLParser";
import { For_updateContext } from "./WGSLParser";
import { Global_declContext } from "./WGSLParser";
import { Global_directiveContext } from "./WGSLParser";
import { Global_value_declContext } from "./WGSLParser";
import { IdentContext } from "./WGSLParser";
import { Int_literalContext } from "./WGSLParser";
import { Lhs_expressionContext } from "./WGSLParser";
import { LiteralContext } from "./WGSLParser";
import { Member_identContext } from "./WGSLParser";
import { Optionally_typed_identContext } from "./WGSLParser";
import { ParamContext } from "./WGSLParser";
import { Primary_expressionContext } from "./WGSLParser";
import { Greater_thanContext } from "./WGSLParser";
import { Less_thanContext } from "./WGSLParser";
import { Relational_expression_post_unary_expressionContext } from "./WGSLParser";
import { StatementContext } from "./WGSLParser";
import { Switch_clauseContext } from "./WGSLParser";
import { Template_arg_expressionContext } from "./WGSLParser";
import { Template_elaborated_ident_post_identContext } from "./WGSLParser";
import { Translation_unitContext } from "./WGSLParser";
import { Type_specifierContext } from "./WGSLParser";
import { Unary_expressionContext } from "./WGSLParser";
import { Variable_declContext } from "./WGSLParser";
import { Variable_or_value_statementContext } from "./WGSLParser";
import { Variable_updating_statementContext } from "./WGSLParser";


/**
 * This interface defines a complete listener for a parse tree produced by
 * `WGSLParser`.
 */
export default class WGSLListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by `WGSLParser.template_args_start`.
	 * @param ctx the parse tree
	 */
	enterTemplate_args_start?: (ctx: Template_args_startContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.template_args_start`.
	 * @param ctx the parse tree
	 */
	exitTemplate_args_start?: (ctx: Template_args_startContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.template_args_end`.
	 * @param ctx the parse tree
	 */
	enterTemplate_args_end?: (ctx: Template_args_endContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.template_args_end`.
	 * @param ctx the parse tree
	 */
	exitTemplate_args_end?: (ctx: Template_args_endContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.additive_operator`.
	 * @param ctx the parse tree
	 */
	enterAdditive_operator?: (ctx: Additive_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.additive_operator`.
	 * @param ctx the parse tree
	 */
	exitAdditive_operator?: (ctx: Additive_operatorContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.multiplicative_operator`.
	 * @param ctx the parse tree
	 */
	enterMultiplicative_operator?: (ctx: Multiplicative_operatorContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.multiplicative_operator`.
	 * @param ctx the parse tree
	 */
	exitMultiplicative_operator?: (ctx: Multiplicative_operatorContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.argument_expression_list`.
	 * @param ctx the parse tree
	 */
	enterArgument_expression_list?: (ctx: Argument_expression_listContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.argument_expression_list`.
	 * @param ctx the parse tree
	 */
	exitArgument_expression_list?: (ctx: Argument_expression_listContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.assignment_statement`.
	 * @param ctx the parse tree
	 */
	enterAssignment_statement?: (ctx: Assignment_statementContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.assignment_statement`.
	 * @param ctx the parse tree
	 */
	exitAssignment_statement?: (ctx: Assignment_statementContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.shift_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 */
	enterShift_expression_post_unary_expression?: (ctx: Shift_expression_post_unary_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.shift_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 */
	exitShift_expression_post_unary_expression?: (ctx: Shift_expression_post_unary_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.attribute`.
	 * @param ctx the parse tree
	 */
	enterAttribute?: (ctx: AttributeContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.attribute`.
	 * @param ctx the parse tree
	 */
	exitAttribute?: (ctx: AttributeContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.bitwise_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 */
	enterBitwise_expression_post_unary_expression?: (ctx: Bitwise_expression_post_unary_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.bitwise_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 */
	exitBitwise_expression_post_unary_expression?: (ctx: Bitwise_expression_post_unary_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.case_selector`.
	 * @param ctx the parse tree
	 */
	enterCase_selector?: (ctx: Case_selectorContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.case_selector`.
	 * @param ctx the parse tree
	 */
	exitCase_selector?: (ctx: Case_selectorContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.component_or_swizzle_specifier`.
	 * @param ctx the parse tree
	 */
	enterComponent_or_swizzle_specifier?: (ctx: Component_or_swizzle_specifierContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.component_or_swizzle_specifier`.
	 * @param ctx the parse tree
	 */
	exitComponent_or_swizzle_specifier?: (ctx: Component_or_swizzle_specifierContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.compound_statement`.
	 * @param ctx the parse tree
	 */
	enterCompound_statement?: (ctx: Compound_statementContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.compound_statement`.
	 * @param ctx the parse tree
	 */
	exitCompound_statement?: (ctx: Compound_statementContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.core_lhs_expression`.
	 * @param ctx the parse tree
	 */
	enterCore_lhs_expression?: (ctx: Core_lhs_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.core_lhs_expression`.
	 * @param ctx the parse tree
	 */
	exitCore_lhs_expression?: (ctx: Core_lhs_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.diagnostic_control`.
	 * @param ctx the parse tree
	 */
	enterDiagnostic_control?: (ctx: Diagnostic_controlContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.diagnostic_control`.
	 * @param ctx the parse tree
	 */
	exitDiagnostic_control?: (ctx: Diagnostic_controlContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.diagnostic_rule_name`.
	 * @param ctx the parse tree
	 */
	enterDiagnostic_rule_name?: (ctx: Diagnostic_rule_nameContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.diagnostic_rule_name`.
	 * @param ctx the parse tree
	 */
	exitDiagnostic_rule_name?: (ctx: Diagnostic_rule_nameContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.expression`.
	 * @param ctx the parse tree
	 */
	enterExpression?: (ctx: ExpressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.expression`.
	 * @param ctx the parse tree
	 */
	exitExpression?: (ctx: ExpressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.float_literal`.
	 * @param ctx the parse tree
	 */
	enterFloat_literal?: (ctx: Float_literalContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.float_literal`.
	 * @param ctx the parse tree
	 */
	exitFloat_literal?: (ctx: Float_literalContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.for_init`.
	 * @param ctx the parse tree
	 */
	enterFor_init?: (ctx: For_initContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.for_init`.
	 * @param ctx the parse tree
	 */
	exitFor_init?: (ctx: For_initContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.for_update`.
	 * @param ctx the parse tree
	 */
	enterFor_update?: (ctx: For_updateContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.for_update`.
	 * @param ctx the parse tree
	 */
	exitFor_update?: (ctx: For_updateContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.global_decl`.
	 * @param ctx the parse tree
	 */
	enterGlobal_decl?: (ctx: Global_declContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.global_decl`.
	 * @param ctx the parse tree
	 */
	exitGlobal_decl?: (ctx: Global_declContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.global_directive`.
	 * @param ctx the parse tree
	 */
	enterGlobal_directive?: (ctx: Global_directiveContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.global_directive`.
	 * @param ctx the parse tree
	 */
	exitGlobal_directive?: (ctx: Global_directiveContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.global_value_decl`.
	 * @param ctx the parse tree
	 */
	enterGlobal_value_decl?: (ctx: Global_value_declContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.global_value_decl`.
	 * @param ctx the parse tree
	 */
	exitGlobal_value_decl?: (ctx: Global_value_declContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.ident`.
	 * @param ctx the parse tree
	 */
	enterIdent?: (ctx: IdentContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.ident`.
	 * @param ctx the parse tree
	 */
	exitIdent?: (ctx: IdentContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.int_literal`.
	 * @param ctx the parse tree
	 */
	enterInt_literal?: (ctx: Int_literalContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.int_literal`.
	 * @param ctx the parse tree
	 */
	exitInt_literal?: (ctx: Int_literalContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.lhs_expression`.
	 * @param ctx the parse tree
	 */
	enterLhs_expression?: (ctx: Lhs_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.lhs_expression`.
	 * @param ctx the parse tree
	 */
	exitLhs_expression?: (ctx: Lhs_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.literal`.
	 * @param ctx the parse tree
	 */
	enterLiteral?: (ctx: LiteralContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.literal`.
	 * @param ctx the parse tree
	 */
	exitLiteral?: (ctx: LiteralContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.member_ident`.
	 * @param ctx the parse tree
	 */
	enterMember_ident?: (ctx: Member_identContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.member_ident`.
	 * @param ctx the parse tree
	 */
	exitMember_ident?: (ctx: Member_identContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.optionally_typed_ident`.
	 * @param ctx the parse tree
	 */
	enterOptionally_typed_ident?: (ctx: Optionally_typed_identContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.optionally_typed_ident`.
	 * @param ctx the parse tree
	 */
	exitOptionally_typed_ident?: (ctx: Optionally_typed_identContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.param`.
	 * @param ctx the parse tree
	 */
	enterParam?: (ctx: ParamContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.param`.
	 * @param ctx the parse tree
	 */
	exitParam?: (ctx: ParamContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.primary_expression`.
	 * @param ctx the parse tree
	 */
	enterPrimary_expression?: (ctx: Primary_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.primary_expression`.
	 * @param ctx the parse tree
	 */
	exitPrimary_expression?: (ctx: Primary_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.greater_than`.
	 * @param ctx the parse tree
	 */
	enterGreater_than?: (ctx: Greater_thanContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.greater_than`.
	 * @param ctx the parse tree
	 */
	exitGreater_than?: (ctx: Greater_thanContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.less_than`.
	 * @param ctx the parse tree
	 */
	enterLess_than?: (ctx: Less_thanContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.less_than`.
	 * @param ctx the parse tree
	 */
	exitLess_than?: (ctx: Less_thanContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.relational_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 */
	enterRelational_expression_post_unary_expression?: (ctx: Relational_expression_post_unary_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.relational_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 */
	exitRelational_expression_post_unary_expression?: (ctx: Relational_expression_post_unary_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.statement`.
	 * @param ctx the parse tree
	 */
	enterStatement?: (ctx: StatementContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.statement`.
	 * @param ctx the parse tree
	 */
	exitStatement?: (ctx: StatementContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.switch_clause`.
	 * @param ctx the parse tree
	 */
	enterSwitch_clause?: (ctx: Switch_clauseContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.switch_clause`.
	 * @param ctx the parse tree
	 */
	exitSwitch_clause?: (ctx: Switch_clauseContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.template_arg_expression`.
	 * @param ctx the parse tree
	 */
	enterTemplate_arg_expression?: (ctx: Template_arg_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.template_arg_expression`.
	 * @param ctx the parse tree
	 */
	exitTemplate_arg_expression?: (ctx: Template_arg_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.template_elaborated_ident_post_ident`.
	 * @param ctx the parse tree
	 */
	enterTemplate_elaborated_ident_post_ident?: (ctx: Template_elaborated_ident_post_identContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.template_elaborated_ident_post_ident`.
	 * @param ctx the parse tree
	 */
	exitTemplate_elaborated_ident_post_ident?: (ctx: Template_elaborated_ident_post_identContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.translation_unit`.
	 * @param ctx the parse tree
	 */
	enterTranslation_unit?: (ctx: Translation_unitContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.translation_unit`.
	 * @param ctx the parse tree
	 */
	exitTranslation_unit?: (ctx: Translation_unitContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.type_specifier`.
	 * @param ctx the parse tree
	 */
	enterType_specifier?: (ctx: Type_specifierContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.type_specifier`.
	 * @param ctx the parse tree
	 */
	exitType_specifier?: (ctx: Type_specifierContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.unary_expression`.
	 * @param ctx the parse tree
	 */
	enterUnary_expression?: (ctx: Unary_expressionContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.unary_expression`.
	 * @param ctx the parse tree
	 */
	exitUnary_expression?: (ctx: Unary_expressionContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.variable_decl`.
	 * @param ctx the parse tree
	 */
	enterVariable_decl?: (ctx: Variable_declContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.variable_decl`.
	 * @param ctx the parse tree
	 */
	exitVariable_decl?: (ctx: Variable_declContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.variable_or_value_statement`.
	 * @param ctx the parse tree
	 */
	enterVariable_or_value_statement?: (ctx: Variable_or_value_statementContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.variable_or_value_statement`.
	 * @param ctx the parse tree
	 */
	exitVariable_or_value_statement?: (ctx: Variable_or_value_statementContext) => void;
	/**
	 * Enter a parse tree produced by `WGSLParser.variable_updating_statement`.
	 * @param ctx the parse tree
	 */
	enterVariable_updating_statement?: (ctx: Variable_updating_statementContext) => void;
	/**
	 * Exit a parse tree produced by `WGSLParser.variable_updating_statement`.
	 * @param ctx the parse tree
	 */
	exitVariable_updating_statement?: (ctx: Variable_updating_statementContext) => void;
}

