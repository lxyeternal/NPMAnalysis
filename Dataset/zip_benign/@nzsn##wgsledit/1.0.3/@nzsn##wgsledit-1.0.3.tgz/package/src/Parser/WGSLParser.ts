// Generated from ./WGSL.g4 by ANTLR 4.13.1
// noinspection ES6UnusedImports,JSUnusedGlobalSymbols,JSUnusedLocalSymbols

import {
	ATN,
	ATNDeserializer, DecisionState, DFA, FailedPredicateException,
	RecognitionException, NoViableAltException, BailErrorStrategy,
	Parser, ParserATNSimulator,
	RuleContext, ParserRuleContext, PredictionMode, PredictionContextCache,
	TerminalNode, RuleNode,
	Token, TokenStream,
	Interval, IntervalSet
} from 'antlr4';
import WGSLListener from "./WGSLListener.js";
import WGSLVisitor from "./WGSLVisitor.js";

// for running tests with parameters, TODO: discuss strategy for typed parameters in CI
// eslint-disable-next-line no-unused-vars
type int = number;

export default class WGSLParser extends Parser {
	public static readonly T__0 = 1;
	public static readonly T__1 = 2;
	public static readonly T__2 = 3;
	public static readonly T__3 = 4;
	public static readonly T__4 = 5;
	public static readonly T__5 = 6;
	public static readonly T__6 = 7;
	public static readonly T__7 = 8;
	public static readonly T__8 = 9;
	public static readonly T__9 = 10;
	public static readonly T__10 = 11;
	public static readonly T__11 = 12;
	public static readonly T__12 = 13;
	public static readonly T__13 = 14;
	public static readonly T__14 = 15;
	public static readonly T__15 = 16;
	public static readonly T__16 = 17;
	public static readonly T__17 = 18;
	public static readonly T__18 = 19;
	public static readonly T__19 = 20;
	public static readonly T__20 = 21;
	public static readonly T__21 = 22;
	public static readonly T__22 = 23;
	public static readonly T__23 = 24;
	public static readonly T__24 = 25;
	public static readonly T__25 = 26;
	public static readonly T__26 = 27;
	public static readonly T__27 = 28;
	public static readonly T__28 = 29;
	public static readonly T__29 = 30;
	public static readonly T__30 = 31;
	public static readonly T__31 = 32;
	public static readonly T__32 = 33;
	public static readonly T__33 = 34;
	public static readonly T__34 = 35;
	public static readonly T__35 = 36;
	public static readonly T__36 = 37;
	public static readonly T__37 = 38;
	public static readonly T__38 = 39;
	public static readonly T__39 = 40;
	public static readonly T__40 = 41;
	public static readonly T__41 = 42;
	public static readonly T__42 = 43;
	public static readonly T__43 = 44;
	public static readonly T__44 = 45;
	public static readonly T__45 = 46;
	public static readonly T__46 = 47;
	public static readonly T__47 = 48;
	public static readonly T__48 = 49;
	public static readonly T__49 = 50;
	public static readonly T__50 = 51;
	public static readonly T__51 = 52;
	public static readonly T__52 = 53;
	public static readonly T__53 = 54;
	public static readonly T__54 = 55;
	public static readonly T__55 = 56;
	public static readonly T__56 = 57;
	public static readonly T__57 = 58;
	public static readonly T__58 = 59;
	public static readonly T__59 = 60;
	public static readonly T__60 = 61;
	public static readonly WS = 62;
	public static readonly Positive = 63;
	public static readonly Minus = 64;
	public static readonly Star = 65;
	public static readonly Dash = 66;
	public static readonly MOD = 67;
	public static readonly Left_angle = 68;
	public static readonly Right_angle = 69;
	public static readonly Sigma_term = 70;
	public static readonly Ident_pattern_token = 71;
	public static readonly Bool_literal = 72;
	public static readonly Compound_assignment_operator = 73;
	public static readonly Decimal_float_literal = 74;
	public static readonly Decimal_int_literal = 75;
	public static readonly Hex_float_literal = 76;
	public static readonly Hex_int_literal = 77;
	public static readonly Greater_than_equal = 78;
	public static readonly Less_than_equal = 79;
	public static readonly Shift_left = 80;
	public static readonly Shift_right = 81;
	public static readonly Break_statement = 82;
	public static readonly Continue_statement = 83;
	public static readonly Severity_control_name = 84;
	public static readonly Swizzle_name = 85;
	public static readonly EOF = Token.EOF;
	public static readonly RULE_template_args_start = 0;
	public static readonly RULE_template_args_end = 1;
	public static readonly RULE_additive_operator = 2;
	public static readonly RULE_multiplicative_operator = 3;
	public static readonly RULE_argument_expression_list = 4;
	public static readonly RULE_assignment_statement = 5;
	public static readonly RULE_shift_expression_post_unary_expression = 6;
	public static readonly RULE_attribute = 7;
	public static readonly RULE_bitwise_expression_post_unary_expression = 8;
	public static readonly RULE_case_selector = 9;
	public static readonly RULE_component_or_swizzle_specifier = 10;
	public static readonly RULE_compound_statement = 11;
	public static readonly RULE_core_lhs_expression = 12;
	public static readonly RULE_diagnostic_control = 13;
	public static readonly RULE_diagnostic_rule_name = 14;
	public static readonly RULE_expression = 15;
	public static readonly RULE_float_literal = 16;
	public static readonly RULE_for_init = 17;
	public static readonly RULE_for_update = 18;
	public static readonly RULE_global_decl = 19;
	public static readonly RULE_global_directive = 20;
	public static readonly RULE_global_value_decl = 21;
	public static readonly RULE_ident = 22;
	public static readonly RULE_int_literal = 23;
	public static readonly RULE_lhs_expression = 24;
	public static readonly RULE_literal = 25;
	public static readonly RULE_member_ident = 26;
	public static readonly RULE_optionally_typed_ident = 27;
	public static readonly RULE_param = 28;
	public static readonly RULE_primary_expression = 29;
	public static readonly RULE_greater_than = 30;
	public static readonly RULE_less_than = 31;
	public static readonly RULE_relational_expression_post_unary_expression = 32;
	public static readonly RULE_statement = 33;
	public static readonly RULE_switch_clause = 34;
	public static readonly RULE_template_arg_expression = 35;
	public static readonly RULE_template_elaborated_ident_post_ident = 36;
	public static readonly RULE_translation_unit = 37;
	public static readonly RULE_type_specifier = 38;
	public static readonly RULE_unary_expression = 39;
	public static readonly RULE_variable_decl = 40;
	public static readonly RULE_variable_or_value_statement = 41;
	public static readonly RULE_variable_updating_statement = 42;
	public static readonly literalNames: (string | null)[] = [ null, "'('", 
                                                            "','", "')'", 
                                                            "'='", "'@'", 
                                                            "'align'", "'binding'", 
                                                            "'builtin'", 
                                                            "'compute'", 
                                                            "'const'", "'diagnostic'", 
                                                            "'fragment'", 
                                                            "'group'", "'id'", 
                                                            "'interpolate'", 
                                                            "'invariant'", 
                                                            "'location'", 
                                                            "'must_use'", 
                                                            "'size'", "'vertex'", 
                                                            "'workgroup_size'", 
                                                            "'&'", "'^'", 
                                                            "'|'", "'default'", 
                                                            "'.'", "'['", 
                                                            "']'", "'{'", 
                                                            "'}'", "'&&'", 
                                                            "'||'", "'fn'", 
                                                            "':'", "'->'", 
                                                            "'var'", "';'", 
                                                            "'alias'", "'const_assert'", 
                                                            "'struct'", 
                                                            "'enable'", 
                                                            "'requires'", 
                                                            "'override'", 
                                                            "'!='", "'=='", 
                                                            "'for'", "'if'", 
                                                            "'else'", "'loop'", 
                                                            "'continuing'", 
                                                            "'switch'", 
                                                            "'while'", "'discard'", 
                                                            "'return'", 
                                                            "'case'", "'!'", 
                                                            "'~'", "'let'", 
                                                            "'++'", "'--'", 
                                                            "'_'", null, 
                                                            "'+'", "'-'", 
                                                            "'*'", "'/'", 
                                                            "'%'", "'<'", 
                                                            "'>'", null, 
                                                            null, null, 
                                                            null, null, 
                                                            null, null, 
                                                            null, "'>='", 
                                                            "'<='", "'<<'", 
                                                            "'>>'", "'break'", 
                                                            "'continue'" ];
	public static readonly symbolicNames: (string | null)[] = [ null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             null, null, 
                                                             "WS", "Positive", 
                                                             "Minus", "Star", 
                                                             "Dash", "MOD", 
                                                             "Left_angle", 
                                                             "Right_angle", 
                                                             "Sigma_term", 
                                                             "Ident_pattern_token", 
                                                             "Bool_literal", 
                                                             "Compound_assignment_operator", 
                                                             "Decimal_float_literal", 
                                                             "Decimal_int_literal", 
                                                             "Hex_float_literal", 
                                                             "Hex_int_literal", 
                                                             "Greater_than_equal", 
                                                             "Less_than_equal", 
                                                             "Shift_left", 
                                                             "Shift_right", 
                                                             "Break_statement", 
                                                             "Continue_statement", 
                                                             "Severity_control_name", 
                                                             "Swizzle_name" ];
	// tslint:disable:no-trailing-whitespace
	public static readonly ruleNames: string[] = [
		"template_args_start", "template_args_end", "additive_operator", "multiplicative_operator", 
		"argument_expression_list", "assignment_statement", "shift_expression_post_unary_expression", 
		"attribute", "bitwise_expression_post_unary_expression", "case_selector", 
		"component_or_swizzle_specifier", "compound_statement", "core_lhs_expression", 
		"diagnostic_control", "diagnostic_rule_name", "expression", "float_literal", 
		"for_init", "for_update", "global_decl", "global_directive", "global_value_decl", 
		"ident", "int_literal", "lhs_expression", "literal", "member_ident", "optionally_typed_ident", 
		"param", "primary_expression", "greater_than", "less_than", "relational_expression_post_unary_expression", 
		"statement", "switch_clause", "template_arg_expression", "template_elaborated_ident_post_ident", 
		"translation_unit", "type_specifier", "unary_expression", "variable_decl", 
		"variable_or_value_statement", "variable_updating_statement",
	];
	public get grammarFileName(): string { return "WGSL.g4"; }
	public get literalNames(): (string | null)[] { return WGSLParser.literalNames; }
	public get symbolicNames(): (string | null)[] { return WGSLParser.symbolicNames; }
	public get ruleNames(): string[] { return WGSLParser.ruleNames; }
	public get serializedATN(): number[] { return WGSLParser._serializedATN; }

	protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException {
		return new FailedPredicateException(this, predicate, message);
	}

	constructor(input: TokenStream) {
		super(input);
		this._interp = new ParserATNSimulator(this, WGSLParser._ATN, WGSLParser.DecisionsToDFA, new PredictionContextCache());
	}
	// @RuleVersion(0)
	public template_args_start(): Template_args_startContext {
		let localctx: Template_args_startContext = new Template_args_startContext(this, this._ctx, this.state);
		this.enterRule(localctx, 0, WGSLParser.RULE_template_args_start);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 86;
			this.match(WGSLParser.Left_angle);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public template_args_end(): Template_args_endContext {
		let localctx: Template_args_endContext = new Template_args_endContext(this, this._ctx, this.state);
		this.enterRule(localctx, 2, WGSLParser.RULE_template_args_end);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 88;
			this.match(WGSLParser.Right_angle);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public additive_operator(): Additive_operatorContext {
		let localctx: Additive_operatorContext = new Additive_operatorContext(this, this._ctx, this.state);
		this.enterRule(localctx, 4, WGSLParser.RULE_additive_operator);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 90;
			_la = this._input.LA(1);
			if(!(_la===63 || _la===64)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public multiplicative_operator(): Multiplicative_operatorContext {
		let localctx: Multiplicative_operatorContext = new Multiplicative_operatorContext(this, this._ctx, this.state);
		this.enterRule(localctx, 6, WGSLParser.RULE_multiplicative_operator);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 92;
			_la = this._input.LA(1);
			if(!(((((_la - 65)) & ~0x1F) === 0 && ((1 << (_la - 65)) & 7) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public argument_expression_list(): Argument_expression_listContext {
		let localctx: Argument_expression_listContext = new Argument_expression_listContext(this, this._ctx, this.state);
		this.enterRule(localctx, 8, WGSLParser.RULE_argument_expression_list);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 94;
			this.match(WGSLParser.T__0);
			this.state = 106;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===1 || _la===22 || ((((_la - 56)) & ~0x1F) === 0 && ((1 << (_la - 56)) & 4047619) !== 0)) {
				{
				this.state = 95;
				this.expression();
				this.state = 100;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 0, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 96;
						this.match(WGSLParser.T__1);
						this.state = 97;
						this.expression();
						}
						}
					}
					this.state = 102;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 0, this._ctx);
				}
				this.state = 104;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 103;
					this.match(WGSLParser.T__1);
					}
				}

				}
			}

			this.state = 108;
			this.match(WGSLParser.T__2);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public assignment_statement(): Assignment_statementContext {
		let localctx: Assignment_statementContext = new Assignment_statementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 10, WGSLParser.RULE_assignment_statement);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 110;
			_la = this._input.LA(1);
			if(!(_la===4 || _la===73)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public shift_expression_post_unary_expression(): Shift_expression_post_unary_expressionContext {
		let localctx: Shift_expression_post_unary_expressionContext = new Shift_expression_post_unary_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 12, WGSLParser.RULE_shift_expression_post_unary_expression);
		let _la: number;
		try {
			this.state = 139;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case -1:
			case 2:
			case 3:
			case 5:
			case 28:
			case 29:
			case 31:
			case 32:
			case 34:
			case 37:
			case 44:
			case 45:
			case 63:
			case 64:
			case 65:
			case 66:
			case 67:
			case 68:
			case 69:
			case 78:
			case 79:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 117;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (((((_la - 65)) & ~0x1F) === 0 && ((1 << (_la - 65)) & 7) !== 0)) {
					{
					{
					this.state = 112;
					this.multiplicative_operator();
					this.state = 113;
					this.unary_expression();
					}
					}
					this.state = 119;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 132;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===63 || _la===64) {
					{
					{
					this.state = 120;
					this.additive_operator();
					this.state = 121;
					this.unary_expression();
					this.state = 127;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (((((_la - 65)) & ~0x1F) === 0 && ((1 << (_la - 65)) & 7) !== 0)) {
						{
						{
						this.state = 122;
						this.multiplicative_operator();
						this.state = 123;
						this.unary_expression();
						}
						}
						this.state = 129;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
					}
					this.state = 134;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			case 80:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 135;
				this.match(WGSLParser.Shift_left);
				this.state = 136;
				this.unary_expression();
				}
				break;
			case 81:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 137;
				this.match(WGSLParser.Shift_right);
				this.state = 138;
				this.unary_expression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public attribute(): AttributeContext {
		let localctx: AttributeContext = new AttributeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 14, WGSLParser.RULE_attribute);
		let _la: number;
		try {
			this.state = 272;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 19, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 141;
				this.match(WGSLParser.T__4);
				this.state = 142;
				this.match(WGSLParser.T__5);
				this.state = 143;
				this.match(WGSLParser.T__0);
				this.state = 144;
				this.expression();
				this.state = 146;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 145;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 148;
				this.match(WGSLParser.T__2);
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 150;
				this.match(WGSLParser.T__4);
				this.state = 151;
				this.match(WGSLParser.T__6);
				this.state = 152;
				this.match(WGSLParser.T__0);
				this.state = 153;
				this.expression();
				this.state = 155;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 154;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 157;
				this.match(WGSLParser.T__2);
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 159;
				this.match(WGSLParser.T__4);
				this.state = 160;
				this.match(WGSLParser.T__7);
				this.state = 161;
				this.match(WGSLParser.T__0);
				this.state = 162;
				this.expression();
				this.state = 164;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 163;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 166;
				this.match(WGSLParser.T__2);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 168;
				this.match(WGSLParser.T__4);
				this.state = 169;
				this.match(WGSLParser.T__8);
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 170;
				this.match(WGSLParser.T__4);
				this.state = 171;
				this.match(WGSLParser.T__9);
				}
				break;
			case 6:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 172;
				this.match(WGSLParser.T__4);
				this.state = 173;
				this.match(WGSLParser.T__10);
				this.state = 174;
				this.diagnostic_control();
				}
				break;
			case 7:
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 175;
				this.match(WGSLParser.T__4);
				this.state = 176;
				this.match(WGSLParser.T__11);
				}
				break;
			case 8:
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 177;
				this.match(WGSLParser.T__4);
				this.state = 178;
				this.match(WGSLParser.T__12);
				this.state = 179;
				this.match(WGSLParser.T__0);
				this.state = 180;
				this.expression();
				this.state = 182;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 181;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 184;
				this.match(WGSLParser.T__2);
				}
				break;
			case 9:
				this.enterOuterAlt(localctx, 9);
				{
				this.state = 186;
				this.match(WGSLParser.T__4);
				this.state = 187;
				this.match(WGSLParser.T__13);
				this.state = 188;
				this.match(WGSLParser.T__0);
				this.state = 189;
				this.expression();
				this.state = 191;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 190;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 193;
				this.match(WGSLParser.T__2);
				}
				break;
			case 10:
				this.enterOuterAlt(localctx, 10);
				{
				this.state = 195;
				this.match(WGSLParser.T__4);
				this.state = 196;
				this.match(WGSLParser.T__14);
				this.state = 197;
				this.match(WGSLParser.T__0);
				this.state = 198;
				this.expression();
				this.state = 200;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 199;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 202;
				this.match(WGSLParser.T__2);
				}
				break;
			case 11:
				this.enterOuterAlt(localctx, 11);
				{
				this.state = 204;
				this.match(WGSLParser.T__4);
				this.state = 205;
				this.match(WGSLParser.T__14);
				this.state = 206;
				this.match(WGSLParser.T__0);
				this.state = 207;
				this.expression();
				this.state = 208;
				this.match(WGSLParser.T__1);
				this.state = 209;
				this.expression();
				this.state = 211;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 210;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 213;
				this.match(WGSLParser.T__2);
				}
				break;
			case 12:
				this.enterOuterAlt(localctx, 12);
				{
				this.state = 215;
				this.match(WGSLParser.T__4);
				this.state = 216;
				this.match(WGSLParser.T__15);
				}
				break;
			case 13:
				this.enterOuterAlt(localctx, 13);
				{
				this.state = 217;
				this.match(WGSLParser.T__4);
				this.state = 218;
				this.match(WGSLParser.T__16);
				this.state = 219;
				this.match(WGSLParser.T__0);
				this.state = 220;
				this.expression();
				this.state = 222;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 221;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 224;
				this.match(WGSLParser.T__2);
				}
				break;
			case 14:
				this.enterOuterAlt(localctx, 14);
				{
				this.state = 226;
				this.match(WGSLParser.T__4);
				this.state = 227;
				this.match(WGSLParser.T__17);
				}
				break;
			case 15:
				this.enterOuterAlt(localctx, 15);
				{
				this.state = 228;
				this.match(WGSLParser.T__4);
				this.state = 229;
				this.match(WGSLParser.T__18);
				this.state = 230;
				this.match(WGSLParser.T__0);
				this.state = 231;
				this.expression();
				this.state = 233;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 232;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 235;
				this.match(WGSLParser.T__2);
				}
				break;
			case 16:
				this.enterOuterAlt(localctx, 16);
				{
				this.state = 237;
				this.match(WGSLParser.T__4);
				this.state = 238;
				this.match(WGSLParser.T__19);
				}
				break;
			case 17:
				this.enterOuterAlt(localctx, 17);
				{
				this.state = 239;
				this.match(WGSLParser.T__4);
				this.state = 240;
				this.match(WGSLParser.T__20);
				this.state = 241;
				this.match(WGSLParser.T__0);
				this.state = 242;
				this.expression();
				this.state = 244;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 243;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 246;
				this.match(WGSLParser.T__2);
				}
				break;
			case 18:
				this.enterOuterAlt(localctx, 18);
				{
				this.state = 248;
				this.match(WGSLParser.T__4);
				this.state = 249;
				this.match(WGSLParser.T__20);
				this.state = 250;
				this.match(WGSLParser.T__0);
				this.state = 251;
				this.expression();
				this.state = 252;
				this.match(WGSLParser.T__1);
				this.state = 253;
				this.expression();
				this.state = 255;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 254;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 257;
				this.match(WGSLParser.T__2);
				}
				break;
			case 19:
				this.enterOuterAlt(localctx, 19);
				{
				this.state = 259;
				this.match(WGSLParser.T__4);
				this.state = 260;
				this.match(WGSLParser.T__20);
				this.state = 261;
				this.match(WGSLParser.T__0);
				this.state = 262;
				this.expression();
				this.state = 263;
				this.match(WGSLParser.T__1);
				this.state = 264;
				this.expression();
				this.state = 265;
				this.match(WGSLParser.T__1);
				this.state = 266;
				this.expression();
				this.state = 268;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 267;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 270;
				this.match(WGSLParser.T__2);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public bitwise_expression_post_unary_expression(): Bitwise_expression_post_unary_expressionContext {
		let localctx: Bitwise_expression_post_unary_expressionContext = new Bitwise_expression_post_unary_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 16, WGSLParser.RULE_bitwise_expression_post_unary_expression);
		let _la: number;
		try {
			this.state = 301;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 22:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 274;
				this.match(WGSLParser.T__21);
				this.state = 275;
				this.unary_expression();
				this.state = 280;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===22) {
					{
					{
					this.state = 276;
					this.match(WGSLParser.T__21);
					this.state = 277;
					this.unary_expression();
					}
					}
					this.state = 282;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			case 23:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 283;
				this.match(WGSLParser.T__22);
				this.state = 284;
				this.unary_expression();
				this.state = 289;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===23) {
					{
					{
					this.state = 285;
					this.match(WGSLParser.T__22);
					this.state = 286;
					this.unary_expression();
					}
					}
					this.state = 291;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			case 24:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 292;
				this.match(WGSLParser.T__23);
				this.state = 293;
				this.unary_expression();
				this.state = 298;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===24) {
					{
					{
					this.state = 294;
					this.match(WGSLParser.T__23);
					this.state = 295;
					this.unary_expression();
					}
					}
					this.state = 300;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public case_selector(): Case_selectorContext {
		let localctx: Case_selectorContext = new Case_selectorContext(this, this._ctx, this.state);
		this.enterRule(localctx, 18, WGSLParser.RULE_case_selector);
		try {
			this.state = 305;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 22:
			case 56:
			case 57:
			case 64:
			case 65:
			case 70:
			case 71:
			case 72:
			case 74:
			case 75:
			case 76:
			case 77:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 303;
				this.expression();
				}
				break;
			case 25:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 304;
				this.match(WGSLParser.T__24);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public component_or_swizzle_specifier(): Component_or_swizzle_specifierContext {
		let localctx: Component_or_swizzle_specifierContext = new Component_or_swizzle_specifierContext(this, this._ctx, this.state);
		this.enterRule(localctx, 20, WGSLParser.RULE_component_or_swizzle_specifier);
		let _la: number;
		try {
			this.state = 323;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 28, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 307;
				this.match(WGSLParser.T__25);
				this.state = 308;
				this.member_ident();
				this.state = 310;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===26 || _la===27) {
					{
					this.state = 309;
					this.component_or_swizzle_specifier();
					}
				}

				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 312;
				this.match(WGSLParser.T__25);
				this.state = 313;
				this.match(WGSLParser.Swizzle_name);
				this.state = 315;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===26 || _la===27) {
					{
					this.state = 314;
					this.component_or_swizzle_specifier();
					}
				}

				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 317;
				this.match(WGSLParser.T__26);
				this.state = 318;
				this.expression();
				this.state = 319;
				this.match(WGSLParser.T__27);
				this.state = 321;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===26 || _la===27) {
					{
					this.state = 320;
					this.component_or_swizzle_specifier();
					}
				}

				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public compound_statement(): Compound_statementContext {
		let localctx: Compound_statementContext = new Compound_statementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 22, WGSLParser.RULE_compound_statement);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 328;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===5) {
				{
				{
				this.state = 325;
				this.attribute();
				}
				}
				this.state = 330;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 331;
			this.match(WGSLParser.T__28);
			this.state = 335;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while ((((_la) & ~0x1F) === 0 && ((1 << _la) & 541066274) !== 0) || ((((_la - 36)) & ~0x1F) === 0 && ((1 << (_la - 36)) & 575122443) !== 0) || ((((_la - 70)) & ~0x1F) === 0 && ((1 << (_la - 70)) & 12291) !== 0)) {
				{
				{
				this.state = 332;
				this.statement();
				}
				}
				this.state = 337;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 338;
			this.match(WGSLParser.T__29);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public core_lhs_expression(): Core_lhs_expressionContext {
		let localctx: Core_lhs_expressionContext = new Core_lhs_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 24, WGSLParser.RULE_core_lhs_expression);
		try {
			this.state = 345;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 70:
			case 71:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 340;
				this.ident();
				}
				break;
			case 1:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 341;
				this.match(WGSLParser.T__0);
				this.state = 342;
				this.lhs_expression();
				this.state = 343;
				this.match(WGSLParser.T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public diagnostic_control(): Diagnostic_controlContext {
		let localctx: Diagnostic_controlContext = new Diagnostic_controlContext(this, this._ctx, this.state);
		this.enterRule(localctx, 26, WGSLParser.RULE_diagnostic_control);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 347;
			this.match(WGSLParser.T__0);
			this.state = 348;
			this.match(WGSLParser.Severity_control_name);
			this.state = 349;
			this.match(WGSLParser.T__1);
			this.state = 350;
			this.diagnostic_rule_name();
			this.state = 352;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===2) {
				{
				this.state = 351;
				this.match(WGSLParser.T__1);
				}
			}

			this.state = 354;
			this.match(WGSLParser.T__2);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public diagnostic_rule_name(): Diagnostic_rule_nameContext {
		let localctx: Diagnostic_rule_nameContext = new Diagnostic_rule_nameContext(this, this._ctx, this.state);
		this.enterRule(localctx, 28, WGSLParser.RULE_diagnostic_rule_name);
		try {
			this.state = 360;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 33, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 356;
				this.match(WGSLParser.Ident_pattern_token);
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 357;
				this.match(WGSLParser.Ident_pattern_token);
				this.state = 358;
				this.match(WGSLParser.T__25);
				this.state = 359;
				this.match(WGSLParser.Ident_pattern_token);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public expression(): ExpressionContext {
		let localctx: ExpressionContext = new ExpressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 30, WGSLParser.RULE_expression);
		let _la: number;
		try {
			this.state = 396;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 36, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 362;
				this.unary_expression();
				this.state = 363;
				this.bitwise_expression_post_unary_expression();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 365;
				this.unary_expression();
				this.state = 366;
				this.relational_expression_post_unary_expression();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 368;
				this.unary_expression();
				this.state = 369;
				this.relational_expression_post_unary_expression();
				this.state = 370;
				this.match(WGSLParser.T__30);
				this.state = 371;
				this.unary_expression();
				this.state = 372;
				this.relational_expression_post_unary_expression();
				this.state = 379;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===31) {
					{
					{
					this.state = 373;
					this.match(WGSLParser.T__30);
					this.state = 374;
					this.unary_expression();
					this.state = 375;
					this.relational_expression_post_unary_expression();
					}
					}
					this.state = 381;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 382;
				this.unary_expression();
				this.state = 383;
				this.relational_expression_post_unary_expression();
				this.state = 384;
				this.match(WGSLParser.T__31);
				this.state = 385;
				this.unary_expression();
				this.state = 386;
				this.relational_expression_post_unary_expression();
				this.state = 393;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===32) {
					{
					{
					this.state = 387;
					this.match(WGSLParser.T__31);
					this.state = 388;
					this.unary_expression();
					this.state = 389;
					this.relational_expression_post_unary_expression();
					}
					}
					this.state = 395;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public float_literal(): Float_literalContext {
		let localctx: Float_literalContext = new Float_literalContext(this, this._ctx, this.state);
		this.enterRule(localctx, 32, WGSLParser.RULE_float_literal);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 398;
			_la = this._input.LA(1);
			if(!(_la===74 || _la===76)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public for_init(): For_initContext {
		let localctx: For_initContext = new For_initContext(this, this._ctx, this.state);
		this.enterRule(localctx, 34, WGSLParser.RULE_for_init);
		try {
			this.state = 406;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 37, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 400;
				this.ident();
				this.state = 401;
				this.template_elaborated_ident_post_ident();
				this.state = 402;
				this.argument_expression_list();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 404;
				this.variable_or_value_statement();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 405;
				this.variable_updating_statement();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public for_update(): For_updateContext {
		let localctx: For_updateContext = new For_updateContext(this, this._ctx, this.state);
		this.enterRule(localctx, 36, WGSLParser.RULE_for_update);
		try {
			this.state = 413;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 38, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 408;
				this.ident();
				this.state = 409;
				this.template_elaborated_ident_post_ident();
				this.state = 410;
				this.argument_expression_list();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 412;
				this.variable_updating_statement();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public global_decl(): Global_declContext {
		let localctx: Global_declContext = new Global_declContext(this, this._ctx, this.state);
		this.enterRule(localctx, 38, WGSLParser.RULE_global_decl);
		let _la: number;
		try {
			let _alt: number;
			this.state = 551;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 57, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 418;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 415;
					this.attribute();
					}
					}
					this.state = 420;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 421;
				this.match(WGSLParser.T__32);
				this.state = 422;
				this.ident();
				this.state = 423;
				this.match(WGSLParser.T__0);
				this.state = 443;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5 || _la===70 || _la===71) {
					{
					this.state = 427;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===5) {
						{
						{
						this.state = 424;
						this.attribute();
						}
						}
						this.state = 429;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 430;
					this.ident();
					this.state = 431;
					this.match(WGSLParser.T__33);
					this.state = 432;
					this.type_specifier();
					this.state = 437;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 41, this._ctx);
					while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
						if (_alt === 1) {
							{
							{
							this.state = 433;
							this.match(WGSLParser.T__1);
							this.state = 434;
							this.param();
							}
							}
						}
						this.state = 439;
						this._errHandler.sync(this);
						_alt = this._interp.adaptivePredict(this._input, 41, this._ctx);
					}
					this.state = 441;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===2) {
						{
						this.state = 440;
						this.match(WGSLParser.T__1);
						}
					}

					}
				}

				this.state = 445;
				this.match(WGSLParser.T__2);
				this.state = 456;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===35) {
					{
					this.state = 446;
					this.match(WGSLParser.T__34);
					this.state = 450;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===5) {
						{
						{
						this.state = 447;
						this.attribute();
						}
						}
						this.state = 452;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 453;
					this.ident();
					this.state = 454;
					this.template_elaborated_ident_post_ident();
					}
				}

				this.state = 461;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 458;
					this.attribute();
					}
					}
					this.state = 463;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 464;
				this.match(WGSLParser.T__28);
				this.state = 468;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while ((((_la) & ~0x1F) === 0 && ((1 << _la) & 541066274) !== 0) || ((((_la - 36)) & ~0x1F) === 0 && ((1 << (_la - 36)) & 575122443) !== 0) || ((((_la - 70)) & ~0x1F) === 0 && ((1 << (_la - 70)) & 12291) !== 0)) {
					{
					{
					this.state = 465;
					this.statement();
					}
					}
					this.state = 470;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 471;
				this.match(WGSLParser.T__29);
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 476;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 473;
					this.attribute();
					}
					}
					this.state = 478;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 479;
				this.match(WGSLParser.T__35);
				this.state = 494;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===68) {
					{
					this.state = 480;
					this.template_args_start();
					this.state = 481;
					this.expression();
					this.state = 486;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 49, this._ctx);
					while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
						if (_alt === 1) {
							{
							{
							this.state = 482;
							this.match(WGSLParser.T__1);
							this.state = 483;
							this.expression();
							}
							}
						}
						this.state = 488;
						this._errHandler.sync(this);
						_alt = this._interp.adaptivePredict(this._input, 49, this._ctx);
					}
					this.state = 490;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===2) {
						{
						this.state = 489;
						this.match(WGSLParser.T__1);
						}
					}

					this.state = 492;
					this.template_args_end();
					}
				}

				this.state = 496;
				this.optionally_typed_ident();
				this.state = 499;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===4) {
					{
					this.state = 497;
					this.match(WGSLParser.T__3);
					this.state = 498;
					this.expression();
					}
				}

				this.state = 501;
				this.match(WGSLParser.T__36);
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 503;
				this.global_value_decl();
				this.state = 504;
				this.match(WGSLParser.T__36);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 506;
				this.match(WGSLParser.T__36);
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 507;
				this.match(WGSLParser.T__37);
				this.state = 508;
				this.ident();
				this.state = 509;
				this.match(WGSLParser.T__3);
				this.state = 510;
				this.ident();
				this.state = 511;
				this.template_elaborated_ident_post_ident();
				this.state = 512;
				this.match(WGSLParser.T__36);
				}
				break;
			case 6:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 514;
				this.match(WGSLParser.T__38);
				this.state = 515;
				this.expression();
				this.state = 516;
				this.match(WGSLParser.T__36);
				}
				break;
			case 7:
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 518;
				this.match(WGSLParser.T__39);
				this.state = 519;
				this.ident();
				this.state = 520;
				this.match(WGSLParser.T__28);
				this.state = 524;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 521;
					this.attribute();
					}
					}
					this.state = 526;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 527;
				this.member_ident();
				this.state = 528;
				this.match(WGSLParser.T__33);
				this.state = 529;
				this.type_specifier();
				this.state = 543;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 55, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 530;
						this.match(WGSLParser.T__1);
						this.state = 534;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
						while (_la===5) {
							{
							{
							this.state = 531;
							this.attribute();
							}
							}
							this.state = 536;
							this._errHandler.sync(this);
							_la = this._input.LA(1);
						}
						this.state = 537;
						this.member_ident();
						this.state = 538;
						this.match(WGSLParser.T__33);
						this.state = 539;
						this.type_specifier();
						}
						}
					}
					this.state = 545;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 55, this._ctx);
				}
				this.state = 547;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 546;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 549;
				this.match(WGSLParser.T__29);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public global_directive(): Global_directiveContext {
		let localctx: Global_directiveContext = new Global_directiveContext(this, this._ctx, this.state);
		this.enterRule(localctx, 40, WGSLParser.RULE_global_directive);
		let _la: number;
		try {
			let _alt: number;
			this.state = 590;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 11:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 553;
				this.match(WGSLParser.T__10);
				this.state = 554;
				this.match(WGSLParser.T__0);
				this.state = 555;
				this.match(WGSLParser.Severity_control_name);
				this.state = 556;
				this.match(WGSLParser.T__1);
				this.state = 557;
				this.diagnostic_rule_name();
				this.state = 559;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 558;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 561;
				this.match(WGSLParser.T__2);
				this.state = 562;
				this.match(WGSLParser.T__36);
				}
				break;
			case 41:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 564;
				this.match(WGSLParser.T__40);
				this.state = 565;
				this.match(WGSLParser.Ident_pattern_token);
				this.state = 570;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 59, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 566;
						this.match(WGSLParser.T__1);
						this.state = 567;
						this.match(WGSLParser.Ident_pattern_token);
						}
						}
					}
					this.state = 572;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 59, this._ctx);
				}
				this.state = 574;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 573;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 576;
				this.match(WGSLParser.T__36);
				}
				break;
			case 42:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 577;
				this.match(WGSLParser.T__41);
				this.state = 578;
				this.match(WGSLParser.Ident_pattern_token);
				this.state = 583;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 61, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 579;
						this.match(WGSLParser.T__1);
						this.state = 580;
						this.match(WGSLParser.Ident_pattern_token);
						}
						}
					}
					this.state = 585;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 61, this._ctx);
				}
				this.state = 587;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 586;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 589;
				this.match(WGSLParser.T__36);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public global_value_decl(): Global_value_declContext {
		let localctx: Global_value_declContext = new Global_value_declContext(this, this._ctx, this.state);
		this.enterRule(localctx, 42, WGSLParser.RULE_global_value_decl);
		let _la: number;
		try {
			this.state = 609;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 5:
			case 43:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 595;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 592;
					this.attribute();
					}
					}
					this.state = 597;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 598;
				this.match(WGSLParser.T__42);
				this.state = 599;
				this.optionally_typed_ident();
				this.state = 602;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===4) {
					{
					this.state = 600;
					this.match(WGSLParser.T__3);
					this.state = 601;
					this.expression();
					}
				}

				}
				break;
			case 10:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 604;
				this.match(WGSLParser.T__9);
				this.state = 605;
				this.optionally_typed_ident();
				this.state = 606;
				this.match(WGSLParser.T__3);
				this.state = 607;
				this.expression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ident(): IdentContext {
		let localctx: IdentContext = new IdentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 44, WGSLParser.RULE_ident);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 611;
			_la = this._input.LA(1);
			if(!(_la===70 || _la===71)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public int_literal(): Int_literalContext {
		let localctx: Int_literalContext = new Int_literalContext(this, this._ctx, this.state);
		this.enterRule(localctx, 46, WGSLParser.RULE_int_literal);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 613;
			_la = this._input.LA(1);
			if(!(_la===75 || _la===77)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public lhs_expression(): Lhs_expressionContext {
		let localctx: Lhs_expressionContext = new Lhs_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 48, WGSLParser.RULE_lhs_expression);
		let _la: number;
		try {
			this.state = 623;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 70:
			case 71:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 615;
				this.core_lhs_expression();
				this.state = 617;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===26 || _la===27) {
					{
					this.state = 616;
					this.component_or_swizzle_specifier();
					}
				}

				}
				break;
			case 22:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 619;
				this.match(WGSLParser.T__21);
				this.state = 620;
				this.lhs_expression();
				}
				break;
			case 65:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 621;
				this.match(WGSLParser.Star);
				this.state = 622;
				this.lhs_expression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public literal(): LiteralContext {
		let localctx: LiteralContext = new LiteralContext(this, this._ctx, this.state);
		this.enterRule(localctx, 50, WGSLParser.RULE_literal);
		try {
			this.state = 628;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 72:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 625;
				this.match(WGSLParser.Bool_literal);
				}
				break;
			case 74:
			case 76:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 626;
				this.float_literal();
				}
				break;
			case 75:
			case 77:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 627;
				this.int_literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public member_ident(): Member_identContext {
		let localctx: Member_identContext = new Member_identContext(this, this._ctx, this.state);
		this.enterRule(localctx, 52, WGSLParser.RULE_member_ident);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 630;
			this.match(WGSLParser.Ident_pattern_token);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public optionally_typed_ident(): Optionally_typed_identContext {
		let localctx: Optionally_typed_identContext = new Optionally_typed_identContext(this, this._ctx, this.state);
		this.enterRule(localctx, 54, WGSLParser.RULE_optionally_typed_ident);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 632;
			this.ident();
			this.state = 635;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===34) {
				{
				this.state = 633;
				this.match(WGSLParser.T__33);
				this.state = 634;
				this.type_specifier();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public param(): ParamContext {
		let localctx: ParamContext = new ParamContext(this, this._ctx, this.state);
		this.enterRule(localctx, 56, WGSLParser.RULE_param);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 640;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===5) {
				{
				{
				this.state = 637;
				this.attribute();
				}
				}
				this.state = 642;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 643;
			this.ident();
			this.state = 644;
			this.match(WGSLParser.T__33);
			this.state = 645;
			this.type_specifier();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public primary_expression(): Primary_expressionContext {
		let localctx: Primary_expressionContext = new Primary_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 58, WGSLParser.RULE_primary_expression);
		let _la: number;
		try {
			let _alt: number;
			this.state = 673;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 75, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 647;
				this.ident();
				this.state = 648;
				this.template_elaborated_ident_post_ident();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 650;
				this.ident();
				this.state = 651;
				this.template_elaborated_ident_post_ident();
				this.state = 652;
				this.match(WGSLParser.T__0);
				this.state = 664;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===1 || _la===22 || ((((_la - 56)) & ~0x1F) === 0 && ((1 << (_la - 56)) & 4047619) !== 0)) {
					{
					this.state = 653;
					this.expression();
					this.state = 658;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 72, this._ctx);
					while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
						if (_alt === 1) {
							{
							{
							this.state = 654;
							this.match(WGSLParser.T__1);
							this.state = 655;
							this.expression();
							}
							}
						}
						this.state = 660;
						this._errHandler.sync(this);
						_alt = this._interp.adaptivePredict(this._input, 72, this._ctx);
					}
					this.state = 662;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===2) {
						{
						this.state = 661;
						this.match(WGSLParser.T__1);
						}
					}

					}
				}

				this.state = 666;
				this.match(WGSLParser.T__2);
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 668;
				this.literal();
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 669;
				this.match(WGSLParser.T__0);
				this.state = 670;
				this.expression();
				this.state = 671;
				this.match(WGSLParser.T__2);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public greater_than(): Greater_thanContext {
		let localctx: Greater_thanContext = new Greater_thanContext(this, this._ctx, this.state);
		this.enterRule(localctx, 60, WGSLParser.RULE_greater_than);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 675;
			this.match(WGSLParser.Right_angle);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public less_than(): Less_thanContext {
		let localctx: Less_thanContext = new Less_thanContext(this, this._ctx, this.state);
		this.enterRule(localctx, 62, WGSLParser.RULE_less_than);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 677;
			this.match(WGSLParser.Left_angle);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public relational_expression_post_unary_expression(): Relational_expression_post_unary_expressionContext {
		let localctx: Relational_expression_post_unary_expressionContext = new Relational_expression_post_unary_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 64, WGSLParser.RULE_relational_expression_post_unary_expression);
		try {
			this.state = 710;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 76, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 679;
				this.shift_expression_post_unary_expression();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 680;
				this.shift_expression_post_unary_expression();
				this.state = 681;
				this.greater_than();
				this.state = 682;
				this.unary_expression();
				this.state = 683;
				this.shift_expression_post_unary_expression();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 685;
				this.shift_expression_post_unary_expression();
				this.state = 686;
				this.match(WGSLParser.Greater_than_equal);
				this.state = 687;
				this.unary_expression();
				this.state = 688;
				this.shift_expression_post_unary_expression();
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 690;
				this.shift_expression_post_unary_expression();
				this.state = 691;
				this.less_than();
				this.state = 692;
				this.unary_expression();
				this.state = 693;
				this.shift_expression_post_unary_expression();
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 695;
				this.shift_expression_post_unary_expression();
				this.state = 696;
				this.match(WGSLParser.Less_than_equal);
				this.state = 697;
				this.unary_expression();
				this.state = 698;
				this.shift_expression_post_unary_expression();
				}
				break;
			case 6:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 700;
				this.shift_expression_post_unary_expression();
				this.state = 701;
				this.match(WGSLParser.T__43);
				this.state = 702;
				this.unary_expression();
				this.state = 703;
				this.shift_expression_post_unary_expression();
				}
				break;
			case 7:
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 705;
				this.shift_expression_post_unary_expression();
				this.state = 706;
				this.match(WGSLParser.T__44);
				this.state = 707;
				this.unary_expression();
				this.state = 708;
				this.shift_expression_post_unary_expression();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public statement(): StatementContext {
		let localctx: StatementContext = new StatementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 66, WGSLParser.RULE_statement);
		let _la: number;
		try {
			let _alt: number;
			this.state = 876;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 99, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 715;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 712;
					this.attribute();
					}
					}
					this.state = 717;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 718;
				this.match(WGSLParser.T__45);
				this.state = 719;
				this.match(WGSLParser.T__0);
				this.state = 721;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 4195330) !== 0) || ((((_la - 36)) & ~0x1F) === 0 && ((1 << (_la - 36)) & 574619649) !== 0) || _la===70 || _la===71) {
					{
					this.state = 720;
					this.for_init();
					}
				}

				this.state = 723;
				this.match(WGSLParser.T__36);
				this.state = 725;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===1 || _la===22 || ((((_la - 56)) & ~0x1F) === 0 && ((1 << (_la - 56)) & 4047619) !== 0)) {
					{
					this.state = 724;
					this.expression();
					}
				}

				this.state = 727;
				this.match(WGSLParser.T__36);
				this.state = 729;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===1 || _la===22 || ((((_la - 61)) & ~0x1F) === 0 && ((1 << (_la - 61)) & 1553) !== 0)) {
					{
					this.state = 728;
					this.for_update();
					}
				}

				this.state = 731;
				this.match(WGSLParser.T__2);
				this.state = 732;
				this.compound_statement();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 736;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 733;
					this.attribute();
					}
					}
					this.state = 738;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 739;
				this.match(WGSLParser.T__46);
				this.state = 740;
				this.expression();
				this.state = 741;
				this.compound_statement();
				this.state = 749;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 82, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 742;
						this.match(WGSLParser.T__47);
						this.state = 743;
						this.match(WGSLParser.T__46);
						this.state = 744;
						this.expression();
						this.state = 745;
						this.compound_statement();
						}
						}
					}
					this.state = 751;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 82, this._ctx);
				}
				this.state = 754;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===48) {
					{
					this.state = 752;
					this.match(WGSLParser.T__47);
					this.state = 753;
					this.compound_statement();
					}
				}

				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 759;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 756;
					this.attribute();
					}
					}
					this.state = 761;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 762;
				this.match(WGSLParser.T__48);
				this.state = 766;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 763;
					this.attribute();
					}
					}
					this.state = 768;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 769;
				this.match(WGSLParser.T__28);
				this.state = 773;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while ((((_la) & ~0x1F) === 0 && ((1 << _la) & 541066274) !== 0) || ((((_la - 36)) & ~0x1F) === 0 && ((1 << (_la - 36)) & 575122443) !== 0) || ((((_la - 70)) & ~0x1F) === 0 && ((1 << (_la - 70)) & 12291) !== 0)) {
					{
					{
					this.state = 770;
					this.statement();
					}
					}
					this.state = 775;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 798;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===50) {
					{
					this.state = 776;
					this.match(WGSLParser.T__49);
					this.state = 780;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===5) {
						{
						{
						this.state = 777;
						this.attribute();
						}
						}
						this.state = 782;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 783;
					this.match(WGSLParser.T__28);
					this.state = 787;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 88, this._ctx);
					while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
						if (_alt === 1) {
							{
							{
							this.state = 784;
							this.statement();
							}
							}
						}
						this.state = 789;
						this._errHandler.sync(this);
						_alt = this._interp.adaptivePredict(this._input, 88, this._ctx);
					}
					this.state = 795;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===82) {
						{
						this.state = 790;
						this.match(WGSLParser.Break_statement);
						this.state = 791;
						this.match(WGSLParser.T__46);
						this.state = 792;
						this.expression();
						this.state = 793;
						this.match(WGSLParser.T__36);
						}
					}

					this.state = 797;
					this.match(WGSLParser.T__29);
					}
				}

				this.state = 800;
				this.match(WGSLParser.T__29);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 804;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 801;
					this.attribute();
					}
					}
					this.state = 806;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 807;
				this.match(WGSLParser.T__50);
				this.state = 808;
				this.expression();
				this.state = 812;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 809;
					this.attribute();
					}
					}
					this.state = 814;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 815;
				this.match(WGSLParser.T__28);
				this.state = 819;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===25 || _la===55) {
					{
					{
					this.state = 816;
					this.switch_clause();
					}
					}
					this.state = 821;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 822;
				this.match(WGSLParser.T__29);
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 827;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5) {
					{
					{
					this.state = 824;
					this.attribute();
					}
					}
					this.state = 829;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 830;
				this.match(WGSLParser.T__51);
				this.state = 831;
				this.expression();
				this.state = 832;
				this.compound_statement();
				}
				break;
			case 6:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 834;
				this.compound_statement();
				}
				break;
			case 7:
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 835;
				this.ident();
				this.state = 836;
				this.template_elaborated_ident_post_ident();
				this.state = 837;
				this.match(WGSLParser.T__0);
				this.state = 849;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===1 || _la===22 || ((((_la - 56)) & ~0x1F) === 0 && ((1 << (_la - 56)) & 4047619) !== 0)) {
					{
					this.state = 838;
					this.expression();
					this.state = 843;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 95, this._ctx);
					while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
						if (_alt === 1) {
							{
							{
							this.state = 839;
							this.match(WGSLParser.T__1);
							this.state = 840;
							this.expression();
							}
							}
						}
						this.state = 845;
						this._errHandler.sync(this);
						_alt = this._interp.adaptivePredict(this._input, 95, this._ctx);
					}
					this.state = 847;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===2) {
						{
						this.state = 846;
						this.match(WGSLParser.T__1);
						}
					}

					}
				}

				this.state = 851;
				this.match(WGSLParser.T__2);
				this.state = 852;
				this.match(WGSLParser.T__36);
				}
				break;
			case 8:
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 854;
				this.variable_or_value_statement();
				this.state = 855;
				this.match(WGSLParser.T__36);
				}
				break;
			case 9:
				this.enterOuterAlt(localctx, 9);
				{
				this.state = 857;
				this.variable_updating_statement();
				this.state = 858;
				this.match(WGSLParser.T__36);
				}
				break;
			case 10:
				this.enterOuterAlt(localctx, 10);
				{
				this.state = 860;
				this.match(WGSLParser.Break_statement);
				this.state = 861;
				this.match(WGSLParser.T__36);
				}
				break;
			case 11:
				this.enterOuterAlt(localctx, 11);
				{
				this.state = 862;
				this.match(WGSLParser.Continue_statement);
				this.state = 863;
				this.match(WGSLParser.T__36);
				}
				break;
			case 12:
				this.enterOuterAlt(localctx, 12);
				{
				this.state = 864;
				this.match(WGSLParser.T__36);
				}
				break;
			case 13:
				this.enterOuterAlt(localctx, 13);
				{
				this.state = 865;
				this.match(WGSLParser.T__38);
				this.state = 866;
				this.expression();
				this.state = 867;
				this.match(WGSLParser.T__36);
				}
				break;
			case 14:
				this.enterOuterAlt(localctx, 14);
				{
				this.state = 869;
				this.match(WGSLParser.T__52);
				this.state = 870;
				this.match(WGSLParser.T__36);
				}
				break;
			case 15:
				this.enterOuterAlt(localctx, 15);
				{
				this.state = 871;
				this.match(WGSLParser.T__53);
				this.state = 873;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===1 || _la===22 || ((((_la - 56)) & ~0x1F) === 0 && ((1 << (_la - 56)) & 4047619) !== 0)) {
					{
					this.state = 872;
					this.expression();
					}
				}

				this.state = 875;
				this.match(WGSLParser.T__36);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public switch_clause(): Switch_clauseContext {
		let localctx: Switch_clauseContext = new Switch_clauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 68, WGSLParser.RULE_switch_clause);
		let _la: number;
		try {
			let _alt: number;
			this.state = 900;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 55:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 878;
				this.match(WGSLParser.T__54);
				this.state = 879;
				this.case_selector();
				this.state = 884;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 100, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 880;
						this.match(WGSLParser.T__1);
						this.state = 881;
						this.case_selector();
						}
						}
					}
					this.state = 886;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 100, this._ctx);
				}
				this.state = 888;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 887;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 891;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===34) {
					{
					this.state = 890;
					this.match(WGSLParser.T__33);
					}
				}

				this.state = 893;
				this.compound_statement();
				}
				break;
			case 25:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 895;
				this.match(WGSLParser.T__24);
				this.state = 897;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===34) {
					{
					this.state = 896;
					this.match(WGSLParser.T__33);
					}
				}

				this.state = 899;
				this.compound_statement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public template_arg_expression(): Template_arg_expressionContext {
		let localctx: Template_arg_expressionContext = new Template_arg_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 70, WGSLParser.RULE_template_arg_expression);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 902;
			this.expression();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext {
		let localctx: Template_elaborated_ident_post_identContext = new Template_elaborated_ident_post_identContext(this, this._ctx, this.state);
		this.enterRule(localctx, 72, WGSLParser.RULE_template_elaborated_ident_post_ident);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 918;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 107, this._ctx) ) {
			case 1:
				{
				this.state = 904;
				this.template_args_start();
				this.state = 905;
				this.template_arg_expression();
				this.state = 910;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 105, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 906;
						this.match(WGSLParser.T__1);
						this.state = 907;
						this.expression();
						}
						}
					}
					this.state = 912;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 105, this._ctx);
				}
				this.state = 914;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 913;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 916;
				this.template_args_end();
				}
				break;
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public translation_unit(): Translation_unitContext {
		let localctx: Translation_unitContext = new Translation_unitContext(this, this._ctx, this.state);
		this.enterRule(localctx, 74, WGSLParser.RULE_translation_unit);
		let _la: number;
		try {
			this.state = 934;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 110, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 923;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (((((_la - 11)) & ~0x1F) === 0 && ((1 << (_la - 11)) & 3221225473) !== 0)) {
					{
					{
					this.state = 920;
					this.global_directive();
					}
					}
					this.state = 925;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 929;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===5 || _la===10 || ((((_la - 33)) & ~0x1F) === 0 && ((1 << (_la - 33)) & 1273) !== 0)) {
					{
					{
					this.state = 926;
					this.global_decl();
					}
					}
					this.state = 931;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 932;
				this.statement();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 933;
				this.expression();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public type_specifier(): Type_specifierContext {
		let localctx: Type_specifierContext = new Type_specifierContext(this, this._ctx, this.state);
		this.enterRule(localctx, 76, WGSLParser.RULE_type_specifier);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 936;
			this.ident();
			this.state = 951;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===68) {
				{
				this.state = 937;
				this.template_args_start();
				this.state = 938;
				this.template_arg_expression();
				this.state = 943;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 111, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 939;
						this.match(WGSLParser.T__1);
						this.state = 940;
						this.expression();
						}
						}
					}
					this.state = 945;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 111, this._ctx);
				}
				this.state = 947;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 946;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 949;
				this.template_args_end();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public unary_expression(): Unary_expressionContext {
		let localctx: Unary_expressionContext = new Unary_expressionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 78, WGSLParser.RULE_unary_expression);
		let _la: number;
		try {
			this.state = 967;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 70:
			case 71:
			case 72:
			case 74:
			case 75:
			case 76:
			case 77:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 953;
				this.primary_expression();
				this.state = 955;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===26 || _la===27) {
					{
					this.state = 954;
					this.component_or_swizzle_specifier();
					}
				}

				}
				break;
			case 56:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 957;
				this.match(WGSLParser.T__55);
				this.state = 958;
				this.unary_expression();
				}
				break;
			case 22:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 959;
				this.match(WGSLParser.T__21);
				this.state = 960;
				this.unary_expression();
				}
				break;
			case 65:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 961;
				this.match(WGSLParser.Star);
				this.state = 962;
				this.unary_expression();
				}
				break;
			case 64:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 963;
				this.match(WGSLParser.Minus);
				this.state = 964;
				this.unary_expression();
				}
				break;
			case 57:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 965;
				this.match(WGSLParser.T__56);
				this.state = 966;
				this.unary_expression();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public variable_decl(): Variable_declContext {
		let localctx: Variable_declContext = new Variable_declContext(this, this._ctx, this.state);
		this.enterRule(localctx, 80, WGSLParser.RULE_variable_decl);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 969;
			this.match(WGSLParser.T__35);
			this.state = 984;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===68) {
				{
				this.state = 970;
				this.template_args_start();
				this.state = 971;
				this.expression();
				this.state = 976;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 116, this._ctx);
				while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
					if (_alt === 1) {
						{
						{
						this.state = 972;
						this.match(WGSLParser.T__1);
						this.state = 973;
						this.expression();
						}
						}
					}
					this.state = 978;
					this._errHandler.sync(this);
					_alt = this._interp.adaptivePredict(this._input, 116, this._ctx);
				}
				this.state = 980;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===2) {
					{
					this.state = 979;
					this.match(WGSLParser.T__1);
					}
				}

				this.state = 982;
				this.template_args_end();
				}
			}

			this.state = 986;
			this.optionally_typed_ident();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public variable_or_value_statement(): Variable_or_value_statementContext {
		let localctx: Variable_or_value_statementContext = new Variable_or_value_statementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 82, WGSLParser.RULE_variable_or_value_statement);
		try {
			this.state = 1003;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 119, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 988;
				this.variable_decl();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 989;
				this.variable_decl();
				this.state = 990;
				this.match(WGSLParser.T__3);
				this.state = 991;
				this.expression();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 993;
				this.match(WGSLParser.T__9);
				this.state = 994;
				this.optionally_typed_ident();
				this.state = 995;
				this.match(WGSLParser.T__3);
				this.state = 996;
				this.expression();
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 998;
				this.match(WGSLParser.T__57);
				this.state = 999;
				this.optionally_typed_ident();
				this.state = 1000;
				this.match(WGSLParser.T__3);
				this.state = 1001;
				this.expression();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public variable_updating_statement(): Variable_updating_statementContext {
		let localctx: Variable_updating_statementContext = new Variable_updating_statementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 84, WGSLParser.RULE_variable_updating_statement);
		let _la: number;
		try {
			this.state = 1018;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 120, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1005;
				this.lhs_expression();
				this.state = 1006;
				_la = this._input.LA(1);
				if(!(_la===4 || _la===73)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1007;
				this.expression();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1009;
				this.lhs_expression();
				this.state = 1010;
				this.match(WGSLParser.T__58);
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1012;
				this.lhs_expression();
				this.state = 1013;
				this.match(WGSLParser.T__59);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1015;
				this.match(WGSLParser.T__60);
				this.state = 1016;
				this.match(WGSLParser.T__3);
				this.state = 1017;
				this.expression();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}

	public static readonly _serializedATN: number[] = [4,1,85,1021,2,0,7,0,
	2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,
	2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,7,14,2,15,7,15,2,16,7,16,2,
	17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,
	7,24,2,25,7,25,2,26,7,26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,
	31,2,32,7,32,2,33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,
	2,39,7,39,2,40,7,40,2,41,7,41,2,42,7,42,1,0,1,0,1,1,1,1,1,2,1,2,1,3,1,3,
	1,4,1,4,1,4,1,4,5,4,99,8,4,10,4,12,4,102,9,4,1,4,3,4,105,8,4,3,4,107,8,
	4,1,4,1,4,1,5,1,5,1,6,1,6,1,6,5,6,116,8,6,10,6,12,6,119,9,6,1,6,1,6,1,6,
	1,6,1,6,5,6,126,8,6,10,6,12,6,129,9,6,5,6,131,8,6,10,6,12,6,134,9,6,1,6,
	1,6,1,6,1,6,3,6,140,8,6,1,7,1,7,1,7,1,7,1,7,3,7,147,8,7,1,7,1,7,1,7,1,7,
	1,7,1,7,1,7,3,7,156,8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,165,8,7,1,7,1,7,
	1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,183,8,7,1,7,
	1,7,1,7,1,7,1,7,1,7,1,7,3,7,192,8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,201,
	8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,212,8,7,1,7,1,7,1,7,1,7,1,7,
	1,7,1,7,1,7,1,7,3,7,223,8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,234,
	8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,245,8,7,1,7,1,7,1,7,1,7,1,7,
	1,7,1,7,1,7,1,7,3,7,256,8,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,1,7,
	3,7,269,8,7,1,7,1,7,3,7,273,8,7,1,8,1,8,1,8,1,8,5,8,279,8,8,10,8,12,8,282,
	9,8,1,8,1,8,1,8,1,8,5,8,288,8,8,10,8,12,8,291,9,8,1,8,1,8,1,8,1,8,5,8,297,
	8,8,10,8,12,8,300,9,8,3,8,302,8,8,1,9,1,9,3,9,306,8,9,1,10,1,10,1,10,3,
	10,311,8,10,1,10,1,10,1,10,3,10,316,8,10,1,10,1,10,1,10,1,10,3,10,322,8,
	10,3,10,324,8,10,1,11,5,11,327,8,11,10,11,12,11,330,9,11,1,11,1,11,5,11,
	334,8,11,10,11,12,11,337,9,11,1,11,1,11,1,12,1,12,1,12,1,12,1,12,3,12,346,
	8,12,1,13,1,13,1,13,1,13,1,13,3,13,353,8,13,1,13,1,13,1,14,1,14,1,14,1,
	14,3,14,361,8,14,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,
	1,15,1,15,1,15,1,15,5,15,378,8,15,10,15,12,15,381,9,15,1,15,1,15,1,15,1,
	15,1,15,1,15,1,15,1,15,1,15,5,15,392,8,15,10,15,12,15,395,9,15,3,15,397,
	8,15,1,16,1,16,1,17,1,17,1,17,1,17,1,17,1,17,3,17,407,8,17,1,18,1,18,1,
	18,1,18,1,18,3,18,414,8,18,1,19,5,19,417,8,19,10,19,12,19,420,9,19,1,19,
	1,19,1,19,1,19,5,19,426,8,19,10,19,12,19,429,9,19,1,19,1,19,1,19,1,19,1,
	19,5,19,436,8,19,10,19,12,19,439,9,19,1,19,3,19,442,8,19,3,19,444,8,19,
	1,19,1,19,1,19,5,19,449,8,19,10,19,12,19,452,9,19,1,19,1,19,1,19,3,19,457,
	8,19,1,19,5,19,460,8,19,10,19,12,19,463,9,19,1,19,1,19,5,19,467,8,19,10,
	19,12,19,470,9,19,1,19,1,19,1,19,5,19,475,8,19,10,19,12,19,478,9,19,1,19,
	1,19,1,19,1,19,1,19,5,19,485,8,19,10,19,12,19,488,9,19,1,19,3,19,491,8,
	19,1,19,1,19,3,19,495,8,19,1,19,1,19,1,19,3,19,500,8,19,1,19,1,19,1,19,
	1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,
	19,1,19,1,19,1,19,5,19,523,8,19,10,19,12,19,526,9,19,1,19,1,19,1,19,1,19,
	1,19,5,19,533,8,19,10,19,12,19,536,9,19,1,19,1,19,1,19,1,19,5,19,542,8,
	19,10,19,12,19,545,9,19,1,19,3,19,548,8,19,1,19,1,19,3,19,552,8,19,1,20,
	1,20,1,20,1,20,1,20,1,20,3,20,560,8,20,1,20,1,20,1,20,1,20,1,20,1,20,1,
	20,5,20,569,8,20,10,20,12,20,572,9,20,1,20,3,20,575,8,20,1,20,1,20,1,20,
	1,20,1,20,5,20,582,8,20,10,20,12,20,585,9,20,1,20,3,20,588,8,20,1,20,3,
	20,591,8,20,1,21,5,21,594,8,21,10,21,12,21,597,9,21,1,21,1,21,1,21,1,21,
	3,21,603,8,21,1,21,1,21,1,21,1,21,1,21,3,21,610,8,21,1,22,1,22,1,23,1,23,
	1,24,1,24,3,24,618,8,24,1,24,1,24,1,24,1,24,3,24,624,8,24,1,25,1,25,1,25,
	3,25,629,8,25,1,26,1,26,1,27,1,27,1,27,3,27,636,8,27,1,28,5,28,639,8,28,
	10,28,12,28,642,9,28,1,28,1,28,1,28,1,28,1,29,1,29,1,29,1,29,1,29,1,29,
	1,29,1,29,1,29,5,29,657,8,29,10,29,12,29,660,9,29,1,29,3,29,663,8,29,3,
	29,665,8,29,1,29,1,29,1,29,1,29,1,29,1,29,1,29,3,29,674,8,29,1,30,1,30,
	1,31,1,31,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,
	32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,
	1,32,1,32,1,32,1,32,3,32,711,8,32,1,33,5,33,714,8,33,10,33,12,33,717,9,
	33,1,33,1,33,1,33,3,33,722,8,33,1,33,1,33,3,33,726,8,33,1,33,1,33,3,33,
	730,8,33,1,33,1,33,1,33,5,33,735,8,33,10,33,12,33,738,9,33,1,33,1,33,1,
	33,1,33,1,33,1,33,1,33,1,33,5,33,748,8,33,10,33,12,33,751,9,33,1,33,1,33,
	3,33,755,8,33,1,33,5,33,758,8,33,10,33,12,33,761,9,33,1,33,1,33,5,33,765,
	8,33,10,33,12,33,768,9,33,1,33,1,33,5,33,772,8,33,10,33,12,33,775,9,33,
	1,33,1,33,5,33,779,8,33,10,33,12,33,782,9,33,1,33,1,33,5,33,786,8,33,10,
	33,12,33,789,9,33,1,33,1,33,1,33,1,33,1,33,3,33,796,8,33,1,33,3,33,799,
	8,33,1,33,1,33,5,33,803,8,33,10,33,12,33,806,9,33,1,33,1,33,1,33,5,33,811,
	8,33,10,33,12,33,814,9,33,1,33,1,33,5,33,818,8,33,10,33,12,33,821,9,33,
	1,33,1,33,1,33,5,33,826,8,33,10,33,12,33,829,9,33,1,33,1,33,1,33,1,33,1,
	33,1,33,1,33,1,33,1,33,1,33,1,33,5,33,842,8,33,10,33,12,33,845,9,33,1,33,
	3,33,848,8,33,3,33,850,8,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,
	1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,33,3,33,874,
	8,33,1,33,3,33,877,8,33,1,34,1,34,1,34,1,34,5,34,883,8,34,10,34,12,34,886,
	9,34,1,34,3,34,889,8,34,1,34,3,34,892,8,34,1,34,1,34,1,34,1,34,3,34,898,
	8,34,1,34,3,34,901,8,34,1,35,1,35,1,36,1,36,1,36,1,36,5,36,909,8,36,10,
	36,12,36,912,9,36,1,36,3,36,915,8,36,1,36,1,36,3,36,919,8,36,1,37,5,37,
	922,8,37,10,37,12,37,925,9,37,1,37,5,37,928,8,37,10,37,12,37,931,9,37,1,
	37,1,37,3,37,935,8,37,1,38,1,38,1,38,1,38,1,38,5,38,942,8,38,10,38,12,38,
	945,9,38,1,38,3,38,948,8,38,1,38,1,38,3,38,952,8,38,1,39,1,39,3,39,956,
	8,39,1,39,1,39,1,39,1,39,1,39,1,39,1,39,1,39,1,39,1,39,3,39,968,8,39,1,
	40,1,40,1,40,1,40,1,40,5,40,975,8,40,10,40,12,40,978,9,40,1,40,3,40,981,
	8,40,1,40,1,40,3,40,985,8,40,1,40,1,40,1,41,1,41,1,41,1,41,1,41,1,41,1,
	41,1,41,1,41,1,41,1,41,1,41,1,41,1,41,1,41,3,41,1004,8,41,1,42,1,42,1,42,
	1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,1,42,3,42,1019,8,42,1,42,0,
	0,43,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,
	48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,0,6,1,0,63,64,
	1,0,65,67,2,0,4,4,73,73,2,0,74,74,76,76,1,0,70,71,2,0,75,75,77,77,1158,
	0,86,1,0,0,0,2,88,1,0,0,0,4,90,1,0,0,0,6,92,1,0,0,0,8,94,1,0,0,0,10,110,
	1,0,0,0,12,139,1,0,0,0,14,272,1,0,0,0,16,301,1,0,0,0,18,305,1,0,0,0,20,
	323,1,0,0,0,22,328,1,0,0,0,24,345,1,0,0,0,26,347,1,0,0,0,28,360,1,0,0,0,
	30,396,1,0,0,0,32,398,1,0,0,0,34,406,1,0,0,0,36,413,1,0,0,0,38,551,1,0,
	0,0,40,590,1,0,0,0,42,609,1,0,0,0,44,611,1,0,0,0,46,613,1,0,0,0,48,623,
	1,0,0,0,50,628,1,0,0,0,52,630,1,0,0,0,54,632,1,0,0,0,56,640,1,0,0,0,58,
	673,1,0,0,0,60,675,1,0,0,0,62,677,1,0,0,0,64,710,1,0,0,0,66,876,1,0,0,0,
	68,900,1,0,0,0,70,902,1,0,0,0,72,918,1,0,0,0,74,934,1,0,0,0,76,936,1,0,
	0,0,78,967,1,0,0,0,80,969,1,0,0,0,82,1003,1,0,0,0,84,1018,1,0,0,0,86,87,
	5,68,0,0,87,1,1,0,0,0,88,89,5,69,0,0,89,3,1,0,0,0,90,91,7,0,0,0,91,5,1,
	0,0,0,92,93,7,1,0,0,93,7,1,0,0,0,94,106,5,1,0,0,95,100,3,30,15,0,96,97,
	5,2,0,0,97,99,3,30,15,0,98,96,1,0,0,0,99,102,1,0,0,0,100,98,1,0,0,0,100,
	101,1,0,0,0,101,104,1,0,0,0,102,100,1,0,0,0,103,105,5,2,0,0,104,103,1,0,
	0,0,104,105,1,0,0,0,105,107,1,0,0,0,106,95,1,0,0,0,106,107,1,0,0,0,107,
	108,1,0,0,0,108,109,5,3,0,0,109,9,1,0,0,0,110,111,7,2,0,0,111,11,1,0,0,
	0,112,113,3,6,3,0,113,114,3,78,39,0,114,116,1,0,0,0,115,112,1,0,0,0,116,
	119,1,0,0,0,117,115,1,0,0,0,117,118,1,0,0,0,118,132,1,0,0,0,119,117,1,0,
	0,0,120,121,3,4,2,0,121,127,3,78,39,0,122,123,3,6,3,0,123,124,3,78,39,0,
	124,126,1,0,0,0,125,122,1,0,0,0,126,129,1,0,0,0,127,125,1,0,0,0,127,128,
	1,0,0,0,128,131,1,0,0,0,129,127,1,0,0,0,130,120,1,0,0,0,131,134,1,0,0,0,
	132,130,1,0,0,0,132,133,1,0,0,0,133,140,1,0,0,0,134,132,1,0,0,0,135,136,
	5,80,0,0,136,140,3,78,39,0,137,138,5,81,0,0,138,140,3,78,39,0,139,117,1,
	0,0,0,139,135,1,0,0,0,139,137,1,0,0,0,140,13,1,0,0,0,141,142,5,5,0,0,142,
	143,5,6,0,0,143,144,5,1,0,0,144,146,3,30,15,0,145,147,5,2,0,0,146,145,1,
	0,0,0,146,147,1,0,0,0,147,148,1,0,0,0,148,149,5,3,0,0,149,273,1,0,0,0,150,
	151,5,5,0,0,151,152,5,7,0,0,152,153,5,1,0,0,153,155,3,30,15,0,154,156,5,
	2,0,0,155,154,1,0,0,0,155,156,1,0,0,0,156,157,1,0,0,0,157,158,5,3,0,0,158,
	273,1,0,0,0,159,160,5,5,0,0,160,161,5,8,0,0,161,162,5,1,0,0,162,164,3,30,
	15,0,163,165,5,2,0,0,164,163,1,0,0,0,164,165,1,0,0,0,165,166,1,0,0,0,166,
	167,5,3,0,0,167,273,1,0,0,0,168,169,5,5,0,0,169,273,5,9,0,0,170,171,5,5,
	0,0,171,273,5,10,0,0,172,173,5,5,0,0,173,174,5,11,0,0,174,273,3,26,13,0,
	175,176,5,5,0,0,176,273,5,12,0,0,177,178,5,5,0,0,178,179,5,13,0,0,179,180,
	5,1,0,0,180,182,3,30,15,0,181,183,5,2,0,0,182,181,1,0,0,0,182,183,1,0,0,
	0,183,184,1,0,0,0,184,185,5,3,0,0,185,273,1,0,0,0,186,187,5,5,0,0,187,188,
	5,14,0,0,188,189,5,1,0,0,189,191,3,30,15,0,190,192,5,2,0,0,191,190,1,0,
	0,0,191,192,1,0,0,0,192,193,1,0,0,0,193,194,5,3,0,0,194,273,1,0,0,0,195,
	196,5,5,0,0,196,197,5,15,0,0,197,198,5,1,0,0,198,200,3,30,15,0,199,201,
	5,2,0,0,200,199,1,0,0,0,200,201,1,0,0,0,201,202,1,0,0,0,202,203,5,3,0,0,
	203,273,1,0,0,0,204,205,5,5,0,0,205,206,5,15,0,0,206,207,5,1,0,0,207,208,
	3,30,15,0,208,209,5,2,0,0,209,211,3,30,15,0,210,212,5,2,0,0,211,210,1,0,
	0,0,211,212,1,0,0,0,212,213,1,0,0,0,213,214,5,3,0,0,214,273,1,0,0,0,215,
	216,5,5,0,0,216,273,5,16,0,0,217,218,5,5,0,0,218,219,5,17,0,0,219,220,5,
	1,0,0,220,222,3,30,15,0,221,223,5,2,0,0,222,221,1,0,0,0,222,223,1,0,0,0,
	223,224,1,0,0,0,224,225,5,3,0,0,225,273,1,0,0,0,226,227,5,5,0,0,227,273,
	5,18,0,0,228,229,5,5,0,0,229,230,5,19,0,0,230,231,5,1,0,0,231,233,3,30,
	15,0,232,234,5,2,0,0,233,232,1,0,0,0,233,234,1,0,0,0,234,235,1,0,0,0,235,
	236,5,3,0,0,236,273,1,0,0,0,237,238,5,5,0,0,238,273,5,20,0,0,239,240,5,
	5,0,0,240,241,5,21,0,0,241,242,5,1,0,0,242,244,3,30,15,0,243,245,5,2,0,
	0,244,243,1,0,0,0,244,245,1,0,0,0,245,246,1,0,0,0,246,247,5,3,0,0,247,273,
	1,0,0,0,248,249,5,5,0,0,249,250,5,21,0,0,250,251,5,1,0,0,251,252,3,30,15,
	0,252,253,5,2,0,0,253,255,3,30,15,0,254,256,5,2,0,0,255,254,1,0,0,0,255,
	256,1,0,0,0,256,257,1,0,0,0,257,258,5,3,0,0,258,273,1,0,0,0,259,260,5,5,
	0,0,260,261,5,21,0,0,261,262,5,1,0,0,262,263,3,30,15,0,263,264,5,2,0,0,
	264,265,3,30,15,0,265,266,5,2,0,0,266,268,3,30,15,0,267,269,5,2,0,0,268,
	267,1,0,0,0,268,269,1,0,0,0,269,270,1,0,0,0,270,271,5,3,0,0,271,273,1,0,
	0,0,272,141,1,0,0,0,272,150,1,0,0,0,272,159,1,0,0,0,272,168,1,0,0,0,272,
	170,1,0,0,0,272,172,1,0,0,0,272,175,1,0,0,0,272,177,1,0,0,0,272,186,1,0,
	0,0,272,195,1,0,0,0,272,204,1,0,0,0,272,215,1,0,0,0,272,217,1,0,0,0,272,
	226,1,0,0,0,272,228,1,0,0,0,272,237,1,0,0,0,272,239,1,0,0,0,272,248,1,0,
	0,0,272,259,1,0,0,0,273,15,1,0,0,0,274,275,5,22,0,0,275,280,3,78,39,0,276,
	277,5,22,0,0,277,279,3,78,39,0,278,276,1,0,0,0,279,282,1,0,0,0,280,278,
	1,0,0,0,280,281,1,0,0,0,281,302,1,0,0,0,282,280,1,0,0,0,283,284,5,23,0,
	0,284,289,3,78,39,0,285,286,5,23,0,0,286,288,3,78,39,0,287,285,1,0,0,0,
	288,291,1,0,0,0,289,287,1,0,0,0,289,290,1,0,0,0,290,302,1,0,0,0,291,289,
	1,0,0,0,292,293,5,24,0,0,293,298,3,78,39,0,294,295,5,24,0,0,295,297,3,78,
	39,0,296,294,1,0,0,0,297,300,1,0,0,0,298,296,1,0,0,0,298,299,1,0,0,0,299,
	302,1,0,0,0,300,298,1,0,0,0,301,274,1,0,0,0,301,283,1,0,0,0,301,292,1,0,
	0,0,302,17,1,0,0,0,303,306,3,30,15,0,304,306,5,25,0,0,305,303,1,0,0,0,305,
	304,1,0,0,0,306,19,1,0,0,0,307,308,5,26,0,0,308,310,3,52,26,0,309,311,3,
	20,10,0,310,309,1,0,0,0,310,311,1,0,0,0,311,324,1,0,0,0,312,313,5,26,0,
	0,313,315,5,85,0,0,314,316,3,20,10,0,315,314,1,0,0,0,315,316,1,0,0,0,316,
	324,1,0,0,0,317,318,5,27,0,0,318,319,3,30,15,0,319,321,5,28,0,0,320,322,
	3,20,10,0,321,320,1,0,0,0,321,322,1,0,0,0,322,324,1,0,0,0,323,307,1,0,0,
	0,323,312,1,0,0,0,323,317,1,0,0,0,324,21,1,0,0,0,325,327,3,14,7,0,326,325,
	1,0,0,0,327,330,1,0,0,0,328,326,1,0,0,0,328,329,1,0,0,0,329,331,1,0,0,0,
	330,328,1,0,0,0,331,335,5,29,0,0,332,334,3,66,33,0,333,332,1,0,0,0,334,
	337,1,0,0,0,335,333,1,0,0,0,335,336,1,0,0,0,336,338,1,0,0,0,337,335,1,0,
	0,0,338,339,5,30,0,0,339,23,1,0,0,0,340,346,3,44,22,0,341,342,5,1,0,0,342,
	343,3,48,24,0,343,344,5,3,0,0,344,346,1,0,0,0,345,340,1,0,0,0,345,341,1,
	0,0,0,346,25,1,0,0,0,347,348,5,1,0,0,348,349,5,84,0,0,349,350,5,2,0,0,350,
	352,3,28,14,0,351,353,5,2,0,0,352,351,1,0,0,0,352,353,1,0,0,0,353,354,1,
	0,0,0,354,355,5,3,0,0,355,27,1,0,0,0,356,361,5,71,0,0,357,358,5,71,0,0,
	358,359,5,26,0,0,359,361,5,71,0,0,360,356,1,0,0,0,360,357,1,0,0,0,361,29,
	1,0,0,0,362,363,3,78,39,0,363,364,3,16,8,0,364,397,1,0,0,0,365,366,3,78,
	39,0,366,367,3,64,32,0,367,397,1,0,0,0,368,369,3,78,39,0,369,370,3,64,32,
	0,370,371,5,31,0,0,371,372,3,78,39,0,372,379,3,64,32,0,373,374,5,31,0,0,
	374,375,3,78,39,0,375,376,3,64,32,0,376,378,1,0,0,0,377,373,1,0,0,0,378,
	381,1,0,0,0,379,377,1,0,0,0,379,380,1,0,0,0,380,397,1,0,0,0,381,379,1,0,
	0,0,382,383,3,78,39,0,383,384,3,64,32,0,384,385,5,32,0,0,385,386,3,78,39,
	0,386,393,3,64,32,0,387,388,5,32,0,0,388,389,3,78,39,0,389,390,3,64,32,
	0,390,392,1,0,0,0,391,387,1,0,0,0,392,395,1,0,0,0,393,391,1,0,0,0,393,394,
	1,0,0,0,394,397,1,0,0,0,395,393,1,0,0,0,396,362,1,0,0,0,396,365,1,0,0,0,
	396,368,1,0,0,0,396,382,1,0,0,0,397,31,1,0,0,0,398,399,7,3,0,0,399,33,1,
	0,0,0,400,401,3,44,22,0,401,402,3,72,36,0,402,403,3,8,4,0,403,407,1,0,0,
	0,404,407,3,82,41,0,405,407,3,84,42,0,406,400,1,0,0,0,406,404,1,0,0,0,406,
	405,1,0,0,0,407,35,1,0,0,0,408,409,3,44,22,0,409,410,3,72,36,0,410,411,
	3,8,4,0,411,414,1,0,0,0,412,414,3,84,42,0,413,408,1,0,0,0,413,412,1,0,0,
	0,414,37,1,0,0,0,415,417,3,14,7,0,416,415,1,0,0,0,417,420,1,0,0,0,418,416,
	1,0,0,0,418,419,1,0,0,0,419,421,1,0,0,0,420,418,1,0,0,0,421,422,5,33,0,
	0,422,423,3,44,22,0,423,443,5,1,0,0,424,426,3,14,7,0,425,424,1,0,0,0,426,
	429,1,0,0,0,427,425,1,0,0,0,427,428,1,0,0,0,428,430,1,0,0,0,429,427,1,0,
	0,0,430,431,3,44,22,0,431,432,5,34,0,0,432,437,3,76,38,0,433,434,5,2,0,
	0,434,436,3,56,28,0,435,433,1,0,0,0,436,439,1,0,0,0,437,435,1,0,0,0,437,
	438,1,0,0,0,438,441,1,0,0,0,439,437,1,0,0,0,440,442,5,2,0,0,441,440,1,0,
	0,0,441,442,1,0,0,0,442,444,1,0,0,0,443,427,1,0,0,0,443,444,1,0,0,0,444,
	445,1,0,0,0,445,456,5,3,0,0,446,450,5,35,0,0,447,449,3,14,7,0,448,447,1,
	0,0,0,449,452,1,0,0,0,450,448,1,0,0,0,450,451,1,0,0,0,451,453,1,0,0,0,452,
	450,1,0,0,0,453,454,3,44,22,0,454,455,3,72,36,0,455,457,1,0,0,0,456,446,
	1,0,0,0,456,457,1,0,0,0,457,461,1,0,0,0,458,460,3,14,7,0,459,458,1,0,0,
	0,460,463,1,0,0,0,461,459,1,0,0,0,461,462,1,0,0,0,462,464,1,0,0,0,463,461,
	1,0,0,0,464,468,5,29,0,0,465,467,3,66,33,0,466,465,1,0,0,0,467,470,1,0,
	0,0,468,466,1,0,0,0,468,469,1,0,0,0,469,471,1,0,0,0,470,468,1,0,0,0,471,
	472,5,30,0,0,472,552,1,0,0,0,473,475,3,14,7,0,474,473,1,0,0,0,475,478,1,
	0,0,0,476,474,1,0,0,0,476,477,1,0,0,0,477,479,1,0,0,0,478,476,1,0,0,0,479,
	494,5,36,0,0,480,481,3,0,0,0,481,486,3,30,15,0,482,483,5,2,0,0,483,485,
	3,30,15,0,484,482,1,0,0,0,485,488,1,0,0,0,486,484,1,0,0,0,486,487,1,0,0,
	0,487,490,1,0,0,0,488,486,1,0,0,0,489,491,5,2,0,0,490,489,1,0,0,0,490,491,
	1,0,0,0,491,492,1,0,0,0,492,493,3,2,1,0,493,495,1,0,0,0,494,480,1,0,0,0,
	494,495,1,0,0,0,495,496,1,0,0,0,496,499,3,54,27,0,497,498,5,4,0,0,498,500,
	3,30,15,0,499,497,1,0,0,0,499,500,1,0,0,0,500,501,1,0,0,0,501,502,5,37,
	0,0,502,552,1,0,0,0,503,504,3,42,21,0,504,505,5,37,0,0,505,552,1,0,0,0,
	506,552,5,37,0,0,507,508,5,38,0,0,508,509,3,44,22,0,509,510,5,4,0,0,510,
	511,3,44,22,0,511,512,3,72,36,0,512,513,5,37,0,0,513,552,1,0,0,0,514,515,
	5,39,0,0,515,516,3,30,15,0,516,517,5,37,0,0,517,552,1,0,0,0,518,519,5,40,
	0,0,519,520,3,44,22,0,520,524,5,29,0,0,521,523,3,14,7,0,522,521,1,0,0,0,
	523,526,1,0,0,0,524,522,1,0,0,0,524,525,1,0,0,0,525,527,1,0,0,0,526,524,
	1,0,0,0,527,528,3,52,26,0,528,529,5,34,0,0,529,543,3,76,38,0,530,534,5,
	2,0,0,531,533,3,14,7,0,532,531,1,0,0,0,533,536,1,0,0,0,534,532,1,0,0,0,
	534,535,1,0,0,0,535,537,1,0,0,0,536,534,1,0,0,0,537,538,3,52,26,0,538,539,
	5,34,0,0,539,540,3,76,38,0,540,542,1,0,0,0,541,530,1,0,0,0,542,545,1,0,
	0,0,543,541,1,0,0,0,543,544,1,0,0,0,544,547,1,0,0,0,545,543,1,0,0,0,546,
	548,5,2,0,0,547,546,1,0,0,0,547,548,1,0,0,0,548,549,1,0,0,0,549,550,5,30,
	0,0,550,552,1,0,0,0,551,418,1,0,0,0,551,476,1,0,0,0,551,503,1,0,0,0,551,
	506,1,0,0,0,551,507,1,0,0,0,551,514,1,0,0,0,551,518,1,0,0,0,552,39,1,0,
	0,0,553,554,5,11,0,0,554,555,5,1,0,0,555,556,5,84,0,0,556,557,5,2,0,0,557,
	559,3,28,14,0,558,560,5,2,0,0,559,558,1,0,0,0,559,560,1,0,0,0,560,561,1,
	0,0,0,561,562,5,3,0,0,562,563,5,37,0,0,563,591,1,0,0,0,564,565,5,41,0,0,
	565,570,5,71,0,0,566,567,5,2,0,0,567,569,5,71,0,0,568,566,1,0,0,0,569,572,
	1,0,0,0,570,568,1,0,0,0,570,571,1,0,0,0,571,574,1,0,0,0,572,570,1,0,0,0,
	573,575,5,2,0,0,574,573,1,0,0,0,574,575,1,0,0,0,575,576,1,0,0,0,576,591,
	5,37,0,0,577,578,5,42,0,0,578,583,5,71,0,0,579,580,5,2,0,0,580,582,5,71,
	0,0,581,579,1,0,0,0,582,585,1,0,0,0,583,581,1,0,0,0,583,584,1,0,0,0,584,
	587,1,0,0,0,585,583,1,0,0,0,586,588,5,2,0,0,587,586,1,0,0,0,587,588,1,0,
	0,0,588,589,1,0,0,0,589,591,5,37,0,0,590,553,1,0,0,0,590,564,1,0,0,0,590,
	577,1,0,0,0,591,41,1,0,0,0,592,594,3,14,7,0,593,592,1,0,0,0,594,597,1,0,
	0,0,595,593,1,0,0,0,595,596,1,0,0,0,596,598,1,0,0,0,597,595,1,0,0,0,598,
	599,5,43,0,0,599,602,3,54,27,0,600,601,5,4,0,0,601,603,3,30,15,0,602,600,
	1,0,0,0,602,603,1,0,0,0,603,610,1,0,0,0,604,605,5,10,0,0,605,606,3,54,27,
	0,606,607,5,4,0,0,607,608,3,30,15,0,608,610,1,0,0,0,609,595,1,0,0,0,609,
	604,1,0,0,0,610,43,1,0,0,0,611,612,7,4,0,0,612,45,1,0,0,0,613,614,7,5,0,
	0,614,47,1,0,0,0,615,617,3,24,12,0,616,618,3,20,10,0,617,616,1,0,0,0,617,
	618,1,0,0,0,618,624,1,0,0,0,619,620,5,22,0,0,620,624,3,48,24,0,621,622,
	5,65,0,0,622,624,3,48,24,0,623,615,1,0,0,0,623,619,1,0,0,0,623,621,1,0,
	0,0,624,49,1,0,0,0,625,629,5,72,0,0,626,629,3,32,16,0,627,629,3,46,23,0,
	628,625,1,0,0,0,628,626,1,0,0,0,628,627,1,0,0,0,629,51,1,0,0,0,630,631,
	5,71,0,0,631,53,1,0,0,0,632,635,3,44,22,0,633,634,5,34,0,0,634,636,3,76,
	38,0,635,633,1,0,0,0,635,636,1,0,0,0,636,55,1,0,0,0,637,639,3,14,7,0,638,
	637,1,0,0,0,639,642,1,0,0,0,640,638,1,0,0,0,640,641,1,0,0,0,641,643,1,0,
	0,0,642,640,1,0,0,0,643,644,3,44,22,0,644,645,5,34,0,0,645,646,3,76,38,
	0,646,57,1,0,0,0,647,648,3,44,22,0,648,649,3,72,36,0,649,674,1,0,0,0,650,
	651,3,44,22,0,651,652,3,72,36,0,652,664,5,1,0,0,653,658,3,30,15,0,654,655,
	5,2,0,0,655,657,3,30,15,0,656,654,1,0,0,0,657,660,1,0,0,0,658,656,1,0,0,
	0,658,659,1,0,0,0,659,662,1,0,0,0,660,658,1,0,0,0,661,663,5,2,0,0,662,661,
	1,0,0,0,662,663,1,0,0,0,663,665,1,0,0,0,664,653,1,0,0,0,664,665,1,0,0,0,
	665,666,1,0,0,0,666,667,5,3,0,0,667,674,1,0,0,0,668,674,3,50,25,0,669,670,
	5,1,0,0,670,671,3,30,15,0,671,672,5,3,0,0,672,674,1,0,0,0,673,647,1,0,0,
	0,673,650,1,0,0,0,673,668,1,0,0,0,673,669,1,0,0,0,674,59,1,0,0,0,675,676,
	5,69,0,0,676,61,1,0,0,0,677,678,5,68,0,0,678,63,1,0,0,0,679,711,3,12,6,
	0,680,681,3,12,6,0,681,682,3,60,30,0,682,683,3,78,39,0,683,684,3,12,6,0,
	684,711,1,0,0,0,685,686,3,12,6,0,686,687,5,78,0,0,687,688,3,78,39,0,688,
	689,3,12,6,0,689,711,1,0,0,0,690,691,3,12,6,0,691,692,3,62,31,0,692,693,
	3,78,39,0,693,694,3,12,6,0,694,711,1,0,0,0,695,696,3,12,6,0,696,697,5,79,
	0,0,697,698,3,78,39,0,698,699,3,12,6,0,699,711,1,0,0,0,700,701,3,12,6,0,
	701,702,5,44,0,0,702,703,3,78,39,0,703,704,3,12,6,0,704,711,1,0,0,0,705,
	706,3,12,6,0,706,707,5,45,0,0,707,708,3,78,39,0,708,709,3,12,6,0,709,711,
	1,0,0,0,710,679,1,0,0,0,710,680,1,0,0,0,710,685,1,0,0,0,710,690,1,0,0,0,
	710,695,1,0,0,0,710,700,1,0,0,0,710,705,1,0,0,0,711,65,1,0,0,0,712,714,
	3,14,7,0,713,712,1,0,0,0,714,717,1,0,0,0,715,713,1,0,0,0,715,716,1,0,0,
	0,716,718,1,0,0,0,717,715,1,0,0,0,718,719,5,46,0,0,719,721,5,1,0,0,720,
	722,3,34,17,0,721,720,1,0,0,0,721,722,1,0,0,0,722,723,1,0,0,0,723,725,5,
	37,0,0,724,726,3,30,15,0,725,724,1,0,0,0,725,726,1,0,0,0,726,727,1,0,0,
	0,727,729,5,37,0,0,728,730,3,36,18,0,729,728,1,0,0,0,729,730,1,0,0,0,730,
	731,1,0,0,0,731,732,5,3,0,0,732,877,3,22,11,0,733,735,3,14,7,0,734,733,
	1,0,0,0,735,738,1,0,0,0,736,734,1,0,0,0,736,737,1,0,0,0,737,739,1,0,0,0,
	738,736,1,0,0,0,739,740,5,47,0,0,740,741,3,30,15,0,741,749,3,22,11,0,742,
	743,5,48,0,0,743,744,5,47,0,0,744,745,3,30,15,0,745,746,3,22,11,0,746,748,
	1,0,0,0,747,742,1,0,0,0,748,751,1,0,0,0,749,747,1,0,0,0,749,750,1,0,0,0,
	750,754,1,0,0,0,751,749,1,0,0,0,752,753,5,48,0,0,753,755,3,22,11,0,754,
	752,1,0,0,0,754,755,1,0,0,0,755,877,1,0,0,0,756,758,3,14,7,0,757,756,1,
	0,0,0,758,761,1,0,0,0,759,757,1,0,0,0,759,760,1,0,0,0,760,762,1,0,0,0,761,
	759,1,0,0,0,762,766,5,49,0,0,763,765,3,14,7,0,764,763,1,0,0,0,765,768,1,
	0,0,0,766,764,1,0,0,0,766,767,1,0,0,0,767,769,1,0,0,0,768,766,1,0,0,0,769,
	773,5,29,0,0,770,772,3,66,33,0,771,770,1,0,0,0,772,775,1,0,0,0,773,771,
	1,0,0,0,773,774,1,0,0,0,774,798,1,0,0,0,775,773,1,0,0,0,776,780,5,50,0,
	0,777,779,3,14,7,0,778,777,1,0,0,0,779,782,1,0,0,0,780,778,1,0,0,0,780,
	781,1,0,0,0,781,783,1,0,0,0,782,780,1,0,0,0,783,787,5,29,0,0,784,786,3,
	66,33,0,785,784,1,0,0,0,786,789,1,0,0,0,787,785,1,0,0,0,787,788,1,0,0,0,
	788,795,1,0,0,0,789,787,1,0,0,0,790,791,5,82,0,0,791,792,5,47,0,0,792,793,
	3,30,15,0,793,794,5,37,0,0,794,796,1,0,0,0,795,790,1,0,0,0,795,796,1,0,
	0,0,796,797,1,0,0,0,797,799,5,30,0,0,798,776,1,0,0,0,798,799,1,0,0,0,799,
	800,1,0,0,0,800,877,5,30,0,0,801,803,3,14,7,0,802,801,1,0,0,0,803,806,1,
	0,0,0,804,802,1,0,0,0,804,805,1,0,0,0,805,807,1,0,0,0,806,804,1,0,0,0,807,
	808,5,51,0,0,808,812,3,30,15,0,809,811,3,14,7,0,810,809,1,0,0,0,811,814,
	1,0,0,0,812,810,1,0,0,0,812,813,1,0,0,0,813,815,1,0,0,0,814,812,1,0,0,0,
	815,819,5,29,0,0,816,818,3,68,34,0,817,816,1,0,0,0,818,821,1,0,0,0,819,
	817,1,0,0,0,819,820,1,0,0,0,820,822,1,0,0,0,821,819,1,0,0,0,822,823,5,30,
	0,0,823,877,1,0,0,0,824,826,3,14,7,0,825,824,1,0,0,0,826,829,1,0,0,0,827,
	825,1,0,0,0,827,828,1,0,0,0,828,830,1,0,0,0,829,827,1,0,0,0,830,831,5,52,
	0,0,831,832,3,30,15,0,832,833,3,22,11,0,833,877,1,0,0,0,834,877,3,22,11,
	0,835,836,3,44,22,0,836,837,3,72,36,0,837,849,5,1,0,0,838,843,3,30,15,0,
	839,840,5,2,0,0,840,842,3,30,15,0,841,839,1,0,0,0,842,845,1,0,0,0,843,841,
	1,0,0,0,843,844,1,0,0,0,844,847,1,0,0,0,845,843,1,0,0,0,846,848,5,2,0,0,
	847,846,1,0,0,0,847,848,1,0,0,0,848,850,1,0,0,0,849,838,1,0,0,0,849,850,
	1,0,0,0,850,851,1,0,0,0,851,852,5,3,0,0,852,853,5,37,0,0,853,877,1,0,0,
	0,854,855,3,82,41,0,855,856,5,37,0,0,856,877,1,0,0,0,857,858,3,84,42,0,
	858,859,5,37,0,0,859,877,1,0,0,0,860,861,5,82,0,0,861,877,5,37,0,0,862,
	863,5,83,0,0,863,877,5,37,0,0,864,877,5,37,0,0,865,866,5,39,0,0,866,867,
	3,30,15,0,867,868,5,37,0,0,868,877,1,0,0,0,869,870,5,53,0,0,870,877,5,37,
	0,0,871,873,5,54,0,0,872,874,3,30,15,0,873,872,1,0,0,0,873,874,1,0,0,0,
	874,875,1,0,0,0,875,877,5,37,0,0,876,715,1,0,0,0,876,736,1,0,0,0,876,759,
	1,0,0,0,876,804,1,0,0,0,876,827,1,0,0,0,876,834,1,0,0,0,876,835,1,0,0,0,
	876,854,1,0,0,0,876,857,1,0,0,0,876,860,1,0,0,0,876,862,1,0,0,0,876,864,
	1,0,0,0,876,865,1,0,0,0,876,869,1,0,0,0,876,871,1,0,0,0,877,67,1,0,0,0,
	878,879,5,55,0,0,879,884,3,18,9,0,880,881,5,2,0,0,881,883,3,18,9,0,882,
	880,1,0,0,0,883,886,1,0,0,0,884,882,1,0,0,0,884,885,1,0,0,0,885,888,1,0,
	0,0,886,884,1,0,0,0,887,889,5,2,0,0,888,887,1,0,0,0,888,889,1,0,0,0,889,
	891,1,0,0,0,890,892,5,34,0,0,891,890,1,0,0,0,891,892,1,0,0,0,892,893,1,
	0,0,0,893,894,3,22,11,0,894,901,1,0,0,0,895,897,5,25,0,0,896,898,5,34,0,
	0,897,896,1,0,0,0,897,898,1,0,0,0,898,899,1,0,0,0,899,901,3,22,11,0,900,
	878,1,0,0,0,900,895,1,0,0,0,901,69,1,0,0,0,902,903,3,30,15,0,903,71,1,0,
	0,0,904,905,3,0,0,0,905,910,3,70,35,0,906,907,5,2,0,0,907,909,3,30,15,0,
	908,906,1,0,0,0,909,912,1,0,0,0,910,908,1,0,0,0,910,911,1,0,0,0,911,914,
	1,0,0,0,912,910,1,0,0,0,913,915,5,2,0,0,914,913,1,0,0,0,914,915,1,0,0,0,
	915,916,1,0,0,0,916,917,3,2,1,0,917,919,1,0,0,0,918,904,1,0,0,0,918,919,
	1,0,0,0,919,73,1,0,0,0,920,922,3,40,20,0,921,920,1,0,0,0,922,925,1,0,0,
	0,923,921,1,0,0,0,923,924,1,0,0,0,924,929,1,0,0,0,925,923,1,0,0,0,926,928,
	3,38,19,0,927,926,1,0,0,0,928,931,1,0,0,0,929,927,1,0,0,0,929,930,1,0,0,
	0,930,935,1,0,0,0,931,929,1,0,0,0,932,935,3,66,33,0,933,935,3,30,15,0,934,
	923,1,0,0,0,934,932,1,0,0,0,934,933,1,0,0,0,935,75,1,0,0,0,936,951,3,44,
	22,0,937,938,3,0,0,0,938,943,3,70,35,0,939,940,5,2,0,0,940,942,3,30,15,
	0,941,939,1,0,0,0,942,945,1,0,0,0,943,941,1,0,0,0,943,944,1,0,0,0,944,947,
	1,0,0,0,945,943,1,0,0,0,946,948,5,2,0,0,947,946,1,0,0,0,947,948,1,0,0,0,
	948,949,1,0,0,0,949,950,3,2,1,0,950,952,1,0,0,0,951,937,1,0,0,0,951,952,
	1,0,0,0,952,77,1,0,0,0,953,955,3,58,29,0,954,956,3,20,10,0,955,954,1,0,
	0,0,955,956,1,0,0,0,956,968,1,0,0,0,957,958,5,56,0,0,958,968,3,78,39,0,
	959,960,5,22,0,0,960,968,3,78,39,0,961,962,5,65,0,0,962,968,3,78,39,0,963,
	964,5,64,0,0,964,968,3,78,39,0,965,966,5,57,0,0,966,968,3,78,39,0,967,953,
	1,0,0,0,967,957,1,0,0,0,967,959,1,0,0,0,967,961,1,0,0,0,967,963,1,0,0,0,
	967,965,1,0,0,0,968,79,1,0,0,0,969,984,5,36,0,0,970,971,3,0,0,0,971,976,
	3,30,15,0,972,973,5,2,0,0,973,975,3,30,15,0,974,972,1,0,0,0,975,978,1,0,
	0,0,976,974,1,0,0,0,976,977,1,0,0,0,977,980,1,0,0,0,978,976,1,0,0,0,979,
	981,5,2,0,0,980,979,1,0,0,0,980,981,1,0,0,0,981,982,1,0,0,0,982,983,3,2,
	1,0,983,985,1,0,0,0,984,970,1,0,0,0,984,985,1,0,0,0,985,986,1,0,0,0,986,
	987,3,54,27,0,987,81,1,0,0,0,988,1004,3,80,40,0,989,990,3,80,40,0,990,991,
	5,4,0,0,991,992,3,30,15,0,992,1004,1,0,0,0,993,994,5,10,0,0,994,995,3,54,
	27,0,995,996,5,4,0,0,996,997,3,30,15,0,997,1004,1,0,0,0,998,999,5,58,0,
	0,999,1000,3,54,27,0,1000,1001,5,4,0,0,1001,1002,3,30,15,0,1002,1004,1,
	0,0,0,1003,988,1,0,0,0,1003,989,1,0,0,0,1003,993,1,0,0,0,1003,998,1,0,0,
	0,1004,83,1,0,0,0,1005,1006,3,48,24,0,1006,1007,7,2,0,0,1007,1008,3,30,
	15,0,1008,1019,1,0,0,0,1009,1010,3,48,24,0,1010,1011,5,59,0,0,1011,1019,
	1,0,0,0,1012,1013,3,48,24,0,1013,1014,5,60,0,0,1014,1019,1,0,0,0,1015,1016,
	5,61,0,0,1016,1017,5,4,0,0,1017,1019,3,30,15,0,1018,1005,1,0,0,0,1018,1009,
	1,0,0,0,1018,1012,1,0,0,0,1018,1015,1,0,0,0,1019,85,1,0,0,0,121,100,104,
	106,117,127,132,139,146,155,164,182,191,200,211,222,233,244,255,268,272,
	280,289,298,301,305,310,315,321,323,328,335,345,352,360,379,393,396,406,
	413,418,427,437,441,443,450,456,461,468,476,486,490,494,499,524,534,543,
	547,551,559,570,574,583,587,590,595,602,609,617,623,628,635,640,658,662,
	664,673,710,715,721,725,729,736,749,754,759,766,773,780,787,795,798,804,
	812,819,827,843,847,849,873,876,884,888,891,897,900,910,914,918,923,929,
	934,943,947,951,955,967,976,980,984,1003,1018];

	private static __ATN: ATN;
	public static get _ATN(): ATN {
		if (!WGSLParser.__ATN) {
			WGSLParser.__ATN = new ATNDeserializer().deserialize(WGSLParser._serializedATN);
		}

		return WGSLParser.__ATN;
	}


	static DecisionsToDFA = WGSLParser._ATN.decisionToState.map( (ds: DecisionState, index: number) => new DFA(ds, index) );

}

export class Template_args_startContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Left_angle(): TerminalNode {
		return this.getToken(WGSLParser.Left_angle, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_template_args_start;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterTemplate_args_start) {
	 		listener.enterTemplate_args_start(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitTemplate_args_start) {
	 		listener.exitTemplate_args_start(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitTemplate_args_start) {
			return visitor.visitTemplate_args_start(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Template_args_endContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Right_angle(): TerminalNode {
		return this.getToken(WGSLParser.Right_angle, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_template_args_end;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterTemplate_args_end) {
	 		listener.enterTemplate_args_end(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitTemplate_args_end) {
	 		listener.exitTemplate_args_end(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitTemplate_args_end) {
			return visitor.visitTemplate_args_end(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Additive_operatorContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Minus(): TerminalNode {
		return this.getToken(WGSLParser.Minus, 0);
	}
	public Positive(): TerminalNode {
		return this.getToken(WGSLParser.Positive, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_additive_operator;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterAdditive_operator) {
	 		listener.enterAdditive_operator(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitAdditive_operator) {
	 		listener.exitAdditive_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitAdditive_operator) {
			return visitor.visitAdditive_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Multiplicative_operatorContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Star(): TerminalNode {
		return this.getToken(WGSLParser.Star, 0);
	}
	public Dash(): TerminalNode {
		return this.getToken(WGSLParser.Dash, 0);
	}
	public MOD(): TerminalNode {
		return this.getToken(WGSLParser.MOD, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_multiplicative_operator;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterMultiplicative_operator) {
	 		listener.enterMultiplicative_operator(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitMultiplicative_operator) {
	 		listener.exitMultiplicative_operator(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitMultiplicative_operator) {
			return visitor.visitMultiplicative_operator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Argument_expression_listContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_argument_expression_list;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterArgument_expression_list) {
	 		listener.enterArgument_expression_list(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitArgument_expression_list) {
	 		listener.exitArgument_expression_list(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitArgument_expression_list) {
			return visitor.visitArgument_expression_list(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Assignment_statementContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Compound_assignment_operator(): TerminalNode {
		return this.getToken(WGSLParser.Compound_assignment_operator, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_assignment_statement;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterAssignment_statement) {
	 		listener.enterAssignment_statement(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitAssignment_statement) {
	 		listener.exitAssignment_statement(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitAssignment_statement) {
			return visitor.visitAssignment_statement(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Shift_expression_post_unary_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public multiplicative_operator_list(): Multiplicative_operatorContext[] {
		return this.getTypedRuleContexts(Multiplicative_operatorContext) as Multiplicative_operatorContext[];
	}
	public multiplicative_operator(i: number): Multiplicative_operatorContext {
		return this.getTypedRuleContext(Multiplicative_operatorContext, i) as Multiplicative_operatorContext;
	}
	public unary_expression_list(): Unary_expressionContext[] {
		return this.getTypedRuleContexts(Unary_expressionContext) as Unary_expressionContext[];
	}
	public unary_expression(i: number): Unary_expressionContext {
		return this.getTypedRuleContext(Unary_expressionContext, i) as Unary_expressionContext;
	}
	public additive_operator_list(): Additive_operatorContext[] {
		return this.getTypedRuleContexts(Additive_operatorContext) as Additive_operatorContext[];
	}
	public additive_operator(i: number): Additive_operatorContext {
		return this.getTypedRuleContext(Additive_operatorContext, i) as Additive_operatorContext;
	}
	public Shift_left(): TerminalNode {
		return this.getToken(WGSLParser.Shift_left, 0);
	}
	public Shift_right(): TerminalNode {
		return this.getToken(WGSLParser.Shift_right, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_shift_expression_post_unary_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterShift_expression_post_unary_expression) {
	 		listener.enterShift_expression_post_unary_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitShift_expression_post_unary_expression) {
	 		listener.exitShift_expression_post_unary_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitShift_expression_post_unary_expression) {
			return visitor.visitShift_expression_post_unary_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AttributeContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
	public diagnostic_control(): Diagnostic_controlContext {
		return this.getTypedRuleContext(Diagnostic_controlContext, 0) as Diagnostic_controlContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_attribute;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterAttribute) {
	 		listener.enterAttribute(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitAttribute) {
	 		listener.exitAttribute(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitAttribute) {
			return visitor.visitAttribute(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Bitwise_expression_post_unary_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public unary_expression_list(): Unary_expressionContext[] {
		return this.getTypedRuleContexts(Unary_expressionContext) as Unary_expressionContext[];
	}
	public unary_expression(i: number): Unary_expressionContext {
		return this.getTypedRuleContext(Unary_expressionContext, i) as Unary_expressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_bitwise_expression_post_unary_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterBitwise_expression_post_unary_expression) {
	 		listener.enterBitwise_expression_post_unary_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitBitwise_expression_post_unary_expression) {
	 		listener.exitBitwise_expression_post_unary_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitBitwise_expression_post_unary_expression) {
			return visitor.visitBitwise_expression_post_unary_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Case_selectorContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_case_selector;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterCase_selector) {
	 		listener.enterCase_selector(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitCase_selector) {
	 		listener.exitCase_selector(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitCase_selector) {
			return visitor.visitCase_selector(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Component_or_swizzle_specifierContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public member_ident(): Member_identContext {
		return this.getTypedRuleContext(Member_identContext, 0) as Member_identContext;
	}
	public component_or_swizzle_specifier(): Component_or_swizzle_specifierContext {
		return this.getTypedRuleContext(Component_or_swizzle_specifierContext, 0) as Component_or_swizzle_specifierContext;
	}
	public Swizzle_name(): TerminalNode {
		return this.getToken(WGSLParser.Swizzle_name, 0);
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_component_or_swizzle_specifier;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterComponent_or_swizzle_specifier) {
	 		listener.enterComponent_or_swizzle_specifier(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitComponent_or_swizzle_specifier) {
	 		listener.exitComponent_or_swizzle_specifier(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitComponent_or_swizzle_specifier) {
			return visitor.visitComponent_or_swizzle_specifier(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Compound_statementContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public attribute_list(): AttributeContext[] {
		return this.getTypedRuleContexts(AttributeContext) as AttributeContext[];
	}
	public attribute(i: number): AttributeContext {
		return this.getTypedRuleContext(AttributeContext, i) as AttributeContext;
	}
	public statement_list(): StatementContext[] {
		return this.getTypedRuleContexts(StatementContext) as StatementContext[];
	}
	public statement(i: number): StatementContext {
		return this.getTypedRuleContext(StatementContext, i) as StatementContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_compound_statement;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterCompound_statement) {
	 		listener.enterCompound_statement(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitCompound_statement) {
	 		listener.exitCompound_statement(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitCompound_statement) {
			return visitor.visitCompound_statement(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Core_lhs_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public lhs_expression(): Lhs_expressionContext {
		return this.getTypedRuleContext(Lhs_expressionContext, 0) as Lhs_expressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_core_lhs_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterCore_lhs_expression) {
	 		listener.enterCore_lhs_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitCore_lhs_expression) {
	 		listener.exitCore_lhs_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitCore_lhs_expression) {
			return visitor.visitCore_lhs_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Diagnostic_controlContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Severity_control_name(): TerminalNode {
		return this.getToken(WGSLParser.Severity_control_name, 0);
	}
	public diagnostic_rule_name(): Diagnostic_rule_nameContext {
		return this.getTypedRuleContext(Diagnostic_rule_nameContext, 0) as Diagnostic_rule_nameContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_diagnostic_control;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterDiagnostic_control) {
	 		listener.enterDiagnostic_control(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitDiagnostic_control) {
	 		listener.exitDiagnostic_control(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitDiagnostic_control) {
			return visitor.visitDiagnostic_control(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Diagnostic_rule_nameContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Ident_pattern_token_list(): TerminalNode[] {
	    	return this.getTokens(WGSLParser.Ident_pattern_token);
	}
	public Ident_pattern_token(i: number): TerminalNode {
		return this.getToken(WGSLParser.Ident_pattern_token, i);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_diagnostic_rule_name;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterDiagnostic_rule_name) {
	 		listener.enterDiagnostic_rule_name(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitDiagnostic_rule_name) {
	 		listener.exitDiagnostic_rule_name(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitDiagnostic_rule_name) {
			return visitor.visitDiagnostic_rule_name(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ExpressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public unary_expression_list(): Unary_expressionContext[] {
		return this.getTypedRuleContexts(Unary_expressionContext) as Unary_expressionContext[];
	}
	public unary_expression(i: number): Unary_expressionContext {
		return this.getTypedRuleContext(Unary_expressionContext, i) as Unary_expressionContext;
	}
	public bitwise_expression_post_unary_expression(): Bitwise_expression_post_unary_expressionContext {
		return this.getTypedRuleContext(Bitwise_expression_post_unary_expressionContext, 0) as Bitwise_expression_post_unary_expressionContext;
	}
	public relational_expression_post_unary_expression_list(): Relational_expression_post_unary_expressionContext[] {
		return this.getTypedRuleContexts(Relational_expression_post_unary_expressionContext) as Relational_expression_post_unary_expressionContext[];
	}
	public relational_expression_post_unary_expression(i: number): Relational_expression_post_unary_expressionContext {
		return this.getTypedRuleContext(Relational_expression_post_unary_expressionContext, i) as Relational_expression_post_unary_expressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterExpression) {
	 		listener.enterExpression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitExpression) {
	 		listener.exitExpression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitExpression) {
			return visitor.visitExpression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Float_literalContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Decimal_float_literal(): TerminalNode {
		return this.getToken(WGSLParser.Decimal_float_literal, 0);
	}
	public Hex_float_literal(): TerminalNode {
		return this.getToken(WGSLParser.Hex_float_literal, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_float_literal;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterFloat_literal) {
	 		listener.enterFloat_literal(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitFloat_literal) {
	 		listener.exitFloat_literal(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitFloat_literal) {
			return visitor.visitFloat_literal(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class For_initContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext {
		return this.getTypedRuleContext(Template_elaborated_ident_post_identContext, 0) as Template_elaborated_ident_post_identContext;
	}
	public argument_expression_list(): Argument_expression_listContext {
		return this.getTypedRuleContext(Argument_expression_listContext, 0) as Argument_expression_listContext;
	}
	public variable_or_value_statement(): Variable_or_value_statementContext {
		return this.getTypedRuleContext(Variable_or_value_statementContext, 0) as Variable_or_value_statementContext;
	}
	public variable_updating_statement(): Variable_updating_statementContext {
		return this.getTypedRuleContext(Variable_updating_statementContext, 0) as Variable_updating_statementContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_for_init;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterFor_init) {
	 		listener.enterFor_init(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitFor_init) {
	 		listener.exitFor_init(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitFor_init) {
			return visitor.visitFor_init(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class For_updateContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext {
		return this.getTypedRuleContext(Template_elaborated_ident_post_identContext, 0) as Template_elaborated_ident_post_identContext;
	}
	public argument_expression_list(): Argument_expression_listContext {
		return this.getTypedRuleContext(Argument_expression_listContext, 0) as Argument_expression_listContext;
	}
	public variable_updating_statement(): Variable_updating_statementContext {
		return this.getTypedRuleContext(Variable_updating_statementContext, 0) as Variable_updating_statementContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_for_update;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterFor_update) {
	 		listener.enterFor_update(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitFor_update) {
	 		listener.exitFor_update(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitFor_update) {
			return visitor.visitFor_update(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Global_declContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident_list(): IdentContext[] {
		return this.getTypedRuleContexts(IdentContext) as IdentContext[];
	}
	public ident(i: number): IdentContext {
		return this.getTypedRuleContext(IdentContext, i) as IdentContext;
	}
	public attribute_list(): AttributeContext[] {
		return this.getTypedRuleContexts(AttributeContext) as AttributeContext[];
	}
	public attribute(i: number): AttributeContext {
		return this.getTypedRuleContext(AttributeContext, i) as AttributeContext;
	}
	public type_specifier_list(): Type_specifierContext[] {
		return this.getTypedRuleContexts(Type_specifierContext) as Type_specifierContext[];
	}
	public type_specifier(i: number): Type_specifierContext {
		return this.getTypedRuleContext(Type_specifierContext, i) as Type_specifierContext;
	}
	public template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext {
		return this.getTypedRuleContext(Template_elaborated_ident_post_identContext, 0) as Template_elaborated_ident_post_identContext;
	}
	public statement_list(): StatementContext[] {
		return this.getTypedRuleContexts(StatementContext) as StatementContext[];
	}
	public statement(i: number): StatementContext {
		return this.getTypedRuleContext(StatementContext, i) as StatementContext;
	}
	public param_list(): ParamContext[] {
		return this.getTypedRuleContexts(ParamContext) as ParamContext[];
	}
	public param(i: number): ParamContext {
		return this.getTypedRuleContext(ParamContext, i) as ParamContext;
	}
	public optionally_typed_ident(): Optionally_typed_identContext {
		return this.getTypedRuleContext(Optionally_typed_identContext, 0) as Optionally_typed_identContext;
	}
	public template_args_start(): Template_args_startContext {
		return this.getTypedRuleContext(Template_args_startContext, 0) as Template_args_startContext;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
	public template_args_end(): Template_args_endContext {
		return this.getTypedRuleContext(Template_args_endContext, 0) as Template_args_endContext;
	}
	public global_value_decl(): Global_value_declContext {
		return this.getTypedRuleContext(Global_value_declContext, 0) as Global_value_declContext;
	}
	public member_ident_list(): Member_identContext[] {
		return this.getTypedRuleContexts(Member_identContext) as Member_identContext[];
	}
	public member_ident(i: number): Member_identContext {
		return this.getTypedRuleContext(Member_identContext, i) as Member_identContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_global_decl;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterGlobal_decl) {
	 		listener.enterGlobal_decl(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitGlobal_decl) {
	 		listener.exitGlobal_decl(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitGlobal_decl) {
			return visitor.visitGlobal_decl(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Global_directiveContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Severity_control_name(): TerminalNode {
		return this.getToken(WGSLParser.Severity_control_name, 0);
	}
	public diagnostic_rule_name(): Diagnostic_rule_nameContext {
		return this.getTypedRuleContext(Diagnostic_rule_nameContext, 0) as Diagnostic_rule_nameContext;
	}
	public Ident_pattern_token_list(): TerminalNode[] {
	    	return this.getTokens(WGSLParser.Ident_pattern_token);
	}
	public Ident_pattern_token(i: number): TerminalNode {
		return this.getToken(WGSLParser.Ident_pattern_token, i);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_global_directive;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterGlobal_directive) {
	 		listener.enterGlobal_directive(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitGlobal_directive) {
	 		listener.exitGlobal_directive(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitGlobal_directive) {
			return visitor.visitGlobal_directive(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Global_value_declContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public optionally_typed_ident(): Optionally_typed_identContext {
		return this.getTypedRuleContext(Optionally_typed_identContext, 0) as Optionally_typed_identContext;
	}
	public attribute_list(): AttributeContext[] {
		return this.getTypedRuleContexts(AttributeContext) as AttributeContext[];
	}
	public attribute(i: number): AttributeContext {
		return this.getTypedRuleContext(AttributeContext, i) as AttributeContext;
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_global_value_decl;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterGlobal_value_decl) {
	 		listener.enterGlobal_value_decl(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitGlobal_value_decl) {
	 		listener.exitGlobal_value_decl(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitGlobal_value_decl) {
			return visitor.visitGlobal_value_decl(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class IdentContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Ident_pattern_token(): TerminalNode {
		return this.getToken(WGSLParser.Ident_pattern_token, 0);
	}
	public Sigma_term(): TerminalNode {
		return this.getToken(WGSLParser.Sigma_term, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_ident;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterIdent) {
	 		listener.enterIdent(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitIdent) {
	 		listener.exitIdent(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitIdent) {
			return visitor.visitIdent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Int_literalContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Decimal_int_literal(): TerminalNode {
		return this.getToken(WGSLParser.Decimal_int_literal, 0);
	}
	public Hex_int_literal(): TerminalNode {
		return this.getToken(WGSLParser.Hex_int_literal, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_int_literal;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterInt_literal) {
	 		listener.enterInt_literal(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitInt_literal) {
	 		listener.exitInt_literal(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitInt_literal) {
			return visitor.visitInt_literal(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Lhs_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public core_lhs_expression(): Core_lhs_expressionContext {
		return this.getTypedRuleContext(Core_lhs_expressionContext, 0) as Core_lhs_expressionContext;
	}
	public component_or_swizzle_specifier(): Component_or_swizzle_specifierContext {
		return this.getTypedRuleContext(Component_or_swizzle_specifierContext, 0) as Component_or_swizzle_specifierContext;
	}
	public lhs_expression(): Lhs_expressionContext {
		return this.getTypedRuleContext(Lhs_expressionContext, 0) as Lhs_expressionContext;
	}
	public Star(): TerminalNode {
		return this.getToken(WGSLParser.Star, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_lhs_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterLhs_expression) {
	 		listener.enterLhs_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitLhs_expression) {
	 		listener.exitLhs_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitLhs_expression) {
			return visitor.visitLhs_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class LiteralContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Bool_literal(): TerminalNode {
		return this.getToken(WGSLParser.Bool_literal, 0);
	}
	public float_literal(): Float_literalContext {
		return this.getTypedRuleContext(Float_literalContext, 0) as Float_literalContext;
	}
	public int_literal(): Int_literalContext {
		return this.getTypedRuleContext(Int_literalContext, 0) as Int_literalContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_literal;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterLiteral) {
	 		listener.enterLiteral(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitLiteral) {
	 		listener.exitLiteral(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitLiteral) {
			return visitor.visitLiteral(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Member_identContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Ident_pattern_token(): TerminalNode {
		return this.getToken(WGSLParser.Ident_pattern_token, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_member_ident;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterMember_ident) {
	 		listener.enterMember_ident(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitMember_ident) {
	 		listener.exitMember_ident(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitMember_ident) {
			return visitor.visitMember_ident(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Optionally_typed_identContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public type_specifier(): Type_specifierContext {
		return this.getTypedRuleContext(Type_specifierContext, 0) as Type_specifierContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_optionally_typed_ident;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterOptionally_typed_ident) {
	 		listener.enterOptionally_typed_ident(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitOptionally_typed_ident) {
	 		listener.exitOptionally_typed_ident(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitOptionally_typed_ident) {
			return visitor.visitOptionally_typed_ident(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParamContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public type_specifier(): Type_specifierContext {
		return this.getTypedRuleContext(Type_specifierContext, 0) as Type_specifierContext;
	}
	public attribute_list(): AttributeContext[] {
		return this.getTypedRuleContexts(AttributeContext) as AttributeContext[];
	}
	public attribute(i: number): AttributeContext {
		return this.getTypedRuleContext(AttributeContext, i) as AttributeContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_param;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterParam) {
	 		listener.enterParam(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitParam) {
	 		listener.exitParam(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitParam) {
			return visitor.visitParam(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Primary_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext {
		return this.getTypedRuleContext(Template_elaborated_ident_post_identContext, 0) as Template_elaborated_ident_post_identContext;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
	public literal(): LiteralContext {
		return this.getTypedRuleContext(LiteralContext, 0) as LiteralContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_primary_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterPrimary_expression) {
	 		listener.enterPrimary_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitPrimary_expression) {
	 		listener.exitPrimary_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitPrimary_expression) {
			return visitor.visitPrimary_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Greater_thanContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Right_angle(): TerminalNode {
		return this.getToken(WGSLParser.Right_angle, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_greater_than;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterGreater_than) {
	 		listener.enterGreater_than(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitGreater_than) {
	 		listener.exitGreater_than(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitGreater_than) {
			return visitor.visitGreater_than(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Less_thanContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public Left_angle(): TerminalNode {
		return this.getToken(WGSLParser.Left_angle, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_less_than;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterLess_than) {
	 		listener.enterLess_than(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitLess_than) {
	 		listener.exitLess_than(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitLess_than) {
			return visitor.visitLess_than(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Relational_expression_post_unary_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public shift_expression_post_unary_expression_list(): Shift_expression_post_unary_expressionContext[] {
		return this.getTypedRuleContexts(Shift_expression_post_unary_expressionContext) as Shift_expression_post_unary_expressionContext[];
	}
	public shift_expression_post_unary_expression(i: number): Shift_expression_post_unary_expressionContext {
		return this.getTypedRuleContext(Shift_expression_post_unary_expressionContext, i) as Shift_expression_post_unary_expressionContext;
	}
	public greater_than(): Greater_thanContext {
		return this.getTypedRuleContext(Greater_thanContext, 0) as Greater_thanContext;
	}
	public unary_expression(): Unary_expressionContext {
		return this.getTypedRuleContext(Unary_expressionContext, 0) as Unary_expressionContext;
	}
	public Greater_than_equal(): TerminalNode {
		return this.getToken(WGSLParser.Greater_than_equal, 0);
	}
	public less_than(): Less_thanContext {
		return this.getTypedRuleContext(Less_thanContext, 0) as Less_thanContext;
	}
	public Less_than_equal(): TerminalNode {
		return this.getToken(WGSLParser.Less_than_equal, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_relational_expression_post_unary_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterRelational_expression_post_unary_expression) {
	 		listener.enterRelational_expression_post_unary_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitRelational_expression_post_unary_expression) {
	 		listener.exitRelational_expression_post_unary_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitRelational_expression_post_unary_expression) {
			return visitor.visitRelational_expression_post_unary_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StatementContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public compound_statement_list(): Compound_statementContext[] {
		return this.getTypedRuleContexts(Compound_statementContext) as Compound_statementContext[];
	}
	public compound_statement(i: number): Compound_statementContext {
		return this.getTypedRuleContext(Compound_statementContext, i) as Compound_statementContext;
	}
	public attribute_list(): AttributeContext[] {
		return this.getTypedRuleContexts(AttributeContext) as AttributeContext[];
	}
	public attribute(i: number): AttributeContext {
		return this.getTypedRuleContext(AttributeContext, i) as AttributeContext;
	}
	public for_init(): For_initContext {
		return this.getTypedRuleContext(For_initContext, 0) as For_initContext;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
	public for_update(): For_updateContext {
		return this.getTypedRuleContext(For_updateContext, 0) as For_updateContext;
	}
	public statement_list(): StatementContext[] {
		return this.getTypedRuleContexts(StatementContext) as StatementContext[];
	}
	public statement(i: number): StatementContext {
		return this.getTypedRuleContext(StatementContext, i) as StatementContext;
	}
	public Break_statement(): TerminalNode {
		return this.getToken(WGSLParser.Break_statement, 0);
	}
	public switch_clause_list(): Switch_clauseContext[] {
		return this.getTypedRuleContexts(Switch_clauseContext) as Switch_clauseContext[];
	}
	public switch_clause(i: number): Switch_clauseContext {
		return this.getTypedRuleContext(Switch_clauseContext, i) as Switch_clauseContext;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public template_elaborated_ident_post_ident(): Template_elaborated_ident_post_identContext {
		return this.getTypedRuleContext(Template_elaborated_ident_post_identContext, 0) as Template_elaborated_ident_post_identContext;
	}
	public variable_or_value_statement(): Variable_or_value_statementContext {
		return this.getTypedRuleContext(Variable_or_value_statementContext, 0) as Variable_or_value_statementContext;
	}
	public variable_updating_statement(): Variable_updating_statementContext {
		return this.getTypedRuleContext(Variable_updating_statementContext, 0) as Variable_updating_statementContext;
	}
	public Continue_statement(): TerminalNode {
		return this.getToken(WGSLParser.Continue_statement, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_statement;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterStatement) {
	 		listener.enterStatement(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitStatement) {
	 		listener.exitStatement(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitStatement) {
			return visitor.visitStatement(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Switch_clauseContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public case_selector_list(): Case_selectorContext[] {
		return this.getTypedRuleContexts(Case_selectorContext) as Case_selectorContext[];
	}
	public case_selector(i: number): Case_selectorContext {
		return this.getTypedRuleContext(Case_selectorContext, i) as Case_selectorContext;
	}
	public compound_statement(): Compound_statementContext {
		return this.getTypedRuleContext(Compound_statementContext, 0) as Compound_statementContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_switch_clause;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterSwitch_clause) {
	 		listener.enterSwitch_clause(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitSwitch_clause) {
	 		listener.exitSwitch_clause(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitSwitch_clause) {
			return visitor.visitSwitch_clause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Template_arg_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_template_arg_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterTemplate_arg_expression) {
	 		listener.enterTemplate_arg_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitTemplate_arg_expression) {
	 		listener.exitTemplate_arg_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitTemplate_arg_expression) {
			return visitor.visitTemplate_arg_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Template_elaborated_ident_post_identContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public template_args_start(): Template_args_startContext {
		return this.getTypedRuleContext(Template_args_startContext, 0) as Template_args_startContext;
	}
	public template_arg_expression(): Template_arg_expressionContext {
		return this.getTypedRuleContext(Template_arg_expressionContext, 0) as Template_arg_expressionContext;
	}
	public template_args_end(): Template_args_endContext {
		return this.getTypedRuleContext(Template_args_endContext, 0) as Template_args_endContext;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_template_elaborated_ident_post_ident;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterTemplate_elaborated_ident_post_ident) {
	 		listener.enterTemplate_elaborated_ident_post_ident(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitTemplate_elaborated_ident_post_ident) {
	 		listener.exitTemplate_elaborated_ident_post_ident(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitTemplate_elaborated_ident_post_ident) {
			return visitor.visitTemplate_elaborated_ident_post_ident(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Translation_unitContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public global_directive_list(): Global_directiveContext[] {
		return this.getTypedRuleContexts(Global_directiveContext) as Global_directiveContext[];
	}
	public global_directive(i: number): Global_directiveContext {
		return this.getTypedRuleContext(Global_directiveContext, i) as Global_directiveContext;
	}
	public global_decl_list(): Global_declContext[] {
		return this.getTypedRuleContexts(Global_declContext) as Global_declContext[];
	}
	public global_decl(i: number): Global_declContext {
		return this.getTypedRuleContext(Global_declContext, i) as Global_declContext;
	}
	public statement(): StatementContext {
		return this.getTypedRuleContext(StatementContext, 0) as StatementContext;
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_translation_unit;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterTranslation_unit) {
	 		listener.enterTranslation_unit(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitTranslation_unit) {
	 		listener.exitTranslation_unit(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitTranslation_unit) {
			return visitor.visitTranslation_unit(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Type_specifierContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ident(): IdentContext {
		return this.getTypedRuleContext(IdentContext, 0) as IdentContext;
	}
	public template_args_start(): Template_args_startContext {
		return this.getTypedRuleContext(Template_args_startContext, 0) as Template_args_startContext;
	}
	public template_arg_expression(): Template_arg_expressionContext {
		return this.getTypedRuleContext(Template_arg_expressionContext, 0) as Template_arg_expressionContext;
	}
	public template_args_end(): Template_args_endContext {
		return this.getTypedRuleContext(Template_args_endContext, 0) as Template_args_endContext;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_type_specifier;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterType_specifier) {
	 		listener.enterType_specifier(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitType_specifier) {
	 		listener.exitType_specifier(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitType_specifier) {
			return visitor.visitType_specifier(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Unary_expressionContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public primary_expression(): Primary_expressionContext {
		return this.getTypedRuleContext(Primary_expressionContext, 0) as Primary_expressionContext;
	}
	public component_or_swizzle_specifier(): Component_or_swizzle_specifierContext {
		return this.getTypedRuleContext(Component_or_swizzle_specifierContext, 0) as Component_or_swizzle_specifierContext;
	}
	public unary_expression(): Unary_expressionContext {
		return this.getTypedRuleContext(Unary_expressionContext, 0) as Unary_expressionContext;
	}
	public Star(): TerminalNode {
		return this.getToken(WGSLParser.Star, 0);
	}
	public Minus(): TerminalNode {
		return this.getToken(WGSLParser.Minus, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_unary_expression;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterUnary_expression) {
	 		listener.enterUnary_expression(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitUnary_expression) {
	 		listener.exitUnary_expression(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitUnary_expression) {
			return visitor.visitUnary_expression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Variable_declContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public optionally_typed_ident(): Optionally_typed_identContext {
		return this.getTypedRuleContext(Optionally_typed_identContext, 0) as Optionally_typed_identContext;
	}
	public template_args_start(): Template_args_startContext {
		return this.getTypedRuleContext(Template_args_startContext, 0) as Template_args_startContext;
	}
	public expression_list(): ExpressionContext[] {
		return this.getTypedRuleContexts(ExpressionContext) as ExpressionContext[];
	}
	public expression(i: number): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, i) as ExpressionContext;
	}
	public template_args_end(): Template_args_endContext {
		return this.getTypedRuleContext(Template_args_endContext, 0) as Template_args_endContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_variable_decl;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterVariable_decl) {
	 		listener.enterVariable_decl(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitVariable_decl) {
	 		listener.exitVariable_decl(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitVariable_decl) {
			return visitor.visitVariable_decl(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Variable_or_value_statementContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public variable_decl(): Variable_declContext {
		return this.getTypedRuleContext(Variable_declContext, 0) as Variable_declContext;
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
	public optionally_typed_ident(): Optionally_typed_identContext {
		return this.getTypedRuleContext(Optionally_typed_identContext, 0) as Optionally_typed_identContext;
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_variable_or_value_statement;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterVariable_or_value_statement) {
	 		listener.enterVariable_or_value_statement(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitVariable_or_value_statement) {
	 		listener.exitVariable_or_value_statement(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitVariable_or_value_statement) {
			return visitor.visitVariable_or_value_statement(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class Variable_updating_statementContext extends ParserRuleContext {
	constructor(parser?: WGSLParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public lhs_expression(): Lhs_expressionContext {
		return this.getTypedRuleContext(Lhs_expressionContext, 0) as Lhs_expressionContext;
	}
	public expression(): ExpressionContext {
		return this.getTypedRuleContext(ExpressionContext, 0) as ExpressionContext;
	}
	public Compound_assignment_operator(): TerminalNode {
		return this.getToken(WGSLParser.Compound_assignment_operator, 0);
	}
    public get ruleIndex(): number {
    	return WGSLParser.RULE_variable_updating_statement;
	}
	public enterRule(listener: WGSLListener): void {
	    if(listener.enterVariable_updating_statement) {
	 		listener.enterVariable_updating_statement(this);
		}
	}
	public exitRule(listener: WGSLListener): void {
	    if(listener.exitVariable_updating_statement) {
	 		listener.exitVariable_updating_statement(this);
		}
	}
	// @Override
	public accept<Result>(visitor: WGSLVisitor<Result>): Result {
		if (visitor.visitVariable_updating_statement) {
			return visitor.visitVariable_updating_statement(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
