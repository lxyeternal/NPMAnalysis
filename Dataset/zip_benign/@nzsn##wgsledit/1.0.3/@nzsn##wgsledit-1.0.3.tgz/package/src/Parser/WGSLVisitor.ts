// Generated from ./WGSL.g4 by ANTLR 4.13.1

import {ParseTreeVisitor} from 'antlr4';


import { Template_args_startContext } from "./WGSLParser";
import { Template_args_endContext } from "./WGSLParser";
import { Additive_operatorContext } from "./WGSLParser";
import { Multiplicative_operatorContext } from "./WGSLParser";
import { Argument_expression_listContext } from "./WGSLParser";
import { Assignment_statementContext } from "./WGSLParser";
import { Shift_expression_post_unary_expressionContext } from "./WGSLParser";
import { AttributeContext } from "./WGSLParser";
import { Bitwise_expression_post_unary_expressionContext } from "./WGSLParser";
import { Case_selectorContext } from "./WGSLParser";
import { Component_or_swizzle_specifierContext } from "./WGSLParser";
import { Compound_statementContext } from "./WGSLParser";
import { Core_lhs_expressionContext } from "./WGSLParser";
import { Diagnostic_controlContext } from "./WGSLParser";
import { Diagnostic_rule_nameContext } from "./WGSLParser";
import { ExpressionContext } from "./WGSLParser";
import { Float_literalContext } from "./WGSLParser";
import { For_initContext } from "./WGSLParser";
import { For_updateContext } from "./WGSLParser";
import { Global_declContext } from "./WGSLParser";
import { Global_directiveContext } from "./WGSLParser";
import { Global_value_declContext } from "./WGSLParser";
import { IdentContext } from "./WGSLParser";
import { Int_literalContext } from "./WGSLParser";
import { Lhs_expressionContext } from "./WGSLParser";
import { LiteralContext } from "./WGSLParser";
import { Member_identContext } from "./WGSLParser";
import { Optionally_typed_identContext } from "./WGSLParser";
import { ParamContext } from "./WGSLParser";
import { Primary_expressionContext } from "./WGSLParser";
import { Greater_thanContext } from "./WGSLParser";
import { Less_thanContext } from "./WGSLParser";
import { Relational_expression_post_unary_expressionContext } from "./WGSLParser";
import { StatementContext } from "./WGSLParser";
import { Switch_clauseContext } from "./WGSLParser";
import { Template_arg_expressionContext } from "./WGSLParser";
import { Template_elaborated_ident_post_identContext } from "./WGSLParser";
import { Translation_unitContext } from "./WGSLParser";
import { Type_specifierContext } from "./WGSLParser";
import { Unary_expressionContext } from "./WGSLParser";
import { Variable_declContext } from "./WGSLParser";
import { Variable_or_value_statementContext } from "./WGSLParser";
import { Variable_updating_statementContext } from "./WGSLParser";


/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by `WGSLParser`.
 *
 * @param <Result> The return type of the visit operation. Use `void` for
 * operations with no return type.
 */
export default class WGSLVisitor<Result> extends ParseTreeVisitor<Result> {
	/**
	 * Visit a parse tree produced by `WGSLParser.template_args_start`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTemplate_args_start?: (ctx: Template_args_startContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.template_args_end`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTemplate_args_end?: (ctx: Template_args_endContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.additive_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAdditive_operator?: (ctx: Additive_operatorContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.multiplicative_operator`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMultiplicative_operator?: (ctx: Multiplicative_operatorContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.argument_expression_list`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArgument_expression_list?: (ctx: Argument_expression_listContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.assignment_statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAssignment_statement?: (ctx: Assignment_statementContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.shift_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitShift_expression_post_unary_expression?: (ctx: Shift_expression_post_unary_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.attribute`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAttribute?: (ctx: AttributeContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.bitwise_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBitwise_expression_post_unary_expression?: (ctx: Bitwise_expression_post_unary_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.case_selector`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCase_selector?: (ctx: Case_selectorContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.component_or_swizzle_specifier`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponent_or_swizzle_specifier?: (ctx: Component_or_swizzle_specifierContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.compound_statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCompound_statement?: (ctx: Compound_statementContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.core_lhs_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCore_lhs_expression?: (ctx: Core_lhs_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.diagnostic_control`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDiagnostic_control?: (ctx: Diagnostic_controlContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.diagnostic_rule_name`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDiagnostic_rule_name?: (ctx: Diagnostic_rule_nameContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitExpression?: (ctx: ExpressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.float_literal`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFloat_literal?: (ctx: Float_literalContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.for_init`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFor_init?: (ctx: For_initContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.for_update`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFor_update?: (ctx: For_updateContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.global_decl`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGlobal_decl?: (ctx: Global_declContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.global_directive`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGlobal_directive?: (ctx: Global_directiveContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.global_value_decl`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGlobal_value_decl?: (ctx: Global_value_declContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.ident`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIdent?: (ctx: IdentContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.int_literal`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInt_literal?: (ctx: Int_literalContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.lhs_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLhs_expression?: (ctx: Lhs_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.literal`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLiteral?: (ctx: LiteralContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.member_ident`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMember_ident?: (ctx: Member_identContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.optionally_typed_ident`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOptionally_typed_ident?: (ctx: Optionally_typed_identContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.param`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParam?: (ctx: ParamContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.primary_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPrimary_expression?: (ctx: Primary_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.greater_than`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGreater_than?: (ctx: Greater_thanContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.less_than`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLess_than?: (ctx: Less_thanContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.relational_expression_post_unary_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRelational_expression_post_unary_expression?: (ctx: Relational_expression_post_unary_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStatement?: (ctx: StatementContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.switch_clause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSwitch_clause?: (ctx: Switch_clauseContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.template_arg_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTemplate_arg_expression?: (ctx: Template_arg_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.template_elaborated_ident_post_ident`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTemplate_elaborated_ident_post_ident?: (ctx: Template_elaborated_ident_post_identContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.translation_unit`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTranslation_unit?: (ctx: Translation_unitContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.type_specifier`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitType_specifier?: (ctx: Type_specifierContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.unary_expression`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnary_expression?: (ctx: Unary_expressionContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.variable_decl`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVariable_decl?: (ctx: Variable_declContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.variable_or_value_statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVariable_or_value_statement?: (ctx: Variable_or_value_statementContext) => Result;
	/**
	 * Visit a parse tree produced by `WGSLParser.variable_updating_statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVariable_updating_statement?: (ctx: Variable_updating_statementContext) => Result;
}

