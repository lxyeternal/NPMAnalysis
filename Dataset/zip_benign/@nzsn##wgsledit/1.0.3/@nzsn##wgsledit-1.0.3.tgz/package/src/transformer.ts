import { ParseTreeWalker, ParseTree, TerminalNode, ParserRuleContext  } from 'antlr4';
import WGSLListener from './Parser/WGSLListener';
import { IdentContext, Type_specifierContext, Member_identContext, Global_declContext } from './Parser/WGSLParser';
import { ObfIdent } from './types';

interface SubTransformer {
    walk(t: ParseTree): ParseTree;
};

class SyntaxSubTrans extends WGSLListener {
    walk(t: ParseTree): ParseTree {
        return t;
    }
}

class ObfuscateSubTrans extends WGSLListener {
    private obfId: ObfIdent = new ObfIdent("a");

    obfuscatedDict: Map<string, string> =
        new Map<string, string>();
    userDefinedTypes: Array<string> =
        new Array<string>();

    private obfuscate(token: string): string {

        const obfuscatedInternal = (token: string): string => {
            let id = this.obfId.value;

            this.obfId.next();
            this.obfuscatedDict.set(token, id);

            return id;
        };

        return this.obfuscatedDict.get(token) ??
            /* identifier that not yet obfuscated */
            obfuscatedInternal(token);
    }

    private noTypeSpecifier(ctx: ParserRuleContext): boolean {
        let parent = ctx.parentCtx;

        while (parent != undefined) {
            if (parent instanceof Type_specifierContext) {
                // TODO: User defined types should be
                //       obfuscatable.
                let userTypes = this.userDefinedTypes.find((s: string): boolean => {
                    return s == ctx.getText();
                });

                return userTypes != undefined;
            }
            parent = parent.parentCtx;
        }

        return true;
    }

    filter(ctx: ParserRuleContext): boolean {
        // Filter out all type specifier
        return this.noTypeSpecifier(ctx);
    }

    enterGlobal_decl = (ctx: Global_declContext): void => {
        let type = ctx.getChild(0).getText();

        if (type == "struct" ||
            type == "alias") {
            // User defined type
            this.userDefinedTypes.push(ctx.ident(0).getText());
        }
    }

    terminalObf<Type>(ctx: Type):void  {
        let token: TerminalNode | null = null;

        if (ctx instanceof IdentContext ||
            ctx instanceof Member_identContext) {

            token = ctx.Ident_pattern_token()

            if (!this.filter(ctx)) {
                return;
            } else {
                token.symbol.text = this.obfuscate(token.symbol.text);
            }
        }
    }
    enterIdent = this.terminalObf<IdentContext>;
    enterMember_ident = this.terminalObf<Member_identContext>;

    walk(t: ParseTree): ParseTree {
        ParseTreeWalker.DEFAULT.walk(this, t);
        return t;
    }

}

export enum Features {
    Obfuscate = 0x01,
    ExtendedSyntax = 0x02,
}

export class Transformer {

    private trans: SubTransformer[] = [];

    constructor(features?: Features) {
        this.resetFeatures(features ??
            Features.ExtendedSyntax |
            Features.Obfuscate);
    }

    resetFeatures(features: Features) {
        this.trans = [];

        if (features & Features.Obfuscate) {
            this.trans.push(new ObfuscateSubTrans());
        }
        if (features & Features.ExtendedSyntax) {
            this.trans.push(new SyntaxSubTrans());
        }
    }

    public transform(t: ParseTree): ParseTree {
        return this.trans.reduce(
            (tree, trans) => trans.walk(tree), t
        );
    }
}
