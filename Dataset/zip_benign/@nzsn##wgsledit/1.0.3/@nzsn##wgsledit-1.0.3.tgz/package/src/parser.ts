import { CharStream, CommonTokenStream, ParseTree } from 'antlr4';

import WGSLLexer from './Parser/WGSLLexer';
import WGSLParser from './Parser/WGSLParser';

export class Parser {
    public parse(input: string): ParseTree | null {
        // Trim all comments
        // Single line comments
        input = input.replace(/\/\/[^\n]*/g, "\n");
        // Multi-line comments
        input = input.replace(/\/\*([\s\S]*?(\*\/|\([\s\S]*?)*)\*\//, "\n");

        const chars = new CharStream(input);
        const lexer = new WGSLLexer(chars);
        const tokens = new CommonTokenStream(lexer);
        const parser = new WGSLParser(tokens);
        const tree = parser.translation_unit();

        return parser.syntaxErrorsCount == 0 ?
            tree : null;
    }
}
