------ MODULE Transformer ------
CONSTANTS NULL, Trees
VARIABLE transformer

LOCAL INSTANCE Sequences
LOCAL INSTANCE Types

ObfuscateWalker[t \in Trees] == 0
ImportWalker[t \in Trees] == 0


Walkers == <<ObfuscateWalker, ImportWalker>>
RECURSIVE ApplyWalkers(_)
ApplyWalkers(t, walkers) ==
  LET walker == Head(walkers)
  IN  ApplyWalkers(walker(t), Tail(walkers))

TypeInvariant ==
  transformer = [output |-> NULL]

Transform(t) ==
  transformer' = [transformer EXCEPT
                  !.output = ApplyWalkers(t, Walkers)]
================================
