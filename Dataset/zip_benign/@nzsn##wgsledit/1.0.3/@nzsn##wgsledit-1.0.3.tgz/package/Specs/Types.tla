------- MODULE Types ------
Tree(s) == {1, s}
Transed(t) == {2, t}
Txt(t) == {3, t}
===========================
