------ MODULE WGSLEditor ------
CONSTANTS NULL, Sources, Trees
VARIABLES parser, transformer, state

p == INSTANCE Parser WITH
  NULL <- NULL,
  parser <- parser

t == INSTANCE Transformer WITH
  NULL <- NULL,
  transformer <- transformer,
  Trees <- Trees,

TypeInvariant ==
  /\ state = 0
  /\ p!TypeInvariant
  /\ t!TypeInvariant

Init == TypeInvariant

Parse(s) ==
    /\ state = 0
    /\ state' = 1
    /\ p!Parse(s)
    /\ UNCHANGED <<transformer>>

Transform(t) ==
    /\ state = 1
    /\ state' = 2
    /\ t!Transform(t)
    /\ UNCHANGED <<parser>>

Finished ==
    /\ state = 2
    /\ UNCHANGED <<parser, transformer, state>>

Next ==
    \/ \A s \in Sources: Parse(s)
    \/ \A t \in Trees: Transform(t)

Spec == Init /\ [][Next]_<<parser, transformer, state>>

===============================
