------ MODULE ObfuscatedBits ------
EXTENDS TLC, Naturals, Sequences

\* Bit definitions, it can be anything else
\* only requirements of Bit is those interfaces.
Bit == { "a", "b", "c" }
MinimumBit == "a"
MaximumBit == "c"
\* Interfaces of Bit
nextBit[b \in Bit] ==
    IF b = "a"
    THEN "b"
    ELSE IF b = "b"
    THEN "c"
    ELSE "a"

Samples == UNION {[1..n -> Bit]: n \in {3}}

(*--algorithm ObfuscatedBits
variables bits \in Samples, procBits, lsb, i, remain,
          results = <<>>, steps \in 2..200;

macro PlusN(bb, N) begin
  procBits := bb;
  lsb := procBits[Len(procBits)];
  remain := N;
  while remain > 0 do
    if lsb = MaximumBit then
      \* Carry is required
      i := Len(procBits);
      while i >= 1 do
        if procBits[i] = MaximumBit then
          procBits[i] := MinimumBit;

          if i = 1 then
            procBits := <<MinimumBit>> \o procBits;
          end if;

          i := i - 1;
        else
          procBits[i] := nextBit[procBits[i]];
          \* Stop here, no more carries.
          i := 0;
        end if;
      end while;
      remain := remain - 1;
    end if;
  end while;
end macro;

begin
  while steps > 0 do
    PlusN(bits, steps);
    results := Append(results, procBits);

    steps := steps - 1;
  end while;

  assert \E a \in 1..Len(results):
         \A b \in 1..Len(results):
            a /= b => results[a] /= results[b];

end algorithm;*)
\* BEGIN TRANSLATION (chksum(pcal) = "7f24ecea" /\ chksum(tla) = "9d3fcbdb")
CONSTANT defaultInitValue
VARIABLES bits, procBits, lsb, i, remain, results, steps, pc

vars == << bits, procBits, lsb, i, remain, results, steps, pc >>

Init == (* Global variables *)
        /\ bits \in Samples
        /\ procBits = defaultInitValue
        /\ lsb = defaultInitValue
        /\ i = defaultInitValue
        /\ remain = defaultInitValue
        /\ results = <<>>
        /\ steps \in 2..200
        /\ pc = "Lbl_1"

Lbl_1 == /\ pc = "Lbl_1"
         /\ IF steps > 0
               THEN /\ procBits' = bits
                    /\ lsb' = procBits'[Len(procBits')]
                    /\ remain' = steps
                    /\ pc' = "Lbl_2"
               ELSE /\ Assert(\E a \in 1..Len(results):
                              \A b \in 1..Len(results):
                                 a /= b => results[a] /= results[b], 
                              "Failure of assertion at line 60, column 3.")
                    /\ pc' = "Done"
                    /\ UNCHANGED << procBits, lsb, remain >>
         /\ UNCHANGED << bits, i, results, steps >>

Lbl_2 == /\ pc = "Lbl_2"
         /\ IF remain > 0
               THEN /\ IF lsb = MaximumBit
                          THEN /\ i' = Len(procBits)
                               /\ pc' = "Lbl_3"
                          ELSE /\ pc' = "Lbl_2"
                               /\ i' = i
                    /\ UNCHANGED << results, steps >>
               ELSE /\ results' = Append(results, procBits)
                    /\ steps' = steps - 1
                    /\ pc' = "Lbl_1"
                    /\ i' = i
         /\ UNCHANGED << bits, procBits, lsb, remain >>

Lbl_3 == /\ pc = "Lbl_3"
         /\ IF i >= 1
               THEN /\ IF procBits[i] = MaximumBit
                          THEN /\ procBits' = [procBits EXCEPT ![i] = MinimumBit]
                               /\ IF i = 1
                                     THEN /\ pc' = "Lbl_4"
                                     ELSE /\ pc' = "Lbl_5"
                               /\ i' = i
                          ELSE /\ procBits' = [procBits EXCEPT ![i] = nextBit[procBits[i]]]
                               /\ i' = 0
                               /\ pc' = "Lbl_3"
                    /\ UNCHANGED remain
               ELSE /\ remain' = remain - 1
                    /\ pc' = "Lbl_2"
                    /\ UNCHANGED << procBits, i >>
         /\ UNCHANGED << bits, lsb, results, steps >>

Lbl_5 == /\ pc = "Lbl_5"
         /\ i' = i - 1
         /\ pc' = "Lbl_3"
         /\ UNCHANGED << bits, procBits, lsb, remain, results, steps >>

Lbl_4 == /\ pc = "Lbl_4"
         /\ procBits' = <<MinimumBit>> \o procBits
         /\ pc' = "Lbl_5"
         /\ UNCHANGED << bits, lsb, i, remain, results, steps >>

(* Allow infinite stuttering to prevent deadlock on termination. *)
Terminating == pc = "Done" /\ UNCHANGED vars

Next == Lbl_1 \/ Lbl_2 \/ Lbl_3 \/ Lbl_5 \/ Lbl_4
           \/ Terminating

Spec == Init /\ [][Next]_vars

Termination == <>(pc = "Done")

\* END TRANSLATION 

===================================
