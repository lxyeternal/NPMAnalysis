------ MODULE Parser ------
CONSTANTS NULL
VARIABLE parser

LOCAL INSTANCE Types

TypeInvariant ==
  parser = [tree |-> NULL]

Parse(s) ==
  parser' = [parser EXCEPT !.tree = Tree(s)]
===========================
