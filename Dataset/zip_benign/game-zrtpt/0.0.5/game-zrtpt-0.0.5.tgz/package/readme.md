# zrtpt

# 游戏

##### 安装

```
npm install game-zrtpt
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-zrtpt/zrtpt"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: JSON.stringify({
      row: 3,
      col: 4,
      items: [
        //singleAudioName:单个碎片成功的音效 doneAudioName:整个碎片拼成功的音效 (如果配置了singleAudioName没有doneAudioName，整个拼接成功依旧播放singleAudioName音效)
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Nkhd0l1FJvecI8FYU_!!1080040467.png", probability: 1, val: 20, singleAudioName: "single", doneAudioName1: "default" },
      ],
      source: {//碎片打乱区域
        x: (750 - 657) / 2,
        y: 500,
        width: 657,
        height: 496,
        topBg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bKNuUU1FJveVikaCH_!!1080040467.png", x: (750 - 657) / 2, y: 500 }
      },
      ptq: {//拼图区域
        x: (750 - 657) / 2,
        y: 0,
        width: 657,
        height: 496,
        totalPadding: { left: 4, right: 4, top: 4, bottom: 4 },
        singlePadding: { left: 1, right: 1, top: 1, bottom: 1 },
        src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01efwt9b1FJveZSFfHt_!!1080040467.png",
      },

      timePos: {
        align: "right",
        x: 270,
        y: 230,
        bg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aTRiLo1FJveXoYCMd_!!1080040467.png", x: 48, y: 206 },
        time: 100,//倒计时时间
        // 时间数字图片 0 - 9
        numOffset: -6,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Ve8sS1FJvebl5J0y_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017EHyrt1FJvebEo1q2_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cv0zNh1FJveOqYcST_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0147f9921FJveYuxkj9_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017CzUN31FJveaLpTeI_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IUNX0n1FJveZB36WB_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gphOoG1FJveZB1tga_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R9M8rn1FJvedU2Nd3_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IxZxFX1FJvecmGnwT_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zIjEmp1FJveVXvVsw_!!1080040467.png", val: 9 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EPJwbR1FJveUyNoyH_!!1080040467.png", val: "s" },
        ],
      },
      /* tipScorePos: {
        fadeTime: 0.5,//消失时间
        numOffset: -4,//数字两边空白太多，增加偏移量
        scale: "1.5",
        bg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FM8QxU1FJveZ9Z9j1_!!1080040467.png", x: 0, y: -30 },
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01T251Kg1FJveOa46G1_!!1080040467.png", val: "+" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yPU5CY1FJveWIxirL_!!1080040467.png", val: "s" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DPEQwk1FJveJhg5Vy_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lXNJlP1FJveZsuPSq_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ponlGV1FJveVBdVc5_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BR76pf1FJveYJ1Jul_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YOYyMu1FJveZsvLg6_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pq3Y1f1FJveSOfyl0_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uQqQ7v1FJveOLnbeu_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01coylPi1FJveQP6SyQ_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EwOq2Z1FJveZ9Y9LM_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01m44Vvm1FJveVBfFi3_!!1080040467.png", val: 9 },
        ],
      }, */
      scorePos: {
        align: "left",
        x: 558,
        y: 230,
        money: true,
        bg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IrhdMn1FJvef5MQEM_!!1080040467.png", x: 434, y: 206 },
        // 分数数字图片 0 - 9
        numOffset: -6,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Ve8sS1FJvebl5J0y_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017EHyrt1FJvebEo1q2_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cv0zNh1FJveOqYcST_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0147f9921FJveYuxkj9_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017CzUN31FJveaLpTeI_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IUNX0n1FJveZB36WB_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gphOoG1FJveZB1tga_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R9M8rn1FJvedU2Nd3_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IxZxFX1FJvecmGnwT_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zIjEmp1FJveVXvVsw_!!1080040467.png", val: 9 },
        ],
      },
      audioObj: {
        default: { audioSrc: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/NN6ynLVRxg2yYI1w4cm?auth_key=1626666187-0-0-5c087934de0a5d734697c319791ad9c0&w=0&h=0&e=sd&t=212a81b716264069872271161e190a" },//默认音效
        single: { audioSrc: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/IR12OBhxcTNEoTTd0Rn?auth_key=1626666241-0-0-47593f470c831d1c5e5bf79b835cd721&w=0&h=0&e=sd&t=212a81b716264070416816698e190a" },//默认音效
      },
    }),
  },
  onLoad(query) {
  },

  playFun() {
    this.gameComponent.onEvent("start");
  },
  resetFun() {
    // this.gameComponent.onEvent("reset", { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Nkhd0l1FJvecI8FYU_!!1080040467.png", probability: 1, val: 20 });
    this.gameComponent.onEvent("reset", 0);
  },
  firstRender() {
    // 主动初始化
    // this.gameComponent.onEvent("init1", { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Nkhd0l1FJvecI8FYU_!!1080040467.png", probability: 1, val: 20 });
    this.gameComponent.onEvent("init1", 0);
  },
  pause() {
    // 暂停、继续
    this.gameComponent.onEvent("pause");
  },
  stop() {
    // 暂停、继续
    this.gameComponent.onEvent("gameOver");
  },

  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
  },
  onUpdate(ops) {
    // { totalScore: 0, imgObj: { } }
    console.log(ops)
  },
  onGameOver(ops) {
    let { totalScore } = ops;
    console.log(ops, totalScore)
  }
})
```

- xaml

```
  <game gameSource="{{gameSource}}" 
    onRef="onRef"
    onInitDone="onInitDone" 
    onUpdate="onUpdate" 
    onGameOver="onGameOver"
    />

  <view onTap="firstRender" style="position:absolute;left: 10%;bottom: 100rpx;">首次初始化</view>
  <view onTap="playFun" style="position:absolute;left: 40%;bottom: 100rpx;">开始</view>
  <view onTap="resetFun" style="position:absolute;left: 50%;bottom: 100rpx;">重置</view>
  <view onTap="pause" style="position:absolute;left: 60%;bottom: 100rpx;">暂停</view>
  <view onTap="stop" style="position:absolute;left: 70%;bottom: 100rpx;">结束</view>
```