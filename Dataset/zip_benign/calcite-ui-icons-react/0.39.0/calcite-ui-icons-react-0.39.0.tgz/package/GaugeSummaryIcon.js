"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GaugeSummaryIcon = function GaugeSummaryIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 14v1h2v1H5a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h1v-1H4a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1zm6 2v-5h-1v2H9v-2H8v3h2v2zm3.8-7h-3a3.75 3.75 0 0 0-.206-1.18l-.83.83A2.766 2.766 0 0 1 10.8 9a2.78 2.78 0 0 1-.192 1h5.12a7.621 7.621 0 0 0-1.144-5.17l-.729.73A6.749 6.749 0 0 1 14.8 9zM8 1.2a7.761 7.761 0 0 1 5.145 1.948l.017-.017.707.707-3.535 3.536-.561-.561-.02.02A2.784 2.784 0 0 0 5.393 10H.27A7.751 7.751 0 0 1 8 1.2zM4.2 9a3.763 3.763 0 0 1 .795-2.298L2.857 4.564A6.765 6.765 0 0 0 1.2 9zM8 2.2a6.765 6.765 0 0 0-4.436 1.657l2.138 2.138a3.722 3.722 0 0 1 4.596 0l2.138-2.138A6.765 6.765 0 0 0 8 2.2zm8 .8l-2-2v2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.707 17.293A.997.997 0 0 1 11 18v1a1 1 0 0 1-1 1H9v1h2v1H9a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h1v-1H8a1 1 0 0 1 1-1h1a.997.997 0 0 1 .707.293zM14 19h-1v-2h-1v3h2v2h1v-5h-1zm6-16v2h2zm.307 4.108A10.75 10.75 0 0 1 22.8 14h-5a5.763 5.763 0 0 0-1.058-3.328l-.72.72a4.741 4.741 0 0 1 .67 3.608h7.058c.027-.33.05-.662.05-1a11.746 11.746 0 0 0-2.783-7.603zM14.65 9.936l-.042.042A4.79 4.79 0 0 0 7.308 15H.25a11.9 11.9 0 0 1-.05-1 11.796 11.796 0 0 1 19.244-9.151l.032-.032.707.707-4.972 4.972zM6.2 14a5.761 5.761 0 0 1 .94-3.154L3.565 7.273A10.74 10.74 0 0 0 1.2 14zM12 8.2a5.761 5.761 0 0 1 3.154.94l3.573-3.574a10.754 10.754 0 0 0-14.5.954l3.534 3.534A5.779 5.779 0 0 1 12 8.2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14 25v-2h-3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2v2h3v1h-3a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1zm3-3v4h3v3h1v-7h-1v3h-2v-3zm10.602-11.16A14.715 14.715 0 0 1 30.8 20h-7a7.743 7.743 0 0 0-1.184-4.111l-.721.73A6.625 6.625 0 0 1 22.718 21h9.031c.021-.332.051-.662.051-1a15.724 15.724 0 0 0-3.484-9.884zM28 6v2h2zm-7.351 9.035A6.78 6.78 0 0 0 9.282 21H.25c-.02-.332-.05-.662-.05-1A15.783 15.783 0 0 1 26.807 8.496l.014-.014.712.702-6.323 6.405zm-10.93.36l-4.977-4.978A14.725 14.725 0 0 0 1.2 20h7a7.748 7.748 0 0 1 1.52-4.606zM16 12.2a7.76 7.76 0 0 1 5.186 1.99L26.1 9.212a14.736 14.736 0 0 0-20.685.465l4.948 4.947A7.772 7.772 0 0 1 16 12.2z"
  }));
};

var _default = GaugeSummaryIcon;
exports["default"] = _default;