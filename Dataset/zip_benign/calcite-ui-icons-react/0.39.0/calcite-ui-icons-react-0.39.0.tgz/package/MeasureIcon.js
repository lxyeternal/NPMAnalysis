"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MeasureIcon = function MeasureIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.376 1.354L2.729 3H7v1H2.73l1.646 1.646-.707.707L.815 3.5 3.67.646zM9 4h4.27l-1.646 1.646.707.707L15.185 3.5 12.33.646l-.707.707L13.271 3H9zM0 8h16v6H0zm1 5h2v-2h1v2h1v-3h1v3h1v-2h1v2h1v-3h1v3h1v-2h1v2h1v-3h1v3h1V9H1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.354 2.646l2.851 2.852-2.82 2.854-.712-.704L21.303 6H16V5h5.293l-1.647-1.646zM.794 5.502l2.852 2.852.707-.707L2.707 6H8V5H2.697l1.63-1.648-.711-.704zM1 12h22v8H1zm1 7h2v-3h1v3h1v-2h1v2h1v-5h1v5h1v-2h1v2h1v-3h1v3h1v-2h1v2h1v-5h1v5h1v-2h1v2h1v-3h1v3h1v-6H2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.293 9H21V8h7.293l-2.647-2.646.707-.707L30.207 8.5l-3.854 3.854-.707-.707zm-21.94 2.646L3.708 9H11V8H3.707l2.647-2.646-.707-.707L1.793 8.5l3.854 3.854zM2 17h28v9H2zm1 8h2v-4h1v4h1v-2h1v2h1v-6h1v6h1v-2h1v2h1v-4h1v4h1v-2h1v2h1v-6h1v6h1v-2h1v2h1v-4h1v4h1v-2h1v2h1v-6h1v6h1v-2h1v2h1v-7H3z"
  }));
};

var _default = MeasureIcon;
exports["default"] = _default;