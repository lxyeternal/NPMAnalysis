"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImagesIcon = function ImagesIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 5V4h2v11H3v-2h1v1h11V5zM0 12V1h13v11zm12-2.087L9.191 7.204l-.686.46a1.267 1.267 0 0 1-1.64-.042L5.362 6.288 3.83 7.924a1.28 1.28 0 0 1-.929.405 1.253 1.253 0 0 1-.23-.022L1 10.09V11h11zM1 8.627L2.3 7.24a.27.27 0 0 1 .4 0 .27.27 0 0 0 .4 0l2.017-2.152a.27.27 0 0 1 .381-.018l2.03 1.804a.269.269 0 0 0 .35.01l1.226-.824a.27.27 0 0 1 .37.028L12 8.524V2H1zM8.5 4.5a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19 7h4v15H6v-4h1v3h15V8h-3zM1 17V2h17v15zm1-5.033l1.683-1.683a.409.409 0 0 1 .576-.002.4.4 0 0 0 .57.012L7.753 7.37a.408.408 0 0 1 .55-.025l2.932 2.443a.408.408 0 0 0 .507.013l1.769-1.327a.409.409 0 0 1 .534.038L17 11.467V3H2zM17 16v-3.119l-3.3-3.3-1.358 1.019a1.407 1.407 0 0 1-1.747-.044L8.078 8.459 5.536 11a1.376 1.376 0 0 1-.98.406 1.397 1.397 0 0 1-.492-.09L2 13.381V16zm-5.5-9.5a1 1 0 1 0-1-1 1 1 0 0 0 1 1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 10v18H8v-5h1v4h20V11h-4v-1zM2 22V4h22v18zm1-5.933l2.533-2.533a.503.503 0 0 1 .704-.008.474.474 0 0 0 .678.049l3.627-3.628a.503.503 0 0 1 .677-.03l3.609 3.007a.503.503 0 0 0 .623.016l2.178-1.634a.503.503 0 0 1 .657.047L23 16.067V5H3zM23 21v-3.519l-5.116-5.116-1.833 1.375a1.502 1.502 0 0 1-1.863-.049l-3.26-2.716-3.307 3.307a1.403 1.403 0 0 1-.997.415 1.506 1.506 0 0 1-.677-.163L3 17.48V21zM14 8.5a1.5 1.5 0 1 1 1.5 1.5A1.5 1.5 0 0 1 14 8.5zm1 0a.5.5 0 1 0 .5-.5.5.5 0 0 0-.5.5z"
  }));
};

var _default = ImagesIcon;
exports["default"] = _default;