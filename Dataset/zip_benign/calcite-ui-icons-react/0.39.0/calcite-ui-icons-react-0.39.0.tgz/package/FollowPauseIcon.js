"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FollowPauseIcon = function FollowPauseIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 10V9h1v1zm-2 5h5v-1H2v-4H1zm0-9h1V2h4V1H1zm3 7v-1H3v1zm8-8H9v1h3zm0 11H9V9h3zm-1-6h-1v5h1zM7 4h1V1H7zM5 8V7H4v1zm8 1h3v7h-3zm1 6h1v-5h-1zM10 2h4v4h1V1h-5zM3 6h3V5H3zm5-1H7v1h1zm0 2H7v2.99h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19 9h-4V8h4zm-7 6h1v-4h-1zm2-7.25v1.5a.75.75 0 0 1-.75.75h-1.5a.75.75 0 0 1-.75-.75v-1.5a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 .75.75zM13 8h-1v1h1zm-5 5h2v-2H8zM6 9h4V8H6zm-3 7H2v6h6v-1H3zM16 3h5v5h1V2h-6zM8 2H2v6h1V3h5zm5 0h-1v4h1zM6 16h2v-2H6zm1 3v-2H5v2zm9-4h3v8h-3zm1 7h1v-6h-1zm3-7h3v8h-3zm1 7h1v-6h-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26 30h4V19h-4zm1-10h2v9h-2zm-2-1h-4v11h4zm-1 10h-2v-9h2zm-5-17.93A1.07 1.07 0 0 0 17.93 10h-.86A1.07 1.07 0 0 0 16 11.07v.86A1.07 1.07 0 0 0 17.07 13h.86A1.07 1.07 0 0 0 19 11.93zM18 12h-1v-1h1zm-1 2h1v6h-1zM28 4h-6V3h7v7h-1zM4 10H3V3h7v1H4zm8 5h2v2h-2zm3-3H9v-1h6zm11 0h-6v-1h6zM7 23h2v2H7zm3-3H8v-2h2zm8-11h-1V3h1zm-8 20H3v-7h1v6h6z"
  }));
};

var _default = FollowPauseIcon;
exports["default"] = _default;