"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LockIcon = function LockIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 1a4.012 4.012 0 0 0-4 4v2H3a1.003 1.003 0 0 0-1 1v7a1.003 1.003 0 0 0 1 1h10a1.003 1.003 0 0 0 1-1V8a1.003 1.003 0 0 0-1-1h-1V5a4.012 4.012 0 0 0-4-4zM5 5a3 3 0 0 1 6 0v2h-1V5a2 2 0 0 0-4 0v2H5zm4 2H7V5a1 1 0 0 1 2 0zm4 1v7H3V8zm-5 2h1v1H8v1h1v1H8v1H7V9h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 14h1v1h-1zm-1 6h1v-1h1v-1h-1v-1h1v-1h-1v-1h-1zM6 7a6 6 0 0 1 12 0v3h1.5a1.504 1.504 0 0 1 1.5 1.5v10a1.504 1.504 0 0 1-1.5 1.5h-15A1.504 1.504 0 0 1 3 21.5v-10A1.504 1.504 0 0 1 4.5 10H6zm12 4H4.5a.506.506 0 0 0-.5.5v10a.506.506 0 0 0 .5.5h15a.506.506 0 0 0 .5-.5v-10a.506.506 0 0 0-.5-.5zm-3-4a3 3 0 0 0-6 0v3h6zm-8 3h1V7a4 4 0 0 1 8 0v3h1V7A5 5 0 0 0 7 7z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 10v3h-1v-3a5 5 0 0 0-10 0v3h-1v-3a6 6 0 0 1 12 0zm3 20H7a2.006 2.006 0 0 1-2-2V16a2.006 2.006 0 0 1 2-2h1v-4a8 8 0 0 1 16 0v4h1a2.006 2.006 0 0 1 2 2v12a2.006 2.006 0 0 1-2 2zM9 14h1v-1h1v1h10v-1h1v1h1v-4a7 7 0 0 0-14 0zM7 29h18a1.001 1.001 0 0 0 1-1V16a1.001 1.001 0 0 0-1-1H7a1.001 1.001 0 0 0-1 1v12a1.001 1.001 0 0 0 1 1zm9-10h1v-1h-1zm-1 7h1v-1h1v-1h-1v-1h1v-1h-1v-1h1v-1h-1v-1h-1z"
  }));
};

var _default = LockIcon;
exports["default"] = _default;