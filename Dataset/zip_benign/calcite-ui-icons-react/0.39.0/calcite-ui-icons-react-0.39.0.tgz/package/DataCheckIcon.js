"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DataCheckIcon = function DataCheckIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 4C15 .324 1 .324 1 4v7.8c0 1.764 2.958 2.79 6.036 2.969l-.862-.863a1.496 1.496 0 0 1-.195-.242C3.484 13.34 2 12.469 2 11.8V8.51A12.006 12.006 0 0 0 8 9.8a14.116 14.116 0 0 0 5.199-.867L15 7.132zM8 2.2c3.663 0 6 1.066 6 1.8s-2.337 1.8-6 1.8S2 4.734 2 4s2.337-1.8 6-1.8zm0 6.6C4.337 8.8 2 7.734 2 7V5.511A12.006 12.006 0 0 0 8 6.8a12.006 12.006 0 0 0 6-1.289V7c0 .734-2.337 1.8-6 1.8zm6.527.926l.738.737-5.208 5.205-2.322-2.322.738-.738 1.584 1.588z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.238 20.746C5.714 20.481 3 19.228 3 18.3v-6.282c1.708 1.173 5.366 1.782 9 1.782s7.292-.609 9-1.782v1.2l.915-.364c.028-.012.057-.015.085-.025V5.5c0-2.167-5.03-3.3-10-3.3S2 3.333 2 5.5v12.8c0 2.155 4.628 3.367 9.239 3.488l-.634-.596a2.493 2.493 0 0 1-.367-.446zM12 3.2c5.494 0 9 1.362 9 2.3s-3.506 2.3-9 2.3-9-1.362-9-2.3 3.506-2.3 9-2.3zM3 7.018C4.708 8.191 8.366 8.8 12 8.8s7.292-.609 9-1.782V10.5c0 .938-3.506 2.3-9 2.3s-9-1.363-9-2.3zm19.491 7.8l.7.716-7.684 7.522-3.531-3.32.685-.73 2.832 2.664z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14.609 27.774C8.29 27.552 4 25.844 4 24.3v-8.074c2.09 1.68 7.156 2.574 12 2.574s9.91-.894 12-2.574v3.256l1-.985V7.5c0-2.793-6.698-4.3-13-4.3S3 4.707 3 7.5v16.8c0 2.799 6.141 4.36 12.195 4.487l-.015-.015a1.999 1.999 0 0 1-.571-.998zM16 4.2c6.868 0 12 1.742 12 3.3s-5.132 3.3-12 3.3S4 9.058 4 7.5s5.132-3.3 12-3.3zM4 9.226c2.09 1.68 7.156 2.574 12 2.574s9.91-.894 12-2.574V14.5c0 1.558-5.132 3.3-12 3.3S4 16.058 4 14.5zM30.547 19.78l.701.712L20.513 31.07l-3.957-3.75.687-.725L20.5 29.68z"
  }));
};

var _default = DataCheckIcon;
exports["default"] = _default;