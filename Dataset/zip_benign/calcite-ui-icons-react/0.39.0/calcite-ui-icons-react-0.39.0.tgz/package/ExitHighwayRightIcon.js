"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ExitHighwayRightIcon = function ExitHighwayRightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 8.886a6.411 6.411 0 0 1 1-.85V2H4zm7.5-7.077l2.81 2.81-.708.706L12 3.723V4c0 3.385-2.074 4.346-3.904 5.194C6.435 9.964 5 10.63 5 13v1H4v-1c0-3.01 1.953-3.915 3.675-4.713C9.46 7.46 11 6.747 11 4v-.277L9.398 5.325l-.707-.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 14.907a7.418 7.418 0 0 1 1-1.11V3H7zM17 6.5c0 4.896-2.608 6.306-4.91 7.55C9.897 15.237 8 16.262 8 20v1H7v-1c0-4.333 2.347-5.602 4.616-6.83C13.87 11.953 16 10.8 16 6.5V3.707l-1.64 1.64-.707-.706L16.5 1.793l2.847 2.848-.707.707L17 3.708z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9 20.273a8.957 8.957 0 0 1 1-1.29V4H9zM23 8c0 6.44-3.713 8.293-6.989 9.929C12.921 19.472 10 20.929 10 26v2H9v-2c0-5.69 3.337-7.355 6.564-8.967C18.874 15.382 22 13.821 22 8V4.692l-2.661 2.662-.707-.707 3.853-3.854 3.854 3.854-.707.707L23 4.722z"
  }));
};

var _default = ExitHighwayRightIcon;
exports["default"] = _default;