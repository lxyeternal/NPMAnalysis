"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HaloIcon = function HaloIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 16a5.006 5.006 0 0 0 5-5V6a5.006 5.006 0 0 0-5-5H6a5.006 5.006 0 0 0-5 5v5a5.006 5.006 0 0 0 5 5zm-9-5V6a4.004 4.004 0 0 1 4-4h5a4.004 4.004 0 0 1 4 4v5a4.004 4.004 0 0 1-4 4H6a4.004 4.004 0 0 1-4-4z",
      opacity: ".1"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 15a4.004 4.004 0 0 0 4-4V6a4.004 4.004 0 0 0-4-4H6a4.004 4.004 0 0 0-4 4v5a4.004 4.004 0 0 0 4 4zm-8-4V6a3.003 3.003 0 0 1 3-3h5a3.003 3.003 0 0 1 3 3v5a3.003 3.003 0 0 1-3 3H6a3.003 3.003 0 0 1-3-3z",
      opacity: ".2"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 14a3.003 3.003 0 0 0 3-3V6a3.003 3.003 0 0 0-3-3H6a3.003 3.003 0 0 0-3 3v5a3.003 3.003 0 0 0 3 3zm-7-3V6a2.002 2.002 0 0 1 2-2h5a2.002 2.002 0 0 1 2 2v5a2.002 2.002 0 0 1-2 2H6a2.002 2.002 0 0 1-2-2z",
      opacity: ".3"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 13a2.002 2.002 0 0 0 2-2V6a2.002 2.002 0 0 0-2-2H6a2.002 2.002 0 0 0-2 2v5a2.002 2.002 0 0 0 2 2zm-6-2V6a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z",
      opacity: ".4"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1zM6 6h5v5H6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.75 1H7.25A6.257 6.257 0 0 0 1 7.25v10.5A6.257 6.257 0 0 0 7.25 24h10.5A6.257 6.257 0 0 0 24 17.75V7.25A6.257 6.257 0 0 0 17.75 1zM23 17.75A5.256 5.256 0 0 1 17.75 23H7.25A5.256 5.256 0 0 1 2 17.75V7.25A5.256 5.256 0 0 1 7.25 2h10.5A5.256 5.256 0 0 1 23 7.25z",
      opacity: ".1"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.75 2H7.25A5.256 5.256 0 0 0 2 7.25v10.5A5.256 5.256 0 0 0 7.25 23h10.5A5.256 5.256 0 0 0 23 17.75V7.25A5.256 5.256 0 0 0 17.75 2zM22 17.75A4.255 4.255 0 0 1 17.75 22H7.25A4.255 4.255 0 0 1 3 17.75V7.25A4.255 4.255 0 0 1 7.25 3h10.5A4.255 4.255 0 0 1 22 7.25z",
      opacity: ".2"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.75 3H7.25A4.255 4.255 0 0 0 3 7.25v10.5A4.255 4.255 0 0 0 7.25 22h10.5A4.255 4.255 0 0 0 22 17.75V7.25A4.255 4.255 0 0 0 17.75 3zM21 17.75A3.254 3.254 0 0 1 17.75 21H7.25A3.254 3.254 0 0 1 4 17.75V7.25A3.254 3.254 0 0 1 7.25 4h10.5A3.254 3.254 0 0 1 21 7.25z",
      opacity: ".3"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.75 4H7.25A3.254 3.254 0 0 0 4 7.25v10.5A3.254 3.254 0 0 0 7.25 21h10.5A3.254 3.254 0 0 0 21 17.75V7.25A3.254 3.254 0 0 0 17.75 4zM20 17.75A2.253 2.253 0 0 1 17.75 20H7.25A2.253 2.253 0 0 1 5 17.75V7.25A2.253 2.253 0 0 1 7.25 5h10.5A2.253 2.253 0 0 1 20 7.25z",
      opacity: ".4"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.75 5H7.25A2.253 2.253 0 0 0 5 7.25v10.5A2.253 2.253 0 0 0 7.25 20h10.5A2.253 2.253 0 0 0 20 17.75V7.25A2.253 2.253 0 0 0 17.75 5zM19 17.75A1.251 1.251 0 0 1 17.75 19H7.25A1.251 1.251 0 0 1 6 17.75V7.25A1.251 1.251 0 0 1 7.25 6h10.5A1.251 1.251 0 0 1 19 7.25z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.75 6H7.25A1.251 1.251 0 0 0 6 7.25v10.5A1.251 1.251 0 0 0 7.25 19h10.5A1.251 1.251 0 0 0 19 17.75V7.25A1.251 1.251 0 0 0 17.75 6zM18 17.75a.25.25 0 0 1-.25.25H7.25a.25.25 0 0 1-.25-.25V7.25A.25.25 0 0 1 7.25 7h10.5a.25.25 0 0 1 .25.25z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 1h-16A7.508 7.508 0 0 0 1 8.5v16A7.508 7.508 0 0 0 8.5 32h16a7.508 7.508 0 0 0 7.5-7.5v-16A7.508 7.508 0 0 0 24.5 1zM31 24.5a6.508 6.508 0 0 1-6.5 6.5h-16A6.508 6.508 0 0 1 2 24.5v-16A6.508 6.508 0 0 1 8.5 2h16A6.508 6.508 0 0 1 31 8.5z",
    opacity: ".05"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 2h-16A6.508 6.508 0 0 0 2 8.5v16A6.508 6.508 0 0 0 8.5 31h16a6.508 6.508 0 0 0 6.5-6.5v-16A6.508 6.508 0 0 0 24.5 2zM30 24.5a5.507 5.507 0 0 1-5.5 5.5h-16A5.507 5.507 0 0 1 3 24.5v-16A5.507 5.507 0 0 1 8.5 3h16A5.507 5.507 0 0 1 30 8.5z",
    opacity: ".1"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 3h-16A5.507 5.507 0 0 0 3 8.5v16A5.507 5.507 0 0 0 8.5 30h16a5.507 5.507 0 0 0 5.5-5.5v-16A5.507 5.507 0 0 0 24.5 3zM29 24.5a4.505 4.505 0 0 1-4.5 4.5h-16A4.505 4.505 0 0 1 4 24.5v-16A4.505 4.505 0 0 1 8.5 4h16A4.505 4.505 0 0 1 29 8.5z",
    opacity: ".2"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 4h-16A4.505 4.505 0 0 0 4 8.5v16A4.505 4.505 0 0 0 8.5 29h16a4.505 4.505 0 0 0 4.5-4.5v-16A4.505 4.505 0 0 0 24.5 4zM28 24.5a3.504 3.504 0 0 1-3.5 3.5h-16A3.504 3.504 0 0 1 5 24.5v-16A3.504 3.504 0 0 1 8.5 5h16A3.504 3.504 0 0 1 28 8.5z",
    opacity: ".3"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 5h-16A3.504 3.504 0 0 0 5 8.5v16A3.504 3.504 0 0 0 8.5 28h16a3.504 3.504 0 0 0 3.5-3.5v-16A3.504 3.504 0 0 0 24.5 5zM27 24.5a2.503 2.503 0 0 1-2.5 2.5h-16A2.503 2.503 0 0 1 6 24.5v-16A2.503 2.503 0 0 1 8.5 6h16A2.503 2.503 0 0 1 27 8.5z",
    opacity: ".4"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 6h-16A2.503 2.503 0 0 0 6 8.5v16A2.503 2.503 0 0 0 8.5 27h16a2.503 2.503 0 0 0 2.5-2.5v-16A2.503 2.503 0 0 0 24.5 6zM26 24.5a1.502 1.502 0 0 1-1.5 1.5h-16A1.502 1.502 0 0 1 7 24.5v-16A1.502 1.502 0 0 1 8.5 7h16A1.502 1.502 0 0 1 26 8.5z",
    opacity: ".5"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 7h-16A1.502 1.502 0 0 0 7 8.5v16A1.502 1.502 0 0 0 8.5 26h16a1.502 1.502 0 0 0 1.5-1.5v-16A1.502 1.502 0 0 0 24.5 7zm.5 17.5a.5.5 0 0 1-.5.5h-16a.5.5 0 0 1-.5-.5v-16a.5.5 0 0 1 .5-.5h16a.5.5 0 0 1 .5.5z"
  }));
};

var _default = HaloIcon;
exports["default"] = _default;