"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GroupXIcon = function GroupXIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 3h-1V2h-1V1h2zM2 14H1v-1H0v2h2zM1 2h1V1H0v2h1zm3 0h3V1H4zM1 5H0v2h1zm0 4H0v2h1zm14-2h1V5h-1zm-3-6H9v1h3zM4 15h3v-1H4zm8.518-1.81l2.275 2.274.707-.707-2.275-2.275 2.275-2.275-.707-.707-2.275 2.275L10.243 9.5l-.707.707 2.275 2.275-2.275 2.275.707.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 20h1v1H1v-2h1zM1 5h1V4h1V3H1zm1 2H1v2h1zm0 4H1v2h1zm20-2h1V7h-1zM2 15H1v2h1zM5 4h2V3H5zm4 0h2V3H9zm4 0h2V3h-2zm4 0h2V3h-2zM5 21h2v-1H5zm4 0h2v-1H9zM23 3h-2v1h1v1h1zm-5 14.293l-4.146-4.147-.708.708L17.293 18l-4.147 4.146.708.708L18 18.707l4.146 4.147.708-.708L18.707 18l4.147-4.146-.708-.708z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 6h-1V5h2v2h-1zM3 9H2v2h1zm0 4H2v2h1zm27-4h-1v2h1zm-1 6h1v-2h-1zM3 17H2v2h1zm0 4H2v2h1zM5 6h2V5H5zm4 0h2V5H9zm4 0h2V5h-2zm6-1h-2v1h2zm4 0h-2v1h2zm4 0h-2v1h2zM3 25H2v2h2v-1H3zM2 7h1V6h1V5H2zm3 20h2v-1H5zm4 0h2v-1H9zm4 0h2v-1h-2zm16.843-9.136l-.707-.707-5.636 5.636-5.636-5.636-.707.707 5.636 5.636-5.636 5.636.707.707 5.636-5.636 5.636 5.636.707-.707-5.636-5.636z"
  }));
};

var _default = GroupXIcon;
exports["default"] = _default;