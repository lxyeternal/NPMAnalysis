"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ConvertIcon = function ConvertIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.5 1H10V0h.5A2.503 2.503 0 0 1 13 2.5V3h1.176L12.5 5.058 10.824 3H12v-.5A1.502 1.502 0 0 0 10.5 1zM8 0H0v9h7V8H1V1h6v6a1 1 0 0 1 1-1zm8 9v7H8V7h6zm-1 1h-2V8H9v7h6zm0-1l-1-1v1zM5 2H2v1h3zM4 4H2v1h2zM2 7h2V6H2zm4-1H5v1h1zm0-2H5v1h1zm4 7h4v3h-4zm1 2h2v-1h-2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.354 5.354L18.506 8.2l-2.847-2.847.707-.707L18 6.28V4a2.003 2.003 0 0 0-2-2h-2V1h2a3.003 3.003 0 0 1 3 3v2.293l1.646-1.646zM1 1v13h11V1zm10 12H2V2h9zm9.4-3H13v13h11v-9.4zM23 22h-9V11h5v4h4zm0-8h-3v-3h.31L23 13.69zM8 4H3v1h5zM7 6H3v1h4zm3 0H8v1h2zM8 8H3v1h5zm2 0H9v1h1zm-3 2H3v1h4zm3 0H8v1h2zm12 6v5h-7v-5zm-1 1h-5v3h5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.354 8.34L23.5 12.193 19.646 8.34l.707-.707L23 10.279V7a3.003 3.003 0 0 0-3-3h-2V3h2a4.004 4.004 0 0 1 4 4v3.28l2.646-2.647zM2 2v16h13V2zm12 15H3V3h11zm11.29-3H17v16h13V18.709zM29 29H18V15h6v5h5zm0-10h-4v-4h.2l3.8 3.8zM10 5H4v1h6zm0 6H4v1h6zm3 0h-2v1h2zm-4 2H4v1h5zm4 0h-3v1h3zm-3-4H4v1h6zm3 0h-2v1h2zM9 7H4v1h5zm4 0h-3v1h3zm15 14v7h-9v-7zm-1 1h-7v5h7z"
  }));
};

var _default = ConvertIcon;
exports["default"] = _default;