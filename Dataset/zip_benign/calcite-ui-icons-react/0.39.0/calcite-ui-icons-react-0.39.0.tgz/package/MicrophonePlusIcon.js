"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MicrophonePlusIcon = function MicrophonePlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 13v2h2v1H4v-1h3v-1.09A6.004 6.004 0 0 1 2 8h1a5.006 5.006 0 0 0 5 5zm0-2a3.003 3.003 0 0 1-3-3V3a3 3 0 0 1 6 0v5a3.003 3.003 0 0 1-3 3zm0-1a2.003 2.003 0 0 0 2-2V3a2 2 0 0 0-4 0v5a2.003 2.003 0 0 0 2 2zm4 3v3h1v-3h3v-1h-3V9h-1v3H9v1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 5.5v6a4.5 4.5 0 0 0 9 0v-6a4.5 4.5 0 0 0-9 0zm8 0v6a3.5 3.5 0 0 1-7 0v-6a3.5 3.5 0 0 1 7 0zM16 22v1H6v-1h5v-2.025A8.504 8.504 0 0 1 3 11.5V11h1v.536a7.51 7.51 0 0 0 7.5 7.5c.169 0 .334-.015.5-.026V22zm3-4h4v.999h-4V23h-1v-4.001h-4V18h4v-4h1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 29v1H9v-1h7v-3.025A9.504 9.504 0 0 1 7 16.5V16h1v.5a8.51 8.51 0 0 0 8.5 8.5h.5v4zM11 16.5v-8a5.5 5.5 0 0 1 11 0v8a5.5 5.5 0 0 1-11 0zm1 0a4.5 4.5 0 0 0 9 0v-8a4.5 4.5 0 0 0-9 0zM25 24v-5h-1v5h-5v.999h5V30h1v-5.001h5V24z"
  }));
};

var _default = MicrophonePlusIcon;
exports["default"] = _default;