"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BrushTipIcon = function BrushTipIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.84 10h.32a22.4 22.4 0 0 1 .836 6h1a24.643 24.643 0 0 0-.868-6.22A2.878 2.878 0 0 0 10.98 7.3a5.944 5.944 0 0 0-.824-2.638A8.67 8.67 0 0 1 9 .57V0h-.501C5.572 1.13 5 4.612 5 5.594 5 7.56 5.61 9.07 6.88 9.76A24.524 24.524 0 0 0 6.003 16h1a22.4 22.4 0 0 1 .836-6zm.202-8.606a10.267 10.267 0 0 0 1.219 3.712A5.152 5.152 0 0 1 9.98 7.3a1.238 1.238 0 0 1-.13.53 1.48 1.48 0 0 1-1.402-1.244 3.202 3.202 0 0 0-2.281-2.348 6.13 6.13 0 0 1 1.875-2.844zM5.96 5.214a2.212 2.212 0 0 1 1.543 1.699 2.362 2.362 0 0 0 1.601 1.74A3.778 3.778 0 0 1 8.415 9H7.59c-1.358-.537-1.775-2.375-1.63-3.785z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.318 15h1.364a17.084 17.084 0 0 1 1.203 8h1.007a18.203 18.203 0 0 0-1.253-8.265 4.122 4.122 0 0 0 2.323-3.371 6.16 6.16 0 0 0-1.205-3.222A9.067 9.067 0 0 1 13.1 3v-.756l-.696.296A8.347 8.347 0 0 0 8 9.5a6.776 6.776 0 0 0 2.392 5.158A18.148 18.148 0 0 0 9.108 23h1.007a17.084 17.084 0 0 1 1.203-8zm.814-11.175a10.342 10.342 0 0 0 1.77 4.835 5.272 5.272 0 0 1 1.06 2.704 2.06 2.06 0 0 1-.09.589 3.783 3.783 0 0 1-3.335-2.317 6.014 6.014 0 0 0-1.965-2.627 7.72 7.72 0 0 1 2.56-3.184zM9 9.5a5.662 5.662 0 0 1 .233-1.534 5.545 5.545 0 0 1 1.392 2.08 4.655 4.655 0 0 0 3.725 2.839A4.805 4.805 0 0 1 12.89 14h-1.733A5.784 5.784 0 0 1 9 9.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14 29.975c-.004-.075-.35-7.28.855-10.975h2.29c1.206 3.695.86 10.9.855 10.975l.96.025c.023-.46.376-7.395-.85-11.24A5.01 5.01 0 0 0 21 14.5a9.268 9.268 0 0 0-1.26-4.162A14.404 14.404 0 0 1 18 3.367V2.61l-.696.297C14.31 4.182 11 8.313 11 11.933c0 2.767 1.127 5.462 2.913 6.755-1.253 3.83-.896 10.85-.874 11.312zm3.019-25.809a15.662 15.662 0 0 0 1.82 6.61A8.386 8.386 0 0 1 20 14.5a3.027 3.027 0 0 1-.068.556 5.092 5.092 0 0 1-4.255-3.14 7.78 7.78 0 0 0-2.595-3.584 11.388 11.388 0 0 1 3.937-4.166zM12 11.933a6.837 6.837 0 0 1 .628-2.695 6.983 6.983 0 0 1 2.137 3.088 6.035 6.035 0 0 0 4.839 3.689A5.118 5.118 0 0 1 17.394 18h-2.75C13.047 16.959 12 14.437 12 11.933z"
  }));
};

var _default = BrushTipIcon;
exports["default"] = _default;