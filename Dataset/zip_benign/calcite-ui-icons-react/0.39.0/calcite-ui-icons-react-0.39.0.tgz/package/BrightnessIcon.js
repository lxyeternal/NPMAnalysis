"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BrightnessIcon = function BrightnessIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.153 5.554l-.707-.707 2.2-2.2.708.707zm-9.507 8.092l.707.707 2.2-2.2-.706-.707zm8.8-1.493l2.2 2.2.707-.706-2.2-2.2zM5.554 4.847l-2.2-2.2-.707.706 2.2 2.2zM9 1H8v3h1zM8 16h1v-3H8zm8-7V8h-3v1zM1 9h3V8H1zm4-.5A3.5 3.5 0 1 1 8.5 12 3.5 3.5 0 0 1 5 8.5zm1 0A2.5 2.5 0 1 0 8.5 6 2.503 2.503 0 0 0 6 8.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.5 5.8c-.168 0-.334.013-.5.025V2h1v3.837c-.167-.012-.331-.037-.5-.037zM12 19.175V23h1v-3.837c-.167.012-.331.037-.5.037-.168 0-.334-.013-.5-.025zm7.2-6.675c0 .168-.013.334-.025.5H23v-1h-3.831c.012.166.03.332.03.5zM5.837 12H2v1h3.844c-.012-.167-.044-.33-.044-.5 0-.17.025-.333.037-.5zm11.736-3.866l2.705-2.705-.707-.707-2.702 2.702a6.687 6.687 0 0 1 .704.71zM4.722 19.57l.707.707 2.729-2.729a6.74 6.74 0 0 1-.713-.7zm12.128-2.014l2.721 2.721.707-.707-2.72-2.72a6.653 6.653 0 0 1-.708.706zM8.132 7.425L5.43 4.722l-.707.707 2.704 2.704a6.672 6.672 0 0 1 .706-.708zM17.8 12.5a5.3 5.3 0 1 1-2.337-4.395A5.282 5.282 0 0 1 17.8 12.5zm-.985 0a4.315 4.315 0 1 0-4.315 4.315 4.32 4.32 0 0 0 4.315-4.315z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 16v1h-4.825c.01-.167.025-.332.025-.5 0-.168-.014-.334-.024-.5zM17 7.825V3h-1v4.823c.166-.01.332-.023.5-.023s.334.015.5.025zM7.825 16H3v1h4.824c-.01-.166-.024-.332-.024-.5 0-.168.016-.334.025-.5zM16 25.175V30h1v-4.823c-.166.01-.332.023-.5.023s-.334-.015-.5-.025zm6.5-2.375c-.07.067-.146.125-.218.189l3.41 3.41.707-.707-3.409-3.408a8.809 8.809 0 0 1-.49.516zm.3-12.299c.067.07.125.145.189.217l3.41-3.41-.707-.707-3.408 3.408c.176.158.351.318.516.492zm-12.3-.3c.07-.068.146-.126.218-.19l-3.41-3.41-.707.707 3.409 3.408c.157-.176.317-.351.49-.516zm-.3 12.298c-.067-.07-.125-.145-.189-.217l-3.41 3.41.707.707 3.408-3.408a8.772 8.772 0 0 1-.516-.492zm13.08-8.71a7.327 7.327 0 1 1-1.494-2.324 7.282 7.282 0 0 1 1.494 2.323zm-4.44 8.562a6.326 6.326 0 1 0-2.34.449 6.269 6.269 0 0 0 2.34-.449z"
  }));
};

var _default = BrightnessIcon;
exports["default"] = _default;