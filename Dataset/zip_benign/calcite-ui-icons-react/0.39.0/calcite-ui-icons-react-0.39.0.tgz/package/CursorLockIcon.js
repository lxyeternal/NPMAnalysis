"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CursorLockIcon = function CursorLockIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.174 6.976L1 1.012V11.1l2.116-2.902L5 11.928l2.555-1.285-1.838-3.667zm-2.961 3.222l-.77.388L3.27 6.288 2 8.032V2.979l4.106 2.997h-2.01zM14.25 10H14V9a2 2 0 0 0-4 0v1h-.25a.751.751 0 0 0-.75.75v3.5a.751.751 0 0 0 .75.75h4.5a.751.751 0 0 0 .75-.75v-3.5a.751.751 0 0 0-.75-.75zM11 9a1 1 0 0 1 2 0v1h-2zm3 5h-4v-3h4zm-1-1h-2v-1h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.813 11L2 1.65v15.812l3.345-4.584L8.45 19.03l3.94-1.981L9.359 11zm-3.764 5.604l-2.155 1.084-3.393-6.72L3 14.395V3.618L11.746 10H7.74zM22.125 16H22v-1.5a3.5 3.5 0 0 0-7 0V16h-.125a.877.877 0 0 0-.875.875v5.25a.877.877 0 0 0 .875.875h7.25a.877.877 0 0 0 .875-.875v-5.25a.877.877 0 0 0-.875-.875zM16 14.5a2.5 2.5 0 0 1 5 0V16h-1v-1.5a1.5 1.5 0 0 0-3 0V16h-1zm3 1.5h-1v-1.5a.5.5 0 0 1 1 0zm3 6h-7v-5h7zm-3-3h1v1h-1v1h-1v-3h1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18.425 14L2 2.016v20.266l4.3-5.894 4.062 8.043 5.016-2.523L11.416 14zm-4.376 7.467L10.8 23.102l-4.346-8.606-3.464 4.749V3.964l12.398 9.046H9.813zM29 21h-1v-2a4 4 0 0 0-8 0v2h-1a1.003 1.003 0 0 0-1 1v7a1.003 1.003 0 0 0 1 1h10a1.003 1.003 0 0 0 1-1v-7a1.003 1.003 0 0 0-1-1zm-8-2a3 3 0 0 1 6 0v2h-1v-2a2 2 0 0 0-4 0v2h-1zm4 2h-2v-2a1 1 0 0 1 2 0zm4 8H19v-7h10zm-5-5h1v1h-1v1h1v1h-1v1h-1v-5h1z"
  }));
};

var _default = CursorLockIcon;
exports["default"] = _default;