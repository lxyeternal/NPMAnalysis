"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LightRainIcon = function LightRainIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.618 16l.936-2h1.104l-.936 2zm-.96-2H4.554l-.936 2h1.104zm4.428 1h1.104l.468-1h-1.104zm2.414-2h-9a2.498 2.498 0 0 1-.454-4.954 2.462 2.462 0 0 1 3.069-1.96 3.989 3.989 0 0 1 7.816.226A3.496 3.496 0 0 1 12.5 13zM4.03 8.227l-.125.677-.678.125A1.498 1.498 0 0 0 3.5 12h9a2.496 2.496 0 0 0 1.02-4.776l-.483-.218-.092-.522a2.989 2.989 0 0 0-5.857-.17l-.233.992-.987-.252A1.462 1.462 0 0 0 4.03 8.227z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.38 23H4.277l1.871-4h1.105zm3.469-1l1.403-3H9.147l-1.403 3zm6.298-3l-1.87 4h1.104l1.871-4zm-8.28-1h-1.43a3.438 3.438 0 0 1 0-6.875l.012.001A3.369 3.369 0 0 1 9.4 9.24a5.494 5.494 0 0 1 10.548-.521A4.807 4.807 0 0 1 18.187 18zM3 14.562A2.44 2.44 0 0 0 5.438 17h12.75a3.807 3.807 0 0 0 1.394-7.351l-.429-.17-.15-.436a4.494 4.494 0 0 0-8.629.426l-.232.99-.986-.25a2.407 2.407 0 0 0-.594-.084 2.443 2.443 0 0 0-2.206 1.42l-.268.581h-.715A2.442 2.442 0 0 0 3 14.563z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.787 31H5.682l2.34-5h1.104zm5.234-5l-1.87 4h1.104l1.87-4zm6.597 3h1.104l1.404-3H20.02zM3.678 17a4.486 4.486 0 0 1 2.594-.988A4.487 4.487 0 0 1 10.5 13a4.46 4.46 0 0 1 .64.065 7.497 7.497 0 0 1 14.553-.678A6.496 6.496 0 0 1 23.5 25H6.672a4.614 4.614 0 0 1-4.608-3.727A4.492 4.492 0 0 1 3.68 17zm.092 1.313a3.485 3.485 0 0 0-.72 2.795A3.621 3.621 0 0 0 6.673 24H23.5a5.496 5.496 0 0 0 1.855-10.671l-.478-.172-.143-.488a6.497 6.497 0 0 0-12.612.586l-.18.935-1.01-.145A3.172 3.172 0 0 0 10.5 14a3.497 3.497 0 0 0-3.285 2.344l-.223.633-.67.034a3.507 3.507 0 0 0-2.552 1.302z"
  }));
};

var _default = LightRainIcon;
exports["default"] = _default;