"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BananaIcon = function BananaIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.456 2.117a1.756 1.756 0 0 0-1.676-1.052c-1.646.162-1.713 1.5-1.772 2.68a7.026 7.026 0 0 1-.555 2.794 3.29 3.29 0 0 0-1.86-.554c-2.986 0-4.445 1.982-4.563 3.043a2.278 2.278 0 0 0 .412 1.672.483.483 0 0 0 .075.058c-.329.088-.667.17-1.017.242H2v3.01l1.302-.027a5.508 5.508 0 0 0 3.384 1.022 7.641 7.641 0 0 0 1.294-.112 6.54 6.54 0 0 0 2.914-1.237 3.735 3.735 0 0 1-.615 1.365.5.5 0 0 0 .164.886 1.31 1.31 0 0 0 .348.045 3.238 3.238 0 0 0 2.314-1.431 4.136 4.136 0 0 0 .45-4.425c1.776-2.587 1.925-6.159.9-7.979zm-2.45 1.678c.069-1.364.151-1.664.871-1.733.309-.042.557.279.707.545.722 1.284.756 4.268-.64 6.587a4.926 4.926 0 0 0-1.1-.892 3.648 3.648 0 0 0-.625-1.069 7.615 7.615 0 0 0 .788-3.438zM5.025 9.138c.07-.633 1.198-2.153 3.57-2.153a2.328 2.328 0 0 1 1.871.899A6.811 6.811 0 0 0 5.017 9.44a1.689 1.689 0 0 1 .007-.302zm3.492-.214a11.09 11.09 0 0 1-3.122 1.573 5.212 5.212 0 0 1 3.122-1.573zM11.13 11.9a4.611 4.611 0 0 1-3.32 2.008 5.089 5.089 0 0 1-3.831-.675v-.166c2.611-.003 5.037-.085 6.371-1.712l-.773-.635c-1.047 1.277-3.137 1.347-5.598 1.348v-.164a12.308 12.308 0 0 0 6.144-3.04c.25.02.515.065.78.112a9.141 9.141 0 0 1 .292 2.794c-.021.044-.041.087-.065.13zm1.178 2.017a3.385 3.385 0 0 1-.662.665 9.6 9.6 0 0 0 .448-4.849 2.666 2.666 0 0 1 .422.522 3.166 3.166 0 0 1-.208 3.662z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 6.5C22 3.21 20.86 1 19.166 1c-1.572 0-1.837 1.553-2.118 3.196a10.67 10.67 0 0 1-1.404 4.25 4.722 4.722 0 0 0-3.403-1.418 6.499 6.499 0 0 0-4.877 1.696A5.317 5.317 0 0 0 6 12.567v.933l.884.32A8.074 8.074 0 0 1 13.5 11l.212.003A17.99 17.99 0 0 1 4.506 16H3v2.98l1.434.06A13.236 13.236 0 0 0 9.5 20a11.778 11.778 0 0 0 7.19-2.47 18.22 18.22 0 0 1-1.613 4.46l.3.729a1.677 1.677 0 0 0 .452.058c1.924 0 5.108-2.999 5.108-6.417a5.695 5.695 0 0 0-.823-2.898A13.38 13.38 0 0 0 22 6.5zm-3.966-2.135C18.327 2.648 18.5 2 19.166 2 20.229 2 21 3.893 21 6.5a12.513 12.513 0 0 1-1.516 6.06 6.155 6.155 0 0 0-1.868-1.595l-.57-.419a6.435 6.435 0 0 0-.735-1.316 11.048 11.048 0 0 0 1.723-4.865zM6.996 12.261a4.215 4.215 0 0 1 1.089-2.844 5.562 5.562 0 0 1 4.156-1.389 4.042 4.042 0 0 1 3.477 2.086A17.894 17.894 0 0 0 13.5 10a9.252 9.252 0 0 0-6.504 2.26zM4 18.02v-1.024l.59-.004c.123-.02.248-.057.373-.082l-.024 1.244c-.065-.026-.136-.045-.2-.072zm5.5.98a12.827 12.827 0 0 1-3.568-.5l.008-.425c.266.009.486.01.635.01 3.94 0 7.282-1.195 9.415-3.367l-.714-.701c-1.942 1.98-5.032 3.069-8.7 3.069-.145 0-.358-.002-.617-.011l.007-.383a19.767 19.767 0 0 0 9.091-5.636 10.853 10.853 0 0 1 1.22.166l.652.48a14.038 14.038 0 0 1 .18 2.211 15.686 15.686 0 0 1-.148 2.107A10.917 10.917 0 0 1 9.5 19zm6.851 2.679a19.103 19.103 0 0 0 1.759-7.766c0-.483-.023-.964-.066-1.424a5.259 5.259 0 0 1 1.893 3.871 6.213 6.213 0 0 1-3.586 5.319z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26.53 18.628c2.86-4.288 3.049-11.807 1.196-14.954a2.805 2.805 0 0 0-2.71-1.645c-1.646.134-1.798 1.85-1.96 3.667a15.09 15.09 0 0 1-.475 2.997 12.436 12.436 0 0 1-2.136 4.131 6.494 6.494 0 0 0-4.458-1.753c-5.781 0-8.716 4.389-8.91 6.135a2.808 2.808 0 0 0 1.116 2.781.5.5 0 0 0 .656-.122c1.552-2.012 4.83-3.773 9.018-3.883A26.587 26.587 0 0 1 5.482 22.88l-1.042.125A.5.5 0 0 0 4 23.5v2a.5.5 0 0 0 .154.361.525.525 0 0 0 .368.139l.862-.038a19.56 19.56 0 0 0 6.453 1.119 18.237 18.237 0 0 0 10.951-3.677 15.596 15.596 0 0 1-2.706 6.824.5.5 0 0 0 .136.905 2.023 2.023 0 0 0 .533.068c1.319 0 3.036-1.11 4.38-2.885a8.39 8.39 0 0 0 1.04-9.152zm-2.991-9.646a15.876 15.876 0 0 0 .513-3.198c.167-1.872.316-2.699 1.045-2.759a1.894 1.894 0 0 1 1.767 1.156c1.674 2.843 1.46 9.955-1.167 13.892l-.104.157a9.494 9.494 0 0 0-3.053-2.393.482.482 0 0 0-.015-.13 8.769 8.769 0 0 0-1.377-2.16 13.195 13.195 0 0 0 2.39-4.565zM8.41 18.827a2.089 2.089 0 0 1-.34-1.51c.16-1.445 2.838-5.246 7.916-5.246a6.111 6.111 0 0 1 5.147 3.135c-5.77-.957-10.41 1.016-12.723 3.621zm-2.974 6.131l-.437.02v-1.035l.64-.078c.119-.024.241-.064.36-.09v1.332c-.125-.042-.25-.076-.375-.12a.585.585 0 0 0-.188-.029zm17.289-2.748A17.391 17.391 0 0 1 7 25.412v-.355c4.333-.02 9.924-1.213 13.2-4.55l-.713-.7C16.423 22.928 11.15 24.034 7 24.049v-.528a28.54 28.54 0 0 0 12.275-7.51 17.098 17.098 0 0 1 2.31.303.482.482 0 0 0 .04.125 10.587 10.587 0 0 1 1.283 5.623zm1.608 5.503a6.774 6.774 0 0 1-2.934 2.369c.886-1.429 3.977-7.05 1.758-12.73A6.465 6.465 0 0 1 25.1 19.25c2.31 3.862-.003 7.453-.767 8.462z"
  }));
};

var _default = BananaIcon;
exports["default"] = _default;