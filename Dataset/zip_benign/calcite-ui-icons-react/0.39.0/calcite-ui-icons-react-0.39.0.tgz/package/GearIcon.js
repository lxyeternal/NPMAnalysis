"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GearIcon = function GearIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.487 5.294l-.983-2.1L3.147 1.54l2.104.966a6.162 6.162 0 0 1 .764-.317l.79-2.18L9.136 0l.804 2.17a6.107 6.107 0 0 1 .765.317l2.1-.983 1.655 1.643-.967 2.104a6.149 6.149 0 0 1 .318.764l2.18.79L16 9.136l-2.17.804a6.097 6.097 0 0 1-.317.765l.983 2.1-1.643 1.655-2.104-.966a6.161 6.161 0 0 1-.764.317l-.79 2.18L6.864 16l-.804-2.17a6.105 6.105 0 0 1-.765-.317l-2.1.983-1.655-1.643.966-2.104a6.154 6.154 0 0 1-.317-.764l-2.18-.79L0 6.864l2.17-.804a6.094 6.094 0 0 1 .317-.765zm5.07 9.703l.936-.003.715-1.973.453-.155a5.223 5.223 0 0 0 .64-.265l.428-.216 1.906.876.659-.664-.889-1.9.21-.43a5.449 5.449 0 0 0 .268-.644l.152-.454 1.962-.727-.003-.935-1.973-.715-.155-.453a5.223 5.223 0 0 0-.265-.64l-.216-.428.876-1.906-.664-.659-1.9.889-.43-.21a5.367 5.367 0 0 0-.643-.268l-.455-.151-.728-1.963-.934.003-.715 1.973-.453.155a5.223 5.223 0 0 0-.64.265l-.428.216-1.906-.876-.659.664.889 1.9-.21.43a5.434 5.434 0 0 0-.268.643l-.151.454-1.963.728.003.935 1.973.715.155.453a5.223 5.223 0 0 0 .265.64l.216.428-.876 1.906.664.659 1.9-.889.43.21a5.434 5.434 0 0 0 .643.268l.454.151zM11 8a3 3 0 1 1-3-3 3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2.002 2.002 0 0 0 2-2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.017 14.669L23 13.564l-.012-3.208-2.996-1.085a8.455 8.455 0 0 0-.437-1.05l1.329-2.893-2.277-2.26-2.886 1.351a8.396 8.396 0 0 0-1.052-.436L13.564 1l-3.208.012-1.085 2.996a8.485 8.485 0 0 0-1.05.437L5.328 3.116l-2.26 2.276L4.419 8.28a8.378 8.378 0 0 0-.436 1.052L1 10.436l.012 3.208 2.996 1.085a8.46 8.46 0 0 0 .437 1.05l-1.329 2.893 2.276 2.26 2.887-1.351a8.383 8.383 0 0 0 1.052.436L10.436 23l3.208-.012 1.085-2.996a8.478 8.478 0 0 0 1.05-.437l2.893 1.329 2.26-2.276-1.351-2.887a8.382 8.382 0 0 0 .436-1.052zm-.287 3.73l-1.275 1.285-2.694-1.238-.429.215a7.612 7.612 0 0 1-.928.385l-.452.156-1.01 2.789-1.81.007-1.03-2.779-.456-.151a7.394 7.394 0 0 1-.926-.385l-.43-.21-2.688 1.257-1.286-1.275 1.239-2.695-.216-.43a7.551 7.551 0 0 1-.386-.926l-.155-.452-2.79-1.01-.005-1.81 2.777-1.03.152-.456a7.46 7.46 0 0 1 .384-.927l.212-.43L4.27 5.601l1.275-1.285 2.694 1.238.429-.215a7.612 7.612 0 0 1 .928-.385l.452-.156 1.01-2.789 1.81-.007 1.03 2.779.456.151a7.35 7.35 0 0 1 .925.385l.43.211L18.4 4.27l1.285 1.275-1.239 2.695.216.43a7.551 7.551 0 0 1 .386.926l.155.452 2.79 1.01.005 1.81-2.777 1.03-.152.456a7.46 7.46 0 0 1-.384.927l-.212.43zM12 7.2a4.8 4.8 0 1 0 4.8 4.8A4.8 4.8 0 0 0 12 7.2zm0 8.6a3.8 3.8 0 1 1 3.8-3.8 3.804 3.804 0 0 1-3.8 3.8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26.204 19.397L30 17.99l-.015-4.082-3.814-1.382a10.757 10.757 0 0 0-.556-1.336l1.692-3.682-2.897-2.876-3.674 1.72a10.685 10.685 0 0 0-1.34-.556L17.99 2l-4.082.015-1.382 3.814a10.77 10.77 0 0 0-1.336.556L7.508 4.693 4.632 7.59l1.72 3.674a10.661 10.661 0 0 0-.556 1.34L2 14.01l.015 4.082 3.814 1.382a10.767 10.767 0 0 0 .556 1.336l-1.692 3.682 2.897 2.876 3.674-1.72a10.678 10.678 0 0 0 1.34.556L14.01 30l4.082-.015 1.382-3.814a10.79 10.79 0 0 0 1.336-.556l3.682 1.692 2.876-2.897-1.72-3.674a10.678 10.678 0 0 0 .556-1.34zm-.038 4.804l-1.892 1.905-3.482-1.6-.43.215a9.726 9.726 0 0 1-1.213.505l-.453.155-1.306 3.607-2.685.01-1.331-3.592-.455-.152a9.726 9.726 0 0 1-1.216-.504l-.43-.21L7.8 26.167l-1.906-1.892 1.6-3.483-.215-.43a9.76 9.76 0 0 1-.504-1.211l-.154-.454-3.61-1.307-.008-2.685 3.59-1.33.152-.457a9.766 9.766 0 0 1 .505-1.214l.21-.43-1.626-3.475 1.892-1.905 3.482 1.6.43-.215a9.726 9.726 0 0 1 1.213-.505l.453-.155 1.306-3.607 2.685-.01 1.331 3.592.455.152a9.726 9.726 0 0 1 1.216.504l.43.21L24.2 5.833l1.906 1.892-1.6 3.483.215.43a9.668 9.668 0 0 1 .504 1.211l.154.454 3.61 1.307.008 2.685-3.59 1.33-.152.457a9.735 9.735 0 0 1-.505 1.214l-.21.43zM16 10.2a5.8 5.8 0 1 0 5.8 5.8 5.8 5.8 0 0 0-5.8-5.8zm0 10.6a4.8 4.8 0 1 1 4.8-4.8 4.805 4.805 0 0 1-4.8 4.8z"
  }));
};

var _default = GearIcon;
exports["default"] = _default;