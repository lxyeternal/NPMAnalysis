"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BikingIcon = function BikingIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.5 9A2.5 2.5 0 1 0 7 11.5 2.5 2.5 0 0 0 4.5 9zm0 4A1.5 1.5 0 1 1 6 11.5 1.502 1.502 0 0 1 4.5 13zm8-4a2.5 2.5 0 1 0 2.5 2.5A2.5 2.5 0 0 0 12.5 9zm0 4a1.5 1.5 0 1 1 1.5-1.5 1.502 1.502 0 0 1-1.5 1.5zm-.6-10.5a1.4 1.4 0 1 1-1.4-1.4 1.4 1.4 0 0 1 1.4 1.4zm.876 4.994c.01.404-.377.503-.774.503L9.685 8l-.759-1.912-1.969 1.521 1.73 1.163a.78.78 0 0 1 .303.577S9 9.283 9 13.067c0 .414-.057.71-.47.71S8 13.48 8 13.066v-3.53L5.147 8c-.853-.494-.02-1.388-.02-1.388l2.344-2.05a1.924 1.924 0 0 1 1.17-.5 1.163 1.163 0 0 1 .94.627L10.311 7h1.692c.363 0 .766.169.773.494z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.1 4A1.9 1.9 0 1 1 14 5.9 1.898 1.898 0 0 1 12.1 4zM9.8 18A3.8 3.8 0 1 1 6 14.2 3.8 3.8 0 0 1 9.8 18zm-1.3 0A2.5 2.5 0 1 0 6 20.5 2.503 2.503 0 0 0 8.5 18zm13.3 0a3.8 3.8 0 1 1-3.8-3.8 3.8 3.8 0 0 1 3.8 3.8zm-1.3 0a2.5 2.5 0 1 0-2.5 2.5 2.503 2.503 0 0 0 2.5-2.5zM13.04 6.74l-.843-.582a1.249 1.249 0 0 0-1.626.44l-2.886 4.86a1 1 0 0 0 .367 1.408l3.55 1.944-.452 3.597c-.063.583.118 1.085.555 1.147.54.077.91-.185 1.076-.898l1.07-4.727-2.948-1.59 1.79-2.843L14.387 12H18a1 1 0 0 0 0-2h-2.615l-2.07-3.002a1.047 1.047 0 0 0-.274-.257z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 5.5A2.5 2.5 0 1 1 18.5 8 2.498 2.498 0 0 1 16 5.5zm-1.042 19.02a1.545 1.545 0 0 0 1.021 1.688c.73.104 1.23-.25 1.452-1.211.034-.145 1.173-6.518 1.173-6.518l-3.979-2.146 2.823-4.087L19.498 15H24a1 1 0 0 0 0-2h-3.498l-2.434-3.27a1.63 1.63 0 0 0-.48-.551.995.995 0 0 0-.11-.083l-1.107-.765a1.685 1.685 0 0 0-2.194.595l-4.09 6.534a1 1 0 0 0 .367 1.408l5.114 2.8zM29.8 24.5a5.3 5.3 0 1 1-5.3-5.3 5.3 5.3 0 0 1 5.3 5.3zm-1.8 0a3.5 3.5 0 1 0-3.5 3.5 3.504 3.504 0 0 0 3.5-3.5zm-15.2 0a5.3 5.3 0 1 1-5.3-5.3 5.3 5.3 0 0 1 5.3 5.3zm-1.8 0A3.5 3.5 0 1 0 7.5 28a3.504 3.504 0 0 0 3.5-3.5z"
  }));
};

var _default = BikingIcon;
exports["default"] = _default;