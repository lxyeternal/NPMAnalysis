"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerPolygonServiceIcon = function LayerPolygonServiceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.207 12.2A6.624 6.624 0 0 1 16 13.29L13.867.687a8.205 8.205 0 0 0-3.161-.674C8.016.014 7.982 1 5.294 1A10.39 10.39 0 0 1 2.133.488L0 13.09a9.158 9.158 0 0 0 3.793.711A10.667 10.667 0 0 0 7 13.322V15H2v1h11v-1H8v-2a11.89 11.89 0 0 1 4.207-.8zm-11.082.237L2.935 1.74A11.376 11.376 0 0 0 5.294 2a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.214 7.214 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852 10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363zM12.105 3h-8.21L3 11h10zM8.787 4L7.602 6.042h-3.04L4.79 4zm-4.33 2.964h3.15L10.177 10H4.118zM11.324 10L8.362 6.5 9.812 4h1.398l.672 6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 18.85a21.892 21.892 0 0 1 5.458-.684 13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105A12.674 12.674 0 0 0 16.31.2c-3.848 0-3.892 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722L1 18.783A13.093 13.093 0 0 0 6.424 19.8 22.094 22.094 0 0 0 12 19.088V23H4v1h17v-1h-8zm-10.876-.7L4.848 2.343A16.193 16.193 0 0 0 8.57 2.8a9.805 9.805 0 0 0 4.25-.875 7.791 7.791 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l2.674 15.872a16.248 16.248 0 0 0-4.157-.52 24.03 24.03 0 0 0-6.251.844 22.054 22.054 0 0 1-5.783.789 13.726 13.726 0 0 1-4.3-.65zm19.26-1.75L19.057 2.59a10.555 10.555 0 0 0-2.746-.39 6.87 6.87 0 0 0-3.11.65 10.811 10.811 0 0 1-4.63.95 16.728 16.728 0 0 1-2.914-.268L3.262 17.436a13.436 13.436 0 0 0 3.162.364 21.214 21.214 0 0 0 5.549-.761 24.868 24.868 0 0 1 6.485-.873 18.033 18.033 0 0 1 2.926.234zm-1.21-1.16a19.852 19.852 0 0 0-1.716-.074c-.76 0-1.448.03-2.085.082l-3.767-4.66 4.454-7.342a10.049 10.049 0 0 1 1.12.16zM6.477 4.668a17.065 17.065 0 0 0 2.095.133 11.836 11.836 0 0 0 5.01-1.025 5.842 5.842 0 0 1 2.331-.566L11.793 10H5.558zm5.263 11.4a20.374 20.374 0 0 1-5.315.733 12.935 12.935 0 0 1-2.012-.153L5.385 11h6.268l3.54 4.378a32.767 32.767 0 0 0-3.454.688zM7.5 6.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm10 2.9a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm-9 4.1a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.36 22.39L24.383 4.458a23.564 23.564 0 0 0-3.309-.247 14.759 14.759 0 0 0-4.736.732 19.375 19.375 0 0 1-5.999.925 18.297 18.297 0 0 1-2.918-.231L4.348 24.148a14.05 14.05 0 0 0 4.19.652 18.509 18.509 0 0 0 6.54-1.155 24.388 24.388 0 0 1 8.384-1.445c1.444 0 2.76.079 3.898.19zm-1.196-1.101c-.9-.059-1.805-.089-2.702-.089-.423 0-.819.014-1.208.03l-6.248-7.73 5.029-8.29h.04a21.74 21.74 0 0 1 2.443.143zM8.249 6.756a19.57 19.57 0 0 0 2.09.112 20.235 20.235 0 0 0 6.276-.964 14.45 14.45 0 0 1 3.223-.648L15.14 13H7.212zm6.52 15.938a17.461 17.461 0 0 1-6.23 1.106 12.838 12.838 0 0 1-3.056-.372L7.046 14h8.077l5.91 7.31a26.378 26.378 0 0 0-6.263 1.384zM16 26.5a21.425 21.425 0 0 1 7.462-1.3A33.153 33.153 0 0 1 31 26L27 1.9a26.401 26.401 0 0 0-5.926-.689c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 1.9L1 26a16.273 16.273 0 0 0 7.538 1.8A20.258 20.258 0 0 0 15 26.816V30H3v1h25v-1H16zM2.108 25.434L5.795 3.217a15.6 15.6 0 0 0 4.544.651 17.43 17.43 0 0 0 5.445-.846 16.633 16.633 0 0 1 5.29-.81 26.266 26.266 0 0 1 5.05.517l3.651 22a37.271 37.271 0 0 0-6.313-.529 22.375 22.375 0 0 0-7.77 1.348A20.416 20.416 0 0 1 8.539 26.8a15.986 15.986 0 0 1-6.43-1.366zM11.5 9.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm10 3a1 1 0 1 1-1 1 1 1 0 0 1 1-1zm-9 6a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"
  }));
};

var _default = LayerPolygonServiceIcon;
exports["default"] = _default;