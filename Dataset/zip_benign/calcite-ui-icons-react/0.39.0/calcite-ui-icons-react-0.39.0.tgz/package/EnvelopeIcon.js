"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EnvelopeIcon = function EnvelopeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 14a1 1 0 0 0 1-1V3a1.001 1.001 0 0 0-1-1H1a1.002 1.002 0 0 0-1 1v10a1.001 1.001 0 0 0 1 1zM8 9.526l1.567-1.252L14.293 13H1.707l4.726-4.726zm0-1.28L1.44 3h13.12zm7-4.317v8.364l-4.648-4.648zM5.648 7.645L1 12.293V3.929z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.5 4h-19A1.504 1.504 0 0 0 1 5.5v13A1.5 1.5 0 0 0 2.5 20h19a1.5 1.5 0 0 0 1.5-1.5v-13A1.504 1.504 0 0 0 21.5 4zM12 12.07L2.82 5h18.36zm-2.846-.93L2 18.292V5.631zm.798.615L12 13.33l2.048-1.576L21.293 19H2.707zm4.894-.616L22 5.631v12.662z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28 6H4a2.003 2.003 0 0 0-2 2v16a2.001 2.001 0 0 0 2 2h24a2.001 2.001 0 0 0 2-2V8a2.003 2.003 0 0 0-2-2zm-8.46 8.833l9.324-7.307A.973.973 0 0 1 29 8v16a.963.963 0 0 1-.05.243zM3.05 24.244A.963.963 0 0 1 3 24V8a.973.973 0 0 1 .136-.474l9.323 7.307zM4.086 7h23.826L16 16.337zM4 25a.96.96 0 0 1-.243-.05l9.495-9.495L16 17.608l2.748-2.153 9.496 9.496A.96.96 0 0 1 28 25z"
  }));
};

var _default = EnvelopeIcon;
exports["default"] = _default;