"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CreditsIcon = function CreditsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 10.5c0 .02.003.039.003.058a5.285 5.285 0 1 1 6.555-6.555c-.02 0-.038-.003-.058-.003a6.49 6.49 0 0 0-.96.079 4.289 4.289 0 1 0-5.46 5.46A6.49 6.49 0 0 0 4 10.5zm1.462-7.3l-.017-1A3.301 3.301 0 0 0 2.26 6.127l.982-.19A2.3 2.3 0 0 1 5.462 3.2zM15.8 10.5a5.3 5.3 0 1 1-5.3-5.3 5.306 5.306 0 0 1 5.3 5.3zm-1 0a4.3 4.3 0 1 0-4.3 4.3 4.304 4.304 0 0 0 4.3-4.3zm-6.531-.56a2.297 2.297 0 0 1 2.444-1.73l.096-.996a3.317 3.317 0 0 0-.957.05A3.304 3.304 0 0 0 7.3 9.697zm5.264-.743l-.92.395a2.3 2.3 0 0 1-3.74 2.534l-.706.707a3.3 3.3 0 0 0 5.366-3.636z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 15.5c0 .049.006.096.007.145a7.3 7.3 0 1 1 8.638-8.638c-.049 0-.096-.007-.145-.007a8.557 8.557 0 0 0-.877.045 6.296 6.296 0 1 0-7.578 7.578A8.557 8.557 0 0 0 7 15.5zm.983-11.27l-.119-.992A5.3 5.3 0 0 0 3.2 8.558c.002.153.01.303.024.45l.995-.093a4.508 4.508 0 0 1-.019-.367A4.3 4.3 0 0 1 7.983 4.23zM22.8 15.5a7.3 7.3 0 1 1-7.3-7.3 7.308 7.308 0 0 1 7.3 7.3zm-1 0a6.3 6.3 0 1 0-6.3 6.3 6.307 6.307 0 0 0 6.3-6.3zm-10.58.415a4.508 4.508 0 0 1-.02-.367 4.3 4.3 0 0 1 3.783-4.318l-.119-.992a5.3 5.3 0 0 0-4.664 5.32c.002.153.01.303.024.45zm8.028-4.163l-.707.707a4.3 4.3 0 1 1-6.082 6.082l-.707.707a5.3 5.3 0 0 0 7.496-7.496z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10 20.5c0 .057.008.112.009.169a9.294 9.294 0 1 1 10.66-10.66c-.057-.001-.112-.009-.169-.009-.282 0-.56.02-.836.042a8.296 8.296 0 1 0-9.622 9.622A10.49 10.49 0 0 0 10 20.5zm.968-15.251l-.088-1.043a7.312 7.312 0 0 0-6.7 7.33c.001.167.008.331.019.495l1.044-.072a6.591 6.591 0 0 1-.017-.429 6.266 6.266 0 0 1 5.742-6.281zM29.8 20.5a9.3 9.3 0 1 1-9.3-9.3 9.31 9.31 0 0 1 9.3 9.3zm-1 0a8.3 8.3 0 1 0-8.3 8.3 8.31 8.31 0 0 0 8.3-8.3zm-3.122-5.179l-.74.74a6.277 6.277 0 0 1-8.877 8.878l-.739.74A7.323 7.323 0 0 0 25.678 15.32zM14.243 20.96a6.591 6.591 0 0 1-.017-.429 6.266 6.266 0 0 1 5.742-6.281l-.088-1.043a7.312 7.312 0 0 0-6.7 7.33c.001.167.008.331.019.495z"
  }));
};

var _default = CreditsIcon;
exports["default"] = _default;