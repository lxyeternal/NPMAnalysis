"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CursorMarqueeIcon = function CursorMarqueeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 2h-1V1h2v2h-1zm-.83 13.646l1.791-.9-1.544-3.08H16l-6-4.579V14.9l1.588-2.386zM11 11.691V9.208l2.042 1.558zM2 13H1v2h2v-1H2zM1 3h1V2h1V1H1zm6-2H5v1h2zM2 7V5H1v2zm0 4V9H1v2zm9-10H9v1h2zM7 14H5v1h2zm8-9h-1v2h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 20v1H2v-2h1v1zM3 3h1V2H2v2h1zM2 8h1V6H2zm0 5h1v-3H2zm18-5h1V6h-1zm0 4h1v-2h-1zM2 17h1v-2H2zM8 3V2H6v1zm5 0V2h-3v1zM9 21v-1H7v1zm4 0v-1h-2v1zm4-18V2h-2v1zm2-1v1h1v1h1V2zm-.245 20l2.686-1.351L19.126 16H23l-9-6.538v11.103l2.382-3.264zm-2.217-6.61L15 17.499v-6.073L19.922 15h-2.41l2.59 5.203-.905.455z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26 4h-1V3h2v2h-1zM3 7v2h1V7zm0 4v3h1v-3zm23-4v2h1V7zm0 4v3h1v-3zM3 16v3h1v-3zm23 0v2h1v-2zM3 21v2h1v-2zM7 4h2V3H7zm4 0h3V3h-3zM7 27h2v-1H7zm4 0h3v-1h-3zm5-23h3V3h-3zm5 0h2V3h-2zM4 25H3v2h2v-1H4zM3 5h1V4h1V3H3zm20.34 24.926l3.582-1.802-3.087-6.16H29l-12-8.756v14.805l3.176-4.353zm-3.008-8.176L18 24.945v-9.77l7.933 5.789h-3.718l3.366 6.716-1.799.904z"
  }));
};

var _default = CursorMarqueeIcon;
exports["default"] = _default;