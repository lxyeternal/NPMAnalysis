"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayersEditableIcon = function LayersEditableIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.423 8.208l.734-.734 1.866 1.05-8 4.5-8-4.5L5.6 5.386l-.65 1.513-2.887 1.624 5.96 3.353 3.01-1.693.371-.16a1.983 1.983 0 0 0 .545-.355l2.034-1.145zm-5.4 6.668l-6.98-3.926-1.02.573 7.915 4.452a.175.175 0 0 0 .171 0l7.914-4.452-1.02-.573zm-1.99-5.422l.285-.667 1.47-3.43L12.84.307a.965.965 0 0 1 1.385.03l1.414 1.414a.965.965 0 0 1 .03 1.384l-1.446 1.443-3.607 3.609-3.014 1.292-1.082.464a.371.371 0 0 1-.488-.488zM12.21 2.35l1.415 1.414 1.09-1.09a.306.306 0 0 0 0-.434l-.98-.98a.306.306 0 0 0-.434 0zM8.495 6.065L9.91 7.479l3.008-3.008-1.414-1.414zm-.924 2.338l1.294-.554-.74-.74z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.09 15.367L23 16.495 12 23 1 16.493l1.91-1.128.983.582-.927.547L12 21.838l9.033-5.342-.927-.547zm-3.93-5.159l3.874 2.288-9.033 5.342-9.035-5.344L7.04 10.09l.654-1.527c.005-.01.013-.02.017-.03L1 12.491 12 19l11-6.505-5.11-3.017zm-9.382 3.239l.327-.763L9.533 9.35l8.31-8.309a.98.98 0 0 1 1.385 0l1.429 1.429a.965.965 0 0 1 .03 1.385l-8.325 8.324-3.183 1.364-.914.391a.371.371 0 0 1-.487-.487zm9.316-10.243l1.413 1.415 1.152-1.152a.42.42 0 0 0 .006-.587l-.804-.838a.42.42 0 0 0-.6-.006zm-6.177 6.177l1.414 1.414 5.47-5.47-1.415-1.413zm-1.601 3.015l2.241-.96-1.28-1.28z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.172 13.945l.731-.73 5.597 3.277L16 25 1.5 16.492 16 8l.89.52-.732.732L16 9.159 3.478 16.493 16 23.841l12.522-7.348zm2.558 6.499l1.792 1.05L16 28.84 3.478 21.493l1.792-1.05-.989-.58-2.781 1.63L16 30l14.5-8.508-2.781-1.629zm2.915-16.562a1.203 1.203 0 0 1 .037 1.726L27.88 7.406v.001l-9.565 9.567-5.465 2.342a.306.306 0 0 1-.402-.402l2.342-5.465L26.156 2.083a1.203 1.203 0 0 1 1.726.037zM17.324 16.311l-1.871-1.87-1.403 3.273zm9.584-9.344l-2.11-2.111-8.759 8.757 2.112 2.111zm2.03-2.378l-1.761-1.761a.285.285 0 0 0-.193-.092.163.163 0 0 0-.12.054l-1.36 1.359 2.111 2.11 1.36-1.358c.133-.133-.02-.294-.038-.312z"
  }));
};

var _default = LayersEditableIcon;
exports["default"] = _default;