"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BasemapIcon = function BasemapIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 3V0H9v7h7zm-1-2v1h-3V1zm-4 0v2h2v1h-3V1zm-1 5V5h4V3h1v3zM7 0H0v7h7zM6 4h-.33A2.674 2.674 0 0 1 3 1.33V1h3zM1 6V5h.561A.44.44 0 0 1 2 5.439V6zm2 0v-.561A1.44 1.44 0 0 0 1.561 4H1V1h1v.33A3.675 3.675 0 0 0 5.67 5H6v1zm13 3H9v7h7zm-6 6v-3h3v1h-1v1h1v1zm5 0h-1v-3h1zm0-4h-5v-1h5zM7 9H0v7h7zm-1 1v3.09a8.93 8.93 0 0 0-.314.057 2.863 2.863 0 0 1-.051-.12 3.112 3.112 0 0 0-.653-1.06c-.873-.872-1.18-1.093-1.977-1.093A3.301 3.301 0 0 0 1 12.024V10zm-5 5v-1.432l.11-.149a3.727 3.727 0 0 1 1.895-1.545c.397 0 .47 0 1.27.8a2.209 2.209 0 0 1 .438.742c.112.265.328.78.807.78a.816.816 0 0 0 .245-.041c.013-.005.079-.021.235-.05V15z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 13H13v10h10zm-9 9v-5h5v2h-2v1h2v2zm8 0h-2v-5h2zm0-6h-8v-2h8zM11 1H1v10h10zm-.519 7.085l-.1-.008c-.133-.01-.252-.039-.381-.056V10H5.956c.019.067.043.13.058.2H4.981c-.023-.071-.062-.131-.089-.2H2V7.266a3.707 3.707 0 0 0-.108-.046l-.093-.035-.166-1.129.367.138V2h2.053a7.315 7.315 0 0 1-.094-.422l-.016-.1.989-.155.015.1c.007.04.042.254.126.577H10v5.014c.152.024.299.054.46.067l.1.008zm-.021-1.004l.1.008-.079.996-.1-.008c-.133-.01-.252-.039-.381-.056C5.759 7.455 4.385 3.332 4.053 2a7.315 7.315 0 0 1-.094-.422l-.016-.1.989-.155.015.1c.007.04.042.254.126.577C5.42 3.328 6.603 6.488 10 7.014c.152.024.299.054.46.067zM5.956 10c.019.067.043.13.058.2H4.981c-.023-.071-.062-.131-.089-.2A5.654 5.654 0 0 0 2 7.266a3.707 3.707 0 0 0-.108-.046l-.093-.035-.166-1.129.611.229c.14.052 2.995 1.168 3.712 3.715zM23 9V1H13v10h10zm-1-7v6h-4V7h2V5h1V2zm-3 3v1h-5V4h3v1zm1-3v2h-2V2zm-6 0h3v1h-3zm0 8V7h3v2h5v1zM1 23h10V13H1zm1-1v-1.614A4.076 4.076 0 0 0 3.313 20a2.44 2.44 0 0 0 .6-1.413c.125-1.22.36-1.595 1.65-1.586a1.976 1.976 0 0 1 1.8 1.003c1.01.879 1.552 1.282 2.292 1.048a3.123 3.123 0 0 1 .345-.08V22zm8-8v3.937a9.113 9.113 0 0 0-.646.161c-.501.159-.765-.247-1.528-.99a2.738 2.738 0 0 0-2.224-1.066 2.538 2.538 0 0 0-2.39 1.045c-.306.453.01 1.248-.5 2.038a1.199 1.199 0 0 1-.712.192V14z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 30h13V17H2zm1-12h11v4.684l-1.33.112s-.964.19-1.316.302c-.501.159-.765-.247-1.528-.99a2.738 2.738 0 0 0-2.224-1.066 2.538 2.538 0 0 0-2.39 1.045c-.306.453.01 1.248-.5 2.038a2.44 2.44 0 0 1-1.529.161L3 24.251zm0 7.374l.31.047A4.479 4.479 0 0 0 5.311 25a2.44 2.44 0 0 0 .6-1.413c.126-1.22.361-1.595 1.65-1.586a1.976 1.976 0 0 1 1.8 1.003c1.01.879 1.553 1.282 2.293 1.048a3.093 3.093 0 0 1 .34-.08l2.005-.2V29H3zM2 15h13V2H2zm1-1v-3.568A8.172 8.172 0 0 1 6.879 14zM14 3v6.704C9.904 8.754 8.218 4.912 7.629 3zM3 3h3.585c.567 1.993 2.43 6.71 7.415 7.728V14H7.962C6.754 10.804 3.2 9.418 3 9.343zm14-1v13h13V2zm6 3V3h3v3h-3zm1 2v2h-4V6h2v1zm5 7H18V3h4v2h-3v5h3v3h7zm0-2h-6v-2h2V9h4zm0-4h-4V7h2V3h2zM17 30h13V17H17zm12.01-1H26v-7h3.01zM17.99 18h11.02v3H17.99zm0 4H25v3h-3v1h3v3h-7.01z"
  }));
};

var _default = BasemapIcon;
exports["default"] = _default;