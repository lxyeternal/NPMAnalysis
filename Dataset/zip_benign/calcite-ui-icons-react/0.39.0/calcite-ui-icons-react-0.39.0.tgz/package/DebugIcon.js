"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DebugIcon = function DebugIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.092 13a8.77 8.77 0 0 0 .849-3H15V9h-2v-.023A9.38 9.38 0 0 0 12.522 6h1.265l1.484-2.549-.865-.503L13.213 5h-1.097a5.943 5.943 0 0 0-2.02-2.39l1.258-1.256-.707-.707-1.502 1.5a3.491 3.491 0 0 0-2.29 0L5.354.648l-.707.706L5.904 2.61A5.943 5.943 0 0 0 3.884 5H2.787L1.594 2.948l-.865.503L2.213 6h1.265A9.38 9.38 0 0 0 3 8.977V9H1v1h2.06a8.77 8.77 0 0 0 .848 3H2.195L.917 15.47l.889.46.999-1.93h1.708A4.389 4.389 0 0 0 8 16a4.389 4.389 0 0 0 3.487-2h1.708l1 1.93.888-.46L13.805 13zM8 2.955c1.686 0 3.128 1.58 3.716 3.805a8.624 8.624 0 0 0-7.432 0C4.872 4.534 6.314 2.955 8 2.955zM8 15a2.77 2.77 0 0 1-1.135-.25L8 8.87l1.135 5.879A2.77 2.77 0 0 1 8 15zm2.038-.85L8.84 7.952a6.783 6.783 0 0 0-1.682 0l-1.197 6.2A7.019 7.019 0 0 1 4 8.977a8.987 8.987 0 0 1 .057-.976l.406-.224a6.66 6.66 0 0 1 .941-.419 7.619 7.619 0 0 1 6.133.419l.406.224a8.987 8.987 0 0 1 .057.976 7.019 7.019 0 0 1-1.962 5.174z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.947 8a13.059 13.059 0 0 0-.912 4H2v1h3a13.656 13.656 0 0 0 .589 4H3.15l-1.378 3.727.938.347L3.849 18h2.098c1.213 2.984 3.47 5 6.053 5s4.84-2.016 6.053-5h2.098l1.138 3.074.938-.347L20.849 17H18.41a13.656 13.656 0 0 0 .59-4h3v-1h-3.035a13.059 13.059 0 0 0-.912-4h2.796l1.378-3.727-.938-.347L20.151 7h-2.564a8.187 8.187 0 0 0-2.748-3.132l2.515-2.514-.707-.707-2.74 2.74a4.893 4.893 0 0 0-3.813 0L7.354.647l-.707.706L9.16 3.868A8.187 8.187 0 0 0 6.413 7H3.85L2.71 3.926l-.938.347L3.151 8zM12 4c2.449 0 4.556 2.214 5.488 5.375a12.684 12.684 0 0 0-10.976 0C7.444 6.216 9.552 4 12 4zm0 18a4.196 4.196 0 0 1-1.848-.441L12 11.987l1.848 9.572A4.196 4.196 0 0 1 12 22zm2.756-1.015l-2.094-10.848a10.973 10.973 0 0 0-1.324 0L9.244 20.985C7.319 19.485 6 16.472 6 13a13.191 13.191 0 0 1 .216-2.355l.356-.197h.001a11.622 11.622 0 0 1 10.854 0l.358.197A13.191 13.191 0 0 1 18 13c0 3.472-1.32 6.485-3.244 7.985z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8.153 12a15.975 15.975 0 0 0-.935 5H3v1h4.218a15.975 15.975 0 0 0 .935 5H5.194l-2.34 4.572.891.455L5.805 24h2.757c1.56 3.429 4.307 5.718 7.438 5.718s5.878-2.29 7.438-5.718h2.756l2.06 4.027.892-.455L26.806 23h-2.959a15.975 15.975 0 0 0 .935-5H29v-1h-4.218a15.975 15.975 0 0 0-.935-5h2.96l2.316-4.575-.893-.45L26.192 11h-2.754a10.017 10.017 0 0 0-4.651-5.08l3.567-3.566-.707-.707-3.883 3.882a6.42 6.42 0 0 0-3.528 0l-3.882-3.883-.707.707 3.566 3.567A10.017 10.017 0 0 0 8.563 11H5.807L3.77 6.974l-.893.451L5.192 12zM16 6.282c3.073 0 5.728 2.575 6.999 6.297A16.469 16.469 0 0 0 9 12.58c1.27-3.722 3.926-6.297 6.999-6.297zm0 22.436a5.667 5.667 0 0 1-2.511-.608L16 15.103l2.511 13.007a5.667 5.667 0 0 1-2.511.608zm3.425-1.155l-2.796-14.48c-.42-.017-.838-.017-1.258 0l-2.796 14.48C9.99 25.735 8.2 21.917 8.2 17.5a15.639 15.639 0 0 1 .42-3.602l.063-.034a15.433 15.433 0 0 1 14.634 0l.063.034a15.64 15.64 0 0 1 .42 3.602c0 4.417-1.789 8.235-4.375 10.063z"
  }));
};

var _default = DebugIcon;
exports["default"] = _default;