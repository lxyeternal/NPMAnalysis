"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MobileVibrateIcon = function MobileVibrateIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.992.285a.697.697 0 0 0-.984 0L.285 5.008a.697.697 0 0 0 0 .984l9.723 9.723a.697.697 0 0 0 .984 0l4.723-4.723a.697.697 0 0 0 0-.984zM13.293 9L9 13.293 2.707 7 7 2.707zM5.5 1.207L6.293 2 2 6.293 1.207 5.5zM13 12.293l-.5-.5-.707.707.5.5-1.793 1.793L9.707 14 14 9.707l.793.793zM16 4v2h-1V5h-2V3h-2V1h-1V0h2v2h2v2zM5 15h1v1H4v-2H2v-2H0v-2h1v1h2v2h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.384 3.677a1.251 1.251 0 0 0-1.768 0l-4.94 4.94a1.251 1.251 0 0 0 0 1.767l10.94 10.94a1.25 1.25 0 0 0 1.768 0l4.94-4.94a1.251 1.251 0 0 0 0-1.768zm8.409 9.823L13.5 18.793 5.707 11 11 5.707zM4.383 9.323l4.94-4.94a.25.25 0 0 1 .354 0l.616.617L5 10.293l-.616-.616a.25.25 0 0 1 0-.354zm16.233 6.354l-1.47 1.47-.5-.5-2 2 .5.5-1.47 1.47a.25.25 0 0 1-.353 0L14.207 19.5l5.293-5.293 1.116 1.116a.25.25 0 0 1 0 .354zM23 8.75V11h-1V9h-2.25a.75.75 0 0 1-.75-.75V6h-2.25a.75.75 0 0 1-.75-.75V3h-2V2h2.25a.75.75 0 0 1 .75.75V5h2.25a.75.75 0 0 1 .75.75V8h2.25a.75.75 0 0 1 .75.75zM9 22h2v1H8.75a.75.75 0 0 1-.75-.75V20H5.75a.75.75 0 0 1-.75-.75V17H2.75a.75.75 0 0 1-.75-.75V14h1v2h2.25a.75.75 0 0 1 .75.75V19h2.25a.75.75 0 0 1 .75.75z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13.414 3.586a2.047 2.047 0 0 0-2.828 0l-7 7a2 2 0 0 0 0 2.828l15 15a2 2 0 0 0 2.828 0l7-7a2 2 0 0 0 0-2.828zm12.94 14.353l-8.415 8.415L5.146 13.56l8.415-8.415zM4.293 11.293l7-7a1 1 0 0 1 1.414 0l.147.146-8.415 8.415-.146-.147a1 1 0 0 1 0-1.414zm23.414 9.414l-2.5 2.5-.56-.56-2 2 .56.56-2.5 2.5a1.024 1.024 0 0 1-1.414 0l-.647-.646 8.415-8.415.646.647a1 1 0 0 1 0 1.414zM30 11.75V14h-1v-2h-2.25a.75.75 0 0 1-.75-.75V9h-2.25a.75.75 0 0 1-.75-.75V6h-2.25a.75.75 0 0 1-.75-.75V3h-2V2h2.25a.75.75 0 0 1 .75.75V5h2.25a.75.75 0 0 1 .75.75V8h2.25a.75.75 0 0 1 .75.75V11h2.25a.75.75 0 0 1 .75.75zM12 29h2v1h-2.25a.75.75 0 0 1-.75-.75V27H8.75a.75.75 0 0 1-.75-.75V24H5.75a.75.75 0 0 1-.75-.75V21H2.75a.75.75 0 0 1-.75-.75V18h1v2h2.25a.75.75 0 0 1 .75.75V23h2.25a.75.75 0 0 1 .75.75V26h2.25a.75.75 0 0 1 .75.75z"
  }));
};

var _default = MobileVibrateIcon;
exports["default"] = _default;