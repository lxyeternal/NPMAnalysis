"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EffectsIcon = function EffectsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.5 5L9 7l2 .5L9 8l-.5 2L8 8l-2-.5L8 7zM7.175 6.175L1.877 7.5l5.298 1.325L8.5 14.123l1.325-5.298L15.123 7.5 9.825 6.175 8.5.877zM3 2l-.5-2L2 2l-2 .5L2 3l.5 2L3 3l2-.5zm1 10l-.5-2-.5 2-2 .5 2 .5.5 2 .5-2 2-.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 7l.9 3.6 3.6.9-3.6.9-.9 3.6-.9-3.6-3.6-.9 3.6-.9zm-1.725 2.775L5.877 11.5l6.898 1.725 1.725 6.898 1.725-6.898 6.898-1.725-6.898-1.725L14.5 2.877zM6 4l-.5-4L5 4l-4 .5L5 5l.5 4L6 5l4-.5zm1 14l-.5-4-.5 4-4 .5 4 .5.5 4 .5-4 4-.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.5 8l1.3 6.2 6.2 1.3-6.2 1.3-1.3 6.2-1.3-6.2-6.2-1.3 6.2-1.3zm-2.145 5.355L7.127 15.5l10.228 2.145L19.5 27.873l2.145-10.229L31.873 15.5l-10.228-2.145L19.5 3.127zM7 6l-.5-5L6 6l-5 .5L6 7l.5 5L7 7l5-.5zm2 18l-.5-5-.5 5-5 .5 5 .5.5 5 .5-5 5-.5z"
  }));
};

var _default = EffectsIcon;
exports["default"] = _default;