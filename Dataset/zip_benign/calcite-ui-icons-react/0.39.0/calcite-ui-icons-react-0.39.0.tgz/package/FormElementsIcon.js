"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FormElementsIcon = function FormElementsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 4v2a1.001 1.001 0 0 0 1 1h12a1.001 1.001 0 0 0 1-1V4a1.001 1.001 0 0 0-1-1H2a1.001 1.001 0 0 0-1 1zm13 2H2V4h12v2h.001M1 14a1.001 1.001 0 0 0 1 1h12a1.001 1.001 0 0 0 1-1v-2a1.001 1.001 0 0 0-1-1H2a1.001 1.001 0 0 0-1 1zm13 0H2v-2h12v2h.001M7 1v1H2V1zM2 9h5v1H2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 6H2a1.001 1.001 0 0 0-1 1v3a1.001 1.001 0 0 0 1 1h20a1.001 1.001 0 0 0 1-1V7a1.001 1.001 0 0 0-1-1zm0 4H2V7h20v3h.001M22 17H2a1.001 1.001 0 0 0-1 1v3a1.001 1.001 0 0 0 1 1h20a1.001 1.001 0 0 0 1-1v-3a1.001 1.001 0 0 0-1-1zm0 4H2v-3h20v3h.001M10 14v1H2v-1zM2 3h8v1H2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.5 7h-25A1.502 1.502 0 0 0 2 8.5v4A1.502 1.502 0 0 0 3.5 14h25a1.502 1.502 0 0 0 1.5-1.5v-4A1.502 1.502 0 0 0 28.5 7zm.5 5.5a.5.5 0 0 1-.5.5h-25a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5h25a.5.5 0 0 1 .5.5zm-.5 8.5h-25A1.502 1.502 0 0 0 2 22.5v4A1.502 1.502 0 0 0 3.5 28h25a1.502 1.502 0 0 0 1.5-1.5v-4a1.502 1.502 0 0 0-1.5-1.5zm.5 5.5a.5.5 0 0 1-.5.5h-25a.5.5 0 0 1-.5-.5v-4a.5.5 0 0 1 .5-.5h25a.5.5 0 0 1 .5.5zM13 19H3v-1h10zm0-14H3V4h10z"
  }));
};

var _default = FormElementsIcon;
exports["default"] = _default;