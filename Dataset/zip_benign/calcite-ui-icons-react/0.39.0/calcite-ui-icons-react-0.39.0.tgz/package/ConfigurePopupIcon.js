"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ConfigurePopupIcon = function ConfigurePopupIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 12a1.001 1.001 0 0 1-1 1H9.828L8 15.828 6.172 13H2a1.001 1.001 0 0 1-1-1V2a1.001 1.001 0 0 1 1-1h12a1.001 1.001 0 0 1 1 1zm-7 1.986L9.284 12H14V2H2v10h4.716zM5.204 7.972l-1.2-.444V6.472l1.2-.444q.047-.136.106-.265l-.526-1.194.764-.771 1.163.535q.129-.063.263-.113L7.445 3h1.087l.444 1.2q.136.047.265.107l1.194-.527.77.765-.534 1.163q.062.128.112.262L12 6.441v1.117l-1.217.472q-.05.134-.112.262l.535 1.163-.771.765-1.194-.527q-.13.06-.265.107L8.532 11H7.445l-.47-1.22q-.135-.05-.264-.113l-1.163.535-.764-.771.526-1.194q-.06-.13-.106-.265zM5 7.102l.818.304a2.206 2.206 0 0 0 .358.859l-.385.768.16.16.792-.364a2.206 2.206 0 0 0 .862.354l.27.817h.226l.302-.819a2.206 2.206 0 0 0 .86-.359l.768.386.161-.16-.365-.792a2.206 2.206 0 0 0 .355-.862l.815-.27v-.248l-.815-.27a2.206 2.206 0 0 0-.355-.862l.365-.793-.161-.16-.767.387a2.206 2.206 0 0 0-.861-.36L8.102 4h-.227l-.27.817a2.206 2.206 0 0 0-.861.354l-.793-.364-.159.16.385.768a2.206 2.206 0 0 0-.358.86L5 6.897zM8 6a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 10a2 2 0 1 1-2-2 2 2 0 0 1 2 2zm-2-1a1 1 0 1 0 1 1 1 1 0 0 0-1-1zm1.484 5.34l.653-.235 1.543.71 1.162-1.171-.724-1.624.296-.628 1.586-.59v-1.65l-1.66-.636-.235-.653.705-1.538-1.166-1.167-1.624.724-.628-.296L12.802 4h-1.65l-.636 1.66-.653.235-1.543-.71-1.166 1.168.727 1.627-.295.628L6 9.198v1.65l1.66.636.235.653-.71 1.543 1.168 1.166 1.627-.727.628.295.59 1.586h1.65zm-2.24-.66l-1.161-.544-1.4.627-.412-.411.59-1.283-.434-1.206L7 10.315v-.581l1.32-.49.544-1.161-.627-1.4.411-.412 1.283.59 1.206-.434L11.685 5h.581l.49 1.32 1.16.543 1.396-.622.412.412-.585 1.28.434 1.204L17 9.685v.581l-1.32.49-.543 1.16.623 1.398-.41.413-1.28-.588-1.207.434L12.315 15h-.581zM22 3.5v13a1.502 1.502 0 0 1-1.5 1.5h-5.293l-3.05 4h-.315l-3.049-4H3.5A1.502 1.502 0 0 1 2 16.5v-13A1.502 1.502 0 0 1 3.5 2h17A1.502 1.502 0 0 1 22 3.5zm-1 0a.5.5 0 0 0-.5-.5h-17a.5.5 0 0 0-.5.5v13a.5.5 0 0 0 .5.5h5.788L12 20.558 14.712 17H20.5a.5.5 0 0 0 .5-.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14.129 19.87l-.825-.377-2.149.965-1.576-1.566.949-2.066-.318-.848-2.202-.838L8 12.92l2.13-.79.377-.825-.965-2.15 1.566-1.576 2.066.95.848-.319.838-2.201L17.08 6l.79 2.13.825.377 2.15-.965 1.576 1.565-.95 2.066.319.849 2.201.838.008 2.222-2.13.79-.377.824.965 2.149-1.565 1.576-2.066-.949-.849.318-.838 2.202-2.222.008zm1.454 1.129l.897-.003.758-1.994 1.608-.59 1.81.832.63-.636-.874-1.948.722-1.551L23 14.417l-.004-.897-1.995-.76-.588-1.606.831-1.809-.636-.632-1.945.874-1.555-.721L16.417 7l-.897.004-.758 1.994-1.608.59-1.81-.832-.63.636.873 1.945-.72 1.555L9 13.584l.004.896 1.995.76.588 1.606-.83 1.81.635.63 1.945-.873 1.555.722zm3.417-7A3 3 0 1 1 16 11a3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2 2 0 0 0 2-2zM29 22a2 2 0 0 1-2 2h-6.69l-4.277 6.33L11.757 24H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h22a2 2 0 0 1 2 2zM28 5a1.001 1.001 0 0 0-1-1H5a1.001 1.001 0 0 0-1 1v17a1.001 1.001 0 0 0 1 1h7.289l3.744 5.543L19.778 23H27a1.001 1.001 0 0 0 1-1z"
  }));
};

var _default = ConfigurePopupIcon;
exports["default"] = _default;