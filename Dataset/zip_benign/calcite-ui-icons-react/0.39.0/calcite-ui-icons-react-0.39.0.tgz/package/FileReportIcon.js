"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileReportIcon = function FileReportIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 3.6L11.4 0H2v16h13zM14 15H3V1h7v4h4zm0-11h-3V1h.31L14 3.69zM4 14h9V7H4zm3-1v-1h2v1zm0-2v-1h2v1zm5 2h-2v-1h2zm0-2h-2v-1h2zm0-3v1h-2V8zM9 8v1H7V8zM5 8h1v1H5zm0 2h1v1H5zm0 2h1v1H5zm4-9H4V2h5zm0 2H4V4h5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 1v22h18V6.709L15.29 1zm17 21H4V2h10v6h6zm0-15h-5V2h.2L20 6.8zM6 20h12V10H6zm4-1v-2h3v2zm0-3v-2h3v2zm7 3h-3v-2h3zm0-3h-3v-2h3zm0-5v2h-3v-2zm-4 0v2h-3v-2zm-6 0h2v2H7zm0 3h2v2H7zm0 3h2v2H7zm6-12H6V4h7zm0 2H6V6h7z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5 2v28h22V9.699L19.3 2zm21 27H6V3h12v8h8zm-7-19V3l7 7zM8 27h16V14H8zm4-1v-2h5v2zm5-5v2h-5v-2zm-5-1v-2h5v2zm11 6h-5v-2h5zm0-3h-5v-2h5zm0-3h-5v-2h5zm0-5v2h-5v-2zm-6 0v2h-5v-2zm-8 0h2v2H9zm0 3h2v2H9zm0 3h2v2H9zm0 3h2v2H9zm7-15H8V8h8zm0-3H8V5h8z"
  }));
};

var _default = FileReportIcon;
exports["default"] = _default;