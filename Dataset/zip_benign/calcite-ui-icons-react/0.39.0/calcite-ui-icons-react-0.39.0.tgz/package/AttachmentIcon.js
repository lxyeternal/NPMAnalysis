"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AttachmentIcon = function AttachmentIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.723 10.717a.743.743 0 0 0-.223.533.75.75 0 0 0 .75.75.742.742 0 0 0 .532-.223l7.712-7.797a1.75 1.75 0 1 0-2.499-2.45L2.85 9.91a3 3 0 1 0 4.323 4.159l6.323-6.638.724.69-6.322 6.637A3.963 3.963 0 0 1 5 16a4 4 0 0 1-2.868-6.788L10.278.833A2.75 2.75 0 0 1 15 2.75a2.732 2.732 0 0 1-.795 1.934L6.494 12.48A1.734 1.734 0 0 1 5.25 13a1.752 1.752 0 0 1-1.75-1.75 1.735 1.735 0 0 1 .52-1.244l5.51-5.45.703.71z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.44 15.44a1.5 1.5 0 0 0 2.115 2.125L20.111 7.131a3 3 0 1 0-4.223-4.262L4.332 14.304a4.5 4.5 0 1 0 6.364 6.363l8.98-9.079.712.703-8.981 9.08a5.5 5.5 0 1 1-7.779-7.777L15.185 2.159a4 4 0 1 1 5.63 5.683L10.259 18.276a2.5 2.5 0 0 1-3.527-3.544l8-8 .707.707z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4 22.5a7.453 7.453 0 0 1 2.167-5.273L19.588 3.633a5.5 5.5 0 1 1 7.801 7.756l-.013.014L14.99 23.96a3.5 3.5 0 1 1-4.965-4.935L20.448 8.602l.707.707-10.423 10.423a2.5 2.5 0 1 0 3.546 3.525l12.425-12.596a4.5 4.5 0 0 0-6.385-6.343L6.878 17.929a6.5 6.5 0 0 0 9.157 9.228l11.71-11.366.696.717-11.71 11.366A7.5 7.5 0 0 1 4 22.5z"
  }));
};

var _default = AttachmentIcon;
exports["default"] = _default;