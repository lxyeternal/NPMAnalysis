"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImageLayerIcon = function ImageLayerIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 11H4.219l.194-2H6zm3-4H7v1h2z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 6H7V5h2zm2.781 5l-.194-2H10v2z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.706 1.014c-2.69 0-2.724.986-5.412.986a10.39 10.39 0 0 1-3.161-.512L0 14.09a9.158 9.158 0 0 0 3.793.711c3.665 0 4.749-1.6 8.414-1.6A6.624 6.624 0 0 1 16 14.29L13.867 1.687a8.204 8.204 0 0 0-3.161-.674zM12.207 12.2a12.79 12.79 0 0 0-4.526.852 10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363L2.935 2.74A11.376 11.376 0 0 0 5.294 3a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.212 7.212 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376zM3.896 4l-.779 8h9.766l-.779-8zM10 5h1.197l.098 1H10zm0 2h1.392l.097 1H10zm-4 4H4.219l.194-2H6zm0-3H4.51l.098-1H6zm0-2H4.705l.098-1H6zm3 5H7V9h2zm0-3H7V7h2zm0-2H7V5h2zm1 5V9h1.587l.194 2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 10.478c.421-.112.843-.23 1.27-.353A41.743 41.743 0 0 1 14 9.416v3.056a27.07 27.07 0 0 0-3.09.82c-.308.098-.609.19-.91.28zM6.424 18.8A18.148 18.148 0 0 0 9 18.623v-3.759a11.725 11.725 0 0 1-2.501.263c-.448 0-.943-.032-1.466-.082l-.62 3.602a12.935 12.935 0 0 0 2.01.153z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.581 5.775c.147-.06.284-.116.419-.168v2.792c-1.089.224-2.077.5-3.005.764-.34.097-.669.19-.995.28V6.724a11.84 11.84 0 0 0 3.581-.95zm6.594 11.466l-.705-4.18a25.93 25.93 0 0 0-4.47.254v4.09a24.01 24.01 0 0 1 3.458-.239c.578 0 1.152.025 1.717.075z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.31 2.2c-3.847 0-3.891 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722L1 20.783A13.093 13.093 0 0 0 6.424 21.8c5.242 0 6.792-1.634 12.034-1.634a13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105a12.674 12.674 0 0 0-4.52-.878zm2.148 16.966a24.031 24.031 0 0 0-6.251.845 22.054 22.054 0 0 1-5.783.789 13.727 13.727 0 0 1-4.3-.65L4.848 4.343A16.193 16.193 0 0 0 8.57 4.8a9.805 9.805 0 0 0 4.25-.875 7.791 7.791 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l2.674 15.872a16.25 16.25 0 0 0-4.157-.52zM16.31 4.2a6.88 6.88 0 0 0-3.11.65 10.801 10.801 0 0 1-4.63.95 16.722 16.722 0 0 1-2.914-.268L3.262 19.436a13.44 13.44 0 0 0 3.162.364 21.225 21.225 0 0 0 5.55-.761 24.858 24.858 0 0 1 6.484-.873 18.038 18.038 0 0 1 2.927.234L19.057 4.59a10.548 10.548 0 0 0-2.746-.39zM10 10.478c.421-.112.843-.23 1.27-.353A41.743 41.743 0 0 1 14 9.416v3.056a27.07 27.07 0 0 0-3.09.82c-.308.098-.609.19-.91.28zm-1 3.358a11.696 11.696 0 0 1-3.797.22l.53-3.077c.231.017.468.047.693.047A12.005 12.005 0 0 0 9 10.72zm6-4.611a20.179 20.179 0 0 1 3.776-.283l.526 3.118a27.149 27.149 0 0 0-4.302.244zm3.18-3.819l.428 2.537A21.647 21.647 0 0 0 15 8.216V5.308a6.856 6.856 0 0 1 1.31-.108 9.16 9.16 0 0 1 1.87.206zm-4.599.369c.147-.06.284-.116.419-.168v2.792c-1.089.224-2.077.5-3.005.764-.34.097-.669.19-.995.28V6.724a11.84 11.84 0 0 0 3.581-.95zM8.571 6.8c.15 0 .286-.009.429-.013v2.91a10.6 10.6 0 0 1-3.099.31l.575-3.34A17.059 17.059 0 0 0 8.57 6.8zm-4.16 11.847l.621-3.602a15.7 15.7 0 0 0 1.466.082A11.725 11.725 0 0 0 9 14.864v3.76a18.148 18.148 0 0 1-2.576.176 12.935 12.935 0 0 1-2.012-.153zm7.328-.58c-.577.138-1.143.274-1.74.39v-3.846c.402-.113.802-.236 1.21-.365a27.07 27.07 0 0 1 2.79-.754v4.075c-.803.15-1.538.325-2.26.5zm6.718-.901a24.01 24.01 0 0 0-3.458.239v-4.09a25.93 25.93 0 0 1 4.47-.255l.705 4.18a19.892 19.892 0 0 0-1.717-.074z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M23.463 23.2a26.071 26.071 0 0 0-3.463.224v-5.076a34.065 34.065 0 0 1 5.302-.251l.861 5.191c-.9-.059-1.804-.088-2.7-.088zM13 8.705v4.258c.456-.124.916-.253 1.392-.389A46.427 46.427 0 0 1 19 11.432V7.347a16.922 16.922 0 0 0-2.396.56A22.646 22.646 0 0 1 13 8.705z",
    opacity: ".25"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13 13.999a84.02 84.02 0 0 0 1.666-.464c1.323-.378 2.741-.78 4.334-1.08v5.03a32.286 32.286 0 0 0-4.714 1.202c-.435.137-.86.267-1.286.391zm-4.463 11.8A16.675 16.675 0 0 0 12 25.477v-5.1a15.064 15.064 0 0 1-3.463.395 20.464 20.464 0 0 1-2.259-.142l-.796 4.796a13.024 13.024 0 0 0 3.055.375z",
    opacity: ".5"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M23.462 27.2A33.153 33.153 0 0 1 31 28L27 3.9a26.401 26.401 0 0 0-5.926-.689c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 3.9L1 28a16.273 16.273 0 0 0 7.538 1.8c6.876 0 8.048-2.6 14.924-2.6zm-21.355.234L5.795 5.217a15.6 15.6 0 0 0 4.544.651 17.42 17.42 0 0 0 5.445-.847 16.628 16.628 0 0 1 5.29-.81 26.164 26.164 0 0 1 5.05.518l3.651 21.999a37.286 37.286 0 0 0-6.313-.528 22.381 22.381 0 0 0-7.77 1.348A20.422 20.422 0 0 1 8.539 28.8a15.989 15.989 0 0 1-6.43-1.366zM24.384 6.456a23.558 23.558 0 0 0-3.31-.245 14.762 14.762 0 0 0-4.738.733 19.402 19.402 0 0 1-5.996.924 18.182 18.182 0 0 1-2.92-.228L4.349 26.146a14.096 14.096 0 0 0 4.188.654 18.525 18.525 0 0 0 6.541-1.154 24.357 24.357 0 0 1 8.385-1.446c1.448 0 2.763.078 3.896.188zM20 12.29a26.155 26.155 0 0 1 4.29-.29l.845 5.097a35.442 35.442 0 0 0-5.135.242zm3.519-4.935l.604 3.643a27.235 27.235 0 0 0-4.123.276V7.246c.33-.02.68-.035 1.074-.035a21.744 21.744 0 0 1 2.445.143zm-6.915.553A16.922 16.922 0 0 1 19 7.347v4.085a46.427 46.427 0 0 0-4.608 1.142c-.475.136-.936.265-1.392.389V8.705a22.646 22.646 0 0 0 3.604-.798zM13 14a84.02 84.02 0 0 0 1.666-.464c1.323-.378 2.741-.78 4.334-1.08v5.03a32.286 32.286 0 0 0-4.714 1.202c-.435.137-.86.267-1.286.391zm-2.66-5.13c.603 0 1.146-.027 1.66-.065v4.414a13.823 13.823 0 0 1-4.56.414l.808-4.872a19.724 19.724 0 0 0 2.092.108zM12 19.344a15.286 15.286 0 0 1-5.558.299l.832-5.012c.407.04.808.066 1.198.066A15.487 15.487 0 0 0 12 14.241zm-6.518 6.08l.796-4.796a20.464 20.464 0 0 0 2.26.143A15.064 15.064 0 0 0 12 20.376v5.1a16.675 16.675 0 0 1-3.463.324 13.024 13.024 0 0 1-3.055-.375zm9.289-.73a39.72 39.72 0 0 1-1.771.537V20.12a49.66 49.66 0 0 0 1.587-.48A31.896 31.896 0 0 1 19 18.5v5.077a30.389 30.389 0 0 0-4.23 1.117zM20 23.423v-5.076a34.138 34.138 0 0 1 5.302-.25l.861 5.19c-.9-.059-1.804-.088-2.7-.088a26.071 26.071 0 0 0-3.463.224z"
  }));
};

var _default = ImageLayerIcon;
exports["default"] = _default;