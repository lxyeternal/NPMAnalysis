"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListCheckAllIcon = function ListCheckAllIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 14h9v1H6v-1zM6 3h9V2H6v1zm0 6h9V8H6v1zm-3.44 6.17l2.71-2.7-.74-.74-1.97 1.97-.92-.8-.74.74 1.66 1.53zm0-11l2.7-2.71-.74-.74-1.97 1.97-.92-.8-.74.74 1.66 1.53zm0 6l2.71-2.7-.74-.74L2.56 8.7l-.92-.8-.74.74 1.66 1.53z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 4h13v1H9V4zm0 17h13v-1H9v1zm0-8h13v-1H9v1zm-5.44 9.17L7 18.74 6.26 18l-2.71 2.7-1.12-1-.74.74 1.86 1.73zm0-16L7 2.74 6.26 2 3.55 4.7l-1.12-1-.74.74 1.86 1.73zm0 8L7 10.74 6.26 10l-2.71 2.7-1.12-1-.74.74 1.86 1.73z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 6h18v1H11V6zm0 11h18v-1H11v1zm0 10h18v-1H11v1zm-5.44 1.17l4.71-4.7-.74-.74-3.97 3.97-1.88-1.79-.74.74 2.62 2.52zm0-10l4.71-4.7-.74-.74-3.97 3.97-1.88-1.79-.74.74 2.62 2.52zm0-10l4.7-4.71-.74-.74-3.97 3.97L3.67 4.9l-.74.74 2.62 2.52z"
  }));
};

var _default = ListCheckAllIcon;
exports["default"] = _default;