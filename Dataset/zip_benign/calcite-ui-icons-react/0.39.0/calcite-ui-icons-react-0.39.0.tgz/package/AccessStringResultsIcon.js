"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AccessStringResultsIcon = function AccessStringResultsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 4h3v1h-3zm-1 7h4v-1H9zm0-7H3v1h6zM5 9h3V8H5zm4 0h2V8H9zm3-3h-2v1h2zM5 7h4V6H5zm-2 4h5v-1H3zm-2 3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1zm0-1h14V2H1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 7H4V6h9zm3 1H4v1h12zm-3 2H8v1h5zm5 0h-4v1h4zM8 13h4v-1H8zm9-1h-4v1h4zm-9 3h4v-1H8zm9-1h-4v1h4zm1-8h-4v1h4zM4 17h8v-1H4zm9 0h6v-1h-6zm4-8h3V8h-3zm6-4.5v15a1.5 1.5 0 0 1-1.5 1.5h-19A1.5 1.5 0 0 1 1 19.5v-15A1.5 1.5 0 0 1 2.5 3h19A1.5 1.5 0 0 1 23 4.5zm-1 .25a.75.75 0 0 0-.75-.75H2.75a.75.75 0 0 0-.75.75v14.5a.75.75 0 0 0 .75.75h18.5a.75.75 0 0 0 .75-.75z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17 10H6V9h11zm2 1H6v1h13zM6 24h10v-1H6zm11-10h-6v1h6zm-6 2v1h5v-1zm6 2h-6v1h6zm7-9h-6v1h6zm-4 3h6v-1h-6zm-3 12h8v-1h-8zm6-10h-5v1h5zm-1 2h-5v1h5zm-1 2h-3v1h3zm-10 3h6v-1h-6zm7 0h3v-1h-3zm9.502-16A2.498 2.498 0 0 1 30 7.498V26a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zM29 7.25A1.25 1.25 0 0 0 27.75 6H4a1 1 0 0 0-1 1v19a1 1 0 0 0 1 1h24a1 1 0 0 0 1-1z"
  }));
};

var _default = AccessStringResultsIcon;
exports["default"] = _default;