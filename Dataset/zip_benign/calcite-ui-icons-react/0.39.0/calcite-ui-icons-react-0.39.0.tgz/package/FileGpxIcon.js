"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileGpxIcon = function FileGpxIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v7h1V1h7v4h4v10H2v1h13V3.6zM14 4h-3V1h.31L14 3.69zM4 12.776V8H3v.045A1.16 1.16 0 0 0 2.776 8H1.758A1.76 1.76 0 0 0 0 9.758v.484A1.76 1.76 0 0 0 1.758 12h1.018A1.16 1.16 0 0 0 3 11.955v.821a.224.224 0 0 1-.224.224H1v1h1.776A1.225 1.225 0 0 0 4 12.776zM2.776 11H1.758A.759.759 0 0 1 1 10.242v-.484A.759.759 0 0 1 1.758 9h1.018A.224.224 0 0 1 3 9.224v1.552a.224.224 0 0 1-.224.224zM6 11.936a1.375 1.375 0 0 0 .396.064h1.209A1.397 1.397 0 0 0 9 10.604V9.395A1.397 1.397 0 0 0 7.604 8H6.395A1.375 1.375 0 0 0 6 8.064V8H5v6h1zM6.396 9h1.209A.396.396 0 0 1 8 9.396v1.209a.396.396 0 0 1-.396.395H6.395A.396.396 0 0 1 6 10.604V9.395A.396.396 0 0 1 6.396 9zm6.89-1L12.08 9.9l1.332 2.1H12.23l-.74-1.167L10.75 12H9.568l1.33-2.1L9.694 8h1.183l.613.966.612-.966z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v11h1V2h10v6h6v14H4v-1H3v2h18V6.709zM20 7h-5V2h.2L20 6.8zM5 13.295A2.018 2.018 0 0 0 3.959 13h-.918A2.044 2.044 0 0 0 1 15.041v.918A2.044 2.044 0 0 0 3.041 18h.918A2.018 2.018 0 0 0 5 17.705v.254A1.042 1.042 0 0 1 3.959 19H2v1h1.959A2.044 2.044 0 0 0 6 17.959V13H5zM3.959 17h-.918A1.042 1.042 0 0 1 2 15.959v-.918A1.042 1.042 0 0 1 3.041 14h.918A1.042 1.042 0 0 1 5 15.041v.918A1.042 1.042 0 0 1 3.959 17zM12 15.041A2.044 2.044 0 0 0 9.959 13h-.918A2.018 2.018 0 0 0 8 13.295V13H7v7h1v-2.295A2.018 2.018 0 0 0 9.041 18h.918A2.044 2.044 0 0 0 12 15.959zm-1 .918A1.042 1.042 0 0 1 9.959 17h-.918A1.042 1.042 0 0 1 8 15.959v-.918A1.042 1.042 0 0 1 9.041 14h.918A1.042 1.042 0 0 1 11 15.041zM18.238 13h-1.287L15.5 14.79 14.049 13h-1.287l2.094 2.583L12.896 18h1.288l1.316-1.623L16.816 18h1.287l-1.96-2.417z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v13h1V3h12v8h8v18H6v-1H5v2h22V9.699zm-.3 8V3l7 7zm3.133 9.857L24.577 23h-1.266L21.5 20.671 19.689 23h-1.266l2.444-3.143L18.645 17h1.266l1.589 2.043L23.09 17h1.265zM13 22.22a3 3 0 1 0 0-4.44V17h-1v9h1zM15 18a2 2 0 1 1-2 2 2.003 2.003 0 0 1 2-2zm-8.25 8.1A3.12 3.12 0 0 0 10 22.85V17H9v.79a3 3 0 1 0 0 4.42v.637a2.237 2.237 0 0 1-3.936 1.493l-.75.662A3.252 3.252 0 0 0 6.75 26.1zM7 22a2 2 0 1 1 2-2 2.003 2.003 0 0 1-2 2z"
  }));
};

var _default = FileGpxIcon;
exports["default"] = _default;