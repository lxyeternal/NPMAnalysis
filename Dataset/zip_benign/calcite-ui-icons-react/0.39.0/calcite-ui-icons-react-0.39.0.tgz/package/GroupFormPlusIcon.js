"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GroupFormPlusIcon = function GroupFormPlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 11v-1a1.001 1.001 0 0 0-1-1H4a1.001 1.001 0 0 0-1 1v1a1.001 1.001 0 0 0 1 1h8a1.001 1.001 0 0 0 1-1zm-9-1h8v1H4zm-4 3h1v1h1v1H0zM1 3H0V1h2v1H1zm3-2h3v1H4zM0 5h1v2H0zm0 4h1v2H0zm16 2h-1V9h1zm-9 4H4v-1h3zm8-2h1v2h-2v-1h1zm-6 2v-1h3v1zm7-11h-3v3h-1V4H9V3h3V0h1v3h3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19 13H5a1.001 1.001 0 0 0-1 1v2a1.001 1.001 0 0 0 1 1h14a1.001 1.001 0 0 0 1-1v-2a1.001 1.001 0 0 0-1-1zm0 3H5v-2h14zM2 20h1v1H1v-2h1zM1 3h2v1H2v1H1zm1 6H1V7h1zm0 4H1v-2h1zm0 4H1v-2h1zm20-6h1v2h-1zm0 4h1v2h-1zM7 4H5V3h2zm2 0V3h2v1zM5 20h2v1H5zm4 0h2v1H9zm4 0h2v1h-2zm4 0h2v1h-2zm5-1h1v2h-2v-1h1zM18 5h5v1h-5v5h-1V6h-5V5h5V0h1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26 20.5v-2a1.502 1.502 0 0 0-1.5-1.5h-17A1.502 1.502 0 0 0 6 18.5v2A1.502 1.502 0 0 0 7.5 22h17a1.502 1.502 0 0 0 1.5-1.5zm-19 0v-2a.5.5 0 0 1 .5-.5h17a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-17a.5.5 0 0 1-.5-.5zM3 11H2V9h1zm0 4H2v-2h1zm26-2h1v2h-1zM3 19H2v-2h1zm26-2h1v2h-1zM3 23H2v-2h1zm26-2h1v2h-1zM7 6H5V5h2zm4 0H9V5h2zm4 0h-2V5h2zM3 26h1v1H2v-2h1zM2 5h2v1H3v1H2zm3 21h2v1H5zm6 1H9v-1h2zm4 0h-2v-1h2zm14-2h1v2h-2v-1h1zm-4 1h2v1h-2zm-2 0v1h-2v-1zm-4 0v1h-2v-1zM30 7v1h-6v6h-1V8h-6V7h6V1h1v6z"
  }));
};

var _default = GroupFormPlusIcon;
exports["default"] = _default;