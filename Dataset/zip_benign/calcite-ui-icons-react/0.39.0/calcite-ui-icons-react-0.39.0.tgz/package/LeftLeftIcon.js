"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LeftLeftIcon = function LeftLeftIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 8.255V14h-1V8.255a4.243 4.243 0 0 0-3.83-4.207c-.137-.014-.27-.042-.409-.042l-1.007-.003 1.6 1.599-.707.707L5.837 3.5 8.647.69l.706.708L7.75 3.003l1.015.003c.109 0 .21.026.318.033A5.244 5.244 0 0 1 14 8.255zm-9 3.022V8a4.245 4.245 0 0 1 .616-2.203l-.712-.71A5.216 5.216 0 0 0 4 8v3.277L2.398 9.675l-.707.707 2.809 2.81 2.81-2.81-.708-.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20 11.634V21h-1v-9.366a6.636 6.636 0 0 0-6.608-6.625l-1.668-.004 1.63 1.629-.707.707-2.848-2.847 2.847-2.848.707.707-1.65 1.651 1.692.005A7.638 7.638 0 0 1 20 11.634zM6 17.28V11.5a6.606 6.606 0 0 1 2.31-5.007l-.702-.702A7.593 7.593 0 0 0 5 11.5v5.78l-1.64-1.64-.707.707L5.5 19.194l2.847-2.847-.707-.707z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27 16v12h-1V16a9.015 9.015 0 0 0-8.977-9l-3.288-.008 2.644 2.643-.707.707-3.854-3.853 3.854-3.854.707.707-2.65 2.65L17.026 6A10.016 10.016 0 0 1 27 16zM11.623 8.804l-.706-.705A9.977 9.977 0 0 0 7 16v7.293l-2.646-2.647-.707.707L7.5 25.207l3.854-3.854-.707-.707L8 23.293V16a8.99 8.99 0 0 1 3.623-7.196z"
  }));
};

var _default = LeftLeftIcon;
exports["default"] = _default;