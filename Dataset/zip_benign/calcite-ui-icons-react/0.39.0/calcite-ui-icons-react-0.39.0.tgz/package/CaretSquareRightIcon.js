"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CaretSquareRightIcon = function CaretSquareRightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 14.071a.929.929 0 0 0 .929.929H14.07a.929.929 0 0 0 .929-.929V1.93a.929.929 0 0 0-.928-.93H1.93a.929.929 0 0 0-.93.929zM14 2v12H2V2zm-3.9 6L6 12.1V3.9z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 20.719V3.28A1.281 1.281 0 0 0 20.719 2H3.282A1.282 1.282 0 0 0 2 3.281v17.437A1.282 1.282 0 0 0 3.282 22h17.437A1.281 1.281 0 0 0 22 20.719zM3.281 21A.281.281 0 0 1 3 20.719V3.28A.281.281 0 0 1 3.281 3H20.72a.281.281 0 0 1 .281.281V20.72a.281.281 0 0 1-.281.281zM15.1 12L9 18.1V5.9z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 27.327V4.67A1.672 1.672 0 0 0 27.33 3H4.671A1.671 1.671 0 0 0 3 4.672v22.657A1.671 1.671 0 0 0 4.671 29h22.66A1.674 1.674 0 0 0 29 27.327zM4.671 28A.673.673 0 0 1 4 27.328V4.672A.673.673 0 0 1 4.671 4h22.66a.67.67 0 0 1 .669.67v22.657a.672.672 0 0 1-.67.673zM22.1 16L13 25.035V6.965z"
  }));
};

var _default = CaretSquareRightIcon;
exports["default"] = _default;