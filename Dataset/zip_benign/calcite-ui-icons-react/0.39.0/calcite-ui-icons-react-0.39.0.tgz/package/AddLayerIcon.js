"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AddLayerIcon = function AddLayerIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.65 12.563a12.666 12.666 0 0 0-.174-1.288l-1.5-8.862a7.212 7.212 0 0 0-2.27-.399 5.895 5.895 0 0 0-2.367.434A7.833 7.833 0 0 1 5.294 3a11.376 11.376 0 0 1-2.359-.26l-1.81 10.697a9.54 9.54 0 0 0 2.668.363c.272 0 .506-.023.75-.04a1.64 1.64 0 0 0 1.24.86 10.668 10.668 0 0 1-1.99.18A9.158 9.158 0 0 1 0 14.089l2.133-12.6A10.39 10.39 0 0 0 5.294 2c2.688 0 2.721-.986 5.412-.986a8.204 8.204 0 0 1 3.161.674L16 14.29a5.6 5.6 0 0 0-1.46-.71 1.636 1.636 0 0 0 .11-.579zM10 9H9v3H6v1h3v3h1v-3h3v-1h-3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21 18.358a15.368 15.368 0 0 1 1.615.329L19.941 2.815a11.86 11.86 0 0 0-3.63-.615 7.791 7.791 0 0 0-3.49.725 9.805 9.805 0 0 1-4.25.875 16.193 16.193 0 0 1-3.723-.457L2.124 19.15a13.727 13.727 0 0 0 4.3.65c.625 0 1.193-.024 1.72-.066a2.003 2.003 0 0 0 .749.93 21.55 21.55 0 0 1-2.47.136A13.093 13.093 0 0 1 1 19.783L4.05 2.078a15.028 15.028 0 0 0 4.52.722c3.849 0 3.893-1.6 7.74-1.6a12.674 12.674 0 0 1 4.52.878l3.051 18.105a11.242 11.242 0 0 0-2.918-.818 2.001 2.001 0 0 0 .037-.366zM15 14h-1v4h-4v.999h4V23h1v-4.001h4V18h-4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28 25.47c.689.082 1.289.173 1.775.258l-3.651-22a26.164 26.164 0 0 0-5.05-.517 16.628 16.628 0 0 0-5.29.81 17.42 17.42 0 0 1-5.445.847 15.6 15.6 0 0 1-4.544-.65L2.107 26.433a15.989 15.989 0 0 0 6.43 1.366 19.152 19.152 0 0 0 4.893-.576 1.991 1.991 0 0 0 1.134.724 20.082 20.082 0 0 1-6.026.852A16.273 16.273 0 0 1 1 27L5 2.9a14.99 14.99 0 0 0 5.34.968c4.807 0 5.59-1.657 10.734-1.657A26.401 26.401 0 0 1 27 2.9L31 27a26.337 26.337 0 0 0-3.062-.53A1.985 1.985 0 0 0 28 26zM21 20h-1v5h-5v1h5v5h1v-5h5v-1h-5z"
  }));
};

var _default = AddLayerIcon;
exports["default"] = _default;