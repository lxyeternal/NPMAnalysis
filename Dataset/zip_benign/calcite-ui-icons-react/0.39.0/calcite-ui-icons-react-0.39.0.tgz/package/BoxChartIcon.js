"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BoxChartIcon = function BoxChartIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 15h14v1H1V1h1zm1-3v-1h1V9H3V5h1V3H3V2h3v1H5v2h1v4H5v2h1v1zm1-5h1V6H4zm7 7H8v-1h1v-1H8V7h1V4H8V3h3v1h-1v3h1v5h-1v1h1zM9 9h1V8H9zm0 2h1v-1H9zm4-9h3v1h-1v2h1v4h-1v3h1v1h-3v-1h1V9h-1V5h1V3h-1zm2 5h-1v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 1v21h21v1H1V1zm4 5V3H5V2h3v1H7v3h2v6H7v3h1v1H5v-1h1v-3H4V6zm2 4H5v1h3zM5 7v2h3V7zm9 10v2h1v1h-3v-1h1v-2h-2v-6h2V5h-1V4h3v1h-1v6h2v6zm-2-4h3v-1h-3zm3 3v-2h-3v2zm6-14v5h2v5h-2v5h1v1h-3v-1h1v-5h-2V7h2V2h-1V1h3v1zm1 8h-3v1h3zm-3-2v1h3V8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 29h27v1H2V2h1zm4-7h3v-1H7zM5 8h3V5H7V4h3v1H9v3h3v7H9v6H8v-6H5zm1 4h5V9H6zm0 2h5v-1H6zm13-9h-3v1h3zm-1 18v3h1v1h-3v-1h1v-3h-3v-9h3V6h1v8h3v9zm-3-6h5v-2h-5zm5 5v-4h-5v4zm8-19h-3v1h3zm-3 22h3v-1h-3zm5-9h-3v8h-1v-8h-3v-6h3V4h1v6h3zm-1-3h-5v2h5zm0-2h-5v1h5z"
  }));
};

var _default = BoxChartIcon;
exports["default"] = _default;