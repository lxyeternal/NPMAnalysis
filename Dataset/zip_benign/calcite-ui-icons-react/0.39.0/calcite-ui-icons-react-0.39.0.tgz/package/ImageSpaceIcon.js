"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImageSpaceIcon = function ImageSpaceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 14v2H0V0h2v1H1v2h1v1H1v2h1v1H1v2h1v1H1v2h1v1H1v2h2v-1h1v1h2v-1h1v1h2v-1h1v1h2v-1h1v1h2v-1zm-4.5-9.5a1 1 0 1 0-1-1 1 1 0 0 0 1 1zM15 13H3V1h12zM4 8.59l1.3-1.35a.27.27 0 0 1 .4 0 .27.27 0 0 0 .4 0l2.017-2.152a.27.27 0 0 1 .381-.018l2.03 1.804a.269.269 0 0 0 .35.01l1.226-.824a.27.27 0 0 1 .37.028L14 7.56V2H4zm10 .36l-1.808-1.746-.689.461a1.267 1.267 0 0 1-1.639-.044l-1.5-1.333L6.83 7.923a1.28 1.28 0 0 1-.93.406 1.218 1.218 0 0 1-.24-.023L4 10.03V12h10z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 13.067V19h17V2H5zM21 18H6v-4.519l.947-.948a1.502 1.502 0 0 0 .677.163 1.403 1.403 0 0 0 .998-.415l3.306-3.305 3.26 2.716a1.504 1.504 0 0 0 1.864.047l1.832-1.374L21 12.481zm0-15v8.067l-1.714-1.714a.503.503 0 0 0-.657-.047L16.45 10.94a.503.503 0 0 1-.623-.016l-3.609-3.007a.503.503 0 0 0-.677.031l-3.627 3.628a.474.474 0 0 1-.678-.049.503.503 0 0 0-.704.008L6 12.067V3zm0 19h2v1H1V1h1v2h1v1H2v3h1v1H2v3h1v1H2v3h1v1H2v3h1v1H2v2h2v-1h1v1h3v-1h1v1h3v-1h1v1h3v-1h1v1h3v-1h1zM16.5 8A1.5 1.5 0 1 0 15 6.5 1.5 1.5 0 0 0 16.5 8zm0-2a.5.5 0 1 1-.5.5.5.5 0 0 1 .5-.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M31 28v2H2V1h2v1H3v3h1v1H3v3h1v1H3v3h1v1H3v3h1v1H3v3h1v1H3v3h1v1H3v3h3v-1h1v1h3v-1h1v1h3v-1h1v1h3v-1h1v1h3v-1h1v1h3v-1h1v1h3v-1zm-2-3H7V3h22zM8 18.242l2.68-2.13a.481.481 0 0 1 .538-.088l.62.293 3.855-3.201a.49.49 0 0 1 .643.01l4.413 3.098 2.308-2.061a.49.49 0 0 1 .695.025L28 18.087V4H8zm20 1.202l-4.61-4.237-1.975 1.764a1 1 0 0 1-1.24.072l-4.143-2.91-3.554 2.954a1.004 1.004 0 0 1-.64.23.988.988 0 0 1-.428-.096l-.325-.154L8 19.52V24h20zM19 9a2 2 0 1 1 2 2 2.002 2.002 0 0 1-2-2zm1 0a1 1 0 1 0 1-1 1.001 1.001 0 0 0-1 1z"
  }));
};

var _default = ImageSpaceIcon;
exports["default"] = _default;