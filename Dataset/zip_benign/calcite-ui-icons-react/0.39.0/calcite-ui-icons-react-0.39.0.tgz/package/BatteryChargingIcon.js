"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BatteryChargingIcon = function BatteryChargingIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.25 9H9.117L10 12.3 6.75 9h1.283L7 5.7zM4 15V2a1.003 1.003 0 0 1 1-1h1a1.003 1.003 0 0 1 1-1h3a1.003 1.003 0 0 1 1 1h1a1.003 1.003 0 0 1 1 1v13a1.003 1.003 0 0 1-1 1H5a1.003 1.003 0 0 1-1-1zm1 0h7V2h-2V1H7v1H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.25 13h-1.583l1.483 4.717L9.75 13h1.583L9.85 8.283zM18 5v16a2.006 2.006 0 0 1-2 2H8a2.006 2.006 0 0 1-2-2V5a2.006 2.006 0 0 1 2-2h1V2a1.003 1.003 0 0 1 1-1h4a1.003 1.003 0 0 1 1 1v1h1a2.006 2.006 0 0 1 2 2zm-1 0a1 1 0 0 0-1-1h-2V2h-4v2H8a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.66 17h2.35l-2.2-7 6.53 7h-2.35l2.2 7zM8 28V6a2.006 2.006 0 0 1 2-2h2V3a1.003 1.003 0 0 1 1-1h6a1.003 1.003 0 0 1 1 1v1h2a2.006 2.006 0 0 1 2 2v22a2.006 2.006 0 0 1-2 2H10a2.006 2.006 0 0 1-2-2zm1 0a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-3V3h-6v2h-3a1 1 0 0 0-1 1z"
  }));
};

var _default = BatteryChargingIcon;
exports["default"] = _default;