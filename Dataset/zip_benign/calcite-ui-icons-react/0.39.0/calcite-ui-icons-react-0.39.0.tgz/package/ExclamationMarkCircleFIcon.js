"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ExclamationMarkCircleFIcon = function ExclamationMarkCircleFIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1.2 8.5a7.3 7.3 0 1 0 7.3-7.3 7.3 7.3 0 0 0-7.3 7.3zm8.295 2.976v.048a1 1 0 0 1-2 0v-.048a1 1 0 0 1 2 0zM8.995 9h-.977V5h.977z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.5 2.2a10.3 10.3 0 1 0 10.3 10.3A10.299 10.299 0 0 0 12.5 2.2zM12 7h1v7h-1zm.5 10.5a1 1 0 1 1 1-1 1.002 1.002 0 0 1-1 1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.5 29.8A13.3 13.3 0 1 0 3.2 16.5a13.3 13.3 0 0 0 13.3 13.3zM16 9h1v11h-1zm.5 13.5a1 1 0 1 1-1 1 1.002 1.002 0 0 1 1-1z"
  }));
};

var _default = ExclamationMarkCircleFIcon;
exports["default"] = _default;