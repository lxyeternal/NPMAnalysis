"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CollaborationIcon = function CollaborationIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.864 9.204a5.886 5.886 0 0 0-2.947-6.436 2.925 2.925 0 0 0-5.834 0 5.885 5.885 0 0 0-2.947 6.436 2.932 2.932 0 1 0 3.4 4.256 5.887 5.887 0 0 0 4.927 0 2.931 2.931 0 1 0 3.4-4.256zM8 1.04A1.96 1.96 0 1 1 6.04 3 1.962 1.962 0 0 1 8 1.04zM3 13.96A1.96 1.96 0 1 1 4.96 12 1.962 1.962 0 0 1 3 13.96zM10.06 12a2.928 2.928 0 0 0 .052.521 5.102 5.102 0 0 1-4.224 0 2.899 2.899 0 0 0-2.76-3.449A4.915 4.915 0 0 1 5.203 3.86a2.92 2.92 0 0 0 5.594 0 4.915 4.915 0 0 1 2.075 5.212A2.938 2.938 0 0 0 10.06 12zM13 13.96A1.96 1.96 0 1 1 14.96 12 1.962 1.962 0 0 1 13 13.96z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19.902 13.161a7.876 7.876 0 0 0-3.956-8.1c0-.021.006-.04.006-.061a3.952 3.952 0 0 0-7.904 0c0 .02.006.04.006.06a7.876 7.876 0 0 0-3.956 8.101 3.946 3.946 0 1 0 4.242 5.93 7.855 7.855 0 0 0 7.32 0 3.945 3.945 0 1 0 4.242-5.93zM12 2.051A2.948 2.948 0 1 1 9.052 5 2.951 2.951 0 0 1 12 2.052zM5 19.949A2.948 2.948 0 1 1 7.948 17 2.951 2.951 0 0 1 5 19.948zm3.75-1.76A3.896 3.896 0 0 0 8.952 17a3.952 3.952 0 0 0-3.868-3.944A7.1 7.1 0 0 1 4.996 12a6.977 6.977 0 0 1 3.232-5.885 3.926 3.926 0 0 0 7.544 0A6.977 6.977 0 0 1 19.004 12a7.1 7.1 0 0 1-.088 1.056A3.952 3.952 0 0 0 15.048 17a3.896 3.896 0 0 0 .202 1.188 7.13 7.13 0 0 1-6.5 0zM19 19.948A2.948 2.948 0 1 1 21.948 17 2.951 2.951 0 0 1 19 19.948z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M25.745 18.13a9.85 9.85 0 0 0-4.832-10.818c.006-.105.031-.205.031-.312a4.944 4.944 0 1 0-9.888 0c0 .107.025.207.031.312A9.85 9.85 0 0 0 6.255 18.13a4.936 4.936 0 1 0 5.297 6.799 9.82 9.82 0 0 0 8.896 0 4.94 4.94 0 1 0 5.297-6.799zM16 3.044A3.956 3.956 0 1 1 12.044 7 3.96 3.96 0 0 1 16 3.044zM7 26.956A3.956 3.956 0 1 1 10.956 23 3.96 3.96 0 0 1 7 26.956zm4.846-2.98A4.92 4.92 0 0 0 7.25 18.08a8.888 8.888 0 0 1 4.02-9.722 4.913 4.913 0 0 0 9.46 0 8.888 8.888 0 0 1 4.02 9.722 4.92 4.92 0 0 0-4.596 5.895 9.17 9.17 0 0 1-8.308 0zM25 26.956A3.956 3.956 0 1 1 28.956 23 3.96 3.96 0 0 1 25 26.956z"
  }));
};

var _default = CollaborationIcon;
exports["default"] = _default;