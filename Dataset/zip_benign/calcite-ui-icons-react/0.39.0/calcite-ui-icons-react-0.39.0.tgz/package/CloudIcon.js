"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CloudIcon = function CloudIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.5 12a2.496 2.496 0 0 0 1.02-4.775l-.503-.227-.077-.548a3.968 3.968 0 0 0-7.43-1.357l-.403.734-.794-.266A.978.978 0 0 0 4 5.5a.989.989 0 0 0-.987.92L2.966 7l-.525.246A2.494 2.494 0 0 0 3.5 12zm-.034 1H3.5a3.493 3.493 0 0 1-1.484-6.659 1.966 1.966 0 0 1 2.617-1.73 4.968 4.968 0 0 1 9.298 1.701A3.496 3.496 0 0 1 12.466 13z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 19a5 5 0 0 1-1.934-9.611 3.21 3.21 0 0 1 1.422-2.024A3.17 3.17 0 0 1 6.19 6.87a3.268 3.268 0 0 1 1.446.34 6.293 6.293 0 0 1 12.143 1.867A4.99 4.99 0 0 1 19 19zm14-1a3.991 3.991 0 0 0 .623-7.934l-.79-.124-.052-.798a5.293 5.293 0 0 0-10.214-1.57L8.17 8.59l-.977-.483A2.277 2.277 0 0 0 6.19 7.87a2.18 2.18 0 0 0-1.167.339 2.205 2.205 0 0 0-.98 1.395l-.113.505-.476.2A4 4 0 0 0 5 18z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.515 12.66l-.407-.138-.06-.425A8.956 8.956 0 0 0 18.462 4.2a8.645 8.645 0 0 0-7.566 4.718l-.259.488-.534-.138a4.432 4.432 0 0 0-1.125-.162 3.93 3.93 0 0 0-4.022 3.713l-.022.402-.357.183A6.169 6.169 0 0 0 1.2 18.897c0 3.091 2.533 6.08 5.537 6.103h19.825c2.473 0 5.238-2.807 5.238-6.296a6.358 6.358 0 0 0-4.285-6.044zM26.562 24H6.745C4.366 23.982 2.2 21.55 2.2 18.897a5.173 5.173 0 0 1 2.835-4.603l.357-.183.51-.262.031-.573.022-.404a2.943 2.943 0 0 1 3.024-2.766 3.474 3.474 0 0 1 .874.13l.535.138.763.197.37-.696.26-.487A7.647 7.647 0 0 1 18.462 5.2a7.953 7.953 0 0 1 7.594 7.038l.061.425.087.608.581.198.407.138a5.359 5.359 0 0 1 3.607 5.097c0 2.934-2.318 5.296-4.238 5.296z"
  }));
};

var _default = CloudIcon;
exports["default"] = _default;