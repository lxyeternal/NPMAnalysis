"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DeskIcon = function DeskIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 3v1h1v9h1V6h6v6h6v1h1V4h1V3zm14 8h-2v-1h-1v1H9V9h5zm-2-3V7h-1v1H9V6h5v2zm2-3H2V4h12z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 5v1h1v13h1V8h9v8h9v3h1V6h1V5zm20 10h-8v-3h8zm-8-4V8h8v3zm8-4H3V6h18zm-3 2v1h-2V9zm-2 5v-1h2v1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 8v1h2v15h1V11h11v10h11v3h1V9h2V8zm25 12H17v-4h10zm-10-5v-4h10v4zm10-5H5V9h22zm-4 3v1h-2v-1zm-2 6v-1h2v1z"
  }));
};

var _default = DeskIcon;
exports["default"] = _default;