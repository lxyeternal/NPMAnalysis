"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BooleanIcon = function BooleanIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 11V7a1.001 1.001 0 0 0-1-1H1V3H0v9h3a1.001 1.001 0 0 0 1-1zM1 7h2v4H1zm7-1H6a1.001 1.001 0 0 0-1 1v4a1.001 1.001 0 0 0 1 1h2a1.001 1.001 0 0 0 1-1V7a1.001 1.001 0 0 0-1-1zm0 5H6V7h2zm3 1h2a1.001 1.001 0 0 0 1-1V7a1.001 1.001 0 0 0-1-1h-2a1.001 1.001 0 0 0-1 1v4a1.001 1.001 0 0 0 1 1zm0-5h2v4h-2zm5 5h-1V3h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.75 10H1V5H0v13h3.75A1.251 1.251 0 0 0 5 16.75v-5.5A1.251 1.251 0 0 0 3.75 10zM4 16.75a.25.25 0 0 1-.25.25H1v-6h2.75a.25.25 0 0 1 .25.25zM10.75 10h-2.5A1.251 1.251 0 0 0 7 11.25v5.5A1.251 1.251 0 0 0 8.25 18h2.5A1.251 1.251 0 0 0 12 16.75v-5.5A1.251 1.251 0 0 0 10.75 10zm.25 6.75a.25.25 0 0 1-.25.25h-2.5a.25.25 0 0 1-.25-.25v-5.5a.25.25 0 0 1 .25-.25h2.5a.25.25 0 0 1 .25.25zM17.75 10h-2.5A1.251 1.251 0 0 0 14 11.25v5.5A1.251 1.251 0 0 0 15.25 18h2.5A1.251 1.251 0 0 0 19 16.75v-5.5A1.251 1.251 0 0 0 17.75 10zm.25 6.75a.25.25 0 0 1-.25.25h-2.5a.25.25 0 0 1-.25-.25v-5.5a.25.25 0 0 1 .25-.25h2.5a.25.25 0 0 1 .25.25zm4 .25h2v1h-3V6h-1V5h2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.5 14H2V7H1v17h5.5A1.502 1.502 0 0 0 8 22.5v-7A1.502 1.502 0 0 0 6.5 14zm.5 8.5a.5.5 0 0 1-.5.5H2v-8h4.5a.5.5 0 0 1 .5.5zm8.5-8.5h-4a1.502 1.502 0 0 0-1.5 1.5v7a1.502 1.502 0 0 0 1.5 1.5h4a1.502 1.502 0 0 0 1.5-1.5v-7a1.502 1.502 0 0 0-1.5-1.5zm.5 8.5a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5zm8.5-8.5h-4a1.502 1.502 0 0 0-1.5 1.5v7a1.502 1.502 0 0 0 1.5 1.5h4a1.502 1.502 0 0 0 1.5-1.5v-7a1.502 1.502 0 0 0-1.5-1.5zm.5 8.5a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5zm7 .5v1h-3V8h-2V7h3v16z"
  }));
};

var _default = BooleanIcon;
exports["default"] = _default;