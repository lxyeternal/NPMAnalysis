"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HighwayChangeIcon = function HighwayChangeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 8.238a6.461 6.461 0 0 0 1 .881V14H4zM13 2h-1v6.193a6.407 6.407 0 0 1 1 .836zM4 4c0 3.402 2.36 4.36 4.442 5.204C10.352 9.978 12 10.646 12 13v1h1v-1c0-3.027-2.222-3.928-4.182-4.723C6.77 7.447 5 6.73 5 4v-.277l1.602 1.602.707-.707L4.5 1.808l-2.809 2.81.707.707L4 3.723z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 11.707a7.74 7.74 0 0 0 1 1.138V21H6zm12 3.503V3h-1v11.13a7.408 7.408 0 0 1 1 1.08zM6 3.707V6.5c0 4.923 3.175 6.328 5.977 7.567C14.672 15.26 17 16.29 17 20v1h1v-1c0-4.36-2.857-5.624-5.619-6.847C9.614 11.93 7 10.773 7 6.5V3.707l1.64 1.64.708-.706L6.5 1.793 3.652 4.641l.707.707z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 13.965a9.213 9.213 0 0 0 1 1.342V28H8zM24 4h-1v15.253a8.664 8.664 0 0 1 1 1.247zM7.985 8c0 6.459 4.279 8.309 8.054 9.94C19.62 19.486 23 20.947 23 26v2h1v-2c0-5.709-3.846-7.371-7.564-8.979-3.832-1.655-7.45-3.22-7.45-9.021V4.692l2.66 2.662.707-.707L8.5 2.793 4.646 6.646l.707.707 2.632-2.631z"
  }));
};

var _default = HighwayChangeIcon;
exports["default"] = _default;