"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FeatureLayerIcon = function FeatureLayerIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.793 14.8A9.158 9.158 0 0 1 0 14.089l2.133-12.6a10.247 10.247 0 0 0 2.018.44 4.223 4.223 0 0 0-.143.991 11.991 11.991 0 0 1-1.073-.18l-1.81 10.697a9.54 9.54 0 0 0 2.668.363 10.962 10.962 0 0 0 3.888-.748 12.79 12.79 0 0 1 4.526-.852 8.317 8.317 0 0 1 2.489.376l-1.72-10.163a7.883 7.883 0 0 0-1.065-.278 3.955 3.955 0 0 0-.399-1.07 8.368 8.368 0 0 1 2.355.623L16 14.29a6.624 6.624 0 0 0-3.793-1.089c-3.665 0-4.749 1.6-8.414 1.6zM8 0a2.893 2.893 0 0 1 3 2.999V7l-3 3-3-3V2.999A2.893 2.893 0 0 1 8 0zM6 2.999v3.587l2 2 2-2V2.999A1.893 1.893 0 0 0 8 1a1.893 1.893 0 0 0-2 1.999zM8 1.75A1.25 1.25 0 1 0 9.25 3 1.249 1.249 0 0 0 8 1.75z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.83 3.078l3.051 18.105a13.093 13.093 0 0 0-5.423-1.017c-5.242 0-6.792 1.634-12.034 1.634A13.093 13.093 0 0 1 1 20.783L4.05 3.078A13.726 13.726 0 0 0 6 3.562v1.01c-.429-.072-.828-.15-1.152-.229L2.124 20.15a13.726 13.726 0 0 0 4.3.65 22.054 22.054 0 0 0 5.783-.79 24.03 24.03 0 0 1 6.25-.844 16.248 16.248 0 0 1 4.158.52l-2.674-15.87a12.47 12.47 0 0 0-1.942-.475 4.612 4.612 0 0 0-.119-1.025 12.726 12.726 0 0 1 2.95.763zM8 3.352C8 1.458 9.994 0 12 0s4 1.458 4 3.352v7.662l-4 4.045-4-4.045zm1 0v7.25l3 3.035 3-3.034v-7.25C15 2.006 13.416 1 12 1S9 2.006 9 3.353zm3-.227A1.875 1.875 0 1 1 10.125 5 1.874 1.874 0 0 1 12 3.125zM12.875 5a.875.875 0 1 0-.875.875.876.876 0 0 0 .875-.875z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27 3.9L31 28a33.153 33.153 0 0 0-7.538-.8c-6.876 0-8.048 2.6-14.924 2.6A16.273 16.273 0 0 1 1 28L5 3.9a15.376 15.376 0 0 0 4 .905v1.008a15.34 15.34 0 0 1-3.205-.596L2.108 27.434a15.986 15.986 0 0 0 6.43 1.366 20.416 20.416 0 0 0 7.155-1.252 22.375 22.375 0 0 1 7.77-1.348 37.271 37.271 0 0 1 6.312.528L26.124 4.73a27.018 27.018 0 0 0-3.143-.437 4.484 4.484 0 0 0-.201-1.02A25.792 25.792 0 0 1 27 3.9zm-17 .708C10 2.455 12.258 0 16 0s6 2.455 6 4.608v10.665l-6 5.996-6-5.996zm1 0v10.251l5 4.997 5-4.997V4.607C21 3.095 19.262 1 16 1s-5 2.095-5 3.607zm5-.609a3 3 0 1 1-3 3 3 3 0 0 1 3-3zm-2 3a2 2 0 1 0 2-2 2.002 2.002 0 0 0-2 2z"
  }));
};

var _default = FeatureLayerIcon;
exports["default"] = _default;