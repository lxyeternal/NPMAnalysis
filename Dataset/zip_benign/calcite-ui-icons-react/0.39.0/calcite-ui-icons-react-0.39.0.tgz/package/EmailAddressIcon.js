"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EmailAddressIcon = function EmailAddressIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 2H1a1.002 1.002 0 0 0-1 1v8a1.001 1.001 0 0 0 1 1h7.05a4.403 4.403 0 0 1-.05-.5 4.403 4.403 0 0 1 .05-.5H1.708l3.726-3.726L7 8.526l1.567-1.252.913.913a4.5 4.5 0 0 1 .824-.59l-.952-.952L13 3.73v3.32a4.448 4.448 0 0 1 1 .225V3a1.001 1.001 0 0 0-1-1zM1 10.293V3.729l3.648 2.916zM1.69 3h10.62L7 7.246zm10.18 5.055A3.501 3.501 0 0 0 12.5 15h.5v-1h-.5a2.5 2.5 0 1 1 2.5-2.5v1a.5.5 0 0 1-1 0V10h-1v.092a1.483 1.483 0 0 0-.5-.092 1.5 1.5 0 1 0 .558 2.89A1.496 1.496 0 0 0 16 12.5v-1a3.502 3.502 0 0 0-4.13-3.445zM12 11.5a.5.5 0 1 1 .5.5.5.5 0 0 1-.5-.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.025 17H3.707l5.963-5.963L12 12.83l2.33-1.794 1.603 1.603a5.463 5.463 0 0 1 1.004-.41l-1.808-1.808L21 5.9v6.72a5.514 5.514 0 0 1 1 .64V5.5A1.504 1.504 0 0 0 20.5 4h-17A1.504 1.504 0 0 0 2 5.5v11A1.5 1.5 0 0 0 3.5 18h9.525c-.015-.165-.025-.331-.025-.5s.01-.335.025-.5zM3 16.293V5.901l5.871 4.52zM20.5 5c.009 0 .016.005.025.005L12 11.57 3.475 5.005c.009 0 .016-.005.025-.005zm-2 8a4.505 4.505 0 0 0-4.5 4.5 4.403 4.403 0 0 0 .05.5 4.49 4.49 0 0 0 4.45 4h.5v-1h-.5a3.495 3.495 0 0 1-3.45-3 3.455 3.455 0 0 1-.05-.5 3.498 3.498 0 0 1 5.947-2.5H20v.513A2.476 2.476 0 0 0 18.5 15a2.5 2.5 0 1 0 1.733 4.295A1.497 1.497 0 0 0 23 18.5v-1a4.555 4.555 0 0 0-4.5-4.5zm0 6a1.498 1.498 0 0 1-1.408-1 1.483 1.483 0 0 1-.092-.5 1.5 1.5 0 0 1 3 0 1.483 1.483 0 0 1-.092.5 1.498 1.498 0 0 1-1.408 1zm3.5-.5a.5.5 0 0 1-1 0v-3.447a3.639 3.639 0 0 1 1 2.447z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4 24a.96.96 0 0 1-.244-.05l8.997-8.996 2.747 2.153 2.747-2.152 1.99 1.99a7.966 7.966 0 0 1 .98-.435l-2.177-2.177 8.776-6.878A.973.973 0 0 1 28 8v9.082a8.03 8.03 0 0 1 1 .683V8a2.003 2.003 0 0 0-2-2H4a2.003 2.003 0 0 0-2 2v15a2.001 2.001 0 0 0 2 2h12.07a8.009 8.009 0 0 1-.07-1zm-.95-.757A.96.96 0 0 1 3 23V8a.973.973 0 0 1 .184-.545l8.776 6.878zM4.224 7h22.55L15.5 15.837zM24 18a6 6 0 0 0 0 12v-1a5 5 0 1 1 5-5v1a1 1 0 0 1-2 0v-4h-1v.78a3 3 0 1 0 .255 4.177 1.993 1.993 0 0 0 3.745-.95V24a6.007 6.007 0 0 0-6-6zm0 8a2 2 0 1 1 2-2 2.002 2.002 0 0 1-2 2z"
  }));
};

var _default = EmailAddressIcon;
exports["default"] = _default;