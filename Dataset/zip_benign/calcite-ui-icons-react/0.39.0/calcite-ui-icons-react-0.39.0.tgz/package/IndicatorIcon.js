"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var IndicatorIcon = function IndicatorIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 9h-1V3h1zm-1.5 2.5a1 1 0 1 0 1-1 1 1 0 0 0-1 1zM6 6v1c0 3.477-2.103 6-5 6H.5v-1H1c1.964 0 3.418-1.44 3.853-3.622A3.012 3.012 0 1 1 6 6zM5 6a2 2 0 1 0-2 2 1.913 1.913 0 0 0 2-2zm6.853 2.378A3.012 3.012 0 1 1 13 6v1c0 3.477-2.103 6-5 6h-.5v-1H8c1.964 0 3.418-1.44 3.853-3.622zM12 6a2 2 0 1 0-2 2 1.913 1.913 0 0 0 2-2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.2 15L21 6h1l-.2 9zm.3 1.5a1 1 0 1 0 1 1 1 1 0 0 0-1-1zM8.991 9.4c0 .029.009.066.009.097v.007C8.999 11.969 8.919 19 2.722 19H2v-1h.722c2.827 0 4.464-1.694 5.038-5.258A3.762 3.762 0 0 1 5 14a4.277 4.277 0 0 1-4-4.5A4.277 4.277 0 0 1 5 5a4.26 4.26 0 0 1 3.991 4.4zm-.993.127v-.045A3.28 3.28 0 0 0 5 6a3.283 3.283 0 0 0-3 3.5A3.283 3.283 0 0 0 5 13a3.277 3.277 0 0 0 2.998-3.473zM18.99 9.4c0 .029.009.066.009.097v.007c0 2.465-.08 9.496-6.277 9.496H12v-1h.722c2.827 0 4.464-1.694 5.038-5.258A3.762 3.762 0 0 1 15 14a4.277 4.277 0 0 1-4-4.5A4.277 4.277 0 0 1 15 5a4.26 4.26 0 0 1 3.991 4.4zm-.993.127v-.045A3.28 3.28 0 0 0 15 6a3.283 3.283 0 0 0-3 3.5 3.283 3.283 0 0 0 3 3.5 3.277 3.277 0 0 0 2.998-3.473z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.1 20l-.2-13h1.2l-.2 13zm.4 2.5a1 1 0 1 0 1 1 1 1 0 0 0-1-1zM13 12.5c0 .053-.013.102-.014.155H13l-.022 2.661C12.793 21.746 9.437 25 3 25v-1c5.803 0 8.653-2.635 8.952-8.263A4.76 4.76 0 0 1 8.1 17.8a5.118 5.118 0 0 1-4.9-5.3 5.118 5.118 0 0 1 4.9-5.3 5.118 5.118 0 0 1 4.9 5.3zm-1 0a4.12 4.12 0 0 0-3.9-4.3 4.12 4.12 0 0 0-3.9 4.3 4.12 4.12 0 0 0 3.9 4.3 4.12 4.12 0 0 0 3.9-4.3zm13 0c0 .053-.013.102-.014.155H25l-.022 2.661C24.793 21.746 21.437 25 15 25v-1c5.803 0 8.653-2.635 8.952-8.263A4.76 4.76 0 0 1 20.1 17.8a5.118 5.118 0 0 1-4.9-5.3 5.118 5.118 0 0 1 4.9-5.3 5.118 5.118 0 0 1 4.9 5.3zm-1 0a4.12 4.12 0 0 0-3.9-4.3 4.12 4.12 0 0 0-3.9 4.3 4.12 4.12 0 0 0 3.9 4.3 4.12 4.12 0 0 0 3.9-4.3z"
  }));
};

var _default = IndicatorIcon;
exports["default"] = _default;