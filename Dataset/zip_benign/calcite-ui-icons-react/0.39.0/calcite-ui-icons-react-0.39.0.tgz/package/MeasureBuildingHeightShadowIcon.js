"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MeasureBuildingHeightShadowIcon = function MeasureBuildingHeightShadowIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 8H5V7h1zm0-4H5v1h1zm0 6H5v1h1zm5-.176L8.942 11.5 11 13.176V12h3v1.176l2.058-1.676L14 9.824V11h-3zM4 10H3v1h1zm4 4h8v1H0v-1h1V1h7l5.204 8.408A.99.99 0 0 0 13 10h-.5L8 3zM7 2H2v12h5zM4 7H3v1h1zm0-3H3v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 21V4.242L18.17 16H19a.987.987 0 0 1 .093-.398L12 2H2v19H1v1h22v-1zm-1 0H3V3h8zm4-3h5v-1.176l2.058 1.676L20 20.176V19h-5v1.176L12.942 18.5 15 16.824zM8 5h2v2H8zm-4 7h2v-2H4zm0-5h2V5H4zm0 10h2v-2H4zm4-5h2v-2H8zm0 5h2v-2H8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 6H5v3h3zM7 8H6V7h1zm6-2h-3v3h3zm-1 2h-1V7h1zm1 12h-3v3h3zm-1 2h-1v-1h1zm1-9h-3v3h3zm-1 2h-1v-1h1zm-4-2H5v3h3zm-1 2H6v-1h1zm13 10h8v-2.19l3.058 2.69L28 28.19V26h-8v2.19l-3.058-2.69L20 22.81zM8 20H5v3h3zm-1 2H6v-1h1zm9-18.235L27.085 21.62a.994.994 0 0 1 .468-.515.975.975 0 0 1 .212-.05L16 2H2v27H1v1h30v-1H16zM15 29H3V3h12z"
  }));
};

var _default = MeasureBuildingHeightShadowIcon;
exports["default"] = _default;