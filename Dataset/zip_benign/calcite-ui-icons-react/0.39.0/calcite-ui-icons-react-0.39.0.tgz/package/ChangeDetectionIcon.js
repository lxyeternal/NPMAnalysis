"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ChangeDetectionIcon = function ChangeDetectionIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 1h-4v3.191l4 2V1z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 11.45V15h4v-4.616zM6 9v5H3v1h4v-5a1 1 0 0 1-1-1zM5 3H3v1.691l2 1zM3 13h2v-2.35l-2 .534z",
      opacity: ".2"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 5.809v4.34l2-.533V6.809l-2-1z",
      opacity: ".75"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 1H1v13H0V0h6v1zm11-1v16h-6v-4.55a1 1 0 0 0 .69-.275l.987-.94L15 9.35V7.309l-4-2v.812l-.31-.296A1 1 0 0 0 10 5.55V0zm-1 10.384l-4 1.066V15h4zM15 1h-4v3.191l4 2zm-8 9h1v6H2V2h6v5H7V3H6v11H3v1h4zM3 4.691l2 1V3H3zm0 5.458l2-.533V6.81l-2-1zM3 13h2v-2.35l-2 .534zm4-4h3v1.45l2.05-1.95L10 6.55V8H7z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.64 7.147c.808.335 1.573.694 2.312 1.042l.89.416A39.003 39.003 0 0 1 22 10.258V2h-7v4.942a.706.706 0 0 1 .265.052z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 13.247V22h-7v-5.807l.024.006h.01a6.316 6.316 0 0 0 2.946-.76 6.344 6.344 0 0 0 .771-.55c.133-.106.267-.212.408-.307a3.2 3.2 0 0 1 .626-.294 5.928 5.928 0 0 0 .559-.239c.434-.246.883-.477 1.32-.679.112-.05.224-.083.336-.123zM7.167 8.235c.58.268 1.194.576 1.833.906V4H4v2.774a412.89 412.89 0 0 1 3.167 1.461zM10 20v1H4v1h7v-9h-1zm-1-6.27a8.308 8.308 0 0 0-.948.34c-.612.283-1.236.604-1.84.947a8.357 8.357 0 0 1-.73.31 4.582 4.582 0 0 0-.917.432c-.196.133-.38.28-.565.426V20h5z",
      opacity: ".2"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.873 8.871C5.921 8.431 4.963 7.983 4 7.55v7.759c.06-.043.114-.089.175-.13a12.48 12.48 0 0 1 1.691-.77q.94-.534 1.905-.979A9.43 9.43 0 0 1 9 13V9.93a46.922 46.922 0 0 0-2.127-1.06z",
      opacity: ".75"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 2H2v19H1V1h9zm4-1h9v22h-9v-7.772a3.116 3.116 0 0 0 1 .062 5.415 5.415 0 0 0 2.526-.64 5.233 5.233 0 0 0 .634-.454c.163-.129.322-.255.491-.37a3.922 3.922 0 0 1 .806-.386c.15-.057.302-.115.45-.187.449-.256.915-.495 1.387-.714A6.573 6.573 0 0 1 22 12.28v-.977a37.655 37.655 0 0 0-3.54-1.873l-.863-.404c-.762-.358-1.51-.71-2.267-1.024a3.103 3.103 0 0 0-.33-.134 3.33 3.33 0 0 0-.553-.15 1.565 1.565 0 0 0-.447.054zm8 12.247c-.112.04-.224.074-.337.123a18.17 18.17 0 0 0-1.32.68 5.928 5.928 0 0 1-.558.238 3.2 3.2 0 0 0-.626.294c-.14.095-.275.2-.408.306a6.344 6.344 0 0 1-.77.55 6.316 6.316 0 0 1-2.946.761h-.01L15 16.193V22h7zm-7-6.305a.706.706 0 0 1 .265.052l.376.153c.807.335 1.572.694 2.311 1.042l.89.415A39.003 39.003 0 0 1 22 10.258V2h-7zM11 13h1v10H3V3h9v7h-1V4h-1v6a1 1 0 0 0-.999.999l-.001 1v-2.07a46.922 46.922 0 0 0-2.127-1.058C5.921 8.431 4.963 7.983 4 7.55v7.759c.06-.043.114-.089.175-.13a12.48 12.48 0 0 1 1.691-.77q.94-.534 1.905-.979A9.43 9.43 0 0 1 9 13v-1.001A1.001 1.001 0 0 0 10 13v8H4v1h7zM4 6.774c.676.301 3.167 1.461 3.167 1.461.58.268 1.194.576 1.833.906V4H4zM4 20h5v-6.27a8.308 8.308 0 0 0-.948.34c-.612.283-1.236.604-1.84.947a8.357 8.357 0 0 1-.73.31 4.582 4.582 0 0 0-.917.432c-.196.133-.38.28-.565.426zm10.283-5.717l2.783-2.783-2.783-2.783-.565.566L15.435 11H10v1h5.435l-1.717 1.717z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 9.662c.69.308 3.21 1.483 3.21 1.483A53.47 53.47 0 0 1 29 13.107V3h-8v6.207q.499.23 1 .455z",
    opacity: ".5"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6 18.997c.06-.042.114-.088.175-.129a12.478 12.478 0 0 1 1.691-.77q.94-.534 1.905-.979A9.43 9.43 0 0 1 11 16.69v-3.76a46.922 46.922 0 0 0-2.127-1.058c-.952-.44-1.91-.888-2.873-1.322z",
    opacity: ".75"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3.61 20.012c.14-.08.261-.182.39-.275v.855l-.04.026a5.718 5.718 0 0 1-.586.282l-.094.041a.7.7 0 0 1-.236.05c-.015 0-.03.009-.044.009v3h1v1H2V2h10v4h-1V3H3v17.3a6.163 6.163 0 0 0 .61-.288zM30 2v28H20v-9.879l1-1v1.289a8.821 8.821 0 0 1 1-.34 6.166 6.166 0 0 0 1.56-.619 7.575 7.575 0 0 0 .9-.644c.214-.17.43-.34.659-.495a5.225 5.225 0 0 1 1.074-.514c.211-.082.423-.163.63-.263.617-.351 1.26-.682 1.906-.98.092-.04.18-.064.271-.1V14.14a52.408 52.408 0 0 0-4.169-2.178L21 10.176v3.703l-1-1V2zm-1 15.425c-.576.27-1.16.567-1.739.895a8.36 8.36 0 0 1-.744.317 4.517 4.517 0 0 0-.896.422c-.207.14-.403.295-.597.45a8.475 8.475 0 0 1-1.014.722 7.21 7.21 0 0 1-2.01.775 8.519 8.519 0 0 0-1 .295V29h8zm0-4.318V3h-8v6.207l4.21 1.938A53.462 53.462 0 0 1 29 13.107zM12 7h3v8h-1V8h-2v19H6v2h8V18h1v12H5V7zm-1 10.42a8.308 8.308 0 0 0-.948.34 25.24 25.24 0 0 0-1.84.947 8.357 8.357 0 0 1-.73.31 4.581 4.581 0 0 0-.917.432c-.196.133-.38.28-.565.426V26h5zm0-4.49a46.922 46.922 0 0 0-2.127-1.059c-.952-.44-1.91-.888-2.873-1.322v8.448c.06-.042.114-.088.175-.129a12.478 12.478 0 0 1 1.691-.77q.94-.534 1.905-.979A9.43 9.43 0 0 1 11 16.69zM11 8H6v1.774c.676.301 3.167 1.461 3.167 1.461.58.268 1.194.576 1.833.906zm2 8v1h7.293l-2.646 2.646.707.707 3.853-3.853-3.854-3.854-.707.707L20.293 16z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 3v3H4v13.737c-.129.093-.25.195-.39.275A6.163 6.163 0 0 1 3 20.3V3zm15.517 15.637a4.517 4.517 0 0 0-.896.422c-.207.14-.403.295-.597.45a8.475 8.475 0 0 1-1.014.722 7.21 7.21 0 0 1-2.01.775 8.519 8.519 0 0 0-1 .295V29h8V17.425c-.576.27-1.16.567-1.739.895a8.36 8.36 0 0 1-.744.317zM6 9.774c.676.301 3.167 1.461 3.167 1.461.58.268 1.194.576 1.833.906V8H6zM12 25v2H6v2h8V18h-1a1 1 0 0 1-1-1zm-1-1v-6.58a8.308 8.308 0 0 0-.948.34 25.24 25.24 0 0 0-1.84.947 8.357 8.357 0 0 1-.73.31 4.581 4.581 0 0 0-.917.432c-.196.133-.38.28-.565.426V26h5z",
    opacity: ".2"
  }));
};

var _default = ChangeDetectionIcon;
exports["default"] = _default;