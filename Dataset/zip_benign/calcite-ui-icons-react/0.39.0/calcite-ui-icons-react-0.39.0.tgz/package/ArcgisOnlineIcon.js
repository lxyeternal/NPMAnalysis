"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ArcgisOnlineIcon = function ArcgisOnlineIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.41 11.428l-.836-.68a2.487 2.487 0 0 0-.054-4.524l-.504-.227-.076-.547a3.967 3.967 0 0 0-7.43-1.357l-.402.732-.792-.265A1.008 1.008 0 0 0 4 4.5a.989.989 0 0 0-.987.92L2.967 6l-.525.247A2.476 2.476 0 0 0 1 8.5 2.503 2.503 0 0 0 3.5 11H5v1H3.5a3.493 3.493 0 0 1-1.484-6.659 1.966 1.966 0 0 1 2.617-1.73 4.968 4.968 0 0 1 9.298 1.701 3.49 3.49 0 0 1 .478 6.116zM9.5 7.473L12.975 9.5 9.5 11.527 6.025 9.5zm0 1.158L8.01 9.5l1.49.87 1.49-.87zm3.475 2.869l-.858-.5L9.5 12.527 6.883 11l-.858.5L9.5 13.527zM9.5 14.527L6.883 13l-.858.5L9.5 15.527l3.475-2.027-.858-.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M24 12a4.99 4.99 0 0 1-2.15 4.101l-.85-.495v-.163a3.974 3.974 0 0 0-1.377-7.377l-.79-.124-.052-.798a5.293 5.293 0 0 0-10.214-1.57L8.17 6.59l-.977-.483A2.277 2.277 0 0 0 6.19 5.87a2.18 2.18 0 0 0-1.167.339 2.206 2.206 0 0 0-.98 1.395l-.113.505-.476.2A4 4 0 0 0 5 16h2v1H5a5 5 0 0 1-1.934-9.611 3.21 3.21 0 0 1 1.422-2.025 3.17 3.17 0 0 1 1.702-.493 3.269 3.269 0 0 1 1.446.34 6.293 6.293 0 0 1 12.143 1.867A4.988 4.988 0 0 1 24 12zm-5.437 7.5l-4.016 2.342-4.015-2.342.587-.342-.993-.579-1.578.92 6 3.501 6-3.5-1.579-.92-.992.578zm1.985-3l-1.579-.92-.992.578.586.342-4.016 2.342-4.015-2.342.587-.342-.993-.579-1.578.921 6 3.5zm-12-3l6-3.5 6 3.5-6 3.5zm6 2.342l4.015-2.342-4.016-2.343-4.015 2.343z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29.541 21.722l-.921-.537a5.765 5.765 0 0 0 2.18-4.48 5.359 5.359 0 0 0-3.607-5.098l-.989-.336-.147-1.033A7.953 7.953 0 0 0 18.463 3.2a7.647 7.647 0 0 0-6.683 4.187l-.629 1.184-1.298-.335a3.474 3.474 0 0 0-.874-.13 2.943 2.943 0 0 0-3.024 2.766l-.053.977-.867.445A5.173 5.173 0 0 0 2.2 16.897c0 2.653 2.166 5.085 4.545 5.103H9v1H6.737C3.733 22.978 1.2 19.988 1.2 16.897a6.169 6.169 0 0 1 3.378-5.493l.357-.183.022-.402a3.93 3.93 0 0 1 4.022-3.713 4.432 4.432 0 0 1 1.125.162l.534.138.26-.488A8.645 8.645 0 0 1 18.462 2.2a8.956 8.956 0 0 1 8.584 7.897l.06.425.408.138a6.358 6.358 0 0 1 4.285 6.044 6.776 6.776 0 0 1-2.259 5.018zm-3.409 4.376l-6.678 3.896-6.678-3.896.494-.288-.992-.58-1.486.868 8.662 5.054 8.663-5.054-1.419-.828-.992.58zm-.052-4.659l-.992.58 1.112.648-6.678 3.896-6.678-3.896 1.112-.649-.992-.579-2.105 1.228 8.663 5.054 8.663-5.054zm-15.22-2.386L19.521 14l8.663 5.053-8.663 5.054zm1.984 0l6.678 3.896 6.678-3.896-6.678-3.896z"
  }));
};

var _default = ArcgisOnlineIcon;
exports["default"] = _default;