"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerGraphicsIcon = function LayerGraphicsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.867 1.688a8.204 8.204 0 0 0-3.161-.674c-2.69 0-2.724.986-5.412.986a10.39 10.39 0 0 1-3.161-.512L0 14.09a9.158 9.158 0 0 0 3.793.711c3.665 0 4.749-1.6 8.414-1.6A6.624 6.624 0 0 1 16 14.29zM7.681 13.052a10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363L2.935 2.74A11.376 11.376 0 0 0 5.294 3a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.212 7.212 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852zM9 7v4h4V7zm3 3h-2V8h2zm0-5H4V4h8zM5.5 7A2.5 2.5 0 1 0 8 9.5 2.5 2.5 0 0 0 5.5 7zm0 4A1.5 1.5 0 1 1 7 9.5 1.502 1.502 0 0 1 5.5 11z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.31 2.2c-3.847 0-3.891 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722L1 20.783A13.093 13.093 0 0 0 6.424 21.8c5.242 0 6.792-1.634 12.034-1.634a13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105a12.674 12.674 0 0 0-4.52-.878zm2.148 16.966a24.034 24.034 0 0 0-6.251.845 22.05 22.05 0 0 1-5.783.789 13.727 13.727 0 0 1-4.3-.65L4.848 4.343A16.193 16.193 0 0 0 8.57 4.8a9.805 9.805 0 0 0 4.25-.875 7.792 7.792 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l2.674 15.872a16.25 16.25 0 0 0-4.157-.52zM16.98 7.004C13.244 7.004 11.315 9 8.25 9a21.421 21.421 0 0 1-2.668-.174l.115-1.064A19.403 19.403 0 0 0 8.488 8c2.775 0 4.763-2 8.13-2 .84 0 2.755.278 2.755.278l.124.957a13.11 13.11 0 0 0-2.517-.231zm1.026 4.007a16.835 16.835 0 0 0-4.946.781v5.219a16.879 16.879 0 0 1 4.946-.78 14.796 14.796 0 0 1 1.934.13l-.86-5.31a14.66 14.66 0 0 0-1.074-.04zm0 4.22a17.283 17.283 0 0 0-3.945.474v-3.159a15.483 15.483 0 0 1 3.945-.535c.073 0 .145 0 .217.002l.523 3.236q-.37-.018-.74-.018zM5.01 14.211a2.475 2.475 0 0 0 0 3.579 3.656 3.656 0 0 0 4.98 0 2.466 2.466 0 0 0 0-3.58 3.65 3.65 0 0 0-4.98 0zm4.254 2.882a2.64 2.64 0 0 1-3.528 0 1.488 1.488 0 0 1-.001-2.186 2.642 2.642 0 0 1 3.53 0 1.487 1.487 0 0 1 0 2.186z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.074 3.211c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 3.9L1 28a16.273 16.273 0 0 0 7.538 1.8c6.876 0 8.048-2.6 14.924-2.6A33.153 33.153 0 0 1 31 28L27 3.9a26.401 26.401 0 0 0-5.926-.689zm2.388 22.99a22.381 22.381 0 0 0-7.77 1.347A20.422 20.422 0 0 1 8.539 28.8a15.989 15.989 0 0 1-6.43-1.366L5.794 5.217a15.6 15.6 0 0 0 4.544.651 17.42 17.42 0 0 0 5.445-.847 16.628 16.628 0 0 1 5.29-.81 26.164 26.164 0 0 1 5.05.518l3.651 21.999a37.286 37.286 0 0 0-6.313-.528zM17.227 9.67a19.532 19.532 0 0 1-6.73 1.304 26.748 26.748 0 0 1-3.219-.201l.16-.961a23.278 23.278 0 0 0 3.488.273 16.71 16.71 0 0 0 6.188-1.303 10.623 10.623 0 0 1 3.96-.774 17.558 17.558 0 0 1 3.29.327l.132.79a20.35 20.35 0 0 0-2.964-.228 12.423 12.423 0 0 0-4.305.774zm6.41 4.33A26.697 26.697 0 0 0 16 15.172V23a26.767 26.767 0 0 1 7.637-1.17 23.503 23.503 0 0 1 2.985.195l-1.327-7.965a23.376 23.376 0 0 0-1.658-.06zm0 6.83a27.148 27.148 0 0 0-6.637.858v-5.761A25.363 25.363 0 0 1 23.637 15q.411 0 .803.015l.98 5.883a23.593 23.593 0 0 0-1.783-.068zM9 17.2a3.54 3.54 0 0 0-3.768 3.243A3.54 3.54 0 0 0 9 23.69a3.54 3.54 0 0 0 3.768-3.246A3.54 3.54 0 0 0 9 17.2zm0 5.489a2.543 2.543 0 0 1-2.755-2.246A2.542 2.542 0 0 1 9 18.2a2.542 2.542 0 0 1 2.755 2.243A2.543 2.543 0 0 1 9 22.69z"
  }));
};

var _default = LayerGraphicsIcon;
exports["default"] = _default;