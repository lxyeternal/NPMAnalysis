"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FlashIcon = function FlashIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.5 5a3.376 3.376 0 0 0-.5.05V1h1v4.05A3.376 3.376 0 0 0 8.5 5zM5 8.5a3.534 3.534 0 0 1 .05-.5H1v1h4.05A3.535 3.535 0 0 1 5 8.5zm6.163 2.247l2.849 2.849-.416.416-2.849-2.849c.06-.05.108-.11.163-.163H6.09c.055.053.104.113.163.163l-2.849 2.849-.416-.416 2.849-2.849c.05.059.11.108.163.163V6.09c-.053.056-.113.105-.163.164L2.988 3.405l.416-.416 2.848 2.849c-.058.05-.106.109-.161.162h4.818c-.055-.053-.104-.113-.163-.163l2.849-2.849.416.416-2.848 2.849c-.05-.06-.11-.107-.163-.162v4.82c.053-.056.113-.105.163-.164zM10 7H7v3h3zm1.95 1a3.534 3.534 0 0 1 .05.5 3.535 3.535 0 0 1-.05.5H16V8zM8 11.95V16h1v-4.05a3.376 3.376 0 0 1-.5.05 3.376 3.376 0 0 1-.5-.05zm2.87-8.407a5.524 5.524 0 0 0-.542-.226L9.556 5.18a3.5 3.5 0 0 1 .544.224zm2.586 2.586l-1.86.77a3.447 3.447 0 0 1 .224.544l1.863-.771a5.504 5.504 0 0 0-.227-.543zm-3.899 5.69l.772 1.863a5.508 5.508 0 0 0 .543-.225l-.771-1.861a3.411 3.411 0 0 1-.544.223zm3.9-.947a5.51 5.51 0 0 0 .225-.544l-1.862-.771a3.448 3.448 0 0 1-.224.544zM7.442 5.181L6.67 3.318a5.313 5.313 0 0 0-.543.226l.771 1.86a3.4 3.4 0 0 1 .544-.223zm-1.315 8.276a5.508 5.508 0 0 0 .543.225l.772-1.863a3.38 3.38 0 0 1-.544-.223zM3.544 6.129a5.384 5.384 0 0 0-.226.543l1.862.771a3.447 3.447 0 0 1 .224-.544zm-.226 4.2a5.525 5.525 0 0 0 .226.543l1.86-.771a3.448 3.448 0 0 1-.224-.544z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 2h1v7h-1zM9.547 9.09L5.163 4.707l-.456.457L9.09 9.547zM14 11v3h-3v-3zm1-1h-5v5h5zm-6.533.48L4.168 8.783c-.088.196-.166.397-.244.599l4.295 1.694zm2.013-2.013l.598-.248-1.695-4.295a13.9 13.9 0 0 0-.598.243zM9 13v-1H2v1zm.09 2.453l-4.383 4.384.457.456 4.383-4.383zm1.39 1.08l-1.696 4.299c.196.088.397.166.599.244l1.694-4.295zM8.466 14.52l-.248-.598-4.295 1.695c.078.201.156.402.243.598zM13 16h-1v7h1zm2.453-.09l4.384 4.383.456-.457-4.383-4.383zm1.08-1.39l4.299 1.696c.088-.196.166-.397.244-.599l-4.295-1.694zm-2.013 2.013l-.598.248 1.695 4.295a13.9 13.9 0 0 0 .598-.243zM16 12v1h7v-1zm-.09-2.453l4.383-4.384-.457-.456-4.383 4.383zm-1.39-1.08l1.696-4.299a12.336 12.336 0 0 0-.599-.244l-1.694 4.295zm2.013 2.013l.248.598 4.295-1.695a13.9 13.9 0 0 0-.243-.598z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.383 12.84l-4.95-4.95.456-.457 4.95 4.95zm2.311-1.544l-2.105-5.08-.596.247 2.104 5.08zm-3.151 2.8l-5.08-2.103-.247.597 5.08 2.104zm.84 6.064l-4.95 4.951.457.456 4.95-4.95zm-1.087-1.854l-5.08 2.105.247.596 5.08-2.104zm2.8 3.151l-2.103 5.08.597.247 2.104-5.08zm6.064-.84l4.951 4.95.456-.457-4.95-4.95zm-1.854 1.087l2.105 5.08.596-.247-2.104-5.08zm3.151-2.8l5.08 2.103.247-.597-5.08-2.104zm-.84-6.064l4.95-4.951-.457-.456-4.95 4.95zm1.087 1.854l5.08-2.105-.247-.596-5.08 2.104zm-2.8-3.151l2.103-5.08-.597-.247-2.104 5.08zM19 14v5h-5v-5zm1-1h-7v7h7zM16 3h1v8h-1zM3 17v-1h8v1zm14 13h-1v-8h1zm13-14v1h-8v-1z"
  }));
};

var _default = FlashIcon;
exports["default"] = _default;