"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DrivingTimeIcon = function DrivingTimeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.55 0A3.526 3.526 0 0 0 9 3.5 3.526 3.526 0 0 0 12.55 7 3.44 3.44 0 0 0 16 3.5 3.44 3.44 0 0 0 12.55 0zm-.05 6a2.5 2.5 0 0 1-.5-4.95V4h2V3h-1V1.05A2.5 2.5 0 0 1 12.5 6zM10 15v-3.629a1.371 1.371 0 0 0-1.131-1.347L8.86 10H10V9H8.527l-.439-1.316A.999.999 0 0 0 7.14 7H2.86a.998.998 0 0 0-.948.684L1.473 9H0v1h1.14l-.008.024A1.371 1.371 0 0 0 0 11.371V16h16v-1zm-2.714-3l-.5 1H3.214l-.5-1H2v.714a.708.708 0 0 0 .061.286H1v-1.629A.372.372 0 0 1 1.371 11H8.63a.372.372 0 0 1 .371.371V13H7.939A.708.708 0 0 0 8 12.714V12zM2.86 8h4.28l.666 2H2.194zM2 15v-1h6v1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18 11a5 5 0 1 0-4.95-5A5.006 5.006 0 0 0 18 11zm0-9a4 4 0 1 1-4 4 4.005 4.005 0 0 1 4-4zm2 5h-3V3h1v3h2zm-5 10a1.996 1.996 0 0 0-1.505-1.93l-.013-.07H15v-1h-1.702l-.296-1.605A1.829 1.829 0 0 0 11.394 11H4.606a1.829 1.829 0 0 0-1.608 1.395L2.702 14H1v1h1.518l-.013.07A1.996 1.996 0 0 0 1 17v6h22v-1h-8zM3.981 12.576c.075-.256.387-.576.625-.576h6.788c.238 0 .55.32.643.658l.43 2.342H3.534zM3 22H2v-1h1zm9 0H4v-1h8zm2 0h-1v-1h1zm-1-3a1 1 0 0 0 1-1v2H2v-2a1 1 0 0 0 1 1h1l-1-2H2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1h-1l-1 2zm-8-1h6v1H5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21 22.522A4.095 4.095 0 0 0 20.489 21h.011a.501.501 0 0 0 .5-.5V19h-2.286l-1.517-3.54A.824.824 0 0 0 16.5 15h-9a.824.824 0 0 0-.697.46L5.286 19H3v1.5a.501.501 0 0 0 .5.5 4.194 4.194 0 0 0-.5 1.522V29H2v1h28v-1h-9zM7.66 16h8.68l1.715 4H5.945zM5 29H4v-1.79a1.983 1.983 0 0 0 .613.235c.118.024.254.048.387.071zm13 0H6v-1.331A46.229 46.229 0 0 0 12 28a46.244 46.244 0 0 0 6.001-.331zm2 0h-1v-1.484c.133-.023.269-.047.387-.07A1.989 1.989 0 0 0 20 27.21zm0-3.532a1.015 1.015 0 0 1-.808.997A44.263 44.263 0 0 1 12 27.1a44.39 44.39 0 0 1-7.192-.635A1.015 1.015 0 0 1 4 25.468v-2.946a1.532 1.532 0 0 1 .524-1.156 1.49 1.49 0 0 1 .568-.307L5.296 21h13.406l.205.06a1.493 1.493 0 0 1 .568.308A1.53 1.53 0 0 1 20 22.522zM7 23l1 2H6a1 1 0 0 1-1-1v-1zm10 0h2v1a1 1 0 0 1-1 1h-2zm-8 1h6v1H9zm15-9.2A6.8 6.8 0 1 0 17.2 8a6.8 6.8 0 0 0 6.8 6.8zm0-12.6A5.8 5.8 0 1 1 18.2 8 5.806 5.806 0 0 1 24 2.2zM27 9h-4V4h1v4h3z"
  }));
};

var _default = DrivingTimeIcon;
exports["default"] = _default;