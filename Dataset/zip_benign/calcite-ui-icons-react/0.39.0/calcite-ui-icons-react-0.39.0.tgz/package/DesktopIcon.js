"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DesktopIcon = function DesktopIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.167 12a.834.834 0 0 0 .833-.834V1.834A.834.834 0 0 0 15.167 1H1.833A.834.834 0 0 0 1 1.833V4h1V2h13v9H7v3h4v-1h-1v-1zM9 13H8v-1h1zM.75 5a.751.751 0 0 0-.75.75v8.5a.751.751 0 0 0 .75.75h4.5a.751.751 0 0 0 .75-.75v-8.5A.751.751 0 0 0 5.25 5zM5 14H1V6h4zM4 8H2V7h2zm0 2H2V9h2zm-1 1h1v1H3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 3H3a1.001 1.001 0 0 0-1 1v2h1V4h20v13H9v1h2v1h-1v1h6v-1h-1v-1h8a1.001 1.001 0 0 0 1-1V4a1.001 1.001 0 0 0-1-1zm-9 16h-2v-1h2zM7.25 7H.75a.751.751 0 0 0-.75.75v13.5a.751.751 0 0 0 .75.75h6.5a.751.751 0 0 0 .75-.75V7.75A.751.751 0 0 0 7.25 7zM7 21H1V8h6zM6 10H2V9h4zm0 2H2v-1h4zm0 2H2v-1h4zm-1 1h1v1H5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.833 3H4.167A1.168 1.168 0 0 0 3 4.167V9h1V4.167A.167.167 0 0 1 4.167 4h26.666a.167.167 0 0 1 .167.167v17.667a.167.167 0 0 1-.167.166H11v1h4v2h-2v1h9v-1h-2v-2h10.833A1.168 1.168 0 0 0 32 21.834V4.166A1.168 1.168 0 0 0 30.833 3zM19 25h-3v-2h3zm-9 3V11a1.001 1.001 0 0 0-1-1H1a1.001 1.001 0 0 0-1 1v17a1.001 1.001 0 0 0 1 1h8a1.001 1.001 0 0 0 1-1zM1 11h8v17H1zm1 1h6v1H2zm0 2h6v1H2zm0 2h6v1H2zm5 3h1v1H7z"
  }));
};

var _default = DesktopIcon;
exports["default"] = _default;