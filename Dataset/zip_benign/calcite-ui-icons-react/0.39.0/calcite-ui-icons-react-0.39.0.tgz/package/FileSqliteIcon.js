"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileSqliteIcon = function FileSqliteIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v16h13V3.6zM14 6.105V15H3V1h7v4h4zM14 4h-3V1h.31L14 3.69zm-5.914 8c-.007.328-.007.66.01 1H5.75a.751.751 0 0 1-.75-.75v-4.5A.751.751 0 0 1 5.75 7h3.767a7.414 7.414 0 0 0-.561 1H6v4zm4.987-5.527a5.021 5.021 0 0 1-.618 3.255 6.809 6.809 0 0 0-1.2.572 4.085 4.085 0 0 1 1.037-.321 14.254 14.254 0 0 1-.761 1.052 1.772 1.772 0 0 0-.937.968 28.907 28.907 0 0 1 1.87-5.53 7.672 7.672 0 0 0-2.196 3.217A8.493 8.493 0 0 0 9.988 14h-.8c-.398-3.085.258-5.646 1.77-7.22 1.219-1.267 2.011-.694 2.115-.307z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v22h18V6.709zM20 22H4V2h10v6h6zm0-15h-5V2h.2L20 6.8zm-8.866 11c-.03.329-.05.663-.061 1H8.25A1.251 1.251 0 0 1 7 17.75v-5.5A1.251 1.251 0 0 1 8.25 11h5.466a11.903 11.903 0 0 0-.69 1H8.25a.25.25 0 0 0-.25.25v5.5a.25.25 0 0 0 .25.25zm1.794 3H12.1c-.354-4.648 1.078-8.29 3.465-10.613.615-.544 1.238-.727 1.752-.27v-.002c1.255 1.116.31 3.676-.835 5.477a10.211 10.211 0 0 0-1.8.858 12.954 12.954 0 0 1 1.556-.482l-1.143 1.578a1.93 1.93 0 0 0-1.177 1.098 16.683 16.683 0 0 1 2.675-7.235c-2.636 2.098-3.904 5.353-3.666 9.591z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v28h22V9.699zM26 29H6V3h12v8h8zm-7-19V3l7 7zm-4 16h-4.5A1.502 1.502 0 0 1 9 24.5v-9a1.502 1.502 0 0 1 1.5-1.5h8.432a11.767 11.767 0 0 0-.786 1H10.5a.501.501 0 0 0-.5.5v9a.501.501 0 0 0 .5.5h4.522A23.46 23.46 0 0 0 15 26zm3.873-5.558A21.033 21.033 0 0 1 21.7 15.3a10.67 10.67 0 0 0-3.764 5.273A17.33 17.33 0 0 0 17 28h-.917c-.823-9.408 4.162-15 6.1-15 1.594 0 2.63 2.257-.672 7.456A13.616 13.616 0 0 0 19.11 21.6a8.167 8.167 0 0 1 2.075-.643c-.817 1.239-1.523 2.105-1.523 2.105a3.643 3.643 0 0 0-2.073 1.936 26.142 26.142 0 0 1 1.284-4.556z"
  }));
};

var _default = FileSqliteIcon;
exports["default"] = _default;