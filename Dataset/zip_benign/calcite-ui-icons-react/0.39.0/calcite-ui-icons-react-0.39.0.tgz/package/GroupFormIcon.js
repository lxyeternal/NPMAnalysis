"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GroupFormIcon = function GroupFormIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 1h2v2h-1V2h-1zM0 15h2v-1H1v-1H0zm15-1h-1v1h2v-2h-1zM0 3h1V2h1V1H0zm4-1h3V1H4zM0 7h1V5H0zm0 4h1V9H0zm15-4h1V5h-1zm0 4h1V9h-1zM9 2h3V1H9zM7 14H4v1h3zm5 0H9v1h3zM4 4h8a1.001 1.001 0 0 1 1 1v1a1.001 1.001 0 0 1-1 1H4a1.001 1.001 0 0 1-1-1V5a1.001 1.001 0 0 1 1-1zm8.001 2H12V5H4v1h8m0 6H4a1.001 1.001 0 0 1-1-1v-1a1.001 1.001 0 0 1 1-1h8a1.001 1.001 0 0 1 1 1v1a1.001 1.001 0 0 1-1 1zm.001-1H12v-1H4v1h8"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 20h1v1H1v-2h1zm20 0h-1v1h2v-2h-1zM1 5h1V4h1V3H1zm1 2H1v2h1zm0 4H1v2h1zm20-2h1V7h-1zm0 4h1v-2h-1zM2 15H1v2h1zm20 2h1v-2h-1zM5 4h2V3H5zm6 0V3H9v1zm2 0h2V3h-2zm6-1h-2v1h2zM5 21h2v-1H5zm4 0h2v-1H9zm4 0h2v-1h-2zm4 0h2v-1h-2zm4-17h1v1h1V3h-2zm-1 4v2a1.001 1.001 0 0 1-1 1H5a1.001 1.001 0 0 1-1-1V8a1.001 1.001 0 0 1 1-1h14a1.001 1.001 0 0 1 1 1zm-.999 2H19V8H5v2h14m1 4v2a1.001 1.001 0 0 1-1 1H5a1.001 1.001 0 0 1-1-1v-2a1.001 1.001 0 0 1 1-1h14a1.001 1.001 0 0 1 1 1zm-.999 2H19v-2H5v2h14"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28 5h2v2h-1V6h-1zM3 9H2v2h1zm0 4H2v2h1zm26-2h1V9h-1zm0 4h1v-2h-1zM3 17H2v2h1zm26 2h1v-2h-1zM3 21H2v2h1zm26 2h1v-2h-1zM7 5H5v1h2zm4 0H9v1h2zm4 0h-2v1h2zm4 0h-2v1h2zm4 0h-2v1h2zm2 1h2V5h-2zM3 25H2v2h2v-1H3zm26 1h-1v1h2v-2h-1zM2 7h1V6h1V5H2zm5.5 3h17a1.502 1.502 0 0 1 1.5 1.5v2a1.502 1.502 0 0 1-1.5 1.5h-17A1.502 1.502 0 0 1 6 13.5v-2A1.502 1.502 0 0 1 7.5 10zM7 13.5a.5.5 0 0 0 .5.5h17a.5.5 0 0 0 .5-.5v-2a.5.5 0 0 0-.5-.5h-17a.5.5 0 0 0-.5.5zM24.5 22h-17A1.502 1.502 0 0 1 6 20.5v-2A1.502 1.502 0 0 1 7.5 17h17a1.502 1.502 0 0 1 1.5 1.5v2a1.502 1.502 0 0 1-1.5 1.5zm.5-3.5a.5.5 0 0 0-.5-.5h-17a.5.5 0 0 0-.5.5v2a.5.5 0 0 0 .5.5h17a.5.5 0 0 0 .5-.5zM5 27h2v-1H5zm4 0h2v-1H9zm6-1h-2v1h2zm2 0v1h2v-1zm6 0h-2v1h2zm2 1h2v-1h-2z"
  }));
};

var _default = GroupFormIcon;
exports["default"] = _default;