"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AnnotateToolIcon = function AnnotateToolIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.5 2.5a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm-5.72 7.67l.17-.17H1V8.089l1.67-1.782a1.253 1.253 0 0 0 .23.022 1.28 1.28 0 0 0 .93-.405l1.533-1.636 1.501 1.334a1.207 1.207 0 0 0 1.204.26L9.67 4.28l-.198-.19a.27.27 0 0 0-.37-.029l-1.224.824a.269.269 0 0 1-.35-.01L5.498 3.07a.27.27 0 0 0-.382.018L3.1 5.24a.27.27 0 0 1-.4 0 .27.27 0 0 0-.4 0L1 6.627V1h11v.98a2.416 2.416 0 0 1 1-.509V0H0v11h3.308l.154-.36a1.495 1.495 0 0 1 .319-.47zm11.912-5.548a.965.965 0 0 1 .03 1.385L14.277 7.45h-.002L7.67 14.057l-4.096 1.756a.371.371 0 0 1-.488-.487l1.756-4.097 8.052-8.052a.965.965 0 0 1 1.385.03zm-9.774 9.1l-.74-.74-.554 1.294zm7.052-6.378l-1.414-1.415-6.007 6.008 1.413 1.415zm1.888-2.015a.307.307 0 0 0-.09-.216l-.98-.981a.306.306 0 0 0-.434 0l-1.09 1.09 1.414 1.414 1.09-1.09a.307.307 0 0 0 .09-.217z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.52 15H1V1h16v4.52l-1 1V2H2v7.2l1.4-1.4a.377.377 0 0 1 .533 0 .377.377 0 0 0 .534 0l2.69-2.69a.377.377 0 0 1 .508-.023l2.706 2.256a.377.377 0 0 0 .468.012l1.633-1.225a.377.377 0 0 1 .493.035L14.66 7.86l-.707.707-1.313-1.313-1.2.9a1.375 1.375 0 0 1-1.71-.044L7.461 6.22 5.173 8.509a1.37 1.37 0 0 1-.973.402 1.387 1.387 0 0 1-.429-.068L2 10.614V14h6.52zM10.5 3.479v.043a.981.981 0 0 0 .979.978h.043a.979.979 0 0 0 .978-.979A1.021 1.021 0 0 0 11.479 2.5a.979.979 0 0 0-.979.979zM21.536 4.52a.965.965 0 0 0-1.385-.03L6.998 17.644 5.242 21.74a.371.371 0 0 0 .488.487l4.096-1.756L22.979 7.32a.965.965 0 0 0-.03-1.385zM6.78 20.688l.962-2.24 1.28 1.28zm3.015-1.6l-1.413-1.414L18.679 7.376l1.414 1.414zM21.952 6.932L20.8 8.083l-1.414-1.414L20.555 5.5a.42.42 0 0 1 .599.007l.804.838a.42.42 0 0 1-.006.587z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13.582 20H2V2h22v7.582l-1 1V3H3v10.855l2.804-2.693a.481.481 0 0 1 .539-.088l.62.293 4.229-3.576a.49.49 0 0 1 .643.01s2.679 2.367 3.53 3.098l2.193-2.06a.49.49 0 0 1 .695.025l3.355 3.11-.679.679-3.062-2.733-1.817 1.708a1 1 0 0 1-1.336.03 552.225 552.225 0 0 1-3.216-2.816l-3.89 3.289a1 1 0 0 1-1.072.14l-.297-.14L3 15.24V19h11.582zM16.5 4A1.5 1.5 0 1 1 15 5.5 1.502 1.502 0 0 1 16.5 4zm.5 1a.707.707 0 1 0 0 1 .708.708 0 0 0 0-1zm12.59 3.584a1.203 1.203 0 0 0-1.727-.037L11.962 24.45l-2.343 5.465a.306.306 0 0 0 .403.402l5.465-2.342 14.1-14.102v-.002l1.802-1.797a1.203 1.203 0 0 0-.037-1.727zm-18.368 20.13l1.402-3.274 1.871 1.87zm4.1-1.99l-2.111-2.111L26.504 11.32l2.111 2.111zm15.36-15.359l-1.36 1.36-2.11-2.112 1.358-1.359a.163.163 0 0 1 .121-.054.285.285 0 0 1 .193.092l1.76 1.761c.018.018.171.18.038.312z"
  }));
};

var _default = AnnotateToolIcon;
exports["default"] = _default;