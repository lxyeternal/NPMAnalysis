"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EraseIcon = function EraseIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.037 14.625a.705.705 0 0 0 .778.162l6.738-2.773c.941-.383.173-2.43-.285-3.63l-.22-.576-7.2-6.473a.723.723 0 0 0-.489-.191.631.631 0 0 0-.213.034L.026 3.213 0 3.94a10.405 10.405 0 0 0 .889 3.207.678.678 0 0 0 .154.247zm.58-.838L1.805 6.743l-.125-.33a17.066 17.066 0 0 1-.53-1.556l5.454 5.454a2.191 2.191 0 0 0 2.318.502l5.425-2.034a7.782 7.782 0 0 1 .659 2.378zM7.29 2.177l6.42 5.773-5.14 1.927a1.19 1.19 0 0 1-1.259-.273l-5.78-5.781z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.577 11.732L11.812 2.279A1.095 1.095 0 0 0 11.08 2a.964.964 0 0 0-.318.05L.115 5.02.076 6.082c-.05 1.38.882 3.505 1.33 4.683a.986.986 0 0 0 .23.36l10.458 10.56a1.07 1.07 0 0 0 .759.315 1.089 1.089 0 0 0 .403-.078l10.075-4.05c1.408-.559.259-3.548-.426-5.3zM11.03 3.012l.121.018 10.091 8.861-7.997 3a2.045 2.045 0 0 1-2.155-.468L2.157 5.489zm11.91 13.952l-10.057 4.03-.03.006a.067.067 0 0 1-.048-.02L2.347 10.422l-.225-.571a12.076 12.076 0 0 1-1.047-3.733l.01-.286 9.298 9.298a3.041 3.041 0 0 0 3.213.696l8.292-3.11.086.22c1.117 2.859 1.141 3.768.965 4.028z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.102 16.113L15.749 3.388a1.453 1.453 0 0 0-.975-.376 1.275 1.275 0 0 0-.425.067l-14.197 4-.05 1.429c-.067 1.858 1.175 4.718 1.771 6.304a1.33 1.33 0 0 0 .308.486l13.944 14.215a1.42 1.42 0 0 0 1.012.424 1.44 1.44 0 0 0 .538-.105l13.433-5.452c1.877-.752.345-4.776-.568-7.136zM14.62 4.041l.153-.03a.458.458 0 0 1 .304.118l13.423 11.9-11.182 4.193a2.885 2.885 0 0 1-3.049-.661L2.239 7.53zm16.116 19.41L17.3 28.905a.425.425 0 0 1-.162.033.419.419 0 0 1-.3-.126L2.895 14.597a.352.352 0 0 1-.081-.125l-.293-.763c-.585-1.504-1.47-3.776-1.42-5.166l.025-.7 12.436 12.424a3.882 3.882 0 0 0 4.107.89l11.626-4.36.312.806c1.836 4.746 1.497 5.7 1.13 5.847z"
  }));
};

var _default = EraseIcon;
exports["default"] = _default;