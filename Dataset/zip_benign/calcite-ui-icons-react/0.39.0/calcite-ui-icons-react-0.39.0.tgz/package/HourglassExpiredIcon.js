"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HourglassExpiredIcon = function HourglassExpiredIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 16h11v-1h-1.396A2.272 2.272 0 0 0 13 13.716V13c.05-1.586-1.446-3.055-2.594-4.094-.128-.115-.298-.239-.298-.406s.17-.29.298-.406C11.554 7.055 13.049 5.586 13 4v-.716A2.272 2.272 0 0 0 12.604 2H14V1H3v1h1.396A2.272 2.272 0 0 0 4 3.284V4c-.05 1.586 1.446 3.055 2.594 4.094.128.115.298.239.298.406s-.17.29-.298.406C5.446 9.945 3.951 11.414 4 13v.716A2.272 2.272 0 0 0 4.396 15H3zm2-2.283V13c-.04-1.267 1.518-2.676 2.265-3.353A1.52 1.52 0 0 0 7.892 8.5a1.477 1.477 0 0 0-.59-1.115C6.518 6.675 4.96 5.267 5 4.03v-.748A1.284 1.284 0 0 1 6.284 2h4.432A1.284 1.284 0 0 1 12 3.283V4c.04 1.267-1.518 2.676-2.265 3.353A1.52 1.52 0 0 0 9.108 8.5a1.477 1.477 0 0 0 .59 1.115c.784.71 2.341 2.118 2.302 3.354v.748A1.284 1.284 0 0 1 10.716 15H6.284A1.284 1.284 0 0 1 5 13.717zm5.716.283H6.284A.284.284 0 0 1 6 13.717V13c-.025-.835 1.451-2.172 1.936-2.611l.022-.02a.822.822 0 0 1 1.082 0c.48.434 1.978 1.788 1.96 2.563v.784a.284.284 0 0 1-.284.284z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.085 2H5v1h1.5A5.666 5.666 0 0 0 6 5.319c0 2.15 1.479 4.294 3.545 6.092a1.544 1.544 0 0 1 .62 1.089 1.544 1.544 0 0 1-.62 1.089C7.479 15.387 6 17.53 6 19.68A5.666 5.666 0 0 0 6.5 22H5v1h15v-1h-1.516A5.595 5.595 0 0 0 19 19.681c0-2.15-1.479-4.294-3.545-6.092a1.544 1.544 0 0 1-.62-1.089 1.544 1.544 0 0 1 .62-1.089C17.521 9.613 19 7.47 19 5.32A5.594 5.594 0 0 0 18.484 3H20V2zm10.292 1A4.646 4.646 0 0 1 18 5.32c0 1.645-1.137 3.54-3.201 5.337a2.432 2.432 0 0 0-.965 1.843 2.435 2.435 0 0 0 .965 1.844c2.064 1.796 3.2 3.691 3.2 5.337A4.646 4.646 0 0 1 17.378 22H7.624A4.68 4.68 0 0 1 7 19.68c0-1.645 1.137-3.54 3.201-5.337a2.432 2.432 0 0 0 .965-1.843 2.435 2.435 0 0 0-.965-1.844C8.137 8.86 7 6.965 7 5.32A4.68 4.68 0 0 1 7.623 3zM8.102 18.925a3.246 3.246 0 0 1 1.35-1.9l2.593-1.722a.823.823 0 0 1 .91 0l2.594 1.722a3.248 3.248 0 0 1 1.35 1.901 3.051 3.051 0 0 1 .1.755A3.645 3.645 0 0 1 16.75 21h-8.5A3.713 3.713 0 0 1 8 19.68a3.05 3.05 0 0 1 .102-.755z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9.898 3H7v1h2.44A6.773 6.773 0 0 0 9 6.375c0 2.493 1.765 5.35 3.845 7.283A3.22 3.22 0 0 1 13.952 16a3.22 3.22 0 0 1-1.107 2.342C10.765 20.274 9 23.132 9 25.625A6.773 6.773 0 0 0 9.44 28H7v1h19v-1h-2.44a6.773 6.773 0 0 0 .44-2.375c0-2.493-1.765-5.35-3.845-7.283A3.22 3.22 0 0 1 19.048 16a3.22 3.22 0 0 1 1.107-2.342C22.235 11.726 24 8.868 24 6.375A6.773 6.773 0 0 0 23.56 4H26V3zm12.593 1A5.798 5.798 0 0 1 23 6.375c0 1.959-1.417 4.59-3.526 6.55A4.206 4.206 0 0 0 18.048 16a4.206 4.206 0 0 0 1.426 3.074C21.583 21.034 23 23.666 23 25.625A5.798 5.798 0 0 1 22.491 28H10.51a5.798 5.798 0 0 1-.51-2.375c0-1.959 1.417-4.59 3.526-6.55A4.206 4.206 0 0 0 14.952 16a4.206 4.206 0 0 0-1.426-3.074C11.417 10.966 10 8.334 10 6.375A5.798 5.798 0 0 1 10.509 4zm-11.4 20.774a5.07 5.07 0 0 1 1.898-3.03l2.843-2.164a1.102 1.102 0 0 1 1.336 0l2.843 2.165a5.064 5.064 0 0 1 1.898 3.03 4.32 4.32 0 0 1 .091.85A4.83 4.83 0 0 1 21.798 27H11.202A4.83 4.83 0 0 1 11 25.625a4.322 4.322 0 0 1 .092-.85z"
  }));
};

var _default = HourglassExpiredIcon;
exports["default"] = _default;