"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CheckShieldIcon = function CheckShieldIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.5 15.992l.41-.223c5.995-3.27 6.385-8.315 5.976-12.818l-.067-.74-.743-.037C11.775 2.059 10.14 1.528 9.08.553L8.5.02l-.58.532c-1.06.975-2.695 1.506-4.997 1.62l-.742.038-.067.74c-.409 4.503-.019 9.547 5.976 12.818zM3.1 3.165a8.712 8.712 0 0 0 5.4-1.788 8.72 8.72 0 0 0 5.4 1.789c.36 4.13-.033 8.723-5.4 11.688-5.367-2.966-5.76-7.558-5.4-11.689zM12 5.738l-4.443 4.43-2.322-2.322.738-.738 1.584 1.588L11.262 5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.76 3.854l-.87-.042c-3.31-.166-5.67-.934-7.21-2.35L12 .838l-.68.624c-1.54 1.416-3.9 2.184-7.209 2.35l-.87.042-.08.87c-.574 6.312-.029 13.382 8.358 17.957l.481.262.48-.262c8.388-4.575 8.933-11.645 8.36-17.958zm-8.762 17.95c-7.879-4.3-8.381-11.005-7.837-16.993 3.552-.178 6.122-1.033 7.842-2.613 1.72 1.58 4.287 2.438 7.84 2.615.544 5.99.034 12.692-7.845 16.99zm5.524-13.946l.637.636L10.5 16 7 12.689l.637-.636 2.863 2.674z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.5 30.302l-.556-.31C5.169 23.98 4.47 14.685 5.208 6.385l.09-1.009.999-.052c5.328-.273 7.795-1.623 9.86-3.564l.343-.323.342.323c2.066 1.941 4.533 3.29 9.86 3.564l1 .052.09 1.009c.738 8.3.039 17.595-10.736 23.607zm-.069-1.183l.069.038.07-.038c10.275-5.733 10.935-14.665 10.226-22.646l-.012-.144-.133-.007c-5.346-.274-7.993-1.596-10.151-3.52-2.159 1.924-4.806 3.247-10.152 3.52l-.132.007-.012.144c-.71 7.981-.049 16.913 10.227 22.646zm7.673-18.515l-.707-.707-8.897 8.896-2.896-2.896-.707.707 3.603 3.603z"
  }));
};

var _default = CheckShieldIcon;
exports["default"] = _default;