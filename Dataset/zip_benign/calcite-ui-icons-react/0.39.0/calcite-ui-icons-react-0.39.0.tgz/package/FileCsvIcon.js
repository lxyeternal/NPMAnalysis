"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileCsvIcon = function FileCsvIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v7h1V1h7v4h4v10H3v-1H2v2h13V3.6zM14 4h-3V1h.31L14 3.69zm-4.007 9L8.42 8h1.048l1.044 3.317L11.57 8h1.05l-1.596 5zM3 13H0V8h3v1H1v3h2zm4 0H4v-1h2v-1H4V8h3v1H5v1h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v11h1V2h10v6h6v14H4v-3H3v4h18V6.709zM20 7h-5V2h.2L20 6.8zm-4.96 11l2.126-5H16.08l-1.568 3.688L12.966 13h-1.084l2.095 5zM7 14.349v.302A1.35 1.35 0 0 0 8.349 16H9.65a.349.349 0 0 1 .349.349v.302A.349.349 0 0 1 9.65 17H7v1h2.651A1.35 1.35 0 0 0 11 16.651v-.302A1.35 1.35 0 0 0 9.651 15H8.35a.349.349 0 0 1-.35-.349v-.302A.349.349 0 0 1 8.349 14H11v-1H8.349A1.35 1.35 0 0 0 7 14.349zm-5 .692v.918A2.044 2.044 0 0 0 4.041 18H6v-1H4.041A1.042 1.042 0 0 1 3 15.959v-.918A1.042 1.042 0 0 1 4.041 14H6v-1H4.041A2.044 2.044 0 0 0 2 15.041z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v14h1V3h12v8h8v18H6v-3H5v4h22V9.699zm-.3 8V3l7 7zM4.85 23.269a3.179 3.179 0 1 1 4.496-4.496l-.707.707a2.179 2.179 0 1 0-3.081 3.081 2.229 2.229 0 0 0 3.08 0l.708.707a3.177 3.177 0 0 1-4.495 0zM21.383 18l-2.412 5.986-.929-.002L15.666 18h1.076l1.768 4.453L20.304 18zM10.66 22.86l.863-.505a1.34 1.34 0 0 0 1.283.745 1.165 1.165 0 0 0 1.16-.64.836.836 0 0 0-.04-.683 1.332 1.332 0 0 0-.946-.477c-1.289-.198-1.953-.784-1.974-1.743a1.66 1.66 0 0 1 .48-1.2 1.812 1.812 0 0 1 1.3-.557 2.11 2.11 0 0 1 1.902 1.102l-.851.526a1.123 1.123 0 0 0-1.05-.628.8.8 0 0 0-.58.249.667.667 0 0 0-.201.476c.004.206.014.616 1.126.786a2.19 2.19 0 0 1 1.652.952 1.828 1.828 0 0 1 .126 1.53 2.134 2.134 0 0 1-2.104 1.307 2.318 2.318 0 0 1-2.146-1.24z"
  }));
};

var _default = FileCsvIcon;
exports["default"] = _default;