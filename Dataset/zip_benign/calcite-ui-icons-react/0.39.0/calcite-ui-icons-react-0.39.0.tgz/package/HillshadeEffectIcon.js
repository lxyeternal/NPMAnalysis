"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HillshadeEffectIcon = function HillshadeEffectIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 1v14h14V1zm7.934 5.359L3.021 2h10.272zm-.7.7L2 13.293V2.487zm.707.707L13.513 14H2.707zm.716-.716L14 2.707v10.265z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.934 6.359L3.021 2h10.272L8.934 6.359z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.941 7.766L13.513 14H2.707l6.234-6.234z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.657 7.05L14 2.707v10.265L9.657 7.05z",
      opacity: ".75"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2v20h20V2zm10.957 8.336L3.91 3h16.383zm-.703.703L3 20.293V3.548zm.707.707L20.452 21H3.707zm.71-.71L21 3.706v16.38z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.957 10.336L3.91 3h16.383l-7.336 7.336z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.961 11.746L20.452 21H3.707l9.254-9.254z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.672 11.035L21 3.707v16.381l-7.328-9.053z",
      opacity: ".75"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17.676 15.031L28 27.142V4.707L17.676 15.031z",
    opacity: ".75"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.293 4H4.858l12.115 10.32L27.293 4z",
    opacity: ".25"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.97 15.737L4.707 28h22.71L16.97 15.737z",
    opacity: ".5"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 3v26h26V3zm24.293 1l-10.32 10.32L4.858 4zM16.268 15.025L4 27.293V4.583zm.702.712L27.417 28H4.707zm.706-.706L28 4.707v22.435z"
  }));
};

var _default = HillshadeEffectIcon;
exports["default"] = _default;