"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerHideIcon = function LayerHideIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 13.728v1.008a11.217 11.217 0 0 1-1.207.064A9.158 9.158 0 0 1 0 14.089l2.133-12.6A10.39 10.39 0 0 0 5.294 2c2.688 0 2.721-.986 5.412-.986a8.205 8.205 0 0 1 3.161.674L14.597 6h-1.014l-.607-3.587a7.213 7.213 0 0 0-2.27-.399 5.895 5.895 0 0 0-2.367.434A7.834 7.834 0 0 1 5.294 3a11.376 11.376 0 0 1-2.359-.26l-1.81 10.697a9.537 9.537 0 0 0 2.668.363A10.044 10.044 0 0 0 5 13.728zm-.06-2.195l.06-.077.154-.199c.095-.123 2.365-3.01 5.346-3.01a5.287 5.287 0 0 1 2.115.468l.895-.894.707.707-6.69 6.689-.706-.707.646-.647a9.67 9.67 0 0 1-2.313-2.054L5 11.61zm1.001 0a9.42 9.42 0 0 0 2.115 1.741l1.115-1.115a1.323 1.323 0 0 1-.163-.626 1.458 1.458 0 0 1 1.5-1.408 1.575 1.575 0 0 1 .586.112L12 9.33a4.323 4.323 0 0 0-1.5-.285c-2.1 0-3.914 1.774-4.559 2.488zm8.46-1.716l-.57.568a10.103 10.103 0 0 1 1.244 1.15c-.649.715-2.467 2.487-4.576 2.487-.093 0-.183-.021-.276-.028l-.717.717a4.822 4.822 0 0 0 .994.109c2.981 0 5.266-2.887 5.362-3.01l.138-.177v-.2l-.138-.177a9.73 9.73 0 0 0-1.461-1.44z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.36 20.682a3.67 3.67 0 0 0-.412.833 20.859 20.859 0 0 1-3.524.285A13.093 13.093 0 0 1 0 20.783L3.05 3.078a15.028 15.028 0 0 0 4.52.722c3.849 0 3.893-1.6 7.74-1.6a12.674 12.674 0 0 1 4.52.878l1.112 6.597a1.81 1.81 0 0 0-.997.103l-1.004-5.963a11.86 11.86 0 0 0-3.63-.615 7.791 7.791 0 0 0-3.49.725 9.805 9.805 0 0 1-4.25.875 16.193 16.193 0 0 1-3.723-.457L1.124 20.15a13.726 13.726 0 0 0 4.3.65 19.734 19.734 0 0 0 3.702-.331c.079.07.157.142.234.213zm11.891-5.91l-.638.638a13.675 13.675 0 0 1 2.316 2.09c-.812.93-3.414 3.6-6.47 3.6a5.716 5.716 0 0 1-1.36-.176l-.73.73a6.824 6.824 0 0 0 2.09.346c4.064 0 7.205-4.024 7.337-4.195l.234-.305-.234-.305a13.674 13.674 0 0 0-2.545-2.423zM18.8 17.5a2.395 2.395 0 0 0-.055-.506l-2.85 2.85A2.392 2.392 0 0 0 18.8 17.5zm-7.446 4.854l-.707-.707 1.234-1.234a14.208 14.208 0 0 1-2.871-2.601l-.25-.312.25-.312c.137-.17 3.389-4.188 7.45-4.188a6.857 6.857 0 0 1 2.381.453l1.806-1.807.707.707-1.53 1.531.003.002-.668.668-.003-.002-1.165 1.165.003.002-3.375 3.374-.002-.002-1.195 1.195.003.002-.663.663-.003-.002zm1.173-2.587l1.584-1.584A2.367 2.367 0 0 1 14 17.5a2.403 2.403 0 0 1 2.4-2.4 2.367 2.367 0 0 1 .682.11l1.053-1.052a5.8 5.8 0 0 0-1.675-.258c-3.046 0-5.73 2.663-6.58 3.6a14.104 14.104 0 0 0 2.646 2.267z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11.378 29.086a1.995 1.995 0 0 0-.401.589 22.861 22.861 0 0 1-2.44.125A16.273 16.273 0 0 1 1 28L5 3.9a14.99 14.99 0 0 0 5.34.968c4.807 0 5.59-1.657 10.734-1.657A26.401 26.401 0 0 1 27 3.9L28.676 14h-.288a1.992 1.992 0 0 0-.757-.192l-1.507-9.079a26.266 26.266 0 0 0-5.05-.518 16.633 16.633 0 0 0-5.29.81 17.433 17.433 0 0 1-5.445.847 15.6 15.6 0 0 1-4.544-.65L2.108 27.433a15.986 15.986 0 0 0 6.43 1.366 20.348 20.348 0 0 0 3.39-.264zM31 28l-.193-1.163c-.3.291-.627.596-.998.914C30.572 27.89 31 28 31 28zm-7.1-4.5v-.076a3.39 3.39 0 0 0-.056-.626l-4.02 4.02A3.337 3.337 0 0 0 23.9 23.5zm3.175-3.933l-.637.637a18.552 18.552 0 0 1 3.593 3.284l-.005.006.005.006c-.992 1.202-4.94 5.29-9.493 5.345h-.014a8.603 8.603 0 0 1-2.352-.376l-.717.718a9.656 9.656 0 0 0 3.065.559h.022c5.663-.063 10.171-5.695 10.358-5.947l.224-.299-.22-.301a19.49 19.49 0 0 0-3.829-3.632zM13.5 31.207l-.707-.707 2.382-2.382a19.46 19.46 0 0 1-5.014-4.32l-.224-.298.22-.301c.186-.254 4.634-5.933 10.296-6.056h.155a10.341 10.341 0 0 1 4.376 1.165l2.516-2.515.707.707-.146.146zm2.324-3.738l1.987-1.987a3.371 3.371 0 0 1-.65-1.982v-.076a3.404 3.404 0 0 1 3.335-3.435h.07a3.367 3.367 0 0 1 2.013.725l1.736-1.736a9.382 9.382 0 0 0-3.72-.934h-.128c-4.552.102-8.457 4.233-9.436 5.445l.005.005-.005.006a18.193 18.193 0 0 0 4.793 3.97z"
  }));
};

var _default = LayerHideIcon;
exports["default"] = _default;