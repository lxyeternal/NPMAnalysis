"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileDataIcon = function FileDataIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v16h13V3.6zM14 15H3V1h7v4h4zm0-11h-3V1h.31L14 3.69zM7.6 7.047a6.943 6.943 0 0 0-.903.156 3.985 3.985 0 0 0-.91.333A1.218 1.218 0 0 0 5 8.596v3.714C5 13.419 6.76 14 8.5 14s3.5-.581 3.5-1.69V8.596a1.218 1.218 0 0 0-.787-1.06 3.976 3.976 0 0 0-.911-.333 6.886 6.886 0 0 0-.903-.156 8.939 8.939 0 0 0-1.8 0zM8.5 13c-1.558 0-2.458-.485-2.5-.69V9.748a4.229 4.229 0 0 0 .696.24 6.757 6.757 0 0 0 .905.156 8.541 8.541 0 0 0 .899.046 8.574 8.574 0 0 0 .9-.046 6.725 6.725 0 0 0 .903-.157A4.22 4.22 0 0 0 11 9.748v2.559c-.042.208-.942.693-2.5.693zm2.242-4.581a.8.8 0 0 1 .243.177.821.821 0 0 1-.243.176 3.025 3.025 0 0 1-.68.245 5.612 5.612 0 0 1-.768.132 7.978 7.978 0 0 1-1.587 0 5.643 5.643 0 0 1-.77-.132 3.033 3.033 0 0 1-.68-.246 2.209 2.209 0 0 1-.251-.165.738.738 0 0 1 .252-.187 3.042 3.042 0 0 1 .679-.245 5.798 5.798 0 0 1 .769-.133 7.978 7.978 0 0 1 1.587 0 5.743 5.743 0 0 1 .77.133 3.033 3.033 0 0 1 .68.245z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v22h18V6.709zM20 22H4V2h10v6h6zm0-15h-5V2h.2L20 6.8zm-9.3 3.06a11.054 11.054 0 0 0-1.298.202 6.349 6.349 0 0 0-1.296.422C7.191 11.118 7 11.639 7 12v5.53c0 1.5 2.516 2.286 5 2.286s5-.786 5-2.287V12c0-.361-.191-.882-1.107-1.316a6.31 6.31 0 0 0-1.296-.422 11.005 11.005 0 0 0-1.297-.201 14.445 14.445 0 0 0-2.6 0zm1.3 8.756c-2.404 0-4-.775-4-1.287v-4.27c.037.019.068.039.107.057a6.31 6.31 0 0 0 1.296.422 11.005 11.005 0 0 0 1.297.201 13.834 13.834 0 0 0 2.6 0 11.054 11.054 0 0 0 1.298-.2 6.349 6.349 0 0 0 1.296-.423c.039-.018.07-.038.106-.057v4.27c0 .512-1.596 1.287-4 1.287zm3.466-7.228c.44.208.534.38.534.412s-.095.204-.533.412a5.312 5.312 0 0 1-1.085.35 9.87 9.87 0 0 1-1.178.181 13.05 13.05 0 0 1-2.408 0 9.821 9.821 0 0 1-1.177-.181 5.272 5.272 0 0 1-1.085-.35C8.094 12.204 8 12.032 8 12s.095-.204.533-.412a5.312 5.312 0 0 1 1.085-.35 9.87 9.87 0 0 1 1.178-.181 12.528 12.528 0 0 1 2.408 0 9.821 9.821 0 0 1 1.177.181 5.272 5.272 0 0 1 1.085.35z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14.123 13.295a14.639 14.639 0 0 0-1.866.31 8.316 8.316 0 0 0-1.833.642C9.247 14.85 9 15.533 9 16v7.8c0 1.948 3.606 3 7 3s7-1.052 7-3V16c0-.467-.247-1.15-1.424-1.753a8.308 8.308 0 0 0-1.834-.643 14.581 14.581 0 0 0-1.866-.31 18.826 18.826 0 0 0-3.753 0zM16 25.8c-3.718 0-6-1.165-6-2v-6.294a4.437 4.437 0 0 0 .424.247 8.308 8.308 0 0 0 1.834.643 14.581 14.581 0 0 0 1.866.31A18.445 18.445 0 0 0 16 18.8a18.478 18.478 0 0 0 1.877-.095 14.639 14.639 0 0 0 1.866-.31 8.316 8.316 0 0 0 1.833-.642 4.437 4.437 0 0 0 .424-.247V23.8c0 .835-2.282 2-6 2zm5.121-10.662c.55.281.879.604.879.862s-.33.581-.879.862a7.342 7.342 0 0 1-1.61.56 13.655 13.655 0 0 1-1.737.289 17.947 17.947 0 0 1-3.547 0 13.597 13.597 0 0 1-1.738-.288 7.333 7.333 0 0 1-1.61-.56C10.329 16.58 10 16.257 10 16s.33-.581.879-.862a7.342 7.342 0 0 1 1.61-.56 13.655 13.655 0 0 1 1.737-.289 17.751 17.751 0 0 1 3.547 0 13.597 13.597 0 0 1 1.738.288 7.333 7.333 0 0 1 1.61.56zM19.3 2H5v28h22V9.699zM26 29H6V3h12v8h8zm-7-19V3l7 7z"
  }));
};

var _default = FileDataIcon;
exports["default"] = _default;