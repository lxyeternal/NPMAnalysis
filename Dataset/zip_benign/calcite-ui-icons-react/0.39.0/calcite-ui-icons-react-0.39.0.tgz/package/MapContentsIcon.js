"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MapContentsIcon = function MapContentsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.272 12l-.318 1H4V9h5.636L9 11h7l-1.273-4h-4.455l-.318 1H4V6h3l-.318-1H.318L0 6h3v8h6.636L9 16h7l-1.273-4zm.732-4h2.992l.637 2h-4.266zm-.637 7l.637-2h2.992l.637 2zM5.727 0H1.272L0 4h7zm-4.36 3l.637-2h2.992l.637 2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 7L8.364 1H2.636L1 7zM7.6 2l1.09 4H2.31L3.4 2zm8.036 15l-.818 3H6v-7h8.545L14 15h9l-1.636-6h-5.728l-.818 3H6V9h4l-.273-1H1.273L1 9h4v12h9.545L14 23h9l-1.636-6zm.764-7h4.2l1.09 4h-6.38zm-1.09 12l1.09-4h4.2l1.09 4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 2H5L3 9h11zM5.754 3h5.492l1.428 5H4.326zm14.44 20l-.858 3H9v-9h10.05l-.857 3h11l-2-7h-7l-.857 3H9v-5h5l-.571-1H3.57L3 11h5v16h11.05l-.857 3h11l-2-7zm.753-9h5.492l1.428 5H19.52zM19.52 29l1.427-5h5.492l1.428 5z"
  }));
};

var _default = MapContentsIcon;
exports["default"] = _default;