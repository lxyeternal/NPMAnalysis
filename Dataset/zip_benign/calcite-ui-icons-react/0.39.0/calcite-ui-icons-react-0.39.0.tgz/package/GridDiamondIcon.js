"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GridDiamondIcon = function GridDiamondIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 1v14h14V1zm13 1.707v2.586l-2 2L8.707 4l2-2h2.586zM11.293 8L8 11.293 4.707 8 8 4.707zM8 3.293L6.707 2h2.586zM7.293 4L4 7.293l-2-2V2.707L2.707 2h2.586zm-4 4L2 9.293V6.707zM2 13.293v-2.586l2-2L7.293 12l-2 2H2.707zm6-.586L9.293 14H6.707zM8.707 12L12 8.707l2 2v2.586l-.707.707h-2.586zm4-4L14 6.707v2.586z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2v20h20V2zm10.707 5l4-4h.586L21 6.707v.586l-4 4zm3.586 5L12 16.293 7.707 12 12 7.707zM12 6.293L8.707 3h6.586zM11.293 7L7 11.293l-4-4v-.586L6.707 3h.586zm-5 5L3 15.293V8.707zM3 16.707l4-4L11.293 17l-4 4h-.586L3 17.293zm9 1L15.293 21H8.707zm.707-.707L17 12.707l4 4v.586L17.293 21h-.586zm5-5L21 8.707v6.586zM21 5.293L18.707 3H21zM5.293 3L3 5.293V3zM3 18.707L5.293 21H3zM18.707 21L21 18.707V21z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 3v26h26V3zm13.707 6l5-5h2.586L28 7.707v2.586l-5 5zm5.586 7L16 22.293 9.707 16 16 9.707zM16 8.293L11.707 4h8.586zM15.293 9L9 15.293l-5-5V7.707L7.707 4h2.586zm-7 7L4 20.293v-8.586zM4 21.707l5-5L15.293 23l-5 5H7.707L4 24.293zm12 2L20.293 28h-8.586zm.707-.707L23 16.707l5 5v2.586L24.293 28h-2.586zm7-7L28 11.707v8.586zM28 6.293L25.707 4H28zM6.293 4L4 6.293V4zM4 25.707L6.293 28H4zM25.707 28L28 25.707V28z"
  }));
};

var _default = GridDiamondIcon;
exports["default"] = _default;