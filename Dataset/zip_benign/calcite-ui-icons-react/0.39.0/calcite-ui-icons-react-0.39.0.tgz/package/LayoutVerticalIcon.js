"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayoutVerticalIcon = function LayoutVerticalIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 0H4v4H3v1h1v6H3v1h1v4h8v-4h1v-1h-1V5h1V4h-1zm-1 15H5V1h6zm-5-4h4v1H6zm0-7h4v1H6zm9 6h1v2h-2v-1h1zM1 11h1v1H0v-2h1zm15-7v2h-1V5h-1V4zM2 4v1H1v1H0V4zM1 9H0V7h1zm14-2h1v2h-1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17 1H7v6H5v1h2v8H5v1h2v6h10v-6h2v-1h-2V8h2V7h-2zm-1 21H8V2h8zM15 8H9V7h6zm0 9H9v-1h6zm7-2h1v2h-2v-1h1zM2 16h1v1H1v-2h1zm20-9h1v2h-1V8h-1V7zM2 7h1v1H2v1H1V7zm20 4h1v2h-1zM2 13H1v-2h1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13 20h6v1h-6zm0-8h6v-1h-6zM3 19H2v2h2v-1H3zm26 1h-1v1h2v-2h-1zM2 11v2h1v-1h1v-1zm26 0v1h1v1h1v-2zM8 20H6v1h2zm16 1h2v-1h-2zm-3 0v9H11v-9h-1v-1h1v-8h-1v-1h1V2h10v9h1v1h-1v8h1v1zM20 3h-8v26h8zM8 11H6v1h2zm16 1h2v-1h-2zM3 15H2v2h1zm26 2h1v-2h-1z"
  }));
};

var _default = LayoutVerticalIcon;
exports["default"] = _default;