"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileVideoIcon = function FileVideoIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 9a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-.706L13 13V8l-3 1.706zm-1 3H5V9h4zm2-1.712l1-.57v1.563l-1-.57zM15 3.6L11.4 0H2v16h13zM14 15H3V1h7v4h4zm0-11h-3V1h.31L14 3.69z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.822 12H7.178A1.178 1.178 0 0 0 6 13.178v4.644A1.178 1.178 0 0 0 7.178 19h5.644A1.178 1.178 0 0 0 14 17.822v-4.644A1.178 1.178 0 0 0 12.822 12zM13 17.821a.179.179 0 0 1-.179.179H7.18a.179.179 0 0 1-.18-.179V13.18a.179.179 0 0 1 .179-.18h5.642a.179.179 0 0 1 .179.179zm2-3.499v2.625L17.125 18H18v-5h-.875zm2 2.5l-1-.495v-1.45l1-.621zM3 23h18V6.709L15.29 1H3zM15 2h.2L20 6.8V7h-5zM4 2h10v6h6v14H4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27 9.699L19.3 2H5v28h22zM26 29H6V3h12v8h8zm-7-19V3l7 7zm-9.822 6A1.178 1.178 0 0 0 8 17.178v6.644A1.178 1.178 0 0 0 9.178 25h8.644A1.178 1.178 0 0 0 19 23.822v-6.644A1.178 1.178 0 0 0 17.822 16zM18 17.179v6.642a.179.179 0 0 1-.179.179H9.18a.179.179 0 0 1-.18-.179V17.18a.179.179 0 0 1 .179-.18h8.642a.179.179 0 0 1 .179.179zM24 24v-7h-1l-3 2v3l3 2zm-3-4.465l2-1.333v4.596l-2-1.333z"
  }));
};

var _default = FileVideoIcon;
exports["default"] = _default;