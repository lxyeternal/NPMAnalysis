"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FullScreenIcon = function FullScreenIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 1v14h16V1zm15 13H1V2h14zM9.644 6.65L12.246 4H11V3h3v3h-1V4.66l-2.644 2.69zM12.246 12L9.644 9.35l.712-.7L13 11.34V10h1v3h-3v-1zM3 6H2V3h3v1H3.753l2.603 2.65-.712.7L3 4.66zm2 7H2v-3h1v1.34l2.644-2.69.712.7L3.753 12H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 3v18h22V3zm21 17H2V4h20zM15.644 9.649L19.243 6H17V5h4v4h-1V6.657l-3.644 3.694zM7 19H3v-4h1v2.343l3.645-3.694.71.702L4.755 18H7zm13-4h1v4h-4v-1h2.343l-3.695-3.644.704-.712L20 17.243zM4 9H3V5h4v1H4.657l3.695 3.644-.704.712L4 6.757z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 5v22h28V5zm27 21H3V6h26zm-8.354-12.354L26.3 8H23V7h5v5h-1V8.715l-5.646 5.639zM9 25H4v-5h1v3.285l5.646-5.639.707.708L5.7 24H9zm17.3-1l-5.654-5.646.707-.708L27 23.285V20h1v5h-5v-1zM5 12H4V7h5v1H5.7l5.654 5.646-.707.708L5 8.715z"
  }));
};

var _default = FullScreenIcon;
exports["default"] = _default;