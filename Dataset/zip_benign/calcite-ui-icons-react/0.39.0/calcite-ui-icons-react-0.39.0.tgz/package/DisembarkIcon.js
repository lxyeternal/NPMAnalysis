"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DisembarkIcon = function DisembarkIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.162 3.5l-2.808 2.81-.707-.708L13.248 4H8V3h5.248l-1.602-1.602.707-.707zm-5.91 5.06l1.677.718-2.138 3.725h-.29a4.033 4.033 0 0 0-2.661.928l-.34.315-.34-.315a4.033 4.033 0 0 0-2.661-.928h-.29L.07 9.278l1.68-.718L3.004 5H4V3h1V2h1v1h1v2h.996zM5 5h1V4H5zM2.997 8.026L5.5 6.956l2.503 1.07L7.289 6H3.711zm6.504 1.729L5.5 8.044l-4.002 1.71 1.295 2.257a5.102 5.102 0 0 1 2.707.905 5.102 5.102 0 0 1 2.707-.905zm-3.664 4.84l-.338.213-.336-.214a3.721 3.721 0 0 0-3.935-.314l.544.839a2.665 2.665 0 0 1 2.856.32l.871.553.873-.553a2.711 2.711 0 0 1 2.856-.32l.544-.84a3.717 3.717 0 0 0-3.935.315z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23.201 5.494L20.354 8.34l-.707-.707L21.28 6H15V5h6.293l-1.647-1.646.707-.707zM9.501 22c-1.26-1.135-4.241-3.513-7.065-.85l.687.727a3.18 3.18 0 0 1 1.762-.904 5.442 5.442 0 0 1 .79.002 2.84 2.84 0 0 0-.79-.002c1.512-.211 2.987.883 4.195 1.997l.421.387.418-.385c1.675-1.548 3.867-3.07 5.958-1.095l.687-.726c-2.823-2.665-5.802-.288-7.063.849zm5.315-9.577l2.335 1.027a9.635 9.635 0 0 0-2.6 5.25S12.696 16.522 9.5 20c-3.197-3.478-5.052-1.3-5.052-1.3a9.635 9.635 0 0 0-2.6-5.25l2.335-1.027L5.146 8H6.19l1-3H8V3h3v2h.81l1 3h1.044zM9 5h1V4H9zM7.244 8h4.512l-.666-2H7.91zm-1.928 3.925l4.185-1.84 4.183 1.84L13.047 9H5.953zm10.229 1.91L9.5 11.179l-6.046 2.658a11.273 11.273 0 0 1 1.68 3.324 3.37 3.37 0 0 1 .947-.134A5.198 5.198 0 0 1 9.5 18.592a5.193 5.193 0 0 1 3.417-1.565 3.37 3.37 0 0 1 .947.134 11.273 11.273 0 0 1 1.68-3.324z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.229 27.565l-.41.912c-1.82-.82-4.673-1.173-7.915 1.81l-.344.317-.398-.316c-3.241-2.983-6.092-2.63-7.914-1.811l-.41-.912c2.026-.914 5.152-1.342 8.654 1.671l.048.036c3.518-3.046 6.652-2.624 8.689-1.707zm-1.84-12.962l3.555 1.388-.423.531a16.095 16.095 0 0 0-2.958 7.78l-.072.623-.59-.208a4.19 4.19 0 0 0-1.4-.233 6.934 6.934 0 0 0-4.66 2.19l-.34.314-.34-.315a6.936 6.936 0 0 0-4.662-2.19 4.176 4.176 0 0 0-1.397.234l-.591.208-.073-.622a16.122 16.122 0 0 0-2.96-7.781l-.422-.53 3.557-1.39L8.117 9h1.174l.8-4H12V3h3v2h1.91l.8 4h1.174zM13 5h1V4h-1zm-2.689 4h6.379l-.6-3h-5.18zm-2.542 5.151l5.732-2.237 5.731 2.237L18.116 10H8.885zm14.567 2.286l-8.835-3.45-8.837 3.45a17.26 17.26 0 0 1 2.69 7.17 5.313 5.313 0 0 1 1.145-.123 7.673 7.673 0 0 1 5.002 2.152 7.67 7.67 0 0 1 5.001-2.152 5.313 5.313 0 0 1 1.145.122 17.256 17.256 0 0 1 2.689-7.169zm4.02-13.79l-.708.706L28.294 6H21v1h7.292l-2.646 2.646.707.707L30.207 6.5z"
  }));
};

var _default = DisembarkIcon;
exports["default"] = _default;