"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DeepLearningIcon = function DeepLearningIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.678 5h-1.97L10 2.293V0H7v.898l-4 1.47V2H0v3h1.3l1.94 2.5L1.3 10H0v3h3v-.368l4 1.47V15h3v-2.293L12.707 10h1.97A1.326 1.326 0 0 0 16 8.678V6.322A1.326 1.326 0 0 0 14.678 5zM8 1h1v1H8zm-1 .963v.915L5.543 4.836l-1.71-1.71zM5.579 6.118l1.42 1.177-1.345 1.344-.995-1.336zM1 3h1v1H1zm1.566 2H3V3.707l1.94 1.94-.917 1.23zM2 12H1v-1h1zm.566-2l1.457-1.877.916 1.23L3 11.294V10zm1.268 1.873l1.709-1.709L7 12.122v.915zM9 14H8v-1h1zm.293-2H8.156L6.257 9.45 7 8.707V9h3V8h1v.678a1.3 1.3 0 0 0 .563 1.052zM8 7h1v1H8zm3-.678V7h-1V6H7v.293l-.743-.743L8.156 3h1.137l2.27 2.27A1.3 1.3 0 0 0 11 6.322zm4 1.629A1.05 1.05 0 0 1 13.95 9h-.9A1.05 1.05 0 0 1 12 7.95v-.9A1.05 1.05 0 0 1 13.05 6h.9A1.05 1.05 0 0 1 15 7.05zM13 7h1v1h-1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.5 9a3.49 3.49 0 0 0-3.45 3h-1.1a2.49 2.49 0 0 0-4.396-1.052L8.878 9.731l3.143-4.225a2.458 2.458 0 0 0 2.98-.019L17.339 8H16v1h3V6h-1v1.243l-2.336-2.512A2.473 2.473 0 0 0 16 3.5a2.5 2.5 0 0 0-5 0 2.474 2.474 0 0 0 .343 1.243L7.947 9.308 4.955 7.947a2.404 2.404 0 0 0-.161-1.438l3.704-1.385-.44 1.371.942.333L10 4 7.172 3l-.334.943 1.01.357-3.659 1.368a2.498 2.498 0 1 0-.682 4.117l2.085 2.688-2.053 2.76a2.5 2.5 0 1 0 .87 3.864l3.484 1.587-1.055.373.334.943L10 21l-1-2.828-.943.333.435 1.354-3.608-1.645A2.471 2.471 0 0 0 5 17.5a2.5 2.5 0 0 0-.058-.527l3.053-1.405 3.476 4.48a2.498 2.498 0 1 0 4.113.075L18 17.707V19h1v-3h-3v1h1.293l-2.416 2.416a2.466 2.466 0 0 0-2.667-.047l-3.283-4.23 2.554-1.176A2.494 2.494 0 0 0 15.95 13h1.1a3.493 3.493 0 1 0 3.45-4zm-7-7A1.5 1.5 0 1 1 12 3.5 1.502 1.502 0 0 1 13.5 2zm0 18a1.5 1.5 0 1 1-1.5 1.5 1.502 1.502 0 0 1 1.5-1.5zM1 7.5a1.5 1.5 0 1 1 2.457 1.145l-.144.112A1.496 1.496 0 0 1 1 7.5zm3.32 1.703a2.507 2.507 0 0 0 .264-.326l2.752 1.251-1.124 1.512zM2.5 19A1.5 1.5 0 1 1 4 17.5 1.502 1.502 0 0 1 2.5 19zm2.037-2.941a2.518 2.518 0 0 0-.193-.234l1.885-2.532 1.136 1.464zm3.76-1.731L6.849 12.46l1.42-1.908L11.1 11.84a2.29 2.29 0 0 0-.033 1.213zM13.5 14a1.5 1.5 0 1 1 1.5-1.5 1.502 1.502 0 0 1-1.5 1.5zm7 1a2.5 2.5 0 1 1 2.5-2.5 2.502 2.502 0 0 1-2.5 2.5zm1.5-2.5a1.5 1.5 0 1 1-1.5-1.5 1.502 1.502 0 0 1 1.5 1.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.5 12a4.485 4.485 0 0 0-4.45 4h-2.1a3.474 3.474 0 0 0-6.144-1.71l-2.676-1.294 3.347-4.649a3.441 3.441 0 0 0 3.486.323l3.33 3.33H21v1h3v-3h-1v1.293l-3.186-3.186a3.503 3.503 0 1 0-5.063-.464l-3.535 4.91-4.268-2.064a2.984 2.984 0 0 0-.043-.204l4.576-1.988-.424 1.198.943.333L13 7l-2.828-1-.334.943 1.241.438-4.568 1.985a3.006 3.006 0 1 0-.48 3.83l2.396 3.23-2.418 3.36a2.996 2.996 0 1 0 .517 3.82l4.54 2.017-1.228.434.334.943L13 26l-1-2.828-.943.333.428 1.21-4.57-2.03c.018-.082.029-.166.041-.25l4.268-2.237 3.684 4.969a3.5 3.5 0 1 0 4.906-.274L23 21.707V23h1v-3h-3v1h1.293l-3.33 3.33a3.42 3.42 0 0 0-3.285.195l-3.558-4.797 2.466-1.293A3.488 3.488 0 0 0 20.95 17h2.1a4.49 4.49 0 1 0 4.45-5zm-10-9A2.5 2.5 0 1 1 15 5.5 2.503 2.503 0 0 1 17.5 3zM20 27.5a2.5 2.5 0 1 1-2.5-2.5 2.503 2.503 0 0 1 2.5 2.5zM4 13a2 2 0 1 1 2-2 2.002 2.002 0 0 1-2 2zm2.658-.637a2.953 2.953 0 0 0 .282-.768l3.683 1.782-1.582 2.198zM4 24a2 2 0 1 1 2-2 2.002 2.002 0 0 1-2 2zm2.918-2.674a2.961 2.961 0 0 0-.273-.713l2.408-3.343 1.568 2.115zm4.6-2.411l-1.852-2.497 1.871-2.599 2.736 1.324a3.353 3.353 0 0 0-.103 2.38zM17.5 19a2.5 2.5 0 1 1 2.5-2.5 2.502 2.502 0 0 1-2.5 2.5zm10 1a3.5 3.5 0 1 1 3.5-3.5 3.504 3.504 0 0 1-3.5 3.5zm2.5-3.5a2.5 2.5 0 1 1-2.5-2.5 2.502 2.502 0 0 1 2.5 2.5z"
  }));
};

var _default = DeepLearningIcon;
exports["default"] = _default;