"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImageUnitIcon = function ImageUnitIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.5 5.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zM15 14H1v2h1v-1h12v1h1zm0-14h-1v1H2V0H1v2h14zm0 3v10H1V3zm-1 7.614l-2.36-2.36-1.2.9a1.375 1.375 0 0 1-1.71-.044L6.461 7.22 4.173 9.509a1.37 1.37 0 0 1-.973.402 1.387 1.387 0 0 1-.429-.068L2 10.614V12h12zM14 4H2v5.2l.4-.4a.377.377 0 0 1 .533 0 .377.377 0 0 0 .534 0l2.69-2.69a.377.377 0 0 1 .508-.023L9.37 8.343a.377.377 0 0 0 .468.012l1.633-1.225a.377.377 0 0 1 .493.035L14 9.2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 7A1.5 1.5 0 1 0 16 8.5 1.5 1.5 0 0 0 14.5 7zm0 2a.5.5 0 1 1 .5-.5.5.5 0 0 1-.5.5zM22 4H2V1h1v2h18V1h1zm0 19h-1v-2H3v2H2v-3h20zM2 5v14h20V5zm19 13H3v-2.319l1.947-1.947a1.506 1.506 0 0 0 .677.163 1.403 1.403 0 0 0 .997-.415l3.307-3.307 3.26 2.716a1.502 1.502 0 0 0 1.863.049l1.833-1.375L21 15.681zm-3.714-7.447a.503.503 0 0 0-.657-.047L14.45 12.14a.503.503 0 0 1-.623-.016l-3.609-3.006a.503.503 0 0 0-.677.03l-3.627 3.628a.474.474 0 0 1-.678-.049.503.503 0 0 0-.704.008L3 14.267V6h18v8.267z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19 10a2 2 0 1 0 2 2 2.002 2.002 0 0 0-2-2zm0 3a1 1 0 1 1 1-1 1.001 1.001 0 0 1-1 1zm10 17h-1v-3H4v3H3v-4h26zm0-24H3V2h1v3h24V2h1zM3 7v18h26V7zm25 17H4v-3.264l3.401-2.704 1.198.566L14 14.111l5 4.532 3.506-3.123L28 20.49zm-4.997-9.416a.652.652 0 0 0-.926-.033L19 17.298l-4.554-4.131a.652.652 0 0 0-.857-.013L8.45 17.422l-.826-.39a.642.642 0 0 0-.72.117L4 19.459V8h24v11.17z"
  }));
};

var _default = ImageUnitIcon;
exports["default"] = _default;