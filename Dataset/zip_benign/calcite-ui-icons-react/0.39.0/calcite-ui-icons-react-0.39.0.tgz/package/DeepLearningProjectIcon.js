"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DeepLearningProjectIcon = function DeepLearningProjectIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 0v2H0v11h5v-1H1V6h4V5H1V3h13v2h-4v1h4v4h.695a2.27 2.27 0 0 1 .305.03V2h-4V0zm6 2H5V1h5zm3 12v-1h1v1zM9 6.929V6H6v3h1v3H6v3h3v-1h2v.696A1.305 1.305 0 0 0 12.305 16h2.39A1.305 1.305 0 0 0 16 14.695v-2.39A1.305 1.305 0 0 0 14.695 11h-1.624zM7 7h1v1H7zm0 7v-1h1v1zm7.695-2a.305.305 0 0 1 .305.305v2.39a.305.305 0 0 1-.305.305h-2.39a.305.305 0 0 1-.305-.305v-2.39a.305.305 0 0 1 .305-.305zm-2.92-.882A1.301 1.301 0 0 0 11 12.305V13H9v-1H8V9h1v-.657z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 18.004V8h19v8.05a4.448 4.448 0 0 1 1 .226V3.004h-6v-2H7v2H1V19h8.344a3.526 3.526 0 0 1 .717-.996zM8 2h7v1.004H8zM2 4h19v3.004H2zm18.5 13a3.494 3.494 0 0 0-3.45 3h-2.1A2.502 2.502 0 0 0 13 18.05v-4.1a2.477 2.477 0 0 0 1.002-.463L16.338 16H15v1h3v-3h-1v1.243l-2.336-2.512A2.473 2.473 0 0 0 15 11.5a2.5 2.5 0 1 0-3 2.45v4.1A2.5 2.5 0 1 0 14.95 21h2.1a3.493 3.493 0 1 0 3.45-4zM11 11.5a1.5 1.5 0 1 1 1.5 1.5 1.502 1.502 0 0 1-1.5-1.5zM12.5 22a1.5 1.5 0 1 1 1.5-1.5 1.502 1.502 0 0 1-1.5 1.5zm8 1a2.5 2.5 0 1 1 2.5-2.5 2.502 2.502 0 0 1-2.5 2.5zm1.5-2.5a1.5 1.5 0 1 1-1.5-1.5 1.502 1.502 0 0 1 1.5 1.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 24V10h25v11.213a5.455 5.455 0 0 1 1 .394V4h-8V2H10v2H2v21h10.267a4.44 4.44 0 0 1 .511-1zm8-21h9v1h-9zM3 5h25v4H3zm23.5 17a4.485 4.485 0 0 0-4.45 4h-2.1A3.481 3.481 0 0 0 17 23.05v-4.1a3.472 3.472 0 0 0 2.107-1.136L22.293 21H21v1h3v-3h-1v1.293l-3.33-3.33A3.499 3.499 0 1 0 16 18.95v4.1A3.492 3.492 0 1 0 19.95 27h2.1a4.49 4.49 0 1 0 4.45-5zM14 15.5a2.5 2.5 0 1 1 2.5 2.5 2.503 2.503 0 0 1-2.5-2.5zM16.5 29a2.5 2.5 0 1 1 2.5-2.5 2.503 2.503 0 0 1-2.5 2.5zm10 1a3.5 3.5 0 1 1 3.5-3.5 3.504 3.504 0 0 1-3.5 3.5zm2.5-3.5a2.5 2.5 0 1 1-2.5-2.5 2.502 2.502 0 0 1 2.5 2.5z"
  }));
};

var _default = DeepLearningProjectIcon;
exports["default"] = _default;