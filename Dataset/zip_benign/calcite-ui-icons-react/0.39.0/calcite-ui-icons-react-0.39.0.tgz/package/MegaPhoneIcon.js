"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MegaPhoneIcon = function MegaPhoneIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 10v2a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-.464l3.886 2.244A1.41 1.41 0 0 0 15 12.558V3.442a1.41 1.41 0 0 0-2.114-1.222c-6.75 3.897-3.218 1.86-6.315 3.647a.994.994 0 0 1-.5.133H2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h4.071a.994.994 0 0 1 .5.133L8 10.958V12H5v-2zm2.071-1H2.01L2 7h4.071a2 2 0 0 0 1-.267l6.316-3.646a.401.401 0 0 1 .203-.055.418.418 0 0 1 .205.055.412.412 0 0 1 .205.355v9.116a.412.412 0 0 1-.205.355.418.418 0 0 1-.205.055.404.404 0 0 1-.202-.054L7.07 9.267A2 2 0 0 0 6.071 9z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.25 2.798a1.5 1.5 0 0 0-1.5.002c-11.36 6.558-5.114 3.24-9.894 6a1.492 1.492 0 0 1-.749.2H2.5A1.5 1.5 0 0 0 1 10.5v3A1.5 1.5 0 0 0 2.5 15h7.607a1.499 1.499 0 0 1 .749.2c.484.279.853.495 1.144.669V17.5a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5V15H6v2.5A1.5 1.5 0 0 0 7.5 19h4a1.5 1.5 0 0 0 1.5-1.5v-.999c.555.405-.034.206 7.75 4.7A1.5 1.5 0 0 0 23 19.904V4.097a1.5 1.5 0 0 0-.75-1.3zM22 19.904a.5.5 0 0 1-.75.431l-9.894-6.002a2.5 2.5 0 0 0-1.25-.333H2.5a.5.5 0 0 1-.5-.5v-3a.5.5 0 0 1 .5-.5h7.607a2.503 2.503 0 0 0 1.25-.334l9.893-6a.499.499 0 0 1 .75.431z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.97 4.36a2.06 2.06 0 0 0-2.06.002l-12.768 7.372a1.99 1.99 0 0 1-1 .267H4a2 2 0 0 0-2 2V18a2 2 0 0 0 2 2h4v3a2 2 0 0 0 2 2h5a2 2 0 0 0 2-2v-1.083l9.91 5.722A2.06 2.06 0 0 0 30 25.857V6.144a2.06 2.06 0 0 0-1.03-1.784zM16 23a1.001 1.001 0 0 1-1 1h-5a1.001 1.001 0 0 1-1-1v-3h4.002a2.53 2.53 0 0 1 1.269.341L16 21.34zm13 2.856a1.06 1.06 0 0 1-1.59.916L14.641 19.4a3.015 3.015 0 0 0-1.5-.4H4a1 1 0 0 1-1-1v-4.01a1 1 0 0 1 1-.999h9.144a2.992 2.992 0 0 0 1.496-.4l12.77-7.362a1.067 1.067 0 0 1 .532-.144A1.06 1.06 0 0 1 29 6.145z"
  }));
};

var _default = MegaPhoneIcon;
exports["default"] = _default;