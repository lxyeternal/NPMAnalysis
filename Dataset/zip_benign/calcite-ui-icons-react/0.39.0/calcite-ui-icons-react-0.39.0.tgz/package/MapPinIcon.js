"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MapPinIcon = function MapPinIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.878 9.925L8 10.539V2.46l2-1v4.285a4.168 4.168 0 0 1 1-.726v-3.58l2 .945V4.5a4.274 4.274 0 0 1 1 .128V1.75L10.494.094 7.5 1.591 4.503.092 1 1.805V12.42l3.5-2.275 3.01 1.957 1.683-1.178a7.36 7.36 0 0 1-.315-1zM4 9.279l-2 1.3v-8.15l2-.978zm3 1.3l-2-1.3v-7.82l2 1zM13 6a2.79 2.79 0 0 0-2.756 2.86c0 1.58 1.506 3.717 2.756 6.14 1.25-2.423 2.756-4.56 2.756-6.14A2.79 2.79 0 0 0 13 6zm.12 6.691l-.12.213-.12-.213c-.84-1.502-1.636-2.92-1.636-3.83a1.759 1.759 0 1 1 3.512 0c0 .91-.795 2.328-1.637 3.83zM13.296 10h-.594A.703.703 0 0 1 12 9.297v-.594A.703.703 0 0 1 12.703 8h.594a.703.703 0 0 1 .703.703v.594a.703.703 0 0 1-.703.703z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.29 14.667L11 16.097V3.81l3-1.5v5.968a6.182 6.182 0 0 1 1-1.104V2.307l3.024 1.503-.003 1.974A6.275 6.275 0 0 1 19 5.7l.02.001.005-2.51L14.5.94l-4 2-4-2L2 3.191V17.9l4.5-2.811 4 2.5 3.15-1.968q-.202-.485-.36-.955zM6 14.223l-3.001 1.876-.023-12.29L6 2.308zm4 1.875l-3-1.875V2.309l3 1.5zM19 7a4.96 4.96 0 0 0-4.9 5.086c0 2.807 2.678 6.606 4.9 10.914 2.222-4.308 4.9-8.107 4.9-10.914A4.96 4.96 0 0 0 19 7zm0 13.877c-.298-.543-.598-1.077-.89-1.6-1.548-2.762-3.01-5.37-3.01-7.191a3.905 3.905 0 1 1 7.8 0c0 1.82-1.462 4.429-3.01 7.19-.292.524-.592 1.058-.89 1.601zm0-11.043A2.166 2.166 0 1 0 21.13 12 2.147 2.147 0 0 0 19 9.834zm0 3.332A1.167 1.167 0 1 1 20.13 12 1.15 1.15 0 0 1 19 13.166z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.968 20.722L15 21.695V4.825l5-2.514v6.505a8.102 8.102 0 0 1 1-.458V2.289l5 2.361v3.397a8.179 8.179 0 0 1 1 .31v-4.34L20.493.944 14.532 3.94 8.502.942 2 4.122v19.113l6.498-3.177 6 3 2.881-1.423q-.218-.462-.411-.913zM8 19.187l-5 2.444V4.745l5-2.444zm6 2.504l-5-2.5V2.307l5 2.486zM24 9.1a6.847 6.847 0 0 0-6.9 6.932c0 3.882 3.789 9.01 6.9 14.968 3.111-5.957 6.9-11.086 6.9-14.968A6.847 6.847 0 0 0 24 9.1zm0 19.789c-.58-1.053-1.168-2.075-1.743-3.075-2.23-3.877-4.157-7.227-4.157-9.782a5.9 5.9 0 1 1 11.8 0c0 2.555-1.926 5.905-4.157 9.782-.575 1-1.163 2.022-1.743 3.075zM24 13a3 3 0 1 0 3 3 3 3 0 0 0-3-3zm0 5a2 2 0 1 1 2-2 2.003 2.003 0 0 1-2 2z"
  }));
};

var _default = MapPinIcon;
exports["default"] = _default;