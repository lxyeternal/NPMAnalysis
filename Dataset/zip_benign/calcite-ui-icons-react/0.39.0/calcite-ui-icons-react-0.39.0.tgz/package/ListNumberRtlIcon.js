"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListNumberRtlIcon = function ListNumberRtlIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 14h9v1H1zm9-12H1v1h9zm0 6H1v1h9zm5-5h-1V0h-2v1h1v2h-1v1h3zm0 12v-1a.975.975 0 0 0-.153-.5A.964.964 0 0 0 15 13v-1a1 1 0 0 0-1-1h-1c-.553 0-1 0-1 1h2v1h-.5a.5.5 0 0 0 0 1h.5v1h-2c0 1 .447 1 1 1h1a1 1 0 0 0 1-1zm-1-7a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-1a1 1 0 0 0-1 1h2v1h-1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h2V9h-2V8z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 4h14v1H2zm0 17h14v-1H2zm0-8h14v-1H2zm19 5h-1c-.553 0-1 0-1 1h2v1h-.5a.5.5 0 0 0 0 1h.5v1h-2c0 1 .447 1 1 1h1a1 1 0 0 0 1-1v-1a.975.975 0 0 0-.153-.5A.964.964 0 0 0 22 20v-1a1 1 0 0 0-1-1zm0-16h-2v1h1v3h-1v1h3V6h-1zm0 8h-1a1 1 0 0 0-1 1h2v1h-1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h2v-1h-2v-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 24v2a.964.964 0 0 1-.153.5.975.975 0 0 1 .153.5v2a1 1 0 0 1-1 1h-2c-.553 0-1 0-1-1h3v-2h-1.5a.5.5 0 0 1 0-1H28v-2h-3c0-1 .447-1 1-1h2a1 1 0 0 1 1 1zM28 3h-3v1h2v4h-2v1h5V8h-2zm0 10h-2a1 1 0 0 0-1 1h3v2h-2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h3v-1h-3v-2h2a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1zm-7-7H3v1h18zm0 10H3v1h18zm0 10H3v1h18z"
  }));
};

var _default = ListNumberRtlIcon;
exports["default"] = _default;