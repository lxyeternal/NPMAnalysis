"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileKmlIcon = function FileKmlIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v6h1V1h7v4h4v10H3v-1H2v2h13V3.6zM14 4h-3V1h.31L14 3.69zm-2 9h-1V7h1zM1 13H0V7h1v3.293L2.293 9h1.414l-1.263 1.263L4.321 13H3.108l-1.383-2.018-.725.725zm5 0H5V9h1v.092a1.453 1.453 0 0 1 1.5.298A1.493 1.493 0 0 1 10 10.5V13H9v-2.5a.5.5 0 0 0-1 0V13H7v-2.5a.5.5 0 0 0-1 0z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 18H2v-7h1v4.293L5.293 13h1.414L4.85 14.857 7.006 18H5.793l-1.662-2.424L3 16.707zm13-7v7h1v-7zm-8 2v5h1v-3a1 1 0 0 1 2 0v3h1v-3a1 1 0 0 1 2 0v3h1v-3a1.991 1.991 0 0 0-3.5-1.309 1.959 1.959 0 0 0-2.5-.413V13zm13-6.291V23H3v-4h1v3h16V8h-6V2H4v8H3V1h12.29zM20 6.8L15.2 2H15v5h5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v11h1V3h12v8h8v18H6v-3H5v4h22V9.699zm-.3 8V3l7 7zm4 14h-1v-9h1zm-11 0h-1v-6h1v.512a2.479 2.479 0 0 1 3.5.49A2.499 2.499 0 0 1 20 20.5V24h-1v-3.5a1.5 1.5 0 0 0-3 0V24h-1v-3.5a1.5 1.5 0 0 0-3 0zm-2.494 0H8.293l-2.272-3.314L5 21.707V24H4v-9h1v5.293L7.293 18h1.414L6.74 19.967z"
  }));
};

var _default = FileKmlIcon;
exports["default"] = _default;