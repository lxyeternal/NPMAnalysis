"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HeavySnowIcon = function HeavySnowIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.354 4.354l-.707-.707 3-3 .707.707zM4 5V4H2v1zm1 0h1V4H5zm2-1v1h2V4zM5 3h1V1H5zm1 3H5v2h1zm-1.128-.165l-.743-.67L3.12 6.282l.743.67zm1.256-2.67l.743.67L7.88 2.718l-.743-.67zm.743 2l-.743.67 1.008 1.117.743-.67zM4.13 3.835l.743-.67-1.008-1.117-.743.67zm8.517.813l-7.988 8.016A1.563 1.563 0 0 1 1.99 11.56a1.586 1.586 0 0 1 1.904-1.525l.219-.976a2.563 2.563 0 1 0 1.252 4.312l7.989-8.017zm-3.124 6.071l-1.924 1.925a1.965 1.965 0 1 0 3.354 1.388h-1a.965.965 0 1 1-1.647-.681l1.72-1.72a1.489 1.489 0 0 1-.503-.912zM11 11h1v-1h-1zm3-1h-1v1h1zm2 1v-1h-1v1zm-3-3v1h1V8zm1 5v-1h-1v1zm-1.854-1.854l-.5.5.707.707.5-.5zm2.707-1.293l.5-.5-.707-.707-.5.5zm0 1.293l-.707.707.5.5.707-.707zm-2.707-1.293l.707-.707-.5-.5-.707.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.354 7.354l-.707-.707 5-5 .707.707zm3.129-.541L7.095 19.2a2.426 2.426 0 1 1 0-3.43l.707-.707a3.425 3.425 0 1 0 0 4.844L20.19 7.52zm-3.958 7.933l-4.94 4.94a2 2 0 1 0 3.038.245l-.811.586A.989.989 0 0 1 13 21.1a1 1 0 1 1-1.707-.707l4.748-4.749a1.49 1.49 0 0 1-.516-.898zM17 15h1v-1h-1zm3-1h-1v1h1zm2 1v-1h-1v1zm-3-3v1h1v-1zm1 5v-1h-1v1zm-1.854-1.854l-.5.5.707.707.5-.5zm2.707-1.293l.5-.5-.707-.707-.5.5zm0 1.293l-.707.707.5.5.707-.707zm-2.707-1.293l.707-.707-.5-.5-.707.707zM4.247 9.533l1.472-.85.5.866.366-1.366L8 7.366V10l-1 1h1v1h1v-1h1l-1-1V7.366l1.415.817.366 1.366.5-.866 1.472.85.5-.866-1.472-.85.5-.866-1.366.366L9.5 6.5l1.415-.817 1.366.366-.5-.866 1.472-.85-.5-.866-1.472.85-.5-.866-.366 1.366L9 5.634V3l1-1H9V1H8v1H7l1 1v2.634l-1.415-.817-.366-1.366-.5.866-1.472-.85-.5.866 1.472.85-.5.866 1.366-.366L7.5 6.5l-1.415.817-1.366-.366.5.866-1.472.85z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3.902 13.14l1.547-.874-1.201-.97.627-.778 1.512 1.219 3.097-1.75-3.097-1.752-1.512 1.22-.627-.78 1.201-.97-1.547-.874.493-.871 1.528.864.162-1.516.995.107-.21 1.945L10 9.13V5.288l-1.727-.685.37-.93 1.357.54V3h1v1.213l1.358-.54.369.93L11 5.29v3.84l3.13-1.769-.21-1.945.995-.107.162 1.516 1.528-.864.493.871-1.547.875 1.201.969-.627.78-1.512-1.22-3.097 1.751 3.097 1.75 1.512-1.218.627.779-1.201.97 1.547.874-.493.87-1.528-.863-.162 1.517-.995-.107.21-1.946-3.13-1.77v3.868l1.727.685-.37.93L11 15.787V17h-1v-1.213l-1.358.54-.369-.93L10 14.71v-3.868l-3.13 1.769.21 1.946-.995.107-.162-1.517-1.528.864zm24.452-8.786l-.707-.707-7 7 .707.707zm-2.707 5.293L9.17 26.12a3.658 3.658 0 0 1-5.051 0 3.572 3.572 0 0 1 2.83-6.085l.084-.996a4.572 4.572 0 0 0-3.621 7.788 4.57 4.57 0 0 0 6.465 0l16.476-16.474zM20.54 19.835l-5.872 5.872a2.535 2.535 0 1 0 4.286 1.328l-.983.182a1.535 1.535 0 1 1-2.596-.803l5.722-5.722a1.494 1.494 0 0 1-.557-.857zM24 20v-1h-2v1zm2-1h-1v1h1zm1 0v1h2v-1zm-2-1h1v-2h-1zm1 3h-1v2h1zm-1.128-.165l-.743-.67-1.008 1.117.743.67zm1.256-2.67l.743.67 1.008-1.117-.743-.67zm.743 2l-.743.67 1.008 1.117.743-.67zm-3.75-2.447l1.008 1.117.743-.67-1.008-1.117z"
  }));
};

var _default = HeavySnowIcon;
exports["default"] = _default;