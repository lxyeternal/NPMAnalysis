"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DiamondIcon = function DiamondIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.5 15.85a.852.852 0 0 1-.6-.246l-6.5-6.5a.856.856 0 0 1-.004-1.205l6.5-6.5a.876.876 0 0 1 1.205-.003l6.5 6.5a.856.856 0 0 1 .003 1.205l-6.5 6.5a.855.855 0 0 1-.604.249zM2.21 8.5l6.29 6.29 6.29-6.29L8.5 2.21z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.25 12.5a1.11 1.11 0 0 1 .324-.787l9.138-9.137a1.144 1.144 0 0 1 1.576 0l9.137 9.136a1.118 1.118 0 0 1 0 1.577l-9.137 9.135a1.143 1.143 0 0 1-1.576 0l-9.138-9.136a1.11 1.11 0 0 1-.324-.788zm19.5 0a.116.116 0 0 0-.033-.082l-9.135-9.133a.117.117 0 0 0-.164 0l-9.134 9.133a.117.117 0 0 0 0 .165l9.134 9.133a.117.117 0 0 0 .164 0l9.135-9.134a.116.116 0 0 0 .033-.082z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.089 15.388a1.576 1.576 0 0 1 .003 2.223L17.612 30.09a1.573 1.573 0 0 1-2.223 0L2.91 17.61a1.573 1.573 0 0 1 0-2.222L15.39 2.909a1.576 1.576 0 0 1 2.223.002zM16.096 29.383a.585.585 0 0 0 .808 0l12.48-12.479a.574.574 0 0 0-.002-.81L16.905 3.619a.574.574 0 0 0-.81-.003L3.618 16.095a.585.585 0 0 0 0 .81z"
  }));
};

var _default = DiamondIcon;
exports["default"] = _default;