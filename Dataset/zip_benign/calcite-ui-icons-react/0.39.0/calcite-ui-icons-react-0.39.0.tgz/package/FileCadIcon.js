"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileCadIcon = function FileCadIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v7h1V1h7v4h4v10H3v-1H2v2h13V3.6zM14 4h-3V1h.31L14 3.69zm-2 4h-1.604A1.397 1.397 0 0 0 9 9.396v2.209A1.397 1.397 0 0 0 10.396 13H13V6h-1zm-1.604 4a.396.396 0 0 1-.396-.396V9.395A.396.396 0 0 1 10.396 9H12v3zm-5.688.988H7V13h1v-3a2.003 2.003 0 0 0-2-2H5v1h1a1 1 0 0 1 1 1h-.708A2.285 2.285 0 0 0 4 12.28a.709.709 0 0 0 .708.708zM6.292 11H7v1H5.033a1.294 1.294 0 0 1 1.259-1zM3 13H0V8h3v1H1v3h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v11h1V2h10v6h6v14H4v-3H3v4h18V6.709zM20 7h-5V2h.2L20 6.8zm-3 4v2.295A2.018 2.018 0 0 0 15.959 13h-.918A2.044 2.044 0 0 0 13 15.041v.918A2.044 2.044 0 0 0 15.041 18h.918A2.018 2.018 0 0 0 17 17.705V18h1v-7zm-1.041 6h-.918A1.042 1.042 0 0 1 14 15.959v-.918A1.042 1.042 0 0 1 15.041 14h.918A1.042 1.042 0 0 1 17 15.041v.918A1.042 1.042 0 0 1 15.959 17zM2 15.959v-.918A2.044 2.044 0 0 1 4.041 13H6v1H4.041A1.042 1.042 0 0 0 3 15.041v.918A1.042 1.042 0 0 0 4.041 17H6v1H4.041A2.044 2.044 0 0 1 2 15.959zM8.39 18H12v-3a2.044 2.044 0 0 0-2.041-2H8v1h1.959a1.042 1.042 0 0 1 1.04 1h-2.39A1.61 1.61 0 0 0 7 16.61 1.392 1.392 0 0 0 8.39 18zm.22-2H11v1H8.39a.39.39 0 0 1-.39-.39.61.61 0 0 1 .61-.61z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v14h1V3h12v8h8v18H6v-3H5v4h22V9.699zM21 15v3.78a3 3 0 1 0 0 4.44V24h1v-9zm-2 8a2 2 0 1 1 2-2 2.003 2.003 0 0 1-2 2zM8.565 19.536l.707-.707a3.099 3.099 0 1 0 0 4.385l-.707-.707a2.1 2.1 0 1 1 0-2.97zm4.156-1.636a2.32 2.32 0 0 0-1.896.733l.783.623a1.435 1.435 0 0 1 1.113-.356c.944 0 1.279.405 1.279.75v.343h-1.5c-1.465 0-2.488.825-2.488 2.006a2.08 2.08 0 0 0 2.238 1.994 3.212 3.212 0 0 0 1.75-.546v.403h1v-4.2c0-.842-.713-1.75-2.28-1.75zm-.471 5.093c-.597 0-1.238-.311-1.238-.994 0-.695.747-1.006 1.488-1.006H14v.792c0 .61-.867 1.208-1.75 1.208zM19 10V3l7 7z"
  }));
};

var _default = FileCadIcon;
exports["default"] = _default;