"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LanguageTranslateIcon = function LanguageTranslateIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.176 3L13.5 5.058 11.824 3H13v-.5A1.502 1.502 0 0 0 11.5 1H11V0h.5A2.503 2.503 0 0 1 14 2.5V3zM5 9H1.833A.834.834 0 0 1 1 8.167V1.833A.834.834 0 0 1 1.833 1h6.334A.834.834 0 0 1 9 1.833V5h1V1.833A1.835 1.835 0 0 0 8.167 0H1.833A1.835 1.835 0 0 0 0 1.833v6.334A1.835 1.835 0 0 0 1.833 10H5zm1.733-3.956A6.467 6.467 0 0 0 7.179 4H8V3H5.519l.128-.129L4.59 1.813l-.707.707.48.48H2v1h.768a6.176 6.176 0 0 0 1.418 2.414 5.84 5.84 0 0 1-1.79.768l.242.97A6.723 6.723 0 0 0 4.97 7.086c.011.008.025.014.036.022a2.167 2.167 0 0 1 1.727-2.064zM3.83 4h2.284a5.056 5.056 0 0 1-1.148 1.777A4.957 4.957 0 0 1 3.83 4zm10.362 12H7.808A1.81 1.81 0 0 1 6 14.192V7.808A1.81 1.81 0 0 1 7.808 6h6.384A1.81 1.81 0 0 1 16 7.808v6.384A1.81 1.81 0 0 1 14.192 16zM7.808 7A.809.809 0 0 0 7 7.808v6.384a.809.809 0 0 0 .808.808h6.384a.809.809 0 0 0 .808-.808V7.808A.809.809 0 0 0 14.192 7zm5.342 6.94l.899-.439L11 7.261l-3.049 6.24.899.44.46-.941h3.38zM9.798 12L11 9.54 12.202 12zM5 15v1h-.5A2.503 2.503 0 0 1 2 13.5V13H.824L2.5 10.942 4.176 13H3v.5A1.502 1.502 0 0 0 4.5 15z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 15H3.5A2.502 2.502 0 0 1 1 12.5v-9A2.502 2.502 0 0 1 3.5 1h9A2.502 2.502 0 0 1 15 3.5V8h-1V3.5A1.502 1.502 0 0 0 12.5 2h-9A1.502 1.502 0 0 0 2 3.5v9A1.502 1.502 0 0 0 3.5 14H8zm-.038-4.811a9.77 9.77 0 0 1-3.766 1.796l-.242-.97a8.816 8.816 0 0 0 3.282-1.532A9.264 9.264 0 0 1 4.888 5H4V4h3.279l-.544-.544.707-.707L8.692 4H12v1h-.914A9.836 9.836 0 0 1 9.78 8.152a3.853 3.853 0 0 0-1.82 2.037zm.032-1.383A8.167 8.167 0 0 0 10.058 5H5.922a8.18 8.18 0 0 0 2.072 3.806zM23 20.447v-8.894A2.525 2.525 0 0 0 20.484 9h-8.931A2.556 2.556 0 0 0 9 11.553v8.894A2.556 2.556 0 0 0 11.553 23h8.894A2.556 2.556 0 0 0 23 20.447zM20.484 10A1.517 1.517 0 0 1 22 11.516v8.968A1.517 1.517 0 0 1 20.484 22h-8.968A1.517 1.517 0 0 1 10 20.484v-8.968A1.517 1.517 0 0 1 11.516 10zm-2.086 8h-4.796l-1.159 2.23-.886-.46L16 11.215l4.443 8.555-.886.46zm-.52-1L16 13.385 14.122 17zM6 22.01a2.003 2.003 0 0 1-2-2v-2.303l1.646 1.646.707-.707L3.506 15.8.659 18.646l.707.707L3 17.72v2.292a3.003 3.003 0 0 0 3 3h2.058v-1zM22.646 4.647L21 6.293V4a3.003 3.003 0 0 0-3-3h-2v1h2a2.003 2.003 0 0 1 2 2v2.281l-1.634-1.635-.707.707 2.847 2.848 2.848-2.848z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13 18H6.167A3.17 3.17 0 0 1 3 14.833V6.167A3.17 3.17 0 0 1 6.167 3h8.666A3.17 3.17 0 0 1 18 6.167V13h-1V6.167A2.169 2.169 0 0 0 14.833 4H6.167A2.169 2.169 0 0 0 4 6.167v8.666A2.169 2.169 0 0 0 6.167 17H13zm-.003-2.437a11.225 11.225 0 0 1-2.481-1.932 11.326 11.326 0 0 1-3.297 2.396l-.438-.9a10.255 10.255 0 0 0 3.067-2.267A12.518 12.518 0 0 1 7.552 8H6V7h4.292L8.978 5.685l.707-.707L11.706 7H15v1h-1.518a12.526 12.526 0 0 1-2.303 4.868 10.25 10.25 0 0 0 2.267 1.798 4.406 4.406 0 0 0-.45.897zM12.445 8H8.584a11.459 11.459 0 0 0 1.922 4.074A11.505 11.505 0 0 0 12.445 8zM29 25.885v-8.77A3.119 3.119 0 0 0 25.885 14h-8.77A3.119 3.119 0 0 0 14 17.115v8.77A3.119 3.119 0 0 0 17.115 29h8.77A3.119 3.119 0 0 0 29 25.885zM25.885 15A2.118 2.118 0 0 1 28 17.115v8.77A2.118 2.118 0 0 1 25.885 28h-8.77A2.118 2.118 0 0 1 15 25.885v-8.77A2.118 2.118 0 0 1 17.115 15zm-2.053 8h-4.664l-1.726 3.275-.884-.466 4.942-9.382 4.942 9.382-.884.466zm-.527-1L21.5 18.573 19.695 22zM10 28a3.003 3.003 0 0 1-3-3v-3.28l2.646 2.647.707-.707L6.5 19.807 2.646 23.66l.707.707L6 21.721V25a4.004 4.004 0 0 0 4 4h2v-1zM28.646 7.633L26 10.279V7a4.004 4.004 0 0 0-4-4h-2v1h2a3.003 3.003 0 0 1 3 3v3.28l-2.646-2.647-.707.707 3.853 3.853 3.854-3.853z"
  }));
};

var _default = LanguageTranslateIcon;
exports["default"] = _default;