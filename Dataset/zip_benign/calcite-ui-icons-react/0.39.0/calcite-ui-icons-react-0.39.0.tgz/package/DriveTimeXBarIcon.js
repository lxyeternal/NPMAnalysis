"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DriveTimeXBarIcon = function DriveTimeXBarIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.312 12l.635 1H6.845L3 15v-4.667l-.774-1.166L.01 9l2.216-6h2.31l2.31-2h3.464l1.154 2H15l-3.416 3.444.923.706H10.86l-.788-.602L12.6 4h-1.713L9.732 2H7.22L4.91 4H2.922L1.399 8.103l1.39.103L4 10.031v3.322L6.602 12zM8.15 10V9a1.932 1.932 0 0 1 1.23-1.722l-.82-.627 1.71-1.721L9.155 3H7.592l-2.31 2H3.617L2.8 7.204l.552.041L5 9.73v1.977L6.357 11h2.19a1.593 1.593 0 0 1-.397-1zM10 9v1h6V9zm4.414 2.013l-1.502 1.79-1.066-1.79h-1.088l1.461 2.302L9.8 16h1.033l1.854-2.153L13.967 16h1.097l-1.684-2.685 2.046-2.302z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 19h-1.364L5 22v-6.667l-.963-1.666-3.18-.238L4.037 5h3.121l3.3-3h4.948l1.65 3h5.23l-4.68 4.778 1.6 1.222h-1.648L16.1 9.886 19.906 6h-3.441l-1.65-3h-3.97l-3.3 3H4.729l-2.465 6.531 2.375.178L6 15.064v5.271L10.387 18H12zm1.632-14h-2.015L8.32 8H6.112l-1.033 2.736.646.05L8 14.427v2.515L9.87 16h2.235a3.745 3.745 0 0 1 .332-.767A1.981 1.981 0 0 1 12 14v-1a2 2 0 0 1 2-2h.064l-1.233-.942 2.328-2.28zM14 13v1h9v-1zm7.875 8.188a2.12 2.12 0 0 1-.229.95l-2.545-3.2 2.774-3.488V15h-.844L18.5 18.182 15.969 15h-.844S14.018 16.16 14 16.685V17h1.125v-.315a2.117 2.117 0 0 1 .228-.947l2.546 3.2-2.774 3.487v.45h.844l2.531-3.182 2.531 3.182h.844s1.107-1.16 1.125-1.685V21h-1.125z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M20.493 25l-.796 1h-5.391L7 29.8v-8.867l-1.47-2.216L1.6 18 5.53 7h3.54l4.62-4h6.928l2.31 4H30.4l-6.49 6.544L25.723 15h-1.598l-1.709-1.371L28 8h-5.648l-2.31-4h-5.979L9.444 8h-3.21l-3.296 9.228 3.189.582L8 20.632v7.52L14.062 25zm-4.403-2.818v-.776a3.556 3.556 0 0 1 .647-1.867A1.987 1.987 0 0 1 16 18v-1a2 2 0 0 1 2-2h2.93l-1.498-1.202 2.502-2.522L18.887 6h-4.078l-4.62 4H7.645l-2.032 5.683 1.71.311L10 20.028v4.83L13.572 23h2.697a1.985 1.985 0 0 1-.18-.818zM18 17v1h12v-1zm11 10.584a2.37 2.37 0 0 1-.444 1.334l-3.497-4.458 3.85-4.76v-.587h-1.12l-3.557 4.371-3.437-4.368h-1.123c-.015.016-1.509 1.588-1.532 2.281l-.05.603h1.496v-.603a2.312 2.312 0 0 1 .402-1.333l3.497 4.458-3.8 4.759v.619h1.07l3.556-4.402 3.438 4.402h1.138c.155-.166 1.495-1.66 1.517-2.315l.05-.585H29z"
  }));
};

var _default = DriveTimeXBarIcon;
exports["default"] = _default;