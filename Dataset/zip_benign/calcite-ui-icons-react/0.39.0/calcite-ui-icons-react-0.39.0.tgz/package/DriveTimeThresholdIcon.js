"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DriveTimeThresholdIcon = function DriveTimeThresholdIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 13v3H0v-3h1v2h6v-2h1v2h7v-2zm-9.643-2h4.193l1.474-1.702L8.561 6.65l1.708-1.721L9.155 3H7.592l-2.31 2H3.617L2.8 7.204l.552.041L5 9.73v1.977zM15 3h-3.536L10.31 1H6.845l-2.31 2H2.227L.01 9l2.216.167L3 10.333V12h1v-1.969L2.79 8.206 1.4 8.103 2.921 4h1.987l2.31-2h2.513l1.155 2H12.6l-2.528 2.548 3.405 2.601L11.007 12h1.323l2.599-3-3.345-2.556z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 19v3H1v-3h1v2h9v-2h1v2h10v-2zM9.87 16h6.017l1.908-2.148-4.964-3.794 2.328-2.28L13.632 5h-2.015L8.32 8H6.112l-1.033 2.736.646.05L8 14.427v2.515zM5 15.333V18h1v-2.936L4.64 12.71l-2.376-.178L4.73 6h2.816l3.3-3h3.97l1.65 3h3.441L16.1 9.886l4.834 3.693L17.126 18h1.32l3.938-4.571-4.779-3.651L22.285 5h-5.229l-1.65-3h-4.949L7.158 5h-3.12l-3.18 8.429 3.18.238z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 26v3H16v-3h-1v3H3v-3H2v4h28v-4zm-5.09-12.456l6.054 4.856-6.237 6.6h-1.375l6.14-6.498-6.075-4.873L28 8h-5.648l-2.31-4h-5.979L9.444 8h-3.21l-3.296 9.228 3.189.582L8 20.632V25H7v-4.067l-1.47-2.216L1.6 18 5.53 7h3.54l4.62-4h6.928l2.31 4H30.4zM10 24.858v-4.83l-2.677-4.034-1.71-.311L7.645 10h2.544l4.62-4h4.078l3.047 5.276-2.502 2.522 6.117 4.907L21.489 23h-7.917z"
  }));
};

var _default = DriveTimeThresholdIcon;
exports["default"] = _default;