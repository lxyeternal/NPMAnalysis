"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DrivingDistanceIcon = function DrivingDistanceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 3H0V0h1zm3-1h5v2h3v1l2-1.5L12 2v1h-2V1H4V0L2 1.5 4 3zm11 0v3h1V2zm-5 13h6v1H0v-4.629a1.371 1.371 0 0 1 1.132-1.347L1.14 10H0V9h1.473l.44-1.316A.998.998 0 0 1 2.86 7h4.28a.999.999 0 0 1 .948.684L8.528 9H10v1H8.86l.009.024A1.371 1.371 0 0 1 10 11.371zm-7.806-5h5.612L7.14 8H2.86zM8 14H2v1h6zm1-2.629A.372.372 0 0 0 8.629 11H1.37a.372.372 0 0 0-.371.371V13H2.06a.708.708 0 0 1-.06-.286V12h.714l.5 1h3.572l.5-1H8v.714a.708.708 0 0 1-.061.286H9z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 18h6v1H5zM6 4h6v3h6v2.19l3.058-2.69L18 3.81V6h-5V3H6V.81L2.942 3.5 6 6.19zM2 2H1v3h1zm13 20h8v1H1v-6a1.996 1.996 0 0 1 1.505-1.93l.013-.07H1v-1h1.702l.296-1.605A1.829 1.829 0 0 1 4.606 11h6.788a1.829 1.829 0 0 1 1.608 1.395L13.298 14H15v1h-1.518l.013.07A1.996 1.996 0 0 1 15 17zM3.534 15h8.933l-.43-2.342c-.093-.338-.405-.658-.643-.658H4.606c-.238 0-.55.32-.625.576zM3 21H2v1h1zm9 0H4v1h8zm2 0h-1v1h1zm-2-2l1-2h1a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1h1l1 2H3a1 1 0 0 1-1-1v2h12v-2a1 1 0 0 1-1 1zM22 5v3h1V5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 7v5h-1V7zM3 3H2v5h1zm4 3h8v4h10v2.19l3.058-2.69L25 6.81V9h-9V5H7V2.81L3.942 5.5 7 8.19zm10 17h2v1a1 1 0 0 1-1 1h-2zM5 23v1a1 1 0 0 0 1 1h2l-1-2zm4 2h6v-1H9zm12 4v-6.477A4.095 4.095 0 0 0 20.489 21h.011a.501.501 0 0 0 .5-.5V19h-2.286l-1.517-3.54A.824.824 0 0 0 16.5 15h-9a.824.824 0 0 0-.697.46L5.286 19H3v1.5a.501.501 0 0 0 .5.5 4.194 4.194 0 0 0-.5 1.522V29H2v1h28v-1zM7.66 16h8.68l1.715 4H5.945zM5 29H4v-1.79a1.983 1.983 0 0 0 .613.235c.118.024.254.048.387.071zm13 0H6v-1.331A46.229 46.229 0 0 0 12 28a46.244 46.244 0 0 0 6.001-.331zm2 0h-1v-1.484c.133-.023.269-.047.387-.07A1.989 1.989 0 0 0 20 27.21zm0-3.532a1.015 1.015 0 0 1-.808.997A44.263 44.263 0 0 1 12 27.1a44.39 44.39 0 0 1-7.192-.635A1.015 1.015 0 0 1 4 25.468v-2.946a1.532 1.532 0 0 1 .524-1.156 1.49 1.49 0 0 1 .568-.307L5.296 21h13.406l.205.06a1.493 1.493 0 0 1 .568.308A1.53 1.53 0 0 1 20 22.522z"
  }));
};

var _default = DrivingDistanceIcon;
exports["default"] = _default;