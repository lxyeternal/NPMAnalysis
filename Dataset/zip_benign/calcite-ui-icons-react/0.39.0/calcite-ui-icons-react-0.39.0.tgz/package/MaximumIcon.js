"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MaximumIcon = function MaximumIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 12V7H4v5H3V7H2v5H1V6h2a.97.97 0 0 1 .5.154A.97.97 0 0 1 4 6h1a1.001 1.001 0 0 1 1 1v5zm10.217 0H16v-1h-.217l-1.2-2 1.2-2H16V6h-.783L14 8.028 12.783 6H12v1h.217l1.2 2-1.2 2H12v1h.783L14 9.972zM11 7v5H8a1.001 1.001 0 0 1-1-1V9a1.001 1.001 0 0 1 1-1h2V7H7V6h3a1.001 1.001 0 0 1 1 1zm-1 2H8v2h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 11.25V18H8v-6.75a.25.25 0 0 0-.25-.25h-1.5a.25.25 0 0 0-.25.25V18H5v-6.75a.25.25 0 0 0-.25-.25H3v7H2v-8h2.75a1.223 1.223 0 0 1 .75.276A1.223 1.223 0 0 1 6.25 10h1.5A1.251 1.251 0 0 1 9 11.25zm7-.25v7h-3.75A1.251 1.251 0 0 1 11 16.75v-2.5A1.251 1.251 0 0 1 12.25 13H15v-2h-4v-1h4a1.001 1.001 0 0 1 1 1zm-1 3h-2.75a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25H15zm5.5-1.008L18.79 10H18v1h.21l1.714 3-1.714 3H18v1h.79l1.71-2.992L22.21 18H23v-1h-.21l-1.714-3 1.714-3H23v-1h-.79z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.5 15H4v9H3V14h3.5a1.489 1.489 0 0 1 1 .39 1.489 1.489 0 0 1 1-.39h2a1.502 1.502 0 0 1 1.5 1.5V24h-1v-8.5a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 0-.5.5V24H7v-8.5a.5.5 0 0 0-.5-.5zm7.5 7.5v-4a1.502 1.502 0 0 1 1.5-1.5H20v-1.5a.5.5 0 0 0-.5-.5H14v-1h5.5a1.502 1.502 0 0 1 1.5 1.5V24h-5.5a1.502 1.502 0 0 1-1.5-1.5zm1 0a.5.5 0 0 0 .5.5H20v-5h-4.5a.5.5 0 0 0-.5.5zM30 15v-1h-.768L26.5 18.099 23.768 14H23v1h.232l2.667 4-2.667 4H23v1h.768l2.732-4.099L29.232 24H30v-1h-.232L27.1 19l2.667-4z"
  }));
};

var _default = MaximumIcon;
exports["default"] = _default;