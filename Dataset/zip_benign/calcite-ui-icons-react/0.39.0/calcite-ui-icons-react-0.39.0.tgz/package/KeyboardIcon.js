"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var KeyboardIcon = function KeyboardIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 3h-13A1.502 1.502 0 0 0 0 4.5v8A1.502 1.502 0 0 0 1.5 14h13a1.502 1.502 0 0 0 1.5-1.5v-8A1.502 1.502 0 0 0 14.5 3zm.5 9.5a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5zM12 6h2v1h-2zm-1 1H9V6h2zM8 7H6V6h2zm0 1h2v1H8zM5 8h2v1H5zm0-1H2V6h3zM2 8h2v1H2zm0 2h2v1H2zm10 0h2v1h-2zm-1-2h3v1h-3zm-6 2h6v1H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 10h-2V9h2zM9 9H7v1h2zm6 0h-2v1h2zm3 0h-2v1h2zm-4 2h-2v1h2zm3 0h-2v1h2zm-6 0H9v1h2zm2 2h-2v1h2zm-3 0H8v1h2zm6 0h-2v1h2zM3 16h3v-1H3zm5-5H6v1h2zm10 5h3v-1h-3zm1-6h2V9h-2zm5-3.5v12a1.502 1.502 0 0 1-1.5 1.5h-21A1.502 1.502 0 0 1 0 18.5v-12A1.502 1.502 0 0 1 1.5 5h21A1.502 1.502 0 0 1 24 6.5zm-1 0a.5.5 0 0 0-.5-.5h-21a.5.5 0 0 0-.5.5v12a.5.5 0 0 0 .5.5h21a.5.5 0 0 0 .5-.5zM7 13H3v1h4zm11-1h3v-1h-3zM5 11H3v1h2zm1-2H3v1h3zm1 7h10v-1H7zm10-2h4v-1h-4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.5 7h-29A1.502 1.502 0 0 0 0 8.5v16A1.502 1.502 0 0 0 1.5 26h29a1.502 1.502 0 0 0 1.5-1.5v-16A1.502 1.502 0 0 0 30.5 7zm.5 17.5a.5.5 0 0 1-.5.5h-29a.5.5 0 0 1-.5-.5v-16a.5.5 0 0 1 .5-.5h29a.5.5 0 0 1 .5.5zM9 19H4v-1h5zm17-5h2v1h-2zM9 13H4v-1h5zm-2 2H4v-1h3zm1-1h2v1H8zm3 0h2v1h-2zm3 0h2v1h-2zm3 0h2v1h-2zm3 0h2v1h-2zm3 0h2v1h-2zm1 2h4v1h-4zM8 17H4v-1h4zm-4 3h3v1H4zm8-1h-2v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm5 1h2v1h-2zm-3 0h2v1h-2zm-12-3H9v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm1-1h2v1h-2zm-9-3h-2v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm3 0h-2v-1h2zm1-1h3v1h-3zM8 20h14v1H8zm14-2h6v1h-6z"
  }));
};

var _default = KeyboardIcon;
exports["default"] = _default;