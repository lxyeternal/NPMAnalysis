"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FunctionIcon = function FunctionIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.126 9.743L13.797 14h-1.18l-2.193-3.495L7.204 14h-1.36l4.029-4.373L7.597 6h1.181l1.797 2.864L13.215 6h1.36zM3.743 7H6V6H3.887l.358-2.48a1.845 1.845 0 0 1 .81-1.26 1.82 1.82 0 0 1 1.478-.241l.35.092.257-.966-.35-.093a2.84 2.84 0 0 0-3.534 2.32L2.876 6H1v1h1.733l-1.01 7h1.01z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.526 14.696L20.481 21h-1.18l-3.477-5.542L10.718 21h-1.36l5.914-6.42-3.5-5.58h1.181l3.022 4.817L20.413 9h1.36zM5.383 10H9V9H5.536l.535-3.498a3.01 3.01 0 0 1 3.743-2.455l.527.139.254-.967-.526-.139a4.01 4.01 0 0 0-4.986 3.271L4.525 9H2v1h2.372L2.688 21H3.7z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.256 20.06l4.98 7.94h-1.18l-4.502-7.177L14.94 28h-1.36l7.421-8.056L16.647 13h1.18l3.878 6.182L27.4 13h1.36zM8.162 14H13v-1H8.315l.844-5.514a4.263 4.263 0 0 1 5.51-3.417l.304-.953A5.263 5.263 0 0 0 8.17 7.334L7.304 13H4v1h3.15L5.009 28H6.02z"
  }));
};

var _default = FunctionIcon;
exports["default"] = _default;