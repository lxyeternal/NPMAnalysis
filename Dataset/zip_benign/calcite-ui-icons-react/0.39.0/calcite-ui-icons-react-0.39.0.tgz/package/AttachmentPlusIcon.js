"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AttachmentPlusIcon = function AttachmentPlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.68 13.935l-.784.823A3.962 3.962 0 0 1 5 16a4 4 0 0 1-2.868-6.788L10.278.833A2.75 2.75 0 0 1 15 2.75a2.73 2.73 0 0 1-.795 1.934L6.494 12.48a1.75 1.75 0 1 1-2.473-2.474l5.51-5.45.702.71-5.51 5.45a.75.75 0 1 0 1.06 1.061l7.711-7.797a1.75 1.75 0 1 0-2.498-2.45L2.849 9.91a3 3 0 1 0 4.323 4.158l.861-.903a.979.979 0 0 0 .647.77zM13 9h-1v3H9v1h3v3h1v-3h3v-1h-3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 18.999a.974.974 0 0 0 .196.563l-1.79 1.81a5.5 5.5 0 1 1-7.778-7.78L15.185 2.159a4 4 0 0 1 5.63 5.685L10.259 18.276a2.5 2.5 0 0 1-3.526-3.545l8-7.999.706.707-8 8a1.5 1.5 0 0 0 2.116 2.126L20.111 7.132a3 3 0 1 0-4.223-4.263L4.332 14.304a4.5 4.5 0 1 0 6.364 6.364L13 18.338zM19 14h-1v4h-4v.999h4V23h1v-4.001h4V18h-4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18.72 25.943l-1.988 1.93A7.5 7.5 0 0 1 6.167 17.227a33325.456 33325.456 0 0 1 13.458-13.63 5.5 5.5 0 0 1 7.764 7.792L14.99 23.96a3.5 3.5 0 1 1-4.964-4.935L20.448 8.602l.707.707-10.423 10.423a2.5 2.5 0 1 0 3.546 3.525L25.82 11.543l.882-.883a4.5 4.5 0 0 0-6.385-6.342L6.878 17.93a6.5 6.5 0 0 0 9.157 9.227l2.007-1.948a.974.974 0 0 0 .679.734zM25 19h-1v5h-5v.999h5V30h1v-5.001h5V24h-5z"
  }));
};

var _default = AttachmentPlusIcon;
exports["default"] = _default;