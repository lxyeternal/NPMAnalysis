"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MeasureBuildingHeightTopShadowIcon = function MeasureBuildingHeightTopShadowIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 8H5V7h1zm0-4H5v1h1zm0 6H5v1h1zm10 4v1H0v-1h1V1h7v13zM7 2H2v12h5zm-3 8H3v1h1zm0-6H3v1h1zm0 3H3v1h1zm5.244-5l-.276 3.07 1.073-.583 3.06 6.434-1.08.586 2.727 1.44.277-3.071-1.046.568-3.06-6.434 1.052-.57z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2h10v19h11v1H1v-1h1zm1 19h8V3H3zm17.864-.94l.606-2.96-1.13.476-4.706-12.434 1.14-.45L14.27 3l-.674 2.946 1.108-.437 4.715 12.455-1.098.463zM8 5h2v2H8zm-4 7h2v-2H4zm0-5h2V5H4zm0 10h2v-2H4zm4-5h2v-2H8zm0 5h2v-2H8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 6H5v3h3zM7 8H6V7h1zm6 12h-3v3h3zm-1 2h-1v-1h1zm1-9h-3v3h3zm-1 2h-1v-1h1zm1-9h-3v3h3zm-1 2h-1V7h1zm4 21V2H2v27H1v1h30v-1zm-1 0H3V3h12zM8 13H5v3h3zm-1 2H6v-1h1zm1 5H5v3h3zm-1 2H6v-1h1zM19.996 7.034l-1.884.866 1.166-3.902L23 5.652l-2.096.964L28.17 24.1l1.998-.918L29 27.085l-3.722-1.654 1.983-.912z"
  }));
};

var _default = MeasureBuildingHeightTopShadowIcon;
exports["default"] = _default;