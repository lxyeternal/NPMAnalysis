"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ClusteringIcon = function ClusteringIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 6.5A1.502 1.502 0 0 1 13.5 8a1.484 1.484 0 0 1-.535-.103 5.452 5.452 0 0 0-.734-2.188A1.496 1.496 0 0 1 15 6.5zM3.281 4.978A5.533 5.533 0 0 1 4.99 3.613c0-.038.01-.074.01-.113a1.5 1.5 0 1 0-1.719 1.478zm0 7.044A1.497 1.497 0 1 0 5 13.5c0-.039-.009-.075-.011-.113a5.533 5.533 0 0 1-1.708-1.365z",
      opacity: ".15"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.989 13.387a5.463 5.463 0 0 0 .983.392 2.493 2.493 0 1 1-3.29-2.63 5.52 5.52 0 0 0 .6.873A1.497 1.497 0 1 0 5 13.5c0-.039-.009-.075-.011-.113zM2.682 5.852a5.52 5.52 0 0 1 .6-.874A1.497 1.497 0 1 1 5 3.5c0 .039-.009.075-.011.113a5.463 5.463 0 0 1 .983-.392 2.493 2.493 0 1 0-3.29 2.63zM12 8.5A4.5 4.5 0 1 1 7.5 4 4.5 4.5 0 0 1 12 8.5zm-1 0A3.5 3.5 0 1 0 7.5 12 3.504 3.504 0 0 0 11 8.5zM13.5 4a2.483 2.483 0 0 0-1.88.869 5.52 5.52 0 0 1 .61.84 1.504 1.504 0 1 1 .735 2.188A5.529 5.529 0 0 1 13 8.5c0 .15-.01.297-.022.443A2.5 2.5 0 1 0 13.5 4z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 8.5A3.5 3.5 0 1 1 7.5 5 3.504 3.504 0 0 1 11 8.5z",
      opacity: ".3"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 11.5a2.502 2.502 0 0 1-2.5 2.5 2.467 2.467 0 0 1-.756-.13 7.823 7.823 0 0 0 .056-.895 7.74 7.74 0 0 0-.815-3.45A2.475 2.475 0 0 1 19.5 9a2.502 2.502 0 0 1 2.5 2.5zM4.341 17.016a2.494 2.494 0 1 0 2.644 2.634 7.845 7.845 0 0 1-2.644-2.634zm.72-9.085a7.851 7.851 0 0 1 1.766-1.535A2.477 2.477 0 0 0 7 5.5a2.525 2.525 0 1 0-1.94 2.431z",
      opacity: ".15"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.985 19.65a7.756 7.756 0 0 0 .95.496 3.497 3.497 0 1 1-4.093-4.08 7.776 7.776 0 0 0 .5.95 2.494 2.494 0 1 0 2.643 2.634zM4.312 8.98a7.826 7.826 0 0 1 .749-1.05 2.522 2.522 0 1 1 1.766-1.535 7.779 7.779 0 0 1 1.144-.609C7.98 5.691 8 5.598 8 5.5a3.5 3.5 0 1 0-3.688 3.481zM19.5 8a3.475 3.475 0 0 0-2.016.646 7.809 7.809 0 0 1 .501.879A2.475 2.475 0 0 1 19.5 9a2.5 2.5 0 0 1 0 5 2.467 2.467 0 0 1-.756-.13 7.735 7.735 0 0 1-.183.986A3.464 3.464 0 0 0 19.5 15a3.5 3.5 0 0 0 0-7zm-1.7 4.975a6.8 6.8 0 1 1-6.8-6.8 6.8 6.8 0 0 1 6.8 6.8zm-1 .025a5.8 5.8 0 1 0-5.8 5.8 5.807 5.807 0 0 0 5.8-5.8z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.8 13A5.8 5.8 0 1 1 11 7.2a5.807 5.807 0 0 1 5.8 5.8z",
      opacity: ".3"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4 6.5a3.5 3.5 0 0 1 7 0 3.452 3.452 0 0 1-.05.495 10.836 10.836 0 0 0-4.099 2.94A3.502 3.502 0 0 1 4 6.5zM25.5 9a3.475 3.475 0 0 0-2.356.929 10.745 10.745 0 0 1 2.604 6.046A3.492 3.492 0 0 0 25.5 9zM5.515 22.159a3.49 3.49 0 1 0 4.326 4.326 10.876 10.876 0 0 1-4.326-4.326z",
    opacity: ".15"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15 7.2a9.8 9.8 0 1 0 9.8 9.8A9.811 9.811 0 0 0 15 7.2zm0 18.6a8.8 8.8 0 1 1 8.8-8.8 8.81 8.81 0 0 1-8.8 8.8zm-5.159.685c.294.16.597.306.907.44a4.488 4.488 0 1 1-5.673-5.673c.134.31.28.613.44.907a3.49 3.49 0 1 0 4.326 4.326zM3 6.5a4.5 4.5 0 0 1 9 0c0 .047-.012.09-.014.136a10.714 10.714 0 0 0-1.036.36A3.452 3.452 0 0 0 11 6.5a3.5 3.5 0 1 0-4.149 3.434q-.353.408-.666.848A4.483 4.483 0 0 1 3 6.5zm27 6a4.485 4.485 0 0 1-4.202 4.47c0-.336-.02-.667-.05-.995a3.491 3.491 0 1 0-2.604-6.046q-.329-.378-.69-.724A4.486 4.486 0 0 1 30 12.5z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M23.8 17A8.8 8.8 0 1 1 15 8.2a8.81 8.81 0 0 1 8.8 8.8z",
    opacity: ".3"
  }));
};

var _default = ClusteringIcon;
exports["default"] = _default;