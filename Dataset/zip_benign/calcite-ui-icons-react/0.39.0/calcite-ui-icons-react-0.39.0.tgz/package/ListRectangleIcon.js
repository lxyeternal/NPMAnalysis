"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListRectangleIcon = function ListRectangleIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.5 16a1.502 1.502 0 0 0 1.5-1.5v-12A1.502 1.502 0 0 0 13.5 1h-11A1.502 1.502 0 0 0 1 2.5v12A1.502 1.502 0 0 0 2.5 16zM2 2.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 .5.5V6H2zM11 8v1H5V8zm-9 6.5V11h12v3.5a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5zm9-.5H5v-1h6zM5 3h6v1H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.5 2h-17A1.502 1.502 0 0 0 2 3.5v18A1.502 1.502 0 0 0 3.5 23h17a1.502 1.502 0 0 0 1.5-1.5v-18A1.502 1.502 0 0 0 20.5 2zm.5 19.5a.5.5 0 0 1-.5.5h-17a.5.5 0 0 1-.5-.5V16h18zM8 13v-1h8v1zM3 9V3.5a.5.5 0 0 1 .5-.5h17a.5.5 0 0 1 .5.5V9zm5-4h8v1H8zm8 15H8v-1h8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 7h10v1H11zm10 18H11v1h10zm8-20.5v24a1.502 1.502 0 0 1-1.5 1.5h-23A1.502 1.502 0 0 1 3 28.5v-24A1.502 1.502 0 0 1 4.5 3h23A1.502 1.502 0 0 1 29 4.5zM28 21H4v7.5a.5.5 0 0 0 .5.5h23a.5.5 0 0 0 .5-.5zm-7-4v-1H11v1zm7-5V4.5a.5.5 0 0 0-.5-.5h-23a.5.5 0 0 0-.5.5V12z"
  }));
};

var _default = ListRectangleIcon;
exports["default"] = _default;