"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HeadsetIcon = function HeadsetIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.954 14.147A1.498 1.498 0 0 0 8.5 13h-1a1.5 1.5 0 0 0 0 3h1a1.494 1.494 0 0 0 1.275-.72c2.032-.528 3.336-2.045 3.9-4.535l.925-.695a1.005 1.005 0 0 0 .4-.8v-1.5a1.007 1.007 0 0 0-.4-.8l-.688-.516A6.17 6.17 0 0 0 8 1a6.227 6.227 0 0 0-5.982 6H1v1h2v-.5A5.274 5.274 0 0 1 8 2a5.106 5.106 0 0 1 4.81 4.018 1.01 1.01 0 0 0-.258.087A.995.995 0 0 0 12 7v3a.995.995 0 0 0 .552.895c.012.005.025.003.036.008a4.468 4.468 0 0 1-2.634 3.244zM7 14.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zM13 7l1 .75v1.5L13 10z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.004 9.783l-1.297-.773c-.01-.006-.022-.009-.033-.014A8.968 8.968 0 0 0 12 1.2 9.04 9.04 0 0 0 3.213 10H2v1h2.2v-.5A8.07 8.07 0 0 1 12 2.2a7.957 7.957 0 0 1 7.66 6.762c-.03.014-.06.02-.09.036a1.135 1.135 0 0 0-.57.982v4.767a1.125 1.125 0 0 0 .402.854 8.04 8.04 0 0 1-5.483 5.434A1.495 1.495 0 0 0 12.5 20h-1a1.5 1.5 0 0 0 0 3h1a1.5 1.5 0 0 0 1.383-.92 9.027 9.027 0 0 0 6.492-6.236 1.103 1.103 0 0 0 .333-.126l1.284-.766A1.903 1.903 0 0 0 23 13.271v-1.813a1.9 1.9 0 0 0-.996-1.675zM11 21.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm11-8.23a.916.916 0 0 1-.499.811l-1.307.778a.13.13 0 0 1-.194-.112V9.98a.13.13 0 0 1 .064-.112.132.132 0 0 1 .066-.017.133.133 0 0 1 .066.018l1.305.778.02.012a.904.904 0 0 1 .479.799z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.76 12.716l-1.207-.605a1.057 1.057 0 0 0-.263-.09C26.125 6.69 22.513 2.201 16 2.201 7.906 2.2 4.084 9.13 4.084 16H3v1h2.132c-.027-.33-.048-.663-.048-1a14.703 14.703 0 0 1 2.72-8.871A9.89 9.89 0 0 1 16 3.2c5.956 0 9.26 4.163 10.326 9.108a1.074 1.074 0 0 0-.325.762v5.86a1.07 1.07 0 0 0 .215.628 11.247 11.247 0 0 1-7.651 7.886A1.495 1.495 0 0 0 17.5 27h-2a1.5 1.5 0 0 0 0 3h2a1.5 1.5 0 0 0 1.5-1.5c0-.047-.01-.092-.014-.138a12.252 12.252 0 0 0 8.138-8.367 1.06 1.06 0 0 0 .429-.106l1.206-.605A2.23 2.23 0 0 0 30 17.276v-2.552a2.232 2.232 0 0 0-1.24-2.008zM17.5 29h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 0 1zM29 17.276a1.237 1.237 0 0 1-.688 1.114l-1.207.604-.103-.064v-5.86l.103-.064 1.208.604A1.238 1.238 0 0 1 29 14.724z"
  }));
};

var _default = HeadsetIcon;
exports["default"] = _default;