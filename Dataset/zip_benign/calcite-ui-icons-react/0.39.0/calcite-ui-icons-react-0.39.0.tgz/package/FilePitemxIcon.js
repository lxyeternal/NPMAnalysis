"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FilePitemxIcon = function FilePitemxIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 11h-2v-1h2zm-9 2h4v-1H4zm9-1h-2v1h2zm-6-2H4v1h3zM4 9h5V8H4zm9-3h-2v1h2zM4 2h5v5H4zm3.522 2.385a2.895 2.895 0 0 1-.403.627 3.707 3.707 0 0 1-.706.707c-.058.043-.34.169-.574.281H8V3.703a1.455 1.455 0 0 0-.478.682zM5 5.32a1.68 1.68 0 0 1 .178-.098 2.745 2.745 0 0 0 1.117-.77 8.143 8.143 0 0 0 .537-1.027A1.626 1.626 0 0 1 7.241 3H5zM15 16H2V0h9.4L15 3.6zM14 5h-4V1H3v14h11zm0-1.31L11.31 1H11v3h3zM13 8h-2v1h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 13h8v1H5zm0 7h7v-1H5zM15.29 1L21 6.709V23H3V1zM20 8h-6V2H4v20h16zm0-1.2L15.2 2H15v5h5zM19 19h-4v1h4zM5 3h8v8H5zm7 5.162a1.253 1.253 0 0 1-.13.32.913.913 0 0 1-.584.376c-.081.02-.221.018-.318.045.022.019-.002.1-.005.215-.009.297-.038.585-.035.882H12zM9.815 6.044a4.656 4.656 0 0 1-.537-.047l-.054-.01a2.247 2.247 0 0 0-.226.52 2.087 2.087 0 0 1-.642 1.071 1.61 1.61 0 0 1 .544.893 3.31 3.31 0 0 1 .005 1.213A1.543 1.543 0 0 0 8.92 10h1.102c-.036-.685-.213-1.783.567-2.03.138-.045.36-.02.46-.12.106-.106.153-.432.254-.567A1.333 1.333 0 0 1 12 6.81V4h-1.023l.005.943a1.188 1.188 0 0 1-.114.585 1.083 1.083 0 0 1-1.053.516zM6 10h2.033a1.89 1.89 0 0 1-.021-.434 2.687 2.687 0 0 0 .023-.833c-.053-.192-.265-.35-.512-.533-.08-.06-.16-.119-.238-.181L7.15 7.91l-.087-.228a.594.594 0 0 1 .11-.487 1.203 1.203 0 0 1 .463-.351 1.007 1.007 0 0 0 .106-.057 1.325 1.325 0 0 0 .31-.605 2.703 2.703 0 0 1 .42-.86.935.935 0 0 1 .332-.266 1.04 1.04 0 0 1 .613-.05 2.186 2.186 0 0 0 .386.038.617.617 0 0 0 .194-.02c-.014-.008.085-.052.085-.075L10.009 4H6zm5 6H5v1h6zm8-6h-4v1h4zm0 3h-4v1h4zm0 3h-4v1h4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5 2v28h22V9.699L19.3 2zm21 27H6V3h12v8h8zm-7-19V3l7 7zm-5 14H8v-1h6zm-6-4h9v1H8zm0-3h9v1H8zm16 1h-5v-1h5zm0-3h-5v-1h5zm0 6h-5v-1h5zm0 3h-5v-1h5zM8 26h8v1H8zm16 1h-5v-1h5zM8 14h9V5H8zm8-1h-1.072c-.003-.297.026-.585.035-.882.003-.114.027-.196.005-.215.097-.027.237-.026.318-.045a.913.913 0 0 0 .584-.377 1.253 1.253 0 0 0 .13-.32zm-1.658-7H16v3.81a1.333 1.333 0 0 0-.697.473c-.101.135-.148.461-.254.567-.1.1-.322.075-.46.12-.78.247-.603 1.345-.567 2.03H11.92a1.543 1.543 0 0 1-.015-.316 3.31 3.31 0 0 0-.005-1.213 1.61 1.61 0 0 0-.544-.893 2.087 2.087 0 0 0 .642-1.07 2.247 2.247 0 0 1 .226-.52.418.418 0 0 1 .054.01 4.049 4.049 0 0 0 .502.046 1.576 1.576 0 0 0 1.262-.492c.308-.401-.137-1.106-.157-1.52s.308-.756.457-1.032zM9 6h4.135a1.599 1.599 0 0 0-.3.642q-.002.024-.002.049c0 .244.305.513.305.762 0 .269.054.455-.144.56l-.032.011a.617.617 0 0 1-.193.02 1.819 1.819 0 0 1-.352-.038 1.04 1.04 0 0 0-.613.05.935.935 0 0 0-.331.265 2.703 2.703 0 0 0-.42.86 1.325 1.325 0 0 1-.31.606 1.007 1.007 0 0 1-.107.057 1.203 1.203 0 0 0-.463.351.594.594 0 0 0-.11.487l.087.228.135.109c.078.062.158.122.238.181.247.183.46.341.512.533a2.687 2.687 0 0 1-.023.833 1.89 1.89 0 0 0 .02.434H9z"
  }));
};

var _default = FilePitemxIcon;
exports["default"] = _default;