"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CompactnessIcon = function CompactnessIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 6V3H4.69a6.039 6.039 0 0 0-1.15 1H7v2H5v3H2.09a5.936 5.936 0 0 0 .26 1h2.995L9 12.496v1.414a5.936 5.936 0 0 0 1-.26V10h3.65a5.936 5.936 0 0 0 .26-1H13V6h-2V2.812a5.968 5.968 0 0 0-1-.462V6zm4 1v2H9v2.285l-3-2.05V7zm-4 8.969a8.67 8.67 0 0 1-.428-.011l.051-.937a7.016 7.016 0 0 0 2.597-.347l.297.89A7.956 7.956 0 0 1 8 15.968zm-2.38-.363a7.917 7.917 0 0 1-2.621-1.402l.59-.73a6.974 6.974 0 0 0 2.31 1.238zm6.688-.9l-.508-.789a7.039 7.039 0 0 0 1.903-1.804l.76.55a7.979 7.979 0 0 1-2.155 2.042zm-10.689-1.93a7.893 7.893 0 0 1-1.307-2.669l.905-.247a6.957 6.957 0 0 0 1.152 2.353zm13.799-1.857l-.873-.344A6.982 6.982 0 0 0 15.031 8a5.25 5.25 0 0 0-.004-.251l.938-.031c.003.095.005.19.004.287a7.935 7.935 0 0 1-.551 2.914zM.032 8.144V8a7.96 7.96 0 0 1 .5-2.787l.88.328A6.994 6.994 0 0 0 .968 8v.123zM14.748 6.02a6.952 6.952 0 0 0-1.194-2.332l.74-.577a7.924 7.924 0 0 1 1.354 2.645zM2.225 3.988l-.77-.535a7.955 7.955 0 0 1 2.12-2.081l.52.779a7.02 7.02 0 0 0-1.87 1.837zm10.09-1.54a6.988 6.988 0 0 0-2.333-1.196l.264-.9a7.935 7.935 0 0 1 2.645 1.356zM5.66 1.367L5.35.483A7.93 7.93 0 0 1 7.996.03a1.016 1.016 0 0 0 .29.006l-.035.936L8 .97h-.004a6.992 6.992 0 0 0-2.335.398z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19 14v-4h-3V4.45a8.92 8.92 0 0 0-1-.425V10h-3V6H5.792a9.064 9.064 0 0 0-.9 1H11v3H8v5H3.36a8.93 8.93 0 0 0 .348 1h5.157L14 18.996v2.272a8.896 8.896 0 0 0 1-.293V15h5.64a8.92 8.92 0 0 0 .225-1zm-1 0h-4v3.838L9.135 15H9v-4h9zm-5.982 9.459l-.002-.916a10.05 10.05 0 0 0 2.596-.344l.239.885a11.011 11.011 0 0 1-2.833.375zm-1.9-.162a10.904 10.904 0 0 1-2.73-.854l.385-.83a9.995 9.995 0 0 0 2.5.782zm6.526-.869l-.39-.829a10.05 10.05 0 0 0 2.207-1.411l.59.7a10.96 10.96 0 0 1-2.407 1.54zm-10.91-.938a11.046 11.046 0 0 1-2.111-1.926l.7-.59a10.113 10.113 0 0 0 1.936 1.765zm14.664-1.952l-.7-.589a10.052 10.052 0 0 0 1.407-2.208l.83.386a10.975 10.975 0 0 1-1.537 2.411zM2.523 18.005a10.933 10.933 0 0 1-1.102-2.638l.885-.24a10.011 10.011 0 0 0 1.008 2.417zm20.065-2.671l-.885-.237a10.08 10.08 0 0 0 .339-2.597 10.199 10.199 0 0 0-.162-1.81l.9-.162a11.03 11.03 0 0 1-.192 4.805zM1.087 13.489a11.05 11.05 0 0 1-.045-.989 10.968 10.968 0 0 1 .16-1.866l.902.157a10.035 10.035 0 0 0-.146 1.709c0 .305.014.608.041.906zm1.46-4.39l-.86-.31a10.959 10.959 0 0 1 1.311-2.54l.752.522A10.089 10.089 0 0 0 2.548 9.1zm18.87-.094a10.024 10.024 0 0 0-1.224-2.314l.746-.53a10.936 10.936 0 0 1 1.337 2.526zM4.871 5.428l-.65-.646a11.08 11.08 0 0 1 2.258-1.75l.462.79a10.096 10.096 0 0 0-2.07 1.606zm14.189-.07a10.037 10.037 0 0 0-2.085-1.584l.453-.795a10.916 10.916 0 0 1 2.276 1.729zM8.52 3.078l-.316-.86a10.89 10.89 0 0 1 2.79-.63l.081.912a9.953 9.953 0 0 0-2.555.577zm6.865-.036a9.96 9.96 0 0 0-2.56-.55l.074-.914a10.904 10.904 0 0 1 2.794.602z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26 18v-7h-4V5.624q-.486-.283-1-.519V11h-5V7H8.09a12.094 12.094 0 0 0-1.01 1H15v3h-4v9H4.7c.121.34.255.674.405 1h6.579L19 25.442v2.163q.51-.132 1-.305V19h7.605q.128-.493.214-1zm-1 0h-6v6.272l-7-4.25V12h13zm-8.999 12q-.935-.036-1.793-.156l.137-.99c.54.075 1.104.124 1.675.146.39 0 .793-.019 1.193-.056l.092.996c-.429.039-.865.06-1.304.06zm3.34-.401l-.237-.972a12.918 12.918 0 0 0 2.699-.99l.447.894a13.94 13.94 0 0 1-2.908 1.068zm-7.148-.162a14.442 14.442 0 0 1-2.884-1.115l.46-.887a13.397 13.397 0 0 0 2.684 1.037zm11.831-1.964l-.574-.82a13.116 13.116 0 0 0 2.16-1.899l.739.674a14.126 14.126 0 0 1-2.325 2.045zM7.551 27.23a13.004 13.004 0 0 1-2.264-2.125l.768-.642a11.987 11.987 0 0 0 2.088 1.961zm20.075-3.427l-.83-.558a12.968 12.968 0 0 0 1.331-2.55l.932.362a13.922 13.922 0 0 1-1.433 2.746zm-23.54-.386a13.868 13.868 0 0 1-1.284-2.818l.949-.313a12.902 12.902 0 0 0 1.193 2.616zm25.575-4.34l-.976-.218A13.116 13.116 0 0 0 29 16l1-.06V16a14.146 14.146 0 0 1-.339 3.078zm-27.363-.481a14.897 14.897 0 0 1-.228-2.597c0-.162.003-.324.008-.486l1 .031c-.005.152-.008.304-.008.455a13.961 13.961 0 0 0 .212 2.423zm26.554-4.567a12.97 12.97 0 0 0-.747-2.777l.932-.365a13.995 13.995 0 0 1 .803 2.991zM3.273 13.63l-.986-.171a14.459 14.459 0 0 1 .85-2.975l.925.376a13.46 13.46 0 0 0-.789 2.77zm24.003-4.106a13.172 13.172 0 0 0-1.702-2.319l.737-.677a14.171 14.171 0 0 1 1.83 2.496zm-22.361-.38l-.86-.51A13.199 13.199 0 0 1 5.942 6.17l.717.697a12.215 12.215 0 0 0-1.743 2.277zm19.262-3.252a13.065 13.065 0 0 0-2.422-1.553l.443-.896a14.097 14.097 0 0 1 2.608 1.671zm-16.08-.284L7.5 4.805a13.473 13.473 0 0 1 2.687-1.546l.396.918a12.516 12.516 0 0 0-2.487 1.43zm11.878-1.99a12.955 12.955 0 0 0-2.819-.568l.088-.996a13.982 13.982 0 0 1 3.035.613zm-7.577-.076l-.263-.964a16.73 16.73 0 0 1 3.033-.528l.082.997a15.705 15.705 0 0 0-2.852.495z"
  }));
};

var _default = CompactnessIcon;
exports["default"] = _default;