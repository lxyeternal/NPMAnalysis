"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HeavyRainIcon = function HeavyRainIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 11.132L13.722 16h-1.104l2.339-5H16zM6.917 13H3.5a2.473 2.473 0 0 1-2.465-2.888 2.224 2.224 0 0 1 0-3.758 1.982 1.982 0 0 1 2.428-2.295 2.48 2.48 0 0 1 3.977-.118 3.978 3.978 0 0 1 6.49 2.371 3.5 3.5 0 0 1 2.004 2.544 1.497 1.497 0 0 0-.988.276 2.487 2.487 0 0 0-1.425-1.908l-.484-.218-.092-.522a2.989 2.989 0 0 0-5.857-.17l-.233.992-.987-.252A1.462 1.462 0 0 0 4.03 8.227l-.124.677-.678.125A1.498 1.498 0 0 0 3.5 12h3.885zM3.046 8.046a2.462 2.462 0 0 1 3.069-1.96 3.987 3.987 0 0 1 .643-1.397 1.491 1.491 0 0 0-2.48-.052l-.39.551-.657-.156A1.013 1.013 0 0 0 3 5a.98.98 0 0 0-.98 1.177l.118.66-.564.36a1.214 1.214 0 0 0-.161 1.943 2.498 2.498 0 0 1 1.633-1.094zM9.618 16h1.104l1.404-3h-1.104zm-9 0h1.104l.936-2H1.554zm3 0h1.104l.936-2H4.554zm5.807-6l-2.807 6h1.104l2.808-6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.38 23H2.277l1.871-4h1.105zm3.936-2l.936-2H7.147l-.935 2zm2.831-2l-1.87 4H9.38l1.871-4zm2.364-1H5.438A3.438 3.438 0 0 1 2 14.562c0-.035.01-.068.01-.103a3.05 3.05 0 0 1 .414-4.848 2.725 2.725 0 0 1 3.337-3.155 3.41 3.41 0 0 1 5.466-.166 5.48 5.48 0 0 1 8.723 2.43 4.755 4.755 0 0 1 2.922 5.537 1.44 1.44 0 0 0-.908-.7c.012-.123.037-.243.037-.368a3.789 3.789 0 0 0-2.418-3.54l-.429-.169-.15-.436a4.494 4.494 0 0 0-8.629.426l-.232.99-.986-.25a2.407 2.407 0 0 0-.594-.084 2.443 2.443 0 0 0-2.206 1.42l-.268.581h-.715A2.437 2.437 0 0 0 5.437 17h7.542zm-9.549-7.546a2.038 2.038 0 0 0-.685 2.757 3.437 3.437 0 0 1 3.16-2.086l.012.001A3.369 3.369 0 0 1 9.4 9.24a5.478 5.478 0 0 1 1.124-2.235 2.42 2.42 0 0 0-3.948.03l-.39.55-.657-.156a1.725 1.725 0 0 0-2.155 1.696 1.775 1.775 0 0 0 .033.31l.118.659zM17.72 18h-1.105l-2.339 5h1.105zm3.936-2H20.55l-2.34 5h1.105zm-9.912 6h1.105l3.274-7H15.02z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5.787 31H4.682l2.34-5h1.104zm4.234-5l-1.403 3h1.104l1.404-3zm3 0l-2.339 5h1.105l2.339-5zm3 0l-2.339 5h1.105l2.339-5zM2 19.62a3.953 3.953 0 0 1 1.053-6.094A3.954 3.954 0 0 1 3 13a3.964 3.964 0 0 1 4.72-3.927 4.465 4.465 0 0 1 7.182-.489 7.486 7.486 0 0 1 11.791 3.803 6.495 6.495 0 0 1 1.57 11.407l.319-.682a1.488 1.488 0 0 0 .081-1.029 5.485 5.485 0 0 0-2.308-8.754l-.478-.172-.143-.488a6.497 6.497 0 0 0-12.612.586l-.18.935-1.01-.145A3.172 3.172 0 0 0 11.5 14a3.498 3.498 0 0 0-3.285 2.344l-.223.633-.67.034a3.5 3.5 0 0 0-3.271 4.098A3.621 3.621 0 0 0 7.672 24h11.181l-.468 1H7.672a4.614 4.614 0 0 1-4.608-3.727 4.669 4.669 0 0 1-.057-.824A3.987 3.987 0 0 1 2 19.62zm1.543-5.222a2.965 2.965 0 0 0-.391 4.947 4.5 4.5 0 0 1 4.12-3.333A4.487 4.487 0 0 1 11.5 13a4.46 4.46 0 0 1 .64.065 7.483 7.483 0 0 1 2.016-3.818 3.468 3.468 0 0 0-5.595.367l-.362.563-.658-.12A2.965 2.965 0 0 0 4 13a2.066 2.066 0 0 0 .03.29l.103.776zM22.465 21h-1.104l-4.21 9h1.104zm-1.678 10l2.807-6h-1.105l-2.807 6zm6.743-8h-1.105l-2.807 6h1.105z"
  }));
};

var _default = HeavyRainIcon;
exports["default"] = _default;