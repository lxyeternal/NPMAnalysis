"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DataMagnifyingGlassIcon = function DataMagnifyingGlassIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 11.48V7.905a10.957 10.957 0 0 0 5.23 1.07 4.316 4.316 0 0 1 .728-1.011c-.156.003-.294.014-.458.014-3.839 0-5.5-.993-5.5-1.5V4.906A11.283 11.283 0 0 0 7.5 5.98 11.283 11.283 0 0 0 13 4.906V6.48c0 .146-.156.333-.444.524A4.302 4.302 0 0 1 14 7.93V3.48c0-1.495-2.612-2.5-6.5-2.5S1 1.984 1 3.48v8c0 1.496 2.612 2.5 6.5 2.5.138 0 .27-.004.405-.006A4.31 4.31 0 0 1 7.2 12.97c-3.613-.053-5.2-.998-5.2-1.49zm5.5-9.5c3.839 0 5.5.993 5.5 1.5s-1.661 1.5-5.5 1.5S2 3.985 2 3.48s1.661-1.5 5.5-1.5zm8.268 13.08l-2.398-2.397a2.912 2.912 0 1 0-.707.707l2.398 2.398a.5.5 0 0 0 .707-.707zM9.1 11a1.9 1.9 0 1 1 1.9 1.9A1.902 1.902 0 0 1 9.1 11z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.576 19.92H11.5c-5.267 0-8.5-1.363-8.5-2.34v-6.007c1.638 1.095 5.061 1.665 8.469 1.669a6.036 6.036 0 0 1 .822-1.012c-.26.007-.521.012-.791.012-5.188 0-8.5-1.275-8.5-2.153V6.411C4.643 7.457 8.082 8 11.5 8s6.857-.543 8.5-1.589v3.678c0 .291-.37.625-1.045.942a5.995 5.995 0 0 1 1 .571l.045-.03v.064a6.04 6.04 0 0 1 1 .908V5c0-1.97-4.78-3-9.5-3S2 3.03 2 5v12.58c0 2.193 4.78 3.34 9.5 3.34.314 0 .627-.005.94-.015a6.041 6.041 0 0 1-.864-.985zM11.5 3C17 3 20 4.321 20 5s-3 2-8.5 2S3 5.679 3 5s3-2 8.5-2zm11.511 19.314l-3.085-3.085a4.451 4.451 0 1 0-.69.691l3.085 3.084a.476.476 0 0 0 .673 0l.017-.016a.476.476 0 0 0 0-.674zm-9.91-5.814a3.4 3.4 0 1 1 3.4 3.4 3.404 3.404 0 0 1-3.4-3.4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.5 26.83C8.723 26.83 4 25.068 4 23.49v-7.987c1.873 1.456 6.122 2.283 10.397 2.405a7.308 7.308 0 0 1 .556-.992C8.156 16.825 4 15.086 4 13.825V8.624c2.011 1.498 6.774 2.276 11.5 2.276s9.489-.778 11.5-2.276v5.2c0 .448-.534.956-1.513 1.43a7.355 7.355 0 0 1 .795.721 5.428 5.428 0 0 0 .718-.472v1.35a7.27 7.27 0 0 1 1 2.091V7.096h-.015C27.987 7.063 28 7.033 28 7c0-2.56-6.288-3.9-12.5-3.9S3 4.44 3 7c0 .033.013.063.015.096H3v16.393c0 2.82 6.44 4.34 12.5 4.34.889 0 1.784-.037 2.668-.101a7.292 7.292 0 0 1-1.567-.917c-.362.01-.727.018-1.101.018zm0-22.73C22.625 4.1 27 5.79 27 7s-4.375 2.9-11.5 2.9S4 8.21 4 7s4.375-2.9 11.5-2.9zm14.511 25.214l-4.578-4.578a5.812 5.812 0 1 0-.69.69l4.578 4.578a.476.476 0 0 0 .672.001l.017-.017a.476.476 0 0 0 .001-.674zM16.2 21a4.8 4.8 0 1 1 4.8 4.8 4.806 4.806 0 0 1-4.8-4.8z"
  }));
};

var _default = DataMagnifyingGlassIcon;
exports["default"] = _default;