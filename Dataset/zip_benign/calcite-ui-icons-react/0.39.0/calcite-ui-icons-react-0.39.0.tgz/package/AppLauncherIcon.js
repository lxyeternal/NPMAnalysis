"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AppLauncherIcon = function AppLauncherIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.5 2A1.5 1.5 0 1 1 2 .5 1.5 1.5 0 0 1 3.5 2zM8 .5A1.5 1.5 0 1 0 9.5 2 1.5 1.5 0 0 0 8 .5zm6 3A1.5 1.5 0 1 0 12.5 2 1.5 1.5 0 0 0 14 3.5zm-12 3A1.5 1.5 0 1 0 3.5 8 1.5 1.5 0 0 0 2 6.5zm6 0A1.5 1.5 0 1 0 9.5 8 1.5 1.5 0 0 0 8 6.5zm6 0A1.5 1.5 0 1 0 15.5 8 1.5 1.5 0 0 0 14 6.5zm-12 6A1.5 1.5 0 1 0 3.5 14 1.5 1.5 0 0 0 2 12.5zm6 0A1.5 1.5 0 1 0 9.5 14 1.5 1.5 0 0 0 8 12.5zm6 0a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.5 4A1.5 1.5 0 1 1 4 2.5 1.5 1.5 0 0 1 5.5 4zM12 2.5A1.5 1.5 0 1 0 13.5 4 1.5 1.5 0 0 0 12 2.5zm8 0A1.5 1.5 0 1 0 21.5 4 1.5 1.5 0 0 0 20 2.5zm-16 8A1.5 1.5 0 1 0 5.5 12 1.5 1.5 0 0 0 4 10.5zm8 0a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5zm8 0a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5zm-16 8A1.5 1.5 0 1 0 5.5 20 1.5 1.5 0 0 0 4 18.5zm8 0a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5zm8 0a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17.5 16a1.5 1.5 0 1 1-1.5-1.5 1.5 1.5 0 0 1 1.5 1.5zM6 17.5A1.5 1.5 0 1 0 4.5 16 1.5 1.5 0 0 0 6 17.5zM7.5 26A1.5 1.5 0 1 0 6 27.5 1.5 1.5 0 0 0 7.5 26zm8.5-1.5a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5zm10 0a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5zm0-10a1.5 1.5 0 1 0 1.5 1.5 1.5 1.5 0 0 0-1.5-1.5zm0-10A1.5 1.5 0 1 0 27.5 6 1.5 1.5 0 0 0 26 4.5zm-20 3A1.5 1.5 0 1 0 4.5 6 1.5 1.5 0 0 0 6 7.5zm10-3A1.5 1.5 0 1 0 17.5 6 1.5 1.5 0 0 0 16 4.5z"
  }));
};

var _default = AppLauncherIcon;
exports["default"] = _default;