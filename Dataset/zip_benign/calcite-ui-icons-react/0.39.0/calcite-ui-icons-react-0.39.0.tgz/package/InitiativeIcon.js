"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var InitiativeIcon = function InitiativeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.595 16L8 7.236V5.227c.464-.486 1.104-.326 2.287.127 1.184.453 2.66 1.015 3.63-.44L14 4.786V.633l-.788.555c-.805.569-1.732.258-2.713-.073A3.365 3.365 0 0 0 7.674 1H7v7.39L.405 16zM10.18 2.063a4.727 4.727 0 0 0 2.82.328v2.083c-.468.586-1.103.425-2.356-.055a5.749 5.749 0 0 0-1.954-.496 2.004 2.004 0 0 0-.69.115V1.984c.503-.45 1.145-.268 2.18.08zM13.405 15H2.595L8 8.764z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.626 22L12 10.255V7.627c.941-1.056 1.8-.721 3.223-.015 1.294.643 2.904 1.444 4.59.091l.187-.15V2.329l-.791.568c-1.084.778-2.169.283-3.422-.288l-.13-.06c-1.021-.463-2.35-1.043-3.657-.359V2h-1v9.36L1.374 22zM15.243 3.459l.13.059A4.781 4.781 0 0 0 19 4.13v2.933c-1.114.753-2.148.242-3.359-.36a5.55 5.55 0 0 0-2.367-.76A2.38 2.38 0 0 0 12 6.308V3.383c.949-.868 1.872-.545 3.243.076zM20.373 21H3.627L12 11.745z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29.487 29L16 13.264V9.016c1.484-1.673 2.532-1.07 4.096-.156 1.463.854 3.282 1.916 5.652.564L26 9.279V3.026l-.793.575c-1.374.996-2.663.304-4.156-.492-1.527-.815-3.23-1.72-5.051-.581V2h-1v12.43L2.513 29zM20.58 3.991c1.34.716 2.837 1.514 4.42.866V8.69c-1.736.862-3.032.106-4.4-.692a5.738 5.738 0 0 0-2.765-1.036A2.949 2.949 0 0 0 16 7.64V3.777c1.561-1.397 2.963-.65 4.58.214zM27.313 28H4.687L16 14.8z"
  }));
};

var _default = InitiativeIcon;
exports["default"] = _default;