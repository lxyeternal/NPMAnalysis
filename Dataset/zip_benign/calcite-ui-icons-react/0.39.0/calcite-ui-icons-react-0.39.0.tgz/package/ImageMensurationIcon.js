"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImageMensurationIcon = function ImageMensurationIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.5 3.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zM16 11H4V1h12zm-1-3.11a1.004 1.004 0 0 1-.238-.17l-1.57-1.515-.689.46a1.268 1.268 0 0 1-1.64-.043l-1.5-1.334L7.83 6.924a1.28 1.28 0 0 1-.93.405 1.244 1.244 0 0 1-.23-.022L5 9.09V10h10zM15 2H5v5.627L6.3 6.24a.27.27 0 0 1 .4 0 .27.27 0 0 0 .4 0l2.017-2.152a.27.27 0 0 1 .381-.018l2.03 1.804a.269.269 0 0 0 .35.01l1.226-.824a.27.27 0 0 1 .37.028L15 6.56zm1.058 11.5L14 11.824V13H6v-1.176L3.942 13.5 6 15.176V14h8v1.176zM3.176 3L1.5.942 0 2.784V3h1v6H0v.216l1.5 1.842L3.176 9H2V3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 17h17V3H6zm16-1H7v-3.386l1.771-1.771a1.38 1.38 0 0 0 1.402-.334l2.288-2.29 2.27 1.892a1.376 1.376 0 0 0 1.708.043l1.245-.933L22 12.681zm0-12v7.399l-4.035-3.234a.377.377 0 0 0-.493-.035l-1.633 1.225a.377.377 0 0 1-.468-.012l-2.706-2.256a.377.377 0 0 0-.509.023L9.466 9.8a.377.377 0 0 1-.533 0 .377.377 0 0 0-.533 0L7 11.2V4zm-6.5 1.521v-.043a.979.979 0 0 1 .979-.978A1.021 1.021 0 0 1 17.5 5.521a.979.979 0 0 1-.979.979h-.043a.981.981 0 0 1-.978-.979zM21 18.824l2.058 1.676L21 22.176V21H8v1.176L5.942 20.5 8 18.824V20h13zM3 5v10h1.176L2.5 17.058.824 15H2V5H.824L2.5 2.942 4.176 5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 22V4H8v18zm-1-1H9v-3.759l3.239-3.11.297.14a1 1 0 0 0 1.072-.14l3.89-3.289s2.36 2.08 3.216 2.816a1 1 0 0 0 1.336-.03l1.817-1.708L29 16.5zM9 5h20v10.265l-4.747-4.402a.49.49 0 0 0-.695-.024l-2.193 2.06c-.851-.731-3.53-3.098-3.53-3.098a.49.49 0 0 0-.643-.01l-4.23 3.576-.62-.293a.481.481 0 0 0-.538.088L9 15.855zm13.5 3.8a1.3 1.3 0 1 0-1.3-1.3 1.301 1.301 0 0 0 1.3 1.3zm-.359-1.659a.507.507 0 1 1 0 .717.508.508 0 0 1 0-.717zM28 29.191V27H10v2.19L6.942 26.5 10 23.81V26h18v-2.19l3.058 2.69zM4 6v14h2.19L3.5 23.058.81 20H3V6H.81L3.5 2.942 6.19 6z"
  }));
};

var _default = ImageMensurationIcon;
exports["default"] = _default;