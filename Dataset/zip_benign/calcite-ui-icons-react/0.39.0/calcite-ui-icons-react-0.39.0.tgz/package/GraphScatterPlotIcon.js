"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GraphScatterPlotIcon = function GraphScatterPlotIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.5 9.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm2-4a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm-6 3a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm-2 4a1 1 0 1 0-1-1 1 1 0 0 0 1 1zM16 16v-1H2V1H1v15z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19.5 4.5a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm-2 5a1 1 0 1 0 1-1 1 1 0 0 0-1 1zm-10 8a1 1 0 1 0-1 1 1 1 0 0 0 1-1zm5-2a1 1 0 1 0 1-1 1 1 0 0 0-1 1zm0-8a1 1 0 1 0 1 1 1 1 0 0 0-1-1zM2 1H1v22h22v-1H2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24.5 4.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm-1 9a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm-1 8a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm-6-6a1 1 0 1 0 1-1 1 1 0 0 0-1 1zm-6 3a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm3 6a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm-7 3a1 1 0 1 0-1-1 1 1 0 0 0 1 1zm10-18a1 1 0 1 0-1-1 1 1 0 0 0 1 1zM3 2H2v28h28v-1H3z"
  }));
};

var _default = GraphScatterPlotIcon;
exports["default"] = _default;