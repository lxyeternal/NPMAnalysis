"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LeftRightIcon = function LeftRightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.5.809l2.81 2.809-.708.707L5 2.723V5.25a4.233 4.233 0 0 0 .532 2.037l-.734.733A5.24 5.24 0 0 1 4 5.25V2.723L2.398 4.325l-.707-.707zM8.646 6.69L5.837 9.5l2.81 2.81.706-.708-1.6-1.6L10.506 10A2.508 2.508 0 0 1 13 12.505V14h1v-1.495a3.506 3.506 0 0 0-3.491-3.5l-2.76-.003 1.605-1.604z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.302 11.515l-.712.712A7.605 7.605 0 0 1 6 7.597v-3.89l-1.64 1.64-.707-.707L6.5 1.793 9.347 4.64l-.707.707L7 3.707v3.89a6.606 6.606 0 0 0 1.302 3.918zM14.5 13h-3.793l1.646-1.646-.707-.707L8.8 13.494l2.847 2.847.707-.707L10.72 14h3.779A4.52 4.52 0 0 1 19 18.513V21h1v-2.487A5.522 5.522 0 0 0 14.5 13z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 3.707L5.354 6.354l-.707-.707L8.5 1.793l3.854 3.854-.707.707L9 3.707v5.09a9.006 9.006 0 0 0 3.167 6.855l-.706.706A10.003 10.003 0 0 1 8 8.797zm12.52 13.3l-5.805-.015 2.639-2.638-.707-.707-3.854 3.853 3.854 3.854.707-.707-2.655-2.655 5.818.008A6.516 6.516 0 0 1 27 24.506V28h1v-3.494a7.512 7.512 0 0 0-7.48-7.5z"
  }));
};

var _default = LeftRightIcon;
exports["default"] = _default;