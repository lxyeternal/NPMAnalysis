"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MonitorIcon = function MonitorIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.167 13a.834.834 0 0 0 .833-.834V1.834A.834.834 0 0 0 15.167 1H.833A.834.834 0 0 0 0 1.833v10.334A.834.834 0 0 0 .833 13H6v1H5v1h6v-1h-1v-1zM1 2h14v10H1zm8 12H7v-1h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 4v14a1.001 1.001 0 0 0 1 1h9v1H8v1h8v-1h-2v-1h9a1.001 1.001 0 0 0 1-1V4a1.001 1.001 0 0 0-1-1H1a1.001 1.001 0 0 0-1 1zm13 16h-2v-1h2zm10-2H1V4h22z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.833 4H1.167A1.168 1.168 0 0 0 0 5.167v19.667A1.168 1.168 0 0 0 1.167 26H13v2h-2v1h10v-1h-2v-2h11.833A1.168 1.168 0 0 0 32 24.834V5.166A1.168 1.168 0 0 0 30.833 4zM18 28h-4v-2h4zm13-3.167a.167.167 0 0 1-.167.167H1.167A.167.167 0 0 1 1 24.834V5.166A.167.167 0 0 1 1.167 5h29.666a.167.167 0 0 1 .167.167z"
  }));
};

var _default = MonitorIcon;
exports["default"] = _default;