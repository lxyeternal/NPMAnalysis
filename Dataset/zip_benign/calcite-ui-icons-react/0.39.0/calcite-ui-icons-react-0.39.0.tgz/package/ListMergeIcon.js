"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListMergeIcon = function ListMergeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 2h9v1H6zm-3.443.696l-.92-.796-.737.738 1.657 1.53 2.708-2.705-.738-.737zM6 15V7.715L7.646 9.36l.707-.707L5.5 5.801 2.646 8.654l.707.707L5 7.715V15zm7 0V7.715l1.646 1.646.707-.707L12.5 5.801 9.646 8.654l.707.707L12 7.715V15z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 22V10.707l-1.646 1.647-.707-.707 2.851-2.852 2.854 2.82-.704.712L9 10.697V22zm11 0V10.683l1.663 1.644.703-.711-2.853-2.821-2.852 2.851.707.707L18 10.722V22zm3-18H9v1h13zM2.438 3.7l-.738.738 1.857 1.73L7.3 2.438 6.562 1.7 3.557 4.696z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 6H11V5h18zM9.365 2.363l-.738-.737-4.07 4.07-1.884-1.788-.738.738 2.622 2.522zm-.719 12.282l.707.707L12 12.707V29h.999V12.707l2.647 2.647.707-.707-3.854-3.854zm20.707.002L25.5 10.793l-3.853 3.852.707.707L25 12.706V29h1V12.708l2.646 2.646z"
  }));
};

var _default = ListMergeIcon;
exports["default"] = _default;