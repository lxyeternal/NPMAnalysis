"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ContingentValuesIcon = function ContingentValuesIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 10h-6A1.502 1.502 0 0 0 7 11.5V13H5V8h7c.828-.001.999-.672 1-1.5v-5A1.502 1.502 0 0 0 11.5 0h-10A1.502 1.502 0 0 0 0 1.5v5A1.502 1.502 0 0 0 1.5 8H4v6h3v.5A1.502 1.502 0 0 0 8.5 16h6a1.502 1.502 0 0 0 1.5-1.5v-3a1.502 1.502 0 0 0-1.5-1.5zm-13-3a.5.5 0 0 1-.5-.5v-5a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 .5.5v5a.5.5 0 0 1-.5.5zM15 14.5a.5.5 0 0 1-.5.5h-6a.5.5 0 0 1-.5-.5v-3a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 .5.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M20.5 14h-9a1.502 1.502 0 0 0-1.5 1.5V18H7v-7h8.5A1.502 1.502 0 0 0 17 9.5v-6A1.502 1.502 0 0 0 15.5 2h-12A1.502 1.502 0 0 0 2 3.5v6A1.502 1.502 0 0 0 3.5 11H6v8h4v1.5a1.502 1.502 0 0 0 1.5 1.5h9a1.502 1.502 0 0 0 1.5-1.5v-5a1.502 1.502 0 0 0-1.5-1.5zm-17-4a.5.5 0 0 1-.5-.5v-6a.5.5 0 0 1 .5-.5h12a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-.5.5zM21 20.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5v-5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 .5.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.5 21h-12a1.502 1.502 0 0 0-1.5 1.5V25h-4v-9h12.5a1.502 1.502 0 0 0 1.5-1.5v-10A1.502 1.502 0 0 0 22.5 3h-18A1.502 1.502 0 0 0 3 4.5v10A1.502 1.502 0 0 0 4.5 16H9v10h5v2.5a1.502 1.502 0 0 0 1.5 1.5h12a1.502 1.502 0 0 0 1.5-1.5v-6a1.502 1.502 0 0 0-1.5-1.5zm-23-6a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h18a.5.5 0 0 1 .5.5v10a.5.5 0 0 1-.5.5zM28 28.5a.5.5 0 0 1-.5.5h-12a.5.5 0 0 1-.5-.5v-6a.5.5 0 0 1 .5-.5h12a.5.5 0 0 1 .5.5z"
  }));
};

var _default = ContingentValuesIcon;
exports["default"] = _default;