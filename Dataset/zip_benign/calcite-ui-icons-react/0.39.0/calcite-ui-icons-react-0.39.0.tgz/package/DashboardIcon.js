"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DashboardIcon = function DashboardIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.425 13.718a6.43 6.43 0 0 0 1.24-6.262l.78-.78a7.477 7.477 0 0 1-2.008 8.46l-2.109-2.1.708-.708zm2.726-9.162L8.85 10.857a1.514 1.514 0 1 1-.707-.707l6.301-6.301zM8 11.5a.5.5 0 1 0-.5.5.5.5 0 0 0 .5-.5zM7 5h1V3.025a6.478 6.478 0 0 1 4.03 1.823l.71-.71a7.495 7.495 0 1 0-10.177 11l2.109-2.101-.708-.708-1.389 1.39A6.45 6.45 0 0 1 1.028 10H3V9H1.025A6.466 6.466 0 0 1 2.57 5.276l1.395 1.396.708-.708L3.276 4.57A6.465 6.465 0 0 1 7 3.025z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.95 8.653A7.338 7.338 0 0 0 5.147 13H7v1H5.149a7.324 7.324 0 0 0 1.81 4.346l1.29-1.29.707.708C7.22 19.5 7.633 19.079 6.963 19.777a8.373 8.373 0 1 1 11.398-12.26l-.71.71A7.353 7.353 0 0 0 13 6.147V8h-1V6.146a7.338 7.338 0 0 0-4.342 1.8L8.973 9.26l-.707.707zm13.16 1.358l-.76.76a7.303 7.303 0 0 1-1.301 7.565L16.75 17.04l-.707.707 1.993 2.031a8.339 8.339 0 0 0 2.073-9.766zM3 13.5a9.492 9.492 0 0 1 16.15-6.772l.711-.71a10.493 10.493 0 1 0-14.364 15.29l.694-.725A9.469 9.469 0 0 1 3 13.5zm17.947-4.326a9.442 9.442 0 0 1-2.138 11.41l.694.724a10.473 10.473 0 0 0 2.19-12.88zm1.578-4.406l.707.707-8.648 8.649a2.507 2.507 0 1 1-.707-.707zM14 15.5a1.5 1.5 0 1 0-1.5 1.5 1.502 1.502 0 0 0 1.5-1.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.617 29.09A14.49 14.49 0 1 1 26.69 8.189l-.712.712a13.485 13.485 0 1 0-18.65 19.477zM28 18.5a11.413 11.413 0 0 0-1.584-5.795l-.726.726a10.439 10.439 0 0 1-1.434 12.118l-1.392-1.392-.707.707 2.1 2.1A11.46 11.46 0 0 0 28 18.5zm-.13-7.249a13.42 13.42 0 0 1-2.199 17.127l.712.712A14.462 14.462 0 0 0 28.6 10.52zM17 10V8.025a10.46 10.46 0 0 1 6.858 2.996l.707-.707a11.487 11.487 0 1 0-15.823 16.65l2.101-2.1-.707-.707-1.392 1.392A10.431 10.431 0 0 1 6.027 19H8v-1H6.025a10.443 10.443 0 0 1 2.717-6.55l1.394 1.393.707-.707-1.394-1.394A10.443 10.443 0 0 1 16 8.025V10zm.877 8.416L28.59 7.705l.707.707-10.712 10.71a2.505 2.505 0 1 1-.707-.706zM18 20.5a1.5 1.5 0 1 0-1.5 1.5 1.502 1.502 0 0 0 1.5-1.5z"
  }));
};

var _default = DashboardIcon;
exports["default"] = _default;