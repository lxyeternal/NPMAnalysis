"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerServiceIcon = function LayerServiceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.706 1.014a7.215 7.215 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852l-.604.204-.363.108a9.678 9.678 0 0 1-2.921.436 9.54 9.54 0 0 1-2.668-.363L2.935 1.74A11.372 11.372 0 0 0 5.294 2a7.833 7.833 0 0 0 3.045-.552 5.894 5.894 0 0 1 2.367-.434zm0-1C8.016.014 7.982 1 5.294 1A10.39 10.39 0 0 1 2.133.488L0 13.09a9.158 9.158 0 0 0 3.793.711A10.667 10.667 0 0 0 7 13.322V15H2v1h11v-1H8v-2a11.89 11.89 0 0 1 4.207-.8A6.624 6.624 0 0 1 16 13.29L13.867.687a8.205 8.205 0 0 0-3.161-.674z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.31 1.2a11.86 11.86 0 0 1 3.63.615l2.675 15.872a16.246 16.246 0 0 0-4.157-.52 22.854 22.854 0 0 0-5.688.71l-1.001.238a21.176 21.176 0 0 1-5.345.685 13.724 13.724 0 0 1-4.3-.65L4.848 2.343A16.193 16.193 0 0 0 8.57 2.8a9.806 9.806 0 0 0 4.25-.875 7.791 7.791 0 0 1 3.49-.725m0-1c-3.848 0-3.892 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722L1 18.783A13.093 13.093 0 0 0 6.424 19.8 22.094 22.094 0 0 0 12 19.088V23H4v1h17v-1h-8v-4.15a21.892 21.892 0 0 1 5.458-.684 13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105A12.674 12.674 0 0 0 16.31.2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.074 2.211a26.266 26.266 0 0 1 5.05.518l3.651 22a37.271 37.271 0 0 0-6.313-.529 22.376 22.376 0 0 0-7.769 1.348l-.988.313a19.256 19.256 0 0 1-6.167.939 15.988 15.988 0 0 1-6.43-1.366L5.795 3.217a15.6 15.6 0 0 0 4.544.651 17.431 17.431 0 0 0 5.445-.846 16.633 16.633 0 0 1 5.29-.81zm0-1c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 1.9L1 26a16.273 16.273 0 0 0 7.538 1.8A20.258 20.258 0 0 0 15 26.816V30H3v1h25v-1H16v-3.5a21.425 21.425 0 0 1 7.462-1.3A33.153 33.153 0 0 1 31 26L27 1.9a26.401 26.401 0 0 0-5.926-.689z"
  }));
};

var _default = LayerServiceIcon;
exports["default"] = _default;