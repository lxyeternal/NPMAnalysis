"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BellOffIcon = function BellOffIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 7.828l1-1V10a2 2 0 0 0 2 2v1H6.828l1-1h4.938A2.99 2.99 0 0 1 12 10zm-3.5 7.725a1.5 1.5 0 0 0 1.5-1.5V14H7v.053a1.5 1.5 0 0 0 1.5 1.5zm-7.425-.335L3.293 13H2v-1a2 2 0 0 0 2-2V6.5a4.485 4.485 0 0 1 3.19-4.283A1.484 1.484 0 0 1 7 1.5a1.5 1.5 0 0 1 3 0 1.484 1.484 0 0 1-.19.717 4.492 4.492 0 0 1 2.449 1.817l2.959-2.959.707.707L1.782 15.925zM8.5 2a.5.5 0 1 0-.5-.5.5.5 0 0 0 .5.5zM4.293 12l7.23-7.23A3.488 3.488 0 0 0 5 6.5V10a2.99 2.99 0 0 1-.766 2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.992 10.836l.918-.918a5.927 5.927 0 0 1 .09.995V15a3 3 0 0 0 3 3v1H8.828l1-1h8.529A3.992 3.992 0 0 1 17 15v-4.087c0-.026-.007-.05-.008-.077zM12 21a1.001 1.001 0 0 1-1-1h-1a2 2 0 0 0 4 0h-1a1.001 1.001 0 0 1-1 1zm-8.692 1.4l-.354-.354-.353-.354L5.293 19H3v-1a3 3 0 0 0 3-3v-4.087A5.91 5.91 0 0 1 10.41 5.2a2 2 0 1 1 3.18 0 5.91 5.91 0 0 1 3.27 2.233L21.692 2.6l.354.354.354.354zM11 4a1 1 0 1 0 1-1 1.001 1.001 0 0 0-1 1zM6.293 18l9.85-9.851A4.91 4.91 0 0 0 12.088 6h-.174A4.919 4.919 0 0 0 7 10.913V15a3.992 3.992 0 0 1-1.357 3z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 30a3 3 0 0 1-3-3h1a2 2 0 0 0 4 0h1a3 3 0 0 1-3 3zm9-9v-7a9.012 9.012 0 0 0-.219-1.953l-.864.865A7.992 7.992 0 0 1 24 14v7a4.996 4.996 0 0 0 2.003 4H11.828l-1 1H29v-1a4 4 0 0 1-4-4zM4.48 30.228l-.354-.354-.354-.353L7.292 26H3v-1a4 4 0 0 0 4-4v-7a8.997 8.997 0 0 1 7.372-8.845 2 2 0 1 1 3.257 0 8.998 8.998 0 0 1 6.16 4.35l4.732-4.733.353.354.354.353zM16 5a1 1 0 1 0-1-1 1.001 1.001 0 0 0 1 1zM8.293 25l14.763-14.763A7.998 7.998 0 0 0 8 14v7a4.996 4.996 0 0 1-2.003 4z"
  }));
};

var _default = BellOffIcon;
exports["default"] = _default;