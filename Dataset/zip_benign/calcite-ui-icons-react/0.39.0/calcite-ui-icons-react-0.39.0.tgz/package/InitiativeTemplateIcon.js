"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var InitiativeTemplateIcon = function InitiativeTemplateIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.298 4.026c.756.29 1.897.726 2.618-.356L10 3.544V.401l-.788.557c-.436.307-.919.178-1.66-.07A2.145 2.145 0 0 0 5.296 1H5v4.679L.405 10.98H7V10H2.595L5.75 6.34 7 7.784V7.03a2.003 2.003 0 0 1 .114-.643L6 5.102V3.874c.228-.192.55-.133 1.298.152zM6 1.706c.247-.174.574-.09 1.234.13A3.633 3.633 0 0 0 9 2.107v1.115c-.231.242-.552.174-1.345-.13a3.987 3.987 0 0 0-1.366-.341A1.589 1.589 0 0 0 6 2.776zM14.97 6H9.03A1.031 1.031 0 0 0 8 7.03v7.94A1.031 1.031 0 0 0 9.03 16h5.94A1.031 1.031 0 0 0 16 14.97V7.03A1.031 1.031 0 0 0 14.97 6zm.03 9c-.012.012-6 0-6 0V7h6zm-1-5h-2V9h2zm0 3h-2v-1h2zm-3-3h-1V9h1zm0 3h-1v-1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.595 15L8 8.764l3 3.461V11.5a2.467 2.467 0 0 1 .106-.68L8 7.236V5.228c.464-.486 1.104-.327 2.287.126 1.185.452 2.66 1.014 3.63-.44L14 4.786V.633l-.788.555c-.806.569-1.732.257-2.713-.073A3.369 3.369 0 0 0 7.674 1H7v7.39L.405 16H11v-1zM10.18 2.063a4.727 4.727 0 0 0 2.82.328v2.083c-.468.586-1.102.424-2.356-.055a5.749 5.749 0 0 0-1.954-.496 2.004 2.004 0 0 0-.69.115V1.984c.502-.452 1.145-.268 2.18.08zM21.5 10h-8a1.502 1.502 0 0 0-1.5 1.5v10a1.502 1.502 0 0 0 1.5 1.5h8a1.502 1.502 0 0 0 1.5-1.5v-10a1.502 1.502 0 0 0-1.5-1.5zm.5 11.5a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5zM17 13h3v1h-3zm0 6h3v1h-3zm0-3h3v1h-3zm-2-3h1v1h-1zm0 6h1v1h-1zm.595-3H16v1h-1v-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3.719 21L12 11.75l5 5.585V16.5a2.478 2.478 0 0 1 .075-.58L12 10.25V7.628c.941-1.057 1.81-.718 3.223-.016 1.294.642 2.904 1.444 4.59.091l.187-.15V2.329l-.791.568c-1.084.778-2.167.284-3.42-.287-1.182-.538-2.493-1.114-3.789-.426V2h-1v9.367L1.481 22H17v-1zM15.375 3.52A4.792 4.792 0 0 0 19 4.13v2.933c-1.114.753-2.147.243-3.333-.346a5.61 5.61 0 0 0-2.393-.77A2.38 2.38 0 0 0 12 6.31V3.383c.974-.888 1.931-.52 3.375.137zM28.5 15h-9a1.502 1.502 0 0 0-1.5 1.5v12a1.502 1.502 0 0 0 1.5 1.5h9a1.502 1.502 0 0 0 1.5-1.5v-12a1.502 1.502 0 0 0-1.5-1.5zm.5 13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5v-12a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 .5.5zM23 18h4v1h-4zm0 8h4v1h-4zm0-4h4v1h-4zm-1-3h-1v-1h1zm-1 7h1v1h-1zm0-4h1v1h-1z"
  }));
};

var _default = InitiativeTemplateIcon;
exports["default"] = _default;