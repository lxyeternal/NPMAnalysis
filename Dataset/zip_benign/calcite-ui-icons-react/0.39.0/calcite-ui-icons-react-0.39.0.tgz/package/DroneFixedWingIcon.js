"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DroneFixedWingIcon = function DroneFixedWingIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1.996 10.143a.947.947 0 0 0-1.153.143l-.584.584a.882.882 0 0 0-.133 1.08l1.207 2.01-.686.686a.5.5 0 1 0 .707.707l.686-.687 2.012 1.208a.882.882 0 0 0 1.078-.133l.584-.584a.945.945 0 0 0 .142-1.154l-.626-1.044 2.804-2.093.378.38a21.83 21.83 0 0 0 5.201 4.096.862.862 0 0 0 1.022-.153l1.112-1.11a.87.87 0 0 0 0-1.227L10.88 7.986l.893-1.924a1.71 1.71 0 0 0 .163-.726 1.274 1.274 0 0 0-1.273-1.273 1.71 1.71 0 0 0-.724.162l-1.926.894L3.148.254a.87.87 0 0 0-1.227 0L.81 1.365A.864.864 0 0 0 .659 2.39a21.798 21.798 0 0 0 4.088 5.19l.386.386L3.04 10.77zm8.368-5.013c.228-.106.573-.048.573.206a.72.72 0 0 1-.068.302l-.74 1.596-1.363-1.362zm-3.91 2.74L5.445 6.865a20.975 20.975 0 0 1-3.86-4.862l.95-.948 12.41 12.41-.949.948a21.037 21.037 0 0 1-4.87-3.867l-.997-1L3.908 12.7l1.099 1.751-.52.52-1.718-1.032.384-.384a.5.5 0 0 0-.707-.707l-.384.384-1.034-1.723.455-.507 1.818 1.09zm7.192-1.516l-4-4 .707-.707 4 4z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.612 11.842l1.452-2.622a1.954 1.954 0 0 0 .247-.95 1.572 1.572 0 0 0-.029-.28l2.364 2.364.707-.707-6-6-.707.707 2.365 2.364a1.572 1.572 0 0 0-.28-.029 1.958 1.958 0 0 0-.95.246l-2.623 1.453-7.092-7.092a1.019 1.019 0 0 0-1.435 0l-1.097 1.1a1.875 1.875 0 0 0-.295 2.264 30.92 30.92 0 0 0 5.349 6.612l.852.852-3.155 3.959-1.834-.936a1.06 1.06 0 0 0-1.295.162l-.851.851a1.032 1.032 0 0 0-.158 1.265l1.771 2.95-.772.772a.5.5 0 1 0 .707.707l.772-.771 2.951 1.77a1.03 1.03 0 0 0 1.264-.156l.851-.851a1.047 1.047 0 0 0 .178-1.267l-.951-1.863 3.959-3.155.845.844a30.966 30.966 0 0 0 6.619 5.357 1.876 1.876 0 0 0 2.266-.296l1.094-1.095a1.015 1.015 0 0 0 .001-1.437zm-.345-4.033a.956.956 0 0 1 .463-.12.58.58 0 0 1 .58.58.953.953 0 0 1-.12.465l-1.314 2.373-1.983-1.984zm5.632 12.95a.873.873 0 0 1-1.056.137 29.953 29.953 0 0 1-6.406-5.19l-1.484-1.484-5.297 4.22 1.323 2.591-.002.09.008.014-.895.858-2.736-1.642.5-.5a.5.5 0 0 0-.707-.706l-.497.496-1.64-2.776.853-.852 2.696 1.329 4.22-5.297-1.492-1.491a29.906 29.906 0 0 1-5.183-6.399.874.874 0 0 1 .137-1.055l1.12-1.098 17.634 17.658z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.453 25.746l-10-10 2.2-3.544a2.31 2.31 0 0 0 .347-1.22 1.958 1.958 0 0 0-.031-.306l2.677 2.678.707-.707-7-7-.707.707 2.678 2.677A1.958 1.958 0 0 0 21.018 9a2.315 2.315 0 0 0-1.221.348l-3.542 2.2L6.254 1.547a1.198 1.198 0 0 0-.854-.354 1.195 1.195 0 0 0-.853.354L2.413 3.68a1.203 1.203 0 0 0-.21 1.424 41.402 41.402 0 0 0 7.773 9.864l1.474 1.475-4.498 5.688-3.061-1.66a1.002 1.002 0 0 0-1.221.151L1.353 21.94a1.234 1.234 0 0 0-.187 1.508l2.504 4.175-1.524 1.523a.5.5 0 1 0 .707.707l1.524-1.523 4.175 2.504a1.233 1.233 0 0 0 1.508-.187l1.316-1.317a.99.99 0 0 0 .163-1.203l-1.67-3.08 5.688-4.497 1.466 1.467a41.451 41.451 0 0 0 9.875 7.782 1.2 1.2 0 0 0 1.422-.212l2.132-2.133a1.207 1.207 0 0 0 .001-1.708zm-10.13-15.549a1.322 1.322 0 0 1 .695-.197.983.983 0 0 1 .982.982 1.316 1.316 0 0 1-.197.694l-2.077 3.343-2.745-2.745zm9.423 16.55l-2.133 2.133a.209.209 0 0 1-.244.037 40.497 40.497 0 0 1-9.63-7.6l-2.104-2.103-7.045 5.57 2.08 3.838-1.317 1.318a.234.234 0 0 1-.288.037L5.106 27.6l1.748-1.747a.5.5 0 0 0-.707-.707l-1.748 1.747-2.376-3.96a.236.236 0 0 1 .037-.287l1.336-1.307 3.82 2.07 5.57-7.045-2.111-2.112a40.444 40.444 0 0 1-7.591-9.62.207.207 0 0 1 .036-.246l2.135-2.134a.207.207 0 0 1 .292 0l24.2 24.2a.208.208 0 0 1 .06.148.205.205 0 0 1-.06.145z"
  }));
};

var _default = DroneFixedWingIcon;
exports["default"] = _default;