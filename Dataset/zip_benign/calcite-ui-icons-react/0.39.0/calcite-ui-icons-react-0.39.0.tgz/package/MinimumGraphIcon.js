"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MinimumGraphIcon = function MinimumGraphIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 7a.844.844 0 0 0 .832-.67C1.392 3.751 2.184 1 4.5 1c2.618 0 3.316 3.509 3.99 6.902C9.086 10.9 9.703 14 11.5 14c1.656 0 2.309-2.588 2.934-5.715A1.602 1.602 0 0 1 16 7v1a.6.6 0 0 0-.586.48c-.392 1.962-.85 4.243-1.91 5.52H14v1h-1v-.513a2.396 2.396 0 0 1-1.5.513 2.639 2.639 0 0 1-.5-.049V15h-1v-.504c-1.429-1.085-1.969-3.773-2.49-6.398C6.914 5.1 6.297 2 4.5 2 3.002 2 2.321 4.183 1.81 6.542A1.838 1.838 0 0 1 0 8zm15 8h1v-1h-1zm-6 0v-1H8v1zm-2 0v-1H6v1zm-3 0h1v-1H4zm-1 0v-1H2v1zm-3 0h1v-1H0z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 11v1c-1.108 0-1.36 1.386-1.385 1.544-.284 1.893-1.046 5.66-2.759 7.456H19v1h-1v-.336a2.567 2.567 0 0 1-1.25.336 3.239 3.239 0 0 1-.75-.094V22h-1v-.526c-2.095-1.41-2.804-5.452-3.493-9.388C10.727 7.619 9.918 3 7.25 3c-1.7 0-3.14 2.498-3.755 6.519A2.677 2.677 0 0 1 1 12v-1c1.195 0 1.479-1.473 1.507-1.64C3.223 4.685 4.952 2 7.25 2c3.508 0 4.39 5.04 5.243 9.914.78 4.467 1.589 9.086 4.257 9.086 1.687 0 3.172-2.915 3.876-7.608A2.545 2.545 0 0 1 23 11zm-1 11h1v-1h-1zm-2 0h1v-1h-1zm-7 0h1v-1h-1zm-2 0h1v-1h-1zm-2 0h1v-1H9zm-2 0h1v-1H7zm-2 0h1v-1H5zm-2 0h1v-1H3zm-2 0h1v-1H1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 28h1v1H2zm3 0H4v1h1zm2 0H6v1h1zm2 0H8v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm7 0h-1v1h1zm1 1h1v-1h-1zm2 0h1v-1h-1zm-2.178-9.51C26.23 24.42 24.202 28 22 28c-3.543 0-4.542-6.142-5.506-12.08C15.46 9.568 14.394 3 10 3c-2.804 0-5.141 3.774-5.815 9.389C4.085 13.174 3.672 15 2 15v1c2.015 0 2.962-1.8 3.178-3.488C5.77 7.58 7.798 4 10 4c3.543 0 4.542 6.142 5.506 12.08.853 5.249 1.736 10.634 4.494 12.35V29h1v-.141A3.866 3.866 0 0 0 22 29a3.153 3.153 0 0 0 1-.166V29h1v-.68c1.87-1.326 3.31-4.5 3.815-8.708C27.892 19 28.278 17 30 17v-1c-2.018 0-2.964 1.802-3.178 3.49z"
  }));
};

var _default = MinimumGraphIcon;
exports["default"] = _default;