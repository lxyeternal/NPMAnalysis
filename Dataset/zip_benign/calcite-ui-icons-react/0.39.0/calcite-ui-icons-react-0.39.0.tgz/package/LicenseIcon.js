"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LicenseIcon = function LicenseIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 1v14h16V1zm15 1v1H1V2zM1 14V4h14v10zm6.355-4.84a2.5 2.5 0 1 0-3.71 0A2.496 2.496 0 0 0 2 11.5V13h7v-1.5a2.496 2.496 0 0 0-1.645-2.34zM5.5 6A1.5 1.5 0 1 1 4 7.5 1.502 1.502 0 0 1 5.5 6zM8 12H3v-.5A1.502 1.502 0 0 1 4.5 10h2A1.502 1.502 0 0 1 8 11.5zm2-6h4v1h-4zm0 2h4v1h-4zm1 2h2v1h-2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 21h22V3H1zm1-1V7h20v13zM22 4v2H2V4zM9.355 13.16a2.5 2.5 0 1 0-3.71 0A2.496 2.496 0 0 0 4 15.5V18h7v-2.5a2.496 2.496 0 0 0-1.645-2.34zM7.5 10A1.5 1.5 0 1 1 6 11.5 1.502 1.502 0 0 1 7.5 10zm2.5 7H5v-1.5A1.502 1.502 0 0 1 6.5 14h2a1.502 1.502 0 0 1 1.5 1.5zm3-7h7v1h-7zm0 3h7v1h-7zm1 3h5v1h-5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 27h28V5H2zm1-1V9h26v17zM29 6v2H3V6zM19 21h6v1h-6zm-3-4h12v1H16zm0-4h12v1H16zm-4.5 5h-3A3.504 3.504 0 0 0 5 21.5V24h10v-2.5a3.504 3.504 0 0 0-3.5-3.5zm2.5 5H6v-1.5A2.503 2.503 0 0 1 8.5 19h3a2.503 2.503 0 0 1 2.5 2.5zm-4-6a3 3 0 1 0-3-3 3.003 3.003 0 0 0 3 3zm0-5a2 2 0 1 1-2 2 2.002 2.002 0 0 1 2-2z"
  }));
};

var _default = LicenseIcon;
exports["default"] = _default;