"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var KeypadIcon = function KeypadIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.25 4h-2.5A.751.751 0 0 1 1 3.25v-1.5A.751.751 0 0 1 1.75 1h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM2 3h2V2H2zm7.25 1h-2.5A.751.751 0 0 1 6 3.25v-1.5A.751.751 0 0 1 6.75 1h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM7 3h2V2H7zm7.25 1h-2.5a.751.751 0 0 1-.75-.75v-1.5a.751.751 0 0 1 .75-.75h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM12 3h2V2h-2zM4.25 8h-2.5A.751.751 0 0 1 1 7.25v-1.5A.751.751 0 0 1 1.75 5h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM2 7h2V6H2zm7.25 1h-2.5A.751.751 0 0 1 6 7.25v-1.5A.751.751 0 0 1 6.75 5h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM7 7h2V6H7zm7.25 1h-2.5a.751.751 0 0 1-.75-.75v-1.5a.751.751 0 0 1 .75-.75h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM12 7h2V6h-2zm-7.75 5h-2.5a.751.751 0 0 1-.75-.75v-1.5A.751.751 0 0 1 1.75 9h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM2 11h2v-1H2zm7.25 1h-2.5a.751.751 0 0 1-.75-.75v-1.5A.751.751 0 0 1 6.75 9h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM7 11h2v-1H7zm7.25 1h-2.5a.751.751 0 0 1-.75-.75v-1.5a.751.751 0 0 1 .75-.75h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM12 11h2v-1h-2zm-2.75 5h-2.5a.751.751 0 0 1-.75-.75v-1.5a.751.751 0 0 1 .75-.75h2.5a.751.751 0 0 1 .75.75v1.5a.751.751 0 0 1-.75.75zM7 15h2v-1H7z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 5H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1L7 4.5zM4 2v2h3V2zm10 3h-3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1L14 4.5zM11 2v2h3V2zm10 3h-3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1L21 4.5zM18 2v2h3V2zM7 11H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1L7 10.5zM4 8v2h3V8zm10 3h-3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1l-.001.5zM11 8v2h3V8zm10 3h-3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1l-.001.5zM18 8v2h3V8zM7 17H4a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1L7 16.5zM4 14v2h3v-2zm10 3h-3a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1l-.001.5zM11 14v2h3v-2zm10 3h-3a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1l-.001.5zM18 14v2h3v-2zm-4 9h-3a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1zm.001-1l-.001.5zM11 20v2h3v-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9.75 8h-4.5A1.251 1.251 0 0 1 4 6.75v-2.5A1.251 1.251 0 0 1 5.25 3h4.5A1.251 1.251 0 0 1 11 4.25v2.5A1.251 1.251 0 0 1 9.75 8zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5A.25.25 0 0 0 9.75 4zm13.5 4h-4.5A1.251 1.251 0 0 1 13 6.75v-2.5A1.251 1.251 0 0 1 14.25 3h4.5A1.251 1.251 0 0 1 20 4.25v2.5A1.251 1.251 0 0 1 18.75 8zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zm13.5 4h-4.5A1.251 1.251 0 0 1 22 6.75v-2.5A1.251 1.251 0 0 1 23.25 3h4.5A1.251 1.251 0 0 1 29 4.25v2.5A1.251 1.251 0 0 1 27.75 8zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zM9.75 15h-4.5A1.251 1.251 0 0 1 4 13.75v-2.5A1.251 1.251 0 0 1 5.25 10h4.5A1.251 1.251 0 0 1 11 11.25v2.5A1.251 1.251 0 0 1 9.75 15zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zm13.5 4h-4.5A1.251 1.251 0 0 1 13 13.75v-2.5A1.251 1.251 0 0 1 14.25 10h4.5A1.251 1.251 0 0 1 20 11.25v2.5A1.251 1.251 0 0 1 18.75 15zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zm13.5 4h-4.5A1.251 1.251 0 0 1 22 13.75v-2.5A1.251 1.251 0 0 1 23.25 10h4.5A1.251 1.251 0 0 1 29 11.25v2.5A1.251 1.251 0 0 1 27.75 15zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zM9.75 22h-4.5A1.251 1.251 0 0 1 4 20.75v-2.5A1.251 1.251 0 0 1 5.25 17h4.5A1.251 1.251 0 0 1 11 18.25v2.5A1.251 1.251 0 0 1 9.75 22zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zm13.5 4h-4.5A1.251 1.251 0 0 1 13 20.75v-2.5A1.251 1.251 0 0 1 14.25 17h4.5A1.251 1.251 0 0 1 20 18.25v2.5A1.251 1.251 0 0 1 18.75 22zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zm13.5 4h-4.5A1.251 1.251 0 0 1 22 20.75v-2.5A1.251 1.251 0 0 1 23.25 17h4.5A1.251 1.251 0 0 1 29 18.25v2.5A1.251 1.251 0 0 1 27.75 22zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25zm-4.5 11h-4.5A1.251 1.251 0 0 1 13 27.75v-2.5A1.251 1.251 0 0 1 14.25 24h4.5A1.251 1.251 0 0 1 20 25.25v2.5A1.251 1.251 0 0 1 18.75 29zm-4.5-4a.25.25 0 0 0-.25.25v2.5a.25.25 0 0 0 .25.25h4.5a.25.25 0 0 0 .25-.25v-2.5a.25.25 0 0 0-.25-.25z"
  }));
};

var _default = KeypadIcon;
exports["default"] = _default;