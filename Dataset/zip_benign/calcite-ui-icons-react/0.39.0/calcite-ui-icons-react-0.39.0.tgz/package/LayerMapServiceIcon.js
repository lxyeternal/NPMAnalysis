"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerMapServiceIcon = function LayerMapServiceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.207 12.2A6.624 6.624 0 0 1 16 13.29L13.867.687a8.204 8.204 0 0 0-3.161-.674C8.016.014 7.982 1 5.294 1A10.39 10.39 0 0 1 2.133.488L0 13.09a9.158 9.158 0 0 0 3.793.711A10.666 10.666 0 0 0 7 13.322V15H2v1h11v-1H8v-2a11.89 11.89 0 0 1 4.207-.8zm-11.082.237L2.935 1.74A11.376 11.376 0 0 0 5.294 2a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.212 7.212 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852 10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363zM12.105 3h-8.21L3 11h10zM7.948 4a.742.742 0 0 0-.199.5.75.75 0 0 0 1.5 0 .742.742 0 0 0-.2-.5h2.16l.468 4.182a2.977 2.977 0 0 1-1.026-.175 4.25 4.25 0 0 1-1.23-.911l-.108-.107a1.097 1.097 0 0 0-.743-.292 2.532 2.532 0 0 1-1.475-.324 1.985 1.985 0 0 1-.368-.38 2.331 2.331 0 0 0-1.174-.88 1.833 1.833 0 0 0-.887-.018L4.79 4zm-3.83 6l.45-4.028a1.165 1.165 0 0 1 .769-.09 1.584 1.584 0 0 1 .772.619 2.608 2.608 0 0 0 .539.536 3.26 3.26 0 0 0 1.918.46.297.297 0 0 1 .195.07l.099.099a4.956 4.956 0 0 0 1.475 1.077 3.84 3.84 0 0 0 1.432.244L11.882 10zM9.75 5.5a.75.75 0 1 1 .75.75.75.75 0 0 1-.75-.75z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.384 16.4L19.057 2.59a10.555 10.555 0 0 0-2.746-.39 6.87 6.87 0 0 0-3.11.65 10.811 10.811 0 0 1-4.63.95 16.728 16.728 0 0 1-2.914-.268L3.262 17.436a13.436 13.436 0 0 0 3.162.364 21.214 21.214 0 0 0 5.549-.761 24.868 24.868 0 0 1 6.485-.873 18.033 18.033 0 0 1 2.926.234zM8.571 4.8a11.836 11.836 0 0 0 5.01-1.025 5.906 5.906 0 0 1 2.73-.575 9.163 9.163 0 0 1 1.87.206l1.468 8.715a3.83 3.83 0 0 1-.738.13 2.337 2.337 0 0 1-.803-.145 4.739 4.739 0 0 1-2.007-1.795 5.526 5.526 0 0 0-1.563-1.556 2.388 2.388 0 0 0-1.182-.205 2.17 2.17 0 0 1-1.262-.268 2.532 2.532 0 0 1-.73-1.037 2.095 2.095 0 0 0-.774-1.029A2.016 2.016 0 0 0 9.627 6a7.52 7.52 0 0 0-3.603 1.293l.452-2.626a17.065 17.065 0 0 0 2.095.133zm3.168 11.266a20.373 20.373 0 0 1-5.315.734 12.935 12.935 0 0 1-2.012-.153l1.37-7.951c.093-.076.18-.159.276-.231 1.387-1.036 3.423-1.715 4.097-1.36a1.675 1.675 0 0 1 .363.592 3.396 3.396 0 0 0 1.045 1.414 2.967 2.967 0 0 0 1.786.44 1.882 1.882 0 0 1 .748.09 4.812 4.812 0 0 1 1.268 1.302 5.614 5.614 0 0 0 2.436 2.11 3.223 3.223 0 0 0 1.11.198 4.327 4.327 0 0 0 .904-.144l.36 2.134a19.52 19.52 0 0 0-1.718-.075 25.713 25.713 0 0 0-6.718.9zM12.5 5.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm3 2a1 1 0 1 1 1 1 1 1 0 0 1-1-1zM13 18.85a21.892 21.892 0 0 1 5.458-.684 13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105A12.674 12.674 0 0 0 16.31.2c-3.848 0-3.892 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722L1 18.783A13.093 13.093 0 0 0 6.424 19.8 22.094 22.094 0 0 0 12 19.088V23H4v1h17v-1h-8zm-10.876-.7L4.848 2.343A16.193 16.193 0 0 0 8.57 2.8a9.805 9.805 0 0 0 4.25-.875 7.791 7.791 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l2.674 15.872a16.25 16.25 0 0 0-4.157-.52 24.03 24.03 0 0 0-6.251.844 22.054 22.054 0 0 1-5.783.789 13.727 13.727 0 0 1-4.3-.65z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.074 1.211c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 1.9L1 26a16.273 16.273 0 0 0 7.538 1.8A20.258 20.258 0 0 0 15 26.816V30H3v1h25v-1H16v-3.5a21.425 21.425 0 0 1 7.462-1.3A33.153 33.153 0 0 1 31 26L27 1.9a26.401 26.401 0 0 0-5.926-.689zM23.462 24.2a22.375 22.375 0 0 0-7.77 1.348A20.416 20.416 0 0 1 8.539 26.8a15.986 15.986 0 0 1-6.43-1.366L5.795 3.217a15.6 15.6 0 0 0 4.544.651 17.431 17.431 0 0 0 5.445-.846 16.632 16.632 0 0 1 5.29-.81 26.266 26.266 0 0 1 5.05.517l3.651 22a37.271 37.271 0 0 0-6.313-.529zM21.074 4.21a14.759 14.759 0 0 0-4.736.733 19.375 19.375 0 0 1-5.999.925 18.297 18.297 0 0 1-2.918-.231L4.348 24.148a14.05 14.05 0 0 0 4.19.652 18.509 18.509 0 0 0 6.54-1.155 24.388 24.388 0 0 1 8.384-1.445c1.444 0 2.76.079 3.898.19L24.383 4.458a23.564 23.564 0 0 0-3.309-.247zM10.34 6.869a20.235 20.235 0 0 0 6.276-.964 13.754 13.754 0 0 1 4.46-.693 21.74 21.74 0 0 1 2.443.143l1.935 11.658a3.716 3.716 0 0 1-.725.09 3.498 3.498 0 0 1-1.147-.2 6.505 6.505 0 0 1-2.827-2.344c-.649-.795-1.261-1.938-2.07-2.355a3.255 3.255 0 0 0-1.524-.242 3.232 3.232 0 0 1-1.828-.382 2.696 2.696 0 0 1-1.06-1.134 2.227 2.227 0 0 0-.97-1.137 2.686 2.686 0 0 0-1.224-.258 9.747 9.747 0 0 0-4.455 1.477l.626-3.77a19.57 19.57 0 0 0 2.09.111zM23.462 21.2a25.251 25.251 0 0 0-8.693 1.494A17.461 17.461 0 0 1 8.538 23.8a12.838 12.838 0 0 1-3.057-.372l1.964-11.831.025.034a9.935 9.935 0 0 1 4.608-1.681 1.942 1.942 0 0 1 .812.05 2.103 2.103 0 0 1 .58.854 3.64 3.64 0 0 0 1.359 1.472 4.045 4.045 0 0 0 2.326.534 2.74 2.74 0 0 1 1.11.14c.648.334 1.202 1.405 1.79 2.126a7.199 7.199 0 0 0 3.235 2.628 4.411 4.411 0 0 0 1.448.246 3.27 3.27 0 0 0 .859-.125l.567 3.414c-.9-.059-1.805-.089-2.702-.089zm-2.461-10.338a.933.933 0 0 1 .968-.775.892.892 0 0 1 .982.726.903.903 0 0 1-.972.854.863.863 0 0 1-.978-.805zm-4-3.418a.933.933 0 0 1 .968-.775.892.892 0 0 1 .982.726.903.903 0 0 1-.972.854.863.863 0 0 1-.978-.805z"
  }));
};

var _default = LayerMapServiceIcon;
exports["default"] = _default;