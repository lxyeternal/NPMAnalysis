"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BlogIcon = function BlogIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 15.7L8.3 12H0V0h10.95l-1 1H1v10h7.714L11 13.286V11h4V5.85l1-1V12h-4zm3.463-13.821a.98.98 0 0 1 0 1.386l-1.428 1.428h-.001l-3.079 3.08L7.16 9.228l-.854.366.366-.853 1.456-3.796L12.65.42a.965.965 0 0 1 1.385.03zm-2.736 2.708l-1.413-1.415-3.08 3.08 1.414 1.414zm1.888-2.015a.306.306 0 0 0-.09-.217l-.98-.98a.306.306 0 0 0-.434 0l-1.09 1.09 1.414 1.414 1.09-1.09a.306.306 0 0 0 .09-.217z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 7.662l1-1V18h-7v4.745L11.255 18H1V2h16.763l-1 1H2v14h9.668L15 20.331V17h7zm1.657-5.192a.965.965 0 0 1 .03 1.385l-9.325 9.324-4.097 1.755a.371.371 0 0 1-.487-.487l1.755-4.097 9.31-9.309a.98.98 0 0 1 1.385 0zm-10.1 9.965l-1.28-1.28-.961 2.24zm7.243-7.11l-1.414-1.413-6.469 6.47 1.414 1.413zm1.865-2.445l-.804-.838a.42.42 0 0 0-.6-.006l-1.168 1.168 1.414 1.415 1.152-1.152a.42.42 0 0 0 .006-.587z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 8.583l1-1V24h-6v6.125L17.875 24H2V4h20.29l-1 1H3v18h15.29L23 27.71V23h6zm2.352-6.237a1.203 1.203 0 0 1 .037 1.727l-1.8 1.8-.001-.001-12.394 12.395-5.465 2.342a.306.306 0 0 1-.403-.402l2.343-5.465L27.863.547a1.203 1.203 0 0 1 1.727.037zm-15.15 15.258l-1.87-1.87-1.403 3.273zM28.616 5.43l-2.11-2.11-11.587 11.585 2.112 2.11zm2.03-2.377l-1.761-1.762a.285.285 0 0 0-.193-.092.163.163 0 0 0-.12.054l-1.36 1.36 2.111 2.11 1.36-1.359c.133-.133-.02-.294-.037-.311z"
  }));
};

var _default = BlogIcon;
exports["default"] = _default;