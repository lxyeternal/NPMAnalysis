"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DescriptionIcon = function DescriptionIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 4v7h1v-.611A2.875 2.875 0 0 0 7.6 11 2.417 2.417 0 0 0 10 8.5a2.489 2.489 0 0 0-4-1.989V4zm2.5 2.9a1.6 1.6 0 0 1 0 3.2A1.584 1.584 0 0 1 6 8.5a1.602 1.602 0 0 1 1.5-1.6zM1.994 6a2.029 2.029 0 0 0-1.66.717L1 7.263s.2-.363.994-.363a1.034 1.034 0 0 1 .787.262A1.367 1.367 0 0 1 3 8.088c-1.883 0-3.002.252-2.9 1.693A1.498 1.498 0 0 0 1.725 11 1.6 1.6 0 0 0 3 10.393V11h1V7.974a2.049 2.049 0 0 0-.476-1.38A1.97 1.97 0 0 0 1.994 6zm-.168 4.054c-.595 0-.881-.2-.9-.554C.89 8.842 3 8.905 3 8.905a1.176 1.176 0 0 1-1.174 1.15zm13.354.286a2.5 2.5 0 1 1-.004-3.683l-.635.638A1.586 1.586 0 0 0 13.5 6.9a1.6 1.6 0 1 0 1.043 2.803z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 11.805c0-1.885-.825-2.726-2.896-2.726a3.945 3.945 0 0 0-2.79.927l.736.728a3.206 3.206 0 0 1 2.085-.728 1.699 1.699 0 0 1 1.74 1.794v.2h-.45C3.7 12 1 11.805 1 14.016 1 15.316 2.185 16 3.61 16a2.69 2.69 0 0 0 2.31-1.17h.03a4.541 4.541 0 0 0 .074.999h1.08A7.116 7.116 0 0 1 7 14.673zM5.875 13.37c-.03 1.085-.72 1.689-2.07 1.689-.885 0-1.545-.314-1.545-1.157 0-.899.96-.96 2.445-.96h1.17zm6.675-4.344a3.329 3.329 0 0 0-2.52 1.134H10V5H9v10.83h1v-1.177h.03A3.085 3.085 0 0 0 12.73 16a3.33 3.33 0 0 0 3.37-3.487 3.326 3.326 0 0 0-3.55-3.487zm-.003 5.953A2.407 2.407 0 0 1 10 12.513a2.407 2.407 0 0 1 2.547-2.467 2.293 2.293 0 0 1 2.406 2.467 2.293 2.293 0 0 1-2.406 2.466zm6.416-2.502a2.412 2.412 0 0 0 2.401 2.492 2.003 2.003 0 0 0 1.733-.83l.844.787A3.335 3.335 0 0 1 21.364 16a3.357 3.357 0 0 1-3.524-3.523 3.302 3.302 0 0 1 3.524-3.422 3.413 3.413 0 0 1 2.621.959l-.903.788a2.105 2.105 0 0 0-1.718-.817 2.327 2.327 0 0 0-2.401 2.492z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8.093 19.357v1.237a8.672 8.672 0 0 0 .05 1.104h.906a10.419 10.419 0 0 1-.091-1.324v-4.03c0-2.538-1.12-3.67-3.63-3.67a4.501 4.501 0 0 0-3.103 1.154l.577.602a3.975 3.975 0 0 1 2.566-.911c1.669 0 2.625.862 2.625 2.365v.28H7.09c-2.666 0-5.191.468-5.191 3.287 0 1.836 1.518 2.487 2.988 2.487 2.028 0 3.205-1.344 3.205-2.58zM5.15 21C3.8 21 3 20.277 3 19.292c0-1.416.878-2.104 3.13-2.104h1.863v.536C7.94 19.707 6.903 21 5.149 21zm11.763 1a4.524 4.524 0 0 0 4.392-4.693 4.433 4.433 0 0 0-4.633-4.633 3.969 3.969 0 0 0-3.707 1.974V7H12v14.698h.964v-1.925A4.492 4.492 0 0 0 16.912 22zm-.32-8.481a3.55 3.55 0 0 1 3.628 3.788 3.614 3.614 0 1 1-7.22 0 3.522 3.522 0 0 1 3.592-3.788zm7.392 3.85a3.595 3.595 0 0 0 3.568 3.787 3.038 3.038 0 0 0 2.416-1.021l.71.675A4.347 4.347 0 0 1 27.553 22 4.348 4.348 0 0 1 23 17.368a4.394 4.394 0 0 1 4.552-4.633 4.522 4.522 0 0 1 3.172 1.171l-.782.693a3.104 3.104 0 0 0-2.39-1.019 3.482 3.482 0 0 0-3.568 3.788z"
  }));
};

var _default = DescriptionIcon;
exports["default"] = _default;