"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MobileOffIcon = function MobileOffIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 7.828l1-1V15a1 1 0 0 1-1 1H5a.982.982 0 0 1-.776-.395L5 14.829V15h3v-1h1v1h3v-2H6.828l1-1H12zM1.782 15.925l-.707-.707L4 12.293V1a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v2.293l2.218-2.218.707.707zM5 2h7V1H5zm0 9.293l7-7V3H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18 20H7.828L6 21.828v.648A1.524 1.524 0 0 0 7.524 24h9.952A1.524 1.524 0 0 0 19 22.476V8.828l-1 1zm0 2.477a.524.524 0 0 1-.524.523H14v-1h-3v1H7.524A.524.524 0 0 1 7 22.477V21h11zm4.4-19.17l-.354-.353-.354-.354L19 5.293v-2.77A1.524 1.524 0 0 0 17.476 1H7.524A1.524 1.524 0 0 0 6 2.524v15.769l-3.4 3.4.354.353.354.353zM7 2.524A.524.524 0 0 1 7.524 2h9.952a.524.524 0 0 1 .524.523V3H7zM7 4h11v2.293l-11 11z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M23 27H9.828L8 28.828v.25A1.921 1.921 0 0 0 9.921 31H22.08A1.921 1.921 0 0 0 24 29.079v-16.25l-1 1zm0 2.08a.922.922 0 0 1-.921.92H18v-1h-4v1H9.921A.922.922 0 0 1 9 29.08V28h14zm6.228-23.6l-.354-.354-.353-.354L24 9.292v-5.37A1.921 1.921 0 0 0 22.079 2H9.92A1.921 1.921 0 0 0 8 3.921v21.372L3.772 29.52l.354.353.353.354zM9 3.92A.922.922 0 0 1 9.921 3H22.08a.922.922 0 0 1 .921.92V4H9zM9 5h14v5.293l-14 14z"
  }));
};

var _default = MobileOffIcon;
exports["default"] = _default;