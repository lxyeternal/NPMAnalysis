"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FilePptIcon = function FilePptIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v7h1V1h7v4h4v10H2v1h13V3.6zM14 4h-3V1h.31L14 3.69zm-2 2v2h1v1h-1v2h1v1h-1a1 1 0 0 1-1-1V9h-1V8h1V6zm-6 5.936a1.375 1.375 0 0 0 .396.064h1.209A1.397 1.397 0 0 0 9 10.604V9.395A1.397 1.397 0 0 0 7.604 8H6.395A1.375 1.375 0 0 0 6 8.064V8H5v6h1zM6.396 9h1.209A.396.396 0 0 1 8 9.396v1.209a.396.396 0 0 1-.396.395H6.395A.396.396 0 0 1 6 10.604V9.395A.396.396 0 0 1 6.396 9zM4 10.604V9.395A1.397 1.397 0 0 0 2.604 8H1.395A1.375 1.375 0 0 0 1 8.064V8H0v6h1v-2.064a1.375 1.375 0 0 0 .396.064h1.209A1.397 1.397 0 0 0 4 10.604zM2.604 11H1.395A.396.396 0 0 1 1 10.604V9.395A.396.396 0 0 1 1.396 9h1.209A.396.396 0 0 1 3 9.396v1.209a.396.396 0 0 1-.396.395z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v10h1V2h10v6h6v14H4v-2H3v3h18V6.709zM20 7h-5V2h.2L20 6.8zm-4 3v2h2v1h-2v2.5a.501.501 0 0 0 .5.5H18v1h-1.5a1.502 1.502 0 0 1-1.5-1.5V13h-1v-1h1v-2zm-7 6.705a2.018 2.018 0 0 0 1.041.295h.918A2.044 2.044 0 0 0 13 14.959v-.918A2.044 2.044 0 0 0 10.959 12h-.918A2.018 2.018 0 0 0 9 12.295V12H8v7h1zM10.041 13h.918A1.042 1.042 0 0 1 12 14.041v.918A1.042 1.042 0 0 1 10.959 16h-.918A1.042 1.042 0 0 1 9 14.959v-.918A1.042 1.042 0 0 1 10.041 13zm-6 4h.918A2.044 2.044 0 0 0 7 14.959v-.918A2.044 2.044 0 0 0 4.959 12h-.918A2.018 2.018 0 0 0 3 12.295V12H2v7h1v-2.295A2.018 2.018 0 0 0 4.041 17zm0-4h.918A1.042 1.042 0 0 1 6 14.041v.918A1.042 1.042 0 0 1 4.959 16h-.918A1.042 1.042 0 0 1 3 14.959v-.918A1.042 1.042 0 0 1 4.041 13z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v13h1V3h12v8h8v18H6v-1H5v2h22V9.699zm-.3 8V3l7 7zm1 8v3a1 1 0 0 0 1 1h1v1h-1a2.003 2.003 0 0 1-2-2v-3h-1v-1h1v-2h1v2h2v1zM7 17a2.977 2.977 0 0 0-2 .78V17H4v9h1v-3.78A2.992 2.992 0 1 0 7 17zm0 5a2 2 0 1 1 2-2 2.003 2.003 0 0 1-2 2zm7-5a2.977 2.977 0 0 0-2 .78V17h-1v9h1v-3.78A2.992 2.992 0 1 0 14 17zm0 5a2 2 0 1 1 2-2 2.003 2.003 0 0 1-2 2z"
  }));
};

var _default = FilePptIcon;
exports["default"] = _default;