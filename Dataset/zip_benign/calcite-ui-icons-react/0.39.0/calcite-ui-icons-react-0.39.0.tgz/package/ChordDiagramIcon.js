"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ChordDiagramIcon = function ChordDiagramIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.103 14.77a5.947 5.947 0 0 1 .761.897 7.233 7.233 0 0 1-6.747-2.253 5.843 5.843 0 0 1 1.149-.263A6.268 6.268 0 0 0 8.5 14.8c.204 0 .404-.012.603-.03zM6.283 2.61a5.843 5.843 0 0 0 .435-1.18 7.319 7.319 0 0 0-5.014 4.424 5.846 5.846 0 0 0 1.224-.284 6.329 6.329 0 0 1 3.355-2.96zm8.1 1.587a5.868 5.868 0 0 0-.266 1.465A6.252 6.252 0 0 1 14.8 8.5c0 .086-.01.17-.013.256a5.92 5.92 0 0 0 .863 1.216 7.265 7.265 0 0 0-1.266-5.775zm.1 6.263a7.155 7.155 0 0 0 .77.804 7.33 7.33 0 0 1-4.19 4.062 7.147 7.147 0 0 0-.592-.846 6.24 6.24 0 0 0 .672-.27 7.73 7.73 0 0 0-8.19-2.728 6.3 6.3 0 0 0 .387.622 7.033 7.033 0 0 0-.99.314 7.237 7.237 0 0 1-1.01-5.335 7.108 7.108 0 0 0 1.058-.123 6.252 6.252 0 0 0-.14.729A7.814 7.814 0 0 0 8.479 2.2a6.316 6.316 0 0 0-.75.052 7.044 7.044 0 0 0 .258-1.027c.17-.012.34-.026.514-.026a7.265 7.265 0 0 1 4.986 1.983 7.045 7.045 0 0 0-.356 1.06 6.355 6.355 0 0 0-.578-.56 7.77 7.77 0 0 0 1.638 7.503 6.237 6.237 0 0 0 .293-.726zm-.816 1.634a8.725 8.725 0 0 1-1.96-9.007 6.247 6.247 0 0 0-2.219-.801 8.81 8.81 0 0 1-7.277 6.42 6.257 6.257 0 0 0 .34 1.848 8.741 8.741 0 0 1 9.472 3.166 6.35 6.35 0 0 0 1.644-1.626z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.956 21.777a8.688 8.688 0 0 1 .84.932 10.123 10.123 0 0 1-8.736-3.106 8.561 8.561 0 0 1 1.239-.192A9.251 9.251 0 0 0 12.5 21.8c.154 0 .304-.016.456-.023zM10.37 3.456a8.585 8.585 0 0 0 .584-1.127A10.319 10.319 0 0 0 3.44 7.603a8.642 8.642 0 0 0 1.26-.148 9.318 9.318 0 0 1 5.672-4zm11.478 4.748a8.546 8.546 0 0 0-.407 1.77A9.256 9.256 0 0 1 21.8 12.5a9.352 9.352 0 0 1-.055.992 8.57 8.57 0 0 0 .697 1.656 10.104 10.104 0 0 0-.593-6.944zm-.702 7.697a10.14 10.14 0 0 0 .648 1.007 10.335 10.335 0 0 1-6.383 5.466 10.194 10.194 0 0 0-.65-.864 9.214 9.214 0 0 0 1.657-.588 11.68 11.68 0 0 0-12.271-4.359 9.301 9.301 0 0 0 .919 1.502 10.035 10.035 0 0 0-1.053.26 10.208 10.208 0 0 1-1.23-9.21c.072 0 .143.01.216.01.29 0 .576-.02.86-.044a9.202 9.202 0 0 0-.494 1.7 11.805 11.805 0 0 0 10.6-7.454A9.284 9.284 0 0 0 12.5 3.2c-.103 0-.204.012-.306.016a10.042 10.042 0 0 0 .403-1.01 10.286 10.286 0 0 1 8.312 4.366 10.046 10.046 0 0 0-.466 1.116 9.344 9.344 0 0 0-1.18-1.553 11.727 11.727 0 0 0 .985 11.498 9.28 9.28 0 0 0 .899-1.732zm-1.522 2.565A12.68 12.68 0 0 1 18.503 5.41a9.277 9.277 0 0 0-3.55-1.87 12.806 12.806 0 0 1-11.717 8.248 9.322 9.322 0 0 0-.036.712 9.237 9.237 0 0 0 .555 3.133 12.676 12.676 0 0 1 13.554 4.812 9.362 9.362 0 0 0 2.316-1.98z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5.5 10.75c-.321 0-.636-.024-.95-.048A13.303 13.303 0 0 1 16.5 3.2c.102 0 .202.013.304.016-.143.34-.303.67-.474.993a12.304 12.304 0 0 0-10.692 6.534c-.046 0-.091.007-.138.007zm22.613-.714q-.318.51-.585 1.05a12.154 12.154 0 0 1 0 10.827q.268.542.585 1.05a13.231 13.231 0 0 0 0-12.927zm-2.494-1.76a15.188 15.188 0 0 0 0 16.448 12.364 12.364 0 0 0 1.029-1.287c.18.308.368.61.571.903a13.29 13.29 0 0 1-8.867 5.315q-.183-.483-.4-.949a12.183 12.183 0 0 0 1.575-.299A15.317 15.317 0 0 0 5.5 19.2c-.33 0-.654.029-.979.05a12.156 12.156 0 0 0 .461 1.526c-.349.013-.696.03-1.038.068a13.067 13.067 0 0 1 0-8.689c.342.04.69.056 1.038.069a12.156 12.156 0 0 0-.46 1.526c.324.021.648.05.978.05a15.317 15.317 0 0 0 14.027-9.207 12.183 12.183 0 0 0-1.575-.3q.218-.465.4-.948a13.29 13.29 0 0 1 8.867 5.315c-.203.292-.39.595-.571.903a12.364 12.364 0 0 0-1.029-1.287zm-.72-.737a12.299 12.299 0 0 0-4.402-2.659A16.324 16.324 0 0 1 5.5 14.8c-.391 0-.775-.031-1.16-.059A12.279 12.279 0 0 0 4.2 16.5a12.279 12.279 0 0 0 .14 1.759c.385-.028.769-.059 1.16-.059a16.324 16.324 0 0 1 14.997 9.92 12.299 12.299 0 0 0 4.402-2.66 16.226 16.226 0 0 1 0-17.92zM5.639 22.257c-.047 0-.092-.007-.139-.007-.321 0-.636.024-.95.048A13.303 13.303 0 0 0 16.5 29.8c.102 0 .202-.013.304-.016-.143-.34-.303-.67-.474-.993a12.304 12.304 0 0 1-10.692-6.534z"
  }));
};

var _default = ChordDiagramIcon;
exports["default"] = _default;