"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BrushMarkIcon = function BrushMarkIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.469 7.5a.968.968 0 0 0 .105-.79 1.346 1.346 0 0 0-.699-.632c-.36-.187-.783-.335-1.225-.516a2.665 2.665 0 0 1-1.368-.975 1.284 1.284 0 0 1-.09-1.07 1.66 1.66 0 0 1 .584-.747 3.72 3.72 0 0 1 1.443-.603 6.675 6.675 0 0 1 2.917.071.4.4 0 0 1 .295.483.405.405 0 0 1-.475.297 5.84 5.84 0 0 0-2.539.02 2.847 2.847 0 0 0-1.065.475c-.287.232-.308.43-.217.577a1.969 1.969 0 0 0 .893.503c.411.152.863.286 1.329.503a2.422 2.422 0 0 1 1.28 1.185 2.11 2.11 0 0 1-.149 1.855 3.04 3.04 0 0 1-1.311 1.08l-1.247.577c-.778.383-1.18.817-1.207 1.5-.14.874.65 1.437 1.662 1.711a2.895 2.895 0 0 1-.45.31.999.999 0 0 0-.54.84.973.973 0 0 0 .01.128c-.138-.058-.278-.107-.416-.177A3.347 3.347 0 0 1 .682 12.94a2.777 2.777 0 0 1-.381-1.775 2.875 2.875 0 0 1 .71-1.639 4.038 4.038 0 0 1 1.354-.92c.886-.393 1.813-.65 2.104-1.107zm.548 4.565c.03-1.327 1.55-1.238 1.55-1.238l1.325 1.556s.097 1.197-1.548 1.928a3.26 3.26 0 0 1-2.95-.109s1.594-.824 1.623-2.137zm1 .023a2.838 2.838 0 0 1-.442 1.438 2.547 2.547 0 0 0 .363-.13 1.703 1.703 0 0 0 .886-.724l-.673-.79a.204.204 0 0 0-.134.206zM16 4.62c-.307-.38-.195-.242-.505-.62-.483.388-4.29 3.006-4.29 3.006l-3.665 3.27 1.027 1.228 3.65-3.254s3.3-3.238 3.783-3.63z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.334 21.39a6.166 6.166 0 0 1-1.151-.317 4.233 4.233 0 0 1-2.014-1.575 3.945 3.945 0 0 1 .575-4.804 13.407 13.407 0 0 1 3.549-2.401c1.133-.607 2.337-1.328 2.458-2.122.073-.41-.072-.67-.52-1.024a7.441 7.441 0 0 0-1.631-.82c-.61-.243-1.249-.463-1.903-.766a5.268 5.268 0 0 1-.99-.578 1.985 1.985 0 0 1-.786-1.19 1.525 1.525 0 0 1 .09-.828 1.803 1.803 0 0 1 .426-.606 3.477 3.477 0 0 1 1.022-.645 7.69 7.69 0 0 1 2.105-.529 10.898 10.898 0 0 1 4.193.338.5.5 0 0 1-.265.965 9.856 9.856 0 0 0-3.786-.207 6.592 6.592 0 0 0-1.775.49 2.352 2.352 0 0 0-.665.433c-.164.187-.174.241-.154.37.023.236.537.597 1.107.822.572.244 1.21.443 1.854.675a8.645 8.645 0 0 1 1.979.932 2.905 2.905 0 0 1 .907.96 2.275 2.275 0 0 1 .25 1.423 3.454 3.454 0 0 1-1.347 2.122 14.096 14.096 0 0 1-1.778 1.182 12.174 12.174 0 0 0-3.041 2.157 2.45 2.45 0 0 0-.617 1.33 1.794 1.794 0 0 0 .295 1.28A3.3 3.3 0 0 0 5.5 19.5a.99.99 0 0 1 .363.063 2.958 2.958 0 0 1-.755.639 1.493 1.493 0 0 0-.774 1.189zM22.11 6.018L18.4 9.35l-7.45 7.25 1.4 1.4 7.25-7.449 3.383-3.661a.626.626 0 0 0-.873-.873zM9.368 17.619l1.439 1.738a2.94 2.94 0 0 1-1.63 2.234 3.92 3.92 0 0 1-1.626.359 3.598 3.598 0 0 1-1.733-.427s1.8-.968 1.809-2.464c.006-1.38 1.451-1.44 1.703-1.44zm.35 1.99l-.78-.94a.379.379 0 0 0-.311.395 3.191 3.191 0 0 1-.633 1.85 3.042 3.042 0 0 0 .772-.234 1.823 1.823 0 0 0 .952-1.07z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5.003 27.966a5.58 5.58 0 0 1-2.587-1.898 4.471 4.471 0 0 1-.713-1.553 4.897 4.897 0 0 1-.062-1.668 5.431 5.431 0 0 1 1.346-2.88 17.79 17.79 0 0 1 4.638-3.256c1.496-.861 3.123-1.86 3.136-3.173.05-.583-.376-1.093-1.062-1.531a13.298 13.298 0 0 0-2.327-1.074 27.362 27.362 0 0 1-2.567-1.058 4.726 4.726 0 0 1-1.275-.891 2.387 2.387 0 0 1-.504-.764 2.077 2.077 0 0 1-.114-.96 2.45 2.45 0 0 1 .866-1.516 4.98 4.98 0 0 1 1.301-.799 11.286 11.286 0 0 1 2.746-.753 21.724 21.724 0 0 1 5.538-.074.5.5 0 0 1-.1.995 20.69 20.69 0 0 0-5.258.168 10.197 10.197 0 0 0-2.45.717c-.743.328-1.41.878-1.444 1.402-.095.497.497.975 1.262 1.335.753.36 1.607.635 2.462.941a14.478 14.478 0 0 1 2.606 1.137 4.333 4.333 0 0 1 1.221 1.05 2.687 2.687 0 0 1 .57 1.704 3.326 3.326 0 0 1-.45 1.65 5.138 5.138 0 0 1-1.009 1.223 14.867 14.867 0 0 1-2.332 1.651 16.603 16.603 0 0 0-4.136 3.004 3.112 3.112 0 0 0-.383 3.868 4.265 4.265 0 0 0 2.722 1.431 4.596 4.596 0 0 1-.93.715 1.498 1.498 0 0 0-.711.857zM28.825 7.013L23.2 12.202 12.6 22.8l1.6 1.6 10.6-10.598 5.189-5.625a.835.835 0 0 0-1.164-1.164zM11.157 23.225l1.918 2.317a3.919 3.919 0 0 1-2.171 2.98 5.22 5.22 0 0 1-2.166.477 4.802 4.802 0 0 1-2.313-.568s2.4-1.29 2.411-3.286c.008-1.84 1.935-1.92 2.271-1.92h.05zm.841 2.584l-1.288-1.555c-.456.073-.871.303-.874.896a4.237 4.237 0 0 1-1.263 2.845q.081.004.165.004a4.238 4.238 0 0 0 1.754-.389 2.801 2.801 0 0 0 1.506-1.801z"
  }));
};

var _default = BrushMarkIcon;
exports["default"] = _default;