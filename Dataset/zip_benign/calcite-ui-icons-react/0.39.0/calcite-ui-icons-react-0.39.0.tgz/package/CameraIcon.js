"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CameraIcon = function CameraIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 14h-13A1.502 1.502 0 0 1 0 12.5v-8A1.502 1.502 0 0 1 1.5 3H2V2h4v1h1a1.001 1.001 0 0 1 1-1h5a1.001 1.001 0 0 1 1 1h.5A1.502 1.502 0 0 1 16 4.5v8a1.502 1.502 0 0 1-1.5 1.5zM1.5 4a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5H14a1.001 1.001 0 0 1-1-1H8a1.001 1.001 0 0 1-1 1H5V3H3v1zM5 5.5V5H2v1h3zm5.5-.5A3.5 3.5 0 1 0 14 8.5 3.504 3.504 0 0 0 10.5 5zm0 6A2.5 2.5 0 1 1 13 8.5a2.5 2.5 0 0 1-2.5 2.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 8a4.5 4.5 0 1 0 4.5 4.5A4.505 4.505 0 0 0 14.5 8zm0 8a3.5 3.5 0 1 1 3.5-3.5 3.504 3.504 0 0 1-3.5 3.5zM8 9H4V8h4zm13 11H3a2.002 2.002 0 0 1-2-2V8a2.002 2.002 0 0 1 2-2h1V5h4v1h1.5a.5.5 0 0 0 .5-.5A1.502 1.502 0 0 1 11.5 4h6A1.502 1.502 0 0 1 19 5.5a.5.5 0 0 0 .5.5H21a2.002 2.002 0 0 1 2 2v10a2.002 2.002 0 0 1-2 2zM3 7a1.001 1.001 0 0 0-1 1v10a1.001 1.001 0 0 0 1 1h18a1.001 1.001 0 0 0 1-1V8a1.001 1.001 0 0 0-1-1h-1.5A1.502 1.502 0 0 1 18 5.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0-.5.5A1.502 1.502 0 0 1 9.5 7H7V6H5v1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 12.5v.5H6v-1h5zm19 11v-12A2.503 2.503 0 0 0 27.5 9H27a1.001 1.001 0 0 1-1-1 2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2 1.001 1.001 0 0 1-1 1h-2V8H6v1H4.5A2.503 2.503 0 0 0 2 11.5v12A2.503 2.503 0 0 0 4.5 26h23a2.503 2.503 0 0 0 2.5-2.5zM7 10V9h3v1h3a2.002 2.002 0 0 0 2-2 1.001 1.001 0 0 1 1-1h8a1.001 1.001 0 0 1 1 1 2.002 2.002 0 0 0 2 2h.5a1.502 1.502 0 0 1 1.5 1.5v12a1.502 1.502 0 0 1-1.5 1.5h-23A1.502 1.502 0 0 1 3 23.5v-12A1.502 1.502 0 0 1 4.5 10zm18.8 7a5.8 5.8 0 1 0-5.8 5.8 5.806 5.806 0 0 0 5.8-5.8zm-1 0a4.8 4.8 0 1 1-4.8-4.8 4.805 4.805 0 0 1 4.8 4.8z"
  }));
};

var _default = CameraIcon;
exports["default"] = _default;