"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CollaborationDistributedIcon = function CollaborationDistributedIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.864 9.204a5.886 5.886 0 0 0-2.947-6.436 2.925 2.925 0 0 0-5.834 0 5.885 5.885 0 0 0-2.947 6.436 2.929 2.929 0 1 0 .991-.132A4.915 4.915 0 0 1 5.204 3.86a2.92 2.92 0 0 0 5.594 0 4.915 4.915 0 0 1 2.075 5.212 2.956 2.956 0 1 0 .992.132zM4.96 12A1.96 1.96 0 1 1 3 10.04 1.962 1.962 0 0 1 4.96 12zM8 4.96A1.96 1.96 0 1 1 9.96 3 1.962 1.962 0 0 1 8 4.96zm5 9A1.96 1.96 0 1 1 14.96 12 1.962 1.962 0 0 1 13 13.96z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19.902 13.161a7.876 7.876 0 0 0-3.956-8.1c0-.021.006-.04.006-.061a3.952 3.952 0 0 0-7.904 0c0 .02.006.04.006.06a7.876 7.876 0 0 0-3.956 8.101 3.946 3.946 0 1 0 .986-.105A7.1 7.1 0 0 1 4.996 12a6.977 6.977 0 0 1 3.232-5.885 3.926 3.926 0 0 0 7.544 0A6.977 6.977 0 0 1 19.004 12a7.1 7.1 0 0 1-.088 1.056 3.96 3.96 0 1 0 .986.105zM7.948 17A2.948 2.948 0 1 1 5 14.052 2.951 2.951 0 0 1 7.948 17zM12 7.948A2.948 2.948 0 1 1 14.948 5 2.951 2.951 0 0 1 12 7.948zm7 12A2.948 2.948 0 1 1 21.948 17 2.951 2.951 0 0 1 19 19.948z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M25.745 18.13a9.85 9.85 0 0 0-4.832-10.818c.006-.105.031-.205.031-.312a4.944 4.944 0 1 0-9.888 0c0 .107.025.207.031.312A9.85 9.85 0 0 0 6.255 18.13a4.945 4.945 0 1 0 .995-.05 8.888 8.888 0 0 1 4.02-9.72 4.913 4.913 0 0 0 9.46 0 8.888 8.888 0 0 1 4.02 9.72 4.944 4.944 0 1 0 .994.05zM10.956 23A3.956 3.956 0 1 1 7 19.044 3.96 3.96 0 0 1 10.956 23zM16 10.956A3.956 3.956 0 1 1 19.956 7 3.96 3.96 0 0 1 16 10.956zm9 16A3.956 3.956 0 1 1 28.956 23 3.96 3.96 0 0 1 25 26.956z"
  }));
};

var _default = CollaborationDistributedIcon;
exports["default"] = _default;