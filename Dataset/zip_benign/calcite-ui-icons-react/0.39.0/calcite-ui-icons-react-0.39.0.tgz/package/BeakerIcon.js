"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BeakerIcon = function BeakerIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 5.271l-4.725 7.424A1.5 1.5 0 0 0 2.541 15h10.918a1.5 1.5 0 0 0 1.265-2.306L10 5.271V2.214A.214.214 0 0 1 10.214 2h.572A.214.214 0 0 0 11 1.786v-.572A.214.214 0 0 0 10.786 1H5.214A.214.214 0 0 0 5 1.214v.572A.214.214 0 0 0 5.214 2h.572A.214.214 0 0 1 6 2.214zm7.897 8.47a.5.5 0 0 1-.438.259H2.541a.5.5 0 0 1-.422-.769L4.176 10h7.648l.636 1H10v1h3.097l.783 1.231a.501.501 0 0 1 .017.51zM7 2h2v1H8v1h1v1.562L9.279 6H8v1h1.915l1.273 2H4.812L7 5.562z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 7.942V3.218A.218.218 0 0 1 15.218 3h.564A.218.218 0 0 0 16 2.782v-.564A.218.218 0 0 0 15.782 2H8.218A.218.218 0 0 0 8 2.218v.564A.218.218 0 0 0 8.218 3h.564A.218.218 0 0 1 9 3.218v4.724l-6.627 10.7A2.2 2.2 0 0 0 4.243 22h15.513a2.2 2.2 0 0 0 1.871-3.358zm-5 .284V3h4v2h-2v1h2v2h-2v1h2.48l1.238 2H13v1h3.337l1.239 2H6.424zm10.805 12.158a1.2 1.2 0 0 1-1.049.616H4.243a1.2 1.2 0 0 1-1.02-1.832L5.805 15h12.39l1.239 2H16v1h4.053l.723 1.168a1.2 1.2 0 0 1 .029 1.216z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.469 25.11l-9.463-14.143V4.354A.38.38 0 0 1 19.383 4h1.234A.383.383 0 0 0 21 3.617v-.234A.383.383 0 0 0 20.617 3h-9.234a.383.383 0 0 0-.383.383v.234a.383.383 0 0 0 .383.383h1.234a.383.383 0 0 1 .383.383V5l.006 5.95L3.53 25.11A2.5 2.5 0 0 0 5.61 29h20.782a2.5 2.5 0 0 0 2.078-3.89zM14.006 11.253V4H18v1l.006 3H16v1h2.006v2.271l.488.729H16v1h3.163l2.007 3H18v1h3.84l2.006 3H8.153zm13.632 14.413A1.5 1.5 0 0 1 26.39 28H5.609a1.5 1.5 0 0 1-1.247-2.334L7.484 21h17.032l2.007 3H22v1h5.192z"
  }));
};

var _default = BeakerIcon;
exports["default"] = _default;