"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ClassifyObjectsIcon = function ClassifyObjectsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 15V1H1v14h14zm-1-8h-3V4h3zM8.166 2a4.136 4.136 0 0 0-2.124 1.856 2.185 2.185 0 0 0 .664 2.49.983.983 0 0 1 .106.127 5.338 5.338 0 0 1-1.073.325 3.424 3.424 0 0 0-1.633.655 1.623 1.623 0 0 0-.438 1.503c.053.418.102.852-1.668 1.677V2zM2 14v-2.276c2.397-1.045 2.799-1.81 2.66-2.895-.04-.318-.057-.45.167-.683a3.748 3.748 0 0 1 1.14-.375c.854-.2 1.662-.39 1.848-1.02a1.119 1.119 0 0 0-.388-1.098c-.738-.765-.532-1.247-.465-1.405C7.489 3.007 10.549 2 12.267 2H14v1h-4v5h4v6h-1v-3h-3V9H6v4h3v1zm7-2H7v-2h2v2zm1 2v-2h2v2zm3-8h-1V5h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 22h20V2H2zm13-1v-4h4v4zm-1-5v2h-4v-4h4zm7-5h-5V6h5zm0-6h-6v7h6v9h-1v-5h-5v-3H9v6h5v2H3v-3.01a2.73 2.73 0 0 0 2.646-1.73 4.09 4.09 0 0 0 .284-1.968c-.036-1.181-.059-1.962 2.632-2.296 1.567-.194 2.724-.975 2.813-1.899.04-.42-.113-1.198-1.602-1.684a1.35 1.35 0 0 1-1.037-.99c-.054-.512.412-1.097 1.28-1.602A25.765 25.765 0 0 1 20.52 3H21zm-6.487-2a21.356 21.356 0 0 0-5.001 1.957c-1.674.976-1.827 2.03-1.77 2.573a2.283 2.283 0 0 0 1.72 1.834c.656.214.934.474.918.637-.027.277-.698.849-1.942 1.003-3.33.413-3.557 1.69-3.508 3.319a3.207 3.207 0 0 1-.187 1.506A1.747 1.747 0 0 1 3 16.991V3zM20 10h-3V7h3zm-7 7h-2v-2h2zm3 1h2v2h-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 3v26h26V3zm17.105 1a32.286 32.286 0 0 0-7.359 3.326c-1.975 1.164-2.155 2.405-2.087 3.041a2.677 2.677 0 0 0 2.008 2.146c.488.161 1.296.554 1.216 1.37a2.594 2.594 0 0 1-2.358 1.94c-4.672.586-4.544 2.901-4.475 4.145a2.83 2.83 0 0 1 .004.548c-.63.955-1.2 1.05-2.332 1.238-.223.037-.466.08-.722.13V4zM20 28v-5h5v5zm-1-6v3h-5v-5h5zm9-9h-6V7h6zm-7-7v8h7v14h-2v-6h-6v-3h-7v7h6v2H4v-5.095c.319-.065.619-.12.886-.164a3.671 3.671 0 0 0 3.002-1.674 1.856 1.856 0 0 0 .16-1.154c-.065-1.17-.145-2.627 3.602-3.097a3.59 3.59 0 0 0 3.229-2.837 2.359 2.359 0 0 0-1.899-2.415 1.745 1.745 0 0 1-1.327-1.303c-.072-.676.511-1.43 1.6-2.073A27.175 27.175 0 0 1 25.524 4H28v2zm0 18h3v3h-3zm-3 0h-3v-3h3zm9-12h-4V8h4z"
  }));
};

var _default = ClassifyObjectsIcon;
exports["default"] = _default;