"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FollowPlayIcon = function FollowPlayIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 10V9h1v1zm-2 5h5v-1H2v-4H1zm0-9h1V2h4V1H1zm3 7v-1H3v1zm8-8H9v1h3zM7 4h1V1H7zM5 8V7H4v1zm5-6h4v4h1V1h-5zM3 6h3V5H3zm5-1H7v1h1zm0 2H7v2.99h1zm8 4.5L10 16V7zM11 14l3.333-2.5L11 9z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19 9h-4V8h4zm-7 6h1v-4h-1zm2-7.25v1.5a.75.75 0 0 1-.75.75h-1.5a.75.75 0 0 1-.75-.75v-1.5a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 .75.75zM13 8h-1v1h1zm-5 5h2v-2H8zM6 9h4V8H6zm-3 7H2v6h6v-1H3zM17 3h5v5h1V2h-6zM8 2H2v6h1V3h5zm5 0h-1v4h1zM6 16h2v-2H6zm1 3v-2H5v2zm9-6.95l6.707 5.451L16 22.95zm1 8.8l4.121-3.349L17 14.151z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 10V3h7v1H4v6zm26 0V3h-7v1h6v6zM10 28H4v-6H3v7h7zm4-13h-2v2h2zm-4 3H8v2h2zm-1 5H7v2h2zm11-11h6v-1h-6zM9 12h6v-1H9zm8 2v6h1v-6zm0-11v6h1V3zm2 8.07v.86A1.07 1.07 0 0 1 17.93 13h-.86A1.07 1.07 0 0 1 16 11.93v-.86A1.07 1.07 0 0 1 17.07 10h.86A1.07 1.07 0 0 1 19 11.07zM18 11h-1v1h1zm5 7v12l8-6zm1 2l5.333 4L24 28z"
  }));
};

var _default = FollowPlayIcon;
exports["default"] = _default;