"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var InboxIcon = function InboxIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.123 5l1.714 6H10v.5a1.5 1.5 0 1 1-3 0V11H2.163l1.714-6H6V4H3.123l-2.104 7.363L1 16h15v-4.5L13.877 4H11v1zM2 15v-3h4.05a2.5 2.5 0 0 0 4.899 0H15v3zM8 0h1v8.294l1.62-1.619.706.707-2.809 2.81-2.809-2.81.707-.707L8 8.26z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 6v1h3.15l3.636 10H15v.5a2.5 2.5 0 0 1-5 0V17H3.214L6.85 7H10V6H6.15L2.03 17.33 2 23h21v-5.5L18.85 6zM3 22v-4h6.036a3.5 3.5 0 0 0 6.928 0H22v4zm9-21h1v12.293l2.646-2.646.707.707-3.853 3.853-3.854-3.853.707-.707L12 13.293z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19 10v1h5.157l4.615 12H20v.5a3.5 3.5 0 0 1-7 0V23H4.228l4.615-12H14v-1H8.157L3.033 23.32 3 30h27v-6.5L24.843 10zM4 29v-5h8.028a4.5 4.5 0 0 0 8.944 0H29v5zM16 2h1v16.293l2.646-2.646.707.707-3.853 3.853-3.854-3.854.707-.707L16 18.293z"
  }));
};

var _default = InboxIcon;
exports["default"] = _default;