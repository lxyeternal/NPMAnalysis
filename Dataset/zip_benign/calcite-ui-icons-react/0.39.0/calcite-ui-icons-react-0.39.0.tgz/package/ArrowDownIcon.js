"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ArrowDownIcon = function ArrowDownIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 2v10.295l1.62-1.62.706.707-2.808 2.81-2.81-2.81.707-.707L8 12.26V2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.354 16.646L12 19.293V3h1v16.293l2.646-2.646.707.707-3.853 3.853-3.854-3.853z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.5 27.207l-4.854-4.854.707-.707L16 25.293V5h1v20.293l3.646-3.646.707.707z"
  }));
};

var _default = ArrowDownIcon;
exports["default"] = _default;