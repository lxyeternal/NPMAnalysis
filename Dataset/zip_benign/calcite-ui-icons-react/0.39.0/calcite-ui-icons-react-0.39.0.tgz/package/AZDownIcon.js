"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AZDownIcon = function AZDownIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.5 14.2l-2.828-2.828.707-.708L12 12.286v-9.2h1v9.2l1.621-1.622.707.708zM7 7L6 5H2L1 7H0l3.5-7h1L8 7zM5.5 4L4.004 1.008 2.5 4zM1.111 16H7v-1H2.5l4.3-5V9H1v1h4.5l-4.389 5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.354 16.354L18.5 20.207l-3.854-3.854.707-.707L18 18.293V4.053h1v14.24l2.646-2.646zM4 14h6.707L4 21.707V23h8v-1H5.293L12 14.293V13H4zM8.5 1l4.05 9h-.99l-1.38-3H5.82l-1.38 3h-.99L7.5 1zm1.222 5L8 2.25 6.278 6z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.643 22.643l.707.707-3.85 3.85-3.85-3.85.707-.707L25 25.286V5h1v20.286zM9.189 10h5.622l1.677 4h1.084L15.5 9.057V9h-.024l-2.934-7h-1.084L8.524 9H8.5v.057L6.428 14h1.084zM12 3.293L14.392 9H9.608zM7 18h10v.707L8.707 29H17v1H7v-.707L15.293 19H7z"
  }));
};

var _default = AZDownIcon;
exports["default"] = _default;