"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ClockDownIcon = function ClockDownIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 8.5A4.5 4.5 0 1 0 4.5 4 4.5 4.5 0 0 0 0 8.5zm8 0A3.5 3.5 0 1 1 4.5 5 3.504 3.504 0 0 1 8 8.5zM5 6v2h1v1H4V6zm8-1.914v8.209l1.62-1.62.706.707-2.808 2.81-2.81-2.81.707-.707L12 12.26V4.086z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 5.2a6.8 6.8 0 1 0 6.8 6.8A6.8 6.8 0 0 0 7 5.2zm0 12.6a5.8 5.8 0 1 1 5.8-5.8A5.806 5.806 0 0 1 7 17.8zM7 12h3v1H6V8h1zm15.646 3.646l.707.707-3.853 3.854-3.854-3.854.707-.707L19 18.293V5.053h1v13.24z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 26.8A10.8 10.8 0 1 0 1.2 16 10.8 10.8 0 0 0 12 26.8zm0-20.6A9.8 9.8 0 1 1 2.2 16 9.811 9.811 0 0 1 12 6.2zM16 17h-5v-7h1v6h4zm15.354 6.354L27.5 27.207l-3.854-3.854.707-.707L27 25.293V5h1v20.293l2.646-2.646z"
  }));
};

var _default = ClockDownIcon;
exports["default"] = _default;