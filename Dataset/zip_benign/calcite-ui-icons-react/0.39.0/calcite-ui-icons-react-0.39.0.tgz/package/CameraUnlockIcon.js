"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CameraUnlockIcon = function CameraUnlockIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 6a3 3 0 1 0-3 3 3.003 3.003 0 0 0 3-3zM7 6a2 2 0 1 1 2 2 2.003 2.003 0 0 1-2-2zm7 2a1.96 1.96 0 0 0-1.95 2v1h-3.3a.751.751 0 0 0-.75.75v3.5a.751.751 0 0 0 .75.75h4.5a.751.751 0 0 0 .75-.75v-3.5a.751.751 0 0 0-.75-.75H13v-1a1 1 0 0 1 2 0v2h1v-2a2.002 2.002 0 0 0-2-2zm-1 7H9v-3h4zM2 3h3v1H2zm8 10h2v1h-2zm-8.625-3H7v1H1.375A1.377 1.377 0 0 1 0 9.625v-7.25A1.377 1.377 0 0 1 1.375 1H2V0h3v1h1V0h6v1h.634A1.385 1.385 0 0 1 14 2.4V7h-1V2.4a.385.385 0 0 0-.366-.4H11V1H7v1H4V1H3v1H1.375A.375.375 0 0 0 1 2.375v7.25a.375.375 0 0 0 .375.375z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 12.8A3.8 3.8 0 1 0 9.2 9a3.804 3.804 0 0 0 3.8 3.8zm0-6.6A2.8 2.8 0 1 1 10.2 9 2.803 2.803 0 0 1 13 6.2zM4 6h4v1H4zm11 15h-1v-3h1v1h1v1h-1zm4.5-10a3.504 3.504 0 0 0-3.5 3.5V16h-5.125a.877.877 0 0 0-.875.875v5.25a.877.877 0 0 0 .875.875h7.25a.877.877 0 0 0 .875-.875V14.5a.5.5 0 0 1 1 0V18h3v-3.5a3.504 3.504 0 0 0-3.5-3.5zM18 22h-7v-5h7zm4-5h-1v-2.5a1.5 1.5 0 0 0-3 0V16h-1v-1.5a2.5 2.5 0 0 1 5 0zM3 15h6v1H3a2.003 2.003 0 0 1-2-2V5a2.003 2.003 0 0 1 2-2h1V2h4v1h.5a.501.501 0 0 0 .5-.5A1.502 1.502 0 0 1 10.5 1h5A1.502 1.502 0 0 1 17 2.5a.501.501 0 0 0 .5.5H19a2.003 2.003 0 0 1 2 2v5h-1V5a1 1 0 0 0-1-1h-1.5A1.502 1.502 0 0 1 16 2.5a.501.501 0 0 0-.5-.5h-5a.501.501 0 0 0-.5.5A1.502 1.502 0 0 1 8.5 4H7V3H5v1H3a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5 9h5v1H5zm8.2 4a4.8 4.8 0 1 1 4.8 4.8 4.805 4.805 0 0 1-4.8-4.8zm1 0A3.8 3.8 0 1 0 18 9.2a3.804 3.804 0 0 0-3.8 3.8zM31 18v4h-3v-4a1 1 0 0 0-2 0v10a1.003 1.003 0 0 1-1 1H15a1.003 1.003 0 0 1-1-1v-7a1.003 1.003 0 0 1 1-1h8v-2a4 4 0 0 1 8 0zm-6 3H15v7h10zm5-3a3 3 0 0 0-6 0v2h1v-2a2 2 0 0 1 4 0v3h1zm-10 4h-1v5h1v-1h1v-1h-1v-1h1v-1h-1zM2 19.5v-11A1.502 1.502 0 0 1 3.5 7H6V6h3v1h3a2.003 2.003 0 0 0 2-2 1 1 0 0 1 1-1h6a1 1 0 0 1 1 1 2.003 2.003 0 0 0 2 2h.5A1.502 1.502 0 0 1 26 8.5V13h1V8.5A2.502 2.502 0 0 0 24.5 6H24a1 1 0 0 1-1-1 2.003 2.003 0 0 0-2-2h-6a2.003 2.003 0 0 0-2 2 1 1 0 0 1-1 1h-2V5H5v1H3.5A2.502 2.502 0 0 0 1 8.5v11A2.502 2.502 0 0 0 3.5 22H13v-1H3.5A1.502 1.502 0 0 1 2 19.5z"
  }));
};

var _default = CameraUnlockIcon;
exports["default"] = _default;