"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LineCheckIcon = function LineCheckIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.557 13.725l4.985-4.984.707.707-5.692 5.691L6.75 12.33l.707-.707zM16 0h-2v1.657L10.036 8h-.329L6 4.293V3H4v1.374L1.073 10H0v2h2v-1.617L4.8 5h.493L9 8.707V10h2V8.343L14.965 2H16z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.491 14.819l.7.715-7.684 7.522-3.531-3.32.685-.73 2.832 2.664zM21 1h3v3h-1.796l-5.25 9H17v3h-3v-2.455L9.148 8h-1.01L3 16.074V19H0v-3h1.862L7 7.926V5h3v2.455L14.851 13h.945l5.25-9H21zM8 7h1V6H8zM2 17H1v1h1zm14-3h-1v1h1zm6-12v1h1V2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M31.248 20.481L20.513 31.06l-3.957-3.75.687-.725 3.256 3.084 10.048-9.898zM4 24H1v-3h1.93L10 10.788V8h3v2.293L19.707 17h1.11l7.2-12H28V2h3v3h-1.817l-7.2 12H22v3h-3v-2.293L12.293 11H11.07L4 21.212zM29 4h1V3h-1zm-8 14h-1v1h1zm-10-8h1V9h-1zM3 23v-1H2v1z"
  }));
};

var _default = LineCheckIcon;
exports["default"] = _default;