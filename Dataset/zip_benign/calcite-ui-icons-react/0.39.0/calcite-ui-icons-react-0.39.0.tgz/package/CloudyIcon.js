"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CloudyIcon = function CloudyIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.93 6.312a3.978 3.978 0 0 0-6.49-2.371 2.48 2.48 0 0 0-3.977.118 1.98 1.98 0 0 0-2.427 2.295 2.224 2.224 0 0 0-.001 3.758A2.473 2.473 0 0 0 3.5 13h9a3.496 3.496 0 0 0 1.43-6.688zM12.5 12h-9a1.498 1.498 0 0 1-.273-2.97l.678-.126.124-.677a1.462 1.462 0 0 1 1.84-1.173l.986.252.233-.992a2.989 2.989 0 0 1 5.857.17l.092.522.484.218A2.496 2.496 0 0 1 12.5 12zM1 8.233a1.228 1.228 0 0 1 .574-1.036l.564-.36-.118-.66A.98.98 0 0 1 3 5a1.013 1.013 0 0 1 .231.032l.657.156.39-.55a1.491 1.491 0 0 1 2.48.051 3.987 3.987 0 0 0-.643 1.396 2.462 2.462 0 0 0-3.07 1.96A2.498 2.498 0 0 0 1.414 9.14 1.219 1.219 0 0 1 1 8.233z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19.95 8.719a5.48 5.48 0 0 0-8.723-2.429 3.41 3.41 0 0 0-5.466.166 2.722 2.722 0 0 0-3.337 3.155 3.05 3.05 0 0 0-.414 4.848c0 .035-.01.068-.01.104A3.438 3.438 0 0 0 5.438 18h12.75a4.807 4.807 0 0 0 1.761-9.281zM18.187 17H5.438a2.438 2.438 0 0 1-.066-4.874h.716l.268-.58a2.443 2.443 0 0 1 2.207-1.421 2.41 2.41 0 0 1 .593.085l.986.248.232-.99a4.494 4.494 0 0 1 8.63-.425l.149.436.43.17A3.807 3.807 0 0 1 18.187 17zM3.525 10.094l-.118-.659a1.775 1.775 0 0 1-.033-.31A1.725 1.725 0 0 1 5.53 7.429l.656.156.39-.55a2.42 2.42 0 0 1 3.95-.03A5.478 5.478 0 0 0 9.4 9.24a3.369 3.369 0 0 0-3.952 1.886l-.011-.001a3.437 3.437 0 0 0-3.16 2.086 2.038 2.038 0 0 1 .684-2.757z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26.921 12.471a7.489 7.489 0 0 0-12.566-4.422A4.454 4.454 0 0 0 7.72 9.073 3.964 3.964 0 0 0 3 13a3.954 3.954 0 0 0 .053.526 3.966 3.966 0 0 0-.046 6.923 4.669 4.669 0 0 0 .057.824A4.614 4.614 0 0 0 7.672 25H24.5a6.498 6.498 0 0 0 2.421-12.529zM24.5 24H7.672a3.621 3.621 0 0 1-3.621-2.892 3.5 3.5 0 0 1 3.271-4.098l.67-.033.223-.633A3.498 3.498 0 0 1 11.5 14a1.803 1.803 0 0 1 .246.025l1.212.144.063-1.057a6.49 6.49 0 0 1 12.91-.505l.079.575.538.217A5.498 5.498 0 0 1 24.5 24zM4.133 14.066l-.103-.776A2.065 2.065 0 0 1 4 13a2.965 2.965 0 0 1 3.541-2.944l.658.12.362-.562a3.46 3.46 0 0 1 5.122-.828 7.47 7.47 0 0 0-1.66 4.267A4.431 4.431 0 0 0 11.5 13a4.487 4.487 0 0 0-4.228 3.012 4.5 4.5 0 0 0-4.12 3.333 2.965 2.965 0 0 1 .39-4.947z"
  }));
};

var _default = CloudyIcon;
exports["default"] = _default;