"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GroupIcon = function GroupIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.5 5h2a1.497 1.497 0 0 1 1.486 1.359 3.452 3.452 0 0 1 .969-.304 2.498 2.498 0 0 0-1.6-1.895 2.5 2.5 0 1 0-3.71 0 2.498 2.498 0 0 0-1.6 1.895 3.452 3.452 0 0 1 .97.304A1.497 1.497 0 0 1 7.5 5zm1-4A1.5 1.5 0 1 1 7 2.5 1.502 1.502 0 0 1 8.5 1zm5.855 10.16a2.5 2.5 0 1 0-3.71 0A2.5 2.5 0 0 0 9 13.5V16h7v-2.5a2.5 2.5 0 0 0-1.645-2.34zM12.5 8A1.5 1.5 0 1 1 11 9.5 1.502 1.502 0 0 1 12.5 8zm2.5 7h-5v-1.5a1.517 1.517 0 0 1 1.5-1.5h2a1.517 1.517 0 0 1 1.5 1.5zM1 13.5V16h7v-2.5a2.5 2.5 0 0 0-1.645-2.34 2.5 2.5 0 1 0-3.71 0A2.5 2.5 0 0 0 1 13.5zM7 15H2v-1.5A1.517 1.517 0 0 1 3.5 12h2A1.517 1.517 0 0 1 7 13.5zM4.5 8A1.5 1.5 0 1 1 3 9.5 1.502 1.502 0 0 1 4.5 8z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 13a3.954 3.954 0 0 0 .142 1H9.858A3.954 3.954 0 0 0 10 13zm-3.5-4h3a2.486 2.486 0 0 1 1.945.949 3.992 3.992 0 0 1 .839-.547A3.485 3.485 0 0 0 13.5 8h-3a3.485 3.485 0 0 0-2.784 1.402 3.992 3.992 0 0 1 .84.547A2.486 2.486 0 0 1 10.5 9zM9 4a3 3 0 1 1 3 3 3.003 3.003 0 0 1-3-3zm1 0a2 2 0 1 0 2-2 2.002 2.002 0 0 0-2 2zM4.5 17h3a3.504 3.504 0 0 1 3.5 3.5V23H1v-2.5A3.504 3.504 0 0 1 4.5 17zm0 1A2.503 2.503 0 0 0 2 20.5V22h8v-1.5A2.503 2.503 0 0 0 7.5 18zM6 16a3 3 0 1 1 3-3 3.003 3.003 0 0 1-3 3zm0-1a2 2 0 1 0-2-2 2.002 2.002 0 0 0 2 2zm17 5.5V23H13v-2.5a3.504 3.504 0 0 1 3.5-3.5h3a3.504 3.504 0 0 1 3.5 3.5zm-1 0a2.503 2.503 0 0 0-2.5-2.5h-3a2.503 2.503 0 0 0-2.5 2.5V22h8zM21 13a3 3 0 1 1-3-3 3.003 3.003 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2.002 2.002 0 0 0 2-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 9a4 4 0 1 0-4-4 4.005 4.005 0 0 0 4 4zm0-7a3 3 0 1 1-3 3 3.003 3.003 0 0 1 3-3zm3.101 16a4.944 4.944 0 0 0 .323 1h-6.848a4.944 4.944 0 0 0 .323-1zm-8.588-5.297a4.945 4.945 0 0 0-.908-.415A4.485 4.485 0 0 1 13.5 10h5a4.485 4.485 0 0 1 3.895 2.288 4.945 4.945 0 0 0-.908.415A3.49 3.49 0 0 0 18.5 11h-5a3.49 3.49 0 0 0-2.987 1.703zM12 17a4 4 0 1 0-4 4 4.005 4.005 0 0 0 4-4zm-4 3a3 3 0 1 1 3-3 3.003 3.003 0 0 1-3 3zm-7 6.5V31h14v-4.5a4.505 4.505 0 0 0-4.5-4.5h-5A4.505 4.505 0 0 0 1 26.5zm9.5-3.5a3.504 3.504 0 0 1 3.5 3.5V30H2v-3.5A3.504 3.504 0 0 1 5.5 23zM24 13a4 4 0 1 0 4 4 4.005 4.005 0 0 0-4-4zm0 7a3 3 0 1 1 3-3 3.003 3.003 0 0 1-3 3zm2.5 2h-5a4.505 4.505 0 0 0-4.5 4.5V31h14v-4.5a4.505 4.505 0 0 0-4.5-4.5zm3.5 8H18v-3.5a3.504 3.504 0 0 1 3.5-3.5h5a3.504 3.504 0 0 1 3.5 3.5z"
  }));
};

var _default = GroupIcon;
exports["default"] = _default;