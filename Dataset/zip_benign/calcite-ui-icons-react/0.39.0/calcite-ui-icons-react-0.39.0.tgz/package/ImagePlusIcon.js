"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImagePlusIcon = function ImagePlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 14v1H0V1h16v9h-1V2H1v8.2l1.4-1.4a.377.377 0 0 1 .533 0 .377.377 0 0 0 .534 0l2.69-2.69a.377.377 0 0 1 .508-.023L9.37 8.343a.377.377 0 0 0 .468.012L10 8.234v1.133a1.326 1.326 0 0 1-1.269-.256L6.461 7.22 4.173 9.509a1.37 1.37 0 0 1-.973.402 1.387 1.387 0 0 1-.429-.068L1 11.614V14zm4.5-9.5a1 1 0 1 0-1 1 1 1 0 0 0 1-1zM13 16v-3h3v-1h-3V9h-1v3H9v1h3v3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 3h22v13h-1.481L21 15.481v-1.414l1 1V4H2v11.067l2.533-2.533a.503.503 0 0 1 .704-.008.474.474 0 0 0 .678.049l3.627-3.628a.503.503 0 0 1 .677-.03l3.609 3.007a.503.503 0 0 0 .623.016l2.178-1.634a.503.503 0 0 1 .657.047L18.933 12h-1.414l-.635-.635-1.833 1.375a1.502 1.502 0 0 1-1.863-.049l-3.26-2.716-3.307 3.307a1.403 1.403 0 0 1-.997.415 1.506 1.506 0 0 1-.677-.163L2 16.48V20h10v1H1zm15 4.5A1.5 1.5 0 1 1 14.5 6 1.5 1.5 0 0 1 16 7.5zm-1 0a.5.5 0 1 0-.5.5.5.5 0 0 0 .5-.5zM19 18v-4h-1v4h-4v.999h4V23h1v-4.001h4V18z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 5v22h15v-1H3v-5.474l4.401-3.5 1.198.567L14 13.106l5 4.531 3.506-3.123L29 20.39V22h1V5zm21.003 8.578a.652.652 0 0 0-.926-.033L19 16.293l-4.554-4.131a.652.652 0 0 0-.857-.013L8.45 16.417l-.826-.391a.642.642 0 0 0-.72.117L3 19.248V6h26v13.082zM19 8a2 2 0 1 0 2 2 2.002 2.002 0 0 0-2-2zm0 3a1 1 0 1 1 1-1 1.001 1.001 0 0 1-1 1zm11 13v.999h-5V30h-1v-5.001h-5V24h5v-5h1v5z"
  }));
};

var _default = ImagePlusIcon;
exports["default"] = _default;