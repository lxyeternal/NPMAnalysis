"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MaximumGraphIcon = function MaximumGraphIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 7a.844.844 0 0 0 .832-.67A10.696 10.696 0 0 1 2.475 2H2V1h1v.494a2.396 2.396 0 0 1 1-.443V1h1v.049a2.375 2.375 0 0 1 1 .455V1h1v1h-.487C7.57 3.283 8.036 5.616 8.49 7.902 9.086 10.9 9.703 14 11.5 14c1.656 0 2.309-2.588 2.934-5.715A1.602 1.602 0 0 1 16 7v1a.6.6 0 0 0-.586.48C14.834 11.386 14.111 15 11.5 15c-2.618 0-3.316-3.509-3.99-6.902C6.914 5.1 6.297 2 4.5 2 3.002 2 2.321 4.183 1.81 6.542A1.838 1.838 0 0 1 0 8zm1-6H0v1h1zm8 0H8v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 11v1c-1.108 0-1.36 1.386-1.385 1.544-.381 2.54-1.62 8.456-4.865 8.456-3.508 0-4.39-5.04-5.243-9.914C10.727 7.619 9.918 3 7.25 3c-1.7 0-3.14 2.498-3.755 6.519A2.677 2.677 0 0 1 1 12v-1c1.195 0 1.479-1.473 1.507-1.64C2.967 6.352 3.85 4.175 5.03 3H5V2h1v.29A2.838 2.838 0 0 1 7.25 2a3.239 3.239 0 0 1 .75.094V2h1v.526c2.095 1.41 2.804 5.452 3.493 9.388.78 4.467 1.589 9.086 4.257 9.086 1.687 0 3.172-2.915 3.876-7.608A2.545 2.545 0 0 1 23 11zM2 2H1v1h1zm2 0H3v1h1zm7 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm2 0h-1v1h1zm1 0v1h1V2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 3h1v1h-1zm-1 0h-1v1h1zm-2 0h-1v1h1zm-2 0h-1v1h1zm-2 0h-1v1h1zm-2 0h-1v1h1zm-2 0h-1v1h1zm-2 0h-1v1h1zm-2 0h-1v1h1zM7 3H6v1h1zM5 3H4v1h1zM3 3H2v1h1zm23.822 16.49C26.23 24.42 24.202 28 22 28c-3.543 0-4.542-6.142-5.506-12.08C15.64 10.67 14.758 5.286 12 3.57V3h-1v.141A3.866 3.866 0 0 0 10 3a3.152 3.152 0 0 0-1 .166V3H8v.68c-1.87 1.326-3.31 4.5-3.815 8.709C4.085 13.174 3.672 15 2 15v1c2.015 0 2.962-1.8 3.178-3.488C5.77 7.58 7.798 4 10 4c3.543 0 4.542 6.142 5.506 12.08C16.54 22.432 17.606 29 22 29c2.804 0 5.14-3.773 5.815-9.388C27.892 19 28.278 17 30 17v-1c-2.018 0-2.964 1.802-3.178 3.49z"
  }));
};

var _default = MaximumGraphIcon;
exports["default"] = _default;