"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LabelIcon = function LabelIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.705 7.973l-.565-.567 3.182-3.183.567.566zm2.01 2.01l3.183-3.184-.566-.567-3.183 3.186zM3.38 14.226l.027-.197-1.256-1.257A.517.517 0 0 1 2 12.406V8.777a.517.517 0 0 1 .152-.367l7.26-7.258a.518.518 0 0 1 .732 0l5.704 5.703a.516.516 0 0 1 0 .733l-7.26 7.26a.517.517 0 0 1-.365.152h-3.63a.519.519 0 0 1-.367-.152l-.2-.2c-.1.614-.315 1.274-1.153 1.274h-.025a1.826 1.826 0 0 1-1.657-1.59l.696-.102c.062.268.294.98.972.99.323-.001.414-.177.522-.993zm.33-1.31c.014-.028.023-.059.039-.087a5.596 5.596 0 0 1 .548-.793 2.03 2.03 0 1 1 .47.527 4.821 4.821 0 0 0-.407.606 1.714 1.714 0 0 0-.103.295l.534.535h3.23L14.8 7.222 9.778 2.2 3 8.977v3.23zm2.031-1.382a7.858 7.858 0 0 0-.296.275A.973.973 0 0 0 6 12a1 1 0 1 0-1-1 .959.959 0 0 0 .045.222c.106-.1.198-.182.256-.232z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.635 2.217a.74.74 0 0 0-1.048 0l-10.37 10.37a.74.74 0 0 0-.217.524v5.185a.741.741 0 0 0 .217.524l2.286 2.286c-.247.6-.513.881-.722.881-.429 0-.846-.58-.982-.86l-.086-.18-1.037.493.085.18c.029.063.728 1.518 2.02 1.518a1.853 1.853 0 0 0 1.608-1.215.732.732 0 0 0 .315.077h5.185a.741.741 0 0 0 .524-.217l10.37-10.37a.74.74 0 0 0 0-1.048zM11.782 21H6.81l-.043-.043a10.076 10.076 0 0 0 .258-1.005 2.533 2.533 0 1 0-1.056-.488c-.022.079-.05.152-.066.235-.023.115-.048.216-.072.322L4 18.189v-4.97L14.11 3.106l7.783 7.782zM6 17.5A1.5 1.5 0 1 1 7.5 19c-.021 0-.04-.005-.062-.006a2.873 2.873 0 0 1 .61-.647l.16-.114-.649-.946-.165.115A4.018 4.018 0 0 0 6.39 18.5a1.489 1.489 0 0 1-.39-1zm2.542-5.792l5.922-5.922.707.707-5.922 5.923zm2.021 2.022l5.922-5.922.707.707-5.922 5.922zm2.021 2.021l5.923-5.922.707.707-5.922 5.922z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18.707 2.293a1 1 0 0 0-1.414 0l-14 14A1 1 0 0 0 3 17v7a1 1 0 0 0 .293.707l3.023 3.023c-.367.968-.812 1.52-1.275 1.52-.759 0-1.375-.938-1.549-1.299l-.903.43c.036.076.903 1.869 2.452 1.869.837 0 1.517-.596 2.041-1.754l.211.211A1 1 0 0 0 8 29h7a1 1 0 0 0 .707-.293l14-14a1 1 0 0 0 0-1.414zM15 28H8l-.54-.54c.117-.39.227-.807.321-1.278a3.275 3.275 0 0 1 .113-.398 3.049 3.049 0 1 0-.869-.542 4.348 4.348 0 0 0-.224.742c-.047.234-.098.455-.15.667L4 24v-7L18 3l11 11zm-6.323-4.912a5.01 5.01 0 0 0-1.168 1.232 2.048 2.048 0 1 1 .83.56 4.096 4.096 0 0 1 .904-.968zm1.212-6.824l8.474-8.476.85.849-8.476 8.474zm2.5 2.549l8.475-8.477.85.85-8.476 8.476zm2.5 2.548l8.475-8.474.848.85-8.474 8.473z"
  }));
};

var _default = LabelIcon;
exports["default"] = _default;