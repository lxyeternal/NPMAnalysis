"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MeasureAreaIcon = function MeasureAreaIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 6v6h2v1H1v3h3v-1h8v1h3v-3h-1v-1h2V6h-2V5h1V2h-3v1L4 1V0H1v3h1v3zm2 9v-1h1v1zm12 0h-1v-1h1zm-1-2h-1v1H4v-1H3v-1h10zm2-6v4h-1V8h-1v3h-1V9h-1v2h-1V8H9v3H8V9H7v2H6V8H5v3H4V9H3v2H1V7zm-2-4h1v1h-1zM2 1h1v1H2zm1 2h1v-.945l8 1.963V5h1v1H3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21 8h1V5h-3v1.006L5 2.461V1H2v3h1v6H1v8h2v2H2v3h3v-1h14v1h3v-3h-1v-2h2v-8h-2zm-1-2h1v1h-1zM3 2h1v1H3zm1 2h1v-.502l14 3.545V8h1v2H4zm0 18H3v-1h1zm17 0h-1v-1h1zm-1-2h-1v1H5v-1H4v-2h16zm2-9v6h-1v-3h-1v3h-1v-2h-1v2h-1v-5h-1v5h-1v-2h-1v2h-1v-3h-1v3h-1v-2h-1v2H9v-5H8v5H7v-2H6v2H5v-3H4v3H2v-6z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 23v-9h-3v-2h1V9h-3v.552L7 4.408V3H4v3h1v8H2v9h3v3H4v3h3v-1h18v1h3v-3h-1v-3zm-3-13v1h-1v-1zM5 4h1v1H5zm1 2h1v-.551l18 5.142V12h1v2H6zm-3 9h26v7h-1v-2h-1v2h-1v-6h-1v6h-1v-2h-1v2h-1v-4h-1v4h-1v-2h-1v2h-1v-6h-1v6h-1v-2h-1v2h-1v-4h-1v4h-1v-2h-1v2h-1v-6H9v6H8v-2H7v2H6v-4H5v4H3zm2 13v-1h1v1zm22 0h-1v-1h1zm-1-2h-1v1H7v-1H6v-3h20z"
  }));
};

var _default = MeasureAreaIcon;
exports["default"] = _default;