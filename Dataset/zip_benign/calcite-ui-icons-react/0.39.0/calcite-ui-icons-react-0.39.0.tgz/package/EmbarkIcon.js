"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EmbarkIcon = function EmbarkIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.771 14.28l-.545.838a2.712 2.712 0 0 0-2.855.321l-.872.553-.872-.553a2.708 2.708 0 0 0-2.855-.32l-.544-.839a3.71 3.71 0 0 1 3.935.314l.336.214.336-.214a3.715 3.715 0 0 1 3.936-.314zm-9.7-5.002l1.678-.718L8.003 5H9V3h1V2h1v1h.999v2h.997l1.254 3.56 1.678.718-2.139 3.725h-.29a4.028 4.028 0 0 0-2.66.928l-.339.315-.34-.315a4.033 4.033 0 0 0-2.661-.928h-.29zm9.43.477L10.5 8.044l-4.002 1.71 1.295 2.257a5.103 5.103 0 0 1 2.707.905 5.096 5.096 0 0 1 2.705-.905zM10 5h.999V4H10zM7.997 8.026l2.503-1.07 2.502 1.07L12.288 6H8.71zM4.354.691l-.707.707L5.249 3H0v1h5.249L3.646 5.602l.707.707L7.163 3.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 20c3.196-3.478 5.05-1.3 5.05-1.3a9.635 9.635 0 0 1 2.6-5.25l-2.334-1.027L18.853 8H17.81l-1-3H16V3h-3v2h-.81l-1 3h-1.043l-.963 4.423-2.335 1.027a9.635 9.635 0 0 1 2.6 5.25s1.855-2.178 5.05 1.3zM14 4h1v1h-1zm-1.09 2h3.18l.667 2h-4.514zm-1.957 3h7.094l.637 2.926-4.185-1.84-4.183 1.84zm3.546 2.178l6.046 2.658a11.273 11.273 0 0 0-1.68 3.324 3.37 3.37 0 0 0-.947-.134 5.198 5.198 0 0 0-3.42 1.565 5.193 5.193 0 0 0-3.416-1.565 3.37 3.37 0 0 0-.947.134 11.273 11.273 0 0 0-1.68-3.324zM9.201 5.494L6.354 8.34l-.707-.707L7.28 6H1V5h6.293L5.646 3.354l.707-.707zM21.564 21.15l-.687.726c-2.088-1.972-4.28-.453-5.957 1.093l-.421.387-.418-.385c-1.674-1.546-3.865-3.07-5.958-1.095l-.687-.726c2.822-2.665 5.802-.288 7.063.849 1.26-1.136 4.246-3.514 7.065-.85z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M25.388 14.603L23.883 9h-1.174l-.8-4H20V3h-3v2h-1.91l-.8 4h-1.173l-1.505 5.603-3.556 1.388.422.531a16.095 16.095 0 0 1 2.96 7.78l.071.623.592-.208a4.178 4.178 0 0 1 1.397-.233 6.934 6.934 0 0 1 4.662 2.19l.34.314.34-.315a6.934 6.934 0 0 1 4.661-2.19 4.178 4.178 0 0 1 1.397.234l.592.208.072-.622a16.107 16.107 0 0 1 2.96-7.781l.423-.53zM18 4h1v1h-1zm-2.09 2h5.18l.6 3h-6.38zm-2.026 4h9.232l1.115 4.151-5.731-2.237-5.731 2.237zm10.762 13.606a5.31 5.31 0 0 0-1.145-.122 7.67 7.67 0 0 0-5.001 2.152 7.67 7.67 0 0 0-5.002-2.152 5.31 5.31 0 0 0-1.144.122 17.246 17.246 0 0 0-2.69-7.169l8.836-3.45 8.836 3.45a17.257 17.257 0 0 0-2.69 7.17zm2.517 3.959l-.41.912c-1.822-.82-4.673-1.172-7.915 1.81l-.345.317-.396-.316c-3.241-2.982-6.093-2.631-7.915-1.811l-.41-.912c2.026-.914 5.15-1.337 8.651 1.675l.004-.004.047.036c3.517-3.047 6.655-2.623 8.69-1.707zM11.128 6.5l-3.854 3.854-.707-.707L9.214 7H2V6h7.214L6.567 3.354l.707-.707z"
  }));
};

var _default = EmbarkIcon;
exports["default"] = _default;