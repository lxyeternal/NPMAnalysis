"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FourteenXIcon = function FourteenXIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 16H9v-2H4.793L10 8.793V13h1v1h-1zm-2.793-3H9v-1.793zM2 .911l-1.966.823.386.923.58-.243V8h1zm5.709 1.504L6.799 2 1.055 14.585l.91.415zM14.721 6l-1.219 1.639L12.282 6h-1.277l1.858 2.498L11.002 11h1.278l1.222-1.643L14.724 11H16l-1.86-2.502L16 6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 23h-1v-2H8.046L14 12.1V20h2v1h-2zm-4.046-3H13v-4.4zM4 2.207L1.011 3.634l.43.903L3 3.793V12h1zm8 1.215l-.916-.4-8.077 18.57.916.4zM22.689 9L20.5 11.696 18.311 9h-1.306l2.842 3.5-2.842 3.5h1.306l2.189-2.696L22.689 16h1.306l-2.842-3.5L23.995 9z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 26h2v-1h-2v-9L9 26h6v3h1zm-1-6.945V25h-4.026zm-1-13.64L13.09 5 2.616 28.585l.909.415zM5 4L.981 5.608l.371.929L4 5.477V16h1zm25.97 9l-3.782 4.475L31 21.985V22h-1.334l-3.15-3.729L23.363 22h-1.346l3.824-4.525L22.06 13h1.346l3.108 3.678L29.623 13z"
  }));
};

var _default = FourteenXIcon;
exports["default"] = _default;