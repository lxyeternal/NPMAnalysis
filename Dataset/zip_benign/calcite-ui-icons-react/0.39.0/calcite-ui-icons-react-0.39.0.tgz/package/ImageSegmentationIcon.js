"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImageSegmentationIcon = function ImageSegmentationIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 8h1v1H1zm0 3h1v-1H1zm15-3h-1v1h1zm0 2h-1v1h1zm-1 3h1v-1h-1zM1 13h1v-1H1zm0 3l3-7h9l3 7zm3.225-5h2.823L10 12h3.198l-.857-2H4.659zm-.419 1l-1.29 3h11.967l-.857-2H10l-3-1zM16 7H1l3-7h9zM9 2.665L10 3h3.198l-.857-2H9zm-1 .674L7 3H3.806l-1.29 3H8zM8 1H4.66l-.435 1h2.823L8 2.33zm1 5h5.483l-.857-2H10l-1-.33z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 20h1v1h-1zm0-1h1v-1h-1zm0-2h1v-1h-1zm0-2h1v-1h-1zm0-2h1v-1h-1zm1-3h-1v1h1zM2 21h1v-1H2zm0-2h1v-1H2zm0-2h1v-1H2zm0-2h1v-1H2zm0-2h1v-1H2zm1-3H2v1h1zm15 5h1v-1h-1zm0-2h1v-1h-1zm1-3h-1v1h1zM6 15h1v-1H6zm0-2h1v-1H6zm1-3H6v1h1zm11.75 6l4.5 8H2l4.5-8zM7.085 17l-.562 1h4.075l4.187 2h5.068l-1.688-3zm14.455 6l-1.125-2h-5.857l-4.187-2H6v-.071L3.71 23zM18.75 1l4.5 8H2l4.5-8zM13 2v2.148L14.785 5h5.068l-1.688-3zM7.085 2l-.563 1h4.075L12 3.67V2zM12 8V4.778L10.37 4H6v-.071L3.71 8zm9.54 0l-1.125-2h-5.857L13 5.256V8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9 21L3 31h27l-6-10zm.566 1h13.868l2.4 4h-7.716l-4-2H8.366zm-4.8 8l3-5h6.116l4 2h8.552l1.8 3zM4 16H3v-1h1zm0 2H3v-1h1zm0 2H3v-1h1zm0 1.999H3V21h1zM4 28H3v-1h1zm5-9h1v1H9zm20 8h1v1h-1zm-6-8h1v1h-1zM4 26H3v-1h1zm0-2H3v-1h1zm0-10H3v-1h1zm6 2H9v-1h1zm14 0h-1v-1h1zm-14 2H9v-1h1zm0-4H9v-1h1zm19 1h1v1h-1zm0 2h1v1h-1zm0 2h1v1h-1zm0 2h1v.999h-1zm0 4h1v1h-1zm0-2h1v1h-1zm0-10h1v1h-1zm-5 5h-1v-1h1zm0-4h-1v-1h1zm0-12H9L3 12h27zm4.234 9H17V7.56l.882.44h8.552zm-2.4-4h-7.716L17 6.44V3h6.434zM9.566 3H16v2.94L14.118 5H8.366zm-1.8 3h6.116L16 7.06V11H4.766z"
  }));
};

var _default = ImageSegmentationIcon;
exports["default"] = _default;