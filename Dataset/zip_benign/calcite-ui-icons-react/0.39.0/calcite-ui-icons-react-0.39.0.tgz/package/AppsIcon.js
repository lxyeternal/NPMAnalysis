"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AppsIcon = function AppsIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 1H2a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1zm0 5H2V2h4zm4 1h4a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1zm4-1h-4V2h4zm-4 9h4a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1zm4-1h-4v-4h4zM6 9H2a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1zm0 5H2v-4h4z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.5 2h-6A1.502 1.502 0 0 0 2 3.5v6A1.502 1.502 0 0 0 3.5 11h6A1.502 1.502 0 0 0 11 9.5v-6A1.502 1.502 0 0 0 9.5 2zm.5 7.5a.501.501 0 0 1-.5.5h-6a.501.501 0 0 1-.5-.5v-6a.501.501 0 0 1 .5-.5h6a.501.501 0 0 1 .5.5zM20.5 2h-6A1.502 1.502 0 0 0 13 3.5v6a1.502 1.502 0 0 0 1.5 1.5h6A1.502 1.502 0 0 0 22 9.5v-6A1.502 1.502 0 0 0 20.5 2zm.5 7.5a.501.501 0 0 1-.5.5h-6a.501.501 0 0 1-.5-.5v-6a.501.501 0 0 1 .5-.5h6a.501.501 0 0 1 .5.5zM9.5 13h-6A1.502 1.502 0 0 0 2 14.5v6A1.502 1.502 0 0 0 3.5 22h6a1.502 1.502 0 0 0 1.5-1.5v-6A1.502 1.502 0 0 0 9.5 13zm.5 7.5a.501.501 0 0 1-.5.5h-6a.501.501 0 0 1-.5-.5v-6a.501.501 0 0 1 .5-.5h6a.501.501 0 0 1 .5.5zM20.5 13h-6a1.502 1.502 0 0 0-1.5 1.5v6a1.502 1.502 0 0 0 1.5 1.5h6a1.502 1.502 0 0 0 1.5-1.5v-6a1.502 1.502 0 0 0-1.5-1.5zm.5 7.5a.501.501 0 0 1-.5.5h-6a.501.501 0 0 1-.5-.5v-6a.501.501 0 0 1 .5-.5h6a.501.501 0 0 1 .5.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13.25 3h-8.5A1.752 1.752 0 0 0 3 4.75v8.5A1.752 1.752 0 0 0 4.75 15h8.5A1.752 1.752 0 0 0 15 13.25v-8.5A1.752 1.752 0 0 0 13.25 3zM14 13.25a.751.751 0 0 1-.75.75h-8.5a.751.751 0 0 1-.75-.75v-8.5A.751.751 0 0 1 4.75 4h8.5a.751.751 0 0 1 .75.75zM27.25 3h-8.5A1.752 1.752 0 0 0 17 4.75v8.5A1.752 1.752 0 0 0 18.75 15h8.5A1.752 1.752 0 0 0 29 13.25v-8.5A1.752 1.752 0 0 0 27.25 3zM28 13.25a.751.751 0 0 1-.75.75h-8.5a.751.751 0 0 1-.75-.75v-8.5a.751.751 0 0 1 .75-.75h8.5a.751.751 0 0 1 .75.75zM27.25 17h-8.5A1.752 1.752 0 0 0 17 18.75v8.5A1.752 1.752 0 0 0 18.75 29h8.5A1.752 1.752 0 0 0 29 27.25v-8.5A1.752 1.752 0 0 0 27.25 17zM28 27.25a.751.751 0 0 1-.75.75h-8.5a.751.751 0 0 1-.75-.75v-8.5a.751.751 0 0 1 .75-.75h8.5a.751.751 0 0 1 .75.75zM13.25 17h-8.5A1.752 1.752 0 0 0 3 18.75v8.5A1.752 1.752 0 0 0 4.75 29h8.5A1.752 1.752 0 0 0 15 27.25v-8.5A1.752 1.752 0 0 0 13.25 17zM14 27.25a.751.751 0 0 1-.75.75h-8.5a.751.751 0 0 1-.75-.75v-8.5a.751.751 0 0 1 .75-.75h8.5a.751.751 0 0 1 .75.75z"
  }));
};

var _default = AppsIcon;
exports["default"] = _default;