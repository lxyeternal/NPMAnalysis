"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HourglassActiveIcon = function HourglassActiveIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.996 14H6.004A1.439 1.439 0 0 1 6 13.888c0-.594 1.228-1.997 2-2.578V5.43a15.285 15.285 0 0 1-1.052-.971l3.778-.725A10.542 10.542 0 0 1 9 5.434v5.858c.77.548 2 1.893 2 2.596 0 .037-.001.075-.004.112zM3 15h1.396A2.272 2.272 0 0 1 4 13.716V13c-.05-1.586 1.446-3.055 2.594-4.094.128-.115.298-.239.298-.406s-.17-.29-.298-.406C5.446 7.055 3.951 5.586 4 4v-.716A2.272 2.272 0 0 1 4.396 2H3V1h11v1h-1.396A2.272 2.272 0 0 1 13 3.284V4c.05 1.586-1.446 3.055-2.594 4.094-.128.115-.298.239-.298.406s.17.29.298.406C11.554 9.945 13.049 11.414 13 13v.716A2.272 2.272 0 0 1 12.604 15H14v1H3zm3.284 0h4.432A1.284 1.284 0 0 0 12 13.717v-.748c.04-1.236-1.518-2.645-2.302-3.354a1.477 1.477 0 0 1-.59-1.115 1.52 1.52 0 0 1 .627-1.147C10.482 6.676 12.039 5.267 12 4v-.717A1.284 1.284 0 0 0 10.716 2H6.284A1.284 1.284 0 0 0 5 3.283v.748c-.04 1.236 1.518 2.645 2.302 3.354a1.477 1.477 0 0 1 .59 1.115 1.52 1.52 0 0 1-.627 1.147C6.518 10.324 4.961 11.733 5 13v.717A1.284 1.284 0 0 0 6.284 15z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.827 6.956c2.265.662 5.109-.295 8.172-1.867l.001.079c0 1.3-1.642 2.897-3.248 4.288a3.818 3.818 0 0 0-.752.898v6.726c1.321.372 2.815 2.089 3.827 3.655-.027.088-.043.179-.077.265h-8.5c-.034-.087-.057-.17-.082-.254 1.01-1.57 2.509-3.293 3.833-3.666v-6.729a3.819 3.819 0 0 0-.73-.88 17.898 17.898 0 0 1-2.443-2.515zM17.922 2H20v1h-1.516A5.594 5.594 0 0 1 19 5.319c0 2.15-1.479 4.294-3.545 6.092a1.544 1.544 0 0 0-.62 1.089 1.544 1.544 0 0 0 .62 1.089C17.521 15.387 19 17.53 19 19.68a5.595 5.595 0 0 1-.516 2.32H20v1H5v-1h1.5a5.666 5.666 0 0 1-.5-2.319c0-2.15 1.479-4.294 3.545-6.092a1.544 1.544 0 0 0 .62-1.089 1.544 1.544 0 0 0-.62-1.089C7.479 9.613 6 7.47 6 5.32A5.666 5.666 0 0 1 6.5 3H5V2zm-.545 1H7.624A4.68 4.68 0 0 0 7 5.32c0 1.645 1.137 3.54 3.2 5.336a2.435 2.435 0 0 1 .966 1.844 2.432 2.432 0 0 1-.965 1.843c-2.064 1.797-3.2 3.692-3.2 5.338A4.68 4.68 0 0 0 7.623 22h9.753A4.646 4.646 0 0 0 18 19.68c0-1.645-1.137-3.54-3.2-5.336a2.435 2.435 0 0 1-.966-1.844 2.432 2.432 0 0 1 .965-1.843c2.064-1.797 3.2-3.692 3.2-5.338A4.646 4.646 0 0 0 17.378 3z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9.898 3H7v1h2.44A6.773 6.773 0 0 0 9 6.375c0 2.493 1.765 5.35 3.845 7.283A3.22 3.22 0 0 1 13.952 16a3.22 3.22 0 0 1-1.107 2.342C10.765 20.274 9 23.132 9 25.625A6.773 6.773 0 0 0 9.44 28H7v1h19v-1h-2.44a6.773 6.773 0 0 0 .44-2.375c0-2.493-1.765-5.35-3.845-7.283A3.22 3.22 0 0 1 19.048 16a3.221 3.221 0 0 1 1.107-2.342C22.235 11.726 24 8.868 24 6.375A6.773 6.773 0 0 0 23.56 4H26V3zM23 6.375c0 1.959-1.417 4.59-3.526 6.55A4.206 4.206 0 0 0 18.048 16a4.206 4.206 0 0 0 1.426 3.074C21.583 21.034 23 23.666 23 25.625A5.798 5.798 0 0 1 22.491 28H10.51a5.798 5.798 0 0 1-.51-2.375c0-1.959 1.417-4.59 3.526-6.55A4.206 4.206 0 0 0 14.952 16a4.206 4.206 0 0 0-1.426-3.074C11.417 10.966 10 8.334 10 6.375A5.798 5.798 0 0 1 10.509 4H22.49A5.798 5.798 0 0 1 23 6.375zm-11.115 2.88a20.42 20.42 0 0 0 10.052-2.19l-.005.026c-.385 2.13-2.37 4.878-4.932 6.452v7.596c1.84.333 3.587 2.4 4.991 4.384 0 .033.009.07.009.102A4.8 4.8 0 0 1 21.799 27H11.2a4.8 4.8 0 0 1-.2-1.375c0-.031.008-.066.009-.098l.122-.176c1.382-1.932 3.081-3.89 4.869-4.213v-7.585a12.068 12.068 0 0 1-4.115-4.298z"
  }));
};

var _default = HourglassActiveIcon;
exports["default"] = _default;