"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DroneQuadcopterIcon = function DroneQuadcopterIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1.5 5a1.5 1.5 0 0 0 0 3H2v.707L3.793 10.5 3 11.293V13H2v1h3v-1H4v-1.293L4.707 11h6.586l.707.707V13h-1v1h3v-1h-1v-1.707l-.793-.793L14 8.707V8h.5a1.5 1.5 0 0 0 0-3H14V4h2V3h-5v1h2v1h-.707l-1.664 1.664L9.602 5H6.398L5.375 6.668 3.707 5H3V4h2V3H0v1h2v1zm3.455 2.662a.665.665 0 0 0 .62.183.628.628 0 0 0 .45-.335L6.956 6h2.088l.893 1.435a.68.68 0 0 0 .487.41.663.663 0 0 0 .62-.183L12.707 6H14.5a.5.5 0 0 1 0 1H13v1.293L11.293 10H4.707L3 8.293V7H1.5a.5.5 0 0 1 0-1h1.793z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17 5h3v2h-.41l-2.527 1.784a1.14 1.14 0 0 1-1.748-.6L14.953 7H9.047l-.362 1.185a1.141 1.141 0 0 1-1.75.6L4.41 7H4V5h3V4H0v1h3v2H2a2 2 0 0 0 0 4h1.293l3.5 3.5L5 16.293V19H4v1h3v-1H6v-2.293L7.707 15h8.586L18 16.707V19h-1v1h3v-1h-1v-2.707L17.207 14.5l3.5-3.5H22a2 2 0 0 0 0-4h-1V5h3V4h-7zm6 4a1 1 0 0 1-1 1h-1.707l-4 4H7.707l-4-4H2a1 1 0 0 1 0-2h2.09l2.268 1.6a2.142 2.142 0 0 0 3.284-1.122L9.787 8h4.426l.145.478A2.14 2.14 0 0 0 17.641 9.6L19.909 8H22a1 1 0 0 1 1 1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M23 7h4v3h-.826l-3.904 2.757a1.175 1.175 0 0 1-1.801-.617L19.814 10h-7.628l-.655 2.14a1.174 1.174 0 0 1-1.8.617L5.825 10H5V7h4V6H0v1h4v3H2.5a2.5 2.5 0 0 0 0 5h2.672l4.617 4.504L7 22.293V26H5v1h5v-1H8v-3.293L10.707 20h10.586L24 22.707V26h-2v1h5v-1h-2v-3.707l-2.789-2.789L26.828 15H29.5a2.5 2.5 0 0 0 0-5H28V7h4V6h-9zm8 5.5a1.502 1.502 0 0 1-1.5 1.5h-3.078l-5.125 5H10.703l-5.125-5H2.5a1.5 1.5 0 0 1 0-3h3.008l3.646 2.573a2.175 2.175 0 0 0 3.334-1.14L12.926 11h6.148l.438 1.433a2.175 2.175 0 0 0 3.334 1.14L26.492 11H29.5a1.502 1.502 0 0 1 1.5 1.5z"
  }));
};

var _default = DroneQuadcopterIcon;
exports["default"] = _default;