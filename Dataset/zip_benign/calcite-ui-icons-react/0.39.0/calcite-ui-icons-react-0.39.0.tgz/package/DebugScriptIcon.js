"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DebugScriptIcon = function DebugScriptIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.944 7.294c0-.168.02-.323.03-.484l.197-.109a6.096 6.096 0 0 1 4.657-.412 4.953 4.953 0 0 1 2.197-.741Q9.948 5.267 9.85 5h.906l1.232-2.117-.864-.503L10.181 4h-.824a4.398 4.398 0 0 0-1.323-1.37l1.158-1.165-.71-.705-1.406 1.416A3.685 3.685 0 0 0 6 2a3.597 3.597 0 0 0-1.06.174L3.515.758l-.705.709 1.178 1.17A4.112 4.112 0 0 0 2.752 4H1.82L.876 2.38l-.864.503L1.244 5h1.058a7.171 7.171 0 0 0-.338 2H0v1h1.975a7.607 7.607 0 0 0 .424 2h-.973L.161 12.459l.89.457L2.037 11h.832A3.676 3.676 0 0 0 6 13c.064 0 .126-.01.189-.013a4.944 4.944 0 0 1-.446-1.026c-1.587-.198-2.8-2.164-2.8-4.667zM6 3a3.276 3.276 0 0 1 3.04 2.7 7.115 7.115 0 0 0-5.882-.093A3.075 3.075 0 0 1 6 3zm9.749 12.054L13.29 12.59A3.467 3.467 0 0 0 14 10.5a3.5 3.5 0 1 0-3.5 3.5 3.467 3.467 0 0 0 2.083-.704l2.458 2.464a.5.5 0 0 0 .708-.706zM10.5 13a2.5 2.5 0 1 1 2.5-2.5 2.503 2.503 0 0 1-2.5 2.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.6 15c-.9-2.6-.6-4.6-.5-5.4 2.4-1.5 5.3-2 8-1.3.7-.3 1.5-.5 2.3-.6-.1-.3-.2-.5-.3-.8h2l1.2-3.2-.9-.4-1 2.6h-1.8C13 4.8 12.1 4 11.1 3.4l2.1-2.1-.7-.7L10.1 3c-.7 0-1.5 0-2.3.1L5.4.7l-.7.7 2.1 2.1C5.7 4.1 4.9 4.9 4.3 6H2.5l-1-2.6-.9.4L1.8 7h2C3.3 8.3 3 9.6 3 11H1v1h2c0 1 .2 2 .5 3H1.8L.6 18.3l.9.3 1-2.7h1.4c.4.8 2.1 4.5 5.8 3.9-.3-.2-.5-.5-.7-.8-2.9 0-4.4-3.5-4.4-4zM9 3.9c2 0 3.7 1.6 4.4 3.8-2.9-1-6.2-.8-9 .6.7-2.6 2.5-4.4 4.6-4.4zm14.8 19.2l-4.3-4.3c2.1-2.5 1.8-6.3-.7-8.4s-6.3-1.8-8.4.7-1.8 6.3.7 8.4c2.2 1.9 5.4 1.9 7.7 0l4.3 4.3c.2.2.5.2.7 0 .2-.2.2-.5 0-.7zm-8.8-3c-2.8 0-5.1-2.3-5.1-5.1s2.3-5.1 5.1-5.1 5.1 2.3 5.1 5.1-2.3 5.1-5.1 5.1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11.5 23.8c.3.4.7.8 1.1 1.2-2.7-.2-5.1-2.1-6.4-5h-2l-1.8 3.5-.8-.5 2.1-4h2.2c-.5-1.3-.7-2.6-.8-4H2v-1h3c0-1.4.3-2.7.8-4l-2.2-.1-2-3.9.9-.5L4.2 9h2c.9-2 2.5-3.7 4.5-4.6L7.6 1.3l.7-.7 3.5 3.5c.8-.2 1.6-.2 2.4 0L17.7.6l.7.7-3.1 3.1c2 .9 3.6 2.5 4.5 4.6h1.9l1.8-3.5.9.5-2 4h-1.8c-.5-.1-1-.2-1.5-.2-1.2-2.9-3.5-4.9-6-4.9-2.8 0-5.2 2.3-6.3 5.5 3.5-1.6 7.4-1.8 11-.6-.7.1-1.4.2-2.1.4-3.1-.6-6.4-.1-9.2 1.4l-.1.1c-.2.9-.4 1.9-.4 2.8-.1 4.6 2.4 8.4 5.5 9.3zm18.8 5.8l-6.2-6.3c2.7-3.1 2.3-7.8-.8-10.5s-7.8-2.3-10.5.8c-2.6 3-2.3 7.8.8 10.5 2.8 2.4 7 2.4 9.8-.1l6.2 6.3c.2.2.5.2.7 0 .2-.2.2-.5 0-.7zm-11.8-4.5c-3.6 0-6.6-2.9-6.6-6.6s2.9-6.6 6.6-6.6 6.6 2.9 6.6 6.6c0 3.6-3 6.6-6.6 6.6z"
  }));
};

var _default = DebugScriptIcon;
exports["default"] = _default;