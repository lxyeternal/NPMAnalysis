"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileEcdIcon = function FileEcdIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.4 0H2v7h1V1h7v4h4v10H3v-1H2v2h13V3.6zM14 4h-3V1h.31L14 3.69zm-3 2v2H9.396A1.397 1.397 0 0 0 8 9.396v2.209A1.397 1.397 0 0 0 9.396 13H12V6zm-1.604 6A.396.396 0 0 1 9 11.604V9.395A.396.396 0 0 1 9.396 9H11v3zM4.032 8h2.9v1H5v3h1.932v1h-2.9zM0 13h3v-1H1v-1h2V8H0zm1-4h1v1H1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.29 1H3v11h1V2h10v6h6v14H4v-3H3v4h18V6.709zM20 7h-5V2h.2L20 6.8zm-2 11v-7h-1v2.295A2.018 2.018 0 0 0 15.959 13h-.918A2.044 2.044 0 0 0 13 15.041v.918A2.044 2.044 0 0 0 15.041 18h.918A2.018 2.018 0 0 0 17 17.705V18zm-2.041-1h-.918A1.042 1.042 0 0 1 14 15.959v-.918A1.042 1.042 0 0 1 15.041 14h.918A1.042 1.042 0 0 1 17 15.041v.918A1.042 1.042 0 0 1 15.959 17zM7 18v-1H4.041a1.042 1.042 0 0 1-1.04-1H7v-1a1.996 1.996 0 0 0-1.992-2H4.04A2.044 2.044 0 0 0 2 15.041v.918A2.044 2.044 0 0 0 4.041 18zm-2.959-4h.967a1 1 0 0 1 1 1H3a1.042 1.042 0 0 1 1.04-1zM9 15.041v.918A1.041 1.041 0 0 0 10.041 17H12v1h-1.959A2.041 2.041 0 0 1 8 15.959v-.918A2.041 2.041 0 0 1 10.041 13H12v1h-1.959A1.041 1.041 0 0 0 9 15.041z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.3 2H5v15h1V3h12v8h8v18H6v-4H5v5h22V9.699zm-.3 8V3l7 7zm4 14v-9h-1v3.78a3 3 0 1 0 0 4.44V24zm-3-1a2 2 0 1 1 2-2 2.003 2.003 0 0 1-2 2zM8.879 24v-1H7a1.983 1.983 0 0 1-1.445-.618 2.06 2.06 0 0 1-.301-.404h3.745a.99.99 0 0 0 1-.965 2.656 2.656 0 0 0-1.95-2.885 3.357 3.357 0 0 0-2.838.522 2.859 2.859 0 0 0-1.207 2.212A3 3 0 0 0 7 24zm-3.877-3.093a1.885 1.885 0 0 1 .8-1.45 2.356 2.356 0 0 1 1.987-.364 1.706 1.706 0 0 1 1.21 1.885H5l.002-.07zm7.612-1.37a2.102 2.102 0 0 0 0 2.97 2.081 2.081 0 0 0 2.951 0l.707.707a3.086 3.086 0 0 1-2.19.906 3.05 3.05 0 0 1-2.175-.906 3.094 3.094 0 1 1 4.365-4.385l-.707.707a2.081 2.081 0 0 0-2.951 0z"
  }));
};

var _default = FileEcdIcon;
exports["default"] = _default;