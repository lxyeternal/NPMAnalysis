"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LegendRightIcon = function LegendRightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 9h-3v3h3zm-1 2h-1v-1h1zm-.5-3A1.5 1.5 0 1 0 12 6.5 1.502 1.502 0 0 0 13.5 8zm0-2a.5.5 0 1 1-.5.5.5.5 0 0 1 .5-.5zM15 1h-3v3h3zm-1 2h-1V2h1zM7 14h3v1H7zm8.128 2H11.87l1.619-3zM1 2h9v1H1zm2 4h7v1H3zm2 4h5v1H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 9a2 2 0 1 0-2 2 2 2 0 0 0 2-2zm-1 0a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm-1 10.209L18.937 23h4.126zM20.62 22l.38-.699.38.699zM19 5h4V1h-4zm1-3h2v2h-2zm3 11h-4v4h4zm-1 3h-2v-2h2zm-6 6h-4v-1h4zm0-6H9v-1h7zm0-13v1H3V3zm0 7H6V9h10z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M26.501 10a2.5 2.5 0 1 0 2.5 2.5 2.5 2.5 0 0 0-2.5-2.5zm0 4a1.5 1.5 0 1 1 1.5-1.5 1.5 1.5 0 0 1-1.5 1.5zm-2.453 15h4.888l-2.398-4.864zm1.636-1l.837-1.637L27.33 28zM29 3h-5v5h5zm-1 4h-3V4h3zm-4 15h5v-5h-5zm1-4h3v3h-3zm-4 2H11v-1h10zm0 7h-6v-1h6zm0-21H3V5h18zm0 7H7v-1h14z"
  }));
};

var _default = LegendRightIcon;
exports["default"] = _default;