"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AZUpIcon = function AZUpIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.65 6.322L13 4.672V14h-1V4.729l-1.593 1.593-.707-.707 2.828-2.829 2.829 2.829zM4.5 0h-1L0 7h1l1-2h4l1 2h1zm-2 4l1.496-2.992L5.5 4zm4.3 6V9H1v1h4.5l-4.389 5v1H7v-1H2.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.646 8.354L19 5.707V20h-1V5.707l-2.646 2.647-.707-.707L18.5 3.793l3.854 3.854zM4 14h6.707L4 21.707V23h8v-1H5.293L12 14.293V13H4zM8.5 1l4.05 9h-.99l-1.38-3H5.82l-1.38 3h-.99L7.5 1zm1.222 5L8 2.25 6.278 6z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9.189 10h5.622l1.677 4h1.084L15.5 9.057V9h-.024l-2.934-7h-1.084L8.524 9H8.5v.057L6.428 14h1.084zM12 3.293L14.392 9H9.608zM7 18h10v.707L8.707 29H17v1H7v-.707L15.293 19H7zm21.643-8.643L26 6.714V27h-1V6.714l-2.643 2.643-.707-.707L25.5 4.8l3.85 3.85z"
  }));
};

var _default = AZUpIcon;
exports["default"] = _default;