"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImageDisplayOrderIcon = function ImageDisplayOrderIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 3v7h-3V9h2V7h-2V6h2V4h-2v1h-1V4H9v1H8V4H6v1H5V3zm-6-1L8.5 0 7 2zM7 14l1.5 2 1.5-2zm5-8v7H1V6zM5 7v2h3V7zM2 9h2V7H2zm2 3v-2H2v2zm4 0v-2H5v2zm3-2H9v2h2zm0-3H9v2h2z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 9h-2V7h2zm-4 1H9v2h2zM8 7H5v2h3z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 9H2V7h2zm4 1H5v2h3zm4-6H9v1h3z",
      opacity: ".25"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 4h-5l2.5-2.574zm-3.5 19.574L14 21H9zM1 10h16v9H1zm11 4h4v-3h-4zm0 4h4v-3h-4zm-5-4h4v-3H7zm0 4h4v-3H7zm-5-4h4v-3H2zm0 4h4v-3H2zM7 6v3h1V7h4v2h1V7h4v2h1V7h4v3h-4v1h4v3h-4v1h5V6z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17 9h-4V7h4zM6 11H2v3h4zm5 4H7v3h4z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 14h-4v-3h4zm-11-3H7v3h4zm5 4h-4v3h4z",
      opacity: ".5"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 8v11h-5v-1h4v-4h-4v-1h4V9h-4v4h-1V9h-4v4h-1V9h-4v4h-1V9h-4v4H9V8zM19 6l-2.5-2.574L14 6zm-5 21l2.5 2.574L19 27zm10-13v11H3V14zm-10 1v4h4v-4zm-5 0v4h4v-4zm-5 4h4v-4H4zm4 5v-4H4v4zm5 0v-4H9v4zm5 0v-4h-4v4zm5-4h-4v4h4zm0-5h-4v4h4z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19 13h-4V9h4zm10 1h-4v4h4zm-6 1h-4v4h4zm-10 5H9v4h4zm-5-5H4v4h4z",
    opacity: ".25"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 13h-4V9h4zm-11 7h-4v4h4zm-5-5H9v4h4z",
    opacity: ".5"
  }));
};

var _default = ImageDisplayOrderIcon;
exports["default"] = _default;