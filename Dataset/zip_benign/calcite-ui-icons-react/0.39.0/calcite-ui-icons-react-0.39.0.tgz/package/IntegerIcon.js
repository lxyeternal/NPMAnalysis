"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var IntegerIcon = function IntegerIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 7v5H9V7H7v5H6V7a1.001 1.001 0 0 1 1-1h2a1.001 1.001 0 0 1 1 1zm-9 4v1h4v-1H4V6H1v1h2v4zm2-6h1V3H3zm9 6a1.001 1.001 0 0 0 1 1h2v-1h-2V7h2V6h-2V3h-1v3h-1v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 17h2v1H3v-1h2v-6H3v-1h3zm7.75-7h-2.5A1.251 1.251 0 0 0 10 11.25V18h1v-6.75a.25.25 0 0 1 .25-.25h2.5a.25.25 0 0 1 .25.25V18h1v-6.75A1.251 1.251 0 0 0 13.75 10zM6 9V6H5v3zm14-4h-1v5h-2v1h2v5.75A1.251 1.251 0 0 0 20.25 18H22v-1h-1.75a.25.25 0 0 1-.25-.25V11h2v-1h-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19 15.5a.5.5 0 0 0-.5-.5h-4a.5.5 0 0 0-.5.5V24h-1v-8.5a1.502 1.502 0 0 1 1.5-1.5h4a1.502 1.502 0 0 1 1.5 1.5V24h-1zM11 23H8v-9H4v1h3v8H4v1h7zM8 8H7v4h1zm17-1h-1v7h-2v1h2v7.5a1.502 1.502 0 0 0 1.5 1.5H29v-1h-3.5a.5.5 0 0 1-.5-.5V15h4v-1h-4z"
  }));
};

var _default = IntegerIcon;
exports["default"] = _default;