"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListRadioIcon = function ListRadioIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.959 6A2.041 2.041 0 0 1 5 8.041 1.959 1.959 0 0 1 3.041 10 2.041 2.041 0 0 1 1 7.959 1.959 1.959 0 0 1 2.959 6zM5 14a2 2 0 1 1-2-2 2 2 0 0 1 2 2zm-1-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5zM1 2a2 2 0 1 1 2 2 2 2 0 0 1-2-2zm1 .5a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5zM15 2H6v1h9zM6 15h9v-1H6zm0-6h9V8H6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 4h13v1H9zm0 17h13v-1H9zm0-8h13v-1H9zM7 4a3 3 0 1 1-3-3 3 3 0 0 1 3 3zM6 4a2 2 0 1 0-2 2 2.003 2.003 0 0 0 2-2zm1 8a3 3 0 1 1-3-3 3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2 2 0 0 0 2-2zm1 8a3 3 0 1 1-3-3 3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2.003 2.003 0 0 0 2-2zm-2-9a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 6h17v1H12zm0 11h17v-1H12zm0 10h17v-1H12zM3 6.5A3.5 3.5 0 1 1 6.5 10 3.5 3.5 0 0 1 3 6.5zm1 0A2.5 2.5 0 1 0 6.5 4 2.5 2.5 0 0 0 4 6.5zM6.5 18A1.5 1.5 0 1 0 5 16.5 1.5 1.5 0 0 0 6.5 18zM3 16.5A3.5 3.5 0 1 1 6.5 20 3.5 3.5 0 0 1 3 16.5zm1 0A2.5 2.5 0 1 0 6.5 14 2.503 2.503 0 0 0 4 16.5zM6.5 30a3.5 3.5 0 1 1 3.5-3.5A3.5 3.5 0 0 1 6.5 30zm0-1A2.5 2.5 0 1 0 4 26.5 2.5 2.5 0 0 0 6.5 29z"
  }));
};

var _default = ListRadioIcon;
exports["default"] = _default;