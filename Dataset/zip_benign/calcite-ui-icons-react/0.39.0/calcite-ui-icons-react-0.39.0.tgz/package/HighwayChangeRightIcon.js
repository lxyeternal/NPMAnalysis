"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HighwayChangeRightIcon = function HighwayChangeRightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 8.238a6.461 6.461 0 0 1-1 .881V14h1zM3 2h1v6.193a6.407 6.407 0 0 0-1 .836zm9 2c0 3.402-2.36 4.36-4.442 5.204C5.648 9.978 4 10.646 4 13v1H3v-1c0-3.027 2.222-3.928 4.182-4.723C9.23 7.447 11 6.73 11 4v-.277L9.398 5.325l-.707-.707 2.809-2.81 2.809 2.81-.707.707L12 3.723z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18 11.707a7.74 7.74 0 0 1-1 1.138V21h1zM6 15.21V3h1v11.13a7.408 7.408 0 0 0-1 1.08zM19.5 5.207l-1.5-1.5V6.5c0 4.923-3.164 6.328-5.956 7.567C9.358 15.26 7.039 16.29 7.039 20v1h-1v-1c0-4.36 2.847-5.624 5.599-6.847C14.396 11.93 17 10.773 17 6.5V3.707l-1.64 1.64-.708-.706L17.5 1.793l2.848 2.848-.707.707z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24 13.965a9.213 9.213 0 0 1-1 1.342V28h1zM8 4h1v15.253A8.664 8.664 0 0 0 8 20.5zm16.015 4c0 6.459-4.279 8.309-8.054 9.94C12.38 19.486 9 20.947 9 26v2H8v-2c0-5.709 3.846-7.371 7.564-8.979 3.832-1.655 7.45-3.22 7.45-9.021V4.692l-2.66 2.662-.707-.707L23.5 2.793l3.854 3.854-.707.707-2.632-2.632z"
  }));
};

var _default = HighwayChangeRightIcon;
exports["default"] = _default;