"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GammaIcon = function GammaIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.337.89c-.334.459-2.122 2.935-3.696 5.3-.513-2.253-1.504-4.232-3.136-4.248H5.48c-2.092 0-2.554 2.72-2.573 2.837l.987.159c.003-.02.335-1.996 1.588-1.996h.013c1.007.01 1.948 1.917 2.363 4.445a15.65 15.65 0 0 0-1.718 3.136c-.288 1.182-.479 3.242.173 4.073a1.01 1.01 0 0 0 .803.404c1.967 0 1.967-3.638 1.967-4.834a18.664 18.664 0 0 0-.184-2.551c1.264-1.942 2.95-4.35 4.247-6.138zM7.125 14.003c-.245-.152-.416-1.592-.015-3.243a9.068 9.068 0 0 1 .932-1.789c.027.392.041.792.041 1.196 0 2.826-.499 3.833-.958 3.836z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18.161 2.046c-.04.074-3.037 5.527-5.19 9.673C12.484 7.699 10.952 2 8.5 2 5.693 2 5.065 7.25 5.003 7.848l.994.104C6.131 6.667 6.877 3 8.5 3c1.696 0 3.419 6.31 3.618 10.38a62.72 62.72 0 0 0-.872 1.785l-.124.269c-1.608 3.473-2.607 5.837-1.863 7.002a1.435 1.435 0 0 0 1.304.627c2.395 0 2.575-3.539 2.575-8.938 0-.164-.004-.34-.011-.524 2.11-4.157 5.866-10.991 5.911-11.072zm-7.599 20.017c-.355 0-.432-.12-.46-.166-.505-.79.9-3.826 1.927-6.043l.1-.215c-.055 4.178-.379 6.424-1.567 6.424z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.941 16.287C16.515 9.902 13.801 3 10.5 3 7.04 3 7 9.714 7 10h1c.001-1.669.452-6 2.5-6 2.401 0 5.5 6.79 5.5 14v.5c-1.259 2.97-2.267 5.42-2.574 6.342-.707 2.12-.608 3.981.253 4.74a1.286 1.286 0 0 0 .863.332 1.558 1.558 0 0 0 .674-.164c1.428-.684 1.766-2.678 1.783-11.044 2.871-6.771 6.998-16.168 7.059-16.305L23.142 2c-.22.5-3.494 7.955-6.2 14.288zm-2.158 12.562c-.244.116-.36.055-.443-.017-.356-.314-.66-1.588.035-3.674.218-.654.812-2.13 1.606-4.034-.074 5.502-.39 7.338-1.198 7.725z"
  }));
};

var _default = GammaIcon;
exports["default"] = _default;