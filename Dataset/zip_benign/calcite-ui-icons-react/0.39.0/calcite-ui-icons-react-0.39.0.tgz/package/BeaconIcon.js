"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BeaconIcon = function BeaconIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 7a1 1 0 1 0 1 1 1.001 1.001 0 0 0-1-1zm-2.985 3.91a4.68 4.68 0 0 1-.003-5.817l.783.622a3.68 3.68 0 0 0 .002 4.572zm-1.99 2.052a7.132 7.132 0 0 1 0-9.924l.72.693a6.135 6.135 0 0 0 0 8.538zm7.963-2.055l-.783-.622a3.68 3.68 0 0 0-.002-4.572l.782-.623a4.68 4.68 0 0 1 .003 5.817zm1.988 2.055l-.721-.693a6.135 6.135 0 0 0 0-8.538l.72-.693a7.132 7.132 0 0 1 0 9.924z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.5 11a1.5 1.5 0 1 0 1.5 1.5 1.502 1.502 0 0 0-1.5-1.5zm-4.584 6.219a6.769 6.769 0 0 1 0-9.438l.718.697a5.769 5.769 0 0 0 0 8.044zm-2.845 2.695a10.497 10.497 0 0 1 0-14.828l.707.707a9.497 9.497 0 0 0 0 13.414zm12.013-2.695l-.718-.697a5.769 5.769 0 0 0 0-8.044l.718-.697a6.769 6.769 0 0 1 0 9.438zm2.845 2.695l-.707-.707a9.497 9.497 0 0 0 0-13.414l.707-.707a10.497 10.497 0 0 1 0 14.828z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.024 14a2 2 0 1 0 2 2 2.002 2.002 0 0 0-2-2zm-5.426 8.176a8.858 8.858 0 0 1 0-12.352l.718.697a7.858 7.858 0 0 0 0 10.959zm10.804 0l-.718-.697a7.858 7.858 0 0 0 0-10.959l.718-.696a8.858 8.858 0 0 1 0 12.352zM7.118 25.767a13.812 13.812 0 0 1 0-19.534l.707.707a12.813 12.813 0 0 0 0 18.12zm17.764 0l-.707-.707a12.813 12.813 0 0 0 0-18.12l.707-.707a13.812 13.812 0 0 1 0 19.534z"
  }));
};

var _default = BeaconIcon;
exports["default"] = _default;