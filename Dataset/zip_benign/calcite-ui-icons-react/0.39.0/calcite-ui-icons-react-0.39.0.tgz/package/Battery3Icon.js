"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var Battery3Icon = function Battery3Icon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 16a1.003 1.003 0 0 0 1-1V2a1.003 1.003 0 0 0-1-1h-1a1.003 1.003 0 0 0-1-1H7a1.003 1.003 0 0 0-1 1H5a1.003 1.003 0 0 0-1 1v13a1.003 1.003 0 0 0 1 1zM5 2h2V1h3v1h2v13H5zm1 10h5v2H6zm0-3h5v2H6zm0-3h5v2H6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 5v16a2.006 2.006 0 0 0 2 2h8a2.006 2.006 0 0 0 2-2V5a2.006 2.006 0 0 0-2-2h-1V2a1.003 1.003 0 0 0-1-1h-4a1.003 1.003 0 0 0-1 1v1H8a2.006 2.006 0 0 0-2 2zm1 0a1 1 0 0 1 1-1h2V2h4v2h2a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1zm9 16H8v-3h8zm0-4H8v-3h8zm0-4H8v-3h8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10 30h12a2.006 2.006 0 0 0 2-2V6a2.006 2.006 0 0 0-2-2h-2V3a1.003 1.003 0 0 0-1-1h-6a1.003 1.003 0 0 0-1 1v1h-2a2.006 2.006 0 0 0-2 2v22a2.006 2.006 0 0 0 2 2zM9 6a1 1 0 0 1 1-1h3V3h6v2h3a1 1 0 0 1 1 1v22a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1zm12 21H11v-4h10zm0-5H11v-4h10zm0-5H11v-4h10z"
  }));
};

var _default = Battery3Icon;
exports["default"] = _default;