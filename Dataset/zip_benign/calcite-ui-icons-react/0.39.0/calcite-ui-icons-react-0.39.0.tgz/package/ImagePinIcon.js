"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ImagePinIcon = function ImagePinIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 12.694l2.3-2.454a.27.27 0 0 1 .4 0 .27.27 0 0 0 .4 0l2.017-2.152a.27.27 0 0 1 .381-.018l2.03 1.804a.269.269 0 0 0 .35.01l1.226-.824a.27.27 0 0 1 .37.028L15 11.524V5H7V4h9v11H2v-4.307L3 11.7zM3 14h12v-1.087l-2.809-2.709-.686.46a1.267 1.267 0 0 1-1.64-.042L8.362 9.288 6.83 10.924a1.28 1.28 0 0 1-.929.405 1.253 1.253 0 0 1-.23-.022L3 14zm8.5-6.5a1 1 0 1 0-1-1 1 1 0 0 0 1 1zM6 6.661l-3 3.02-3-3.02v-4.04C0 1.104 1.122.198 3 .198s3 .906 3 2.425zM5 6.25V2.622c0-.945-.673-1.425-2-1.425s-2 .48-2 1.425v3.627l2 2.014zM4 3.5a1 1 0 1 0-1 1 1 1 0 0 0 1-1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 6v11.067l-2.714-2.714a.503.503 0 0 0-.657-.047L16.45 15.94a.503.503 0 0 1-.623-.016l-3.609-3.007a.503.503 0 0 0-.677.031l-3.627 3.628a.474.474 0 0 1-.678-.049.503.503 0 0 0-.704.008L4 19.067v-2.496l-1-1.007V22h20V5H11v1zm0 15H4v-.519l2.947-2.947a1.506 1.506 0 0 0 .677.163 1.403 1.403 0 0 0 .997-.415l3.307-3.307 3.26 2.716a1.502 1.502 0 0 0 1.863.049l1.833-1.375L22 18.481zm-5.5-10A1.5 1.5 0 1 0 15 9.5a1.5 1.5 0 0 0 1.5 1.5zm0-2a.5.5 0 1 1-.5.5.5.5 0 0 1 .5-.5zM5 14.74l4-4.026v-7.42C9 1.294 7.505.2 5 .2S1 1.394 1 3.394v7.32zM2 3.393C2 1.58 3.631 1.2 5 1.2s3 .28 3 2.094v7.008l-3 3.02-3-3.02zM5 7a2 2 0 1 0-2-2 2.002 2.002 0 0 0 2 2zm0-3a1 1 0 1 1-1 1 1.001 1.001 0 0 1 1-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 8v15.247l-3.997-3.669a.652.652 0 0 0-.926-.033L21 22.293l-4.554-4.131a.652.652 0 0 0-.857-.013l-5.139 4.268-.826-.391a.642.642 0 0 0-.72.117L5 25.248V20.56l-1-1.006V29h26V7H14v1zm0 20H5v-1.474l4.401-3.5 1.198.567L16 19.106l5 4.531 3.506-3.123L29 24.581zm-8-12a2 2 0 1 0-2-2 2.002 2.002 0 0 0 2 2zm0-3a1 1 0 1 1-1 1 1.001 1.001 0 0 1 1-1zM7 19.735l5-5.032V6.038c0-2.493-1.776-3.865-5-3.865-3.178 0-5 1.445-5 3.964v8.566zM3 6.137c0-2.45 2.175-2.964 4-2.964 2.654 0 4 .964 4 2.864v8.254l-4 4.026-4-4.026zM5 8a2 2 0 1 0 2-2 2.002 2.002 0 0 0-2 2zm3 0a1 1 0 1 1-1-1 1.001 1.001 0 0 1 1 1z"
  }));
};

var _default = ImagePinIcon;
exports["default"] = _default;