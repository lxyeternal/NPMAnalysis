"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerFilterIcon = function LayerFilterIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.731 8.682a.984.984 0 0 0 .235-.502L16 14.29a6.624 6.624 0 0 0-3.793-1.09c-.04 0-.076.003-.116.003l.05-1.001.066-.002a8.317 8.317 0 0 1 2.489.376l-.553-3.264zm-7.05 4.37a10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363L2.935 2.74A11.376 11.376 0 0 0 5.294 3a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.212 7.212 0 0 1 2.27.399L13.414 5H14a.977.977 0 0 1 .448.118l-.58-3.43a8.204 8.204 0 0 0-3.162-.674c-2.69 0-2.724.986-5.412.986a10.39 10.39 0 0 1-3.161-.512L0 14.09a9.158 9.158 0 0 0 3.793.711 14.894 14.894 0 0 0 5.14-1.103l-.05-1.026c-.418.12-.814.25-1.202.381zM14 8l-2.8 3h-.006l-.24 1-.13 3h-.649l-.13-3-.24-1H9.8L7 8V6h7zm-1.84.8H8.84l1.307 1.4h.706zM13.2 8V6.8H7.8V8z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.636 13.874l.867-.868 1.378 8.177a12.395 12.395 0 0 0-4.32-.977l.124-.997a15.765 15.765 0 0 1 2.93.477zM1 20.783A13.093 13.093 0 0 0 6.424 21.8a29.78 29.78 0 0 0 7.513-1.16l-.123-.995c-.556.115-1.086.24-1.607.366a22.05 22.05 0 0 1-5.783.789 13.727 13.727 0 0 1-4.3-.65L4.848 4.343A16.193 16.193 0 0 0 8.57 4.8a9.805 9.805 0 0 0 4.25-.875 7.792 7.792 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l.684 4.059h1.014l-.808-4.796a12.674 12.674 0 0 0-4.52-.878c-3.848 0-3.892 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722zm22.222-11.91v2l-4 4-1 8h-3l-1-8-4-4v-2zm-5.133 6h-2.734l.75 7h1.234zm2.72-3h-8.173l2 2h4.172zm-9.587-2v.586l.414.414h10.172l.414-.414v-.586z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.075 26.612l.122.994c-3.553.731-5.502 2.194-10.66 2.194A16.273 16.273 0 0 1 1 28L5 3.9a14.99 14.99 0 0 0 5.34.968c4.807 0 5.59-1.657 10.734-1.657A26.401 26.401 0 0 1 27 3.9l1.178 7.1h-1.013l-1.041-6.271a26.164 26.164 0 0 0-5.05-.518 16.628 16.628 0 0 0-5.29.81 17.42 17.42 0 0 1-5.445.847 15.6 15.6 0 0 1-4.544-.65L2.107 27.433a15.989 15.989 0 0 0 6.43 1.366 20.422 20.422 0 0 0 7.156-1.252 29.638 29.638 0 0 1 3.382-.936zm10.7.116a36.802 36.802 0 0 0-4.803-.495l-.122.994A31.917 31.917 0 0 1 31 28l-1.935-11.658-.87.868zM30 12v2l-5 5-1.5 11h-3L19 19l-5-5v-2zm-6.146 7h-3.709l1.228 10h1.254zm4.01-4H16.136l3.333 3h5.064zm1.335-2.2H14.801V14h14.398z"
  }));
};

var _default = LayerFilterIcon;
exports["default"] = _default;