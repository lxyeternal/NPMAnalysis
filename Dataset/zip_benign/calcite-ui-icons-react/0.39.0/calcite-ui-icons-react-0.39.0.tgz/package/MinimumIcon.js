"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MinimumIcon = function MinimumIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 7h-2v5h-1V7a1.001 1.001 0 0 1 1-1h2a1.001 1.001 0 0 1 1 1v5h-1zm-8 5V7a1.001 1.001 0 0 0-1-1H4a.97.97 0 0 0-.5.154A.97.97 0 0 0 3 6H1v6h1V7h1v5h1V7h1v5zm4-1H9V6H7v1h1v4H7v1h3zM9 3H8v2h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 17h2v1h-5v-1h2v-6h-2v-1h3zm7.75-7h-2.5A1.251 1.251 0 0 0 18 11.25V18h1v-6.75a.25.25 0 0 1 .25-.25h2.5a.25.25 0 0 1 .25.25V18h1v-6.75A1.251 1.251 0 0 0 21.75 10zm-14 0h-1.5a1.223 1.223 0 0 0-.75.276A1.223 1.223 0 0 0 4.75 10H2v8h1v-7h1.75a.25.25 0 0 1 .25.25V18h1v-6.75a.25.25 0 0 1 .25-.25h1.5a.25.25 0 0 1 .25.25V18h1v-6.75A1.251 1.251 0 0 0 7.75 10zM14 9V6h-1v3z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M7 15.5a.5.5 0 0 0-.5-.5H4v9H3V14h3.5a1.489 1.489 0 0 1 1 .39 1.489 1.489 0 0 1 1-.39h2a1.502 1.502 0 0 1 1.5 1.5V24h-1v-8.5a.5.5 0 0 0-.5-.5h-2a.5.5 0 0 0-.5.5V24H7zM21 23h-3v-9h-4v1h3v8h-3v1h7zM18 8h-1v4h1zm10.5 6h-4a1.502 1.502 0 0 0-1.5 1.5V24h1v-8.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 .5.5V24h1v-8.5a1.502 1.502 0 0 0-1.5-1.5z"
  }));
};

var _default = MinimumIcon;
exports["default"] = _default;