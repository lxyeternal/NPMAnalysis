"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BracketsCurlyIcon = function BracketsCurlyIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 8v1a1.001 1.001 0 0 0-1 1v2.578A2.425 2.425 0 0 1 11.578 15H11v-1h.578A1.423 1.423 0 0 0 13 12.578V10a1.996 1.996 0 0 1 .679-1.5A1.996 1.996 0 0 1 13 7V4.422A1.423 1.423 0 0 0 11.578 3H11V2h.578A2.425 2.425 0 0 1 14 4.422V7a1.001 1.001 0 0 0 1 1zM3 4.422V7a1.001 1.001 0 0 1-1 1v1a1.001 1.001 0 0 1 1 1v2.578A2.425 2.425 0 0 0 5.422 15H6v-1h-.578A1.423 1.423 0 0 1 4 12.578V10a1.996 1.996 0 0 0-.679-1.5A1.996 1.996 0 0 0 4 7V4.422A1.423 1.423 0 0 1 5.422 3H6V2h-.578A2.425 2.425 0 0 0 3 4.422z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 22H7.703A3.707 3.707 0 0 1 4 18.297V15a2.002 2.002 0 0 0-2-2v-1a2.002 2.002 0 0 0 2-2V6.703A3.707 3.707 0 0 1 7.703 3H9v1H7.703A2.706 2.706 0 0 0 5 6.703V10a3 3 0 0 1-1.343 2.5A3 3 0 0 1 5 15v3.297A2.706 2.706 0 0 0 7.703 21H9zm11-3.703V15a2.002 2.002 0 0 1 2-2v-1a2.002 2.002 0 0 1-2-2V6.703A3.707 3.707 0 0 0 16.297 3H15v1h1.297A2.706 2.706 0 0 1 19 6.703V10a3 3 0 0 0 1.343 2.5A3 3 0 0 0 19 15v3.297A2.706 2.706 0 0 1 16.297 21H15v1h1.297A3.707 3.707 0 0 0 20 18.297z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6 23.336V19.75A2.753 2.753 0 0 0 3.25 17H3v-1h.25A2.753 2.753 0 0 0 6 13.25V9.664A4.67 4.67 0 0 1 10.664 5H12v1h-1.336A3.668 3.668 0 0 0 7 9.664v3.586a3.752 3.752 0 0 1-1.88 3.25A3.752 3.752 0 0 1 7 19.75v3.586A3.668 3.668 0 0 0 10.664 27H12v1h-1.336A4.67 4.67 0 0 1 6 23.336zM29.75 16A2.753 2.753 0 0 1 27 13.25V9.664A4.67 4.67 0 0 0 22.336 5H21v1h1.336A3.668 3.668 0 0 1 26 9.664v3.586a3.752 3.752 0 0 0 1.88 3.25A3.752 3.752 0 0 0 26 19.75v3.586A3.668 3.668 0 0 1 22.336 27H21v1h1.336A4.67 4.67 0 0 0 27 23.336V19.75A2.753 2.753 0 0 1 29.75 17H30v-1z"
  }));
};

var _default = BracketsCurlyIcon;
exports["default"] = _default;