"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FreehandAreaIcon = function FreehandAreaIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 10.453c0-1.63 2.07-1.93 2.233-5.265A4.135 4.135 0 0 1 7.696 1.2c4.129 0 7.104 4.476 7.104 9.362 0 2.435-.76 4.438-3.127 4.438-2.623 0-3.786-1.776-6.09-1.776-.59 0-1.075.108-1.554.108A2.898 2.898 0 0 1 1 10.453zm12.8.11c0-4.611-2.738-8.363-6.105-8.363a3.145 3.145 0 0 0-3.463 3.037 6.435 6.435 0 0 1-1.657 4.175C2.15 9.94 2 10.15 2 10.453c0 1.857 2.008 1.879 2.028 1.879a5.694 5.694 0 0 0 .592-.044 8.876 8.876 0 0 1 .963-.064 7.144 7.144 0 0 1 3.278.947 6.05 6.05 0 0 0 2.812.829c.582 0 2.127 0 2.127-3.438z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.673 14a6.05 6.05 0 0 1-2.812-.83 7.144 7.144 0 0 0-3.278-.946 8.876 8.876 0 0 0-.963.064 5.694 5.694 0 0 1-.592.044c-.02 0-2.028-.022-2.028-1.879 0-.303.15-.514.575-1.04a6.435 6.435 0 0 0 1.657-4.176A3.145 3.145 0 0 1 7.695 2.2c3.367 0 6.105 3.752 6.105 8.362C13.8 14 12.255 14 11.673 14z",
      opacity: ".25"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.8 15.66c0 3.479-1.17 6.14-4.553 6.14-3.743 0-5.414-2.337-8.7-2.337-.844 0-1.535.154-2.22.154A4.14 4.14 0 0 1 2 15.504c0-2.329 2.956-2.756 3.19-7.521C5.373 4.254 8.23 2.2 11.565 2.2 17.521 2.2 21.8 8.757 21.8 15.66zm-1 0c0-6.017-3.711-12.46-9.235-12.46-2.37 0-5.2 1.265-5.376 4.832a8.817 8.817 0 0 1-2.272 5.716C3.314 14.493 3 14.91 3 15.504c0 3.077 3.293 3.113 3.326 3.113a8.45 8.45 0 0 0 .89-.066 12.225 12.225 0 0 1 1.33-.088 10.29 10.29 0 0 1 4.465 1.2 9.621 9.621 0 0 0 4.235 1.137c.879 0 3.554 0 3.554-5.14z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.246 20.8a9.621 9.621 0 0 1-4.235-1.137 10.29 10.29 0 0 0-4.464-1.2 12.225 12.225 0 0 0-1.331.088 8.45 8.45 0 0 1-.89.066C6.293 18.617 3 18.58 3 15.504c0-.594.314-1.01.917-1.756a8.817 8.817 0 0 0 2.272-5.716C6.364 4.465 9.194 3.2 11.565 3.2c5.524 0 9.235 6.443 9.235 12.46 0 5.14-2.675 5.14-3.554 5.14z",
      opacity: ".25"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.8 20.759c0 2.418-.583 8.04-5.98 8.04a12.725 12.725 0 0 1-5.953-1.608 11.537 11.537 0 0 0-5.357-1.489 14.998 14.998 0 0 0-1.614.108 12.156 12.156 0 0 1-1.272.091c-1.508 0-5.424-1.124-5.424-5.345a4.626 4.626 0 0 1 1.437-2.975 10.367 10.367 0 0 0 2.71-6.794A7.76 7.76 0 0 1 15.435 3.2C21.89 3.2 28.8 10.256 28.8 20.76zm-1 0C27.8 10.854 21.406 4.2 15.436 4.2a6.796 6.796 0 0 0-7.09 6.636 11.372 11.372 0 0 1-2.934 7.376c-.796.986-1.212 1.538-1.212 2.344 0 3.608 3.49 4.345 4.425 4.345a11.797 11.797 0 0 0 1.193-.087 15.554 15.554 0 0 1 1.692-.112 12.477 12.477 0 0 1 5.798 1.591A11.813 11.813 0 0 0 22.82 27.8c4.333 0 4.98-4.412 4.98-7.041z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.82 27.8a11.813 11.813 0 0 1-5.512-1.507 12.477 12.477 0 0 0-5.798-1.59 15.554 15.554 0 0 0-1.692.11 11.797 11.797 0 0 1-1.193.088c-.935 0-4.425-.737-4.425-4.345 0-.806.416-1.358 1.212-2.344a11.372 11.372 0 0 0 2.934-7.376 6.796 6.796 0 0 1 7.09-6.636c5.97 0 12.364 6.654 12.364 16.559 0 2.63-.647 7.04-4.98 7.04z",
    opacity: ".25"
  }));
};

var _default = FreehandAreaIcon;
exports["default"] = _default;