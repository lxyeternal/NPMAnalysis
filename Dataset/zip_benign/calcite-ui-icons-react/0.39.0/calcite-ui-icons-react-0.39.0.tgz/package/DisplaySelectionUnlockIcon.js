"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DisplaySelectionUnlockIcon = function DisplaySelectionUnlockIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.542 8.803a15.32 15.32 0 0 0-.852-2.156A7.708 7.708 0 0 1 7 1H1v5.78A2.987 2.987 0 0 1 6 9v1a.947.947 0 0 1-.032.158A1.75 1.75 0 0 1 7 11.75V15h4v-1.246c-1.417-2.834-1.035-3.317-1.458-4.951z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 1v14h-3v-1h2V6.026a6.874 6.874 0 0 0-3.739 1.67l-.265-.636c-.053-.128-.104-.23-.156-.342a7.952 7.952 0 0 1 4.16-1.7V2H8V1zM6.104 2.955l.993-.125A24.482 24.482 0 0 1 7 1.876V1H5v1h1.008q.043.525.096.955zm2.02 2.83a4.43 4.43 0 0 1-.568-.946l-.922.389a5.428 5.428 0 0 0 .68 1.143 7.47 7.47 0 0 1 .505.767l.871-.49a8.577 8.577 0 0 0-.566-.864zm.83 5.41l.977-.214c-.07-.324-.11-.609-.15-.894a10.735 10.735 0 0 0-.239-1.284l-.969.252a9.545 9.545 0 0 1 .217 1.17c.044.31.087.619.164.97zm.757 2.181c.086.19.195.41.3.624H8v1h3v-1.246a22.007 22.007 0 0 1-.377-.79zM1 1v2h1V2h1V1H1zm6.972 8.094l.026.013-.019-.027zM2 6.184V5H1v1.78a2.986 2.986 0 0 1 1-.596zm4 5.566v3.5a.751.751 0 0 1-.75.75H.75a.751.751 0 0 1-.75-.75v-3.5A.751.751 0 0 1 .75 11H1V9a2 2 0 0 1 4 0v1H4V9a1 1 0 0 0-2 0v2h3.25a.751.751 0 0 1 .75.75zM5 12H1v3h4zm-1 1H2v1h2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.5 8a4.505 4.505 0 0 1 4.5 4.5V15a.954.954 0 0 1-.041.204A1.87 1.87 0 0 1 11 16.875V22h6.541c-1.848-3.401-2.184-3.98-2.345-5.23-.278-2.167-.508-4.685-2.33-6.391C10.593 8.249 9.145 8.605 9 2H3v6.762A4.473 4.473 0 0 1 5.5 8z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 2v20h-3v-1h2V9.05a10.327 10.327 0 0 0-5.253 1.91c-.154-.249-.35-.542-.558-.837A11.364 11.364 0 0 1 21 8.048V3H10V2zM3 2v2h1V3h1V2H3zm9 20h2v-1h-2zM3 8h1V6H3zm6-6H7v1h1v.022c.017.362.038.7.067 1.024l.996-.09A17.355 17.355 0 0 1 9 2zm5.84 12.214a13.604 13.604 0 0 0-.594-1.81l-.088-.21-.914.406.073.173a12.676 12.676 0 0 1 .553 1.68zm.307 2.096l-.996.091c.016.165.032.33.053.497a6.758 6.758 0 0 0 .413 1.631l.932-.365a5.747 5.747 0 0 1-.353-1.394 12.46 12.46 0 0 1-.049-.46zM8.397 6.142a7.701 7.701 0 0 0 .772 2.035l.87-.494a6.726 6.726 0 0 1-.67-1.774zm4.47 4.237a11.45 11.45 0 0 0-.99-.802c-.211-.158-.424-.317-.632-.49l-.639.77c.222.183.447.352.671.52a10.747 10.747 0 0 1 .908.732zm3.583 9.592l-.888.457c.134.262.274.55.417.876l.305.696h1.257L17 21s-.405-.749-.55-1.03zM10 16.875v5.25a.877.877 0 0 1-.875.875h-7.25A.877.877 0 0 1 1 22.125v-5.25A.877.877 0 0 1 1.875 16H2v-3.5a3.5 3.5 0 0 1 7 0V15H6v-2.5a.5.5 0 0 0-1 0V16h4.125a.877.877 0 0 1 .875.875zM3 16h1v-3.5a1.5 1.5 0 0 1 3 0V14h1v-1.5a2.5 2.5 0 0 0-5 0zm6 1H2v5h7zm-3 2v-1H5v3h1v-1h1v-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 12a5.006 5.006 0 0 1 5 5v3a2.003 2.003 0 0 1 2 2v6h6.125c-1.812-4.102-1.217-6.705-2.028-9.7-1.825-6.736-4.83-4.49-5.82-11.308A27.182 27.182 0 0 1 13 3H4v11.03A4.981 4.981 0 0 1 8 12z",
    opacity: ".25"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.08 24.974c-.143-.678-.231-1.333-.34-2.186l.991-.127c.106.828.192 1.465.328 2.106zm.017-6.673l-.965.262a12.05 12.05 0 0 1 .367 2.053l.996-.097a12.988 12.988 0 0 0-.398-2.218zm-1.855-4.109l-.797.604a7.908 7.908 0 0 1 1.001 1.77l.924-.38a8.835 8.835 0 0 0-1.128-1.994zm-1.498-1.65a8.005 8.005 0 0 1-1.26-1.606l-.865.502a9.102 9.102 0 0 0 1.406 1.8zm-3-3.217l.961-.275a15.776 15.776 0 0 1-.429-2.058l-.99.145a16.771 16.771 0 0 0 .458 2.188zM4 9h1V7H4zm0-6v2h1V4h1V3H4zm4 1h2V3H8zm7 24h2v-1h-2zM4 13h1v-2H4zm8.057-8.066l.998-.067c-.021-.31-.045-.622-.055-.972S13 3 13 3h-1s-.011.635 0 1 .037.636.057.934zM19 28h2v-1h-2zM9 25v-1H8v-1H7v5h1v-1h1v-1H8v-1zm6-22v.84l.009.16H28v5.97a14.314 14.314 0 0 0-8.996 3.411 8.01 8.01 0 0 1 .454.932A13.213 13.213 0 0 1 28 10.97V27h-5v1h6V3zm-1 19v7a1.003 1.003 0 0 1-1 1H3a1.003 1.003 0 0 1-1-1v-7a1.003 1.003 0 0 1 1-1h1v-4a4 4 0 0 1 8 0v3H9v-3a1 1 0 0 0-2 0v4h6a1.003 1.003 0 0 1 1 1zm-9-1h1v-4a2 2 0 0 1 4 0v2h1v-2a3 3 0 0 0-6 0zm8 1H3v7h10z"
  }));
};

var _default = DisplaySelectionUnlockIcon;
exports["default"] = _default;