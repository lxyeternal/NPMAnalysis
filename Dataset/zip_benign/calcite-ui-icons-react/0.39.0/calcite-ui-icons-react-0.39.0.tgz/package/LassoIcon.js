"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LassoIcon = function LassoIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.673 15c2.368 0 3.127-2.003 3.127-4.438 0-4.886-2.975-9.362-7.104-9.362a4.135 4.135 0 0 0-4.463 3.988C3.069 8.524 1 8.823 1 10.453a2.898 2.898 0 0 0 3.029 2.879c.48 0 .963-.108 1.554-.108 2.304 0 3.467 1.776 6.09 1.776zm0-1a6.044 6.044 0 0 1-2.812-.83 7.138 7.138 0 0 0-3.278-.946 8.77 8.77 0 0 0-.964.064 5.657 5.657 0 0 1-.59.044c-.02 0-2.029-.021-2.029-1.879 0-.303.149-.514.575-1.04a6.434 6.434 0 0 0 1.657-4.177A3.145 3.145 0 0 1 7.696 2.2c3.366 0 6.104 3.751 6.104 8.362C13.8 14 12.254 14 11.673 14z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.247 21.8c3.382 0 4.553-2.661 4.553-6.14 0-6.903-4.28-13.46-10.235-13.46-3.334 0-6.192 2.054-6.375 5.783C4.956 12.748 2 13.175 2 15.504a4.14 4.14 0 0 0 4.327 4.113c.685 0 1.376-.154 2.22-.154 3.286 0 4.957 2.337 8.7 2.337zm0-1a9.619 9.619 0 0 1-4.237-1.137 10.293 10.293 0 0 0-4.464-1.2 12.357 12.357 0 0 0-1.33.088 8.562 8.562 0 0 1-.89.065c-.033 0-3.326-.035-3.326-3.112 0-.594.314-1.01.917-1.756a8.819 8.819 0 0 0 2.272-5.717c.175-3.565 3.006-4.83 5.376-4.83 5.524 0 9.235 6.442 9.235 12.46 0 5.139-2.675 5.139-3.553 5.139z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.82 28.8a12.725 12.725 0 0 1-5.953-1.61 11.537 11.537 0 0 0-5.357-1.488 14.998 14.998 0 0 0-1.614.108 12.156 12.156 0 0 1-1.272.091c-1.508 0-5.424-1.124-5.424-5.345a4.626 4.626 0 0 1 1.437-2.975 10.367 10.367 0 0 0 2.71-6.794A7.76 7.76 0 0 1 15.435 3.2C21.89 3.2 28.8 10.256 28.8 20.76c0 2.418-.583 8.04-5.98 8.04zm4.98-8.041C27.8 10.854 21.406 4.2 15.435 4.2a6.795 6.795 0 0 0-7.09 6.636 11.375 11.375 0 0 1-2.932 7.376c-.797.985-1.213 1.537-1.213 2.344 0 3.608 3.49 4.345 4.425 4.345a11.701 11.701 0 0 0 1.195-.087 15.518 15.518 0 0 1 1.69-.112 12.468 12.468 0 0 1 5.798 1.591A11.816 11.816 0 0 0 22.82 27.8c4.332 0 4.979-4.411 4.979-7.041z"
  }));
};

var _default = LassoIcon;
exports["default"] = _default;