"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileImageIcon = function FileImageIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.879 9.884a.269.269 0 0 1-.35-.01L7.498 8.07a.27.27 0 0 0-.382.018L5.1 10.24a.27.27 0 0 1-.4 0 .27.27 0 0 0-.4 0l-.3.32V14h9v-3.44l-1.527-1.472a.27.27 0 0 0-.37-.028zM12 10.985V13H5v-1.675a1.28 1.28 0 0 0 .83-.402l1.533-1.635 1.501 1.334a1.269 1.269 0 0 0 1.642.041l.685-.459zM15 3.6L11.4 0H2v16h13zM14 15H3V1h7v4h4zm0-11h-3V1h.31L14 3.69zm-3.5 2.75a.75.75 0 1 1-.75.75.75.75 0 0 1 .75-.75z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.472 13.13l-1.633 1.225a.377.377 0 0 1-.468-.012l-2.706-2.256a.377.377 0 0 0-.509.023l-2.69 2.69a.377.377 0 0 1-.533 0 .377.377 0 0 0-.533 0l-.4.4V20h12v-4.8l-2.035-2.035a.377.377 0 0 0-.493-.035zM17 19H7v-3.104a1.376 1.376 0 0 0 1.174-.389l2.287-2.287 2.27 1.89a1.375 1.375 0 0 0 1.708.044l1.2-.9L17 15.614zm-4-7.979v-.043a.979.979 0 0 1 .979-.978A1.021 1.021 0 0 1 15 11.021a.979.979 0 0 1-.979.979h-.043a.981.981 0 0 1-.978-.979zM3 23h18V6.709L15.29 1H3zM15 2h.2L20 6.8V7h-5zM4 2h10v6h6v14H4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27 9.699L19.3 2H5v28h22zM26 29H6V3h12v8h8zm-7-19V3l7 7zm.5 6a1.5 1.5 0 1 0-1.5-1.5 1.502 1.502 0 0 0 1.5 1.5zm0-2a.5.5 0 1 1-.5.5.5.5 0 0 1 .5-.5zm1.007 4.259l-1.79 1.684a.488.488 0 0 1-.653.015c-.765-.652-2.498-2.16-3.25-2.832a.488.488 0 0 0-.642-.009l-3.839 3.243a.485.485 0 0 1-.666 0 .485.485 0 0 0-.667 0l-1 .96V27h16v-5.68l-2.798-3.036a.49.49 0 0 0-.695-.025zM23 21.71V26H9v-4.253l.396-.381a1.486 1.486 0 0 0 1.63-.285l3.453-2.914c.852.752 2.265 1.98 2.937 2.553a1.488 1.488 0 0 0 1.985-.049l1.414-1.33z"
  }));
};

var _default = FileImageIcon;
exports["default"] = _default;