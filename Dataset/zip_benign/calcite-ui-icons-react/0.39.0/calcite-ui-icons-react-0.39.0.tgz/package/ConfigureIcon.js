"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ConfigureIcon = function ConfigureIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 4H6V3h6zm-4.38 6H1V1h12v5.853a1.241 1.241 0 0 1 .705.714l.054.145.17-.076c.023-.01.048-.006.071-.015V0H0v11h6.859a1.24 1.24 0 0 1 .711-.7l.146-.054-.075-.172c-.01-.024-.011-.05-.02-.074zM2 6h3v3H2zm1 2h1V7H3zm2-3H2V2h3zM4 3H3v1h1zm2 5h2.58l.081-.082a1.25 1.25 0 0 1 1.41-.256l.14.065.068-.177a1.24 1.24 0 0 1 .426-.55H6zm8.783 5.03q-.05.134-.112.262l.535 1.163-.771.765-1.194-.527q-.13.06-.265.107l-.444 1.2h-1.087l-.47-1.22q-.135-.05-.264-.113l-1.163.535-.764-.771.527-1.194q-.06-.13-.107-.265l-1.2-.444v-1.056l1.2-.444q.047-.136.107-.265l-.527-1.194.764-.771 1.163.535q.129-.062.263-.113L11.445 8h1.087l.444 1.2q.136.047.265.107l1.194-.527.77.765-.534 1.163q.062.128.112.262l1.217.471v1.117zm.215-.906v-.248l-.815-.27a2.206 2.206 0 0 0-.355-.862l.365-.793-.161-.16-.767.387a2.206 2.206 0 0 0-.861-.36L12.101 9h-.226l-.27.817a2.206 2.206 0 0 0-.861.354l-.793-.364-.159.16.385.768a2.206 2.206 0 0 0-.358.86L9 11.897v.204l.818.304a2.205 2.205 0 0 0 .358.859l-.385.768.16.16.792-.364a2.205 2.205 0 0 0 .862.354l.27.817h.226l.302-.819a2.207 2.207 0 0 0 .86-.359l.768.386.161-.16-.365-.792a2.205 2.205 0 0 0 .355-.862zM12 11a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.969 14a1.237 1.237 0 0 0 .044.863l.061.137H8v-1zm5.183-3.25h1.65a1.216 1.216 0 0 1 .198.03V10H8v1h8.412a1.243 1.243 0 0 1 .74-.25zM19 6H8v1h11zM4 13h3v3H4zm1 2h1v-1H5zm5.75 3H2V3h19v9.077l.135-.06a1.1 1.1 0 0 1 .865-.039V2H1v17h9.773a1.201 1.201 0 0 1-.023-.152zM7 8H4V5h3zM6 6H5v1h1zm1 6H4V9h3zm-1-2H5v1h1zm14 8a2 2 0 1 1-2-2 2 2 0 0 1 2 2zm-1 0a1 1 0 1 0-1 1 1 1 0 0 0 1-1zm3.414 1.392l-.296.628.724 1.624-1.162 1.17-1.543-.71-.653.236-.636 1.66h-1.65l-.59-1.586-.628-.295-1.627.727-1.167-1.166.71-1.543-.236-.653-1.66-.636v-1.65l1.586-.59.295-.628-.727-1.627 1.166-1.167 1.543.71.653-.236.636-1.66h1.65l.59 1.586.628.296 1.624-.724 1.166 1.167-.705 1.538.235.653 1.66.636v1.65zm-1.277.523l.544-1.158 1.319-.49v-.582l-1.427-.548-.434-1.204.585-1.28-.412-.412-1.397.622-1.158-.544-.49-1.319h-.582l-.548 1.427-1.206.434-1.283-.59-.41.411.626 1.4-.545 1.161-1.319.49v.582l1.427.548.434 1.206-.59 1.283.411.41 1.4-.626 1.161.545.49 1.319h.582l.548-1.427 1.206-.434 1.28.588.411-.413z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 18h4.55l.45 1h-5zm9.691-4.436a1.244 1.244 0 0 1 .436-.564H11v1h9.525zM25 8H11v1h14zM9 15H6v-3h3zm-1-2H7v1h1zm5.757 10H3V4h25v10.322a1.232 1.232 0 0 1 .726.333l.274.272V3H2v21h12.12a1.238 1.238 0 0 1-.361-.855zM9 10H6V7h3zM8 8H7v1h1zm-2 9h3v3H6zm1 2h1v-1H7zm19 3a3 3 0 1 1-3-3 3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2 2 0 0 0 2-2zm3.493 2.696l.965 2.149-1.565 1.577-2.066-.95-.849.319-.838 2.201-2.222.008-.79-2.13-.824-.377-2.149.965-1.576-1.565.949-2.066-.318-.849-2.202-.838L15 20.92l2.13-.79.377-.826-.965-2.149 1.566-1.576 2.066.949.848-.318.838-2.202L24.08 14l.79 2.13.825.377 2.15-.965 1.576 1.566-.95 2.066.319.848 2.201.838.008 2.222-2.13.79zm-.206 1.913l-.875-1.948.722-1.552L30 22.417l-.004-.896-1.995-.76-.588-1.607.831-1.808-.636-.633-1.945.874-1.555-.721L23.417 15l-.897.004-.758 1.994-1.608.59-1.81-.832-.63.636.873 1.945-.72 1.555-1.866.692.003.896 1.995.76.588 1.606-.83 1.81.635.63 1.945-.872 1.555.721.69 1.864.898-.003.758-1.994 1.608-.59 1.81.832z"
  }));
};

var _default = ConfigureIcon;
exports["default"] = _default;