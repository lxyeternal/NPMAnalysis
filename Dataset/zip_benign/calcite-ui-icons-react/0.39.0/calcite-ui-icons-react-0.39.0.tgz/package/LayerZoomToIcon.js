"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerZoomToIcon = function LayerZoomToIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.793 14.8A9.158 9.158 0 0 1 0 14.089l2.133-12.6A10.39 10.39 0 0 0 5.294 2c2.688 0 2.721-.986 5.412-.986a8.205 8.205 0 0 1 3.161.674l1.748 10.324-1.181-.984-.436-2.578a5.468 5.468 0 0 0-.288-1.7l-.734-4.337a7.214 7.214 0 0 0-2.27-.399 5.895 5.895 0 0 0-2.367.434A7.833 7.833 0 0 1 5.294 3a11.376 11.376 0 0 1-2.359-.26l-1.81 10.697a9.54 9.54 0 0 0 2.668.363 9.568 9.568 0 0 0 2.073-.218l.691.865a10.534 10.534 0 0 1-2.764.353zm10.126 1.003l-2.067-2.067a.667.667 0 0 1 0-.943l.129-.13-.673-.672a4.55 4.55 0 1 1 .69-.691l.673.674.124-.124a.668.668 0 0 1 .943 0l2.067 2.068a.666.666 0 0 1 0 .943l-.943.942a.665.665 0 0 1-.943 0zM8.5 12A3.5 3.5 0 1 0 5 8.5 3.504 3.504 0 0 0 8.5 12zm4.294 1.265l1.597 1.595.471-.47-1.595-1.598zM9 9h2V8H9V6H8v2H6v1h2v2h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9.277 20.442a7.294 7.294 0 0 0 1.304.744 21.448 21.448 0 0 1-5.157.614A13.093 13.093 0 0 1 0 20.783L3.05 3.078a15.028 15.028 0 0 0 4.52.722c3.849 0 3.893-1.6 7.74-1.6a12.674 12.674 0 0 1 4.52.878l2.642 15.678-1.113-1.114c-.031-.031-.07-.052-.102-.081L18.94 3.815a11.86 11.86 0 0 0-3.63-.615 7.791 7.791 0 0 0-3.49.725 9.805 9.805 0 0 1-4.25.875 16.193 16.193 0 0 1-3.723-.457L1.124 20.15a13.726 13.726 0 0 0 4.3.65 19.768 19.768 0 0 0 3.853-.358zm13.519 1.467a.68.68 0 0 1 0 .962l-.934.932a.666.666 0 0 1-.943 0l-2.855-2.855a.668.668 0 0 1 0-.943l.129-.13-1.32-1.318a5.362 5.362 0 1 1 .69-.69l1.32 1.319.124-.124a.668.668 0 0 1 .943 0zm-4.994-7.41a4.3 4.3 0 1 0-4.3 4.3 4.304 4.304 0 0 0 4.3-4.3zm4.06 7.89l-2.383-2.385-.473.473 2.385 2.383zM14 12h-1v2h-2v1h2v2h1v-2h2v-1h-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.823 26.938l.299.3c-5.72.31-7.182 2.562-13.584 2.562A16.273 16.273 0 0 1 1 28L5 3.9a14.99 14.99 0 0 0 5.34.968c4.807 0 5.59-1.657 10.734-1.657A26.401 26.401 0 0 1 27 3.9l3.579 21.563-1.215-1.215-3.24-19.519a26.266 26.266 0 0 0-5.05-.518 16.633 16.633 0 0 0-5.29.81 17.433 17.433 0 0 1-5.445.847 15.6 15.6 0 0 1-4.544-.65L2.108 27.433a15.986 15.986 0 0 0 6.43 1.366 20.416 20.416 0 0 0 7.155-1.252 23.514 23.514 0 0 1 5.666-1.256 2.73 2.73 0 0 0 .464.646zM24.8 18.5a6.32 6.32 0 0 1-1.51 4.082l.872.873.218-.218a.81.81 0 0 1 1.144 0l4.24 4.238a.811.811 0 0 1 0 1.145l-1.145 1.143a.808.808 0 0 1-1.143 0l-4.24-4.239a.81.81 0 0 1 0-1.144l.219-.218-.873-.873A6.294 6.294 0 1 1 24.8 18.5zm-.722 6.453l3.97 3.968.874-.873-3.97-3.968zM18.5 23.8a5.3 5.3 0 1 0-5.3-5.3 5.25 5.25 0 0 0 5.3 5.3zM22 19v-1h-3v-3h-1v3h-3v1h3v3h1v-3z"
  }));
};

var _default = LayerZoomToIcon;
exports["default"] = _default;