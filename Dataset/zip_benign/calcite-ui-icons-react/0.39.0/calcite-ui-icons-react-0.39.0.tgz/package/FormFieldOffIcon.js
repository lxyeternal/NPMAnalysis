"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FormFieldOffIcon = function FormFieldOffIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 4L6 3h8.5A1.502 1.502 0 0 1 16 4.5v7a1.495 1.495 0 0 1-.44 1.06l-.707-.707A.498.498 0 0 0 15 11.5v-7a.5.5 0 0 0-.5-.5zm1 7h1v-1H8zm-2 0h1v-1H6zm9.354 3.646l-.707.707L12.293 13H1.5A1.502 1.502 0 0 1 0 11.5v-7A1.502 1.502 0 0 1 1.5 3h.793L.646 1.354l.707-.707zM11.293 12L5 5.707V6c-.742 0-.949.418-1 .572V9.43c.046.142.25.57 1 .57v1a2.08 2.08 0 0 1-1.5-.557A2.08 2.08 0 0 1 2 11v-1c.742 0 .949-.418 1-.572V6.57C2.954 6.428 2.75 6 2 6V5a2.08 2.08 0 0 1 1.5.557 1.954 1.954 0 0 1 .877-.473L3.293 4H1.5a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .5.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.5 8.557A2.08 2.08 0 0 1 7 8v1c-.742 0-.949.418-1 .572v5.858c.046.142.25.57 1 .57v1a2.08 2.08 0 0 1-1.5-.557A2.08 2.08 0 0 1 4 17v-1c.742 0 .949-.418 1-.572V9.57C4.954 9.428 4.75 9 4 9V8a2.08 2.08 0 0 1 1.5.557zM21.5 6a.5.5 0 0 1 .5.5v12a.493.493 0 0 1-.25.423l.716.715A1.49 1.49 0 0 0 23 18.5v-12A1.502 1.502 0 0 0 21.5 5H7.828l1 1zM10 17h1v-1h-1zm-2 0h1v-1H8zm6 0h1v-1h-1zm-2 0h1v-1h-1zm10.354 4.646l-.707.707L19.293 20H2.5A1.502 1.502 0 0 1 1 18.5v-12A1.502 1.502 0 0 1 2.5 5h1.793L1.646 2.354l.707-.707zM18.293 19l-13-13H2.5a.5.5 0 0 0-.5.5v12a.5.5 0 0 0 .5.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10.828 8l-1-1H28.5A1.502 1.502 0 0 1 30 8.5v15a1.502 1.502 0 0 1-1.5 1.5h-.672l-1-1H28.5a.5.5 0 0 0 .5-.5v-15a.5.5 0 0 0-.5-.5zM6 11v1c.75 0 .954.428 1 .57v6.858c-.051.154-.258.572-1 .572v1a2.087 2.087 0 0 0 1.43-.5h.14A2.087 2.087 0 0 0 9 21v-1c-.75 0-.954-.428-1-.57v-6.858c.051-.154.258-.572 1-.572v-1a2.08 2.08 0 0 0-1.5.557A2.08 2.08 0 0 0 6 11zm18 9h-1v.172l.828.828H24zm1 1h1v-1h-1zm-14 0h1v-1h-1zm6 0h1v-1h-1zm-2 0h1v-1h-1zm-2 0h1v-1h-1zm17.354 8.646l-.707.707L24.293 25H3.5A1.502 1.502 0 0 1 2 23.5v-15A1.502 1.502 0 0 1 3.5 7h2.793L1.646 2.354l.707-.707zM23.293 24L20 20.707V21h-1v-1h.293l-12-12H3.5a.5.5 0 0 0-.5.5v15a.5.5 0 0 0 .5.5z"
  }));
};

var _default = FormFieldOffIcon;
exports["default"] = _default;