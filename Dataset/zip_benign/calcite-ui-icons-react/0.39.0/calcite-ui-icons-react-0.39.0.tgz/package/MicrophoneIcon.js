"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MicrophoneIcon = function MicrophoneIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 13a5.006 5.006 0 0 0 5-5h1a6.004 6.004 0 0 1-5 5.91V15h3v1H4v-1h3v-1.09A6.004 6.004 0 0 1 2 8h1a5.006 5.006 0 0 0 5 5zm0-2a3.003 3.003 0 0 1-3-3V3a3 3 0 0 1 6 0v5a3.003 3.003 0 0 1-3 3zm0-1a2.003 2.003 0 0 0 2-2V3a2 2 0 0 0-4 0v5a2.003 2.003 0 0 0 2 2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 5.5v6a4.5 4.5 0 0 0 9 0v-6a4.5 4.5 0 0 0-9 0zm8 0v6a3.5 3.5 0 0 1-7 0v-6a3.5 3.5 0 0 1 7 0zm4 5.5h1v.5a8.504 8.504 0 0 1-8 8.475V22h5v1H6v-1h5v-2.025A8.504 8.504 0 0 1 3 11.5V11h1v.536a7.5 7.5 0 1 0 15 0z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.5 22a5.507 5.507 0 0 0 5.5-5.5v-8a5.5 5.5 0 0 0-11 0v8a5.507 5.507 0 0 0 5.5 5.5zM12 8.5a4.5 4.5 0 0 1 9 0v8a4.5 4.5 0 0 1-9 0zm5 17.475V29h7v1H9v-1h7v-3.025A9.504 9.504 0 0 1 7 16.5V16h1v.5a8.5 8.5 0 0 0 17 0V16h1v.5a9.504 9.504 0 0 1-9 9.475z"
  }));
};

var _default = MicrophoneIcon;
exports["default"] = _default;