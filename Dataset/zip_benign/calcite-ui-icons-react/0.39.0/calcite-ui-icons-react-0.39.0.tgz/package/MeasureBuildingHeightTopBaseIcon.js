"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MeasureBuildingHeightTopBaseIcon = function MeasureBuildingHeightTopBaseIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 8H5V7h1zm0 2H5v1h1zm3.824 1l1.676 2.058L13.176 11H12V4h1.176L11.5 1.942 9.824 4H11v7zM6 4H5v1h1zM4 7H3v1h1zm0-3H3v1h1zm12 10v1H0v-1h1V1h7v13zM7 2H2v12h5zm-3 8H3v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2h10v19h11v1H1v-1h1zm1 19h8V3H3zM17.176 5L15.5 2.942 13.824 5H15v13h-1.176l1.676 2.058L17.176 18H16V5zM8 5h2v2H8zm-4 7h2v-2H4zm0-5h2V5H4zm0 10h2v-2H4zm4-5h2v-2H8zm0 5h2v-2H8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 6H5v3h3zM7 8H6V7h1zm9 21V2H2v27H1v1h30v-1zm-1 0H3V3h12zm-2-16h-3v3h3zm-1 2h-1v-1h1zm1 5h-3v3h3zm-1 2h-1v-1h1zm8 3V6h-2.19l2.69-3.058L23.19 6H21v19h2.19l-2.69 3.058L17.81 25zM8 13H5v3h3zm-1 2H6v-1h1zm1 5H5v3h3zm-1 2H6v-1h1zm6-16h-3v3h3zm-1 2h-1V7h1z"
  }));
};

var _default = MeasureBuildingHeightTopBaseIcon;
exports["default"] = _default;