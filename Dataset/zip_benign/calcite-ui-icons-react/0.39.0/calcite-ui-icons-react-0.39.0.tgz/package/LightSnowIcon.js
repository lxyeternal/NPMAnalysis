"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LightSnowIcon = function LightSnowIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 10h-1V9h1zm1 0h1V9h-1zm2-1v1h1V9zm-2-1h1V7h-1zm0 4h1v-1h-1zm-1.354-1.354l.707.707.5-.5-.707-.707zm3.707-2.293l-.707-.707-.5.5.707.707zm-1.207 2.5l.5.5.707-.707-.5-.5zm-2.5-2.5l.5.5.707-.707-.5-.5zM2 13H1v1h1zm1 1h1v-1H3zm2 0h1v-1H5zm-2-2h1v-1H3zm0 4h1v-1H3zm-1.354-1.354l.707.707.5-.5-.707-.707zm2.5-2.5l.707.707.5-.5-.707-.707zm0 2.707l.5.5.707-.707-.5-.5zm-2.5-2.5l.5.5.707-.707-.5-.5zM5 3H3v1h2zm1 1h1V3H6zm2 0h2V3H8zM6 2h1V0H6zm0 5h1V5H6zm-.128-2.165l-.743-.67L4.12 5.282l.743.67zm3.007-3.117l-.743-.67-1.008 1.117.743.67zm-1.75 3.117l1.007 1.117.743-.67L7.87 4.165zm-1.257-2.67L4.864 1.048l-.743.67L5.13 2.835z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 20H3v-1h2zm2-1H6v1h1zm3 0H8v1h2zm-3-3H6v2h1zm0 5H6v2h1zm-1.128-.165l-.743-.67-1.008 1.117.743.67zm3.007-3.117l-.743-.67-1.008 1.117.743.67zm0 3.564L7.87 20.165l-.743.67 1.008 1.117zm-3.007-3.117l-1.008-1.117-.743.67 1.008 1.117zM17 15h-2v1h2zm2 0h-1v1h1zm3 0h-2v1h2zm-3-3h-1v2h1zm0 5h-1v2h1zm-1.128-.165l-.743-.67-1.008 1.117.743.67zm3.007-3.117l-.743-.67-1.008 1.117.743.67zm0 3.564l-1.008-1.117-.743.67 1.008 1.117zm-3.007-3.117l-1.008-1.117-.743.67 1.008 1.117zm-3.59-7.214l-1.367.366L11.5 6.5l1.415-.817 1.366.366-.5-.866 1.472-.85-.5-.866-1.472.85-.5-.866-.366 1.366L11 5.634V3l1-1h-1V1h-1v1H9l1 1v2.634l-1.415-.817-.366-1.366-.5.866-1.472-.85-.5.866 1.472.85-.5.866 1.366-.366L9.5 6.5l-1.415.817-1.366-.366.5.866-1.472.85.5.866 1.472-.85.5.866.366-1.366L10 7.366V10l-1 1h1v1h1v-1h1l-1-1V7.366l1.415.817.366 1.366.5-.866 1.472.85.5-.866-1.472-.85z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.098 5.831l-1.547.875 1.201.969-.627.78-1.512-1.22-3.097 1.751 3.097 1.75 1.512-1.218.627.779-1.201.97 1.547.874-.493.87-1.528-.863-.162 1.517-.995-.107.21-1.946L13 9.843v3.868l1.727.685-.37.93L13 14.787V16h-1v-1.213l-1.358.54-.369-.93L12 13.71V9.843l-3.13 1.769.21 1.946-.995.107-.162-1.517-1.528.864-.493-.871 1.547-.875-1.201-.97.627-.778 1.512 1.219 3.097-1.75-3.097-1.752-1.512 1.22-.627-.78 1.201-.97-1.547-.874.493-.871 1.528.864.162-1.516.995.107-.21 1.945L12 8.13V4.288l-1.727-.685.37-.93 1.357.54V2h1v1.213l1.358-.54.369.93L13 4.29v3.84l3.13-1.769-.21-1.945.995-.107.162 1.516 1.528-.864zm10.183 13.12l-1.366.366L26.5 18.5l1.415-.817 1.366.366-.5-.866.866-.5-.5-.866-.866.5-.5-.866-.366 1.366-1.415.817V16l1-1h-1v-1h-1v1h-1l1 1v1.634l-1.415-.817-.366-1.366-.5.866-.866-.5-.5.866.866.5-.5.866 1.366-.366 1.415.817-1.415.817-1.366-.366.5.866-.866.5.5.866.866-.5.5.866.366-1.366L25 19.366V21l-1 1h1v1h1v-1h1l-1-1v-1.634l1.415.817.366 1.366.5-.866.866.5.5-.866-.866-.5zm-17.134 3.866l-.866.5-.5-.866-.366 1.366L9 24.634V23l1-1H9v-1H8v1H7l1 1v1.634l-1.415-.817-.366-1.366-.5.866-.866-.5-.5.866.866.5-.5.866 1.366-.366L7.5 25.5l-1.415.817-1.366-.366.5.866-.866.5.5.866.866-.5.5.866.366-1.366L8 26.366V28l-1 1h1v1h1v-1h1l-1-1v-1.634l1.415.817.366 1.366.5-.866.866.5.5-.866-.866-.5.5-.866-1.366.366L9.5 25.5l1.415-.817 1.366.366-.5-.866.866-.5z"
  }));
};

var _default = LightSnowIcon;
exports["default"] = _default;