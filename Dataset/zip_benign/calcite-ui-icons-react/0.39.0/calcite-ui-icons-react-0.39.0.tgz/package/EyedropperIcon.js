"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EyedropperIcon = function EyedropperIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M.069 15.188a.559.559 0 0 0 .743.743l4.038-1.953 7.614-7.614.708.707.707-.707-.243-.243a.656.656 0 0 1 0-.928l1.778-1.779A2 2 0 0 0 12.586.586l-1.779 1.778a.656.656 0 0 1-.928 0l-.243-.243-.707.707.707.708-7.614 7.614zM11.515 3.071l1.778-1.778a1 1 0 0 1 1.414 1.414L12.93 4.486a1.65 1.65 0 0 0-.37.559L10.956 3.44a1.646 1.646 0 0 0 .56-.369zm-1.172 1.172l1.414 1.414-3.3 3.3H5.628z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.957 5.457a2.06 2.06 0 0 0-2.914-2.914L16.5 5.086a.5.5 0 0 1-.707 0l-.44-.44-.706.707.723.724L4.927 16.519l-2.38 5.234a.151.151 0 0 0 .2.2l5.234-2.38L18.423 9.13l.723.724.707-.707-.439-.44a.5.5 0 0 1 0-.707zM12.34 14l-4.18.5 7.817-7.816 1.84 1.84L12.34 14zm6.367-6.707a1.495 1.495 0 0 0-.29.418l-1.639-1.64a1.406 1.406 0 0 0 .429-.278L19.75 3.25a1.06 1.06 0 0 1 1.5 1.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29.519 7.22a2.644 2.644 0 0 0-3.739-3.74l-3.334 3.334a.643.643 0 0 1-.91 0l-.96-.959-.705.706 1.414 1.414L5.684 23.577 3.023 29.46a.321.321 0 0 0 .419.427l5.98-2.57 15.602-15.601 1.414 1.414.706-.706-.96-.959a.644.644 0 0 1 0-.91zM17.324 18h-4.648l9.317-9.317 2.324 2.324zm8.154-8.153a1.627 1.627 0 0 0-.362.546l-2.508-2.508a1.646 1.646 0 0 0 .544-.362l3.335-3.334a1.643 1.643 0 0 1 2.324 2.324z"
  }));
};

var _default = EyedropperIcon;
exports["default"] = _default;