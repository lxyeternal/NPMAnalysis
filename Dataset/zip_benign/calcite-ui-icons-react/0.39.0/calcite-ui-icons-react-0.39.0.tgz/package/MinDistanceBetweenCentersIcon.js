"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MinDistanceBetweenCentersIcon = function MinDistanceBetweenCentersIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.494 14.168l.46.794a6.855 6.855 0 0 1-6.577.156 8.047 8.047 0 0 0 .705-.676 5.94 5.94 0 0 0 5.412-.274zm-2.98-12.133a5.959 5.959 0 0 1 2.98.797l.46-.794a6.855 6.855 0 0 0-6.577-.156 8.047 8.047 0 0 1 .705.676 5.92 5.92 0 0 1 2.432-.523zM0 7v3h3V7zm2 2H1V8h1zm11-2v3h3V7zm2 2h-1V8h1zm-3-.5L10 7v1H6V7L4 8.5 6 10V9h4v1zM3.581 2.12a6.19 6.19 0 0 1 5.704 3.803h1.012a7.125 7.125 0 0 0-10.282-3.8l.476.823a6.178 6.178 0 0 1 3.09-.827zm5.704 8.957a6.182 6.182 0 0 1-8.794 2.977l-.476.823a7.125 7.125 0 0 0 10.282-3.8z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.995 4.089a12.11 12.11 0 0 0-.732-.679 10.4 10.4 0 0 1 5.187-1.387 10.511 10.511 0 0 1 4.767 1.146l-.434.848a9.512 9.512 0 0 0-8.788.072zm4.455 17.934a9.46 9.46 0 0 1-4.455-1.112c-.233.238-.48.461-.732.679a10.4 10.4 0 0 0 5.187 1.387 10.511 10.511 0 0 0 4.767-1.146l-.434-.848a9.425 9.425 0 0 1-4.333 1.04zM2 14v-3h3v3zm1-1h1v-1H3zm17-2h3v3h-3zm1 2h1v-1h-1zM5.45 2.977A9.53 9.53 0 0 1 14.844 11h.962A10.47 10.47 0 0 0 .788 3.115l.423.854a9.42 9.42 0 0 1 4.24-.992zM14.844 14a9.53 9.53 0 0 1-9.394 8.023 9.42 9.42 0 0 1-4.239-.992l-.423.854A10.47 10.47 0 0 0 15.806 14zM19 12.5L17 11v1H8v-1l-2 1.5L8 14v-1h9v1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.513 28.154l.348.938a13.923 13.923 0 0 1-11.285-.719c.285-.226.557-.465.826-.71a12.891 12.891 0 0 0 10.111.491zM18.403 4.337a12.891 12.891 0 0 1 10.11-.491l.348-.938a13.923 13.923 0 0 0-11.285.719c.285.226.557.465.826.71zM6 15v3H3v-3zm-1 1H4v1h1zm24-1v3h-3v-3zm-1 1h-1v1h1zm-2.942.5L22 13.81V16H10v-2.19L6.942 16.5 10 19.19V17h12v2.19zM7.994 3.042A12.976 12.976 0 0 1 20.313 12h1.048A13.962 13.962 0 0 0 3.319 2.845l.335.941a12.94 12.94 0 0 1 4.34-.744zM19.946 21a12.969 12.969 0 0 1-16.291 7.214l-.335.943A13.956 13.956 0 0 0 21.01 21z"
  }));
};

var _default = MinDistanceBetweenCentersIcon;
exports["default"] = _default;