"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ChartGearIcon = function ChartGearIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.657 9.969c-.02.007-.036.022-.056.031H6V0h3v6.954a1.013 1.013 0 0 0-.257-.057 1.001 1.001 0 0 0-.711.296L8 7.225V1H7v7.297a.998.998 0 0 0-.033.872l.26.589zM11 3h1v3h1V2h-3v4h1zM0 0v12h6v-1H1V0zm5 5v5H2V5zM4 6H3v3h1zm3 4.906l1.354-.5q.053-.152.12-.298l-.592-1.343.86-.867 1.308.601q.144-.07.296-.126L10.876 7h1.222l.5 1.35q.152.053.298.12l1.343-.593.868.86-.602 1.309q.07.144.126.296l1.37.53v1.256l-1.37.53q-.056.152-.126.296l.602 1.308-.868.86-1.343-.592q-.145.067-.298.12l-.5 1.35h-1.222l-.53-1.373q-.151-.056-.296-.126l-1.308.601-.86-.867.592-1.343q-.067-.146-.12-.299L7 12.094zm.754.522v.144l1.188.44.119.33c.028.08.058.158.093.233l.144.309-.524 1.185.131.133 1.156-.531.32.156a1.988 1.988 0 0 0 .224.096l.318.118.468 1.209h.185l.442-1.192.335-.117c.08-.027.159-.06.236-.094l.305-.138 1.18.521.132-.13-.53-1.155.154-.318a2.322 2.322 0 0 0 .097-.227l.116-.318 1.207-.468v-.228l-1.207-.468-.116-.318a2.322 2.322 0 0 0-.097-.227l-.154-.318.53-1.155-.132-.13-1.184.522-.307-.14a2.47 2.47 0 0 0-.23-.093l-.335-.117-.442-1.192h-.185l-.468 1.209-.318.118a1.988 1.988 0 0 0-.224.096l-.32.156-1.156-.531-.13.133.523 1.185-.144.309a2.684 2.684 0 0 0-.093.232l-.119.331zM13 11.5a1.5 1.5 0 1 1-1.5-1.5 1.5 1.5 0 0 1 1.5 1.5zm-1-.5h-1v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 1v13h3V1zm2 12H9V2h1zm4-1h-1V5h3v6.023a.99.99 0 0 0-.781.62l-.137.357H15V6h-1zM6 9H3v5h3zm-1 4H4v-3h1zm6 2v1H1V1h1v14zm6 1a2 2 0 1 0 2 2 2 2 0 0 0-2-2zm0 3a1 1 0 1 1 1-1 1 1 0 0 1-1 1zm4.105-3.137l.705-1.538-1.166-1.167-1.624.724-.628-.296-.59-1.586h-1.65l-.636 1.66-.653.235-1.543-.71-1.166 1.168.727 1.627-.295.628-1.586.59v1.65l1.66.636.235.653-.71 1.543 1.168 1.166 1.627-.727.628.295.59 1.586h1.65l.636-1.66.653-.235 1.543.71 1.162-1.171-.724-1.624.296-.628 1.586-.59v-1.65l-1.66-.636zM22 18.266l-1.32.49-.543 1.16.623 1.398-.41.413-1.28-.588-1.207.434L17.315 23h-.581l-.491-1.32-1.16-.544-1.4.627-.412-.411.59-1.283-.434-1.206L12 18.315v-.581l1.32-.491.544-1.16-.627-1.4.411-.412 1.283.59 1.206-.434.548-1.427h.581l.491 1.32 1.158.543 1.397-.622.412.412-.585 1.28.434 1.204 1.427.548z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19 16h-1V6h4v9h-1V7h-2zm-9 5H6V11h4zm-1-9H7v8h2zm4 8V3h2v15.251a1.764 1.764 0 0 1 .264-.364l.736-.742V2h-4v19h3.398l-.45-1zM3 23V2H2v22h12v-1zm27.992-.14L31 25.082l-2.13.789-.377.825.965 2.149-1.565 1.576-2.066-.949-.849.318-.838 2.202-2.222.008-.79-2.13-.824-.377-2.149.965-1.576-1.566.949-2.066-.318-.848-2.202-.838L15 22.92l2.13-.79.377-.825-.965-2.15 1.566-1.575 2.066.949.848-.318.838-2.202L24.08 16l.79 2.13.825.377 2.15-.965 1.576 1.565-.95 2.066.319.849zM30 24.417l-.004-.897-1.995-.76-.588-1.606.831-1.809-.636-.632-1.945.873-1.555-.72L23.417 17l-.897.004-.758 1.994-1.608.59-1.81-.832-.63.636.873 1.945-.72 1.555-1.867.692.004.896 1.995.76.588 1.606-.83 1.81.635.63 1.945-.873 1.555.722.69 1.864.898-.003.758-1.994 1.608-.59 1.81.832.63-.636-.874-1.948.722-1.551zM26 24a3 3 0 1 1-3-3 3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2 2 0 0 0 2-2z"
  }));
};

var _default = ChartGearIcon;
exports["default"] = _default;