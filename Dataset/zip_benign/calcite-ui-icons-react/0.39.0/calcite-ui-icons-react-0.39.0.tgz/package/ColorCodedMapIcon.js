"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ColorCodedMapIcon = function ColorCodedMapIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 1v14h14V1zm13 10.555l-3.467-.858L7.887 2H14zM2 2h4.842L8.75 8.273 2 9.935zm0 12v-3.065a1.021 1.021 0 0 0 .24-.03l6.802-1.674.7 2.3L14 12.585V14z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 14v-3.065a1.021 1.021 0 0 0 .24-.03l6.802-1.674.7 2.3L14 12.585V14z",
      opacity: ".2"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 11.555l-3.467-.858L7.887 2H14v9.555z",
      opacity: ".5"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2v20h20V2zm19 17.194l-5.604-1.6L10.837 3H21zM3 3h6.789l2.457 7.864L3 12.845zm0 18v-7.154a1.03 1.03 0 0 0 .21-.022l9.336-2.001 2.058 6.583L21 20.234V21z"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21 19.194l-5.604-1.6L10.837 3H21v16.194z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 21v-7.154a1.03 1.03 0 0 0 .21-.022l9.336-2.001 2.058 6.583L21 20.234V21z",
      opacity: ".2"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 3v26h26V3zm1 1h9.747l2.726 10.092L4 17.086zm24 24H4v-9.914a.997.997 0 0 0 .233-.028l12.546-3.011 2.267 7.251a.997.997 0 0 0 .68.663l8 2.286a.993.993 0 0 0 .274.039zm0-3.715L20 22l-2.545-8.143L14.783 4H28z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28 28H4v-9.914a.997.997 0 0 0 .233-.028l12.546-3.011 2.267 7.251a.997.997 0 0 0 .68.663l8 2.286a.993.993 0 0 0 .274.039z",
    opacity: ".2"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28 24.285L20 22l-2.545-8.143L14.783 4H28v20.285z",
    opacity: ".5"
  }));
};

var _default = ColorCodedMapIcon;
exports["default"] = _default;