"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListNumberIcon = function ListNumberIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 14h9v1H6zm9-12H6v1h9zM6 9h9V8H6zM4 3H3V0H1v1h1v2H1v1h3zm0 9a1 1 0 0 0-1-1H2c-.553 0-1 0-1 1h2v1h-.5a.5.5 0 0 0 0 1H3v1H1c0 1 .447 1 1 1h1a1 1 0 0 0 1-1v-1a.975.975 0 0 0-.153-.5A.964.964 0 0 0 4 13zM3 8a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1h2v1H2a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h2V9H2V8z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 5H8V4h14zm0 15H8v1h14zm0-8H8v1h14zM5 19a1 1 0 0 0-1-1H3c-.553 0-1 0-1 1h2v1h-.5a.5.5 0 0 0 0 1H4v1H2c0 1 .447 1 1 1h1a1 1 0 0 0 1-1v-1a.975.975 0 0 0-.153-.5A.964.964 0 0 0 5 20zM5 6H4V2H2v1h1v3H2v1h3zm-1 7a1 1 0 0 0 1-1v-1a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1h2v1H3a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1h2v-1H3v-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6 29v-2H4.5a.5.5 0 0 1 0-1H6v-2H3c0-1 .447-1 1-1h2a1 1 0 0 1 1 1v2a.964.964 0 0 1-.153.5A.975.975 0 0 1 7 27v2a1 1 0 0 1-1 1H4c-.553 0-1 0-1-1zM8 8H6V3H3v1h2v4H3v1h5zM4 20h3v-1H4v-2h2a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1h3v2H4a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1zM29 6H11v1h18zm0 10H11v1h18zm0 10H11v1h18z"
  }));
};

var _default = ListNumberIcon;
exports["default"] = _default;