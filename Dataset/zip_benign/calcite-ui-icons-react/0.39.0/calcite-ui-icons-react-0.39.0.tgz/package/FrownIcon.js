"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FrownIcon = function FrownIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 .2A7.8 7.8 0 1 0 15.8 8 7.8 7.8 0 0 0 8 .2zm0 14.6A6.8 6.8 0 1 1 14.8 8 6.808 6.808 0 0 1 8 14.8zm2.07-7.126a1.08 1.08 0 0 1-.32-.315 1.422 1.422 0 0 1-.189-.41 1.677 1.677 0 0 1 0-.897 1.422 1.422 0 0 1 .188-.41 1.08 1.08 0 0 1 .321-.316.797.797 0 0 1 .86 0 1.08 1.08 0 0 1 .32.315 1.422 1.422 0 0 1 .189.41 1.677 1.677 0 0 1 0 .897 1.422 1.422 0 0 1-.188.41 1.08 1.08 0 0 1-.321.316.797.797 0 0 1-.86 0zM5.5 7.8a.81.81 0 0 1-.43-.126 1.08 1.08 0 0 1-.32-.315 1.422 1.422 0 0 1-.189-.41 1.677 1.677 0 0 1 0-.897 1.422 1.422 0 0 1 .188-.41 1.08 1.08 0 0 1 .321-.316.797.797 0 0 1 .86 0 1.08 1.08 0 0 1 .32.315 1.422 1.422 0 0 1 .189.41 1.677 1.677 0 0 1 0 .897 1.422 1.422 0 0 1-.188.41 1.08 1.08 0 0 1-.321.316.81.81 0 0 1-.43.126zm-.532 4.407l-.727-.688a5.143 5.143 0 0 1 3.756-1.42 5.223 5.223 0 0 1 3.762 1.42l-.727.688a4.216 4.216 0 0 0-3.035-1.108 4.209 4.209 0 0 0-3.03 1.108z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 1.2A10.8 10.8 0 1 0 22.8 12 10.8 10.8 0 0 0 12 1.2zm0 20.6a9.8 9.8 0 1 1 9.8-9.8 9.811 9.811 0 0 1-9.8 9.8zm4.73-3.982a6.581 6.581 0 0 0-4.735-1.74 6.565 6.565 0 0 0-4.725 1.74l-.727-.687a7.468 7.468 0 0 1 5.452-2.053 7.59 7.59 0 0 1 5.462 2.053zM15.5 11a1.074 1.074 0 0 1-.518-.135 1.293 1.293 0 0 1-.405-.353 1.575 1.575 0 0 1-.246-.479 1.79 1.79 0 0 1 0-1.066 1.575 1.575 0 0 1 .246-.479 1.293 1.293 0 0 1 .405-.353 1.065 1.065 0 0 1 1.036 0 1.293 1.293 0 0 1 .405.353 1.575 1.575 0 0 1 .246.48 1.79 1.79 0 0 1 0 1.065 1.575 1.575 0 0 1-.246.479 1.293 1.293 0 0 1-.405.353A1.074 1.074 0 0 1 15.5 11zm-7 0a1.074 1.074 0 0 1-.518-.135 1.293 1.293 0 0 1-.405-.353 1.575 1.575 0 0 1-.246-.479 1.79 1.79 0 0 1 0-1.066 1.575 1.575 0 0 1 .246-.479 1.293 1.293 0 0 1 .405-.353 1.065 1.065 0 0 1 1.036 0 1.293 1.293 0 0 1 .405.353 1.575 1.575 0 0 1 .246.48 1.79 1.79 0 0 1 0 1.065 1.575 1.575 0 0 1-.246.479 1.293 1.293 0 0 1-.405.353A1.074 1.074 0 0 1 8.5 11z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 29.8A13.8 13.8 0 1 1 29.8 16 13.815 13.815 0 0 1 16 29.8zm0-26.6A12.8 12.8 0 1 0 28.8 16 12.815 12.815 0 0 0 16 3.2zm6.318 20.026l.692-.723c-3.604-3.451-10.418-3.452-14.02 0l.692.723c3.19-3.057 9.448-3.055 12.636 0zM11.5 13.8a1.2 1.2 0 0 0 .608-.168 1.52 1.52 0 0 0 .464-.43 1.927 1.927 0 0 0 .278-.572 2.234 2.234 0 0 0 0-1.26 1.927 1.927 0 0 0-.278-.571 1.52 1.52 0 0 0-.464-.431 1.185 1.185 0 0 0-1.216 0 1.52 1.52 0 0 0-.464.43 1.927 1.927 0 0 0-.277.572 2.234 2.234 0 0 0 0 1.26 1.927 1.927 0 0 0 .277.571 1.52 1.52 0 0 0 .464.431 1.2 1.2 0 0 0 .608.168zm9.608-.168a1.52 1.52 0 0 0 .464-.43 1.927 1.927 0 0 0 .278-.572 2.234 2.234 0 0 0 0-1.26 1.927 1.927 0 0 0-.278-.571 1.52 1.52 0 0 0-.464-.431 1.185 1.185 0 0 0-1.216 0 1.52 1.52 0 0 0-.464.43 1.927 1.927 0 0 0-.277.572 2.234 2.234 0 0 0 0 1.26 1.927 1.927 0 0 0 .277.571 1.52 1.52 0 0 0 .464.431 1.185 1.185 0 0 0 1.216 0z"
  }));
};

var _default = FrownIcon;
exports["default"] = _default;