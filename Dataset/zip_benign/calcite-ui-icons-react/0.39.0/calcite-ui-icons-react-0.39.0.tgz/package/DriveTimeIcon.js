"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DriveTimeIcon = function DriveTimeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 3h-3.536L10.31 1H6.845l-2.31 2H2.227L.01 9l2.216.167L3 10.333V15l3.845-2h4.62l3.464-4-3.345-2.556zm-1.523 6.15L11.007 12H6.602L4 13.353V10.03L2.79 8.206 1.4 8.103 2.921 4h1.987l2.31-2h2.513l1.155 2H12.6l-2.528 2.548zM8.56 6.65l3.463 2.647L10.55 11H6.357L5 11.706V9.729L3.352 7.245l-.552-.04L3.617 5h1.665l2.31-2h1.563l1.114 1.93z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.605 9.778L22.285 5h-5.229l-1.65-3h-4.949L7.158 5h-3.12l-3.18 8.429 3.18.238L5 15.333V22l5.636-3h6.949l4.799-5.571zM17.126 18h-6.74L6 20.335v-5.27l-1.36-2.356-2.376-.178L4.73 6h2.816l3.3-3h3.97l1.65 3h3.441L16.1 9.886l4.834 3.693zm.67-4.148L15.886 16H9.87L8 16.943v-2.515l-2.275-3.643-.646-.049L6.112 8h2.207l3.298-3h2.015l1.527 2.778-2.328 2.28z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.4 7h-7.471l-2.31-4H13.69L9.071 7H5.53L1.6 18l3.93.717L7 20.933V29.8l7.306-3.8h8.476l7.182-7.6-6.055-4.856zm-1.908 11.502L22.352 25h-8.29L8 28.152v-7.52L6.127 17.81l-3.19-.582L6.235 8h3.21l4.62-4h5.978l2.31 4H28l-5.583 5.629zm-9.06-4.704l6.117 4.907L21.489 23h-7.917L10 24.858v-4.83l-2.677-4.034-1.71-.311L7.645 10h2.544l4.62-4h4.078l3.047 5.276z"
  }));
};

var _default = DriveTimeIcon;
exports["default"] = _default;