"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ListButtonIcon = function ListButtonIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 4a1.001 1.001 0 0 0 1 1h12a1.001 1.001 0 0 0 1-1V2a1.001 1.001 0 0 0-1-1H2a1.001 1.001 0 0 0-1 1zm1-2h12v2H2zM1 9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1zm0 6a1.001 1.001 0 0 0 1 1h12a1.001 1.001 0 0 0 1-1v-2a1.001 1.001 0 0 0-1-1H2a1.001 1.001 0 0 0-1 1zm1-2h12v2H2zm9-4H5V8h6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 20h8v1H8zm14 0v1a2.002 2.002 0 0 1-2 2H4a2.002 2.002 0 0 1-2-2v-1a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2zm-1 0a1.001 1.001 0 0 0-1-1H4a1.001 1.001 0 0 0-1 1v1a1.001 1.001 0 0 0 1 1h16a1.001 1.001 0 0 0 1-1zm1-16v1a2.002 2.002 0 0 1-2 2H4a2.002 2.002 0 0 1-2-2V4a2.002 2.002 0 0 1 2-2h16a2.002 2.002 0 0 1 2 2zm-1 0a1.001 1.001 0 0 0-1-1H4a1.001 1.001 0 0 0-1 1v1a1.001 1.001 0 0 0 1 1h16a1.001 1.001 0 0 0 1-1zM8 5h8V4H8zm14 7v1a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2zm-6 0H8v1h8z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 6h10v1H11zm0 21h10v-1H11zM26.731 3A2.271 2.271 0 0 1 29 5.269V7.73A2.271 2.271 0 0 1 26.731 10H5.27A2.271 2.271 0 0 1 3 7.731V5.269A2.271 2.271 0 0 1 5.269 3zM28 5.269A1.27 1.27 0 0 0 26.731 4H5.27A1.27 1.27 0 0 0 4 5.269V7.73A1.27 1.27 0 0 0 5.269 9H26.73A1.27 1.27 0 0 0 28 7.731zm1 20v2.462A2.271 2.271 0 0 1 26.731 30H5.27A2.271 2.271 0 0 1 3 27.731v-2.462A2.271 2.271 0 0 1 5.269 23H26.73A2.271 2.271 0 0 1 29 25.269zm-1 0A1.27 1.27 0 0 0 26.731 24H5.27A1.27 1.27 0 0 0 4 25.269v2.462A1.27 1.27 0 0 0 5.269 29H26.73A1.27 1.27 0 0 0 28 27.731zM26.731 13A2.271 2.271 0 0 1 29 15.269v2.462A2.271 2.271 0 0 1 26.731 20H5.27A2.271 2.271 0 0 1 3 17.731v-2.462A2.271 2.271 0 0 1 5.269 13zM11 16v1h10v-1z"
  }));
};

var _default = ListButtonIcon;
exports["default"] = _default;