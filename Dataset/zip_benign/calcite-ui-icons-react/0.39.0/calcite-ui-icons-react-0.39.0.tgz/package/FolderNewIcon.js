"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FolderNewIcon = function FolderNewIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 8h1v6H1V3h1.7L4 2h2.981L8 2.774V4h-.037L6.644 3H4.34l-1.3 1H2v2h6v1H2v6h12zm-3.4-5.694L10.292 2l-.621-.621.707-.71.928.93a2.23 2.23 0 0 1 .692-.289V0h1v1.31a2.23 2.23 0 0 1 .694.289l.928-.93.707.708-.622.623-.305.305a2.23 2.23 0 0 1 .29.695H16v1h-1.31a2.231 2.231 0 0 1-.289.693l.928.928-.708.707-.927-.927a2.228 2.228 0 0 1-.695.29V7h-1V5.69a2.233 2.233 0 0 1-.693-.29l-.927.928-.707-.707.927-.927A2.231 2.231 0 0 1 10.31 4H9V3h1.31a2.23 2.23 0 0 1 .29-.694zM12.5 2A1.5 1.5 0 1 0 14 3.5 1.5 1.5 0 0 0 12.5 2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 3h7l1.2 2h.8v1h-1.366l-1.2-2H4.566l-1.2 2H2v2h11v1H2v11h20v-9h1v10H1V5h1.8zm12.05 2a2.483 2.483 0 0 1 .366-.877l-1.452-1.451.708-.708 1.45 1.452A2.483 2.483 0 0 1 18 3.05V1h1v2.05a2.483 2.483 0 0 1 .877.366l1.451-1.452.708.708-1.452 1.45A2.483 2.483 0 0 1 20.95 5H23v1h-2.05a2.483 2.483 0 0 1-.366.877l1.452 1.451-.708.708-1.45-1.452A2.482 2.482 0 0 1 19 7.95V10h-1V7.95a2.482 2.482 0 0 1-.877-.366l-1.451 1.452-.708-.708 1.452-1.45A2.483 2.483 0 0 1 16.05 6H14V5zm2.45-1A1.5 1.5 0 1 0 20 5.5 1.502 1.502 0 0 0 18.5 4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 14h1v13H2V7h2l1-2h10l1 2h2v1h-2.618l-1-2H5.618l-1 2H3v3h15v1H3v14h26zm-7.294-8.587l-1.449-1.449.707-.707 1.449 1.448A3.463 3.463 0 0 1 24 4.05V2h1v2.05a3.463 3.463 0 0 1 1.587.655l1.449-1.448.707.707-1.449 1.449A3.463 3.463 0 0 1 27.95 7H30v1h-2.05a3.463 3.463 0 0 1-.656 1.587l1.449 1.449-.707.707-1.449-1.449A3.463 3.463 0 0 1 25 10.95V13h-1v-2.05a3.463 3.463 0 0 1-1.587-.656l-1.449 1.449-.707-.707 1.449-1.449A3.463 3.463 0 0 1 21.05 8H19V7h2.05a3.463 3.463 0 0 1 .656-1.587zM24.5 5A2.5 2.5 0 1 0 27 7.5 2.5 2.5 0 0 0 24.5 5z"
  }));
};

var _default = FolderNewIcon;
exports["default"] = _default;