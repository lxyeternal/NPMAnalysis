"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FilePdfPlusIcon = function FilePdfPlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.4 0H1v16h9v-1H2V1h7v4h4v2h1V3.6zM10 4V1h.31L13 3.69V4zm-3.814 6.65a51.34 51.34 0 0 0 .69-1.9c.345.42.652.844 1.02 1.25H9v-.106c-.054.012-.105.02-.16.034a21.272 21.272 0 0 1-1.626-1.914 9.45 9.45 0 0 0 .555-2.972 1.299 1.299 0 0 0-.827-1.075 1.16 1.16 0 0 0-.39-.067 1.278 1.278 0 0 0-.851.333c-.684.613-.645 1.93.1 3.354a2.093 2.093 0 0 0 .343.502l-.66 2.435a3.07 3.07 0 0 0-.689.361c-1.314.753-2.103 1.463-1.68 2.477a.994.994 0 0 0 .764.62 1.134 1.134 0 0 0 .2.018 1.858 1.858 0 0 0 1.31-.65 6.728 6.728 0 0 0 1.022-1.945L7 11.27v-.85c-.27.074-.537.15-.814.23zm-1.379 2.079a1.442 1.442 0 0 1-.888.522.116.116 0 0 1-.12-.063c-.086-.207-.263-.636 1.817-1.837a4.69 4.69 0 0 1-.809 1.378zm1.147-7.456a.666.666 0 0 1 .256-.443.7.7 0 0 1 .372-.113.56.56 0 0 1 .136.016.476.476 0 0 1 .34.39A5.116 5.116 0 0 1 6.56 7.23a2.73 2.73 0 0 1-.607-1.958zM13 9v3h3v1h-3v3h-1v-3H9v-1h3V9z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 22V2h10v6h6v5h1V6.709L15.29 1H3v22h14v-1zM15 2h.2L20 6.8V7h-5zm2 14.936v-.929a4.264 4.264 0 0 1-1.475-1.057l.178-.032a7.814 7.814 0 0 1 1.292-.168H17v-.928a12.751 12.751 0 0 0-2.312.331 24.235 24.235 0 0 1-2.344-2.728 11.894 11.894 0 0 0 .697-4.028 1.432 1.432 0 0 0-.928-1.237 1.37 1.37 0 0 0-.461-.08 1.524 1.524 0 0 0-1.014.398c-.836.75-.752 2.316.226 4.187.042.081.084.175.13.276a1.939 1.939 0 0 0 .323.56c-.334 1.047-.803 2.183-1.216 3.185l-.252.694a9.195 9.195 0 0 0-1.36.607c-1.673.959-2.683 1.849-2.17 3.08a1.147 1.147 0 0 0 .88.716 1.315 1.315 0 0 0 .23.02 2.343 2.343 0 0 0 1.623-.813 10.846 10.846 0 0 0 1.467-2.83c1.074-.37 2.484-.74 3.784-1.04A8.168 8.168 0 0 0 17 16.937zm-7.56-.462c-.395.94-1.057 2.513-1.842 2.513a.655.655 0 0 1-.154-.018.624.624 0 0 1-.372-.58c.001-.285.195-1.033 1.972-1.815.096-.042.202-.094.314-.15l.13-.063zm1.84-9.28a.557.557 0 0 1 .367-.153.418.418 0 0 1 .144.024.627.627 0 0 1 .355.54 8.16 8.16 0 0 1-.47 2.71l-.01-.02c-.797-1.525-.794-2.736-.387-3.102zm-.424 8.02l1.17-2.792a69.42 69.42 0 0 0 1.709 1.937c-.947.21-2.358.678-2.88.854zM24 19v.999h-4V24h-1v-4.001h-4V19h4v-4h1v4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6 29V3h12v8h8v8h1V9.699L19.3 2H5v28h19v-1zM19 3l7 7h-7zm1.52 16.855l-.174-.003a12.714 12.714 0 0 0-2.571.352 25.241 25.241 0 0 1-2.442-2.842 12.386 12.386 0 0 0 .726-4.195 1.49 1.49 0 0 0-.966-1.288 1.425 1.425 0 0 0-.48-.082 1.587 1.587 0 0 0-1.055.414c-.872.781-.784 2.411.234 4.36.044.084.088.182.135.287a2.02 2.02 0 0 0 .338.584c-.349 1.09-.837 2.273-1.267 3.316l-.262.723a9.577 9.577 0 0 0-1.417.632c-1.742.998-2.794 1.926-2.26 3.208a1.194 1.194 0 0 0 .917.745 1.376 1.376 0 0 0 .24.02 2.44 2.44 0 0 0 1.69-.846 11.293 11.293 0 0 0 1.527-2.947c1.119-.386 2.587-.771 3.94-1.082a7.838 7.838 0 0 0 2.996 1.946 2.233 2.233 0 0 0 .443.047 1.403 1.403 0 0 0 1.133-.509 1.72 1.72 0 0 0 .142-1.774 1.778 1.778 0 0 0-1.567-1.066zm-8.21 2.765c-.412.98-1.101 2.618-1.919 2.618a.682.682 0 0 1-.16-.02.65.65 0 0 1-.388-.603c.002-.297.204-1.076 2.054-1.89.1-.045.21-.099.327-.156l.135-.066zm1.915-9.664a.58.58 0 0 1 .383-.16.435.435 0 0 1 .15.026.653.653 0 0 1 .37.563 8.5 8.5 0 0 1-.49 2.822l-.011-.022c-.83-1.587-.826-2.849-.402-3.23zm-.441 8.351l1.218-2.907c.56.672 1.46 1.666 1.78 2.017-.986.22-2.456.707-2.998.89zm7.387.7a.575.575 0 0 1-.505.229 3.333 3.333 0 0 1-2.02-1.203l.186-.033a8.138 8.138 0 0 1 1.345-.175.93.93 0 0 1 1 .544.673.673 0 0 1-.006.637zM27 26h5v.999h-5V32h-1v-5.001h-5V26h5v-5h1z"
  }));
};

var _default = FilePdfPlusIcon;
exports["default"] = _default;