"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayersReferenceIcon = function LayersReferenceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.5 7.104l2.523 1.42-8 4.5-8-4.5L2.68 7.03a4.62 4.62 0 0 0 .369.94l-.985.553 5.96 3.353 5.96-3.353-.61-.343a1.983 1.983 0 0 0 .127-.68zm-5.477 7.772l-6.98-3.926-1.02.573 7.915 4.452a.175.175 0 0 0 .171 0l7.914-4.452-1.02-.573zM8 5V4H6v1zM4 7.333V1.5A1.502 1.502 0 0 1 5.5 0H12v8h-2v1H5.667A1.67 1.67 0 0 1 4 7.333zM5 1.5a.501.501 0 0 0 .5.5H10v5h1V1H5.5a.501.501 0 0 0-.5.5zm0 1.414v4.419A.667.667 0 0 0 5.667 8H9V3H5.498A1.478 1.478 0 0 1 5 2.914z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.09 15.367L23 16.495 12 23 1 16.493l1.91-1.128.983.582-.927.547L12 21.838l9.033-5.342-.927-.547zM19.5 11.5c0 .03-.007.056-.009.085l1.543.911-4.198 2.483a1.988 1.988 0 0 1-.68.402L12 17.838l-9.035-5.344L5.5 10.998V9.837L1 12.493 12 19l11-6.505-3.5-2.067zM14 7V6H9v1zm-4 1v1h3V8zM7 2.5C7 1.66 7.952 1 9.167 1H18v11h-2v2H9.5A2.502 2.502 0 0 1 7 11.5zm1 0c0 .177.443.5 1.167.5H16v8h1V2H9.167C8.443 2 8 2.323 8 2.5zm0 9A1.502 1.502 0 0 0 9.5 13H15V4H9.167A2.943 2.943 0 0 1 8 3.77z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M25.5 13.564l5 2.928L16 25 1.5 16.492l6-3.514v1.16l-4.022 2.355L16 23.841l5.734-3.365a1.99 1.99 0 0 0 1.389-.814l5.4-3.169-3.023-1.77zm1.23 6.88l1.792 1.05L16 28.84 3.478 21.493l1.792-1.05-.989-.58-2.781 1.63L16 30l14.5-8.508-2.781-1.629zM18 10V9h-5v1zm-4 2h3v-1h-3zM9 3.5c0-.84.952-1.5 2.167-1.5H24v15h-2v2H11.5A2.502 2.502 0 0 1 9 16.5zm1 0c0 .177.443.5 1.167.5H22v12h1V3H11.167C10.443 3 10 3.323 10 3.5zm0 13a1.502 1.502 0 0 0 1.5 1.5H21V5h-9.833A2.943 2.943 0 0 1 10 4.77z"
  }));
};

var _default = LayersReferenceIcon;
exports["default"] = _default;