"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FogIcon = function FogIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.5 13h9a3.496 3.496 0 0 0 1.43-6.688 3.989 3.989 0 0 0-7.815-.227 2.462 2.462 0 0 0-3.07 1.96A2.498 2.498 0 0 0 3.5 13zm2-6a1.49 1.49 0 0 1 .368.054l.987.252.233-.992a2.989 2.989 0 0 1 5.857.17l.092.522.484.218A2.496 2.496 0 0 1 12.5 12h-9a1.498 1.498 0 0 1-.273-2.97l.678-.126.124-.677A1.496 1.496 0 0 1 5.5 7zm4.5 4H5v-1h5zm-1 3h6v1H9zm-9 1h4v1H0zm5 0h2v1H5zm7-4h-1v-1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19.95 8.719A5.494 5.494 0 0 0 9.4 9.24a3.369 3.369 0 0 0-3.951 1.886l-.011-.001a3.438 3.438 0 0 0 0 6.875h12.75a4.807 4.807 0 0 0 1.761-9.281zM18.187 17H5.438a2.438 2.438 0 0 1-.066-4.874h.716l.268-.58a2.443 2.443 0 0 1 2.207-1.421 2.41 2.41 0 0 1 .593.085l.986.248.232-.99a4.494 4.494 0 0 1 8.63-.425l.149.436.43.17A3.807 3.807 0 0 1 18.187 17zM7 15h7v1H7zm4 5h10v1H11zm-9 2h6v1H2zm8 0h3v1h-3zm5-7h2v1h-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M23.5 25a6.496 6.496 0 0 0 2.193-12.613 7.497 7.497 0 0 0-14.552.678A4.46 4.46 0 0 0 10.5 13a4.487 4.487 0 0 0-4.228 3.012 4.5 4.5 0 0 0-4.208 5.26A4.614 4.614 0 0 0 6.672 25zM3.77 18.313a3.507 3.507 0 0 1 2.552-1.303l.67-.033.223-.633A3.498 3.498 0 0 1 10.5 14a3.172 3.172 0 0 1 .432.045l1.01.145.18-.935a6.497 6.497 0 0 1 12.612-.586l.143.488.478.172A5.496 5.496 0 0 1 23.5 24H6.672a3.621 3.621 0 0 1-3.621-2.892 3.485 3.485 0 0 1 .719-2.795zM17 22H8v-1h9zm4 0h-3v-1h3zm-5 5h14v1H16zm-2 3h4v1h-4zM4 30h7v1H4z"
  }));
};

var _default = FogIcon;
exports["default"] = _default;