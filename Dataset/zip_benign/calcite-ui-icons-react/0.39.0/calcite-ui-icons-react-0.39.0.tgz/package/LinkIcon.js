"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LinkIcon = function LinkIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5 9.5a4.505 4.505 0 0 0 .048.493c-.007-.007-.016-.011-.023-.018l-3-3a3.5 3.5 0 1 1 4.95-4.95l3 3a3.486 3.486 0 0 1-1.31 5.76l-.226-.225a1.484 1.484 0 0 1-.37-.631 2.495 2.495 0 0 0 1.199-4.197l-3-3a2.5 2.5 0 1 0-3.536 3.536L5.09 8.625A4.498 4.498 0 0 0 5 9.5zm11 3a3.475 3.475 0 0 0-1.025-2.475l-3-3c-.007-.007-.016-.011-.023-.018A4.505 4.505 0 0 1 12 7.5a4.498 4.498 0 0 1-.089.876l2.357 2.356a2.5 2.5 0 0 1-.009 3.544 2.561 2.561 0 0 1-3.527-.008l-3-3a2.5 2.5 0 0 1-.094-3.436 2.43 2.43 0 0 1 1.3-.74 1.485 1.485 0 0 0-.377-.652l-.222-.222a3.482 3.482 0 0 0-1.314 5.757l3 3a3.5 3.5 0 0 0 4.937.012l-.351-.355.352.355A3.476 3.476 0 0 0 16 12.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 14c0 .025.003.05.004.075l-3.54-3.54a5 5 0 0 1 7.072-7.07l4 4a4.992 4.992 0 0 1-1.713 8.187l-.237-.237a1.998 1.998 0 0 1-.413-.609 3.985 3.985 0 0 0 1.656-6.635l-4-4a4 4 0 0 0-5.369-.26l-.318-.387.318.386a4 4 0 0 0-.29 5.92l2.94 2.94A7.012 7.012 0 0 0 7 14zm16 4a4.97 4.97 0 0 0-1.464-3.536l-3.54-3.539c0 .025.004.05.004.075a7.087 7.087 0 0 1-.113 1.23l2.942 2.941a4 4 0 0 1-.128 5.78l.338.368-.338-.368a4 4 0 0 1-5.53-.122l-4-4a3.966 3.966 0 0 1 1.658-6.631 1.998 1.998 0 0 0-.415-.613l-.234-.234a5.004 5.004 0 0 0-1.907 1.315 5 5 0 0 0 .191 6.87l4 4A5 5 0 0 0 23 18z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.766 13.875c.063.058.128.11.189.17l5 5a6.3 6.3 0 0 1-8.91 8.91l-5-5a6.286 6.286 0 0 1 2.969-10.568 3.279 3.279 0 0 1 .553.905 5.288 5.288 0 0 0-2.815 8.956l5 5a5.3 5.3 0 0 0 7.496-7.496l-4.488-4.488a8.366 8.366 0 0 0 .006-1.389zm-12.526 3.86l-4.488-4.487a5.3 5.3 0 0 1 7.496-7.496l5 5a5.288 5.288 0 0 1-2.815 8.956 3.278 3.278 0 0 0 .553.905 6.287 6.287 0 0 0 2.969-10.568l-5-5a6.3 6.3 0 0 0-8.91 8.91l5 5c.061.06.126.112.189.17a8.367 8.367 0 0 1 .006-1.39z"
  }));
};

var _default = LinkIcon;
exports["default"] = _default;