"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GridTriangleIcon = function GridTriangleIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 1v14h14V1zm7.5 1.508L11.64 8H5.362zM2 5.134L3.638 8H2zM2 9h1.638L2 11.866zm9.638 0L8.78 14h-.562L5.362 9zM14 10.116L13.362 9H14zM14 8h-.638L14 6.884zm0-6v2.866l-1.5 2.626L9.362 2zM7.638 2L4.5 7.491 2 3.116V2zM2 13.884l2.5-4.375L7.067 14H2zM9.933 14L12.5 9.509l1.5 2.625V14z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2v20h20V2zm18.902 19l-2.5-4H21v4zm-10.45-8.278L12.5 9.444 16.598 16H8.402zM13.401 9H21v.957l-3.5 5.6zm0-1l3.125-5h1.946L21 7.043V8zm-.902-.444L9.652 3h5.696zM11.598 8H3.402l3.125-5h1.946zm0 1L7.5 15.556 3.402 9zm-3.196 8h8.196l-2.5 4h-3.196zm1.321 4H5.277L7.5 17.443zm7.777-3.557L19.723 21h-4.446zM18.402 16L21 11.843V16zM21 5.157L19.652 3H21zM5.348 3L3 6.757V3zm1.25 13H3v-5.756zM3 17h3.598l-2.5 4H3z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 3v26h26V3zm1 8.35L9.63 21H4zm24-6.858V9h-9.63l2.917-5h6.426zM13.565 15.254L10.5 20.508 4.37 10h12.26zm.87.492l3.065-5.254L23.63 21H11.37zm7-.492L18.37 10H28v4.508l-3.5 6zM17.5 8.508L14.87 4h5.26zM16.63 9H4.37l2.917-5h6.426zm-5.26 13h12.26l-3.5 6h-5.26zm2.343 6H7.287l3.213-5.508zM24.5 22.492L27.713 28h-6.426zm.87-.492H28v4.508zM28 21h-2.63L28 16.492zM6.13 4L4 7.651V4zM4 22h5.63l-3.5 6H4z"
  }));
};

var _default = GridTriangleIcon;
exports["default"] = _default;