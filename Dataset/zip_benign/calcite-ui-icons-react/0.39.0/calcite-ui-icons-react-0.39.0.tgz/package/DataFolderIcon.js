"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DataFolderIcon = function DataFolderIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 12.963c-.17.004-.32.016-.5.016-3.84 0-5.5-.993-5.5-1.5V7.906a7.983 7.983 0 0 0 2.971.911 19.322 19.322 0 0 0 4.469.067l.165-.331A1 1 0 0 1 10.5 8h2a.997.997 0 0 1 .255.036c.082-.043.17-.084.245-.13v.232a.995.995 0 0 1 .395.415l.223.447H14V3.48C14 1.983 11.388 1 7.5 1S1 1.984 1 3.48v8c0 1.495 2.612 2.5 6.5 2.5.17 0 .335-.005.5-.009zM7.5 1.98c3.84 0 5.5.994 5.5 1.5S11.34 5 7.5 5 2 3.986 2 3.48s1.66-1.5 5.5-1.5zM2 4.906a7.983 7.983 0 0 0 2.971.911A19.796 19.796 0 0 0 10 5.821a8.024 8.024 0 0 0 3-.915V6.48c0 .507-1.66 1.5-5.5 1.5S2 6.986 2 6.48zM13 10l-.5-1h-2l-.5 1H9v6h7v-6zm2 5h-5v-2h5zm0-3h-5v-1h.618l.5-1h.764l.5 1H15z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 19.913c-4.966-.084-8-1.388-8-2.334v-6.248C4.643 12.429 8.082 13 11.5 13s6.857-.57 8.5-1.67V14h1V5c0-1.97-4.78-3-9.5-3S2 3.03 2 5v12.58c0 2.116 4.448 3.255 9 3.333zM11.5 3C17 3 20 4.321 20 5s-3 2-8.5 2S3 5.679 3 5s3-2 8.5-2zM3 6.411C4.643 7.457 8.082 8 11.5 8s6.857-.543 8.5-1.589v3.437C20 10.726 16.689 12 11.5 12S3 10.726 3 9.848zM18 15l-1-1h-3l-1 1h-1v8h11v-8zm4 7h-9v-4h9zm-9-5v-1h.414l1-1h2.172l1 1H22v1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15 26.821c-6.505-.085-11-1.791-11-3.332v-7.986c2.034 1.58 6.873 2.42 11.5 2.42.676 0 1.356-.02 2.031-.055l.86-.661A1.004 1.004 0 0 1 19 17h2.981a.996.996 0 0 1 .605.204l.024.018a11.436 11.436 0 0 0 4.39-1.72V18h1V7.096h-.015C27.987 7.063 28 7.033 28 7c0-2.56-6.288-3.9-12.5-3.9S3 4.44 3 7c0 .033.013.063.015.096H3v16.393c0 2.741 6.091 4.251 12 4.332zM15.5 4.1C22.625 4.1 27 5.79 27 7s-4.375 2.9-11.5 2.9S4 8.21 4 7s4.375-2.9 11.5-2.9zM4 8.624c2.011 1.499 6.774 2.276 11.5 2.276s9.489-.777 11.5-2.276v5.201c0 1.294-4.375 3.099-11.5 3.099S4 15.119 4 13.825zm19.3 10.378L21.98 18H19l-1.3 1H16v11h14V19zM29 29H17v-6h12zm0-7H17v-2h1.04l1.3-1h2.304l1.319 1H29z"
  }));
};

var _default = DataFolderIcon;
exports["default"] = _default;