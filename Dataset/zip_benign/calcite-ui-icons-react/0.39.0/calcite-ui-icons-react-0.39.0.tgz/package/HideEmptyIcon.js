"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HideEmptyIcon = function HideEmptyIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 5h14v1h1V1H0v14h5v-1H1zm0-3h14v2H1zm13.665 5.665L13.28 9.052a5.642 5.642 0 0 0-2.779-.806c-2.981 0-5.251 2.888-5.346 3.011l-.214.276.214.276a9.445 9.445 0 0 0 2.957 2.41l-1.047 1.047.707.707 7.601-7.6zm-2.992 2.992a1.528 1.528 0 0 0-1.165-.532 1.458 1.458 0 0 0-1.5 1.408 1.383 1.383 0 0 0 .64 1.15l-.928.927a8.744 8.744 0 0 1-2.779-2.077C6.586 10.82 8.4 9.045 10.5 9.045a4.743 4.743 0 0 1 2.19.595zm4.327.776v.2l-.138.177c-.096.123-2.381 3.01-5.362 3.01-.033 0-.064-.005-.097-.006l.87-.87a7.7 7.7 0 0 0 3.802-2.41c-.163-.18-.4-.426-.698-.694l.562-.562a9.041 9.041 0 0 1 .923.978z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.417 20H2V8h20v5.509c.371.294.704.587 1 .866V3H1v18h7.162c.034-.057.065-.114.102-.171A23.96 23.96 0 0 1 7.417 20zM2 4h20v3H2zm12.893 15.844l2.85-2.85a2.392 2.392 0 0 1-2.85 2.85zM23.03 17.5l-.234.305c-.132.171-3.273 4.195-7.338 4.195a6.92 6.92 0 0 1-2.303-.418l.715-.715a5.834 5.834 0 0 0 1.59.233c3.055 0 5.657-2.67 6.47-3.6a13.557 13.557 0 0 0-2.486-2.206l.643-.644a13.56 13.56 0 0 1 2.709 2.545zm-11.273 3.45h.003l.663-.662-.003-.002 1.196-1.195.002.002 3.375-3.374-.003-.003 1.165-1.164.003.001.668-.667-.003-.002 1.53-1.53-.707-.707-1.806 1.806A6.858 6.858 0 0 0 15.458 13c-4.06 0-7.312 4.017-7.45 4.188l-.248.312.249.312a14.21 14.21 0 0 0 2.87 2.6l-1.233 1.234.707.707zM8.88 17.5c.85-.937 3.534-3.6 6.58-3.6a5.8 5.8 0 0 1 1.674.258l-1.052 1.053a2.367 2.367 0 0 0-.683-.111 2.403 2.403 0 0 0-2.4 2.4 2.367 2.367 0 0 0 .111.682l-1.584 1.585A14.104 14.104 0 0 1 8.88 17.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9.398 26H3V11h26v3.464l.622.621a2.726 2.726 0 0 1 .378.581V5H2v22h8.352a22.583 22.583 0 0 1-.954-1zM3 6h26v4H3zm20.877 16.765a3.306 3.306 0 0 1 .073.715v.076a3.441 3.441 0 0 1-3.451 3.394 3.547 3.547 0 0 1-.724-.083zm6.903.434l.22.301-.224.299c-.187.252-4.57 6.084-10.234 6.147h-.022a9.359 9.359 0 0 1-3.192-.633l.704-.703a8.265 8.265 0 0 0 2.492.435h.014c4.552-.054 8.377-4.343 9.368-5.545l-.004-.006.005-.006a19.33 19.33 0 0 0-3.462-3.291l.642-.642a19.358 19.358 0 0 1 3.693 3.644zm-2.573-6.7l-.707-.706-2.47 2.47a10.082 10.082 0 0 0-4.422-1.22h-.155c-5.662.123-10.048 5.902-10.233 6.156L10 23.5l.224.299a19.64 19.64 0 0 0 4.868 4.402l-2.3 2.3.708.706zM11.094 23.5l.004-.006-.005-.006c.98-1.211 4.822-5.442 9.374-5.544h.128a9.075 9.075 0 0 1 3.767.987l-1.808 1.808a3.506 3.506 0 0 0-2.018-.689h-.072a3.44 3.44 0 0 0-3.414 3.43v.076a3.31 3.31 0 0 0 .685 2.002l-1.99 1.99a19.166 19.166 0 0 1-4.651-4.048z"
  }));
};

var _default = HideEmptyIcon;
exports["default"] = _default;