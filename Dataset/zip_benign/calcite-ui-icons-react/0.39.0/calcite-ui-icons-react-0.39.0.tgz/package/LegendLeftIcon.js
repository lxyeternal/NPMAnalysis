"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LegendLeftIcon = function LegendLeftIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.5 8A1.5 1.5 0 1 0 1 6.5 1.502 1.502 0 0 0 2.5 8zm0-2a.5.5 0 1 1-.5.5.5.5 0 0 1 .5-.5zM4 1H1v3h3zM3 3H2V2h1zm1 6H1v3h3zm-1 2H2v-1h1zm3-5h7v1H6zm-3.51 7l1.638 3H.87zM15 2v1H6V2zm-9 8h5v1H6zm0 4h3v1H6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 11a2 2 0 1 0-2-2 2 2 0 0 0 2 2zm0-3a1 1 0 1 1-1 1 1 1 0 0 1 1-1zM1.937 23h4.126L4 19.209zm1.683-1l.38-.699.38.699zM6 1H2v4h4zM5 4H3V2h2zM2 17h4v-4H2zm1-3h2v2H3zm6 7h4v1H9zm0-6h7v1H9zM22 3v1H9V3zM9 9h10v1H9z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5.5 15A2.5 2.5 0 1 0 3 12.5 2.5 2.5 0 0 0 5.5 15zm0-4A1.5 1.5 0 1 1 4 12.5 1.5 1.5 0 0 1 5.5 11zM3.064 29h4.888l-2.49-4.864zm3.252-1H4.671l.808-1.637zM3 8h5V3H3zm1-4h3v3H4zM3 22h5v-5H3zm1-4h3v3H4zm17 2H11v-1h10zm-4 7h-6v-1h6zM11 5h18v1H11zm0 7h14v1H11z"
  }));
};

var _default = LegendLeftIcon;
exports["default"] = _default;