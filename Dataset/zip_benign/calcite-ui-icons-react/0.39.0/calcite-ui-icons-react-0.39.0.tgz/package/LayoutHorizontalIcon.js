"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayoutHorizontalIcon = function LayoutHorizontalIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 6h1v4H4zm7 4h1V6h-1zM10 0v1h1v1h1V0zm1 15h-1v1h2v-2h-1zm-6-1H4v2h2v-1H5zM4 0v2h1V1h1V0zm3 1h2V0H7zm0 15h2v-1H7zm5-12h4v8h-4v1h-1v-1H5v1H4v-1H0V4h4V3h1v1h6V3h1zm3 1H1v6h14z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 15H7V9h1zm9-6h-1v6h1zm0-6V1h-2v1h1v1zm-1 19h-1v1h2v-2h-1zm1-15h6v10h-6v2h-1v-2H8v2H7v-2H1V7h6V5h1v2h8V5h1zm5 1H2v8h20zM7 1v2h1V2h1V1zm1 20H7v2h2v-1H8zm3-19h2V1h-2zm0 21h2v-1h-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 13h1v6h-1zm9 6h1v-6h-1zM12 3h1V2h-2v2h1zm-1 27h2v-1h-1v-1h-1zm9-26h1V2h-2v1h1zm0 25h-1v1h2v-2h-1zM12 6h-1v2h1zm0 18h-1v2h1zm8-16h1V6h-1zm1 3h9v10h-9v1h-1v-1h-8v1h-1v-1H2V11h9v-1h1v1h8v-1h1zm8 1H3v8h26zm-8 12h-1v2h1zM17 2h-2v1h2zm0 27h-2v1h2z"
  }));
};

var _default = LayoutHorizontalIcon;
exports["default"] = _default;