"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CutAndFillVolumeCalculationIcon = function CutAndFillVolumeCalculationIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 7v1H0V7zM0 7zm4.738-6c.742 0 .981.283 1.695 1.265A14.643 14.643 0 0 0 10.188 6h1.844a14.397 14.397 0 0 1-4.79-4.322C6.535.704 6.024 0 4.739 0 2.737 0 1.276 2.98.306 6h1.05c1.055-3.156 2.289-5 3.382-5zm4.85 9.717a4.072 4.072 0 0 0-1.559 1.195 7.431 7.431 0 0 1-1.097.987 5.396 5.396 0 0 1-.797-1.314L8.72 9H7.306l-1.612 1.612A53.494 53.494 0 0 1 5.038 9H3.964c.77 1.974 1.91 4.947 2.891 4.947 1.04 0 2.452-2.283 3.11-2.283.84 0 1.506 2.845 6.035 4.377v-1.06c-.32-.118-.614-.243-.89-.372l.89-.889v-1.414l-1.807 1.807a8.49 8.49 0 0 1-1.465-1.121L16 9.72V9h-.694l-3.266 3.266c-.129-.15-.25-.295-.359-.429a4.458 4.458 0 0 0-.9-.897L12.72 9h-1.415z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.95 19.356l5.05-5.05v1.414l-4.278 4.278a8.105 8.105 0 0 0 1.644.942L23 18.306v1.414l-1.589 1.589A10.25 10.25 0 0 0 23 21.64v1.015c-4.672-.548-6.488-3.29-7.731-4.915-.499-.652-.93-1.215-1.236-1.215-.61 0-1.156.785-1.683 1.544-.65.935-1.32 1.902-2.358 1.902-1.978 0-4.214-3.654-5.557-6.971H5.72l-.142.142c.262.61.54 1.2.833 1.754L8.306 13H9.72l-2.804 2.804a15.351 15.351 0 0 0 1.04 1.546l4.35-4.35h1.414l-5.117 5.117a2.288 2.288 0 0 0 1.389.854c.514 0 1.034-.749 1.537-1.473.59-.848 1.25-1.8 2.232-1.952L16.306 13h1.414l-2.829 2.829a6.59 6.59 0 0 1 1.172 1.303l.048.063L20.306 13h1.414l-4.996 4.996a12.053 12.053 0 0 0 1.226 1.36zM7.63 2c1.007 0 1.614.728 2.783 2.243A23.199 23.199 0 0 0 16.462 10h1.916a22.14 22.14 0 0 1-7.172-6.368C10.026 2.104 9.174 1 7.632 1 4.989 1 2.909 5.801 1.59 10h1.049c1.875-5.845 3.767-8 4.992-8zM1 11v1h22v-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3.537 15H2.498C4.25 9.057 6.817 2.011 11.164 2.011c1.793 0 2.943 1.954 4.398 4.428 1.64 2.79 3.674 6.31 7.351 8.561h-1.796c-3.018-2.285-4.838-5.368-6.314-7.88l-.102-.174c-1.294-2.198-2.316-3.935-3.537-3.935-3.877 0-6.41 7.851-7.627 11.989zm19.227 9.542a90.622 90.622 0 0 1-.898-.952l-.356-.38L26.72 18h-1.414l-4.488 4.488a7.612 7.612 0 0 0-1.403-1.183L22.72 18h-1.414l-3.027 3.027c-1.044.136-1.678 1.198-2.341 2.33C15.178 24.658 14.392 26 13 26a2.142 2.142 0 0 1-1.397-.883L18.72 18h-1.414l-6.326 6.326a17.255 17.255 0 0 1-.972-1.614L14.72 18h-1.414l-3.779 3.779a38.405 38.405 0 0 1-.814-1.772L10.72 18H9.306l-1.01 1.01Q8.093 18.503 7.9 18H6.828c1.264 3.447 3.685 9 6.172 9 1.965 0 2.983-1.74 3.8-3.137.561-.958 1.091-1.863 1.7-1.863.515 0 1.592 1.155 2.634 2.272 2.16 2.316 5.089 5.443 8.866 5.703v-1.002a6.877 6.877 0 0 1-1.837-.416L30 26.72v-1.414l-2.813 2.813a11.688 11.688 0 0 1-1.585-1.001L30 22.72v-1.414l-5.187 5.187a23.33 23.33 0 0 1-1.348-1.238L30 18.72V18h-.694zM2 16v1h28v-1z"
  }));
};

var _default = CutAndFillVolumeCalculationIcon;
exports["default"] = _default;