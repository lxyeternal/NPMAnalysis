"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DistributeWidthEvenlyIcon = function DistributeWidthEvenlyIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 16h7V9H9zm1-6h5v5h-5zM0 16h7V9H0zm1-6h5v5H1zM15 0h1v7h-1zM1 0v7H0V0zm2.707 3h8.487l-1.583-1.583.707-.707 2.81 2.81-2.81 2.808-.707-.707L12.233 4H3.669L5.29 5.621l-.707.707-2.81-2.808L4.584.71l.707.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 10V3h1v7zm19 0h1V3h-1zm-5.354-.354l.707.707L20.207 6.5l-3.853-3.854-.707.707L18.293 6H5.707l2.647-2.646-.707-.707L3.793 6.5l3.854 3.854.707-.707L5.707 7h12.586zM13 13h9v9h-9zm1 8h7v-7h-7zM2 13h9v9H2zm1 8h7v-7H3z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4 14H3V3h1zM28 3v11h1V3zM8.646 12.354l.707-.707L6.707 9h18.586l-2.646 2.646.707.707L27.207 8.5l-3.853-3.854-.707.707L25.293 8H6.707l2.647-2.646-.707-.707L4.793 8.5zM17 17h12v12H17zm1 11h10V18H18zm-3 1H3V17h12zm-1-11H4v10h10z"
  }));
};

var _default = DistributeWidthEvenlyIcon;
exports["default"] = _default;