"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FilesCsvCollectionIcon = function FilesCsvCollectionIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 15h1v1H1V4h1v11h8zm.394-2H3v1h10v-1h-2.606zM4 3V2H3v4h1zm1-3h6.4L15 3.6V6h-1V5h-4V1H6v5H5zm6 1v3h3v-.31L11.31 1zm3.57 6l-1.058 3.317L12.468 7H11.42l1.591 5.059h.994L15.62 7zM6 12v-1H4V8h2V7H3v5h3zm4-3H8V8h2V7H7v3h2v1H7v1h3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 21h1v2H3V7h2v1H4v14h11zm3-2H7v-4H6v5h13v-2h-1zM7 5h1V4H6v4h1zm14 10v1H10v-1H9v2h13v-2h-1zM9 1h9.4L22 4.6V8h-1V6h-4V2h-7v6H9zm9 4h3v-.31L18.31 2H18zm2.04 9h-1.063l-2.095-5h1.084l1.546 3.688L21.08 9h1.086zM16 9h-2.651A1.35 1.35 0 0 0 12 10.349v.302A1.35 1.35 0 0 0 13.349 12h1.302a.349.349 0 0 1 .349.349v.302a.349.349 0 0 1-.349.349H12v1h2.651A1.35 1.35 0 0 0 16 12.651v-.302A1.35 1.35 0 0 0 14.651 11H13.35a.349.349 0 0 1-.349-.349v-.302A.349.349 0 0 1 13.35 10H16zm-6.959 5H11v-1H9.041A1.042 1.042 0 0 1 8 11.959v-.918A1.042 1.042 0 0 1 9.041 10H11V9H9.041A2.044 2.044 0 0 0 7 11.041v.918A2.044 2.044 0 0 0 9.041 14z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21 28h1v2H4V8h2v1H5v20h16zm3-2H8V6h1V5H7v22h18v-2h-1zm4-18.291V12h-1V9h-6V3H11v9h-1V2h12.29zM27 8v-.2L22.2 3H22v5zm1 16v-2h-1v1H11v-1h-1v2zm-12.861-8.52l.707-.707a3.18 3.18 0 1 0 0 4.496l-.707-.707a2.23 2.23 0 0 1-3.081 0 2.179 2.179 0 1 1 3.08-3.081zM26.804 14l-1.794 4.453L23.242 14h-1.076l2.375 5.984.929.002L27.882 14zm-7.172 2.312c-1.112-.171-1.122-.58-1.126-.787a.667.667 0 0 1 .2-.476.8.8 0 0 1 .58-.25 1.125 1.125 0 0 1 1.052.629l.85-.526a2.11 2.11 0 0 0-1.902-1.102 1.812 1.812 0 0 0-1.3.556 1.66 1.66 0 0 0-.48 1.2c.021.96.685 1.546 1.973 1.744a1.332 1.332 0 0 1 .947.477.836.836 0 0 1 .04.684 1.165 1.165 0 0 1-1.16.639 1.34 1.34 0 0 1-1.283-.745l-.863.504a2.318 2.318 0 0 0 2.146 1.24 2.134 2.134 0 0 0 2.104-1.306 1.828 1.828 0 0 0-.126-1.53 2.19 2.19 0 0 0-1.652-.951z"
  }));
};

var _default = FilesCsvCollectionIcon;
exports["default"] = _default;