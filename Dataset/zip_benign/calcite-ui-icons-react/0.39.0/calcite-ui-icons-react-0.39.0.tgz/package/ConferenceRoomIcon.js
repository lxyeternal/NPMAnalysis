"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ConferenceRoomIcon = function ConferenceRoomIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.309 7.5A1.996 1.996 0 1 0 0 6a1.987 1.987 0 0 0 .691 1.5A1.987 1.987 0 0 0 0 9v2h1V9a1 1 0 0 1 2 0v.896l.715-1.908A2 2 0 0 0 3.31 7.5zM1 6a1 1 0 1 1 1 1 1.001 1.001 0 0 1-1-1zm14.309 1.5a2 2 0 1 0-2.618 0 2 2 0 0 0-.406.488L13 9.896V9a1 1 0 0 1 2 0v2h1V9a1.987 1.987 0 0 0-.691-1.5zM13 6a1 1 0 1 1 1 1 1.001 1.001 0 0 1-1-1zM7 5a1 1 0 0 1 2 0v1h1V5a1.987 1.987 0 0 0-.691-1.5 2 2 0 1 0-2.618 0A1.987 1.987 0 0 0 6 5v1h1zm0-3a1 1 0 1 1 1 1 1.001 1.001 0 0 1-1-1zm4.09 5.648l2.878 7.676-.936.352L10.153 8H5.847l-2.879 7.676-.936-.352L4.91 7.648A1.005 1.005 0 0 1 5.847 7h4.306a1.005 1.005 0 0 1 .937.648z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.898 12.581a2.467 2.467 0 0 1 2.073-.538 2.38 2.38 0 0 1 1.42.871l.419-1.023a3.39 3.39 0 0 0-.707-.489 2.5 2.5 0 1 0-3.215-.006 3.454 3.454 0 0 0-.631.418A3.491 3.491 0 0 0 1 14.5V16h1v-1.5a2.492 2.492 0 0 1 .898-1.919zM3 9.5A1.5 1.5 0 1 1 4.5 11 1.502 1.502 0 0 1 3 9.5zm18.103 1.902a2.5 2.5 0 1 0-3.215-.007 3.448 3.448 0 0 0-.631.419c-.026.021-.044.05-.07.072l.412 1.006a2.407 2.407 0 0 1 2.372-.849A2.608 2.608 0 0 1 22 14.646V16h1v-1.354a3.647 3.647 0 0 0-1.897-3.244zM18 9.5a1.5 1.5 0 1 1 1.5 1.5A1.502 1.502 0 0 1 18 9.5zM10 9V8a1.99 1.99 0 0 1 .764-1.572 2.02 2.02 0 0 1 1.739-.367A2.08 2.08 0 0 1 14 8.119V9h1v-.88a3.173 3.173 0 0 0-1.445-2.678 2.5 2.5 0 1 0-3.1.009 2.956 2.956 0 0 0-.31.192A2.984 2.984 0 0 0 9 8v1zm.5-5.5A1.5 1.5 0 1 1 12 5a1.502 1.502 0 0 1-1.5-1.5zm9.463 17.81l-.926.38L14.664 11H9.336L4.963 21.69l-.926-.38L8.41 10.622A.997.997 0 0 1 9.336 10h5.328a.996.996 0 0 1 .925.62z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6 16a2.99 2.99 0 0 1 2.578 1.49l.383-1.155a3.999 3.999 0 0 0-1.207-.912 3 3 0 1 0-3.508 0A3.992 3.992 0 0 0 2 19v2h1v-2a3.003 3.003 0 0 1 3-3zm0-5a2 2 0 1 1-2 2 2.003 2.003 0 0 1 2-2zm21.754 4.423a3 3 0 1 0-3.508 0 4 4 0 0 0-1.207.912l.384 1.155A2.99 2.99 0 0 1 29 19v2h1v-2a3.992 3.992 0 0 0-2.246-3.577zM26 11a2 2 0 1 1-2 2 2.003 2.003 0 0 1 2-2zm-13 2v-2a3 3 0 0 1 6 0v2h1v-2a3.992 3.992 0 0 0-2.246-3.577 3 3 0 1 0-3.508 0A3.992 3.992 0 0 0 12 11v2zm3-10a2 2 0 1 1-2 2 2.003 2.003 0 0 1 2-2zm9.975 25.343l-.95.314-.052-.157-4.372-13.158a.5.5 0 0 0-.475-.342h-8.252a.5.5 0 0 0-.475.343L7.027 28.5l-.052.157-.95-.314 4.425-13.316A1.498 1.498 0 0 1 11.874 14h8.252a1.499 1.499 0 0 1 1.424 1.026z"
  }));
};

var _default = ConferenceRoomIcon;
exports["default"] = _default;