"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DataRasterIcon = function DataRasterIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 11h-1v-1h1zm4 1h-1v1h1zm-2 2h-1v1h1z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 15h-1v-1h1zm2-5h-1v1h1z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 9v7h7V9zm2 6h-1v-1h1zm0-2h-1v-1h1zm0-2h-1v-1h1zm2 4h-1v-1h1zm0-2h-1v-1h1zm0-2h-1v-1h1zm2 4h-1v-1h1zm0-2h-1v-1h1zm0-2h-1v-1h1zm-7 1.963c-.17.004-.32.016-.5.016-3.84 0-5.5-.993-5.5-1.5V7.906a7.983 7.983 0 0 0 2.971.911 18.622 18.622 0 0 0 3.035.152A.997.997 0 0 1 9 8h5V3.48C14 1.983 11.388 1 7.5 1S1 1.984 1 3.48v8c0 1.495 2.612 2.5 6.5 2.5.17 0 .335-.005.5-.009zM7.5 1.98c3.84 0 5.5.994 5.5 1.5S11.34 5 7.5 5 2 3.986 2 3.48s1.66-1.5 5.5-1.5zM2 4.906a7.983 7.983 0 0 0 2.971.911 18.873 18.873 0 0 0 6.03-.173A6.649 6.649 0 0 0 13 4.906V6.48c0 .507-1.66 1.5-5.5 1.5S2 6.986 2 6.48z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 16h-2v-2h2zm6 1h-2v2h2zm-3 3h-2v2h2z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 22h-2v-2h2zm3-8h-2v2h2z",
      opacity: ".5"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 19.913c-.167.003-.33.008-.5.008-5.266 0-8.5-1.364-8.5-2.342v-6.248C4.643 12.429 8.082 13 11.5 13c.168 0 .335-.008.502-.01A.999.999 0 0 1 13 12h5.597A6.558 6.558 0 0 0 20 11.33V12h1V5c0-1.97-4.78-3-9.5-3S2 3.03 2 5v12.58c0 2.193 4.78 3.34 9.5 3.34.167 0 .333-.004.5-.007zM11.5 3C17 3 20 4.321 20 5s-3 2-8.5 2S3 5.679 3 5s3-2 8.5-2zM3 6.411C4.643 7.457 8.082 8 11.5 8s6.857-.543 8.5-1.589v3.437C20 10.726 16.689 12 11.5 12S3 10.726 3 9.848zM13 13v10h10V13zm3 9h-2v-2h2zm0-3h-2v-2h2zm0-3h-2v-2h2zm3 6h-2v-2h2zm0-3h-2v-2h2zm0-3h-2v-2h2zm3 6h-2v-2h2zm0-3h-2v-2h2zm0-3h-2v-2h2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21 21h-3v-3h3zm8 1h-3v3h3zm-4 4h-3v3h3z",
    opacity: ".25"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M25 21h-3v-3h3zm-4 5h-3v3h3z",
    opacity: ".5"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18 17h-1v13h13V17zm3 12h-3v-3h3zm0-4h-3v-3h3zm0-4h-3v-3h3zm4 8h-3v-3h3zm0-4h-3v-3h3zm0-4h-3v-3h3zm4 8h-3v-3h3zm0-4h-3v-3h3zm0-4h-3v-3h3zM28 7c0-2.56-6.288-3.9-12.5-3.9S3 4.44 3 7c0 .033.013.063.015.096H3v16.393c0 2.819 6.44 4.34 12.5 4.34.166 0 .333-.005.5-.008v-1c-.167.002-.33.008-.5.008-6.777 0-11.5-1.76-11.5-3.34v-7.986c2.034 1.58 6.873 2.42 11.5 2.42.166 0 .333-.003.5-.005v-1.002c-.166.003-.33.008-.5.008-7.125 0-11.5-1.805-11.5-3.099V8.624c2.011 1.499 6.774 2.276 11.5 2.276s9.489-.777 11.5-2.276v5.201c0 .698-1.283 1.543-3.575 2.175h2.793a5.684 5.684 0 0 0 .782-.497V16h1V7.096h-.015C27.987 7.063 28 7.033 28 7zM15.5 9.9C8.375 9.9 4 8.21 4 7s4.375-2.9 11.5-2.9S27 5.79 27 7s-4.375 2.9-11.5 2.9z"
  }));
};

var _default = DataRasterIcon;
exports["default"] = _default;