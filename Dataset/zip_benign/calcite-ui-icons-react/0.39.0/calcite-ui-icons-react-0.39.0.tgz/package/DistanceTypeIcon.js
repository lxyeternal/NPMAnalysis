"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DistanceTypeIcon = function DistanceTypeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 1v3h3V1zm2 2H1V2h1zm11-2v3h3V1zm2 2h-1V2h1zM3 14h2v2H3zm0-2h2v-2H3zm4-5h9V6H7zm0 4h9v-1H7zm0 4h9v-1H7zM3 8h2V6H3zm7-4V3H6v1L4 2.5 6 1v1h4V1l2 1.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6 9h2v2H6zm0 7h2v-2H6zm0 5h2v-2H6zm4-1h11v-1H10zm0-5h11v-1H10zm0-5h11V9H10zM2 3h3v3H2zm1 2h1V4H3zm19-2v3h-3V3zm-1 1h-1v1h1zm-5 1v1l2-1.5L16 3v1H8V3L6 4.5 8 6V5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8 25h2v2H8zm0-4h2v-2H8zm4-7h17v-1H12zm0 6h17v-1H12zm0 6h17v-1H12zM8 15h2v-2H8zM2 8h3V5H2zm1-2h1v1H3zm24-1v3h3V5zm2 2h-1V6h1zm-6-3.19l3.058 2.69L23 9.19V7H9v2.19L5.942 6.5 9 3.81V6h14z"
  }));
};

var _default = DistanceTypeIcon;
exports["default"] = _default;