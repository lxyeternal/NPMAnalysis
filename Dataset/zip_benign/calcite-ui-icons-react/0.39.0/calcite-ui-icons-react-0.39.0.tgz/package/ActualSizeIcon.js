"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ActualSizeIcon = function ActualSizeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 1v5h-1V2h-4V1zM2 10H1v5h5v-1H2zm12 4h-4v1h5v-5h-1zM1 6h1V2h4V1H1zm7 2h1V7H8zm0 3h1v-1H8zM4.174 6.343L5 6.027V11h1V4.573l-2.184.837zM12 11V4.573l-2.184.837.358.933.826-.316V11z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.938 7.946L9 6.773V17H8V8.227l-1.704.653zM21 21h-5v1h6v-6h-1zM3 16H2v6h6v-1H3zM3 3h5V2H2v6h1zm13-1v1h5v5h1V2zm-3.5 7.75a.75.75 0 1 0 .75.75.75.75 0 0 0-.75-.75zm0 5a.75.75 0 1 0 .75.75.75.75 0 0 0-.75-.75zM16 17h1V6.773l-3.062 1.173.358.934L16 8.227z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.93 10.054L11 8.494V23h-1V9.948l-2.713 1.04zM22 23h1V8.494l-4.07 1.56.357.934L22 9.948zM4 4h6V3H3v7h1zm18-1v1h6v6h1V3zM4 22H3v7h7v-1H4zm24 6h-6v1h7v-7h-1zM16.5 13.5a1 1 0 1 0 1 1 1 1 0 0 0-1-1zm0 7a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"
  }));
};

var _default = ActualSizeIcon;
exports["default"] = _default;