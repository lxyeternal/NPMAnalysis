"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CaretSquareDownIcon = function CaretSquareDownIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1.929 1A.929.929 0 0 0 1 1.929V14.07a.929.929 0 0 0 .929.929H14.07a.929.929 0 0 0 .929-.929V1.93a.929.929 0 0 0-.928-.93zM14 14H2V2h12zm-6-3.9L3.9 6h8.2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.281 22h17.437A1.281 1.281 0 0 0 22 20.719V3.282A1.282 1.282 0 0 0 20.719 2H3.28A1.282 1.282 0 0 0 2 3.282v17.437A1.281 1.281 0 0 0 3.281 22zM3 3.281A.281.281 0 0 1 3.281 3H20.72a.281.281 0 0 1 .281.281V20.72a.281.281 0 0 1-.281.281H3.28a.281.281 0 0 1-.28-.282zM12 15.1L5.9 9h12.2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4.673 29H27.33A1.672 1.672 0 0 0 29 27.33V4.671A1.671 1.671 0 0 0 27.328 3H4.672A1.671 1.671 0 0 0 3 4.671v22.66A1.674 1.674 0 0 0 4.673 29zM4 4.671A.673.673 0 0 1 4.672 4h22.656a.673.673 0 0 1 .672.671v22.66a.67.67 0 0 1-.67.669H4.673A.672.672 0 0 1 4 27.33zM16 22.1L6.965 13h18.07z"
  }));
};

var _default = CaretSquareDownIcon;
exports["default"] = _default;