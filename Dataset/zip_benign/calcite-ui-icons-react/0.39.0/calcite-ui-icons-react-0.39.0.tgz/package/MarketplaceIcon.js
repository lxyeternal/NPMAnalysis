"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var MarketplaceIcon = function MarketplaceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.033 6.68L6.811 3H3.16L.054 13H4.13l.96-3.21L6.192 13h3.594l1.104-3.17.993 3.17h4.057L12.832 3h-3.65zM3.386 12H1.41l2.486-8h1.881zm2.196-3.856l.893-2.983 1.048 3.156-.895 2.87zM12.617 12l-1.175-3.755 1.043-2.994L14.583 12zm-.756-8l-2.786 8H7.422l2.496-8z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.269 5l-1.939 5.588L9.746 5H5.242L.24 19h5.773l1.553-5.334L9.152 19h5.714l1.552-5.046L18.008 19h5.742L18.749 5zM5.26 18.005H1.656l4.291-12.01H8.76zm2.82-6.11l1.45-4.979 2.328 5.032-2.025 5.84zm6.045 6.11h-3.31l4.165-12.01h2.84zm4.616 0l-1.805-5.735 1.55-5.037 3.847 10.772z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10.305 18.699L13.158 26h6.682l2.032-7.219L24.132 26h7.292l-6.54-19H19.14l-2.662 7.965L13.863 7h-6.76L.563 26h7.314zM24.867 25l-2.499-7.982 2.208-7.843L30.021 25zM19.86 8h4.008l-4.786 17H14.18zm-3.912 8.552l-2.493 7.46-2.657-6.798 2.7-8.12zM1.966 25l5.85-17h4.992L7.156 25z"
  }));
};

var _default = MarketplaceIcon;
exports["default"] = _default;