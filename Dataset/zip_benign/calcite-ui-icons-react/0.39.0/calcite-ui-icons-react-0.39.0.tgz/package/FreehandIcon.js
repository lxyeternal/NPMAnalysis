"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FreehandIcon = function FreehandIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.348 2.72c.232-.168.44-.32.602-.451l-.63-.776c-.151.122-.344.262-.56.418C2.662 2.71 1 3.914 1 5.5A2.473 2.473 0 0 0 3.5 8c1.045 0 1.954-1.002 2.755-1.886C6.634 5.697 7.267 5 7.5 5a.492.492 0 0 1 .5.5 5.3 5.3 0 0 1-.854 1.991A6.558 6.558 0 0 0 6 10.5a2.883 2.883 0 0 0 .936 2.132A6.455 6.455 0 0 0 11.5 14h.077a8.18 8.18 0 0 0 4.09 1.743l.166-.986a8.565 8.565 0 0 1-2.838-.962A4.097 4.097 0 0 0 16 10a2.916 2.916 0 0 0-3-3c-1.738 0-3 1.472-3 3.5a4.542 4.542 0 0 0 .71 2.501 5.017 5.017 0 0 1-3.086-1.095A1.882 1.882 0 0 1 7 10.5a5.962 5.962 0 0 1 1.015-2.513A5.634 5.634 0 0 0 9 5.5 1.486 1.486 0 0 0 7.5 4c-.676 0-1.283.669-1.985 1.442C4.885 6.137 4.102 7 3.5 7A1.467 1.467 0 0 1 2 5.5c0-1.075 1.413-2.1 2.348-2.78zM13 8a1.968 1.968 0 0 1 2 2 3.186 3.186 0 0 1-3.048 2.978A3.497 3.497 0 0 1 11 10.5c0-1.448.841-2.5 2-2.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 14.25A3.88 3.88 0 0 0 19.25 10C16.314 10 15 12.763 15 15.5a6.493 6.493 0 0 0 .95 3.516 7.005 7.005 0 0 1-4.905-1.566A3.255 3.255 0 0 1 10 15a9.084 9.084 0 0 1 1.555-3.894A8.31 8.31 0 0 0 13 7.5 2.276 2.276 0 0 0 10.5 5c-.919 0-1.795 1.072-2.81 2.314C6.714 8.511 5.498 10 4.5 10 3.684 10 2 9.51 2 8c0-1.848 2.703-4.028 4.002-5.076l.266-.215-.632-.775-.262.212C3.845 3.379 1 5.675 1 8c0 2.07 2.047 3 3.5 3 1.473 0 2.797-1.622 3.965-3.053C9.174 7.08 10.055 6 10.5 6c1.038 0 1.5.463 1.5 1.5a7.868 7.868 0 0 1-1.313 3.11A9.681 9.681 0 0 0 9 15a4.275 4.275 0 0 0 1.357 3.176A8.438 8.438 0 0 0 16.5 20c.072 0 .144-.001.215-.003a11.08 11.08 0 0 0 6.326 2.871l.167-.986a11.16 11.16 0 0 1-5.178-2.024A5.937 5.937 0 0 0 23 14.25zm-7 1.25c0-2.24 1.005-4.5 3.25-4.5.951 0 2.75.68 2.75 3.25a5.033 5.033 0 0 1-4.857 4.722A5.396 5.396 0 0 1 16 15.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30 18.5c0-3.78-2.333-5.5-4.5-5.5-4.06 0-5.5 4.04-5.5 7.5a8.597 8.597 0 0 0 1.146 4.515 9.465 9.465 0 0 1-6.683-2.016A4.636 4.636 0 0 1 13 19.5a14.85 14.85 0 0 1 1.58-5.324A13.262 13.262 0 0 0 16 9.5 2.349 2.349 0 0 0 13.5 7c-1.13 0-2.274 1.26-3.6 2.72C8.507 11.259 6.927 13 5.5 13A2.768 2.768 0 0 1 3 10.5c0-1.809 1.983-4.419 5.585-7.35l-.63-.776C5.237 4.585 2 7.789 2 10.5A3.751 3.751 0 0 0 5.5 14c1.869 0 3.607-1.916 5.141-3.607C11.71 9.217 12.812 8 13.5 8A1.36 1.36 0 0 1 15 9.5a12.74 12.74 0 0 1-1.339 4.281A15.508 15.508 0 0 0 12 19.5a5.6 5.6 0 0 0 1.775 4.225C15.479 25.34 18.3 26.167 21.5 26c.117 0 .233-.002.348-.005 1.684 1.993 4.527 3.315 8.569 3.998l.166-.986c-3.379-.571-5.848-1.608-7.433-3.131A7.775 7.775 0 0 0 30 18.5zm-7.65 6.465A7.33 7.33 0 0 1 21 20.5c0-2.998 1.179-6.5 4.5-6.5 1.686 0 3.5 1.408 3.5 4.5a6.88 6.88 0 0 1-6.65 6.465z"
  }));
};

var _default = FreehandIcon;
exports["default"] = _default;