"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AntennaHeightIcon = function AntennaHeightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 1h-5V0h5zm-5 15h5v-1h-5zm3-3.706V3.706l1.62 1.619.706-.707-2.809-2.81-2.809 2.81.707.707L12 3.74v8.52l-1.585-1.585-.707.707 2.81 2.81 2.808-2.81-.707-.707zM8 2.034V4H6v12H5V4H4v12H3V4H1V2.033A2.036 2.036 0 0 1 3.033 0h2.934A2.036 2.036 0 0 1 8 2.033zm-1 0A1.034 1.034 0 0 0 5.967 1H3.033A1.034 1.034 0 0 0 2 2.033V3h5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21 2h-7V1h7zm-7 21h7v-1h-7zm4-3.707V4.707l2.646 2.646.707-.707L17.5 2.793l-3.854 3.853.707.707L17 4.707v14.586l-2.646-2.646-.707.707 3.853 3.853 3.854-3.854-.707-.707zM12 3.891V6H9v17H8V6H7v17H6V6H3V3.89A2.894 2.894 0 0 1 5.89 1h3.22A2.894 2.894 0 0 1 12 3.89zm-1 0A1.893 1.893 0 0 0 9.11 2H5.89A1.893 1.893 0 0 0 4 3.89V5h7z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28 2v1H17V2zM17 30h11v-1H17zm2.354-6.354l-.707.707 3.853 3.854 3.854-3.854-.707-.707L23 26.293V5.707l2.646 2.646.707-.707L22.5 3.793l-3.854 3.853.707.707L22 5.707v20.586zM13 4.891V7h-3v23H9V7H8v23H7V7H4V4.89A2.894 2.894 0 0 1 6.89 2h3.22A2.894 2.894 0 0 1 13 4.89zm-1 0A1.893 1.893 0 0 0 10.11 3H6.89A1.893 1.893 0 0 0 5 4.89V6h7z"
  }));
};

var _default = AntennaHeightIcon;
exports["default"] = _default;