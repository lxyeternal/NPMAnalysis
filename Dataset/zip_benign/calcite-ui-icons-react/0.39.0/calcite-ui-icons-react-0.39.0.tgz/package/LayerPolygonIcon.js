"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerPolygonIcon = function LayerPolygonIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.207 13.2A6.624 6.624 0 0 1 16 14.29L13.867 1.687a8.205 8.205 0 0 0-3.161-.674c-2.69 0-2.724.986-5.412.986a10.39 10.39 0 0 1-3.161-.512L0 14.09a9.158 9.158 0 0 0 3.793.711c3.665 0 4.749-1.6 8.414-1.6zM2.935 2.74A11.376 11.376 0 0 0 5.294 3a7.834 7.834 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.213 7.213 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852 10.962 10.962 0 0 1-3.888.748 9.537 9.537 0 0 1-2.668-.363zM12 4H4l-1 8h10zM8.788 5L7.602 7.042H4.628L4.883 5zM4.512 7.964h3.096L10.177 11H4.133zM11.324 11L8.362 7.5 9.812 5h1.305l.75 6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16.31 2.2c-3.847 0-3.891 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722L1 20.783A13.093 13.093 0 0 0 6.424 21.8c5.242 0 6.792-1.634 12.034-1.634a13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105a12.674 12.674 0 0 0-4.52-.878zm2.148 16.966a24.03 24.03 0 0 0-6.251.845 22.054 22.054 0 0 1-5.783.789 13.726 13.726 0 0 1-4.3-.65L4.848 4.343A16.193 16.193 0 0 0 8.57 4.8a9.805 9.805 0 0 0 4.25-.875 7.791 7.791 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l2.674 15.872a16.248 16.248 0 0 0-4.157-.52zM16.31 4.2a6.87 6.87 0 0 0-3.11.65 10.811 10.811 0 0 1-4.63.95 16.728 16.728 0 0 1-2.914-.268L3.262 19.436a13.436 13.436 0 0 0 3.162.364 21.214 21.214 0 0 0 5.549-.761 24.868 24.868 0 0 1 6.485-.873 18.033 18.033 0 0 1 2.926.234L19.057 4.59a10.555 10.555 0 0 0-2.746-.39zM6.476 6.667a17.064 17.064 0 0 0 2.095.133 11.836 11.836 0 0 0 5.01-1.025 5.842 5.842 0 0 1 2.331-.566L11.793 12H5.558zm5.263 11.4a20.374 20.374 0 0 1-5.315.733 12.935 12.935 0 0 1-2.012-.153L5.385 13h6.268l3.54 4.378a32.767 32.767 0 0 0-3.454.688zm6.719-.901c-.76 0-1.448.03-2.085.082l-3.767-4.66 4.454-7.342a10.049 10.049 0 0 1 1.12.16l1.995 11.835c-.565-.05-1.14-.075-1.717-.075zM7.5 8.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm10 2.9a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm-9 4.1a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.074 3.211c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 3.9L1 28a16.273 16.273 0 0 0 7.538 1.8c6.876 0 8.048-2.6 14.924-2.6A33.153 33.153 0 0 1 31 28L27 3.9a26.401 26.401 0 0 0-5.926-.689zM23.462 26.2a22.376 22.376 0 0 0-7.77 1.348A20.416 20.416 0 0 1 8.539 28.8a15.986 15.986 0 0 1-6.43-1.366L5.795 5.217a15.6 15.6 0 0 0 4.544.651 17.433 17.433 0 0 0 5.445-.846 16.633 16.633 0 0 1 5.29-.81 26.266 26.266 0 0 1 5.05.517l3.651 22a37.271 37.271 0 0 0-6.313-.529zM21.074 6.21a14.759 14.759 0 0 0-4.736.733 19.375 19.375 0 0 1-5.999.925 18.297 18.297 0 0 1-2.918-.231L4.348 26.148a14.05 14.05 0 0 0 4.19.652 18.509 18.509 0 0 0 6.54-1.155 24.388 24.388 0 0 1 8.384-1.445c1.444 0 2.76.079 3.898.19L24.383 6.458a23.564 23.564 0 0 0-3.309-.247zM8.25 8.757a19.57 19.57 0 0 0 2.09.112 20.235 20.235 0 0 0 6.276-.964 14.641 14.641 0 0 1 3.073-.638L14.997 15H7.212zm6.52 15.938A17.461 17.461 0 0 1 8.539 25.8a12.838 12.838 0 0 1-3.056-.372L7.046 16h7.98l5.915 7.316a26.442 26.442 0 0 0-6.171 1.378zm8.693-1.494c-.456 0-.886.013-1.304.032l-6.276-7.763 5.007-8.255c.064 0 .12-.003.185-.003a21.74 21.74 0 0 1 2.444.143l2.645 15.935c-.9-.059-1.804-.089-2.7-.089zM11.5 11.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm11 4a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm-10 5a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"
  }));
};

var _default = LayerPolygonIcon;
exports["default"] = _default;