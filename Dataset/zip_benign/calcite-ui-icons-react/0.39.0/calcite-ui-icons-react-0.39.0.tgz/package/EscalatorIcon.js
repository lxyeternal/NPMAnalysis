"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EscalatorIcon = function EscalatorIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 4a2.002 2.002 0 0 0-2-2h-1.728l-9 9H2a2 2 0 0 0 0 4h13V5.722A1.994 1.994 0 0 0 16 4zm-2 10H4.707l8-8H14zm0-9h-1.707l-9 9H2a1 1 0 0 1 0-2h1.686l9-9H14a1 1 0 0 1 0 2z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M24 5.5A2.387 2.387 0 0 0 21.75 3h-3.457l-13 13H2.25A2.387 2.387 0 0 0 0 18.5a2.413 2.413 0 0 0 2 2.472V21h21V7.577A2.582 2.582 0 0 0 24 5.5zM22 20H6.707l12-12h3.043a1.993 1.993 0 0 0 .25-.028zm-.25-13h-3.457l-13 13H2.25A1.394 1.394 0 0 1 1 18.5 1.394 1.394 0 0 1 2.25 17h3.457l13-13h3.043A1.394 1.394 0 0 1 23 5.5 1.394 1.394 0 0 1 21.75 7z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M32 7a3.003 3.003 0 0 0-3-3h-3.707l-18 18H3a3 3 0 0 0 0 6h28V9.22A2.982 2.982 0 0 0 32 7zm-2 20H8.707l17-17H29a2.965 2.965 0 0 0 1-.184zM29 9h-3.707l-18 18H3a2 2 0 0 1 0-4h4.707l18-18H29a2 2 0 0 1 0 4z"
  }));
};

var _default = EscalatorIcon;
exports["default"] = _default;