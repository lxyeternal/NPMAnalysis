"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BellIcon = function BellIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 6.5V10a2 2 0 0 1-2 2v1h13v-1a2 2 0 0 1-2-2V6.5a4.485 4.485 0 0 0-3.19-4.283A1.484 1.484 0 0 0 10 1.5a1.5 1.5 0 0 0-3 0 1.484 1.484 0 0 0 .19.717A4.485 4.485 0 0 0 4 6.5zm4-5a.5.5 0 1 1 .5.5.5.5 0 0 1-.5-.5zM8.5 3A3.504 3.504 0 0 1 12 6.5V10a2.99 2.99 0 0 0 .766 2H4.234A2.99 2.99 0 0 0 5 10V6.5A3.504 3.504 0 0 1 8.5 3zM7 14.053V14h3v.053a1.5 1.5 0 0 1-3 0z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18 15v-4.087A5.91 5.91 0 0 0 13.59 5.2a2 2 0 1 0-3.18 0A5.91 5.91 0 0 0 6 10.913V15a3 3 0 0 1-3 3v1h18v-1a3 3 0 0 1-3-3zM12 3a1 1 0 1 1-1 1 1.001 1.001 0 0 1 1-1zM5.643 18A3.992 3.992 0 0 0 7 15v-4.087A4.919 4.919 0 0 1 11.913 6h.174A4.919 4.919 0 0 1 17 10.913V15a3.992 3.992 0 0 0 1.357 3zM13 20h1a2 2 0 0 1-4 0h1a1 1 0 0 0 2 0z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 30a3 3 0 0 1-3-3h1a2 2 0 0 0 4 0h1a3 3 0 0 1-3 3zm13-5v1H3v-1a4 4 0 0 0 4-4v-7a8.997 8.997 0 0 1 7.372-8.845 2 2 0 1 1 3.257 0A8.997 8.997 0 0 1 25 14v7a4 4 0 0 0 4 4zM16 5a1 1 0 1 0-1-1 1.001 1.001 0 0 0 1 1zm10.003 20A4.996 4.996 0 0 1 24 21v-7a8 8 0 0 0-16 0v7a4.996 4.996 0 0 1-2.003 4z"
  }));
};

var _default = BellIcon;
exports["default"] = _default;