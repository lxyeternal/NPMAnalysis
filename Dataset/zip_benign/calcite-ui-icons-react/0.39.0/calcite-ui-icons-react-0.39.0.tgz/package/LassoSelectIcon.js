"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LassoSelectIcon = function LassoSelectIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.074 10.979l-.835.634A2.897 2.897 0 0 1 1 10.453c0-.92.658-1.415 1.261-2.271l.958.363a10.6 10.6 0 0 1-.644.867C2.15 9.94 2 10.15 2 10.453a2.035 2.035 0 0 0 .074.526zM9.538 2.59a5.73 5.73 0 0 1 1.782 1.26l.932-.469a6.57 6.57 0 0 0-2.766-1.875zM3.233 5.188a6.417 6.417 0 0 1-.207 1.359l.939.356a7.356 7.356 0 0 0 .267-1.667 3.618 3.618 0 0 1 .16-.89l-.775-.774a4.4 4.4 0 0 0-.384 1.616zm4.485-2.986l-.048-1a4.776 4.776 0 0 0-2.932.945l.707.707a3.908 3.908 0 0 1 2.25-.654zm6.757 5.664a10.947 10.947 0 0 0-1.157-3.006l-.882.444a9.334 9.334 0 0 1 .726 1.604zm-1.74 3.11l1.838 3.667-2.555 1.285-1.884-3.73L8.018 15.1V5.012L16 10.976zm-1.62-1h2.01L9 6.98v5.053l1.29-1.744 2.17 4.298.771-.388zM6 12.261c-.14-.011-.27-.037-.417-.037a8.77 8.77 0 0 0-.964.064 5.657 5.657 0 0 1-.59.044 2.749 2.749 0 0 1-.629-.1l-.92.7a3.549 3.549 0 0 0 1.549.4c.48 0 .963-.108 1.554-.108A3.821 3.821 0 0 1 6 13.25z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4.495 11.05a8.186 8.186 0 0 0 .695-3.067c.001-.027.006-.052.007-.078l.965.41a9.254 9.254 0 0 1-.648 2.888zm14.087-5.128l-.81.61a12.73 12.73 0 0 1 1.272 1.98l1-.307a13.602 13.602 0 0 0-1.462-2.283zm-4.224-2.13a8.128 8.128 0 0 1 2.02 1.285l.825-.62a9.226 9.226 0 0 0-2.6-1.648zm-4.541-.355a6.581 6.581 0 0 1 1.748-.237 6.919 6.919 0 0 1 .864.063l.245-.985a7.967 7.967 0 0 0-1.109-.078 7.501 7.501 0 0 0-2.023.276zM5.873 18.574a3.676 3.676 0 0 1-2.13-1.012L2.66 17.8a4.49 4.49 0 0 0 3.103 1.776zm-2.861-2.9c-.003-.058-.012-.11-.012-.17 0-.594.314-1.01.917-1.756.168-.208.349-.438.53-.682l-1.13-.169A4.135 4.135 0 0 0 2 15.504c0 .136.012.261.022.389zM6.534 6.3a4.422 4.422 0 0 1 1.458-1.97l-.29-1.016a5.53 5.53 0 0 0-2.078 2.599zm15.084 7.022a16.977 16.977 0 0 0-.788-3.266l-.974.299a16.1 16.1 0 0 1 .587 2.11zM18.757 17l2.189 4.515-2.894 1.456-2.266-4.621L13 22.17V9.51L23.266 17zm-1.597-1h3.038L14 11.478v7.624l1.954-2.68 2.552 5.201 1.11-.559zM11 18.854a8.011 8.011 0 0 0-2.454-.391c-.229 0-.444.011-.651.026l-.111 1.013c.243-.022.493-.039.763-.039a7.2 7.2 0 0 1 2.453.453z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.745 14H26.71a18.077 18.077 0 0 0-1.041-2.415l.883-.444A19.191 19.191 0 0 1 27.745 14zM14.097 4.312a8.209 8.209 0 0 1 1.338-.112 8.457 8.457 0 0 1 1.605.175l.351-.945a8.833 8.833 0 0 0-3.543-.094zm5.205-.282l-.344.927a11.524 11.524 0 0 1 2.384 1.39l.62-.764a12.602 12.602 0 0 0-2.66-1.553zm5.356 5.825l.886-.446a16.374 16.374 0 0 0-2.063-2.524l-.624.77a15.268 15.268 0 0 1 1.801 2.2zM9.86 6.72a6.54 6.54 0 0 1 2.325-1.82l-.253-.99a7.483 7.483 0 0 0-2.858 2.172zm-4.172 9.455l.846.531a10.342 10.342 0 0 0 1.405-3.142l-.998-.149a9.347 9.347 0 0 1-1.253 2.76zm.532 7.997a4.037 4.037 0 0 1-1.495-1.487l-1.053.14a5.038 5.038 0 0 0 2.348 2.381zm-2.008-3.436c-.002-.062-.01-.118-.01-.181 0-.776.393-1.325 1.13-2.241l-.853-.537A4.3 4.3 0 0 0 3.2 20.556c0 .11.013.208.019.313zm3.136-9.95c-.012.234-.041.44-.063.658l.989.148c.025-.25.06-.488.073-.757a7.466 7.466 0 0 1 .5-2.361l-.818-.665a8.491 8.491 0 0 0-.681 2.977zM16 25.695a11.883 11.883 0 0 0-2.9-.87v1.014a11.797 11.797 0 0 1 2.9.942zm12.75-6.344A22.564 22.564 0 0 0 28.28 16h-1.017a21.494 21.494 0 0 1 .419 2.571zM24.798 23l2.54 5.363-3.232 1.626-2.649-5.511L18 29.215V13.983L30.358 23zm-1.62-1h4.114L19 15.951v10.196l2.611-3.58 2.936 6.08 1.448-.729zM11 24.726c-.415.019-.81.049-1.18.087a11.701 11.701 0 0 1-1.195.088 3.418 3.418 0 0 1-.5-.046l-.191.985a4.494 4.494 0 0 0 .69.061 12.156 12.156 0 0 0 1.273-.09c.35-.037.72-.066 1.103-.085z"
  }));
};

var _default = LassoSelectIcon;
exports["default"] = _default;