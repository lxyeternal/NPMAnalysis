"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerLineIcon = function LayerLineIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.207 13.2A6.624 6.624 0 0 1 16 14.29L13.867 1.687a8.204 8.204 0 0 0-3.161-.674c-2.69 0-2.724.986-5.412.986a10.39 10.39 0 0 1-3.161-.512L0 14.09a9.158 9.158 0 0 0 3.793.711c3.665 0 4.749-1.6 8.414-1.6zM2.935 2.74A11.376 11.376 0 0 0 5.294 3a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.212 7.212 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852 10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363zM7 10H4V9h3V4h1v2h4v1H8v5H7z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 20.783A13.093 13.093 0 0 0 6.424 21.8c5.242 0 6.792-1.634 12.034-1.634a13.093 13.093 0 0 1 5.423 1.017l-3.05-18.105a12.674 12.674 0 0 0-4.52-.878c-3.848 0-3.892 1.6-7.74 1.6a15.028 15.028 0 0 1-4.52-.722zM8.57 4.8a9.805 9.805 0 0 0 4.25-.875 7.792 7.792 0 0 1 3.49-.725 11.86 11.86 0 0 1 3.63.615l2.675 15.872a16.25 16.25 0 0 0-4.157-.52 24.034 24.034 0 0 0-6.251.844 22.05 22.05 0 0 1-5.783.789 13.727 13.727 0 0 1-4.3-.65L4.848 4.343A16.193 16.193 0 0 0 8.57 4.8zM12 15H7v-1h5V5h1v3h5v1h-5v9h-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.074 3.211c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 3.9L1 28a16.273 16.273 0 0 0 7.538 1.8c6.876 0 8.048-2.6 14.924-2.6A33.153 33.153 0 0 1 31 28L27 3.9a26.401 26.401 0 0 0-5.926-.689zm2.388 22.99a22.381 22.381 0 0 0-7.77 1.347A20.422 20.422 0 0 1 8.539 28.8a15.989 15.989 0 0 1-6.43-1.366L5.794 5.217a15.6 15.6 0 0 0 4.544.651 17.42 17.42 0 0 0 5.445-.847 16.628 16.628 0 0 1 5.29-.81 26.164 26.164 0 0 1 5.05.518l3.651 21.999a37.286 37.286 0 0 0-6.313-.528zM16 11h7v1h-7v12h-1v-4H8v-1h7V8h1z"
  }));
};

var _default = LayerLineIcon;
exports["default"] = _default;