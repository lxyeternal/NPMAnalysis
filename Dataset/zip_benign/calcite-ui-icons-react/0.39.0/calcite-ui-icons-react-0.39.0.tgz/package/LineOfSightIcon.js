"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LineOfSightIcon = function LineOfSightIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 6h1v1H8zm0 3h1V8H8zm0 2h1v-1H8zm0 2h1v-1H8zm8 2v1H0v-1h6V8H5V7h1V4.572l5-3.57V15zm-6 0V2.944L7 5.087V15zm-6-4.605v-.842A3.373 3.373 0 0 1 .84 7.765a3.37 3.37 0 0 1 1.804-1.234 2.054 2.054 0 0 0-.323 1.073 1.467 1.467 0 0 0 1.6 1.46c.027 0 .053-.005.08-.006v-3.45c-.04 0-.08-.008-.12-.008A5.27 5.27 0 0 0 .066 7.4a.374.374 0 0 0-.032.365A3.893 3.893 0 0 0 4 10.395zM13 7h-1v1h1zm.354-2.288l-.707.707L14.227 7H14v1h.27l-1.623 1.623.707.707L16 7.684v-.325z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M.04 10.707a.467.467 0 0 1 .042-.457A6.589 6.589 0 0 1 4.852 8c.05 0 .098.01.148.011v4.313c-.034 0-.066.007-.1.007a1.835 1.835 0 0 1-2-1.826 2.567 2.567 0 0 1 .405-1.34 4.212 4.212 0 0 0-2.256 1.542A4.217 4.217 0 0 0 5 12.942v1.053C.89 13.948.054 10.735.04 10.707zM24 23v1H0v-1h8V11H6v-1h2V7l9-6v22zM16 2.868L9 7.535V23h7zM15 10h-2v2h2zm0-3h-2v2h2zm-3 6h-2v2h2zm3 0h-2v2h2zm-3 3h-2v2h2zm3 0h-2v2h2zm-3 3h-2v2h2zm3 0h-2v2h2zm-3-9h-2v2h2zm7 0h-1v1h1zm1 0v1h1.293l-2.646 2.646.707.707 3.854-3.853-3.854-3.854-.707.707L21.293 10z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M24 15h-1v-1h1zm2-1h-1v1h1zm1 0v1h1v-1zm5 16v1H0v-1h11V15H6v-1h5V8.6L22 2v28zm-11 0V3.767l-9 5.399V30zM5 17.995v-1.053a4.217 4.217 0 0 1-3.951-2.235 4.212 4.212 0 0 1 2.256-1.543 2.567 2.567 0 0 0-.405 1.341 1.835 1.835 0 0 0 2 1.826c.034 0 .066-.006.1-.007V12.01c-.05 0-.098-.01-.149-.01a6.589 6.589 0 0 0-4.77 2.25.467.467 0 0 0-.04.457c.013.028.849 3.24 4.959 3.288zM14 28h2v-2h-2zm3 0h2v-2h-2zm-3-3h2v-2h-2zm3 0h2v-2h-2zm-3-3h2v-2h-2zm3 0h2v-2h-2zm-3-3h2v-2h-2zm3 0h2v-2h-2zm-3-3h2v-2h-2zm3 0h2v-2h-2zm-3-3h2v-2h-2zm3 0h2v-2h-2zm0-3h2V8h-2zm12 4v1h.293l-3.646 3.646.707.707 4.854-4.853-4.854-4.854-.707.707L29.293 14z"
  }));
};

var _default = LineOfSightIcon;
exports["default"] = _default;