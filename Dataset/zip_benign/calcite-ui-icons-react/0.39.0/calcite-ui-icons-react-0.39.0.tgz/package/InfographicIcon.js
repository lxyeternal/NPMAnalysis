"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var InfographicIcon = function InfographicIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 1v14h16V1zm15 13H1V2h14zM4.5 10A1.5 1.5 0 1 0 3 8.5 1.502 1.502 0 0 0 4.5 10zm0-2a.5.5 0 1 1-.5.5.5.5 0 0 1 .5-.5zm3.489-1.3L6.209 10H9.79zm.008 1.392L8.49 9h-.984zM13 7h-3v3h3zm-1 2h-1V8h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.499 10A2.5 2.5 0 1 0 9 12.5 2.502 2.502 0 0 0 6.499 10zm0 4A1.5 1.5 0 1 1 8 12.5 1.501 1.501 0 0 1 6.5 14zm3.065 1h4.888l-2.49-4.864zm3.252-1h-1.645l.808-1.637zM16 15h4v-5h-4zm1-4h2v3h-2zM1 22h22V3H1zM2 4h20v17H2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8.5 20A3.5 3.5 0 1 0 5 16.5 3.5 3.5 0 0 0 8.5 20zm0-6A2.5 2.5 0 1 1 6 16.5 2.503 2.503 0 0 1 8.5 14zM27 13h-6v7h6zm-1 6h-4v-5h4zm-10-6l-3.5 7h7zm0 2.236L17.882 19h-3.764zM2 5v22h28V5zm27 21H3V6h26z"
  }));
};

var _default = InfographicIcon;
exports["default"] = _default;