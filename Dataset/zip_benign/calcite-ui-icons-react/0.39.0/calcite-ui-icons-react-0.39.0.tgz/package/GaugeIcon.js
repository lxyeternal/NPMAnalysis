"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GaugeIcon = function GaugeIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13.855 6.56l.73-.73A7.621 7.621 0 0 1 15.728 11h-5.121a2.78 2.78 0 0 0 .192-1 2.766 2.766 0 0 0-.035-.35l.829-.83A3.75 3.75 0 0 1 11.8 10h3a6.748 6.748 0 0 0-.945-3.44zM9.773 7.812l-.02.02A2.784 2.784 0 0 0 5.393 11H.27a7.788 7.788 0 0 1 12.874-6.852l.017-.017.707.707-3.536 3.536zM4.2 10a3.763 3.763 0 0 1 .795-2.298L2.857 5.564A6.765 6.765 0 0 0 1.2 10zM8 6.2a3.763 3.763 0 0 1 2.298.794l2.138-2.137a6.765 6.765 0 0 0-8.872 0l2.138 2.138A3.763 3.763 0 0 1 8 6.2zM14 2v2h2zM0 15h16v-1H0z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 6h-2V4zM12 3.2a11.747 11.747 0 0 1 7.444 2.649l.032-.032.707.707-4.972 4.972-.56-.56-.044.042A4.79 4.79 0 0 0 7.307 16H.25a11.9 11.9 0 0 1-.05-1A11.8 11.8 0 0 1 12 3.2zM6.2 15a5.761 5.761 0 0 1 .94-3.154L3.565 8.272A10.74 10.74 0 0 0 1.2 15zM4.228 7.52l3.533 3.534a5.77 5.77 0 0 1 7.393-.915l3.573-3.573a10.753 10.753 0 0 0-14.5.954zM22.8 15h-5a5.763 5.763 0 0 0-1.058-3.328l-.72.72a4.741 4.741 0 0 1 .67 3.608h7.058c.027-.33.05-.662.05-1a11.746 11.746 0 0 0-2.783-7.603l-.71.71A10.75 10.75 0 0 1 22.8 15zM0 21h24v-1H0z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9.282 22a6.789 6.789 0 0 1 11.36-5.96l.567.549 6.324-6.405-.71-.702-.015.015A15.783 15.783 0 0 0 .2 21c0 .338.03.668.05 1zM16 6.2a14.73 14.73 0 0 1 10.1 4.013l-4.914 4.977a7.76 7.76 0 0 0-10.823.434l-4.947-4.948A14.749 14.749 0 0 1 16 6.2zM4.742 11.417l4.977 4.977A7.748 7.748 0 0 0 8.2 21h-7a14.725 14.725 0 0 1 3.542-9.583zm22.86.422l.714-.723A15.724 15.724 0 0 1 31.8 21c0 .338-.03.668-.05 1h-9.032a6.625 6.625 0 0 0-.823-4.38l.721-.731A7.742 7.742 0 0 1 23.8 21h7a14.715 14.715 0 0 0-3.198-9.16zM30 9h-2V7zm2 18v1H0v-1z"
  }));
};

var _default = GaugeIcon;
exports["default"] = _default;