"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DistributeHeightEvenlyIcon = function DistributeHeightEvenlyIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 16h7V9H0zm1-6h5v5H1zM0 7h7V0H0zm1-6h5v5H1zm15 15H9v-1h7zm0-15H9V0h7zm-3 2.735v8.56l1.62-1.62.706.707-2.809 2.81-2.809-2.81.707-.707L12 12.26V3.77l-1.585 1.585-.707-.707 2.81-2.81 2.808 2.81-.707.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 2h7v1h-7zm0 20h7v-1h-7zm5-15.293l1.646 1.646.707-.707L17.5 3.793l-3.854 3.853.707.707L17 5.707v12.586l-2.646-2.646-.707.707 3.853 3.853 3.854-3.854-.707-.707L18 18.293V5.707zM2 13h9v9H2zm1 8h7v-7H3zM2 2h9v9H2zm1 8h7V3H3z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18 3h11v1H18zm0 26h11v-1H18zm4-4.707l-1.646-1.646-.707.707 3.853 3.853 3.854-3.854-.707-.707L24 25.293V6.707l2.646 2.646.707-.707L23.5 4.793l-3.854 3.853.707.707L23 6.707v18.586zM3 17h12v12H3zm1 11h10V18H4zM3 3h12v12H3zm1 11h10V4H4z"
  }));
};

var _default = DistributeHeightEvenlyIcon;
exports["default"] = _default;