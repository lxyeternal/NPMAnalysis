"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GraphMovingAverageIcon = function GraphMovingAverageIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 8.333l1 1V14H8V7.877l1-.4V13h1zM9 3.941V2h1v1.945a1.625 1.625 0 0 1 .666.389l.334.333V1H8v3.323l.887-.355c.037-.015.076-.015.113-.027zM13 5v1.667l1 1V6h1v2.816l.184.184H16V5zm2 7.999h-1v-.935a1.64 1.64 0 0 1-.666-.398L13 11.333V14h3v-2h-1zM2 1H1v15h15v-1H2zm12.707 9L9.621 4.913 4.404 7H3v1h1.5l4.88-1.913L14.292 11H16v-1zM3 9h3v5H3zm2 1H4v3h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 11.536l1 1V20h-4V9.946l.965-.446.035.036V19h2zM12 2h2v2.464l1 1V1h-4v3.439l1-.462zM5 12h4v8H5zm1 7h2v-6H6zM18 6h2v4.464l.536.536H21V5h-4v2.464l1 1zm2 13h-2v-3.464l-1-1V20h4v-4h-1zM2 1H1v22h22v-1H2zm17.707 12l-7.1-7.1L5.89 9H5v1h1l6.393-2.9 6.9 6.9H21v-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 29h27v1H2V2h1zM16 3h3v2.465l1 1V2h-5v4.122l1-.631zm3 23h-3V11.404l-1 .632V27h5V13.535l-1-1zM6 16h5v11H6zm1 10h3v-9H7zm21 0h-3v-7.464l-1-1V27h5v-7h-1zM25 9h3v5.464l.536.536H29V8h-5v2.465l1 1zm2.707 8L17.571 6.864 7.855 13H6v1h2.145l9.284-5.864L27.293 18H29v-1z"
  }));
};

var _default = GraphMovingAverageIcon;
exports["default"] = _default;