"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FormFieldIcon = function FormFieldIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 13a1.502 1.502 0 0 0 1.5-1.5v-7A1.502 1.502 0 0 0 14.5 3h-13A1.502 1.502 0 0 0 0 4.5v7A1.502 1.502 0 0 0 1.5 13zM1 11.5v-7a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5zm2.5-1.057A2.08 2.08 0 0 1 2 11v-1c.74 0 .948-.417 1-.571v-2.86C2.952 6.426 2.749 6 2 6V5a2.08 2.08 0 0 1 1.5.557A2.08 2.08 0 0 1 5 5v1c-.74 0-.948.417-1 .571v2.86c.048.143.251.569 1 .569v1a2.08 2.08 0 0 1-1.5-.557zM7 11H6v-1h1zm2 0H8v-1h1zm2 0h-1v-1h1zm2 0h-1v-1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.5 8.557A2.08 2.08 0 0 1 7 8v1c-.74 0-.948.417-1 .571v5.86c.048.143.251.569 1 .569v1a2.08 2.08 0 0 1-1.5-.557A2.08 2.08 0 0 1 4 17v-1c.74 0 .948-.417 1-.571v-5.86C4.952 9.426 4.749 9 4 9V8a2.08 2.08 0 0 1 1.5.557zM23 6.5v12a1.502 1.502 0 0 1-1.5 1.5h-19A1.502 1.502 0 0 1 1 18.5v-12A1.502 1.502 0 0 1 2.5 5h19A1.502 1.502 0 0 1 23 6.5zm-1 0a.5.5 0 0 0-.5-.5h-19a.5.5 0 0 0-.5.5v12a.5.5 0 0 0 .5.5h19a.5.5 0 0 0 .5-.5zM12 17h1v-1h-1zm-2 0h1v-1h-1zm-2 0h1v-1H8zm6 0h1v-1h-1zm4 0h1v-1h-1zm-2 0h1v-1h-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.5 7h-25A1.502 1.502 0 0 0 2 8.5v15A1.502 1.502 0 0 0 3.5 25h25a1.502 1.502 0 0 0 1.5-1.5v-15A1.502 1.502 0 0 0 28.5 7zm.5 16.5a.5.5 0 0 1-.5.5h-25a.5.5 0 0 1-.5-.5v-15a.5.5 0 0 1 .5-.5h25a.5.5 0 0 1 .5.5zM7.5 11.557A2.08 2.08 0 0 1 9 11v1c-.74 0-.948.417-1 .571v6.86c.048.143.251.569 1 .569v1a2.086 2.086 0 0 1-1.43-.5h-.14A2.086 2.086 0 0 1 6 21v-1c.74 0 .948-.417 1-.571v-6.86C6.952 12.426 6.749 12 6 12v-1a2.08 2.08 0 0 1 1.5.557zM13 20h1v1h-1zm-2 0h1v1h-1zm10 0h1v1h-1zm4 0h1v1h-1zm-2 0h1v1h-1zm-4 0h1v1h-1zm-2 0h1v1h-1zm-2 0h1v1h-1z"
  }));
};

var _default = FormFieldIcon;
exports["default"] = _default;