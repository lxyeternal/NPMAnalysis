"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var HighlighterIcon = function HighlighterIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15.04 2.332L13.667.961A1 1 0 0 0 12.34.883L3.033 8.23l-.504 3.533L.574 13.72l2.561.853 1.1-1.1 3.534-.505 7.348-9.308a1 1 0 0 0-.078-1.327zM3.853 9.561l2.585 2.585-2.262.324-.647-.647zm-.99 3.867l-.438-.147.574-.574.293.293zm4.592-1.68L4.25 8.545l8.71-6.876 1.371 1.371z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22.688 3.525l-2.213-2.212a1.253 1.253 0 0 0-1.704-.06L5.053 13.226 4.05 17.244 1.274 20.02l4.061 1.353 1.42-1.42 4.018-1.005L22.75 5.227a1.254 1.254 0 0 0-.061-1.702zM5.77 14.478l3.751 3.751-2.869.717-1.6-1.6zm-.706 5.75l-1.94-.647L4.5 18.207 5.793 19.5zM21.995 4.57l-11.52 13.197-4.243-4.243L19.427 2.007a.251.251 0 0 1 .34.013l2.214 2.213a.25.25 0 0 1 .014.338z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29.703 4.996l-2.7-2.7a1.492 1.492 0 0 0-2.028-.084L6 18.268v4.025l-4.344 4.344 4.943 2.471L9.707 26h4.025L29.788 7.025a1.49 1.49 0 0 0-.085-2.029zM6.401 27.892l-3.057-1.53L5 24.708 7.293 27zM9.293 25L8 26.293 5.707 24 7 22.707v-3L12.293 25zM29.024 6.38L13.469 24.762l-6.231-6.231L25.62 2.976a.496.496 0 0 1 .677.028l2.7 2.7a.498.498 0 0 1 .027.676z"
  }));
};

var _default = HighlighterIcon;
exports["default"] = _default;