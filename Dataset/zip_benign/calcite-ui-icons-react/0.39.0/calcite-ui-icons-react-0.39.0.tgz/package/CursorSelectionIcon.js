"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CursorSelectionIcon = function CursorSelectionIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.531 15H1v-1.271l1.116-1.53zm6.011-6.197a15.32 15.32 0 0 0-.852-2.156A7.708 7.708 0 0 1 7 1H1v4.741l7.174 5.235H4.717l1.838 3.667-.71.357H11v-1.246c-1.417-2.834-1.035-3.317-1.458-4.951z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14 14V6.026a6.874 6.874 0 0 0-3.739 1.67l-.265-.636c-.053-.128-.104-.23-.156-.342a7.952 7.952 0 0 1 4.16-1.7V2H8V1h7v14h-3v-1zM5 1v1h1.008q.043.525.097.955l.992-.125A24.482 24.482 0 0 1 7 1.876V1zm2.82 6.138l.87-.49a8.577 8.577 0 0 0-.566-.864 4.43 4.43 0 0 1-.568-.945l-.922.389a5.428 5.428 0 0 0 .68 1.143 7.47 7.47 0 0 1 .505.767zm1.1 3.882c.012.059.02.113.033.174l.977-.213c-.07-.324-.11-.609-.15-.894a10.735 10.735 0 0 0-.239-1.284l-.969.252c.063.242.106.458.14.668a1.81 1.81 0 0 1 .208 1.297zM11 13.754a22.007 22.007 0 0 1-.377-.79l-.912.412c.086.19.195.41.3.624H8v.18l.41.82H11zM2 4V2h1V1H1v2.884L1.159 4zm2 11.928l-1.884-3.73L0 15.1V5.012l8.174 5.964H4.717l1.838 3.667zm.442-1.342l.77-.388-2.115-4.222h2.01L1 6.98v5.053l1.271-1.744z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 10.24V2h6c.145 6.605 1.593 6.25 3.866 8.379 1.822 1.706 2.052 4.224 2.33 6.39.161 1.25.497 1.83 2.345 5.231h-8.56l.965-.485L7.756 17h4.51zm1.786 8.11L3 20.799V22h3.576z",
      opacity: ".25"
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 2h12v20h-3v-1h2V9.05a10.327 10.327 0 0 0-5.253 1.91c-.154-.249-.35-.542-.558-.837A11.364 11.364 0 0 1 21 8.048V3H10zM4 3h1V2H3v2h1zm8 19h2v-1h-2zM3 8h1V6H3zm5.067-3.954l.996-.09A17.355 17.355 0 0 1 9 2H7v1h1v.022c.017.362.038.7.067 1.024zm5.803 10.406l.97-.238a13.604 13.604 0 0 0-.594-1.81l-.088-.21-.914.406.073.173a12.677 12.677 0 0 1 .553 1.68zm1.277 1.858l-.996.091c.016.165.032.33.053.497a6.758 6.758 0 0 0 .413 1.631l.932-.365a5.747 5.747 0 0 1-.353-1.394 12.46 12.46 0 0 1-.049-.46zm-5.109-8.627a6.726 6.726 0 0 1-.669-1.774l-.973.233a7.701 7.701 0 0 0 .773 2.035zm2.828 2.696a11.45 11.45 0 0 0-.989-.802c-.211-.158-.424-.317-.632-.49l-.639.77c.222.183.447.352.671.52a10.747 10.747 0 0 1 .908.732zm3.584 9.592l-.888.457c.134.262.274.55.417.876l.305.696h1.257L17 21s-.405-.749-.55-1.03zM7.757 17l2.189 4.515-2.894 1.456-2.266-4.621L2 22.17V9.51L12.266 17zM6.16 16h3.038L3 11.478v7.624l1.954-2.68 2.552 5.201 1.11-.559z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4 15.443V3h9a27.182 27.182 0 0 0 .276 3.992c.992 6.818 3.996 4.572 5.82 11.309.812 2.994.217 5.597 2.03 9.699h-9.96l-2.37-5h5.562zm1.456 9.035L4 26.473V28h3.149z",
    opacity: ".25"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.254 27.964l-.47-.964H13v1h-.738c-.005-.012-.003-.024-.008-.036zm6.485-5.176c.11.853.198 1.508.341 2.186l.979-.207c-.136-.641-.222-1.278-.328-2.106zm-.607-4.226a12.05 12.05 0 0 1 .367 2.054l.996-.097a12.988 12.988 0 0 0-.398-2.218zm-1.687-3.766a7.908 7.908 0 0 1 1.001 1.77l.924-.38a8.835 8.835 0 0 0-1.128-1.994zm-1.42-1.559l.72-.695a8.005 8.005 0 0 1-1.26-1.606l-.866.502a9.102 9.102 0 0 0 1.406 1.8zm-2.28-3.912l.96-.275a15.776 15.776 0 0 1-.429-2.058l-.99.145a16.771 16.771 0 0 0 .458 2.188zM5 7H4v2h1zm0-3h1V3H4v2h1zm5-1H8v1h2zm5 25h2v-1h-2zM5 11H4v2h1zm9.997-7.213c.003.074.008.14.012.213H28v5.97a14.314 14.314 0 0 0-8.996 3.411 8.01 8.01 0 0 1 .454.932A13.213 13.213 0 0 1 28 10.97V27h-5v1h6V3H14.999c-.002.262-.014.522-.002.787zm-2.94 1.147l.998-.067c-.021-.31-.045-.622-.055-.972S13 3 13 3h-1s-.011.635 0 1 .037.636.057.934zM5.456 24.478L2 29.215V13.983L14.358 23H8.797l2.54 5.363-3.232 1.626zM3 26.148l2.611-3.58 2.936 6.079 1.448-.729L7.178 22h4.113L3 15.951zM19 28h2v-1h-2z"
  }));
};

var _default = CursorSelectionIcon;
exports["default"] = _default;