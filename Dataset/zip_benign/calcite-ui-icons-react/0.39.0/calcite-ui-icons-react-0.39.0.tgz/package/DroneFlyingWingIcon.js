"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DroneFlyingWingIcon = function DroneFlyingWingIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.458 8.41L2.622 9.914.854 8.146A.5.5 0 0 0 0 8.5v2.572a.5.5 0 0 0 .186.389l2.103 1.702a2.823 2.823 0 0 0 2.451.542l8.881-2.22a.5.5 0 0 0 .357-.338l2-6.5a.5.5 0 0 0-.03-.37l-1-2a.505.505 0 0 0-.224-.224l-2-1A.5.5 0 0 0 12 1.5v1.833l-1.845 2.46a1.504 1.504 0 0 1-1.74.5l-.153-.059a.504.504 0 0 0-.427.033l-1.275.728a.5.5 0 0 0-.036.847.324.324 0 0 1-.066.567zM1 10.833V9.707l1.063 1.063.421 1.265zm13.127-7.96l.385.77L13 3.138v-.83zM6.823 9.34a1.324 1.324 0 0 0 .73-1.762l.574-.327a2.51 2.51 0 0 0 2.83-.86l1.727-2.303 2.194.731-1.773 5.763-8.607 2.151a1.827 1.827 0 0 1-.719.022l-.654-1.964z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23.964 7.064l-1-2.5a.5.5 0 0 0-.272-.276l-3-1.25A.5.5 0 0 0 19 3.5v2.074l-3.458 4.319a2.495 2.495 0 0 1-2.827.779l-.372-.14a.5.5 0 0 0-.42.03l-1.962 1.09a.5.5 0 0 0-.035.854.763.763 0 0 1-.134 1.338l-6.72 2.77-2.218-2.218A.5.5 0 0 0 0 14.75v2.786a.5.5 0 0 0 .162.368l2.06 1.893a4.381 4.381 0 0 0 2.956 1.147 4.323 4.323 0 0 0 .836-.082l14.583-2.872a.5.5 0 0 0 .382-.35l3-10.25a.492.492 0 0 0-.015-.326zM4.328 19.828l-.677-2.37 6.522-2.69a1.765 1.765 0 0 0 .832-2.55l1.203-.668.155.057a3.485 3.485 0 0 0 3.96-1.09l3.495-4.364 3.138 1.177-2.85 9.738L5.82 19.882a3.354 3.354 0 0 1-1.492-.054zM1 15.957l1.6 1.6c.013.013.033.014.047.025l.466 1.633c-.07-.055-.149-.094-.215-.154L1 17.316zM22.114 5.131l.384.96L20 5.154V4.25z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3.064 25.771a3.45 3.45 0 0 0 3.029.96l21.493-3.739a.5.5 0 0 0 .394-.354l4-14a.501.501 0 0 0-.005-.296l-1-3a.5.5 0 0 0-.317-.317l-3-1A.501.501 0 0 0 27 4.5v1.802l-6.05 6.427a3.49 3.49 0 0 1-3.76.885l-.767-.283a.505.505 0 0 0-.413.03l-2.65 1.45a.5.5 0 0 0-.036.856 1.198 1.198 0 0 1-.195 2.104l-9.604 4.046-2.671-2.67A.5.5 0 0 0 0 19.5v3a.5.5 0 0 0 .146.354zm11.79-8.9a2.195 2.195 0 0 0-.42-1.508l1.856-1.015.554.204a4.492 4.492 0 0 0 4.835-1.137l5.93-6.301 3.296 1.648-3.8 13.3-21.184 3.684a2.465 2.465 0 0 1-1.112-.071l-.749-2.997 9.458-3.985a2.196 2.196 0 0 0 1.336-1.823zm15.25-10.975l.54 1.617L28 6.19v-.998zM1 20.707l2.048 2.048.529 2.115L1 22.293zm3.39 5.356h.001z"
  }));
};

var _default = DroneFlyingWingIcon;
exports["default"] = _default;