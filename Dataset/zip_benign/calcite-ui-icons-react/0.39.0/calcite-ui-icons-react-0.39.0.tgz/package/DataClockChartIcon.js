"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DataClockChartIcon = function DataClockChartIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2.445 8h-1A7.062 7.062 0 0 1 8 1.443v1.02A6.032 6.032 0 0 0 2.451 7.89c-.004.037-.003.074-.006.111zm10.777-3.34A6.036 6.036 0 0 1 14.568 8h1A7.061 7.061 0 0 0 9 1.444v1.004a6.055 6.055 0 0 1 4.222 2.213zm1.337 4.462A6.033 6.033 0 0 1 9 14.548v1.02A7.06 7.06 0 0 0 15.566 9h-1c-.004.04-.003.081-.007.122zM3.79 12.35A6.036 6.036 0 0 1 2.442 9h-1A7.061 7.061 0 0 0 8 15.565v-1.003a6.055 6.055 0 0 1-4.211-2.212zm5.933-7.738A4.075 4.075 0 0 0 9 4.464v1.004a3.144 3.144 0 0 1 .423.098A3.07 3.07 0 0 1 11.525 8h1.015a4.07 4.07 0 0 0-2.818-3.388zM5.48 9H4.464A4.007 4.007 0 0 0 8 12.54v-1.004a3.105 3.105 0 0 1-.417-.097A3.07 3.07 0 0 1 5.48 9zM8 5.466v-1A4.006 4.006 0 0 0 4.465 8H5.48a3.038 3.038 0 0 1 .085-.417A3.063 3.063 0 0 1 8 5.466zm1 6.075v1A4.01 4.01 0 0 0 12.542 9h-1.016a3.026 3.026 0 0 1-.087.423A3.063 3.063 0 0 1 9 11.54zM8.5 7A1.5 1.5 0 1 0 10 8.5 1.5 1.5 0 0 0 8.5 7z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M13 3.125v-.9A10.282 10.282 0 0 1 22.775 12h-.9A9.396 9.396 0 0 0 13 3.125zm-1 0v-.9A10.282 10.282 0 0 0 2.225 12h.9A9.397 9.397 0 0 1 12 3.125zM3.125 13h-.9A10.28 10.28 0 0 0 12 22.775v-.9A9.397 9.397 0 0 1 3.125 13zM13 21.875v.9A10.28 10.28 0 0 0 22.775 13h-.9A9.396 9.396 0 0 1 13 21.875zM6.225 12h1.026A5.273 5.273 0 0 1 12 7.25V6.226A6.303 6.303 0 0 0 6.225 12zm12.55 1h-1.026A5.273 5.273 0 0 1 13 17.75v1.025A6.303 6.303 0 0 0 18.775 13zM12 18.775v-1.026A5.273 5.273 0 0 1 7.25 13H6.226A6.303 6.303 0 0 0 12 18.775zm1-12.55v1.026A5.273 5.273 0 0 1 17.75 12h1.025A6.303 6.303 0 0 0 13 6.225zM9.25 12h1.008A2.303 2.303 0 0 1 12 10.258V9.251A3.29 3.29 0 0 0 9.25 12zm6.5 1h-1.008A2.303 2.303 0 0 1 13 14.742v1.007A3.29 3.29 0 0 0 15.75 13zM13 9.25v1.008A2.303 2.303 0 0 1 14.742 12h1.007A3.29 3.29 0 0 0 13 9.25zm-1 6.5v-1.008A2.303 2.303 0 0 1 10.258 13H9.251A3.29 3.29 0 0 0 12 15.75z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4.225 16h-1A13.296 13.296 0 0 1 16 3.225v1A12.296 12.296 0 0 0 4.225 16zm0 1h-1A13.296 13.296 0 0 0 16 29.775v-1A12.296 12.296 0 0 1 4.225 17zm24.55-1h1A13.296 13.296 0 0 0 17 3.225v1A12.296 12.296 0 0 1 28.775 16zM17 28.775v1A13.296 13.296 0 0 0 29.775 17h-1A12.296 12.296 0 0 1 17 28.775zm0-20.55v1A7.3 7.3 0 0 1 23.775 16h1A8.298 8.298 0 0 0 17 8.225zM8.225 16h1A7.3 7.3 0 0 1 16 9.225v-1A8.298 8.298 0 0 0 8.225 16zm16.55 1h-1A7.3 7.3 0 0 1 17 23.775v1A8.298 8.298 0 0 0 24.775 17zM16 24.775v-1A7.3 7.3 0 0 1 9.225 17h-1A8.298 8.298 0 0 0 16 24.775zM20.75 17h-1A3.29 3.29 0 0 1 17 19.75v1A4.278 4.278 0 0 0 20.75 17zm-8.5-1h1A3.29 3.29 0 0 1 16 13.25v-1A4.278 4.278 0 0 0 12.25 16zM16 20.75v-1A3.29 3.29 0 0 1 13.25 17h-1A4.278 4.278 0 0 0 16 20.75zm1-8.5v1A3.29 3.29 0 0 1 19.75 16h1A4.278 4.278 0 0 0 17 12.25z"
  }));
};

var _default = DataClockChartIcon;
exports["default"] = _default;