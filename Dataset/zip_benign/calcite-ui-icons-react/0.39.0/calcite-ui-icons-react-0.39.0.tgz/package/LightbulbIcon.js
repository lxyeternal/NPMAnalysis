"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LightbulbIcon = function LightbulbIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.01 11.035a3.81 3.81 0 0 1 .135-.904 3.174 3.174 0 0 1 .426-.657 6.33 6.33 0 0 0 1.479-3.576 4.57 4.57 0 0 0-1.555-3.72 4.497 4.497 0 0 0-5.9-.075A4.557 4.557 0 0 0 3.95 5.897a6.33 6.33 0 0 0 1.48 3.577 3.15 3.15 0 0 1 .426.658 3.795 3.795 0 0 1 .134.903 4.948 4.948 0 0 0 .1.817c.013.059.036.095.051.148h-.312l.45 1.5-.365 1.215 1.487.967a2.02 2.02 0 0 0 2.2-.001l1.487-.966-.364-1.215.449-1.5h-.312c.015-.053.038-.09.051-.148a4.948 4.948 0 0 0 .1-.817zm-1.953 3.807a1.036 1.036 0 0 1-1.113 0l-.857-.557.235-.785-.15-.5h2.656l-.15.5.235.785zM9 12V9H8v3h-.79a1.018 1.018 0 0 1-.145-.365 3.897 3.897 0 0 1-.078-.66 4.702 4.702 0 0 0-.17-1.118 3.312 3.312 0 0 0-.586-.981 5.377 5.377 0 0 1-1.283-3.038 3.57 3.57 0 0 1 1.29-2.97 3.504 3.504 0 0 1 4.595.06 3.576 3.576 0 0 1 1.219 2.91 5.377 5.377 0 0 1-1.283 3.038 3.32 3.32 0 0 0-.585.98 4.716 4.716 0 0 0-.171 1.119 3.897 3.897 0 0 1-.078.66 1.138 1.138 0 0 1-.14.365zm1-4H7V7h3z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.662 1.204h-.324A6.35 6.35 0 0 0 6 7.496c0 1.866 1.182 3.69 2.045 5.023a6.572 6.572 0 0 1 .752 1.324 10.398 10.398 0 0 1 .114 1.235 3.628 3.628 0 0 0 .77 2.473l-.518.453a.804.804 0 0 0 .066 1.264l.414.293-.364.263a.804.804 0 0 0-.333.689.794.794 0 0 0 .37.641l2.45 1.625a1.311 1.311 0 0 0 .723.22h.016a1.316 1.316 0 0 0 .73-.22l2.43-1.613a.803.803 0 0 0 .059-1.34l-.367-.265.418-.295a.806.806 0 0 0 .062-1.263l-.518-.452a3.626 3.626 0 0 0 .77-2.476 10.735 10.735 0 0 1 .114-1.232 6.64 6.64 0 0 1 .75-1.323C17.817 11.186 19 9.358 19 7.496a6.35 6.35 0 0 0-6.338-6.292zm2.245 19.265l-2.225 1.476a.41.41 0 0 1-.185.053h-.002a.32.32 0 0 1-.177-.053l-2.225-1.475 1.264-.923-1.35-.953.68-.594h3.625l.68.594-1.35.953zM12 17v-3h1v3zm4.114-5.023a5.595 5.595 0 0 0-.897 1.702 11.287 11.287 0 0 0-.126 1.344A2.598 2.598 0 0 1 14.46 17H14v-3.421l1.075-3.325-.951-.309L13.136 13h-1.272l-.988-3.055-.951.309L11 13.579V17h-.46a2.59 2.59 0 0 1-.63-1.973 11.574 11.574 0 0 0-.127-1.348 5.597 5.597 0 0 0-.898-1.704C8.089 10.748 7 9.067 7 7.496a5.343 5.343 0 0 1 5.338-5.292h.324A5.343 5.343 0 0 1 18 7.496c0 1.566-1.09 3.251-1.886 4.48z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.65 4.72a8.333 8.333 0 0 0-6.16-2.52 8.323 8.323 0 0 0-6.14 2.519 8.45 8.45 0 0 0-2.093 6.329 11.328 11.328 0 0 0 2.71 6.473 3.622 3.622 0 0 1 1.038 2.702L12 20.5a3.238 3.238 0 0 0 .446 1.728l-.227.295A1.32 1.32 0 0 0 12.5 24.4l.14.1-.272.193a.992.992 0 0 0 .002 1.615l.27.192-.272.193a.992.992 0 0 0 .012 1.621l1.17.792a5.237 5.237 0 0 0 5.9 0l1.182-.8a.992.992 0 0 0-.002-1.614l-.27-.192.272-.193a.992.992 0 0 0-.002-1.615l-.27-.192.138-.099a1.321 1.321 0 0 0 .282-1.88l-.226-.294A3.239 3.239 0 0 0 21 20.5l-.005-.277a3.626 3.626 0 0 1 1.04-2.703 11.321 11.321 0 0 0 2.708-6.472A8.446 8.446 0 0 0 22.65 4.72zm-3.76 23.558a4.243 4.243 0 0 1-4.78 0l-1.159-.771 1.41-1.007-1.41-.993 1.41-1.007-1.28-.915a.32.32 0 0 1-.068-.454l.15-.197a.593.593 0 0 0 .225.066h6.224a.594.594 0 0 0 .225-.066l.15.195a.328.328 0 0 1 .063.243.322.322 0 0 1-.132.214l-1.278.914 1.409.993-1.41 1.007 1.42.986zM17 22h-1v-4h1zm6.745-11.01a10.463 10.463 0 0 1-2.513 5.932 4.542 4.542 0 0 0-1.237 3.328l.005.25a1.834 1.834 0 0 1-.536 1.5H18v-4.421l1.075-3.325-.951-.309L17.136 17h-1.272l-.988-3.055-.951.309L15 17.579V22h-1.464A1.834 1.834 0 0 1 13 20.5l.005-.25a4.543 4.543 0 0 0-1.24-3.33 10.463 10.463 0 0 1-2.51-5.93 7.463 7.463 0 0 1 1.829-5.593A7.332 7.332 0 0 1 16.49 3.2a7.342 7.342 0 0 1 5.426 2.198 7.46 7.46 0 0 1 1.83 5.591z"
  }));
};

var _default = LightbulbIcon;
exports["default"] = _default;