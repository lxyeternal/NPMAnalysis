"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DataCloudIcon = function DataCloudIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.5 1C3.612 1 1 1.984 1 3.48v8c0 1.43 2.398 2.41 6.013 2.492a3.021 3.021 0 0 1 .215-1.001C3.594 12.922 2 11.973 2 11.479V7.906a9.4 9.4 0 0 0 3.995 1.038 20.073 20.073 0 0 0 3.007 0A9.404 9.404 0 0 0 13 7.906v1.14a3.296 3.296 0 0 1 1 .33V3.48C14 1.984 11.388 1 7.5 1zM13 6.48c0 .506-1.66 1.5-5.5 1.5S2 6.985 2 6.48V4.905a9.35 9.35 0 0 0 3.996 1.02 20.97 20.97 0 0 0 2.997 0A9.364 9.364 0 0 0 13 4.906zM7.5 5C3.66 5 2 3.986 2 3.48s1.66-1.5 5.5-1.5 5.5.993 5.5 1.5S11.34 5 7.5 5zm7.465 7.352A2.577 2.577 0 0 0 12.5 10a2.47 2.47 0 0 0-2.184 1.425.916.916 0 0 0-.316-.061 1.037 1.037 0 0 0-.992 1.004A1.922 1.922 0 0 0 8 14.09 1.835 1.835 0 0 0 9.75 16h4.483A1.844 1.844 0 0 0 16 14.09a1.92 1.92 0 0 0-1.035-1.738zM14.205 15H9.75a.842.842 0 0 1-.75-.91.926.926 0 0 1 .464-.832 1 1 0 0 0 .54-.817.83.83 0 0 0 .292.053 1.067 1.067 0 0 0 .914-.62A1.483 1.483 0 0 1 12.5 11a1.59 1.59 0 0 1 1.473 1.479 1.002 1.002 0 0 0 .553.772.92.92 0 0 1 .474.84.856.856 0 0 1-.795.909z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21.254 17.528A4.165 4.165 0 0 0 17.094 14a4.22 4.22 0 0 0-3.685 2.137 1.717 1.717 0 0 0-.534-.092 1.67 1.67 0 0 0-1.556 1.04A2.996 2.996 0 0 0 12 23h8.018A2.918 2.918 0 0 0 23 20.136a2.858 2.858 0 0 0-1.746-2.608zM19.994 22h-7.54l-.46-.003a1.995 1.995 0 0 1-.448-3.938l.506-.118.195-.481a.67.67 0 0 1 .628-.415.734.734 0 0 1 .225.043l.777.252.402-.711A3.231 3.231 0 0 1 17.094 15a3.18 3.18 0 0 1 3.17 2.67l.08.552.51.223A1.863 1.863 0 0 1 22 20.137 1.916 1.916 0 0 1 19.995 22zM11.5 2C6.78 2 2 3.03 2 5v12.58c0 1.64 2.676 2.695 6 3.123v-1.006c-3.16-.426-5-1.381-5-2.118v-6.248C4.643 12.429 8.082 13 11.5 13s6.857-.57 8.5-1.67v2.568a5.22 5.22 0 0 1 1 .856V5c0-1.97-4.78-3-9.5-3zM20 9.848C20 10.726 16.689 12 11.5 12S3 10.726 3 9.848V6.41C4.643 7.457 8.082 8 11.5 8s6.857-.543 8.5-1.589zM11.5 7C6 7 3 5.679 3 5s3-2 8.5-2S20 4.321 20 5s-3 2-8.5 2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.04 26.666C7.17 26.196 4 24.783 4 23.489v-7.986c2.034 1.58 6.873 2.42 11.5 2.42a36.915 36.915 0 0 0 5.435-.395 6.21 6.21 0 0 1 1.15-.196A12.26 12.26 0 0 0 27 15.502v3.669a6.334 6.334 0 0 1 1 1.292V7.096h-.015C27.987 7.063 28 7.033 28 7c0-2.56-6.288-3.9-12.5-3.9S3 4.44 3 7c0 .033.013.063.015.096H3v16.393c0 2.312 4.335 3.75 9.237 4.192a4.663 4.663 0 0 1-.198-1.015zM15.5 4.1C22.625 4.1 27 5.79 27 7s-4.375 2.9-11.5 2.9S4 8.21 4 7s4.375-2.9 11.5-2.9zM4 8.624c2.011 1.499 6.774 2.276 11.5 2.276s9.489-.777 11.5-2.276v5.201c0 1.294-4.375 3.099-11.5 3.099S4 15.119 4 13.825zm23.815 14.264a5.283 5.283 0 0 0-9.888-1.809 2.091 2.091 0 0 0-2.783 1.84A3.715 3.715 0 0 0 16.722 30h9.535a3.718 3.718 0 0 0 1.558-7.112zM26.233 29h-9.51A2.726 2.726 0 0 1 14 26.277a2.698 2.698 0 0 1 1.57-2.455l.525-.247.046-.577a1.114 1.114 0 0 1 1.113-1.038 1.101 1.101 0 0 1 .354.067l.793.266.403-.733a4.283 4.283 0 0 1 8.02 1.465l.076.548.505.227a2.719 2.719 0 0 1-1.172 5.2z"
  }));
};

var _default = DataCloudIcon;
exports["default"] = _default;