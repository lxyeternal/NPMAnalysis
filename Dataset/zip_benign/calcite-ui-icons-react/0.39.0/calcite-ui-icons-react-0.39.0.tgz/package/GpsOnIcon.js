"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GpsOnIcon = function GpsOnIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 13.75V16h1v-2.25A5.265 5.265 0 0 0 13.75 9H16V8h-2.25A5.265 5.265 0 0 0 9 3.25V1H8v2.25A5.265 5.265 0 0 0 3.25 8H1v1h2.25A5.265 5.265 0 0 0 8 13.75zm.5-9.55a4.3 4.3 0 1 1-4.3 4.3 4.304 4.304 0 0 1 4.3-4.3zm0 6.8A2.5 2.5 0 1 0 6 8.5 2.5 2.5 0 0 0 8.5 11zm0-4A1.5 1.5 0 1 1 7 8.5 1.5 1.5 0 0 1 8.5 7z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M24 12h-3.225A8.287 8.287 0 0 0 13 4.225V1h-1v3.225A8.287 8.287 0 0 0 4.225 12H1v.955h3.223A8.287 8.287 0 0 0 12 20.775V24h1v-3.225A8.287 8.287 0 0 0 20.775 13H24zm-11.5 7.8a7.3 7.3 0 1 1 7.3-7.3 7.308 7.308 0 0 1-7.3 7.3zm0-11.8a4.5 4.5 0 1 0 4.5 4.5A4.506 4.506 0 0 0 12.5 8zm0 8a3.5 3.5 0 1 1 3.5-3.5 3.504 3.504 0 0 1-3.5 3.5z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M31.98 16h-3.226A12.262 12.262 0 0 0 17 4.225V1h-1v3.225A12.3 12.3 0 0 0 4.205 16H1v1h3.205A12.3 12.3 0 0 0 16 28.775V32h.98v-3.225A12.28 12.28 0 0 0 28.754 17h3.226zm-15.5 11.8a11.3 11.3 0 1 1 11.3-11.3 11.312 11.312 0 0 1-11.3 11.3zm0-18.6a7.3 7.3 0 1 0 7.3 7.3 7.309 7.309 0 0 0-7.3-7.3zm0 13.6a6.3 6.3 0 1 1 6.3-6.3 6.307 6.307 0 0 1-6.3 6.3z"
  }));
};

var _default = GpsOnIcon;
exports["default"] = _default;