"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayersIcon = function LayersIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8.023 1.023l-8 4.5 8 4.5 8-4.5zm-5.96 4.5l5.96-3.352 5.96 3.352-5.96 3.353zm13.96 3l-8 4.5-8-4.5 1.02-.573 6.98 3.926 6.98-3.926zm-8 6.353l6.98-3.926 1.02.573-7.914 4.452a.175.175 0 0 1-.171 0L.023 11.523l1.02-.573z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.893 15.947l-.927.547L12 21.838l9.033-5.342-.927-.547.983-.582L23 16.495 12 23 1 16.493l1.91-1.128zM23 8.495L12 15 1 8.493 12 2zm-10.999 5.343l9.033-5.342-9.033-5.335-9.035 5.333zm9.089-2.47l-.983.58.927.548-9.033 5.342-9.035-5.344.927-.547-.983-.582L1 12.493 12 19l11-6.505z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M30.5 11.492L16 3 1.5 11.492 16 20zM16 4.16l12.522 7.334L16 18.841 3.478 11.493zM16 25L1.5 16.492l2.781-1.629.989.58-1.792 1.05L16 23.841l12.522-7.348-1.792-1.05.989-.58 2.781 1.63zm0 5L1.5 21.492l2.781-1.629.989.58-1.792 1.05L16 28.841l12.522-7.348-1.792-1.05.989-.58 2.781 1.63z"
  }));
};

var _default = LayersIcon;
exports["default"] = _default;