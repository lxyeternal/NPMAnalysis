"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var EditAttributesIcon = function EditAttributesIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.95 5l-1 1H1V5zM1 2v1h8.95l1-1zm0 6v1h2.95l1-1zm3.841 2.23l8.052-8.051a.965.965 0 0 1 1.385.03l1.414 1.413a.965.965 0 0 1 .03 1.385l-1.444 1.444h-.002L7.67 13.058l-4.096 1.755a.371.371 0 0 1-.488-.487zm8.946-7.098a.306.306 0 0 0-.433 0l-1.09 1.09 1.414 1.414 1.09-1.09a.306.306 0 0 0 0-.433zM5.55 10.937l1.413 1.415 6.008-6.008-1.414-1.415zm-.37 1.045l-.555 1.294 1.294-.555z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18.52 4l-1 1H2V4zM2 8v1h11.52l1-1zm4.52 8H2v1h3.655a1.477 1.477 0 0 1 .282-.417zM2 12v1h7.52l1-1zm20.95-6.066a.965.965 0 0 1 .03 1.385L9.825 20.471 5.73 22.227a.371.371 0 0 1-.488-.487l1.756-4.097L20.15 4.491a.965.965 0 0 1 1.385.03zM9.02 19.728l-1.28-1.28-.96 2.24zM20.093 8.79L18.68 7.376 8.382 17.674l1.413 1.414zm1.865-2.445l-.804-.838a.42.42 0 0 0-.6-.007l-1.167 1.17L20.8 8.083l1.152-1.151a.42.42 0 0 0 .006-.587z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.582 11l-1 1H3v-1zM3 6h25V5H3zm0 11v1h12.582l1-1zm7.548 6.034l.034-.034H3v1h6.978l.146-.34a2.003 2.003 0 0 1 .424-.626zm20.804-12.688a1.203 1.203 0 0 1 .037 1.727l-1.8 1.8-.001-.001-14.101 14.102-5.465 2.342a.306.306 0 0 1-.403-.402l2.343-5.465L27.863 8.547a1.203 1.203 0 0 1 1.727.037zM14.495 27.311l-1.87-1.87-1.403 3.273zm14.12-13.88l-2.11-2.11L13.21 24.612l2.112 2.111zm2.03-2.377l-1.761-1.762a.285.285 0 0 0-.193-.092.163.163 0 0 0-.12.054l-1.36 1.36 2.111 2.11 1.36-1.359c.133-.133-.02-.294-.037-.311z"
  }));
};

var _default = EditAttributesIcon;
exports["default"] = _default;