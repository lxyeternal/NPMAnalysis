"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var BellFIcon = function BellFIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7 14h3v.053a1.5 1.5 0 0 1-3 0zm8-2v1H2v-1h.062A1.938 1.938 0 0 0 4 10.062V6.5a4.555 4.555 0 0 1 .027-.5 4.49 4.49 0 0 1 3.161-3.786A1.483 1.483 0 0 1 7 1.5a1.5 1.5 0 0 1 3 0 1.483 1.483 0 0 1-.188.714A4.49 4.49 0 0 1 12.972 6a4.555 4.555 0 0 1 .028.5v3.562A1.938 1.938 0 0 0 14.938 12H15zM8.5 2a.5.5 0 1 0-.5-.5.5.5 0 0 0 .5.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M18 15v-4.087a5.911 5.911 0 0 0-4.387-5.708A1.933 1.933 0 0 0 14 4.05v-.1A1.95 1.95 0 0 0 12.05 2h-.1A1.95 1.95 0 0 0 10 3.95v.1a1.933 1.933 0 0 0 .39 1.16A5.906 5.906 0 0 0 6 10.913V15a3 3 0 0 1-3 3v1h18v-1a3 3 0 0 1-3-3zM12 3a1 1 0 1 1-1 1 1.001 1.001 0 0 1 1-1zm-2 17h4a2 2 0 0 1-4 0z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.95 25A4 4 0 0 1 25 21v-7q0-.326-.023-.646a9.002 9.002 0 0 0-7.323-8.199A1.939 1.939 0 0 0 18 4.05v-.1A1.95 1.95 0 0 0 16.05 2h-.1A1.95 1.95 0 0 0 14 3.95v.1a1.939 1.939 0 0 0 .346 1.105 9.002 9.002 0 0 0-7.323 8.199Q7 13.674 7 14v7a4 4 0 0 1-3.95 4H3v1h26v-1zM15 4a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm-2 23h6a3 3 0 0 1-6 0z"
  }));
};

var _default = BellFIcon;
exports["default"] = _default;