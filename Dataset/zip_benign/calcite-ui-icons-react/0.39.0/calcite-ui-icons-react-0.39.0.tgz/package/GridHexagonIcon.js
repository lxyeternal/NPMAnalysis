"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GridHexagonIcon = function GridHexagonIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 1v14h14V1zm13 5h-.232L12.1 3.5l1-1.5h.9zm-2.768 3H8.768L7.1 6.5 8.768 4h2.464L12.9 6.5zm-5 3H3.768L2.1 9.5 3.768 7h2.464L7.9 9.5zm5-9H8.768L8.1 2h3.798zM7.9 3.5L6.232 6H3.768L2.1 3.5l1-1.5h3.8zm-5 3L2 7.849V5.15zm0 6L2 13.848v-2.697zm.869.5h2.464l.667 1H3.101zm3.333-.5L8.768 10h2.464l1.667 2.5-1 1.5H8.1zm6.667-.5L12.1 9.5 13.768 7H14v5zm-.667 2l.667-1H14v1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 2v20h20V2zm1 12V7h1.19l1.75 3.5L4.19 14zm15.19 0h-4.38l-1.75-3.5L13.81 7h4.38l1.75 3.5zm0-8h-4.38l-1.5-3h7.38zm-5.25.5L11.19 10H6.81L5.06 6.5 6.81 3h4.38zM6.81 11h4.38l1.75 3.5-1.75 3.5H6.81l-1.75-3.5zm0 8h4.38l1 2H5.81zm5.25-.5l1.75-3.5h4.38l1.75 3.5-1.25 2.5h-5.38zm7-4l1.75-3.5H21v7h-.19zM21 10h-.19l-1.75-3.5L20.81 3H21zM5.69 3l-1.5 3H3V3zM3 15h1.19l1.75 3.5L4.69 21H3zm16.81 6l1-2H21v2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3 3v26h26V3zm25 10h-2.217l-2.7-4.5 2.7-4.5H28zm-5.783 15h-4.434l-2.7-4.5 2.7-4.5h4.434l2.7 4.5zM9.783 23l-2.7-4.5 2.7-4.5h4.434l2.7 4.5-2.7 4.5zm0-19h4.434l2.7 4.5-2.7 4.5H9.783l-2.7-4.5zm12.434 5l2.7 4.5-2.7 4.5h-4.434l-2.7-4.5 2.7-4.5zm-16 0l2.7 4.5-2.7 4.5H4V9zm19.566 14l-2.7-4.5 2.7-4.5H28v9zM24.617 4l-2.4 4h-4.434l-2.4-4zm-16 0l-2.4 4H4V4zM4 19h2.217l2.7 4.5-2.7 4.5H4zm3.383 9l2.4-4h4.434l2.4 4zm16 0l2.4-4H28v4z"
  }));
};

var _default = GridHexagonIcon;
exports["default"] = _default;