"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FolderStarIcon = function FolderStarIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M6.981 1H4L2.7 2H1v11h7v-1H2V6h12v2h1V2l-6.7.002zM14 5H2V3h1.04l1.3-1h2.304l1.319 1H14zm-1.564 5L11.5 7.12 10.564 10H7.541l2.446 1.774-.935 2.883 2.448-1.774 2.448 1.774-.935-2.883L15.459 10zm-.386 2.046l-.55-.398-.55.398.213-.654-.54-.392h.668l.209-.643.209.643h.668l-.54.392z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M2 20V9h20v7h1V5H12.2L11 3H4L2.8 5H1v16h13.85l.324-1zM2 6h1.366l1.2-2h5.868l1.2 2H22v2H2zm17.799 11L18.5 13l-1.298 4H13l3.4 2.466-1.3 3.996L18.5 21l3.4 2.462-1.3-3.996L24 17zm-.374 2.083l.574 1.769-1.499-1.086-1.499 1.086.574-1.769L16.082 18h1.847l.571-1.76.572 1.76h1.846z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.379 26H3V12h26v8.084h1V7H16l-1-2H5L4 7H2v20h17.223l.28-.905zM3 8h1.618l1-2h8.764l1 2H29v3H3zm23.164 14.084L24.5 16.7l-1.664 5.384h-5.287l4.276 3.268-1.652 5.348 4.327-3.305 4.327 3.305-1.652-5.348 4.276-3.268zm-.15 2.897l.934 3.026-2.448-1.87-2.448 1.87.934-3.026-2.482-1.897h3.07l.926-2.997.927 2.997h3.07z"
  }));
};

var _default = FolderStarIcon;
exports["default"] = _default;