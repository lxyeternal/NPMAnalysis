"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FileSoundIcon = function FileSoundIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.731 8.034L6.078 9h-1.16A.917.917 0 0 0 4 9.917v1.166a.917.917 0 0 0 .917.917H6l1.731.966A.17.17 0 0 0 8 12.821V8.18a.17.17 0 0 0-.269-.145zM7 11.414L6.26 11H5v-1h1.35L7 9.62zm3.559-3.806l.686-.515A8.362 8.362 0 0 1 12 10.538a8.13 8.13 0 0 1-.742 3.379l-.684-.513a7.592 7.592 0 0 0 .587-2.866 7.786 7.786 0 0 0-.602-2.93zm-1.045.76a5.272 5.272 0 0 1 .486 2.17 5.167 5.167 0 0 1-.464 2.11l-.712-.534a4.453 4.453 0 0 0 .306-1.576 4.552 4.552 0 0 0-.322-1.64zM15 3.6L11.4 0H2v16h13zM14 15H3V1h7v4h4zm0-11h-3V1h.31L14 3.69z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11.597 12.047L9.126 14H6.917a.917.917 0 0 0-.917.917v1.166a.917.917 0 0 0 .917.917h2.209l2.47 1.953A.255.255 0 0 0 12 18.75v-6.5a.255.255 0 0 0-.403-.203zM11 17.208L9.474 16H7v-1h2.474L11 13.793zm2.575-5.212a5.339 5.339 0 0 1 1.396 3.588 5.194 5.194 0 0 1-1.417 3.568l-.578-.504a5.273 5.273 0 0 0 1.125-3.064 5.406 5.406 0 0 0-1.123-3.095zm2.276-1.95a8.457 8.457 0 0 1 2.09 5.538 8.165 8.165 0 0 1-2.133 5.5l-.546-.476a8.252 8.252 0 0 0 1.839-5.024 8.536 8.536 0 0 0-1.83-5.087zM3 23h18V6.709L15.29 1H3zM15 2h.2L20 6.8V7h-5zM4 2h10v6h6v14H4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27 9.699L19.3 2H5v28h22zM26 29H6V3h12v8h8zm-7-19V3l7 7zm-4.538 5.293L11.112 18H8.917a.917.917 0 0 0-.917.917v2.166a.917.917 0 0 0 .917.917h2.196l3.35 2.707A.34.34 0 0 0 15 24.43v-8.86a.34.34 0 0 0-.538-.277zM14 23.05L11.466 21H9v-2h2.466L14 16.952zm3.584-6.819l.682-.663A6.485 6.485 0 0 1 20 20a6.739 6.739 0 0 1-1.664 4.427l-.032.038-.715-.626A6.08 6.08 0 0 0 19 20a5.732 5.732 0 0 0-1.416-3.769zM23 20a9.728 9.728 0 0 0-2.412-6.398l.684-.664A10.468 10.468 0 0 1 24 20a10.727 10.727 0 0 1-2.657 7.057l-.033.038-.717-.627A10.07 10.07 0 0 0 23 20z"
  }));
};

var _default = FileSoundIcon;
exports["default"] = _default;