"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ConditionalRulesIcon = function ConditionalRulesIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 8H5.95a2.5 2.5 0 1 0 0 1H7v4h6.227l-1.58 1.581.706.707 2.81-2.81-2.81-2.808-.707.707L13.27 12H8V9h2V4h3.227l-1.58 1.581.706.707 2.81-2.81L12.352.67l-.706.707L13.27 3H9zm-5.5 2A1.5 1.5 0 1 1 5 8.5 1.5 1.5 0 0 1 3.5 10z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19.367 8.355l3.89-3.89L19.426.632l-.707.707L21.378 4H14v8H7.95a3.5 3.5 0 1 0 0 1H11v7h10.309l-2.649 2.648.707.707 3.89-3.89-3.832-3.833-.707.707L21.378 19H12v-6h3V5h6.309L18.66 7.648zM4.5 15A2.5 2.5 0 1 1 7 12.5 2.5 2.5 0 0 1 4.5 15z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M25.633 23.354L28.279 26H17v-9h4V6h7.28l-2.647 2.646.707.707L30.193 5.5 26.34 1.646l-.707.707L28.279 5H20v11h-9.05a4.5 4.5 0 1 0 0 1H16v10h12.28l-2.647 2.646.707.707 3.853-3.853-3.853-3.854zM6.5 20a3.5 3.5 0 1 1 3.5-3.5A3.504 3.504 0 0 1 6.5 20z"
  }));
};

var _default = ConditionalRulesIcon;
exports["default"] = _default;