"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AppGearIcon = function AppGearIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M11 2.342V6h-1V2.996L5.617 1.078a.284.284 0 0 0-.234 0L1.48 2.785a.805.805 0 0 0-.48.737v6.482l4.383 1.918a.292.292 0 0 0 .234 0L6 11.754v1.088a1.269 1.269 0 0 1-1.018-.004L0 10.658V3.522A1.806 1.806 0 0 1 1.08 1.87L4.983.162a1.291 1.291 0 0 1 1.036 0zm1.896 6.128l1.343-.593.868.86-.602 1.309q.07.144.126.296l1.37.53v1.256l-1.37.53q-.056.152-.126.296l.602 1.308-.868.86-1.343-.592q-.145.067-.298.12l-.5 1.35h-1.222l-.53-1.373q-.151-.056-.296-.126l-1.308.601-.86-.867.592-1.343q-.067-.146-.12-.299l-1.35-.499v-1.188l1.35-.5q.053-.152.12-.298l-.592-1.343.86-.867 1.308.601q.144-.07.296-.126L10.876 7h1.222l.5 1.35q.152.053.298.12zm-.006.822l-.307-.14a2.47 2.47 0 0 0-.23-.093l-.335-.117-.442-1.192h-.185l-.468 1.209-.318.118a1.988 1.988 0 0 0-.224.096l-.32.156-1.156-.531-.13.133.523 1.185-.144.309a2.684 2.684 0 0 0-.093.232l-.119.331-1.188.44v.144l1.188.44.119.33c.028.08.058.158.093.233l.144.309-.524 1.185.131.133 1.156-.531.32.156a1.988 1.988 0 0 0 .224.096l.318.118.468 1.209h.185l.442-1.192.335-.117c.08-.027.159-.06.236-.094l.305-.138 1.18.521.132-.13-.53-1.155.154-.318a2.322 2.322 0 0 0 .097-.227l.116-.318 1.207-.468v-.228l-1.207-.468-.116-.318a2.322 2.322 0 0 0-.097-.227l-.154-.318.53-1.155-.132-.13zM13 11.5a1.5 1.5 0 1 1-1.5-1.5 1.5 1.5 0 0 1 1.5 1.5zm-1-.5h-1v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10 17.745v1.092l-.323.142a1.702 1.702 0 0 1-1.352 0L1 15.774v-9.94a2.455 2.455 0 0 1 1.472-2.251l5.85-2.562a1.7 1.7 0 0 1 1.353 0L17 4.226V11h-1V4.88L9.276 1.939a.709.709 0 0 0-.554 0L2.873 4.5A1.456 1.456 0 0 0 2 5.834v9.285l6.724 2.944a.709.709 0 0 0 .554-.001zM19 18a2 2 0 1 1-2-2 2 2 0 0 1 2 2zm-1 0a1 1 0 1 0-1 1 1 1 0 0 0 1-1zm3.34-1.484l1.66.636v1.65l-1.586.59-.296.628.724 1.624-1.162 1.17-1.543-.71-.653.236-.636 1.66h-1.65l-.59-1.586-.628-.295-1.627.727-1.167-1.166.71-1.543-.236-.653-1.66-.636v-1.65l1.586-.59.295-.628-.727-1.627 1.166-1.167 1.543.71.653-.236.636-1.66h1.65l.59 1.586.628.296 1.624-.724 1.166 1.167-.705 1.538zm.66 1.169l-1.427-.548-.434-1.204.585-1.28-.412-.412-1.397.622-1.158-.544-.49-1.319h-.582l-.548 1.427-1.206.434-1.283-.59-.41.411.626 1.4-.545 1.161-1.319.49v.582l1.427.548.434 1.206-.59 1.283.411.41 1.4-.626 1.161.545.49 1.319h.582l.548-1.427 1.206-.434 1.28.588.411-.413-.623-1.399.544-1.158 1.319-.49z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14.546 26.355l.285.109-.963.422a2.166 2.166 0 0 1-1.737 0L2 22.45V8.667a3.24 3.24 0 0 1 1.94-2.968l8.192-3.585a2.182 2.182 0 0 1 1.737 0L24 6.55V15h-1V7.203L13.467 3.03a1.175 1.175 0 0 0-.933 0L4.342 6.615A2.24 2.24 0 0 0 3 8.667v13.13l9.533 4.173a1.171 1.171 0 0 0 .933 0l.425-.186a1.284 1.284 0 0 0 .655.571zm16.446-3.495L31 25.082l-2.13.789-.377.825.965 2.149-1.565 1.576-2.066-.949-.849.318-.838 2.202-2.222.008-.79-2.13-.824-.377-2.149.965-1.576-1.566.949-2.066-.318-.848-2.202-.838L15 22.92l2.13-.79.377-.825-.965-2.15 1.566-1.575 2.066.949.848-.318.838-2.202L24.08 16l.79 2.13.825.377 2.15-.965 1.576 1.565-.95 2.066.319.849zM30 24.417l-.004-.897-1.995-.76-.588-1.606.831-1.809-.636-.632-1.945.873-1.555-.72L23.417 17l-.897.004-.758 1.994-1.608.59-1.81-.832-.63.636.873 1.945-.72 1.555-1.867.692.004.896 1.995.76.588 1.606-.83 1.81.635.63 1.945-.873 1.555.722.69 1.864.898-.003.758-1.994 1.608-.59 1.81.832.63-.636-.874-1.948.722-1.551zM26 24a3 3 0 1 1-3-3 3 3 0 0 1 3 3zm-1 0a2 2 0 1 0-2 2 2 2 0 0 0 2-2z"
  }));
};

var _default = AppGearIcon;
exports["default"] = _default;