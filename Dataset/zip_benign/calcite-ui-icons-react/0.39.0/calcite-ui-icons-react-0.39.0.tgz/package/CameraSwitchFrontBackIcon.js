"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CameraSwitchFrontBackIcon = function CameraSwitchFrontBackIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 3H14a1.001 1.001 0 0 0-1-1H8a1.001 1.001 0 0 0-1 1H6V2H2v1h-.5A1.502 1.502 0 0 0 0 4.5v8A1.502 1.502 0 0 0 1.5 14h13a1.502 1.502 0 0 0 1.5-1.5v-8A1.502 1.502 0 0 0 14.5 3zm.5 9.5a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-8a.5.5 0 0 1 .5-.5H3V3h2v1h2a1.001 1.001 0 0 0 1-1h5a1.001 1.001 0 0 0 1 1h.5a.5.5 0 0 1 .5.5zM10.741 9h1.008a3.282 3.282 0 0 1-5.526 1.877L5 12.1V9h3.1l-1.17 1.17A2.29 2.29 0 0 0 10.74 9zm.036-2.877L12 4.9V8H8.9l1.17-1.17A2.29 2.29 0 0 0 6.26 8H5.25a3.282 3.282 0 0 1 5.526-1.877z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M21 6h-1.5a.5.5 0 0 1-.5-.5A1.502 1.502 0 0 0 17.5 4h-6A1.502 1.502 0 0 0 10 5.5a.5.5 0 0 1-.5.5H8V5H4v1H3a2.002 2.002 0 0 0-2 2v10a2.002 2.002 0 0 0 2 2h18a2.002 2.002 0 0 0 2-2V8a2.002 2.002 0 0 0-2-2zm1 12a1.001 1.001 0 0 1-1 1H3a1.001 1.001 0 0 1-1-1V8a1.001 1.001 0 0 1 1-1h2V6h2v1h2.5A1.502 1.502 0 0 0 11 5.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 .5.5A1.502 1.502 0 0 0 19.5 7H21a1.001 1.001 0 0 1 1 1zM8.2 13h-1a4.796 4.796 0 0 1 8.8-2.644V9h1v3h-3v-1h1.217A3.79 3.79 0 0 0 8.2 13zm7.6 0h1A4.796 4.796 0 0 1 8 15.644V17H7v-3h3v1H8.783a3.79 3.79 0 0 0 7.017-2z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27.5 9H27a1.001 1.001 0 0 1-1-1 2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2 1.001 1.001 0 0 1-1 1h-2V8H6v1H4.5A2.503 2.503 0 0 0 2 11.5v12A2.503 2.503 0 0 0 4.5 26h23a2.503 2.503 0 0 0 2.5-2.5v-12A2.503 2.503 0 0 0 27.5 9zM29 23.5a1.502 1.502 0 0 1-1.5 1.5h-23A1.502 1.502 0 0 1 3 23.5v-12A1.502 1.502 0 0 1 4.5 10H7V9h3v1h3a2.002 2.002 0 0 0 2-2 1.001 1.001 0 0 1 1-1h8a1.001 1.001 0 0 1 1 1 2.002 2.002 0 0 0 2 2h.5a1.502 1.502 0 0 1 1.5 1.5zM21.71 16h.98a5.773 5.773 0 0 1-10.623 4H12v3h-1v-4h4v1h-1.74a4.801 4.801 0 0 0 8.45-4zm-9.42 2h-.98a5.773 5.773 0 0 1 10.623-4H22v-3h1v4h-4v-1h1.74a4.801 4.801 0 0 0-8.45 4z"
  }));
};

var _default = CameraSwitchFrontBackIcon;
exports["default"] = _default;