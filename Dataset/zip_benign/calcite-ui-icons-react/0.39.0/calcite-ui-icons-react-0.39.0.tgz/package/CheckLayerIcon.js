"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CheckLayerIcon = function CheckLayerIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.852 13.584l.83.83a10.557 10.557 0 0 1-2.89.386A9.158 9.158 0 0 1 0 14.089l2.133-12.6A10.39 10.39 0 0 0 5.294 2c2.688 0 2.721-.986 5.412-.986a8.205 8.205 0 0 1 3.161.674l.942 5.566a1.44 1.44 0 0 0-.988.156l-.845-4.997a7.215 7.215 0 0 0-2.27-.399 5.895 5.895 0 0 0-2.367.434A7.833 7.833 0 0 1 5.294 3a11.376 11.376 0 0 1-2.359-.26l-1.81 10.697a9.54 9.54 0 0 0 2.668.363 9.56 9.56 0 0 0 2.06-.216zm9.397-4.136l-.707-.707-4.985 4.984-2.1-2.102-.707.707 2.807 2.81z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M10.626 21.142l.028.027a21.546 21.546 0 0 1-5.23.631A13.093 13.093 0 0 1 0 20.783L3.05 3.078a15.028 15.028 0 0 0 4.52.722c3.849 0 3.893-1.6 7.74-1.6a12.674 12.674 0 0 1 4.52.878l1.695 10.054a1.983 1.983 0 0 0-.401.296l-.484.473-1.7-10.086a11.86 11.86 0 0 0-3.63-.615 7.792 7.792 0 0 0-3.49.725 9.805 9.805 0 0 1-4.25.875 16.196 16.196 0 0 1-3.722-.457L1.124 20.15a13.727 13.727 0 0 0 4.3.65 20.115 20.115 0 0 0 4.673-.53 1.994 1.994 0 0 0 .529.872zm4.867.528l-2.832-2.663-.685.728 3.53 3.321 7.684-7.522-.699-.715z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.202 28.725l.024.022A20.44 20.44 0 0 1 8.538 29.8 16.273 16.273 0 0 1 1 28L5 3.9a14.99 14.99 0 0 0 5.34.968c4.807 0 5.59-1.657 10.734-1.657A26.401 26.401 0 0 1 27 3.9l2.378 14.33a1.979 1.979 0 0 0-.202.163l-.674.664-2.378-14.328a26.266 26.266 0 0 0-5.05-.518 16.633 16.633 0 0 0-5.29.81 17.433 17.433 0 0 1-5.445.847 15.6 15.6 0 0 1-4.544-.65L2.108 27.433a15.986 15.986 0 0 0 6.43 1.366 19.212 19.212 0 0 0 6.143-.932 1.99 1.99 0 0 0 .521.857zm5.297.954l-3.256-3.084-.687.726 3.957 3.749 10.735-10.577-.701-.712z"
  }));
};

var _default = CheckLayerIcon;
exports["default"] = _default;