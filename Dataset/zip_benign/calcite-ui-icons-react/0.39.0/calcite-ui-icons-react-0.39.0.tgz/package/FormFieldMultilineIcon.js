"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FormFieldMultilineIcon = function FormFieldMultilineIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3.5 7.443A2.08 2.08 0 0 1 2 8V7c.74 0 .948-.417 1-.571v-1.86C2.952 4.426 2.749 4 2 4V3a2.08 2.08 0 0 1 1.5.557A2.08 2.08 0 0 1 5 3v1c-.74 0-.948.417-1 .571v1.86c.048.143.251.569 1 .569v1a2.08 2.08 0 0 1-1.5-.557zM1.5 15A1.502 1.502 0 0 1 0 13.5v-11A1.502 1.502 0 0 1 1.5 1h13A1.502 1.502 0 0 1 16 2.5v11a1.502 1.502 0 0 1-1.5 1.5zm0-1h13a.5.5 0 0 0 .5-.5v-11a.5.5 0 0 0-.5-.5h-13a.5.5 0 0 0-.5.5v11a.5.5 0 0 0 .5.5zM10 7H9v1h1zM8 7H7v1h1zm4 0h-1v1h1zm2 0h-1v1h1zm-6 5H7v1h1zm6 0h-1v1h1zm-2 0h-1v1h1zm-9 1h1v-1H3zm7-1H9v1h1zm-5 1h1v-1H5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M5.5 11.443A2.08 2.08 0 0 1 4 12v-1c.74 0 .948-.417 1-.571v-2.86C4.952 7.426 4.749 7 4 7V6a2.08 2.08 0 0 1 1.5.557A2.08 2.08 0 0 1 7 6v1c-.74 0-.948.417-1 .571v2.86c.048.143.251.569 1 .569v1a2.08 2.08 0 0 1-1.5-.557zM23 4.5v15a1.502 1.502 0 0 1-1.5 1.5h-19A1.502 1.502 0 0 1 1 19.5v-15A1.502 1.502 0 0 1 2.5 3h19A1.502 1.502 0 0 1 23 4.5zm-1 0a.5.5 0 0 0-.5-.5h-19a.5.5 0 0 0-.5.5v15a.5.5 0 0 0 .5.5h19a.5.5 0 0 0 .5-.5zM13 12h1v-1h-1zm-4 0h1v-1H9zm6 0h1v-1h-1zm-4 0h1v-1h-1zm8 0h1v-1h-1zm-2 0h1v-1h-1zM7 18h1v-1H7zm2 0h1v-1H9zm2 0h1v-1h-1zm-6 0h1v-1H5zm8 0h1v-1h-1zm6 0h1v-1h-1zm-2 0h1v-1h-1zm-2 0h1v-1h-1z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M28.5 5h-25A1.502 1.502 0 0 0 2 6.5v19A1.502 1.502 0 0 0 3.5 27h25a1.502 1.502 0 0 0 1.5-1.5v-19A1.502 1.502 0 0 0 28.5 5zm.5 20.5a.5.5 0 0 1-.5.5h-25a.5.5 0 0 1-.5-.5v-19a.5.5 0 0 1 .5-.5h25a.5.5 0 0 1 .5.5zM20 15h1v1h-1zm2 0h1v1h-1zm4 0h1v1h-1zm-8 0h1v1h-1zm6 0h1v1h-1zm-8 0h1v1h-1zm-2 0h1v1h-1zm-4 0h1v1h-1zm2 0h1v1h-1zm2 8h1v1h-1zm-2 0h1v1h-1zm4 0h1v1h-1zm-8 0h1v1H8zm10 0h1v1h-1zm-8 0h1v1h-1zm14 0h1v1h-1zm-2 0h1v1h-1zM6 23h1v1H6zm20 0h1v1h-1zm-6 0h1v1h-1zM6.5 15.443A2.08 2.08 0 0 1 5 16v-1c.74 0 .948-.417 1-.571v-4.86C5.952 9.426 5.749 9 5 9V8a2.08 2.08 0 0 1 1.5.557A2.08 2.08 0 0 1 8 8v1c-.74 0-.948.417-1 .571v4.86c.048.143.251.569 1 .569v1a2.08 2.08 0 0 1-1.5-.557z"
  }));
};

var _default = FormFieldMultilineIcon;
exports["default"] = _default;