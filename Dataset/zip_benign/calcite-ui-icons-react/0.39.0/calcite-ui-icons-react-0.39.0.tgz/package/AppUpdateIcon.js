"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var AppUpdateIcon = function AppUpdateIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M8 10.879v1.091l-1.982.868a1.292 1.292 0 0 1-1.036 0L0 10.658V3.522A1.805 1.805 0 0 1 1.08 1.87L4.983.162a1.299 1.299 0 0 1 1.036 0L11 2.342V7h-1V2.997L5.617 1.078a.284.284 0 0 0-.234 0L1.48 2.785a.805.805 0 0 0-.48.737v6.481l4.383 1.919a.292.292 0 0 0 .234 0zm6 2.35a2.267 2.267 0 0 1-3.07-.058L12.1 12H9v3.1l1.223-1.223c.046.045.1.081.148.123a3.27 3.27 0 0 0 5.378-2h-1.008A2.29 2.29 0 0 1 14 13.229zm.777-4.106A3.305 3.305 0 0 0 14 8.578a3.258 3.258 0 0 0-1.5-.377A3.296 3.296 0 0 0 9.25 11h1.009A2.283 2.283 0 0 1 14 9.771c.023.02.048.038.07.058L12.9 11H16V7.9z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 16.87v1.091l-2.323 1.017a1.692 1.692 0 0 1-1.354 0L1 15.773v-9.94a2.456 2.456 0 0 1 1.472-2.25l5.85-2.561a1.692 1.692 0 0 1 1.355 0L17 4.227V12h-1V4.881L9.276 1.938a.697.697 0 0 0-.552 0L2.873 4.499A1.457 1.457 0 0 0 2 5.834v9.285l6.724 2.943a.697.697 0 0 0 .552 0zm6 4.93a3.79 3.79 0 0 1-3.217-1.8H16v-1h-3v3h1v-1.356A4.796 4.796 0 0 0 22.8 18h-1a3.804 3.804 0 0 1-3.8 3.8zM13.2 18h1a3.79 3.79 0 0 1 7.017-2H20v1h3v-3h-1v1.356A4.796 4.796 0 0 0 13.2 18z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17 25.515l-3.132 1.371a2.171 2.171 0 0 1-1.736 0L2 22.452V8.667a3.24 3.24 0 0 1 1.94-2.968l8.192-3.585a2.183 2.183 0 0 1 1.736 0L24 6.548V17h-1V7.203L13.467 3.03a1.168 1.168 0 0 0-.934 0L4.342 6.615A2.24 2.24 0 0 0 3 8.667v13.13l9.533 4.173a1.168 1.168 0 0 0 .934 0L17 24.423zm2.65.485H22v-1h-4v4h1v-2.075A5.795 5.795 0 0 0 29.8 24h-1a4.792 4.792 0 0 1-9.15 2zM29 19v2.075A5.795 5.795 0 0 0 18.2 24h1a4.792 4.792 0 0 1 9.15-2H26v1h4v-4z"
  }));
};

var _default = AppUpdateIcon;
exports["default"] = _default;