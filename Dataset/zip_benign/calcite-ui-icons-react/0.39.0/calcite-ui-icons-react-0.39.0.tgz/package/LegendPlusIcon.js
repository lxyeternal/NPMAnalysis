"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LegendPlusIcon = function LegendPlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M4 0H1v3h3zM3 2H2V1h1zm12 0H6V1h9zm1 10v1h-3v3h-1v-3H9v-1h3V9h1v3zM2.49 6l1.638 3H.87zM15 8H6V7h9zM2.5 12A1.5 1.5 0 1 0 4 13.5 1.502 1.502 0 0 0 2.5 12zm0 2a.5.5 0 1 1 .5-.5.5.5 0 0 1-.5.5z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M22 5H9V4h13zM9 21h5v-1H9zm0-8h13v-1H9zM2 6V2h4v4zm1-1h2V3H3zm17 12h-1v3h-3v.999h3V24h1v-3.001h3V20h-3zM6 20a2 2 0 1 1-2-2 2 2 0 0 1 2 2zm-1 0a1 1 0 1 0-1 1 1 1 0 0 0 1-1zM4 9.209L6.607 14H1.393zM4.925 13L4 11.301 3.075 13z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M29 6H11V5h18zm0 9H11v1h18zM18 25h-7v1h7zM8 8H3V3h5zM7 4H4v3h3zm19 21v-5h-1v5h-5v.999h5V31h1v-5.001h5V25zM3 15.5A2.5 2.5 0 1 1 5.5 18 2.5 2.5 0 0 1 3 15.5zm1 0A1.5 1.5 0 1 0 5.5 14 1.5 1.5 0 0 0 4 15.5zM8.154 28H2.846L5.5 22.932zm-3.656-1h2.004L5.5 25.087z"
  }));
};

var _default = LegendPlusIcon;
exports["default"] = _default;