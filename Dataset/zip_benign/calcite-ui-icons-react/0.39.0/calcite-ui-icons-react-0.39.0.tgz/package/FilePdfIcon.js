"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var FilePdfIcon = function FilePdfIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M15 3.6L11.4 0H2v16h13zM14 15H3V1h7v4h4zm0-11h-3V1h.31L14 3.69zM8.214 8.014a9.45 9.45 0 0 0 .555-2.972 1.299 1.299 0 0 0-.827-1.075 1.16 1.16 0 0 0-.39-.067 1.278 1.278 0 0 0-.851.333c-.684.613-.645 1.93.1 3.354a2.093 2.093 0 0 0 .343.502l-.66 2.435a3.07 3.07 0 0 0-.689.361c-1.314.753-2.103 1.463-1.68 2.477a.994.994 0 0 0 .764.62 1.134 1.134 0 0 0 .2.018 1.858 1.858 0 0 0 1.31-.65 6.728 6.728 0 0 0 1.022-1.945l2.043-.47a5.695 5.695 0 0 0 2.17 1.393 1.713 1.713 0 0 0 .35.038 1.143 1.143 0 0 0 .92-.419 1.375 1.375 0 0 0 .12-1.42 1.411 1.411 0 0 0-1.247-.847l-.139-.003a8.296 8.296 0 0 0-1.788.25 21.272 21.272 0 0 1-1.626-1.913zM5.807 12.73a1.442 1.442 0 0 1-.888.522.116.116 0 0 1-.12-.063c-.086-.207-.263-.636 1.817-1.837a4.69 4.69 0 0 1-.809 1.378zm1.147-7.456a.666.666 0 0 1 .256-.443.7.7 0 0 1 .372-.113.56.56 0 0 1 .136.016.476.476 0 0 1 .34.39A5.116 5.116 0 0 1 7.56 7.23a2.73 2.73 0 0 1-.607-1.958zm.232 5.376a51.34 51.34 0 0 0 .69-1.899c.39.474.719.957 1.155 1.41-.663.146-1.228.314-1.845.49zm4.464-.125l.131.003a.589.589 0 0 1 .52.371.596.596 0 0 1 .008.546.272.272 0 0 1-.21.069.914.914 0 0 1-.191-.023 4.05 4.05 0 0 1-1.461-.858 9.174 9.174 0 0 1 1.203-.108z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M3 23h18V6.709L15.29 1H3zM15 2h.2L20 6.8V7h-5zM4 2h10v6h6v14H4zm13.324 11.819l-.167-.004a12.208 12.208 0 0 0-2.469.338 24.235 24.235 0 0 1-2.344-2.728 11.894 11.894 0 0 0 .697-4.028 1.432 1.432 0 0 0-.928-1.237 1.37 1.37 0 0 0-.461-.08 1.524 1.524 0 0 0-1.014.398c-.836.75-.752 2.316.226 4.187.042.081.084.175.13.276a1.939 1.939 0 0 0 .323.561c-.334 1.046-.803 2.182-1.216 3.184l-.252.694a9.195 9.195 0 0 0-1.36.607c-1.673.959-2.683 1.849-2.17 3.08a1.147 1.147 0 0 0 .88.716 1.315 1.315 0 0 0 .23.02 2.343 2.343 0 0 0 1.623-.813 10.846 10.846 0 0 0 1.467-2.83c1.074-.37 2.484-.74 3.784-1.04a7.526 7.526 0 0 0 2.876 1.87 2.144 2.144 0 0 0 .426.045 1.347 1.347 0 0 0 1.088-.489 1.652 1.652 0 0 0 .136-1.703 1.707 1.707 0 0 0-1.505-1.024zM9.44 16.474c-.395.94-1.057 2.513-1.842 2.513a.655.655 0 0 1-.154-.018.624.624 0 0 1-.372-.58c.001-.285.195-1.033 1.972-1.815.096-.042.202-.094.314-.15l.13-.063zm1.84-9.28a.557.557 0 0 1 .367-.153.418.418 0 0 1 .144.024.627.627 0 0 1 .355.54 8.16 8.16 0 0 1-.47 2.71l-.01-.02c-.797-1.525-.794-2.736-.387-3.102zm-.424 8.02l1.17-2.792a69.42 69.42 0 0 0 1.709 1.937c-.947.21-2.358.678-2.88.854zm7.094.67a.552.552 0 0 1-.485.22 3.2 3.2 0 0 1-1.94-1.154l.178-.032a7.814 7.814 0 0 1 1.292-.168.894.894 0 0 1 .96.522.646.646 0 0 1-.005.613z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M27 9.699L19.3 2H5v28h22zM26 29H6V3h12v8h8zm-7-19V3l7 7zm-3.667 7.362a12.386 12.386 0 0 0 .726-4.195 1.49 1.49 0 0 0-.966-1.288 1.425 1.425 0 0 0-.48-.082 1.587 1.587 0 0 0-1.055.414c-.871.781-.784 2.411.234 4.36.044.084.088.182.135.287a2.02 2.02 0 0 0 .338.584c-.349 1.09-.837 2.273-1.267 3.316l-.262.723a9.577 9.577 0 0 0-1.417.632c-1.742.998-2.794 1.926-2.26 3.208a1.194 1.194 0 0 0 .917.745 1.376 1.376 0 0 0 .24.02 2.44 2.44 0 0 0 1.69-.846 11.293 11.293 0 0 0 1.527-2.947c1.119-.386 2.587-.771 3.94-1.082a7.838 7.838 0 0 0 2.996 1.946 2.233 2.233 0 0 0 .443.047 1.403 1.403 0 0 0 1.133-.509 1.72 1.72 0 0 0 .142-1.774 1.778 1.778 0 0 0-1.567-1.066l-.174-.003a12.714 12.714 0 0 0-2.571.352 25.241 25.241 0 0 1-2.441-2.842zM12.31 22.62c-.412.98-1.101 2.618-1.919 2.618a.682.682 0 0 1-.16-.02.65.65 0 0 1-.388-.603c.002-.297.204-1.076 2.054-1.89.1-.045.21-.099.327-.156l.135-.066zm1.915-9.664a.58.58 0 0 1 .383-.16.435.435 0 0 1 .15.026.653.653 0 0 1 .37.563 8.5 8.5 0 0 1-.49 2.822l-.011-.022c-.83-1.587-.826-2.849-.402-3.23zm-.441 8.351l1.218-2.907c.56.672 1.46 1.666 1.78 2.017-.986.22-2.456.707-2.998.89zM18.832 21a8.138 8.138 0 0 1 1.345-.175.93.93 0 0 1 1 .544.673.673 0 0 1-.006.637.575.575 0 0 1-.505.23 3.333 3.333 0 0 1-2.02-1.203z"
  }));
};

var _default = FilePdfIcon;
exports["default"] = _default;