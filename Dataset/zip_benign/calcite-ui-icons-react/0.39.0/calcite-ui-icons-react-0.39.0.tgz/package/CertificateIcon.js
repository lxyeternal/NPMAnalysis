"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CertificateIcon = function CertificateIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M0 0h16v14h-2v-1h1V1H1v12h6v1H0zm11 2H5v1h6zM5 8H2v1h3zm-3 3h2v-1H2zm6 4.92v-4.978a3.5 3.5 0 1 1 5 0v4.978l-2.5-1.586zm4-1.818v-2.453a3.38 3.38 0 0 1-3 0v2.453l1.5-.952zM8 8.5A2.5 2.5 0 1 0 10.5 6 2.503 2.503 0 0 0 8 8.5zm2 1.5h1V9h1V8h-1V7h-1v1H9v1h1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M23 1v18h-3v-1h2V2H2v16h8v1H1V1zm-7 2H8v1h8zm-2 3V5h-4v1zm-7 5H3v1h4zm0 2H3v1h4zm-4 3h2v-1H3zm14-3a2 2 0 1 1-2-2 2.002 2.002 0 0 1 2 2zm-1 0a1 1 0 1 0-1 1 1.001 1.001 0 0 0 1-1zm.002-4.293a.965.965 0 0 0 1.32.55 1.08 1.08 0 0 1 1.213.207 1.066 1.066 0 0 1 .21 1.21.966.966 0 0 0 .548 1.324 1.064 1.064 0 0 1 0 2.004.965.965 0 0 0-.549 1.323A1.05 1.05 0 0 1 18 16.816v7.046l-3-2.538-3 2.538v-7.046a1.05 1.05 0 0 1-.744-1.49.965.965 0 0 0-.549-1.324 1.064 1.064 0 0 1 0-2.004.966.966 0 0 0 .549-1.324 1.066 1.066 0 0 1 .209-1.21 1.08 1.08 0 0 1 1.212-.206.965.965 0 0 0 1.32-.551 1.064 1.064 0 0 1 2.005 0zm.998 13v-5.04a.93.93 0 0 0-.998.625 1.064 1.064 0 0 1-2.004 0 .93.93 0 0 0-.998-.625v5.039l2-1.692zm-1.94-4.749a1.967 1.967 0 0 1 1.853-1.308 2.12 2.12 0 0 1 .87.197l.058-.091a1.964 1.964 0 0 1 1.116-2.695v-.122a1.966 1.966 0 0 1-1.116-2.695l-.087-.084a1.965 1.965 0 0 1-2.694-1.117h-.12a1.965 1.965 0 0 1-2.694 1.117l-.087.084a1.966 1.966 0 0 1-1.116 2.695v.122a1.964 1.964 0 0 1 1.116 2.695l.058.09a2.12 2.12 0 0 1 .87-.196 1.967 1.967 0 0 1 1.853 1.308L15 17z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 2h28v22h-4v-1h3V3H3v20h12v1H2zm20 3H10v1h12zm-4 3V7h-4v1zm-8 8H5v1h5zm0 2H5v1h5zm-5 3h3v-1H5zm13-3.5a2.5 2.5 0 1 1 2.5 2.5 2.503 2.503 0 0 1-2.5-2.5zm1 0a1.5 1.5 0 1 0 1.5-1.5 1.502 1.502 0 0 0-1.5 1.5zm-5 0a1.258 1.258 0 0 1 .831-1.18 1.454 1.454 0 0 0 .827-1.993 1.252 1.252 0 0 1 1.67-1.668 1.454 1.454 0 0 0 1.992-.826 1.252 1.252 0 0 1 2.36 0 1.454 1.454 0 0 0 1.992.826 1.269 1.269 0 0 1 1.424.244 1.256 1.256 0 0 1 .245 1.423 1.454 1.454 0 0 0 .825 1.994 1.252 1.252 0 0 1 .002 2.36 1.454 1.454 0 0 0-.827 1.993A1.244 1.244 0 0 1 24 22.438v8.817l-3.5-3.456-3.5 3.456v-8.817a1.272 1.272 0 0 1-1.095-.34 1.257 1.257 0 0 1-.247-1.424 1.453 1.453 0 0 0-.825-1.994A1.254 1.254 0 0 1 14 17.5zm9 11.362V22.21a1.418 1.418 0 0 0-1.32.957 1.252 1.252 0 0 1-2.36.002 1.456 1.456 0 0 0-.812-.857A1.478 1.478 0 0 0 18 22.21v6.652l2.5-2.467zM15 17.5a.254.254 0 0 0 .168.238 2.453 2.453 0 0 1 1.394 3.365.254.254 0 0 0 .05.287.245.245 0 0 0 .283.05 2.453 2.453 0 0 1 3.368 1.394.263.263 0 0 0 .474-.002 2.454 2.454 0 0 1 3.366-1.394.252.252 0 0 0 .335-.336 2.452 2.452 0 0 1 1.395-3.364.253.253 0 0 0-.002-.476 2.453 2.453 0 0 1-1.393-3.365.258.258 0 0 0-.049-.287.248.248 0 0 0-.284-.05 2.452 2.452 0 0 1-3.367-1.392.263.263 0 0 0-.475 0 2.454 2.454 0 0 1-3.366 1.394.248.248 0 0 0-.287.05.253.253 0 0 0-.048.286 2.453 2.453 0 0 1-1.394 3.364.255.255 0 0 0-.168.238z"
  }));
};

var _default = CertificateIcon;
exports["default"] = _default;