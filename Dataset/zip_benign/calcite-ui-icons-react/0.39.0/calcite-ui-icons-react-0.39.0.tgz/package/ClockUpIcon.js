"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var ClockUpIcon = function ClockUpIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M9 8.5A4.5 4.5 0 1 0 4.5 13 4.5 4.5 0 0 0 9 8.5zm-8 0A3.5 3.5 0 1 1 4.5 12 3.504 3.504 0 0 1 1 8.5zM6 9H4V6h1v2h1zm6.518-6.191l2.808 2.81-.707.706L13 4.705V13h-1V4.74l-1.585 1.585-.707-.707z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M19 19V5.707l-2.646 2.647-.707-.707L19.5 3.793l3.854 3.854-.707.707L20 5.707V19zM7 5.2A6.8 6.8 0 1 1 .2 12 6.799 6.799 0 0 1 7 5.2zM1.2 12A5.8 5.8 0 1 0 7 6.2 5.806 5.806 0 0 0 1.2 12zm8.8 0H7V8H6v5h4z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 26.8A10.8 10.8 0 1 0 1.2 16 10.8 10.8 0 0 0 12 26.8zm0-20.6A9.8 9.8 0 1 1 2.2 16 9.811 9.811 0 0 1 12 6.2zM16 17h-5v-7h1v6h4zM27.5 4.793l3.854 3.854-.707.707L28 6.707V27h-1V6.707l-2.646 2.647-.707-.707z"
  }));
};

var _default = ClockUpIcon;
exports["default"] = _default;