"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CameraPlusIcon = function CameraPlusIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M16 4.5v8a1.502 1.502 0 0 1-1.5 1.5H9v-1h5.5a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5H14a1.001 1.001 0 0 1-1-1H8a1.001 1.001 0 0 1-1 1H5V3H3v1H1.5a.5.5 0 0 0-.5.5V10H0V4.5A1.502 1.502 0 0 1 1.5 3H2V2h4v1h1a1.001 1.001 0 0 1 1-1h5a1.001 1.001 0 0 1 1 1h.5A1.502 1.502 0 0 1 16 4.5zm-11 1V5H2v1h3zm2 3a3.5 3.5 0 1 1 3.5 3.5A3.504 3.504 0 0 1 7 8.5zm1 0A2.5 2.5 0 1 0 10.5 6 2.5 2.5 0 0 0 8 8.5zM4 12V9H3v3H0v1h3v3h1v-3h3v-1z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M14.5 17a4.5 4.5 0 1 0-4.5-4.5 4.505 4.505 0 0 0 4.5 4.5zm0-8a3.5 3.5 0 1 1-3.5 3.5A3.504 3.504 0 0 1 14.5 9zM8 9H4V8h4zm4 10.999V19h9a1.001 1.001 0 0 0 1-1V8a1.001 1.001 0 0 0-1-1h-1.5A1.502 1.502 0 0 1 18 5.5a.5.5 0 0 0-.5-.5h-6a.5.5 0 0 0-.5.5A1.502 1.502 0 0 1 9.5 7H7V6H5v1H3a1.001 1.001 0 0 0-1 1v8H1V8a2.002 2.002 0 0 1 2-2h1V5h4v1h1.5a.5.5 0 0 0 .5-.5A1.502 1.502 0 0 1 11.5 4h6A1.502 1.502 0 0 1 19 5.5a.5.5 0 0 0 .5.5H21a2.002 2.002 0 0 1 2 2v10a2.002 2.002 0 0 1-2 2zM6 23H5v-4.001H1V18h4v-4h1v4h4v.999H6z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11 13H6v-1h5v1zm16.5 13a2.503 2.503 0 0 0 2.5-2.5v-12A2.503 2.503 0 0 0 27.5 9H27a1.001 1.001 0 0 1-1-1 2.002 2.002 0 0 0-2-2h-8a2.002 2.002 0 0 0-2 2 1.001 1.001 0 0 1-1 1h-2V8H6v1H4.5A2.503 2.503 0 0 0 2 11.5V22h1V11.5A1.502 1.502 0 0 1 4.5 10H7V9h3v1h3a2.002 2.002 0 0 0 2-2 1.001 1.001 0 0 1 1-1h8a1.001 1.001 0 0 1 1 1 2.002 2.002 0 0 0 2 2h.5a1.502 1.502 0 0 1 1.5 1.5v12a1.502 1.502 0 0 1-1.5 1.5H15v.999zm-13.3-9a5.8 5.8 0 1 1 5.8 5.8 5.806 5.806 0 0 1-5.8-5.8zm1 0a4.8 4.8 0 1 0 4.8-4.8 4.805 4.805 0 0 0-4.8 4.8zM8 24.999h5V24H8v-5H7v5H2v.999h5V30h1z"
  }));
};

var _default = CameraPlusIcon;
exports["default"] = _default;