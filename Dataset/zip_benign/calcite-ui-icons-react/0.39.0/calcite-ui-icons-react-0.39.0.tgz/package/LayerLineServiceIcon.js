"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var LayerLineServiceIcon = function LayerLineServiceIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.207 12.2A6.624 6.624 0 0 1 16 13.29L13.867.687a8.205 8.205 0 0 0-3.161-.674C8.016.014 7.982 1 5.294 1A10.39 10.39 0 0 1 2.133.488L0 13.09a9.158 9.158 0 0 0 3.793.711A10.667 10.667 0 0 0 7 13.322V15H2v1h11v-1H8v-2a11.89 11.89 0 0 1 4.207-.8zm-11.082.237L2.935 1.74A11.376 11.376 0 0 0 5.294 2a7.833 7.833 0 0 0 3.045-.552 5.895 5.895 0 0 1 2.367-.434 7.213 7.213 0 0 1 2.27.399l1.72 10.163a8.317 8.317 0 0 0-2.489-.376 12.79 12.79 0 0 0-4.526.852 10.962 10.962 0 0 1-3.888.748 9.54 9.54 0 0 1-2.668-.363zM7 9H4V8h3V3h1v2h4v1H8v5H7z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 16v-3H7v-1h5V3h1v3h5v1h-5v9zm1 7h8v1H4v-1h8v-3.912a22.094 22.094 0 0 1-5.576.712A13.093 13.093 0 0 1 1 18.783L4.05 1.078a15.028 15.028 0 0 0 4.52.722c3.849 0 3.893-1.6 7.74-1.6a12.673 12.673 0 0 1 4.52.878l3.051 18.105a13.093 13.093 0 0 0-5.423-1.017A21.892 21.892 0 0 0 13 18.85zm-6.576-4.2a22.051 22.051 0 0 0 5.783-.79 24.033 24.033 0 0 1 6.25-.844 16.248 16.248 0 0 1 4.158.52l-2.674-15.87a11.859 11.859 0 0 0-3.63-.615 7.791 7.791 0 0 0-3.49.725 9.805 9.805 0 0 1-4.25.875 16.193 16.193 0 0 1-3.723-.457L2.124 18.15a13.727 13.727 0 0 0 4.3.65z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 26.5a21.425 21.425 0 0 1 7.462-1.3A33.153 33.153 0 0 1 31 26L27 1.9a26.401 26.401 0 0 0-5.926-.689c-5.144 0-5.927 1.657-10.735 1.657A14.99 14.99 0 0 1 5 1.9L1 26a16.273 16.273 0 0 0 7.538 1.8A20.258 20.258 0 0 0 15 26.816V30H3v1h25v-1H16zm-7.462.3a15.989 15.989 0 0 1-6.43-1.366L5.794 3.217a15.6 15.6 0 0 0 4.544.651 17.42 17.42 0 0 0 5.445-.847 16.628 16.628 0 0 1 5.29-.81 26.164 26.164 0 0 1 5.05.518l3.651 21.999a37.286 37.286 0 0 0-6.313-.528 22.381 22.381 0 0 0-7.77 1.348A20.422 20.422 0 0 1 8.539 26.8zM15 23v-4H8v-1h7V7h1v3h7v1h-7v12z"
  }));
};

var _default = LayerLineServiceIcon;
exports["default"] = _default;