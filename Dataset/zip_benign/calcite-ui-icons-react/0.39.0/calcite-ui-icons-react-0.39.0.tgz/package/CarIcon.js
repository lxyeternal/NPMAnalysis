"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var CarIcon = function CarIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 8v6h3v-2h8v2h3V8a1.996 1.996 0 0 0-1.505-1.93L13.482 6H15V5h-1.702l-.296-1.605A1.829 1.829 0 0 0 11.394 2H4.606a1.829 1.829 0 0 0-1.608 1.395L2.702 5H1v1h1.518l-.013.07A1.996 1.996 0 0 0 1 8zm2 5H2v-1h1zm11 0h-1v-1h1zM3.981 3.576C4.056 3.32 4.368 3 4.606 3h6.788c.238 0 .55.32.643.658L12.467 6H3.534zM3 7h10a1 1 0 0 1 1 1h-1l-1 2h1a1 1 0 0 0 1-1v2H2V9a1 1 0 0 0 1 1h1L3 8H2a1 1 0 0 1 1-1zm8 3H5V9h6z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M17.197 5.46A.824.824 0 0 0 16.5 5h-9a.824.824 0 0 0-.697.46l-1.988 4.638L5.285 9H3v1.5a.501.501 0 0 0 .5.5 2.572 2.572 0 0 1 .367-.388A2.532 2.532 0 0 0 3 12.522V19.5a.501.501 0 0 0 .5.5h2a.501.501 0 0 0 .5-.5v-1.831A46.229 46.229 0 0 0 12 18a46.244 46.244 0 0 0 6.001-.331L18 19.5a.501.501 0 0 0 .5.5h2a.501.501 0 0 0 .5-.5v-6.978a2.534 2.534 0 0 0-.87-1.909 2.523 2.523 0 0 1 .359.387h.011a.501.501 0 0 0 .5-.5V9h-2.286zM7.66 6h8.68l1.715 4H5.945zM5 19H4v-1.79a1.983 1.983 0 0 0 .613.235c.118.024.254.048.387.071zm15 0h-1v-1.484c.133-.023.269-.047.387-.07A1.989 1.989 0 0 0 20 17.21zm-.525-7.632A1.53 1.53 0 0 1 20 12.522v2.946a1.015 1.015 0 0 1-.808.997A43.178 43.178 0 0 1 12 17a43.255 43.255 0 0 1-7.192-.535A1.015 1.015 0 0 1 4 15.468v-2.946a1.532 1.532 0 0 1 .524-1.156 1.49 1.49 0 0 1 .568-.307L5.296 11h13.406l.205.06a1.493 1.493 0 0 1 .568.308zM17 13h2v1a1 1 0 0 1-1 1h-2zM7 13l1 2H6a1 1 0 0 1-1-1v-1zm2 1h6v1H9z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13 21h6a2.002 2.002 0 0 0 2-2v-1H11v1a2.002 2.002 0 0 0 2 2zm7-2a1.001 1.001 0 0 1-1 1h-6a1.001 1.001 0 0 1-1-1zm3.496-10.7a2.42 2.42 0 0 0-2.15-1.3H10.654a2.42 2.42 0 0 0-2.152 1.302L6.702 12H3v1.075a1.924 1.924 0 0 0 1.878 1.92A3.152 3.152 0 0 0 4 17.161v9.127a.713.713 0 0 0 .712.712h2.576A.713.713 0 0 0 8 26.288v-1.565l.046.005C10.147 24.93 12.972 25 16 25c3.682 0 6.23-.082 8-.267v1.555a.713.713 0 0 0 .712.712h2.576a.713.713 0 0 0 .712-.712v-9.127a3.152 3.152 0 0 0-.878-2.166A1.924 1.924 0 0 0 29 13.075V12h-3.702zm-14.094.44A1.422 1.422 0 0 1 10.655 8h10.69a1.42 1.42 0 0 1 1.253.74l2.526 5.186-.154.074H7.04l-.161-.077zM4 13.074V13h2.215l-.487 1h-.804A.926.926 0 0 1 4 13.075zM7 26H5v-1.777a11.7 11.7 0 0 0 2 .388zm20 0h-2v-1.388a11.194 11.194 0 0 0 2-.43zm1-13v.075a.926.926 0 0 1-.924.925h-.804l-.487-1zm-2.092 2.287a2.137 2.137 0 0 1 .337.227A2.165 2.165 0 0 1 27 17.159L24 18l-3 3h4a2.955 2.955 0 0 0 2-1.307v3.416c-1.428.79-6.765.922-11 .941-3.035-.022-9.537-.116-11-.896v-3.461A2.955 2.955 0 0 0 7 21h4l-3-3-3-.84a2.077 2.077 0 0 1 1.096-1.875L6.591 15h18.845zm.633 3.04A2.196 2.196 0 0 1 24.937 20h-1.523l1.108-1.107zm-21.082 0l2.02.566L8.585 20H7.063a2.196 2.196 0 0 1-1.604-1.674z"
  }));
};

var _default = CarIcon;
exports["default"] = _default;