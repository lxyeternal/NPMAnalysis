"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var GeonetQuestionIcon = function GeonetQuestionIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12 12h4V0H0v12h8.3l3.7 3.7zm-1 1.286L8.714 11H1V1h14v10h-4zM9.5 9.5a1 1 0 1 1-1-1 1 1 0 0 1 1 1zm1.514-5.23a2.617 2.617 0 0 1-1.032 1.934C9.462 6.715 9 6.995 9 8H8a3.046 3.046 0 0 1 1.282-2.51c.47-.462.736-.746.732-1.217a1.324 1.324 0 0 0-1.46-1.27 1.418 1.418 0 0 0-1.548 1.394h-1c0-3.09 5.009-3.154 5.008-.128z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M1 18h10.255L16 22.745V18h7V2H1zM2 3h20v14h-7v3.331L11.668 17H2zm9.5 11.5a1 1 0 1 1 1 1 1 1 0 0 1-1-1zm1.085-9.445A2.036 2.036 0 0 0 10.376 7h-1.08a2.869 2.869 0 0 1 1.046-2.235 3.56 3.56 0 0 1 2.22-.76 2.907 2.907 0 0 1 3.151 2.899 3.331 3.331 0 0 1-1.296 2.458l-.137.133A2.99 2.99 0 0 0 13.034 12H11.97a3.945 3.945 0 0 1 1.49-3.2c.132-.128.26-.252.38-.375a2.208 2.208 0 0 0 .795-1.404 2.068 2.068 0 0 0 0-.286 1.883 1.883 0 0 0-2.05-1.68z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 24h15.875L24 30.125V24h6V4H2zM3 5h26v18h-6v4.71L18.29 23H3zm15.504 7.958A3.636 3.636 0 0 0 17 16h-1a4.62 4.62 0 0 1 1.803-3.755c.672-.66 1.203-1.182 1.197-2.049A2.188 2.188 0 0 0 16.607 8a2.419 2.419 0 0 0-2.624 2.39h-1a3.19 3.19 0 0 1 1.163-2.557A3.88 3.88 0 0 1 16.606 7 3.173 3.173 0 0 1 20 10.193a3.732 3.732 0 0 1-1.496 2.765zM17.5 19.5a1 1 0 1 1-1-1 1 1 0 0 1 1 1z"
  }));
};

var _default = GeonetQuestionIcon;
exports["default"] = _default;