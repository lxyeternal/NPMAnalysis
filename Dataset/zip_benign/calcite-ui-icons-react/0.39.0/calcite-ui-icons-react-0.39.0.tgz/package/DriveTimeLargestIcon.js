"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireDefault(require("react"));

var _excluded = ["color", "size", "className", "children"];

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

var DriveTimeLargestIcon = function DriveTimeLargestIcon(_ref) {
  var _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'currentColor' : _ref$color,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 24 : _ref$size,
      className = _ref.className,
      children = _ref.children,
      props = _objectWithoutProperties(_ref, _excluded);

  var classes = 'calcite-icon';
  if (className) classes += " ".concat(className);

  if (size <= 16) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 16 16",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M7.992 12l.268 1H6.845L3 15v-4.667l-.774-1.166L.01 9l2.216-6h2.31l2.31-2h3.464l1.154 2H15l-3.416 3.444 2.895 2.212-2.537-.68-1.87-1.428L12.6 4h-1.713L9.732 2H7.22L4.91 4H2.922L1.399 8.103l1.39.103L4 10.031v3.322L6.602 12zm-.23-4.237a1.715 1.715 0 0 1 1.654-.458L8.56 6.65l1.708-1.721L9.155 3H7.592l-2.31 2H3.617L2.8 7.204l.552.041L5 9.73v1.977L6.357 11h1.367L7.31 9.453a1.75 1.75 0 0 1 .453-1.69zM9 9l1.514 5.652a5.86 5.86 0 0 0 4.138-4.138z"
    }));
  }

  if (size <= 24) {
    return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
      width: size,
      height: size,
      fill: color,
      viewBox: "0 0 24 24",
      className: classes
    }), /*#__PURE__*/_react["default"].createElement("path", {
      d: "M12.528 18l.268 1h-2.16L5 22v-6.667l-.963-1.666-3.18-.238L4.037 5h3.121l3.3-3h4.948l1.65 3h5.23l-4.68 4.778 4.778 3.65-.192.223-1.792-.48-4.3-3.285L19.906 6h-3.441l-1.65-3h-3.97l-3.3 3H4.729l-2.465 6.531 2.375.178L6 15.064v5.271L10.387 18zm2.631-10.222L13.632 5h-2.015L8.32 8H6.112l-1.033 2.736.646.05L8 14.427v2.515L9.87 16h2.122l-.682-2.547a1.75 1.75 0 0 1 .26-1.461c.055-.078.482-.57 3.59-4.214zM13 13l2.524 9.42a9.768 9.768 0 0 0 6.896-6.896z"
    }));
  }

  return /*#__PURE__*/_react["default"].createElement("svg", _extends({}, props, {
    width: size,
    height: size,
    fill: color,
    viewBox: "0 0 32 32",
    className: classes
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17.332 25l.268 1h-3.294L7 29.8v-8.867l-1.47-2.216L1.6 18 5.53 7h3.54l4.62-4h6.928l2.31 4H30.4l-6.49 6.544 6.054 4.856-.197.209-1.714-.46-5.636-4.52L28 8h-5.648l-2.31-4h-5.979L9.444 8h-3.21l-3.297 9.228 3.19.582L8 20.632v7.52L14.062 25zm-1.57-9.237a1.75 1.75 0 0 1 1.69-.453l5.801 1.554-3.821-3.066 2.502-2.522L18.887 6h-4.078l-4.62 4H7.645l-2.032 5.683 1.71.311L10 20.028v4.83L13.572 23h3.224l-1.486-5.547a1.75 1.75 0 0 1 .453-1.69zM17 17l3.534 13.188a13.675 13.675 0 0 0 9.654-9.654z"
  }));
};

var _default = DriveTimeLargestIcon;
exports["default"] = _default;