const CommonjsPlug = require('@etcpack/commonjs-plug');

module.exports = {

    devServer: {
        contentBase: "./",
        port: 20000
    },
    mode: "development",

    // 打包入口
    entry: './test/index.js',

    // 打包出口
    output: './test/dist.js',

    loader: [{
        test: /\.clunch$/,
        handler: ['clunch/loader.js']
    }, {
        test: /\.json$/,
        handler: [function (source) {
            return "export default " + source;
        }]
    }],

    plug: [
        new CommonjsPlug()
    ]
};
