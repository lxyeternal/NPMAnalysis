"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorService = void 0;
const calc_error_1 = require("./calc-error");
class ErrorService {
    static getInstance() {
        if (!this.instance) {
            this.instance = new ErrorService();
        }
        return this.instance;
    }
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {
        this.errorEventEmitter = null;
    }
    onError(calle) {
        this.errorEventEmitter = calle;
    }
    emitError(config, error) {
        const calcError = new calc_error_1.CalcError(error);
        if (config.thrownStrategy === 'emit-event') {
            if (this.errorEventEmitter) {
                this.errorEventEmitter(calcError);
            }
        }
        else if (config.thrownStrategy === 'console') {
            console.error(calcError);
        }
        else {
            throw calcError;
        }
    }
}
exports.ErrorService = ErrorService;
ErrorService.instance = null;
//# sourceMappingURL=error.service.js.map