"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalcError = void 0;
class CalcError extends Error {
}
exports.CalcError = CalcError;
//# sourceMappingURL=calc-error.js.map