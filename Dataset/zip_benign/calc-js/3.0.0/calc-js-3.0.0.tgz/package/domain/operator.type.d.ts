export type Operator = '+' | '-' | '/' | '*';
