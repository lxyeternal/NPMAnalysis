"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigService = void 0;
class ConfigService {
    static getInstance() {
        if (!this.instance) {
            this.instance = new ConfigService();
        }
        return this.instance;
    }
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() { }
    static configure(config) {
        ConfigService.defaultConfig = this.mergeConfigs(this.defaultConfig, config);
    }
    static mergeConfigs(config, mergeWith) {
        return { ...config, ...mergeWith };
    }
    createConfigs(customConfig) {
        return ConfigService.mergeConfigs(ConfigService.defaultConfig, customConfig);
    }
}
exports.ConfigService = ConfigService;
ConfigService.instance = null;
ConfigService.defaultConfig = {
    thrownStrategy: 'emit-event',
    throwNaN: true,
    throwInfinite: true,
    throwUnsafeNumber: true
};
//# sourceMappingURL=config.service.js.map