"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalcBuild = void 0;
const config_service_1 = require("../config/config.service");
const number_validator_1 = require("../validator/number.validator");
const error_service_1 = require("./../error/error.service");
const divide_1 = require("./divide");
const minus_1 = require("./minus");
const multiply_1 = require("./multiply");
const sum_1 = require("./sum");
class CalcBuild {
    static getInstance() {
        if (!this.instance) {
            this.instance = new CalcBuild();
        }
        return this.instance;
    }
    static configure(config) {
        config_service_1.ConfigService.configure(config);
    }
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() {
        this.numberValidator = number_validator_1.NumberValidator.getInstance();
        this.errorService = error_service_1.ErrorService.getInstance();
    }
    calculate(equation, config) {
        this.validateEquation(equation, config);
        const executedEquation = this.createExecutedEquation(equation);
        const equationCopy = [].concat(equation.operations);
        let operation;
        let finalResult = equation.baseNumber;
        while (operation = equationCopy.shift()) {
            if (typeof operation === 'function') {
                finalResult = operation(finalResult);
            }
            else {
                finalResult = CalcBuild.calcMap[operation.type](finalResult, operation.value);
            }
            executedEquation.operations.push(operation);
            this.validate(finalResult, executedEquation, equation, config);
        }
        return finalResult;
    }
    createExecutedEquation(equation) {
        return {
            baseNumber: equation.baseNumber,
            operations: []
        };
    }
    validate(value, executedEquation, equation, config) {
        const errorMessage = this.numberValidator.validate(value, executedEquation, equation, config);
        if (errorMessage) {
            this.errorService.emitError(config, errorMessage);
        }
    }
    validateEquation(equation, config) {
        this.validate(equation.baseNumber, null, equation, config);
        equation.operations.forEach(operation => {
            if (typeof operation !== 'function') {
                this.validate(operation.value, null, equation, config);
            }
        });
    }
}
exports.CalcBuild = CalcBuild;
CalcBuild.instance = null;
CalcBuild.calcMap = {
    '+': sum_1.sum,
    '-': minus_1.minus,
    '/': divide_1.divide,
    '*': multiply_1.multiply
};
//# sourceMappingURL=calc-build.js.map