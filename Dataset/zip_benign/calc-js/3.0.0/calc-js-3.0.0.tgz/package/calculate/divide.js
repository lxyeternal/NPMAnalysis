"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.divide = void 0;
function divide(n1, n2) {
    let length = String(n1 / n2).replace(/\d+\.?/, '').length;
    let baseDecimal = '1';
    while (length--) {
        baseDecimal = `${baseDecimal}0`;
    }
    baseDecimal = Number(baseDecimal);
    n1 = Math.round(n1 * baseDecimal);
    return (n1 / n2) / baseDecimal;
}
exports.divide = divide;
//# sourceMappingURL=divide.js.map