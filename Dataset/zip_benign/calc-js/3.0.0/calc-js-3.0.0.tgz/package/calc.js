"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Calc = void 0;
const calc_build_1 = require("./calculate/calc-build");
const config_service_1 = require("./config/config.service");
const equation_type_guard_1 = require("./equation.type-guard");
const error_service_1 = require("./error/error.service");
const number_validator_1 = require("./validator/number.validator");
class Calc {
    /**
     * It will throw (or console it) if this isn't a valid number.
     * @returns if is valid return true, if is invalid return false.
     *
     * @param value
     * Number to be verified
     *
     * @param complementaryErrorMessage
     * Aditional information to add to the error object (this will come first)
     *
     * @param config
     * Some overriden configuration
     */
    static checkNumber(value, complementaryErrorMessage, config) {
        const errorMessage = number_validator_1.NumberValidator.getInstance().validateSingleNumber(value, complementaryErrorMessage, config);
        if (errorMessage) {
            const definitiveConfig = config_service_1.ConfigService.getInstance().createConfigs(config);
            error_service_1.ErrorService.getInstance().emitError(definitiveConfig, errorMessage);
            return false;
        }
        return true;
    }
    static onError(calle) {
        error_service_1.ErrorService.getInstance().onError(calle);
    }
    static configure(config) {
        config_service_1.ConfigService.configure(config);
    }
    static sum(x, y, config) {
        return new Calc(x, config).sum(y).finish();
    }
    static minus(x, y, config) {
        return new Calc(x, config).minus(y).finish();
    }
    static divide(x, y, config) {
        return new Calc(x, config).divide(y).finish();
    }
    static multiply(x, y, config) {
        return new Calc(x, config).multiply(y).finish();
    }
    constructor(baseNumber, customConfig) {
        this.baseNumber = baseNumber;
        this.calcBuild = calc_build_1.CalcBuild.getInstance();
        this.configService = config_service_1.ConfigService.getInstance();
        this.operations = [];
        this.customConfig = config_service_1.ConfigService.defaultConfig;
        this.customConfig = this.configService.createConfigs(customConfig);
    }
    sum(value) {
        this.operations.push({ type: '+', value });
        return this;
    }
    minus(value) {
        this.operations.push({ type: '-', value });
        return this;
    }
    divide(value) {
        this.operations.push({ type: '/', value });
        return this;
    }
    multiply(value) {
        this.operations.push({ type: '*', value });
        return this;
    }
    pipe(lambda) {
        this.operations.push(lambda);
        return this;
    }
    valueOf() {
        return this.finish();
    }
    finish() {
        const operations = this.operations;
        const baseNumber = this.baseNumber;
        if ((0, equation_type_guard_1.equationTypeGuard)(operations)) {
            return this.calcBuild.calculate({
                baseNumber, operations
            }, this.customConfig);
        }
        return baseNumber;
    }
}
exports.Calc = Calc;
//# sourceMappingURL=calc.js.map