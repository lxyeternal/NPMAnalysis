"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NumberValidator = void 0;
const config_service_1 = require("./../config/config.service");
const equation_stringify_1 = require("./equation.stringify");
class NumberValidator {
    static getInstance() {
        if (!this.instance) {
            this.instance = new NumberValidator();
        }
        return this.instance;
    }
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor() { }
    validate(value, executedEquation, completeEquation, calcConfig) {
        const errorMessage = this.validateSingleNumber(value, undefined, calcConfig);
        if (errorMessage) {
            return this.generateErrorMessage(value, executedEquation, completeEquation, errorMessage);
        }
        return null;
    }
    validateSingleNumber(value, complementaryErrorMessage, customConfig) {
        const config = config_service_1.ConfigService.getInstance().createConfigs(customConfig);
        if (config.throwNaN) {
            const checkNaNMessage = this.checkNaN(value);
            if (checkNaNMessage) {
                return this.joinMessages(checkNaNMessage, complementaryErrorMessage);
            }
        }
        if (config.throwInfinite) {
            const checkInfiniteMessage = this.checkInfinite(value);
            if (checkInfiniteMessage) {
                return this.joinMessages(checkInfiniteMessage, complementaryErrorMessage);
            }
        }
        if (config.throwUnsafeNumber) {
            const checkUnsafeNumberMessage = this.checkUnsafeNumber(value);
            if (checkUnsafeNumberMessage) {
                return this.joinMessages(checkUnsafeNumberMessage, complementaryErrorMessage);
            }
        }
        return null;
    }
    joinMessages(message, complementaryErrorMessage) {
        if (complementaryErrorMessage) {
            return `${complementaryErrorMessage}\n${message}`;
        }
        return message;
    }
    generateErrorMessage(value, executedEquation, completeEquation, errorMessage) {
        const completeEquationStr = (0, equation_stringify_1.equationStringify)(completeEquation);
        if (executedEquation) {
            if (executedEquation.operations.length === completeEquation.operations.length) {
                return `Invalid result value in equation ${completeEquationStr}, ${errorMessage}`;
            }
            else {
                const executedEquationStr = (0, equation_stringify_1.equationStringify)(executedEquation);
                return `Invalid result value in ${executedEquationStr} in equation ${completeEquationStr}, ${errorMessage}`;
            }
        }
        else {
            return `Invalid value ${value} in equation ${completeEquationStr}, ${errorMessage}`;
        }
    }
    checkNaN(value) {
        if (isNaN(value)) {
            return `NaN was found`;
        }
        return null;
    }
    checkInfinite(value) {
        if (!Number.isFinite(value) && !Number.isNaN(value)) {
            return `infinite value was found`;
        }
        return null;
    }
    checkUnsafeNumber(value) {
        const isSafeInteger = !!String(value).split('.').find(str => !Number.isSafeInteger(Number(str)));
        if (isSafeInteger) {
            return `${value} is not a secure number`;
        }
        return null;
    }
}
exports.NumberValidator = NumberValidator;
NumberValidator.instance = null;
//# sourceMappingURL=number.validator.js.map