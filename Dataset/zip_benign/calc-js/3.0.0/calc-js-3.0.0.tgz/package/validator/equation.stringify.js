"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.equationStringify = void 0;
function equationStringify(equation) {
    let stringifiedEquation = String(equation.baseNumber);
    const operationsCopy = [].concat(equation.operations);
    let operation;
    while (operation = operationsCopy.shift()) {
        if (typeof operation === 'function') {
            stringifiedEquation = `(${stringifiedEquation} ${operation.name}(n) => n)`;
        }
        else {
            stringifiedEquation = `(${stringifiedEquation} ${operation.type} ${operation.value})`;
        }
    }
    return stringifiedEquation;
}
exports.equationStringify = equationStringify;
//# sourceMappingURL=equation.stringify.js.map