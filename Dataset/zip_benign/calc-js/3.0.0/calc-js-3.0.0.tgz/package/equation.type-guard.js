"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.equationTypeGuard = void 0;
function equationTypeGuard(operations) {
    if (operations[0]) {
        return true;
    }
    return false;
}
exports.equationTypeGuard = equationTypeGuard;
//# sourceMappingURL=equation.type-guard.js.map