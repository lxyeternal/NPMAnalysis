npm-start(1) -- Start a package
===============================

## SYNOPSIS

    npm start [-- <args>]

## DESCRIPTION

This runs a package's "start" script, if one was provided.

## SEE ALSO

* npm-run-script(1)
* npm-scripts(7)
* npm-test(1)
* npm-restart(1)
* npm-stop(1)
