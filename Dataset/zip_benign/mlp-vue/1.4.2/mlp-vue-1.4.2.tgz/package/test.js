const MLP = require('./src/MultilayerPerceptron');

const m = new MLP(2, 1);
m.addHiddenLayer(2, 'sfmx');
m.addHiddenLayer(2, 'sfmx');
m.init();

const lr = 0.5;


m.addToTrainingSet([0, 0], [0]);
m.addToTrainingSet([1, 0], [1]);
m.addToTrainingSet([1
    , 1], [1]);
m.addToTrainingSet([0, 1], [1]);

console.log(m.train(lr));
console.log(m.train(lr));
console.log(m.train(lr));
console.log(m.train(lr));
console.log(m.train(lr));
console.log(m.train(lr));
console.log(m.train(lr));
console.log(m.train(lr));
