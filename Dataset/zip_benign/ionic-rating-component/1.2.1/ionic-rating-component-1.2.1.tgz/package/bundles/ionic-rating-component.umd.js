(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('rxjs'), require('@angular/forms'), require('@angular/common'), require('@ionic/angular')) :
    typeof define === 'function' && define.amd ? define('ionic-rating-component', ['exports', '@angular/core', 'rxjs', '@angular/forms', '@angular/common', '@ionic/angular'], factory) :
    (global = global || self, factory(global['ionic-rating-component'] = {}, global.ng.core, global.rxjs, global.ng.forms, global.ng.common, global.ionicBundle));
}(this, (function (exports, core, rxjs, forms, common, angular) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __createBinding(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
    }

    function __exportStar(m, exports) {
        for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var IonicRatingService = /** @class */ (function () {
        function IonicRatingService() {
            this.starRatingSubject = new rxjs.Subject();
            this.topicSubject = new rxjs.Subject();
        }
        IonicRatingService.prototype.publishStartRatingChanged = function (value) {
            this.starRatingSubject.next(value);
        };
        IonicRatingService.prototype.getStartRatingChangedObservable = function () {
            return this.starRatingSubject;
        };
        IonicRatingService.prototype.publishTopic = function (topic, value) {
            this.topicSubject.next({ topic: topic, value: value });
        };
        IonicRatingService.prototype.getTopicObservable = function (key) {
            return this.topicSubject[key];
        };
        IonicRatingService.ɵprov = core.ɵɵdefineInjectable({ factory: function IonicRatingService_Factory() { return new IonicRatingService(); }, token: IonicRatingService, providedIn: "root" });
        IonicRatingService = __decorate([
            core.Injectable({
                providedIn: 'root'
            })
        ], IonicRatingService);
        return IonicRatingService;
    }());

    var IonicRatingComponent = /** @class */ (function () {
        function IonicRatingComponent(ionicRatingService) {
            this.ionicRatingService = ionicRatingService;
            this.iconsArray = [];
            this.ratingChanged = new core.EventEmitter();
            this.readonly = 'false';
            this.activeColor = '#488aff';
            this.defaultColor = '#aaaaaa';
            this.activeIcon = 'star';
            this.defaultIcon = 'star-outline';
            this.halfIcon = 'star-half';
            this.halfStar = 'false';
            this.maxRating = 5;
            this.fontSize = '28px';
            this.eventInfo = (function () {
                var id = new Date().getTime();
                var topic = "star-rating:" + id + ":changed";
                return {
                    topic: topic,
                };
            })();
            this.Math = Math;
            this.parseFloat = parseFloat;
        }
        IonicRatingComponent_1 = IonicRatingComponent;
        Object.defineProperty(IonicRatingComponent.prototype, "rating", {
            get: function () {
                return this._rating;
            },
            set: function (val) {
                this._rating = val;
                if (this.onChange) {
                    this.onChange(val);
                }
            },
            enumerable: true,
            configurable: true
        });
        IonicRatingComponent.prototype.ngOnInit = function () {
            this.rating = this.rating || 3; //default after input`s initialization
            for (var i = 0; i < this.maxRating; i++) {
                this.iconsArray.push(i);
            }
        };
        IonicRatingComponent.prototype.writeValue = function (obj) {
            this.rating = obj;
        };
        IonicRatingComponent.prototype.registerOnChange = function (fn) {
            this.onChange = fn;
        };
        IonicRatingComponent.prototype.registerOnTouched = function (fn) {
            this.onTouched = fn;
        };
        IonicRatingComponent.prototype.setDisabledState = function (isDisabled) {
            this.readonly = isDisabled ? "true" : "false";
        };
        IonicRatingComponent.prototype.changeRating = function (event) {
            if (this.readonly && this.readonly === 'true')
                return;
            // event is different for firefox and chrome
            var id = event.target.id ? parseInt(event.target.id) : parseInt(event.target.parentElement.id);
            if (this.halfStar && this.halfStar === 'true') {
                this.rating = ((this.rating - id > 0) && (this.rating - id <= 0.5)) ? id + 1 : id + .5;
            }
            else {
                this.rating = id + 1;
            }
            // subscribe this event to get the changed value in your parent compoanent
            this.ionicRatingService.publishStartRatingChanged(this.rating);
            this.ionicRatingService.publishTopic(this.eventInfo.topic, this.rating);
            // unique event
            this.ratingChanged.emit(this.rating);
        };
        var IonicRatingComponent_1;
        IonicRatingComponent.ctorParameters = function () { return [
            { type: IonicRatingService }
        ]; };
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "rating", null);
        __decorate([
            core.Output()
        ], IonicRatingComponent.prototype, "ratingChanged", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "readonly", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "activeColor", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "defaultColor", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "activeIcon", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "defaultIcon", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "halfIcon", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "halfStar", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "maxRating", void 0);
        __decorate([
            core.Input()
        ], IonicRatingComponent.prototype, "fontSize", void 0);
        IonicRatingComponent = IonicRatingComponent_1 = __decorate([
            core.Component({
                selector: 'ionic-rating-component',
                template: "\n    <div class=\"ionic5-star-rating\">\n      <ion-button size=\"large\" fill=\"clear\" class=\"rate-button\" [ngStyle]=\"{'width' : fontSize, 'height' : fontSize}\" *ngFor=\"let index of iconsArray\" id=\"{{index}}\" (click)=\"changeRating($event)\">\n        <ion-icon [ngStyle]=\"{'color': ((halfStar === 'false' && index < this.Math.round(this.parseFloat(rating))) || (halfStar === 'true' && index < this.parseFloat(rating))) ? activeColor : defaultColor, 'font-size' : fontSize }\" name=\"{{(halfStar ==='true' && (rating - index > 0) && (rating - index <= 0.5)) ? halfIcon : (index < this.Math.round(this.parseFloat(rating))) ? activeIcon : defaultIcon}}\"></ion-icon>\n      </ion-button>\n    </div>\n  ",
                providers: [
                    {
                        provide: forms.NG_VALUE_ACCESSOR,
                        useExisting: IonicRatingComponent_1,
                        multi: true,
                    },
                ],
                styles: ["\n    .rate-button {\n            --padding-bottom:0;\n            --padding-end:0;\n            --padding-start:0;\n            --padding-top:0;\n    }\n  "]
            })
        ], IonicRatingComponent);
        return IonicRatingComponent;
    }());

    var IonicRatingComponentModule = /** @class */ (function () {
        function IonicRatingComponentModule() {
        }
        IonicRatingComponentModule = __decorate([
            core.NgModule({
                declarations: [IonicRatingComponent],
                imports: [
                    common.CommonModule,
                    angular.IonicModule,
                ],
                exports: [IonicRatingComponent]
            })
        ], IonicRatingComponentModule);
        return IonicRatingComponentModule;
    }());

    exports.IonicRatingComponent = IonicRatingComponent;
    exports.IonicRatingComponentModule = IonicRatingComponentModule;
    exports.IonicRatingService = IonicRatingService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ionic-rating-component.umd.js.map
