import { Subject } from 'rxjs';
export declare class IonicRatingService {
    private starRatingSubject;
    private topicSubject;
    publishStartRatingChanged(value: number): void;
    getStartRatingChangedObservable(): Subject<any>;
    publishTopic(topic: string, value: number): void;
    getTopicObservable(key: any): Subject<any>;
}
