export declare class IonicRatingComponentModule {
}
