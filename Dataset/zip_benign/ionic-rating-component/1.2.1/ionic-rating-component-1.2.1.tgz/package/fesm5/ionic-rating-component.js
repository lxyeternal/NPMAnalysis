import { __decorate } from 'tslib';
import { ɵɵdefineInjectable, Injectable, EventEmitter, Input, Output, Component, NgModule } from '@angular/core';
import { Subject } from 'rxjs';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

var IonicRatingService = /** @class */ (function () {
    function IonicRatingService() {
        this.starRatingSubject = new Subject();
        this.topicSubject = new Subject();
    }
    IonicRatingService.prototype.publishStartRatingChanged = function (value) {
        this.starRatingSubject.next(value);
    };
    IonicRatingService.prototype.getStartRatingChangedObservable = function () {
        return this.starRatingSubject;
    };
    IonicRatingService.prototype.publishTopic = function (topic, value) {
        this.topicSubject.next({ topic: topic, value: value });
    };
    IonicRatingService.prototype.getTopicObservable = function (key) {
        return this.topicSubject[key];
    };
    IonicRatingService.ɵprov = ɵɵdefineInjectable({ factory: function IonicRatingService_Factory() { return new IonicRatingService(); }, token: IonicRatingService, providedIn: "root" });
    IonicRatingService = __decorate([
        Injectable({
            providedIn: 'root'
        })
    ], IonicRatingService);
    return IonicRatingService;
}());

var IonicRatingComponent = /** @class */ (function () {
    function IonicRatingComponent(ionicRatingService) {
        this.ionicRatingService = ionicRatingService;
        this.iconsArray = [];
        this.ratingChanged = new EventEmitter();
        this.readonly = 'false';
        this.activeColor = '#488aff';
        this.defaultColor = '#aaaaaa';
        this.activeIcon = 'star';
        this.defaultIcon = 'star-outline';
        this.halfIcon = 'star-half';
        this.halfStar = 'false';
        this.maxRating = 5;
        this.fontSize = '28px';
        this.eventInfo = (function () {
            var id = new Date().getTime();
            var topic = "star-rating:" + id + ":changed";
            return {
                topic: topic,
            };
        })();
        this.Math = Math;
        this.parseFloat = parseFloat;
    }
    IonicRatingComponent_1 = IonicRatingComponent;
    Object.defineProperty(IonicRatingComponent.prototype, "rating", {
        get: function () {
            return this._rating;
        },
        set: function (val) {
            this._rating = val;
            if (this.onChange) {
                this.onChange(val);
            }
        },
        enumerable: true,
        configurable: true
    });
    IonicRatingComponent.prototype.ngOnInit = function () {
        this.rating = this.rating || 3; //default after input`s initialization
        for (var i = 0; i < this.maxRating; i++) {
            this.iconsArray.push(i);
        }
    };
    IonicRatingComponent.prototype.writeValue = function (obj) {
        this.rating = obj;
    };
    IonicRatingComponent.prototype.registerOnChange = function (fn) {
        this.onChange = fn;
    };
    IonicRatingComponent.prototype.registerOnTouched = function (fn) {
        this.onTouched = fn;
    };
    IonicRatingComponent.prototype.setDisabledState = function (isDisabled) {
        this.readonly = isDisabled ? "true" : "false";
    };
    IonicRatingComponent.prototype.changeRating = function (event) {
        if (this.readonly && this.readonly === 'true')
            return;
        // event is different for firefox and chrome
        var id = event.target.id ? parseInt(event.target.id) : parseInt(event.target.parentElement.id);
        if (this.halfStar && this.halfStar === 'true') {
            this.rating = ((this.rating - id > 0) && (this.rating - id <= 0.5)) ? id + 1 : id + .5;
        }
        else {
            this.rating = id + 1;
        }
        // subscribe this event to get the changed value in your parent compoanent
        this.ionicRatingService.publishStartRatingChanged(this.rating);
        this.ionicRatingService.publishTopic(this.eventInfo.topic, this.rating);
        // unique event
        this.ratingChanged.emit(this.rating);
    };
    var IonicRatingComponent_1;
    IonicRatingComponent.ctorParameters = function () { return [
        { type: IonicRatingService }
    ]; };
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "rating", null);
    __decorate([
        Output()
    ], IonicRatingComponent.prototype, "ratingChanged", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "readonly", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "activeColor", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "defaultColor", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "activeIcon", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "defaultIcon", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "halfIcon", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "halfStar", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "maxRating", void 0);
    __decorate([
        Input()
    ], IonicRatingComponent.prototype, "fontSize", void 0);
    IonicRatingComponent = IonicRatingComponent_1 = __decorate([
        Component({
            selector: 'ionic-rating-component',
            template: "\n    <div class=\"ionic5-star-rating\">\n      <ion-button size=\"large\" fill=\"clear\" class=\"rate-button\" [ngStyle]=\"{'width' : fontSize, 'height' : fontSize}\" *ngFor=\"let index of iconsArray\" id=\"{{index}}\" (click)=\"changeRating($event)\">\n        <ion-icon [ngStyle]=\"{'color': ((halfStar === 'false' && index < this.Math.round(this.parseFloat(rating))) || (halfStar === 'true' && index < this.parseFloat(rating))) ? activeColor : defaultColor, 'font-size' : fontSize }\" name=\"{{(halfStar ==='true' && (rating - index > 0) && (rating - index <= 0.5)) ? halfIcon : (index < this.Math.round(this.parseFloat(rating))) ? activeIcon : defaultIcon}}\"></ion-icon>\n      </ion-button>\n    </div>\n  ",
            providers: [
                {
                    provide: NG_VALUE_ACCESSOR,
                    useExisting: IonicRatingComponent_1,
                    multi: true,
                },
            ],
            styles: ["\n    .rate-button {\n            --padding-bottom:0;\n            --padding-end:0;\n            --padding-start:0;\n            --padding-top:0;\n    }\n  "]
        })
    ], IonicRatingComponent);
    return IonicRatingComponent;
}());

var IonicRatingComponentModule = /** @class */ (function () {
    function IonicRatingComponentModule() {
    }
    IonicRatingComponentModule = __decorate([
        NgModule({
            declarations: [IonicRatingComponent],
            imports: [
                CommonModule,
                IonicModule,
            ],
            exports: [IonicRatingComponent]
        })
    ], IonicRatingComponentModule);
    return IonicRatingComponentModule;
}());

/*
 * Public API Surface of ionic-rating
 */

/**
 * Generated bundle index. Do not edit.
 */

export { IonicRatingComponent, IonicRatingComponentModule, IonicRatingService };
//# sourceMappingURL=ionic-rating-component.js.map
