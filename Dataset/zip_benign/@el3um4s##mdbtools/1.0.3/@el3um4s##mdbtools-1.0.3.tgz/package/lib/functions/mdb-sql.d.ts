declare const sqlAsString: (data?: {
    database: string;
    windowsPath?: string;
    sql: string;
}) => Promise<string>;
declare const sql: (data?: {
    database: string;
    windowsPath?: string;
    sql: string;
}) => Promise<Record<string, unknown>[]>;
declare const sqlToFile: (data?: {
    database: string;
    windowsPath?: string;
    sql: string;
    file: string;
}) => Promise<boolean>;
declare const sqlFromFileAsString: (data?: {
    database: string;
    windowsPath?: string;
    inputFile: string;
}) => Promise<string>;
declare const sqlFromFile: (data?: {
    database: string;
    windowsPath?: string;
    inputFile: string;
}) => Promise<Record<string, unknown>[]>;
declare const sqlFromFileToFile: (data?: {
    database: string;
    windowsPath?: string;
    inputFile: string;
    file: string;
}) => Promise<boolean>;
export { sql, sqlAsString, sqlToFile, sqlFromFile, sqlFromFileAsString, sqlFromFileToFile, };
