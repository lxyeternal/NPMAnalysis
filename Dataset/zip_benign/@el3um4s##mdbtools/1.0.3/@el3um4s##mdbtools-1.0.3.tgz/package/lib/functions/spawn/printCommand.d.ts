/// <reference types="node" />
/// <reference types="node" />
import { SpawnOptionsWithoutStdio } from "node:child_process";
import { Buffer } from "buffer";
interface Cmd {
    command: string;
    args: string[];
    options?: SpawnOptionsWithoutStdio;
    input?: string | Buffer;
    file: string;
}
declare const printCommand: (cmd: Cmd) => Promise<boolean>;
export { printCommand };
