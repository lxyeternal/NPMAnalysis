declare const columnsName: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
}) => Promise<string[]>;
declare const columnsNameTables: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<Record<string, string[]>>;
export { columnsName, columnsNameTables };
