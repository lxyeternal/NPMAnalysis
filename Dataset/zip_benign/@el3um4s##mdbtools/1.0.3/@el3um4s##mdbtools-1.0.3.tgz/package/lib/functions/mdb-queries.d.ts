declare const queries: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<string[]>;
declare const queriesSQL: (data?: {
    database: string;
    windowsPath?: string;
    query: string;
}) => Promise<string>;
declare const queriesToFile: (data?: {
    database: string;
    windowsPath?: string;
    file: string;
}) => Promise<boolean>;
declare const queriesSQLToFile: (data?: {
    database: string;
    windowsPath?: string;
    query: string;
    file: string;
}) => Promise<boolean>;
export { queries, queriesSQL, queriesToFile, queriesSQLToFile };
