declare const runQueryAsString: (data?: {
    database: string;
    windowsPath?: string;
    query: string;
}) => Promise<string>;
export { runQueryAsString };
