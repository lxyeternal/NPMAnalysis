declare const tableToCSV: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
}) => Promise<string>;
declare const tableToCSVFile: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
    file: string;
    options?: string;
}) => Promise<boolean>;
export { tableToCSV, tableToCSVFile };
