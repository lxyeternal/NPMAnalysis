declare const tables: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<string[]>;
declare const tablesAll: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<string[]>;
declare const tablesSystem: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<string[]>;
declare const tablesToFile: (data?: {
    database: string;
    windowsPath?: string;
    file: string;
}) => Promise<boolean>;
declare const tablesAllToFile: (data?: {
    database: string;
    windowsPath?: string;
    file: string;
}) => Promise<boolean>;
export { tables, tablesAll, tablesSystem, tablesToFile, tablesAllToFile };
