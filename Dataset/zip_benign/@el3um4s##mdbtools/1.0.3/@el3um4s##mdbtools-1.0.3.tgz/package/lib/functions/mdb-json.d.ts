declare const tableToJson: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
}) => Promise<Record<string, unknown>[]>;
export { tableToJson };
