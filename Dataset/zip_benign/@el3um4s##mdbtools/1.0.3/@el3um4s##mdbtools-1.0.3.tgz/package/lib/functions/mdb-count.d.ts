declare const count: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
}) => Promise<number>;
export { count };
