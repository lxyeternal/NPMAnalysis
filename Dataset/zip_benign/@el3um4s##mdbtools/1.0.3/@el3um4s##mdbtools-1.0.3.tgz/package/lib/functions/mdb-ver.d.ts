declare const versionMdbTools: (windowsPath?: string) => Promise<string>;
declare const version: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<string>;
export { versionMdbTools, version };
