declare const titleCSVToJSON: (data: string, delimiter?: string) => string[];
declare const CSVToJSON: (data: string, delimiter?: string) => Record<string, unknown>[];
export { CSVToJSON, titleCSVToJSON };
