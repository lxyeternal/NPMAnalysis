declare const schema: (data?: {
    database: string;
    windowsPath?: string;
}) => Promise<string>;
declare const schemaTable: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
}) => Promise<string>;
declare const schemaToFile: (data?: {
    database: string;
    windowsPath?: string;
    file: string;
}) => Promise<boolean>;
declare const schemaTableToFile: (data?: {
    database: string;
    windowsPath?: string;
    table: string;
    file: string;
}) => Promise<boolean>;
export { schema, schemaTable, schemaToFile, schemaTableToFile };
