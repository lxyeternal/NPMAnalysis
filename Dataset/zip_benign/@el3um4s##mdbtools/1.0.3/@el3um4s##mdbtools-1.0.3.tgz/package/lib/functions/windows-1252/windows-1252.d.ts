/*! https://mths.be/windows-1252 v3.0.4 by @mathias | MIT license */
export declare const decode: (input: string | Uint16Array, options: {
    mode?: string;
} | undefined) => string;
export declare const encode: (input: string, options: {
    mode: string;
}) => Uint16Array;
export declare const labels: string[];
