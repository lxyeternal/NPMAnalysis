declare const engine: (data?: {
    command: string;
    windowsPath: string;
}) => string;
export { engine };
