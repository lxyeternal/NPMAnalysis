declare const ver: () => Promise<unknown>;
export { ver };
