export const cfgItem = [{
  label: 'x',
  name: 'x',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'y',
  name: 'y',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'clazz',
  name: 'clazz',
  value: '',
  placeholder: '例如：cz-title',
  type: []
}, {
  label: '请求参数',
  name: 'params',
  value: '',
  placeholder: '例如：{id: 2}',
  type: []
}, {
  label: '请求方式',
  name: 'method',
  value: '',
  placeholder: '例如：get',
  type: []
}, {
  label: '请求地址',
  name: 'url',
  value: '',
  placeholder: '例如：',
  type: []
}, {
  label: '宽度',
  name: 'width',
  value: '380px',
  placeholder: '例如：1070px',
  type: []
}, {
  label: '高度',
  name: 'height',
  value: '380px',
  placeholder: '例如：820px',
  type: []
}, {
  label: '中心位置',
  name: 'mapCenter',
  value: [120.442378, 30.482656],
  placeholder: '例如：[120.442378,30.482656]',
  type: []
}, {
  label: '地图缩放级别',
  name: 'mapZoom',
  value: 12,
  placeholder: '例如：12',
  type: []
},
{
  label: '地图类型',
  name: 'mapType',
  value: 'default',
  placeholder: '例如：default/layers',
  type: []
}, {
  label: '地图Key',
  name: 'mapKey',
  value: 'b4632e015f7c759ad338e6f44b404ca2',
  placeholder: '例如：b4632e015f7c759ad338e6f44b404ca2',
  type: []
}, {
  label: '地图密钥',
  name: 'mapStyle',
  value: 'e7a049b4b7de96fb23f8b1b49e362b56',
  placeholder: '例如：e7a049b4b7de96fb23f8b1b49e362b56',
  type: []
}, {
  label: '呼吸点样式',
  name: 'scatterStyle',
  value: {
    unit: 'px',
    size: [30, 30],
    borderWidth: 0,
    texture: 'https://a.amap.com/Loca/static/loca-v2/demos/images/breath_red.png',
    duration: 500,
    animate: true,
  },
  placeholder: `例如：{size: [50, 50],borderWidth: 0,texture: 'https://a.amap.com/Loca/static/loca-v2/demos/images/breath_red.png'}`,
  type: []
}, {
  label: '文本点数据',
  name: 'point',
  value: [{ location: [120.242378, 30.282656], label: '杭州' }, { location: [120.755989, 30.760587], label: '嘉兴' }, { location: [120.595228, 30.041977], label: '绍兴' }],
  placeholder: '例如：[{ location: [120.242378,30.282656], label: "杭州" }, { location: [120.755989,30.760587], label: "嘉兴" }]',
  type: []
}, {
  label: '文本点样式',
  name: 'pointStyle',
  value: {
    'padding': '.5rem 0rem',
    'margin-bottom': '1rem',
    'border-radius': '.25rem',
    'background-color': 'white',
    'width': '8rem',
    'border-width': 0,
    'box-shadow': '0 2px 6px 0 rgba(114, 124, 245, .5)',
    'text-align': 'center',
    'font-size': '20px',
    'color': 'blue',
    'anchor': 'top-left'
  },
  placeholder: '例如：{padding: 0,fillColor:"#fff"}',
  type: []
}, {
  label: '标记点数据',
  name: 'marker',
  value: [{ location: [120.595228, 30.041977], label: '绍兴',img: '../../src/static/images/mapspot.png' }],
  placeholder: `例如：[{ location: [120.595228, 30.041977], label: '绍兴' }]`,
  type: []
}, {
  label: '标记点样式',
  name: 'markerStyle',
  value: {
    anchor: 'top'
  },
  placeholder: `例如：{anchor: 'top'}`,
  type: []
}, {
  label: '聚焦点',
  name: 'lineFocus',
  value: { location: [120.242378, 30.282656], label: '杭州' },
  placeholder: `例如：{ location: [120.242378,30.282656], label: '杭州' }`,
  type: []
}, {
  label: '线数据',
  name: 'line',
  value: [{ fromName: '绍兴', toName: '杭州', fromCoord: [120.595228, 30.041977], toCoord: [120.242378, 30.282656], data: 90000 },
  { fromName: '杭州', toName: '绍兴', fromCoord: [120.242378, 30.282656], toCoord: [120.595228, 30.041977], data: 60000 },
  { fromName: '嘉兴', toName: '杭州', fromCoord: [120.755989, 30.760587], toCoord: [120.242378, 30.282656], data: 40000 }],
  placeholder: `例如：[{ fromName:'绍兴', toName:'杭州', fromCoord:[120.595228,30.041977], toCoord:[120.242378,30.282656], data: 90 }, { fromName:'嘉兴', toName:'杭州', fromCoord:[120.755989,30.760587], toCoord:[120.242378,30.282656], data: 140 }]`,
  type: []
}, {
  label: '线样式',
  name: 'lineStyle',
  value: {
    width: 2,
    opacity: 0.6,
    curveness: 0.3,
    scatterColor: '#1de7e2'
  },
  placeholder: `例如：{width: 2,opacity: 0.6,curveness: 0.3}`,
  type: []
},{
  label: '线类型',
  name: 'lineType',
  value: 'default', // 'layer' 'default' 'echarts'
  placeholder: `例如：default`,
  type: []
}, {
  label: '面数据',
  name: 'polygon',
  value: [{ location: [[119.867898, 30.399751], [120.614969, 30.494464], [120.584756, 30.100805], [119.823953, 30.041383]], label: '杭州' },
  { location: [[120.392496, 30.910104], [121.043436, 30.9478], [121.065408, 30.617453], [120.450174, 30.558343]], label: '嘉兴' }
  ],
  placeholder: '例如：[{ location: [[119.867898, 30.399751], [120.614969, 30.494464], [120.584756, 30.100805], [119.823953, 30.041383] ], label: "杭州" }]',
  type: []
}, {
  label: '面样式',
  name: 'polygonStyle',
  value: {
    fillColor: '#ccebc5',
    fillOpacity: '0.6',
    strokeWeight: 1,
    strokeColor: 'none'
  },
  placeholder: `例如：{topColor:'#FFD87B', height:10, sideTopColor:'#FFD87B'}`,
  type: []
}, {
  label: '图例标题',
  name: 'legendTitle',
  value: '流入流出量（万）',
  placeholder: `例如：流入流出量（万）`,
  type: []
}, {
  label: '图例数据',
  name: 'legendData',
  value: [0, 1, 3, 7, 10],
  placeholder: `例如：[0, 1, 3, 7, 10]`,
  type: []
}, {
  label: '图例颜色',
  name: 'legendColor',
  value: ['#ff3333', '#ffa500', '#ffff00', '#00ff00', '#00ffff'],
  placeholder: `例如：['#ff3333', '#ffa500', '#ffff00', '#00ff00', '#00ffff']`,
  type: []
}, {
  label: '图例是否显示',
  name: 'legendShow',
  value: "是",
  placeholder: `例如：是/否`,
  type: []
}, {
  label: '热力图数据',
  name: 'heatMapData',
  value: [{
    "lng": 120.242378,
    "lat": 30.282656,
    "count": 10
  }, {
    "lng": 120.442378,
    "lat": 30.282656,
    "count": 11
  }, {
    "lng": 120.642378,
    "lat": 30.282656,
    "count": 12
  }],
  placeholder: `例如：[{"lng": 119.191031,"lat": 30.988585,"count": 10}, {"lng": 119.389275,"lat": 30.925818,"count": 11}]`,
  type: []
}, {
  label: '热力图颜色值',
  name: 'heatMapColor',
  value: ['#00ffff', '#00ff00', '#ffff00', '#ffa500', '#ff3333'],
  placeholder: `例如：['#00ffff', '#00ff00', '#ffff00', '#ffa500', '#ff3333']`,
  type: []
}, {
  label: '热力图点半径',
  name: 'heatMapRadius',
  value: 10,
  placeholder: `例如：10`,
  type: []
}, {
  label: '热力图最大值',
  name: 'heatMapMaxData',
  value: 1000,
  placeholder: `例如：1000`,
  type: []
}]
// 图片的话直接文件夹下的图换一套图就行了
export default {
  x: 0,
  y: 0,
  clazz: '',
  params: {},
  url: '',
  method: 'get',
  width: '1000px',
  height: '1000px',

  mapCenter: [119.442378, 30.482656],
  mapZoom: 8,
  mapType: 'default', // default / layers
  mapKey: 'b4632e015f7c759ad338e6f44b404ca2',
  mapStyle: 'e7a049b4b7de96fb23f8b1b49e362b56',

  scatterStyle: {
    unit: 'px',
    size: [30, 30],
    borderWidth: 0,
    texture: 'https://a.amap.com/Loca/static/loca-v2/demos/images/breath_red.png',
    duration: 500,
    animate: true,
  },
  point: [{ location: [120.242378, 30.282656], label: '杭州' }, { location: [120.755989, 30.760587], label: '嘉兴' }, { location: [120.595228, 30.041977], label: '绍兴' }] , //[{ location: [120.242378, 30.282656], label: '杭州' }, { location: [120.755989, 30.760587], label: '嘉兴' }, { location: [120.595228, 30.041977], label: '绍兴' }],
  marker: [{ location: [120.242378, 31.282656], label: '绍兴',img: '../../src/static/images/mapspot.png' },{ location: [121.242378, 31.282656], label: '绍兴',img: '../../src/static/images/mapspot.png' }], // [{ location: [120.595228, 30.041977], label: '绍兴' }],
  // 3D
  // pointStyle: {
  //   fontSize: 12,
  //   fontWeight: 'normal',
  //   fillColor: '#fff',
  // },
  // 2D
  pointStyle: {
    padding: '0.2rem 0',
    marginBottom: '0',
    borderRadius: '0',
    backgroundColor: '#EE5D5B',
    width: '4rem',
    borderWidth: 1,
    borderColor: '#BC3B3A',
    boxShadow: 'none',
    textAlign: 'center',
    fontSize: '12px',
    color: '#fff',
    anchor: 'center'
  },
  markerStyle: {
    anchor: 'top'
  },
  ////////  线
  lineType: 'layer', // echarts default
  // 迁徙图
  lineFocus: { location: [120.242378, 30.282656], label: '杭州' }, // { location: [120.242378,30.282656], label: '杭州' }
  // line: [{ fromName:'绍兴', toName:'杭州', fromCoord:[120.595228,30.041977], toCoord:[120.242378,30.282656], data: 90000 },
  // // { fromName:'杭州', toName:'绍兴', fromCoord:[120.242378,30.282656], toCoord:[120.595228,30.041977], data: 60000 },
  //  { fromName:'嘉兴', toName:'杭州', fromCoord:[120.755989,30.760587], toCoord:[120.242378,30.282656], data: 40000 }],
  // lineStyle: {
  //   width: 2,
  //   opacity: 0.6,
  //   curveness: 0.3,
  //   symbolSize: 6,
  //   scatterColor: '#f00',
  //   scatterSymbol: 'pin',
  //   allScatterData: true,
  //   lineEffectShow: false,
  //   lineType: '单向' //单向 双向
  // },

  // 普通
  // line: [{ location: [[120.595228, 30.041977], [120.242378, 30.282656]], label: '' }], // [{ location: [[120.595228, 30.041977], [120.242378, 30.282656]], label: '' }],
  // lineStyle: {
  //   strokeWeight: 1, // 线条宽度，默认为 1
  //   strokeColor: ['red'], // 线条颜色
  //   defaultStrokeColor: 'red',
  //   lineJoin: 'round' // 折线拐点连接处样式
  // },

  // 线图层
  line: [{"lnglat":[[120.595228, 30.041977],[120.242378, 30.282656]]}],
  lineStyle: {
    color: '#f00',
    width: 2,
    opacity: 0.9,
    borderWidth: 4
  },

  /////// 面
  polygon: [{ location: [[119.867898, 30.399751], [120.614969, 30.494464], [120.584756, 30.100805], [119.823953, 30.041383]], label: '杭州' },
  { location: [[120.392496, 30.910104], [121.043436, 30.9478], [121.065408, 30.617453], [120.450174, 30.558343]], label: '嘉兴' }
  ],
  // 3D
  // polygonStyle: {
  //   topColor: '#FFD87B',
  //   sideTopColor: '#FFD87B',
  //   sideBottomColor: '#FFD87B',
  //   height: 1,
  //   altitude: 0,
  // },
  // 2D
  polygonStyle: {
    fillColor: ['#ccebc5', '#1cebc5'],
    fillOpacity: '0.6',
    strokeWeight: 1,
    strokeColor: ['#ccebc5', '#1cebc5']
  },
  legendTitle: '流入流出量（万）',
  legendData: [0, 1, 3, 7, 10],
  legendColor: ['#00ffff', '#00ff00', '#ffff00', '#ffa500', '#ff3333'],
  legendShow: '是',
  heatMapData: [{"lng": 120.595228,"lat": 30.041977,"count": 80}, {"lng": 119.907898,"lat": 30.409851,"count": 89 }], // [{"lng": 120.595228,"lat": 30.041977,"count": 80}, {"lng": 119.907898,"lat": 30.409851,"count": 89 }]
  heatMapColor: ['#00ffff', '#00ff00', '#ffff00', '#ffa500', '#ff3333'],
  heatMapRadius: 20,
  heatMapMaxData: 100
}