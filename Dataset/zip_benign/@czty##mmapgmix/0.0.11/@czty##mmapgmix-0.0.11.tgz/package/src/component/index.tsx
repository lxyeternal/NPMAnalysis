import React, { FC, useState, useEffect, useImperativeHandle, forwardRef } from 'react'
import AMapLoader from '@amap/amap-jsapi-loader'
import * as echarts from 'echarts';
import 'echarts-extension-amap';
import configers from './../../configer'
import './index.scss'
import _ from 'lodash-es'

let Satellite = null, RoadNet = null;
const MMapgmix: FC = forwardRef(({
  draggable = true,
  configer = configers
}, ref) => {
  const [dots] = useState(Math.floor(Math.random() * 100))
  const { clazz, mapCenter, mapZoom, mapType, mapKey, mapStyle, scatterStyle, point, pointStyle, marker, markerStyle, lineFocus, line, lineType, lineStyle, polygon, polygonStyle, legendTitle, legendData, legendColor, legendShow, heatMapData, heatMapColor, heatMapRadius, heatMapMaxData } = configer

  const [pointd, setPointd] = useState([]) // 存储绘制的点数据
  const [markerd, setMarkerd] = useState([]) // 存储绘制的点数据
  const [lined, setLined] = useState([]) // 存储绘制的线数据
  const [polygond, setPolygond] = useState([]) // 存储绘制的面数据
  const [map, setMap] = useState(null)
  const [chart, setChart] = useState(null)
  const [AMap, setAMap] = useState(null)
  const [lineLayer, setlineLayer] = useState(null)


  const handleDrag = (e) => {
    // antdI本来应该是个数组的，因为一个组件可能包含多个antd的组件，外面可以扁平化啊
    const params = JSON.stringify({ type: 'other', id: 'MMapgmix', antdI: '', relate: 'in' })
    e.dataTransfer.setData('Text', params)
  }
  useEffect(() => {
    AMapLoader.load({
      key: mapKey,
      version: '1.4.15', // '1.4.15' '2.0',
      plugins: ["AMap.Heatmap"],
      AMapUI: {
        version: '1.1',
        plugins: ['overlay/SimpleMarker'],
      },
      Loca: {
        version: '1.3.2', // '1.3.2' '2.0'
      },
    }).then((AMap) => {
      Satellite = new AMap.TileLayer.Satellite()
      RoadNet = new AMap.TileLayer.RoadNet()
      setAMap(AMap)
      let map = null
      if (lineType !== "echarts") {
        map = new AMap.Map(`mapContainer${dots}`, {
          viewMode: '2D',
          center: mapCenter,
          zoom: mapZoom,
          resizeEnable: true,
          pitch: 45,
          showLabel: true,
          mapStyle: `amap://styles/${mapStyle}`,
        });

        setMap(map)
      } else {
        const chart = echarts.init(document.getElementById(`mapContainer${dots}`));
        const defaultOption = {
          // 加载 amap 组件
          amap: {
            // 3D模式，无论你使用的是1.x版本还是2.x版本，都建议开启此项以获得更好的渲染体验
            viewMode: '2D',
            // 高德地图支持的初始化地图配置
            // 高德地图初始中心经纬度
            center: mapCenter,
            // 高德地图初始缩放级别
            zoom: mapZoom,
            resizeEnable: true,
            pitch: 45,
            showLabel: true,
            mapStyle: `amap://styles/${mapStyle}`,
          },
          tooltip: {},
          series: [],
        };
        chart.setOption(defaultOption)
        const amapComponent = chart.getModel().getComponent('amap'); // 获取 ECharts 高德地图组件

        // 获取高德地图实例，使用高德地图自带的控件(需要在高德地图js API script标签手动引入)
        map = amapComponent.getAMap();
        setMap(map)
        setChart(chart)
      }
      if (lineType === 'layer') {
        const linelayer = new Loca.LineLayer({
          map: map,
          zIndex: 112
        });
        setlineLayer(linelayer)
      }
      if (mapType === 'layers') {
        map.add(Satellite)
        map.add(RoadNet)
      } else {
        map.remove(Satellite)
        map.remove(RoadNet)
      }
    })
  }, [])


  // 文本点
  const draw2dPoint = () => {
    let pointD = []
    for (var i = 0; i < point.length; i += 1) {
      var text = new AMap.Text({
        text: point[i].label,
        anchor: pointStyle.anchor,
        draggable: false,
        cursor: 'pointer',
        style: pointStyle,
        position: point[i].location,
        extData: point[i].extData ? point[i].extData : null
      });
      pointD.push(text);
    }
    setPointd(pointD)
    map.add(pointD);
  }
  useEffect(() => {
    if (!AMap || !map) {
      return;
    }
    map.remove(pointd)
    if (point.length) {
      draw2dPoint()
    }
  }, [point, map, AMap])

  // 自定义点
  const draw2dMarker = () => {
    let markerD = []
    for (var i = 0; i < marker.length; i += 1) {
      var markerc = new AMap.Marker({
        position: marker[i].location,
        offset: new AMap.Pixel(-14, -35),
        icon: marker[i].img,
        anchor: markerStyle.anchor,
        title: marker[i].label,
        extData: marker[i].extData ? marker[i].extData : null
      });
      markerD.push(markerc);
    }
    setMarkerd(markerD)
    map.add(markerD);
  }
  useEffect(() => {
    if (!AMap || !map) {
      return;
    }
    map.remove(markerd)
    if (marker.length) {
      draw2dMarker()
    }
  }, [marker, map, AMap])

  // echarts线
  const generateScatter = () => {
    const scatterData = []
    line.forEach((item) => {
      const scatterObj = {
        name: item.fromName,
        value: item.fromCoord
      }
      if (!scatterData.find((e) => e.value === scatterObj.value && e.name === scatterObj.name)) {
        scatterData.push(scatterObj)
      }
    })
    
    if (lineStyle.lineType === '单向' && lineFocus) {
      scatterData.push({ name: lineFocus.label, value: lineFocus.location })
    }
    return scatterData
  }
  const generateLines = () => {
    const seriesLines = []
    line.forEach((item, index) => {
      seriesLines.push({
        type: 'lines',
        coordinateSystem: 'amap',
        zlevel: 1,
        effect: {
          show: lineStyle.lineEffectShow,
          period: 10, // 箭头指向速度，值越小速度越快
          trailLength: 0.01, // 特效尾迹长度[0,1]值越大，尾迹越长重
          symbol: 'arrow', // 箭头图标
          symbolSize: 6, // 图标大小
          opacity: 0.6,
        },
        lineStyle: {
          normal: lineStyle
        },
        progressive: 200,
        progressiveThreshold: 3000,
        data: [{
          fromName: item.fromName,
          toName: item.toName,
          value: item.data,
          coords: [item.fromCoord, item.toCoord]
        }]
      })
    });
    return seriesLines;
  }
  // echarts
  const drawechartsLine = () => {
    let piecsLeg = [
      { min: legendData[0] * 10000, max: legendData[1] * 10000 },
      { min: legendData[1] * 10000, max: legendData[2] * 10000 },
      { min: legendData[2] * 10000, max: legendData[3] * 10000 },
      { min: legendData[3] * 10000, max: legendData[4] * 10000 },
      { min: legendData[4] * 10000 }
    ]
    const seriesLines = generateLines()
    const scatterList = generateScatter()
    const option = {
      tooltip: {
        className: 'echarts-tooltip mmapgmix-tooltip',
        formatter: (params) => {
          if (params.componentSubType === 'lines') {
            const num = Number(params.data.value / 10000).toFixed(2)
            if (lineStyle.lineType === '双向') {
              return `${params.data.fromName}->${params.data.toName}: ${num}万人`
            } else {
              return `${params.data.fromName}-${params.data.toName}: ${num}万人`
            }
          }
          return ''
        }
      },
      visualMap: [
        {
          // 视觉影射
          type: 'piecewise',
          pieces: piecsLeg,
          left: '5%',
          bottom: '20',
          top: 'auto',
          calculable: true,
          show: false,
          color: legendColor.reverse(),
          textStyle: {
            color: '#fff'
          },
          align: 'left',
          dimension: 0
        },
        // {
        //   // 其他点颜色映射, 因为第一个是应用在全部的series上，故下面的是对特定series单设置
        //   type: 'piecewise',
        //   left: '1%',
        //   bottom: '13%',
        //   top: 'auto',
        //   calculable: true,
        //   show: false,
        //   color: [lineStyle.scatterColor],
        //   textStyle: {
        //     color: '#fff'
        //   },
        //   dimension: 0,
        //   seriesIndex: 0,
        // },
        // {
        //   // 被攻击点颜色
        //   type: 'piecewise',
        //   left: '1%',
        //   bottom: '13%',
        //   top: 'auto',
        //   calculable: true,
        //   show: false,
        //   color: [lineStyle.scatterColor],
        //   textStyle: {
        //     color: '#fff'
        //   },
        //   seriesIndex: 1
        // }
      ],
      series: [
        // 呼吸点
        {
          type: 'effectScatter',
          coordinateSystem: 'amap',
          zlevel: 200,
          symbolSize: lineStyle.symbolSize,
          animation: false,
          showEffectOn: 'render',
          rippleEffect: {
            period: 4, // 动画时间，值越小速度越快
            brushType: 'stroke', // 波纹绘制方式 stroke, fill
            scale: 5
          },
          label: {
            show: true,
            distance: 8,
            color: '#000',
            fontSize: 14,
            textBorderColor: '#fff',
            textBorderWidth: 2,
            position: 'bottom',
            formatter: '{b}'
          },
          data: lineStyle.allScatterData ? scatterList : [{ name: lineFocus.label, value: lineFocus.location }]
        }, {
          // 被攻击点
          type: 'scatter',
          coordinateSystem: 'amap',
          zlevel: 210,
          symbol: lineStyle.scatterSymbol,
          symbolSize: 30,
          itemStyle: {
            color: '#fff'
          },
          label: {
            show: true,
            color: '#000',
            textBorderColor: '#fff',
            textBorderWidth: 2,
            position: 'bottom',
            offset: [30, 0],
            formatter: '{b}',
            fontSize: 14,
            fontWeight: 800,
            opacity: 1,
          },
          data: lineStyle.allScatterData ? scatterList : [{ name: lineFocus.label, value: lineFocus.location }]
        }
      ].concat(seriesLines)
    }
    const opts = chart.getOption()
    opts.series.forEach((s) => {
      s.data = []
    })
    chart.setOption(opts);
    setTimeout(() => {
      chart.setOption(option)
    }, 100);
  }
  // 普通线
  const drawLine = () => {
    let lineD = []
    for (var i = 0; i < line.length; i += 1) {
      const lineObj = {
        path: line[i].location,
        strokeWeight: lineStyle.strokeWeight ? lineStyle.strokeWeight : lineStyle.defaultStrokeWeight, // 线条宽度，默认为 1
        strokeColor: lineStyle.strokeColor[i] ? lineStyle.strokeColor[i] : lineStyle.defaultStrokeColor, // 线条颜色
        lineJoin: lineStyle.lineJoin,
        extData: line[i].extData ? line[i].extData : null
      }
      var polyline = new AMap.Polyline(lineObj);
      lineD.push(polyline);
    }
    setLined(lineD)
    map.add(lineD)
  }
  // 线的绘制
  useEffect(() => {
    if (!AMap || !map) {
      return;
    }
    map.remove(lined)
    if (line.length) {
      if (lineType === 'layer') {
        if (lineLayer) {
          lineLayer.setData(line, {
            lnglat: "lnglat"
          });
          lineLayer.setOptions({
            style: lineStyle
          });
          lineLayer.render();
        }
      } else {
        if (lineType !== 'echarts') {
          drawLine()
        } else {
          if (!chart) return;
          drawechartsLine()
        }
      }
    }
  }, [line, lineStyle, map, AMap, chart, lineLayer])

  useEffect(() => {
    if (lineType === 'layer') {
      if (!lineLayer) return
      lineLayer.setOptions({
        style: lineStyle
      });
      lineLayer.render();
    } else if (lineType === 'echarts') {
      if (!chart) return;
      drawechartsLine()
    } else {
      if (lined.length) {
        for (var i = 0; i < lined.length; i += 1) {
          lined[i].setOptions({
            strokeWeight: lineStyle.strokeWeight ? lineStyle.strokeWeight : lineStyle.defaultStrokeWeight, // 线条宽度，默认为 1
            strokeColor: lineStyle.strokeColor[i] ? lineStyle.strokeColor[i] : lineStyle.defaultStrokeColor, // 线条颜色
            lineJoin: linestyle.lineJoin
          })
        }
      }
    }
  }, [lineStyle, lined, chart, lineLayer])

  // 面的绘制
  // 分批绘制
  // const drawPolygon = async (n, data) => {
  //   let polygonD = []
  //   for (var i = 0; i < data.length; i += 1) {
  //     const polygonObj = {
  //       path: data[i].location,
  //       fillColor: polygonStyle.fillColor[i] ? polygonStyle.fillColor[i] : polygonStyle.fillColor[0],
  //       fillOpacity: polygonStyle.fillOpacity,
  //       strokeWeight: polygonStyle.strokeWeight,
  //       strokeColor: polygonStyle.strokeColor[i] ? polygonStyle.strokeColor[i] : polygonStyle.strokeColor[0],
  //       extData: data[i].extData ? data[i].extData : null
  //     }
  //     var polygon = new AMap.Polygon(polygonObj);
  //     polygonD.push(polygon);
  //   }
  //   if (n === 0) {
  //     setPolygond(polygonD)
  //   } else {
  //     setPolygond(polygond.concat(polygonD))
  //   }
  //   map.add(polygonD);
  // }

  // const draw2dPolygon = () => {
  //   for (var i = 0; i < polygon.length; i += 10) {
  //     const pgds = polygon.slice(i, i + 10)
  //     drawPolygon(i, pgds)
  //   }
  // }
  const draw2dPolygon = () => {
    let polygonD = []
    for (var i = 0; i < polygon.length; i++) {
      const polygonObj = {
        path: polygon[i].location,
        fillColor: polygonStyle.fillColor[i] ? polygonStyle.fillColor[i] : polygonStyle.fillColor[0],
        fillOpacity: polygonStyle.fillOpacity,
        strokeWeight: polygonStyle.strokeWeight,
        strokeColor: polygonStyle.strokeColor[i] ? polygonStyle.strokeColor[i] : polygonStyle.strokeColor[0],
        extData: polygon[i].extData ? polygon[i].extData : null
      }
      var polygonM = new AMap.Polygon(polygonObj);
      polygonD.push(polygonM);
    }
    setPolygond(polygonD)
    map.add(polygonD);
  }
  useEffect(() => {
    if (!AMap || !map) {
      return;
    }
    map.remove(polygond)
    if (polygon.length) {
      draw2dPolygon()
    }
  }, [polygon, map, AMap])

  useEffect(() => {
    if (polygond.length) {
      for (var i = 0; i < polygond.length; i++) {
        const polygonObj = {
          fillColor: polygonStyle.fillColor[i] ? polygonStyle.fillColor[i] : polygonStyle.fillColor[0],
          fillOpacity: polygonStyle.fillOpacity,
          strokeWeight: polygonStyle.strokeWeight,
          strokeColor: polygonStyle.strokeColor[i] ? polygonStyle.strokeColor[i] : polygonStyle.strokeColor[0]
        }
        polygond[i].setOptions(polygonObj)
      }
    }
  }, [polygonStyle, polygond])

  // 绘制热力图
  useEffect(() => {
    if (!AMap || !map) {
      return;
    }
    if (heatMapData.length) {
      // 热力图
      var heatMapLayer = new AMap.Heatmap(map, {
        zIndex: 110,
        radius: heatMapRadius,
        opacity: [0, 0.9],
        gradient: {
          0.4: heatMapColor[0],
          0.65: heatMapColor[1],
          0.7: heatMapColor[2],
          0.9: heatMapColor[3],
          1.0: heatMapColor[4]
        }
      })
      heatMapLayer.setDataSet({
        data: heatMapData,
        max: heatMapMaxData
      })
    }
  }, [heatMapData, AMap, map, heatMapColor, heatMapRadius])

  useImperativeHandle(ref, () => ({
    AMap,
    map,
    pointd,
    markerd,
    lined,
    polygond
  }), [AMap, map, pointd, markerd, lined, polygond])

  return (
    <div className='cz-mapgmix-container' style={configer}>
      <div
        draggable={draggable}
        className={`dragor ${clazz} cz-mapgmix`}
        id={`mapContainer${dots}`}
        onDragStart={(e) => { handleDrag(e) }}
        style={configer}
      >

      </div>
      {
        legendShow === '是' ?
          <div className="legend-box">
            <div>{legendTitle}</div>
            <ul className="legend-ui">
              {
                legendData.length ? legendData.map((item, index) => {
                  return (<li key={index}>
                    <i className="color" style={{ background: legendColor[index], display: 'inline-block', width: '20px', height: '10px' }}></i>
                    {index < legendData.length - 1 ? item + '-' + legendData[index + 1] : '>' + item}
                  </li>)
                }) : ''
              }

            </ul>
          </div> : null
      }
    </div>
  )
})

MMapgmix.name = 'MMapgmix'

export default MMapgmix