import React, { FC } from 'react'
import 'antd/dist/antd.css'
import MMapgmix from '@/component'

const App: FC = () => {
  return (
    <div className="app">
      <MMapgmix /> 
    </div>
  )
}

export default App