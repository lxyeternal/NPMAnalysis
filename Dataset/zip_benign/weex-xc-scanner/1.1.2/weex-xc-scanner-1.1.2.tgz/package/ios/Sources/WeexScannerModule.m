//
//  WeexScannerModule.m
//  WeexPluginTemp
//
//  Created by  on 17/3/14.
//  Copyright © 2017年 . All rights reserved.
//

#import "WeexScannerModule.h"
#import "SGQRCodeScanningVC.h"
#import "SGQRCodeHelperTool.h"
#import <AVFoundation/AVFoundation.h>

@implementation WeexScannerModule
@synthesize weexInstance;

WX_EXPORT_METHOD(@selector(scanQR:callBack:))
WX_EXPORT_METHOD(@selector(openFlashlight))
WX_EXPORT_METHOD(@selector(closeFlashlight))
- (void)scanQR:(NSString *)title callBack:(WXModuleCallback)callback
{
    self.callBack=callback;
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    if (device) {
        AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (status == AVAuthorizationStatusNotDetermined) {
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                if (granted) {
                    dispatch_sync(dispatch_get_main_queue(), ^{
                        SGQRCodeScanningVC *vc = [[SGQRCodeScanningVC alloc] init];
                        weexInstance.viewController.navigationController.navigationBarHidden = false;
                        vc.callBack = self.callBack;
                        vc.navigationItem.title =title.length?title:@"扫一扫";
                        [[weexInstance.viewController navigationController] pushViewController:vc animated:YES];
                    });
                    // 用户第一次同意了访问相机权限
                    NSLog(@"用户第一次同意了访问相机权限 - - %@", [NSThread currentThread]);
                    
                } else {
                    // 用户第一次拒绝了访问相机权限
                    NSLog(@"用户第一次拒绝了访问相机权限 - - %@", [NSThread currentThread]);
                    self.callBack(@{@"status":@"error",@"msg":@"用户第一次拒绝了访问相机权限"});
                }
            }];
        } else if (status == AVAuthorizationStatusAuthorized) { // 用户允许当前应用访问相机
            SGQRCodeScanningVC *vc = [[SGQRCodeScanningVC alloc] init];
            vc.callBack = self.callBack;
            vc.navigationItem.title =title.length?title:@"扫一扫";
            weexInstance.viewController.navigationController.navigationBarHidden = false;
            [[weexInstance.viewController navigationController] pushViewController:vc animated:YES];
        } else if (status == AVAuthorizationStatusDenied) { // 用户拒绝当前应用访问相机
            UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"请去-> [设置 - 隐私 - 相机 - SGQRCodeExample] 打开访问开关" preferredStyle:(UIAlertControllerStyleAlert)];
            UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            
            [alertC addAction:alertA];
            [[weexInstance.viewController navigationController] presentViewController:alertC animated:YES completion:nil];
            self.callBack(@{@"status":@"error",@"msg":@"用户拒绝当前应用访问相机"});
            
        } else if (status == AVAuthorizationStatusRestricted) {
            NSLog(@"因为系统原因, 无法访问相册");
            self.callBack(@{@"status":@"error",@"msg":@"因为系统原因, 无法访问相册"});
        }
    } else {
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"未检测到您的摄像头" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *alertA = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        
        [alertC addAction:alertA];
        [[weexInstance.viewController navigationController] presentViewController:alertC animated:YES completion:nil];
        self.callBack(@{@"status":@"error",@"msg":@"未检测到您的摄像头"});
    }
}
-(void)openFlashlight{
    [SGQRCodeHelperTool SG_openFlashlight];
}
-(void)closeFlashlight{
    [SGQRCodeHelperTool SG_CloseFlashlight];
}
@end
