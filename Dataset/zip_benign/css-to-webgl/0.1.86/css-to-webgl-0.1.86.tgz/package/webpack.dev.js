const webpack = require('webpack');
const path = require('path');
const glob = require('glob');
const argv = require('yargs').argv;

module.exports = {
    stats: {
        all: true,
    },

    module: {
        rules: [
            {
                include: [path.resolve(__dirname, 'src')],
                loader: 'babel-loader',
                options: {
                    presets: [
                        [
                            '@babel/env',
                            {
                                modules: false,
                            },
                        ],
                    ],
                },

                test: /\.js$/,
            },
            {
                test: /\.(png|jpe?g|gif|svg)$/,
                use: [
                    {
                        loader: 'file-loader',
                        options: {
                            name: '[name].[ext]',
                        },
                    },
                ],
            },
            {
                test: /\.(glsl|vs|fs|vert|frag)$/,
                exclude: /node_modules/,
                use: ['raw-loader', 'glslify-loader'],
            },
        ],
    },

    devServer: {
        contentBase: path.resolve(__dirname, 'public'),
        disableHostCheck: true,
        historyApiFallback: true,
        stats: 'minimal',
    },

    entry: {
        index: './src/index.js',
    },

    // output: {
    //     path: path.resolve(__dirname, 'public'),
    // },
    output: {
        library: 'CssToWebglRenderer',
        libraryTarget: 'commonjs2',
    },

    plugins: [new webpack.DefinePlugin({})],

    // mode: 'development',
    mode: 'production',

    optimization: {
        splitChunks: {
            cacheGroups: {
                vendors: {
                    priority: -10,
                    test: /[\\/]node_modules[\\/]/,
                },
            },

            // chunks: 'all',
            minChunks: 1,
            minSize: 3000,
            name: false,
        },
    },
};
