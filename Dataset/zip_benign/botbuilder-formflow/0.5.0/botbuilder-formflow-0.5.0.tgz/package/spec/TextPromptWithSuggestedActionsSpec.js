const botFactory = require('./botFactory');
const loadForm = require('./loadForm');

describe('Testing Text Prompt with Suggested Actions', function () {
  return ;
  let bot = null;

  beforeEach( (done) => {
    bot = botFactory.create();
  });

  it('Test key-value object',(done) => {
    loadForm(bot,'flows/TextPromptWithSuggestedActions/01-keyvalueForm', done)
  });
  it('Test that callback object MUST return a promise',(done) => {
    loadForm(bot,'flows/TextPromptWithSuggestedActions/02-callback-promise-missedForm', done)
  });
  it('Test that callback object MUST return a promise',(done) => {
    loadForm(bot,'flows/TextPromptWithSuggestedActions/03-callback-resolved-with-errorForm', done)
  });
  it('Test key-value object',(done) => {
    loadForm(bot,'flows/TextPromptWithSuggestedActions/04-callbackForm', done)
  });
})