module.exports = [
  {
    "type": "text-with-suggested-actions",
    "id": "value",
    "prompt": "Please enter a text value",
    "suggestedActions" : [
      { type : 'imBack', title : "Hello", "value" : "Hello"},
      { type : 'imBack', title : "World!", "value" : "World!"},
    ],
    "response" : "You selected %s"
  }
];