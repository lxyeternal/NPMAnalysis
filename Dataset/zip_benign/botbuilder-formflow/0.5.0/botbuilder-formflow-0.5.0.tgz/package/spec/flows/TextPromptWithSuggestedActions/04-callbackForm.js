module.exports = [
  {
    "type": "suggested-text-prompt",
    "id": "value",
    "prompt": "Please enter a text value",
    "response" : "You selected %s",
    "suggestedActions" : function () {
      return [
        { type : 'imBack', title : "Hello", "value" : "Hello"},
        { type : 'imBack', title : "World!", "value" : "World!"},
      ]
    }
  }
];