const botbuilder = require('botbuilder');
module.exports = [
  {user:'hi'},
  {
    bot: 'Please enter a text value',
    suggestedActions: [
      new botbuilder.CardAction.imBack(null, 'Hello'),
      new botbuilder.CardAction.imBack(null, 'World!'),
    ]
  },
  {user:'1234'},
  {"bot": "{\"value\":\"Hello world!\"}"}

];