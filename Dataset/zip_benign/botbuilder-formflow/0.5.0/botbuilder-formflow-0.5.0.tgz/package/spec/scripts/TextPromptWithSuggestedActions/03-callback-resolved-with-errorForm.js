const botbuilder = require('botbuilder');
module.exports = [
  {user:'hi'},
  {bot: 'Internal error'},
];