module.exports = [
  {user:'hi'},
  {bot: 'Internal error',}
];