'use strict';
// var DataV = require('../line-with-point-area');
var DataV = require('dchart-line-with-point-area');
// var _ = require('../../../util');
var _ = require('dchart-core/util');
var d3 = require('d3');

const { animationController, SERIES_INDEX, AXIS_NAME, interactionHandlerSelector } = _;

function LineWithPointArea(container, options) {
  var opt = {
    xaxis: {
      type: 'category',
      padding: 0.2,
      dy: 10,
    },
    yaxis: {},
    zaxis: {
      show: true,
      key: 'z',
      orient: 'right',
      fontSize: 12,
      dy: 10,
      color: '#fff',
      ticks: 5,
      assistLine: false
    },
    series: [{color: null, area: {frameColor: null, frameColorWidth: null, color: {type: 'double', from: '#fff', to: '#fff'}, hide: null}}],
    series2: [{color: null, area: {frameColor: null, frameColorWidth: null, color: {type: 'double', from: '#fff', to: '#fff'}, hide: null}}]
  };
  opt = _.deepMerge(opt, options);
  DataV.call(this, container, opt);
}

LineWithPointArea = DataV.extend(LineWithPointArea, {
  data: function (data) {
    if (!data) return this._data;
    var opt = this.options;
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;
    var zkey = opt.zaxis.key;
    data.forEach(function (obj) {
      if (!_.isArray(obj[ykey])) {
        obj[ykey] = [obj[ykey]];
      }
      if (!_.isArray(obj[zkey])) {
        obj[zkey] = [obj[zkey]];
      }
      obj[ykey] = _.map(obj[ykey], function (n) {
        if (typeof n === 'string') {
          n = _.toNumber(n);
        }
        if (!n && !opt.hiddenEmptyData) {
          n = 0;
        }
        return n;
      });
      obj[zkey] = _.map(obj[zkey], function (n) {
        if (typeof n.value === 'string') {
          n.value = _.toNumber(n.value);
        }
        if (!n.value && !opt.hiddenEmptyData) {
          n.value = 0;
        }
        return n;
      });
    });
    // 如果是时间型的话format后排序
    if (opt.xaxis.format && opt.xaxis.type === 'time') {
      let format = d3.time.format(opt.xaxis.format);
      data.sort((a, b) => format.parse(a[xkey]) - format.parse(b[xkey]));
    }
    this._data = data;
  },
  beforeRender: function () {
    DataV.prototype.beforeRender.call(this);
    var self = this;
    var opt  = this.options;

    opt.series2 && opt.series2.length && opt.series2.forEach(function (serie, i) {
      serie.color && self.dealColor(opt, 'series2[' + i + '].color');
      serie.area && self.dealColor(opt, 'series2[' + i + '].area.color');
    });
  },
  afterRender: function () {
    var opt = this.options;
    var data = this.data();
    var xAxis = this.getComs('axis', 'xaxis');
    var x = xAxis.getX();
    var zAxis = this.getComs('axis', 'zaxis');
    var z = zAxis.getX();
    var xkey = opt.xaxis.key;
    var zkey = opt.zaxis.key;
    var self = this;
    var series, areaSeries, pointSeries, labelSeries;
    var transform = this.svg.select('.series:not(.area2-g)').attr('transform');
    if (opt.isFirst) {
      areaSeries = this.svg.insert('g', '.scatterplot-g .interaction-g').attr({class: 'area2-g series', transform: transform});
      series = this.svg.insert('g', '.scatterplot-g .interaction-g').attr({class: 'series2 series', transform: transform});
      pointSeries = this.svg.insert('g', '.scatterplot-g').attr({class: 'scatterplot2-g series interaction-g', transform: transform});
      labelSeries = this.svg.append('g').attr('class', 'series-labels');
    } else {
      areaSeries = this.svg.select('.area2-g').attr('transform', transform);
      series = this.svg.select('.series2').attr('transform', transform);
      pointSeries = this.svg.select('.scatterplot2-g').attr('transform', transform);
      labelSeries = this.svg.select('.series-labels');
    }
    labelSeries.attr('transform', transform);

    var len = _.maxBy(data, function (n) {
      return n[zkey].length;
    })[zkey].length;

    var updateAreaSeriesAttr = function (d, seriesIndex) {
      var that = this;
      var area = d3.svg
        .area().x(function (d) {
          if (opt.xaxis.type === 'time' && typeof d[xkey] === 'string') {
            return x(d3.time.format(xAxis.options.format).parse(d[xkey])) + (x.rangeBand ?  x.rangeBand() / 2 : 0);
          }
          return x(d[xkey]) + (x.rangeBand ?  x.rangeBand() / 2 : 0);
        })
        .y0(z(zAxis.getMin()))
        .y1(function (d) {
          return z(d[zkey] || zAxis.getMin());
        });
      area.interpolate(opt.series2[seriesIndex] && opt.series2[seriesIndex].interpolate || opt.interpolate || '');

      // clipPath 动画
      that.attr('clip-path', 'url(#' + self.clipPathId + ')');

      var animationHandler = ({duration, ease}) => {
        that.transition()
          .duration(opt.isFirst && !opt.animationUpdateFromPrevious ? 0 : duration)
          .ease(ease)
          .attr('d', area);
      }

      var notAnimationHandler = () => that.attr('d', area);

      animationController({animationHandler: animationHandler, notAnimationHandler, options: opt})

      var cfg = opt.series2[seriesIndex] && opt.series2[seriesIndex].area || opt.area;
      if (cfg && _.isObject(cfg)) {
        that.style({
          'fill': function () {
            return cfg.color && cfg.color.res;
          },
          'stroke': function () {
            return cfg.frameColor;
          },
          'stroke-width': function () {
            return cfg.frameColorWidth;
          },
          'display': (d, i) => {
            return cfg.hide || (opt.hiddenEmptyData && !_.get(d, `${i}.${zkey}`)) ? 'none' : 'block';
          },
          'pointer-events': 'none'
        });
      }
    };

    var updateSeriesAttr = function (d, index) {
      var line = this;
      var area = d3.svg
        .line().x(function (d) {
          if (opt.xaxis.type === 'time' && typeof d[xkey] === 'string') {
            return x(d3.time.format(xAxis.options.format).parse(d[xkey])) + (x.rangeBand ?  x.rangeBand() / 2 : 0);
          }
          return x(d[xkey]) +
            (x.rangeBand ?  x.rangeBand() / 2 : 0);
        })
        .y(function (d) {
          return z(d[zkey] || zAxis.getMin());
        });

      area.interpolate(opt.series2[index] && opt.series2[index].interpolate || opt.interpolate || '');

      if (opt.withAnimated) {
        line.transition()
          .duration(opt.animatedTiming)
          .ease(opt.animatedEasing)
          .attr({d: area});
      } else {
        line.attr({d: area});
      }

      line.style({
        'stroke': function () {
          return opt.series2[index] && opt.series2[index].color && opt.series2[index].color.res || (opt.color && opt.color.res);
        },
        'stroke-width': function () {
          return opt.series2[index] && opt.series2[index].colorWidth || opt.colorWidth;
        },
        'pointer-events': 'none'
      });
    };

    var updatePointSeriesAttr = function (d, seriesIndex) {
      var that = d3.select(this);
      if (opt.withAnimated) {
        if (opt.isFirst) {
          that.attr({
            cx: function (d) {
              return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
            },
            cy: function (d) {
              return z(d[zkey][seriesIndex].value || zAxis.getMin());
            },
            r: 0
          });
        }
        that.transition()
          .duration(opt.animatedTiming)
          .ease(opt.animatedEasing);
      }
      var cfg = opt.series2[seriesIndex] && opt.series2[seriesIndex].point || opt.point;
      d[zkey][seriesIndex] && that.attr({
        cx: function () {
          return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
        },
        cy: z(d[zkey][seriesIndex].value || zAxis.getMin()),
        r: cfg.radius || 4
      }) || that.attr({
        cx: function () {
          if (opt.hiddenEmptyData) return;
          return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
        },
        cy: function () {
          if (opt.hiddenEmptyData) return;
          return z(zAxis.getMin());
        },
        r: opt.hiddenEmptyData ? 0 : cfg.radius || 4
      });
      if (cfg && _.isObject(cfg)) {
        that.style({
          'fill': cfg.color,
          'stroke': cfg.frameColor,
          'stroke-width': cfg.frameColorWidth,
          'display': (d, i) => {
            return cfg.hide || (opt.hiddenEmptyData && d[zkey][i].__isNull) ? 'none' : 'block';
          }
        });
      }
    };

    var updateLabelAttr = function (d, i, index) {
      if (d && _.isNumber(d[zkey][i].value)) {
        this.attr({
          x: function () {
            return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
          },
          y: function () {
            return z(d[zkey][i].value);
          },
          dx: function () {
            return opt.series2[i] && opt.series2[i].label && opt.series2[i].label.dx || opt.label.dx || 0;
          },
          dy: function () {
            return opt.series2[i] && opt.series2[i].label && opt.series2[i].label.dy || opt.label.dy || 0;
          },
        }).html(function () {
          var format = opt.series2[i] && opt.series2[i].label && opt.series2[i].label.format || opt.label.format || null;
          if (format) {
            return format.call(self, d, i);
          } else {
            return d[zkey][i].value;
          }
        }).style({
          'text-anchor': function () {
            return opt.series2[i] && opt.series2[i].label && opt.series2[i].label.anchor || opt.label.anchor || 'middle';
          },
          'display': function () {
            var show = (opt.series2[i] && opt.series2[i].label && typeof opt.series2[i].label.show === 'boolean') ? opt.series2[i].label.show : (typeof opt.label.show === 'boolean' ? opt.label.show : false);
            const emptyDataHide = opt.hiddenEmptyData && d[zkey][i].__isNull;
            return show && !emptyDataHide && _.isNumber(d[zkey][i].value) && 'block' || 'none';
          },
          'font-size': function () {
            return (opt.series2[i] && opt.series2[i].label && opt.series2[i].label.fontSize || opt.label.fontSize || '10') + 'px';
          },
          'font-weight': function () {
            return opt.series2[i] && opt.series2[i].label && opt.series2[i].label.fontWeight || opt.label.fontWeight;
          },
          'fill': function () {
            return opt.series2[i] && opt.series2[i].label && opt.series2[i].label.color || opt.label.color;
          },
          'stroke': function () {
            return opt.label.strokeWidth && opt.series2[i] && opt.series2[i].label && opt.series2[i].label.color || opt.label.color || '#fff';
          },
          'stroke-width': opt.label.strokeWidth,
        });
      }
    };

    areaSeries.datum(data);
    series.datum(data);
    var ps = pointSeries.selectAll('.series-group').data(data);
    var psenter = ps.enter().append('g').attr('class', 'series-group');
    ps.exit().remove();

    var labels = labelSeries.selectAll('.series-group').data(data);
    labels.enter().append('g').attr('class', 'series-group');
    labels.exit().remove();

    for (var i = 0; i < len; i++) {
      var lineData = this.calZLineData(data, i);
      var area = areaSeries.select('.serie' + (i + 1));
      var line = series.select('.serie' + (i + 1));

      var node = area[0][0] && area || areaSeries.append('path').attr('class', 'serie serie' + (i + 1)).style('stroke', 'none');
      node = node.datum(lineData);
      var lnode = line[0][0] && line || series.append('path').attr('class', 'serie serie' + (i + 1)).style('stroke', 'none');
      lnode = lnode.datum(lineData);

      node && updateAreaSeriesAttr.call(node, lineData, i);
      lnode && updateSeriesAttr.call(lnode, lineData, i);

      psenter.append('circle')
        .attr('class', `${interactionHandlerSelector} serie serie${(i + 1)}`)
        .attr({
          [SERIES_INDEX]: i,
          [AXIS_NAME]: 'z'
        })
        .each(function (d) {
          updatePointSeriesAttr.call(this, d, i);
        });
      ps.each(function (d) {
        var that = d3.select(this);
        var node = that.select('.serie' + (i + 1))[0][0] || that.append('circle')
          .attr({
            'class': `${interactionHandlerSelector} serie serie${(i + 1)}`,
            [SERIES_INDEX]: i,
            [AXIS_NAME]: 'z'
          })[0][0];
        node && updatePointSeriesAttr.call(node, d, i);
      });

      labels.each(function (d, index) {
        var that = d3.select(this);
        var label = that.select('.serie-label-' + (i + 1))[0][0] ? that.select('.serie-label-' + (i + 1)) :
          that.append('text').attr('class', 'serie-label serie-label-' + (i + 1));
        updateLabelAttr.call(label, data[index], i, index);
      });
    }

    areaSeries.selectAll('.serie.serie' + len + ' ~ .serie').remove();
    series.selectAll('.serie.serie' + len + ' ~ .serie').remove();

    series.selectAll('.serie').each(function (d, i) {
      var n = d3.select(this);
      if (opt.series2[i] && opt.series2[i].style === 'dashed') {
        n.style({
          'stroke-dasharray': opt.series2[i].dashed || '4 4'
        });
      } else {
        n.style({
          'stroke-dasharray': 'none'
        });
      }
    });

    DataV.prototype.afterRender.call(this);
  },
  calZLineData: function (d, index) {
    var opt = this.options;
    var xkey = opt.xaxis.key;
    var zkey = opt.zaxis.key;

    var result = [];
    if (!d.length) return result;
    d = _.filter(d, function (n) {
      return opt.hiddenEmptyData ? +(_.get(n, `${zkey}.${index}.value`)) !== 0 : true;
    });
    d.forEach(function (n, i) {
      if (_.isNumber(n[zkey][index].value)) {
        var tmp = {};
        tmp[xkey] = n[xkey];
        tmp[zkey] = +n[zkey][index].value;
        result.push(tmp);
      }
    });
    return result;
  },
  updateAfterRender: function () {
    LineWithPointArea.prototype.afterRender.call(this);

    // 位置调整在line-with-point-area之后
    var transform = this.svg.select('.series:not(.area2-g)').attr('transform');
    this.svg.select('.area2-g').attr('transform', transform);
    this.svg.select('.series2').attr('transform', transform);
    this.svg.select('.scatterplot2-g').attr('transform', transform);
    this.svg.select('.series-labels').attr('transform', transform);
  },
  _beforeRender: function () {
    this.emit('start.beforerender');
    this.beforeRender();
    this.emit('before.render');
    var opt = this.options;
    if (opt.xaxis) {
      opt.xaxis = _.deepMerge(opt.xaxisDefault, opt.xaxis);
      var xaxis = this.renderXAxis('xaxis', this.svg[0][0], opt.xaxis);
    }
    if (opt.yaxis) {
      opt.yaxis = _.deepMerge(opt.yaxisDefault, opt.yaxis);
      var yaxis = this.renderYAxis('yaxis', this.svg[0][0], opt.yaxis);
    }
    if (opt.zaxis) {
      opt.zaxis = _.deepMerge(opt.yaxisDefault, opt.zaxis);
      var zaxis = this.renderAxis('zaxis', this.svg[0][0], opt.zaxis);
    }

    if (opt.margin.containLabel) {
      xaxis.options.__height = xaxis.el[0][0].getBBox().height - (opt.xaxis.net && xaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerHeight || 0);
      yaxis.options.__width = yaxis.el[0][0].getBBox().width - (opt.yaxis.net && yaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      zaxis.options.__width = zaxis.el[0][0].getBBox().width - (opt.zaxis.net && zaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      var height = xaxis.options.__height + opt.xaxis.dy;
      var yWidth = yaxis.options.__width + opt.yaxis.dy;
      var zWidth = zaxis.options.__width + opt.zaxis.dy;
      opt._innerWidth = opt.innerWidth;
      opt._innerHeight = opt.innerHeight;
      opt.innerWidth -= (yWidth + zWidth);
      opt.innerHeight -= height;
      xaxis.update(null, _.deepMerge(opt.xaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      yaxis.update(null, _.deepMerge(opt.yaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      zaxis.update(null, _.deepMerge(opt.zaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      if (opt.yaxis.orient === 'left') {
        yaxis.el.attr('transform', 'translate(' + yWidth + ',0)');
        zaxis.el.attr('transform', 'translate(' + (opt.innerWidth + yWidth) + ',0)');
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', ' + opt.innerHeight + ')');
          this.series.attr('transform', 'translate(' + yWidth + ', 0)');
        } else if (opt.xaxis.orient === 'top') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', 0)');
          this.series.attr('transform', 'translate(' + yWidth + ', ' + height + ')');
        }
      } else if (opt.yaxis.orient === 'right') {
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(0, ' + opt.innerHeight + ')');
        } else if (opt.xaxis.orient === 'top') {
          this.series.attr('transform', 'translate(0, ' + height + ')');
        }
      }
    }

    if (opt.tooltip) {
      this.renderTooltip('tooltip', this.el[0][0], opt.tooltip);
    }
    this.emit('end.beforerender');
  },
  _updateBeforeRender: function () {
    this.updateBeforeRender();
    var opt = this.options;
    var tmp = {innerWidth: opt.innerWidth, innerHeight: opt.innerHeight};
    if (opt.xaxis) {
      var xaxis = this.getComs('axis', 'xaxis');
      xaxis.update(this._data, _.deepMerge(tmp, opt.xaxis));
    }
    if (opt.yaxis) {
      var yaxis = this.getComs('axis', 'yaxis');
      yaxis.update(this._data, _.deepMerge(tmp, opt.yaxis));
    }
    if (opt.zaxis) {
      var zaxis = this.getComs('axis', 'zaxis');
      zaxis.update(this._data, _.deepMerge(tmp, opt.zaxis));
    }

    if (opt.margin.containLabel) {
      xaxis.options.__height = xaxis.el[0][0].getBBox().height - (opt.xaxis.net && xaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerHeight || 0);
      yaxis.options.__width = yaxis.el[0][0].getBBox().width - (opt.yaxis.net && yaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      zaxis.options.__width = zaxis.el[0][0].getBBox().width - (opt.zaxis.net && zaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      var height = xaxis.options.__height + opt.xaxis.dy;
      var yWidth = yaxis.options.__width + opt.yaxis.dy;
      var zWidth = zaxis.options.__width + opt.zaxis.dy;
      opt._innerWidth = opt.innerWidth;
      opt._innerHeight = opt.innerHeight;
      opt.innerWidth -= (yWidth + zWidth);
      opt.innerHeight -= height;
      xaxis.update(null, _.deepMerge(opt.xaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      yaxis.update(null, _.deepMerge(opt.yaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      zaxis.update(null, _.deepMerge(opt.zaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      if (opt.yaxis.orient === 'left') {
        yaxis.el.attr('transform', 'translate(' + yWidth + ',0)');
        zaxis.el.attr('transform', 'translate(' + (opt.innerWidth + yWidth) + ',0)');
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', ' + opt.innerHeight + ')');
          this.series.attr('transform', 'translate(' + yWidth + ', 0)');
        } else if (opt.xaxis.orient === 'top') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', 0)');
          this.series.attr('transform', 'translate(' + yWidth + ', ' + height + ')');
        }
      } else if (opt.yaxis.orient === 'right') {
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(0, ' + opt.innerHeight + ')');
        } else if (opt.xaxis.orient === 'top') {
          this.series.attr('transform', 'translate(0, ' + height + ')');
        }
      }
    }
  }
});

module.exports = LineWithPointArea;
