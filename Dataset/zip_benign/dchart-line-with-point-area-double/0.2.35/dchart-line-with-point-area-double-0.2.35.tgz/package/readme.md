dchart-line-with-point-area-double

符合dchart规范的双轴折线点图

### 安装

```
npm install dchart-line-with-point-area-double
```

### 用法
```
var Line = require('dchart-line-with-point-area-double');
var line = new Line(container, {
  xaxis: {
    type: 'time',             //时间类型
    padding: [0.2, 0.4],      //柱状子间的间距[innerPadding, outerPadding],默认[0.9, 0.4]
    dy: 40,                   //位移
    tickFormat: function (d, i) { 
        return d.x
    }
  },
  yaxis: {
    min: null                 //默认null会自动计算数据中的最小值
    max: null                 //默认null会自动计算数据中的最大值
  }
});
line.render([
        {"x": "山东", "y": 100, "z": 200},
        {"x": "山西", "y": 52, "z": 197},
        {"x": "河北", "y": 49, "z": 311}
      ]);
```
