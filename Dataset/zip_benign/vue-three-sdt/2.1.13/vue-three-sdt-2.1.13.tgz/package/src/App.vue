<template>
  <model-json
    ref="fileModel"
    :backgroundAlpha="backgroundAlpha"
    :src="indoorfileUrl"
    :labelList="labelList"
    :cameraSize = "cameraSize"
    :controlsOptions="controlsOptions"
    :cameraPosition="cameraPosition"
    @on-click="onClick"
    @on-model="getEditModel"
    @on-cartoon="getCartoon"
    :standSize='1.6'
    :nodeColor="'cb5f9a'"
    :isEdit="true"
    :dataMes="dataMes"
    :windDataMes="windDataMes"
    :otherThreeMod="otherThreeMod"
    style="background-color: #000000;">
  </model-json>
  <!--	 <file-to-json :src="fbxUrl"></file-to-json>-->
</template>

<script setup>
import ModelJson from './components/vue-3d/model-mixin.vue'
import FileToJson from './components/vue-3d/fileToJson.vue'
import {ref} from 'vue'
const indoorfileUrl = ref('http://localhost:8000/startfile/shaozhai.json')
const fbxUrl = ref('http://localhost:8000/startfile/3ge(1).glb')
const backgroundAlpha = ref(0)
const cameraPosition = ref({
  "x": 931,
  "y": 2027,
  "z": 3811
})
const controlsOptions = ref({
  autoRotate: false,
  autoRotateSpeed: 0.5
})
const cameraSize = ref(0.01)
const labelList = ref([{
  text: '32m³/min',
  name: '351-347',
  num: 32
}, {
  text: '344m³/min',
  name: '342-351',
  num: 344
}])

const otherThreeMod = []

// 点击对象
const intersected = ref({})

let editModel = null

function getEditModel (model) {
  editModel = model
}

const dataMes = ref({})
const windDataMes = ref({})

const fileModel = ref(null)

function onClick (event) {
  if (!event) {
    intersected.value = null
    return
  }
  console.log('========单击========')
  console.log(event.object)
  // console.log(event.object.material.color.getHexString())
  // console.log(fileModel.value.getCameraData())
  // console.log(fileModel.value.getObjectData())
  // console.log(fileModel.value.getModel())
  intersected.value = event.object
  // console.log(event)
  // console.log(event.object.material)
  if (event.setModelType) {
    // console.log(event)
    editModel.addSmallModel(
      {
        x: event.point.x,
        y: event.point.y,
        z: event.point.z
      },
      event.object,
      event.setModelType,
      {
        id: '11',
        name: '风门1',
        type: '2',
        code: '3'
      }
    )
  }
  if (intersected.value.modelMes) {
    dataMes.value = {
      name: '风门',
      id: '111',
      obj: {
        windSpeed: '123',
        airVolume: '123'
      },
      messList: [{
        name: 'asdasdas',
        value: '123123',
        type: '106001',
      }, {
        name: 'asdasdas',
        value: '123123',
        type: '106001',
      }, {
        name: 'asdasdas',
        value: '123123'
      }, {
        name: 'asdasdas',
        value: '123123'
      }],
      x: event.point.x,
      y: event.point.y,
      z: event.point.z
    }
  }
}
let cartoon = null
function getCartoon (toon) {
  cartoon = toon
  cartoon._playCartoon()
}

</script>

<style scoped>
a {
  color: #42b983;
}
</style>
