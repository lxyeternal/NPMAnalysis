<template>
  <div ref="myThreeCas" class="modelBody">
    <canvas
      ref="canvas"
      class="modelBody"
      @click="onClick($event)"
      @dblclick="onDblclick($event)"
      @mousedown="onMouseDown($event)"
      @mousemove="onMouseMove($event)"
    ></canvas>
    <edit-area v-if="isEdit" @optBtn="optBtn" @save-model="saveModel"></edit-area>
    <div class="pmBtn" v-if="isRedact">
      <label style="float: left;">平面高度</label>
      <input v-model="planeHei" />
      <label style="float: left;">起点高度</label>
      <input v-model="initPoint" />
    </div>
    <!-- 删除弹窗 -->
    <delete-dialog v-if="showDeleteDia" @close="showDeleteDia = false" @confirm="confirmDelete"></delete-dialog>

    <pop-up ref="mesPage" :popup="props.dataMes" v-if="showMesDia"></pop-up>
    <wind-pop ref="windPage" :popup="windDataMes" v-if="showWindMesDia"></wind-pop>
  </div>
</template>

<script setup>
import '../../assets/scss/modelmixin.scss'

import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch,watchEffect } from 'vue'

import {
  Clock,
  Raycaster,
  Vector2,
  PerspectiveCamera,
  Scene,
  Object3D,
  Vector3,
  WebGLRenderer,
  Color,
  AmbientLight,
  PointLight,
  DirectionalLight,
  HemisphereLight,
  AnimationMixer,
  MeshBasicMaterial,
  ObjectLoader
} from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'
import { TransformControls } from 'three/examples/jsm/controls/TransformControls'
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer'
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass'
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass'
import { OutlinePass } from 'three/examples/jsm/postprocessing/OutlinePass'
import { FXAAShader } from 'three/examples/jsm/shaders/FXAAShader'
import { CopyShader } from 'three/examples/jsm/shaders/CopyShader'
import { BloomPass } from 'three/examples/jsm/postprocessing/BloomPass'
import { CSS2DObject, CSS2DRenderer } from 'three/examples/jsm/renderers/CSS2DRenderer'
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'

// 编辑区
import EditArea from '../edit-area/index.vue'
// 删除弹窗
import DeleteDialog from '../deleteDialog/index.vue'
import PopUp from '../myPop/popUp.vue'
import WindPop from '../myPop/windPop.vue'

// 删除弹窗
import { getSizes } from '../../utils/threeutil'

//模型 动画类
import { cartoonUtil } from '../../utils/animModel'
// 模型编辑类
import { editModel } from '../../utils/editModel'

import { setNewPlane } from './pubModFun.js'

const DEFAULT_GL_OPTIONS = {
  antialias: true,
  alpha: true
}
// 时钟，动画刷新
const clock = new Clock()
const props = defineProps({
  src: String,
  width: Number,
  height: Number,
  position: {
    type: Object,
    default() {
      return { x: 0, y: 0, z: 0 }
    }
  },
  rotation: {
    type: Object,
    default() {
      return { x: 0, y: 0, z: 0 };
    }
  },
  scale: {
    type: Object,
    default() {
      return { x: 1, y: 1, z: 1 };
    }
  },
  lights: {
    type: Array,
    default() {
      return [{
        type: 'Hemispherelight',
        position: { x: 1, y: 1, z: 1 },
        skyColor: 0xffffff,
        groundColor: 0xffffff,
        intensity: 1
      }, {
        type: 'Ambientlight',
        color: 0xffffff,
        intensity: 1
      }]
    }
  },
  cameraPosition: {
    type: Object,
    default() {
      return { x: 0, y: 1000, z: 2000 }
    }
  },
  cameraRotation: {
    type: Object,
    default() {
      return { x: 0, y: 0, z: 0 }
    }
  },
  cameraUp: {
    type: Object
  },
  cameraLookAt: {
    type: Object
  },
  backgroundColor: {
    default: 0xffffff
  },
  backgroundAlpha: {
    type: Number,
    default: 1
  },
  controlsOptions: {
    type: Object
  },
  crossOrigin: {
    default: 'anonymous'
  },
  gammaOutput: {
    type: Boolean,
    default: true
  },
  glOptions: {
    type: Object
  },
  // 相机分辨率大小
  cameraSize: {
    type: Number,
    default() {
      return 1;
    }
  },
  showplace: {
    type: Boolean,
    default: true
  },
  // 标签列表
  labelList: {
    type: Array,
    default() {
      return [];
    }
  },
  isEdit: {
    type: Boolean,
    default: false
  },
  nodeColor: {
    type: String
  },
  rwColorNums: {
    type: Array,
    default() {
      return [261.3, 52.8, 27.5, 9.6, 0.6, 0]
    }
  },
  // 待添加模型标准大小
  standSize: {
    type: Number,
    default() {
      return 1;
    }
  },
  // 风门/风窗模型数据
  dataMes: {
    type: Object,
    default: {}
  },
  // 风速传感器模型数据
  windDataMes: {
    type: Object,
    default: {}
  },
  loadType: {
    type: String,
    default: ''
  },
  otherThreeMod: {
    type: Array,
    default: []
  }
})
const canvas = ref(null)
const myThreeCas = ref(null)
let size = {
  width: props.width,
  height: props.height
}
let object, camera, renderer, controls, transformControl, reqId, composer, outlinePass, effectFXAA, mixer, newCartoon, newModel, planeModel,
  initModel, dealRoadWay, loader;

let raster = new Raycaster()
let mouse = new Vector2()
let scene = new Scene()
let wrapper = new Object3D()

let labelRenderer = new CSS2DRenderer()
let allLights = []
let moveTextures = []
let selectedObjects = []
let initialCamera = 0
const planeHei = ref(0)
const initPoint = ref(0)
watch(planeHei, (newHei) => {
  planeModel.position.y = newHei
})
// 编辑区名称
const editName = ref('')

let startRedact = false
const isRedact = computed(() => editName.value === 'isRedact')
const isRemove = computed(() => editName.value === 'isRemove')
const addDoor = computed(() => editName.value === 'addDoor')
const addWindow = computed(() => editName.value === 'addWindow')
const addSensor = computed(() => editName.value === 'addSensor')
const isWind = computed(() => editName.value === 'isWind')
const isFlow = computed(() => editName.value === 'isFlow')
const isTSControl = computed(() => editName.value === 'isTSControl')
// 显示确认删除弹窗
const showDeleteDia = ref(false)
const rwColors = ['#FF96FF', '#E400E4', '#FF0000', '#FFFF00', '#00FF00', '#00FFFF', '#000080', '#000040']

const emit = defineEmits(['on-load', 'on-progress', 'on-error', 'on-click', 'on-model', 'on-cartoon', 'delete-model', 'end-draw', 'on-dblclick', 'save-model'])

onMounted(() => {
  changeLoader()

  if (props.width === undefined || props.height === undefined) {
    size = {
      width: canvas.value.offsetWidth,
      height: canvas.value.offsetHeight
    }
  }
  const options = Object.assign({}, DEFAULT_GL_OPTIONS, props.glOptions, {
    canvas: canvas.value
  })
  camera = new PerspectiveCamera(40, 1, props.cameraSize, 5000000)
  renderer = new WebGLRenderer(options)
  renderer.shadowMap.enabled = true
  renderer.autoClear = false
  renderer.antialias = true
  renderer.alpha = true
  labelRenderer.domElement.style.position = 'absolute'
  labelRenderer.domElement.style.top = '0px'
  labelRenderer.setSize(size.width, size.height)
  labelRenderer.domElement.style.pointerEvents = 'none'
  myThreeCas.value.appendChild(labelRenderer.domElement)
  controls = new OrbitControls(camera, canvas.value)
  controls.type = 'orbit'

  transformControl = new TransformControls(camera, canvas.value)
  scene.add(transformControl)
  scene.add(wrapper)

  // 移动控制器监听
  transformControl.addEventListener('change', render, false);
  transformControl.addEventListener('dragging-changed', onDraggingChanged, false)
  transformControl.addEventListener('objectChange', onObjectChange, false)

  // 添加平面
  if (props.showplace) {
    planeModel = setNewPlane(planeModel, wrapper, props.standSize)
    wrapper.add(planeModel)
  }

  load()
  loadOtherMods()
  update()
  animate()
})
onBeforeUnmount(() => {
  cancelAnimationFrame(reqId)
  // scene.dispose()
  renderer.dispose()
  if (controls) {
    controls.dispose()
  }
  if (transformControl) {
    transformControl.dispose()
  }
  transformControl.removeEventListener('change', render, false)
  transformControl.removeEventListener('dragging-changed', onDraggingChanged, false)
  transformControl.removeEventListener('objectChange', onObjectChange, false)
  renderer.forceContextLoss()
  renderer = ''
})
watch(() => props.src, () => {
  changeLoader()
  load()
})
// 监听rotation
watch(() => props.rotation, (val) => {
  if (!object) return
  object.rotation.set(val.x, val.y, val.z)
})
// 监听position
watch(() => props.position, (val) => {
  if (!object) return
  object.position.set(val.x, val.y, val.z)
})
// 监听scale
watch(() => props.scale, (val) => {
  if (!object) return
  object.scale.set(val.x, val.y, val.z)
})
// 监听风流显示
watch(isWind, (newVal) => {
  if (newVal) {
    moveTextures = newModel.addAllWindDir();
  } else {
    for (let i = 0; i < moveTextures.length; i++) {
      let moveTexture = moveTextures[i]
      let obj = moveTexture.obj
      object.remove(obj)
      obj.geometry.dispose()
      obj.material.dispose()
    }
    moveTextures = []
  }
})

// 监听风量显示
watch(isFlow, () => {
  addLabels()
})
watchEffect(() => {
  if (props.labelList && !props.isEdit) {
    addLabels2()
  }
})
// 监听移动编辑
watch(isTSControl, (newVal) => {
  // 关闭移动
  transformControl.detach()
  transformControl.enabled = newVal
})
// 监听标准大小
watch(() => props.standSize, (val) => {
  newModel.standSize = val
})

function changeLoader() {
  if (props.loadType === 'FBX') {
    loader = new FBXLoader()
  } else if (props.loadType === 'GLTF') {
    loader = new GLTFLoader()
  } else {
    loader = new ObjectLoader()
  }
}

function onClick(event) {
  if (selectedObjects.length > 0) {
    selectedObjects[0].children = []
  }
  selectedObjects = []
  const intersected = pick(event.clientX, event.clientY)
  if (intersected !== null) {
    selectedObjects.push(intersected.object)
  }
  outlinePass.selectedObjects = selectedObjects
  // 判断是否删除
  if (isRemove.value && intersected && intersected.object.name !== 'planeModel') {
    showDeleteDia.value = true
  }
  // 判断是否添加模型
  if ((addDoor.value || addWindow.value || addSensor.value) && intersected.object.name !== 'planeModel') {
    intersected.setModelType = addDoor.value ? '1' : addWindow.value ? '2' : addSensor.value ? '3' : '3'
    // newModel.addSmallModel(
    // 	{
    // 		x: intersected.point.x,
    // 		y: intersected.point.y,
    // 		z: intersected.point.z
    // 	},intersected.object,mType
    // )
  }
  // 判断是否移动
  if (intersected && isTSControl.value) {
    let obj = intersected.object
    // 判断是否是节点
    if (obj.isMesh && obj.name !== 'planeModel' && obj.name.split('-').length === 1) {
      if (obj !== transformControl.object) {
        transformControl.attach(obj)
      }
      let tName = obj.name + ''
      dealRoadWay = []
      // 添加待移动模型
      object.traverse((child) => {
        if (child.isMesh && child.name.indexOf(tName) !== -1) {
          if (child.name.split('-').length > 1) {
            dealRoadWay.push(child)
          }
        }
      })
    }
  }
  emit('on-click', intersected, selectedObjects)
}
function onDblclick(event) {
  // 判断是否新增
  if (isRedact.value) {
    const intersected = pick(event.clientX, event.clientY)
    startRedact = !startRedact
    // 找中心点
    let po = new Vector3(intersected.point.x, intersected.point.y, intersected.point.z)
    let obj = intersected.object
    if (obj.name !== 'planeModel') {
      if (obj.name.split('-').length > 1) {
        // 找中心点
        po = newModel.findCenterByPoint(po, obj)
      } else {
        po = obj.position
      }
    }
    if (startRedact) {
      newModel.addNewCylinder(po, obj)
      // 起始点
      initPoint.value = po.y
      planeHei.value = po.y
    } else {
      let changeModel = newModel.drawEnd(po, obj)
      emit('end-draw', changeModel)
    }
    emit('on-dblclick', intersected)
  }
}

function onMouseDown(event) {
  const intersected = pick(event.clientX, event.clientY)
  if (event.button === 0) {
  }
  if (event.button === 2) {
    initialCamera = camera.position.clone()
  }
}

function onMouseMove(event) {
  if (!props.showplace) return
  // if (!this.hasListener['on-mousemove']) return
  // 判断是否开启编辑
  if (startRedact) {
    if (selectedObjects.length > 0) {
      selectedObjects[0].children = []
    }
    selectedObjects = []
  }

  const intersected = pick(event.clientX, event.clientY)
  if (event.buttons === 0) {
    // 编辑
    if (intersected && startRedact && intersected.object.name !== 'textcylinder') {
      selectedObjects.push(intersected.object)
      outlinePass.selectedObjects = selectedObjects
      newModel.mouseMoveCylinder({
        x: intersected.point.x,
        y: intersected.point.y,
        z: intersected.point.z
      })
    }
  } else if (event.buttons === 1) {
  } else if (event.buttons === 2) {
    let xChange = planeModel.position.x + camera.position.x - initialCamera.x
    let yChange = planeModel.position.y + camera.position.y - initialCamera.y
    let zChange = planeModel.position.z + camera.position.z - initialCamera.z
    planeModel.position.set(xChange, yChange, zChange)
    planeHei.value = JSON.parse(JSON.stringify(yChange))
    initialCamera = camera.position.clone()
  }
}

function onDraggingChanged(event) {
  controls.enabled = !event.value
}
function onObjectChange() {
  for (let i = 0; i < dealRoadWay.length; i++) {
    newModel.removeModelByNames(dealRoadWay[i].name)
    nextTick(() => {
      newModel.connectBall([dealRoadWay[i].name], dealRoadWay[i].material)
    })
  }
}

function pick(x, y) {
  if (!object) return null

  const rect = canvas.value.getBoundingClientRect()

  x -= rect.left
  y -= rect.top

  mouse.x = (x / size.width) * 2 - 1
  mouse.y = -(y / size.height) * 2 + 1
  raster.setFromCamera(mouse, camera)
  // let vector = new Vector3(this.mouse.x, this.mouse.y,0.5).unproject(this.camera)
  const intersects = raster.intersectObject(isRedact.value ? wrapper : object, true)
  let obj = null;
  if ((intersects && intersects.length) > 0) {
    for (let i = 0; i < intersects.length; i++) {
      if (intersects[i].object.name !== 'textcylinder') {
        obj = intersects[i]
        break
      }
    }
  }
  return obj
}

/**
 * 设置编辑
 */
function optBtn(name) {
  editName.value = name
  // 关闭编辑
  startRedact = false
  newModel.clearCylinder()
}

function confirmDelete() {
  let obj = selectedObjects[selectedObjects.length - 1]
  emit('delete-model', obj.name)
  newModel.removeGeoModel(obj)
  selectedObjects = []
  showDeleteDia.value = false
}

function addLabels() {

  let removeList = []
  if (!object) return;
  object.traverse(child => {
    if (child.type === 'Object3D') {
      removeList.push(child)
    }
  });
  object.remove(...removeList)
  for (let i = 0; i < props.labelList.length; i++) {
    let tNum = parseFloat(props.labelList[i].num)
    let poName = object.children.find(a => {
      return a.name === props.labelList[i].name
    })
    if (!poName) continue
    if (isFlow.value && props.rwColorNums.length > 0) {
      // 根据风量设置颜色
      if (tNum > props.rwColorNums[0]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[0] })
      } else if (tNum > props.rwColorNums[1]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[1] })
      } else if (tNum > props.rwColorNums[2]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[2] })
      } else if (tNum > props.rwColorNums[3]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[3] })
      } else if (tNum > props.rwColorNums[4]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[4] })
      } else if (tNum > props.rwColorNums[5]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[5] })
      } else if (tNum === props.rwColorNums[5]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[6] })
      } else if (tNum < props.rwColorNums[5]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[7] })
      }
    }

    let pos = new Vector3(poName.position.x, poName.position.y, poName.position.z)
    // pos.multiplyScalar(0.5)
    const div = document.createElement('div')
    div.className = 'label'
    div.textContent = isFlow.value ? (props.labelList[i].text ? `${props.labelList[i].text} ${isFlow.value ? props.labelList[i]?.wind : ''}` : '') : ''
    // debugger
    const divLabel = new CSS2DObject(div)
    divLabel.position.set(pos.x, pos.y, pos.z)
    divLabel.name = 'roadName-' + Math.random()
    object.add(divLabel)
  }
}

function addLabels2() {

  let removeList = []
  if (!object) return;
  object.traverse(child => {
    if (child.type === 'Object3D') {
      removeList.push(child)
    }
  });
  object.remove(...removeList)
  for (let i = 0; i < props.labelList.length; i++) {
    let tNum = parseFloat(props.labelList[i].num)
    let poName = object.children.find(a => {
      return a.name === props.labelList[i].name
    })
    if (!poName) continue
    if (props.rwColorNums.length > 0) {
      // 根据风量设置颜色
      if (tNum > props.rwColorNums[0]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[0] })
      } else if (tNum > props.rwColorNums[1]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[1] })
      } else if (tNum > props.rwColorNums[2]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[2] })
      } else if (tNum > props.rwColorNums[3]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[3] })
      } else if (tNum > props.rwColorNums[4]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[4] })
      } else if (tNum > props.rwColorNums[5]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[5] })
      } else if (tNum === props.rwColorNums[5]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[6] })
      } else if (tNum < props.rwColorNums[5]) {
        poName.material = new MeshBasicMaterial({ color: rwColors[7] })
      }
    }

    let pos = new Vector3(poName.position.x, poName.position.y, poName.position.z)
    // pos.multiplyScalar(0.5)
    const div = document.createElement('div')
    div.className = 'label'
    div.textContent = props.labelList[i].text ? `${props.labelList[i].text} ${props.labelList[i]?.wind}` : ''
    // debugger
    const divLabel = new CSS2DObject(div)
    divLabel.position.set(pos.x, pos.y, pos.z)
    divLabel.name = 'roadName-' + Math.random()
    object.add(divLabel)
  }
}

function remove3D() {
  let removeList = []
  object.traverse(child => {
    if (child.type === 'Object3D' && child.name.split('-')[0] !== 'roadName') {
      removeList.push(child)
    }
  });
  object.remove(...removeList)
}

function load() {
  if (!props.src) return
  if (object) {
    wrapper.remove(object)
  }
  loader.load(
    props.src,
    (args) => {
      const object = getObject(args)
      addObject(object)
      emit('on-load')
    },
    xhr => {
      emit('on-progress', xhr)
    },
    err => {
      emit('on-error', err)
    }
  );
}
function getObject(object) {
  return props.loadType === 'GLTF' ? object.scene : object
}
function addObject(obj) {
  object = obj
  // console.log(object.toJSON())
  wrapper.add(object)
  updateModel()
  updateCamera()
  // eslint-disable-next-line new-cap
  newModel = new editModel(object, camera, wrapper, initModel, props.nodeColor, props.standSize)
  emit('on-model', newModel)

  mixer = new AnimationMixer(object)
  newCartoon = new cartoonUtil(object, mixer)
  newCartoon._disposeMod(-1)
  emit('on-cartoon', newCartoon)
}

function update() {
  updateRenderer()
  updateCamera()
  updateLights()
  updateControls()
  updateClickDomColor()
}

function updateModel() {

  if (!object) return

  const position = props.position
  const rotation = props.rotation
  const scale = props.scale

  object.position.set(position.x, position.y, position.z)
  object.rotation.set(rotation.x, rotation.y, rotation.z)
  object.scale.set(scale.x, scale.y, scale.z)
}

function updateRenderer() {

  renderer.setSize(size.width, size.height)
  renderer.setPixelRatio(window.devicePixelRatio || 1)
  renderer.setClearColor(new Color(props.backgroundColor).getHex())
  renderer.setClearAlpha(props.backgroundAlpha)
}

function updateCamera() {
  camera.aspect = size.width / size.height
  camera.updateProjectionMatrix()
  if (!props.cameraLookAt && !props.cameraUp) {
    if (!object) return

    const distance = getSizes(object).length()
    camera.position.set(props.cameraPosition.x, props.cameraPosition.y, props.cameraPosition.z)
    camera.rotation.set(props.cameraRotation.x, props.cameraRotation.y, props.cameraRotation.z)

    if (props.cameraPosition.x === 0 && props.cameraPosition.y === 0 && props.cameraPosition.z === 0) {
      camera.position.z = distance
    }

    camera.lookAt(new Vector3())
  } else {
    camera.position.set(props.cameraPosition.x, props.cameraPosition.y, props.cameraPosition.z)
    camera.rotation.set(props.cameraRotation.x, props.cameraRotation.y, props.cameraRotation.z)
    camera.up.set(props.cameraUp.x, props.cameraUp.y, props.cameraUp.z)

    camera.lookAt(new Vector3(props.cameraLookAt.x, props.cameraLookAt.y, props.cameraLookAt.z))
  }
}

function updateLights() {
  scene.remove(...allLights)
  allLights = []
  props.lights.forEach(item => {
    if (!item.type) return
    const type = item.type.toLowerCase()
    let light = null
    if (type === 'ambient' || type === 'ambientlight') {
      const color = item.color === 0x000000 ? item.color : item.color || 0x404040
      const intensity = item.intensity === 0 ? item.intensity : item.intensity || 1
      light = new AmbientLight(color, intensity)
    } else if (type === 'point' || type === 'pointlight') {
      const color = item.color === 0x000000 ? item.color : item.color || 0xffffff
      const intensity = item.intensity === 0 ? item.intensity : item.intensity || 1
      const distance = item.distance || 0
      const decay = item.decay === 0 ? item.decay : item.decay || 1
      light = new PointLight(color, intensity, distance, decay)
      if (item.position) {
        light.position.copy(item.position)
      }
    } else if (type === 'directional' || type === 'directionallight') {
      const color = item.color === 0x000000 ? item.color : item.color || 0xffffff
      const intensity = item.intensity === 0 ? item.intensity : item.intensity || 1
      light = new DirectionalLight(color, intensity)
      if (item.position) {
        light.position.copy(item.position)
      }
      if (item.target) {
        light.target.copy(item.target)
      }
    } else if (type === 'hemisphere' || type === 'hemispherelight') {
      const skyColor = item.skyColor === 0x000000 ? item.skyColor : item.skyColor || 0xffffff
      const groundColor = item.groundColor === 0x000000 ? item.groundColor : item.groundColor || 0xffffff
      const intensity = item.intensity === 0 ? item.intensity : item.intensity || 1
      light = new HemisphereLight(skyColor, groundColor, intensity)
      if (item.position) {
        light.position.copy(item.position)
      }
    }
    allLights.push(light)
    scene.add(light)
  })
}

function updateControls() {
  if (props.controlsOptions) {
    Object.assign(controls, props.controlsOptions)
  }
}

function updateClickDomColor() {
  composer = new EffectComposer(renderer)
  let renderPass = new RenderPass(scene, camera)
  composer.addPass(renderPass)
  outlinePass = new OutlinePass(new Vector2(window.innerWidth, window.innerHeight), scene, camera)
  composer.addPass(outlinePass)
  let outlineParams = {
    renderToScreen: true,
    edgeStrength: 3, // 度 默认3
    edgeGlow: 1, // 度 默认1
    edgeThickness: 1.0, // 边缘浓度
    pulsePeriod: 0, // 闪烁频率 默认0 值越大频率越低
    usePatternTexture: false, // 使用纹理
    visibleEdgeColor: 0x00ffff, // 边缘可见部分发光颜色
    hiddenEdgeColor: 0x00ffff // 边缘遮挡部分发光颜色
  }
  outlinePass.renderToScreen = outlineParams.renderToScreen
  outlinePass.edgeStrength = outlineParams.edgeStrength
  outlinePass.edgeGlow = outlineParams.edgeGlow
  outlinePass.edgeThickness = outlineParams.edgeThickness
  outlinePass.visibleEdgeColor.set(outlineParams.visibleEdgeColor)
  outlinePass.hiddenEdgeColor.set(outlineParams.hiddenEdgeColor)
  outlinePass.usePatternTexture = outlineParams.usePatternTexture
  // let effectCopy = new ShaderPass(CopyShader)
  // CopyShader是为了能将结果输出，普通的通道一般都是不能输出的，要靠CopyShader进行输出
  // effectCopy.renderToScreen = true // 设置这个参数的目的是马上将当前的内容输出
  // let bloomPass = new BloomPass(0, 50, 0)
  // composer.addPass(bloomPass) // 添加光效
  // composer.addPass(effectCopy) // 输出到屏幕
  effectFXAA = new ShaderPass(FXAAShader)
  effectFXAA.uniforms['resolution'].value.set(1 / window.innerWidth, 1 / window.innerHeight)
  composer.addPass(effectFXAA)
}

function texturesUpdate(data) {
  if (data.counter < 1) {
    data.obj.position.copy(data.curve.getPointAt(data.counter))
    let tangent = data.curve.getTangentAt(data.counter).normalize()
    data.axis.crossVectors(data.up, tangent).normalize()
    let radians = Math.acos(data.up.dot(tangent))
    data.obj.quaternion.setFromAxisAngle(data.axis, radians)
    data.obj.rotateX(-Math.PI * 0.5)
    data.counter += data.speed
  } else {
    data.counter = 0
  }
}

function animate() {
  controls.update()
  let time = clock.getDelta()
  if (mixer) {
    mixer.update(time)
  }
  for (let i = 0; i < moveTextures.length; i++) {
    let moveTexture = moveTextures[i]
    texturesUpdate(moveTexture)
  }
  render()
  reqId = requestAnimationFrame(animate)
}
function render() {
  if (composer) {
    composer.render()
  }
  labelRenderer.render(scene, camera)
  renderer.render(scene, camera)
}

function saveModel() {
  emit('save-model')
}

const showMesDia = ref(false)
const showWindMesDia = ref(false)

// 监听风门数据
watch(() => props.dataMes, () => {
  setMesDiaLog()
})
// 监听传感器数据
watch(() => props.windDataMes, () => {
  setWindMesDiaLog()
})
const mesPage = ref(null)
// 显示风门等模型信息
function setMesDiaLog() {
  remove3D()
  let len = Object.keys(props.dataMes).length
  if (len > 0) {
    showMesDia.value = true
    nextTick(() => {
      let divLabel = new CSS2DObject(mesPage.value.$el);
      divLabel.position.set(props.dataMes.x, props.dataMes.y, props.dataMes.z);
      object.add(divLabel);
    })
  }
}
const windPage = ref(null)
// 显示传感器信息
function setWindMesDiaLog() {
  remove3D()
  let len = Object.keys(props.windDataMes).length
  if (len > 0) {
    showWindMesDia.value = true
    nextTick(() => {
      let divLabel = new CSS2DObject(windPage.value.$el);
      divLabel.position.set(props.windDataMes.x, props.windDataMes.y, props.windDataMes.z);
      object.add(divLabel);
    })
  }
}

watch(() => props.otherThreeMod, () => {
  loadOtherMods()
})

function loadOtherMods() {
  for (let i = 0; i < props.otherThreeMod.length; i++) {
    let mod = props.otherThreeMod[i]
    if (mod.type === 'GLTF') {
      let loader = new GLTFLoader()
      loader.setCrossOrigin(props.crossOrigin)
      loader.load(mod.src, (data) => {
        wrapper.remove(data.scene)
        nextTick(() => {
          wrapper.add(data.scene)
          updateModel()
          updateCamera()
        })
      })
    } else if (mod.type === 'FBX') {
      let loader = new FBXLoader()
      loader.load(mod.src, (...args) => {
        const object = getObject(...args);
        wrapper.remove(object)
        nextTick(() => {
          wrapper.add(object)
          updateModel()
          updateCamera()
        })
      })
    }
  }
}

function getCameraData () {
  return camera
}
function getObjectData() {
  return object
}

function getModel() {
  return newModel
}


defineExpose({
  getCameraData,
  getObjectData,
  getModel,
})

</script>

<style>
</style>
