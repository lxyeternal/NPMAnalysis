import {PlaneGeometry, MeshBasicMaterial, DoubleSide, Mesh} from 'three'
/**
 * 设置平面
 */
export function setNewPlane(planeModel, wrapper, standSize) {
	const geometry = new PlaneGeometry(7000 * standSize, 7000 * standSize, 20, 20)
	const material = new MeshBasicMaterial({
		color: 0x49a8d7,
		side: DoubleSide,
		transparent: false,
		wireframe: true
	})
	geometry.name = 'planeModelgeometry'
	material.name = 'planeModelmaterial'
	planeModel = new Mesh(geometry, material)
	planeModel.rotation.set(-0.5 * Math.PI, 0, 0)
	planeModel.position.set(0, 0, 0)
	planeModel.name = 'planeModel'
	return planeModel
}
