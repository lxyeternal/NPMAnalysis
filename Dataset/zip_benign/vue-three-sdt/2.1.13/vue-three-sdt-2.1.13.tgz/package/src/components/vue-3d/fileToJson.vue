<script setup>
	import { ref, watch, onMounted } from 'vue'
	import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader'

	const props = defineProps({
		src: String,
	})
	watch(() => props.src, (newsrc, prvesrc) => {
		load()
	})
	const loader = new FBXLoader()
	const animations = ref('')

	onMounted(() => {
		load()
	})

	function getObject (geometry) {
	  animations.value = geometry.animations
	  return geometry
	}

	function load() {
		if (!props.src) return;

		loader.load(props.src,(args) => {
				const object = getObject(args)
				console.log(object.toJSON())
			},
			xhr => {
			},
			err => {
			}
		)
	}

</script>
