<template>
  <div class="ol-popup1">
    <div class="fontTitle">
      <span>{{props.popup.name}}</span>
    </div>
    <div class="popup-content1" v-if="props.popup.obj">
      <hr class="style-five" />
      <div>{{ '风速（m/s）:' +  props.popup.obj.windSpeed }}</div>
      <div>{{ '风量(m3/min):' + props.popup.obj.airVolume }}</div>
    </div>
  </div>
</template>

<script setup>
	const props = defineProps({
		popup: {
		  type: Object
		}
	})
</script>

<style>
  .ol-popup1 {
    min-width: 100px;
    height: auto;
    overflow-y: auto;
    background: rgba(53,55,58,0.8);
    -webkit-box-shadow: -5px 0 15px #494A4F inset, 10px 0 15px #494A4F inset;
     box-shadow: -5px 0 15px #494A4F inset;
  }
  .closeIcon {
    color: #ED2641;
    cursor: pointer;
    float: right;
    font-size: 20px;
    line-height: 30px;
    margin-top: 1px;
    margin-right: 1px;
  }
  .fontTitle span{
    font-size: 14px;
    line-height: 30px;
    margin-right: 10px;
    margin-left: 10px;
    color: #fff;
  }
  .popup-content1 {
    width: 100%;
    max-height: 100px;
    overflow-y: auto;
    margin-right: 0;
    float: left;
    font-size: 12px;
    line-height: 20px;
    color: #fff;
  }
</style>
