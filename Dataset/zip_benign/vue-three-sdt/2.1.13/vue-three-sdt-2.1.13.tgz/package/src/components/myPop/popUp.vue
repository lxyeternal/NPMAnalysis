<template>
  <div class="ol-popup">
    <div class="fontTitle">
      <span>{{props.popup.name}}</span>
    </div>
    <div class="popup-content">
      <hr class="style-five" />
			<div style="width: 50%;height: 100%;float: left;">
				<div v-for="(a, aindex) in leftList" :key="aindex">
				  <span>{{a.name + ':&emsp;' + a.value + getSenSorKind(a.type) + ';&emsp;'}}</span>
				</div>
			</div>
			<div style="width: 50%;height: 100%;float: left;">
				<div v-for="(a, aindex) in rightList" :key="aindex">
				  <span>{{a.name + ':&emsp;' + a.value + getSenSorKind(a.type) + ';&emsp;'}}</span>
				</div>
			</div>
    </div>
  </div>
</template>

<script setup>
	import { computed } from 'vue'
	const props = defineProps({
		popup: {
		  type: Object
		}
	})

	const leftList = computed(() => {
		let list = []
		if (props.popup.messList) {
			list = props.popup.messList.filter((i, index) => {
				return index % 2 === 0
			})
		}
		return list
	})

	const rightList = computed(() => {
		let list = []
		if (props.popup.messList) {
			list = props.popup.messList.filter((i, index) => {
				return index % 2 === 1
			})
		}
		return list
	})

	const SenSorKind = [{
		'code': '101001',
		'value': '甲烷',
		'unit': ' %'
	}, {
		'code': '103001',
		'value': 'CO',
		'unit': ' ppm'
	}, {
		'code': '119001',
		'value': '氧气',
		'unit': ' %'
	}, {
		'code': '104001',
		'value': '二氧化碳',
		'unit': ' %'
	}, {
		'code': '102001',
		'value': '温度',
		'unit': ' °C'
	}, {
		'code': '105001',
		'value': '风速',
		'unit': ' m/s'
	}, {
		'code': '106001',
		'value': '压力',
		'unit': ' KPa'
	}, {
		'code': '109001',
		'value': '粉尘',
		'unit': ' mg/m3'
	}, {
		'code': '201001',
		'value': '泵开停',
		'unit': ''
	}, {
		'code': '201002',
		'value': '烟雾',
		'unit': ''
	}, {
		'code': '201003',
		'value': '风门',
		'unit': ''
	}, {
		'code': '201005',
		'value': '风筒',
		'unit': ''
	}, {
		'code': '201006',
		'value': '断电(馈电)',
		'unit': ''
	}, {
		'code': '201007',
		'value': '局扇',
		'unit': ''
	}, {
		'code': '201008',
		'value': '主扇',
		'unit': ''
	}, {
		'code': '301001',
		'value': '断电短路',
		'unit': ''
	}, {
		'code': '701001',
		'value': '交流情况',
		'unit': ''
	}]

  function getSenSorKind (value) {
		let data = ''
		for (let i = 0; i < SenSorKind.length; i++) {
			if (value == SenSorKind[i].code) {
				data = SenSorKind[i].unit
			}
		}
		return data
	}
</script>

<style>
  .ol-popup {
    min-width: 100px;
    min-height: 30px;
    overflow-y: auto;
    background: rgba(53,55,58,0.8);
    -webkit-box-shadow: -5px 0 15px #494A4F inset, 10px 0px 15px #494A4F inset;
     box-shadow: -5px 0 15px #494A4F inset;
  }
  .closeIcon {
    color: #ED2641;
    cursor: pointer;
    float: right;
    font-size: 20px;
    line-height: 30px;
    margin-top: 1px;
    margin-right: 1px;
  }
	.fontTitle span {
		font-size: 14px;
		line-height: 30px;
		margin-right: 10px;
		margin-left: 10px;
		color: #fff;
	}
  .popup-content {
    width: 100%;
    overflow-y: auto;
    margin-right: 0;
    float: left;
    font-size: 12px;
    line-height: 20px;
    color: #fff;
  }
</style>
