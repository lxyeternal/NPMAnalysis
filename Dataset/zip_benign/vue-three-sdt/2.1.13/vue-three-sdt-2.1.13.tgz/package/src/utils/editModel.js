import {nextTick} from 'vue'
import {
	Vector3,
	MeshLambertMaterial,
	SphereGeometry,
	MeshBasicMaterial,
	Mesh,
	Matrix4,
	Quaternion,
	Object3D,
	CylinderGeometry,
	Line3,
	MeshPhongMaterial,
	ObjectLoader,
	CatmullRomCurve3
} from 'three'

import {Point} from './vector.js'

// 静态模型
import {doorModel, sensorModel, windModel, windowModel} from './staticModel.js'

/**
 * 添加模型类
 */
export class editModel {
  constructor (object, camera, wrapper, initModel, nodeColor, standSize) {

    this.object = object
    this.camera = camera
		this.wrapper = wrapper
		this.cylinder = initModel
		// 节点颜色
		this.nodeColor = nodeColor
		// 标准大小
		this.standSize = standSize
		this.startPoint = new Vector3(0, 0, 0)
		// 起始绘制点
		this.startDrawPoint = null
		// 起始绘制模型
		this.startDrawModel = []
		// 终止绘制模型
		this.endDrawModel = []

		// 柱体模型
		this.material = new MeshLambertMaterial({
			color: '#05a110'
		})

		this.initGLB()
  }
  /**
   * 控制某模型隐藏显示
   * @param isshow 是否显示
   * @param name 隐藏显示模型名称
   */
  hideOrShowObj (isshow, name) {
    this.object.traverse((obj) => {
      if (obj.name === name) {
        for (let i = 0; i < obj.children.length; i++) {
          obj.children[i].material.visible = isshow
        }
      }
    })
  }
  changeColor (selectedObjects) {
    this.outlinePass.selectedObjects = selectedObjects
  }
  /**
   * 删除某个对象
   * @param {Object} obj
   */
  deletePicSprite (obj) {
		this.object.remove(obj)
		obj.geometry.dispose()
		obj.material.dispose()
  }

	getMousePositon (e, tz) {
		let mouse = {
			x: '',
			y: ''
		}
		mouse.x = (e.clientX / window.innerWidth) * 2 - 1
		mouse.y = -(e.clientY / window.innerHeight) * 2 + 1
		return new Vector3(mouse.x, mouse.y, tz).unproject(this.camera)
	}
	/**
	 * 生成球模型
	 * @param {Object} position
	 */
	addNewBall (position) {
		const geometry = new SphereGeometry(4, 30, 40)
		const material = new MeshBasicMaterial( {color: 0x0000FF} );
		this.cylinder = new Mesh( geometry, material )
		this.cylinder.position.set(position.x, position.y, position.z)
		this.object.add(this.cylinder)
	}
	/**
	 * 生成初始圆柱
	 * @param {Object} position 生成位置
	 * @param obj
	 */
	addNewCylinder (position, obj) {
		if (!obj) return
		let po = position
		// 判断是否是平面
		if (obj.name !== 'planeModel') {
			// 起始绘制模型
			this.startDrawModel = obj.name.split('-')
		}
		this.pubANC(po)
	}
	pubANC (position) {
		this.cylinder = this.createUnitCylinder(position)
		this.cylinder.name = 'textcylinder'
		this.startPoint = new Vector3(position.x, position.y, position.z)
		this.object.add(this.cylinder)
	}
	calModelCenter (position, obj) {
	}
	/**
	 * 旋转模型
	 * @param {Object} v 目标点
	 * @param {Object} model 模型
	 */
	oriPoint (v, model) {
		let apos = new Vector3(v.x, v.y, v.z)
		let toRod = this.setModelSpin(model, apos)
		model.quaternion.set(toRod.x, toRod.y, toRod.z, toRod.w)
	}
	/**
	 * 计算四元值
	 * @param {Object} model 模型对象
	 * @param {Object} lookPoint 目标点
	 */
	setModelSpin (model, lookPoint) {
		//以下代码在多段路径时可重复执行
		let mtx = new Matrix4()  //创建一个4维矩阵
		mtx.lookAt(lookPoint, model.position , model.up) //设置朝向
		let toRot = new Quaternion()
		toRot.setFromRotationMatrix(mtx)  //计算出需要进行旋转的四元数值
		return toRot
	}
	/**
	 * 鼠标移动设置圆柱体模型长度和朝向
	 * @param p2
	 */
	mouseMoveCylinder (p2) {
		let p1 = this.startPoint
		let len = new Point(p1.x, p1.y, p1.z).distance(new Point(p2.x, p2.y, p2.z))

		this.cylinder.scale.set(1, 1, len)
		this.cylinder.position.set(p1.x + (p2.x - p1.x) / 2, p1.y + (p2.y - p1.y) / 2, p1.z + (p2.z - p1.z) / 2)
		this.oriPoint(p2, this.cylinder)
	}

	/**
	 * 结束绘制
	 */
	drawEnd (position, obj) {
		if (!obj) return
		let po = position
		// 判断是否是平面
		if (obj.name !== 'planeModel') {
			// 结束绘制模型
			this.endDrawModel = obj.name.split('-')
		}
		let lens = this.startDrawModel.length
		let lene = this.endDrawModel.length
		// 生成模型名称
		let name = ''
		// 生成节点
		let nodeArray = [null, null]
		// 生成巷道数组
		let genModelList = []
		// 被拆分的巷道
		let splitModelList = []
		// 生成2节点
		// 连接两巷道
		if (lens !== 1 && lene !== 1) {
			name = `${this.startDrawPoint + ''}-${this.startDrawPoint + 1 + ''}`
			nodeArray = [{
				name: this.startDrawPoint + '',
				position: this.startPoint
			}, {
				name: this.startDrawPoint + 1 + '',
				position: po,
				connectPoint: name
			}]
			this.startDrawPoint = this.startDrawPoint + 2
		}
		// 生成1节点
		if ((lens === 1 && lene === 0) || (lens === 1 && lene === 2)) {
			name = `${this.startDrawModel[0]}-${this.startDrawPoint + ''}`
			nodeArray = [null, {
				name: this.startDrawPoint + '',
				position: po
			}]
			this.startDrawPoint = this.startDrawPoint + 1
		} else if ((lens === 0 && lene === 1) || (lens === 2 && lene === 1)) {
			name = `${this.startDrawPoint + ''}-${this.endDrawModel[0]}`
			nodeArray = [{
				name: this.startDrawPoint + '',
				position: this.startPoint
			}, null]
			this.startDrawPoint = this.startDrawPoint + 1
		}
		// 生成0节点
		if (lens === 1 && lene === 1) {
			name = `${this.startDrawModel[0]}-${this.endDrawModel[0]}`
		}
		// 生成球
		for (let i = 0; i < nodeArray.length; i++) {
			let a = nodeArray[i]
			if (a) {
				this.creatBallsByPoint(a.position, a.name)
			}
		}
		genModelList.push(name)
		// 如果起点处拆分
		if (lens === 2) {
			genModelList.push(`${this.startDrawModel[0]}-${nodeArray[0].name}`)
			genModelList.push(`${nodeArray[0].name}-${this.startDrawModel[1]}`)
			splitModelList.push(`${this.startDrawModel[0]}-${this.startDrawModel[1]}`)
		}
		// 如果结尾处拆分
		if (lene === 2) {
			genModelList.push(`${this.endDrawModel[0]}-${nodeArray[1].name}`)
			genModelList.push(`${nodeArray[1].name}-${this.endDrawModel[1]}`)
			splitModelList.push(`${this.endDrawModel[0]}-${this.endDrawModel[1]}`)
		}
		this.deletePicSprite(this.cylinder)
		let tMaterial = this.removeSkycheck(splitModelList)
		nextTick(() => {
			this.connectBall(genModelList, tMaterial)
		})
		this.cylinder = null
		this.startPoint = new Vector3(0, 0, 0)
		// 起始绘制模型
		this.startDrawModel = []
		// 终止绘制模型
		this.endDrawModel = []
		return [genModelList, splitModelList]
	}
	// 删除初始巷道
	clearCylinder () {
		if (this.cylinder) {
			this.deletePicSprite(this.cylinder)
			nextTick(() => {
				this.cylinder = null
				this.startPoint = new Vector3(0, 0, 0)
				// 起始绘制模型
				this.startDrawModel = []
				// 终止绘制模型
				this.endDrawModel = []
			})
		}
	}
	// 按名称删除巷道
	removeModelByNames (name) {
		this.removeSkycheck([name])
	}
	/**
	 * 连接球
	 * @param {Object} names
	 * @param material
	 */
	connectBall (names, material) {
		let sumPoint = []
		for (let i = 0; i < names.length; i++) {
			let conts = names[i].split('-')
			let points = []
			points = this.object.children.filter(obj => {
				return obj.isMesh && (obj.name === conts[0] || obj.name === conts[1])
			})
			sumPoint.push(points)
		}
		for (let i = 0; i < sumPoint.length; i++) {
			this.addSkycheck(sumPoint[i][0].position, sumPoint[i][1].position, names[i], material ? material : this.material)
		}
	}
	removeGeoModel (removeObj) {
		// 查询与选中模型连接的球
		let names = removeObj.name.split('-')
		// 一球
		let firstPoint = null
		// 二球
		let secondPoint = null
		// 与球连接的巷道条数
		let leftPoint = []
		let rightPoint = []
		// 判断是否是巷道
		if (names.length > 1) {
			this.object.traverse((child) => {
				if (child.isMesh) {
					if (child.name === `${names[0] + ''}`) {
						firstPoint = child
					}
					if (child.name === `${names[1] + ''}`) {
						secondPoint = child
					}
					if ((child.name.indexOf(`-${names[0] + ''}`) !== -1) || (child.name.indexOf(`${names[0] + ''}-`) !== -1)) {
						leftPoint.push(child)
					}
					if ((child.name.indexOf(`-${names[1] + ''}`) !== -1) || (child.name.indexOf(`${names[1] + ''}-`) !== -1)) {
						rightPoint.push(child)
					}
				}
			})
			// 移除选中模型
			this.deletePicSprite(removeObj)
		} else {
			// 是否删除
			let tt = this.object.children.find(child => {
				return child.isMesh && ((child.name.indexOf(`-${removeObj.name + ''}`) !== -1) || (child.name.indexOf(`${removeObj.name + ''}-`) !== -1))
			})
			if (!tt) {
				// 移除选中模型
				this.deletePicSprite(removeObj)
			}
		}
		if (firstPoint && leftPoint && leftPoint.length < 2) {
			this.deletePicSprite(firstPoint)
		}
		if (secondPoint && rightPoint && rightPoint.length < 2) {
			this.deletePicSprite(secondPoint)
		}
	}
	/**
	 * 初始化模型数据
	 */
	initGLB () {
		let pcolor = this.nodeColor
		// 节点球体
		let ballNode = []
		// 巷道信息
		let roadWayList = []
		// 不规则几何体
		let anoGeometryList = []
		this.object.traverse((child) => {
		  if (child.isMesh) {
				// 获取小球
				if (child.material.color && child.material.color.getHexString() === pcolor) {
					ballNode.push({
						name: child.name,
						position: child.position
					})
				}
		  }
		})
		let maxnum = ballNode.filter(i => {
			if (!isNaN(parseInt(i.name))) {
				return i
			}
		}).map(i => {
			return parseInt(i.name)
		})
		this.startDrawPoint = Math.max(...maxnum) + 1
	}
	/**
	 * 添加风门风窗传感器模型
	 * @param {Object} position 点击位置
	 * @param {Object} obj 点击模型
	 * @param {Object} type 模型类型
	 * @param modelMes
	 */
	addSmallModel (position, obj, type, modelMes) {
		let po = this.findCenterByPoint(position, obj)
		this.addMyModel(po, obj, type, modelMes)
	}
	/**
	 * 添加圆柱体
	 * @param {Object} start 开始点
	 * @param {Object} end 结束点
	 * @param name
	 * @param material
	 */
	addSkycheck(start, end, name, material) {
		this.object.add(this.createCylinderByTwoPoints(start, end, name, material))
	}
	createCylinderByTwoPoints(pointX, pointY, name, material) {
		let direction = new Vector3().subVectors(pointY, pointX);
		let orientation = new Matrix4();
		orientation.lookAt(pointX, pointY, new Object3D().up);
		orientation.multiply(
			new Matrix4().set(
				1, 0, 0, 0,
				0, 0, 1, 0,
				0, -1, 0, 0,
				0, 0, 0, 1
			)
		);
		let edgeGeometry = new CylinderGeometry(
			2.5 * this.standSize, 2.5 * this.standSize, direction.length(), 4
		);
		let edge = new Mesh(edgeGeometry, material);
		edge.name = name ? name : 'textcylinder'
		edge.applyMatrix4(orientation)
		//两个点的中心点 position based on midpoints - there may be a better solution than this
		edge.position.x = (pointY.x + pointX.x) / 2;
		edge.position.y = (pointY.y + pointX.y) / 2;
		edge.position.z = (pointY.z + pointX.z) / 2;
		return edge;
	}
	/**
	 * 生成1长度圆柱体
	 * @param {Object} position
	 */
	createUnitCylinder(position) {
		let geometry = new CylinderGeometry( 2.5 * this.standSize, 2.5 * this.standSize,1, 4 );
		geometry.rotateX( Math.PI * 0.5 )
		let material = new MeshBasicMaterial( {color: '#05a110'} )
		let cylinder = new Mesh( geometry, material )
		cylinder.position.set(position.x, position.y, position.z)
		return cylinder
	}
	/**根据三点确定中心点
	 * @param {Object} position 点击位置
	 * @param {Object} obj 点击模型
	 */
	findCenterByPoint (position, obj) {
		let pointsName = obj.name.split('-')
		let points = []
		this.object.traverse((child) => {
		  if (child.isMesh && ((child.name === pointsName[0]) || (child.name === pointsName[1]))) {
				points.push(child.position)
		  }
		})
		let target = new Vector3()
		let clickPoint = new Vector3(position.x, position.y, position.z)
		let line = new Line3(points[0], points[1])
		line.closestPointToPoint(clickPoint, true, target)
		return target
	}
	/**
	 * 根据坐标生成球
	 * @param {Object} position
	 * @param {Object} name
	 */
	creatBallsByPoint (position, name) {
		const geometry = new SphereGeometry(3.5 * this.standSize, 30, 40)
		const material = new MeshPhongMaterial({
			color: `#${this.nodeColor}`,
			shininess: 2
			});
		let ball = new Mesh( geometry, material )
		ball.position.set(position.x, position.y, position.z)
		ball.name = name
		this.object.add(ball)
	}
	/**
	 * 删除巷道及辅助线
	 * @param {Object} names
	 */
	removeSkycheck(names) {
		// 待删除数组
		let removeList = []
		for (let i = 0; i < names.length; i++) {
			let cylinderName = names[i]
			this.object.traverse((obj) => {
	      if (obj.isMesh && obj.name === cylinderName) {
					removeList.push(obj)
	      }
	    })
		}
		let tMaterial = removeList.length > 0 ? removeList[0].material : ''
		for (let i = 0; i < removeList.length; i++) {
			this.object.remove(removeList[i])
			removeList[i].geometry.dispose()
			removeList[i].material.dispose()
		}
		return tMaterial
	}

	addAllWindDir () {
		let roadList = this.object.children.filter(i => {
			return i.isMesh && i.name.split('-').length > 1 && i.name.split('-')[0] !== 'door' && i.name.split('-')[0] !== 'window' && i.name.split('-')[0] !== 'sensor'
		})
		let moveTextures = []
		for (let i = 0; i < roadList.length; i++) {
			let abs = this.addWindDirByCurve(roadList[i])
			let obj = this.getArrows(roadList[i].position)
			moveTextures.push({
				obj: obj,
				curve: abs.curve,
				counter: 0,
				speed: 1 * this.standSize / abs.len,
				up: new Vector3(0, 1, 0),
				axis: new Vector3()
			})
		}
		return moveTextures
	}

	getArrows (position) {
		let loader = new ObjectLoader()
		let myWind = loader.parse(windModel)
		let arrowHelper = myWind.clone()
		arrowHelper.scale.set(1 * this.standSize, 1 * this.standSize, 1 * this.standSize)
		arrowHelper.name = 'wind' + Math.random()
		arrowHelper.position.set(position.x, position.y, position.z)
		this.object.add(arrowHelper)
		return arrowHelper
	}

	addWindDirByCurve (obj) {
		let curveArr  = []
		let objname = obj.name
		let names = objname.split('-')
		let len = 0
		// 取直线连接点
		for (let i = 0; i < names.length; i++) {
			let sObj = null
			this.object.traverse((child) => {
				if (child.isMesh && names[i] === child.name) {
					sObj = child
				}
			})
			curveArr.push(new Vector3(sObj.position.x, sObj.position.y, sObj.position.z))
		}
		for (let i = 0; i < curveArr.length - 1; i++) {
			len += new Point(curveArr[i].x, curveArr[i].y, curveArr[i].z).distance(new Point(curveArr[i + 1].x, curveArr[i + 1].y, curveArr[i + 1].z))
		}
		// 通过类CatmullRomCurve3创建一个3D样条曲线
		let curve = new CatmullRomCurve3(curveArr, false, 'catmullrom', 0)
		return {curve, len}
	}

	addMyModel (position, object, type, modelMes) {
		let loader = new ObjectLoader()
		let myModel = type === '1' ? doorModel : (type === '2' ? windowModel: sensorModel)
		let randomName = type === '1' ? 'door-' : (type === '2' ? 'window-': 'sensor-')

		let myWind = loader.parse(myModel)
		let arrowHelper = myWind.clone()
		arrowHelper.scale.set(1 * this.standSize, 1 * this.standSize, 1 * this.standSize)
		arrowHelper.name = randomName + modelMes.id + '-' + modelMes.code + '-' + modelMes.type + '-' + modelMes.atype

		let pointsName = object.name.split('-')
		let points = []
		this.object.traverse((child) => {
		  if (child.isMesh && ((child.name === pointsName[0]) || (child.name === pointsName[1]))) {
				points.push(child.position)
		  }
		})

		let start = points[0]
		let end = points[1]
		let axis = new Vector3()
		let dir = new Vector3()

		dir.subVectors(start, end)
		let up = new Vector3(0, 1, 0)
		arrowHelper.position.set(position.x, position.y, position.z)
		let tangent = dir.clone().normalize()
		axis.crossVectors(up, tangent).normalize()
		let radians = Math.acos(up.dot(tangent))
		arrowHelper.quaternion.setFromAxisAngle(axis, radians)
		arrowHelper.modelMes = modelMes
		this.object.add(arrowHelper)
	}
}
