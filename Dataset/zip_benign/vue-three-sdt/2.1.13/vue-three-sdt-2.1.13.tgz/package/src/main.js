import modelMinix from './components/vue-3d/model-mixin.vue'
import fileToJson from './components/vue-3d/fileToJson.vue'

const components = [
	modelMinix,
	fileToJson
]

/* eslint-disable no-shadow */
const install = (Vue) => {
  components.forEach(component => {
		Vue.component(component.name, component)
	})
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
	modelMinix,
	fileToJson
}
export {
	modelMinix,
	fileToJson
}