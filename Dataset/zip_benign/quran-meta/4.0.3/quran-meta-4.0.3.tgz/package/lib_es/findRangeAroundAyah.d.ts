import { AyahId, AyahRange } from "./types";
/**
 * Finds the range of ayahs surrounding a given ayah based on specified mode
 * @param ayahId - The unique identifier of the ayah
 * @param mode - The scope for finding the range:
 *   - "juz": Returns range of ayahs in the same juz
 *   - "surah": Returns range of ayahs in the same surah
 *   - "ayah": Returns the single ayah as both start and end of range
 *   - "page": Returns range of ayahs on the same page
 *   - "all": Returns range covering all ayahs (1 to total number of ayahs)
 * @returns An array of two numbers representing the start and end ayah IDs of the range [startAyahId, endAyahId]
 */
export declare function findRangeAroundAyah(ayahId: AyahId, mode: "juz" | "surah" | "ayah" | "page" | "all"): AyahRange;
