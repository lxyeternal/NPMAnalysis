import { SurahList as findSurahByAyahIdModule } from "./lists/surahList.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function findSurahAyahByAyahId(ayaId) {
  checkValidAyahId(ayaId);
  const suraNum = findSurahByAyahIdModule.findIndex((x) => x[0] > ayaId) - 1;
  const ayahNo = ayaId - findSurahByAyahIdModule[suraNum][0] + 1;
  return [suraNum, ayahNo];
}
