import { meta } from "./const.mjs";
import { findJuzByAyahId } from "./findJuzByAyahId.mjs";
import { findPagebyAyahId } from "./findPagebyAyahId.mjs";
import { findSurahByAyahId } from "./findSurahByAyahId.mjs";
import { JuzList } from "./lists/juzList.mjs";
import { PageList } from "./lists/pageList.mjs";
import { SurahList } from "./lists/surahList.mjs";
export function findRangeAroundAyah(ayahId, mode) {
  switch (mode) {
    case "juz": {
      const juz = findJuzByAyahId(ayahId);
      return [JuzList[juz], JuzList[juz + 1] - 1];
    }
    case "surah": {
      const surah = findSurahByAyahId(ayahId);
      return [SurahList[surah][0], SurahList[surah + 1][0] - 1];
    }
    case "ayah": {
      return [ayahId, ayahId];
    }
    case "page": {
      const page = findPagebyAyahId(ayahId);
      return [PageList[page], PageList[page + 1] - 1];
    }
    case "all":
    default:
      return [1, meta.numAyahs];
  }
}
