import { HizbQuarterList } from "./lists/hizbList.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function findRubAlHizbByAyahId(ayahId) {
  checkValidAyahId(ayahId);
  return HizbQuarterList.findIndex((x) => x > ayahId) - 1;
}
