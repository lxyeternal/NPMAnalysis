import { AyahNo, AyahRange, Surah } from "./types";
/**
 * Finds a range of ayahs around a given ayah based on the specified mode.
 *
 * @param surah - The surah number (1-114)
 * @param ayah - The ayah number within the surah
 * @param mode - The range mode: "juz", "surah", "ayah", "page", or "all"
 * @returns A tuple containing the start and end ayah IDs of the range
 */
export declare function findRangeAroundSurahAyah(surah: Surah, ayah: AyahNo, mode: "juz" | "surah" | "ayah" | "page" | "all"): AyahRange;
