import { AyahNo, Juz, Surah } from "./types";
/**
 * Determines if a given Surah and Ayah combination marks the beginning of a Juz.
 *
 * @param surah - The Surah number to check
 * @param ayah - The Ayah number within the Surah to check
 * @returns The Juz number if the combination marks the start of a Juz, -1 otherwise
 * @throws Error When the provided Surah number is invalid
 *
 * @example
 * ```typescript
 * isSurahAyahJuzFirst(2, 142) // Returns 2
 * isSurahAyahJuzFirst(2, 143) // Returns -1
 * ```
 */
export declare function isSurahAyahJuzFirst(surah: Surah, ayah: AyahNo): Juz | number;
