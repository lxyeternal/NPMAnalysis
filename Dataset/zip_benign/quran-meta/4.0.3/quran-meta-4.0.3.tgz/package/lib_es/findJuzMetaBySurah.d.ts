import { AyahNo, SurahJuzMeta as SurahJuzMeta, Surah } from "./types";
/**
 * Finds the SurahJuzMeta for a given Surah and Ayah.
 *
 * @param surah - The Surah (chapter) number.
 * @param ayah - The Ayah (verse) number.
 * @returns The SurahJuzMeta object containing the left juz, ayahs between juz and surah, right juz, ayah ID of first ayah in left juz, and last ayah ID of right juz .
 */
export declare function findJuzMetaBySurah(surah: Surah, ayah?: AyahNo): SurahJuzMeta;
