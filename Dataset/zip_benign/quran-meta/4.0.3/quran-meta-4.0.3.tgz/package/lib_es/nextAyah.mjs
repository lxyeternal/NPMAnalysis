import { meta } from "./const.mjs";
import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { findSurahAyahByAyahId } from "./findSurahAyahByAyahId.mjs";
export function nextAyah(surah, ayah) {
  if (surah < 1 || surah > meta.numSurahs)
    throw new RangeError("Surah must be between 1 and " + meta.numSurahs);
  const ayahId = findAyahIdBySurah(surah, ayah);
  return findSurahAyahByAyahId(ayahId == meta.numAyahs ? 1 : ayahId + 1);
}
