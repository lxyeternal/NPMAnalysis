import { findSurahAyahByAyahId } from "./findSurahAyahByAyahId.mjs";
import { PageList } from "./lists/pageList.mjs";
import { checkValidPage } from "./validation.mjs";
export function getPageMeta(pageNum) {
  checkValidPage(pageNum);
  const [curPage, nextPage] = [
    PageList[pageNum],
    PageList[pageNum + 1]
  ];
  return {
    pageNum,
    first: findSurahAyahByAyahId(curPage),
    last: findSurahAyahByAyahId(nextPage - 1)
  };
}
