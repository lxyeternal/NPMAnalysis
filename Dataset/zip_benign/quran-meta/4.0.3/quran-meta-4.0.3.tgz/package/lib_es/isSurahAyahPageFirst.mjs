import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { PageList } from "./lists/pageList.mjs";
import { binarySearch } from "./utils.mjs";
import { checkValidSurah } from "./validation.mjs";
export function isSurahAyahPageFirst(surah, ayah) {
  checkValidSurah(surah);
  const ayahId = findAyahIdBySurah(surah, ayah);
  return binarySearch(PageList, ayahId);
}
