export declare const meta: {
    readonly numAyahs: 6236;
    readonly numSurahs: 114;
    readonly numPages: 604;
    readonly numJuzs: 30;
    readonly numHizbs: 60;
    readonly numRubAlHizbs: 240;
    readonly numRubsInJuz: 8;
    readonly numSajdas: 15;
    readonly numRukus: 556;
    readonly numManzils: 7;
};
/**
 * The maximum number of ayahs (verses) that can exist in any surah (chapter) of the Quran.
 * This maximum occurs in Surah Al-Baqarah (2), which has 286 ayahs.
 */
export declare const maxAyahsInSurah = 286;
/**
 * Represents the type derived from the `meta` constant containing Quranic metadata.
 * This type encompasses the structure and properties of Quranic information.
 */
export type QuranMeta = typeof meta;
