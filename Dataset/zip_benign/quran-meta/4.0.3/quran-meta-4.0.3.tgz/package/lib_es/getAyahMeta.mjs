import { findPagebyAyahId } from "./findPagebyAyahId.mjs";
import { findSurahAyahByAyahId } from "./findSurahAyahByAyahId.mjs";
import { getRubAlHizbMetaByAyahId } from "./getRubAlHizbMetaByAyahId.mjs";
import { HizbQuarterList } from "./lists/hizbList.mjs";
import { JuzList } from "./lists/juzList.mjs";
import { PageList } from "./lists/pageList.mjs";
import { SajdaList } from "./lists/sajdaList.mjs";
import { SurahList } from "./lists/surahList.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function getAyahMeta(ayahId) {
  checkValidAyahId(ayahId);
  const quarterData = getRubAlHizbMetaByAyahId(ayahId);
  const [surah, ayah] = findSurahAyahByAyahId(ayahId);
  const page = findPagebyAyahId(ayahId);
  const isSajdahAyah = SajdaList.some(([sajdaAyahId]) => sajdaAyahId === ayahId);
  const isStartOfSurah = SurahList[surah][0] === ayahId;
  const isStartOfPage = PageList[page] === ayahId;
  const isStartOfJuz = JuzList[quarterData.juz] === ayahId;
  const isStartOfQuarter = HizbQuarterList[quarterData.rubAlHizbId] === ayahId;
  const isEndOfSurah = SurahList[surah + 1][0] - 1 === ayahId;
  const isEndOfPage = PageList[page + 1] - 1 === ayahId;
  const isEndOfJuz = JuzList[quarterData.juz + 1] - 1 === ayahId;
  const isEndOfQuarter = HizbQuarterList[quarterData.rubAlHizbId + 1] - 1 === ayahId;
  return {
    ...quarterData,
    surah,
    ayah,
    isStartOfQuarter,
    isEndOfQuarter,
    isSajdahAyah,
    isStartOfPage,
    isEndOfPage,
    isStartOfJuz,
    isEndOfJuz,
    isStartOfSurah,
    isEndOfSurah
  };
}
