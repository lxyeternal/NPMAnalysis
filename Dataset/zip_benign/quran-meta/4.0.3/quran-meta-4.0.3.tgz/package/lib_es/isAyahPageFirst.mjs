import { PageList } from "./lists/pageList.mjs";
import { binarySearch } from "./utils.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function isAyahPageFirst(ayahId) {
  checkValidAyahId(ayahId);
  return binarySearch(PageList, ayahId);
}
