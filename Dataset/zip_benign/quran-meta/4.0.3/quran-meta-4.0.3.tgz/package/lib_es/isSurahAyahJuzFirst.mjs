import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { JuzList } from "./lists/juzList.mjs";
import { binarySearch } from "./utils.mjs";
import { checkValidSurah } from "./validation.mjs";
export function isSurahAyahJuzFirst(surah, ayah) {
  checkValidSurah(surah);
  const ayahId = findAyahIdBySurah(surah, ayah);
  return binarySearch(JuzList, ayahId);
}
