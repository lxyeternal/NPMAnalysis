import { getSurahMeta } from "./getSurahMeta.mjs";
export function getAyahCountInSurah(surah) {
  return getSurahMeta(surah)[1];
}
