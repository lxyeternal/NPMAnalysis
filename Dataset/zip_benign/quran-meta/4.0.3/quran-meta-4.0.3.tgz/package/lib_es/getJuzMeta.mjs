import { findSurahAyahByAyahId } from "./findSurahAyahByAyahId.mjs";
import { JuzList } from "./lists/juzList.mjs";
import { checkValidJuz } from "./validation.mjs";
export function getJuzMeta(juzNum) {
  checkValidJuz(juzNum);
  const [curJuzAyahId, nextJuzAyahId] = [
    JuzList[juzNum],
    JuzList[juzNum + 1]
  ];
  return {
    juzNum,
    first: findSurahAyahByAyahId(curJuzAyahId),
    last: findSurahAyahByAyahId(nextJuzAyahId - 1)
  };
}
