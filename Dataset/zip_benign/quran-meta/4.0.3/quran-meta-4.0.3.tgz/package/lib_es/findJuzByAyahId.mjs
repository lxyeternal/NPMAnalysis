import { JuzList } from "./lists/juzList.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function findJuzByAyahId(ayahId) {
  checkValidAyahId(ayahId);
  const juz = JuzList.findIndex((x) => x > ayahId) - 1;
  return juz;
}
