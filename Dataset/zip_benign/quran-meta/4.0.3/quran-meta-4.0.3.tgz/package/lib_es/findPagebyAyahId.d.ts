import { AyahId, Page } from "./types";
/**
 * Returns the page number for a given ayah ID in the Quran.
 *
 * @param ayahId - A numeric identifier representing a verse (ayah) in the Quran
 * @returns The page number where the specified ayah can be found
 * @throws Will throw an error if the ayahId is invalid
 *
 * @example
 * ```ts
 * const page = findPagebyAyahId(142); // Returns the page number containing ayah 142
 * ```
 */
export declare function findPagebyAyahId(ayahId: AyahId): Page;
