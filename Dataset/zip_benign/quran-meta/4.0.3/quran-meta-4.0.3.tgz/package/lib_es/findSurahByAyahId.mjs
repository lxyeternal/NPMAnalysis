import { findSurahAyahByAyahId } from "./findSurahAyahByAyahId.mjs";
export function findSurahByAyahId(ayaId) {
  return findSurahAyahByAyahId(ayaId)[0];
}
