export function getRubAlHizbMeta(quarterIndex) {
  const juz = Math.floor((quarterIndex - 1) / 8) + 1;
  const hizbIndex = Math.floor((quarterIndex - 1) / 4) + 1;
  const juzPart = quarterIndex % 8 || 8;
  return { juz, hizbId: hizbIndex, juzPart, rubAlHizbId: quarterIndex };
}
