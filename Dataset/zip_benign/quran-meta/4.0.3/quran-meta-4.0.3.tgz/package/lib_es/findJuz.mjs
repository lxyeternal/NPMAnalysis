import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { findJuzByAyahId } from "./findJuzByAyahId.mjs";
export function findJuz(surah, ayah = 1) {
  const ayahId = findAyahIdBySurah(surah, ayah);
  return findJuzByAyahId(ayahId);
}
