import { meta } from "./const.mjs";
import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { findSurahAyahByAyahId } from "./findSurahAyahByAyahId.mjs";
import { checkValidSurah } from "./validation.mjs";
export function prevAyah(surah, ayah) {
  checkValidSurah(surah);
  const ayahId = findAyahIdBySurah(surah, ayah);
  return findSurahAyahByAyahId(ayahId == 1 ? meta.numAyahs : ayahId - 1);
}
