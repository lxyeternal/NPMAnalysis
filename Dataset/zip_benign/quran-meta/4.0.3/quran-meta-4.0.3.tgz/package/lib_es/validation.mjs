import { meta } from "./const.mjs";
import { getAyahCountInSurah } from "./getAyahCountInSurah.mjs";
import { isValidAyahId, isValidJuz, isValidPage, isValidSurah } from "./typeGuards.mjs";
export function checkValidSurah(surah) {
  if (typeof surah !== "number" || !Number.isInteger(surah)) {
    throw new TypeError("Ayah ID must be an integer");
  }
  if (!isValidSurah(surah)) {
    throw new RangeError("Surah must be between 1 and " + meta.numSurahs);
  }
}
export function checkValidSurahAyah(surah, ayah) {
  checkValidSurahAyahPair([surah, ayah]);
}
export function checkValidSurahAyahPair(surahAyah) {
  const [surah, ayah] = surahAyah;
  checkValidSurah(surah);
  if (typeof ayah !== "number" || !Number.isInteger(ayah) || ayah < 1 || ayah > getAyahCountInSurah(surah)) {
    throw new RangeError("Ayah must be between 1 and " + getAyahCountInSurah(surah));
  }
}
export function checkValidAyahId(ayahId) {
  if (typeof ayahId !== "number" || !Number.isInteger(ayahId)) {
    throw new TypeError("Ayah ID must be an integer");
  }
  if (!isValidAyahId(ayahId)) {
    throw new RangeError("Ayah ID must be between 1 and " + meta.numAyahs);
  }
}
export function checkValidPage(x) {
  if (typeof x !== "number" || !Number.isInteger(x)) {
    throw new TypeError("Page must be an integer");
  }
  if (!isValidPage(x)) {
    throw new RangeError("Page must be between 1 and " + meta.numPages);
  }
}
export function checkValidJuz(x) {
  if (typeof x !== "number" || !Number.isInteger(x)) {
    throw new TypeError("Juz must be an integer");
  }
  if (!isValidJuz(x)) {
    throw new RangeError("Juz must be between 1 and " + meta.numJuzs);
  }
}
