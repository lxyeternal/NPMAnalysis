import { AyahId, AyahNo, SurahMeta } from "./types";
export declare const partNames: readonly ["surah", "juz", "page", "manzil", "rubAlHizb", "ruku"];
export type PartType = (typeof partNames)[number];
/**
 * An object that maps part types to their corresponding data lists.
 */
export declare const parts: {
    readonly surah: SurahMeta[];
    readonly juz: number[];
    readonly rubAlHizb: number[];
    readonly page: number[];
    readonly manzil: number[];
    readonly ruku: number[];
};
/**
 * Represents a block or section of the Quran with its starting ayah and length
 * startAyahId - The identifier of the first ayah in the block
 * ayahCount - The number of ayahs contained in this block
 */
type PartBlock = {
    startAyahId: AyahId;
    ayahCount: AyahId | AyahNo;
};
/**
 * Retrieves a formatted list of Quran parts based on the specified type.
 * @param type - The type of parts to retrieve (e.g., juz, hizb, rub)
 * @returns An array of formatted part blocks, excluding the first and last elements
 */
export declare function getList(type: PartType): PartBlock[];
export {};
