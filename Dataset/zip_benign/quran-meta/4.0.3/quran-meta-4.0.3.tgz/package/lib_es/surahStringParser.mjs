import { isValidSurah } from "./typeGuards.mjs";
export function surahStringParser(str, isStrict = false) {
  const surahX = isStrict ? Number(str.trim()) : Number.parseInt(str.trim(), 10);
  if (isNaN(surahX)) {
    throw new Error("Error in surah format " + str);
  }
  if (!isValidSurah(surahX)) {
    throw new Error("Error in surah number " + str);
  }
  return surahX;
}
