import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { findRangeAroundAyah } from "./findRangeAroundAyah.mjs";
import { SurahList } from "./lists/surahList.mjs";
import { checkValidSurah } from "./validation.mjs";
export function findRangeAroundSurahAyah(surah, ayah, mode) {
  checkValidSurah(surah);
  if (mode === "surah") {
    return [SurahList[surah][0], SurahList[surah + 1][0] - 1];
  }
  const ayahId = findAyahIdBySurah(surah, ayah);
  return findRangeAroundAyah(ayahId, mode);
}
