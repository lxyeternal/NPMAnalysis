import { JuzList } from "./lists/juzList.mjs";
import { binarySearch } from "./utils.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function isAyahJuzFirst(ayahId) {
  checkValidAyahId(ayahId);
  return binarySearch(JuzList, ayahId);
}
