import { SurahMeta } from "../types";
export declare const SurahList: SurahMeta[];
