import { AyahId, Juz } from "./types";
/**
 * Returns the Juz (part) number that the given Ayah (verse) belongs to.
 *
 *
 * @param ayahId - The Ayah Id (verse) number.
 * @returns The Juz (part) number that the given Ayah belongs to. Returns Positive number if ayah is first ayah of juz, number is juz number
 */
export declare function isAyahJuzFirst(ayahId: AyahId): Juz | number;
