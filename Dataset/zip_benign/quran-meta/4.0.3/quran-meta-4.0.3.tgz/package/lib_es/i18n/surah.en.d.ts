import { SurahName } from "../types";
export declare const surahNamesEn: (SurahName | [])[];
