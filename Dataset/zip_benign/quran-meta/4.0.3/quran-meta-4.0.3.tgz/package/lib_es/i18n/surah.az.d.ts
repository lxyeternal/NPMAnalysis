import { SurahName } from "../types";
export declare const surahNamesAz: (SurahName | [])[];
