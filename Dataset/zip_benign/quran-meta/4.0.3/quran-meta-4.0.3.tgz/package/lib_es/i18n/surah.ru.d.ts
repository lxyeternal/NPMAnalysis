import { SurahName } from "../types";
export declare const surahNamesRu: (SurahName | [])[];
