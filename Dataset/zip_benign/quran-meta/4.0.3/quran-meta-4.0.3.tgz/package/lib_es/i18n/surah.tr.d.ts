import { SurahName } from "../types";
export declare const surahNamesTr: (SurahName | [])[];
