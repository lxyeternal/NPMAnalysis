import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { findJuzByAyahId } from "./findJuzByAyahId.mjs";
import { findSurahByAyahId } from "./findSurahByAyahId.mjs";
import { JuzList } from "./lists/juzList.mjs";
import { SurahList } from "./lists/surahList.mjs";
import { checkValidAyahId, checkValidSurah } from "./validation.mjs";
export function findJuzAndShift(surah, ayah) {
  checkValidSurah(surah);
  const ayahId = findAyahIdBySurah(surah, ayah);
  const juz = findJuzByAyahId(ayahId);
  const juzLeftAyahId = JuzList[juz];
  const [surahStartAyahId] = SurahList[surah];
  return {
    juz,
    ayahsBetweenJuzSurah: surahStartAyahId - juzLeftAyahId,
    leftAyahId: juzLeftAyahId
  };
}
export function findJuzAndShiftByAyahId(ayahId) {
  checkValidAyahId(ayahId);
  const juz = findJuzByAyahId(ayahId);
  const leftAyahId = JuzList[juz];
  const surah = findSurahByAyahId(ayahId);
  const [surahStartAyahId] = SurahList[surah];
  return {
    juz,
    ayahsBetweenJuzSurah: surahStartAyahId - leftAyahId,
    leftAyahId
  };
}
