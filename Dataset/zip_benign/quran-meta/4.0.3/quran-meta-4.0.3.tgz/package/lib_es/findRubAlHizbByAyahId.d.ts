import { AyahId, RubAlHizbId } from "./types";
/**
 * Finds the Maqra/Rub-al-Hizb  of the Quran that contains the given Ayah (verse) ID.
 *
 * @param ayahId - The ID of the Ayah (verse) to find the Juz for.
 * @returns The Maqra of the Quran that contains the given Ayah ID.
 */
export declare function findRubAlHizbByAyahId(ayahId: AyahId): RubAlHizbId;
