import { PageList } from "./lists/pageList.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function findPagebyAyahId(ayahId) {
  checkValidAyahId(ayahId);
  return PageList.findIndex((x) => x > ayahId) - 1;
}
