import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { PageList } from "./lists/pageList.mjs";
import { checkValidSurah } from "./validation.mjs";
export function findPage(surah, ayah) {
  checkValidSurah(surah);
  const ayahId = findAyahIdBySurah(surah, ayah);
  return PageList.findIndex((x) => x > ayahId) - 1;
}
