import { maxAyahsInSurah, meta } from "./const.mjs";
import { getAyahCountInSurah } from "./getAyahCountInSurah.mjs";
export function isValidAyahId(x) {
  return Number.isInteger(x) && 1 <= x && x <= meta.numAyahs;
}
export function isValidAyahNo(x) {
  return Number.isInteger(x) && 1 <= x && x <= maxAyahsInSurah;
}
export function isValidSurah(x) {
  return Number.isInteger(x) && 1 <= x && x <= meta.numSurahs;
}
export function isValidSurahAyah(x) {
  const [surah, ayah] = x;
  if (!isValidSurah(surah)) {
    return false;
  }
  return Number.isInteger(ayah) && ayah >= 1 && ayah <= getAyahCountInSurah(surah);
}
export function isValidJuz(x) {
  return Number.isInteger(x) && 1 <= x && x <= meta.numJuzs;
}
export function isValidHizb(x) {
  return Number.isInteger(x) && 1 <= x && x <= meta.numHizbs;
}
export function isValidRubAlHizb(x) {
  return Number.isInteger(x) && 1 <= x && x <= meta.numRubAlHizbs;
}
export function isValidPage(x) {
  return Number.isInteger(x) && 1 <= x && x <= meta.numPages;
}
