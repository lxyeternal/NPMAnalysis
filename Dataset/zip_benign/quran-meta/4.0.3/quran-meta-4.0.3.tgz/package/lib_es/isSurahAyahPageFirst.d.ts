import { AyahNo, Page, Surah } from "./types";
/**
 * Determines if an ayah is the first ayah on its page in the Quran
 * @param surah - The surah number (1-114)
 * @param ayah - The ayah number within the surah
 * @returns The page number if the ayah is first on its page, -1 otherwise
 * @throws Error If surah number is invalid
 */
export declare function isSurahAyahPageFirst(surah: Surah, ayah: AyahNo): Page | number;
