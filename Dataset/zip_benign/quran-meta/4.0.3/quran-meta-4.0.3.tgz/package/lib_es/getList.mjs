import { HizbQuarterList } from "./lists/hizbList.mjs";
import { JuzList } from "./lists/juzList.mjs";
import { ManzilList } from "./lists/manzilList.mjs";
import { PageList } from "./lists/pageList.mjs";
import { RukuList } from "./lists/rukuList.mjs";
import { SurahList } from "./lists/surahList.mjs";
export const partNames = ["surah", "juz", "page", "manzil", "rubAlHizb", "ruku"];
export const parts = {
  surah: SurahList,
  juz: JuzList,
  rubAlHizb: HizbQuarterList,
  page: PageList,
  manzil: ManzilList,
  ruku: RukuList
};
function toPartFormatter(type) {
  return type === "surah" ? ([startAyahId, ayahCount]) => ({
    startAyahId,
    ayahCount
  }) : (ayahId, index) => {
    const ayahCount = parts[type][index + 2] - ayahId;
    return {
      startAyahId: ayahId,
      ayahCount
    };
  };
}
export function getList(type) {
  const list = parts[type];
  return list.slice(1, list.length - 1).map(toPartFormatter(type));
}
