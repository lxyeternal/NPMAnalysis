import { findAyahIdBySurah } from "./findAyahIdBySurah.mjs";
import { findRubAlHizbByAyahId } from "./findRubAlHizbByAyahId.mjs";
import { checkValidSurah } from "./validation.mjs";
export function findRubAlHizb(surah, ayah = 1) {
  checkValidSurah(surah);
  const ayahId = findAyahIdBySurah(surah, ayah);
  return findRubAlHizbByAyahId(ayahId);
}
