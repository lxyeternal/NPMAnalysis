import { AyahId, JuzHizb } from "./types";
/**
 * Finds the Juz, Hizb, and Rub-el-Hizb id for the given Ayah ID.
 *
 * @param ayahId - The Ayah ID to find the Juz, Hizb, and Hizb ID for.
 * @returns An object containing the Juz, Hizb, and Hizb ID for the given Ayah ID.
 */
export declare function getRubAlHizbMetaByAyahId(ayahId: AyahId): JuzHizb;
