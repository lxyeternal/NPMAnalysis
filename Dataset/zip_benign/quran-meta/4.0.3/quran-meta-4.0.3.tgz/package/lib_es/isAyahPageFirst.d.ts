import { AyahId, Page } from "./types";
/**
 * Determines if the given ayah is the first ayah of a juz.
 *
 * @param ayahId - The ayah id .
 * @returns The page number if the ayah is the first ayah of the page, otherwise -1.
 */
export declare function isAyahPageFirst(ayahId: AyahId): Page | number;
