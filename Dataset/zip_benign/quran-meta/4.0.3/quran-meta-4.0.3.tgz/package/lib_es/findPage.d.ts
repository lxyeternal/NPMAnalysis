import { AyahId, AyahNo, Page, Surah } from "./types";
/**
 * Finds the page number for the given Surah and Ayah number.
 *
 * @param surah - The Surah to find the page for.
 * @param ayah - The Ayah number to find the page for.
 * @returns The page number for the given Surah and Ayah.
 */
export declare function findPage(surah: Surah, ayah: AyahNo | AyahId): Page;
