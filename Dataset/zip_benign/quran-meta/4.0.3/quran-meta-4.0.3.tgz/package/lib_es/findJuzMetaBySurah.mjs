import { meta } from "./const.mjs";
import { findJuzAndShift } from "./findJuzAndShift.mjs";
import { findSurahByAyahId } from "./findSurahByAyahId.mjs";
import { JuzList } from "./lists/juzList.mjs";
export function findJuzMetaBySurah(surah, ayah = 1) {
  const {
    juz: leftjuz,
    ayahsBetweenJuzSurah,
    leftAyahId
  } = findJuzAndShift(surah, ayah);
  let rightJuz = leftjuz;
  while (rightJuz < meta.numJuzs && findSurahByAyahId(JuzList[rightJuz + 1]) === surah) {
    rightJuz++;
  }
  return {
    leftjuz,
    ayahsBetweenJuzSurah,
    rightJuz,
    leftAyahId,
    rightAyahId: JuzList[rightJuz + 1]
    // todo check if this is correct or should be -1
  };
}
