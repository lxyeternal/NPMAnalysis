import { findRubAlHizbByAyahId } from "./findRubAlHizbByAyahId.mjs";
import { getRubAlHizbMeta } from "./getRubAlHizbMeta.mjs";
import { checkValidAyahId } from "./validation.mjs";
export function getRubAlHizbMetaByAyahId(ayahId) {
  checkValidAyahId(ayahId);
  const quarterIndex = findRubAlHizbByAyahId(ayahId);
  return getRubAlHizbMeta(quarterIndex);
}
