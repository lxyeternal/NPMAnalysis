"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.checkValidAyahId = checkValidAyahId;
exports.checkValidJuz = checkValidJuz;
exports.checkValidPage = checkValidPage;
exports.checkValidSurah = checkValidSurah;
exports.checkValidSurahAyah = checkValidSurahAyah;
exports.checkValidSurahAyahPair = checkValidSurahAyahPair;
var _const = require("./const.cjs");
var _getAyahCountInSurah = require("./getAyahCountInSurah.cjs");
var _typeGuards = require("./typeGuards.cjs");
function checkValidSurah(surah) {
  if (typeof surah !== "number" || !Number.isInteger(surah)) {
    throw new TypeError("Ayah ID must be an integer");
  }
  if (!(0, _typeGuards.isValidSurah)(surah)) {
    throw new RangeError("Surah must be between 1 and " + _const.meta.numSurahs);
  }
}
function checkValidSurahAyah(surah, ayah) {
  checkValidSurahAyahPair([surah, ayah]);
}
function checkValidSurahAyahPair(surahAyah) {
  const [surah, ayah] = surahAyah;
  checkValidSurah(surah);
  if (typeof ayah !== "number" || !Number.isInteger(ayah) || ayah < 1 || ayah > (0, _getAyahCountInSurah.getAyahCountInSurah)(surah)) {
    throw new RangeError("Ayah must be between 1 and " + (0, _getAyahCountInSurah.getAyahCountInSurah)(surah));
  }
}
function checkValidAyahId(ayahId) {
  if (typeof ayahId !== "number" || !Number.isInteger(ayahId)) {
    throw new TypeError("Ayah ID must be an integer");
  }
  if (!(0, _typeGuards.isValidAyahId)(ayahId)) {
    throw new RangeError("Ayah ID must be between 1 and " + _const.meta.numAyahs);
  }
}
function checkValidPage(x) {
  if (typeof x !== "number" || !Number.isInteger(x)) {
    throw new TypeError("Page must be an integer");
  }
  if (!(0, _typeGuards.isValidPage)(x)) {
    throw new RangeError("Page must be between 1 and " + _const.meta.numPages);
  }
}
function checkValidJuz(x) {
  if (typeof x !== "number" || !Number.isInteger(x)) {
    throw new TypeError("Juz must be an integer");
  }
  if (!(0, _typeGuards.isValidJuz)(x)) {
    throw new RangeError("Juz must be between 1 and " + _const.meta.numJuzs);
  }
}