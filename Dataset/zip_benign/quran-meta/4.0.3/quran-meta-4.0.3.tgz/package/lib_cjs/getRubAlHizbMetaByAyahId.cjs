"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getRubAlHizbMetaByAyahId = getRubAlHizbMetaByAyahId;
var _findRubAlHizbByAyahId = require("./findRubAlHizbByAyahId.cjs");
var _getRubAlHizbMeta = require("./getRubAlHizbMeta.cjs");
var _validation = require("./validation.cjs");
function getRubAlHizbMetaByAyahId(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  const quarterIndex = (0, _findRubAlHizbByAyahId.findRubAlHizbByAyahId)(ayahId);
  return (0, _getRubAlHizbMeta.getRubAlHizbMeta)(quarterIndex);
}