"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isAyahJuzFirst = isAyahJuzFirst;
var _juzList = require("./lists/juzList.cjs");
var _utils = require("./utils.cjs");
var _validation = require("./validation.cjs");
function isAyahJuzFirst(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  return (0, _utils.binarySearch)(_juzList.JuzList, ayahId);
}