"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findRangeAroundAyah = findRangeAroundAyah;
var _const = require("./const.cjs");
var _findJuzByAyahId = require("./findJuzByAyahId.cjs");
var _findPagebyAyahId = require("./findPagebyAyahId.cjs");
var _findSurahByAyahId = require("./findSurahByAyahId.cjs");
var _juzList = require("./lists/juzList.cjs");
var _pageList = require("./lists/pageList.cjs");
var _surahList = require("./lists/surahList.cjs");
function findRangeAroundAyah(ayahId, mode) {
  switch (mode) {
    case "juz":
      {
        const juz = (0, _findJuzByAyahId.findJuzByAyahId)(ayahId);
        return [_juzList.JuzList[juz], _juzList.JuzList[juz + 1] - 1];
      }
    case "surah":
      {
        const surah = (0, _findSurahByAyahId.findSurahByAyahId)(ayahId);
        return [_surahList.SurahList[surah][0], _surahList.SurahList[surah + 1][0] - 1];
      }
    case "ayah":
      {
        return [ayahId, ayahId];
      }
    case "page":
      {
        const page = (0, _findPagebyAyahId.findPagebyAyahId)(ayahId);
        return [_pageList.PageList[page], _pageList.PageList[page + 1] - 1];
      }
    case "all":
    default:
      return [1, _const.meta.numAyahs];
  }
}