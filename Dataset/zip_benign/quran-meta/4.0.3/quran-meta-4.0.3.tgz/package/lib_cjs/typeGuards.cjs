"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isValidAyahId = isValidAyahId;
exports.isValidAyahNo = isValidAyahNo;
exports.isValidHizb = isValidHizb;
exports.isValidJuz = isValidJuz;
exports.isValidPage = isValidPage;
exports.isValidRubAlHizb = isValidRubAlHizb;
exports.isValidSurah = isValidSurah;
exports.isValidSurahAyah = isValidSurahAyah;
var _const = require("./const.cjs");
var _getAyahCountInSurah = require("./getAyahCountInSurah.cjs");
function isValidAyahId(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.meta.numAyahs;
}
function isValidAyahNo(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.maxAyahsInSurah;
}
function isValidSurah(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.meta.numSurahs;
}
function isValidSurahAyah(x) {
  const [surah, ayah] = x;
  if (!isValidSurah(surah)) {
    return false;
  }
  return Number.isInteger(ayah) && ayah >= 1 && ayah <= (0, _getAyahCountInSurah.getAyahCountInSurah)(surah);
}
function isValidJuz(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.meta.numJuzs;
}
function isValidHizb(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.meta.numHizbs;
}
function isValidRubAlHizb(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.meta.numRubAlHizbs;
}
function isValidPage(x) {
  return Number.isInteger(x) && 1 <= x && x <= _const.meta.numPages;
}