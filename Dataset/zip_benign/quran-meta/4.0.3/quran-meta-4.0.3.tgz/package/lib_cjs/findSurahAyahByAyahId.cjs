"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findSurahAyahByAyahId = findSurahAyahByAyahId;
var _surahList = require("./lists/surahList.cjs");
var _validation = require("./validation.cjs");
function findSurahAyahByAyahId(ayaId) {
  (0, _validation.checkValidAyahId)(ayaId);
  const suraNum = _surahList.SurahList.findIndex(x => x[0] > ayaId) - 1;
  const ayahNo = ayaId - _surahList.SurahList[suraNum][0] + 1;
  return [suraNum, ayahNo];
}