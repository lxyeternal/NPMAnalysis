"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.prevAyah = prevAyah;
var _const = require("./const.cjs");
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
var _validation = require("./validation.cjs");
function prevAyah(surah, ayah) {
  (0, _validation.checkValidSurah)(surah);
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(ayahId == 1 ? _const.meta.numAyahs : ayahId - 1);
}