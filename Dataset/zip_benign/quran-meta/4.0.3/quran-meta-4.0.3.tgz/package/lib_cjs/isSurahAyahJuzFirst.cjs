"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isSurahAyahJuzFirst = isSurahAyahJuzFirst;
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _juzList = require("./lists/juzList.cjs");
var _utils = require("./utils.cjs");
var _validation = require("./validation.cjs");
function isSurahAyahJuzFirst(surah, ayah) {
  (0, _validation.checkValidSurah)(surah);
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return (0, _utils.binarySearch)(_juzList.JuzList, ayahId);
}