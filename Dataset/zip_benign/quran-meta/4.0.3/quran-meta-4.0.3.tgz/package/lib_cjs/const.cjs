"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.meta = exports.maxAyahsInSurah = void 0;
const meta = exports.meta = {
  numAyahs: 6236,
  numSurahs: 114,
  numPages: 604,
  numJuzs: 30,
  numHizbs: 60,
  numRubAlHizbs: 240,
  numRubsInJuz: 8,
  numSajdas: 15,
  numRukus: 556,
  numManzils: 7
};
const maxAyahsInSurah = exports.maxAyahsInSurah = 286;