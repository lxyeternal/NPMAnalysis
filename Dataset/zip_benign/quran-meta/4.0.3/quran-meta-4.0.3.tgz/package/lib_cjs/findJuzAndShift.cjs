"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findJuzAndShift = findJuzAndShift;
exports.findJuzAndShiftByAyahId = findJuzAndShiftByAyahId;
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findJuzByAyahId = require("./findJuzByAyahId.cjs");
var _findSurahByAyahId = require("./findSurahByAyahId.cjs");
var _juzList = require("./lists/juzList.cjs");
var _surahList = require("./lists/surahList.cjs");
var _validation = require("./validation.cjs");
function findJuzAndShift(surah, ayah) {
  (0, _validation.checkValidSurah)(surah);
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  const juz = (0, _findJuzByAyahId.findJuzByAyahId)(ayahId);
  const juzLeftAyahId = _juzList.JuzList[juz];
  const [surahStartAyahId] = _surahList.SurahList[surah];
  return {
    juz,
    ayahsBetweenJuzSurah: surahStartAyahId - juzLeftAyahId,
    leftAyahId: juzLeftAyahId
  };
}
function findJuzAndShiftByAyahId(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  const juz = (0, _findJuzByAyahId.findJuzByAyahId)(ayahId);
  const leftAyahId = _juzList.JuzList[juz];
  const surah = (0, _findSurahByAyahId.findSurahByAyahId)(ayahId);
  const [surahStartAyahId] = _surahList.SurahList[surah];
  return {
    juz,
    ayahsBetweenJuzSurah: surahStartAyahId - leftAyahId,
    leftAyahId
  };
}