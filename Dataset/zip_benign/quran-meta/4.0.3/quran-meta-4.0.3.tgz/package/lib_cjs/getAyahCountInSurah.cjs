"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getAyahCountInSurah = getAyahCountInSurah;
var _getSurahMeta = require("./getSurahMeta.cjs");
function getAyahCountInSurah(surah) {
  return (0, _getSurahMeta.getSurahMeta)(surah)[1];
}