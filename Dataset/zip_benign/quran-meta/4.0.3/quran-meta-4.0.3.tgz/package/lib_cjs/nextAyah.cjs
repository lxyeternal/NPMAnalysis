"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.nextAyah = nextAyah;
var _const = require("./const.cjs");
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
function nextAyah(surah, ayah) {
  if (surah < 1 || surah > _const.meta.numSurahs) throw new RangeError("Surah must be between 1 and " + _const.meta.numSurahs);
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(ayahId == _const.meta.numAyahs ? 1 : ayahId + 1);
}