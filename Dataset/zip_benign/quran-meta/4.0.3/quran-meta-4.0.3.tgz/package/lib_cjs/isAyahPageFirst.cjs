"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isAyahPageFirst = isAyahPageFirst;
var _pageList = require("./lists/pageList.cjs");
var _utils = require("./utils.cjs");
var _validation = require("./validation.cjs");
function isAyahPageFirst(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  return (0, _utils.binarySearch)(_pageList.PageList, ayahId);
}