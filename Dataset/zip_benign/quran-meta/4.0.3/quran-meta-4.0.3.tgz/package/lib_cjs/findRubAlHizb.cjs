"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findRubAlHizb = findRubAlHizb;
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findRubAlHizbByAyahId = require("./findRubAlHizbByAyahId.cjs");
var _validation = require("./validation.cjs");
function findRubAlHizb(surah, ayah = 1) {
  (0, _validation.checkValidSurah)(surah);
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return (0, _findRubAlHizbByAyahId.findRubAlHizbByAyahId)(ayahId);
}