"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getAyahMeta = getAyahMeta;
var _findPagebyAyahId = require("./findPagebyAyahId.cjs");
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
var _getRubAlHizbMetaByAyahId = require("./getRubAlHizbMetaByAyahId.cjs");
var _hizbList = require("./lists/hizbList.cjs");
var _juzList = require("./lists/juzList.cjs");
var _pageList = require("./lists/pageList.cjs");
var _sajdaList = require("./lists/sajdaList.cjs");
var _surahList = require("./lists/surahList.cjs");
var _validation = require("./validation.cjs");
function getAyahMeta(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  const quarterData = (0, _getRubAlHizbMetaByAyahId.getRubAlHizbMetaByAyahId)(ayahId);
  const [surah, ayah] = (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(ayahId);
  const page = (0, _findPagebyAyahId.findPagebyAyahId)(ayahId);
  const isSajdahAyah = _sajdaList.SajdaList.some(([sajdaAyahId]) => sajdaAyahId === ayahId);
  const isStartOfSurah = _surahList.SurahList[surah][0] === ayahId;
  const isStartOfPage = _pageList.PageList[page] === ayahId;
  const isStartOfJuz = _juzList.JuzList[quarterData.juz] === ayahId;
  const isStartOfQuarter = _hizbList.HizbQuarterList[quarterData.rubAlHizbId] === ayahId;
  const isEndOfSurah = _surahList.SurahList[surah + 1][0] - 1 === ayahId;
  const isEndOfPage = _pageList.PageList[page + 1] - 1 === ayahId;
  const isEndOfJuz = _juzList.JuzList[quarterData.juz + 1] - 1 === ayahId;
  const isEndOfQuarter = _hizbList.HizbQuarterList[quarterData.rubAlHizbId + 1] - 1 === ayahId;
  return {
    ...quarterData,
    surah,
    ayah,
    isStartOfQuarter,
    isEndOfQuarter,
    isSajdahAyah,
    isStartOfPage,
    isEndOfPage,
    isStartOfJuz,
    isEndOfJuz,
    isStartOfSurah,
    isEndOfSurah
  };
}