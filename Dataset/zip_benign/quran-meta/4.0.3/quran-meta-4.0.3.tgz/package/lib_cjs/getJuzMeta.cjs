"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getJuzMeta = getJuzMeta;
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
var _juzList = require("./lists/juzList.cjs");
var _validation = require("./validation.cjs");
function getJuzMeta(juzNum) {
  (0, _validation.checkValidJuz)(juzNum);
  const [curJuzAyahId, nextJuzAyahId] = [_juzList.JuzList[juzNum], _juzList.JuzList[juzNum + 1]];
  return {
    juzNum,
    first: (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(curJuzAyahId),
    last: (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(nextJuzAyahId - 1)
  };
}