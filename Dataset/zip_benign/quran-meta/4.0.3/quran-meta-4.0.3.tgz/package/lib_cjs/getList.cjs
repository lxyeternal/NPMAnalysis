"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getList = getList;
exports.parts = exports.partNames = void 0;
var _hizbList = require("./lists/hizbList.cjs");
var _juzList = require("./lists/juzList.cjs");
var _manzilList = require("./lists/manzilList.cjs");
var _pageList = require("./lists/pageList.cjs");
var _rukuList = require("./lists/rukuList.cjs");
var _surahList = require("./lists/surahList.cjs");
const partNames = exports.partNames = ["surah", "juz", "page", "manzil", "rubAlHizb", "ruku"];
const parts = exports.parts = {
  surah: _surahList.SurahList,
  juz: _juzList.JuzList,
  rubAlHizb: _hizbList.HizbQuarterList,
  page: _pageList.PageList,
  manzil: _manzilList.ManzilList,
  ruku: _rukuList.RukuList
};
function toPartFormatter(type) {
  return type === "surah" ? ([startAyahId, ayahCount]) => ({
    startAyahId,
    ayahCount
  }) : (ayahId, index) => {
    const ayahCount = parts[type][index + 2] - ayahId;
    return {
      startAyahId: ayahId,
      ayahCount
    };
  };
}
function getList(type) {
  const list = parts[type];
  return list.slice(1, list.length - 1).map(toPartFormatter(type));
}