"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findPagebyAyahId = findPagebyAyahId;
var _pageList = require("./lists/pageList.cjs");
var _validation = require("./validation.cjs");
function findPagebyAyahId(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  return _pageList.PageList.findIndex(x => x > ayahId) - 1;
}