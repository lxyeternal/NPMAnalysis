"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findSurahByAyahId = findSurahByAyahId;
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
function findSurahByAyahId(ayaId) {
  return (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(ayaId)[0];
}