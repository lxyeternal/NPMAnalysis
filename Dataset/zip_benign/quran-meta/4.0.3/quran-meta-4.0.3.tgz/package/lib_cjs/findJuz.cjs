"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findJuz = findJuz;
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findJuzByAyahId = require("./findJuzByAyahId.cjs");
function findJuz(surah, ayah = 1) {
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return (0, _findJuzByAyahId.findJuzByAyahId)(ayahId);
}