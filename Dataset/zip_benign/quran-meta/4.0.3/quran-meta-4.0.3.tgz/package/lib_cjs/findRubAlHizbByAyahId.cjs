"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findRubAlHizbByAyahId = findRubAlHizbByAyahId;
var _hizbList = require("./lists/hizbList.cjs");
var _validation = require("./validation.cjs");
function findRubAlHizbByAyahId(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  return _hizbList.HizbQuarterList.findIndex(x => x > ayahId) - 1;
}