"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.surahStringParser = surahStringParser;
var _typeGuards = require("./typeGuards.cjs");
function surahStringParser(str, isStrict = false) {
  const surahX = isStrict ? Number(str.trim()) : Number.parseInt(str.trim(), 10);
  if (isNaN(surahX)) {
    throw new Error("Error in surah format " + str);
  }
  if (!(0, _typeGuards.isValidSurah)(surahX)) {
    throw new Error("Error in surah number " + str);
  }
  return surahX;
}