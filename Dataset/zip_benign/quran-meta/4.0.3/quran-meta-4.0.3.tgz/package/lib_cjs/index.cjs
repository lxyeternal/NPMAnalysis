"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "HizbQuarterList", {
  enumerable: true,
  get: function () {
    return _hizbList.HizbQuarterList;
  }
});
Object.defineProperty(exports, "JuzList", {
  enumerable: true,
  get: function () {
    return _juzList.JuzList;
  }
});
Object.defineProperty(exports, "ManzilList", {
  enumerable: true,
  get: function () {
    return _manzilList.ManzilList;
  }
});
Object.defineProperty(exports, "PageList", {
  enumerable: true,
  get: function () {
    return _pageList.PageList;
  }
});
Object.defineProperty(exports, "RukuList", {
  enumerable: true,
  get: function () {
    return _rukuList.RukuList;
  }
});
Object.defineProperty(exports, "SajdaList", {
  enumerable: true,
  get: function () {
    return _sajdaList.SajdaList;
  }
});
Object.defineProperty(exports, "SurahList", {
  enumerable: true,
  get: function () {
    return _surahList.SurahList;
  }
});
Object.defineProperty(exports, "ayahStringSplitter", {
  enumerable: true,
  get: function () {
    return _ayahStringSplitter.ayahStringSplitter;
  }
});
Object.defineProperty(exports, "checkValidAyahId", {
  enumerable: true,
  get: function () {
    return _validation.checkValidAyahId;
  }
});
Object.defineProperty(exports, "checkValidJuz", {
  enumerable: true,
  get: function () {
    return _validation.checkValidJuz;
  }
});
Object.defineProperty(exports, "checkValidPage", {
  enumerable: true,
  get: function () {
    return _validation.checkValidPage;
  }
});
Object.defineProperty(exports, "checkValidSurah", {
  enumerable: true,
  get: function () {
    return _validation.checkValidSurah;
  }
});
Object.defineProperty(exports, "checkValidSurahAyah", {
  enumerable: true,
  get: function () {
    return _validation.checkValidSurahAyah;
  }
});
Object.defineProperty(exports, "findAyahIdBySurah", {
  enumerable: true,
  get: function () {
    return _findAyahIdBySurah.findAyahIdBySurah;
  }
});
Object.defineProperty(exports, "findJuz", {
  enumerable: true,
  get: function () {
    return _findJuz.findJuz;
  }
});
Object.defineProperty(exports, "findJuzAndShift", {
  enumerable: true,
  get: function () {
    return _findJuzAndShift.findJuzAndShift;
  }
});
Object.defineProperty(exports, "findJuzByAyahId", {
  enumerable: true,
  get: function () {
    return _findJuzByAyahId.findJuzByAyahId;
  }
});
Object.defineProperty(exports, "findJuzMetaBySurah", {
  enumerable: true,
  get: function () {
    return _findJuzMetaBySurah.findJuzMetaBySurah;
  }
});
Object.defineProperty(exports, "findPage", {
  enumerable: true,
  get: function () {
    return _findPage.findPage;
  }
});
Object.defineProperty(exports, "findPagebyAyahId", {
  enumerable: true,
  get: function () {
    return _findPagebyAyahId.findPagebyAyahId;
  }
});
Object.defineProperty(exports, "findRangeAroundAyah", {
  enumerable: true,
  get: function () {
    return _findRangeAroundAyah.findRangeAroundAyah;
  }
});
Object.defineProperty(exports, "findRangeAroundSurahAyah", {
  enumerable: true,
  get: function () {
    return _findRangeAroundSurahAyah.findRangeAroundSurahAyah;
  }
});
Object.defineProperty(exports, "findRubAlHizb", {
  enumerable: true,
  get: function () {
    return _findRubAlHizb.findRubAlHizb;
  }
});
Object.defineProperty(exports, "findRubAlHizbByAyahId", {
  enumerable: true,
  get: function () {
    return _findRubAlHizbByAyahId.findRubAlHizbByAyahId;
  }
});
Object.defineProperty(exports, "findSurahAyahByAyahId", {
  enumerable: true,
  get: function () {
    return _findSurahAyahByAyahId.findSurahAyahByAyahId;
  }
});
Object.defineProperty(exports, "findSurahByAyahId", {
  enumerable: true,
  get: function () {
    return _findSurahByAyahId.findSurahByAyahId;
  }
});
Object.defineProperty(exports, "getAyahCountInSurah", {
  enumerable: true,
  get: function () {
    return _getAyahCountInSurah.getAyahCountInSurah;
  }
});
Object.defineProperty(exports, "getAyahMeta", {
  enumerable: true,
  get: function () {
    return _getAyahMeta.getAyahMeta;
  }
});
Object.defineProperty(exports, "getList", {
  enumerable: true,
  get: function () {
    return _getList.getList;
  }
});
Object.defineProperty(exports, "getPageMeta", {
  enumerable: true,
  get: function () {
    return _getPageMeta.getPageMeta;
  }
});
Object.defineProperty(exports, "getRubAlHizbMeta", {
  enumerable: true,
  get: function () {
    return _getRubAlHizbMeta.getRubAlHizbMeta;
  }
});
Object.defineProperty(exports, "getRubAlHizbMetaByAyahId", {
  enumerable: true,
  get: function () {
    return _getRubAlHizbMetaByAyahId.getRubAlHizbMetaByAyahId;
  }
});
Object.defineProperty(exports, "getSurahMeta", {
  enumerable: true,
  get: function () {
    return _getSurahMeta.getSurahMeta;
  }
});
Object.defineProperty(exports, "isAyahJuzFirst", {
  enumerable: true,
  get: function () {
    return _isAyahJuzFirst.isAyahJuzFirst;
  }
});
Object.defineProperty(exports, "isAyahPageFirst", {
  enumerable: true,
  get: function () {
    return _isAyahPageFirst.isAyahPageFirst;
  }
});
Object.defineProperty(exports, "isSurahAyahJuzFirst", {
  enumerable: true,
  get: function () {
    return _isSurahAyahJuzFirst.isSurahAyahJuzFirst;
  }
});
Object.defineProperty(exports, "isSurahAyahPageFirst", {
  enumerable: true,
  get: function () {
    return _isSurahAyahPageFirst.isSurahAyahPageFirst;
  }
});
Object.defineProperty(exports, "isValidAyahId", {
  enumerable: true,
  get: function () {
    return _typeGuards.isValidAyahId;
  }
});
Object.defineProperty(exports, "isValidAyahNo", {
  enumerable: true,
  get: function () {
    return _typeGuards.isValidAyahNo;
  }
});
Object.defineProperty(exports, "isValidJuz", {
  enumerable: true,
  get: function () {
    return _typeGuards.isValidJuz;
  }
});
Object.defineProperty(exports, "isValidPage", {
  enumerable: true,
  get: function () {
    return _typeGuards.isValidPage;
  }
});
Object.defineProperty(exports, "isValidSurah", {
  enumerable: true,
  get: function () {
    return _typeGuards.isValidSurah;
  }
});
Object.defineProperty(exports, "isValidSurahAyah", {
  enumerable: true,
  get: function () {
    return _typeGuards.isValidSurahAyah;
  }
});
Object.defineProperty(exports, "meta", {
  enumerable: true,
  get: function () {
    return _const.meta;
  }
});
Object.defineProperty(exports, "nextAyah", {
  enumerable: true,
  get: function () {
    return _nextAyah.nextAyah;
  }
});
Object.defineProperty(exports, "prevAyah", {
  enumerable: true,
  get: function () {
    return _prevAyah.prevAyah;
  }
});
Object.defineProperty(exports, "string2NumberSplitter", {
  enumerable: true,
  get: function () {
    return _ayahStringSplitter.string2NumberSplitter;
  }
});
Object.defineProperty(exports, "string2NumberSplitterStrict", {
  enumerable: true,
  get: function () {
    return _ayahStringSplitter.string2NumberSplitterStrict;
  }
});
Object.defineProperty(exports, "surahNamesAz", {
  enumerable: true,
  get: function () {
    return _surah.surahNamesAz;
  }
});
Object.defineProperty(exports, "surahNamesEn", {
  enumerable: true,
  get: function () {
    return _surah2.surahNamesEn;
  }
});
Object.defineProperty(exports, "surahNamesRu", {
  enumerable: true,
  get: function () {
    return _surah3.surahNamesRu;
  }
});
Object.defineProperty(exports, "surahNamesTr", {
  enumerable: true,
  get: function () {
    return _surah4.surahNamesTr;
  }
});
Object.defineProperty(exports, "surahStringParser", {
  enumerable: true,
  get: function () {
    return _surahStringParser.surahStringParser;
  }
});
var _ayahStringSplitter = require("./ayahStringSplitter.cjs");
var _surahStringParser = require("./surahStringParser.cjs");
var _const = require("./const.cjs");
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findJuz = require("./findJuz.cjs");
var _findJuzAndShift = require("./findJuzAndShift.cjs");
var _findJuzByAyahId = require("./findJuzByAyahId.cjs");
var _findJuzMetaBySurah = require("./findJuzMetaBySurah.cjs");
var _findPage = require("./findPage.cjs");
var _findPagebyAyahId = require("./findPagebyAyahId.cjs");
var _findRangeAroundAyah = require("./findRangeAroundAyah.cjs");
var _findRangeAroundSurahAyah = require("./findRangeAroundSurahAyah.cjs");
var _findRubAlHizb = require("./findRubAlHizb.cjs");
var _findRubAlHizbByAyahId = require("./findRubAlHizbByAyahId.cjs");
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
var _findSurahByAyahId = require("./findSurahByAyahId.cjs");
var _getAyahCountInSurah = require("./getAyahCountInSurah.cjs");
var _getAyahMeta = require("./getAyahMeta.cjs");
var _getList = require("./getList.cjs");
var _getPageMeta = require("./getPageMeta.cjs");
var _getRubAlHizbMeta = require("./getRubAlHizbMeta.cjs");
var _getRubAlHizbMetaByAyahId = require("./getRubAlHizbMetaByAyahId.cjs");
var _getSurahMeta = require("./getSurahMeta.cjs");
var _isAyahJuzFirst = require("./isAyahJuzFirst.cjs");
var _isAyahPageFirst = require("./isAyahPageFirst.cjs");
var _isSurahAyahJuzFirst = require("./isSurahAyahJuzFirst.cjs");
var _isSurahAyahPageFirst = require("./isSurahAyahPageFirst.cjs");
var _hizbList = require("./lists/hizbList.cjs");
var _juzList = require("./lists/juzList.cjs");
var _manzilList = require("./lists/manzilList.cjs");
var _pageList = require("./lists/pageList.cjs");
var _rukuList = require("./lists/rukuList.cjs");
var _sajdaList = require("./lists/sajdaList.cjs");
var _surahList = require("./lists/surahList.cjs");
var _nextAyah = require("./nextAyah.cjs");
var _prevAyah = require("./prevAyah.cjs");
var _typeGuards = require("./typeGuards.cjs");
var _validation = require("./validation.cjs");
var _surah = require("./i18n/surah.az.cjs");
var _surah2 = require("./i18n/surah.en.cjs");
var _surah3 = require("./i18n/surah.ru.cjs");
var _surah4 = require("./i18n/surah.tr.cjs");