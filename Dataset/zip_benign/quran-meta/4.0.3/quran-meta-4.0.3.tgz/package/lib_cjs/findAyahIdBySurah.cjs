"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findAyahIdBySurah = findAyahIdBySurah;
var _getSurahMeta = require("./getSurahMeta.cjs");
var _validation = require("./validation.cjs");
function findAyahIdBySurah(surah, ayah) {
  (0, _validation.checkValidSurahAyah)(surah, ayah);
  const [startAyahId] = (0, _getSurahMeta.getSurahMeta)(surah);
  return startAyahId + ayah - 1;
}