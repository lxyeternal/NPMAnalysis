"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findRangeAroundSurahAyah = findRangeAroundSurahAyah;
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _findRangeAroundAyah = require("./findRangeAroundAyah.cjs");
var _surahList = require("./lists/surahList.cjs");
var _validation = require("./validation.cjs");
function findRangeAroundSurahAyah(surah, ayah, mode) {
  (0, _validation.checkValidSurah)(surah);
  if (mode === "surah") {
    return [_surahList.SurahList[surah][0], _surahList.SurahList[surah + 1][0] - 1];
  }
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return (0, _findRangeAroundAyah.findRangeAroundAyah)(ayahId, mode);
}