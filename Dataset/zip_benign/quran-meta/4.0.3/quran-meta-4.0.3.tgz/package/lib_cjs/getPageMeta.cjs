"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getPageMeta = getPageMeta;
var _findSurahAyahByAyahId = require("./findSurahAyahByAyahId.cjs");
var _pageList = require("./lists/pageList.cjs");
var _validation = require("./validation.cjs");
function getPageMeta(pageNum) {
  (0, _validation.checkValidPage)(pageNum);
  const [curPage, nextPage] = [_pageList.PageList[pageNum], _pageList.PageList[pageNum + 1]];
  return {
    pageNum,
    first: (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(curPage),
    last: (0, _findSurahAyahByAyahId.findSurahAyahByAyahId)(nextPage - 1)
  };
}