"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findJuzByAyahId = findJuzByAyahId;
var _juzList = require("./lists/juzList.cjs");
var _validation = require("./validation.cjs");
function findJuzByAyahId(ayahId) {
  (0, _validation.checkValidAyahId)(ayahId);
  const juz = _juzList.JuzList.findIndex(x => x > ayahId) - 1;
  return juz;
}