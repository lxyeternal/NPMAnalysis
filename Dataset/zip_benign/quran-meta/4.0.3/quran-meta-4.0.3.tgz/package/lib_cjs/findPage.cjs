"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findPage = findPage;
var _findAyahIdBySurah = require("./findAyahIdBySurah.cjs");
var _pageList = require("./lists/pageList.cjs");
var _validation = require("./validation.cjs");
function findPage(surah, ayah) {
  (0, _validation.checkValidSurah)(surah);
  const ayahId = (0, _findAyahIdBySurah.findAyahIdBySurah)(surah, ayah);
  return _pageList.PageList.findIndex(x => x > ayahId) - 1;
}