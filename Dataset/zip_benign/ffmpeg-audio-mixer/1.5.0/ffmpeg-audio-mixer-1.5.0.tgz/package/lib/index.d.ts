type Codecs = 'aac' | 'ac3' | 'ac3_fixed' | 'flac' | 'opus' | 'libfdk_aac' | 'libmp3lame' | 'libopencore-amrnb' | 'libopus' | 'libshine' | 'libtwolame' | 'libvo-amrwbenc' | 'libvorbis' | 'mjpeg' | 'wavpack';
type SampleFormats = 'u8' | 's16' | 's32' | 'flt' | 'dbl' | 'u8p' | 's16p' | 's32p' | 'fltp' | 'dblp ' | 's64' | 's64p';
type InputOptions = {
    inputFile: string;
    weight?: number;
    delay?: number;
    trim?: {
        start?: number;
        end?: number;
    };
};
type AudioInput = string | InputOptions;
type OutputOptions = {
    frames?: number;
    codec?: Codecs;
    sampleFormat?: SampleFormats;
    volume?: number;
    normalize?: boolean;
};

declare class AudioMixer {
    private inputs;
    private options;
    constructor(inputs: AudioInput | AudioInput[], options?: OutputOptions);
    addInput(input: AudioInput): this;
    setOptions(options: OutputOptions): this;
    setFrames(frames: number): this;
    setCodec(codec: Codecs): this;
    setSampleFormat(sampleFormat: SampleFormats): this;
    setVolume(volume: number): this;
    toFile(outputFileName: string): Promise<void>;
    toStream(fileFormat: string): NodeJS.ReadableStream;
    toBuffer(fileFormat: string): Promise<Buffer>;
}
declare function mixAudio(inputs: AudioInput | AudioInput[], options?: OutputOptions): AudioMixer;

export { type AudioInput, AudioMixer, type Codecs, type InputOptions, type OutputOptions, type SampleFormats, mixAudio };
