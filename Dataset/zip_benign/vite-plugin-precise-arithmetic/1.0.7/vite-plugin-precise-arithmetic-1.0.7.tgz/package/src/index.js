const { findNodeAt, simple } = require("acorn-walk");
const path = require("path");

module.exports = function () {
  let needRequireCache = [];
  function pushCache(operation) {
    let operationFun;
    switch (operation) {
      case "+":
        operationFun = "accAdd";
        break;
      case "-":
        operationFun = "accSub";
        break;
      case "*":
        operationFun = "accMul";
        break;
      case "/":
        operationFun = "accDiv";
        break;
      case "+=":
        operationFun = "accAdd";
        break;
      case "-=":
        operationFun = "accSub";
        break;
      default:
        operationFun = "none";
    }
    if (needRequireCache.indexOf(operationFun) >= 0) return operationFun;
    operationFun !== "none" && needRequireCache.push(operationFun);
    return operationFun;
  }
  return {
    // 插件名称
    name: "vite-plugin-precise-arithmetic",
    // 该插件在 plugin-vue 插件之前执行，这样就可以直接解析到原模板文件
    enforce: "post",
    // 代码转译，这个函数的功能类似于 `webpack` 的 `loader`
    transform(code, id) {
      if (
        !id.includes("node_modules") &&
        id.includes((path.resolve("./") + "/src").replace(/\\/g, "/"))
      ) {
        while (true) {
          const found = findNodeAt(
            this.parse(code),
            null,
            null,
            (type, node) => {
              return (
                ("AssignmentExpression" === type ||
                  "BinaryExpression" === type) &&
                pushCache(node.operator) !== "none"
              );
            }
          );
          let replaceOperator = pushCache(found?.node.operator);
          if (found?.node && replaceOperator && replaceOperator !== "none") {
            const node = found?.node;
            let left = code.substring(node.left.start, node.left.end);
            let right = code.substring(node.right.start, node.right.end);
            const args = [left, right];
            if (node.type == "AssignmentExpression") {
              const replace = `${left} = ${replaceOperator}(${args.toString()})`;
              code =
                code.substring(0, node.start) +
                replace +
                code.substring(node.end, code.length);
            } else if (node.type == "BinaryExpression") {
              const replace = `${replaceOperator}(${args.toString()})`;
              code =
                code.substring(0, node.start) +
                replace +
                code.substring(node.end, code.length);
            }
          } else {
            break;
          }
        }
        if (needRequireCache.length) {
          let isImport = false;
          simple(this.parse(code), {
            ImportDeclaration: (node) => {
              if (
                needRequireCache.length &&
                node?.source?.value &&
                node?.source?.value.includes(
                  "vite-plugin-precise-arithmetic/src/calc"
                )
              ) {
                isImport = true;
              }
            },
          });
          if (!isImport) {
            code = `import { ${needRequireCache.toString()} } from 'vite-plugin-precise-arithmetic/src/calc.js';\n${code}`;
          }
        }
      }
      return {
        code: code,
      };
    },
  };
};
