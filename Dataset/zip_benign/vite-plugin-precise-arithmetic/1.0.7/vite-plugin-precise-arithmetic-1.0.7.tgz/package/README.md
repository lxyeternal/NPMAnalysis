# vite-plugin-precise-arithmetic

- 一个 vite 插件，作为浮点数计算精度问题的解决方案

## 功能

- 一个 vite 插件，作为浮点数计算精度问题的解决方案

## 前言

- 本插件目的为不改变写法的情况下解决`javascript`中浮点数计算精度问题，如`0.1+0.2=0.30000000000000004`，本插件原理为利用`vite plugin`中的`transform`将代码进行二次转译，将原来的算术运算转换成函数运算，函数中会将浮点数转换成整数计算，计算完成后再转换成浮点数返回
- 关于浮点数精度问题，在`javascript`中当数值对于大于 2 的 53 次方时精度将丢失。
- 由于插件原理为转换成整数计算，会把数字值变大，也就是越接近于 2 的 53 次方，所以此插件并不能在语言本质上解决。
- 如您只是想解决浮点数计算问题，又不想改代码，数字又不会超过 2 的 53 次方，那就使用此插件吧

## 感谢

- 插件参考自`webpack`插件[babel-plugin-precise-arithmetic](https://www.npmjs.com/package/babel-plugin-precise-arithmetic)，因为本人没有找到`vite`对应替代插件，所以便仿照写了一个对应`vite`的插件

## 安装 (yarn or npm)

**vite version:** >=2.0.0

```bash
yarn add vite-plugin-precise-arithmetic -D
```

或

```bash
npm i vite-plugin-precise-arithmetic -D
```

## 使用

- 在 `vite.config.ts` 中增加配置，例如

```ts
...
  import preciseArithmetic from 'vite-plugin-precise-arithmetic';
...
  {
    plugins:[preciseArithmetic()]
  }
...
```

## 例子

- 通过这个插件，它将 BinaryExpression 转换为 FunctionCall 以获得具有浮点数的正确结果。

```ts
var a = 0.1 + 0.2; // 0.30000000000000004
var b = 0.8 - 0.2; // 0.6000000000000001
```

- 将被转换成

```ts
  import { accAdd, accSub } from 'vite-plugin-precise-arithmetic/src/calc.js'
  ...
  var a = accAdd ( 0.1, 0.2 ); // 0.3
  var b = accSub ( 0.8, 0.2 );  //0.6
```
