# Node.js Client Library for Dependency Health API

Dependency Health provides data about open-source package health. 
It could be used in a CI/CD pipeline or as an IDE plugin.

## Installation

```bash
npm install dependencyhealth
```

## Usage

```ts
import {DependencyHealthNPMClient} from 'dependency_health'

let dh = new DependencyHealthNPMClient(process.env.DH_API_KEY);
await dh.login();

let packageInfo = await HealthCheck._client.get('@angular/core');
console.log(packageInfo);
```

```json
{
  "age": 7,
  "versions": 711,
  "maintainers": 2,
  "dependencies": 1,
  "health": 95,
  "security": "no known security issues",
  "popularity": "key ecosystem project",
  "maintenance": "healthy",
  "community": "active",
  "name": "@angular/core",
  "updated_at": "2023-07-14T13:37:37.573865Z"
}
```