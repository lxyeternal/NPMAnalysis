/**
 *
 * @param {Array} RGBArray
 */
const rgbToHex = RGBArray =>
  RGBArray.reduce((hex, rgb) => {
    if (rgb < 16) return `${hex}0${rgb.toString(16)}`;
    return hex + rgb.toString(16);
  }, "#");

/**
 *
 * @param {number} H Hue
 * @param {number} S Saturation
 * @param {number} L Lightness
 */
const hslToRgb = (H, S, L) => {
  const q = L < 0.5 ? L * (1 + S) : L + S - L * S;
  const p = 2 * L - q;
  const hueToRgb = (p, q, t) => {
    let preRGB = t < 0 ? t + 1 : t > 1 ? t - 1 : t;
    if (preRGB < 1 / 6) preRGB = p + (q - p) * 6 * preRGB;
    else if (preRGB < 1 / 2) preRGB = q;
    else if (preRGB < 2 / 3) preRGB = p + (q - p) * 6 * (2 / 3 - preRGB);
    else preRGB = p;
    return Math.round(preRGB * 255);
  };
  const R = hueToRgb(p, q, H + 1 / 3);
  const G = hueToRgb(p, q, H);
  const B = hueToRgb(p, q, H - 1 / 3);
  return [R, G, B];
};

/**
 *
 * @param {string} hash generated hash
 * @param {number} hue Hue
 * @param {number} sat Saturation
 * @param {number} light Lightness
 */
const hslGeneration = (hash, hue, sat, light) => {
  const hashFactor = (hash % 1007) / 1007; // 1007 is a prime
  const generateWithinRange = (val, min, max) => val * (max - min) + min;
  const H = generateWithinRange(hashFactor, hue.min, hue.max);
  const S = generateWithinRange(hashFactor, sat.min, sat.max);
  const L = generateWithinRange(hashFactor, light.max, light.min);
  return [H, S, L];
};

/**
 *
 * @param {string} str string to hash
 */
const standardHashFunction = str =>
  str
    .split("")
    .reduce((hash, char, id) => hash * char.charCodeAt(0) * id + 1, 1);

/**
 *
 * @param {Object} {
 *  str: String to be hashed,
 *  hue: { min, max } values (in deg)
 *  sat: { min, max } values (0 to 1)
 *  light: { min, max } values (0 to 1),
 *  hashFunction: Custom hash function,
 *  scheme: return scheme
 * }
 */
const generateColorHash = ({
  str,
  hue = { min: 0, max: 360 },
  sat = { min: 0.35, max: 0.65 },
  light = { min: 0.3, max: 0.7 },
  hashFunction = standardHashFunction,
  scheme = "hex"
}) => {
  const [H, S, L] = hslGeneration(hashFunction(str), hue, sat, light);
  const RGBArray = hslToRgb(H / 360, S, L);
  const hex = rgbToHex(RGBArray);
  if (scheme === "hsl") return [H, S, L];
  else if (scheme === "rgb") return RGBArray;
  return hex;
};

export default generateColorHash;
