# Simple Color Hash

### How to use it?

```js
const input = "Ashwanth A R";
const output = generateColorHash({ str: input }); // returns hex value
```

It's that simple. The color hash generator returns a hex code value.

If you want to configure more options, you can additionally provide hue, saturation, lightness, hash function and scheme.

```js
const input = "Ashwanth A R";
const output = generateColorHash({
  str: input,
  hue: { min: 210, max: 450 },
  sat: { min: 0.35, max: 0.65 },
  light: { min: 0.4, max: 0.6 },
  scheme: "rgb",
  hashFunction: customHash
});
```
