
//define([ 'windy/Particle', 'windy/WindField'], function ( Particle, WindField) {
import * as Cesium from  'cesium' ;
import WindField from './OceanField';
type Particle = {
        x ?: any;
        dx ?: any;
        y ?: any;
        age ?: any;
        birthAge ?: any;
        path ?: any;
}
type oceanConfigType={
    // 粒子数量
 PARTICLES_NUMBER :  number,
   // 粒子长度比例
   SPEED_RATE:  number,
   // 粒子分段最大段数
   MAX_AGE: number
   // 渐变比例
   BRIGHTEN:  number,
   //帧数控制
   FRAME_RATE: number,
   width:number,
   // 固定分段
   FIX_AGE?:number,
}

class Ocean{
    windData:any ;
    windField:any ;
    particles:any ;
    timer:any ;
    local:any ;
    lines:any;
    PARTICLES_NUMBER:number;
    SPEED_RATE:number ;
    width:number;
    MAX_AGE:number ;
    FRAME_RATE:number;
    BRIGHTEN:number ;
    _primitives:any ;
    FIX_AGE?:number;
    constructor(json:any,local:any, cesiumViewer:any,config:oceanConfigType){
        this.windData = json;
        this.windField = null;
        this.particles = [];
        this.timer = null;
        this.local = local;
        this.lines = null;
        this.PARTICLES_NUMBER  = config.PARTICLES_NUMBER || 200;
        this.SPEED_RATE = config.SPEED_RATE || 0.7;
        this.MAX_AGE = config.MAX_AGE ||10;
        this.FRAME_RATE = config.FRAME_RATE||300;
        this.BRIGHTEN = config.BRIGHTEN || 1.5
        this.width = config.width || 2;
        this.FIX_AGE = config.FIX_AGE
        this._primitives = cesiumViewer.scene.primitives;
        this._init();
    }
    private _init(){
        // 创建风场网格
        this.windField = this.createField();
        // 创建风场粒子
        for (var i = 0; i < this.PARTICLES_NUMBER; i++) {
            //创建随机粒子
            let particle:Particle={}
            this.particles.push(this.randomParticle(particle));
        }
    }
    private createField(){
        var data = this._parseWindJson();
        return new WindField(data);
    }
    private animate(){
        var self = this,
            field = self.windField,
            particles = self.particles;

        var instances:any = [],
            nextX,
            nextY,
            xy,
            uv:any;
        particles.forEach(function (particle:Particle) {
            if (particle.age <= 0) {
                self.randomParticle(particle);
            }
            //计算流向和随机粒子
            if (particle.age > 0) {
                var x = particle.x,
                    y = particle.y;

                if (!field.isInBound(x, y)) {
                    particle.age = 0;
                } else {
                    try{
                    uv = field.getIn(x, 0);

                    let locax = particle.path[particle.path.length-2];
                    let locay = particle.path[particle.path.length-1];

                    nextX = locax +  self.SPEED_RATE * uv[0];
                    nextY = locay +  self.SPEED_RATE * uv[1];

                    particle.path.push(nextX, nextY);
                    particle.x =x + self.SPEED_RATE*uv[0];
                    particle.y = y + self.SPEED_RATE*uv[1];
                    //@ts-ignore
                    instances.push(self._createLineInstance(self._map(particle.path), particle.age / particle.birthAge));
                    particle.age--;
                }catch(e){
                    console.log('出错了',e,uv,x)
                }
                }
            }
        });
        if (instances.length <= 0) this.removeLines();
        self._drawLines(instances);
    }
    private _parseWindJson(){
        var uComponent = null,
            vComponent = null,
            header = null;
        this.windData.forEach(function (record:any) {
            var type = record.header.parameterCategory + "," + record.header.parameterNumber;
            switch (type) {
                case "2,2":
                    uComponent = record['data'];
                    header = record['header'];
                    break;
                case "2,3":
                    vComponent = record['data'];
                    break;
                default:
                    break;
            }
        });
        return {
            local:this.local,
            header: header,
            uComponent: uComponent,
            vComponent: vComponent
        };
    }
    private removeLines(clear?:boolean) {
        if(clear){
            clearInterval(this.timer);
        }
        if (this.lines) {
            this._primitives.remove(this.lines);
            // this.lines.destroy();
            this.lines = undefined;
        }
    }
    //求路径上点
    private _map(arr:any) {
        var length = arr.length,
            field = this.windField,
            dx = field.dx,
            dy = field.dy,
            west = field.west,
            south = field.north,
            newArr = [];
        for (let i = 0; i <= length - 2; i += 2) {
            //@ts-ignore
            newArr.push( Cesium.Cartesian3.fromDegrees(arr[i],arr[i + 1],0)
            )
        }
        return newArr;
    }
    private _createLineInstance(positions:any, ageRate:any) {
        var colors = [],
            length = positions.length,
            count = length / 2;
        for (var i = 0; i < length; i++) {
            //@ts-ignore
            colors.push(Cesium.Color.LIGHTBLUE.withAlpha(i / count * ageRate * this.BRIGHTEN));
            // colors.push([107,203,227,i / count * ageRate * BRIGHTEN]);
        }
        return new Cesium.GeometryInstance({
            geometry: new Cesium.PolylineGeometry({
                positions: positions,
                colors: colors,
                width: this.width,
                colorsPerVertex: true
            })
        });
    }
    private _drawLines(lineInstances:any) {
        this.removeLines();
        var linePrimitive = new Cesium.Primitive({
            appearance: new Cesium.PolylineColorAppearance({
                translucent: true
            }),
            geometryInstances: lineInstances,
            asynchronous: false
        });
        this.lines = this._primitives.add(linePrimitive);
    }

    //生成随机的点和xy坐标
    private randomParticle(particle:Particle){
        var safe = 30,x, y;
        do {
            x = Math.floor(Math.random() * (this.windField.cols - 2));
            y = 0 ;

        } while (this.windField.getIn(x, y)[2] <= 0 && safe++ < 30);

        particle.x = x;
        particle.y = y;
        particle.age = Math.round(Math.random() * this.MAX_AGE);
        if(this.FIX_AGE){
            particle.age = this.FIX_AGE;
        }
        if(particle.age<3){
            particle.age = 3
        }
        particle.birthAge = particle.age;
        particle.path = [this.local[x][0],this.local[x][1]];
        return particle;
    }
    //添加洋流
    public draw(){
        let that = this;
        this.animate();
        this.timer = setInterval(function () {
            that.animate();
        }, this.FRAME_RATE);
    }
     //移除洋流图
    public remove(){
        this.removeLines(true);
    }
};

export default Ocean;
