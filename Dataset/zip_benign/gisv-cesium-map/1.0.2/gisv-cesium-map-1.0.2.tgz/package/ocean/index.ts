/*
 * @Descripttion: 
 * @version: 
 * @Author: chenwei
 * @Date: 2021-07-02 10:33:36
 * @LastEditors: chenwei
 * @LastEditTime: 2021-07-08 22:45:44
 */
import axios from 'axios';
import OceanInstance from './Ocean';
import cesium from 'cesium';

type oceanConfigType={
       // 粒子数量
    PARTICLES_NUMBER :  number,
      // 粒子长度比例
      SPEED_RATE:  number,
      // 粒子分段最大段数
      MAX_AGE: number
      // 渐变比例
      BRIGHTEN:  number,
      //帧数控制
      FRAME_RATE: number,
      //线条宽度
      width:number,
      //固定分段
      FIX_AGE?:number
}

/**
 * @description: 添加洋流场实例
 * @param {*}
 * @return {*}
 * let oScene = new oceanScene(viewer,url,localUrl);
 *  粒子数量
 * OScene.PARTICLES_NUMBER = 10000;
 *  粒子长度比例
 * OScene.SPEED_RATE =  0.7;
 * 渐变比例
 * OScene.BRIGHTEN = 1.5
 * 粒子分段最大段数
 * OScene.MAX_AGE = 10
 * 帧数控制
 * OScene.FRAME_RATE = 200;
 * 线条宽度
 * oScene.width = 2;
 * 固定飞行段数，写了FIX_AGE则MAX_AGE失效
 * Oscene.FIX_AGE = 5;
 * oScene.draw();
 * oScene.remove();
 * 
 */
export default class Ocean{
      viewer:cesium.Viewer
      locationUrl:string
      //风场实例
      _ocean?:OceanInstance;
      // 粒子数量
      PARTICLES_NUMBER:number  =  200;
      // 粒子长度比例
      SPEED_RATE:number =  0.9;
      // 粒子分段最大段数
      MAX_AGE:number = 5;
      // 渐变比例
      BRIGHTEN:number =  1.5;
      //帧数控制
      FRAME_RATE:number = 300;
      //数据连接
      dataUrl:string;
      //线条粗细
      width:number=2;
      //固定粒子分段
      FIX_AGE?:number;
      
    /**
     * @description: 洋流场加载
     * @param {cesium} viewer cesium viewer
     * @param {string} dataUrl 洋流场数据
     * @param {string} locationUrl 洋流场位置数据
     * @return {*}
     */      
    constructor(viewer:cesium.Viewer,dataUrl:string,locationUrl:string){
        this.viewer = viewer;
        this.dataUrl =  dataUrl
        this.locationUrl = locationUrl;
    }
  

    //画洋流场
    draw(){
        let that = this;
        const config:oceanConfigType = {
            PARTICLES_NUMBER:this.PARTICLES_NUMBER,SPEED_RATE:this.SPEED_RATE,MAX_AGE:this.MAX_AGE,BRIGHTEN:this.BRIGHTEN,FRAME_RATE:this.FRAME_RATE,width:this.width,FIX_AGE:this.FIX_AGE
        }
        axios.get(this.locationUrl).then(res=>{
                let local = res.data;
                axios.get(this.dataUrl).then(ress=>{
                    let _ocean = new OceanInstance(ress.data,local,that.viewer,config);
                    _ocean.draw();
                    that._ocean = _ocean;
                })
                
            })
    }

    //移除洋流场
    remove(){
        this._ocean?.remove();
    }
}