/*
 * @Descripttion:
 * @version:
 * @Author: chenwei
 * @Date: 2021-06-15 09:51:26
 * @LastEditors: chenwei
 * @LastEditTime: 2021-07-08 23:12:00
 */
import * as Cesium from  'cesium' ;
import axios from 'axios';
import h337 from 'gisv-cesium-heatmaps';

/**
 * @description: 添加温场图
 * @param {*}
 * @return {*}
 * let heap =new Heap(viewer,url)
 * heap.draw();
 * heap.remove();
 */
export default class HeapMap{
    viewer:Cesium.Viewer;
    _heap:any;
    dataUrl:string;
    /**
     * @description: 热力图
     * @param {Cesium} viewer cesium viewer
     * @param {string} dataUrl 热力数据
     * @return {*}
     */
    constructor(viewer:Cesium.Viewer,dataUrl:string){
        this.viewer = viewer;
        this.dataUrl  = dataUrl;
    }
    //制作热图
    draw(){
        let that = this;
        axios.get(this.dataUrl).then(res=>{
            that.show(res.data);
        })
    }
    //移除热图
    remove(){
        this.viewer.scene.primitives.remove(this._heap);
    }
    //展示数据
    show(data:any){
        let lonmin=1000;
        let lonmax=-1000;
        let latmin=1000;
        let latmax=-1000;
        data.features.forEach(function(feature:any){
            let lon = feature.geometry.coordinates[0];
            let lat = feature.geometry.coordinates[1];
            lonmin = lon<lonmin?lon:lonmin;
            latmin = lat<latmin?lat:latmin;
            lonmax = lon>lonmax?lon:lonmax;
            latmax = lat>latmax?lat:latmax;
        });
        let xrange = lonmax-lonmin;
        let yrange = latmax-latmin;
        let extent={xMin:lonmin-xrange/10,yMin:latmin-yrange/10, xMax:lonmax+xrange/10,yMax:latmax+yrange/10};
        let heatmapContainer = document.createElement('div');
        let width = 1000;
        let height = 1000/(extent.xMax-extent.xMin)*(extent.yMax-extent.yMin);
        heatmapContainer.setAttribute('style','width:'+width+'px;height:'+height+'px');
        document.body.appendChild(heatmapContainer);
        let heatmapInstance = h337.create({
            container: heatmapContainer,
            maxOpacity: .9,
            radius:60,
            minOpacity: .1,
            gradient: {
                '.06': '#7A378B',
                '.12':'#7D26CD',
                '.18':'#87CEFA',
                '.24':'#A4D3EE',
                '.32':'#3CB371',
                '.38':'#48D1CC',
                '.44':'#2E8B57',
                '.50':'#32CD32',
                '.56':'#C0FF3E',
                '.62':'#BCF390',
                '.68':'#A9A607',
                '.74':'#F5F50B',
                '.80':'#F5BC3C',
                '.86':'#F5969B',
                '.92':'red',

            },
        });
        let points = new Array();
        data.features.forEach(function(feature:any){
            let x = (feature.geometry.coordinates[0]-extent.xMin)/(extent.xMax-extent.xMin)*width;
            let y = (-(feature.geometry.coordinates[1]-extent.yMin)/(extent.yMax-extent.yMin)+1)*height;
            let point = {
                x: x,
                y: y,
                value: 0.02
            };
            points.push(point);
        });
        let datas = {
            max: 1,
            data: points
        };
        heatmapInstance.setData(datas);
        let heatmapcanvas = heatmapInstance._renderer.canvas;
        this.drawHeatmapRect( heatmapcanvas,extent,heatmapContainer);
        // this.viewer.camera.flyTo({
        //     destination : Cesium.Rectangle.fromDegrees(extent.xMin, extent.yMin, extent.xMax, extent.yMax)
        // });
    }
    //制作热图
    drawHeatmapRect(canvas:HTMLCanvasElement,extent:any,heatmapContainer:any) {
		let image = this.convertCanvasToImage(canvas);
        try{
            console.log(Cesium.Rectangle.fromDegrees(extent.xMin, extent.yMin, extent.xMax, extent.yMax),'ssss');
		let worldRectangle = this.viewer.scene.primitives.add(new Cesium.GroundPrimitive({
			geometryInstances : new Cesium.GeometryInstance({
				geometry : new Cesium.RectangleGeometry({
					rectangle : Cesium.Rectangle.fromDegrees(extent.xMin, extent.yMin, extent.xMax, extent.yMax),
					vertexFormat : Cesium.EllipsoidSurfaceAppearance.VERTEX_FORMAT
				})
			}),
			appearance : new Cesium.EllipsoidSurfaceAppearance({
                // aboveGround : true,
                        translucent : true,
                        material : new Cesium.Material({
                            fabric : {
                                type : 'Image',
                                uniforms : {
                                    image : image.src
                                }
                            }
                        })
              }),
			show : true
		}));
        this._heap = worldRectangle;
		// this._worldRectangle.appearance.material =
        }catch(e){
            console.log(e)
        }
       document.body.removeChild(heatmapContainer);
    }
    //转换成图片
    convertCanvasToImage(canvas:HTMLCanvasElement) {
		let image = new Image();
		image.src = canvas.toDataURL("image/png");
		return image;
    }

}
