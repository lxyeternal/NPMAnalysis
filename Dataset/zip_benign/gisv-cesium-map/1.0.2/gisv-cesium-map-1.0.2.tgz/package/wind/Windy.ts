
//define([ 'windy/Particle', 'windy/WindField'], function ( Particle, WindField) {

import * as Cesium from  'cesium' ;
import { GeometryInstance } from '../../../../types/cesium';
    import WindField from './WindField';
    type Particle = {
        x ?: any;
        dx ?: any;
        y ?: any;
        age ?: any;
        birthAge ?: any;
        path ?: any;
}
    type windyConfigType={
        // 粒子数量
     PARTICLES_NUMBER :  number,
       // 粒子长度比例
       SPEED_RATE:  number,
       // 粒子分段最大段数
       MAX_AGE: number
       // 渐变比例
       BRIGHTEN:  number,
       //帧数控制
       FRAME_RATE: number,
       height?:number;

    }
    class  Windy{
        windData:any;
        windField: any;
        particles: Particle[];
        timer: any;
        lines: any;
        PARTICLES_NUMBER: number;
        SPEED_RATE: number;
        height:number;
        MAX_AGE: number;
        FRAME_RATE: number;
        BRIGHTEN: number;
        private _primitives: any;
        constructor(json:any, cesiumViewer:Cesium.Viewer,config:windyConfigType){
            this.windData = json;
            this.windField = null;
            this.particles = [];
            this.timer = null;
            this.lines = null;
            this.PARTICLES_NUMBER  = config.PARTICLES_NUMBER || 2000;
            this.SPEED_RATE = config.SPEED_RATE || 0.15;
            this.MAX_AGE = config.MAX_AGE ||10;
            this.FRAME_RATE = config.FRAME_RATE || 300
            this.BRIGHTEN = config.BRIGHTEN || 1.5;
            this.height = config.height || 1000;
            this._primitives = cesiumViewer.scene.primitives;
            this._init();
       }
    private _init() {
        // 创建风场网格
        this.windField = this.createField();
        // 创建风场粒子
        for (var i = 0; i < this.PARTICLES_NUMBER; i++) {
            //@ts-ignore
            //创建随机粒子
            let partice:Particle={};
            this.particles.push(this.randomParticle(partice));
        }
    }
    private createField() {
        var data = this._parseWindJson();
        return new WindField(data);
    }
    private animate() {
        var self = this,
            field = self.windField,
            particles = self.particles;

        var instances:any = [],
            nextX = null,
            nextY = null,
            xy ,
            uv;
        particles.forEach(function (particle:Particle) {
            if (particle.age <= 0) {
                self.randomParticle(particle);
            }
            //计算流向和随机粒子
            if (particle.age > 0) {
                var x = particle.x,
                    y = particle.y;

                if (!field.isInBound(x, y)) {
                    particle.age = 0;
                } else {
                    uv = field.getIn(x, y);
                    nextX = x +  self.SPEED_RATE * uv[0];
                    nextY = y +  self.SPEED_RATE * uv[1];
                    particle.path.push(nextX, nextY);
                    particle.x = nextX;
                    particle.y = nextY;
                    //@ts-ignore
                    instances.push(self._createLineInstance(self._map(particle.path), particle.age / particle.birthAge));
                    particle.age--;
                }
            }
        });
        if (instances.length <= 0) this.removeLines();
        self._drawLines(instances);
    }

    private _parseWindJson() {
        let uComponent = null,
            vComponent = null,
            header = null;
        this.windData.forEach(function (record:any) {
            let type = record.header.parameterCategory + "," + record.header.parameterNumber;
            switch (type) {
                case "2,2":
                    uComponent = record['data'];
                    header = record['header'];
                    break;
                case "2,3":
                    vComponent = record['data'];
                    break;
                default:
                    break;
            }
        });
        return {
            header: header,
            uComponent: uComponent,
            vComponent: vComponent
        };
    }
    private removeLines(clear?:boolean) {
        if(clear){
            clearInterval(this.timer);
        }
        if (this.lines) {
            this._primitives.remove(this.lines);
            // this.lines.destroy();
            this.lines = undefined;
        }
    }

    //求路径上点
    private _map(arr:number[]) {
        var length = arr.length,
            field = this.windField,
            dx = field.dx,
            dy = field.dy,
            west = field.west,
            south = field.north,
            newArr = [];
        for (var i = 0; i <= length - 2; i += 2) {
            //@ts-ignore
            newArr.push(Cesium.Cartesian3.fromDegrees(west + arr[i] * dx,south - arr[i + 1] * dy,this.height))
        }
        return newArr;
    }
    private _createLineInstance(positions:number[], ageRate:number) {
        var colors = [],
            length = positions.length,
            count = length / 2;
        for (var i = 0; i < length; i++) {
            //@ts-ignore
            colors.push(Cesium.Color.WHITE.withAlpha(i / count * ageRate * this.BRIGHTEN));
        }
        return new Cesium.GeometryInstance({
            geometry: new Cesium.PolylineGeometry({
                positions: positions,
                colors: colors,
                width: 1.5,
                colorsPerVertex: true
            })
        });
    }
    private _drawLines(lineInstances:GeometryInstance) {
        this.removeLines();
        var linePrimitive = new Cesium.Primitive({
            appearance: new Cesium.PolylineColorAppearance({
                translucent: true
            }),
            geometryInstances: lineInstances,
            asynchronous: false
        });
        this.lines = this._primitives.add(linePrimitive);
    }
    //生成随机的点和xy坐标
    private randomParticle(particle:Particle) {
        var safe = 30,x, y;

        do {
            x = Math.floor(Math.random() * (this.windField.cols - 2));
            y = Math.floor(Math.random() * (this.windField.rows - 2));
            if(x>115||x<105||y>75||y<65){
                x = Math.floor(Math.random()*10 + 108);
                y = Math.floor(Math.random()*10  +60);
            }
        } while (this.windField.getIn(x, y)[2] <= 0 && safe++ < 30);

        particle.x = x;
        particle.y = y;
        particle.age = Math.round(Math.random() * this.MAX_AGE);//每一次生成都不一样
        particle.birthAge = particle.age;
        particle.path = [x, y];
        return particle;
    }
    //画风场图
    public draw(){
        let that = this;
        that.animate();
        that.timer = setInterval(function () {
            that.animate();
        }, this.FRAME_RATE);
    }
    //移除风场图
    public remove(){
        this.removeLines(true);
    }


    };
    export default Windy;
