/*
 * @Descripttion:
 * @version:
 * @Author: chenwei
 * @Date: 2021-07-02 10:33:36
 * @LastEditors: chenwei
 * @LastEditTime: 2021-07-08 23:08:18
 */
import axios from 'axios';
import * as Cesium from  'cesium' ;
import Windy from './Windy';
type windyConfigType={
    // 粒子数量
 PARTICLES_NUMBER :  number,
   // 粒子长度比例
   SPEED_RATE:  number,
   // 粒子分段最大段数
   MAX_AGE: number;
   // 渐变比例
   BRIGHTEN:  number,
   //帧数控制
   FRAME_RATE: number,
   height:number,
}

/**
 * @description: 添加风场
 * @param {*}
 * @return {*}
 * 使用方法
 * let windy = new oceanScene(viewer,url);
 * 粒子数量
 * windy.PARTICLES_NUMBER = 10000;
 *  粒子长度比例
 * windy.SPEED_RATE =  0.15;
 * 渐变比例
 * windy.BRIGHTEN = 1.5
 * 粒子分段最大段数
 * windy.MAX_AGE = 10
 * 风场高度
 * windy.height = 100
 * 帧数控制
 * windy.FRAME_RATE = 200;
 * windy.draw();
 * windy.remove();
 */
export default class Ocean{
    dataUrl:string;

    /**
     * @description: 风场
     * @param {Cesium} viewer cesium viewer
     * @param {string} dataUrl 风场数据
     * @return {*}
     */
    constructor(viewer:Cesium.Viewer,dataUrl:string){
        this.viewer = viewer;
        this.dataUrl = dataUrl;
    }
    viewer:Cesium.Viewer
    //风场实例
    _windy?:Windy;
    // 粒子数量
    PARTICLES_NUMBER  =  2000;
    // 粒子长度比例
    SPEED_RATE =  0.15;
    // 粒子分段最大段数
    MAX_AGE = 10;
    // 渐变比例
    BRIGHTEN =  1.5;
    //帧数数据
    FRAME_RATE = 300;
    //风场高度
    height = 1000;

    /**
     * @description: 加载风场
     * @return {*}
     */
    draw(){
        let that = this;
        const config:windyConfigType = {
            PARTICLES_NUMBER:this.PARTICLES_NUMBER,SPEED_RATE:this.SPEED_RATE,MAX_AGE:this.MAX_AGE,BRIGHTEN:this.BRIGHTEN,FRAME_RATE:this.FRAME_RATE,height:this.height
        }
        axios.get(this.dataUrl).then(ress=>{
            let _windy = new Windy(ress.data,that.viewer,config);
            _windy.draw();
            that._windy = _windy;
        })

    }
    remove(){
        if(this._windy){
            this._windy?.remove();
        }
    }
}
