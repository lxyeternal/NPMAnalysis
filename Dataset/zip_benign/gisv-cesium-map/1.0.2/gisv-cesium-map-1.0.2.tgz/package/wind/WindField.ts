/*
 * @Descripttion:
 * @version:
 * @Author: chenwei
 * @Date: 2021-06-03 16:58:18
 * @LastEditors: CarsonChe
 * @LastEditTime: 2021-07-06 17:12:30
 */
//define([],function () {

class WindField {
   private west: number|null;
    private east?: number|null;
   private  south?: number|null;
    private north?:number|null;
    private rows?:number|null;
    private cols?:number|null;
    private dx?:number|null;
    private dy?:number|null;
    private unit?: any;
    private date?: any;
    private grid?: any;
    constructor(obj:any) {
        this.west = null;
        this.east = null;
        this.south = null;
        this.north = null;
        this.rows = null;
        this.cols = null;
        this.dx = null;
        this.dy = null;
        this.unit = null;
        this.date = null;
        this.grid = null;
        this._init(obj);
    }
    //初始化每一个值
    private _init(obj:any) {
        var header = obj.header,
            uComponent = obj['uComponent'],
            vComponent = obj['vComponent'];

        this.west = +header['lo1'];
        this.east = +header['lo2'];
        this.south = +header['la2'];
        this.north = +header['la1'];
        this.rows = +header['ny'];
        this.cols = +header['nx'];
        this.dx = +header['dx'];
        this.dy = +header['dy'];
        this.unit = header['parameterUnit'];
        this.date = header['refTime'];
        this.grid = [];
        var k = 0,
            rows,
            uv;
        for (var j = 0; j < this.rows; j++) {
            rows = [];
            for (var i = 0; i < this.cols; i++, k++) {
                uv = this._calcUV(uComponent[k], vComponent[k]);
                rows.push(uv);
            }

            this.grid.push(rows);
        }
    }
    //计算速度向量
    private _calcUV(u:number, v:number) {
        return [+u, +v, Math.sqrt(u * u + v * v)];
    }

    //线性插值
    private _bilinearInterpolation(x:number, y:number, g00:number[], g10:number[], g01:number[], g11:number[]) {
        var rx = (1 - x);
        var ry = (1 - y);
        var a = rx * ry, b = x * ry, c = rx * y, d = x * y;
        var u = g00[0] * a + g10[0] * b + g01[0] * c + g11[0] * d;
        var v = g00[1] * a + g10[1] * b + g01[1] * c + g11[1] * d;
        return this._calcUV(u, v);
    }
    //获取
    private getIn(x:number, y:number) {
        var x0 = Math.floor(x),
            y0 = Math.floor(y),
            x1, y1;
        if (x0 === x && y0 === y) return this.grid[y][x];

        x1 = x0 + 1;
        y1 = y0 + 1;
        //获取4个点的分量
		let g00:any = this.getIn(x0, y0);
         let   g10:any = this.getIn(x1, y0);
         let   g01:any = this.getIn(x0, y1);
         let   g11:any = this.getIn(x1, y1);
        return this._bilinearInterpolation(x - x0, y - y0, g00, g10, g01, g11);
    }
    private isInBound(x:number, y:number) {
        if ((x >= 0 && x < this.cols! - 2) && (y >= 0 && y < this.rows !- 2)) return true;
        return false;
    }
};

//    return WindField;
//})
export default WindField;
