import * as React from "react";
import { Animated, NativeSyntheticEvent, NativeScrollEvent, FlatList } from "react-native";
import { ITab, ScrollEventHandler } from "./ScrollableTabView";
import { Ref, RefObject } from "react";
export interface IProps {
    headerOffset: number;
    activeTabKey: string;
    tabs: ITab[];
    renderTab: (params: {
        ref: Ref<{
            getNode: () => FlatList<any>;
        }>;
        tab: ITab;
        isActive: boolean;
        onScroll?: ScrollEventHandler;
        onScrollBeginDrag?: ScrollEventHandler;
        onScrollEndDrag?: ScrollEventHandler;
        onMomentumScrollEnd?: ScrollEventHandler;
    }) => JSX.Element;
    onTabChange: (params: {
        tab: ITab;
    }) => void;
    renderHeader: (params: {
        offsetY: Animated.AnimatedInterpolation;
    }) => JSX.Element;
}
export interface IState {
    parallaxOffsetValue: Animated.AnimatedInterpolation;
}
export declare class ParallaxScrollableTabView extends React.Component<IProps, IState> {
    parallaxOffset: number;
    tabRefs: Map<string, RefObject<{
        getNode: () => FlatList<any>;
    }>>;
    tabScrollOffsets: Map<string, number>;
    tabParallaxInterpolateLowerBounds: Map<string, number>;
    tabScrollOffsetValues: Map<string, Animated.Value>;
    constructor(props: IProps);
    generateParallaxOffsetValue(tabKey: string): Animated.AnimatedInterpolation;
    checkParallaxInterpolateLowerBound(tabKey: string, offsetY: number): void;
    updateParallaxInterpolateLowerBound(tabKey: string): void;
    onTabChange: ({ tab }: {
        tab: ITab;
    }) => void;
    synchronizeScrollOffsets(): void;
    onScroll: (tab: ITab) => (...args: any[]) => void;
    onScrollBeginDrag: ({ nativeEvent: { contentOffset: { y } } }: NativeSyntheticEvent<NativeScrollEvent>) => void;
    onScrollEndDrag: ({ nativeEvent: { contentOffset: { y } } }: NativeSyntheticEvent<NativeScrollEvent>) => void;
    onMomentumScrollEnd: ({ nativeEvent: { contentOffset: { y } } }: NativeSyntheticEvent<NativeScrollEvent>) => void;
    render(): JSX.Element;
}
