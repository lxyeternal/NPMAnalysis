import * as React from "react";
import { NativeSyntheticEvent, NativeScrollEvent } from "react-native";
export interface ITab {
    key: string;
    title: string;
}
export declare type ScrollEventHandler = (evt: NativeSyntheticEvent<NativeScrollEvent>) => void;
export interface IProps {
    activeTabKey: string;
    tabs: ITab[];
    renderTab: (params: {
        tab: ITab;
        isActive: boolean;
    }) => JSX.Element;
    onTabChange: (params: {
        tab: ITab;
    }) => void;
}
export declare class ScrollableTabView extends React.PureComponent<IProps> {
    onMomentumScrollEnd: ({ nativeEvent: { contentOffset: { x } } }: NativeSyntheticEvent<NativeScrollEvent>) => void;
    render(): JSX.Element;
}
