//Created by Idan Birman @ 2015

//core
function reduceFraction(n, d) {
    var output = 'error - division by 0';
    //handle positive/negative
    var mark = getSymbolForResult(n, d);
    if (mark === undefined) {
        mark = "";
    }
    n = Math.abs(n);
    d = Math.abs(d);
    var gcd = findGCD(n, d);

    n = n / gcd;
    d = d / gcd;
    if (n === 0) {
        if (d === 0) {
            throw `Error: Division by Zero`
        } else {
            output = 0;
        }
    } else if (d == 1) {
        output = n;

    } else {
        if (n < d) {
            output = n + "/" + d;
        }
    }
    if (n > d) {
        output = handleReducedFractionBiggerThanOne(n, d);
    }
    //handle 0
    if (d === 0) {
        throw `Error: Division by Zero`;
    } else if (n === 0) {
        return "0";
    } else {
        if (output === undefined) {
            output = 0;
        }
        if (output === 'error - division by 0') {
            throw `Error: Division by Zero`;
        }
        return mark + output;
    }
}


function findGCD(numerator, denominator) {
    var gcd = function gcd(a, b) {
        return b ? gcd(b, a % b) : a;
    };
    gcd = gcd(numerator, denominator);
    return gcd;
}

function handleReducedFractionBiggerThanOne(n, d) {
    var newNumerator, output;
    newNumerator = n % d;
    if (newNumerator === 0) {
        output = n / d;
    } else {
        output = parseInt(n / d + "") + " " + newNumerator + "/" + d;
    }
    return output;
}

//decimal to frac
function decimalToFraction(decimal) {
    var mark = getSymbolForResult(decimal, 1);
    decimal = Math.abs(decimal);
    if (decimal % 1 === 0) {
        return decimal;
    }
    var preFloat, postFloat, numString, output;
    var outputArr = [];
    numString = decimal.toString();
    var arr = numString.split(".");
    preFloat = parseInt(arr[0]);
    postFloat = parseInt(arr[1]);

    var denominator, numerator;
    denominator = 1;
    numerator = postFloat;
    var denStr = "1";
    for (var i = numerator.toString().length; i > 0; i--) {
        denStr = denStr + "0";
    }
    denominator = parseInt(denStr);
    if (preFloat === 0) {
        output = reduceFraction(numerator, denominator);
        outputArr.push(numerator, denominator);
    } else {
        output = reduceFraction((preFloat * denominator + numerator), denominator);
        outputArr.push((preFloat * denominator + numerator), denominator);
    }
    var res = mark + output;
    if (res === "NaN") { throw "Error: Failed to Convert Decimal to Fraction" }
    return res;
}

function getSymbolForResult(n, d) {
    var output;
    if ((n < 0 && d < 0) || (n > 0 && d > 0)) {
        output = false;
    }

    //final result is negative
    else if ((n < 0 && d > 0) || (n > 0 && d < 0)) {
        output = true;
    }
    if (output) {
        return "-";
    } else {
        return "";
    }
}

//frac to decimal
function fractionToDecimal(fraction) {
    var output;
    var arr = fraction.split(" ");
    try {
        if (arr[1] === undefined) {
            // < 1
            output = eval(arr[0] + "");
        } else {
            output = eval(arr[1]) + eval(arr[0]);

        }
    } catch (error) {
        console.log("eval failure: " + error);
    }
    return output;
}


function convertFractionToNaturalForm(fraction) {
    var arr = (fraction + "").split(" "),
        output;
    if (arr[1] === undefined) {
        output = fraction;
    } else {
        var arrND = (arr[1] + "").split("/");
        var n = parseInt(arrND[0]);
        var d = parseInt(arrND[1]);
        n = n + parseInt(arr[0]) * d;
        output = n + "/" + d;
    }
    return output;
}

function convertFractionToSimpleForm(fraction) {
    var arr = (fraction + "").split("/"), n, d;
    n = parseInt(arr[0]);
    d = parseInt(arr[1]);
    return reduceFraction(n, d);
}

function numerator(NaturalFraction) {
    var arr = (NaturalFraction + "").split("/");
    return parseInt(arr[0]);
}

function denominator(NaturalFraction) {
    var arr = (NaturalFraction + "").split("/");
    return parseInt(arr[1]);
}


function identify(numStr) {
    var identified = false;
    numStr = numStr + "";
    if (numStr.indexOf("-") != -1) {
        numStr = numStr.replace("-", "");
    }
    var output;
    if (numStr.indexOf(".") != -1) {
        identified = true;
        output = 0;
        // console.log("fractions.identify(): ["+numStr+"] is a decimal(0)");
        //decimal
    }
    if (numStr.indexOf(" ") != -1 && numStr.indexOf("/") != -1) {
        identified = true;
        output = 1;
        // console.log("fractions.identify(): ["+numStr+"] is a simplified fraction (finalized)(1)");
        // simplified fraction
    }
    if (numStr.indexOf(" ") == -1 && numStr.indexOf("/") != -1) {
        identified = true;
        output = 2;
        // console.log("fractions.identify(): ["+numStr+"] is a natural fraction (preped)(2)");
        // natural fraction
    }
    if (numStr.indexOf("/") == -1 && numStr.indexOf(".") == -1) {
        //used to be in the if: numStr.indexOf(" ") == -1 &&
        identified = true;
        output = 3;
        // console.log("fractions.identify(): ["+numStr+"] is an integer(3)");
        //integer
    }

    if (!identified) {
        output = 4;
        throw "Error: failed to identify the input [" + numStr + "](4)";
    }

    return output;
}

function validate(numStr) { //validate input
    if (identify(numStr) == 4) {
        return false;
    }
    else {
        return true;
    }
}
//convert any number string to natural form
function prep(numStr) {
    var type = identify(numStr),
        output, mark = "";
    if ((numStr + "").indexOf("-") != -1) {
        numStr = (numStr + "").replace("-", "");
        mark = "-";
    }
    switch (type) {
        case 0:
            output = mark + convertFractionToNaturalForm(decimalToFraction(parseFloat(numStr)));
            break;

        case 1:
            output = mark + convertFractionToNaturalForm(numStr);
            break;

        case 2:
            output = mark + numStr;
            break;

        case 3:
            output = mark + numStr + "/1";
            break;


    }
    return output;
}

// convert any number string to simple form
function finalize(numStr) {
    var output;
    if (identify(numStr) === 0) {
        output = decimalToFraction(numStr);
    } else {
        var naturalForm = prep(numStr + "");
        var arr = (naturalForm + "").split("/");
        output = reduceFraction(arr[0], arr[1]);
    }
    return output;
}
//+ - * /


function addFractions(first, second) {
    var n, d;
    d = denominator(first) * denominator(second);
    n = numerator(first) * denominator(second) + numerator(second) * denominator(first);
    return reduceFraction(n, d);
}

function subtractFractions(first, second) {
    var n, d;
    d = denominator(first) * denominator(second);
    n = numerator(first) * denominator(second) - numerator(second) * denominator(first);
    return reduceFraction(n, d);

}

function multiplyFractions(first, second) {
    var n, d;
    n = numerator(first) * numerator(second);
    d = denominator(first) * denominator(second);
    return reduceFraction(n, d);
}

function divideFractions(first, second) {
    var n, d;
    n = numerator(first) * denominator(second);
    d = denominator(first) * numerator(second);
    return reduceFraction(n, d);
}

function compareFractions(first, second) {
    var a, b, aN, bN, aD, bD;
    a = prep(first);
    b = prep(second);
    aN = numerator(a);
    aD = denominator(a);
    bN = numerator(b);
    bD = denominator(b);
    aN = aN * bD;
    bN = bN * aD;
    if (parseInt(aN) > parseInt(bN)) {
        return finalize(a);
    } else if (parseInt(aN) < parseInt(bN)) {
        return finalize(b);
    } else {
        return "e";
    }

}
// to be used in implementation

function addF(firstNumStr, SecondNumStr) {
    return addFractions(prep(firstNumStr), prep(SecondNumStr));
}

function subF(firstNumStr, SecondNumStr) {
    return subtractFractions(prep(firstNumStr), prep(SecondNumStr));
}

function multF(firstNumStr, SecondNumStr) {
    return multiplyFractions(prep(firstNumStr), prep(SecondNumStr));
}

function divdF(firstNumStr, SecondNumStr) {
    return divideFractions(prep(firstNumStr), prep(SecondNumStr));
}

function squaredF(numStr) {
    return finalize(multF(numStr, numStr));
}


function powerF(numStr, power) {
    var output, a, b, c, d, N, D;
    if ((power + "").indexOf("-") != -1) {
        power = (power + "").replace("-", "");
        numStr = divdF(1, numStr);
    }
    a = parseInt(numerator(prep(numStr)) + ""); // numerator of base
    b = parseInt(denominator(prep(numStr)) + ""); // denominator of base
    c = parseInt(numerator(prep(power)) + ""); // numerator of power
    d = parseInt(denominator(prep(power)) + ""); // denominator of  power

    N = Math.pow(Math.pow(a, c), 1 / d); // numerator of base raised by power
    D = Math.pow(Math.pow(b, c), 1 / d); // denominator of base raised by power

    //check if rational or not
    if (Math.pow(a, 1 / d) % 1 === 0 && Math.pow(b, 1 / d) % 1 === 0) {
        output = divdF(N, D);
    } else {
        output = N / D;
        console.log('fractions.powerF(): ' + numStr + '^' + power + ' is not a rational number, so an approximation was returned');
    }
    //handle negative base under even root

    if (identify(output) == 4) {
        output = "Math Error";
    }

    //experimental fix to 0^0
    if (isEqualF(b, '0') || isEqualF(d, '0')) {
        output = "Math Error";
    }

    if (output === "Math Error") {
        throw "Math Error: Raising [" + numStr + "] to the power of [" + power + "]";
    }
    return output;
}


function sqrtF(numStr) {
    return powerF(numStr, 0.5);
}

function compareF(firstNumStr, seconfNumStr) {
    //returns the bigger of 2 fractions, if equal, returns 'e'
    return compareFractions(firstNumStr, seconfNumStr);
}

function isEqualF(firstNumStr, seconfNumStr) {
    if (compareF(firstNumStr, seconfNumStr) == "e") {
        return true;
    } else {
        return false;
    }
}

function smallerF(firstNumStr, secondNumStr) {
    //this does the opposite of what i think it needs to do and i don't know why
    var bigger = compareF(firstNumStr, secondNumStr);
    if (isEqualF(bigger, firstNumStr)) {
        return finalize(secondNumStr);
    } else {
        return finalize(firstNumStr);
    }
}

function biggerF(firstNumStr, secondNumStr) {
    let res = compareF(firstNumStr, secondNumStr);
    if (res === 'e') {
        return smallerF(firstNumStr, secondNumStr);
    } else {
        return res;
    }
}


function percentF(fraction, appendSymbol) {
    //return a ratio as a percent (1/4 should return 25, set appendSymbol as true and it becomes 25%)
    if (appendSymbol === undefined) {
        appendSymbol = false;
    }
    var frac = prep(fraction);
    var symbol = "";
    if (appendSymbol) {
        symbol = "%";
    }
    return divdF(multF(100, numerator(frac)), denominator(frac)) + symbol;
}

function piRadiansToDegreesF(frac, appendDegreesChar) {
    //converts (num)*pi radians to degrees
    if (appendDegreesChar === undefined) {
        appendDegreesChar = false;
    }

    var fraction = prep(frac);
    var n = numerator(fraction);
    var d = denominator(fraction);
    if (!appendDegreesChar) {
        return divdF(multF(n, 180), d);
    } else {
        return divdF(multF(n, 180), d) + "°";
    }

}

function absoluteF(fraction) {
    var frac = prep(fraction);
    if (smallerF(frac, 0) === 0) {
        return finalize(frac);
    } else {
        return finalize(multF(frac, -1));
    }
}

function altFormsF(numStr) {
    //returns an array containing 2 n/d and a.b for fracs < 1 and these 2 + w n/d for fracs > 1
    var outputArr = [];
    if (identify(finalize(numStr)) == 3) {
        return [numStr];
    }
    outputArr.push(fractionToDecimal(prep(numStr)));
    outputArr.push(prep(numStr));
    outputArr.push(finalize(numStr));

    if (outputArr[1] == outputArr[2]) {
        outputArr.pop();
    }
    return outputArr;
}



//**********
//HTML
//**********

//nasty, messy code:
function generateMathMLMarkup(numStr) {
    //handle 0
    if (numStr == "0") {
        return "<math><mn>0</mn></math>";
    }
    //handle negatives
    var mark = "";
    if ((numStr + "").indexOf("-") != -1) {
        numStr = numStr.replace("-", "");
        mark = "<math><mo>-</mo></math>";
    }
    var frac = finalize(numStr),
        htmlText, n, d, w, bigger = true;
    //smaller than 1
    if (compareF(frac, 1) == "1") {
        bigger = false;
        frac = prep(frac);
        n = numerator(frac) + "";
        d = denominator(frac) + "";
        htmlText = "<math><mfrac><mrow><mn>" + n + "</mn></mrow><mn>" + d + "</mn></mfrac></math>";
    }

    //integer (whole)
    if (identify(frac) == 3) {
        htmlText = "<math><mn>" + frac + "</mn></math>";
    } else if (compareF(frac, 1) != "e" && compareF(frac, 1) != "1") {
        frac = finalize(frac);

        if (identify(frac) == 2) {
            //overkill to handle a dodgy bug
            frac = finalize(frac);
            frac = reduceFraction(numerator(frac), denominator(frac));

        }
        var arr = (frac + "").split(" ");
        w = arr[0];
        var arr_two = (arr[1] + "").split("/");
        n = arr_two[0] + "";
        d = arr_two[1] + "";
        htmlText = "<math><mn>" + w + "</mn><mfrac><mrow><mn>" + n + "</mn></mrow><mn>" + d + "</mn></mfrac></math>";
    }
    return mark + htmlText;
}

function generateMathMLMarkupForPrep(numStr) {
    //handle 0
    if (isEqualF(prep(numStr), 0)) {
        return "<math><mn>0</mn></math>";
    }
    //handle negatives
    var mark = "";
    if ((numStr + "").indexOf("-") != -1) {
        numStr = numStr.replace("-", "");
        mark = "<math><mo>-</mo></math>";
    }
    var frac = prep(numStr);
    var N = numerator(frac);
    var D = denominator(frac);
    var htmlText;
    //handle integers
    if (identify(finalize(frac)) == 3) {
        htmlText = mark + "<math><mn>" + finalize(frac) + "</mn></math>";
    } else {
        htmlText = mark + "<math><mfrac><mrow><mn>" + N + "</mn></mrow><mn>" + D + "</mn></mfrac></math>";
    }

    return htmlText;

}

//return the original numStr as well as the mathml
function generateMathMLandReturnOriginal(numStr) {
    //handle 0
    if (numStr == "0") {
        return "<math><mn>0</mn></math>";
    }
    //handle negatives
    var mark = "";
    if ((numStr + "").indexOf("-") != -1) {
        numStr = numStr.replace("-", "");
        mark = "<math><mo>-</mo></math>";
    }
    var frac = finalize(numStr),
        htmlText, n, d, w, bigger = true;
    //smaller than 1
    if (compareF(frac, 1) == "1") {
        bigger = false;
        frac = prep(frac);
        n = numerator(frac) + "";
        d = denominator(frac) + "";
        htmlText = "<math><mfrac><mrow><mn>" + n + "</mn></mrow><mn>" + d + "</mn></mfrac></math>";
    }

    //integer (whole)
    if (identify(frac) == 3) {
        htmlText = "<math><mn>" + frac + "</mn></math>";
    } else if (compareF(frac, 1) != "e" && compareF(frac, 1) != "1") {
        frac = finalize(frac);

        if (identify(frac) == 2) {
            //overkill to handle a dodgy bug
            frac = finalize(frac);
            frac = reduceFraction(numerator(frac), denominator(frac));

        }
        var arr = (frac + "").split(" ");
        w = arr[0];
        var arr_two = (arr[1] + "").split("/");
        n = arr_two[0] + "";
        d = arr_two[1] + "";
        htmlText = "<math><mn>" + w + "</mn><mfrac><mrow><mn>" + n + "</mn></mrow><mn>" + d + "</mn></mfrac></math>";
    }

    var finalArr = [mark + htmlText, prep(numStr)];
    return finalArr;
}

// reverse

function reverseMathML(html) {
    var output;
    var str = html + "";
    var numsArr = [];
    var numsCount = 0;
    var strChain = "";
    var isNegative = false;
    for (var i = 0; i < str.length; i++) {
        if (!isNegative && str.charAt(i) == "-") {
            isNegative = true;
        }
        if (!isNaN(str.charAt(i))) {
            //char is number
            numsCount++;
            strChain = strChain + str.charAt(i);
        } else {
            if (strChain !== "") {
                numsArr.push(strChain);
            }
            strChain = "";
            numsCount = 0;
        }

    }

    switch (numsArr.length) {
        case 1:
            output = numsArr[0];

            break;
        case 2:
            output = divdF(numsArr[0], numsArr[1]);
            break;

        case 3:
            output = divdF(addF(multF(numsArr[0], numsArr[2]), numsArr[1]), numsArr[2]);
            break;

        default:
            return "error";

    }
    if (isNegative) {
        output = "-" + output;
    }
    return output;

}

// exports

module.exports = {
    add: addF,
    subtract: subF,
    multiply: multF,
    divide: divdF,
    power: powerF,
    sqrt: sqrtF,
    isEqual: isEqualF,
    smaller: smallerF,
    bigger: biggerF,
    asPercentage: percentF,
    piRadiansToDegrees: piRadiansToDegreesF,
    absolute: absoluteF,
    allForms: altFormsF,
    toMathML: generateMathMLMarkup,
    fromMathML: reverseMathML
}

