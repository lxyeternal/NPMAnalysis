# easyfracs

easyfracs helps you to handle and perform operations on rational numbers (fractions) easily and efficiently by representing them as strings. 


# Usage

    const fracs = require("easyfracs");


## Acceptable Input Forms
Fractions must be represented like one of the following examples:

    let acceptableFractionForms = [-1.5, 1.5, '-1 1/2', '1 1/2', '3/2', '-3/2'];

Integers are also accepted.

> **DO NOT** put a space between the minus sign and the fraction, e.g:

    let bad = '- 1 1/2'; // this will cause errors


## Arithmetic Operations


### Add

    fracs.add('2/5','5/7'); // '1 4/35'
    
###  Subtract

    fracs.subtract('2/5','5/7'); // '-11/35'

### Multiply

    fracs.multiply(0.4,'5/7'); // '2/7' 

### Divide

    fracs.divide('2/5','5/7'); // '14/25'

### Power

    fracs.power('2/5','5/7'); // raise 2/5 to the power of 5/7
    
because the result of this expression is not a rational number, an approximation is returned:

    0.5197052890437639
another example:

    fracs.power('2/5', 2); // raise 2/5 to the power of 2

this time, the result of the expression can be represented as a fraction so it is returned:

    '4/25'

### Square Root

    fracs.sqrt('4/25'); // '2/5'

this is shorthand for:

    fracs.power('4/25',0.5);
and as such, if the result is irrational, an approximation is returned.

## Equality & Comparison

### Equals 

checks if two fractions are equal

    fracs.isEqual('1/2',0.5); // true
    fracs.isEqual('1/2','1/2'); // true
    fracs.isEqual(2,'200/100'); // true
    fracs.isEqual('1/2','2/3'); // false

### Bigger

returns the bigger fraction

    fracs.bigger('23/45','57/110'); // 57/110
    fracs.bigger('23/45','-57/110'); // 23/45
	fracs.bigger('23/45','23/45'); // 23/45

### Smaller

returns the smaller fraction

    fracs.smaller('23/45','57/110'); // 23/45
    fracs.smaller('23/45','-57/110'); // -57/110
	fracs.smaller('23/45','23/45'); // 23/45

## Other

### Percentage

returns the fraction as a percentage

	fracs.asPercentage('5/8'); // '62 1/2'

A second, boolean argument can be passed to tell the function wether or not a percentage sign should be appended as a suffix, like so:

	fracs.asPercentage('5/8',true); // '62 1/2%'

> **DO NOT** pass a fraction with a percentage sign suffix to any other easyfracs function.

### Pi Radians to Degrees

the following call will return 0.25*pi radians in degrees:

	fracs.piRadiansToDegrees('1/4'); // 45

Similarly to `asPercentage()`, passing `true` as a second argument will tell the function to append a degree symbol as a suffix, like so:

	fracs.piRadiansToDegrees('1/4',true); // '45°'

> **DO NOT** pass a fraction with a degrees sign suffix to any other easyfracs function.


### Absolute

Similar to `Math.abs()`, returns the distance of the fraction from `0` on the Number Line:

	fracs.absolute('-23 56/78'); //returns '23 56/78'
	fracs.absolute('23 56/78'); //returns '23 56/78'

### All Forms

returns an array with all possible forms of notation for the input fraction

	fracs.allForms('12'); // [12]
	fracs.allForms('1/3'); // [ 0.3333333333333333, '1/3' ]
	fracs.allForms(0.4); // [ 0.4, '2/5' ]
	fracs.allForms(-13.4); // [ -13.4, '-67/5', '-13 2/5' ]
	fracs.allForms('17/2'); // [ 8.5, '17/2', '8 1/2' ]


## MathML 

Special tags that allow mathematical formulas and notations to be written on web pages.

Currently only supported in Firefox and Safari. [(caniuse)](https://caniuse.com/#feat=mathml)

the call 

    fracs.toMathML('1/4');

returns markup that when injected into a HTML element results in a properly rendered fraction on supported browsers. 

it is also possible to convert MathML back to a string representation of a fraction like so:

	let markup = fracs.toMathML('1/4'); // stores the markup string in a variable
	fracs.fromMathML(markup); // '1/4';
> it's recommended to avoid using `fromMathML()` if possible.

> both `toMathML()` and `fromMathML()` can only accept a single fraction as a parameter!
