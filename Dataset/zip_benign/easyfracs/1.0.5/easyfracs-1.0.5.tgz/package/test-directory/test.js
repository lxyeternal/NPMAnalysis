const fracs = require('easyfracs');

let res = fracs.allForms('17/2');

console.log(res);
