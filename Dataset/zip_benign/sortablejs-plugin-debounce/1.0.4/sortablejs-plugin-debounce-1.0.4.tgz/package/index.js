import DebouncePlugin from "./lib/plugin";
export { DebouncePlugin as default, DebouncePlugin };
