import { PlanetView } from './Planet.view';
import type { PlanetProps } from './Planet.types';
export { PlanetView };
export type { PlanetProps };
//# sourceMappingURL=index.d.ts.map