import { type ImageSourcePropType } from 'react-native';
export declare function convertTextureProp(texture?: ImageSourcePropType): string | undefined;
//# sourceMappingURL=texture.d.ts.map