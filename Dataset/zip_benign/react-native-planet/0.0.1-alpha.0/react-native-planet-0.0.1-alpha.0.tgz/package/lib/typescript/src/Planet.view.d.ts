/// <reference types="react" />
import type { PlanetProps } from './Planet.types';
export declare const PlanetView: (props: PlanetProps) => JSX.Element;
//# sourceMappingURL=Planet.view.d.ts.map