# react-native-planet

Create your own planet using React Native

https://github.com/mateoguzmana/react-native-planet/assets/20783123/e52b5f84-8b9a-4f3e-971b-33c98d0a2d24

## Installation

```sh
npm install react-native-planet
```

## Usage

```js
import { PlanetView } from 'react-native-planet';

// ...

<PlanetView
  sceneBackgroundColor="#000000"
  // You can use either a remote url or a local image
  // texture={require('./assets/your_local_texture.jpg')}
  texture={{
    uri: 'https://eoimages.gsfc.nasa.gov/images/imagerecords/144000/144898/BlackMarble_2016_01deg.jpg',
  }}
  showsStatistics
  allowsCameraControl
  rotationDuration={60}
  bloom={{ intensity: 0.5, radius: 100 }}
/>
```

## Contributing

See the [contributing guide](CONTRIBUTING.md) to learn how to contribute to the repository and the development workflow.

## License

MIT

---

Made with [create-react-native-library](https://github.com/callstack/react-native-builder-bob)
