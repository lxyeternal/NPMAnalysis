//
//  PlanetNode.swift
//  react-native-planet
//
//  Created by Mateo Guzmán on 17/12/2023.
//
import SceneKit
import SwiftUI

class PlanetNode: SCNNode {
    private var rotationDuration: TimeInterval = 50

    override init() {
        super.init()
        self.geometry = SCNSphere(radius: 1)
        self.geometry?.firstMaterial?.shininess = 50

        self.runDefinedAction()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    private func runDefinedAction() {
        let action = SCNAction.rotate(by: 360 * CGFloat(Double.pi / 180), around: SCNVector3(x: 0, y: 1, z:0), duration: rotationDuration)
        let repeatAction = SCNAction.repeatForever(action)

        self.runAction(repeatAction)
    }

    private func loadImageAsync(url: URL, completion: @escaping (UIImage?) -> ()) {
        DispatchQueue.global().async {
            let data = try? Data(contentsOf: url)
            DispatchQueue.main.async {
                completion(data.flatMap(UIImage.init))
            }
        }
    }

    public func addBloom(options: NSDictionary) {
        let intensity = options["intensity"] as? NSNumber
        let radius = options["radius"] as? NSNumber
        let bloomFilter = CIFilter(name:"CIBloom")!

        if let intensity = intensity {
            bloomFilter.setValue(intensity, forKey: "inputIntensity")
        }

        if let radius = radius {
            bloomFilter.setValue(radius, forKey: "inputRadius")
        }

        self.filters = [bloomFilter]
    }

    public func overwriteTextureAndReapplyAction(url: String) {
        self.loadImageAsync(url: URL(string: url)!) { image in
            self.geometry?.firstMaterial?.diffuse.contents = image
            self.geometry?.firstMaterial?.specular.contents = image
            self.geometry?.firstMaterial?.emission.contents = image
            self.geometry?.firstMaterial?.normal.contents = image
        }
    }

    public func updateRotationDuration(_ duration: TimeInterval) {
        rotationDuration = duration

        self.removeAllActions()
        self.runDefinedAction()
    }
}
