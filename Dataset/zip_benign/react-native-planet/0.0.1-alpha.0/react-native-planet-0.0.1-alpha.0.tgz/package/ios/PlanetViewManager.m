#import <React/RCTViewManager.h>

@interface RCT_EXTERN_MODULE(PlanetViewManager, RCTViewManager)

RCT_EXPORT_VIEW_PROPERTY(sceneBackgroundColor, NSString)
RCT_EXPORT_VIEW_PROPERTY(texture, NSString)
RCT_EXPORT_VIEW_PROPERTY(showsStatistics, BOOL)
RCT_EXPORT_VIEW_PROPERTY(allowsCameraControl, BOOL)
RCT_EXPORT_VIEW_PROPERTY(rotationDuration, NSNumber)
RCT_EXPORT_VIEW_PROPERTY(bloom, NSDictionary)

@end
