import UIKit
import SceneKit
import React

@objc(PlanetViewManager)
class PlanetViewManager: RCTViewManager {

  override func view() -> UIView! {
    let planetView = PlanetView()
    createPlanet(sceneView: planetView.sceneView)

    return planetView
  }

  @objc override static func requiresMainQueueSetup() -> Bool {
    return false
  }
    
  func createPlanet(sceneView: SCNView) {
    let scene = SCNScene()
    
    let cameraNode = SCNNode()
    cameraNode.camera = SCNCamera()
    cameraNode.position = SCNVector3(x: 0, y: 0, z: 5)
    scene.rootNode.addChildNode(cameraNode)
    
    let lightNode = SCNNode()
    lightNode.light = SCNLight()
    lightNode.light?.type = .omni
    lightNode.position = SCNVector3(x: 0, y: 10, z: 2)
    scene.rootNode.addChildNode(lightNode)
    
    let planetNode = PlanetNode()

    scene.rootNode.addChildNode(planetNode)
    
    sceneView.scene = scene
  }
}

class PlanetView: UIView {
    var sceneView: SCNView!

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSceneView()
        addSubview(sceneView)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupSceneView() {
        sceneView = SCNView(frame: bounds)
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    }

    @objc var sceneBackgroundColor: String = "" {
        didSet {
          self.sceneView.backgroundColor = hexStringToUIColor(hexColor: sceneBackgroundColor)
        }
    }

    @objc var texture: String = "" {
        didSet {
            let planetNode = getPlanetNode()

            if let planetNode = planetNode {
                planetNode.overwriteTextureAndReapplyAction(url: texture)
             }
          }
    }

    @objc var showsStatistics: Bool = false {
        didSet {
            self.sceneView.showsStatistics = showsStatistics
        }
    }

    @objc var allowsCameraControl: Bool = false {
        didSet {
            self.sceneView.allowsCameraControl = allowsCameraControl
        }
    }

    @objc var rotationDuration: NSNumber = 50 {
        didSet {
            let planetNode = getPlanetNode()

            if let planetNode = planetNode {
                planetNode.updateRotationDuration(TimeInterval(rotationDuration))
             }
        }
    }

    @objc var bloom: NSDictionary? = nil {
        didSet {
            let planetNode = getPlanetNode()

            if let planetNode = planetNode {
                if let bloom = bloom {
                    planetNode.addBloom(options: bloom)
                }
             }
        }
    }

    private func getPlanetNode() -> PlanetNode? {
        if let scene = self.sceneView.scene {
            for (_, childNode) in scene.rootNode.childNodes.enumerated() {
                     if let planetNode = childNode as? PlanetNode {
                         return planetNode
                     }
                 }
             }
        
        return nil
    }

    func hexStringToUIColor(hexColor: String) -> UIColor {
        let stringScanner = Scanner(string: hexColor)

        if hexColor.hasPrefix("#") {
            stringScanner.scanLocation = 1
        }
        var color: UInt32 = 0
        stringScanner.scanHexInt32(&color)

        let r = CGFloat(Int(color >> 16) & 0x000000FF)
        let g = CGFloat(Int(color >> 8) & 0x000000FF)
        let b = CGFloat(Int(color) & 0x000000FF)

        return UIColor(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: 1)
    }
}
