package com.planet

import android.graphics.Color
import android.view.View
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.annotations.ReactProp
import android.util.Log
import android.app.Activity
import org.rajawali3d.view.SurfaceView
import org.rajawali3d.primitives.Sphere
import org.rajawali3d.materials.Material
import org.rajawali3d.materials.textures.Texture
import org.rajawali3d.math.vector.Vector3
import org.rajawali3d.renderer.Renderer
import android.view.MotionEvent
import org.rajawali3d.materials.textures.ATexture
import java.net.URL
import kotlin.io.readBytes

class PlanetViewManager : SimpleViewManager<View>() {
    override fun getName() = "PlanetView"

    override fun createViewInstance(reactContext: ThemedReactContext): SurfaceView {
         val surfaceView = SurfaceView(reactContext)
         surfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0)
         surfaceView.setSecure(true)

        val renderer = PlanetRenderer(reactContext)
        surfaceView.setSurfaceRenderer(renderer)

        return surfaceView
    }

    @ReactProp(name = "sceneBackgroundColor")
    fun setColor(view: View, sceneBackgroundColor: String) {
        Log.d("PlanetViewManager", "setColor: $sceneBackgroundColor")
        // view.setBackgroundColor(Color.parseColor(sceneBackgroundColor))
        // set purple
        // view.setBackgroundColor(Color.parseColor("#800080"))
    }
}

class PlanetRenderer(reactContext: ThemedReactContext) : Renderer(reactContext) {
  private lateinit var sphere: Sphere

  override fun onRender(elapsedRealtime: Long, deltaTime: Double) {
    super.onRender(elapsedRealtime, deltaTime)

    if (!isSceneInitialized) {
      initScene()
      isSceneInitialized = true
    }
  }

  override fun onOffsetsChanged(
    xOffset: Float,
    yOffset: Float,
    xOffsetStep: Float,
    yOffsetStep: Float,
    xPixelOffset: Int,
    yPixelOffset: Int
  ) {
    Log.d("PlanetRenderer", "onOffsetsChanged: $xOffset, $yOffset, $xOffsetStep, $yOffsetStep, $xPixelOffset, $yPixelOffset")
  }

  private var previousX: Float = 0f
    private var previousY: Float = 0f

    override fun onTouchEvent(event: MotionEvent?) {
        Log.d("PlanetRenderer", "onTouchEvent: $event")
        if (event != null) {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    previousX = event.x
                    previousY = event.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX: Float = event.x - previousX
                    val deltaY: Float = event.y - previousY

                    // Adjust rotation based on touch input
                    sphere.rotate(Vector3.Axis.Y, deltaX * 0.5)
                    sphere.rotate(Vector3.Axis.X, deltaY * 0.5)

                    previousX = event.x
                    previousY = event.y
                }
            }
        }
    }

  override fun initScene() {
    try {
        sphere = Sphere(1f, 24, 24)
        sphere.setPosition(Vector3(0.0, 0.0, 0.0))

        val material = Material()
        material.setColor(Color.BLUE)

        val url = URL("https://web.cortland.edu/flteach/civ/davidweb/images/fullmapb.jpg")
        val bytes = url.readBytes()
        val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

        val texture = Texture("earth", bitmap)
        texture.setFilterType(ATexture.FilterType.NEAREST)

        material.addTexture(texture)

        sphere.material = material

        currentScene.addChild(sphere)
        currentCamera.setPosition(Vector3(0.0, 0.0, 5.0))

        Log.d("PlanetRenderer", "initScene: $currentScene")
    } catch (e: Exception) {
        Log.d("PlanetRenderer", "initScene: $e")
    }
  }

  private var isSceneInitialized = false
}
