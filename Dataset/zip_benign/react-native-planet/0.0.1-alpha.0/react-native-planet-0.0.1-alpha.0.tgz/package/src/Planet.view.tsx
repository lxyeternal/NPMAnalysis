import React from 'react';
import { requireNativeComponent, UIManager, Platform } from 'react-native';
import type { PlanetProps } from './Planet.types';
import { convertTextureProp } from './utils/texture';

const LINKING_ERROR =
  `The package 'react-native-planet' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';

const ComponentName = 'PlanetView';

const InternalPlanetView =
  UIManager.getViewManagerConfig(ComponentName) != null
    ? requireNativeComponent<PlanetProps>(ComponentName)
    : () => {
        throw new Error(LINKING_ERROR);
      };

export const PlanetView = (props: PlanetProps) => {
  return (
    <InternalPlanetView
      {...props}
      // @ts-expect-error in the native side we just get the uri, but on the API we want to expose the full image source prop type
      texture={convertTextureProp(props?.texture)}
    />
  );
};
