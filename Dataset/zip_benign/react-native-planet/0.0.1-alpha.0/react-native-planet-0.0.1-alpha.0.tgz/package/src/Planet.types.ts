import type { ImageSourcePropType, ViewStyle } from 'react-native';

interface Bloom {
  intensity?: number;
  radius?: number;
}

export interface PlanetProps {
  /**
   * Background color of the planet scene
   */
  sceneBackgroundColor?: string;
  /**
   * Texture of the planet. Could be an http address or a
   * resource (which should be wrapped in the `require('./path/to/image.png')`
   */
  texture?: string | ImageSourcePropType;
  /**
   * Style of the planet container
   */
  style?: ViewStyle;
  /**
   * Controls whether the planet scene should display statistics information.
   */
  showsStatistics?: boolean;
  /**
   * Controls whether the planet can be rotated by a two-finger twist gesture.
   */
  allowsCameraControl?: boolean;
  /**
   * Duration of the planet rotation animation
   */
  rotationDuration?: number;
  /**
   * Applies a bloom filter to the planet.
   */
  bloom?: Bloom;
}
