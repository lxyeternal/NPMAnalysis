import { Image, type ImageSourcePropType } from 'react-native';

export function convertTextureProp(texture?: ImageSourcePropType) {
  if (!texture) return undefined;

  return Image.resolveAssetSource(texture).uri;
}
