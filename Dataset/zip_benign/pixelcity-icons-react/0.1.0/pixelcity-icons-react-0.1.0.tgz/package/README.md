# pixelCityIcons

## Getting Started

Install PixelCity Icons,

```bash
$ npm i pixelcity-icons-react
```

Import them,

```Javascript
import { Dog,Elephant,Hedgehog,Rat } from 'pixelcity-icons-react';
```

Use them in your code,

```Javascript
      <Dog size="176px"/>
      <Elephant size="176px"/>
      <Rat size="176px"/>
      <Hedgehog size="176px"/>
```

Advanced

```Javascript
    <Dog size="56px" scale={0.9} offsetY={7}/>
    <Elephant size="56px" scale={.9} offsetY={6}/>
    <Hedgehog size="56px" scale={1.1} offsetX={0.5} offsetY={6}/>
    <Rat size="56px" scale={1.2} offsetY={1}/>
    <Hog size="56px" offsetX={-2} offsetY={4}/>
    <Rabbit size="56px" offsetY={8}/>
    <Squirrel size="56px" offsetY={4}/>
```