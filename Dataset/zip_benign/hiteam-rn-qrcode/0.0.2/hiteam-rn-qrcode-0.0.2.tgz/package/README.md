# hiteam-rn-qrcode
a small barcode scanner component for React Native@0.49<br/>
1.<h3>说明</h3>
修复了react-native新版本中不在支持propTypes及navigator属性的问题<br/>
本组件为扫描二维码,条形码组件适用于react-native@0.4以上版本；<br/>
此组件是基于<a href='https://github.com/react-native-component/react-native-smart-barcode'>react-native-smart-barcode</a>进行了升级,对此提出万分感谢。其中并没有大的改动，只是原组件很久没人进行维护已经不再适用目前的RN0.4以上的版本。<br/>
支持android及ios端。<br/>
只有在窗口内才能有效扫描解决了部分组件全屏都能扫描的问题<br/>
<h3>Thanks</h3>
<a href='https://github.com/react-native-component/react-native-smart-barcode'>react-native-smart-barcode</a><br/>
<a href='https://github.com/zxing/zxing'>https://github.com/zxing/zxing</a>
