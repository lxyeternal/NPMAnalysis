window.onwheel = function(e) {
  let scrollUp = e.deltaY < 0;

  if(scrollUp) onScrollUp()
  else onScrollDown()
};

function onScrollUp() {
  console.log('up');
}

function onScrollDown() {
  console.log('down');
}
