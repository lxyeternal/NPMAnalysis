type OptionsType = {
  targetName?: string,
  ratioName?: string,
  observerName?: string,
  callbackName?: string,
  exposeOnlyOnceName?: string,
  dataName?: string,
  ratioRange?: number[],
  ratio?: number,
  exposeOnlyOnce?: boolean,
  callback?: (element: HTMLElement) => void
}

declare class ExposeMachine {
  constructor (options?: OptionsType)
}

export = ExposeMachine

export as namespace ExposeMachine

export const vuePlugin: any
