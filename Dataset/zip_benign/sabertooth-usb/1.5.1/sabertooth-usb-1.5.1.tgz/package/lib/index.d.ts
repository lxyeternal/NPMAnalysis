import SerialPort from 'serialport';
export declare type SingleChannel = 1 | 2;
export declare type Channel = 1 | 2 | '*';
export declare enum GetType {
    Value = 0,
    Battery = 16,
    Current = 32,
    Temperature = 64
}
export declare enum SetType {
    Value = 0,
    KeepAlive = 16,
    Shutdown = 32,
    Timeout = 64
}
export declare enum Command {
    Set = 40,
    Get = 41
}
export declare enum Type {
    Motor = 77,
    Freewheel = 81,
    Signal = 83,
    Aux = 65,
    Power = 80,
    CurrentLimit = 84,
    Ramping = 82
}
export declare enum MixedModeMotor {
    Drive = 68,
    Turn = 84
}
/** Sabertooth USB connection options. */
export declare type Options = {
    /** Serial baud rate, options are 2400, 9600, 19200, 38400 and 115200. Default is 38400. */
    baudRate?: number;
    /** The timeout for get requests, in ms. Default is 1000. 0 indicates timeout is disabled. */
    timeout?: number;
    /** The address of the Sabertooth. Default is 128. */
    address?: number;
    /** The number of times to attempt a get request. Default is 3. */
    maxGetAttemptCount?: number;
    /** Flag to enable debug console.log messages. Default is false. */
    debug?: boolean;
    /**
     * Maximum motor output as proportion of battery input, in range [0, 1].
     * Default is 0.95 (95%).
     * Set to 1 to disable maximum output rate compensation.
     *
     * The actual output motor voltage for a given input drive rate is non-linear above approximately a 95% drive rate;
     * the output motor voltage is capped at approximately 95% of the battery voltage (see image below).
     *
     * When `maxMotorOutputRate` is set to a value < 1, a given drive rate is adjusted by scaling it with `rate * maxMotorOutputRate`.
     * This provides for a linear relationship between the input drive rate and the actual motor output voltage.
     *
     * ![Plot of input drive rate vs output voltage](https://raw.githubusercontent.com/OliverColeman/node-sabertooth-usb/gh-pages/assets/Drive_rate_vs_output_rate.png)
     */
    maxMotorOutputRate?: number;
    /**
     * Motor current denoise exponential moving average factor.
     * Range is (0, 1]. Larger value means less de-noising.
     * Set to 1 to disable denoising. Default is 0.1.
     */
    motorCurrentDenoiseAlpha?: number;
};
/**
 * Controls USB-enabled Sabertooth motor drivers running in Packet Serial mode.
 *
 * See https://www.dimensionengineering.com/datasheets/USBSabertoothPacketSerialReference.pdf
 *
 * Note: Only Checksum protection is implemented, not CRC.
 */
export declare class SabertoothUSB {
    /** The path for the USB serial port this SabertoothUSB is connected to. */
    readonly path: string;
    /** The address of the Sabertooth. */
    readonly address: number;
    /** The timeout for get requests, in ms. */
    readonly timeout: number;
    /** The number of retry attempts for get requests. */
    readonly maxGetAttemptCount: number;
    /** Flag indicating if console.log debug messages are enabled. */
    readonly debug: boolean;
    /** Maximum motor output as proportion of battery input. */
    readonly maxMotorOutputRate: number;
    /** Motor current denoise exponential moving average factor. */
    readonly motorCurrentDenoiseAlpha: number;
    private serial;
    private lastError;
    private motorCurrentExponetialAverage;
    /**
     * Create an object to control a motor driver.
     *
     * A connection to the motor driver will be attempted upon creation but
     * this is asynchronous and is not available immediately after creation.
     * If the connection fails reconnection will be attempted automatically.
     *
     * @param path the path to the (USB) serial port. eg `/dev/ttyACM0` or `COM1`.
     * @param options Optional connection options. See `Options` type for details.
     */
    constructor(path: string, options?: Options);
    /** Returns true iff the USB serial connection to the motor driver is open and working. */
    isConnected: () => boolean;
    /** Get the last error that occurred in the connection to the motor driver. */
    getLastError: () => Error;
    private checkRange;
    /**
     * Controls the specified motor output(s).
     * This sets the output of the motor channel as a fraction of the battery voltage.
     * Note that the given rate is scaled by the `maxMotorOutputRate`.
     *
     * @param channel the motor channel(s), either `1`, `2`, or `*` for all motors.
     * @param rate the new rate for the motor(s), in range [-1, 1] for maximum reverse to maximum forward respectively.
     */
    setMotor(channel: Channel, rate: number): void;
    /**
     * Controls the specified power output, if the power output is configured as a controllable output.
     *
     * @param channel the power channel(s), either `1`, `2`, or `*` for all channels.
     * @param rate the new rate for the power output(s), in range [-1, 1]
     */
    setPower(channel: Channel, rate: number): void;
    /**
     * Controls the mixed-mode (differential) drive rate.
     * Note that the given rate is scaled by the `maxMotorOutputRate`.
     *
     * @param rate the new drive rate for the motors, in range [-1, 1] for maximum reverse to maximum forward respectively.
     */
    setDrive(rate: number): void;
    /**
     * Controls the mixed-mode (differential) turn rate.
     *
     * @param rate the new turn rate for the motors, in range [-1, 1] for maximum left to maximum right respectively.
     */
    setTurn(rate: number): void;
    /**
     * Enables or disables freewheeling for the specified motor output(s).
     *
     * @param channel the motor channel(s), either `1`, `2`, or `*` for all motors.
     * @param enableFreewheel True to enable freewheeling, false to disable freewheeling.
     */
    setFreewheel(channel: Channel, enableFreewheel: boolean): void;
    /**
     * Shuts down motor or power output(s).
     *
     * @param type The type of output to shutdown, either `SetType.Motor` or `SetType.Power`
     * @param channel the channel(s), either `1`, `2`, or `*` for all channels.
     * @param enableFreewheel True to trigger shutdown, false to clear the shutdown.
     */
    shutDown(type: Type.Motor | Type.Power, channel: Channel, shutdownEnabled: boolean): void;
    /**
     * Sets the current limit for the specified motor output channel.
     *
     * @param channel the motor channel(s), either `1`, `2`, or `*` for all channels.
     * @param currentLimit the new current limit on Amps, in range (0, 100], or -1 to use the default limit.
     */
    setCurrentLimit(channel: Channel, currentLimit: number): void;
    /**
     * Sets the ramping for the specified motor output channel.
     *
     * @param channel the motor channel(s), either `1`, `2`, or `*` for all channels.
     * @param ramping The ramping value, between -16383 (fast) and 2047 (slow).
     */
    setRamping(channel: Channel, ramping: number): void;
    /**
     * Get the battery/source voltage.
     */
    getBatteryVoltage(): Promise<number>;
    /**
     * Get the output transistor temperature for the specified motor channel, in degrees centigrade.
     */
    getMotorDriverOutputTemperature(channel: SingleChannel): Promise<number>;
    /**
     * Get the output rate for the specified motor channel, in range [-1, 1].
     */
    getMotorDriverOutputRate(channel: SingleChannel): Promise<number>;
    /**
     * Get the output current for the specified motor channel, in Amps.
     * This is a noisy signal and may vary by up to several amps.
     * Positive current values indicate energy is being drawn from the battery,
     * and negative values indicate energy is being regenerated into the battery.
     */
    getMotorCurrent(channel: SingleChannel): Promise<number>;
    private get;
    private set;
    private sendCommand;
}
/** Get a list of the avilable Sabertooth devices.
 * The return is an array of objects with fields like:
 * ```
 * manufacturer: 'Dimension Engineering',
 * serialNumber: '1600DB368EC8',
 * pnpId: 'usb-Dimension_Engineering_Sabertooth_2x32_1600DB368EC8-if01',
 * locationId: undefined,
 * vendorId: '268b',
 * productId: '0201',
 * path: '/dev/ttyACM0'
 * ```
 */
export declare const listSabertoothDevices: () => Promise<SerialPort.PortInfo[]>;
