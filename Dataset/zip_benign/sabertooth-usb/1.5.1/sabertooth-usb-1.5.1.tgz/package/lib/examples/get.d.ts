/**
 * Prints telemetry from each connected Sabertooth device.
 */
export {};
