# elovate-rating
A Javascript implementation of the [Elo rating system](http://en.wikipedia.org/wiki/Elo_rating_system).

# Installation

    npm install elovate-rating --save

# Usage
1. Require `elovate-rating`
2. Use `new Rating(ratingA, ratingB, scoreA, scoreB, kfactor)` to invoke the class

# Example
    const Rating = require('elovate-rating');

    const rating = new Rating(1500, 1500, 1, 0);
    
    const expectedScores = rating.getExpectedScores(); // => { a: 0.5, b: 0.5 }
    const newRatings = rating.getNewRatings(); // => { a: 1508, b: 1492 }
    const deltaRatings = rating.getDeltaRatings(); // => { a: 8, b: -8 }
    
    const expectedScoreA = expectedScores.a; // => 0.5
    const expectedScoreB = expectedScores.b; // => 0.5
    
    const newRatingA = newRatings.a; // => 1508
    const newRatingB = newRatings.b; // => 1492
    
    const deltaRatingA = deltaRatings.a; // => 8
    const deltaRatingB = deltaRatings.b; // => -8
