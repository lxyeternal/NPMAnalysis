'use strict';

const elovateRating = require('./lib/elovate-rating');

module.exports = elovateRating;
