/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng-magnizoom" />
export * from './public-api';
