import * as i0 from "@angular/core";
export declare class MagnizoomService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<MagnizoomService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MagnizoomService>;
}
