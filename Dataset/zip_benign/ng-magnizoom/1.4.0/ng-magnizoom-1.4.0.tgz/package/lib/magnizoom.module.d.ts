import * as i0 from "@angular/core";
import * as i1 from "./magnizoom.component";
import * as i2 from "@angular/common";
export declare class NgMagnizoomModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgMagnizoomModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgMagnizoomModule, [typeof i1.NgMagnizoomComponent], [typeof i2.CommonModule], [typeof i1.NgMagnizoomComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgMagnizoomModule>;
}
