import type { ElementRef } from '@angular/core';
import { OnInit, OnChanges, SimpleChanges, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
interface Size2D {
    width: number;
    height: number;
}
type Point2D = {
    x: number;
    y: number;
} | null;
export declare class NgMagnizoomComponent implements OnInit, OnChanges {
    imageSrc: string;
    zoomMode: 'LENS' | 'COVER';
    minZoomFactor: number;
    maxZoomFactor: number;
    zoomFactor: number;
    zoomFactorChange: EventEmitter<number>;
    lensSizeUnit: 'NORMALIZED' | 'PIXEL';
    lensSize: Size2D;
    zoomCenterUnit: 'NORMALIZED' | 'PIXEL';
    zoomCenter?: Point2D;
    zoomCenterChange: EventEmitter<{
        x: number;
        y: number;
    }>;
    updateOnMouseEvents: boolean;
    imageStyle: {
        [x: string]: any;
    };
    imageClass: any;
    mainCanvasRef: ElementRef;
    canvas: HTMLCanvasElement;
    context: CanvasRenderingContext2D;
    image: HTMLImageElement;
    _centerPosition: Point2D;
    _lensSize?: Size2D;
    _zoomFactor: number;
    imageReady: boolean;
    get canvasWidth(): number;
    get canvasHeight(): number;
    constructor();
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    initContext(): void;
    loadImage(src: string): void;
    updateParameters(): void;
    update(): void;
    render(): void;
    renderLensMode(): void;
    renderCoverMode(): void;
    getZoomRect(): {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    getClippingRect(): {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    getCoverRect(): {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    clampRect(x: number, y: number, w: number, h: number): {
        x: number;
        y: number;
        w: number;
        h: number;
    };
    calculateMousePosition(clientX: number, clientY: number): void;
    onMouseLeave(event: MouseEvent): void;
    onMouseEnterOrMove(event: MouseEvent): void;
    onMouseScroll(event: WheelEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgMagnizoomComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgMagnizoomComponent, "ng-magnizoom", never, { "imageSrc": "imageSrc"; "zoomMode": "zoomMode"; "minZoomFactor": "minZoomFactor"; "maxZoomFactor": "maxZoomFactor"; "zoomFactor": "zoomFactor"; "lensSizeUnit": "lensSizeUnit"; "lensSize": "lensSize"; "zoomCenterUnit": "zoomCenterUnit"; "zoomCenter": "zoomCenter"; "updateOnMouseEvents": "updateOnMouseEvents"; "imageStyle": "imageStyle"; "imageClass": "imageClass"; }, { "zoomFactorChange": "zoomFactorChange"; "zoomCenterChange": "zoomCenterChange"; }, never, never, false, never>;
}
export {};
