/**
 * Copyright 2020 Payton Quinn
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { GameGridConfig } from "./GameGridConfig";
export declare class GameGrid {
    private mouseOffset?;
    private config;
    /**
     * Creates an instance of game grid.
     * @param config The configuration for the game grid.
     */
    constructor(config: GameGridConfig);
    /**
     * Draws game grid
     */
    draw(): void;
    private handleMouseMove;
    private drawBoard;
    private updateBoard;
    private updateTranslation;
    private drawGrid;
}
