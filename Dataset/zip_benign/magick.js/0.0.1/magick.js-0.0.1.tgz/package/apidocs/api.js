YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "inputTypes"
    ],
    "modules": [
        "options"
    ],
    "allModules": [
        {
            "displayName": "options",
            "name": "options"
        }
    ]
} };
});