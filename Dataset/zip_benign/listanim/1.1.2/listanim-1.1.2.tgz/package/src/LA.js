import $ from "jquery"
class LA {
    constructor() {
        this.isStop = false;
    }

    init(data, callback) {
        LA.isStop = false;
        this.data = data;

        var num = parseInt(this.data.animateTo.height.replace(/\p|x/g, ''))
        this.maxNumber = Math.ceil($("#" + this.data.container).height() / num);
        this.refresh(this.data.data, 0, callback)
    }

    stop() {
        this.isStop = true;
    }

    refresh(Arr, n = 0, callback) {       
        let self = this;
        var Item = Arr[n];
        //获取数据
        //字符串转换-------------------------------------------------------------------------
        var listyle = JSON.stringify(this.data.liStyle).replace(/\{|}/g, '');
        listyle = listyle.replace(/\"/g, '');
        let len = $("#" + this.data.container + " li").length;
        let ele = $("<li style='" + listyle + "'></li>");
        var num = Item.length;
        ele.animate(self.data.animateTo,
            this.data.animateTime,
            () => {
                var str = "";
                var allPercent = 0;
                for (var i = 0; i < this.data.content.length; i++) {
                    allPercent += this.data.content[i].flex;
                }
                //生成样式字符串
                for (var i = 0; i < num; i++) {
                    var percent = this.data.content[i].flex / allPercent;
                    var width = percent * $("#" + this.data.container).width();
                    var style = JSON.stringify(this.data.content[i].style);
                    var cuStr = "<div style='width:" + width + "px;" + style + "'></div>"
                    str += cuStr;
                }
                //字段替换,替换为;
                str = str.replace(/\{|}/g, '')
                str = str.replace(/\,/g, ';')
                ele.append(str);
                //具体内容赋值
                for (var j = 0; j < Item.length; j++) {
                    var text = Item[j];
                    $("#" + this.data.container + " li:first div:eq(" + j + ")").html(text);
                }
                //赋值li的样式-------------------------------------------------------------------------------
                var spArr0 = listyle.split(',');
                var keys = [];
                var vals = [];
                for (var i = 0; i < spArr0.length; i++) {
                    var spArr1 = spArr0[i].split(':');
                    keys.push(spArr1[0]);
                    vals.push(spArr1[1]);
                }
                //赋值li子元素div的样式-----------------------------------------------------------------------
                var contentStyle = this.data.content;
                for (var i = 0; i < contentStyle.length; i++) {
                    var citemStyle = contentStyle[i];
                    citemStyle = JSON.stringify(citemStyle).replace(/\{|}/g, '');
                    citemStyle = citemStyle.replace(/\"/g, '');
                    //
                    var cArr0 = citemStyle.split(',');
                    var ckeys = [];
                    var cvals = [];
                    for (var j = 0; j < cArr0.length; j++) {
                        var cArr1 = cArr0[j].split(':');
                        ckeys.push(cArr1[0]);
                        cvals.push(cArr1[1]);
                    }
                    for (var k = 0; k < ckeys.length; k++) {
                        $("#" + this.data.container + " li:first div:eq(" + i + ")").css(ckeys[k], cvals[k])
                        //设置不同的背景颜色------------------------------------------------------------------
                        if (ckeys[k] == 'backgroundColor' && cvals[k].indexOf("|") != -1) {
                            var cls = cvals[k].split('|');
                            for (var s = 0; s < cls.length; s++) {
                                if (s == n) {
                                    $("#" + this.data.container + " li:first div:eq(" + i + ")").css(ckeys[k], cls[s])
                                }
                            }
                        }
                        //-----------------------------------------------------------------------------------
                    }
                }
                //-------------------------------------------------------------------------------------------
                for (var i = 0; i < keys.length; i++) {
                    $("#" + this.data.container + " li:first").css(keys[i], vals[i])
                }
                //添加动画--------------------------------------------------------
                if (len >= self.maxNumber) {
                    if (this.data.animateKind) {
                        ele.addClass(this.data.animateKind);
                    } else {
                        ele.addClass("animated flash");
                    }
                }
                ele.bind("click", e => {
                    //生成单点
                    var arrs = [];
                    var childNodes = e.currentTarget.childNodes;
                    for (var i = 0; i < childNodes.length; i++) {
                        arrs.push(childNodes[i].innerHTML);
                    }
                    var evedata = {
                        sql: this.data.sqlkey,
                        index: n,
                        arr: arrs
                    };
                    callback(evedata)
                });
                if (len > self.maxNumber) {
                    $("#" + this.data.container + " li:last").unbind();
                    $("#" + this.data.container + " li:last").remove();
                }
            }
        );
        $("#" + this.data.container).prepend(ele);
        let t = len < self.maxNumber ? 120 : this.data.nextTime;
        //延时递归
        setTimeout(() => {
            if (n < Arr.length - 1) {
                n++
            } else {
                n = 0;
            }
            if (self.isStop == false) {
                this.refresh(Arr, n, callback)
            }
        }, t);
    }
}

export default LA;