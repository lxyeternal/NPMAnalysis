
import LA from "./src/LA.js";
import animate from 'animate.css'
export default{
    LA,
}