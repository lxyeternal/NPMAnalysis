"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.half = void 0;
function half(value) {
    return 0.5 * value;
    //?
}
exports.half = half;
