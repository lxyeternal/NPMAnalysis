export declare function half(value: number): number;
