import { HSectionProps, Vertex2D } from "../../types";
export default function toHSectionVertices(props: HSectionProps): Vertex2D[][];
