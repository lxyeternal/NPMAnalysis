import { SolidRectangleProps, Vertex2D } from "../../types";
export default function toSolidRectangleVertices(props: SolidRectangleProps): Vertex2D[][];
