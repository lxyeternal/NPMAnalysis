"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _lib_utils_1 = require("../../utils");
function toSolidRectangleVertices(props) {
    var b = props.b, h = props.h;
    var vertices = [];
    var lbb = { x: -(0, _lib_utils_1.half)(b), y: (0, _lib_utils_1.half)(h) };
    var rbb = { x: (0, _lib_utils_1.half)(b), y: (0, _lib_utils_1.half)(h) };
    var rbt = { x: (0, _lib_utils_1.half)(b), y: -(0, _lib_utils_1.half)(h) };
    var lbt = { x: -(0, _lib_utils_1.half)(b), y: -(0, _lib_utils_1.half)(h) };
    vertices.push([lbb, rbb, rbt, lbt]);
    return vertices;
}
exports.default = toSolidRectangleVertices;
