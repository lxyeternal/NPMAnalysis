"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _lib_functions_1 = require("../functions");
describe('functions/h-section.ts', function () {
    test('H-300x250x30x50', function () {
        var vertices = (0, _lib_functions_1.toVertices)({
            type: "HSection",
            properties: {
                h: 300,
                tw: 30,
                b1: 250,
                tf1: 50,
                b2: 250,
                tf2: 50,
                r1: 10,
                r2: 10,
            },
        });
        if (vertices instanceof Error) {
            fail("Function returned an error: ".concat(vertices.message));
        }
        else {
            expect(vertices).toMatchSnapshot();
        }
    });
});
