"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _lib_functions_1 = require("../functions");
describe('functions/solid-rectangle.ts', function () {
    test('250x300', function () {
        var vertices = (0, _lib_functions_1.toVertices)({
            type: "SolidRectangle",
            properties: {
                b: 250,
                h: 300,
            },
        });
        if (vertices instanceof Error) {
            fail("Function returned an error: ".concat(vertices.message));
        }
        else {
            expect(vertices).toMatchSnapshot();
        }
    });
});
