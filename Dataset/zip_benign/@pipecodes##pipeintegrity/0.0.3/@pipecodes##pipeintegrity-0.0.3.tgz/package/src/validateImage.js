const path = require('path');
const tf = require('@tensorflow/tfjs-node');
const nsfwjs = require('nsfwjs');
const mobilenet = require('@tensorflow-models/mobilenet');
const axios = require('axios');
const fs = require('fs');

const ACCEPTED_EXTENSIONS = ['jpeg', 'jpg', 'png'];
const INAPPROPRIATE_CLASSES = ['Porn', 'Sexy', 'Hentai'];

/**
 * Performs a two-step validation of an image file,
 * the first step being the validation of the extension
 * based on the second parameter, and the second step
 * being a validation of the image itself, being invalid
 * cases where the image has inappropriate content.
 *
 * @param {String} file File being validated.
 * @param {String} extension Extension to validate the file.
 * @param {Number} extension Threshold to compare to each probability.
 * @returns {Object} Returns an object with a "isValid" property and the predictions result.
 */
const validateImage = async (file, extension, threshold = 0.4) => {
  if (isNaN(threshold) || threshold >= 1 || threshold <= 0) {
    throw new Error('Threshold must be a number between 0 and 1 (excluding)');
  }

  return _validateExtension(file, extension) ? _validateContent(file, threshold) : { isValid: false, predictions: null };
};

/**
 * Checks if the file's extension is
 * in fact the extension that is expected.
 * 
 * @param {String} file File being validated.
 * @param {String} extension Extension expected to match.
 * @returns {Boolean} Returns true if the file's extension matches the expected one.
 */
const _validateExtension = (file, extension) => {
  extension = _normalizeExtension(extension);

  if (!ACCEPTED_EXTENSIONS.includes(extension)) {
    throw new Error(`Extension provided ("${extension}") is not an accepted extension.`);
  }

  const fileExtension = _normalizeExtension(path.extname(file));

  return fileExtension === extension;
};

/**
 * Transforms an extension into
 * a string in lowercase and without
 * any starting dot.
 * 
 * @param {String} extension Possibly incorrectly formed extension.
 * @returns {String} Normalized extension.
 */
const _normalizeExtension = (extension) => {
  return extension.toLowerCase().replace('.', '');
}

/**
 * Performs a validation to the
 * image, detecting any inappropriate
 * content it might have.
 * 
 * @param {String} file File being validated.
 * @returns {Boolean} Returns true if the image content is appropriate.
 */
const _validateContent = async (file, threshold) => {
  const content = await _getContent(file); 

  if (!content) {
    throw new Error(
      `Unable to load the image content, please provide a valid URL or a valid file path.`
    );
  }

  const predictions = await _getPredictions(content);
    
  return _resolveValidation(predictions, threshold);
};

/**
 * Downloads or reads the file, returning
 * its contents.
 * 
 * @param {String} file File to get the content from.
 * @returns {Buffer} Returns the image's content.
 */
const _getContent = async (file) => {
  let content = null;

  if (_isUrl(file)) {
    content = await _downloadImage(file);
  } else {
    try { 
      content = fs.readFileSync(file); 
    } catch (error) {
      throw new Error('Unable to read local file, please make sure the path points to a file.');
    }
  }

  return content;
}

/**
 * Detects wether the file is
 * a file path or an URL.
 * 
 * @param {String} file File path or file URL.
 * @returns {Boolean} Returns true if it is an URL.
 */
const _isUrl = (file) => {
  const pattern = new RegExp('^(https?:\\/\\/)?'+
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+
    '((\\d{1,3}\\.){3}\\d{1,3}))'+
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+
    '(\\?[;&a-z\\d%_.~+=-]*)?'+
    '(\\#[-a-z\\d_]*)?$','i');

  return !!pattern.test(file);
}

/**
 * Downloads and returns the contents
 * of the image.
 * 
 * @param {String} file URL to perform the download.
 * @returns {Buffer} Returns the Buffer content from the downloaded image.
 */
const _downloadImage = async (file) => {
  return await axios.get(file, { responseType: 'arraybuffer' });
}

/**
 * Calculates the probability of several
 * categories for which the image content
 * might belong to.
 * 
 * @param {Buffer} content Content from the image.
 * @returns {Object} Returns an object with all the predictions.
 */
const _getPredictions = async (content) => {
  const tensorFlowImage = await tf.node.decodeImage(content.data ?? content, 3);
  
  const model = await nsfwjs.load();
  // const model = await mobilenet.load();
  const predictions = await model.classify(tensorFlowImage);

  tensorFlowImage.dispose();

  return predictions;
}

/**
 * Decides wether the image is appropriate or not.
 * 
 * @param {Object} predictions Object with the resulting predictions.
 * @param {Number} threshold Threshold to compare the probabilities.
 * @returns {Object} Object with the predictions and an "isValid" property.
 */
const _resolveValidation = (predictions, threshold) => {
  let isValid = true;

  for (prediction of predictions) {
    if (
      INAPPROPRIATE_CLASSES.includes(prediction.className) &&
      prediction.probability >= threshold
    ) {
      isValid = false;
      break;
    }
  }

  return { isValid, predictions }
}

module.exports = validateImage;