const Filter = require('bad-words');
const pt = require('./profane-words/pt');

/**
 * Checks if the text provided has any
 * profanity and returns results with
 * an "isValid" property and a clean
 * version of the text provided. You may also
 * provide a blacklist and a whitelist of words
 * within an object in the second parameter.
 * 
 * @param {String} text Text to test for profanity.
 * @param {Object} options Options object
 * @param {String[]} options.blacklist List of additional forbidden words
 * @param {String[]} options.whitelist List of additional permitted words
 * @returns {Object} Object with the profanity test results.
 */
const validateText = (text, options = { blacklist: [], whitelist: [] }) => {
  return _resolve(_setUp(options), text);
};

/**
 * Sets up and returns a 
 * Filter instance.
 * 
 * @param {Object} options Options object
 * @param {String[]} options.blacklist List of additional forbidden words
 * @param {String[]} options.whitelist List of additional permitted words
 * @returns {Filter}
 */
const _setUp = (options = { blacklist: [], whitelist: [] }) => {
  const filter = new Filter();
  filter.addWords(...pt);

  const keys = typeof options === 'object' ? 
    Object.keys(options) : 
    [];
  
  if (keys.length > 0) {
    if (keys.includes('blacklist') && Array.isArray(options.blacklist)) {
      filter.addWords(...options.blacklist);
    }

    if (keys.includes('whitelist') && Array.isArray(options.whitelist)) {
      filter.removeWords(...options.whitelist);
    }
  }

  return filter;
};

/**
 * Resolves the test into an object
 * with the profanity test results.
 * 
 * @param {Filter} filter Filter instance to test for profanity.
 * @param {string} text Text to be tested.
 * @returns {Object} Object with the profanity test results.
 */
const _resolve = (filter, text) => {
  return {
    isValid: !filter.isProfane(text),
    textClean: filter.clean(text)
  }
};

module.exports = validateText;