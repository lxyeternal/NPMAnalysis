/**
 * Integrity's function object.
 * 
 * Contains all functions available
 * in this package.
 */
module.exports = {
  validateImage: require('./src/validateImage'),
  validateText: require('./src/validateText'),
};