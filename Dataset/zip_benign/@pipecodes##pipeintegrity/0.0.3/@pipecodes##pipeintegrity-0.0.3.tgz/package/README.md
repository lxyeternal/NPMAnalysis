[![N|Solid](https://pipecodes.com/upload/logo.svg)](https://pipecodes.com)
# PipeIntegrity
#### Image and Text Validation

**PipeIntegrity** is a PipeCodes internal package written in (and to be used with) JavaScript (Node.js).
It's function is to **validate** certain user inputs, returning back a result regarding the validation of that said input, thus protecting the integrity of any web application.

## Features
Here's what PipeIntegrity, as of the current version, detects as **invalid**:
- **Images of nudity and pornographic content**;
- **Profane and/or inappropriate text**.

## Technology
Here are some technologies PipeIntegrity depends on:
- [TensorFlow.js](https://www.npmjs.com/package/@tensorflow/tfjs/) - Machine learning library;
- [TensorFlow.js via Node.js](https://www.npmjs.com/package/@tensorflow/tfjs-node/) - TensorFlow adapter to Node.js;
- [NSFWJS](https://www.npmjs.com/package/nsfwjs/) - Evaluates image content;
- [bad-words](https://www.npmjs.com/package/bad-words/) - Evaluates text content.


## Installation
PipeIntegrity requires [Node.js](https://nodejs.org/) v14+ to run.
To install PipeIntegrity, please run the following commands on your terminal:

```sh
cd [your project folder]
npm i @pipecodes/pipeintegrity
```

## Usage
The package includes two functions you can use for each of these inputs.

#### Images

The "validateImage" function will first validate if the image extension matches the extension provided in the second argument, and then will validate the image's content.

```js
const pipeintegrity = require('@pipecodes/pipeintegrity');

const myImage = "[this must be a string with either an URL or a local path to that image]";
const myExtension = 'png';

// Default: 0.4 - this is the "sensitivity" the validator is when encountering any inappropriate content in the image. 
// The value must be between 0 and 1 (excluding).
// The higher the value, the more difficult will be for any inappropriate image to be invalidated.
const myThreshold = 0.7; 

pipeintegrity.validateImage(myImage, myExtension, myThreshold)
    .then((validation) => {
        // Here you can check "validation.isValid" for a decision on wether 
        // the image is appropriate or not.
        // Also, "validation.predictions" contains an array with the types of image it might fall into.
    })
    .catch((error) => {
        // Handle errors.
    });
```

#### Text
The "validateText" function will take a text string and validate if the text has any inappropriate words of phrases that are included in the default list of profane content.
As a second argument to this function, you can provide an object containing the properties "blacklist" and "whitelist". Both of them **must be an array with strings, otherwise an error will be thrown**.
- **options.blacklist** adds extra words to be marked as "forbidden";
- **options.whitelist** removes words that were otherwise "forbidden" and are now "allowed".

```js
const pipeintegrity = require('@pipecodes/pipeintegrity');

const myText = "[any kind of text in a string]";
const options = {
    blacklist: ['This MUST be an array', 'containing', 'only strings'],
    whitelist: ['This also MUST be an array', 'containing', 'only strings'],
}

try {
    const validation = pipeintegrity.validateText(myText, options);
    // "validation.isValid" has the decision of
    // wether the text has any inappropriate content or not.
    // You can also access "validation.textClean" for a
    // censored version of the text provided.
} catch (error) {
    // Handle errors.
}
```
