/**
 * Entry point.
 * 
 * Exports an object with all
 * the available functions.
 */
module.exports = require('./integrity');