import { AwesomeQR } from "@qrcode-js/core";
export { AwesomeQR };
export default function QRCodeNode(): AwesomeQR<import("canvas").Canvas>;
