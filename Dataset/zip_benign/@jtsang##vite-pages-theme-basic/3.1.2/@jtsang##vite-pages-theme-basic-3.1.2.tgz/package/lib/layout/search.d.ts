/// <reference types="react" />
import type { PagesStaticData } from 'vite-plugin-react-pages';
interface Props {
    readonly pagesStaticData: PagesStaticData;
}
declare const SiteSearch: ({ pagesStaticData }: Props) => JSX.Element;
export default SiteSearch;
//# sourceMappingURL=search.d.ts.map