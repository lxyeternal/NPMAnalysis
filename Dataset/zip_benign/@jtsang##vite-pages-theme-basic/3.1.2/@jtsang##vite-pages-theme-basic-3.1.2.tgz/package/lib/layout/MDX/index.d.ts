import React from 'react';
declare const MDX: React.FC;
export default MDX;
//# sourceMappingURL=index.d.ts.map