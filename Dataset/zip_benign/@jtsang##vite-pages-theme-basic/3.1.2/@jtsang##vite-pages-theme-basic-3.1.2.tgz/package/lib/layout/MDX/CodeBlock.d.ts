/// <reference types="react" />
interface Props {
    readonly className?: string;
    readonly children?: string;
}
declare const CodeBlock: ({ children, className }: Props) => JSX.Element;
export default CodeBlock;
//# sourceMappingURL=CodeBlock.d.ts.map