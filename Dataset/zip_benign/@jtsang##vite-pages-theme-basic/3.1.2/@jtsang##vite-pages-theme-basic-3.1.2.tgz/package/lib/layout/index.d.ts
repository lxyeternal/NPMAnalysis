import React from 'react';
import 'github-markdown-css/github-markdown.css';
import type { PagesStaticData } from 'vite-plugin-react-pages';
import './global.css';
interface Props {
    readonly sideMenuData: ReadonlyArray<SideMenuData>;
    readonly topNavs: ReadonlyArray<TopNavData>;
    readonly logo: React.ReactNode;
    readonly path?: string;
    readonly footer?: React.ReactNode;
    readonly pagesStaticData?: PagesStaticData;
    readonly topbarOperations?: React.ReactNode;
    readonly search?: boolean;
}
declare const Layout: React.FC<Props>;
export default Layout;
export declare type SideMenuData = {
    readonly text: string;
    readonly path: string;
};
export declare type TopNavData = {
    readonly text: string;
    /**
     * The url.
     * @example 'https://www.google.com/'
     */
    readonly href: string;
} | {
    readonly text: string;
    /**
     * The path in the current webapp.
     * @example '/posts/hello-world'
     */
    readonly path: string;
} | {
    /**
     * The label of the subnav
     */
    readonly subNav: string;
    readonly children: ReadonlyArray<TopNavData>;
} | {
    /**
     * The label of the nav group
     */
    readonly group: string;
    readonly children: ReadonlyArray<TopNavData>;
};
export declare function renderNav(navs: ReadonlyArray<TopNavData>): JSX.Element[];
//# sourceMappingURL=index.d.ts.map