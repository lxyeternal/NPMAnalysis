import React from 'react';
import type { Theme, PagesStaticData } from 'vite-plugin-react-pages';
import Layout from './layout';
import type { SideMenuData, TopNavData } from './layout';
interface Option {
    /**
     * Take fully control of side nav menu.
     */
    readonly sideMenuData?: ReadonlyArray<SideMenuData>;
    /**
     * Navigation menu at top bar.
     */
    readonly topNavs?: ReadonlyArray<TopNavData>;
    /**
     * Logo area at top bar.
     */
    readonly logo?: React.ReactNode;
    /**
     * Operation area at top bar.
     */
    readonly topbarOperations?: React.ReactNode;
    /**
     * Footer area.
     */
    readonly footer?: React.ReactNode;
    /**
     * Enable search.
     * @default true
     */
    readonly search?: boolean;
}
export declare function createTheme({ topNavs, logo, sideMenuData, footer, topbarOperations, search, }?: Option): Theme;
export { Layout };
export declare function defaultMenu(pages: PagesStaticData): SideMenuData[];
//# sourceMappingURL=index.d.ts.map