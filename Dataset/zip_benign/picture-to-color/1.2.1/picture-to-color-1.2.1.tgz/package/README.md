# picture-to-color

picture to color ratio

```bash
$ npm install -g picture-to-color

$ p2c <file path>
# ex: p2c ~/Documents/sample.jpg
[
  { id: 3, color: { r: 255, g: 0, b: 255 }, count: 8, ratio: 0.4 },
  { id: 0, color: { r: 255, g: 0, b: 0 }, count: 6, ratio: 0.3 },
  { id: 1, color: { r: 0, g: 255, b: 0 }, count: 4, ratio: 0.2 },
  { id: 2, color: { r: 0, g: 0, b: 255 }, count: 2, ratio: 0.1 }
]
```
