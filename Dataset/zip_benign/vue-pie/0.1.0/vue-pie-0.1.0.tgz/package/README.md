##
	make a pie with vue

## Example

```
	<VuePie
		value="0.2"
		ring="0.5"
		isShowNumber="true"
		color="red"
		rotate="45">
	</VuePie>	
```


## Installation

    cnpm install @skylar/vue-pie 

## License

	(The MIT License)