import { IRendition, Player, IPlayerConfig } from './Player';
import * as Hls from 'hls.js';
export declare class PlayerHls extends Player<Hls> {
    constructor(url: string, htmlPlayer: HTMLVideoElement, config: IPlayerConfig);
    load(): void;
    destroy(): void;
    getRenditions(): IRendition[];
    setRendition(rendition: IRendition | number, immediately: boolean): void;
    getCurrentRendition(): IRendition;
    private convertLevelsToIRenditions;
}
