export declare class NgxEpicVideoPlayerModule {
}
