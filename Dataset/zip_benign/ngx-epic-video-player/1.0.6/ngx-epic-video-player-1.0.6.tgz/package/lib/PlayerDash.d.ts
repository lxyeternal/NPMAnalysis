import { MediaPlayerClass } from 'dashjs';
import { IRendition, Player, IPlayerConfig } from './Player';
export declare class PlayerDash extends Player<MediaPlayerClass> {
    constructor(url: string, htmlPlayer: HTMLVideoElement, config: IPlayerConfig);
    load(): void;
    destroy(): void;
    getRenditions(): IRendition[];
    setRendition(rendition: IRendition | number, immediately: boolean): void;
    getCurrentRendition(): IRendition;
    private convertBitratesToIRenditions;
    private getCodecName;
}
