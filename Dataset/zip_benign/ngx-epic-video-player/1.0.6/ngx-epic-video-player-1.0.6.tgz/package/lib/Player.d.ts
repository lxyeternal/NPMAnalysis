import { MediaPlayerClass } from 'dashjs';
import * as Hls from 'hls.js';
export declare enum PlayerType {
    DASH = 0,
    HLS = 1
}
export interface IStatsTimeRanges {
    start: number;
    end: number;
}
export interface IStats {
    buffered: IStatsTimeRanges[];
    duration: number;
    droppedFrames: number;
    loadTime: number;
    played: IStatsTimeRanges[];
    seekable: IStatsTimeRanges[];
}
export interface IRendition {
    audioCodec?: string;
    bitrate: number;
    height: number;
    level?: number;
    name?: string;
    videoCodec?: string;
    width: number;
}
export interface IPlayerConfig {
    initialRenditionKbps?: number;
    initialRenditionIndex?: number;
}
export declare type PlayerClassType = MediaPlayerClass | Hls;
export declare abstract class Player<T> {
    protected url: string;
    protected htmlPlayer: HTMLVideoElement;
    protected config: IPlayerConfig;
    player: T;
    playerType: PlayerType;
    stats: IStats;
    loadStartTime: number;
    updateStats: () => void;
    loadStart: () => void;
    loadEnd: () => void;
    protected constructor(url: string, htmlPlayer: HTMLVideoElement, config: IPlayerConfig);
    abstract load(): void;
    abstract destroy(): void;
    abstract getRenditions(): IRendition[];
    abstract setRendition(rendition: IRendition | number, immediately: boolean): void;
    abstract getCurrentRendition(): IRendition;
    getStats(): IStats;
    initListeners(): void;
    destroyListeners(): void;
    protected reset(): void;
    protected resetStats(): void;
}
