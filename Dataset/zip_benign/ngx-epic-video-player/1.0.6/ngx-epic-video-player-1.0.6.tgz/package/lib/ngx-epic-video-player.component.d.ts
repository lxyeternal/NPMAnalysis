import { EventEmitter, OnDestroy, ElementRef } from '@angular/core';
import { IRendition, IStats, Player, PlayerClassType } from './Player';
export interface IEvent {
    type: string;
    data?: any;
}
export declare class NgxEpicVideoPlayerComponent implements OnDestroy {
    htmlVideoRef: ElementRef<HTMLVideoElement>;
    url: string;
    setUrl: string;
    autoplay: boolean;
    setAutoplay: boolean;
    muted: boolean;
    setMuted: boolean | string;
    initialRenditionKbps: number;
    setInitialRenditionKbps: number;
    initialRenditionIndex: number;
    setinitialRenditionIndex: number;
    poster: string;
    videoId: string;
    controls: boolean;
    loop: boolean;
    player: Player<PlayerClassType>;
    /**
     * Regular HTML video event emitters
     */
    abortEvent: EventEmitter<IEvent>;
    canplayEvent: EventEmitter<IEvent>;
    canplaythroughEvent: EventEmitter<IEvent>;
    durationchangeEvent: EventEmitter<IEvent>;
    emptiedEvent: EventEmitter<IEvent>;
    endedEvent: EventEmitter<IEvent>;
    errorEvent: EventEmitter<IEvent>;
    loadeddataEvent: EventEmitter<IEvent>;
    loadedmetadataEvent: EventEmitter<IEvent>;
    loadstartEvent: EventEmitter<IEvent>;
    pauseEvent: EventEmitter<IEvent>;
    playEvent: EventEmitter<IEvent>;
    playingEvent: EventEmitter<IEvent>;
    progressEvent: EventEmitter<IEvent>;
    ratechangeEvent: EventEmitter<IEvent>;
    seekedEvent: EventEmitter<IEvent>;
    seekingEvent: EventEmitter<IEvent>;
    stalledEvent: EventEmitter<IEvent>;
    suspendEvent: EventEmitter<IEvent>;
    timeupdateEvent: EventEmitter<IEvent>;
    volumechangeEvent: EventEmitter<IEvent>;
    waitingEvent: EventEmitter<IEvent>;
    /**
     * Regular HTML video event listeners
     */
    abortListener: (e: any) => void;
    canplayListener: (e: any) => void;
    canplaythroughListener: (e: any) => void;
    durationchangeListener: (e: any) => void;
    emptiedListener: (e: any) => void;
    endedListener: (e: any) => void;
    errorListener: (e: any) => void;
    loadeddataListener: (e: any) => void;
    loadedmetadataListener: (e: any) => void;
    loadstartListener: (e: any) => void;
    pauseListener: (e: any) => void;
    playListener: (e: any) => void;
    playingListener: (e: any) => void;
    progressListener: (e: any) => void;
    ratechangeListener: (e: any) => void;
    seekedListener: (e: any) => void;
    seekingListener: (e: any) => void;
    stalledListener: (e: any) => void;
    suspendListener: (e: any) => void;
    timeupdateListener: (e: any) => void;
    volumechangeListener: (e: any) => void;
    waitingListener: (e: any) => void;
    ngOnDestroy(): void;
    isTrue(value: boolean | string): boolean;
    getStats(): IStats;
    getHtmlVideo(): HTMLVideoElement;
    getRenditions(): IRendition[];
    getCurrentRendition(): IRendition;
    setRendition(rendition: IRendition | number, immediately?: boolean): void;
    private init;
    private createPlayer;
    private destroy;
    pause(): void;
    play(): void;
    currentTime(secs?: number): void | number;
    volume(perc?: number): void | number;
    playbackRate(rate?: number): void | number;
}
