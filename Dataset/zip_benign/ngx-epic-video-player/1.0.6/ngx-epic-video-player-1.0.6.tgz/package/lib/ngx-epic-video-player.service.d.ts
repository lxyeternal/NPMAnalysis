export declare class NgxEpicVideoPlayerService {
    constructor();
}
