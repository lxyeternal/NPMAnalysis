import { IStatsTimeRanges } from './Player';
export declare class Utils {
    static getDroppedFrames(htmlVideo: HTMLVideoElement): number;
    static getDuration(htmlVideo: HTMLVideoElement): number;
    static getBuffered(htmlVideo: HTMLVideoElement): TimeRanges;
    static getSeekable(htmlVideo: HTMLVideoElement): TimeRanges;
    static getPlayed(htmlVideo: HTMLVideoElement): TimeRanges;
    static timeRangesToIStatsTimeRanges(tr: TimeRanges): IStatsTimeRanges[];
}
