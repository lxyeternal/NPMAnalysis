/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of ngx-epic-video-player
 */
export { NgxEpicVideoPlayerService } from './lib/ngx-epic-video-player.service';
export { NgxEpicVideoPlayerComponent } from './lib/ngx-epic-video-player.component';
export { NgxEpicVideoPlayerModule } from './lib/ngx-epic-video-player.module';
export { PlayerType, Player } from './lib/Player';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25neC1lcGljLXZpZGVvLXBsYXllci8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUlBLDBDQUFjLHFDQUFxQyxDQUFDO0FBQ3BELDRDQUFjLHVDQUF1QyxDQUFDO0FBQ3RELHlDQUFjLG9DQUFvQyxDQUFDO0FBQ25ELG1DQUFjLGNBQWMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2Ygbmd4LWVwaWMtdmlkZW8tcGxheWVyXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvbmd4LWVwaWMtdmlkZW8tcGxheWVyLnNlcnZpY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbmd4LWVwaWMtdmlkZW8tcGxheWVyLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9uZ3gtZXBpYy12aWRlby1wbGF5ZXIubW9kdWxlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL1BsYXllcic7XG4iXX0=