(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('dashjs'), require('hls.js'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('ngx-epic-video-player', ['exports', 'dashjs', 'hls.js', '@angular/core'], factory) :
    (factory((global['ngx-epic-video-player'] = {}),global['2']['9']['2'],global['0']['12']['2'],global.ng.core));
}(this, (function (exports,dashjs,Hls,i0) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var NgxEpicVideoPlayerService = /** @class */ (function () {
        function NgxEpicVideoPlayerService() {
        }
        NgxEpicVideoPlayerService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] }
        ];
        /** @nocollapse */
        NgxEpicVideoPlayerService.ctorParameters = function () { return []; };
        /** @nocollapse */ NgxEpicVideoPlayerService.ngInjectableDef = i0.defineInjectable({ factory: function NgxEpicVideoPlayerService_Factory() { return new NgxEpicVideoPlayerService(); }, token: NgxEpicVideoPlayerService, providedIn: "root" });
        return NgxEpicVideoPlayerService;
    }());

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (b.hasOwnProperty(p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var Utils = /** @class */ (function () {
        function Utils() {
        }
        /**
         * @param {?} htmlVideo
         * @return {?}
         */
        Utils.getDroppedFrames = /**
         * @param {?} htmlVideo
         * @return {?}
         */
            function (htmlVideo) {
                if (!htmlVideo) {
                    return;
                }
                /** @type {?} */
                var hasWebKit = ('webkitDroppedFrameCount' in htmlVideo) && ('webkitDecodedFrameCount' in htmlVideo);
                /** @type {?} */
                var hasQuality = ('getVideoPlaybackQuality' in htmlVideo);
                if (hasQuality) {
                    return (( /** @type {?} */(htmlVideo))).getVideoPlaybackQuality();
                }
                else if (hasWebKit) {
                    return (( /** @type {?} */(htmlVideo))).webkitDroppedFrameCount;
                }
                return;
            };
        /**
         * @param {?} htmlVideo
         * @return {?}
         */
        Utils.getDuration = /**
         * @param {?} htmlVideo
         * @return {?}
         */
            function (htmlVideo) {
                if (!htmlVideo) {
                    return;
                }
                return htmlVideo.duration;
            };
        /**
         * @param {?} htmlVideo
         * @return {?}
         */
        Utils.getBuffered = /**
         * @param {?} htmlVideo
         * @return {?}
         */
            function (htmlVideo) {
                if (!htmlVideo) {
                    return;
                }
                return htmlVideo.buffered;
            };
        /**
         * @param {?} htmlVideo
         * @return {?}
         */
        Utils.getSeekable = /**
         * @param {?} htmlVideo
         * @return {?}
         */
            function (htmlVideo) {
                if (!htmlVideo) {
                    return;
                }
                return htmlVideo.seekable;
            };
        /**
         * @param {?} htmlVideo
         * @return {?}
         */
        Utils.getPlayed = /**
         * @param {?} htmlVideo
         * @return {?}
         */
            function (htmlVideo) {
                if (!htmlVideo) {
                    return;
                }
                return htmlVideo.played;
            };
        /**
         * @param {?} tr
         * @return {?}
         */
        Utils.timeRangesToIStatsTimeRanges = /**
         * @param {?} tr
         * @return {?}
         */
            function (tr) {
                /** @type {?} */
                var res = [];
                for (var i = 0; i < tr.length; i++) {
                    res.push({ start: tr.start(i), end: tr.end(i) });
                }
                return res;
            };
        return Utils;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @enum {number} */
    var PlayerType = {
        DASH: 0,
        HLS: 1,
    };
    PlayerType[PlayerType.DASH] = 'DASH';
    PlayerType[PlayerType.HLS] = 'HLS';
    /**
     * @abstract
     * @template T
     */
    var /**
     * @abstract
     * @template T
     */ Player = /** @class */ (function () {
        function Player(url, htmlPlayer, config) {
            var _this = this;
            this.url = url;
            this.htmlPlayer = htmlPlayer;
            this.config = config;
            this.updateStats = function () {
                _this.stats = {
                    buffered: Utils.timeRangesToIStatsTimeRanges(Utils.getBuffered(_this.htmlPlayer)),
                    droppedFrames: Utils.getDroppedFrames(_this.htmlPlayer),
                    duration: Utils.getDuration(_this.htmlPlayer),
                    loadTime: _this.stats.loadTime,
                    played: Utils.timeRangesToIStatsTimeRanges(Utils.getPlayed(_this.htmlPlayer)),
                    seekable: Utils.timeRangesToIStatsTimeRanges(Utils.getSeekable(_this.htmlPlayer)),
                };
            };
            this.loadStart = function () {
                _this.updateStats();
                if (_this.stats.loadTime === -1) {
                    _this.loadStartTime = (new Date()).getTime();
                }
            };
            this.loadEnd = function () {
                _this.updateStats();
                if (_this.stats.loadTime === -1) {
                    _this.stats.loadTime = ((new Date()).getTime() - _this.loadStartTime) / 1000;
                }
                _this.updateStats();
            };
            this.resetStats();
            this.load();
        }
        /**
         * @return {?}
         */
        Player.prototype.getStats = /**
         * @return {?}
         */
            function () {
                return this.stats;
            };
        /**
         * @return {?}
         */
        Player.prototype.initListeners = /**
         * @return {?}
         */
            function () {
                this.htmlPlayer.addEventListener('timeupdate', this.updateStats);
                this.htmlPlayer.addEventListener('loadstart', this.loadStart);
                this.htmlPlayer.addEventListener('canplay', this.loadEnd);
            };
        /**
         * @return {?}
         */
        Player.prototype.destroyListeners = /**
         * @return {?}
         */
            function () {
                this.htmlPlayer.removeEventListener('timeupdate', this.updateStats);
                this.htmlPlayer.removeEventListener('loadstart', this.loadStart);
                this.htmlPlayer.removeEventListener('canplay', this.loadEnd);
            };
        /**
         * @protected
         * @return {?}
         */
        Player.prototype.reset = /**
         * @protected
         * @return {?}
         */
            function () {
                this.destroyListeners();
                this.resetStats();
            };
        /**
         * @protected
         * @return {?}
         */
        Player.prototype.resetStats = /**
         * @protected
         * @return {?}
         */
            function () {
                this.stats = {
                    buffered: [],
                    duration: 0,
                    droppedFrames: 0,
                    loadTime: -1,
                    played: [],
                    seekable: [],
                };
            };
        return Player;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var PlayerDash = /** @class */ (function (_super) {
        __extends(PlayerDash, _super);
        function PlayerDash(url, htmlPlayer, config) {
            return _super.call(this, url, htmlPlayer, config) || this;
        }
        /**
         * @return {?}
         */
        PlayerDash.prototype.load = /**
         * @return {?}
         */
            function () {
                this.reset();
                try {
                    this.player = dashjs.MediaPlayer().create();
                    this.player.getDebug().setLogToBrowserConsole(false);
                    this.player.initialize(this.htmlPlayer, this.url, false);
                    // an initial rendition needs to be loaded
                    if (this.config && typeof this.config.initialRenditionKbps === 'number') {
                        this.player.setAutoSwitchQualityFor('video', false);
                        this.player.enableLastBitrateCaching(false);
                        this.player.setInitialBitrateFor('video', this.config.initialRenditionKbps);
                    }
                    this.initListeners();
                    this.playerType = PlayerType.DASH;
                }
                catch (e) {
                    console.error(e);
                }
            };
        /**
         * @return {?}
         */
        PlayerDash.prototype.destroy = /**
         * @return {?}
         */
            function () {
                try {
                    if (this.player !== undefined) {
                        this.player.reset();
                    }
                    this.playerType = undefined;
                }
                catch (e) {
                    console.warn(e);
                }
            };
        /**
         * @return {?}
         */
        PlayerDash.prototype.getRenditions = /**
         * @return {?}
         */
            function () {
                if (this.player === undefined) {
                    return;
                }
                return this.convertBitratesToIRenditions(this.player.getBitrateInfoListFor('video'));
            };
        /**
         * @param {?} rendition
         * @param {?} immediately
         * @return {?}
         */
        PlayerDash.prototype.setRendition = /**
         * @param {?} rendition
         * @param {?} immediately
         * @return {?}
         */
            function (rendition, immediately) {
                if (this.player === undefined) {
                    return;
                }
                if (typeof rendition === 'number') {
                    if (rendition === -1) {
                        this.player.setAutoSwitchQualityFor('video', true);
                    }
                    else {
                        this.player.setAutoSwitchQualityFor('video', false);
                        this.player.enableLastBitrateCaching(false);
                        this.player.setQualityFor('video', rendition);
                    }
                    return;
                }
                else {
                    /** @type {?} */
                    var renditions = this.getRenditions();
                    if (renditions !== undefined && renditions.length > 0) {
                        for (var i = 0; i < renditions.length; i++) {
                            if (renditions[i].bitrate === rendition.bitrate) {
                                return this.setRendition(i, immediately);
                            }
                        }
                    }
                }
                return this.setRendition(-1, immediately);
            };
        /**
         * @return {?}
         */
        PlayerDash.prototype.getCurrentRendition = /**
         * @return {?}
         */
            function () {
                if (this.player === undefined) {
                    return;
                }
                /** @type {?} */
                var renditions = this.getRenditions();
                if (renditions !== undefined && renditions.length > 0) {
                    /** @type {?} */
                    var currentQuality = this.player.getQualityFor('video');
                    if (currentQuality >= 0 && renditions.length > currentQuality) {
                        return renditions[currentQuality];
                    }
                }
                return;
            };
        /**
         * @private
         * @param {?} bitrates
         * @return {?}
         */
        PlayerDash.prototype.convertBitratesToIRenditions = /**
         * @private
         * @param {?} bitrates
         * @return {?}
         */
            function (bitrates) {
                var _this = this;
                /** @type {?} */
                var videoInfo = this.player.getCurrentTrackFor('video');
                /** @type {?} */
                var audioInfo = this.player.getCurrentTrackFor('audio');
                if (bitrates === undefined || bitrates.length === 0) {
                    return;
                }
                return bitrates.map(function (b) {
                    return {
                        bitrate: b.bitrate !== undefined ? b.bitrate : undefined,
                        height: b.height !== undefined ? b.height : undefined,
                        level: b.qualityIndex !== undefined ? b.qualityIndex : undefined,
                        width: b.width !== undefined ? b.width : undefined,
                        videoCodec: videoInfo && videoInfo.codec ? _this.getCodecName(videoInfo.codec) : undefined,
                        audioCodec: audioInfo && audioInfo.codec ? _this.getCodecName(audioInfo.codec) : undefined,
                    };
                });
            };
        /**
         * @private
         * @param {?} codec
         * @return {?}
         */
        PlayerDash.prototype.getCodecName = /**
         * @private
         * @param {?} codec
         * @return {?}
         */
            function (codec) {
                /** @type {?} */
                var re = /"(.*?)"/g;
                /** @type {?} */
                var codecName = re.exec(codec);
                if (codecName !== undefined && !!codecName[1]) {
                    return codecName[1];
                }
                return;
            };
        return PlayerDash;
    }(Player));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var PlayerHls = /** @class */ (function (_super) {
        __extends(PlayerHls, _super);
        function PlayerHls(url, htmlPlayer, config) {
            return _super.call(this, url, htmlPlayer, config) || this;
        }
        /**
         * @return {?}
         */
        PlayerHls.prototype.load = /**
         * @return {?}
         */
            function () {
                this.reset();
                try {
                    if (Hls.isSupported()) {
                        this.player = new Hls();
                        this.player.loadSource(this.url);
                        this.player.attachMedia(this.htmlPlayer);
                        // an initial rendition needs to be loaded
                        if (this.config && typeof this.config.initialRenditionIndex === 'number') {
                            this.player.startLevel = this.config.initialRenditionIndex;
                        }
                        // hls is not supported but the native player is able to load the video
                        // some features (like renditions getter/setter) will NOT be available
                    }
                    else if (this.htmlPlayer.canPlayType('application/vnd.apple.mpegurl')) {
                        this.player = undefined;
                        this.htmlPlayer.src = this.url;
                    }
                    this.initListeners();
                    this.playerType = PlayerType.HLS;
                }
                catch (e) {
                    console.error(e);
                }
            };
        /**
         * @return {?}
         */
        PlayerHls.prototype.destroy = /**
         * @return {?}
         */
            function () {
                try {
                    this.htmlPlayer.src = '';
                    if (this.player !== undefined) {
                        this.player.destroy();
                    }
                }
                catch (e) {
                    console.warn(e);
                }
                finally {
                    this.playerType = undefined;
                }
            };
        /**
         * @return {?}
         */
        PlayerHls.prototype.getRenditions = /**
         * @return {?}
         */
            function () {
                if (this.player === undefined) {
                    return;
                }
                return this.convertLevelsToIRenditions(this.player.levels);
            };
        /**
         * @param {?} rendition
         * @param {?} immediately
         * @return {?}
         */
        PlayerHls.prototype.setRendition = /**
         * @param {?} rendition
         * @param {?} immediately
         * @return {?}
         */
            function (rendition, immediately) {
                if (this.player === undefined) {
                    return;
                }
                if (typeof rendition === 'number') {
                    if (immediately) {
                        this.player.currentLevel = rendition;
                    }
                    else {
                        this.player.loadLevel = rendition;
                    }
                    return;
                }
                else {
                    /** @type {?} */
                    var renditions = this.getRenditions();
                    if (renditions !== undefined && renditions.length > 0) {
                        for (var i = 0; i < renditions.length; i++) {
                            if (renditions[i].bitrate === rendition.bitrate) {
                                return this.setRendition(i, immediately);
                            }
                        }
                    }
                }
                return this.setRendition(-1, immediately);
            };
        /**
         * @return {?}
         */
        PlayerHls.prototype.getCurrentRendition = /**
         * @return {?}
         */
            function () {
                if (this.player === undefined) {
                    return;
                }
                /** @type {?} */
                var renditions = this.getRenditions();
                if (renditions !== undefined && renditions.length > 0) {
                    /** @type {?} */
                    var currentLevel = this.player.currentLevel;
                    if (currentLevel >= 0 && renditions.length > currentLevel) {
                        return renditions[currentLevel];
                    }
                }
                return;
            };
        // update any to Hls.Level[] after Hls.js typings fixing
        // update any to Hls.Level[] after Hls.js typings fixing
        /**
         * @private
         * @param {?} levels
         * @return {?}
         */
        PlayerHls.prototype.convertLevelsToIRenditions =
            // update any to Hls.Level[] after Hls.js typings fixing
            /**
             * @private
             * @param {?} levels
             * @return {?}
             */
            function (levels) {
                if (levels === undefined || levels.length === 0) {
                    return;
                }
                return levels.map(function (l) {
                    return {
                        audioCodec: l.audioCodec !== undefined ? l.audioCodec : undefined,
                        bitrate: l.bitrate !== undefined ? l.bitrate : undefined,
                        height: l.height !== undefined ? l.height : undefined,
                        level: l.level !== undefined ? l.level : undefined,
                        name: l.name !== undefined ? l.name : undefined,
                        videoCodec: l.videoCodec !== undefined ? l.videoCodec : undefined,
                        width: l.width !== undefined ? l.width : undefined,
                    };
                });
            };
        return PlayerHls;
    }(Player));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var NgxEpicVideoPlayerComponent = /** @class */ (function () {
        function NgxEpicVideoPlayerComponent() {
            var _this = this;
            /**
             * Regular HTML video event emitters
             */
            this.abortEvent = new i0.EventEmitter();
            this.canplayEvent = new i0.EventEmitter();
            this.canplaythroughEvent = new i0.EventEmitter();
            this.durationchangeEvent = new i0.EventEmitter();
            this.emptiedEvent = new i0.EventEmitter();
            this.endedEvent = new i0.EventEmitter();
            this.errorEvent = new i0.EventEmitter();
            this.loadeddataEvent = new i0.EventEmitter();
            this.loadedmetadataEvent = new i0.EventEmitter();
            this.loadstartEvent = new i0.EventEmitter();
            this.pauseEvent = new i0.EventEmitter();
            this.playEvent = new i0.EventEmitter();
            this.playingEvent = new i0.EventEmitter();
            this.progressEvent = new i0.EventEmitter();
            this.ratechangeEvent = new i0.EventEmitter();
            this.seekedEvent = new i0.EventEmitter();
            this.seekingEvent = new i0.EventEmitter();
            this.stalledEvent = new i0.EventEmitter();
            this.suspendEvent = new i0.EventEmitter();
            this.timeupdateEvent = new i0.EventEmitter();
            this.volumechangeEvent = new i0.EventEmitter();
            this.waitingEvent = new i0.EventEmitter();
            /**
             * Regular HTML video event listeners
             */
            this.abortListener = function (e) { return _this.abortEvent.emit({ type: 'abort' }); };
            this.canplayListener = function (e) { return _this.canplayEvent.emit({ type: 'canplay' }); };
            this.canplaythroughListener = function (e) {
                _this.canplaythroughEvent.emit({ type: 'canplaythrough' });
                if (_this.autoplay && _this.getHtmlVideo().paused) {
                    _this.play();
                }
            };
            this.durationchangeListener = function (e) { return _this.durationchangeEvent.emit({ type: 'durationchange' }); };
            this.emptiedListener = function (e) { return _this.emptiedEvent.emit({ type: 'emptied' }); };
            this.endedListener = function (e) { return _this.endedEvent.emit({ type: 'ended' }); };
            this.errorListener = function (e) { return _this.errorEvent.emit({ type: 'error', data: e }); };
            this.loadeddataListener = function (e) { return _this.loadeddataEvent.emit({ type: 'loadeddata' }); };
            this.loadedmetadataListener = function (e) { return _this.loadedmetadataEvent.emit({ type: 'loadedmetadata' }); };
            this.loadstartListener = function (e) { return _this.loadstartEvent.emit({ type: 'loadstart' }); };
            this.pauseListener = function (e) { return _this.pauseEvent.emit({ type: 'pause' }); };
            this.playListener = function (e) { return _this.playEvent.emit({ type: 'play' }); };
            this.playingListener = function (e) { return _this.playingEvent.emit({ type: 'playing' }); };
            this.progressListener = function (e) { return _this.progressEvent.emit({ type: 'progress' }); };
            this.ratechangeListener = function (e) { return _this.ratechangeEvent.emit({ type: 'ratechange', data: { playbackRate: _this.playbackRate() } }); };
            this.seekedListener = function (e) { return _this.seekedEvent.emit({ type: 'seeked' }); };
            this.seekingListener = function (e) { return _this.seekingEvent.emit({ type: 'seeking' }); };
            this.stalledListener = function (e) { return _this.stalledEvent.emit({ type: 'stalled' }); };
            this.suspendListener = function (e) { return _this.suspendEvent.emit({ type: 'suspend' }); };
            this.timeupdateListener = function (e) { return _this.timeupdateEvent.emit({ type: 'timeupdate', data: { currentTime: _this.currentTime() } }); };
            this.volumechangeListener = function (e) { return _this.volumechangeEvent.emit({ type: 'volumechange', data: { volume: _this.volume() } }); };
            this.waitingListener = function (e) { return _this.waitingEvent.emit({ type: 'waiting' }); };
        }
        Object.defineProperty(NgxEpicVideoPlayerComponent.prototype, "setUrl", {
            set: /**
             * @param {?} value
             * @return {?}
             */ function (value) {
                if (this.url !== value) {
                    this.destroy();
                    this.url = value;
                    if (value === undefined || value === '') {
                        this.errorEvent.emit({ type: 'error', 'data': { mssg: 'Provided video URL is empty.' } });
                        return;
                    }
                    this.init();
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NgxEpicVideoPlayerComponent.prototype, "setAutoplay", {
            set: /**
             * @param {?} value
             * @return {?}
             */ function (value) {
                this.autoplay = this.isTrue(value);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NgxEpicVideoPlayerComponent.prototype, "setMuted", {
            set: /**
             * @param {?} value
             * @return {?}
             */ function (value) {
                this.muted = this.isTrue(value);
                if (this.muted) {
                    this.volume(0);
                }
                else {
                    this.volume(1);
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NgxEpicVideoPlayerComponent.prototype, "setInitialRenditionKbps", {
            set: /**
             * @param {?} value
             * @return {?}
             */ function (value) {
                value = value !== undefined ? parseInt(value.toString(), 10) : undefined;
                if (!isNaN(value) && value !== this.initialRenditionKbps) {
                    this.initialRenditionKbps = value + 1;
                    if (this.player !== undefined && !!this.url) {
                        this.destroy();
                        this.init();
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(NgxEpicVideoPlayerComponent.prototype, "setinitialRenditionIndex", {
            set: /**
             * @param {?} value
             * @return {?}
             */ function (value) {
                value = value !== undefined ? parseInt(value.toString(), 10) : undefined;
                if (!isNaN(value) && value !== this.initialRenditionKbps) {
                    this.initialRenditionIndex = value;
                    if (this.player !== undefined && !!this.url) {
                        this.destroy();
                        this.init();
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                this.destroy();
            };
        /**
         * @param {?} value
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.isTrue = /**
         * @param {?} value
         * @return {?}
         */
            function (value) {
                return value === true || value === 'true';
            };
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.getStats = /**
         * @return {?}
         */
            function () {
                return this.player.getStats();
            };
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.getHtmlVideo = /**
         * @return {?}
         */
            function () {
                return this.htmlVideoRef.nativeElement;
            };
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.getRenditions = /**
         * @return {?}
         */
            function () {
                return this.player.getRenditions();
            };
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.getCurrentRendition = /**
         * @return {?}
         */
            function () {
                return this.player.getCurrentRendition();
            };
        /**
         * @param {?} rendition
         * @param {?=} immediately
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.setRendition = /**
         * @param {?} rendition
         * @param {?=} immediately
         * @return {?}
         */
            function (rendition, immediately) {
                return this.player.setRendition(rendition, immediately);
            };
        /**
         * @private
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.init = /**
         * @private
         * @return {?}
         */
            function () {
                try {
                    this.destroy();
                    this.createPlayer();
                    this.getHtmlVideo().addEventListener('abort', this.abortListener);
                    this.getHtmlVideo().addEventListener('canplay', this.canplayListener);
                    this.getHtmlVideo().addEventListener('canplaythrough', this.canplaythroughListener);
                    this.getHtmlVideo().addEventListener('durationchange', this.durationchangeListener);
                    this.getHtmlVideo().addEventListener('emptied', this.emptiedListener);
                    this.getHtmlVideo().addEventListener('ended', this.endedListener);
                    this.getHtmlVideo().addEventListener('error', this.errorListener);
                    this.getHtmlVideo().addEventListener('loadeddata', this.loadeddataListener);
                    this.getHtmlVideo().addEventListener('loadedmetadata', this.loadedmetadataListener);
                    this.getHtmlVideo().addEventListener('loadstart', this.loadstartListener);
                    this.getHtmlVideo().addEventListener('pause', this.pauseListener);
                    this.getHtmlVideo().addEventListener('play', this.playListener);
                    this.getHtmlVideo().addEventListener('playing', this.playingListener);
                    this.getHtmlVideo().addEventListener('progress', this.progressListener);
                    this.getHtmlVideo().addEventListener('ratechange', this.ratechangeListener);
                    this.getHtmlVideo().addEventListener('seeked', this.seekedListener);
                    this.getHtmlVideo().addEventListener('seeking', this.seekingListener);
                    this.getHtmlVideo().addEventListener('stalled', this.stalledListener);
                    this.getHtmlVideo().addEventListener('suspend', this.suspendListener);
                    this.getHtmlVideo().addEventListener('timeupdate', this.timeupdateListener);
                    this.getHtmlVideo().addEventListener('volumechange', this.volumechangeListener);
                    this.getHtmlVideo().addEventListener('waiting', this.waitingListener);
                }
                catch (e) {
                    console.error(e);
                }
            };
        /**
         * @private
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.createPlayer = /**
         * @private
         * @return {?}
         */
            function () {
                /** @type {?} */
                var filename = this.url.substr(this.url.lastIndexOf('/') + 1);
                /** @type {?} */
                var extension = filename.split('.').pop();
                /** @type {?} */
                var config = {
                    initialRenditionIndex: this.initialRenditionIndex,
                    initialRenditionKbps: this.initialRenditionKbps,
                };
                if (extension === 'm3u8') {
                    this.player = new PlayerHls(this.url, this.getHtmlVideo(), config);
                    (( /** @type {?} */(this.player.player))).on('keySystemNoKeys', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('keySystemNoAccess', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('keySystemNoSession', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('keySystemLicenseRequestFailed', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('manifestLoadError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('manifestLoadTimeOut', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('manifestParsingError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('manifestIncompatibleCodecsError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('levelLoadError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('levelLoadTimeOut', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('levelSwitchError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('audioTrackLoadError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('audioTrackLoadTimeOut', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('fragLoadError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('fragLoadTimeOut', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('fragDecryptError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('fragParsingError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('remuxAllocError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('keyLoadError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('keyLoadTimeOut', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferAddCodecError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferAppendError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferAppendingError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferStalledError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferFullError', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferSeekOverHole', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('bufferNudgeOnStall', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('internalException', this.errorListener);
                }
                else {
                    this.player = new PlayerDash(this.url, this.getHtmlVideo(), config);
                    (( /** @type {?} */(this.player.player))).on('error', this.errorListener);
                    (( /** @type {?} */(this.player.player))).on('playbackError', this.errorListener);
                }
            };
        /**
         * @private
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.destroy = /**
         * @private
         * @return {?}
         */
            function () {
                this.getHtmlVideo().removeEventListener('abort', this.abortListener);
                this.getHtmlVideo().removeEventListener('canplay', this.canplayListener);
                this.getHtmlVideo().removeEventListener('canplaythrough', this.canplaythroughListener);
                this.getHtmlVideo().removeEventListener('durationchange', this.durationchangeListener);
                this.getHtmlVideo().removeEventListener('emptied', this.emptiedListener);
                this.getHtmlVideo().removeEventListener('ended', this.endedListener);
                this.getHtmlVideo().removeEventListener('error', this.errorListener);
                this.getHtmlVideo().removeEventListener('loadeddata', this.loadeddataListener);
                this.getHtmlVideo().removeEventListener('loadedmetadata', this.loadedmetadataListener);
                this.getHtmlVideo().removeEventListener('loadstart', this.loadstartListener);
                this.getHtmlVideo().removeEventListener('pause', this.pauseListener);
                this.getHtmlVideo().removeEventListener('play', this.playListener);
                this.getHtmlVideo().removeEventListener('playing', this.playingListener);
                this.getHtmlVideo().removeEventListener('progress', this.progressListener);
                this.getHtmlVideo().removeEventListener('ratechange', this.ratechangeListener);
                this.getHtmlVideo().removeEventListener('seeked', this.seekedListener);
                this.getHtmlVideo().removeEventListener('seeking', this.seekingListener);
                this.getHtmlVideo().removeEventListener('stalled', this.stalledListener);
                this.getHtmlVideo().removeEventListener('suspend', this.suspendListener);
                this.getHtmlVideo().removeEventListener('timeupdate', this.timeupdateListener);
                this.getHtmlVideo().removeEventListener('volumechange', this.volumechangeListener);
                this.getHtmlVideo().removeEventListener('waiting', this.waitingListener);
                if (this.player) {
                    this.player.destroy();
                }
            };
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.pause = /**
         * @return {?}
         */
            function () {
                this.getHtmlVideo().pause();
            };
        /**
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.play = /**
         * @return {?}
         */
            function () {
                this.getHtmlVideo().play();
            };
        /**
         * @param {?=} secs
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.currentTime = /**
         * @param {?=} secs
         * @return {?}
         */
            function (secs) {
                if (secs !== undefined) {
                    this.getHtmlVideo().currentTime = secs;
                }
                else {
                    return this.getHtmlVideo().currentTime;
                }
            };
        /**
         * @param {?=} perc
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.volume = /**
         * @param {?=} perc
         * @return {?}
         */
            function (perc) {
                if (perc !== undefined) {
                    this.getHtmlVideo().volume = perc;
                }
                else {
                    return this.getHtmlVideo().volume;
                }
            };
        /**
         * @param {?=} rate
         * @return {?}
         */
        NgxEpicVideoPlayerComponent.prototype.playbackRate = /**
         * @param {?=} rate
         * @return {?}
         */
            function (rate) {
                if (rate !== undefined) {
                    this.getHtmlVideo().playbackRate = rate;
                }
                else {
                    return this.getHtmlVideo().playbackRate;
                }
            };
        NgxEpicVideoPlayerComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'vp-ngx-epic-video-player',
                        template: "<video #htmlVideoRef\n       [attr.poster]=\"!!poster ? poster : undefined\"\n       [attr.autoplay]=\"autoplay ? true : undefined\"\n       [attr.id]=\"videoId ? videoId : undefined\"\n       [attr.controls]=\"isTrue(controls) ? true : undefined\"\n       [attr.loop]=\"isTrue(loop) ? true : undefined\"\n       [attr.muted]=\"muted ? true : undefined\"></video>\n",
                        styles: ["video{width:100%}"]
                    }] }
        ];
        NgxEpicVideoPlayerComponent.propDecorators = {
            htmlVideoRef: [{ type: i0.ViewChild, args: ['htmlVideoRef',] }],
            setUrl: [{ type: i0.Input, args: ['url',] }],
            setAutoplay: [{ type: i0.Input, args: ['autoplay',] }],
            setMuted: [{ type: i0.Input, args: ['muted',] }],
            setInitialRenditionKbps: [{ type: i0.Input, args: ['initialRenditionKbps',] }],
            setinitialRenditionIndex: [{ type: i0.Input, args: ['initialRenditionIndex',] }],
            poster: [{ type: i0.Input }],
            videoId: [{ type: i0.Input }],
            controls: [{ type: i0.Input }],
            loop: [{ type: i0.Input }],
            abortEvent: [{ type: i0.Output }],
            canplayEvent: [{ type: i0.Output }],
            canplaythroughEvent: [{ type: i0.Output }],
            durationchangeEvent: [{ type: i0.Output }],
            emptiedEvent: [{ type: i0.Output }],
            endedEvent: [{ type: i0.Output }],
            errorEvent: [{ type: i0.Output }],
            loadeddataEvent: [{ type: i0.Output }],
            loadedmetadataEvent: [{ type: i0.Output }],
            loadstartEvent: [{ type: i0.Output }],
            pauseEvent: [{ type: i0.Output }],
            playEvent: [{ type: i0.Output }],
            playingEvent: [{ type: i0.Output }],
            progressEvent: [{ type: i0.Output }],
            ratechangeEvent: [{ type: i0.Output }],
            seekedEvent: [{ type: i0.Output }],
            seekingEvent: [{ type: i0.Output }],
            stalledEvent: [{ type: i0.Output }],
            suspendEvent: [{ type: i0.Output }],
            timeupdateEvent: [{ type: i0.Output }],
            volumechangeEvent: [{ type: i0.Output }],
            waitingEvent: [{ type: i0.Output }]
        };
        return NgxEpicVideoPlayerComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var NgxEpicVideoPlayerModule = /** @class */ (function () {
        function NgxEpicVideoPlayerModule() {
        }
        NgxEpicVideoPlayerModule.decorators = [
            { type: i0.NgModule, args: [{
                        imports: [],
                        declarations: [NgxEpicVideoPlayerComponent],
                        exports: [NgxEpicVideoPlayerComponent]
                    },] }
        ];
        return NgxEpicVideoPlayerModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */

    exports.NgxEpicVideoPlayerService = NgxEpicVideoPlayerService;
    exports.NgxEpicVideoPlayerComponent = NgxEpicVideoPlayerComponent;
    exports.NgxEpicVideoPlayerModule = NgxEpicVideoPlayerModule;
    exports.PlayerType = PlayerType;
    exports.Player = Player;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=ngx-epic-video-player.umd.js.map