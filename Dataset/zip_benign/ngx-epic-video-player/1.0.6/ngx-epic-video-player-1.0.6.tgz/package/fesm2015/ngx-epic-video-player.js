import { MediaPlayer } from 'dashjs';
import * as Hls from 'hls.js';
import { isSupported } from 'hls.js';
import { Injectable, NgModule, Component, EventEmitter, Input, Output, ViewChild, defineInjectable } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxEpicVideoPlayerService {
    constructor() { }
}
NgxEpicVideoPlayerService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
NgxEpicVideoPlayerService.ctorParameters = () => [];
/** @nocollapse */ NgxEpicVideoPlayerService.ngInjectableDef = defineInjectable({ factory: function NgxEpicVideoPlayerService_Factory() { return new NgxEpicVideoPlayerService(); }, token: NgxEpicVideoPlayerService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class Utils {
    /**
     * @param {?} htmlVideo
     * @return {?}
     */
    static getDroppedFrames(htmlVideo) {
        if (!htmlVideo) {
            return;
        }
        /** @type {?} */
        const hasWebKit = ('webkitDroppedFrameCount' in htmlVideo) && ('webkitDecodedFrameCount' in htmlVideo);
        /** @type {?} */
        const hasQuality = ('getVideoPlaybackQuality' in htmlVideo);
        if (hasQuality) {
            return ((/** @type {?} */ (htmlVideo))).getVideoPlaybackQuality();
        }
        else if (hasWebKit) {
            return ((/** @type {?} */ (htmlVideo))).webkitDroppedFrameCount;
        }
        return;
    }
    /**
     * @param {?} htmlVideo
     * @return {?}
     */
    static getDuration(htmlVideo) {
        if (!htmlVideo) {
            return;
        }
        return htmlVideo.duration;
    }
    /**
     * @param {?} htmlVideo
     * @return {?}
     */
    static getBuffered(htmlVideo) {
        if (!htmlVideo) {
            return;
        }
        return htmlVideo.buffered;
    }
    /**
     * @param {?} htmlVideo
     * @return {?}
     */
    static getSeekable(htmlVideo) {
        if (!htmlVideo) {
            return;
        }
        return htmlVideo.seekable;
    }
    /**
     * @param {?} htmlVideo
     * @return {?}
     */
    static getPlayed(htmlVideo) {
        if (!htmlVideo) {
            return;
        }
        return htmlVideo.played;
    }
    /**
     * @param {?} tr
     * @return {?}
     */
    static timeRangesToIStatsTimeRanges(tr) {
        /** @type {?} */
        const res = [];
        for (let i = 0; i < tr.length; i++) {
            res.push({ start: tr.start(i), end: tr.end(i) });
        }
        return res;
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @enum {number} */
const PlayerType = {
    DASH: 0,
    HLS: 1,
};
PlayerType[PlayerType.DASH] = 'DASH';
PlayerType[PlayerType.HLS] = 'HLS';
/**
 * @abstract
 * @template T
 */
class Player {
    /**
     * @protected
     * @param {?} url
     * @param {?} htmlPlayer
     * @param {?} config
     */
    constructor(url, htmlPlayer, config) {
        this.url = url;
        this.htmlPlayer = htmlPlayer;
        this.config = config;
        this.updateStats = () => {
            this.stats = {
                buffered: Utils.timeRangesToIStatsTimeRanges(Utils.getBuffered(this.htmlPlayer)),
                droppedFrames: Utils.getDroppedFrames(this.htmlPlayer),
                duration: Utils.getDuration(this.htmlPlayer),
                loadTime: this.stats.loadTime,
                played: Utils.timeRangesToIStatsTimeRanges(Utils.getPlayed(this.htmlPlayer)),
                seekable: Utils.timeRangesToIStatsTimeRanges(Utils.getSeekable(this.htmlPlayer)),
            };
        };
        this.loadStart = () => {
            this.updateStats();
            if (this.stats.loadTime === -1) {
                this.loadStartTime = (new Date()).getTime();
            }
        };
        this.loadEnd = () => {
            this.updateStats();
            if (this.stats.loadTime === -1) {
                this.stats.loadTime = ((new Date()).getTime() - this.loadStartTime) / 1000;
            }
            this.updateStats();
        };
        this.resetStats();
        this.load();
    }
    /**
     * @return {?}
     */
    getStats() {
        return this.stats;
    }
    /**
     * @return {?}
     */
    initListeners() {
        this.htmlPlayer.addEventListener('timeupdate', this.updateStats);
        this.htmlPlayer.addEventListener('loadstart', this.loadStart);
        this.htmlPlayer.addEventListener('canplay', this.loadEnd);
    }
    /**
     * @return {?}
     */
    destroyListeners() {
        this.htmlPlayer.removeEventListener('timeupdate', this.updateStats);
        this.htmlPlayer.removeEventListener('loadstart', this.loadStart);
        this.htmlPlayer.removeEventListener('canplay', this.loadEnd);
    }
    /**
     * @protected
     * @return {?}
     */
    reset() {
        this.destroyListeners();
        this.resetStats();
    }
    /**
     * @protected
     * @return {?}
     */
    resetStats() {
        this.stats = {
            buffered: [],
            duration: 0,
            droppedFrames: 0,
            loadTime: -1,
            played: [],
            seekable: [],
        };
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PlayerDash extends Player {
    /**
     * @param {?} url
     * @param {?} htmlPlayer
     * @param {?} config
     */
    constructor(url, htmlPlayer, config) {
        super(url, htmlPlayer, config);
    }
    /**
     * @return {?}
     */
    load() {
        this.reset();
        try {
            this.player = MediaPlayer().create();
            this.player.getDebug().setLogToBrowserConsole(false);
            this.player.initialize(this.htmlPlayer, this.url, false);
            // an initial rendition needs to be loaded
            if (this.config && typeof this.config.initialRenditionKbps === 'number') {
                this.player.setAutoSwitchQualityFor('video', false);
                this.player.enableLastBitrateCaching(false);
                this.player.setInitialBitrateFor('video', this.config.initialRenditionKbps);
            }
            this.initListeners();
            this.playerType = PlayerType.DASH;
        }
        catch (e) {
            console.error(e);
        }
    }
    /**
     * @return {?}
     */
    destroy() {
        try {
            if (this.player !== undefined) {
                this.player.reset();
            }
            this.playerType = undefined;
        }
        catch (e) {
            console.warn(e);
        }
    }
    /**
     * @return {?}
     */
    getRenditions() {
        if (this.player === undefined) {
            return;
        }
        return this.convertBitratesToIRenditions(this.player.getBitrateInfoListFor('video'));
    }
    /**
     * @param {?} rendition
     * @param {?} immediately
     * @return {?}
     */
    setRendition(rendition, immediately) {
        if (this.player === undefined) {
            return;
        }
        if (typeof rendition === 'number') {
            if (rendition === -1) {
                this.player.setAutoSwitchQualityFor('video', true);
            }
            else {
                this.player.setAutoSwitchQualityFor('video', false);
                this.player.enableLastBitrateCaching(false);
                this.player.setQualityFor('video', rendition);
            }
            return;
        }
        else {
            /** @type {?} */
            const renditions = this.getRenditions();
            if (renditions !== undefined && renditions.length > 0) {
                for (let i = 0; i < renditions.length; i++) {
                    if (renditions[i].bitrate === rendition.bitrate) {
                        return this.setRendition(i, immediately);
                    }
                }
            }
        }
        return this.setRendition(-1, immediately);
    }
    /**
     * @return {?}
     */
    getCurrentRendition() {
        if (this.player === undefined) {
            return;
        }
        /** @type {?} */
        const renditions = this.getRenditions();
        if (renditions !== undefined && renditions.length > 0) {
            /** @type {?} */
            const currentQuality = this.player.getQualityFor('video');
            if (currentQuality >= 0 && renditions.length > currentQuality) {
                return renditions[currentQuality];
            }
        }
        return;
    }
    /**
     * @private
     * @param {?} bitrates
     * @return {?}
     */
    convertBitratesToIRenditions(bitrates) {
        /** @type {?} */
        const videoInfo = this.player.getCurrentTrackFor('video');
        /** @type {?} */
        const audioInfo = this.player.getCurrentTrackFor('audio');
        if (bitrates === undefined || bitrates.length === 0) {
            return;
        }
        return bitrates.map((b) => {
            return {
                bitrate: b.bitrate !== undefined ? b.bitrate : undefined,
                height: b.height !== undefined ? b.height : undefined,
                level: b.qualityIndex !== undefined ? b.qualityIndex : undefined,
                width: b.width !== undefined ? b.width : undefined,
                videoCodec: videoInfo && videoInfo.codec ? this.getCodecName(videoInfo.codec) : undefined,
                audioCodec: audioInfo && audioInfo.codec ? this.getCodecName(audioInfo.codec) : undefined,
            };
        });
    }
    /**
     * @private
     * @param {?} codec
     * @return {?}
     */
    getCodecName(codec) {
        /** @type {?} */
        const re = /"(.*?)"/g;
        /** @type {?} */
        const codecName = re.exec(codec);
        if (codecName !== undefined && !!codecName[1]) {
            return codecName[1];
        }
        return;
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PlayerHls extends Player {
    /**
     * @param {?} url
     * @param {?} htmlPlayer
     * @param {?} config
     */
    constructor(url, htmlPlayer, config) {
        super(url, htmlPlayer, config);
    }
    /**
     * @return {?}
     */
    load() {
        this.reset();
        try {
            if (isSupported()) {
                this.player = new Hls();
                this.player.loadSource(this.url);
                this.player.attachMedia(this.htmlPlayer);
                // an initial rendition needs to be loaded
                if (this.config && typeof this.config.initialRenditionIndex === 'number') {
                    this.player.startLevel = this.config.initialRenditionIndex;
                }
                // hls is not supported but the native player is able to load the video
                // some features (like renditions getter/setter) will NOT be available
            }
            else if (this.htmlPlayer.canPlayType('application/vnd.apple.mpegurl')) {
                this.player = undefined;
                this.htmlPlayer.src = this.url;
            }
            this.initListeners();
            this.playerType = PlayerType.HLS;
        }
        catch (e) {
            console.error(e);
        }
    }
    /**
     * @return {?}
     */
    destroy() {
        try {
            this.htmlPlayer.src = '';
            if (this.player !== undefined) {
                this.player.destroy();
            }
        }
        catch (e) {
            console.warn(e);
        }
        finally {
            this.playerType = undefined;
        }
    }
    /**
     * @return {?}
     */
    getRenditions() {
        if (this.player === undefined) {
            return;
        }
        return this.convertLevelsToIRenditions(this.player.levels);
    }
    /**
     * @param {?} rendition
     * @param {?} immediately
     * @return {?}
     */
    setRendition(rendition, immediately) {
        if (this.player === undefined) {
            return;
        }
        if (typeof rendition === 'number') {
            if (immediately) {
                this.player.currentLevel = rendition;
            }
            else {
                this.player.loadLevel = rendition;
            }
            return;
        }
        else {
            /** @type {?} */
            const renditions = this.getRenditions();
            if (renditions !== undefined && renditions.length > 0) {
                for (let i = 0; i < renditions.length; i++) {
                    if (renditions[i].bitrate === rendition.bitrate) {
                        return this.setRendition(i, immediately);
                    }
                }
            }
        }
        return this.setRendition(-1, immediately);
    }
    /**
     * @return {?}
     */
    getCurrentRendition() {
        if (this.player === undefined) {
            return;
        }
        /** @type {?} */
        const renditions = this.getRenditions();
        if (renditions !== undefined && renditions.length > 0) {
            /** @type {?} */
            const currentLevel = this.player.currentLevel;
            if (currentLevel >= 0 && renditions.length > currentLevel) {
                return renditions[currentLevel];
            }
        }
        return;
    }
    // update any to Hls.Level[] after Hls.js typings fixing
    /**
     * @private
     * @param {?} levels
     * @return {?}
     */
    convertLevelsToIRenditions(levels) {
        if (levels === undefined || levels.length === 0) {
            return;
        }
        return levels.map(l => {
            return {
                audioCodec: l.audioCodec !== undefined ? l.audioCodec : undefined,
                bitrate: l.bitrate !== undefined ? l.bitrate : undefined,
                height: l.height !== undefined ? l.height : undefined,
                level: l.level !== undefined ? l.level : undefined,
                name: l.name !== undefined ? l.name : undefined,
                videoCodec: l.videoCodec !== undefined ? l.videoCodec : undefined,
                width: l.width !== undefined ? l.width : undefined,
            };
        });
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxEpicVideoPlayerComponent {
    constructor() {
        /**
         * Regular HTML video event emitters
         */
        this.abortEvent = new EventEmitter();
        this.canplayEvent = new EventEmitter();
        this.canplaythroughEvent = new EventEmitter();
        this.durationchangeEvent = new EventEmitter();
        this.emptiedEvent = new EventEmitter();
        this.endedEvent = new EventEmitter();
        this.errorEvent = new EventEmitter();
        this.loadeddataEvent = new EventEmitter();
        this.loadedmetadataEvent = new EventEmitter();
        this.loadstartEvent = new EventEmitter();
        this.pauseEvent = new EventEmitter();
        this.playEvent = new EventEmitter();
        this.playingEvent = new EventEmitter();
        this.progressEvent = new EventEmitter();
        this.ratechangeEvent = new EventEmitter();
        this.seekedEvent = new EventEmitter();
        this.seekingEvent = new EventEmitter();
        this.stalledEvent = new EventEmitter();
        this.suspendEvent = new EventEmitter();
        this.timeupdateEvent = new EventEmitter();
        this.volumechangeEvent = new EventEmitter();
        this.waitingEvent = new EventEmitter();
        /**
         * Regular HTML video event listeners
         */
        this.abortListener = (e) => this.abortEvent.emit({ type: 'abort' });
        this.canplayListener = (e) => this.canplayEvent.emit({ type: 'canplay' });
        this.canplaythroughListener = (e) => {
            this.canplaythroughEvent.emit({ type: 'canplaythrough' });
            if (this.autoplay && this.getHtmlVideo().paused) {
                this.play();
            }
        };
        this.durationchangeListener = (e) => this.durationchangeEvent.emit({ type: 'durationchange' });
        this.emptiedListener = (e) => this.emptiedEvent.emit({ type: 'emptied' });
        this.endedListener = (e) => this.endedEvent.emit({ type: 'ended' });
        this.errorListener = (e) => this.errorEvent.emit({ type: 'error', data: e });
        this.loadeddataListener = (e) => this.loadeddataEvent.emit({ type: 'loadeddata' });
        this.loadedmetadataListener = (e) => this.loadedmetadataEvent.emit({ type: 'loadedmetadata' });
        this.loadstartListener = (e) => this.loadstartEvent.emit({ type: 'loadstart' });
        this.pauseListener = (e) => this.pauseEvent.emit({ type: 'pause' });
        this.playListener = (e) => this.playEvent.emit({ type: 'play' });
        this.playingListener = (e) => this.playingEvent.emit({ type: 'playing' });
        this.progressListener = (e) => this.progressEvent.emit({ type: 'progress' });
        this.ratechangeListener = (e) => this.ratechangeEvent.emit({ type: 'ratechange', data: { playbackRate: this.playbackRate() } });
        this.seekedListener = (e) => this.seekedEvent.emit({ type: 'seeked' });
        this.seekingListener = (e) => this.seekingEvent.emit({ type: 'seeking' });
        this.stalledListener = (e) => this.stalledEvent.emit({ type: 'stalled' });
        this.suspendListener = (e) => this.suspendEvent.emit({ type: 'suspend' });
        this.timeupdateListener = (e) => this.timeupdateEvent.emit({ type: 'timeupdate', data: { currentTime: this.currentTime() } });
        this.volumechangeListener = (e) => this.volumechangeEvent.emit({ type: 'volumechange', data: { volume: this.volume() } });
        this.waitingListener = (e) => this.waitingEvent.emit({ type: 'waiting' });
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set setUrl(value) {
        if (this.url !== value) {
            this.destroy();
            this.url = value;
            if (value === undefined || value === '') {
                this.errorEvent.emit({ type: 'error', 'data': { mssg: 'Provided video URL is empty.' } });
                return;
            }
            this.init();
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set setAutoplay(value) {
        this.autoplay = this.isTrue(value);
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set setMuted(value) {
        this.muted = this.isTrue(value);
        if (this.muted) {
            this.volume(0);
        }
        else {
            this.volume(1);
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set setInitialRenditionKbps(value) {
        value = value !== undefined ? parseInt(value.toString(), 10) : undefined;
        if (!isNaN(value) && value !== this.initialRenditionKbps) {
            this.initialRenditionKbps = value + 1;
            if (this.player !== undefined && !!this.url) {
                this.destroy();
                this.init();
            }
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set setinitialRenditionIndex(value) {
        value = value !== undefined ? parseInt(value.toString(), 10) : undefined;
        if (!isNaN(value) && value !== this.initialRenditionKbps) {
            this.initialRenditionIndex = value;
            if (this.player !== undefined && !!this.url) {
                this.destroy();
                this.init();
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.destroy();
    }
    /**
     * @param {?} value
     * @return {?}
     */
    isTrue(value) {
        return value === true || value === 'true';
    }
    /**
     * @return {?}
     */
    getStats() {
        return this.player.getStats();
    }
    /**
     * @return {?}
     */
    getHtmlVideo() {
        return this.htmlVideoRef.nativeElement;
    }
    /**
     * @return {?}
     */
    getRenditions() {
        return this.player.getRenditions();
    }
    /**
     * @return {?}
     */
    getCurrentRendition() {
        return this.player.getCurrentRendition();
    }
    /**
     * @param {?} rendition
     * @param {?=} immediately
     * @return {?}
     */
    setRendition(rendition, immediately) {
        return this.player.setRendition(rendition, immediately);
    }
    /**
     * @private
     * @return {?}
     */
    init() {
        try {
            this.destroy();
            this.createPlayer();
            this.getHtmlVideo().addEventListener('abort', this.abortListener);
            this.getHtmlVideo().addEventListener('canplay', this.canplayListener);
            this.getHtmlVideo().addEventListener('canplaythrough', this.canplaythroughListener);
            this.getHtmlVideo().addEventListener('durationchange', this.durationchangeListener);
            this.getHtmlVideo().addEventListener('emptied', this.emptiedListener);
            this.getHtmlVideo().addEventListener('ended', this.endedListener);
            this.getHtmlVideo().addEventListener('error', this.errorListener);
            this.getHtmlVideo().addEventListener('loadeddata', this.loadeddataListener);
            this.getHtmlVideo().addEventListener('loadedmetadata', this.loadedmetadataListener);
            this.getHtmlVideo().addEventListener('loadstart', this.loadstartListener);
            this.getHtmlVideo().addEventListener('pause', this.pauseListener);
            this.getHtmlVideo().addEventListener('play', this.playListener);
            this.getHtmlVideo().addEventListener('playing', this.playingListener);
            this.getHtmlVideo().addEventListener('progress', this.progressListener);
            this.getHtmlVideo().addEventListener('ratechange', this.ratechangeListener);
            this.getHtmlVideo().addEventListener('seeked', this.seekedListener);
            this.getHtmlVideo().addEventListener('seeking', this.seekingListener);
            this.getHtmlVideo().addEventListener('stalled', this.stalledListener);
            this.getHtmlVideo().addEventListener('suspend', this.suspendListener);
            this.getHtmlVideo().addEventListener('timeupdate', this.timeupdateListener);
            this.getHtmlVideo().addEventListener('volumechange', this.volumechangeListener);
            this.getHtmlVideo().addEventListener('waiting', this.waitingListener);
        }
        catch (e) {
            console.error(e);
        }
    }
    /**
     * @private
     * @return {?}
     */
    createPlayer() {
        /** @type {?} */
        const filename = this.url.substr(this.url.lastIndexOf('/') + 1);
        /** @type {?} */
        const extension = filename.split('.').pop();
        /** @type {?} */
        const config = {
            initialRenditionIndex: this.initialRenditionIndex,
            initialRenditionKbps: this.initialRenditionKbps,
        };
        if (extension === 'm3u8') {
            this.player = new PlayerHls(this.url, this.getHtmlVideo(), config);
            ((/** @type {?} */ (this.player.player))).on('keySystemNoKeys', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('keySystemNoAccess', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('keySystemNoSession', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('keySystemLicenseRequestFailed', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('manifestLoadError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('manifestLoadTimeOut', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('manifestParsingError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('manifestIncompatibleCodecsError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('levelLoadError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('levelLoadTimeOut', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('levelSwitchError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('audioTrackLoadError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('audioTrackLoadTimeOut', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('fragLoadError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('fragLoadTimeOut', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('fragDecryptError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('fragParsingError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('remuxAllocError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('keyLoadError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('keyLoadTimeOut', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferAddCodecError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferAppendError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferAppendingError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferStalledError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferFullError', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferSeekOverHole', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('bufferNudgeOnStall', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('internalException', this.errorListener);
        }
        else {
            this.player = new PlayerDash(this.url, this.getHtmlVideo(), config);
            ((/** @type {?} */ (this.player.player))).on('error', this.errorListener);
            ((/** @type {?} */ (this.player.player))).on('playbackError', this.errorListener);
        }
    }
    /**
     * @private
     * @return {?}
     */
    destroy() {
        this.getHtmlVideo().removeEventListener('abort', this.abortListener);
        this.getHtmlVideo().removeEventListener('canplay', this.canplayListener);
        this.getHtmlVideo().removeEventListener('canplaythrough', this.canplaythroughListener);
        this.getHtmlVideo().removeEventListener('durationchange', this.durationchangeListener);
        this.getHtmlVideo().removeEventListener('emptied', this.emptiedListener);
        this.getHtmlVideo().removeEventListener('ended', this.endedListener);
        this.getHtmlVideo().removeEventListener('error', this.errorListener);
        this.getHtmlVideo().removeEventListener('loadeddata', this.loadeddataListener);
        this.getHtmlVideo().removeEventListener('loadedmetadata', this.loadedmetadataListener);
        this.getHtmlVideo().removeEventListener('loadstart', this.loadstartListener);
        this.getHtmlVideo().removeEventListener('pause', this.pauseListener);
        this.getHtmlVideo().removeEventListener('play', this.playListener);
        this.getHtmlVideo().removeEventListener('playing', this.playingListener);
        this.getHtmlVideo().removeEventListener('progress', this.progressListener);
        this.getHtmlVideo().removeEventListener('ratechange', this.ratechangeListener);
        this.getHtmlVideo().removeEventListener('seeked', this.seekedListener);
        this.getHtmlVideo().removeEventListener('seeking', this.seekingListener);
        this.getHtmlVideo().removeEventListener('stalled', this.stalledListener);
        this.getHtmlVideo().removeEventListener('suspend', this.suspendListener);
        this.getHtmlVideo().removeEventListener('timeupdate', this.timeupdateListener);
        this.getHtmlVideo().removeEventListener('volumechange', this.volumechangeListener);
        this.getHtmlVideo().removeEventListener('waiting', this.waitingListener);
        if (this.player) {
            this.player.destroy();
        }
    }
    /**
     * @return {?}
     */
    pause() {
        this.getHtmlVideo().pause();
    }
    /**
     * @return {?}
     */
    play() {
        this.getHtmlVideo().play();
    }
    /**
     * @param {?=} secs
     * @return {?}
     */
    currentTime(secs) {
        if (secs !== undefined) {
            this.getHtmlVideo().currentTime = secs;
        }
        else {
            return this.getHtmlVideo().currentTime;
        }
    }
    /**
     * @param {?=} perc
     * @return {?}
     */
    volume(perc) {
        if (perc !== undefined) {
            this.getHtmlVideo().volume = perc;
        }
        else {
            return this.getHtmlVideo().volume;
        }
    }
    /**
     * @param {?=} rate
     * @return {?}
     */
    playbackRate(rate) {
        if (rate !== undefined) {
            this.getHtmlVideo().playbackRate = rate;
        }
        else {
            return this.getHtmlVideo().playbackRate;
        }
    }
}
NgxEpicVideoPlayerComponent.decorators = [
    { type: Component, args: [{
                selector: 'vp-ngx-epic-video-player',
                template: "<video #htmlVideoRef\n       [attr.poster]=\"!!poster ? poster : undefined\"\n       [attr.autoplay]=\"autoplay ? true : undefined\"\n       [attr.id]=\"videoId ? videoId : undefined\"\n       [attr.controls]=\"isTrue(controls) ? true : undefined\"\n       [attr.loop]=\"isTrue(loop) ? true : undefined\"\n       [attr.muted]=\"muted ? true : undefined\"></video>\n",
                styles: ["video{width:100%}"]
            }] }
];
NgxEpicVideoPlayerComponent.propDecorators = {
    htmlVideoRef: [{ type: ViewChild, args: ['htmlVideoRef',] }],
    setUrl: [{ type: Input, args: ['url',] }],
    setAutoplay: [{ type: Input, args: ['autoplay',] }],
    setMuted: [{ type: Input, args: ['muted',] }],
    setInitialRenditionKbps: [{ type: Input, args: ['initialRenditionKbps',] }],
    setinitialRenditionIndex: [{ type: Input, args: ['initialRenditionIndex',] }],
    poster: [{ type: Input }],
    videoId: [{ type: Input }],
    controls: [{ type: Input }],
    loop: [{ type: Input }],
    abortEvent: [{ type: Output }],
    canplayEvent: [{ type: Output }],
    canplaythroughEvent: [{ type: Output }],
    durationchangeEvent: [{ type: Output }],
    emptiedEvent: [{ type: Output }],
    endedEvent: [{ type: Output }],
    errorEvent: [{ type: Output }],
    loadeddataEvent: [{ type: Output }],
    loadedmetadataEvent: [{ type: Output }],
    loadstartEvent: [{ type: Output }],
    pauseEvent: [{ type: Output }],
    playEvent: [{ type: Output }],
    playingEvent: [{ type: Output }],
    progressEvent: [{ type: Output }],
    ratechangeEvent: [{ type: Output }],
    seekedEvent: [{ type: Output }],
    seekingEvent: [{ type: Output }],
    stalledEvent: [{ type: Output }],
    suspendEvent: [{ type: Output }],
    timeupdateEvent: [{ type: Output }],
    volumechangeEvent: [{ type: Output }],
    waitingEvent: [{ type: Output }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxEpicVideoPlayerModule {
}
NgxEpicVideoPlayerModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                declarations: [NgxEpicVideoPlayerComponent],
                exports: [NgxEpicVideoPlayerComponent]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { NgxEpicVideoPlayerService, NgxEpicVideoPlayerComponent, NgxEpicVideoPlayerModule, PlayerType, Player };

//# sourceMappingURL=ngx-epic-video-player.js.map