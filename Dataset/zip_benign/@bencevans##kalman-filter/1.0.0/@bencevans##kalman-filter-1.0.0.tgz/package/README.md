# @bencevans/kalman-filter

> Typescript / JavaScript Implementation of Kalman Filter

## Install

    npm install --save @bencevans/kalman-filter

## Example (Single Measurement)

```js
> import KalmanFilter from '@bencevans/kalman-filter';

> const filter = new KalmanFilter({
    initialEstimate: 0,
    initialErrorInEstimate: 1
  })

> const [estimate, errorInEstimate] = filter.update({
    measurement: 20,
    errorInMeasurement: 0
  });

> estimate
20
> errorInEstimate
0
```

## Example (Multiple Measurements)

Measurements with multiple numeric values e.g. coordinates.

```js
> import { KalmanFilterArray } from '@bencevans/kalman-filter';

> const filter = new KalmanFilterArray({
    initialEstimate: [0, 1],
    initialErrorInEstimate: 1
  })

> const [estimate, errorInEstimate] = filter.update({
    measurement: [1, 1],
    errorInMeasurement: 0.4
  });

> estimate
[ 0.7142857142857143, 1 ]
> errorInEstimate
0.2857142857142857
```

## Related:

* https://en.wikipedia.org/wiki/Kalman_filter
* https://www.youtube.com/watch?v=CaCcOwJPytQ&list=PLX2gX-ftPVXU3oUFNATxGXY90AULiqnWT