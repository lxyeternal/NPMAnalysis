import * as test from "tape";
import KalmanFilter, { KalmanFilterArray } from ".";

test("single run", t => {
  const filter = new KalmanFilter({
    initialEstimate: 0,
    initialErrorInEstimate: 1
  });

  const [estimate, errorInEstimate] = filter.update({
    measurement: 20,
    errorInMeasurement: 0
  });

  t.equal(estimate, 20);
  t.equal(errorInEstimate, 0);

  t.end();
});

test("multi run", t => {
  const filter = new KalmanFilter({
    initialEstimate: 68,
    initialErrorInEstimate: 2
  });

  let [estimate, errorInEstimate] = filter.update({
    measurement: 75,
    errorInMeasurement: 4
  });

  t.equal(estimate.toFixed(2), "70.33");
  t.equal(errorInEstimate.toFixed(2), "1.33");

  [estimate, errorInEstimate] = filter.update({
    measurement: 71,
    errorInMeasurement: 4
  });

  t.equal(estimate.toFixed(2), "70.50");
  t.equal(errorInEstimate.toFixed(2), "1.00");

  [estimate, errorInEstimate] = filter.update({
    measurement: 70,
    errorInMeasurement: 4
  });

  t.equal(estimate.toFixed(2), "70.40");
  t.equal(errorInEstimate.toFixed(2), "0.80");

  [estimate, errorInEstimate] = filter.update({
    measurement: 74,
    errorInMeasurement: 4
  });

  t.equal(estimate.toFixed(2), "71.00");
  t.equal(errorInEstimate.toFixed(2), "0.67");

  t.end();
});
