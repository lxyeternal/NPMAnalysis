import type { OptionType } from './types';
import type { Root } from 'postcss';
declare const postcssPxToViewport: (options: OptionType) => {
    postcssPlugin: string;
    Once(css: Root, { result }: {
        result: any;
    }): void;
};
export default postcssPxToViewport;
export { postcssPxToViewport };
