(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (factory((global.Chroma = {})));
}(this, (function (exports) { 'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }

    return obj;
  }

  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread();
  }

  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) {
      for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) arr2[i] = arr[i];

      return arr2;
    }
  }

  function _iterableToArray(iter) {
    if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter);
  }

  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance");
  }

  var COLOR_MODES = ['RGB', 'HSL', 'HSV', 'Hex', 'CMYK', 'Numeric', 'Bits'];
  var PREFERRED_CONVERSIONS = {
    RGB: ['Hex', 'CMYK'],
    HSL: ['HSV', 'RGB'],
    HSV: ['HSL', 'RGB'],
    Hex: ['RGB', 'CMYK'],
    CMYK: ['RGB', 'Hex'],
    Numeric: ['RGB', 'Hex', 'CMYK'],
    Bits: ['Numeric', 'Hex']
  };
  var MODE_PROPS = {
    RGB: ['r', 'g', 'b'],
    HSL: ['h', 's', 'l'],
    HSV: ['h', 's', 'v'],
    Hex: function Hex(val) {
      return typeof val === 'string';
    },
    CMYK: ['c', 'm', 'y', 'k'],
    Numeric: function Numeric(val) {
      return typeof val === 'number';
    },
    Bits: function Bits(val) {
      return val instanceof Array;
    }
  };

  /**
   * Safe mod. Accounts for negative numbers. Always returns the positive mod.
   * 
   * @param {number} n The number to mod.
   * @param {number} modulo The number to mod by.
   * 
   * @returns {number} The adjusted mod result.
   */
  function mod(n, modulo) {
    return (n % modulo + modulo) % modulo;
  }
  /**
   * Naive left pad. Ensure a string is at least {len} in length by prepending the string
   * with a repeated character.
   * 
   * @param {string} inp A string to pad.
   * @param {number} len Length the output string must be.
   * @param {string} char The character to use to pad the string.
   * 
   * @return {string} The paded string.
   */

  function padStart(inp, len, char) {
    while (inp.length < len) {
      inp = char + inp;
    }

    return inp;
  }

  var RGB = {
    toRGB: function toRGB(colorData) {
      return colorData;
    },
    toHSL: function toHSL(colorData) {
      var r = colorData.RGB.r / 255,
          g = colorData.RGB.g / 255,
          b = colorData.RGB.b / 255,
          cMax = Math.max(r, Math.max(g, b)),
          cMin = Math.min(r, Math.min(g, b)),
          delta = cMax - cMin,
          l = (cMax + cMin) / 2,
          h = delta && (cMax === r ? mod((g - b) / delta, 6) : cMax === g ? (b - r) / delta + 2 : (r - g) / delta + 4) * 60,
          s = delta && delta / (1 - Math.abs(2 * l - 1));
      return colorData.set('HSL', {
        h: h,
        s: s,
        l: l
      });
    },
    toHSV: function toHSV(colorData) {
      var r = colorData.RGB.r / 255,
          g = colorData.RGB.g / 255,
          b = colorData.RGB.b / 255,
          cMax = Math.max(r, Math.max(g, b)),
          cMin = Math.min(r, Math.min(g, b)),
          delta = cMax - cMin;
      return colorData.set('HSV', {
        h: delta && (cMax === r ? mod((g - b) / delta, 6) : cMax === g ? (b - r) / delta + 2 : (r - g) / delta + 4) * 60,
        s: cMax && delta / cMax,
        v: cMax
      });
    },
    toHex: function toHex(colorData) {
      var _colorData$RGB = colorData.RGB,
          r = _colorData$RGB.r,
          g = _colorData$RGB.g,
          b = _colorData$RGB.b;
      return colorData.set('Hex', '#' + padStart(Math.round(r).toString(16), 2, '0') + padStart(Math.round(g).toString(16), 2, '0') + padStart(Math.round(b).toString(16), 2, '0'));
    },
    toCMYK: function toCMYK(colorData) {
      var r = colorData.RGB.r / 255,
          g = colorData.RGB.g / 255,
          b = colorData.RGB.b / 255,
          k = 1 - Math.max(r, Math.max(g, b)),
          c = 1 - k && (1 - r - k) / (1 - k),
          m = 1 - k && (1 - g - k) / (1 - k),
          y = 1 - k && (1 - b - k) / (1 - k);
      return colorData.set('CMYK', {
        c: c,
        m: m,
        y: y,
        k: k
      });
    },
    toNumeric: function toNumeric(colorData) {
      return colorData.set('Numeric', Math.round(colorData.RGB.r) * 0x10000 + Math.round(colorData.RGB.g) * 0x100 + Math.round(colorData.RGB.b));
    },
    toBits: function toBits(colorData) {
      var RGB = colorData.RGB,
          r = Math.round(RGB.r),
          g = Math.round(RGB.g),
          b = Math.round(RGB.b),
          i = 8,
          bits = [];

      while (i--) {
        bits.unshift((b & 1) === 1);
        b = b >> 1;
      }

      i = 8;

      while (i--) {
        bits.unshift((g & 1) === 1);
        g = g >> 1;
      }

      i = 8;

      while (i--) {
        bits.unshift((r & 1) === 1);
        r = r >> 1;
      }

      return colorData.set('Bits', bits);
    }
  };

  var HSL = {
    toRGB: function toRGB(colorData) {
      var h = mod(colorData.HSL.h, 360),
          _colorData$HSL = colorData.HSL,
          s = _colorData$HSL.s,
          l = _colorData$HSL.l,
          c = (1 - Math.abs(2 * l - 1)) * s,
          x = c * (1 - Math.abs(h / 60 % 2 - 1)),
          m = l - c / 2,
          hPrime = Math.floor(h / 60),
          rPrime = 0,
          gPrime = 0,
          bPrime = 0;

      switch (hPrime) {
        case 0:
          rPrime = c;
          gPrime = x;
          break;

        case 1:
          gPrime = c;
          rPrime = x;
          break;

        case 2:
          gPrime = c;
          bPrime = x;
          break;

        case 3:
          bPrime = c;
          gPrime = x;
          break;

        case 4:
          bPrime = c;
          rPrime = x;
          break;

        case 5:
          rPrime = c;
          bPrime = x;
          break;
      }

      return colorData.set('RGB', {
        r: (rPrime + m) * 255,
        g: (gPrime + m) * 255,
        b: (bPrime + m) * 255
      });
    },
    toHSL: function toHSL(colorData) {
      return colorData;
    },
    toHSV: function toHSV(colorData) {
      var _colorData$HSL2 = colorData.HSL,
          h = _colorData$HSL2.h,
          s = _colorData$HSL2.s,
          l = _colorData$HSL2.l;
      s *= 0.5 - Math.abs(l - 0.5);
      return colorData.set('HSV', {
        h: h,
        s: l + s && 2 * s / (l + s),
        v: l + s
      });
    },
    toHex: function toHex(colorData) {
      return RGB.toHex(HSL.toRGB(colorData));
    },
    toCMYK: function toCMYK(colorData) {
      return RGB.toCMYK(HSL.toRGB(colorData));
    },
    toNumeric: function toNumeric(colorData) {
      return RGB.toNumeric(HSL.toRGB(colorData));
    },
    toBits: function toBits(colorData) {
      return RGB.toBits(HSL.toRGB(colorData));
    }
  };

  var HSV = {
    toRGB: function toRGB(colorData) {
      var h = mod(colorData.HSV.h, 360),
          _colorData$HSV = colorData.HSV,
          s = _colorData$HSV.s,
          v = _colorData$HSV.v,
          c = v * s,
          x = c * (1 - Math.abs(h / 60 % 2 - 1)),
          m = v - c,
          hPrime = Math.floor(h / 60),
          rPrime = 0,
          gPrime = 0,
          bPrime = 0;

      switch (hPrime) {
        case 0:
          rPrime = c;
          gPrime = x;
          break;

        case 1:
          gPrime = c;
          rPrime = x;
          break;

        case 2:
          gPrime = c;
          bPrime = x;
          break;

        case 3:
          bPrime = c;
          gPrime = x;
          break;

        case 4:
          bPrime = c;
          rPrime = x;
          break;

        case 5:
          rPrime = c;
          bPrime = x;
          break;
      }

      return colorData.set('RGB', {
        r: (rPrime + m) * 255,
        g: (gPrime + m) * 255,
        b: (bPrime + m) * 255
      });
    },
    toHSL: function toHSL(colorData) {
      var _colorData$HSV2 = colorData.HSV,
          h = _colorData$HSV2.h,
          s = _colorData$HSV2.s,
          v = _colorData$HSV2.v,
          c = (2 - s) * v,
          m = c < 1 ? c : 2 - c;
      return colorData.set('HSL', {
        h: h,
        s: m && s * v / m,
        l: c / 2
      });
    },
    toHSV: function toHSV(colorData) {
      return colorData;
    },
    toHex: function toHex(colorData) {
      return RGB.toHex(HSV.toRGB(colorData));
    },
    toCMYK: function toCMYK(colorData) {
      return RGB.toCMYK(HSV.toRGB(colorData));
    },
    toNumeric: function toNumeric(colorData) {
      return RGB.toNumeric(HSV.toRGB(colorData));
    },
    toBits: function toBits(colorData) {
      return RGB.toBits(HSV.toRGB(colorData));
    }
  };

  var Hex = {
    toRGB: function toRGB(colorData) {
      var hex = colorData.Hex;
      return colorData.set('RGB', {
        r: parseInt(hex.substring(1, 3), 16),
        g: parseInt(hex.substring(3, 5), 16),
        b: parseInt(hex.substring(5, 7), 16)
      });
    },
    toHSL: function toHSL(colorData) {
      return RGB.toHSL(Hex.toRGB(colorData));
    },
    toHSV: function toHSV(colorData) {
      return RGB.toHSV(Hex.toRGB(colorData));
    },
    toHex: function toHex(colorData) {
      return colorData;
    },
    toCMYK: function toCMYK(colorData) {
      return RGB.toCMYK(Hex.toRGB(colorData));
    },
    toNumeric: function toNumeric(colorData) {
      return colorData.set('Numeric', parseInt(colorData.Hex.substring(1), 16));
    },
    toBits: function toBits(colorData) {
      return RGB.toBits(Hex.toRGB(colorData));
    }
  };

  var CMYK = {
    toRGB: function toRGB(colorData) {
      var _colorData$CMYK = colorData.CMYK,
          c = _colorData$CMYK.c,
          m = _colorData$CMYK.m,
          y = _colorData$CMYK.y,
          k = _colorData$CMYK.k;
      return colorData.set('RGB', {
        r: 255 * (1 - c) * (1 - k),
        g: 255 * (1 - m) * (1 - k),
        b: 255 * (1 - y) * (1 - k)
      });
    },
    toHSL: function toHSL(colorData) {
      return RGB.toHSL(CMYK.toRGB(colorData));
    },
    toHSV: function toHSV(colorData) {
      return RGB.toHSV(CMYK.toRGB(colorData));
    },
    toHex: function toHex(colorData) {
      return RGB.toHex(CMYK.toRGB(colorData));
    },
    toCMYK: function toCMYK(colorData) {
      return colorData;
    },
    toNumeric: function toNumeric(colorData) {
      return RGB.toNumeric(CMYK.toRGB(colorData));
    },
    toBits: function toBits(colorData) {
      return RGB.toBits(CMYK.toRGB(colorData));
    }
  };

  var Numeric = {
    toRGB: function toRGB(colorData) {
      return colorData.set('RGB', {
        r: Math.floor(colorData.Numeric / 0x10000),
        g: Math.floor(colorData.Numeric % 0x10000 / 0x100),
        b: colorData.Numeric % 0x100
      });
    },
    toHSL: function toHSL(colorData) {
      return RGB.toHSL(Numeric.toRGB(colorData));
    },
    toHSV: function toHSV(colorData) {
      return RGB.toHSV(Numeric.toRGB(colorData));
    },
    toHex: function toHex(colorData) {
      return RGB.toHex(Numeric.toRGB(colorData));
    },
    toCMYK: function toCMYK(colorData) {
      return RGB.toCMYK(Numeric.toRGB(colorData));
    },
    toNumeric: function toNumeric(colorData) {
      return colorData;
    },
    toBits: function toBits(colorData) {
      var numeric = colorData.Numeric,
          i = 24,
          bits = [];

      while (i--) {
        bits.unshift((numeric & 1) === 1);
        numeric = numeric >> 1;
      }

      return colorData.set('Bits', bits);
    }
  };

  var Bits = {
    toRGB: function toRGB(colorData) {
      return colorData.set('RGB', colorData.Bits.reduce(function (rgb, bit, i) {
        if (i < 8) {
          rgb.r = rgb.r << 1 | bit;
        } else if (i < 16) {
          rgb.g = rgb.g << 1 | bit;
        } else {
          rgb.b = rgb.b << 1 | bit;
        }

        return rgb;
      }, {
        r: 0,
        g: 0,
        b: 0
      }));
    },
    toHSL: function toHSL(colorData) {
      return RGB.toHSL(Bits.toRGB(colorData));
    },
    toHSV: function toHSV(colorData) {
      return RGB.toHSV(Bits.toRGB(colorData));
    },
    toHex: function toHex(colorData) {
      return RGB.toHex(Bits.toRGB(colorData));
    },
    toCMYK: function toCMYK(colorData) {
      return RGB.toCMYK(Bits.toRGB(colorData));
    },
    toNumeric: function toNumeric(colorData) {
      return colorData.set('Numeric', colorData.Bits.reduce(function (hex, bit) {
        return hex << 1 | bit;
      }, 0));
    },
    toBits: function toBits(colorData) {
      return colorData;
    }
  };

  var Null = {
    toRGB: function toRGB(colorData) {
      return colorData;
    },
    toHSL: function toHSL(colorData) {
      return colorData;
    },
    toHSV: function toHSV(colorData) {
      return colorData;
    },
    toHex: function toHex(colorData) {
      return colorData;
    },
    toCMYK: function toCMYK(colorData) {
      return colorData;
    },
    toNumeric: function toNumeric(colorData) {
      return colorData;
    },
    toBits: function toBits(colorData) {
      return colorData;
    }
  };

  var Converters = {
    RGB: RGB,
    HSL: HSL,
    HSV: HSV,
    Hex: Hex,
    CMYK: CMYK,
    Numeric: Numeric,
    Bits: Bits,
    Null: Null
  };

  /**
   * @class ColorData
   *
   * Includes properties for each color mode.
   */

  var ColorData =
  /*#__PURE__*/
  function () {
    /**
     * Constructor
     *
     * Initialize color modes from the provided data.
     *
     * @param {object<string, *>} initial 
     */
    function ColorData() {
      var _this = this;

      var initial = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      _classCallCheck(this, ColorData);

      COLOR_MODES.forEach(function (mode) {
        _this[mode] = initial[mode] !== undefined ? initial[mode] : null;
      });
    }
    /**
     * Get mode data.
     *
     * @param {string} mode 
     *
     * @return {*}
     */


    _createClass(ColorData, [{
      key: "get",
      value: function get(mode) {
        return this[mode];
      }
      /**
       * Set mode data.
       *
       * @param {string} mode 
       * @param {*} value 
       *
       * @return ColorData
       */

    }, {
      key: "set",
      value: function set(mode, value) {
        var clone = new ColorData(this);
        clone[mode] = value;
        return clone;
      }
      /**
       * Determine from the data currently available on this instance how to get the values for
       * the provided mode, and return that function.
       *
       * @param {string} target The color mode we're converting to.
       *
       * @return {(ColorData) => ColorData}
       */

    }, {
      key: "_getConverter",
      value: function _getConverter(target) {
        var method = "to".concat(target),
            converter = ColorData.Converters.Null,
            preferred = PREFERRED_CONVERSIONS[target] || [];

        var _arr = _toConsumableArray(preferred).concat(_toConsumableArray(COLOR_MODES));

        for (var _i = 0; _i < _arr.length; _i++) {
          var source = _arr[_i];

          if (this[source] !== null) {
            converter = ColorData.Converters[source];
          }
        }

        return converter[method];
      }
    }]);

    return ColorData;
  }(); // Populate ColorData prototype with a list of color mode

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    var _loop = function _loop() {
      var mode = _step.value;

      ColorData.prototype["ensure".concat(mode)] = function () {
        if (this[mode] === null) {
          return this._getConverter(mode)(this);
        }

        return this;
      };
    };

    for (var _iterator = COLOR_MODES[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      _loop();
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator.return != null) {
        _iterator.return();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ColorData.Converters = Converters;

  var Color =
  /**
   * Constructor
   *
   * @param {*} data 
   */
  function Color() {
    var data = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
      r: 0,
      g: 0,
      b: 0
    };

    _classCallCheck(this, Color);

    this.colorData = createColorData(data);
  };
  /**
   * Determine the color mode from the input provided, and use that mode
   * to create a ColorData instance.
   * 
   * @param {*} data 
   */

  function createColorData(data) {
    if (data instanceof ColorData) return data;
    var detected = detectColorMode(data);

    if (detected) {
      return new ColorData(_defineProperty({}, detected, data));
    }

    throw new Error('Can\'t parse color input');
  }
  /**
   * Determine from the shape of the input which color mode the caller is describing.
   * 
   * @example detectColorMode({r: 0, g: 0, b: 0}); // returns 'RGB'
   *          detectColorMode('#ffffff); // returns 'Hex'
   * @param {*} data An object of some shape. Could be 
   * 
   * @return {string|null} 
   */


  function detectColorMode(data) {
    for (var mode in MODE_PROPS) {
      var props = MODE_PROPS[mode];
      if (props instanceof Function && props(data)) return mode;
      if (props instanceof Array && props.reduce(function (op, prop) {
        return op && data[prop] !== undefined;
      }, true)) return mode;
    }

    return null;
  } // Populate the Color prototype with getter/setters for each color mode.


  var _iteratorNormalCompletion$1 = true;
  var _didIteratorError$1 = false;
  var _iteratorError$1 = undefined;

  try {
    var _loop$1 = function _loop() {
      var mode = _step$1.value;

      Color.prototype[mode] = function (value) {
        // Setter, immutable style. Returns new instance.
        if (value) return new Color(new ColorData(_defineProperty({}, mode, value))); // Getter

        this.colorData = this.colorData["ensure".concat(mode)]();
        return this.colorData[mode];
      };
    };

    for (var _iterator$1 = COLOR_MODES[Symbol.iterator](), _step$1; !(_iteratorNormalCompletion$1 = (_step$1 = _iterator$1.next()).done); _iteratorNormalCompletion$1 = true) {
      _loop$1();
    }
  } catch (err) {
    _didIteratorError$1 = true;
    _iteratorError$1 = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion$1 && _iterator$1.return != null) {
        _iterator$1.return();
      }
    } finally {
      if (_didIteratorError$1) {
        throw _iteratorError$1;
      }
    }
  }

  exports.Color = Color;

  Object.defineProperty(exports, '__esModule', { value: true });

})));
