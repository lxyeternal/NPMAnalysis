# Readme

Display file/author heatmap in the console. e.g
```
┌───────┬───────────────────────────────────────┬────────┬────────┬──────────────────────────────────────────────────────────────────┐
│ Index │                                 Entry │ # file │ # line │ Wed Aug 31 2022                                  Tue Nov 01 2022 │
├───────┼───────────────────────────────────────┼────────┼────────┼──────────────────────────────────────────────────────────────────┤
│     1 │    ...MyTestProject/Code/TestFile1.ts │    129 │    494 │  ▨▨▨ ▨▨▩▨▨▩  ▨▩▩▨▨   ▨▩▨▨  ▨▨▨▨   ▨▨     ▨▨▩▨    ▨▨▩   ▨▨▨▨▨     │
│     2 │    ...MyTestProject/Code/TestFile2.ts │     70 │    268 │    ▨   ▨▨ ▨   ▨▩▨▨  ▨▨▩ ▨  ▨▨▩▨    ▨ ▨▨  ▩▩▩    ▨ ▨▩▩  ▩▨▨       │
└───────┴───────────────────────────────────────┴────────┴────────┴──────────────────────────────────────────────────────────────────┘
```

Options:
```
  -n, --numCommits <number>  number of commits to check (default: "1000")
  -s, --startDate <date>     start date of the commits to look at (default: "")
  -i, --ignore <filter>      ignore files types (glob patterns seperated by space) (default: "")
  -k, --topK <number>        Top k result to return (default: "20")
  -w, --weight <number>      the weight factor of line change (default: "0.5")
  -d, --debug                debug mode
  -e, --email <email>        filter by authors email (seperated by space) (default: "")
  -c, --commit <sha>         filter by commit sha hash (seperated by space) (default: "")
  -f, --file <filename>      filter by file (glob patterns seperated by space) (default: "")
  -h, --help                 display help for command
```

To install:
`npm i git-heatmap -g`

To use this tool, cd to a git directory
`git-heatmap`

Examples with filters
```
# Filter out all .json and .lock files
git-heatmap -i "**/*.json **/*.lock"

# Filter file heatmap
git-heatmap -f "file1 file2"

# Filter author heatmap
git-heatmap -e "author1@email.com author2@email.com"

# Filter commits since 2022-01-01
git-heatmap -s 2022-01-01
```

