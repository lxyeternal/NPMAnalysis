import PriorityQueue from "ts-priority-queue";
import CommitItem from "./interface/CommitItem";
import { RankItem } from "./interface/RankItem";
import { Logger } from "./Logger";
import { getDate } from "./utils/DateUtils";

export default class Ranker {
    static rank(commitItems: CommitItem[], topCount: number, lineWeight: number): RankItem[] {
        Logger.log('Perform ranking, return top ', topCount);
        let maxFileChange: number = 0;
        let maxLineChange: number = 0;

        commitItems.forEach(function(item) {
            maxFileChange = Math.max(maxFileChange, item.fileChangeCount);
            maxLineChange = Math.max(maxLineChange, item.lineChangeLn);
        })
        const rankItems = Ranker.getRankItem(commitItems, maxFileChange, maxLineChange, topCount, lineWeight);

        let maxDateFileChange: number = 0;
        let maxDateLineChange: number = 0;
        rankItems.forEach(x=> {x.dateCommits.forEach((dateCommit) => {
            maxDateFileChange = Math.max(maxDateFileChange, dateCommit.fileChangeCount);
            maxDateLineChange = Math.max(maxDateLineChange, dateCommit.lineChangeLn);
        })});
        rankItems.forEach(x => x.computeDateScore(maxDateFileChange, maxDateLineChange, lineWeight));
        Ranker.logRankItem(rankItems);
        return rankItems;
    }

    private static logRankItem(rankItems: RankItem[]) {
        const printArray: object[] = [];
        rankItems.slice(0, 3).forEach((x) => printArray.push({name: x.filename, fileChange: x.fileChange, fileScore: x.fileScore.toFixed(2), lineChange: x.lineChange, lineScore: x.lineScore.toFixed(2),
        dateScore: x.dateScore?.reduce((prev, x) => prev+=`${getDate(x.date).toISOString().split('T')[0]}:${x.score.toFixed(2)} `, '')}));
        Logger.log(JSON.stringify(printArray, null, 2));
    }

    private static normalizeScore(count: number, total: number, factor: number): number {
        return count * factor / total;
    }

    private static compare(a: RankItem, b: RankItem): number {
        return a.fileScore + a.lineScore - b.fileScore - b.lineScore;
    }

    private static getRankItem(commitItems: CommitItem[], maxFileChange: number, maxLineChange: number, topCount: number, lineWeight: number): RankItem[] {
        let pq = new PriorityQueue<RankItem>({ comparator: function(a: RankItem, b: RankItem) {
                return a.fileScore + a.lineScore - b.fileScore - b.lineScore;
            }})
        commitItems.forEach(function(item) {
            let rankItem = new RankItem(
                item.filename,
                item.lineChangeCount,
                item.fileChangeCount,
                Ranker.normalizeScore(item.lineChangeLn, maxLineChange, lineWeight),
                Ranker.normalizeScore(item.fileChangeCount, maxFileChange, 1-lineWeight),
                item.dateCommits);
            if (pq.length < topCount) {
                pq.queue(rankItem);
            } else if (Ranker.compare(rankItem, pq.peek()) > 0) {
                pq.dequeue();
                pq.queue(rankItem);
            }
        })
        return Ranker.getOrderedRankItems(pq);
    }

    private static getOrderedRankItems(pq: PriorityQueue<RankItem>): RankItem[] {
        const len = pq.length
        let rankItems: RankItem[] = new Array(len);
        for (let i=len-1; i>=0; i--) {
            rankItems[i] = pq.dequeue()
        }
        return rankItems;
    }
}