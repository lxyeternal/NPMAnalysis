import micromatch from 'micromatch';
export default class FileFilter {
    readonly patterns: string[];
    constructor(patterns: string[]) {
      this.patterns = patterns;
    }

    match(filename: string): boolean {
      return micromatch.isMatch(filename, this.patterns);
    }
}