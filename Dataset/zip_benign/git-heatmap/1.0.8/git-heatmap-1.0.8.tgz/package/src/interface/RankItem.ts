import { DateCommit } from "./CommitItem";

export class DateScore {
    date: number;
    score: number;
    constructor(date: number, score: number) {
        this.date = date;
        this.score = score;
    }
}
export class RankItem {
    readonly filename: string;
    readonly fileChange: number;
    readonly lineChange: number;
    readonly lineScore: number;
    readonly fileScore: number;
    readonly dateCommits: DateCommit[];
    dateScore: DateScore[] = [];

    constructor(filename: string, lineChange: number, fileChange: number, lineScore: number, fileScore:number, dateCommits: DateCommit[]) {
        this.filename = filename;
        this.lineChange = lineChange;
        this.fileChange = fileChange;
        this.lineScore = lineScore;
        this.fileScore = fileScore;
        this.dateCommits = dateCommits;
    }

    computeDateScore(maxDateFileChange: number, maxDateLineChange: number, lineWeight: number) {
        this.dateScore = this.dateCommits.map(x => {
            const lineScore = (x.lineChangeLn) / maxDateLineChange * lineWeight;
            const fileScore = x.fileChangeCount / maxDateFileChange * (1-lineWeight);
            return new DateScore(x.date, lineScore + fileScore);
        });
    }

}