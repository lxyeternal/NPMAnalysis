import { getDays } from "../utils/DateUtils";
export class DateCommit {
    date: number;
    lineChangeCount: number;
    lineChangeLn: number;
    fileChangeCount: number;
    constructor(days: number, lineChangeCount: number, fileChangeCount: number) {
        this.date = days;
        this.lineChangeCount = lineChangeCount;
        this.fileChangeCount = fileChangeCount;
        this.lineChangeLn = 0;
    }
}
export default class CommitItem {
    filename: string;
    lineChangeCount: number;
    lineChangeLn: number;
    fileChangeCount: number;
    dateCommits: DateCommit[];

    constructor(filename: string, lineChangeCount: number, fileChangeCount: number, lineChangeLn: number, dateCommits: DateCommit[]) {
        this.filename = filename;
        this.lineChangeCount = lineChangeCount;
        this.fileChangeCount = fileChangeCount;
        this.dateCommits = dateCommits;
        this.lineChangeLn = lineChangeLn;
    }
}

export class InternalCommitItem{
    key: string;
    author: string;
    filename: string;
    date: number;
    lineChangeCount: number;
    fileChangeCount: number;
    private dateCommitMap: Map<number, DateCommit>;
    constructor(filename: string, lineChangeCount: number, fileChangeCount: number, author: string, date: number) {
        this.key = filename;
        this.lineChangeCount = lineChangeCount;
        this.fileChangeCount = fileChangeCount;
        this.author = author;
        this.filename = filename;
        this.date = date;
        this.dateCommitMap = new Map<number, DateCommit>();
    }

    addDateCommit(days: number, lineCount: number, fileChangeCount: number) {
        let item = this.dateCommitMap.get(days);
        if(item) {
            item.lineChangeCount += lineCount;
            item.fileChangeCount += fileChangeCount;
        } else {
            const dateCommit = new DateCommit(days, lineCount, fileChangeCount);
            this.dateCommitMap.set(days, dateCommit);
        }
    }

    computeDateCommit() {
        return Array.from(this.dateCommitMap.values()).sort((x, y) => x.date - y.date);
    }
}