#! /usr/bin/env node
import { Command } from 'commander';
import CommitParser from './CommitParser.js';
import Ranker from './Ranker.js';
import { Logger } from './Logger.js';
import { plot } from './Plot.js';
import { getDate } from './utils/DateUtils.js';

const splitOption = (value) => {
    return !value? [] : value.split(' ');
} 

(async () => {
    const program = new Command();
    program
        .option('-n, --numCommits <number>', 'number of commits to check', '1000')
        .option('-s, --startDate <date>', 'start date of the commits to look at', '')
        // .option('-e, --endDate <date>', 'end date of the commits to look at', '')
        .option('-i, --ignore <filter>', 'ignore files types (glob patterns seperated by space)', '')
        .option('-k, --topK <number>', 'Top k result to return', '20')
        .option('-w, --weight <number>', 'the weight factor of line change', '0.7')
        .option('-d, --debug', 'debug mode')
        .option('-e, --email <email>', 'filter by authors email (seperated by space)', '')
        .option('-c, --commit <sha>', 'filter by commit sha hash (seperated by space)', '')
        .option('-f, --file <filename>', 'filter by file (glob patterns seperated by space)', '')
        .parse();
    
    const options = program.opts();
    Logger.setDebug(options.debug);
    Logger.table(options);

    const startDate = Date.parse(options.startDate);
    const endDate = Date.parse(options.endDate);
    const numCommits = isNaN(startDate) ? options.numCommits : 2147483647;
    const parser = new CommitParser(numCommits,
        isNaN(startDate) ? null : startDate, 
        isNaN(endDate) ? null : endDate,
        splitOption(options.ignore),
        splitOption(options.email),
        splitOption(options.commit),
        splitOption(options.file));

    Logger.log('Start Parsing: ', new Date());
    const [fileItems, authorItems, firstCommitDate, lastCommitDate] = await parser.parse();

    Logger.log('First Commit: ', getDate(firstCommitDate), ' Last Commit: ', getDate(lastCommitDate));
    Logger.log('Start Ranking: ', new Date());
    const rankFileItems = Ranker.rank(fileItems, options.topK, options.weight);
    const rankAuthorItems = Ranker.rank(authorItems, options.topK, options.weight);

    Logger.log('Start Plot: ', new Date());
    const nameColumns = plot(rankFileItems, firstCommitDate, lastCommitDate);

    console.log('\n');
    plot(rankAuthorItems, firstCommitDate, lastCommitDate, nameColumns);

})();
