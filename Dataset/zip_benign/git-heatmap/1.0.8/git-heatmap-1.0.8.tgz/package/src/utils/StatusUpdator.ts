
export const StatusUpdater = (total: number, prefix: string) => {
    let index = 0;
    return () => {
        index++;
        process.stdout.write(`\r${prefix} ${index} of ${total}: ${(index/total * 100).toFixed(2)}%`);
        if(index >= total - 1) {
            process.stdout.write('\r');
        }
    }
}
