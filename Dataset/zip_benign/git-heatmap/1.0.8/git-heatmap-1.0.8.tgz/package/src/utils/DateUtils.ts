export const getDays = (date: Date) => {
    return Math.floor(date.getTime() / (1000 * 3600 * 24));
}

export const getDate = (days: number) => {
    return new Date(days * 1000 * 3600 * 24);
}