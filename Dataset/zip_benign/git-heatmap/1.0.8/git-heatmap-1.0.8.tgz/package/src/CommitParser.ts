import FileFilter from "./FileFilter";
import git, { Commit, Signature } from "nodegit";
import CommitItem, {InternalCommitItem} from "./interface/CommitItem";
import { Logger } from "./Logger";
import { StatusUpdater } from "./utils/StatusUpdator";
import { getDays, getDate } from "./utils/DateUtils";
import micromatch from 'micromatch';

export default class CommitParser {
    static readonly MaxDate = new Date(8640000000000000);
    static readonly MinDate = new Date(-8640000000000000);

    readonly numCommits: number;
    readonly startDate: Date;
    readonly endDate: Date;
    readonly email: string[];
    readonly commit: string[];
    readonly file: string[];
    readonly ignorePatterns: string[];

    constructor(numCommits: number, startDate: Date | null, endDate: Date | null, ignorePattern: string[], email: string[], commit: string[], file: string[]) {
      this.numCommits = numCommits;
      this.startDate = startDate ?? CommitParser.MinDate;
      this.endDate = endDate ?? CommitParser.MaxDate;
      this.ignorePatterns = ignorePattern
      this.email = email;
      this.commit = commit;
      this.file = file;
    }

    async getCommits(): Promise<Commit[]> {
        if(this.numCommits < 1) {
            return [];
        }
        if(this.startDate > new Date()) {
            return [];
        }

        const repo = await git.Repository.open('./');

        if(this.commit && this.commit.length > 0) {
            const commitsByHash: Commit[] = [];
            for(let i = 0; i < this.commit.length; i ++){
                const commit = await repo.getCommit(this.commit[i]);
                commitsByHash.push(commit);
            }
            return commitsByHash;
        }

        const walker = git.Revwalk.create(repo);
        walker.pushHead();

        let commitCounter = 0;
        const filterCommit = (c: Commit): boolean => {
            const date = c.date(); 
            return ++commitCounter < this.numCommits && date >= this.startDate && date <= this.endDate;
        }

        const commits = (await walker.getCommitsUntil(filterCommit))
                        .filter(c => c.parents().length === 1); //Remove merge commits

        if(this.email && this.email.length > 0) {
            return commits.filter(c => micromatch.isMatch(c.author().email(), this.email));
        }
        return commits;
    }

    async getInternalCommitItem(commit: Commit, filter: FileFilter, statusUpdater: ()=>void): Promise<InternalCommitItem[]> {
        try {
            const currentTree = await commit.getTree();
            const parentTree = await (await commit.parent(0)).getTree();
            const diff = await currentTree.diff(parentTree);
            let patches = (await diff.patches()).filter(p => !filter.match(p.newFile().path()) && !p.isDeleted());
            if(this.file && this.file.length > 0) {
                patches = patches.filter(x => micromatch.isMatch(x.newFile().path(), this.file));
            }

            statusUpdater();

            const lineItems = patches.filter(p => !filter.match(p.newFile().path()) && !p.isDeleted()).map(x => {
                const insertionCount = parseInt(x.lineStats()['total_additions']);
                const deletionCount = parseInt(x.lineStats()['total_deletions']);
                return new InternalCommitItem(x.newFile().path(), insertionCount + deletionCount, 1, commit.author().email(), getDays(commit.date()));
            });

            return lineItems;
        } catch {
            return [];
        }
    }

    lnTransform(items: CommitItem[]){
        return items.map(x => {
            x.lineChangeLn = Math.log(x.lineChangeCount + 1);
            x.dateCommits.map(y => {
                y.lineChangeLn = Math.log(y.lineChangeCount + 1);
                return y;
            });
            return x;
        })
    }

    groupItems(items: InternalCommitItem[], key: string): CommitItem[] {
        let itemMap = new Map<string, InternalCommitItem>();
        items.forEach(function(rawItem) {
            let item = itemMap.get(rawItem[key]);
            if (!item) {
                item = new InternalCommitItem(rawItem.filename, rawItem.lineChangeCount, rawItem.fileChangeCount, rawItem.author, rawItem.date);
                item.key = rawItem[key];
            }
            item.lineChangeCount += rawItem.lineChangeCount;
            item.fileChangeCount++;
            item.addDateCommit(rawItem.date, rawItem.lineChangeCount, rawItem.fileChangeCount);
            itemMap.set(item.key, item);
        })
        return this.lnTransform(Array.from(itemMap.values()).map(x => new CommitItem(x.key, x.lineChangeCount, x.fileChangeCount, 0, x.computeDateCommit())));
    }

    async parse(): Promise<[CommitItem[], CommitItem[], number, number]> {
        const startTime = Date.now();
        const commits = await this.getCommits();
        const getCommitsTime = Date.now()
        Logger.log('Total commits:', commits.length, ' Time spend:', `${getCommitsTime - startTime} ms`);

        const filter = new FileFilter(this.ignorePatterns);
        const statusUpdater = StatusUpdater(commits.length, 'Commit');
        const resultPromise: Promise<InternalCommitItem[]>[] = commits.reduce((prev, x, index) => {
            prev.push(this.getInternalCommitItem(x, filter, statusUpdater)); return prev;
        }, [] as Promise<InternalCommitItem[]>[]);
        const lineItems = (await Promise.all(resultPromise)).flat();

        const fileResult = this.groupItems(lineItems, 'filename');
        const authorResult = this.groupItems(lineItems, 'author');

        const getLinesTime = Date.now();
        Logger.log('Total files:', fileResult.length, ' Time spend: ', `${getLinesTime - getCommitsTime} ms`);
        this.logCommitItems(fileResult);
        this.logCommitItems(authorResult);

        const hasCommit = commits && commits.length > 0;
        return [fileResult, authorResult, hasCommit ? getDays(commits[commits.length-1].date()) : 0, hasCommit ? getDays(commits[0].date()) : 0];
    }

    logCommitItems(items: CommitItem[]) {
        const printArray: object[] = [];
        items.slice(0, 3).forEach((x) => printArray.push({name: x.filename, fileChange: x.fileChangeCount, lineChange: x.lineChangeCount, lineChangeLn: x.lineChangeLn.toFixed(2),
        dateCommits: x.dateCommits?.reduce((prev, x) => prev+=`${getDate(x.date).toISOString().split('T')[0]}:${x.fileChangeCount}:${x.lineChangeCount}:${x.lineChangeLn.toFixed(2)} `, '')}));
        Logger.log(JSON.stringify(printArray, null, 2));
    }
}