export const Logger = (function() {
    let isDebug: boolean = false;
    return { // public interface
      setDebug: (debug: boolean): void => {
        isDebug = debug;
      },
      log: (...params: any[]): void => {
        isDebug && console.log(...params);
      },
      table: (obj: object):void => {
        isDebug && console.table(obj);
      }
    };
  })();