import { RankItem } from "./interface/RankItem";
import { DateScore } from "./interface/RankItem";
import { getDate } from "./utils/DateUtils";
import chalk from "chalk";
import { Table } from "console-table-printer";

const DefaultMaxNameColumns: number = Math.floor(process.stdout.columns - 40)/4;
const DefaultMaxDateColumns: number = Math.floor(DefaultMaxNameColumns * 3); 

function getScore(dateScore: DateScore[], startDate: number, collapseFactor: number) {
    let totalScore = 0;
    let counter = 0;
    while(dateScore && dateScore.length > 0 && dateScore[0].date < startDate + collapseFactor) {
        totalScore += dateScore[0].score;
        counter++;
        dateScore.shift();
    }
    return counter === 0 ? 0 : totalScore/counter;
}

function getIntensityColor(score: number) {
    if (score === 0){
        return ' ';
    } else if (score <= 1/8) {
        return chalk.green('⬚');
    } else if (score <= 2/8) {
        return chalk.greenBright('⬚');
    } else if (score <= 3/8) {
        return chalk.green('□');
    } else if (score <= 4/8) {
        return chalk.greenBright('□');
    } else if (score <= 5/8) {
        return chalk.green('▨');
    } else if (score <= 6/8) {
        return chalk.greenBright('▨');
    } else if (score <= 7/8) {
        return chalk.green('▩');
    } else {
        return chalk.greenBright('▩');
    }
}

// DateScore is already sorted based on date
function generateLine(startDate: number, endDate: number, maxDateColumns: number, dateScore: DateScore[]) {
    const dateDiff = endDate - startDate + 1;
    const collapseFactor = dateDiff > maxDateColumns ? dateDiff/maxDateColumns : 1;
    let line = '';
    for(let i = startDate; i < endDate; i += collapseFactor) {
        line += getIntensityColor(getScore(dateScore, i, collapseFactor));
    }
    return line;
}

function shortenFilename(filename: string, maxLength: number) {
    if(filename.length <= maxLength) {
        return filename;
    }

    const diff = filename.length - maxLength;
    return '**/*' + filename.substring(diff + 4);
}

export function plot(rankItems: RankItem[], startDate: number, endDate: number, refNameColumns?: number): number {
    const maxNameColumns = !refNameColumns ? DefaultMaxNameColumns: Math.min(refNameColumns, DefaultMaxNameColumns);

    const dateDiff = Math.max(endDate - startDate + 1, 32);
    const actualDateColumns = dateDiff > DefaultMaxDateColumns ? DefaultMaxDateColumns : dateDiff;
    const actualFileColumns = !refNameColumns ? Math.min(maxNameColumns, Math.max(Math.max(...rankItems.map(items => items.filename.length)), 20)) : refNameColumns;
    const dateLabel = getDate(startDate).toDateString() + getDate(endDate).toDateString().padStart(actualDateColumns - 14);
    const p = new Table();
    rankItems.forEach((rankItem, index) => {
        const dateLine = generateLine(startDate, endDate, actualDateColumns, rankItem.dateScore ?? []);

        const printObject = new Object();
        printObject['Index'] = index + 1;
        printObject['Entry'] = shortenFilename(rankItem.filename, maxNameColumns).padStart(actualFileColumns + 1);
        printObject['# file'] = rankItem.fileChange;
        printObject['# line'] = rankItem.lineChange;
        printObject[dateLabel] = dateLine;
        p.addRow(printObject);
    });

    p.printTable();
    return actualFileColumns;
}