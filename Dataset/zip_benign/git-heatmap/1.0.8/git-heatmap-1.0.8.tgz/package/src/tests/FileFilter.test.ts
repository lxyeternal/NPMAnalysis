import FileFilter from '../FileFilter';

describe('FileFilter', () => {
    test('test file filter match', () => {
        const filter = new FileFilter(['**/*.po', 'package-lock.json', '*.{jpg,png}']);
        expect(filter.match('/src/i18n/ja.po')).toBe(true);
        expect(filter.match('package-lock.json')).toBe(true);
        expect(filter.match('photo.png')).toBe(true);
        expect(filter.match('photo.jpg')).toBe(true);
        expect(filter.match('abc.java')).toBe(false);
    });

    test('test file filter match empty', () => {
        const filter = new FileFilter([]);
        expect(filter.match('/src/i18n/ja.po')).toBe(false);
        expect(filter.match('package-lock.json')).toBe(false);
    });
});