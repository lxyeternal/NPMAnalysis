import { getDays, getDate } from "../utils/DateUtils";


describe('DateUtils', () => {
    test('test getDays', () => {
        expect(getDays(new Date('2022-01-01'))).toBe(18993);
        expect(getDays(new Date('2022-01-02'))).toBe(18994);
        expect(getDays(new Date('2022-01-02T10:10:10.000'))).toBe(18994);
    });

    test('test getDate', () => {
        expect(getDate(18993)).toEqual(new Date('2022-01-01'));
        expect(getDate(18994)).toEqual(new Date('2022-01-02'));
    });
});