import Ranker from '../Ranker';
import CommitItem from "../interface/CommitItem";
import { RankItem } from "../interface/RankItem";

describe('Ranker', () => {
    test('test rank commits', () => {
        const commitItems = [
            new CommitItem("abc.file", 2, 1, 2, []), // 0.1, 0.05
            new CommitItem("def.file", 4, 10, 4, []), // 0.2, 0.5
            new CommitItem("xxx.file", 10, 2, 10, []), // 0.5, 0.1
            new CommitItem("yyy.file", 9, 5, 9,[]) // 0.45, 0.25
        ]
        const rankItems = Ranker.rank(commitItems, 3, 0.5);
        const expected = [
            new RankItem("yyy.file", 9, 5, 0.45, 0.25, []),
            new RankItem("def.file", 4, 10, 0.2, 0.5, []),
            new RankItem("xxx.file", 10, 2, 0.5, 0.1, [])
        ]
        expect(rankItems).toStrictEqual(expected);
    })
})