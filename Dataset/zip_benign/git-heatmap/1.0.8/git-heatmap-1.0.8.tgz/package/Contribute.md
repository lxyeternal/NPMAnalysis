# Readme

Setup
`npm ci`

Unit test:
`npm run test`

To test the tool:
```
npm run build
npm i -g
npx git-file-heatmap
```

