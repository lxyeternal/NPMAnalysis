# @palmetto/result

A simple result type to represent failures without throwing errors.

## Installation

```sh
yarn add @palmetto/result
```

## Usage

### Return a result

> tip: Functions that return a `Result` are referred to as "operations".

```ts
function randomFailures() {
  const rand = Math.random();

  if (rand < 0.5) {
    return Err("UNLUCKY", { value: rand });
  } else if (rand === 0.99) {
    return Err("TOO_LUCKY");
  }

  return Ok(rand);
}
```

### Use a result

```ts
const result = randomFailures();

if (!result.ok) {
  console.err("Operation failed with:", result.error.code);

  if (result.error.code === "TOO_LUCKY") {
    console.err("Maybe try the lottery instead");
  }
} else {
  console.log("Your number:", result.data);
}
```

### Use helper types

```ts
type RandomFailuresData = ExtractResultData<typeof randomFailures>;
// => number

type RandomFailuresError = ExtractResultErr<typeof randomFailures>;
// => ResultErr<{ code: "UNLUCKY", value: number }> | ResultErr<{ code: "TOO_LUCKY" }>
```

### Return a result without a value

```ts
function checkSomething() {
  if (somethingIsWrong()) {
    return Err("SOMETHING_WRONG");
  }

  return Ok();
}
```

### Assert an operation was successful

```ts
const result = randomFailures();
assertOk(result);

console.log("Your number:", result.data);
```

```ts
assertOk(checkSomething());
```
