## v0.4.11-1
 * Backports http.js from node.js v0.4.11.

## v0.4.10-2
 * Maintenance release for cleaning up the npm package.

## v0.4.10-1
 * Backports the libraries from 0.4.10. Targets the node [#1399](https://github.com/joyent/node/issues/1399) issue.

## v0.4.9-2
 * Backports the libraries from 0.5.1. Targets the node [#877](https://github.com/joyent/node/issues/877) issue.

## v0.4.9-1
 * Initial version, backporting fixes from 0.5.1 to the 0.4.9 libraries.
