## About

This is a module that contains some backported fixes for the node.js core libraries. It happens to be here just to support my other projects that heavily depend on the targeted core modules.

This module will be maintained as long as any of the previous statements is true:

 * node.js v0.6.x is unreleased **or** node.js v0.4.x won't backport fixes to v0.4.11+ from v0.5.x **or** my own patches won't make it into the upstream distribution.
 * somebody requests reasonable support for this module. No features will be added. Just bugfixes. This is what you ought to understand from *reasonable support*. Nowever, if adopting newer version is trivial, the newer version will be used, with minimal modifications in order to make it fit into this module.

## Installation

Either manually clone this repository into your node_modules directory, or the recommended method:

> npm install backport-0.4

## Backported fixes

This version specifically targets:

 * [#1399](https://github.com/joyent/node/issues/1399) - HTTP client request.abort() race condition for requests with bodies

## Available modules

 * http
 * https

The provied backported modules are the modules from node.js v0.4.10 with the above fix. The http module doesn't have the DTrace support that the core http module has. The reason is to keep the backporting effort to minim since node doesn't expose the used DTrace functions as globals into the userland code.

## Usage mode

The backport-0.4 module contains a simple loader for the provided backported core modules. Basically it resumes to this:

```javascript
// load the backported http module
var http = require('backport-0.4').load('http');

// load the backported https module
var https = require('backport-0.4').load('https');
```

The rest of the invocation follows the logic of the core module itself. This module specifically targets node v0.4.9+.
