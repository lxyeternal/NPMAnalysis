var ArithmeticFunction=function(x,y){
                      this.x=x;
                      this.y=y;
                      this.resultAdd=x+y;
                      this.resultSub=x-y;
                      this.resultMul=x*y;
                      this.resultDiv=x/y;
                      };

var functionAdd=function(){console.log(`(${this.x})+(${this.y})=${this.resultAdd}`);};
var functionSub=function(){console.log(`(${this.x})-(${this.y})=${this.resultSub}`);};
var functionMul=function(){console.log(`(${this.x})*(${this.y})=${this.resultMul}`);};
var functionDiv=function(){console.log(`(${this.x})/(${this.y})=${this.resultDiv}`);};

ArithmeticFunction.prototype={
                             ADD:functionAdd,
                             SUB:functionSub,
                             MUL:functionMul,
                             DIV:functionDiv
                            };

var makeArithmeticFunction=function(x,y){
      return new ArithmeticFunction(x,y);
      };



var sayHello=function(){console.log("Hello");}
var sayHelloTwice=function(){console.log("Hello Hello");}
var eatLunch=function(){console.log("Let us go to Lunch");}
var eatDinner=function(){console.log("Let us go to Dinner");}
var gotoMovie=function(){console.log("How about see a movie");}
var paytheBill=function(){console.log("You! Pay the bill!");}

module.exports={
      AMF:makeArithmeticFunction,

     SAYH:sayHello,
    SAYHH:sayHelloTwice,
     EATL:eatLunch,
     EATD:eatDinner,
     GTM:gotoMovie,
     PTB:paytheBill
};
