"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.InternalServerError = exports.Forbidden = exports.BadRequest = exports.NotFound = exports.RestishServerError = void 0;

class RestishServerError extends Error {
  constructor(message, name, code) {
    super(message);
    this.name = name;
    this.code = code;
  }

}

exports.RestishServerError = RestishServerError;

class NotFound extends RestishServerError {
  constructor(message = 'Not Found') {
    super(message, "NotFound", 404);
  }

}

exports.NotFound = NotFound;

class BadRequest extends RestishServerError {
  constructor(message = 'Bad Request') {
    super(message, "BadRequest", 400);
  }

}

exports.BadRequest = BadRequest;

class Forbidden extends RestishServerError {
  constructor(message = 'Forbidden') {
    super(message, "Forbidden", 403);
  }

}

exports.Forbidden = Forbidden;

class InternalServerError extends RestishServerError {
  constructor(message = 'Internal Server Error') {
    super(message, "InternalServerError", 500);
  }

}

exports.InternalServerError = InternalServerError;
//# sourceMappingURL=errors.js.map