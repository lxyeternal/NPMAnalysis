"use strict";

let canConnect = require("./cache/canConnect");
let getNodeData = require("./cache/getNodeData");
let getConnectList = require("./cache/getConnectList");
let getVariableList = require("./cache/getVariableList");
let findOneNodeByType = require("./cache/findOneNodeByType");
let findNodeByType = require("./cache/findNodeByType");
let findOneNodeById = require("./cache/findOneNodeById");
let getParentIdsForId = require("./cache/getParentIdsForId");
let getLinkStatsForId = require("./cache/getLinkStatsForId");
let variableAsFormSchema = require("./cache/goDataTransformation/variableAsFormSchema");
let formSchemaToState = require("./cache/goDataTransformation/formSchemaToState");
let updateRefs = require("./cache/updateRefs");
let validateNodeRefs = require("./cache/validateNodeRefs");

let saveForm = require("./core/saveForm");
let findOne = require("./core/findOne");
let saveComponent = require("./core/saveComponent");
let getConstants = require("./core/getConstants");
let transformNode = require("./core/transformNode");
let execute_node_instance = require("./core/executeNode");
let formatSchema = require("./core/canvasToModelTransform/misc/formatSchema");
let parseSchemaWithDefaultValue = require("./core/canvasToModelTransform/misc/parseSchemaWithDefaultValue");

class Component {
  constructor(params){
    this.config = params || {};
  }

  //cache/local functions
  canConnect = canConnect
  getNodeData = getNodeData
  getConnectList = getConnectList
  findOneNodeByType = findOneNodeByType
  findNodeByType = findNodeByType
  findOneNodeById = findOneNodeById
  getParentIdsForId = getParentIdsForId
  getLinkStatsForId = getLinkStatsForId
  variableAsFormSchema = variableAsFormSchema
  formSchemaToState = formSchemaToState
  getConstants = getConstants
  transformNode = transformNode
  formatSchema = formatSchema
  parseSchemaWithDefaultValue = parseSchemaWithDefaultValue
  updateRefs = updateRefs
  validateNodeRefs = validateNodeRefs

  getVariableList(canvas_data, node_id, parent_id, asset_id){
    return getVariableList(this.config, canvas_data, node_id, parent_id, asset_id);
  }

  //Core functions
  saveForm(body){
    return saveForm(this.config, body);
  }

  saveComponent(canvas_data, node_id, body){
    return saveComponent(this.config, canvas_data, node_id, body);
  }

  findOne(query){
    return findOne(this.config, query);
  }

  executeNode(ui_type, _config_data, state){
    return execute_node_instance.transformAndExecute(this.config, ui_type, _config_data, state);
  }

  executeTransformedNode(body){
    return execute_node_instance.executeTransformed(this.config, body);
  }
}

module.exports = Component;