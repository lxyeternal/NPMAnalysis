# This module expose helper functions

- Initialization

```js
  params = {
    url: @server url
    token: @access token
  }
  Component = require("oute-services-component-sdk")
  component_instance = new Component(params)
```

## Cache functions

- can connect

```js
  canvas_data = 
"{ \"class\": \"GraphLinksModel\",\n  \"nodeCategoryProperty\": \"template\",\n  \"linkKeyProperty\": \"key\",\n  \"nodeDataArray\": [\n{\"key\":\"1692455148241\",\"src\":\"/static/media/input-setup.6bc4e1375793765dd9b1e7463776f5c9.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Input Setup\",\"template\":\"startNode\",\"background\":\"rgb(33, 150, 243)\",\"foreground\":\"#fff\",\"viewSpot\":\"0 0.5\",\"location\":\"-756 0\"},\n{\"key\":\"1692455148245\",\"src\":\"/static/media/failure-setup.2e6fe9f6dcb6fb35de5a33083c93486e.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Failure Setup\",\"template\":\"endNode\",\"background\":\"rgb(255, 82, 82)\",\"foreground\":\"#fff\",\"viewSpot\":\"1 0.6667\",\"location\":\"756 133.36\"},\n{\"key\":\"1692455148246\",\"src\":\"/static/media/success-setup.b7611cf8ee605348416961dad01f45bc.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Success Setup\",\"template\":\"endNode\",\"background\":\"rgb(76, 175, 80)\",\"foreground\":\"#fff\",\"viewSpot\":\"1 0.3333\",\"location\":\"756 -133.36\"}\n],\n  \"linkDataArray\": []}"
  from_id = "1692455148246"
  to_id = "1692455148241"
  component_instance.canConnect(canvas_data, from_id, to_id)
```

- get Node Data

```js
  canvas_data = "{}"
  node_id = "1692361641779"
  component_instance.getNodeData(canvas_data, node_id)
```

- get Connect list

```js
  canvas_data = "{}"
  node_id = "1692361641779"
  component_instance.getConnectList(canvas_data, node_id)
```

- get Variable/Output list

```js
  canvas_data = "{}"
  node_id = "1692361641779"
  parent_id = "q-GmTD5-K"
  asset_id = "1ZXZKMvvE" //For all local and global send asset_id = null
  await component_instance.getVariableList(canvas_data, node_id, parent_id, asset_id)
```

- find one node by ui type

```js
  canvas_data = "{}"
  ui_type = "If Else"
  component_instance.findOneNodeByType(canvas_data, ui_type)
```

- find node by ui type

```js
  canvas_data = "{}"
  ui_type = "If Else"
  component_instance.findNodeByType(canvas_data, ui_type)
```

- find one node by key

```js
  canvas_data = "{}"
  node_id = "1692361625690"
  component_instance.findOneNodeById(canvas_data, node_id)
```

- Get parent list

```js
  canvas_data = "{}"
  node_id = "1692361625690"
  component_instance.getParentIdsForId(canvas_data, node_id)
```

- Variable as form schema

```js
  go_data = {}
  component_instance.variableAsFormSchema(go_data)
```

- form schema to state

```js
  form_schema = {}
  component_instance.formSchemaToState(form_schema)
```

## Core functions

- Save

```js
  body = {
    "title": "form test",
    "description": "Used to test form",
    "qtip": "Enter input",
    "icon": "https://parts.vw.com/images/uploads/SimplePart%20-%20VW/fullsize/a_20150729_1048209665.png",
    "workspace_id": "test",
    "is_discoverable": false,
    "type": "FORM",
    "sub_type": "free_text",
    "state": "ACTIVE",
    "tags": ["FORM"],
    "inputs": {
      "a": "b"
    },
    "outputs": [],
    "meta": {
      "msg": "anything"
    }
  }
  await component_instance.save(body)
```

- Save Form

```js
  body = {
    "title": "form test",
    "description": "Used to test form",
    "qtip": "Enter input",
    "icon": "https://parts.vw.com/images/uploads/SimplePart%20-%20VW/fullsize/a_20150729_1048209665.png",
    "workspace_id": "test",
    "is_discoverable": false,
    "type": "FORM",
    "sub_type": "free_text",
    "state": "ACTIVE",
    "tags": ["FORM"],
    "inputs": {
      "a": "b"
    },
    "outputs": [],
    "meta": {
      "msg": "anything"
    }
  }
  await component_instance.saveForm(body)
```

- Find One

```js
  query = {
    "title": "form test"
  }
  await component_instance.findOne(query)
```

- Save Component

```js
  canvas_data = "{}"
  node_id = "1692361641779"
  data = {
    "title": "Test",
    "description": "IfElse",
    "qtip": "If else node",
    "icon": "https://parts.vw.com/images/uploads/SimplePart%20-%20VW/fullsize/a_20150729_1048209665.png",
    "is_discoverable": false,
    "state": "ACTIVE",
    "tags": [],
    "inputs": [
      {
        "key": null,
        "value": [
          {
            op: "EQ",
            expr: [
              1,
              1
            ]
          }
        ],
        type: "EXPRESSION",
        default: null,
        required: false,
        regex: null,
        node_id: "1692361631573"
      }
    ],
    "outputs": [],
    "meta": {
      "msg": "anything"
    }
  }
  await component_instance.saveComponent(canvas_data, node_id, data)
```

- Get Constants

```js
  component_instance.getConstants()
```

- Transform node data

```js
  canvas_data = "{}"
  node_id = "1692361641779"
  data = {}
  component_instance.transformNode(canvas_data, node_id, data)
```

- Execute node

```js
  config_data = {"url": "google.com"}
  ui_type = "HTTP"
  state = {}
  await component_instance.executeNode(ui_type, config_data, state)
```

- Execute transformed node

```js
  config_data = {flow: {}, state: {}, type: "HTTP", task_id: "1692361641779"}
  await component_instance.executeTransformedNode(body)
```

- Format schema

```js
  override_value = false
  schema = []
  path_list = []
  result = component_instance.formatSchema(schema, path_list, override_value)
```

- parse schema with default value

```js
  schema = []
  update_key_by_alias = false
  component_instance.parseSchemaWithDefaultValue(schema, update_key_by_alias)
```

- update the node reference variable

```js
  canvas_data = "{ \"class\": \"GraphLinksModel\""
  node_id = "1718095359248"
  component_instance.updateRefs(canvas_data, node_id)
```

- Validate the node reference variable

```js
  canvas_data = "{ \"class\": \"GraphLinksModel\""
  node_id = "1718095359248"
  variables = {"GLOBAL": [{"mode": "GLOBAL","name": "http_mode","data_type": "NUMBER"}]}
  component_instance.validateNodeRefs(canvas_data, node_id, variables)
```
