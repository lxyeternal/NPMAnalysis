#!/bin/bash

# Find all directories containing a "test" subdirectory
directories=$(find . -maxdepth 2 -type d -name "test")

# Loop through each test directory
for test_dir in $directories; do
  # Check if the test directory contains JavaScript files
  if [ -n "$(find "$test_dir" -type f -name "*.js" -print -quit)" ]; then
    echo
    echo
    echo @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    echo
    echo "Processing $test_dir..."

    # Find and execute all .js files in the test directory and its subdirectories
    find "$test_dir" -type f -name "*.js" | while read -r file; do
      echo
      echo =====================================================
      echo "Running $file..."
      node "$file"
      if [ $? -ne 0 ]; then
        echo "Error executing $file"
      fi
    done
    while true; do
      read -p "Press 'x' to exit, 'c' to continue: " choice
      if [ "$choice" = "x" ]; then
        echo "Terminating $file..."
        exit 1
      elif [ "$choice" = "c" ]; then
        break
      fi
    done
  else
    echo "No JavaScript files found in $test_dir. Skipping."
  fi
done
