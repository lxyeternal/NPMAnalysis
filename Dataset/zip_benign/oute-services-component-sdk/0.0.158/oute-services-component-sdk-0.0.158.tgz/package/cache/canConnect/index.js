"use strict";

let _ = require("lodash");
let constant_instance = require("oute-services-constants-sdk");

let constants = constant_instance.getConstants("canvas")?.result;
let getParentIdsForId = require("../getParentIdsForId");
let getLinkStatsForId = require("../getLinkStatsForId");
let findOneNodeById = require("../findOneNodeById");

module.exports = (_canvas_data, from_id, to_id)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    let canvas_node_types = constants?.canvas_node_types;
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(from_id) || !(to_id)) { throw {message: "From/to is mandatory"}; }
    //find from and to node
    let from_node = findOneNodeById(_canvas_data, from_id)?.result;
    let to_node = findOneNodeById(_canvas_data, to_id)?.result;
    //from and to node cant be empty
    if(_.isEmpty(from_node?.key) || _.isEmpty(to_node?.key)) { throw {message: "Node id is missing in canvas data"}; }
    //from and to node cant be same
    if(from_node?.key === to_node?.key) { throw {message: "Cyclic reference not allowed"}; }
    //start node cant be directly connected to success or failed
    if(from_node?.type && ([canvas_node_types?.start?.ui, canvas_node_types?.success?.ui, canvas_node_types?.failed?.ui].includes(from_node?.type)) && ([canvas_node_types?.start?.ui, canvas_node_types?.success?.ui, canvas_node_types?.failed?.ui].includes(to_node?.type))) {
      throw {message: "Start/success/failed direct linking is not allowed"};
    }
    let from_parent_ids = getParentIdsForId(_canvas_data, from_id)?.result;
    //Back linking validation
    if(from_parent_ids.includes(to_node?.key)) { throw {message: "Back linking is not allowed"}; }
    let from_link_result = getLinkStatsForId(_canvas_data, from_id)?.result;
    let to_link_result = getLinkStatsForId(_canvas_data, to_id)?.result;
    //outgoing link validation of from node
    if(![canvas_node_types?.if_else?.ui].includes(from_node?.type)) {
      if(from_link_result?.out_links?.counts?.all > 0) { throw {message: "Unlink older outgoing links from source"}; }
    } else {
      if(from_link_result?.out_links?.counts?.[to_id] > 0) { throw {message: "Link is already exists"}; }
    }
    //incoming link validation of to node
    //this validations removed as of now
    //if(to_link_result?.in_links?.counts?.all > 0) then throw {message: "Unlink older incoming links from target"}
    return {status: "success", result: true};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};