"use strict";

let _ = require("lodash");

let findOneNodeById = require("./findOneNodeById");

module.exports = (_canvas_data, node_id)=> {
  try {
    let current_node = findOneNodeById(_canvas_data, node_id)?.result;
    return {status: "success", result: current_node?.tf_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};