"use strict";

let _ = require("lodash");

module.exports = (_canvas_data, node_id)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(node_id)) { throw {message: "Node id is mandatory"}; }
    //find current node
    let current_node = _.find((canvas_data?.nodeDataArray || []), ele=> { return (ele?.key && (ele?.key === node_id)); });
    return {status: "success", result: current_node};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};