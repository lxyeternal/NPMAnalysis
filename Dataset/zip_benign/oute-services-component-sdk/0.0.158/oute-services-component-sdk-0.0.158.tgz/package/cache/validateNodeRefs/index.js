"use strict";

let _ = require("lodash");

let findOneNodeById = require("../findOneNodeById");
let getUniqVariableRef = require("./getUniqVariableRef");

module.exports = (_canvas_data, node_id, variables)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if (_.isEmpty(canvas_data)) { throw { message: "Canvas data parameters are required but were not provided"}; }
    if (!(node_id)) { throw { message: "Node id parameters are required but were not provided"}; }
    //get the current node
    let current_node = findOneNodeById(_canvas_data, node_id)?.result || {};
    let result = {nodes: []};
    //get the uniq var ref list
    let curr_ref_list = getUniqVariableRef(current_node)?.variable_refs;
    if (!_.isArray(current_node?.warnings)){
      current_node.warnings = [];
    }
    let is_changed = false;
    for (let ref_ele of curr_ref_list){
      let ref_ele_type = String(ref_ele?.type).toUpperCase();
      let ref_ele_path_str = ref_ele?.path?.join(".");
      let ref_ele_key = ref_ele?.key;
      if (["OBJECT"].includes(ref_ele_type)) {
        ref_ele_type = "JSON";
      }
      if(ref_ele?.variable_type === "NODE"){
        let ref_node = findOneNodeById(_canvas_data, ref_ele?.id)?.result || {};
        //get the output of ref node
        let ref_outputs = ref_node?.go_data?.output?.schema?.flattened_schema;
        if (!_.isArray(ref_outputs)) {
          ref_outputs = [];
        }
        let ref_node_variable = _.find(ref_outputs, (ele) => {
          let ele_path_str = ele?.path?.join(".");
          let ele_key = ele?.key;
          return (ref_ele_path_str && ref_ele_path_str === ele_path_str && ref_ele_key === ele_key)
        })
        let ref_node_variable_type = String(ref_node_variable?.type).toUpperCase();
        if (["OBJECT"].includes(ref_node_variable_type)) {
          ref_node_variable_type = "JSON";
        }
        let message = "The references"
        if (_.isEmpty(ref_node_variable) || (ref_node_variable_type !== ref_ele_type)){
          if(ref_node?.name){
            message = message + " for " + ref_node?.name;
          }
          if (ref_node?.description) {
            message = message + " - " + ref_node?.description;
          }
          message = `${message} are outdated. Please remove them and add them again to ensure the latest values are used.`
          current_node.warnings.push(message);
          is_changed = true;
        }
      } else if (["LOCAL", "GLOBAL", "HIDDEN_PARAMS", "QUERY_PARAMS"].includes(ref_ele?.variable_type)) {
        //validate for the constants
        let constant_var_ref = _.find((variables?.[ref_ele?.variable_type] || []), (ele) => {
          return (ref_ele?.variable_type && ref_ele?.variable_type === ele?.mode && ref_ele_key === ele?.name);
        });
        let constant_var_ref_type = String(constant_var_ref?.data_type).toUpperCase();
        if (["OBJECT"].includes(constant_var_ref_type)) {
          constant_var_ref_type = "JSON";
        }
        let message = "The references"
        if (_.isEmpty(constant_var_ref) || (constant_var_ref_type !== ref_ele_type)) {
          if (constant_var_ref?.mode) {
            message = message + " for " + constant_var_ref?.mode;
          }
          if (constant_var_ref?.key) {
            message = message + " - " + constant_var_ref?.key;
          }
          message = `${message} are outdated. Please remove them and add them again to ensure the latest values are used.`
          current_node.warnings.push(message);
          is_changed = true;
        }
      }
    }
    if (is_changed === true) {
      current_node.warnings = _.uniq(current_node.warnings);
      result.nodes.push(current_node);
    }
    return { status: "success", result: result };
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};