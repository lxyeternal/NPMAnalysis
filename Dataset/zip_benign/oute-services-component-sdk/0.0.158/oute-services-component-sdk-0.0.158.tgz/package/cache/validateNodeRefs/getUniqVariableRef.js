"use strict";

let _ = require("lodash");

let getUniqVariableRef = (obj) => {
  let result = {variable_refs: []};
  if (_.isObject(obj)) {
    if (_.isArray(obj)) {
      for(let node of obj){
        let _result = getUniqVariableRef(node);
        result.variable_refs = result.variable_refs.concat(_result.variable_refs);
      }
    } else {
      if (obj?.type === "fx") {
        for (let block of (obj?.blocks || [])) {
          let variable_data = block?.variableData;
          if (block?.type === "NODE") {
            result.variable_refs.push({ id: variable_data?.nodeId, key: variable_data?.key, path_ref: variable_data?.path, type: variable_data?.type, variable_type: block?.type })
          } else if (["LOCAL", "GLOBAL", "HIDDEN_PARAMS", "QUERY_PARAMS"].includes(block?.type)) {
            result.variable_refs.push({ id: variable_data?.asset_id, key: variable_data?.name, path_ref: [variable_data?.name], type: variable_data?.data_type, variable_type: variable_data?.mode })
          }
        }
      } else {
        for (let key of Object.keys(obj)) {
          let _result = getUniqVariableRef(obj?.[key]);
          result.variable_refs = result.variable_refs.concat(_result.variable_refs);
        }
      }
    }
  }
  result.variable_refs = _.uniqWith(result.variable_refs, _.isEqual);
  return result;
}

module.exports = getUniqVariableRef