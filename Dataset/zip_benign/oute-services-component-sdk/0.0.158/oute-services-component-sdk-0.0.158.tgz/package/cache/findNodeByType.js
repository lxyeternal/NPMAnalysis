"use strict";

let _ = require("lodash");

module.exports = (_canvas_data, ui_type)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(ui_type)) { throw {message: "Node type is mandatory"}; }
    let nodes = [];
    for (var ele of (canvas_data?.nodeDataArray || [])) {
      if(ele?.type && (ele?.type === ui_type)) {
        nodes.push(ele);
      }
    }
    return {status: "success", result: nodes};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};