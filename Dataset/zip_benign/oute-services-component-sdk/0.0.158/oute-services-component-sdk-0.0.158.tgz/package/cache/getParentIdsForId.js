"use strict";

let _ = require("lodash");
let utility = require("oute-services-utility-sdk");

let findOneNodeById = require("./findOneNodeById");

var getParentIds = (data, node_id)=> {
  try {
    data = data || [];
    let _data = _.cloneDeep(data);
    let parentIds = [];
    let ele_list = utility.queryArray(_data, {to: node_id});
    for (var ele of ele_list) {
      var ele_index = _.findIndex(_data, ele);
      if(ele_index >= 0) {
        var from_id = _data?.[ele_index]?.from;
        parentIds.push(from_id);
        _data?.splice(ele_index, 1);
        var _parentIds = getParentIds(_data, from_id);
        if(_parentIds?.length) {
          parentIds = parentIds?.concat(_parentIds);
        }
      }
    }
    return parentIds;
  } catch (error) {
    throw error;
  }
};

module.exports = (_canvas_data, node_id)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(node_id)) { throw {message: "Node id is mandatory"}; }
    //find current node
    let current_node = findOneNodeById(_canvas_data, node_id)?.result;
    //current node cant be empty
    if(_.isEmpty(current_node?.key)) { throw {message: "Node id is missing in canvas data"}; }
    let parent_ids = getParentIds(canvas_data?.linkDataArray, node_id);
    return {status: "success", result: parent_ids};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};