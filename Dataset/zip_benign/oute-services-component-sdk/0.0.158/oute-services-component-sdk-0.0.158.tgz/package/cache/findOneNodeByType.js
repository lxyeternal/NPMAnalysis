"use strict";

let _ = require("lodash");

module.exports = (_canvas_data, ui_type)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(ui_type)) { throw {message: "Node type is mandatory"}; }
    //find current node
    let current_node = _.find((canvas_data?.nodeDataArray || []), ele=> { return (ele?.type && (ele?.type === ui_type)); });
    return {status: "success", result: current_node};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};