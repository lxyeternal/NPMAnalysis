"use strict";

let _ = require("lodash");

let types = ["NODE", "VARIABLE"];

let getUniqVariableRef = (obj, node_id, type) => {
  let result = {keys: []};
  if (!types.includes(type)) { throw { message: `Type should be any of ${types.join(", ")}`}}
  if (_.isObject(obj)) {
    if(type === "NODE") {
      if (_.isArray(obj)) {
        for(let node of obj){
          let _result = getUniqVariableRef(node, node_id, type);
          result.keys = result.keys.concat(_result.keys);
        }
      } else {
        if (obj?.type === "fx") {
          for (let block of (obj?.blocks || [])) {
            let block_node_id = block?.variableData?.nodeId;
            let block_path_str = block?.variableData?.path?.join(".");
            if (block?.type === "NODE" && block_node_id && block_node_id === node_id) {
              result.keys.push(block_path_str)
            }
          }
        } else {
          for (let key of Object.keys(obj)) {
            let _result = getUniqVariableRef(obj?.[key], node_id, type);
            result.keys = result.keys.concat(_result.keys);
          }
        }
      }
    } else if (type === "VARIABLE") {
      if(_.isArray(obj)) {
        for(let input of obj) {
          let path_str = input?.path?.join(".");
          if (path_str){
            result.keys.push(path_str);
          }
          if(input?.schema?.length){
            let _result = getUniqVariableRef(input?.schema, node_id, type);
            result.keys = result.keys.concat(_result.keys);
          }
        }
      }
    }
  }
  result.keys = _.uniq(result.keys);
  return result;
}

module.exports = getUniqVariableRef