"use strict";

let _ = require("lodash");

//update the recursive objects
let updateNodeRef = (node_id, output, node) => {
  let result = {errors: [], is_changed: false}
  if(_.isObject(node)){
    if(node?.type === "fx"){
      for(let block of (node?.blocks || [])) {
        let block_node_id = block?.variableData?.nodeId;
        let block_path_str = block?.variableData?.path?.join(".");
        let block_type = block?.variableData?.type?.toUpperCase();
        let output_path_str = output?.path?.join(".");
        let output_type = output?.type?.toUpperCase();
        if (["OBJECT"].includes(block_type)){
          block_type = "JSON";
        }
        if (["OBJECT"].includes(output_type)) {
          output_type = "JSON";
        }
        if (block?.type === "NODE" && block_node_id && block_node_id === node_id && block_path_str === output_path_str){
          if (block_type && block_type !== output_type) {
            let message = `The type has been changed from ${block_type} to ${output_type} for key ${block?.variableData?.key}`;
            if (!result.errors.includes(message)){
              result.errors.push(message);
            }
            result.is_changed = true;
          }
          if (!_.isEqual(block.variableData.sample_value, output.sample_value)){
            result.is_changed = true;
          }
          if (result.is_changed === true){
            block.variableData.type = output_type;
            block.variableData.path = output.path;
            block.variableData.pathStr = output.pathStr;
            block.variableData.schema = output.schema;
            block.variableData.sample_value = output.sample_value;
          }
        }
      }
    } else {
      for(let key of Object.keys(node)){
        let _result = updateNodeRef(node_id, output, node?.[key]);
        result.errors = result.errors.concat(_result.errors);
        if(result.is_changed !== true){
          result.is_changed = _result?.is_changed;
        }
      }
    }
  }
  result.errors = _.uniq(result.errors)
  result.node = node;
  return result;
}

module.exports = (node_id, output, node_list)=> {
  try {
    if(!_.isArray(node_list)){node_list = []}
    let result = {nodes: []};
    for(let node of node_list){
      let updated_info = updateNodeRef(node_id, output, node);
      if (!_.isArray(node.errors)) { node.errors = []}
      if(updated_info?.is_changed === true){
        node.errors = node.errors.concat(updated_info?.errors);
        result.nodes.push(node);
      }
    }
    return { status: "success", result: result };
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};