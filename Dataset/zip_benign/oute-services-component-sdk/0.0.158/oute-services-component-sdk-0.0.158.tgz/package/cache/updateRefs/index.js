"use strict";

let _ = require("lodash");

let findOneNodeById = require("../findOneNodeById");
let updateVariableRef = require("./updateVariableRef");
let getUniqVariableRef = require("./getUniqVariableRef");

//call this for recursive updates
let updateOutputRefs = (node_id, outputs, canvas_data) => {
  let result = { nodes: [] };
  for (let output of outputs) {
    let updated_node_info = updateVariableRef(node_id, output, canvas_data?.nodeDataArray);
    result.nodes = result.nodes.concat(updated_node_info?.result?.nodes);
    if(output?.schema?.length){
      let _result = updateOutputRefs(node_id, output?.schema, canvas_data);
      result.nodes = result.nodes.concat(_result.nodes);
    }
  }
  result.nodes = _.uniqBy(result.nodes, "key");
  return result;
}

module.exports = (_canvas_data, node_id)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if (_.isEmpty(canvas_data)) { throw { message: "Canvas data parameters are required but were not provided"}; }
    if (!(node_id)) { throw { message: "Node id parameters are required but were not provided"}; }
    //get the current node data
    let current_data = findOneNodeById(_canvas_data, node_id)?.result || {};
    let tf_data = current_data?.tf_data;
    let go_data = current_data?.go_data;
    let outputs = []
    //use the output if available
    if(go_data?.output?.schema?.schema){
      outputs = go_data?.output?.schema?.schema;
    } else {
      outputs = tf_data?.outputs || [];
      if (!outputs?.length){
        outputs = tf_data?.inputs || [];
      }
    }
    let result = {nodes: []};
    //get the uniq var ref list
    let curr_ref_list = getUniqVariableRef(outputs, node_id, "VARIABLE")?.keys;
    for (let node of canvas_data?.nodeDataArray){
      let used_ref_list = getUniqVariableRef(node, node_id, "NODE")?.keys;
      let missing_ref_list = _.difference(used_ref_list, curr_ref_list);
      if(missing_ref_list?.length){
        if (!_.isArray(node.errors)) { node.errors = [] }
        node.errors.push("It appears the old reference is no longer available. Please correct it");
      }
    }
    //update the node for outputs
    result.nodes = updateOutputRefs(node_id, outputs, canvas_data)?.nodes;
    return { status: "success", result: result };
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};