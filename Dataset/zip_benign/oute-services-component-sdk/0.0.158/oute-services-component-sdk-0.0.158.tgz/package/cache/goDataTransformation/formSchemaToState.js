"use strict";

let _ = require("lodash");
let utility = require("oute-services-utility-sdk");

let formSchemaToState = form_schema => {
  try {
    let state = {};
    for (var node_id of Object.keys((form_schema?.blocks || {}))) {
      var node_config = form_schema?.blocks?.[node_id];
      if(_.isArray(node_config?.schema)) {
        state[node_id] = utility.schemaToJson({schema: node_config?.schema});
      }
    }
    return state;
  } catch (error) {
    throw error;
  }
};

module.exports = form_schema=> {
  let result;
  try {
    if(_.isEmpty(form_schema)) { throw {message: "Form schema is mandatory"}; }
    result = formSchemaToState(form_schema);
    return {status: "success", result};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};