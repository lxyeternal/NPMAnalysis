"use strict";

let _ = require("lodash");
let utility = require("oute-services-utility-sdk");

var updateTheParentInfoToChilds = (schema, variable_data) => {
  try {
    schema = _.map(schema,ele => {
      let ele_schema = ele?.schema || [];
      if(ele_schema?.length) {
        ele_schema = updateTheParentInfoToChilds(ele_schema, variable_data);
      }
      ele = {...variable_data, ...ele, schema: ele_schema};
      delete ele?.rolling_path;
      return ele;
    });
    return schema;
  } catch (error) {
    throw error;
  }
};

var isPathExists = (schema, path_str) => {
  try {
    let result = {is_exists: false, item: undefined};
    for (var ele of (schema || [])) {
      if((ele?.pathStr !== undefined) && (ele?.pathStr === path_str)) {
        result.is_exists = true;
        result.item = ele;
        break;
      } else if(ele?.schema?.length) {
        result = isPathExists(ele?.schema, path_str);
      }
    }
    return result;
  } catch (error) {
    throw error;
  }
};

var generateSchemaForPath = (schema=[], variable_data={}, sub_path_index=0) => {
  try {
    let sub_path = variable_data.path?.[sub_path_index];
    if(variable_data.rolling_path === undefined) { variable_data.rolling_path = []; }
    if(sub_path) {
      let key_info = utility.getDefaultValueAndTypeForKey(variable_data.pathStr, sub_path_index, ".");
      let sample_value = key_info?.default || variable_data.sample_value;
      if (typeof (variable_data.sample_value) === typeof (key_info?.default)){
        sample_value = variable_data.sample_value;
      }
      let type = key_info?.type || variable_data.type;
      let path_str = key_info?.path_str || variable_data.pathStr;
      let var_path_str = variable_data.pathStr;
      variable_data.rolling_path.push(sub_path);
      let item_info = isPathExists(schema, path_str);
      let is_exists = item_info?.is_exists;
      let base_schema_ele = item_info?.item;
      if(base_schema_ele === undefined) {
        base_schema_ele = { ...variable_data, schema: [], key: sub_path, type, sample_value, pathStr: path_str, path : [...variable_data.rolling_path] };
      } else {
        is_exists = false;
      }
      let ele_schema = base_schema_ele.schema;
      if(var_path_str && (var_path_str === base_schema_ele?.pathStr)) {
        //Here the sequence of concat matters
        ele_schema = _.uniqBy(_.cloneDeep(variable_data?.schema || []).concat(ele_schema), "pathStr");
      }
      ele_schema = generateSchemaForPath(ele_schema, variable_data, sub_path_index + 1);
      base_schema_ele.schema = ele_schema;
      is_exists = isPathExists(schema, path_str)?.is_exists;
      if(is_exists === false) {
        schema.push(base_schema_ele);
      }
    }
    return schema;
  } catch (error) {
    throw error;
  }
};

var generateFormSchema = (node_config, form_schema) => {
  try {
    if(_.isEmpty(form_schema)) { form_schema = {blocks: {}, keys: []}; }
    if(_.isPlainObject(node_config)) {
      if(node_config?.type === "fx") {
        for (var block of node_config?.blocks) {
          var block_variable_data = block?.variableData;
          delete block_variable_data?.rolling_path;
          if((block?.type === "NODE") && block_variable_data) {
            var _key = `${block.variableData.nodeId}_${block.variableData.pathStr}`;
            if (!form_schema.keys.includes(_key)) {
              form_schema.keys.push(_key);
              if (form_schema.blocks[block.variableData.nodeId] === undefined) {
                form_schema.blocks[block.variableData.nodeId] = {
                  nodeName : block.variableData.nodeName,
                  schema : [],
                  nodeId : block.variableData.nodeId
                };
              }
              var new_schema = form_schema.blocks[block.variableData.nodeId].schema;
              new_schema = generateSchemaForPath(new_schema, block_variable_data, 0);
              new_schema = updateTheParentInfoToChilds(new_schema, block_variable_data);
              form_schema.blocks[block.variableData.nodeId].schema = new_schema;
            }
          }
        }
      } else {
        for (var key of Object.keys(node_config)) {
          form_schema = generateFormSchema(node_config?.[key], form_schema);
        }
      }
    } else if(_.isArray(node_config)) {
      for (var ele_config of node_config) {
        form_schema = generateFormSchema(ele_config, form_schema);
      }
    }
    return form_schema;
  } catch (error) {
    throw error;
  }
};

module.exports = node_config=> {
  let result;
  try {
    if(_.isEmpty(node_config)) { throw {message: "Config is mandatory"}; }
    result = generateFormSchema(_.cloneDeep(node_config), {});
    return {status: "success", result};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};