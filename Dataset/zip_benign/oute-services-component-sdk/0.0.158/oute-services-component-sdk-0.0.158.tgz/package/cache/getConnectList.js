"use strict";

let _ = require("lodash");

let constant_instance = require("oute-services-constants-sdk");

let getParentIdsForId = require("./getParentIdsForId");
let constants = constant_instance.getConstants("canvas")?.result;

module.exports = (_canvas_data, node_id)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(node_id)) { throw {message: "Node id is mandatory"}; }
    let canvas_node_types = constants?.canvas_node_types;
    //find all parents id
    let parent_ids = getParentIdsForId(_canvas_data, node_id)?.result;
    //adding current node id in parent list as we want to exclued it
    parent_ids?.push(node_id);
    let connect_list = [];
    for (var node of canvas_data?.nodeDataArray) {
      if(node?.type && ![canvas_node_types?.start?.ui, canvas_node_types?.dummy?.ui].includes(node?.type) && !parent_ids.includes(node?.key)) {
        connect_list.push(node);
      }
    }
    return {status: "success", result: connect_list};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};