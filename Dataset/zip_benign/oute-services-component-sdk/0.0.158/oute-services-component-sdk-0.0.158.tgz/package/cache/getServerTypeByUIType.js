"use strict";

let constant_instance = require("oute-services-constants-sdk");

let constants = constant_instance.getConstants("canvas")?.result;

module.exports = (ui_type, ignore_server_type_check=true)=> {
  try {
    if(!(ui_type)) { throw {message: "Node type is mandatory"}; }
    let canvas_node_types = constants?.canvas_node_types;
    let server_type = undefined;
    for (var key of Object.keys(canvas_node_types)) {
      var value = canvas_node_types?.[key];
      if(value?.ui && (value?.ui === ui_type)) {
        server_type = value?.server;
        break;
      }
    }
    if(!(server_type) && (ignore_server_type_check === true)) { throw {message: `Type missing for ${ui_type}`}; }
    return {status: "success", result: server_type};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};