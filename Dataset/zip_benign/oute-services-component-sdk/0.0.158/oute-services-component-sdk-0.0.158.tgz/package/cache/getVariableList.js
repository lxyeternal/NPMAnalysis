"use strict";

let _ = require("lodash");
let constant_instance = require("oute-services-constants-sdk");

let constants = constant_instance.getConstants("canvas")?.result;
let getParentIdsForId = require("./getParentIdsForId");
let getVariableByParent = require("../core/getVariableByParent");
let findOneNodeById = require("./findOneNodeById");

module.exports = (config, _canvas_data, node_id, parent_id, asset_id)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      let canvas_data = JSON.parse(_canvas_data|| "{}");
      if(_.isEmpty(canvas_data)) { return reject({status: "failed", result: {message: "Canvas data is required"}}); }
      if(!(node_id)) { return reject({status: "failed", result: {message: "Node id is mandatory"}}); }
      if(!(parent_id)) { return reject({status: "failed", result: {message: "Project/parent is mandatory"}}); }
      let canvas_node_types = constants?.canvas_node_types;
      //find all parents id
      let parent_ids = getParentIdsForId(_canvas_data, node_id)?.result;
      let variables = {NODE: []};
      if(parent_id) {
        let asset_variable = (await getVariableByParent(config, {parent_id}))?.result || {};
        if(asset_id && asset_variable?.LOCAL?.length) {
          asset_variable.LOCAL = _.filter(asset_variable?.LOCAL, (ele => { return (asset_id && (asset_id === ele?.asset_id)); }));
        }
        variables = _.extend(variables, asset_variable);
      }
      //predict the grouped ids
      let skip_ids = [];
      let aggregator_src_ids = [];
      for (parent_id of parent_ids) {
        var node_data = findOneNodeById(_canvas_data, parent_id)?.result;
        if(node_data?.type && (node_data?.type === canvas_node_types?.array_aggregator?.ui)) {
          var src_node_id = node_data?.tf_data?.config?.source?.key;
          if(src_node_id) {
            aggregator_src_ids.push(src_node_id);
          }
        } else {
          var aggregator_last_src_id = aggregator_src_ids.at(-1);
          if(aggregator_last_src_id) {
            if(aggregator_last_src_id === parent_id) {
              aggregator_src_ids.pop();
            }
            skip_ids.push(parent_id);
          }
        }
      }
      //add the valid node to variables
      for (var node of canvas_data?.nodeDataArray) {
        if(parent_ids.includes(node?.key)) {
          if((node?.go_data === undefined) || skip_ids.includes(node?.key)) {
            continue;
          }
          var ele = {...node, tf_data: undefined};
          ele.data = node?.go_data?.output;
          if(!(_.isEmpty(ele?.data?.schema?.keys))) {
            variables?.NODE?.push(ele);
          }
        }
      }
      return resolve({status: "success", result: variables});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};