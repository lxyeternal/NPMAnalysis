"use strict";

let _ = require("lodash");

let findOneNodeById = require("./findOneNodeById");

module.exports = (_canvas_data, node_id)=> {
  let error;
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is required"}; }
    if(!(node_id)) { throw {message: "Node id is mandatory"}; }
    //find current node
    let current_node = findOneNodeById(_canvas_data, node_id)?.result;
    //current node cant be empty
    if(_.isEmpty(current_node?.key)) { throw {message: "Node id is missing in canvas data"}; }
    let linkDataArray = canvas_data?.linkDataArray || [];
    let in_links = {counts: {all: 0}, nodes: []};
    let out_links = {counts: {all: 0}, nodes: []};
    let exceptions = undefined;
    for (var link of linkDataArray) {
      try {
        if(link?.from && (link?.from === node_id)) {
          out_links.counts.all = out_links?.counts?.all + 1;
          var oute_node = findOneNodeById(_canvas_data, link?.to)?.result;
          if(out_links?.counts?.[oute_node?.type] === undefined) { out_links.counts[oute_node?.type] = 0; }
          if(out_links?.counts?.[oute_node?.key] === undefined) { out_links.counts[oute_node?.key] = 0; }
          out_links.counts[oute_node?.key] = out_links?.counts?.[oute_node?.key] + 1;
          out_links.counts[oute_node?.type] = out_links?.counts?.[oute_node?.type] + 1;
          out_links?.nodes?.push(oute_node);
        }
        if(link?.to && (link?.to === node_id)) {
          in_links.counts.all = in_links?.counts?.all + 1;
          var in_node = findOneNodeById(_canvas_data, link?.from)?.result;
          if(in_links?.counts?.[in_node?.type] === undefined) { in_links.counts[in_node?.type] = 0; }
          if(in_links?.counts?.[in_node?.key] === undefined) { in_links.counts[in_node?.key] = 0; }
          in_links.counts[in_node?.key] = in_links?.counts?.[in_node?.key] + 1;
          in_links.counts[in_node?.type] = in_links?.counts?.[in_node?.type] + 1;
          in_links?.nodes?.push(in_node);
        }
      } catch (error1) {
        error = error1;
        exceptions = error;
        break;
      }
    }
    if(exceptions) { throw {status: "failed", result: (exceptions?.result?.result || exceptions?.result || exceptions)}; }
    return {status: "success", result: {in_links, out_links}};
  } catch (error2) {
    error = error2;
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};