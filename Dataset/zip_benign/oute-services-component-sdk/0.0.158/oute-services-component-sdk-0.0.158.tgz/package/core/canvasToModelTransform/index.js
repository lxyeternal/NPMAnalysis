"use strict";

let tranformer_map = require("./typeFunctionMap");

module.exports = node_data => {
  try {
    if(!(node_data?.type)) { throw {message: "Type is mandatory"}; }
    let type = node_data?.type;
    if (Object.keys(tranformer_map).includes(type)) {
      let fn = tranformer_map?.[type];
      if(fn === undefined) { throw {message: "This feature will be availabe in next release"}; }
      return fn(node_data);
    } else {
      return {status: "success", result: node_data};
    }
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};