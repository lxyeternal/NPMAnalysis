"use strict";

let _ = require("lodash");

let getInputsAndConfig = require("./getInputsAndConfig");
let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    //massage inputs
    let input_result = getInputsAndConfig(go_data)?.result;
    node_data.inputs = formatSchema(input_result?.inputs, [], false).schema;
    //massage outputs
    node_data.outputs = formatSchema(go_data?.output?.schema?.schema, [], false).schema;
    node_data.type = go_data?.type;
    //massage configs
    node_data.config = {
      ...(input_result?.config || {}),
      url: go_data?.url,
      method: go_data?.method,
      max_retry: go_data?.max_retry,
      retry_delay: go_data?.retry_delay,
      timeout: go_data?.timeout,
      parse_response: go_data?.parse_response,
      output_in_sequence: go_data?.output_in_sequence,
      node_id: go_data?.node_id
    };
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};