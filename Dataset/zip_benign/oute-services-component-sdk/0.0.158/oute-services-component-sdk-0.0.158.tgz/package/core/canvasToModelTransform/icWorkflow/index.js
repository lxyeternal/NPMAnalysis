"use strict";
let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    node_data.inputs = formatSchema(go_data?.inputs, [], false).schema;
    node_data.outputs = formatSchema(go_data?.outputs, [go_data?.node_id], true).schema;
    node_data.type = go_data?.type;
    delete go_data?.inputs;
    delete go_data?.outputs;
    node_data.config = {...go_data};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};