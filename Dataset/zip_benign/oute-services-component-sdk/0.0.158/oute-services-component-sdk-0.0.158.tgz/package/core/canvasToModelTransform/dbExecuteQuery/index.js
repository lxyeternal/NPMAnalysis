"use strict";

let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = go_data => {
  try {
    let node_data = {};
    go_data.record = go_data?.record || [];
    node_data.inputs = [{ "key": "query", "value": go_data?.content, "type": "STRING", "default": null, "required": true, "regex": null }];
    let output = { "key": "response", "value": undefined, "type": "ARRAY", "default": null, "required": false, "regex": null };
    node_data.outputs = formatSchema([output], [go_data?.node_id], true).schema;
    node_data.type = go_data?.type;
    go_data.connection.id = go_data?.connection?._id;
    node_data.config = {
      node_id: go_data?.node_id,
      ...go_data
    };
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};