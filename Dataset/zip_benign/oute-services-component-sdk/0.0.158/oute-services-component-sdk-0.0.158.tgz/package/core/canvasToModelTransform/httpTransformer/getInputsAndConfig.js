"use strict";

let _ = require("lodash");

let data_mappings = [
  {key: "path_variable", type: "JSON"},
  {key: "query_params", type: "JSON"},
  {key: "headers", type: "JSON"},
  {key: "authorization", type: "JSON"},
  {key: "body"}
];

module.exports = go_data => {
  let result;
  try {
    result = {inputs: [], config: {}};
    for (var data_mapping of data_mappings) {
      var key_name = data_mapping?.key;
      var key_data = go_data?.[key_name];
      var input = {
        key: key_name,
        type: data_mapping?.type,
        schema: key_data
      };
      if(key_name === "authorization") {
        input.schema = key_data?.data || [];
        result.config[key_name] = {type: key_data?.type};
      } else if(key_name === "body") {
        input.type = key_data?.sub_type;
        result.config[key_name] = {type: key_data?.type, sub_type: key_data?.sub_type};
        input.schema = [];
        if(_.isArray(key_data?.data)) {
          input.schema = key_data?.data;
        } else {
          input.value = key_data?.data;
        }
      }
      result.inputs.push(input);
    }
    return {status: "success", result};
  } catch (error) {
    throw {status: "failed", result: error};
  }
};