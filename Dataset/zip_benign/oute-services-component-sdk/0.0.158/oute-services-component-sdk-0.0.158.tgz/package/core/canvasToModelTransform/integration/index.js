"use strict";

let _ = require("lodash");
let constant_instance = require("oute-services-constants-sdk");

let constants = constant_instance.getConstants("canvas")?.result;

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    node_data.inputs = go_data?.inputs || [];
    node_data.outputs = formatSchema(go_data?.outputs).schema;
    node_data.type = go_data?.type;
    delete go_data?.inputs;
    let canvas_node_types = constants?.canvas_node_types;
    go_data.state = go_data?.state || {};
    go_data.flow.flow = go_data?.flow?.flow || {};
    for (let node_id of Object.keys(go_data?.flow?.flow)) {
      let node_config = go_data?.flow?.flow?.[node_id];
      if(!(_.isEmpty(node_config))) {
        node_config.inputs = node_config?.inputs || [];
        node_config.outputs = node_config?.outputs || [];
        //Append the available inputs of flow to his input
        if (!(node_config?.prev_node_ids?.length)) {
          node_data.inputs = node_data.inputs.concat(node_config?.inputs || [])
        } else if([canvas_node_types?.question_fx?.server].includes(node_config?.type)) {
          let fx_output = { "key": "response", "value": go_data?.state?.[node_id]?.response, "type": "ANY", "default": null, "required": false, "regex": null };
          node_config.inputs = formatSchema([fx_output], [], false).schema;
          delete go_data?.state?.[node_id];
        } else if ([canvas_node_types?.key_value_table?.server].includes(node_config?.type)) {
          let key_value_output = { "key": "response", "value": go_data?.state?.[node_id]?.response, "type": "ARRAY", "default": null, "required": false, "regex": null };
          node_config.inputs = formatSchema([key_value_output], [], false).schema;
          delete go_data?.state?.[node_id];
        } else if(["END"].includes(node_config?.node_marker)) {
          node_data.outputs = node_data.outputs.concat(formatSchema(node_config?.outputs, [go_data?.node_id], true).schema);
        }
      }
    }
    node_data.inputs = formatSchema(node_data.inputs).schema;
    node_data.config = {...go_data};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};