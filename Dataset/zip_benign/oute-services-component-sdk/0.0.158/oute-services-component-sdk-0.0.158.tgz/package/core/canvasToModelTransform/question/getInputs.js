"use strict";

let _ = require("lodash");
let utility = require("oute-services-utility-sdk");

let formatSchema = require("../misc/formatSchema");

module.exports = go_data => {
  try {
    let input = { "key": "response", "value": undefined, "type": go_data?.response_type || "ANY", "default": null, "required": false, "regex": null };
    let inputs = [];
    if(go_data?.type === "KEY_VALUE_TABLE") {
      if(input?.type?.toUpperCase() !== "ARRAY") {
        input.type = "ARRAY";
      }
      input.value = go_data?.value;
    } else {
      if((go_data?.value?.type === "fx") && go_data?.value?.blocks?.length) {
        input.value = go_data?.value;
      } else {
        input.schema = utility.jsonToSchema((go_data?.value || {}), {})?.schema || [];
      }
    }
    inputs = formatSchema([input], [go_data?.node_id], false).schema;
    return inputs;
  } catch (error) {
    throw (error?.result?.result || error?.result || error);
  }
};