"use strict";

let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    go_data.inputs = [];
    go_data.outputs = [
      {
        key: "response", type: "ARRAY",
        schema: [
          {key: "index", type: "INT"},
          {key: "input", type: "STRING"},
          {key: "groups", type: "ANY"},
          {key: "data", type: "ARRAY"}
        ]
      }
    ];
    node_data.outputs = formatSchema(go_data.outputs).schema;
    node_data.type = go_data?.type;
    node_data.config = {
      node_id: go_data?.node_id,
      ...go_data
    };
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};