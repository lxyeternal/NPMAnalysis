"use strict";

let _ = require("lodash")
module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    let output = { "key": "response", "value": go_data?.content, "type": "ANY", "default": null, "required": false, "regex": null };
    node_data.outputs = [];
    node_data.inputs = [output];
    node_data.type = go_data?.type;
    node_data.config = { node_id: go_data?.node_id, log_level: go_data?.logType };
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};