"use strict";
let _ = require("lodash");
const utility = require("oute-services-utility-sdk");

let formatSchema = require("../../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    go_data.record = go_data?.record || [];
    node_data.inputs = [];
    node_data.outputs = [];
    for (var field of go_data.record) {
      let field_format = {}
      field_format.key = field?.dbFieldName;
      field_format.type = utility.convertDbType(field?.dbFieldType);
      field.type = field_format.type;
      field_format.value = field?.value;
      node_data.inputs.push({ ...field });
      node_data.outputs.push(field_format);
    }
    node_data.outputs = formatSchema(node_data.outputs, [go_data?.node_id], true).schema;
    node_data.type = go_data?.type;
    go_data.asset.id = go_data?.asset?._id;
    delete go_data?.record;
    node_data.config = {...go_data};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};