"use strict";

let _ = require("lodash");

let getInputs = require("./getInputs");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    node_data.inputs = getInputs(go_data);
    node_data.outputs = [];
    node_data.type = go_data?.type;
    node_data.config = {...go_data};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};