"use strict";

let _ = require("lodash");
let constants_instance = require("oute-services-constants-sdk");
let constants = constants_instance.getConstants("constants")?.result;
let getType = require("./getType");

var formatSchema = (schema, path_list=[], parent_type, override_value) => {
  try {
    let formatted_schema = [];
    for (var item of schema) {
      if(item?.validation?._id) {
        item.validation.id = item.validation._id;
      }
      item.default = item.default || item?.default_value;
      //skip the row if the key, type, value, default is not available
      if(_.isEmpty(item?.key)) {
        if((item?.value === undefined) && (item?.default === undefined)) {
          continue;
        } else if (((item?.value?.blocks !== undefined) || (item?.default?.blocks !== undefined)) && _.isEmpty(item?.value?.blocks) && _.isEmpty(item?.default?.blocks)) {
          continue;
        }
      }
      //if config key is array then change it to schema
      if(_.isArray(item?.config)) {
        item.schema = item?.config;
        delete item?.config;
      }
      if(!(_.isArray(item?.schema))) {
        item.schema = [];
      }
      //generate the path list
      if(item?.key) {
        item.path = [...path_list, item.key];
      } else {
        item.path = [...path_list];
      }
      //type treatment
      item.type = getType(item?.type);
      //set the value if not provided
      if(!(item?.value) || (override_value === true)) {
        if(["ARRAY"].includes(parent_type)) {
          if(item?.key) {
            item.path = item.path.toSpliced((item.path.length - 1), 0, "VAR_NAME");
          } else {
            item.path.push("VAR_NAME");
          }
        }
        item.value = constants?.variable_format?.replace(/VAR_NAME/g, item?.path?.join("."));
      }
      item.schema = formatSchema(item?.schema, item?.path, item.type, override_value);
      formatted_schema.push(item);
    }
    return formatted_schema;
  } catch (error) {
    throw error;
  }
};

module.exports = (org_schema, path_list=[], override_value=false) => {
  try {
    let schema;
    if(!(_.isArray(org_schema))) {
      schema = [];
    } else {
      schema = _.cloneDeep(org_schema);
    }
    schema = formatSchema(schema, path_list, undefined, override_value);
    return {schema};
  } catch (error) {
    throw error;
  }
};