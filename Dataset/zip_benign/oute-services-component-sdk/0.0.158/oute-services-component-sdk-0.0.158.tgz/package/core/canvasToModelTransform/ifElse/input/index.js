"use strict";

let _ = require("lodash");

let appendInputs = require("../../misc/appendInputs");

module.exports = go_data => {
  try {
    let inputs = [];
    let data = [];
    let iterable = go_data?.ifData || [];
    for (let index = 0; index < iterable.length; index++) {
      var ele = iterable[index];
      if(!(_.isEmpty(ele?.condition)) && ele?.jumpTo?.key) {
        data.push({key: `statement_${index}`, value: ele?.condition, type: "BOOLEAN", node_id: ele?.jumpTo?.key});
      }
    }
    if(go_data?.elseData?.[0]?.jumpTo?.key) {
      data.push({key: "else_statement", value: {type: "fx", blocks: [{"type":"KEYWORDS","subType": "TRUE"}]}, type: "BOOLEAN", node_id: go_data?.elseData?.[0]?.jumpTo?.key});
    }
    inputs = appendInputs(inputs, data, undefined, undefined);
    return {status: "success", result: inputs};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};