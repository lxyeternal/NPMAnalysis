"use strict";

let formatSchema = require("../misc/formatSchema");

module.exports = go_data => {
  try {
    let node_data = {};
    //massage outputs
    node_data.outputs = formatSchema(go_data?.outputs).schema;
    node_data.type = go_data?.type;
    node_data.config = {node_id: go_data?.node_id};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};