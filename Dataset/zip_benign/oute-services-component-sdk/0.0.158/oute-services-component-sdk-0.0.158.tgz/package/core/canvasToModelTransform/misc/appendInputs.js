"use strict";

module.exports = (inputs, data) => {
  try {
    data = data || [];
    for (var input of data) {
      if(input?.validation?._id) {
        input.validation.id = input.validation._id;
      }
      var new_input = {
        ...input,
        key: input?.key,
        value: input?.value,
        type: input?.type || "ANY",
        default: input?.default || input?.default_value,
        required: input?.required,
        regex: input?.regex,
        node_id: input?.node_id
      };
      inputs.push(new_input);
    }
    return inputs;
  } catch (error) {
    throw error;
  }
};