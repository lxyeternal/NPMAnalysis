"use strict";

let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    let input = { "key": "data", "value": go_data?.content, "type": "ARRAY", "default": null, "required": false, "regex": null };
    node_data.inputs = [input];
    //currently assumed that the output will have only one element for iterator
    let schema = [];
    if((go_data?.content?.blocks?.length === 1) && _.isArray(go_data?.content?.blocks?.[0]?.variableData?.schema)) {
      schema = go_data?.content?.blocks?.[0]?.variableData?.schema;
    }
    let outputs = [
      { "key": "response", "value": undefined, "type": "ANY", "default": null, "required": false, "regex": null },
      { "key": "index", "value": undefined, "type": "INT", "default": null, "required": false, "regex": null }
    ];
    if(!(_.isEmpty(schema))) {
      outputs[0].schema = schema;
      outputs[0].type = "JSON";
    }
    node_data.outputs = formatSchema(outputs, [go_data?.node_id], true).schema;
    node_data.type = go_data?.type;
    delete go_data?.content;
    node_data.config = {...go_data};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};