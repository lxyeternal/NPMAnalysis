"use strict";

let _ = require("lodash");
let flow_utility_instance = require("oute-services-flow-utility-sdk");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    //massage outputs
    node_data.outputs = formatSchema(go_data?.outputs).schema;
    let status_code = go_data?.statusCode || 200;
    status_code = flow_utility_instance.parseAndValidate({key: "status_code", value: status_code, type: "INT"})?.value;
    node_data.type = go_data?.type;
    node_data.config = {
      node_id: go_data?.node_id,
      status_code
    };
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};