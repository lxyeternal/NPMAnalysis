"use strict";

let _ = require("lodash");
let flow_utility_instance = require("oute-services-flow-utility-sdk");
let constants_instance = require("oute-services-constants-sdk");
let constants = constants_instance.getConstants("constants")?.result;
let regexp_constants = constants?.regexp;

var parseSchemaWithDefaultValue = (inputs, update_key_by_alias=false) => {
  let error;
  try {
    inputs = inputs || [];
    let output_info = flow_utility_instance.predictOutputInfo(inputs);
    let parsed_obj = output_info?.value;
    let output_type = output_info?.type;
    for (var input of inputs) {
      //extract the values which is going to be used
      var key = input?.key;
      var alias = input?.alias;
      var value = input?.value;
      var default_value = input?.default;
      var case_type = input?.case_type;
      if(update_key_by_alias === true) {
        key = alias || key;
      }
      var type = String(input?.type || "").toUpperCase();
      var sub_inputs = input?.schema;
      try {
        value = flow_utility_instance.resolveValue({}, key, value, type, default_value, case_type)?.value;
      } catch (error1) {
        error = error1;
        console.log("PARSING-FAILED", error);
      }
      var var_regexp = new RegExp(regexp_constants?.variable_syntax_regexp, "gi");
      if(var_regexp.test(value) || (value === undefined)) {
        value = flow_utility_instance.getDefaultValueByType(input?.type)?.value;
      }
      //skip the row if the key, type, value, default is not available
      if(_.isEmpty(key)) {
        if((value === undefined) && (default_value === undefined)) {
          continue;
        } else if (((value?.blocks !== undefined) || (default_value?.blocks !== undefined)) && _.isEmpty(value?.blocks) && _.isEmpty(default_value?.blocks)) {
          continue;
        }
      }
      //Resolve child schema
      if(["ARRAY", "OBJECT", "JSON", "ANY"].includes(type) && !(_.isEmpty(sub_inputs)) && _.isArray(sub_inputs)) {
        if(["ARRAY"].includes(type)) {
          var _value = parseSchemaWithDefaultValue(sub_inputs, update_key_by_alias);
          value.push(_value);
        } else {
          value = parseSchemaWithDefaultValue(sub_inputs, update_key_by_alias);
        }
      }
      //set the value in parsed schema
      if(key) {
        value = {[key]: value};
      }
      if((output_type === "ARRAY") && _.isArray(parsed_obj)) {
        parsed_obj.push(value);
      } else if((output_type === "JSON") && _.isObject(value)) {
        parsed_obj = {...parsed_obj, ...value};
      } else if(output_type === "ANY") {
        parsed_obj = value;
      }
    }
    return parsed_obj;
  } catch (error2) {
    error = error2;
    return (() => { throw error; })();
  }
};

module.exports = parseSchemaWithDefaultValue;