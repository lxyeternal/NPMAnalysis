"use strict";

let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    node_data.inputs = [];
    node_data.outputs = [];
    for (var output of (go_data?.aggregateOnFields || [])) {
      //This was done to get the value on each iteration
      node_data.inputs.push({...output, type: "ANY"});
      output.type = "ARRAY";
      if((output?.value?.blocks?.length === 1) && _.isArray(output?.value?.blocks?.[0]?.variableData?.schema)) {
        output.schema = output?.value?.blocks?.[0]?.variableData?.schema;
      } else {
        output.schema = [{key: undefined, type: "ANY", value: output?.value}];
      }
      output.value = undefined;
      node_data.outputs.push({...output, filter_condition: undefined, filterCondition: undefined});
    }
    //if value not present then only append the values
    node_data.inputs = formatSchema(node_data.inputs, [], false).schema;
    node_data.outputs = formatSchema(node_data.outputs, [go_data?.node_id], true).schema;
    node_data.type = go_data?.type;
    let source_node_id = go_data?.source?.key;
    delete go_data?.aggregateOnFields;
    node_data.config = {...go_data, source_node_id};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};