"use strict";

let getType = type=> {
  try {
    type = (type || "ANY") + "";
    if(type === "object") {
      type = "JSON";
    }
    return type.toUpperCase();
  } catch (error) {
    throw error;
  }
};

module.exports = getType;