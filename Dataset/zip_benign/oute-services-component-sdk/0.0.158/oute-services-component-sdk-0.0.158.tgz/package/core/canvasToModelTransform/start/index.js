"use strict";

let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    //massage inputs
    node_data.inputs = formatSchema(go_data?.inputs).schema;
    node_data.type = go_data?.type;
    node_data.config = {node_id: go_data?.node_id};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};