"use strict";

module.exports = go_data => {
  try {
    let node_data = {};
    let output = { "key": "response", "value": go_data?.content, "type": go_data?.response_type || "ANY", "default": null, "required": false, "regex": null };
    if((output?.value?.blocks?.length === 1) && _.isArray(output?.value?.blocks?.[0]?.variableData?.schema)) {
      output.schema = output?.value?.blocks?.[0]?.variableData?.schema;
    }
    node_data.outputs = [];
    node_data.inputs = [output];
    node_data.type = go_data?.type;
    node_data.config = {node_id: go_data?.node_id};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};