"use strict";

let _ = require("lodash");

let formatSchema = require("../misc/formatSchema");

module.exports = _go_data => {
  try {
    let go_data = _.cloneDeep(_go_data);
    let node_data = {};
    go_data.record = go_data?.record || [];
    node_data.inputs = [];
    node_data.outputs = [];
    for (var field of go_data.record) {
      field.id = field?._id;
      field.key = field?.key || field?.name;
      node_data.inputs.push({...field});
      if(field?.checked === true) {
        node_data.outputs.push({...field});
      }
    }
    node_data.outputs = formatSchema(node_data.outputs, [go_data?.node_id], true).schema;
    node_data.type = go_data?.type;
    go_data.connection.id = go_data?.connection?._id;
    go_data.table.id = go_data?.table?._id;
    node_data.config = {
      node_id: go_data?.node_id,
      ...go_data
    };
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};