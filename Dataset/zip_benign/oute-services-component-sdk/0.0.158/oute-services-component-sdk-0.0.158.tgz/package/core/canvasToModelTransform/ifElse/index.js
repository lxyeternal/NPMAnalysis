"use strict";

let inputTransformer = require("./input");

module.exports = go_data => {
  try {
    let node_data = {};
    //massage inputs
    node_data.inputs = inputTransformer(go_data)?.result;
    node_data.type = go_data?.type;
    node_data.has_output = false;
    node_data.config = {node_id: go_data?.node_id};
    return {status: "success", result: node_data};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};