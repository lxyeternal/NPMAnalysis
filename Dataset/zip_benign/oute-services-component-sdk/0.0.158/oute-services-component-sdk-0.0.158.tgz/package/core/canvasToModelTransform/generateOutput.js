"use strict";

let utility = require("oute-services-utility-sdk");

let parseSchemaWithDefaultValue = require("./misc/parseSchemaWithDefaultValue");

module.exports = tf_data => {
  let result;
  try {
    if(!(tf_data?.type)) { throw {message: "Type is mandatory"}; }
    let outputs = [];
    if(tf_data?.outputs?.length) {
      outputs = tf_data?.outputs;
    } else if(tf_data?.inputs?.length) {
      outputs = tf_data?.inputs;
    }
    let plain_schema = parseSchemaWithDefaultValue(outputs);
    result = utility.jsonToSchema(plain_schema, {});
    return {status: "success", result};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};