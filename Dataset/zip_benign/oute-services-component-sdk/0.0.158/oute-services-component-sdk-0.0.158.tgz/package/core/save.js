"use strict";

let _ = require("lodash");

let utility = require("oute-services-utility-sdk");

module.exports = (config, body)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      if(_.isEmpty(body)) { return reject({status: "failed", result: {message: "Body parameters are required but were not provided"}}); }
      let save_option = {
        method: "POST",
        url: `${config?.url}/service/v0/component/add`,
        headers:{
          "Content-Type": "application/json",
          token: config?.token
        },
        body: JSON.stringify(body)
      };
      save_option = utility.processReqOptions(config, save_option);
      let save_resp = await utility.executeAPI(save_option);
      if(save_resp?.result?.status !== "success") { return reject({status: "failed", result: save_resp?.result?.result}); }
      save_resp.result.result.id = save_resp?.result?.result?._id;
      return resolve({status: "success", result: save_resp?.result?.result});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};