"use strict";

let _ = require("lodash");

let findOneNodeById = require("../cache/findOneNodeById");
let getServerTypeByUIType = require("../cache/getServerTypeByUIType");
let canvasToModel = require("./canvasToModelTransform");
let generateOutput = require("./canvasToModelTransform/generateOutput");

//This function used to transform UI data to backend data

module.exports = (_canvas_data, node_id, data)=> {
  try {
    let canvas_data = JSON.parse(_canvas_data|| "{}");
    if(_.isEmpty(data)) { throw {message: "Node data is mandatory"}; }
    if(_.isEmpty(canvas_data)) { throw {message: "Canvas data is mandatory"}; }
    let current_node = findOneNodeById(_canvas_data, node_id)?.result;
    if(_.isEmpty(current_node)) { throw {message: "Node is missing in canvas data"}; }
    let body = {...data, node_id};
    let tf_output = {};
    let server_type = getServerTypeByUIType(current_node?.type, false)?.result;
    if(!(server_type)) { throw {message: "This feature will be available in the next update"}; }
    body.type = server_type;
    body = canvasToModel(body)?.result;
    if(!(_.isEmpty(data?.output))) {
      tf_output = data?.output;
    } else {
      if(body?.has_output !== false) {
        tf_output = {schema: generateOutput(body)?.result};
      }
    }
    //Addtional keys needed in tf_data
    //setting the _id = node_id to maintain the structure so that in future we can support node save
    //gojs wont allow to save _id, so setting _id = id
    body.id = node_id;
    return {status: "success", result: {tf_data: body, tf_output}};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};