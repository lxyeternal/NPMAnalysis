"use strict";

let _ = require("lodash");

let save = require("./save");
let findOneNodeById = require("../cache/findOneNodeById");
let getServerTypeByUIType = require("../cache/getServerTypeByUIType");
let canvasToModel = require("./canvasToModelTransform");

module.exports = (config, _canvas_data, node_id, data)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      let canvas_data = JSON.parse(_canvas_data|| "{}");
      if(_.isEmpty(data)) { return reject({status: "failed", result: {message: "Node data is required"}}); }
      if(_.isEmpty(canvas_data)) { return reject({status: "failed", result: {message: "Canvas data is required"}}); }
      let current_node = findOneNodeById(_canvas_data, node_id)?.result;
      if(_.isEmpty(current_node)) { return reject({status: "failed", result: {message: "Node is missing in canvas data"}}); }
      let body = {...data};
      body.type = getServerTypeByUIType(current_node?.type)?.result;
      body = canvasToModel(body)?.result;
      let save_resp = await save(config, body);
      if(save_resp?.status !== "success") { return reject({status: "failed", result: save_resp?.result}); }
      return resolve({status: "success", result: save_resp?.result});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};