"use strict";

let _ = require("lodash");

let save = require("./save");

module.exports = (config, body)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      if(_.isEmpty(body)) { return reject({status: "failed", result: {message: "Body parameters are required but were not provided"}}); }
      body.type = "FORM";
      if(!(body?.state)) {
        body.state = "ACTIVE";
      }
      let save_resp = await save(config, body);
      if(save_resp?.status !== "success") { return reject({status: "failed", result: save_resp?.result}); }
      return resolve({status: "success", result: save_resp?.result});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};