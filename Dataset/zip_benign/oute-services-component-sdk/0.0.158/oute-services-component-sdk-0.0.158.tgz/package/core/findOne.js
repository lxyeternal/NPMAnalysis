"use strict";

let _ = require("lodash");

let utility = require("oute-services-utility-sdk");

module.exports = (config, query)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      if(_.isEmpty(query)) { return reject({status: "failed", result: {message: "Query parameters are required but were not provided"}}); }
      let find_option = {
        method: "GET",
        url: `${config?.url}/service/v0/component/find/one`,
        headers:{
          "Content-Type": "application/json",
          token: config?.token
        },
        query_params: query
      };
      find_option = utility.processReqOptions(config, find_option);
      let find_resp = await utility.executeAPI(find_option);
      if(find_resp?.result?.status !== "success") { return reject({status: "failed", result: find_resp?.result?.result}); }
      return resolve({status: "success", result: find_resp?.result?.result});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};