"use strict";

let _ = require("lodash");
let utility = require("oute-services-utility-sdk");

module.exports = (config, body)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      if(_.isEmpty(body)) { return reject({status: "failed", result: {message: "Body parameters are required but were not provided"}}); }
      if(_.isEmpty(body?.flow)) { return reject({status: "failed", result: {message: "Flow is required but were not provided"}}); }
      if(!(body?.type)) { return reject({status: "failed", result: {message: "Node type is mandatory"}}); }
      let execute_option = {
        method: "POST",
        url: `${config?.url}/service/v0/external/processor/custom/execute/node`,
        headers:{
          "Content-Type": "application/json",
          token: config?.token
        },
        body: JSON.stringify(body)
      };
      execute_option = utility.processReqOptions(config, execute_option);
      let execute_resp = await utility.executeAPI(execute_option);
      if(execute_resp?.result?.status !== "success") { return resolve({status: "success", result: execute_resp?.result?.result}); }
      return resolve({status: "success", result: execute_resp?.result?.result});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};