"use strict";

let executeTransformed = require("./executeTransformed");
let transformAndExecute = require("./transformAndExecute");

module.exports = {
  executeTransformed,
  transformAndExecute
};