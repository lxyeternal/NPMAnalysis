"use strict";

let _ = require("lodash");

let getServerTypeByUIType = require("../../cache/getServerTypeByUIType");
let canvasToModel = require("../canvasToModelTransform");
let executeTransformed = require("./executeTransformed");

module.exports = (config, ui_type, _config_data, state)=> {
  return new Promise(async (resolve, reject)=> {
    try {
      if(!(ui_type)) { return reject({status: "failed", result: {message: "Node type is mandatory"}}); }
      if(_.isEmpty(_config_data)) { return reject({status: "failed", result: {message: "Config data is mandatory"}}); }
      let config_data = {..._config_data};
      let type = getServerTypeByUIType(ui_type)?.result;
      config_data.type = type;
      config_data = canvasToModel(config_data)?.result;
      let task_id = String(config_data?._id || new Date().getTime());
      let flow = {flow: {}};
      flow.flow[task_id] = config_data;
      let execute_payload = {flow, state, type, task_id};
      let execute_resp = await executeTransformed(config, execute_payload);
      if(execute_resp?.status !== "success") { return resolve({status: "success", result: execute_resp?.result}); }
      return resolve({status: "success", result: execute_resp?.result});
    } catch (error) {
      return reject({status: "failed", result: (error?.result?.result || error?.result || error)});
    }
  });
};