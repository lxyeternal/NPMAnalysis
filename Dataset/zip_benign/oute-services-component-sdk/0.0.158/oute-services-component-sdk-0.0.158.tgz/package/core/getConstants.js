"use strict";

let _ = require("lodash");
let constant_instance = require("oute-services-constants-sdk");

let constants = constant_instance.getConstants("canvas")?.result;

module.exports = ()=> {
  try {
    return {status: "success", result: _.cloneDeep(constants)};
  } catch (error) {
    throw {status: "failed", result: (error?.result?.result || error?.result || error)};
  }
};