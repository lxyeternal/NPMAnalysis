(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

let config_data = {
    "url": {
        "type": "fx",
        "blocks": [
            {
                "type": "GLOBAL",
                "subType": "http_mode",
                "background": "#E5EAF1",
                "variableData": {
                    "_id": "1Pn700krI",
                    "name": "http_mode",
                    "data_type": "STRING",
                    "mode": "GLOBAL",
                    "workspace_id": "sx20823A-",
                    "asset_id": "Iyt_uA6Aq",
                    "parent_id": "Iyt_uA6Aq",
                    "implemented_asset_ids": [],
                    "default": "http",
                    "state": "ACTIVE",
                    "created_at": "2023-11-14T05:16:30.825Z",
                    "updated_at": "2023-11-14T05:16:30.827Z",
                    "__v": 0,
                    "implemented_assets": []
                }
            },
            {
                "type": "PRIMITIVES",
                "value": "://"
            },
            {
                "type": "LOCAL",
                "subType": "host",
                "background": "#E5EAF1",
                "variableData": {
                    "_id": "U4DOaqTzY",
                    "name": "host",
                    "data_type": "STRING",
                    "mode": "LOCAL",
                    "workspace_id": "sx20823A-",
                    "asset_id": "OGNXw9DSS",
                    "parent_id": "Iyt_uA6Aq",
                    "implemented_asset_ids": [],
                    "default": "localhost:3027",
                    "state": "ACTIVE",
                    "created_at": "2023-11-14T05:18:09.805Z",
                    "updated_at": "2023-11-14T05:18:09.806Z",
                    "__v": 0,
                    "implemented_assets": []
                }
            },
            {
                "type": "PRIMITIVES",
                "value": "/service/v0/deployment/find/one"
            }
        ]
    },
    "method": "GET",
    "query_params": [
        {
            "key": "project_id",
            "value": {
                "type": "fx",
                "blocks": []
            },
            "type": "STRING",
            "default": "1ZXZKMvvE",
            "required": false,
            "regex": null
        }
    ],
    "headers": [
        {
            "key": "token",
            "value": {
                "type": "fx",
                "blocks": [
                    {
                        "type": "PRIMITIVES",
                        "value": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"
                    }
                ]
            },
            "type": "STRING",
            "default": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc",
            "required": false,
            "regex": null
        }
    ],
    "authorization": {
        "type": "none",
        "data": null
    },
    "body": {
        "type": "none",
        "data": null
    },
    "output": {
        "response": {
            "headers": {
                "content-type": "application/json"
            },
            "body": {
                "name": "oute run"
            },
            "status_code": 200
        },
        "schema": {
            "schema": [
                {
                    "type": "object",
                    "key": "headers",
                    "schema": [
                        {
                            "type": "string",
                            "key": "content-type",
                            "sample_value": "application/json",
                            "path": [
                                "headers",
                                "content-type"
                            ],
                            "pathStr": "{headers}.content-type"
                        }
                    ],
                    "path": [],
                    "pathStr": "headers"
                },
                {
                    "type": "object",
                    "key": "body",
                    "schema": [
                        {
                            "type": "string",
                            "key": "name",
                            "sample_value": "oute run",
                            "path": [
                                "body",
                                "name"
                            ],
                            "pathStr": "{body}.name"
                        }
                    ],
                    "path": [],
                    "pathStr": "body"
                },
                {
                    "type": "number",
                    "key": "status_code",
                    "sample_value": 200,
                    "path": [
                        "status_code"
                    ],
                    "pathStr": "status_code"
                }
            ],
            "path": [],
            "keys": [
                "headers",
                "{headers}.content-type",
                "body",
                "{body}.name",
                "status_code"
            ],
            "flattened_schema": [
                {
                    "type": "object",
                    "key": "headers",
                    "path": [
                        "headers"
                    ],
                    "pathStr": "{headers}"
                },
                {
                    "type": "string",
                    "key": "content-type",
                    "sample_value": "application/json",
                    "path": [
                        "headers",
                        "content-type"
                    ],
                    "pathStr": "{headers}.content-type"
                },
                {
                    "type": "object",
                    "key": "body",
                    "path": [
                        "body"
                    ],
                    "pathStr": "{body}"
                },
                {
                    "type": "string",
                    "key": "name",
                    "sample_value": "oute run",
                    "path": [
                        "body",
                        "name"
                    ],
                    "pathStr": "{body}.name"
                },
                {
                    "type": "number",
                    "key": "status_code",
                    "sample_value": 200,
                    "path": [
                        "status_code"
                    ],
                    "pathStr": "status_code"
                }
            ]
        }
    },
    "path_variable": {
        "data": []
    },
    "max_retry": 0,
    "output_in_sequence": false,
    "parse_response": false,
    "retry_delay": 0,
    "timeout": 0,
    "label": "test1"
};
let ui_type = "HTTP";
let state = {};

try {
  let result = await component_instance.executeNode(ui_type, config_data, state);
  console.log("dsf", JSON.stringify(result));
} catch (e) {
  console.error("asdfg", e);
}
    
})();
