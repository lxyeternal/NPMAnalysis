(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});
let body = {
  "title": "form test",
  "description": "Used to test form",
  "qtip": "Enter input",
  "icon": "https://parts.vw.com/images/uploads/SimplePart%20-%20VW/fullsize/a_20150729_1048209665.png",
  "workspace_id": "test",
  "is_discoverable": false,
  "type": "FORM",
  "sub_type": "free_text",
  "state": "ACTIVE",
  "tags": ["FORM"],
  "inputs": {
    "a": "b"
  },
  "outputs": [],
  "meta": {
    "msg": "anything"
  }
};

try {
  let c = await component_instance.saveForm(body);
  console.log("dsf", c);
} catch (e) {
  console.error("asdfg", e);
}
    
})();
