(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

try {
  let result = component_instance.getConstants();
  console.log("dsf", result);
} catch (e) {
  console.error("asdfg", e);
}
    
})();
