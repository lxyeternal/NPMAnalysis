(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

let canvas_data = "{ \"class\": \"GraphLinksModel\", \"nodeCategoryProperty\": \"template\", \"linkKeyProperty\": \"key\", \"nodeDataArray\": [ {\"key\":\"1692361625690\",\"src\":\"/static/media/input-setup.6bc4e1375793765dd9b1e7463776f5c9.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Input Setup\",\"template\":\"startNode\",\"background\":\"rgb(33, 150, 243)\",\"foreground\":\"#fff\",\"viewSpot\":\"0 0.5\",\"location\":\"-746 0\"}, {\"key\":\"1692361625695\",\"src\":\"/static/media/failure-setup.2e6fe9f6dcb6fb35de5a33083c93486e.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Failure Setup\",\"template\":\"endNode\",\"background\":\"rgb(255, 82, 82)\",\"foreground\":\"#fff\",\"viewSpot\":\"1 0.6667\",\"location\":\"766 133.36\"}, {\"key\":\"16923616256952\",\"src\":\"/static/media/success-setup.b7611cf8ee605348416961dad01f45bc.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Success Setup\",\"template\":\"endNode\",\"background\":\"rgb(76, 175, 80)\",\"foreground\":\"#fff\",\"viewSpot\":\"1 0.3333\",\"location\":\"766 -133.36\"}, {\"key\":\"1692361631573\",\"src\":\"/static/media/http.7e60c9cb780694dcb54bfa896b38083f.svg\",\"text\":\"Method\",\"subText\":\"HTTP\",\"type\":\"HTTP\",\"template\":\"\",\"background\":\"#be63f9\",\"foreground\":\"#fff\",\"module\":\"Flow Controls\",\"location\":\"-416.2578125 -85.8671875\"}, {\"key\":\"1692361641779\",\"src\":\"/static/media/ifelse.60d2e8e0ecf5753156427c8d55b0459c.svg\",\"text\":\"If Else\",\"subText\":\"Condition\",\"type\":\"If Else\",\"template\":\"\",\"background\":\"rgb(33, 150, 243)\",\"foreground\":\"#fff\",\"module\":\"Flow Controls\",\"location\":\"-135.7578125 -85.90234375\"} ], \"linkDataArray\": [ {\"from\":\"1692361625690\",\"to\":\"1692361631573\",\"key\":-1}, {\"from\":\"1692361631573\",\"to\":\"1692361641779\",\"key\":-2}, {\"from\":\"1692361641779\",\"to\":\"16923616256952\",\"key\":-3} ]}";
let ui_type = "If Else";
try {
  let result = component_instance.findOneNodeByType(canvas_data, ui_type);
  console.log("dsf", result);
} catch (e) {
  console.error("asdfg", e);
}
    
})();
