(async () => {
  let _ = require("lodash");
  let chalk = require("cli-color");

  let Component = require("../../index");

  let component_instance = new Component({ url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc" });

  let data = require("./data");

  try {
    for (let index = 0; index < data.data.length; index++) {
      var item = data.data[index];
      var result = component_instance.validateNodeRefs(item.inputs?.canvas_data, item.inputs?.node_id, item.inputs?.variables)?.result;
      var statement = _.isEqual(JSON.stringify(result), JSON.stringify(item.result));
      if(statement === true) {
        console.log("RESULT", item.name, statement);
      } else {
        console.error(chalk.red("testcase failed for index", index, item.name), statement, typeof (result), JSON.stringify(result), chalk.red("SEP"), typeof (item.result), JSON.stringify(item.result));
        break;
      }
    }
  } catch (e) {
    console.error("ERRROR", e);
  }
    
})();
