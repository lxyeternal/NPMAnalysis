(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

let canvas_data = "{ \"class\": \"GraphLinksModel\", \"nodeCategoryProperty\": \"template\", \"linkKeyProperty\": \"key\", \"nodeDataArray\": [ {\"key\":\"1692361625690\",\"src\":\"/static/media/input-setup.6bc4e1375793765dd9b1e7463776f5c9.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Input Setup\",\"template\":\"startNode\",\"background\":\"rgb(33, 150, 243)\",\"foreground\":\"#fff\",\"viewSpot\":\"0 0.5\",\"location\":\"-746 0\"}, {\"key\":\"1692361625695\",\"src\":\"/static/media/failure-setup.2e6fe9f6dcb6fb35de5a33083c93486e.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Failure Setup\",\"template\":\"endNode\",\"background\":\"rgb(255, 82, 82)\",\"foreground\":\"#fff\",\"viewSpot\":\"1 0.6667\",\"location\":\"766 133.36\"}, {\"key\":\"16923616256952\",\"src\":\"/static/media/success-setup.b7611cf8ee605348416961dad01f45bc.svg\",\"text\":\"\",\"subText\":\"\",\"type\":\"Success Setup\",\"template\":\"endNode\",\"background\":\"rgb(76, 175, 80)\",\"foreground\":\"#fff\",\"viewSpot\":\"1 0.3333\",\"location\":\"766 -133.36\"}, {\"key\":\"1692361631573\",\"src\":\"/static/media/http.7e60c9cb780694dcb54bfa896b38083f.svg\",\"text\":\"Method\",\"subText\":\"HTTP\",\"type\":\"HTTP\",\"template\":\"\",\"background\":\"#be63f9\",\"foreground\":\"#fff\",\"module\":\"Flow Controls\",\"location\":\"-416.2578125 -85.8671875\"}, {\"key\":\"1692361641779\",\"src\":\"/static/media/ifelse.60d2e8e0ecf5753156427c8d55b0459c.svg\",\"text\":\"If Else\",\"subText\":\"Condition\",\"type\":\"HTTP\",\"template\":\"\",\"background\":\"rgb(33, 150, 243)\",\"foreground\":\"#fff\",\"module\":\"Flow Controls\",\"location\":\"-135.7578125 -85.90234375\"} ], \"linkDataArray\": [ {\"from\":\"1692361625690\",\"to\":\"1692361631573\",\"key\":-1}, {\"from\":\"1692361631573\",\"to\":\"1692361641779\",\"key\":-2}, {\"from\":\"1692361641779\",\"to\":\"16923616256952\",\"key\":-3} ]}";
let node_id = "1692361641779";
let data = {
  "url": {
      "type": "fx",
      "blocks": [
          {
              "type": "PRIMITIVES",
              "value": ""
          },
          {
              "type": "FUNCTIONS",
              "subType": "average",
              "background": "hsl(56.06880912666216, 100%, 75%)",
              "description": "Returns the average value for a set of numeric values within an array or when numeric values are entered individually.",
              "group": 1698663997815,
              "variableData": null,
              "args": [
                  {
                      "name": "value1, [value2], ...",
                      "required": false,
                      "repeat": true
                  }
              ]
          },
          {
              "type": "OPERATORS",
              "subType": "(",
              "background": "hsl(56.06880912666216, 100%, 75%)",
              "description": "Opening Bracket",
              "group": 1698663997815,
              "variableData": null
          },
          {
              "type": "PRIMITIVES",
              "value": ""
          },
          
          {
              "type": "NODE",
              "subType": "ORDERID",
              "background": "#E5EAF1",
              "variableData": {
                  "nodeId" : "NODE1",
                  "nodeName" : "Node Label name",
                  "type": "string",
                  "key": "orderId",
                  "sample_value": "123",
                  "path": [
                      "orderId"
                  ],
                  "pathStr": "orderId"
              }
          },
          {
              "type": "NODE",
              "subType": "ORDERITEMID",
              "background": "#E5EAF1",
              "variableData": {
                  "nodeId" : "NODE1",
                  "nodeName" : "Node Label name",
                  "type": "string",
                  "key": "orderItemId",
                  "sample_value": "123",
                  "path": [
                      "orderItemId"
                  ],
                  "pathStr": "orderItemId"
              }
          },
          {
              "type": "PRIMITIVES",
              "value": null
          },
          {
              "type": "NODE",
              "subType": "ORDERID",
              "background": "#E5EAF1",
              "variableData": {
                  "nodeId" : "NODE1",
                  "nodeName" : "Node Label name",
                  "type": "string",
                  "key": "orderId",
                  "sample_value": "123",
                  "path": [
                      "orderId"
                  ],
                  "pathStr": "orderId"
              }
          },
          {
              "type": "NODE",
              "subType": "ORDERID",
              "background": "#E5EAF1",
              "variableData": {
                  "nodeId" : "NODE2",
                  "nodeName" : "Node Label name",
                  "type": "string",
                  "key": "orderId",
                  "sample_value": "123",
                  "path": [
                      "orderId"
                  ],
                  "pathStr": "orderId"
              }
          },
          {
              "type": "OPERATORS",
              "subType": ")",
              "background": "hsl(56.06880912666216, 100%, 75%)",
              "description": "Closing Bracket",
              "group": 1698663997815,
              "variableData": null
          },
          {
              "type": "PRIMITIVES",
              "value": ""
          },
          {
              "type": "FUNCTIONS",
              "subType": "sum",
              "background": "hsl(90.8743127857045, 100%, 75%)",
              "description": "Returns the sum of the values for a set of numeric values within an array or when numeric values are entered individually.",
              "group": 1698664356974,
              "variableData": null,
              "args": [
                  {
                      "name": "value1, [value2], ...",
                      "required": false,
                      "repeat": true
                  }
              ]
          },
          {
              "type": "OPERATORS",
              "subType": "(",
              "background": "hsl(90.8743127857045, 100%, 75%)",
              "description": "Opening Bracket",
              "group": 1698664356974,
              "variableData": null
          },
          {
              "type": "PRIMITIVES",
              "value": ""
          },
          {
              "type": "LOCAL",
              "subType": "Gender",
              "background": "#E5EAF1",
              "variableData": {
                  "_id": "3purGPi7c",
                  "name": "Gender",
                  "data_type": "STRING",
                  "mode": "LOCAL",
                  "workspace_id": "PhgvxiJ7o",
                  "asset_id": "UPZyE1Ecc",
                  "parent_id": "PO0EnTDVE",
                  "implemented_asset_ids": [],
                  "default": "Male",
                  "state": "ACTIVE",
                  "created_at": "2023-10-30T08:21:38.613Z",
                  "updated_at": "2023-10-30T08:21:38.614Z",
                  "__v": 0,
                  "implemented_assets": []
              }
          },
          {
              "type": "PRIMITIVES",
              "value": null
          },
          {
              "type": "OPERATORS",
              "subType": ")",
              "background": "hsl(90.8743127857045, 100%, 75%)",
              "description": "Closing Bracket",
              "group": 1698664356974,
              "variableData": null
          },
          {
              "type": "PRIMITIVES",
              "value": null
          }
      ]
  },
  "method": "GET",
  "query_params": [
      {
          "key": "Name",
          "value": {
              "type": "fx",
              "blocks": [
                  {
                      "type": "PRIMITIVES",
                      "value": null
                  },
                  {
                      "type": "FUNCTIONS",
                      "subType": "average",
                      "background": "hsl(258.0541321838761, 100%, 75%)",
                      "description": "Returns the average value for a set of numeric values within an array or when numeric values are entered individually.",
                      "group": 1698323699727,
                      "args": [
                          {
                              "name": "value1, [value2], ...",
                              "required": false,
                              "repeat": true
                          }
                      ]
                  },
                  {
                      "type": "OPERATORS",
                      "subType": "(",
                      "background": "hsl(258.0541321838761, 100%, 75%)",
                      "description": "Opening Bracket",
                      "group": 1698323699727
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": ""
                  },
                  {
                      "type": "FUNCTIONS",
                      "subType": "sum",
                      "background": "hsl(359.3889604854925, 100%, 75%)",
                      "description": "Returns the sum of the values for a set of numeric values within an array or when numeric values are entered individually.",
                      "group": 1698323700514,
                      "args": [
                          {
                              "name": "value1, [value2], ...",
                              "required": false,
                              "repeat": true
                          }
                      ]
                  },
                  {
                      "type": "OPERATORS",
                      "subType": "(",
                      "background": "hsl(359.3889604854925, 100%, 75%)",
                      "description": "Opening Bracket",
                      "group": 1698323700514
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": "dwdaad"
                  },
                  {
                      "type": "OPERATORS",
                      "subType": ")",
                      "background": "hsl(359.3889604854925, 100%, 75%)",
                      "description": "Closing Bracket",
                      "group": 1698323700514
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": null
                  },
                  {
                      "type": "OPERATORS",
                      "subType": ")",
                      "background": "hsl(258.0541321838761, 100%, 75%)",
                      "description": "Closing Bracket",
                      "group": 1698323699727
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": null
                  }
              ]
          },
          "type": "STRING",
          "default": "pratik",
          "required": false,
          "regex": null
      }
  ],
  "headers": [
      {
          "key": "Name",
          "value": {
              "type": "fx",
              "blocks": [
                  {
                      "type": "PRIMITIVES",
                      "value": null
                  },
                  {
                      "type": "FUNCTIONS",
                      "subType": "average",
                      "background": "hsl(258.0541321838761, 100%, 75%)",
                      "description": "Returns the average value for a set of numeric values within an array or when numeric values are entered individually.",
                      "group": 1698323699727,
                      "args": [
                          {
                              "name": "value1, [value2], ...",
                              "required": false,
                              "repeat": true
                          }
                      ]
                  },
                  {
                      "type": "OPERATORS",
                      "subType": "(",
                      "background": "hsl(258.0541321838761, 100%, 75%)",
                      "description": "Opening Bracket",
                      "group": 1698323699727
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": ""
                  },
                  {
                      "type": "FUNCTIONS",
                      "subType": "sum",
                      "background": "hsl(359.3889604854925, 100%, 75%)",
                      "description": "Returns the sum of the values for a set of numeric values within an array or when numeric values are entered individually.",
                      "group": 1698323700514,
                      "args": [
                          {
                              "name": "value1, [value2], ...",
                              "required": false,
                              "repeat": true
                          }
                      ]
                  },
                  {
                      "type": "OPERATORS",
                      "subType": "(",
                      "background": "hsl(359.3889604854925, 100%, 75%)",
                      "description": "Opening Bracket",
                      "group": 1698323700514
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": "dwdaad"
                  },
                  {
                      "type": "OPERATORS",
                      "subType": ")",
                      "background": "hsl(359.3889604854925, 100%, 75%)",
                      "description": "Closing Bracket",
                      "group": 1698323700514
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": null
                  },
                  {
                      "type": "OPERATORS",
                      "subType": ")",
                      "background": "hsl(258.0541321838761, 100%, 75%)",
                      "description": "Closing Bracket",
                      "group": 1698323699727
                  },
                  {
                      "type": "PRIMITIVES",
                      "value": null
                  }
              ]
          },
          "type": "STRING",
          "default": "pratik",
          "required": false,
          "regex": null
      }
  ],
  "authorization": {
      "type": "basic",
      "data": [
          {
              "key": "username",
              "value": {
                  "type": "fx",
                  "blocks": [
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      },
                      {
                          "type": "FUNCTIONS",
                          "subType": "average",
                          "background": "hsl(51.1057987523829, 100%, 75%)",
                          "description": "Returns the average value for a set of numeric values within an array or when numeric values are entered individually.",
                          "group": 1698323760045,
                          "args": [
                              {
                                  "name": "value1, [value2], ...",
                                  "required": false,
                                  "repeat": true
                              }
                          ]
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "(",
                          "background": "hsl(51.1057987523829, 100%, 75%)",
                          "description": "Opening Bracket",
                          "group": 1698323760045
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": ""
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "%",
                          "background": "#71AC34",
                          "description": "Modulo"
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "%",
                          "background": "#71AC34",
                          "description": "Modulo"
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "%",
                          "background": "#71AC34",
                          "description": "Modulo"
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": "dadw"
                      },
                      {
                          "type": "OPERATORS",
                          "subType": ")",
                          "background": "hsl(51.1057987523829, 100%, 75%)",
                          "description": "Closing Bracket",
                          "group": 1698323760045
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": "`"
                      }
                  ]
              },
              "type": "STRING",
              "default": "",
              "required": false,
              "regex": null
          },
          {
              "key": "password",
              "value": {
                  "type": "fx",
                  "blocks": [
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      },
                      {
                          "type": "FUNCTIONS",
                          "subType": "average",
                          "background": "hsl(307.46445202239005, 100%, 75%)",
                          "description": "Returns the average value for a set of numeric values within an array or when numeric values are entered individually.",
                          "group": 1698323775915,
                          "args": [
                              {
                                  "name": "value1, [value2], ...",
                                  "required": false,
                                  "repeat": true
                              }
                          ]
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "(",
                          "background": "hsl(307.46445202239005, 100%, 75%)",
                          "description": "Opening Bracket",
                          "group": 1698323775915
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": ""
                      },
                      {
                          "type": "FUNCTIONS",
                          "subType": "sum",
                          "background": "hsl(92.78643949516724, 100%, 75%)",
                          "description": "Returns the sum of the values for a set of numeric values within an array or when numeric values are entered individually.",
                          "group": 1698323777150,
                          "args": [
                              {
                                  "name": "value1, [value2], ...",
                                  "required": false,
                                  "repeat": true
                              }
                          ]
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "(",
                          "background": "hsl(92.78643949516724, 100%, 75%)",
                          "description": "Opening Bracket",
                          "group": 1698323777150
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": ""
                      },
                      {
                          "type": "FUNCTIONS",
                          "subType": "sum",
                          "background": "hsl(305.55292760598894, 100%, 75%)",
                          "description": "Returns the sum of the values for a set of numeric values within an array or when numeric values are entered individually.",
                          "group": 1698323777330,
                          "args": [
                              {
                                  "name": "value1, [value2], ...",
                                  "required": false,
                                  "repeat": true
                              }
                          ]
                      },
                      {
                          "type": "OPERATORS",
                          "subType": "(",
                          "background": "hsl(305.55292760598894, 100%, 75%)",
                          "description": "Opening Bracket",
                          "group": 1698323777330
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": "dda"
                      },
                      {
                          "type": "OPERATORS",
                          "subType": ")",
                          "background": "hsl(305.55292760598894, 100%, 75%)",
                          "description": "Closing Bracket",
                          "group": 1698323777330
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      },
                      {
                          "type": "OPERATORS",
                          "subType": ")",
                          "background": "hsl(92.78643949516724, 100%, 75%)",
                          "description": "Closing Bracket",
                          "group": 1698323777150
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      },
                      {
                          "type": "OPERATORS",
                          "subType": ")",
                          "background": "hsl(307.46445202239005, 100%, 75%)",
                          "description": "Closing Bracket",
                          "group": 1698323775915
                      },
                      {
                          "type": "PRIMITIVES",
                          "value": null
                      }
                  ]
              },
              "type": "STRING",
              "default": "",
              "required": false,
              "regex": null
          }
      ]
  },
  "body": {
    "type": "raw",
    "data": "<div>Hello World</div>",
    "sub_type": "html"
  },
  "output": {
    "response": {
        "orderId": "123",
        "items": {
            "itemList": [
                {
                    "medicineId": 12,
                    "name": "xyz"
                },
                {
                    "medicineId": 11,
                    "expiryInDays": 200
                }
            ],
            "total": 2
        }
    },
    "schema": {
      "schema": [
          {
              "type": "string",
              "key": "orderId",
              "sample_value": "123",
              "path": [
                  "orderId"
              ],
              "pathStr": "orderId"
          },
          {
              "type": "object",
              "key": "items",
              "schema": [
                  {
                      "type": "array",
                      "key": "itemList",
                      "schema": [
                          {
                              "type": "number",
                              "key": "medicineId",
                              "sample_value": 12,
                              "path": [
                                  "items",
                                  "itemList",
                                  "medicineId"
                              ],
                              "pathStr": "{items}.[itemList].medicineId"
                          },
                          {
                              "type": "string",
                              "key": "name",
                              "sample_value": "xyz",
                              "path": [
                                  "items",
                                  "itemList",
                                  "name"
                              ],
                              "pathStr": "{items}.[itemList].name"
                          },
                          {
                              "type": "number",
                              "key": "expiryInDays",
                              "sample_value": 200,
                              "path": [
                                  "items",
                                  "itemList",
                                  "expiryInDays"
                              ],
                              "pathStr": "{items}.[itemList].expiryInDays"
                          }
                      ],
                      "path": [
                          "items"
                      ],
                      "pathStr": "{items}.itemList"
                  },
                  {
                      "type": "number",
                      "key": "total",
                      "sample_value": 2,
                      "path": [
                          "items",
                          "total"
                      ],
                      "pathStr": "{items}.total"
                  }
              ],
              "path": [],
              "pathStr": "items"
          }
      ],
      "path": [],
      "keys": [
          "orderId",
          "items",
          "{items}.itemList",
          "{items}.[itemList].medicineId",
          "{items}.[itemList].name",
          "{items}.[itemList].expiryInDays",
          "{items}.total"
      ],
      "flattened_schema": [
          {
              "type": "string",
              "key": "orderId",
              "sample_value": "123",
              "path": [
                  "orderId"
              ],
              "pathStr": "orderId"
          },
          {
              "type": "object",
              "key": "items",
              "path": [
                  "items"
              ],
              "pathStr": "{items}"
          },
          {
              "type": "array",
              "key": "itemList",
              "path": [
                  "items",
                  "itemList"
              ],
              "pathStr": "{items}.itemList"
          },
          {
              "type": "number",
              "key": "medicineId",
              "sample_value": 12,
              "path": [
                  "items",
                  "itemList",
                  "medicineId"
              ],
              "pathStr": "{items}.[itemList].medicineId"
          },
          {
              "type": "string",
              "key": "name",
              "sample_value": "xyz",
              "path": [
                  "items",
                  "itemList",
                  "name"
              ],
              "pathStr": "{items}.[itemList].name"
          },
          {
              "type": "number",
              "key": "expiryInDays",
              "sample_value": 200,
              "path": [
                  "items",
                  "itemList",
                  "expiryInDays"
              ],
              "pathStr": "{items}.[itemList].expiryInDays"
          },
          {
              "type": "number",
              "key": "total",
              "sample_value": 2,
              "path": [
                  "items",
                  "total"
              ],
              "pathStr": "{items}.total"
          }
      ]
    }
  },
  "path_variable": {
    "data": []
  },
  "max_retry": "123",
  "output_in_sequence": true,
  "parse_response": true,
  "retry_delay": "123",
  "timeout": "123",
  "label": "Http Node"
};

try {
  let result = component_instance.transformNode(canvas_data, node_id, data);
  console.log("dsf", JSON.stringify(result));
} catch (e) {
  console.error("asdfg", e);
}
    
})();
