(async () => {
let _ = require("lodash");
let chalk = require("cli-color");

let data = require("./data");
let Component = require("../../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

try {
  for (let index = 0; index < data.data.length; index++) {
    var item = data.data[index];
    if(item?.will_do_later === true) {
      continue;
    }
    var result = component_instance.formSchemaToState(item.inputs)?.result;
    var statement = _.isEqual(result, item.result);
    if(statement === true) {
      console.log("RESULT", item.name, statement);
    } else {
      console.error(chalk.red("testcase failed for index", index, item.name), statement, typeof(result), JSON.stringify(result), chalk.red("SEP"), typeof(item.result), JSON.stringify(item.result));
      break
    }
  }
} catch (e) {
  console.error("ERRROR", e);
}
    

    
})();
