(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

try {
  let override_value = true;
  let path_list = ["body"];
  let schema = [ { "id": "1712299838694", "key": "a", "type": "array", "valueStr": "asd", "default": { "type": "fx", "blocks": [ { "type": "PRIMITIVES", "value": "[]" } ] }, "config": [ { "id": "1712300057836", "config": [ { "id": "1712300068201", "key": "c", "type": "string", "value": { "type": "fx", "blocks": [ { "type": "PRIMITIVES", "value": "sdf" } ] }, "valueStr": "sdf" }, { "id": "1712300073136" } ], "type": "object", "default": { "type": "fx", "blocks": [ { "type": "PRIMITIVES", "value": "{}" } ] }, "key": "b" }, { "id": "1712300068201" } ] } ];
  let result = component_instance.formatSchema(schema, path_list, override_value);
  console.log("RESULT", JSON.stringify(result));
} catch (e) {
  console.error("ERROR", e);
}
})();
