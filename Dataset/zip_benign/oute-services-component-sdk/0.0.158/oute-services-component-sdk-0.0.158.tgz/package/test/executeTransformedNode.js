(async () => {
let Component = require("../index");

let component_instance = new Component({url: "http://localhost:3027", token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"});

let body = {
    "flow": {
        "1700830491326": {
            "inputs": [
                {
                    "key": "project_id",
                    "value": {
                        "type": "fx",
                        "blocks": []
                    },
                    "type": "STRING",
                    "required": false,
                    "regex": null,
                    "location": "query_params"
                },
                {
                    "key": "token",
                    "value": {
                        "type": "fx",
                        "blocks": [
                            {
                                "type": "PRIMITIVES",
                                "value": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoidGVzdEBnb2ZvLmFwcCIsIm9yZ0lkcyI6WyJaekJmSk1wZlEiXSwiaWF0IjoxNjgyMjQ4MjcwLCJleHAiOjMzMjA4MjkwNjcwfQ.OADEKdh1IaABuKCEwFgskapkNVrg_IIjzj1cd0HoGdc"
                            }
                        ]
                    },
                    "type": "STRING",
                    "required": false,
                    "regex": null,
                    "location": "headers"
                }
            ],
            "outputs": [
                {
                    "key": "headers",
                    "type": "JSON"
                },
                {
                    "key": "content-type",
                    "type": "STRING"
                },
                {
                    "key": "body",
                    "type": "JSON"
                },
                {
                    "key": "name",
                    "type": "STRING"
                },
                {
                    "key": "status_code",
                    "type": "NUMBER"
                }
            ],
            "config": {
                "url": {
                    "type": "fx",
                    "blocks": [
                        {
                            "type": "GLOBAL",
                            "subType": "http_mode",
                            "background": "#E5EAF1",
                            "variableData": {
                                "_id": "1Pn700krI",
                                "name": "http_mode",
                                "data_type": "STRING",
                                "mode": "GLOBAL",
                                "workspace_id": "sx20823A-",
                                "asset_id": "Iyt_uA6Aq",
                                "parent_id": "Iyt_uA6Aq",
                                "implemented_asset_ids": [],
                                "default": "http",
                                "state": "ACTIVE",
                                "created_at": "2023-11-14T05:16:30.825Z",
                                "updated_at": "2023-11-14T05:16:30.827Z",
                                "__v": 0,
                                "implemented_assets": []
                            }
                        },
                        {
                            "type": "PRIMITIVES",
                            "value": "://"
                        },
                        {
                            "type": "LOCAL",
                            "subType": "host",
                            "background": "#E5EAF1",
                            "variableData": {
                                "_id": "U4DOaqTzY",
                                "name": "host",
                                "data_type": "STRING",
                                "mode": "LOCAL",
                                "workspace_id": "sx20823A-",
                                "asset_id": "OGNXw9DSS",
                                "parent_id": "Iyt_uA6Aq",
                                "implemented_asset_ids": [],
                                "default": "localhost:3027",
                                "state": "ACTIVE",
                                "created_at": "2023-11-14T05:18:09.805Z",
                                "updated_at": "2023-11-14T05:18:09.806Z",
                                "__v": 0,
                                "implemented_assets": []
                            }
                        },
                        {
                            "type": "PRIMITIVES",
                            "value": "/service/v0/deployment/find/one"
                        }
                    ]
                },
                "method": "GET",
                "max_retry": 0,
                "retry_delay": 0,
                "timeout": 0,
                "parse_response": false,
                "output_in_sequence": false
            },
            "type": "HTTP"
        }
    },
    "state": {
        "Iyt_uA6Aq": {
            "http_mode": "http"
        },
        "OGNXw9DSS": {
            "host": "localhost:3027"
        }
    },
    "task_id": "1700830491326",
    "type": "HTTP"
};

try {
  let result = await component_instance.executeTransformedNode(body);
  console.log("dsf", JSON.stringify(result));
} catch (e) {
  console.error("asdfg", e);
}
    
})();
