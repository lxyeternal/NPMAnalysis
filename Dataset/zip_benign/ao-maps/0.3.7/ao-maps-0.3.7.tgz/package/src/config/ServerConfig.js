
export const ServerConfig = {
  baseURL: 'https://api.tennis-australia.onimapengine.com/api', // AUstralia Tennis Base URL 
  apiKey: 'AIzaSyD4kuAguA3ynXDJKYPJnUsXh9WST0Vc-Ww' // Australia Tennis API Key
};
