export const categoryItems = {
  name: 'What are you looking for?',
  options: [
    {
      id: 1,
      name: 'Favourite',
      backgroundColor: '#F2F2F2',
      image: 'star',
      textColor: '#153A5A',
      imageColor: '#153A5A'
    },
    {
      id: 2,
      name: 'Courts',
      backgroundColor: '#3F90CD',
      textColor: '#FFFFFF',
    },
    {
      id: 3,
      name: 'Food',
      backgroundColor: '#ED706A',
      textColor: '#FFFFFF',
    }, {
      id: 4,
      name: 'Kids',
      backgroundColor: '#D7D646',
      textColor: '#153A5A',
    }
  ]
};

export const locations = {
  favourite: [
    {
      id: 1,
      type: 'court',
      lat: 37.78825,
      lng: -122.4324,
      name: 'Court Location 1',
      description: 'this is the description'
    },
    {
      id: 2,
      type: 'food',
      name: 'Food location 1',
      description: 'this is the description',
      lat: 37.79403,
      lng: -122.4413677,
    },
  ],
  courts: [
    {
      id: 1,
      lat: 37.791521,
      lng: -122.437362,
      name: 'Court location 1'
    },
    {
      id: 2,
      lat: 37.792062,
      lng: -122.427031,
      name: 'Court location 2'
    },
  ]
};

export const defaultMarkerLocation = [
  {
    id: 1,
    lat: -37.82476494814675,
    lng: 144.98281486294005,
    name: 'Court location 1'
  }
];

export const filterData = [
  {
    title: 'Section Title 1',
    data: ['Filter Label 1 1', 'Filter Label 1 2', 'Filter Label 1 3'],
  },
  {
    title: 'Section Title 2',
    data: ['Filter Label 2 1', 'Filter Label 2 2', 'Filter Label 2 3'],
  },
  {
    title: 'Section Title 3',
    data: ['Filter Label 3 1', 'Filter Label 3 2', 'Filter Label 3 3'],
  },
  {
    title: 'Section Title 4',
    data: ['Filter Label 4 1', 'Filter Label 4 2', 'Filter Label 4 3'],
  },
  {
    title: 'Section Title 5',
    data: ['Filter Label 5 1', 'Filter Label 5 2', 'Filter Label 5 3'],
  },
];

export const routes = [
  {
    summary: '',
    legs: [
      {
        steps: [


          {
            html_instructions: 'arrive at destination',
            distance: {
              value: 0,
              text: '0 m'
            },
            maneuver: '',
            duration: {
              value: 0,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82533826993155,
              lng: 144.97497136609113
            },
            end_location: {
              lat: -37.82533826993155,
              lng: 144.97497136609113
            },
            polyline: {
              points: 'jwzeFqlzsZ??'
            },
            travel_mode: 'WALKING'
          }
        ],
        distance: {
          value: 1124,
          text: '1.1 km'
        },
        duration: {
          value: 809,
          text: '13 mins'
        },
        start_location: {
          lat: -37.824981,
          lng: 144.983613
        },
        end_location: {
          lat: -37.825568,
          lng: 144.975302
        },
        start_address: '',
        end_address: ''
      }
    ],
    waypoint_order: [],
    overview_polyline: {
      points: 'vszeFq}{sZ?FQG[O{A]mAAy@`@?d@MDjAn@@Yl@HuAfTKtBA^EJE^SxGBVHJI`@\d@TSz@j@d@`@p@PX?VE`@QJKZN^b@JXJpADPTV'
    },
    bounds: {
      northeast: {
        lat: -37.82328395895549,
        lng: 144.98304899744053
      },
      southwest: {
        lat: -37.82533826993155,
        lng: 144.97497136609113
      }
    },
    copyrights: 'OniGroup'
  },
  {
    summary: '',
    legs: [
      {
        steps: [
          {
            html_instructions: 'continue',
            distance: {
              value: 4,
              text: '4 m'
            },
            maneuver: '',
            duration: {
              value: 2,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82476494814675,
              lng: 144.98281486294005
            },
            end_location: {
              lat: -37.82476196791445,
              lng: 144.98277183583613
            },
            polyline: {
              points: 'vszeFq}{sZ?F'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn right',
            distance: {
              value: 10,
              text: '10 m'
            },
            maneuver: 'turn-right',
            duration: {
              value: 7,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82476196791445,
              lng: 144.98277183583613
            },
            end_location: {
              lat: -37.82467386479692,
              lng: 144.98280592224313
            },
            polyline: {
              points: 'vszeFi}{sZQG'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'keep right',
            distance: {
              value: 18,
              text: '18 m'
            },
            maneuver: '',
            duration: {
              value: 12,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82467386479692,
              lng: 144.98280592224313
            },
            end_location: {
              lat: -37.82452988232367,
              lng: 144.98288787863152
            },
            polyline: {
              points: 'dszeFq}{sZ[O'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'keep right',
            distance: {
              value: 96,
              text: '96 m'
            },
            maneuver: '',
            duration: {
              value: 69,
              text: '1 mins'
            },
            start_location: {
              lat: -37.82452988232367,
              lng: 144.98288787863152
            },
            end_location: {
              lat: -37.82368386887797,
              lng: 144.98304899744053
            },
            polyline: {
              points: 'hrzeFa~{sZ{A]mAA'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn slight left',
            distance: {
              value: 60,
              text: '60 m'
            },
            maneuver: 'turn-slight-left',
            duration: {
              value: 43,
              text: '1 mins'
            },
            start_location: {
              lat: -37.82368386887797,
              lng: 144.98304899744053
            },
            end_location: {
              lat: -37.82332493714969,
              lng: 144.98266193976988
            },
            polyline: {
              points: '~lzeFa_|sZy@`@?d@MD'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn sharp left',
            distance: {
              value: 47,
              text: '47 m'
            },
            maneuver: 'turn-sharp-left',
            duration: {
              value: 33,
              text: '1 mins'
            },
            start_location: {
              lat: -37.82332493714969,
              lng: 144.98266193976988
            },
            end_location: {
              lat: -37.82369895630402,
              lng: 144.98241793324988
            },
            polyline: {
              points: 'vjzeFs|{sZjAn@'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn left',
            distance: {
              value: 12,
              text: '12 m'
            },
            maneuver: 'turn-left',
            duration: {
              value: 8,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82369895630402,
              lng: 144.98241793324988
            },
            end_location: {
              lat: -37.82371385746555,
              lng: 144.9825488772068
            },
            polyline: {
              points: 'bmzeFc{{sZ@Y'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn right',
            distance: {
              value: 25,
              text: '25 m'
            },
            maneuver: 'turn-right',
            duration: {
              value: 18,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82371385746555,
              lng: 144.9825488772068
            },
            end_location: {
              lat: -37.82393886500461,
              lng: 144.98250082096087
            },
            polyline: {
              points: 'dmzeF}{{sZl@H'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn right',
            distance: {
              value: 355,
              text: '355 m'
            },
            maneuver: 'turn-right',
            duration: {
              value: 255,
              text: '4 mins'
            },
            start_location: {
              lat: -37.82393886500461,
              lng: 144.98250082096087
            },
            end_location: {
              lat: -37.823445822822585,
              lng: 144.97850786846521
            },
            polyline: {
              points: 'rnzeFs{{sZuAfTKtB'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'keep left',
            distance: {
              value: 13,
              text: '13 m'
            },
            maneuver: '',
            duration: {
              value: 9,
              text: '0 mins'
            },
            start_location: {
              lat: -37.823445822822585,
              lng: 144.97850786846521
            },
            end_location: {
              lat: -37.82344097994508,
              lng: 144.97835494529505
            },
            polyline: {
              points: 'pkzeFub{sZA^'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn slight right',
            distance: {
              value: 7,
              text: '7 m'
            },
            maneuver: 'turn-slight-right',
            duration: {
              value: 4,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82344097994508,
              lng: 144.97835494529505
            },
            end_location: {
              lat: -37.823409873770395,
              lng: 144.9782899389779
            },
            polyline: {
              points: 'nkzeFua{sZEJ'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'keep left',
            distance: {
              value: 157,
              text: '157 m'
            },
            maneuver: '',
            duration: {
              value: 112,
              text: '2 mins'
            },
            start_location: {
              lat: -37.823409873770395,
              lng: 144.9782899389779
            },
            end_location: {
              lat: -37.82334989659525,
              lng: 144.97654482669856
            },
            polyline: {
              points: 'hkzeFia{sZE^SxGBVHJ'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn right',
            distance: {
              value: 16,
              text: '16 m'
            },
            maneuver: 'turn-right',
            duration: {
              value: 11,
              text: '0 mins'
            },
            start_location: {
              lat: -37.82334989659525,
              lng: 144.97654482669856
            },
            end_location: {
              lat: -37.823297928794425,
              lng: 144.97637085563773
            },
            polyline: {
              points: '|jzeFkvzsZI`@'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn left',
            distance: {
              value: 24,
              text: '24 m'
            },
            maneuver: 'turn-left',
            duration: {
              value: 17,
              text: '0 mins'
            },
            start_location: {
              lat: -37.823297928794425,
              lng: 144.97637085563773
            },
            end_location: {
              lat: -37.823453832196904,
              lng: 144.97617583668625
            },
            polyline: {
              points: 'rjzeFiuzsZ\d@'
            },
            travel_mode: 'WALKING'
          },
          {
            html_instructions: 'turn left',
            distance: {
              value: 15,
              text: '15 m'
            },
            maneuver: 'turn-left',
            duration: {
              value: 10,
              text: '0 mins'
            },
            start_location: {
              lat: -37.823453832196904,
              lng: 144.97617583668625
            },
            end_location: {
              lat: -37.82355683647596,
              lng: 144.97628387010732
            },
            polyline: {
              points: 'pkzeFctzsZTS'
            },
            travel_mode: 'WALKING'
          },
        ],
        distance: {
          value: 1124,
          text: '1.1 km'
        },
        duration: {
          value: 809,
          text: '13 mins'
        },
        start_location: {
          lat: -37.824981,
          lng: 144.983613
        },
        end_location: {
          lat: -37.825568,
          lng: 144.975302
        },
        start_address: '',
        end_address: ''
      }
    ],
    waypoint_order: [],
    overview_polyline: {
      points: 'vszeFq}{sZ?FQG[O{A]mAAy@`@?d@MDjAn@@Yl@HuAfTKtBA^EJE^SxGBVHJI`@\d@TSz@j@d@`@p@PX?VE`@QJKZN^b@JXJpADPTV'
    },
    bounds: {
      northeast: {
        lat: -37.82328395895549,
        lng: 144.98304899744053
      },
      southwest: {
        lat: -37.82533826993155,
        lng: 144.97497136609113
      }
    },
    copyrights: 'OniGroup'
  }
];
