import { icon_types, icons } from '../constants/images';

// Generate style from here https://mapstyle.withgoogle.com/


export const googleConfig = {
  map: {
    showUserLocation: true,
    showsCompass: true,
    showsMyLocationButton: false,
    loadingEnabled: true,
    rotateEnabled: true,
    scrollEnabled: true,
    pitchEnabled: true,
    zoomEnabled: true,
    zoomControlEnabled: false,
    followsUserLocation: true,
    minZoomLevel: 14,
    maxZoomLevel: 24,
    toolbarEnabled: false,
  },
  distanceFilter: 0,
  refreshTime: 10000, // 10 seconds
  initialRegion: {
    latitude: -37.824981,
    longitude: 144.983613,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  },
  mapStyle: [],
  marker: {
    selected: '#D85040',
    unSelected: '#4C7BC1'
  },
  polyLine: {
    strokeWidth: 4,
    strokeColor: '#729DEF'
  },
  dashLine: {
    strokeWidth: 4,
    strokeColor: '#9896a4',
    lineDashPattern: [5, 5, 5, 5],
  },
  androidEdgePadding: {
    top: 250,
    bottom: 250,
    right: 150,
    left: 150
  },
  iosEdgePadding: {
    top: 150,
    bottom: 150,
    right: 80,
    left: 80
  },
  mapOutline: {
    strokeWidth: 1,
    strokeColor: '#D0684D'
  },
  icon: {
    filter: {
      name: icons.filter,
      type: icon_types.font_awesome,
      color: '#AFB5BC',
      size: 24,
    },
    currentLocation: {
      name: icons.crosshairs,
      type: icon_types.font_awesome,
      color: '#AFB5BC',
      size: 24,
    }
  }
};
