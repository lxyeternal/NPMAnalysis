import { request_methods } from '../constants/general';
import { general_message } from '../constants/message';
import NetInfo from '@react-native-community/netinfo';

export const isConnectedToNetwork = () => {
  return new Promise((resolve, reject) => {
    NetInfo.isConnected.fetch()
      .then(isConnected => {
        resolve(isConnected);
      })
      .catch(error => reject(error));
  });
};

export const requestToServer = (info, axiosInstance) => {
  switch (info.method) {
    case request_methods.post:
      return axiosInstance.post(info.url, info.params);
    case request_methods.get:
      return axiosInstance.get(info.url, { params: info.params });
    // return axiosInstance.get(info.url);
    default:
      return Promise.reject(Error(general_message.method_not_found));
  }
};
