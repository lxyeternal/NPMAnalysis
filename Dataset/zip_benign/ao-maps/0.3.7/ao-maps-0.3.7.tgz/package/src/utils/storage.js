import { AsyncStorage } from 'react-native';

export const storeData = async (key, value) => {
  await AsyncStorage.setItem(key, value);
};

export const retrieveData = async (key) => {
  const value = await AsyncStorage.getItem(key);

  return value;
};

export const removeData = async keys => {
  await AsyncStorage.multiRemove(keys);
};
