import { Platform } from 'react-native';
import { OS } from '../constants/general';
import { Linking, Dimensions } from 'react-native';

export const isAndroid = Platform.OS === OS.androd;
export const isIOS = Platform.OS === OS.iOS;
export const screenWidth = Math.round(Dimensions.get('window').width);
export const screenHeight = Math.round(Dimensions.get('window').height);

// transforms something like this geocFltrhVvDsEtA}ApSsVrDaEvAcBSYOS_@... to an array of coordinates
export const decodePolylinePoints = (t, e) => {
  for (var n, o, u = 0, l = 0, r = 0, d = [], h = 0, i = 0, a = null, c = Math.pow(10, e || 5); u < t.length;) {
    a = null, h = 0, i = 0;

    do {
      a = t.charCodeAt(u++) - 63, i |= (31 & a) << h, h += 5;
    }
    while (a >= 32); n = 1 & i ? ~(i >> 1) : i >> 1, h = i = 0;
    do {
      a = t.charCodeAt(u++) - 63, i |= (31 & a) << h, h += 5;
    }
    while (a >= 32); o = 1 & i ? ~(i >> 1) : i >> 1, l += n, r += o, d.push([l / c, r / c]);
  }

  return d = d.map((t) => {
    return { latitude: t[0], longitude: t[1] };
  });
};

// get the routing list and return in appropriate format to draw polylines
export const getRoutingCoordinates = (points) => {
  return points.map(item => {
    return { latitude: item.lat, longitude: item.lng };
  });
};

export const getVenuOpeningInfo = (openingHours) => {
  // Format 08:30-22:30 
  const hours = openingHours.split('-');
  const startHappyHours = hours[0] || '';
  const endHappyHours = hours[1] || '';

  // make an array of hour and minute from start time
  const startHappyTimes = startHappyHours.split(':');
  const openingHour = startHappyTimes[0];
  const openingMinute = startHappyTimes[1];

  // make an array of hour and minute from end time
  const endHappyTimes = endHappyHours.split(':');
  const closingHour = endHappyTimes[0];
  const closingMinute = endHappyTimes[1];

  const currentDate = new Date();
  const openingDate = new Date();
  const closingDate = new Date();

  openingDate.setHours(openingHour, openingMinute, 0);
  closingDate.setHours(closingHour, closingMinute, 0);

  if (currentDate >= openingDate && currentDate < closingDate) {
    return { isOpen: true, time: endHappyHours };
  } else {
    return { isOpen: false, time: startHappyHours };
  }
};

// make a telephone call
export const makeACall = (contactNumber) => {
  Linking.openURL(`tel:${contactNumber}`).catch((err) => console.error('Unable to make a call', err));
};

// open the web url 
export const openWebsite = (url) => {
  Linking.openURL(url).catch((err) => console.error('Unable to open website', err));
};

// return the text with first letter capatilized
export const captalizeString = (text) => {
  return text.charAt(0).toUpperCase() + text.slice(1);
};

// return if iOS device is iPhone X or above
export function isIphoneXorAbove() {
  return (
    Platform.OS === 'ios' &&
    !Platform.isPad &&
    !Platform.isTVOS &&
    ((screenHeight === 812 || screenWidth === 812) || (screenHeight === 896 || screenWidth === 896))
  );
}
