import React from 'react';
import PropTypes from 'prop-types';
import {
  View,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { size } from '../constants/general';

const AOLoader = props => {
  return (
    <View style={styles.container}>
      <ActivityIndicator size={props.size} color={props.color} style={props.style} />
    </View>
  );
};

AOLoader.propTypes = {
  size: PropTypes.string,
  color: PropTypes.string,
  style: PropTypes.object
};

AOLoader.defaultProps = {
  size: size.large,
  color: '#2C7BD2',
  style: {}
};

export default AOLoader;

const styles = StyleSheet.create({
  container: {
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    zIndex: 100,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    // opacity: 0.1,
    // backgroundColor: '#000000'
  },
});
