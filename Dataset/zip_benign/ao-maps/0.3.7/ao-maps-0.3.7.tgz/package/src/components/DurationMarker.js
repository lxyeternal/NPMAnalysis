import React from 'react';
import MapView from 'react-native-maps';
import { View, Text, StyleSheet } from 'react-native';

const getMarkerTitle = (props) => {
  const duration = props.duration && props.duration.text;
  const distance = props.distance && props.distance.text;

  return (
    (duration || duration) && <Text style={styles.durationWrapper}>
      {duration && <Text style={styles.duration}>
        {`${duration}`}
      </Text>
      }
      {
        distance && <Text style={styles.distance}>
          {` (${distance})`}
        </Text>
      }
    </Text>
  );
};

const DurationMarker = (props) => {
  const title = getMarkerTitle(props);

  return (
    <MapView.Marker
      coordinate={props.coordinate}
    // anchor={{ x: 1, y: 1.5 }}
    >
      <View style={{
        flexDirection: 'column',
        alignItems: 'center',
        position: 'relative',
        borderRadius: 5,
        shadowOffset: { width: 2, height: 2, },
        shadowColor: 'black',
        shadowOpacity: 0.8,
      }}>
        <View style={{
          flexDirection: 'column',
          // backgroundColor: 'red',
          height: 50,
        }}>
          {title}
        </View>
        <View style={{
          position: 'absolute',
          zIndex: 100,
          top: 36,
          borderTopWidth: 10,
          borderRightWidth: 10,
          borderBottomWidth: 0,
          borderLeftWidth: 10,
          borderTopColor: '#FFFFFF',
          borderRightColor: 'transparent',
          borderBottomColor: 'transparent',
          borderLeftColor: 'transparent',
        }} />
      </View>
    </MapView.Marker >
  );
};

export default DurationMarker;

const styles = StyleSheet.create({
  durationWrapper: {
    padding: 10,
    backgroundColor: '#ffffff'
  },
  duration: {
    fontSize: 14,
    color: '#EB622D',
    padding: 10
  },
  distance: {
    fontSize: 14,
    color: '#916C47',
    padding: 10
  }
});
