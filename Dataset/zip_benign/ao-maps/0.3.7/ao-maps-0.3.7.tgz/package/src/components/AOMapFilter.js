import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'react-native-elements';
import { Button } from 'react-native-elements';
import { filterData } from '../config/mockData';
import { ListItem } from 'react-native-elements';
import { icons, icon_types } from '../constants/images';
import { StyleSheet, View, SectionList, Text } from 'react-native';

class AOMapFilter extends React.Component {

  constructor() {
    super();

    this.state = {
      selectedItems: []
    };
  }

  _getRightIconConfig = () => {
    return {
      name: icons.check,
      type: icon_types.font_awesome,
      size: 16
    };
  }

  _renderItem = ({ item }) => {
    return (
      <ListItem
        title={item}
        rightIcon={this._isItemSelected(item) && this._getRightIconConfig()}
        bottomDivider
        onPress={() => this._handleItemSelection(item)}
      />
    );
  }

  // Return if an item is selected.
  _isItemSelected = (item) => {

    return this.state.selectedItems.includes(item);
  }

  _handleItemSelection = (item) => {
    const isItemSelected = this._isItemSelected(item);
    let selectedItems = this.state.selectedItems;

    if (isItemSelected) {
      selectedItems = selectedItems.filter(item => item !== item);
    } else {
      selectedItems.push(item);
    }

    this.setState({ selectedItems });
  }

  _dismissOverlay = () => {
    this.props.dismissOverlay();
  }

  _getHeaderView = () => {
    return (
      <View style={styles.headerView}>
        <Text style={styles.headerText}>Filters</Text>
        <Icon
          name={icons.times}
          type={icon_types.font_awesome}
          color='#7B7B7B'
          onPress={this._dismissOverlay}
        />
      </View>
    );
  }

  _clearSelectedItems = () => {
    this.setState({ selectedItems: [] });
  }

  _applyFilter = () => {
    this.props.applyFilters(this.state.selectedItems);
    setTimeout(() => {
      this._dismissOverlay();
    }, 100);
  }

  _getFooterView = () => {
    return (
      <View style={styles.footerView}>
        <Button
          title="Clear All"
          type="solid"
          buttonStyle={styles.clearButton}
          titleStyle={{ color: '#203D5C' }}
          onPress={this._clearSelectedItems}
        />
        <Button
          title="Apply"
          type="solid"
          buttonStyle={styles.applyButton}
          titleStyle={{ color: '#203D5C' }}
          onPress={this._applyFilter}
        />
      </View>
    );
  }

  render() {
    return (
      <View style={styles.container}>
        {this._getHeaderView()}
        <View style={{ flex: 1, marginTop: 16 }}>
          <SectionList
            sections={this.props.data}
            keyExtractor={(item, index) => item + index}
            renderItem={this._renderItem}
            renderSectionHeader={({ section: { title } }) => (
              <Text style={styles.header}>{title}</Text>
            )}
          />
        </View>
        {this._getFooterView()}
      </View>
    );
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  headerWrapper: {
    flex: 1,
    flexDirection: 'row'
  },
  headerView: {
    flexDirection: 'row',
    height: 60,
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  footerView: {
    flexDirection: 'row',
    // width: '100%',
    paddingTop: 10,
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  clearButton: {
    backgroundColor: '#F4F4F4',
    borderRadius: 10,
    paddingHorizontal: 16,
  },
  applyButton: {
    backgroundColor: '#B7B743',
    borderRadius: 10,
    paddingHorizontal: 16,
  },
  headerText: {
    fontSize: 20,
    color: '#203D5C',
    fontWeight: 'bold'
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
  },
  header: {
    backgroundColor: '#FFFFFF',
    fontSize: 32,
  },
  title: {
    fontSize: 24,
  },
});

AOMapFilter.propTypes = {
  data: PropTypes.array,
  dismissOverlay: PropTypes.func,
  applyFilters: PropTypes.func,
};

AOMapFilter.defaultProps = {
  data: filterData
};

export default AOMapFilter;
