import React from 'react';
import AOLoader from './AOLoader';
import Animated from 'react-native-reanimated';
import { response_keys } from '../constants/key';
import BottomSheet from 'reanimated-bottom-sheet';
import SimpleToast from 'react-native-simple-toast';
import { Icon, Button } from 'react-native-elements';
import { general_message } from '../constants/message';
import { icons, icon_types } from '../constants/images';
import { Image, ListItem } from 'react-native-elements';
import { generalText, buttonText } from '../constants/text';
import { storeFavouritePOI } from '../services/favourite';
import { default_opening_hours } from '../constants/appConstant';
import { View, ActivityIndicator, Text, StyleSheet } from 'react-native';
import { getVenuOpeningInfo, makeACall, openWebsite, captalizeString } from '../utils/general';
import {
  FlatList,
  ScrollView,
  TouchableOpacity,
} from 'react-native-gesture-handler';

const hitSlop = { top: 14, bottom: 14, left: 40, right: 40 };
const snapPoints = [350, 250, 80];

class AOBottomSheet extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      snapPosition: 2,
      // favouritePOIs: [],
    };

    this.bottomSheet = React.createRef();
    this.sheetOpenValue = new Animated.Value(0);
  }

  componentDidMount = () => {
    setTimeout(() => {
      this.bottomSheet.current.snapTo(2);
    }, 100);
  }

  _renderMenuItem = ({ item }) => {
    const isFavourite = item === generalText.favourite;
    const isSelected = item === this.props.selectedCategory;
    const backgroundColor = isSelected ? '#3F90CD' : '#F2F2F2';
    const textColor = isSelected ? '#FFFFFF' : '#153A5A';

    return (
      item ? <TouchableOpacity
        onPress={() => {
          this.bottomSheet.current.snapTo(1);
          this.props.handleCategoryPressed(item);
        }}
        style={[styles.categoryButton, { backgroundColor }]}
      >
        <View style={styles.categoryWrapper}>
          {isFavourite && <Icon
            name={icons.star}
            type={icon_types.font_awesome}
            color={isSelected ? '#FFFFFF' : '#00aced'}
          />
          }
          <Text style={[styles.categoryText, { color: textColor }]}>
            {captalizeString(item)}
          </Text>
        </View>
      </TouchableOpacity >
        : null
    );
  }

  _handleSnapHeaderPress = () => {
    let snapValue = 0;

    (this.state.snapPosition === snapPoints.length - 1) ? snapValue = 1 : snapValue = 2;
    this.setState({ snapPosition: snapValue }, () => {
      this.bottomSheet.current.snapTo(this.state.snapPosition);
    });
  }

  snapToPosition = (position) => {
    if (snapPoints[position]) {
      this.bottomSheet.current.snapTo(position);
    } else {
      SimpleToast.show(general_message.no_position);
    }
  }

  _renderPOIs = ({ item }) => {
    return (
      <ListItem
        title={item.name}
        leftIcon={{ name: icons.location_arrow, type: icon_types.font_awesome, color: '#A7A7A7' }}
        bottomDivider
        onPress={() => this.props.handlePOISelected(item)}
      />
    );
  }

  _getMenuView = (menuItems) => {
    return (
      <View style={{ flex: 1 }}>
        {this.props.isLoadingCategories && <AOLoader />}
        <FlatList
          showsHorizontalScrollIndicator={false}
          extraData={this.props.selectedCategory}
          horizontal={true}
          data={menuItems}
          renderItem={this._renderMenuItem}
          keyExtractor={(item, index) => index.toString()}
        />
        <FlatList
          showsHorizontalScrollIndicator={false}
          data={this.props.quickPOIs}
          renderItem={this._renderPOIs}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    );
  }

  _getOpeningDetailView = (markerData) => {
    const openingHours = markerData[response_keys.opening_hours] || default_opening_hours;
    // const isVenuOpen = isVenuOpen(openingHours);
    const venuOpeningInfo = getVenuOpeningInfo(openingHours);
    const openStatus = venuOpeningInfo.isOpen ? generalText.openNow : generalText.closedNow;
    const timing = venuOpeningInfo.isOpen ? `Closing at ${venuOpeningInfo.time}` : `Opening at ${venuOpeningInfo.time}`;

    return (
      <View style={styles.openDetailContainer}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={styles.openingStatus}>{openStatus}</Text>
          <Text style={styles.openingTiming}>{timing}</Text>
        </View>
        <Button
          type='outline'
          raised
          title={buttonText.getDirection}
          onPress={() => {
            this.props.getDirection();
          }}
        />
      </View >
    );
  }

  _getContactButtonView = (markerData) => {
    const phoneNumber = markerData[response_keys.telephone] || null;
    const websiteURL = markerData[response_keys.website] || null;

    return (
      <View style={styles.contactButtonContainer}>
        {phoneNumber && <Button
          icon={
            <Icon
              name={icons.phone}
              size={15}
              color='white'
              type={icon_types.font_awesome}
            />
          }
          titleStyle={{ marginLeft: 20 }}
          title={buttonText.enquiries}
          onPress={() => makeACall(phoneNumber)}
        />}
        {websiteURL && <Button
          type='outline'
          raised
          title={buttonText.openWebsite}
          onPress={() => openWebsite(websiteURL)}
        />
        }
      </View >
    );
  }

  _getDetailView = (markerData) => {
    const imageURL = markerData[response_keys.photo_url1];
    const description = markerData[response_keys.description] || '';

    return (
      <View style={{ flex: 1, paddingBottom: 16 }}>
        {imageURL ? <Image
          source={{ uri: imageURL }}
          style={styles.coverImage}
          PlaceholderContent={<ActivityIndicator />}
        /> : <View />
        }
        <View style={{ padding: 16 }}>
          {this._getOpeningDetailView(markerData)}
          {this._getContactButtonView(markerData)}
          <Text style={{ paddingVertical: 16 }}>{description}</Text>
        </View>
      </View >
    );
  }

  _renderContent = () => {
    const { markerData, menuItems } = this.props;

    return (
      <ScrollView style={{ height: 350, backgroundColor: '#FFFFFF' }}>
        {markerData ? this._getDetailView(markerData) : this._getMenuView(menuItems)}
        <View style={{ height: 150 }} />
      </ScrollView>
    );
  }

  _cancelSelection = () => {
    this.props.hideDetailPage();
    this.setState({ snapPosition: 2 }, () => {
      this.bottomSheet.current.snapTo(2);
    });
  }

  _handleFavourite = async (markerData) => {
    try {
      const favouritePOIs = await storeFavouritePOI(markerData);

      this.setState({ favouritePOIs });
    } catch (error) {
      SimpleToast.show(general_message.error_interacting);
    }
  }

  // return header with button to set marker as favourite
  _getHeaderWithFavourite = (markerData) => {
    // const favouritePOI = this.state.favouritePOIs && this.state.favouritePOIs.filter(item => markerData.id === item.id);
    return (
      <View style={styles.headerIconWrapper}>
        {/* <Icon
          name={icons.star}
          type={icon_types.font_awesome}
          color={favouritePOI.length ? '#00aced' : '#000000'}
          onPress={() => this._handleFavourite(markerData)}
        /> */}
        <View />
        <TouchableOpacity
          onPress={this._handleSnapHeaderPress}
          hitSlop={hitSlop}
          style={styles.headerButton}
        />
        <Icon
          name={icons.times}
          type={icon_types.font_awesome}
          color='red'
          onPress={this._cancelSelection}
        />
      </View>
    );
  }

  _getNormalHeader = () => {
    return (
      <View style={{ flex: 1, paddingVertical: 16 }}>
        <TouchableOpacity
          onPress={this._handleSnapHeaderPress}
          hitSlop={hitSlop}
          style={styles.headerButton}
        />
      </View>
    );
  }

  _renderHeader = () => {
    const { markerData } = this.props;


    return (
      <View style={styles.headerWrapper}>
        {markerData ? this._getHeaderWithFavourite(markerData) : this._getNormalHeader()}
        <Text style={styles.headerTitle}>
          {markerData ? markerData.name : generalText.bottomSheetTitle}
        </Text>
      </View>
    );
  }

  render() {
    return (
      <BottomSheet
        ref={this.bottomSheet}
        snapPoints={snapPoints}
        initialSnap={this.state.snapPosition}
        renderContent={this._renderContent}
        renderHeader={this._renderHeader}
        // onOpenEnd={this.props.handleOpen}
        // onCloseEnd={this.props.handleClose}
        callbackNode={this.sheetOpenValue}
        enabledInnerScrolling={false}
        enabledContentTapInteraction={false}
      // enabledContentGestureInteraction={true}
      />
    );
  }
}

export default AOBottomSheet;

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  headerWrapper: {
    flex: 1,
    borderTopStartRadius: 10,
    borderTopEndRadius: 10,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    paddingBottom: 10
  },
  headerIconWrapper: {
    flex: 1,
    width: '100%',
    paddingVertical: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  headerTitle: {
    fontSize: 18,
    paddingHorizontal: 6,
    paddingBottom: 6,
    fontWeight: 'bold',
    color: '#153A5A'
  },
  headerButton: {
    height: 6,
    width: 50,
    borderRadius: 5,
    // marginTop: 16,
    backgroundColor: '#D3D3D3'
  },
  iconStyle: {
    width: 36,
    height: 36,
    marginLeft: 20,
    tintColor: '#153A5A'
  },
  categoryWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    // justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  categoryButton: {
    margin: 16,
    borderRadius: 8,
  },
  categoryText: {
    fontWeight: 'bold',
    fontSize: 16,
    padding: 20
  },
  contentWrapper: {
    paddingHorizontal: 16,
    backgroundColor: 'red'
  },
  coverImage: {
    width: '100%',
    height: 200,
  },
  openDetailContainer: {
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  openingStatus: {
    paddingRight: 10,
    fontSize: 16,
    color: '#363E4E',
    fontWeight: 'bold'
  },
  openingTiming: {
    fontSize: 14,
    color: 'gray'
  },
  contactButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10
  },
});
