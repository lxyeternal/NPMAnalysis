import React from 'react';
import PropTypes from 'prop-types';
import { SearchBar } from 'react-native-elements';
import { Platform, StyleSheet } from 'react-native';

class AOSearchBar extends React.Component {

  _updateSearch = searchText => {
    this.setState({ searchText }, () => {
      this.props.fetchResults(searchText);
    });
  };

  _cancelSearch = () => {
    this.setState({ searchText: '' }, () => {
      this.props.cancelSearch();
    });
  };

  _onTextClear = () => {
    this.setState({ searchText: '' }, () => {
      this.props.cancelSearch();
    });
  }

  render() {
    return (
      <SearchBar
        clearIcon={this.props.searchText ? true : false}
        onClear={this._onTextClear}
        placeholder={this.props.placeHolder}
        onChangeText={this._updateSearch}
        value={this.props.searchText}
        containerStyle={[this.props.containerStyle, { paddingTop: 6, paddingBottom: 6 }]}
        platform={Platform.OS}
        onCancel={this._cancelSearch}
        showLoading={this.props.shouldShowLoading}
        autoCorrect={false}
      />
    );
  }

}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  headerWrapper: {
    flex: 1,
  },
});


AOSearchBar.propTypes = {
  fetchResults: PropTypes.func,
  cancelSearch: PropTypes.func,
  containerStyle: PropTypes.object,
  placeHolder: PropTypes.string
};

AOSearchBar.defaultProps = {
  containerStyle: styles.container,
  shouldShowLoading: false,
  placeHolder: 'Search'
};

export default AOSearchBar;
