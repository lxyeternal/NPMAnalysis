import axios from 'axios';
import { general_message } from '../constants/message';
import { isConnectedToNetwork } from '../utils/network';

// import { handleErrors } from '../errorHandler';

// Add a request interceptor 
var AOAxiosInstance = axios.create();

AOAxiosInstance.interceptors.request.use(async (config) => {
  // Do something before request is sent 
  // If the header does not contain the token and the url not public, redirect to login    

  try {
    const isConnected = await isConnectedToNetwork();

    if (isConnected) {
      // TODO: Get accessToken if required
      // const accessToken = await getAccessToken();

      // if token is found add it to the header
      // if (accessToken) {
      // 	config.headers.Authorization = accessToken;
      // }
      const baseURL = global.baseURL;

      if (!baseURL) {
        throw (general_message.no_base_url);
      } else {
        config.baseURL = baseURL;
      }

      return config;
    } else {
      return Promise.reject(Error('No Internet Connection'));
    }
  } catch (error) {
    Promise.reject(error);
  }
}, (error) => {
  // Do something with request error 
  return Promise.reject(error);
});

AOAxiosInstance.interceptors.response.use((response) => {
  // Do something with response data
  return response;
}, (error) => {
  // Do something with response error  
  // TODO: add a new error handler function
  // return promise.reject(handleErrors(error));

  return Promise.reject(error);
}
);

export default AOAxiosInstance;
