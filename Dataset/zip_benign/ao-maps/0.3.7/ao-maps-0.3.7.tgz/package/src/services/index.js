import AOAxiosInstance from './axiosInstance';
import { googleConfig } from '../config/google';
import { requestToServer } from '../utils/network';
import { end_points, request_methods } from '../constants/general';
import { filterData } from '../config/mockData';

// Returns the markers according to the search text
// TODO: verify if the filter works or not

// NOTE: here markers represent the POIs

export const autoCompletePOI = (searchText, filters) => {
  const url = `${end_points.marker_autocomplete}`;
  const info = { url, method: request_methods.get, params: { prefix: searchText, key: global.apiKey, category: filters } };

  return requestToServer(info, AOAxiosInstance);
};

export const searchPOI = (searchText) => {
  const url = `${end_points.search}`;
  const info = { url, method: request_methods.get, params: { query: searchText, key: global.apiKey } };

  return requestToServer(info, AOAxiosInstance);
}

export const defaultMarkers = () => {
  const url = `${end_points.search}`;
  const info = { url, method: request_methods.get, params: { default: 1, key: global.apiKey } };

  return requestToServer(info, AOAxiosInstance);
};

// Return all the categories available
export const getAllCategories = () => {
  const url = `${end_points.all_categories}`;
  const info = { url, method: request_methods.get, params: { key: global.apiKey } };

  return requestToServer(info, AOAxiosInstance);
};

// Return all markers of the provided category like courts.
export const getAllMarkerWithCategory = (category) => {
  const url = `${end_points.search}`;
  const info = { url, method: request_methods.get, params: { category, key: global.apiKey } };

  return requestToServer(info, AOAxiosInstance);
};

export const getAllPOIsWithID = (ids) => {
  const url = `${end_points.list_by_poi_id}?key=${global.apiKey}`;
  const info = { url, method: request_methods.post, params: { poiIds: ids } };

  return requestToServer(info, AOAxiosInstance);
};

export const getAllPOIs = () => {
  const url = `${end_points.list_by_poi_id}?key=${global.apiKey}`;
  const info = { url, method: request_methods.post, params: { poiIds: ['all'] } };

  return requestToServer(info, AOAxiosInstance);
}

// Return the route to get to the destination
export const getRoute = (origin, destination) => {
  const url = `${end_points.route}`;
  const info = { url, method: request_methods.get, params: { origin, destination, key: global.apiKey } };

  return requestToServer(info, AOAxiosInstance);
};

// Return the detail of the marker
export const getMarkerDetail = (markerID, isKMLID = false) => {
  const url = end_points.poi_detail;
  const params = isKMLID ? { poi_id: markerID, key: global.apiKey } : { id: markerID, key: global.apiKey };
  const info = { url, method: request_methods.get, params };

  return requestToServer(info, AOAxiosInstance);
};

// Return the AO api key required to make a request to server
export const getAPIKey = () => {
  // TODO: fetch global.apiKey from server
  return global.apiKey;
};

// Return the API key for google map
export const getGoogleAPIKey = () => {
  // TODO: fetch googleAPIKey from server
  return googleConfig.map.APIKey;
};

export const getRoutingList = () => {
  // TODO: Fetch the direction for server
  const url = `${end_points.routing_list} `;
  const info = { url, method: request_methods.get, params: { key: global.apiKey } };

  return requestToServer(info, AOAxiosInstance);

  // return routes;
};

export const getFilterItems = () => {
  // TODO: fethc filte items from server
  return filterData;
};
