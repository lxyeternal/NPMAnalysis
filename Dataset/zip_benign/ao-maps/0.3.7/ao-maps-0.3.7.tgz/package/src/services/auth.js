import { storage_keys } from '../constants/key';
import { storeData, retrieveData } from '../utils/storage';

export const storeao_api_key = async () => {
  const key = await getao_api_key();

  await storeData(storage_keys.ao_api_key, key);
};
export const getao_api_key = async () => {
  const value = await retrieveData(storage_keys.ao_api_key);

  return value;
};
