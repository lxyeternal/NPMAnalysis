import { getAllPOIsWithID } from '.';

export const getFavoritePOIs = async (pois) => {
  // await CacheStore.set(storage_keys.favourite_marker, []);
  // const favouritePOIs = await CacheStore.get(storage_keys.favourite_marker);
  // convert poi ids to string if they are in number
  const newPois = pois.map(item => item.toString());
  const results = await getAllPOIsWithID(newPois);

  return results.data;
};
