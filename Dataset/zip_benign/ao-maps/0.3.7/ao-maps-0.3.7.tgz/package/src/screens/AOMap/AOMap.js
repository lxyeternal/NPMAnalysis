import React from 'react';
import styles from './style';
import PropTypes from 'prop-types';
import AOLoader from '../../components/AOLoader';
import { generalText } from '../../constants/text';
import { googleConfig } from '../../config/google';
import { response_keys } from '../../constants/key';
import SimpleToast from 'react-native-simple-toast';
import AOSearchBar from '../../components/AOSearchBar';
import AOMapFilter from '../../components/AOMapFilter';
import { general_message } from '../../constants/message';
import AOBottomSheet from '../../components/AOBottomSheet';
import { icons, icon_types } from '../../constants/images';
import { getFavoritePOIs, } from '../../services/favourite';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import DurationMarker from '../../components/DurationMarker';
import AwesomeDebouncePromise from 'awesome-debounce-promise';
import Geolocation from 'react-native-geolocation-service';
import { Icon, Overlay, ListItem } from 'react-native-elements';
import { View, FlatList, PermissionsAndroid, Keyboard } from 'react-native';
import { response, buttons, location } from '../../constants/general';
import { decodePolylinePoints, getRoutingCoordinates, isAndroid, isIphoneXorAbove } from '../../utils/general';
import {
  getRoute,
  getMarkerDetail,
  getFilterItems,
  getAllCategories,
  getAllMarkerWithCategory,
  getRoutingList,
  defaultMarkers,
  getAllPOIs
} from '../../services';

class AOMap extends React.Component {

  constructor(props) {
    super(props);

    const initialRegion = { ...googleConfig.initialRegion, ...props.initialRegion };

    this.state = {
      initialRegion: initialRegion,
      searchText: '',
      dataSource: [],
      searchResults: [],
      selectedMarkerDetail: null,
      categoryItems: [],
      quickPOIs: [],
      defaultPOIs: [],
      directionCoordinates: [],
      allRouteCoordinates: [],
      selectedMarkers: [],
      selectedFilters: [],
      isOverlayVisible: false,
      shouldUpdateLocation: false,
      isLoadingOutline: true,
      isLoadingCategories: false,
      currentLocation: initialRegion,
      initialPOIDetail: null,
      duration: null,
      distance: null,
      isNavigationOn: false,
      selectedCategory: null,
    };

    this.allPOIs = [];
    this.bottomSheet = React.createRef();
    this.mapView = React.createRef();
    this.searchAPIDebounced = AwesomeDebouncePromise(this._searchItems, 100);
  }

  componentDidMount = async () => {
    const { initialPOIID, favouritePOIs } = this.props;

    try {
      this._setGlobalVariables();
      await this._checkLocationPermission();
      const defaultPOIResult = await defaultMarkers();
      const defaultPOIs = defaultPOIResult.data || [];
      const categoryResult = await getAllCategories();
      const allPOIResult = await getAllPOIs();
      // const routingList = await this._getRoutingList();
      const favourieText = favouritePOIs ? generalText.favourite : '';
      const allCategories = [favourieText, ...categoryResult.data];

      this.allPOIs = this._getFormattedPOIs(allPOIResult.data);

      initialPOIID && await this._setInitialPOIDetail(initialPOIID);

      // this.setState({ allRouteCoordinates: routingList.length ? routingList : [], categoryItems: allCategories, isLoadingOutline: false, quickPOIs: defaultPOIs });
      this.setState({ categoryItems: allCategories, isLoadingOutline: false, quickPOIs: defaultPOIs, defaultPOIs });
    } catch (error) {
      this.setState({ allRouteCoordinates: [], categoryItems: [generalText.favourite], isLoadingOutline: false });
      SimpleToast.show(error.message);
    }
  }

  componentWillUnmount() {
    this.watchID !== null && Geolocation.clearWatch(this.watchID);
    clearInterval(this.refreshRoute);
    Keyboard.dismiss();
  }

  _getFormattedPOIs = (pois) => {
    const allNames = pois.map(item => {
      return {
        [response_keys.id]: item.id,
        [response_keys.name]: item.name.toLowerCase(),
        [response_keys.lat]: item.lat,
        [response_keys.lng]: item.lng
      };
    });

    return allNames;
  }

  _setGlobalVariables = () => {
    const { baseURL, apiKey } = this.props;

    if (!apiKey) {
      throw (general_message.no_api_key);
    } else {
      global.baseURL = baseURL;
      global.apiKey = apiKey;
    }
  };

  _getRoutingList = async () => {
    try {
      let routingList = [];
      const result = await getRoutingList();

      routingList = result.data;

      return routingList;
    } catch (error) {
      SimpleToast.show(error.message);
    }
  }

  _updateRoute = async () => {
    if (this.state.selectedMarkers.length === 0) {
      clearInterval(this.refreshRoute);

      return;
    }

    try {
      const origin = `${this.state.currentLocation.latitude},${this.state.currentLocation.longitude}`;
      const destination = `${this.state.selectedMarkers[0].lat},${this.state.selectedMarkers[0].lng}`;
      const result = await getRoute(origin, destination);

      if (result[response_keys.data][response_keys.status] === response.noDataFound) {
        throw (Error(general_message.seems_far));
      } else {
        const routes = result && result.data.routes;
        const route = routes.length && routes[0];
        const coordinates = route && decodePolylinePoints(route.overview_polyline.points);
        const leg = route && route.legs[0];
        const duration = leg.duration || '0 min';
        const distance = leg.distance || '0 m';

        this.setState({ directionCoordinates: coordinates, isLoadingOutline: false, duration, distance });
      }

      if (!this.state.isNavigationOn) {
        this.setState({ isNavigationOn: true }, () => {
          this._fitNavigationDirection();
        });
      }
    } catch (error) {
      SimpleToast.show(error.message);
      this.setState({ directionCoordinates: [], isLoadingOutline: false, isNavigationOn: false });
    }
  }

  // Fit the direction on the map
  _fitNavigationDirection = () => {
    const currentPosition = this.state.currentLocation;
    const selectedMarker = this.state.selectedMarkers[0];
    const coordinates = [
      { [location.latitude]: selectedMarker.lat, [location.longitude]: selectedMarker.lng },
      currentPosition,
    ];
    const edgePadding = isAndroid ? googleConfig.androidEdgePadding : googleConfig.iosEdgePadding;

    this.mapView.current.fitToCoordinates(coordinates, { edgePadding: edgePadding, animated: true });
  }

  _getRegion = (position) => {
    return {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      latitudeDelta: 0.0922,
      longitudeDelta: 0.0421,
    };
  }

  _cancelSearch = () => {
    this.setState({ searchText: '' });
    this._fetchResults(null);
  };

  _searchItems = (searchKey) => {
    try {
      const keyTerm = searchKey ? searchKey.toLowerCase() : '';
      // const result = await autoCompletePOI(keyTerm, this.state.selectedFilters);
      // return result && result.data;

      return this.allPOIs.filter(item => item[response_keys.name].includes(keyTerm));
    } catch (error) {
      SimpleToast.show(error.message);
    }
  }

  // fetch results with the search text in the search bar
  _fetchResults = searchText => {
    this.setState({ isLoading: true, searchText: searchText }, async () => {
      let searchResults = [];
      // Reset the list if the search key is empty

      if (!searchText) {
        this.setState({ searchResults: searchResults, isLoading: false });
      } else {
        try {
          searchResults = await this.searchAPIDebounced(searchText);
          this.setState({ searchResults: searchResults, isLoading: false });
        } catch (error) {
          this.setState({ isLoading: false });
          SimpleToast.show(error.message);
        }
      }
    });
  };

  // Fetch marker location as per the selected category 
  _handleCategoryPressed = item => {
    let allPOIs = this.state.defaultPOIs;

    if (item === this.state.selectedCategory) {
      this.setState({ quickPOIs: allPOIs, selectedCategory: null }, () => {
        // this._fitAllPOIs(allPOIs);
        this.mapView.current.animateCamera({ center: this.state.currentLocation, zoom: 14 }, 1000);
      });
    } else {
      this.setState({ isLoadingCategories: true, selectedCategory: item }, async () => {
        try {
          if (item === 'Favourite') {
            const favouritePOIs = await getFavoritePOIs(this.props.favouritePOIs);

            // Filter the null values
            allPOIs = favouritePOIs.length ? favouritePOIs.filter(Boolean) : [];
            // allPOIs = await getFavoritePOIs(this.props.favouritePOIs);
          } else {
            const result = await getAllMarkerWithCategory(item);

            allPOIs = result.data.length ? result.data.filter(Boolean) : [];
          }

          this.setState({ selectedMarkers: [], directionCoordinates: [], quickPOIs: allPOIs, initialPOIDetail: null, isLoadingCategories: false }, () => {
            this._fitAllPOIs(allPOIs);
          });
        } catch (error) {
          SimpleToast.show(error.message);
          this.setState({ isLoadingCategories: false });
        }
      });
    }
  }

  _fitAllPOIs = (allPOIs) => {
    const coordinates = allPOIs.map(item => {
      return { [location.latitude]: item.lat, [location.longitude]: item.lng };
    });

    coordinates.length === 1 ? this._animateToPOI(coordinates[0])
      :
      this.mapView.current.fitToCoordinates(coordinates, { edgePadding: { top: 150, bottom: 250, right: 40, left: 40 }, animated: true });
  }

  _animateToPOI = (poi) => {
    const coordinate = { [location.latitude]: poi.latitude, [location.longitude]: poi.longitude, latitudeDelta: 0.01, longitudeDelta: 0.01 };

    this.mapView.current.animateCamera({ center: coordinate, zoom: 16 }, 1000);
  }

  // Dispaly the detailed information about the marker location.
  _setSelectedItem = marker => {
    this.setState({ searchText: '', searchResults: [], directionCoordinates: [], selectedCategory: null }, async () => {
      await this._onMarkerClick(marker);
    });
  }

  _renderSearchedItem = ({ item }) => {
    return (
      <ListItem
        title={item.name}
        leftIcon={{ name: icons.location_arrow, type: icon_types.font_awesome, color: '#A7A7A7' }}
        bottomDivider
        onPress={() => this._setSelectedItem(item)}
      />
    );
  }

  _handlePOISelected = (item) => {
    const selectedPOI = this.state.selectedMarkers[0];
    const isSelectedPOI = (selectedPOI && item.id === selectedPOI.id);

    this.setState({ directionCoordinates: isSelectedPOI ? this.state.directionCoordinates : [] }, async () => {
      await this._onMarkerClick(item, true);
    });
  }

  _showFilterView = () => {
    this.setState({ isOverlayVisible: !this.state.isOverlayVisible });
  }

  _setFilters = (filters) => {
    this.setState({ selectedFilters: filters });
  }

  _getFilters = () => {
    const filterItems = getFilterItems();

    return (
      <Overlay
        isVisible={this.state.isOverlayVisible}
        width={'90%'}
        height={'90%'}
      >
        <AOMapFilter
          dismissOverlay={() => {
            SimpleToast.show(general_message.make_search);
            this.setState({ isOverlayVisible: false });
          }}
          applyFilters={this._setFilters}
          data={filterItems}
        />
      </ Overlay>
    );
  }

  _checkLocationPermission = async () => {
    // Need to check permission for android to  avoid crash while getting current location.
    if (isAndroid) {
      try {
        const isPermissionGranted = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);

        if (!isPermissionGranted) {
          await this._requestLocationPermission();
        }
      } catch (error) {
        SimpleToast.show(error.message);
      }
    }
  }

  _showCurrentLocation = () => {
    this.setState({ isLoadingOutline: true }, async () => {
      try {
        await this._checkLocationPermission();
        this.setState({ shouldUpdateLocation: true }, () => {
          Geolocation.getCurrentPosition(
            position => {
              this.setState({ currentLocation: this._getRegion(position), isLoadingOutline: false }, () => {
                this.mapView.current.animateToRegion(this.state.currentLocation, 500);
              });
            },
            error => {
              this.setState({ isLoadingOutline: false });
              SimpleToast.show(error.message);
            },
            { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
          );
        });
      } catch (error) {
        this.setState({ isLoadingOutline: false });
        SimpleToast.show(error.message);
      }
    });
  }

  _requestLocationPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: general_message.need_permission,
          message: general_message.need_permission_message,
          buttonNeutral: buttons.askLater,
          buttonNegative: buttons.cancel,
          buttonPositive: buttons.ok,
        },
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        SimpleToast.show(general_message.show_pois);
      } else {
        SimpleToast.show(general_message.permission_denied);
      }
    } catch (err) {
      SimpleToast.show(err.message);
    }
  }

  // shouldAnimate: set to true if the all pois need to be displayed during selection as well
  _onMarkerClick = async (item, shouldDisplayAll = false) => {
    try {
      clearInterval(this.refreshRoute);
      Keyboard.dismiss();

      const result = await getMarkerDetail(item.id);
      const itemDetail = result && result.data;
      const pois = shouldDisplayAll ? this.state.quickPOIs : [item];

      // itemDetail && this.setState({ selectedMarkers: [item], selectedMarkerDetail: itemDetail, initialPOIDetail: null }, () => {
      itemDetail && this.setState({ selectedMarkers: [item], selectedMarkerDetail: itemDetail, isNavigationOn: false, quickPOIs: pois }, () => {
        const temp_cordinate = {
          latitude: item.lat,
          longitude: item.lng,
        };

        this.bottomSheet.current.snapToPosition(1);
        this.mapView.current.animateCamera({ center: temp_cordinate, zoom: 18 }, 1000);
      });
    } catch (error) {
      SimpleToast.show(general_message.no_marker_detail);
    }
  }

  _setInitialPOIDetail = async (ID) => {
    try {
      const result = await getMarkerDetail(ID, true);
      const itemDetail = result && result.data;

      itemDetail && this.setState({ initialPOIDetail: itemDetail });
    } catch (error) {
      SimpleToast.show(error.message);
    }
  }

  _getMarkers = (locations) => {
    if (locations) {
      const markers = locations.map((item, index) => {
        const coordinate = {
          latitude: item.lat,
          longitude: item.lng
        };

        const selectedPOI = this.state.selectedMarkers[0];
        const isSelectedPOI = (selectedPOI && item.id === selectedPOI.id);
        const pinColor = isSelectedPOI ? googleConfig.marker.selected : googleConfig.marker.unSelected;

        return <MapView.Marker
          key={item.name + index.toString() + isSelectedPOI}
          coordinate={coordinate}
          onPress={() => this._handlePOISelected(item)}
          identifier={item.id.toString()}
          pinColor={pinColor}
        />;
      });

      return markers;
    }
  }

  _getSearchView = () => {
    const iOSTopMargin = isIphoneXorAbove() ? 44 : 22;
    const paddingBottom = this.state.searchResults.length > 0 ? 16 : 0;

    return (
      <View style={[styles.searchBarWrapper, { marginTop: isAndroid ? 0 : iOSTopMargin, paddingBottom, backgroundColor: '#FFFFFF' }]}>
        {/* <View style={styles.searchBarWrapper}> */}
        <AOSearchBar
          searchText={this.state.searchText}
          containerStyle={styles.searchBarContainer}
          fetchResults={this._fetchResults}
          cancelSearch={this._cancelSearch}
          shouldShowLoading={this.state.isLoading}
        />
        <FlatList
          data={this.state.searchResults}
          bounces={false}
          renderItem={this._renderSearchedItem}
          enableEmptySections={true}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    );
  }

  // show the route from origin to destination
  _displayRoute = () => {
    const polyLineStyle = { ...googleConfig.polyLine, ...this.props.polyLineStyle };

    return <MapView.Polyline
      coordinates={this.state.directionCoordinates}
      strokeWidth={polyLineStyle.strokeWidth}
      strokeColor={polyLineStyle.strokeColor}
    />;
  }

  _displayDashedRoute = () => {
    const dashLineStyle = { ...googleConfig.dashLine, ...this.props.dashLineStyle };
    const selectedPOI = this.state.selectedMarkers[0];
    const directionCoordinates = this.state.directionCoordinates;
    const coordinatesFromOrigin = [this.state.currentLocation, directionCoordinates[0]];
    const coordinatesToDestination = [directionCoordinates[directionCoordinates.length - 1], { latitude: selectedPOI.lat, longitude: selectedPOI.lng }];

    return (
      <>
        <MapView.Polyline
          coordinates={coordinatesFromOrigin}
          strokeWidth={dashLineStyle.strokeWidth}
          strokeColor={dashLineStyle.strokeColor}
          lineDashPattern={dashLineStyle.lineDashPattern}
        />
        <MapView.Polyline
          coordinates={coordinatesToDestination}
          strokeWidth={dashLineStyle.strokeWidth}
          strokeColor={dashLineStyle.strokeColor}
          lineDashPattern={dashLineStyle.lineDashPattern}
        />
      </>
    );
  }

  _updateDirection = () => {
    this.setState({ isLoadingOutline: true, shouldUpdateLocation: true, isNavigationOn: false }, async () => {
      await this._checkLocationPermission();
      this._startNavigation();

      // TODO Find better solution
      this.refreshRoute = setInterval(() => {
        this._startNavigation();
      }, 7000);
    });
  }

  _startNavigation = () => {
    try {
      Geolocation.getCurrentPosition(
        position => {
          this.setState({ currentLocation: this._getRegion(position) }, async () => {
            await this._updateRoute();
          });
        },
        error => {
          this.setState({ isLoadingOutline: false });
          SimpleToast.show(error.message);
        },
        { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
      );
    } catch (error) {
      this.setState({ isLoadingOutline: false });
      SimpleToast.show(error.message);
    }
  }

  _displayAllRouteList = () => {
    const mapOutlineStyle = { ...googleConfig.mapOutline, ...this.props.mapOutlineStyle };

    return (
      this.state.allRouteCoordinates.map((item, index) => {
        const points = item.points;
        const coordinates = getRoutingCoordinates(points);

        return <MapView.Polyline
          key={index.toString()}
          coordinates={coordinates}
          strokeWidth={mapOutlineStyle.strokeWidth}
          strokeColor={mapOutlineStyle.strokeColor}
        />;
      })
    );
  };

  _dismissBottomSheet = () => {
    clearInterval(this.refreshRoute);
    Keyboard.dismiss();

    this.setState({ selectedMarkerDetail: null, directionCoordinates: [], selectedMarkers: [], duration: null, distance: null, isNavigationOn: false }, () => {
      this._fitAllPOIs(this.state.quickPOIs);
    });
  }

  _dispalyDurationMarker = () => {
    const index = Math.round(this.state.directionCoordinates.length / 2);

    // Return the marker with duration if there are more than 4 coordinates so as to fit label.
    return (
      index > 0 ? <DurationMarker
        coordinate={this.state.directionCoordinates[index - 1]}
        duration={this.state.duration}
        distance={this.state.distance}
      /> : null
    );
  }

  _getMapView = () => {
    const markerLocations = this.state.quickPOIs;
    const mapConfig = { ...googleConfig.map, ...this.props.mapConfig };
    const mapStyle = [...googleConfig.mapStyle, ...this.props.mapStyle];
    const iOSTopMargin = isIphoneXorAbove() ? 44 : 22;

    return (
      <MapView
        ref={this.mapView}
        style={[styles.map, { marginTop: isAndroid ? 0 : iOSTopMargin }]}
        moveOnMarkerPress
        provider={PROVIDER_GOOGLE}
        showsUserLocation={mapConfig.showUserLocation}
        showsMyLocationButton={mapConfig.showsMyLocationButton}
        showsCompass={mapConfig.showsCompass}
        loadingEnabled={mapConfig.loadingEnabled}
        rotateEnabled={mapConfig.rotateEnabled}
        scrollEnabled={mapConfig.scrollEnabled}
        zoomControlEnabled={mapConfig.zoomControlEnabled}
        pitchEnabled={mapConfig.pitchEnabled}
        zoomEnabled={mapConfig.zoomEnabled}
        followsUserLocation={mapConfig.followsUserLocation}
        minZoomLevel={mapConfig.minZoomLevel}
        maxZoomLevel={mapConfig.maxZoomLevel}
        customMapStyle={mapStyle}
        initialRegion={this.state.initialRegion}
      >
        {this._getMarkers(markerLocations)}
        {/* {this.state.initialPOIDetail && this._getMarkers([this.state.initialPOIDetail])} */}
        {this.state.directionCoordinates.length > 0 ? this._displayRoute() : null}
        {this.state.directionCoordinates.length > 0 ? this._displayDashedRoute() : null}
        {this.state.directionCoordinates.length > 0 ? this._dispalyDurationMarker() : null}
        {this.state.allRouteCoordinates.length > 0 ? this._displayAllRouteList() : null}
      </MapView>
    );
  }

  render() {
    const filterButtonStyle = { ...googleConfig.icon.filter, ...this.props.filterButtonStyle };
    const myLocationButtonStyle = { ...googleConfig.icon.currentLocation, ...this.props.myLocationButtonStyle };

    return (
      <View style={styles.container}>
        {this._getSearchView()}
        {this.state.isLoadingOutline && <AOLoader />}
        {this._getFilters()}
        <View style={[styles.iconWrapper]}>
          {
            this.props.isFilterVisible && <Icon
              raised
              size={filterButtonStyle.size}
              name={filterButtonStyle.name}
              type={filterButtonStyle.type}
              color={filterButtonStyle.color}
              onPress={this._showFilterView}
            />
          }
          <Icon
            raised
            size={myLocationButtonStyle.size}
            name={myLocationButtonStyle.name}
            type={myLocationButtonStyle.type}
            color={myLocationButtonStyle.color}
            onPress={this._showCurrentLocation}
          />
        </View>
        {!this.state.isLoadingOutline && <AOBottomSheet
          ref={this.bottomSheet}
          menuItems={this.state.categoryItems}
          markerData={this.state.selectedMarkerDetail}
          hideDetailPage={this._dismissBottomSheet}
          handleCategoryPressed={this._handleCategoryPressed}
          handlePOISelected={this._handlePOISelected}
          getDirection={this._updateDirection}
          quickPOIs={this.state.quickPOIs}
          isLoadingCategories={this.state.isLoadingCategories}
          duration={this.state.duration}
          distance={this.state.distance}
          selectedCategory={this.state.selectedCategory}
        />}
        {this._getMapView()}
      </View>
    );
  }
}

AOMap.propTypes = {
  apiKey: PropTypes.string.isRequired,
  baseURL: PropTypes.string.isRequired,
  mapConfig: PropTypes.object,
  mapStyle: PropTypes.array,
  initialRegion: PropTypes.object,
  distanceFilter: PropTypes.number,
  polyLineStyle: PropTypes.object,
  dashLineStyle: PropTypes.object,
  edgePadding: PropTypes.object,
  mapOutlineStyle: PropTypes.object,
  myLocationButtonStyle: PropTypes.object,
  filterButtonStyle: PropTypes.object,
  initialPOIID: PropTypes.number,
  isFilterVisible: PropTypes.bool,
};

AOMap.defaultProps = {
  mapConfig: googleConfig.map,
  mapStyle: googleConfig.mapStyle,
  initialRegion: googleConfig.initialRegion,
  distanceFilter: googleConfig.distanceFilter,
  polyLineStyle: googleConfig.polyLine,
  dashLineStyle: googleConfig.dashLine,
  edgePadding: googleConfig.edgePadding,
  mapOutlineStyle: googleConfig.mapOutline,
  myLocationButtonStyle: googleConfig.icon.currentLocation,
  filterButtonStyle: googleConfig.icon.filter,
  isFilterVisible: false
};

export default AOMap;
