import { StyleSheet } from 'react-native';
import { Colors } from 'react-native/Libraries/NewAppScreen';
import { screenHeight, screenWidth } from '../../utils/general';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
    backgroundColor: '#0091D2',
  },
  wrapper: {
    flex: 1,
    bottom: 60,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  map: {
    flex: 1,
    // bottom: 20,
    // top: 0,
    // bottom: 0,
    // left: 0,
    // right: 0,
    // zIndex: 1,
    // position: 'absolute',
  },
  drawerButton: {
    flex: 0.04,
    padding: 10,
    alignItems: 'center',
    backgroundColor: Colors.light,
    justifyContent: 'flex-start',
  },
  searchBarContainer: {
  },
  searchBarWrapper: {
    position: 'absolute',
    // top: 59,
    zIndex: 2,
    maxHeight: 400,
    width: '100%'
  },
  iconWrapper: {
    position: 'absolute',
    zIndex: 3,
    bottom: 94,
    right: 4
  },
  textStyle: {
    padding: 10,
    marginRight: 10,
  },
  itemSeperator: {
    height: 0.3,
    width: '100%',
    backgroundColor: '#080808',
  },
  iconStyle: {
    width: 20,
    // height: 20,        
    marginLeft: 16
  },
  loadingIndicatorContainer: {
    top: 0,
    left: 0,
    height: screenHeight,
    width: screenWidth,
    zIndex: 100,
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 0.7,
    backgroundColor: '#000000'
  },
  durationWrapper: {
    paddingHorizontal: 6,
    backgroundColor: '#ffffff'
  },
  duration: {
    fontSize: 14,
    color: '#EB622D',
    padding: 10
  },
  distance: {
    fontSize: 14,
    color: '#916C47',
    padding: 10
  }
});

export default styles;
