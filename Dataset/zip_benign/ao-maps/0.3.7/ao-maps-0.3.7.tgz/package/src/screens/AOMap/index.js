import AOMap from './AOMap';

export default AOMap;
