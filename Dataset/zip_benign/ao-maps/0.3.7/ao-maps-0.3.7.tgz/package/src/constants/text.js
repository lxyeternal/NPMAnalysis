export const generalText = {
  openNow: 'Open Now',
  closedNow: 'Closed Now',
  bottomSheetTitle: 'What are you looking for?',
  favourite: 'Favourite'
};

export const buttonText = {
  openWebsite: 'Open Website',
  getDirection: 'Get Direction',
  enquiries: 'Enquiries'
};
