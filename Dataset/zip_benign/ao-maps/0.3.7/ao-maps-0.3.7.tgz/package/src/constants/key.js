export const storage_keys = {
  favourite_marker: 'favouriteMarker',
  ao_api_key: 'ao_api_key',
  routing_list: 'rotutingList'
};

export const response_keys = {
  opening_hours: 'opening_hours',
  description: 'description',
  telephone: 'telephone',
  website: 'website',
  name: 'name',
  photo_url1: 'photo_url1',
  status: 'status',
  data: 'data',
  poi_name: 'name',
  lat: 'lat',
  lng: 'lng',
  id: 'id'
};
