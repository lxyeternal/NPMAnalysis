/* global require */

export const images = {
  star: require('./../assets/images/star.png'),
};

export const icons = {
  star: 'star',
  times: 'times',
  check: 'check',
  filter: 'filter',
  phone: 'phone',
  crosshairs: 'crosshairs',
  location_arrow: 'location-arrow',
  map_marker: 'map-marker'
};

export const icon_types = {
  font_awesome: 'font-awesome'
};
