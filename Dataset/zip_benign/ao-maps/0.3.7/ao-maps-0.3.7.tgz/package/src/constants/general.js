export const image_resize_mode = {
  cover: 'cover',
  contain: 'contain',
  stretch: 'stretch',
  repeat: 'repeat',
  center: 'center'
};

export const OS = {
  androd: 'android',
  iOS: 'ios'
};

export const request_methods = {
  post: 'post',
  get: 'get',
};

export const end_points = {
  poi_detail: '/marker/detail',
  route: '/routing/directions/json',
  marker_autocomplete: '/marker/autocomplete',
  routing_list: '/routing/list',
  all_categories: '/marker/category/list',
  search: '/marker/search',
  list_by_poi_id: 'marker/list_by_poi_id'
};

export const size = {
  small: 'small',
  large: 'large'
};

export const response = {
  noDataFound: 'NOT_FOUND'
};

export const buttons = {
  askLater: 'Ask Me Later',
  cancel: 'Cancel',
  ok: 'ok'
};

export const location = {
  latitude: 'latitude',
  longitude: 'longitude'
};
