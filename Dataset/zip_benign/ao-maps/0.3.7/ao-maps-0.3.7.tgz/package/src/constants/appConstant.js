export const caching_time = 1440; // minutes to store routing list in cache
export const is_caching_enabled = true; // set to false if caching map layout isn't required
export const default_image_url = 'https://media-cdn.tripadvisor.com/media/photo-s/0e/cc/0a/dc/restaurant-chocolat.jpg';
export const default_opening_hours = '08:30-23:30';
export const default_poi_description = 'This is the placeholder description';
export const default_contact_number = '0312345678';
