module.exports = {
  root: true,
  "extends": ["eslint-config-leapfrog/react"],
  "parser": "babel-eslint",
  "rules": {
    "require-jsdoc": 0,
    "react/prop-types": 0,
    "ban-ts-ignore": 0,
    "camelcase": 0,
    "no-explicit-any": 0,
    "indent": ["error", 2],
    "explicit- member - accessibility": 0,
    "explicit-function-return-type": 0,
    "lines-between-class-members": 1
  },
  "env": {
    "es6": true
  }
};
