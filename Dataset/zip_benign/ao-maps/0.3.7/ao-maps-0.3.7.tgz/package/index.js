/**
 * @format
 */

import AOMap from "./src/screens/AOMap"

export default AOMap;
