# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [2.10.34](https://github.com/dfyn/smart-order-router/compare/v2.10.32...v2.10.34) (2023-06-15)


### Bug Fixes

* remove gas model in arb ([05ea453](https://github.com/dfyn/smart-order-router/commit/05ea453156b46996706caaa8dbe7b8c6a5080a78))

### [2.10.32](https://github.com/dfyn/smart-order-router/compare/v2.10.22...v2.10.32) (2023-06-14)

### [2.10.22](https://github.com/dfyn/smart-order-router/compare/v2.11.0...v2.10.22) (2023-06-14)

## 2.11.0 (2023-06-14)


### Features

* add network context to logs ([#163](https://github.com/dfyn/smart-order-router/issues/163)) ([d686a14](https://github.com/dfyn/smart-order-router/commit/d686a14a0d0cf248caf29bc1c0384c4d84719475))
* add stale config ([#116](https://github.com/dfyn/smart-order-router/issues/116)) ([3c4a32f](https://github.com/dfyn/smart-order-router/commit/3c4a32fc671ee1b57c48f494090caede2d5f776f))
* added ipfs subgraph support ([2375806](https://github.com/dfyn/smart-order-router/commit/2375806b96c1b189b6a2ba7299bd0ffbcdd3cf7d))
* **arbitrum:** arbitrum address change ([51cbad6](https://github.com/dfyn/smart-order-router/commit/51cbad696cb31dd9eb42d9b6ebf765856b5838af))
* **arbitrum:** multichain madness ([470f797](https://github.com/dfyn/smart-order-router/commit/470f79785af3933efd4a6a17e8f19189e51f6e77))
* exactOutput multiHop support ([aaabddb](https://github.com/dfyn/smart-order-router/commit/aaabddb0da402f04e05a311f2a8a16cadb48237b))
* exactOutputSingle support ([f274366](https://github.com/dfyn/smart-order-router/commit/f2743663cfd96d9218b203bccda1ce4fb7c1e1e5))
* export TokenValidatorProvider ([#110](https://github.com/dfyn/smart-order-router/issues/110)) ([53c6bef](https://github.com/dfyn/smart-order-router/commit/53c6befc4a78f814a80d510896e4c15da527151c))
* reduce approvals ([69d8463](https://github.com/dfyn/smart-order-router/commit/69d84631433d88e9d6eaf1130e42b30e6afe264f))
* reduce approvals for exactOutputSingle ([630bfa0](https://github.com/dfyn/smart-order-router/commit/630bfa01508b468bca6228443d8c2bfd4a45b21e))
* v2dfyn support for mixed quoter ([e12ec42](https://github.com/dfyn/smart-order-router/commit/e12ec428d5d77808372aecc7f2d9e81381d6ba07))


### Bug Fixes

* add export ([609ae40](https://github.com/dfyn/smart-order-router/commit/609ae40c4bb1af6a6cb682258f19171d427bdbf9))
* **arbitrum:** gas qoute fix ([22b488f](https://github.com/dfyn/smart-order-router/commit/22b488fff5989a2a968482b91bac8840349067d1))
* **arbitrum:** gas qoute fix ([7688dd1](https://github.com/dfyn/smart-order-router/commit/7688dd1de99f13724df7986d413fce881519682a))
* **bestroute.js:** fix bestroute ([7eaa3a4](https://github.com/dfyn/smart-order-router/commit/7eaa3a46ead93b569a08462de542b8ce50fd1538))
* calling deposit and swap ([1017ddd](https://github.com/dfyn/smart-order-router/commit/1017ddd871b7582b888d6e56570f1c7c4fbcdafd))
* consider v2dfyn for mixed route ([3b579df](https://github.com/dfyn/smart-order-router/commit/3b579df0a9b6b934630dde461339149a55f3de03))
* exactOut native output ([9a53435](https://github.com/dfyn/smart-order-router/commit/9a534351d7ceafe5194a5d4e96f8785429df096a))
* exactOut native output removed wmatic logic ([5b8835c](https://github.com/dfyn/smart-order-router/commit/5b8835c5d3dd3e9e3cd2cfb9aeba87acb3a85432))
* mixed routing encoding ([9abbe03](https://github.com/dfyn/smart-order-router/commit/9abbe03cfe781f22d1f4374f133486d44200b897))
* move prettier-plugin-organize-imports and sinon to dev dependencies ([#18](https://github.com/dfyn/smart-order-router/issues/18)) ([c9514cc](https://github.com/dfyn/smart-order-router/commit/c9514cc8ba87b62aedf1402cfd8188fc59d4a363))
* native and unWrap WETH ([bf1f39d](https://github.com/dfyn/smart-order-router/commit/bf1f39dd16c64ea6d7ff94191017b1af75e63c32))
* ready for swapRouter ([21a73a6](https://github.com/dfyn/smart-order-router/commit/21a73a6d28b1c97116812a5609b616e813e9613d))
* reduce approval for multiHop ([17e6c86](https://github.com/dfyn/smart-order-router/commit/17e6c8669a3768673d7dc6aaba35a31fc3fe40dc))
* reduce approvals for exactOut multihop ([9f0286e](https://github.com/dfyn/smart-order-router/commit/9f0286e2774d8180b18059eab395817e47e5da40))
* retain ethers as dep for factories ([#84](https://github.com/dfyn/smart-order-router/issues/84)) ([a24b0b2](https://github.com/dfyn/smart-order-router/commit/a24b0b2d6116fef9a7796cb5e090e8d0f2c956b0))
* single v2dfyn native input ([711cd9a](https://github.com/dfyn/smart-order-router/commit/711cd9adb597bc50afd31ae46d701e0c4f0adfb6))
* split tsconfig to reduce package size ([#85](https://github.com/dfyn/smart-order-router/issues/85)) ([3ebf637](https://github.com/dfyn/smart-order-router/commit/3ebf637290a8c3f3e3fef6f2c5f5a488bbc5825c))
* swapRouter bytes data encode bug ([a85b790](https://github.com/dfyn/smart-order-router/commit/a85b79022b32b0d8079aaf4118e0b269c356e78f))
* swapRouter for multi hop ([d57a6bd](https://github.com/dfyn/smart-order-router/commit/d57a6bdff0098fb2cce4d9904266c582a94b2103))
* tree-shake mnemonist ([#83](https://github.com/dfyn/smart-order-router/issues/83)) ([dc5ce16](https://github.com/dfyn/smart-order-router/commit/dc5ce16e560ecda5d81a6642ae963add21825d73))
* unwrapEth for output ([0eb66a7](https://github.com/dfyn/smart-order-router/commit/0eb66a70e63b65214ed36f917fafca3712393363))
* update  fork for compilation ([eea0c87](https://github.com/dfyn/smart-order-router/commit/eea0c878874a3f54b5b18a46307dabe8386a4056))
* update celo contract addresses ([#109](https://github.com/dfyn/smart-order-router/issues/109)) ([121e9ba](https://github.com/dfyn/smart-order-router/commit/121e9ba5fd37afaaeea65d0e92e9fdd599d7cbb2))
* update fork tar ([c5b482d](https://github.com/dfyn/smart-order-router/commit/c5b482d77e3be0ade17222210b2af55988a5185b))
* update to dfyn-v2-sdk ([586004d](https://github.com/dfyn/smart-order-router/commit/586004d722216091ea40b1597e9fa1f0396235f4))
* use DFYN_WMATIC for v1 gas calculations ([53d6ce8](https://github.com/dfyn/smart-order-router/commit/53d6ce8491c88dd5fbf99362198f5f43aa855c27))
* vault share conversions ([79df174](https://github.com/dfyn/smart-order-router/commit/79df174403e4cdc026d268540db0cf6bfa0a5b59))

### [2.10.1](https://github.com/Uniswap/smart-order-router/compare/v2.10.0...v2.10.1) (2022-10-12)

## [2.10.0](https://github.com/Uniswap/smart-order-router/compare/v2.9.3...v2.10.0) (2022-09-09)


### Features

* add network context to logs ([#163](https://github.com/Uniswap/smart-order-router/issues/163)) ([d686a14](https://github.com/Uniswap/smart-order-router/commit/d686a14a0d0cf248caf29bc1c0384c4d84719475))

### [2.9.3](https://github.com/Uniswap/smart-order-router/compare/v2.9.2...v2.9.3) (2022-08-17)

### [2.9.2](https://github.com/Uniswap/smart-order-router/compare/v2.9.1...v2.9.2) (2022-08-10)

### [2.9.1](https://github.com/Uniswap/smart-order-router/compare/v2.8.2...v2.9.1) (2022-08-10)

### [2.8.2](https://github.com/Uniswap/smart-order-router/compare/v2.8.1...v2.8.2) (2022-08-02)

### [2.8.1](https://github.com/Uniswap/smart-order-router/compare/v2.8.0...v2.8.1) (2022-07-31)

## [2.8.0](https://github.com/Uniswap/smart-order-router/compare/v2.6.1...v2.8.0) (2022-07-20)


### Features

* add stale config ([#116](https://github.com/Uniswap/smart-order-router/issues/116)) ([3c4a32f](https://github.com/Uniswap/smart-order-router/commit/3c4a32fc671ee1b57c48f494090caede2d5f776f))

## [2.7.0](https://github.com/Uniswap/smart-order-router/compare/v2.6.1...v2.7.0) (2022-07-14)


### Features

* add stale config ([#116](https://github.com/Uniswap/smart-order-router/issues/116)) ([3c4a32f](https://github.com/Uniswap/smart-order-router/commit/3c4a32fc671ee1b57c48f494090caede2d5f776f))

### [2.6.1](https://github.com/Uniswap/smart-order-router/compare/v2.6.0...v2.6.1) (2022-07-12)

## [2.6.0](https://github.com/Uniswap/smart-order-router/compare/v2.5.32...v2.6.0) (2022-07-07)


### Features

* export TokenValidatorProvider ([#110](https://github.com/Uniswap/smart-order-router/issues/110)) ([53c6bef](https://github.com/Uniswap/smart-order-router/commit/53c6befc4a78f814a80d510896e4c15da527151c))


### Bug Fixes

* update celo contract addresses ([#109](https://github.com/Uniswap/smart-order-router/issues/109)) ([121e9ba](https://github.com/Uniswap/smart-order-router/commit/121e9ba5fd37afaaeea65d0e92e9fdd599d7cbb2))

### [2.5.32](https://github.com/Uniswap/smart-order-router/compare/v2.5.31...v2.5.32) (2022-07-05)

### [2.5.31](https://github.com/Uniswap/smart-order-router/compare/v2.5.30...v2.5.31) (2022-07-01)

### [2.5.30](https://github.com/Uniswap/smart-order-router/compare/v2.5.29...v2.5.30) (2022-05-14)

### [2.5.29](https://github.com/Uniswap/smart-order-router/compare/v2.5.28...v2.5.29) (2022-05-14)

### [2.5.28](https://github.com/Uniswap/smart-order-router/compare/v2.5.27...v2.5.28) (2022-05-14)

### [2.5.27](https://github.com/Uniswap/smart-order-router/compare/v2.5.26...v2.5.27) (2022-05-13)

### [2.5.26](https://github.com/Uniswap/smart-order-router/compare/v2.5.25...v2.5.26) (2022-03-29)

### Bug Fixes

- split tsconfig to reduce package size ([#85](https://github.com/Uniswap/smart-order-router/issues/85)) ([3ebf637](https://github.com/Uniswap/smart-order-router/commit/3ebf637290a8c3f3e3fef6f2c5f5a488bbc5825c))

### [2.5.25](https://github.com/Uniswap/smart-order-router/compare/v2.5.24...v2.5.25) (2022-03-29)

### Bug Fixes

- retain ethers as dep for factories ([#84](https://github.com/Uniswap/smart-order-router/issues/84)) ([a24b0b2](https://github.com/Uniswap/smart-order-router/commit/a24b0b2d6116fef9a7796cb5e090e8d0f2c956b0))

### [2.5.24](https://github.com/Uniswap/smart-order-router/compare/v2.5.23...v2.5.24) (2022-03-28)

### Bug Fixes

- tree-shake mnemonist ([#83](https://github.com/Uniswap/smart-order-router/issues/83)) ([dc5ce16](https://github.com/Uniswap/smart-order-router/commit/dc5ce16e560ecda5d81a6642ae963add21825d73))

### [2.5.23](https://github.com/Uniswap/smart-order-router/compare/v2.5.22...v2.5.23) (2022-03-28)

### [2.5.22](https://github.com/Uniswap/smart-order-router/compare/v2.5.21...v2.5.22) (2022-03-18)

### [2.5.21](https://github.com/Uniswap/smart-order-router/compare/v2.5.19...v2.5.21) (2022-03-18)

### [2.5.19](https://github.com/Uniswap/smart-order-router/compare/v2.5.17...v2.5.19) (2022-02-22)

### [2.5.18](https://github.com/Uniswap/smart-order-router/compare/v2.5.17...v2.5.18) (2022-02-17)

### [2.5.17](https://github.com/Uniswap/smart-order-router/compare/v2.5.16...v2.5.17) (2022-02-17)

### [2.5.16](https://github.com/Uniswap/smart-order-router/compare/v2.5.14...v2.5.16) (2022-02-17)

### [2.5.14](https://github.com/Uniswap/smart-order-router/compare/v2.5.13...v2.5.14) (2022-02-01)

### [2.5.13](https://github.com/Uniswap/smart-order-router/compare/v2.5.12...v2.5.13) (2022-01-22)

### [2.5.12](https://github.com/Uniswap/smart-order-router/compare/v2.5.9...v2.5.12) (2022-01-13)

### [2.5.11](https://github.com/Uniswap/smart-order-router/compare/v2.5.9...v2.5.11) (2022-01-11)

### [2.5.10](https://github.com/Uniswap/smart-order-router/compare/v2.5.9...v2.5.10) (2022-01-11)

### [2.5.9](https://github.com/Uniswap/smart-order-router/compare/v2.5.4...v2.5.9) (2022-01-05)

### [2.5.8](https://github.com/Uniswap/smart-order-router/compare/v2.5.4...v2.5.8) (2022-01-04)

### [2.5.7](https://github.com/Uniswap/smart-order-router/compare/v2.5.4...v2.5.7) (2021-12-22)

### [2.5.5](https://github.com/Uniswap/smart-order-router/compare/v2.5.4...v2.5.5) (2021-12-22)

### [2.5.4](https://github.com/Uniswap/smart-order-router/compare/v2.5.1...v2.5.4) (2021-12-15)

### [2.5.2](https://github.com/Uniswap/smart-order-router/compare/v2.5.1...v2.5.2) (2021-12-15)

### [2.5.1](https://github.com/Uniswap/smart-order-router/compare/v2.4.5...v2.5.1) (2021-12-15)

### [2.4.5](https://github.com/Uniswap/smart-order-router/compare/v2.4.1...v2.4.5) (2021-12-15)

### Bug Fixes

- add export ([609ae40](https://github.com/Uniswap/smart-order-router/commit/609ae40c4bb1af6a6cb682258f19171d427bdbf9))

### [2.4.3](https://github.com/Uniswap/smart-order-router/compare/v2.4.1...v2.4.3) (2021-12-14)

### Bug Fixes

- add export ([609ae40](https://github.com/Uniswap/smart-order-router/commit/609ae40c4bb1af6a6cb682258f19171d427bdbf9))

### [2.4.1](https://github.com/Uniswap/smart-order-router/compare/v2.3.1...v2.4.1) (2021-12-14)

### [2.3.1](https://github.com/Uniswap/smart-order-router/compare/v2.2.3...v2.3.1) (2021-12-14)

### [2.2.3](https://github.com/Uniswap/smart-order-router/compare/v2.2.1...v2.2.3) (2021-12-14)

### [2.2.1](https://github.com/Uniswap/smart-order-router/compare/v2.1.1...v2.2.1) (2021-12-14)

### [2.1.1](https://github.com/Uniswap/smart-order-router/compare/v2.0.0-beta.18...v2.1.1) (2021-12-13)

### [2.0.5](https://github.com/Uniswap/smart-order-router/compare/v2.0.0-beta.18...v2.0.5) (2021-12-13)

### [2.0.3](https://github.com/Uniswap/smart-order-router/compare/v2.0.2...v2.0.3) (2021-12-06)

### [2.0.2](https://github.com/Uniswap/smart-order-router/compare/v2.0.0-beta.18...v2.0.2) (2021-12-06)

### [2.0.1](https://github.com/Uniswap/smart-order-router/compare/v2.0.0-beta.18...v2.0.1) (2021-12-02)

### [1.46.5](https://github.com/Uniswap/smart-order-router/compare/v1.46.4...v1.46.5) (2021-11-02)

### [1.46.4](https://github.com/Uniswap/smart-order-router/compare/v1.46.3...v1.46.4) (2021-10-25)

### [1.46.3](https://github.com/Uniswap/smart-order-router/compare/v1.46.1...v1.46.3) (2021-10-08)

### [1.46.1](https://github.com/Uniswap/smart-order-router/compare/v1.45.1...v1.46.1) (2021-10-06)

### Bug Fixes

- move prettier-plugin-organize-imports and sinon to dev dependencies ([#18](https://github.com/Uniswap/smart-order-router/issues/18)) ([c9514cc](https://github.com/Uniswap/smart-order-router/commit/c9514cc8ba87b62aedf1402cfd8188fc59d4a363))

### [1.45.1](https://github.com/Uniswap/smart-order-router/compare/v1.44.1...v1.45.1) (2021-09-28)

### [1.44.1](https://github.com/Uniswap/smart-order-router/compare/v1.43.1...v1.44.1) (2021-09-22)

### [1.43.1](https://github.com/Uniswap/smart-order-router/compare/v1.42.1...v1.43.1) (2021-09-22)

### [1.42.1](https://github.com/Uniswap/smart-order-router/compare/v1.41.1...v1.42.1) (2021-09-21)

### [1.41.1](https://github.com/Uniswap/smart-order-router/compare/v1.40.1...v1.41.1) (2021-09-21)

### [1.40.1](https://github.com/Uniswap/smart-order-router/compare/v1.39.1...v1.40.1) (2021-09-16)

### [1.39.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.38.1...v1.39.1) (2021-09-15)

### [1.38.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.37.1...v1.38.1) (2021-09-14)

### [1.37.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.36.1...v1.37.1) (2021-09-14)

### [1.36.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.35.1...v1.36.1) (2021-09-14)

### [1.35.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.34.1...v1.35.1) (2021-09-10)

### [1.34.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.33.1...v1.34.1) (2021-09-10)

### [1.33.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.32.1...v1.33.1) (2021-09-09)

### [1.32.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.31.1...v1.32.1) (2021-09-09)

### [1.31.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.30.1...v1.31.1) (2021-09-09)

### [1.30.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.29.1...v1.30.1) (2021-08-29)

### [1.29.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.28.1...v1.29.1) (2021-08-27)

### [1.28.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.27.1...v1.28.1) (2021-08-26)

### [1.27.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.25.1...v1.27.1) (2021-08-26)

### [1.26.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.25.1...v1.26.1) (2021-08-26)

### [1.25.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.24.1...v1.25.1) (2021-08-23)

### [1.24.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.23.1...v1.24.1) (2021-08-12)

### [1.23.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.22.1...v1.23.1) (2021-07-29)

### [1.22.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.21.1...v1.22.1) (2021-07-29)

### [1.21.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.20.1...v1.21.1) (2021-07-29)

### [1.20.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.18.1...v1.20.1) (2021-07-27)

### [1.19.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.18.1...v1.19.1) (2021-07-26)

### [1.18.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.14.1...v1.18.1) (2021-07-26)

### [1.17.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.14.1...v1.17.1) (2021-07-23)

### [1.16.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.14.1...v1.16.1) (2021-07-22)

### [1.15.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.14.1...v1.15.1) (2021-07-21)

### [1.14.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.13.1...v1.14.1) (2021-07-20)

### [1.13.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.12.1...v1.13.1) (2021-07-19)

### [1.12.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.11.1...v1.12.1) (2021-07-19)

### [1.11.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.10.1...v1.11.1) (2021-07-14)

### [1.10.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.9.1...v1.10.1) (2021-07-14)

### [1.9.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.8.1...v1.9.1) (2021-07-05)

### [1.8.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.7.1...v1.8.1) (2021-06-28)

### [1.7.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.6.1...v1.7.1) (2021-06-27)

### [1.6.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.5.3...v1.6.1) (2021-06-26)

### [1.5.3](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.5.1...v1.5.3) (2021-06-23)

### [1.5.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.4.1...v1.5.1) (2021-06-23)

### [1.4.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.3.1...v1.4.1) (2021-06-21)

### [1.3.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.2.1...v1.3.1) (2021-06-15)

### [1.2.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.1.1...v1.2.1) (2021-06-11)

### [1.1.1](https://github.com/Uniswap/uniswap-smart-order-router/compare/v1.0.1...v1.1.1) (2021-06-09)

### 1.0.1 (2021-05-06)
