const isProbablyOdd = require("./index");

describe("isProbablyOdd", () => {
  test("returns an object with the correct structure", () => {
    const result = isProbablyOdd(5);
    expect(result).toHaveProperty("number", 5);
    expect(result).toHaveProperty("isOdd");
    expect(typeof result.isOdd).toBe("boolean");
    expect(result).toHaveProperty("conf");
    expect(result.conf).toBe(0.5);
  });

  test("accepts different numbers as input", () => {
    const numbers = [1, 2, 3, 4, 5];
    numbers.forEach((num) => {
      const result = isProbablyOdd(num);
      expect(result.number).toBe(num);
      expect(typeof result.isOdd).toBe("boolean");
      expect(result.conf).toBe(0.5);
    });
  });

  test("handles edge cases", () => {
    const edgeCases = [0, -1, 1.5, Number.MAX_SAFE_INTEGER];
    edgeCases.forEach((num) => {
      const result = isProbablyOdd(num);
      expect(result.number).toBe(num);
      expect(typeof result.isOdd).toBe("boolean");
      expect(result.conf).toBe(0.5);
    });
  });
});
