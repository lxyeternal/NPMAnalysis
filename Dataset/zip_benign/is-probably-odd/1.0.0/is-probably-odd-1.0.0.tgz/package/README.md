# is-probably-odd

A fun npm package that tells you if a number is odd... probably! It always returns with 50% confidence, because why not?

## Installation

```bash
npm install is-probably-odd
```

## Usage

```javascript
const isProbablyOdd = require("is-probably-odd");

const result = isProbablyOdd(5);
console.log(result);
// {
//   number: 5,
//   isOdd: true,
//   conf: 0.5
// }
```

## API

### isProbablyOdd(number)

Returns an object containing:

- `number`: The original input number
- `isOdd`: A boolean indicating whether the number is probably odd
- `conf`: Confidence score (always 0.5, because we're only 50% sure!)

## License

MIT

## Contributing

1. Fork the repository
2. Create a new branch
3. Make your changes
4. Submit a pull request

## PS

This package is a joke.
