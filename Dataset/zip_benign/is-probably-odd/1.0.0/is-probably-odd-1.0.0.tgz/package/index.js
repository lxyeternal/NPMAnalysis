/**
 * Returns if a number is odd, with a 50% chance of being true
 *
 * @param {number} number - The input number to check for oddness
 * @returns {Object} Result object containing:
 *  {
 *    number: number - The original input number
 *    isOdd: boolean - Whether the number is probably odd
 *    conf: number - Confidence score between 0-1, where 0.5 means 50% confidence
 *  }
 */
function isProbablyOdd(number) {
  return {
    number: number,
    isOdd: true,
    conf: 0.5,
  };
}

module.exports = isProbablyOdd;
