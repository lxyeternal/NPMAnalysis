import { JitProxyClient, PriceType } from '../jitProxyClient';
import { PublicKey } from '@solana/web3.js';
import { AuctionSubscriber, BN, DriftClient, Order, PostOnlyParams, SwiftOrderSubscriber, SlotSubscriber, SignedMsgOrderParams, UserAccount, UserStatsMap } from '@drift-labs/sdk';
export type UserFilter = (userAccount: UserAccount, userKey: string, order: Order) => boolean;
export type JitParams = {
    bid: BN;
    ask: BN;
    minPosition: BN;
    maxPosition: any;
    priceType: PriceType;
    subAccountId?: number;
    postOnlyParams?: PostOnlyParams;
};
export declare abstract class BaseJitter {
    auctionSubscriber: AuctionSubscriber;
    swiftOrderSubscriber: SwiftOrderSubscriber;
    slotSubscriber: SlotSubscriber;
    driftClient: DriftClient;
    jitProxyClient: JitProxyClient;
    auctionSubscriberIgnoresSwiftOrders?: boolean;
    userStatsMap: UserStatsMap;
    perpParams: Map<number, JitParams>;
    spotParams: Map<number, JitParams>;
    seenOrders: Set<string>;
    onGoingAuctions: Map<string, Promise<void>>;
    userFilter: UserFilter;
    computeUnits: number;
    computeUnitsPrice: number;
    constructor({ auctionSubscriber, jitProxyClient, driftClient, userStatsMap, swiftOrderSubscriber, slotSubscriber, auctionSubscriberIgnoresSwiftOrders, }: {
        driftClient: DriftClient;
        auctionSubscriber: AuctionSubscriber;
        jitProxyClient: JitProxyClient;
        userStatsMap: UserStatsMap;
        swiftOrderSubscriber?: SwiftOrderSubscriber;
        slotSubscriber?: SlotSubscriber;
        auctionSubscriberIgnoresSwiftOrders?: boolean;
    });
    subscribe(): Promise<void>;
    createTryFill(taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string): () => Promise<void>;
    createTrySignedMsgFill(authorityToUse: PublicKey, signedMsgOrderParams: SignedMsgOrderParams, uuid: Uint8Array, taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string, marketIndex: number): () => Promise<void>;
    deleteOnGoingAuction(orderSignature: string): void;
    getOrderSignatures(takerKey: string, orderId: number): string;
    private convertUuidToNumber;
    updatePerpParams(marketIndex: number, params: JitParams): void;
    updateSpotParams(marketIndex: number, params: JitParams): void;
    setUserFilter(userFilter: UserFilter | undefined): void;
    setComputeUnits(computeUnits: number): void;
    setComputeUnitsPrice(computeUnitsPrice: number): void;
}
