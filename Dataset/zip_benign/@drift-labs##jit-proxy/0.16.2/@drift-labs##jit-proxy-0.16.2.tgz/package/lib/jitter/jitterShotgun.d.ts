import { JitProxyClient } from '../jitProxyClient';
import { PublicKey } from '@solana/web3.js';
import { AuctionSubscriber, DriftClient, Order, SlotSubscriber, SignedMsgOrderParams, SwiftOrderSubscriber, UserAccount, UserStatsMap } from '@drift-labs/sdk';
import { BaseJitter } from './baseJitter';
export declare class JitterShotgun extends BaseJitter {
    constructor({ auctionSubscriber, jitProxyClient, driftClient, userStatsMap, swiftOrderSubscriber, slotSubscriber, auctionSubscriberIgnoresSwiftOrders, }: {
        driftClient: DriftClient;
        auctionSubscriber: AuctionSubscriber;
        jitProxyClient: JitProxyClient;
        userStatsMap?: UserStatsMap;
        swiftOrderSubscriber?: SwiftOrderSubscriber;
        slotSubscriber?: SlotSubscriber;
        auctionSubscriberIgnoresSwiftOrders?: boolean;
    });
    createTryFill(taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string): () => Promise<void>;
    createTrySignedMsgFill(authorityToUse: PublicKey, signedMsgOrderParams: SignedMsgOrderParams, uuid: Uint8Array, taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string, marketIndex: number): () => Promise<void>;
}
