## 初始化
<br/>
安装依赖

```bash
$ npm i zxf-utils
```

导入方法

```bash
import { throttle } from 'zxf-utils'
```
<br/>

## debounce 防抖
Function 回调函数<br/>Number 等待时长(ms)
```bash
debounce(() => default, 2000)
```

## throttle 节流
Function 回调函数<br/>Number 延时时长(ms)
```bash
throttle(() => default, 2000)
```

## getRawType 判断数据类型
Any 源数据
```bash
getRawType({a:123})
// Object

getRawType(/1/g)
// RegExp
```

## platformType 判断运行浏览器平台类型
String 判断匹配平台<br/>'isWx' | 'wxPlatform' | 'isIE' | 'isIE9' | 'isEdge' | 'isAndroid' | 'isIOS' | 'isChrome'
```bash
platformType('isIOS')
// false

platformType('wxPlatform')
// android || ios
```

## getUrlParam 获取url参数
String url路径
```bash
getUrlParam('https://www.baidu.com?a=123')
// {a:123}
```

## accDiv JS除法运算
Number 参数1<br/>Number 参数2
```bash
accDiv(1,2)
// 0.5
```

## accMul JS乘法运算
Number 参数1<br/>Number 参数2
```bash
accMul(1,2)
// 2
```

## accAdd JS加法运算
Number 参数1<br/>Number 参数2
```bash
accAdd(1,2)
// 3
```

## accSubtr JS减法运算
Number 参数1<br/>Number 参数2
```bash
accSubtr(1,2)
// -1
```