module.exports = {
    verbose: true
};