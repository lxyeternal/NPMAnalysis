###自定义滚动条

#####增加样式
```
.scroll-field {
            width: 4px;
            bottom: 8px;
            position: absolute;
            top: 8px;
            right: 4px;
            border-radius: 2px;
            background-color: #f1f1f1;
        }
        .scroll-field .scroll-btn {
            width: 4px;
            height: 10px;
            background: #353535;
            opacity: 0.3;
            border-radius: 2px;
            position: relative;
        }
        .scroll-field .scroll-btn:hover{
            opacity: 0.5;
            cursor: pointer;
        }
```
#####引入js:
```
<script src="../src/customScrollbar.js"></script>
```
#####调用：
```
var scroll = new customScroll({
        parentDom: 父元素,
        contentDom: 滚动的内容元素
    });
```