(function (window,undefind) {
    //滚轮事件 火狐：DOMMouseScroll(必须用2级事件写) 其余：onmousewheel(一级事件，用2级事件写也可以：mousewheel)  
    //火狐中:e.detail>0时向下滚动，e.detail<0时向上滚动  
    //其余浏览器包括IE: e.wheelDelta<0时表示向下滚动，e.wheelDelta>0时向上滚动
    var fn = {
        setClass: function (element, className) {
            if (typeof element === 'string') {
                element = document.createElement(element);
            }
            element.className = className;
            return element;
        },
        hasClass: function (element, className) {
            if (!element || element.nodeType !== 1)//让异常通过，外面不进行处理
                return true;
            var elementClassName = element.className;
            if (elementClassName.length < 1) {
                return false;
            }
            if (elementClassName == className || elementClassName.match(new RegExp("(^|\\s)" + className + "(\\s|$)"))) {
                return true;
            }
            return false;
        },
        addClass: function (element, className) {
            if (!fn.hasClass(element, className)) {
                if (element.className.length < 1) {
                    element.className = className;
                } else {
                    element.className += ' ' + className;
                }
            }
            return element;
        },
        removeClass: function (element, className) {
            if (fn.hasClass(element, className)) {
                var reg = new RegExp("(^|\\s)" + className + "(\\s|$)");
                element.className = element.className.replace(reg, '');
            }
            return element;
        },
        css: function (element, key) {
            return element.currentStyle ? element.currentStyle[key] : document.defaultView.getComputedStyle(element, false)[key];
        },
        addEvent: function (element, type, fn) {
            if (element.attachEvent) {
                element['e' + type + fn] = fn;
                element[type + fn] = function () { element['e' + type + fn](window.event); }
                element.attachEvent('on' + type, element[type + fn]);
            } else if (element.addEventListener) {
                element.addEventListener(type, fn, false);
            }
        },
        addScrollEvent: function (element, fn) {
            var bindScrollFn = function (e) {
                e = e || window.event;
                //判断滚轮滚动方向：Firefox和其他浏览器不同
                e.wheel = (e.wheelDelta ? e.wheelDelta : -e.detail) > 0 ? 1 : -1; // 通过事件判断鼠标滚轮反向，1是向上，-1是向下
                //阻止浏览器默认行为
                if (e.preventDefault) { //ff
                    e.preventDefault();
                } else {
                    e.returnValue = false; //ie
                }
                fn.call(element, e);
            }
            if (document.addEventListener) {
                //ff
                element.addEventListener('DOMMouseScroll', bindScrollFn, false);
                //w3c
                element.addEventListener('mousewheel', bindScrollFn, false);
            } else//ie
            {
                element.attachEvent('onmousewheel', bindScrollFn);
            }
        },
        getEvent: function () {
            if (document.all) {
                return window.event;
            }
            func = getEvent.caller;
            while (func != null) {
                var arg0 = func.arguments[0];
                if (arg0) {
                    if ((arg0.constructor == Event || arg0.constructor == MouseEvent) || (typeof (arg0) == "object" && arg0.preventDefault && arg0.stopPropagation)) {
                        return arg0;
                    }
                }
                func = func.caller;
            }
            return null;
        },
        getMousePos: function (ev) {
            if (!ev) {
                ev = currScroll.getEvent();
            }
            if (ev.pageX || ev.pageY) {
                return {
                    x: ev.pageX,
                    y: ev.pageY
                };
            }
            if (document.documentElement && document.documentElement.scrollTop) {
                return {
                    x: ev.clientX + document.documentElement.scrollLeft - document.documentElement.clientLeft,
                    y: ev.clientY + document.documentElement.scrollTop - document.documentElement.clientTop
                };
            }
            else if (document.body) {
                return {
                    x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
                    y: ev.clientY + document.body.scrollTop - document.body.clientTop
                };
            }
        },
        extend: function (oldObj, newObj) {
            var tempObj = fn.clone(oldObj);
            for (var key in newObj) {
                if (newObj.hasOwnProperty(key) && !tempObj.hasOwnProperty(key)) {
                    tempObj[key] = newObj[key];
                }
            }
            return tempObj;
        },
        clone: function (obj) {
            function Clone() { }
            Clone.prototype = obj;
            var newObj = new Clone();
            for (var key in newObj) {
                if (typeof newObj[key] == "object") {
                    newObj[key] = fn.clone(newObj[key]);
                }
            }
            return newObj;
        },
        convertValue: function (value) {
            var reg = /^\d+$/g;
            if (typeof (value) === 'number' || reg.test(value)) {
                return value + 'px';
            } else
                return value;
        }
    };
    var customScroll = function (options) {
        customScroll.prototype.init(options);
    }
    customScroll.prototype = {
        init: function (options) {
            this.options = fn.extend({},options);
            this.parentDom = this.options.parentDom;
            this.contentDom = this.options.contentDom;

            var scrollField = document.createElement('div');
            var scrollBtn = document.createElement('div');
            scrollField.className = 'scroll-field';
            scrollBtn.className = 'scroll-btn';
            scrollField.appendChild(scrollBtn);
            this.scrollBox = scrollField;
            this.scrollBtn = (this.scrollBox.querySelectorAll('.scroll-btn'))[0];
            this.parentDom.appendChild(this.scrollBox);
            this.parentDom.style.position = 'relative';
            this.parentDom.style.overflow = 'hidden';
            this.contentDom.style.position = 'relative';
            this.change();
            this.addEvent();
        },
        change: function () {
            this.startTop = 0;
            this.endTop = this.scrollBox.style.top?this.scrollBox.style.top:0;

            var pClientH = this.options.parentDom.clientHeight,
                cOffsetH = this.options.contentDom.offsetHeight,
                cClientH = this.options.contentDom.clientHeight,
                sOffsetH = this.scrollBox.offsetHeight;
            this.scrollRadix = cOffsetH / sOffsetH;

            this.scrollBtn.style.height = sOffsetH*(pClientH/cOffsetH)+'px';
            if(cOffsetH < pClientH){
                this.scrollBox.style.display = 'none';
            }else {
                this.scrollBox.style.display = 'block';

                this.limit = cOffsetH - pClientH;
            }


        },
        addEvent: function () {
            var _self = this;
            fn.addScrollEvent(_self.contentDom, function (e) {

                if (e.wheel > 0) {//滚轮向上滚动
                    var currTop = _self.endTop -= 1;
                    _self.scrollEvent(currTop);
                } else {//滚轮向下滚动
                    var currTop = _self.endTop += 1;
                    _self.scrollEvent(currTop);
                }
            });
            fn.addEvent(_self.scrollBox,'mousedown',function (e) {
                _self.mouseDown(e);
            });
            fn.addEvent(_self.scrollBox, 'mouseup', function (e) {
                _self.mouseUp(e);
            });
            fn.addEvent(document.body, 'mousemove', function (e) {
                if (_self.isDrag) {
                    //获取当前鼠标位置
                    var position = fn.getMousePos(e).y;
                    var currTop = (_self.endTop + position - _self.startTop);
                    _self.scrollEvent(currTop);
                }
            });
        },
        scrollEvent: function (currTop) {
            var _self = this;
            if( currTop < 0){
                currTop = 0
            }else if(currTop >= (_self.limit/_self.scrollRadix)){
                currTop = _self.limit/_self.scrollRadix;
            }
            _self.scrollBtn.style.top = currTop+'px';
            _self.contentDom.style.top = currTop * (- _self.scrollRadix)+'px';
        },
        mouseUp: function (e) {
            this.isDrag = false;
            this.startTop = fn.getMousePos(e).y;
        },
        mouseDown: function (e) {
            this.isDrag = true;
            this.startTop = fn.getMousePos(e).y;
        }
    };
    window.customScroll = customScroll;
})(window)