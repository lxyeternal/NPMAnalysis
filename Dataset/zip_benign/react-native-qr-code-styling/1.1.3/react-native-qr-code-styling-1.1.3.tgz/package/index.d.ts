import * as React from "react";

declare class QRGenerator extends React.PureComponent<QRGeneratorProps, any> { }

export type dotTypeValues =
    | "rounded"
    | "dots"
    | "classy"
    | "classy-rounded"
    | "square"
    | "extra-rounded";

export type cornerSquareTypeValues = "dots" | "square" | "extra-rounded";

export type cornerDotTypeValues = "dots" | "square";

export type QROptionsMode = "Numeric" | "Alphanumeric" | "Byte" | "Kanji";

export type ErrorCorrectionLevelType = "L" | "M" | "Q" | "H";

export type QRGeneratorType = "svg" | "canvas";

export type GradientType = "linear" | "radial";

export type CrossOriginType = "anonymous" | "use-credentials";

export type QROptionsTypeNumber =
    | 0
    | 1
    | 2
    | 3
    | 4
    | 5
    | 6
    | 7
    | 8
    | 9
    | 10
    | 11
    | 12
    | 13
    | 14
    | 15
    | 16
    | 17
    | 18
    | 19
    | 20
    | 21
    | 22
    | 23
    | 24
    | 25
    | 26
    | 27
    | 28
    | 29
    | 30
    | 31
    | 32
    | 33
    | 34
    | 35
    | 36
    | 37
    | 38
    | 39
    | 40;

export interface ColorStopsProps {
    offset?: number;
    color?: string;
}

export interface GradientProps {
    type?: GradientType;
    rotation?: number;
    colorStops?: Array<ColorStopsProps>;
}

export interface DotOptionsProps {
    type?: dotTypeValues;
    color?: string;
    gradient?: GradientProps;
}

export interface CornerSquareOptionsProps {
    type?: cornerSquareTypeValues;
    color?: string;
    gradient?: GradientProps;
}

export interface CornerDotOptionsProps {
    type?: cornerDotTypeValues;
    color?: string;
    gradient?: GradientProps;
}

export interface BackgroundOptionsProps {
    color?: string;
    gradient?: GradientProps;
}

export interface ImageOptionsProps {
    hideBackgroundDots?: boolean;
    imageSize?: number;
    margin?: number;
    crossOrigin?: CrossOriginType;
}

export interface QROptionsProps {
    typeNumber?: QROptionsTypeNumber;
    mode?: QROptionsMode;
    errorCorrectionLevel?: ErrorCorrectionLevelType;
}

export interface QRGeneratorProps {
    value: string;
    type?: QRGeneratorType;
    width: number;
    height: number;
    borderRadius?: number;
    image?: string;
    dotOptions?: DotOptionsProps;
    cornerSquareOptions?: CornerSquareOptionsProps;
    cornerDotOptions?: CornerDotOptionsProps;
    backgroundOptions?: BackgroundOptionsProps;
    imageOptions?: ImageOptionsProps;
    qrOptions?: QROptionsProps;
    getBase64DataImage?: (value: string) => void;
}


export default QRGenerator;