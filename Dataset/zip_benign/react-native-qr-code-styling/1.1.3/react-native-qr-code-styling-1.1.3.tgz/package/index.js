import QRGenerator from './src/QRGenerator';
export default QRGenerator;