class HelloWorld
  @test: 'test'