var tryparse = require('try-parse');
process.env = tryparse.parse(process.env);

var cc = require('config-chain');
var path = require('path');
var opts = require('optimist').argv;
var env = opts.env || process.env.NODE_ENV || 'development';

var configWithEnv = path.join(__dirname, './config/', env+'.json');
var configDefault = path.join(__dirname,  './config/', 'default.json');
var logFile = path.join(process.cwd(), env+'.log');

var conf = cc(opts, cc.env('searchlight_'), configWithEnv, configDefault, {logFile: logFile});


var out = conf.snapshot;
delete out.$0;

module.exports = out;