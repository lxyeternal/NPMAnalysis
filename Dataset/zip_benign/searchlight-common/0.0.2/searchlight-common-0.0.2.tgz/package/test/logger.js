var should = require('should');
require('mocha');

var common = require('../');
var config = common.config;
var logger = common.logger;

describe('common - loggly logging', function() {
  it('loggly should log', function(done) {
    should.exist(config);
    should.exist(logger);
    logger.log('info', "testing app logging", {test:"foo"}, function(err){
      should.not.exist(err);
      done();
    });
  });
});