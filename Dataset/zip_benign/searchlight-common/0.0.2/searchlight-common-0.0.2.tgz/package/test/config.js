var should = require('should');
require('mocha');

var common = require('../');
var config = common.config;

describe('common - config loading', function() {
  it('should have loaded the config correctly', function(done) {
    should.exist(config);
    should.exist(config.mongodb, 'mongodb');
    should.exist(config.mongodb.uri, 'mongodb.uri');
    should.exist(config.mysql, 'mysql');
    should.exist(config.mysql.uri, 'mysql.uri');
    should.exist(config.elasticSearch, 'elasticSearch');
    should.exist(config.elasticSearch.host, 'elasticSearch.host');
    should.exist(config.elasticSearch.port, 'elasticSearch.port');
    should.exist(config.batchSize, 'batchSize');
    should.exist(config.interval, 'interval');
    done();
  });
});

describe('common - database loading', function() {
  it('should have loaded the databases', function(done) {
    should.exist(common.mongo, 'mongodb');
    should.exist(common.mysql, 'mysql');
    should.exist(common.elasticSearch, 'elasticSearch');
    done();
  });
});