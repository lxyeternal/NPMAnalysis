var fs = require('fs');
var path = require('path');

var config = require('./config');
var logger = require('./lib/logger');

var elasticSearch = require('./lib/elasticSearch');
var mongo = require('./lib/mongodb');
var mysql = require('./lib/mysql');

var mongoData = require('./seed/mongo');
var esData = require('./seed/elasticSearch');
var sqlPath = path.join(__dirname, "./seed/mysql.sql");
var sqlData = String(fs.readFileSync(sqlPath));

module.exports = {
  config: config,
  logger: logger,
  mongo: mongo,
  elasticSearch: elasticSearch,
  mysql: mysql,
  fixtures: {
    mysql: sqlData,
    mongo: mongoData,
    elasticSearch: esData
  }
};