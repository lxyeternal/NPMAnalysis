var fs = require('fs');
var path = require('path');
var outpath = path.join(__dirname, "../seed/mongo.json");
var outpath2 = path.join(__dirname, "../seed/elasticSearch.json");

var urls = require("../seed/mongo.json");
var docs = require("../seed/elasticSearch.json");

var before = urls.length;

// fix URLs that dont have page_keys pointing to valid ES docs
var validPageKeys = docs.map(function(d){
  return d._id;
});

var nurls = urls.filter(function(url){
  if (!url.page_key) return true;
  var isGood = (validPageKeys.indexOf(url.page_key) !== -1);
  return isGood;
});

var after = nurls.length;

fs.writeFileSync(outpath, JSON.stringify(nurls, null, 2));

console.log("Found", before-after, "broken URL references");

// remove ES docs that don't have valid URLs

var before2 = docs.length;

// fix URLs that dont have page_keys pointing to valid ES docs
var validURLIds = urls.map(function(d){
  return d._id;
});

var ndocs = docs.filter(function(doc){
  return validURLIds.indexOf(doc.url_id) !== -1;
});

var after2 = ndocs.length;

fs.writeFileSync(outpath2, JSON.stringify(ndocs, null, 2));

console.log("Found", before2-after2, "broken ES references");
