var elasticSearch = require('../lib/elasticSearch');
var fs = require('fs');
var path = require('path');
var outpath = path.join(__dirname, "../seed/elasticSearch.json");

elasticSearch.dump(function(err, res) {
  if (err) return console.log(err);
  console.log(res);
  fs.writeFileSync(outpath, JSON.stringify(res, null, 2));
  process.exit();
});