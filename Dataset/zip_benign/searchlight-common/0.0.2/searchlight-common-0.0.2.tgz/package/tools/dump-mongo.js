var mongo = require('../lib/mongodb');
var fs = require('fs');
var path = require('path');
var outpath = path.join(__dirname, "../seed/mongo.json");

mongo.dump('URL', function(err, docs) {
  if (err) return console.log(err);
  fs.writeFileSync(outpath, JSON.stringify(docs, null, 2));
  process.exit();
});