var mysql = require('../lib/mysql');
var fs = require('fs');
var path = require('path');
var outPath = path.join(__dirname, "../seed/mysql.sql");

mysql.dump(function(err, dump){
  if (err) return console.log(err);
  fs.writeFileSync(outPath, dump);
});