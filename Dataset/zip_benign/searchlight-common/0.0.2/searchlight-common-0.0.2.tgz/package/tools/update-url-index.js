// run this from the shell

// count how many docs we are about to update
db.urls.count({random: {$exists: false}});

// add this random field to all existing urls that dont have it
db.urls.find({random: {$exists: false}}).forEach(function(url){
  url.random = [Math.random(), 0];
  db.urls.save(url);
});

/*
RUN TO WIPE RANDOM FIELD
ONY USE THIS IN CASE THE PREVIOUS QUERY FAILED

db.urls.find().forEach(function(url){
  delete url.random;
  db.urls.save(url);
});
*/


// index this field so queries start working
db.urls.ensureIndex({random: '2d'});