import { GuardOptions } from './interface/guard.options';
import { Worker } from './worker';
import { Script } from './script';
import { WorkerHost } from './interface/WorkerHost';
import { CGroups } from './external/cgroups';
export declare class VmGuard implements WorkerHost {
    workers: Worker[];
    pendingScripts: Script[];
    options: GuardOptions;
    cgroups: CGroups;
    private onControlGroupCreated;
    private isControlGroupCreated;
    constructor(options?: GuardOptions);
    private waitingCGroupCreated;
    run(script: string, path?: string): Promise<any>;
    get isAllWorkersFree(): boolean;
    onWorkerActive(worker: Worker): void;
    private waitingSynchronousResolvers;
    private startWaitingSynchronous;
    private endWaitingSynchronous;
    private newWorker;
    getWorker(): Promise<Worker>;
    getActivityWorker(): Worker;
    releaseAllWorker(): void;
    adjustWorks(): void;
    onWorkerDestroy(worker: Worker): void;
    private createControlGroup;
}
