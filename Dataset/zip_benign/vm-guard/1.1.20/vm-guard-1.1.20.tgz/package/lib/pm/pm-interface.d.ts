export interface PmOptions {
    concurrency?: number;
    memoryQuota?: number;
    cpuQuota?: number;
    noHardwareLimit?: boolean;
    latencyTime?: number;
}
export declare enum ProcessEventType {
    CALL_CHILD = 0,
    CALL_PARENT = 1,
    CHILD_RETURN = 2,
    PARENT_RETURN = 3
}
