import { PmOptions } from './pm-interface';
import { CallableChildProcess } from './callable-child-process';
export declare class ProcessManager {
    private options;
    private processes;
    constructor(options?: PmOptions);
    private cpFunctions;
    getProcess(): Promise<any>;
    fetchProcess(cp: CallableChildProcess): Promise<CallableChildProcess>;
    load(scriptPath: string): Promise<any>;
    exec(path: string, method: string, args?: any[]): Promise<any>;
}
