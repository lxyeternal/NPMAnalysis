/// <reference types="node" />
import { CallableProcess } from './callable-process';
import { ChildProcess } from 'child_process';
import { ProcessEventType } from './pm-interface';
export declare class CallableChildProcess extends CallableProcess {
    origin: ChildProcess;
    protected callInType: ProcessEventType;
    protected callOutType: ProcessEventType;
    protected responseType: ProcessEventType;
    protected returnType: ProcessEventType;
    constructor(origin: ChildProcess);
    protected isAvailable(): boolean;
    get pid(): number;
    get connected(): boolean;
    destroy(): void;
}
