import { ProcessEventType } from './pm-interface';
declare type PromiseFunction<T = any> = (...args: any[]) => Promise<T>;
export declare abstract class CallableProcess {
    origin: any;
    caller: {
        [key: string]: PromiseFunction;
    };
    protected pendingCalls: any[];
    respondent: {
        [key: string]: (...args: any[]) => any;
    };
    protected abstract callOutType: ProcessEventType;
    protected abstract callInType: ProcessEventType;
    protected abstract returnType: ProcessEventType;
    protected abstract responseType: ProcessEventType;
    protected constructor(origin: any);
    private initRespondent;
    protected isAvailable(): boolean;
    addFunctions(map?: {}): void;
    private initCaller;
}
export {};
