/// <reference types="node" />
import { CallableProcess } from './callable-process';
import { ProcessEventType } from './pm-interface';
export declare class CallablePrimaryProcess extends CallableProcess {
    origin: NodeJS.Process;
    protected callInType: ProcessEventType;
    protected callOutType: ProcessEventType;
    protected responseType: ProcessEventType;
    protected returnType: ProcessEventType;
    constructor(origin: NodeJS.Process);
    get pid(): number;
}
