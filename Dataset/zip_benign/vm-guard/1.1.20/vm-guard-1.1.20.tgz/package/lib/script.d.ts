import { Worker } from './worker';
export declare class Script {
    content: string;
    timeout: number;
    path?: string;
    private resolve;
    private reject;
    private promise;
    private timeoutId;
    private worker;
    constructor(content: string, timeout?: number, path?: string);
    bindWorker(worker: Worker): void;
    getScriptResult(): Promise<any>;
    assertStart(): Promise<any>;
    private assertStop;
    defer(r: any): void;
    error(r: any): void;
    private clearDefers;
}
