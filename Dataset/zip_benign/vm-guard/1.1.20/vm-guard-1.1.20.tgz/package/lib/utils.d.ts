export declare function firstSuccessPromise(promises: any): Promise<unknown>;
export declare function wait(ms: any): Promise<unknown>;
