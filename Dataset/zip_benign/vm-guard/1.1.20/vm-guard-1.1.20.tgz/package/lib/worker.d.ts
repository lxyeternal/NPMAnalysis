/// <reference types="node" />
import { ProcessState } from './enum/process.state';
import { ChildProcess } from 'child_process';
import { GuardOptions } from './interface/guard.options';
import { Script } from './script';
import { WorkerHost } from './interface/WorkerHost';
export declare class Worker {
    private options?;
    pid: number;
    state: ProcessState;
    runner: string;
    process: ChildProcess;
    host: WorkerHost;
    currentScript: Script;
    constructor(options?: GuardOptions, runner?: string);
    bindHost(host: WorkerHost): void;
    private initProcess;
    defer(r: any): void;
    deferError(e: any): void;
    private startListenEvent;
    private finishScript;
    private run;
    runScript(script: Script): Promise<any>;
    destroy(): boolean;
}
