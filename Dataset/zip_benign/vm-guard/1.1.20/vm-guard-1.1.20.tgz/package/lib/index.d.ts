import { GuardOptions } from './interface/guard.options';
export * from './vm.guard';
export * as cGuard from './simple-run';
export { Configuration } from 'log4js';
export declare function runInProcess(script: string, options?: GuardOptions, path?: string): Promise<any>;
