export declare enum ProcessState {
    PREPARE = 0,
    ACTIVE = 1,
    RUNNING = 2,
    DESTROY = 3
}
