export declare enum ProcessMessageType {
    READY = 0,
    RUN_SCRIPT = 1,
    RETURN = 2,
    SCRIPT_ERROR = 3
}
