import { SimpleRunOptions } from '../simple-run';
import { ProcessManager } from '../pm/process-manager';
export declare class VmGuard extends ProcessManager {
    timeout: number;
    run(script: string, options?: SimpleRunOptions): Promise<any>;
}
