import { NodeVMOptions } from '@palerock/vm2';
import { ModuleStringMatcher } from './interface/guard.options';
import { Configuration } from 'log4js';
export interface SimpleRunOptions extends NodeVMOptions {
    sandbox?: {
        [key: string]: any;
    };
    allowedVariables?: Array<string | RegExp>;
    allowedModules?: ModuleStringMatcher[];
    allowInnerRunner?: boolean;
    innerRunnerName?: string;
    compilePath?: Array<string | RegExp>;
    legacyRequire?: boolean;
    compatibleRequire?: boolean;
    moduleName?: string;
    loggerConfigure?: Configuration;
    loggerPrefix?: string;
    requireMocking?: {
        [filePath: string]: {
            [requirePath: string]: string;
        };
    };
    emptyRequire?: boolean;
}
export declare function run(script: string, options?: SimpleRunOptions, path?: string): any;
