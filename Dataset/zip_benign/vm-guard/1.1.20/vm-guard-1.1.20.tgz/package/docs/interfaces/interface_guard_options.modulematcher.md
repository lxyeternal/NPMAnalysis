[vm-guard](../README.md) / [Modules](../modules.md) / [interface/guard.options](../modules/interface_guard_options.md) / ModuleMatcher

# Interface: ModuleMatcher

[interface/guard.options](../modules/interface_guard_options.md).ModuleMatcher

## Table of contents

### Properties

- [children](interface_guard_options.modulematcher.md#children)
- [role](interface_guard_options.modulematcher.md#role)

## Properties

### children

• `Optional` **children**: [ModuleStringMatcher](../modules/interface_guard_options.md#modulestringmatcher)[]

#### Defined in

[main/interface/guard.options.ts:14](https://github.com/canguser/vm-guard/blob/2e3cb31/main/interface/guard.options.ts#L14)

___

### role

• **role**: `string` \| `RegExp`

#### Defined in

[main/interface/guard.options.ts:13](https://github.com/canguser/vm-guard/blob/2e3cb31/main/interface/guard.options.ts#L13)
