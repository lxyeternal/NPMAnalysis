<template>
  <div
    ref="table"
    class="table-pannel edit-table-vue3"
    :class="{
      readonly: readonly === true,
      'is-anywhere-selected': TABLE.selectedState.cells?.length,
      'has-border': border,
      'auto-row-height': rowAutoHeight,
      'stripe-table': stripe,
      'width-fill': block,
      'loading': loading
    }"
    @click="TABLE.closeMenus()"
    @mousemove.prevent
  >
    <virtualScroll
      :oneDataHeight="24"
      v-model:sourceDataList="dataSource"
      :rowKey="rowKey"
      @contextmenuRight="TABLE.openMenus()"
      :openVirtualScroll="!!openVirtualScroll && rowAutoHeight !== true"
      class="table-warp"
      :style="tableWarpStyle"
      v-bind="typeof openVirtualScroll === 'boolean' ? undefined : openVirtualScroll"
    >
      <template #thead>
        <thead class="t-head"
          :class="{
            sticky: ![undefined, false].includes(stickyHead),
            'sticky-top': ![undefined, false].includes(stickyHead),
          }"
        >
          <template v-for="(row, rowindex) of TABLE.columnGroup.value" :key="rowindex">
            <tableRow :rowindex="rowindex - TABLE.columnGroup.value.length">
              <template v-if="rowindex === 0">
                <!-- 表头行选中 -->
                <RowCheckbox v-if="rowSelection" type="th" :rowspan="TABLE.columnGroup.value.length">
                  <slot name="headerSelect"></slot>
                </RowCheckbox>
                <!-- 行选择 -->
                <RowIndex v-if="showRowIndex || showRowDrag" type="th" :rowspan="TABLE.columnGroup.value.length">
                  <slot v-if="showRowIndex" name="headerRowindex">
                    {{ toValue(TABLE.getMessage("index")) }}
                  </slot>
                </RowIndex>
                <!-- 打开子表 -->
                <RowExpanded v-if="expandedRowKeys" type="th" :rowspan="TABLE.columnGroup.value.length">
                  <slot name="headerExpandedRow"></slot>
                </RowExpanded>
              </template>
              <!-- 列 表头 -->
              <template v-for="column of row" :key="column?.sortKey">
                <tableTh v-if="column" :column="column" :colindex="column.colindex" :colspan="column.colspan" :rowspan="column.rowspan">
                  <template v-for="(_, name) in $slots" #[name]="slotData">
                    <slot v-if=" name && [ 'headerCell', `head-${column.slotName}`, 'resize-icon', ].includes(name)" :name v-bind="slotData"></slot>
                  </template>
                </tableTh>
              </template>
            </tableRow>
          </template>
        </thead>
      </template>
      <template #default="{ item, rowindex }">
        <!-- 数据行 -->
        <randerRow
          :rowindex="rowindex"
          :record="item"
          :row-key="rowKey"
          v-model:expandedRowKeys="expandedRowKeys"
        >
          <template v-for="(_, name) in $slots" #[name]="slotData">
            <slot :name v-bind="slotData"></slot>
          </template>
        </randerRow>
        <!-- 扩展行 slot -->
        <template v-if="expandedRowKeys?.includes(item[rowKey])">
          <template v-if="!$slots.expandedRow && Array.isArray(item[childrenColumnName])">
            <template v-for="exRow of item[childrenColumnName]">
              <!-- TODO: rowindex 怎么办？复制怎么办？ 粘贴怎么办？ 删除行怎么办？ -->
              <!-- 子表 数据行 -->
              <randerRow
                :rowindex="rowindex"
                :record="exRow"
                :row-key="rowKey"
                :expandedRowKeys="expandedRowKeys"
                isExpanded
              >
                <template v-for="(_, name) in $slots" #[name]="slotData">
                  <slot :name v-bind="slotData"></slot>
                </template>
              </randerRow>
            </template>
          </template>
          <tr v-else class="expanded-row-child">
            <td :colspan="toValue(TABLE.allTileColumnsLength)">
              <slot name="expandedRow" :record="item" :index="rowindex">
                {{ item[childrenColumnName] ?? "展开行啦。。。" }}
              </slot>
            </td>
          </tr>
        </template>
      </template>

      <!-- 扩展底部 slot -->
      <template #summary>
        <slot name="summary"></slot>
      </template>

      <!-- 空数据 slot -->
      <template v-if="!loading" #empty>
        <slot name="empty">
          <tableRow class="empty">
            <td :colspan="toValue(TABLE.allTileColumnsLength)">
              <Empty :image="Empty.PRESENTED_IMAGE_SIMPLE" />
            </td>
          </tableRow>
        </slot>
      </template>

      <template #virtualScrollFooter>
        
      </template>
    </virtualScroll>

    <div class="pagination-warp" :style="{ width: tableElement.width + 'px' }">
      <div v-if="pagination" class="divider-line"></div>
      <Pagination 
        v-if="pagination" 
        v-bind="pagination" 
        v-model:current="pagination.current"
        v-model:pageSize="pagination.pageSize"
        @change="() => TABLE.emitChange('paginate')"
        size="small"
      ></Pagination>
    </div>

    <!-- 右键菜单 -->
    <Teleport
      to="body"
      v-if="toValue(TABLE.menuList)?.filter?.((item) => TABLE.visableMenu(item))?.length"
    >
      <Menu></Menu>
    </Teleport>

    <Spin v-if="loading" :style="{ width: tableElement.width + 'px' }"/>
  </div>
</template>

<script setup lang="ts">
import {
  shallowRef,
  computed,
  provide,
  onMounted,
  toValue,
  ModelRef,
  ref,
onBeforeUnmount
} from "vue";
import { Empty, Pagination, Spin } from "ant-design-vue";
import { editTableVue3Props } from "./plugins/edit-table";
import EditTable from "./plugins/core";
import {
  PROVIDE_READONLY,
  PROVIDE_EDIT_STATE,
  FieldPath,
  PROVIDE_TABLE,
  Props
} from "./plugins/core/type";
import virtualScroll from "./components/virtual-scroll.vue";
import Menu from "./components/menu.vue";
import tableRow from "./components/table-row.vue";
import tableTh from "./components/table-th.vue";
import randerRow from "./components/rander-row.vue";
import useComponents from "./components/useComponents";
const { RowIndex, RowExpanded, RowCheckbox } = useComponents();

const props = defineProps(editTableVue3Props());
const emits = defineEmits([
  "afterInsertEmptyRow",
  "warning",
  "scroll",
  "scroll-last",
  "change"
]);
const table = shallowRef<HTMLElement>();
const columns = defineModel("columns", { default: [] });
const dataSource = defineModel("dataSource", { default: [] });
const expandedRowKeys: ModelRef<unknown[] | undefined, string> = defineModel(
  "expandedRowKeys",
  { type: Array }
);

const TABLE = new EditTable({
  table,
  columns,
  dataSource,
  props,
  emits,
});
provide(PROVIDE_EDIT_STATE, TABLE.editState);
provide(
  PROVIDE_READONLY,
  computed(() => {
    const readonly =
      TABLE.checkHasReadonly(TABLE.selectAreasData.value.records) ||
      TABLE.checkHasDisable(TABLE.selectAreasData.value.records);
    return readonly;
  })
);
provide(PROVIDE_TABLE, TABLE);

onMounted(() => {
  table.value?.style?.setProperty(
    "--selected-border-color",
    props.selectedStyleBorderColor
  );
  table.value?.style?.setProperty(
    "--selected-border-width",
    props.selectedStyleBorderWidth
  );
  table.value?.style?.setProperty("--selected-bg-color", props.selectedBgcolor);
  table.value?.style?.setProperty("--hover-bg-color", props.hoverRowBgcolor);
  
});


const tableElement = ref({ width: 0 })
let resizeObsiver: ResizeObserver;
onMounted(() => {
  function tableEleResize(){
    tableElement.value.width = table.value?.querySelector('table')?.offsetWidth as number;
  }
  resizeObsiver = new ResizeObserver(tableEleResize)
  resizeObsiver.observe(table.value?.querySelector('table') as Element)
})
onBeforeUnmount(() => {
  resizeObsiver?.disconnect()
})

defineExpose({
  validate: () => TABLE.validate(),
  validateFields: (filedList?: FieldPath[], rowindex?: number) =>
    TABLE.validateFields(filedList, rowindex),
  clearValidate: (filedList?: FieldPath[], rowindex?: number) =>
    TABLE.clearValidate(filedList, rowindex),
  scrollToField: () => TABLE.scrollToField(),
  columns: TABLE.tileColumns,
});
</script>

<style lang="less">
@import url("./plugins/style.less");
</style>
