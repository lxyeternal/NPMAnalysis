import {type Options} from "./type"
import Validate from "./validate";
export default class EditTable extends Validate {
    constructor(options: Options){
        super(options)
    }
}