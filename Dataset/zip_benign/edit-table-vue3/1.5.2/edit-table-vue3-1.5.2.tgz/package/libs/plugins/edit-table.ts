import { Props } from "./core/type"
import lang from "./lang/zh_CN.json"

export const editTableVue3Props = () => {
  return {
    rowKey: {
      type: String,
      default: "id",
    },
    defaultRowData: {
      type: Function,
      default: undefined,
    },
    showRowIndex: {
      type: Boolean,
      default: false,
    },
    showRowDrag: {
      type: Boolean,
      default: false,
    },
    dargRowEnd: {
      type: Function,
      default: undefined,
    },
    showColDrag: {
      type: Boolean,
      default: false,
    },
    dargColEnd: {
      type: Function,
      default: undefined,
    },
    rowSelection: {
      type: Object,
      default: undefined,
    },
    keepLastRowEmpty: {
      type: Boolean,
      default: false,
    },
    stickyIndex: {
      type: Boolean,
      default: false,
    },
    stickyHead: {
      type: Boolean,
      default: false,
    },
    menus: {
      type: Array,
      default: undefined,
    },
    tableWarpStyle: {
      type: Object,
      default: undefined,
    },
    resizeCol: {
      type: Boolean,
      default: false,
    },
    readonly: {
      type: [Boolean, Array],
      default: false,
    },
    disabled: {
      type: [Boolean, Array],
      default: false,
    },
    openVirtualScroll: {
      type: [Boolean, Object],
      default: false,
    },
    relateRowChosed: {
      type: Boolean,
      default: false,
    },
    customRow: {
      type: Function,
      default: undefined,
    },
    customCell: {
      type: Function,
      default: undefined,
    },
    customEditer: {
      type: Object,
      default: undefined,
    },
    wrapMenusClassName: {
      type: String,
      default: undefined,
    },
    border: {
      type: Boolean,
      default: true,
    },
    selectedStyleBorderWidth: {
      type: String,
      default: '0.5px',
    },
    selectedStyleBorderColor: {
      type: String,
      default: 'rgba(0, 127, 255, 0.5)',
    },
    selectedBgcolor: {
      type: String,
      default: '#deeeff',
    },
    hoverRowBgcolor: {
      type: String,
      default: '#e5e5e5',
    },
    lang: {
      type: String, // zh_CN、en_US、ru_RU
      default: 'zh_CN'
    },
    messageConfig: {
      type: Object,
      default: undefined
    },
    openUndo: {
      type: Boolean,
      default: true,
    },
    fastKeyboard: {
      type: Array,
      default: undefined,
    },
    checkNoRepaeatRowKey: {
      type: Boolean,
      default: false,
    },
    stickyExpandedRow: {
      type: Boolean,
      default: false
    },
    expandRowByClick: {
      type: Boolean,
      default: false
    },
    expandIconColumnIndex: {
      type: Number,
      default: undefined
    },
    childrenColumnName: {
      type: String,
      default: 'children'
    },
    rowAutoHeight: {
      type: Boolean,
      default: undefined
    },
    pagination: {
      type: Object,
      default: undefined
    },
    stripe: {
      type: Boolean,
      default: undefined
    },
    block: {
      type: Boolean,
      default: undefined
    },
    serviceSorter: {
      type: Boolean,
      default: undefined
    },
    loading: {
      type: Boolean,
      default: undefined
    },
    sortCallback: {
      type: Function,
      default: undefined
    }
  };
};
