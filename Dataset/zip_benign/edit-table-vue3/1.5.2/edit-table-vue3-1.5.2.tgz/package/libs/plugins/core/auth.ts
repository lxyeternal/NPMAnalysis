import {type Options } from "./type"
import Select from './select'

export default class extends Select {
    constructor(options: Options){
        super(options)
    }

    /**
     * 是否具备复制权限
     * @returns 
     */
    AuthActionCopy(): boolean{
        if (!this.currentView) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        if (this.selectedState.rows || this.selectedState.cells) return false;
        // if (this.getMinStartY() >= this.dataSource.value.length) return true;
        // if (this.getValueByModel(this.tileColumns.value[this.getMinStartX()].dataIndex, this.dataSource.value[this.getMinStartY()]) === undefined) return false;
        return true;
    }

    /**
     * 是否具备粘贴权限
     * @returns 
     */
    AuthActionPaste(): boolean{
        if (!this.currentView) return false;
        if (this.checkHasReadonly(this.selectAreasData.value.records)) return false;
        if (this.checkHasDisable(this.selectAreasData.value.records)) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        if (this.selectedState.rows || this.selectedState.cells) return false;

        return true;
    }

    /**
     * 是否具备撤销权限
     * @returns 
     */
    AuthActionUndo(): boolean{
        if (!this.selectAreasData.value.records.length) return false;
        return this.can_undo()
    }

    /**
     * 是否具备重做权限
     * @returns 
     */
    AuthActionRedo(): boolean{
        if (!this.selectAreasData.value.records.length) return false;
        return this.can_redo()
    }

    /**
     * 是否具备向后复制权限
     * @returns 
     */
    AuthActionCopyDown(): boolean{
        if (!this.currentView) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        // if (this.selectedState.startY !== this.selectedState.endY) return false;
        if (this.getValueByModel(this.tileColumns.value[this.getMinStartX()]?.dataIndex, this.dataSource.value[this.getMinStartY()]) === undefined) return false;

        return true;
    }

    /**
     * 是否具备向后递增权限
     * @returns 
     */
    AuthActionAddStepDown(): boolean{
        if (!this.currentView) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        // if (this.selectedState.startY !== this.selectedState.endY) return false;

        if (this.getValueByModel(this.tileColumns.value[this.getMinStartX()]?.dataIndex, this.dataSource.value[this.getMinStartY()]) === undefined) return false;

        return true;
    }

    /**
     * 是否具备向前插入行权限
     * @returns 
     */
    AuthActionInsertBeforeRow(): boolean{
        if (!this.currentView) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;

        return true;
    }

    /**
     * 是否具备向后插入行权限
     * @returns 
     */
    AuthActionInsertAfterRow(): boolean{
        if (!this.currentView) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;

        return true;
    }

    /**
     * 是否具备向下复制行权限
     * @returns 
     */
    AuthActionCpyAfterRows(): boolean{
        if (!this.currentView) return false;
        if (this.checkHasReadonly(this.selectAreasData.value.records)) return false;
        if (this.checkHasDisable(this.selectAreasData.value.records)) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        if (this.getMinStartY() === this.getMaxEndY() && this.hasLastEmptyRowInSelectState()) return false;
        if (this.selectedState.startY !== this.selectedState.endY) return false;

        return true;
    }

    /**
     * 是否具备删除行权限
     * @returns 
     */
    AuthActionDeleteRow(): boolean{
        if (!this.currentView) return false;
        if (this.checkHasReadonly(this.selectAreasData.value.records)) return false;
        if (this.checkHasDisable(this.selectAreasData.value.records)) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        if (this.getMinStartY() === this.getMaxEndY() && this.hasLastEmptyRowInSelectState()) return false;
        
        return true;
    }

    /**
     * 是否具备删除单元格权限
     * @returns 
     */
    AuthActionDeleteCell(): boolean{
        if (!this.currentView) return false;
        if (this.checkHasReadonly(this.selectAreasData.value.records)) return false;
        if (this.checkHasDisable(this.selectAreasData.value.records)) return false;
        if (!this.selectAreasData.value.records.length) return false;
        if (this.selectedState.startY === undefined || this.selectedState.startX === undefined) return false;
        if (this.getMinStartY() === this.getMaxEndY() && this.hasLastEmptyRowInSelectState()) return false;
        
        return true;
    }

    private hasLastEmptyRowInSelectState(): boolean{
        if (!this.props.keepLastRowEmpty) return false;
        if (this.getMaxEndY() === this.dataSource.value.length - 1) return true;
        return false;
    }

}