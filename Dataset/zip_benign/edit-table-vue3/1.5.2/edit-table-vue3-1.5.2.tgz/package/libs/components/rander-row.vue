<script setup lang="ts">
import { withDefaults, inject, provide, computed, toValue } from "vue";
import Select from './../components/select-simple.vue';
import Input from './../components/input-number.vue';
import CustomInputNumber from './../components/input-number.vue';
import { PROVIDE_TABLE, EXPAND_ROW } from "./../plugins/core/type"
import { RightOutlined, DownOutlined } from '@ant-design/icons-vue';
import DragIcon from "./../icon/drag-icon.png"
import tableRow from './../components/table-row.vue';
import tableCell from './../components/table-cell.vue';
import useComponents from "./useComponents"
const { RowIndex, RowExpanded, RowCheckbox } = useComponents();

const props = withDefaults(defineProps<{
    rowindex: number,
    record: object,
    rowKey: string,
    expandedRowKeys?: any
    isExpanded?: boolean
}>(), {
    record: () => ({})
})

const TABLE: any = inject(PROVIDE_TABLE);
provide(EXPAND_ROW, computed(() => props.isExpanded))

const expandedHandel = (key: string | number) => {
  const index = props.expandedRowKeys?.findIndex((item: any) => item === key) ?? -1;
  if (index > -1) props.expandedRowKeys?.splice(index, 1);
  else props.expandedRowKeys?.push(key);
}
</script>
<template>
    <tableRow 
        :class="{
            'expanded-row' : expandedRowKeys?.includes(record[rowKey]),
            'expanded-row-child': isExpanded,
        }"
        :rowindex="rowindex" 
        :record="record" 
        v-bind="TABLE.props.customRow?.(record, rowindex)"
    >
        <!-- 行选中 -->
        <RowCheckbox v-if="TABLE.props.rowSelection" :rowindex="rowindex" :record="record">
            <slot name="rowSelect" :record="record" :index="rowindex"></slot>
        </RowCheckbox>
        <!-- 行号 -->
        <RowIndex v-if="TABLE.props.showRowIndex || TABLE.props.showRowDrag" :rowindex="rowindex">
            <slot name="rowIndex" :record="record" :index="rowindex" v-if="TABLE.props.showRowDrag" >
                <img class="sort-handel iconfont icon-tuodong" :src="DragIcon" />
            </slot>
        </RowIndex>
        <!-- 扩展 -->
        <RowExpanded v-if="expandedRowKeys" :rowindex="rowindex">
            <div v-if="isExpanded !== true" @click="expandedHandel(record[rowKey])">
                <slot name="expandIcon">
                    <RightOutlined v-if="!expandedRowKeys?.includes(record[rowKey])" />
                    <DownOutlined v-else />
                </slot>
            </div>
        </RowExpanded>
        
        <!-- 表格数据 -->
        <template v-for="(col, colindex) of toValue(TABLE.tileColumns)" :key="col.sortKey">
            <tableCell 
                :rowindex="rowindex" 
                :colindex="colindex" 
                :column="col" 
                :record="record"
                v-bind="TABLE.props.customCell?.(record, col, rowindex)"
            >
                <slot
                    name="bodyCell"
                    :isEditer="TABLE.isEditer(rowindex, colindex)"
                    :record="record"
                    :text="TABLE.getValueByModel(col.dataIndex, record)"
                    :index="rowindex"
                    :column="toValue(TABLE.tileColumns)[colindex]"
                    :editState="TABLE.editState"
                >
                    <!-- 文本 -->
                    <template
                        v-if="
                            [undefined, 'text', 'number'].includes(
                            toValue(TABLE.tileColumns)[colindex]?.type,
                            )
                        "
                    >
                        <CustomInputNumber v-if="toValue(TABLE.tileColumns)[colindex].type === 'number'"
                            :value="TABLE.getValueByModel(col.dataIndex, record)"
                            @update:value="val => TABLE.setValueByModel(col.dataIndex, record, val)"
                            :is-editer="TABLE.isEditer(rowindex, colindex)"
                            :type="toValue(TABLE.tileColumns)[colindex].type"
                            :open-tooltip="toValue(TABLE.tileColumns)[colindex].tooltip"
                            :auto-tooltip="toValue(TABLE.tileColumns)[colindex].autoTooltip"
                            :disabled="toValue(TABLE.tileColumns)[colindex].disabled"
                            :precision="toValue(TABLE.tileColumns)[colindex].precision"
                            stringMode
                        />
                        <Input v-else
                            :value="TABLE.getValueByModel(col.dataIndex, record)"
                            @update:value="val => TABLE.setValueByModel(col.dataIndex, record, val)"
                            :is-editer="TABLE.isEditer(rowindex, colindex)"
                            :type="toValue(TABLE.tileColumns)[colindex].type"
                            :open-tooltip="toValue(TABLE.tileColumns)[colindex].tooltip"
                            :auto-tooltip="toValue(TABLE.tileColumns)[colindex].autoTooltip"
                            :disabled="toValue(TABLE.tileColumns)[colindex].disabled"
                        />
                    </template>
                    <!-- 下拉框 -->
                    <template v-else-if="toValue(TABLE.tileColumns)[colindex].type === 'select'">
                        <Select
                            :value="TABLE.getValueByModel(col.dataIndex, record)"
                            @update:value="val => TABLE.setValueByModel(col.dataIndex, record, val)"
                            :is-editer="TABLE.isEditer(rowindex, colindex)"
                            :options="toValue(TABLE.tileColumns)[colindex].options"
                            :open-tooltip="toValue(TABLE.tileColumns)[colindex].tooltip"
                            :auto-tooltip="toValue(TABLE.tileColumns)[colindex].autoTooltip"
                            :disabled="toValue(TABLE.tileColumns)[colindex].disabled"
                        ></Select>
                    </template>
                </slot>
            </tableCell>
        </template>
    </tableRow>
</template> 