<script setup lang="ts">
import { toValue, inject } from "vue";
import { InputNumber, Button, Form, FormItem } from 'ant-design-vue';
import { PROVIDE_TABLE, DEFAULT_MENU } from "./../plugins/core/type";

const TABLE: any = inject(PROVIDE_TABLE);
</script>

<template>
    <div>
        <div
          class="edit-table-actions edit-table-menus"
          :class="TABLE.props.wrapMenusClassName"
          v-if="toValue(TABLE.menuList).length && toValue(TABLE.showMenus)"
          v-show="toValue(TABLE.showMenus)"
          :style="TABLE.menuPosition"
          :key="'' + TABLE.editState.editX + TABLE.editState.editY"
          @mouseup.stop
          @mousedown.stop
          @click.stop
        >
          <template v-for="item of toValue(TABLE.menuList)"
          :key="item.key">
            <Button
              v-if="TABLE.visableMenu(item)" 
              class="edit-table-action-list"
              :class="{
                disable: item._disabled,
              }"
              @mouseup="TABLE.menuClickHandel(item)"
              :disabled="item._disabled"
              @keydown.stop
            >
              <Form layout="inline" :model="item.inputProps ?? {}" :ref="vnode => item.vForm = vnode">
                <FormItem 
                  name="value" 
                  :rules="item.validator && [{ validator: () => item.validator?.(item, toValue(TABLE.selectAreasData), TABLE) }]"
                > 
                  <component v-if="item.label?.__v_isVNode" :is="item.label"></component>
                  <template v-else>
                    <template
                      v-if="
                        [
                          DEFAULT_MENU.ADD_STEP_DOWN,
                          DEFAULT_MENU.INSERT_BEFORE_ROWS,
                          DEFAULT_MENU.INSERT_AFTER_ROWS,
                          DEFAULT_MENU.INSERT_COPY_AFTER_ROWS,
                        ].includes(item.key)
                      "
                    >
                      {{ item.label?.split('[input]')[0] }}
                      <InputNumber
                        v-if="item.input"
                        class="action-input"
                        :disabled="item._disabled"
                        v-model:value="item.inputProps.value"
                        v-bind="item.inputProps"
                        @mouseup.stop
                        @click.stop
                        @pressEnter="TABLE.menuClickHandel(item)"
                      ></InputNumber>
                    </template>
                    <template v-else>{{ item.label }}</template>
                    <template
                      v-if="
                        [
                          DEFAULT_MENU.INSERT_BEFORE_ROWS,
                          DEFAULT_MENU.INSERT_AFTER_ROWS,
                          DEFAULT_MENU.INSERT_COPY_AFTER_ROWS,
                        ].includes(item.key)
                      "
                    >
                      {{ item.label?.split('[input]')[1] }}
                    </template>
                  </template>
                </FormItem>
              </Form>
            </Button>
          </template>
        </div>
    </div>
</template>