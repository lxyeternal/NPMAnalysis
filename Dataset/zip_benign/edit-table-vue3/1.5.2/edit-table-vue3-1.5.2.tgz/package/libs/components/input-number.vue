<template>
  <Input :formatter="formatter" v-bind="$attrs" type="number">
    <template v-for="(slot, k) in $slots" :key="k" v-slot:[k]="slotProps">
      <slot :name="k" v-bind="slotProps ?? {}" />
    </template>
  </Input>
</template>
<script lang="ts" setup>
import { useAttrs } from "vue"
import Input from './input.vue';
import { splitFillPrecision } from "./../plugins/core/util"

const attrs = useAttrs()
const formatter = (value: number | string) => {
  if (typeof attrs?.precision === 'number') return splitFillPrecision(value, attrs?.precision);
  else return value;
};
</script>
