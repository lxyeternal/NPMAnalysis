<template>
    <svg v-if="!active" width="0.7em" height="0.7em" viewBox="0 0 14 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <title>路径</title>
        <g id="70分优化" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="CORUI-Lab-70分优化-审计" transform="translate(-635, -1937)" fill="#B1B1B1" fill-rule="nonzero">
                <g id="筛选-列表" transform="translate(634, 1936)">
                    <path d="M14.94,1.505 C15.053,1.777 15.006,2.009 14.801,2.201 L9.906,7.103 L9.906,13.481 C9.91843974,13.7400226 9.7619655,13.9773621 9.519,14.068 C9.44009506,14.0997208 9.35603191,14.116669 9.271,14.118 C9.10178751,14.1220348 8.93899173,14.0532016 8.824,13.929 L6.282,12.383 C6.16025668,12.2663807 6.09220513,12.1045772 6.094,11.936 L6.094,7.103 L1.199,2.201 C0.994,2.009 0.947,1.777 1.06,1.505 C1.173,1.247 1.368,1.117 1.646,1.117 L14.355,1.117 C14.632,1.118 14.827,1.247 14.94,1.505 Z" id="路径"></path>
                </g>
            </g>
        </g>
    </svg>

    <svg v-else width="0.7em" height="0.7em" viewBox="0 0 14 14" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <title>路径</title>
        <g id="70分优化" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <g id="CORUI-Lab-70分优化-审计" transform="translate(-635, -1937)" fill="#007fff" fill-rule="nonzero">
                <g id="筛选-列表" transform="translate(634, 1936)">
                    <path d="M14.94,1.505 C15.053,1.777 15.006,2.009 14.801,2.201 L9.906,7.103 L9.906,13.481 C9.91843974,13.7400226 9.7619655,13.9773621 9.519,14.068 C9.44009506,14.0997208 9.35603191,14.116669 9.271,14.118 C9.10178751,14.1220348 8.93899173,14.0532016 8.824,13.929 L6.282,12.383 C6.16025668,12.2663807 6.09220513,12.1045772 6.094,11.936 L6.094,7.103 L1.199,2.201 C0.994,2.009 0.947,1.777 1.06,1.505 C1.173,1.247 1.368,1.117 1.646,1.117 L14.355,1.117 C14.632,1.118 14.827,1.247 14.94,1.505 Z" id="路径"></path>
                </g>
            </g>
        </g>
    </svg>
</template>

<script setup lang="ts">
defineProps({
    active: {
        type: Boolean,
        default: false
    }
})
</script>