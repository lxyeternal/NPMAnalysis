<template>
    <div ref="InputWapRef" class="input-wap" :class="{
        'edit-ready': !disabled && isEditer && editState.status === 'ready',
        'edit-doing': !disabled && isEditer && editState.status === 'doing',
        disabled: disabled
        }"
    >
        <template v-if="disabled || !isEditer || editState.status !== 'doing' ">
            <template v-if="value !== undefined">
                <tooltip :open-tooltip="openTooltip" :auto-tooltip="autoTooltip">{{ valueText }}</tooltip>
            </template>
            <span v-else class="placeholder">{{ placeholder }}</span>
        </template>
        <template v-if="!disabled && isEditer"> 
            <div class="input-controler">
                <slot name="input">
                    <InputNumber 
                        v-if="type === 'number'" 
                        v-model:value.trim="value" 
                        v-bind="$attrs"
                        :formatter="(!disabled && isEditer && editState.status === 'doing') ? undefined : $attrs.formatter"
                        :precision="(!disabled && isEditer && editState.status === 'doing') ? undefined : $attrs.precision"
                    >
                        <template v-for="(slot, k) in $slots" :key="k" v-slot:[k]="slotProps">
                            <slot :name="k" v-bind="slotProps ?? {}" />
                        </template>
                    </InputNumber>
                    <template v-else>
                        <Teleport :to="tableElementParent" :disabled="!tableElementParent">
                            <Textarea
                                ref="TextareaRef"
                                @compositionstart="compositionstart($event)"
                                @compositionend="compositionend($event)"
                                @mousedown.stop
                                @mouseup.stop
                                @click.stop
                                auto-size
                                :class="[ noEditing ? 'edit-table-textarea-hide': 'edit-table-textarea', placement]" v-model:value="value"  v-bind="$attrs" 
                                :style="textareaStyle"
                            ></Textarea>
                            <div class="back-computed-width-conetent">
                                <span ref="computedWidthRef" :style="{
                                    'max-width': textareaStyle.maxWidth
                                }">{{ value }} {{ keydownCountCode }}</span>
                            </div>
                        </Teleport>
                    </template>
                </slot>
            </div>
        </template>
        <slot name="suffix"></slot>
    </div>
</template>

<script lang="ts" setup>
import { watch, inject, computed, ref, onMounted, onBeforeUnmount, useAttrs, nextTick } from "vue"
import { Tooltip, InputNumber, Textarea } from "ant-design-vue"
import { EditState, PROVIDE_EDIT_STATE, PROVIDE_TABLE } from "./../plugins/core/type"
import tooltip from "./tooltip.vue"

const props = defineProps({
    isEditer: {
        type: Boolean,
        default: false
    },
    type: {
        type: String,
        default: 'text'
    },
    placeholder: {
        type: String,
        default: undefined
    },
    disabled: {
        type: Boolean,
        default: false
    },
    openTooltip: {
        type: Boolean,
        default: false
    },
    autoTooltip: {
        type: Boolean,
        default: true
    },
})
const emits = defineEmits(["change"])

const value = defineModel('value')

const InputWapRef = ref(null)
const attrs = useAttrs()
const valueText = computed(() => (props.type === 'number' && attrs.formatter) ? attrs.formatter?.(value.value) : value.value)
const editState: EditState = inject(PROVIDE_EDIT_STATE) as EditState;
const TABLE: any = inject(PROVIDE_TABLE);

watch(value, () => {
    if (props.isEditer && editState.status === 'doing') emits("change", value.value)
})

// 是否处在未编辑状态
const noEditing = computed(() => {
    return !(!props.disabled && props.isEditer && editState.status === 'doing')
})

const tdElement = ref<HTMLElement>()
const tableElement = ref<HTMLElement>()
const tableElementParent = ref<HTMLElement>()
const queryElements = () => {
    if (tdElement.value) return;
    let current: any = InputWapRef.value;
    while(current.tagName !== 'TD') current = current.parentElement;
    tdElement.value = current
    tableElement.value = TABLE?.table?.value?.querySelector('table')
    tableElementParent.value = tableElement.value?.parentElement as HTMLElement;
}


const placement = ref<'top' | 'bottom'>('bottom');
const textareaStyle = ref<any>({})
const computedWidthRef = ref()

let absoverConentChange: any;
const createObsover = () => {
    if (absoverConentChange || !computedWidthRef.value) return;
    absoverConentChange = new ResizeObserver((entries, observer) => {
        for (const entry of entries) {
            textareaStyle.value.width = computedWidthRef.value.offsetWidth + 24 + 'px'
            textareaStyle.value.minHeight = Math.max(
                25, 
                computedWidthRef.value.offsetHeight, 
                (tdElement.value?.offsetHeight ?? 0) + 2
            ) + 'px !important'
        }
    });
    absoverConentChange?.observe?.(computedWidthRef.value)
}
const cancelObsover = () => { 
    absoverConentChange?.unobserve?.(computedWidthRef.value)
    absoverConentChange?.disconnect?.()
    absoverConentChange = null;
}

// cancel listen scroll
const cancelListenScrollHandel = () => {
    const scrollbox = tableElementParent.value?.parentElement
    scrollbox?.removeEventListener?.('scroll', listenScrollHandel)
}
// listen scroll
const listenScrollHandel = () => {
    // 自动追加行时
    if (TABLE.scrollOrigin === 'autoInsert') return;

    if(editState.status === 'doing') editState.status = 'ready'
    cancelListenScrollHandel()
}

const TextareaRef = ref()
let keydownCountCode = ref("");
const compositionstart = () => {
    keydownCountCode.value = '';
    TextareaRef.value?.$el?.addEventListener("compositionupdate", compositionupdate)
}
const compositionend = () => {
    keydownCountCode.value = '';
    TextareaRef.value?.$el?.removeEventListener("compositionupdate", compositionupdate)
}
const compositionupdate = (e: any) => {
    keydownCountCode.value = e.data
}

const computedTextareaStyle = () => {
    if (!tableElementParent.value || !tdElement.value || !tableElement.value) {
        throw '表格节点未找到.'
    };

    const scrollbox: HTMLElement = tableElementParent.value.parentElement as HTMLElement;

    const offsetTop = (tdElement.value?.offsetTop ?? 0) - scrollbox.scrollTop;
    const offsetLeft = Math.max((tdElement.value?.offsetLeft ?? 0) - scrollbox.scrollLeft, 0);
    const offsetBottom = scrollbox.offsetHeight - offsetTop - tdElement.value.offsetHeight;

    const tableAreaHeight = scrollbox.parentElement!.clientHeight;
    const clientHeight = scrollbox.clientHeight;
    // 方向
    placement.value = (offsetTop * 1.5 > clientHeight && clientHeight + 4 >= tableAreaHeight) ? 'top' : 'bottom'

    textareaStyle.value = {
        width: 0,
        maxWidth: tableElementParent.value.offsetWidth - offsetLeft + 'px',
        minWidth: tdElement.value.offsetWidth + 1 + 'px',
        maxHeight: (placement.value === 'top' ? offsetTop : offsetBottom) + 'px',
        left: offsetLeft - 1 + 'px',
        [placement.value === 'bottom' ? 'top' : 'bottom']: (placement.value === 'top' ? offsetBottom + 1 : offsetTop) - 1 + 'px',
    }
}

const watchNumberValue = {
    watcher: function(){},
    start: function() {
        this.watcher = watch(value, (val) => {
            value.value = attrs?.blurPrecision?.(value, attrs.precision)
        }) as any
    },
    stop: function (){
        this.watcher?.();
    }
}

onMounted(() => {

    // if (props.type === 'number') {
    //     watchNumberValue.start();
    // }

    if (props.type !== 'number') {
        
        watch(() => !props.disabled && props.isEditer, val => {
            if (val) {
                queryElements()
                computedTextareaStyle()
            }
        })
        
        watch(noEditing, (dt) => {
            if (dt) {
                cancelObsover()
                cancelListenScrollHandel()
            } else {
                computedTextareaStyle()
                const scrollbox: HTMLElement = tableElementParent.value?.parentElement as HTMLElement;

                // listen content size
                createObsover()
                scrollbox.addEventListener('scroll', listenScrollHandel)

                // 临时挂载window，在输入时，插入新行需重新计算位置
                window.$computedTextareaStyle = () => {
                    computedTextareaStyle();
                }
                
            } 
        })

        
    }
})

onBeforeUnmount(() => {
    cancelObsover()
    cancelListenScrollHandel()
    tdElement.value = undefined;
    tableElementParent.value = undefined;
})

</script>

<style scoped lang="less">
.input-wap{
    width: 100%;
    align-items: center;
    justify-content: space-between;
    .placeholder,
    .overflow-text{
        flex: 1;
    }
    .input-controler{
        flex: 1;
        height: inherit;
        .ant-input-number-input{
            border-radius: none !important;
            /* font-size: calc(1em + 1px); */
        }
    }
    &.edit-ready{
        .input-controler,
        .input-controler input{
            width: 0;
            flex: unset;
            overflow: hidden;
        }
    }
    &.edit-doing{
        .placeholder,
        :deep(.overflow-text),
        .overflow-text{
            display: none !important;
            flex: unset;
        }
        :deep(.ant-input-number-input){
            position: absolute;
        }
    }
}
.disabled{
    cursor: not-allowed;
}
</style>

<style lang="less">
@td-chosed-bgcolor: #deeeff;
@td-chosed-bordercolor: rgba(0, 127, 255, 0.5);
.table-pannel{
    textarea.ant-input{
        opacity: 0;
    }
}
.edit-table-textarea{
    background-color: @td-chosed-bgcolor !important;
    z-index: 20 !important;
    border-color: @td-chosed-bordercolor !important;
    border-radius: 0 !important;
    padding: 0 3px !important;
    min-height: 0 !important;
    position: absolute !important;
    min-height: 25px !important;
    user-select: none !important;
    transition: opacity 50ms !important;
    display: inline-block !important;
    opacity: 1 !important;
    height: 0;
    line-height: 1.5 !important;
    // font-size: 12px !important;
    outline: none !important;
    box-shadow: none !important;
    padding-top: 2px !important;
    // left: -1px;
    // right: -1px;
    // max-width: unset !important;
    // width: auto !important;
    // line-height: 24px !important;
    // &.top{
    //     bottom: -1px;
    // }
    // &.bottom{
    //     top: -1px;
    // }
}
.edit-table-textarea-hide{
    width: 0 !important;
    height: 0 !important;
    overflow: hidden !important;
    min-height: 0px !important;
    position: absolute !important;
    padding: 0 !important;
    opacity: 0 !important;
    transition: none !important;
    border: 0 !important;
}
.back-computed-width-conetent{
    // width: 0;
    height: 0;
    opacity: 0;
    overflow: hidden;
    font-size: 1em;
    line-height: 1.5;
    span{
        display: inline-block;
    }
}
</style>
