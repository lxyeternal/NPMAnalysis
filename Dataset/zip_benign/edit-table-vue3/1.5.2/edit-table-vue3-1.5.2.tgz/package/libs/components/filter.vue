<template>
    <Dropdown @mousedown.stop v-model:open="visible" overlayClassName="edit-table-filter" :trigger="['click']" :getPopupContainer="() => TABLE.table.value.querySelector('.table-warp')">

        <div class="filter-icon pointer">
            <filterIcon :active="!!value?.length" />
        </div>

        <template #overlay>
            <div class="edit-table-filter-panel" @click="visible = true;" @mouseup.stop >

                <CheckboxGroup v-if="column.filterMultiple" v-model:value="_value" :options="column.filters"></CheckboxGroup>
                <RadioGroup v-else :value="_value[0]" @update:value="(v: any) => _value = [v]" :options="column.filters"></RadioGroup>

                <div class="footer-btns" @click.stop>
                    <Button size="small" @click="cancelHandel" style="border: none;" :disabled="!_value?.length">重置</Button>
                    <Button size="small" type="primary" @click="okHandel">确定</Button>
                </div>
            </div>
        </template>

    </Dropdown>
</template>

<script setup lang="ts">
import { withDefaults, inject, ref, watch, toValue } from "vue";
import { PROVIDE_TABLE, Column } from "./../plugins/core/type";
import filterIcon from "./filter-icon.vue";
import { CheckboxGroup, RadioGroup, Button, Dropdown } from "ant-design-vue";

const props = withDefaults(
  defineProps<{
    column?: Column;
    value?: (string | number)[]
  }>(),
  {
    column: () => ({}),
  }
);

const TABLE: any = inject(PROVIDE_TABLE);
const emits = defineEmits(['update:value', 'ok', 'cancel'])

const _value = ref();
const visible = ref(false);


watch(() => props.value, (val) => {
    _value.value = val ?? [];
}, {
    immediate: true
})

watch(visible, (val) => {
    if (val) {
        _value.value = props.value ?? [];

        function handel(){
            visible.value = false;
            document.removeEventListener('mouseup', handel)
        }
        document.addEventListener('mouseup', handel);
    }
})


const okHandel = () => {
    emits('update:value', toValue(_value));
    emits('ok', toValue(_value));
    visible.value = false;
}

const cancelHandel = () => {
    emits('update:value', undefined);
    emits('cancel', undefined);
    visible.value = false;
}
</script>