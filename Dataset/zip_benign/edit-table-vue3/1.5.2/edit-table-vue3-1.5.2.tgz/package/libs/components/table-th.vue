<script setup lang="ts">
import { withDefaults, inject, onMounted, computed, watch, Ref } from "vue";
import {
  PROVIDE_TABLE,
  Column,
  PROVIDE_ROWINDEX,
} from "./../plugins/core/type";
import Filter from "./filter.vue"

const props = withDefaults(
  defineProps<{
    rowindex?: number;
    colindex?: number;
    column?: Column;
    record?: object;
    colspan?: number | string;
    rowspan?: number | string;
  }>(),
  {
    column: () => ({}),
    record: () => ({}),
  }
);

const TABLE: any = inject(PROVIDE_TABLE);
const ROWINDEX = inject(PROVIDE_ROWINDEX) as Ref;
const Rowindex = computed(() => ROWINDEX.value || props.rowindex);

/**
 * 单元格是否处在选区矩阵范围内
 */
function isIntoSelectAreas(){
  const rowindex = Rowindex.value;
  const { colindex, rowspan, colspan } = props;
  const selfMaxY = Number(rowindex) + Number(rowspan ?? 1) - 1;
  const selfMaxX = Number(colindex) + Number(colspan ?? 1) - 1;

  if (TABLE.getMaxEndY() < rowindex || TABLE.getMinStartY() > selfMaxY) {
    return false;
  }
  if (TABLE.getMaxEndX() < colindex || TABLE.getMinStartX() > selfMaxX) {
    return false;
  }
  return true;
}

if (props.colspan && Number(props.colspan) > 1) {
  watch(() => [
    TABLE.selectedState.startY,
    TABLE.selectedState.endY,
    TABLE.selectedState.startX,
    TABLE.selectedState.endX,
  ], () => {
    if (!isIntoSelectAreas()) {
      return;
    }
    
    const [minX, maxX] = [TABLE.getMinStartX(), TABLE.getMaxEndX()];
    const { colindex, colspan } = props;
    const selfMaxX = Number(colindex) + Number(colspan) - 1;

    if (selfMaxX > maxX) {
      if (maxX === TABLE.selectedState.endX) TABLE.selectedState.endX = selfMaxX;
      else TABLE.selectedState.startX = selfMaxX;
    }
    if (colindex < minX) {
      if (minX === TABLE.selectedState.startX) TABLE.selectedState.startX = colindex;
      else TABLE.selectedState.endX = colindex;
    }
  })
}

if (props.rowspan && Number(props.rowspan) > 1) {
  watch(() => [
    TABLE.selectedState.startY,
    TABLE.selectedState.endY,
    TABLE.selectedState.startX,
    TABLE.selectedState.endX,
  ], () => {
    if (!isIntoSelectAreas()) {
      return;
    }

    const [minY, maxY] = [TABLE.getMinStartY(), TABLE.getMaxEndY()];
    const rowindex = Rowindex.value;
    const { rowspan } = props;
    const selfMaxY = Number(rowindex) + Number(rowspan) - 1;

    if (selfMaxY > maxY) {
      if (maxY === TABLE.selectedState.endY) TABLE.selectedState.endY = selfMaxY;
      else TABLE.selectedState.startY = selfMaxY;
    }
    if (minY > rowindex) {
      if (minY === TABLE.selectedState.startY) TABLE.selectedState.startY = rowindex;
      else TABLE.selectedState.endY = rowindex;
    }
  })
}
</script>
<template>
    <th
        :style="{ 
          width: TABLE.getThWidth(colindex),
          minWidth: TABLE.getThMinWidth(colindex),
        }"
        v-if="column"
        :colspan="colspan"
        :rowspan="rowspan"
        :data-rowindex="Rowindex"
        :data-colindex="colindex"
        :class="{
            'selected': TABLE.isSelectCol(Rowindex, colindex, colspan),
            'first-selected': TABLE.isFirstSelectedTh(colindex),
            'last-selected': TABLE.isLastSelectedTh(colindex, colspan),
            'has-rowspan-last-tr-td': rowspan && TABLE.isLastSelectedTrTd(Rowindex, rowspan ?? 0),
        }"
        @mousedown="TABLE.selectColumnsMousedown(Rowindex, colindex, colspan)"
    >
        <div class="th-cell">
          <slot name="headerCell" :column="column" :title="column.title">
            <slot :name="`head-${column.slotName}`">
              {{ column.title }}
            </slot>
          </slot>
    
          <i v-if="column.sorter" class="sorter-icon" :class="{
            ascend: column.sortOrder === 'ascend',
            descend: column.sortOrder === 'descend'
          }" @click.stop="TABLE.sortHandel(column)" @mousedown.stop></i>
          
          <Filter 
            v-if="column.filters"
            :column="column" 
            :value="column.filteredValue"
            @ok="(v) => TABLE.setFilteredValue(v, column)" 
            @cancel="(v) => TABLE.setFilteredValue(v, column)"
          ></Filter>
        </div>
        <div
          v-if="TABLE.props.resizeCol"
          class="handel-resize"
          @mousedown.prevent.stop="TABLE.startResize(colindex, Rowindex)"
        >
          <slot name="resize-icon">
            <img
              class="iconfont icon-tuozhuai"
              src="./../icon/tuozhuai.png"
              alt=""
            />
          </slot>
        </div>
    </th>
</template>
