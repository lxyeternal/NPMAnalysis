<script setup lang="ts">
import { withDefaults, inject, provide, watch, ref, onMounted } from "vue";
import { PROVIDE_TABLE, PROVIDE_ROWINDEX } from "./../plugins/core/type"

const props = withDefaults(defineProps<{
    rowindex?: number,
    record?: object,
}>(), {
    record: () => ({})
})

const TABLE: any = inject(PROVIDE_TABLE);
const rowIndex = ref(props.rowindex);

provide(PROVIDE_ROWINDEX, rowIndex);
onMounted(() => {
    if (TABLE.$$rowindex === undefined) TABLE.$$rowindex = 0;
    if (props.rowindex === undefined) {
        const step = TABLE.$$rowindex;
        watch(() => TABLE.dataSource.value?.length, (length) => {
            rowIndex.value = length + step;
        }, {
           immediate: true
        })
        TABLE.$$rowindex++;
    }
    watch(() => props.rowindex, () => {
        rowIndex.value = props.rowindex;
    })
})
</script>
<template>
    <tr
        :class="{
            selected: TABLE.isSelectedTr(rowIndex),
            'selected-row': TABLE.isSelectRow(rowIndex),
            'first-selected': TABLE.isFirstSelectedTr(rowIndex),
            'last-selected': TABLE.isLastSelectedTr(rowIndex),
            'readonly-row': TABLE.checkHasReadonly([record]),
            'disable-edit-row' :TABLE.checkHasDisable([record]),
        }"
        :data-rowindex="rowIndex"
        @click="TABLE.props.customRow?.(record, rowIndex).onClick?.()"
        @dblclick="TABLE.props.customRow?.(record, rowIndex).onDblclick?.()"
        @contextmenu="TABLE.props.customRow?.(record, rowIndex).onContextmenu?.()"
        @mouseenter="TABLE.props.customRow?.(record, rowIndex).onMouseenter?.()"
        @mouseleave="TABLE.props.customRow?.(record, rowIndex).onMouseleave?.()"
    >
        <slot></slot>
    </tr>
</template> 