<script setup lang="ts">
import { withDefaults, inject, onMounted, computed, watch, Ref, provide } from "vue";
import {
  PROVIDE_TABLE,
  Column,
  PROVIDE_ROWINDEX,
  PROVIDE_READONLY
} from "./../plugins/core/type";

const props = withDefaults(
  defineProps<{
    rowindex?: number;
    colindex?: number;
    column?: Column;
    record?: object;
    colspan?: number | string;
    rowspan?: number | string;
    disabled?: boolean;
    readonly?: boolean;
  }>(),
  {
    // @ts-ignore
    column: () => ({}),
    record: () => ({}),
  }
);

const TABLE: any = inject(PROVIDE_TABLE);
const ROWINDEX = inject(PROVIDE_ROWINDEX) as Ref;
const Rowindex = computed(() => ROWINDEX.value || props.rowindex);
const provide_readonly: any = inject(PROVIDE_READONLY)
const readonly_cell = computed(() => props.readonly || provide_readonly?.value || props.column.readonly)
provide(PROVIDE_READONLY, readonly_cell)

/**
 * 单元格是否处在选区矩阵范围内
 */
function isIntoSelectAreas(){
  const rowindex = Rowindex.value;
  const { colindex, rowspan, colspan } = props;
  const selfMaxY = Number(rowindex) + Number(rowspan ?? 1) - 1;
  const selfMaxX = Number(colindex) + Number(colspan ?? 1) - 1;

  if (TABLE.getMaxEndY() < rowindex || TABLE.getMinStartY() > selfMaxY) {
    return false;
  }
  if (TABLE.getMaxEndX() < colindex || TABLE.getMinStartX() > selfMaxX) {
    return false;
  }
  return true;
}

if (props.colspan && Number(props.colspan) > 1) {
  watch(() => [
    TABLE.selectedState.startY,
    TABLE.selectedState.endY,
    TABLE.selectedState.startX,
    TABLE.selectedState.endX,
  ], () => {
    if (!isIntoSelectAreas()) {
      return;
    }
    
    const [minX, maxX] = [TABLE.getMinStartX(), TABLE.getMaxEndX()];
    const { colindex, colspan } = props;
    const selfMaxX = Number(colindex) + Number(colspan) - 1;

    if (selfMaxX > maxX) {
      if (maxX === TABLE.selectedState.endX) TABLE.selectedState.endX = selfMaxX;
      else TABLE.selectedState.startX = selfMaxX;
    }
    if (colindex < minX) {
      if (minX === TABLE.selectedState.startX) TABLE.selectedState.startX = colindex;
      else TABLE.selectedState.endX = colindex;
    }
  })
}

if (props.rowspan && Number(props.rowspan) > 1) {
  watch(() => [
    TABLE.selectedState.startY,
    TABLE.selectedState.endY,
    TABLE.selectedState.startX,
    TABLE.selectedState.endX,
  ], () => {
    if (!isIntoSelectAreas()) {
      return;
    }

    const [minY, maxY] = [TABLE.getMinStartY(), TABLE.getMaxEndY()];
    const rowindex = Rowindex.value;
    const { rowspan } = props;
    const selfMaxY = Number(rowindex) + Number(rowspan) - 1;

    if (selfMaxY > maxY) {
      if (maxY === TABLE.selectedState.endY) TABLE.selectedState.endY = selfMaxY;
      else TABLE.selectedState.startY = selfMaxY;
    }
    if (minY > rowindex) {
      if (minY === TABLE.selectedState.startY) TABLE.selectedState.startY = rowindex;
      else TABLE.selectedState.endY = rowindex;
    }
  })
}
</script>
<template>
  <td
    :colspan="colspan"
    :rowspan="rowspan"
    :class="{
      selected: TABLE.isSelectedTd(Rowindex, colindex),
      sticky: column.fixed,
      [`sticky-${column.fixed}`]: column.fixed,
      'first-selected': TABLE.isFirstSelectedTd(colindex),
      'last-selected': TABLE.isLastSelectedTd(colindex, colspan ?? 0),
      'has-rowspan-last-tr-td': rowspan && TABLE.isLastSelectedTrTd(Rowindex, rowspan ?? 0),
      error: TABLE.isCellError(record, column),
      'disabled': disabled,
      'readonly-cell': readonly_cell,
    }"
    :data-rowindex="Rowindex"
    :data-colindex="colindex"
    @mousedown="TABLE.selectMousedownHandel(Rowindex, colindex); TABLE.checkRowindexSetDefaultRowData(Rowindex)"
    @click="TABLE.clickEditHandel(Rowindex, colindex)"
    @dblclick.prevent="TABLE.dblclickEditHandel(Rowindex, colindex)"
  >
    <div
      class="td-cell"
      :class="{
        [column.align!]: !!column.align,
      }"
      :style="{ 
        width: TABLE.getThWidth(colindex),
        minWidth: TABLE.getThMinWidth(colindex),
      }"
    >
      <slot></slot>
    </div>
    <div
      v-if="
        TABLE.isLastSelectedTd(colindex) && TABLE.isLastSelectedTr(Rowindex)
      "
      class="drag-core"
      @click.stop
      @mousedown.stop="TABLE.dragContruneHandel"
    ></div>
  </td>
</template>
