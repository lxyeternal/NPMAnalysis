import TableComponent from "./libs/index.vue";
import TableComponentInput from "./libs/components/input.vue";
import TableComponentInputNumber from "./libs/components/input-number.vue";
import TableComponentSelect from "./libs/components/select.vue";
// 只是简单的下拉， 没有复杂的交互，关注性能时优先使用此组件
import TableComponentSelectSimple from "./libs/components/select-simple.vue";
import tableRow from "./libs/components/table-row.vue"
import tableCell from "./libs/components/table-cell.vue"
import autoTooltip from "./libs/components/tooltip.vue"

const EditTable = {
  install: function (Vue) {
    Vue.component("edit-table-vue3", TableComponent);
    Vue.component("edit-table-input", TableComponentInput);
    Vue.component("edit-table-input-number", TableComponentInputNumber);
    Vue.component("edit-table-select", TableComponentSelect);
    Vue.component("edit-table-select-simple", TableComponentSelectSimple);
    Vue.component("edit-table-tooltip", autoTooltip);
    Vue.component("edit-table-summary-row", tableRow);
    Vue.component("edit-table-summary-cell", tableCell);
  },
};

export default EditTable;
