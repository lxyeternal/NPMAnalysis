<template>
    <h3>summary插槽</h3>
    <edit-table-vue3 
    :dataSource="data1" 
    :columns="column1"
    >
        <template #summary>
            <edit-table-summary-row>
                <edit-table-summary-cell :colindex="0" rowspan="2">统计</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="1" colspan="2">23.34</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="3">23</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="4">45</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="5"></edit-table-summary-cell>
                <edit-table-summary-cell :colindex="6"></edit-table-summary-cell>
                <edit-table-summary-cell :colindex="7"></edit-table-summary-cell>
            </edit-table-summary-row>
            <edit-table-summary-row>
                <edit-table-summary-cell :colindex="1">12.567</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="2" colspan="2">73.244</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="4">55.235</edit-table-summary-cell>
                <edit-table-summary-cell :colindex="5"></edit-table-summary-cell>
                <edit-table-summary-cell :colindex="6"></edit-table-summary-cell>
                <edit-table-summary-cell :colindex="7"></edit-table-summary-cell>
            </edit-table-summary-row>
        </template>
    </edit-table-vue3>
</template>

<script setup lang="ts">
import {useColumns, useData} from "@/assets/table"

const column1 = useColumns()
const data1 = useData()
</script>