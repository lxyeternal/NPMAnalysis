<template>
    <a-button @click="openModal">打开弹窗</a-button>
</template>

<script setup lang="ts">
import { h } from "vue";
import { useAntModal } from "./useModal";

const showModal = useAntModal()
function openModal(){
    const modal = showModal({
        modalComponent: h('div', {}, '哈哈哈哈'),
        title: "测试弹窗",
        onOk: () => {
            alert("ok了")
            modal.$close?.()
        },
        onCancel: () => alert("取消了")
    })
}
</script>