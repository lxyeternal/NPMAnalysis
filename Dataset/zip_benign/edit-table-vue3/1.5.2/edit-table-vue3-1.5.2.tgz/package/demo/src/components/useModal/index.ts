import { h } from "vue"
import { Modal } from "ant-design-vue"
import useShowModal from "./base"
import type { IModalOptions } from "./base"

interface ModalOptions extends IModalOptions {
    onOk?: Function
}

/**
 * 扩展加载自定义弹窗内容组件，ant-design-vue中的Modal弹窗
 * @returns Function
 */
export function useAntModal() {
    const showModal = useShowModal()

    /**
     * 打开弹窗
     * @param options ModalOptions
     * @returns `{ $close() 关闭弹窗方法, ... }`
     */
    function fn (options: ModalOptions) {
        const modal = showModal({
            ...options,
            modalComponent: h(Modal, h(options.modalComponent)),
        })
        return modal;
    }

    return fn
}