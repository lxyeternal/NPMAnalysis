import { ref } from "vue"

export function useColumns(){
    return ref([
        {
            title: "姓名",
            dataIndex: "name",
            width: '120px',
        },
        {
            title: "年龄(精度：0)",
            dataIndex: "age",
            key: "age",
            type: "number",
            precision: 0,
            width: '120px',
        },
        {
            title: "工龄(精度：1)",
            dataIndex: "workage",
            key: "workage",
            type: "number",
            precision: 1,
            width: '120px',
        },
        {
            title: "性别",
            dataIndex: ["other", "sex"],
            type: "select",
            valueType: "number",
            width: '120px',
            options: [
                {label: "男", value: 0},
                {label: "女", value: 1},
            ]
        },
        {
            title: "note",
            dataIndex: "note",
            width: '180px',
            tooltip: true,
        },
        {
            title: "lg",
            dataIndex: ["other", "lg"],
            width: '100px',
            rules: [
                {
                    required: true
                },
            ]
        },
        {
            title: "只读列",
            dataIndex: "summary",
            width: '120px',
            readonly: true,
        },
        {
            title: "禁用列",
            dataIndex: "disabled",
            width: '120px',
            disabled: true,
        }
    ])
}


export function useData(){
    return ref([
        {
            name: "朱雀",
            age: 22, 
            note: "朱雀，中国古代神话中的天之四灵之一，源于远古星宿崇拜，是代表炎帝与南方七宿的南方之神，于八卦为离，于五行主火，象征四象中的老阳，四季中的夏季，同时也是天之南陆。", 
            id: "abcdefg",
            old_name: '曾阿牛', 
            new_name: '张无忌',
            other: {
                sex: 1,
                lg: "明日上市！比亚迪放大招！车长5米22，续航1100km，剑指奥迪A6L",
            },
            summary: "诸葛亮1",
            disabled: "禁用1",
        },
        {
            name: "白虎", 
            age: 28, 
            old_name: '曾阿牛', 
            new_name: '张无忌',
            note: "白虎，中国古代神话中的天之四灵之一，西方之神，后为道教所信奉，同青龙、朱雀、玄武合称四方四神。",
            id: "hijklmn",
            other: {
                sex: 0,
                lg: "无论你是一名社会工作者、从事医学、国际商务、语言教学或只是出国旅行，用客户的母语语言与他们交流的能力都是一个巨大的优势。", 
            },
            summary: "诸葛亮2",
            disabled: "禁用2",
        },
        {
            name: "某运动员",
            age: 24, 
            note: "",
            old_name: '曾阿牛', 
            new_name: '张无忌',
            id: "768768768768768",
            other: {
                sex: 0, 
            },
            summary: "诸葛亮3",
            disabled: "禁用3",
        },
        {
            name: "张菲",
            age: 21, 
            note: "",
            old_name: '曾阿牛', 
            new_name: '张无忌',
            id: "3242423424324324",
            other: {
                sex: 1, 
            },
            summary: "诸葛亮4",
            disabled: "禁用4",
        },
    ])
}