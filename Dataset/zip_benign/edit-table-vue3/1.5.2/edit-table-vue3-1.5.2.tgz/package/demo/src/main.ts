// import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'

import Antd from 'ant-design-vue';
import 'ant-design-vue/dist/reset.css';

import table from './../../index.js'


createApp(App).use(Antd).use(table).mount('#app')
