<template>
    <h3>内置排序</h3>
    <edit-table-vue3 :dataSource="data1" :columns="column1">

    </edit-table-vue3>

    <h3>服务端排序</h3>
    <edit-table-vue3 :dataSource="data2" :columns="column2" serviceSorter @change="changeHandel">

    </edit-table-vue3>

</template>

<script setup lang="ts">
import {useColumns, useData} from "@/assets/table"

const column1 = useColumns()
const data1 = useData()
column1.value[0].sorter = true;
column1.value[1].sorter = true;
column1.value[4].sorter = true;

const column2 = useColumns()
const data2 = useData()
column2.value[1].sorter = true;
function changeHandel(pagination, filters, sorter, { action }){
    data2.value.sort((a, b) => {
        return sorter?.order === 'ascend' ? a.age - b.age : b.age - a.age;
    })
}
</script>