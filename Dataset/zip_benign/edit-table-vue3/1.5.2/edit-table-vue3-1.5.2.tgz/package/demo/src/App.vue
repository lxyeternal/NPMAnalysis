<script setup lang="ts">
import { message } from "ant-design-vue";
import { h, watch } from "vue";
import { ref } from "vue"
import sortTable from "@/components/sort-table.vue"
import spanTable from "./components/span-table.vue";
import summaryTable from "./components/summary-table.vue";
import { useColumns, useData } from "@/assets/table";
import modalDemo from "./components/useModalDemo.vue"

const column = useColumns();
const data = useData()

const autoChangeDataTimer = ref();
const autoChangeData = () => {
    if (autoChangeDataTimer.value) {
        clearInterval(autoChangeDataTimer.value);
        autoChangeDataTimer.value = null;
        return;
    }
    
    autoChangeDataTimer.value = setInterval(() => {
        data.value[0].age += 1;
        data.value[1].age += 1;
    }, 250);
}

for (let i = 3; i < 10; i++) {
    data.value.push({ name: "张三丰" + i, old_name: '曾阿牛', new_name: '张无忌' });
}

const tableRef = ref();
const rowSelection = ref<{
    fixed: true,
    selectedRowKeys: string[],
    disableSelectedRowKeys: string[],
    selectedRows: any[],
    onChange: (selectedRowKeys: string[], selectedRows: any[]) => void
}>({
    fixed: true,
    selectedRowKeys: [], 
    disableSelectedRowKeys: [data.value[0].id],
    selectedRows: [],
    onChange: (selectedRowKeys: string[], selectedRows: any[]) => {
        rowSelection.value.selectedRowKeys = selectedRowKeys;
        rowSelection.value.selectedRows = selectedRows
    }
})

const rules = [
    {
        field: "name",
        required: true,
        message: '名称必填',
    },
    {
        field: "age",
        precision: 0,
        message: '只能整数',
    },
    {
        field: ["other", "sex"],
        required: true,
        message: '性别必填',
        validator: (a, b, c) => {
            return Promise.resolve()
        }
    }
]
const Editer = ref({
    selectedRowKeys: [data.value[0].id],
    rules: rules,
    onChange: (data) => {
        console.log("onChange", data)
    },
    onFocus: (a, b) => {
        console.log("onFocus", a, b)
    },
    onBlur: (a, b) => {
        console.log("onBlur", a, b)
    },
    onSelected: (a, b) => {
        console.log("onSelected", a, b)
    }
})
const validatorTable = async () => {
    await tableRef.value.validate();
}
const clearvalidatorTable = () => {
    tableRef.value.clearValidate();
}

const functions = ref({
    rowSelection: undefined,
    keepLastRowEmpty: false,
    showRowIndex: false,
    resizeCol: false,
    showRowDrag: false,
    showColDrag: false,
    readonly: false,
    readonlyLine1: false,
    openVirtualScroll: false,
    relateRowChosed: false,
    disabled: false,
    disabledLine2: false,
    sorter: false,
    filters: false,
    openUndo: false,
    disabledMenu: false,
    rowAutoHeight: false,
    openPagination: false,
    stripe: false,
    openExpandedRowKeys: false,
    block: false
})

watch(() => functions.value.sorter, (val) => {
    if (val) {
        column.value.forEach(column => {
            if(column.dataIndex === 'age' || column.dataIndex === 'name'){
                column.sorter = true
                column.sortCallback = (a, b, c) => {
                    console.log('列配置排序回调', a, b, c)
                }
            }
        })
    }else {
        column.value.forEach(column => {
            column.sorter = false
        })
    }
})

const VirtualScroll = {
    scrollFlag: true,
    onScroll: (y: number) => {
        console.log('虚拟滚动了', y)
    },
    scrollLastFlag: true,
    onScrollLast: () => {
        console.warn('虚拟滚动, 到底了')
    }
}

const messageConfig = ref()
const changMessage = () => {
    messageConfig.value = messageConfig.value ? undefined : {
        "index": "Index",
        "menus": {
            "copyLabel": "Copy",
            "paetsLabel": "Paets",
            "copyDownLabel": "Copy Down",
            "addStepDownLabel": "Add Step Down",
            "insertBeforeLabel":"Insert Before [input]",
            "insertAfterLabel": "Insert After [input]",
            "insertAfterCopyLabel": "Insert Copy [input]",
            "deleteRowsLabel": "Delete Chose Rows"
        },
        "input": {
            "mustInt": "Please Input Int",
            "maxDecimal": "Please Input Floot []"
        },
        "disabledMoreArea": "Operate More Areas Not Yellow"
    }
}

const menus = ref()
watch(() => functions.value.disabledMenu, (val) => {
    if (val) {
        menus.value = []
    }
})

const expandedRowKeys = ref()
watch(() => functions.value.openExpandedRowKeys, (val) => {
    expandedRowKeys.value = val ? [] : undefined
})

watch(() => functions.value.filters, (val) => {
    if (val) {
        column.value.forEach(column => {
            if(column.key === 'age' || column.key === 'sex'){
                column.filters = [
                    {label: "22", value: 22},
                    {label: "33", value: 33},
                ]
            }
        })
    }else {
        column.value.forEach(column => {
            column.filters = undefined
        })
    }
})
const TableChange = (a, b, c, d, e) => {
    console.log(a, b, c, d, e)
}

const pagination = ref()
watch(() => functions.value.openPagination, (val) => {
    pagination.value = val ? {
        total: 100,
        current: 1,
        pageSize: 20,
    } : undefined
})

function sortCallback(a, b, c){
    console.log('表格配置排序回调', a, b, c)
}



</script>

<template>
    <div class="box">
        <div>
            <a-checkbox v-model:checked="functions.keepLastRowEmpty">保持最后一行为空数据</a-checkbox>
            <a-checkbox v-model:checked="functions.rowSelection">行选择</a-checkbox>
            <a-checkbox v-model:checked="functions.showRowIndex">显示行号</a-checkbox>
            <a-checkbox v-model:checked="functions.resizeCol">调整列宽</a-checkbox>
            <a-checkbox v-model:checked="functions.showRowDrag">拖动行</a-checkbox>
            <a-checkbox v-model:checked="functions.showColDrag">拖动列</a-checkbox>
            <a-checkbox v-model:checked="functions.readonly">只读模式</a-checkbox>
            <a-checkbox v-model:checked="functions.readonlyLine1">只读模式(仅第一行)</a-checkbox>
            <a-checkbox v-model:checked="functions.disabled">禁用模式</a-checkbox>
            <a-checkbox v-model:checked="functions.disabledLine2">禁用模式(仅第二行)</a-checkbox>
            <a-checkbox v-model:checked="functions.openVirtualScroll">开启虚部滚动</a-checkbox>
            <a-checkbox v-model:checked="functions.relateRowChosed">开启checkbox选择行与内容联动</a-checkbox>
            <a-checkbox v-model:checked="functions.sorter">开启排序</a-checkbox>
            <a-checkbox v-model:checked="functions.filters">开启过滤</a-checkbox>
            <a-checkbox v-model:checked="functions.openUndo">开启撤销重做</a-checkbox>
            <a-checkbox v-model:checked="functions.disabledMenu">禁用复制、粘贴、删除菜单</a-checkbox>
            <a-checkbox v-model:checked="functions.rowAutoHeight">取消限制每行高度24</a-checkbox>
            <a-checkbox v-model:checked="functions.openPagination">打开分页</a-checkbox>
            <a-checkbox v-model:checked="functions.stripe">斑马纹表格</a-checkbox>
            <a-checkbox v-model:checked="functions.openExpandedRowKeys">开启子表</a-checkbox>
            <a-checkbox v-model:checked="functions.block">将表格自动铺满内容区域</a-checkbox>

            <div>
                <a-button @click="Editer.selectedRowKeys = [data[1].id]">选区手动选中第二行</a-button>
                <a-button @click="changMessage">语言变换</a-button>
                <a-button @click="validatorTable">验证表格内容</a-button>
                <a-button @click="clearvalidatorTable">验证清除</a-button>
                <a-button @click="autoChangeData">{{!autoChangeDataTimer ? 'Start' : 'Stop'}} 自动变化数据测试</a-button>
            </div>

            <edit-table-vue3 ref="tableRef" :dataSource="data" :columns="column"
            :rowSelection="functions.rowSelection && rowSelection"
            :keepLastRowEmpty="functions.keepLastRowEmpty"
            :showRowIndex="functions.showRowIndex"
            :resizeCol="functions.resizeCol"
            :showRowDrag="functions.showRowDrag"
            :showColDrag="functions.showColDrag"
            :readonly="functions.readonlyLine1 ? [data[0].id] : functions.readonly"
            :disabled="functions.disabledLine2 ? [data[1].id] : functions.disabled"
            :openVirtualScroll="functions.openVirtualScroll && VirtualScroll"
            :relateRowChosed="functions.relateRowChosed"
            :customEditer="Editer"
            stickyIndex
            stickyExpandedRow
            stickyHead
            :menus="menus"
            style="min-height: 300px"
            @scroll="VirtualScroll.onScroll"
            @scroll-last="VirtualScroll.onScrollLast"
            :messageConfig="messageConfig"
            :openUndo="functions.openUndo"
            :expandedRowKeys="expandedRowKeys"
            :rowAutoHeight="functions.rowAutoHeight"
            @change="TableChange"
            :pagination="pagination"
            :stripe="functions.stripe"
            :block="functions.block"
            :sortCallback="sortCallback"
            >
                <!-- <template #summary>
                    <edit-table-summary-row>
                        <edit-table-summary-cell v-if="functions.rowSelection"></edit-table-summary-cell>
                        <edit-table-summary-cell v-if="functions.showRowIndex"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="0" rowspan="2"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="1" colspan="2"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="3"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="4"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="5"></edit-table-summary-cell>
                    </edit-table-summary-row>
                    <edit-table-summary-row>
                        <edit-table-summary-cell v-if="functions.rowSelection"></edit-table-summary-cell>
                        <edit-table-summary-cell v-if="functions.showRowIndex"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="1"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="2" colspan="2"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="4"></edit-table-summary-cell>
                        <edit-table-summary-cell :colindex="5"></edit-table-summary-cell>
                    </edit-table-summary-row>
                </template> -->
                <!-- <template #rowCheckbox="{index}">{{index}}</template> -->
            </edit-table-vue3>

            <sortTable />
            <spanTable />
            <summaryTable/>
        </div>
        <div class="right">
            <h4>表格数据 :</h4>
            [
            <p v-for="dt of data">{{ dt }}</p>
            ]
            <h4>选择数据 :</h4>
            [
            <p v-for="key of rowSelection.selectedRowKeys">{{ key }}</p>
            ]
            <br/>
            [
            <p v-for="row of rowSelection.selectedRows">{{ row }}</p>
            ]
        </div>
    </div>

    <modalDemo></modalDemo>
</template>

<style scoped>
.box{
    font-size: 14px;
    display: grid;
    grid-template-columns: 60% calc(60% - 20px);
    gap: 20px;
    padding: 30px;
}
.right{
    background: #f5f5f5;
    padding: 10px;
    max-height: 80vh;
    overflow: auto;
}
button{
    margin: 8px 6px 8px 0;
}
h4{
    margin: 4px 0;
}
p{
    margin: 3px 0 3px 24px;
    font-size: 12px;
}
</style>
<style>
h3{
  margin: 2em 0 1em !important;
  font-weight: 800 !important;
}</style>
