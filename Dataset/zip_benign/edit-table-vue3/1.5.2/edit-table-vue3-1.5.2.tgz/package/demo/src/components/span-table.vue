<template>
    <h3>表头跨行、跨列</h3>
    <edit-table-vue3 
    :dataSource="data1" 
    :columns="column1"
    >
    </edit-table-vue3>
</template>

<script setup lang="ts">
import {useColumns, useData} from "@/assets/table"

const column1 = useColumns()
const data1 = useData()
column1.value[0].children = [
    { title: "曾用名", dataIndex: "old_name", width: 60 },
    { title: "现用名", dataIndex: "new_name", width: 60 },
]
column1.value[1].children = [
    { title: "取整1", dataIndex: "int1", width: 60 },
]
column1.value[2].children = [
    { title: "取整2", dataIndex: "int2", width: 60 },
]
</script>