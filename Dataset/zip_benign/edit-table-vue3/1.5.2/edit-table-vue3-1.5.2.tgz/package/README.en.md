# edit-table-vue3

#### Description
可编辑表格

### Params

| 参数    | 说明               | 类型                      | 默认值 |
| ------- | ------------------ | ------------------------- | ------ |
| dataSource      | 表格数据 | `{}[]` | -      |
| columns | 表格列     | `columns`                 | -      |
| rowKey | 行唯一key     | `string`                 | `id`      |
| rowSelection | 选择行配置     | `rowSelection`                 | -      |
| defaultRowData | 编辑表格行默认数据     | `Object`                 | -      |
| menus | 自定义右键菜单     | `menus`                 | -      |
| keepLastRowEmpty | 保持表格最后一行为空数据     | `boolean`                 | `false`      |
| resizeCol | 手动调整列宽     | `boolean`                 | `false`      |
| showRowIndex | 是否显示行号     | `boolean`                 | `false`      |
| showRowDrag | 是否开启拖拽行功能     | `boolean`                 | `false`      |
| showColDrag | 是否开启拖拽列功能     | `boolean`                 | `false`      |
| stickyHead | 表头是否启用粘性     | `boolean`                 | `false`      |
| stickyIndex | 行号是否启用粘性     | `boolean`                 | `false`      |
| readonly | 只读模式     | `boolean`                 | `false`      |


### columns

| 参数     | 说明                     | 类型      | 默认值  |
| -------- | ------------------------ | --------- | ------- |
| title     |      |   |   |
| dataIndex     |      |   |   |
| type     | `text、select、checkbox`     | `string`  | -  |
| options     | 当type为select时，下拉选择项     | `{label, value}[]`  | -  |
| slotName     | 列插槽名     | -  | -  |
| width     | 列默认宽度     | `number`  | `-  |
| minWidth     | 列最小宽度     | `number`  | -  |
| rules     |      | -  | -  |
| fixed     | 是否固定列     | `boolean、 'left'、 'right'`  | `false`  |
| tooltip     | 是否开启Tooltip     | `boolean`  | `false`  |

### rowSelection

同Ant Design Vue

### menus

| 参数     | 说明                     | 类型      | 默认值  |
| -------- | ------------------------ | --------- | ------- |