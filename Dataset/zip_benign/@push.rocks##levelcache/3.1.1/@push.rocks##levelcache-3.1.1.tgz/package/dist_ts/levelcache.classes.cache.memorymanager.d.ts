import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
export declare class CacheMemoryManager extends AbstractCache {
    private levelCacheRef;
    private fastMap;
    private readyDeferred;
    ready: Promise<void>;
    status: 'active' | 'inactive';
    constructor(levelCacheRefArg: LevelCache);
    init(): Promise<void>;
    storeCacheEntryByKey(keyArg: string, cacheEntryArg: CacheEntry): Promise<void>;
    retrieveCacheEntryByKey(keyArg: string): Promise<CacheEntry>;
    checkKeyPresence(keyArg: string): Promise<boolean>;
    deleteCacheEntryByKey(keyArg: string): Promise<void>;
    cleanOutdated(): Promise<void>;
    cleanAll(): Promise<void>;
}
