import * as plugins from './levelcache.plugins.js';
import { CacheDiskManager } from './levelcache.classes.cache.diskmanager.js';
import { CacheMemoryManager } from './levelcache.classes.cache.memorymanager.js';
import { CacheS3Manager } from './levelcache.classes.cache.s3manager.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
import { CacheRouter } from './levelcache.classes.cacherouter.js';
import { AbstractCache } from './levelcache.abstract.classes.cache.js';
/**
 * a leveled cache for storing things for a short time
 */
export class LevelCache extends AbstractCache {
    constructor(optionsArg) {
        super();
        this.readyDeferred = plugins.smartpromise.defer();
        this.ready = this.readyDeferred.promise;
        this.status = 'active'; // artifact of AbstractCache
        this.cacheRouter = new CacheRouter(this);
        this.options = {
            maxMemoryStorageInMB: 0.5,
            maxDiskStorageInMB: 10,
            maxS3StorageInMB: 50,
            ...optionsArg,
        };
        this.init();
    }
    async init() {
        this.cacheMemoryManager = new CacheMemoryManager(this);
        this.cacheDiskManager = new CacheDiskManager(this);
        this.cacheS3Manager = new CacheS3Manager(this);
        await Promise.all([
            this.cacheDiskManager.ready,
            this.cacheMemoryManager.ready,
            this.cacheS3Manager.ready,
        ]);
        this.readyDeferred.resolve();
    }
    // store things
    async storeCacheEntryByKey(keyArg, cacheEntryArg) {
        cacheEntryArg.key = keyArg;
        const targetCache = await this.cacheRouter.getCacheForStoreAction(keyArg, cacheEntryArg);
        cacheEntryArg.createdAt = Date.now();
        await targetCache.storeCacheEntryByKey(keyArg, cacheEntryArg);
    }
    // retrieve things
    /**
     * retrieve cache entry
     */
    async retrieveCacheEntryByKey(keyArg) {
        const targetCache = await this.cacheRouter.getCacheForRetrieveAction(keyArg);
        if (targetCache) {
            const cacheEntry = await targetCache.retrieveCacheEntryByKey(keyArg);
            if (cacheEntry.createdAt + cacheEntry.ttl < Date.now()) {
                await this.deleteCacheEntryByKey(keyArg).catch();
                return null;
            }
            return cacheEntry;
        }
        else {
            return null;
        }
    }
    async checkKeyPresence(keyArg) {
        return plugins.smartpromise.getFirstTrueOrFalse([
            this.cacheMemoryManager.checkKeyPresence(keyArg),
            this.cacheDiskManager.checkKeyPresence(keyArg),
            this.cacheS3Manager.checkKeyPresence(keyArg),
        ]);
    }
    async deleteCacheEntryByKey(keyArg) {
        await Promise.all([
            this.cacheMemoryManager.deleteCacheEntryByKey(keyArg),
            this.cacheDiskManager.deleteCacheEntryByKey(keyArg),
            this.cacheS3Manager.deleteCacheEntryByKey(keyArg),
        ]);
    }
    // cache maintenance
    async cleanOutdated() { }
    /**
     * cleans the complete cache
     */
    async cleanAll() {
        await Promise.all([
            this.cacheDiskManager.cleanAll(),
            this.cacheDiskManager.cleanAll(),
            this.cacheS3Manager.cleanAll(),
        ]);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGV2ZWxjYWNoZS5jbGFzc2VzLmxldmVsY2FjaGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi90cy9sZXZlbGNhY2hlLmNsYXNzZXMubGV2ZWxjYWNoZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEtBQUssT0FBTyxNQUFNLHlCQUF5QixDQUFDO0FBQ25ELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJDQUEyQyxDQUFDO0FBQzdFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQ2pGLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSx5Q0FBeUMsQ0FBQztBQUN6RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFDaEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3Q0FBd0MsQ0FBQztBQW1CdkU7O0dBRUc7QUFDSCxNQUFNLE9BQU8sVUFBVyxTQUFRLGFBQWE7SUFjM0MsWUFBWSxVQUF5QztRQUNuRCxLQUFLLEVBQUUsQ0FBQztRQWRGLGtCQUFhLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQVEsQ0FBQztRQUVwRCxVQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7UUFFbkMsV0FBTSxHQUFhLFFBQVEsQ0FBQyxDQUFDLDRCQUE0QjtRQUV6RCxnQkFBVyxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBU3pDLElBQUksQ0FBQyxPQUFPLEdBQUc7WUFDYixvQkFBb0IsRUFBRSxHQUFHO1lBQ3pCLGtCQUFrQixFQUFFLEVBQUU7WUFDdEIsZ0JBQWdCLEVBQUUsRUFBRTtZQUNwQixHQUFHLFVBQVU7U0FDZCxDQUFDO1FBQ0YsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJO1FBQ2YsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDaEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUs7WUFDM0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUs7WUFDN0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLO1NBQzFCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVELGVBQWU7SUFDUixLQUFLLENBQUMsb0JBQW9CLENBQUMsTUFBYyxFQUFFLGFBQXlCO1FBQ3pFLGFBQWEsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO1FBQzNCLE1BQU0sV0FBVyxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDekYsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDckMsTUFBTSxXQUFXLENBQUMsb0JBQW9CLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCxrQkFBa0I7SUFDbEI7O09BRUc7SUFDSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsTUFBYztRQUNqRCxNQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0UsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNoQixNQUFNLFVBQVUsR0FBRyxNQUFNLFdBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyRSxJQUFJLFVBQVUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztnQkFDdkQsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUNELE9BQU8sVUFBVSxDQUFDO1FBQ3BCLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO0lBQ0gsQ0FBQztJQUVNLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFjO1FBQzFDLE9BQU8sT0FBTyxDQUFDLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQztZQUM5QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO1lBQ2hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7WUFDOUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7U0FDN0MsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNO1FBQ3ZDLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUNoQixJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDO1lBQ3JELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUM7WUFDbkQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUM7U0FDbEQsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELG9CQUFvQjtJQUNiLEtBQUssQ0FBQyxhQUFhLEtBQUksQ0FBQztJQUUvQjs7T0FFRztJQUNJLEtBQUssQ0FBQyxRQUFRO1FBQ25CLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUNoQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFO1lBQ2hDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUU7WUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLEVBQUU7U0FDL0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGIn0=