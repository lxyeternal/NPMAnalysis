import * as plugins from './levelcache.plugins.js';
import { CacheDiskManager } from './levelcache.classes.cache.diskmanager.js';
import { CacheMemoryManager } from './levelcache.classes.cache.memorymanager.js';
import { CacheS3Manager } from './levelcache.classes.cache.s3manager.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
import { CacheRouter } from './levelcache.classes.cacherouter.js';
import { AbstractCache } from './levelcache.abstract.classes.cache.js';
export interface ILevelCacheConstructorOptions {
    /**
     * a unique id when having more than one cache
     */
    cacheId: string;
    maxMemoryStorageInMB?: number;
    maxDiskStorageInMB?: number;
    maxS3StorageInMB?: number;
    diskStoragePath?: string;
    s3Config?: plugins.tsclass.storage.IS3Descriptor;
    s3BucketName?: string;
    forceLevel?: 'memory' | 'disk' | 's3';
    expirationInMs?: number;
    immutableCache?: boolean;
    persistentCache?: boolean;
}
/**
 * a leveled cache for storing things for a short time
 */
export declare class LevelCache extends AbstractCache {
    private readyDeferred;
    ready: Promise<void>;
    status: 'active';
    cacheRouter: CacheRouter;
    cacheDiskManager: CacheDiskManager;
    cacheMemoryManager: CacheMemoryManager;
    cacheS3Manager: CacheS3Manager;
    options: ILevelCacheConstructorOptions;
    constructor(optionsArg: ILevelCacheConstructorOptions);
    init(): Promise<void>;
    storeCacheEntryByKey(keyArg: string, cacheEntryArg: CacheEntry): Promise<void>;
    /**
     * retrieve cache entry
     */
    retrieveCacheEntryByKey(keyArg: string): Promise<CacheEntry>;
    checkKeyPresence(keyArg: string): Promise<boolean>;
    deleteCacheEntryByKey(keyArg: any): Promise<void>;
    cleanOutdated(): Promise<void>;
    /**
     * cleans the complete cache
     */
    cleanAll(): Promise<void>;
}
