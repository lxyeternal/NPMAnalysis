/**
 * autocreated commitinfo by @push.rocks/commitinfo
 */
export declare const commitinfo: {
    name: string;
    version: string;
    description: string;
};
