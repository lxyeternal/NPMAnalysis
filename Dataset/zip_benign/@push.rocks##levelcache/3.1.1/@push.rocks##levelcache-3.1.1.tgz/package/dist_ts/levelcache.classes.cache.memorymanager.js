import * as plugins from './levelcache.plugins.js';
import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
export class CacheMemoryManager extends AbstractCache {
    constructor(levelCacheRefArg) {
        super();
        this.fastMap = new plugins.lik.FastMap();
        this.readyDeferred = plugins.smartpromise.defer();
        this.ready = this.readyDeferred.promise;
        this.levelCacheRef = levelCacheRefArg;
        this.init();
    }
    async init() {
        this.status = 'active';
        this.readyDeferred.resolve();
    }
    async storeCacheEntryByKey(keyArg, cacheEntryArg) {
        this.fastMap.addToMap(keyArg, cacheEntryArg, { force: true });
    }
    async retrieveCacheEntryByKey(keyArg) {
        return this.fastMap.getByKey(keyArg);
    }
    async checkKeyPresence(keyArg) {
        if (this.fastMap.getByKey(keyArg)) {
            return true;
        }
        else {
            return false;
        }
    }
    async deleteCacheEntryByKey(keyArg) {
        this.fastMap.removeFromMap(keyArg);
    }
    async cleanOutdated() { }
    async cleanAll() {
        this.fastMap.clean();
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGV2ZWxjYWNoZS5jbGFzc2VzLmNhY2hlLm1lbW9yeW1hbmFnZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi90cy9sZXZlbGNhY2hlLmNsYXNzZXMuY2FjaGUubWVtb3J5bWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEtBQUssT0FBTyxNQUFNLHlCQUF5QixDQUFDO0FBQ25ELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3Q0FBd0MsQ0FBQztBQUN2RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFDaEUsT0FBTyxFQUFzQyxVQUFVLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUVwRyxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsYUFBYTtJQVFuRCxZQUFZLGdCQUE0QjtRQUN0QyxLQUFLLEVBQUUsQ0FBQztRQVBGLFlBQU8sR0FBRyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFjLENBQUM7UUFDaEQsa0JBQWEsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBUSxDQUFDO1FBRXBELFVBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQztRQUt4QyxJQUFJLENBQUMsYUFBYSxHQUFHLGdCQUFnQixDQUFDO1FBQ3RDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSTtRQUNmLElBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVNLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxNQUFjLEVBQUUsYUFBeUI7UUFDekUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFTSxLQUFLLENBQUMsdUJBQXVCLENBQUMsTUFBYztRQUNqRCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsTUFBYztRQUMxQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7WUFDbEMsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7SUFFTSxLQUFLLENBQUMscUJBQXFCLENBQUMsTUFBYztRQUMvQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU0sS0FBSyxDQUFDLGFBQWEsS0FBSSxDQUFDO0lBRXhCLEtBQUssQ0FBQyxRQUFRO1FBQ25CLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDdkIsQ0FBQztDQUNGIn0=