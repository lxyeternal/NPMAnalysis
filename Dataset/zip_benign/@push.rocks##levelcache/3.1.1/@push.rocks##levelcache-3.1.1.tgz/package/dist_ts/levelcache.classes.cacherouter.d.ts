import * as plugins from './levelcache.plugins.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
export declare class CacheRouter {
    levelCacheRef: LevelCache;
    cacheKeyMap: plugins.lik.FastMap<AbstractCache>;
    constructor(levelCacheRef: LevelCache);
    /**
     * gets the relevant cache to perform a store action on
     */
    getCacheForStoreAction(keyArg: string, cacheEntry: CacheEntry): Promise<AbstractCache>;
    /**
     * gets the relevant cache to perform a retrieval action on
     */
    getCacheForRetrieveAction(keyArg: string): Promise<AbstractCache>;
}
