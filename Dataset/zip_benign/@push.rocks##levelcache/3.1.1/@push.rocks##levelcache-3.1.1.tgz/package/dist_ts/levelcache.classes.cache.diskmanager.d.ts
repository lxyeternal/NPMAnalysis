import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
/**
 *
 */
export declare class CacheDiskManager extends AbstractCache {
    private levelCacheRef;
    private readyDeferred;
    ready: Promise<void>;
    status: 'active' | 'inactive';
    fsPath: string;
    maxCacheSizeInMb: number;
    constructor(levelCacheRefArg: LevelCache);
    init(): Promise<void>;
    retrieveCacheEntryByKey(keyArg: string): Promise<CacheEntry>;
    storeCacheEntryByKey(keyArg: string, cacheEntryArg: CacheEntry): Promise<void>;
    checkKeyPresence(keyArg: string): Promise<boolean>;
    deleteCacheEntryByKey(keyArg: string): Promise<void>;
    cleanOutdated(): Promise<void>;
    cleanAll(): Promise<void>;
}
