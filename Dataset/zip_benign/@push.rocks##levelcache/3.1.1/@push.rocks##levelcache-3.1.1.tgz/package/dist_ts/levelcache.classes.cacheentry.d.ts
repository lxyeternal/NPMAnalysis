import * as plugins from './levelcache.plugins.js';
export interface ICacheEntryConstructorOptions {
    key?: string;
    ttl: number;
    typeInfo?: string;
    contents: Buffer;
}
/**
 * a CacheEntry
 */
export declare class CacheEntry extends plugins.smartjson.Smartjson implements ICacheEntryConstructorOptions {
    static fromStorageJsonString(storageJsonString: string): CacheEntry;
    key: string;
    ttl: number;
    createdAt: number;
    typeInfo: string;
    contents: Buffer;
    toStorageJsonString(): string;
    constructor(optionsArg: ICacheEntryConstructorOptions);
}
