import * as plugins from './levelcache.plugins.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
export class CacheRouter {
    constructor(levelCacheRef) {
        this.cacheKeyMap = new plugins.lik.FastMap();
        this.levelCacheRef = levelCacheRef;
    }
    /**
     * gets the relevant cache to perform a store action on
     */
    async getCacheForStoreAction(keyArg, cacheEntry) {
        let returnCache;
        const mbToBytesMultiplier = 1000 * 1000;
        const maxMemoryBytes = this.levelCacheRef.options.maxMemoryStorageInMB * mbToBytesMultiplier;
        const maxDiskBytes = this.levelCacheRef.options.maxDiskStorageInMB * mbToBytesMultiplier;
        const maxS3Bytes = this.levelCacheRef.options.maxS3StorageInMB * mbToBytesMultiplier;
        switch (true) {
            case cacheEntry.contents.byteLength <= maxMemoryBytes &&
                this.levelCacheRef.cacheMemoryManager.status === 'active':
                returnCache = this.levelCacheRef.cacheMemoryManager;
                break;
            case this.levelCacheRef.cacheDiskManager.status === 'active' &&
                cacheEntry.contents.byteLength > maxMemoryBytes &&
                cacheEntry.contents.byteLength <= maxDiskBytes &&
                this.levelCacheRef.cacheDiskManager.status === 'active':
                returnCache = this.levelCacheRef.cacheDiskManager;
                break;
            case cacheEntry.contents.byteLength > maxDiskBytes &&
                cacheEntry.contents.byteLength < maxS3Bytes &&
                this.levelCacheRef.cacheS3Manager.status === 'active':
                returnCache = this.levelCacheRef.cacheS3Manager;
                break;
            default:
                returnCache = null;
        }
        this.cacheKeyMap.addToMap(keyArg, returnCache);
        return returnCache;
    }
    /**
     * gets the relevant cache to perform a retrieval action on
     */
    async getCacheForRetrieveAction(keyArg) {
        const done = plugins.smartpromise.defer();
        const returnCache = this.cacheKeyMap.getByKey(keyArg);
        if (!returnCache && this.levelCacheRef.options.persistentCache) {
            const checkCache = (cacheArg) => {
                const resultPromise = cacheArg.checkKeyPresence(keyArg);
                resultPromise.then((hasKeyArg) => {
                    if (hasKeyArg) {
                        done.resolve(cacheArg);
                    }
                });
                return resultPromise;
            };
            Promise.all([
                checkCache(this.levelCacheRef.cacheMemoryManager),
                checkCache(this.levelCacheRef.cacheDiskManager),
                checkCache(this.levelCacheRef.cacheMemoryManager),
            ]).then(() => {
                done.resolve(returnCache);
            });
        }
        else {
            done.resolve(returnCache);
        }
        return done.promise;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGV2ZWxjYWNoZS5jbGFzc2VzLmNhY2hlcm91dGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vdHMvbGV2ZWxjYWNoZS5jbGFzc2VzLmNhY2hlcm91dGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sS0FBSyxPQUFPLE1BQU0seUJBQXlCLENBQUM7QUFDbkQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ2hFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3Q0FBd0MsQ0FBQztBQUN2RSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFFaEUsTUFBTSxPQUFPLFdBQVc7SUFJdEIsWUFBWSxhQUF5QjtRQUY5QixnQkFBVyxHQUFHLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQWlCLENBQUM7UUFHNUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7SUFDckMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHNCQUFzQixDQUFDLE1BQWMsRUFBRSxVQUFzQjtRQUNqRSxJQUFJLFdBQTBCLENBQUM7UUFDL0IsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLG9CQUFvQixHQUFHLG1CQUFtQixDQUFDO1FBQzdGLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLGtCQUFrQixHQUFHLG1CQUFtQixDQUFDO1FBQ3pGLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLGdCQUFnQixHQUFHLG1CQUFtQixDQUFDO1FBRXJGLFFBQVEsSUFBSSxFQUFFLENBQUM7WUFDYixLQUFLLFVBQVUsQ0FBQyxRQUFRLENBQUMsVUFBVSxJQUFJLGNBQWM7Z0JBQ25ELElBQUksQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsTUFBTSxLQUFLLFFBQVE7Z0JBQ3pELFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDO2dCQUNwRCxNQUFNO1lBQ1IsS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxRQUFRO2dCQUMxRCxVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxjQUFjO2dCQUMvQyxVQUFVLENBQUMsUUFBUSxDQUFDLFVBQVUsSUFBSSxZQUFZO2dCQUM5QyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxRQUFRO2dCQUN2RCxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDbEQsTUFBTTtZQUNSLEtBQUssVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsWUFBWTtnQkFDaEQsVUFBVSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsVUFBVTtnQkFDM0MsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxLQUFLLFFBQVE7Z0JBQ3JELFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQztnQkFDaEQsTUFBTTtZQUNSO2dCQUNFLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFDdkIsQ0FBQztRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUMvQyxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMseUJBQXlCLENBQUMsTUFBYztRQUM1QyxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBaUIsQ0FBQztRQUN6RCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN0RCxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQy9ELE1BQU0sVUFBVSxHQUFHLENBQUMsUUFBdUIsRUFBRSxFQUFFO2dCQUM3QyxNQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3hELGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRTtvQkFDL0IsSUFBSSxTQUFTLEVBQUUsQ0FBQzt3QkFDZCxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUN6QixDQUFDO2dCQUNILENBQUMsQ0FBQyxDQUFDO2dCQUNILE9BQU8sYUFBYSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQztZQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUM7Z0JBQ1YsVUFBVSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUM7Z0JBQ2pELFVBQVUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDO2dCQUMvQyxVQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQzthQUNsRCxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDWCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzVCLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDdEIsQ0FBQztDQUNGIn0=