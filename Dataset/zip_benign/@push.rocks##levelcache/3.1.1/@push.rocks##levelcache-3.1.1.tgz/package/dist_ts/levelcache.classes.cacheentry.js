var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import * as plugins from './levelcache.plugins.js';
/**
 * a CacheEntry
 */
export class CacheEntry extends plugins.smartjson.Smartjson {
    static fromStorageJsonString(storageJsonString) {
        return new CacheEntry(plugins.smartjson.parse(storageJsonString));
    }
    toStorageJsonString() {
        return this.foldToJson();
    }
    constructor(optionsArg) {
        super();
        Object.assign(this, optionsArg);
    }
}
__decorate([
    plugins.smartjson.foldDec(),
    __metadata("design:type", String)
], CacheEntry.prototype, "key", void 0);
__decorate([
    plugins.smartjson.foldDec(),
    __metadata("design:type", Number)
], CacheEntry.prototype, "ttl", void 0);
__decorate([
    plugins.smartjson.foldDec(),
    __metadata("design:type", Number)
], CacheEntry.prototype, "createdAt", void 0);
__decorate([
    plugins.smartjson.foldDec(),
    __metadata("design:type", String)
], CacheEntry.prototype, "typeInfo", void 0);
__decorate([
    plugins.smartjson.foldDec(),
    __metadata("design:type", Buffer)
], CacheEntry.prototype, "contents", void 0);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGV2ZWxjYWNoZS5jbGFzc2VzLmNhY2hlZW50cnkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi90cy9sZXZlbGNhY2hlLmNsYXNzZXMuY2FjaGVlbnRyeS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxPQUFPLEtBQUssT0FBTyxNQUFNLHlCQUF5QixDQUFDO0FBU25EOztHQUVHO0FBQ0gsTUFBTSxPQUFPLFVBQ1gsU0FBUSxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVM7SUFHNUIsTUFBTSxDQUFDLHFCQUFxQixDQUFDLGlCQUF5QjtRQUMzRCxPQUFPLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBaUJNLG1CQUFtQjtRQUN4QixPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQsWUFBWSxVQUF5QztRQUNuRCxLQUFLLEVBQUUsQ0FBQztRQUNSLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ2xDLENBQUM7Q0FDRjtBQXRCUTtJQUROLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFOzt1Q0FDVDtBQUdaO0lBRE4sT0FBTyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUU7O3VDQUNUO0FBR1o7SUFETixPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRTs7NkNBQ0g7QUFHbEI7SUFETixPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRTs7NENBQ0o7QUFHeEI7SUFEQyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRTs4QkFDbEIsTUFBTTs0Q0FBQyJ9