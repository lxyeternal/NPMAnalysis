import * as plugins from './levelcache.plugins.js';
import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
/**
 *
 */
export class CacheS3Manager extends AbstractCache {
    constructor(levelCacheRefArg) {
        super();
        this.readyDeferred = plugins.smartpromise.defer();
        this.ready = this.readyDeferred.promise;
        this.levelCacheRef = levelCacheRefArg;
        this.init();
    }
    async init() {
        if (this.levelCacheRef.options.s3Config) {
            this.smartbucket = new plugins.smartbucket.SmartBucket(this.levelCacheRef.options.s3Config);
            this.s3CacheBucket = await this.smartbucket.getBucketByName('');
            this.s3CacheDir = await (await this.s3CacheBucket.getBaseDirectory()).getSubDirectoryByName(this.levelCacheRef.options.cacheId);
            if (this.levelCacheRef.options.maxS3StorageInMB) {
                console.log(`cache level S3 activated with ${this.levelCacheRef.options.maxS3StorageInMB}`);
            }
            else {
                console.log(`s3 cache started without limit. Automatically applying timebox of 1 month`);
            }
            this.status = 'active';
        }
        else {
            this.status = 'inactive';
        }
        this.readyDeferred.resolve();
    }
    async retrieveCacheEntryByKey(keyArg) {
        const jsonFileString = (await this.s3CacheDir.fastGet({
            path: encodeURIComponent(keyArg),
        })).toString();
        const cacheEntry = CacheEntry.fromStorageJsonString(jsonFileString);
        return cacheEntry;
    }
    async storeCacheEntryByKey(keyArg, cacheEntryArg) {
        await this.s3CacheDir.fastPut({
            path: encodeURIComponent(keyArg),
            contents: cacheEntryArg.toStorageJsonString()
        });
    }
    async checkKeyPresence(keyArg) {
        const files = await this.s3CacheDir.listFiles();
        for (const file of files) {
            if (file.name === keyArg) {
                return true;
            }
        }
        return false;
    }
    async deleteCacheEntryByKey(keyArg) {
        if (this.status === 'active') {
            await this.s3CacheDir.fastRemove({
                path: encodeURIComponent(keyArg),
            });
        }
    }
    /**
     * clean outdated
     */
    async cleanOutdated() { }
    async cleanAll() {
        await this.s3CacheDir.delete({
            mode: 'permanent',
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGV2ZWxjYWNoZS5jbGFzc2VzLmNhY2hlLnMzbWFuYWdlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3RzL2xldmVsY2FjaGUuY2xhc3Nlcy5jYWNoZS5zM21hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxLQUFLLE9BQU8sTUFBTSx5QkFBeUIsQ0FBQztBQUNuRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0NBQXdDLENBQUM7QUFDdkUsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ2hFLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUVoRTs7R0FFRztBQUNILE1BQU0sT0FBTyxjQUFlLFNBQVEsYUFBYTtJQVUvQyxZQUFZLGdCQUE0QjtRQUN0QyxLQUFLLEVBQUUsQ0FBQztRQU5GLGtCQUFhLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQVEsQ0FBQztRQUVwRCxVQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7UUFLeEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxnQkFBZ0IsQ0FBQztRQUN0QyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUk7UUFDZixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM1RixJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQ3RCLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxDQUM1QyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDaEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDO1lBQzlGLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLDJFQUEyRSxDQUFDLENBQUM7WUFDM0YsQ0FBQztZQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDO1FBQ3pCLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7UUFDM0IsQ0FBQztRQUNELElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVNLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxNQUFjO1FBQ2pELE1BQU0sY0FBYyxHQUFHLENBQUMsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztZQUNwRCxJQUFJLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDO1NBQ2pDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2YsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLHFCQUFxQixDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3BFLE9BQU8sVUFBVSxDQUFDO0lBQ3BCLENBQUM7SUFFTSxLQUFLLENBQUMsb0JBQW9CLENBQUMsTUFBYyxFQUFFLGFBQXlCO1FBQ3pFLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7WUFDNUIsSUFBSSxFQUFFLGtCQUFrQixDQUFDLE1BQU0sQ0FBQztZQUNoQyxRQUFRLEVBQUUsYUFBYSxDQUFDLG1CQUFtQixFQUFFO1NBQzlDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsTUFBYztRQUMxQyxNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDaEQsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN6QixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFLENBQUM7Z0JBQ3pCLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFTSxLQUFLLENBQUMscUJBQXFCLENBQUMsTUFBYztRQUMvQyxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDN0IsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztnQkFDL0IsSUFBSSxFQUFFLGtCQUFrQixDQUFDLE1BQU0sQ0FBQzthQUNqQyxDQUFDLENBQUM7UUFDTCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSyxDQUFDLGFBQWEsS0FBSSxDQUFDO0lBRXhCLEtBQUssQ0FBQyxRQUFRO1FBQ25CLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFDM0IsSUFBSSxFQUFFLFdBQVc7U0FDbEIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGIn0=