import { AbstractCache } from './levelcache.abstract.classes.cache.js';
import { LevelCache } from './levelcache.classes.levelcache.js';
import { CacheEntry } from './levelcache.classes.cacheentry.js';
/**
 *
 */
export declare class CacheS3Manager extends AbstractCache {
    private levelCacheRef;
    private smartbucket;
    private s3CacheBucket;
    private s3CacheDir;
    private readyDeferred;
    ready: Promise<void>;
    status: 'active' | 'inactive';
    constructor(levelCacheRefArg: LevelCache);
    init(): Promise<void>;
    retrieveCacheEntryByKey(keyArg: string): Promise<CacheEntry>;
    storeCacheEntryByKey(keyArg: string, cacheEntryArg: CacheEntry): Promise<void>;
    checkKeyPresence(keyArg: string): Promise<boolean>;
    deleteCacheEntryByKey(keyArg: string): Promise<void>;
    /**
     * clean outdated
     */
    cleanOutdated(): Promise<void>;
    cleanAll(): Promise<void>;
}
