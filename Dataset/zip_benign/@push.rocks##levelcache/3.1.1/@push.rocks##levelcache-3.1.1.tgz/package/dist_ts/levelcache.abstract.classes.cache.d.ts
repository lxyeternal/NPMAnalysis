import { CacheEntry } from './levelcache.classes.cacheentry.js';
export declare abstract class AbstractCache {
    abstract ready: Promise<void>;
    abstract status: 'active' | 'inactive';
    /**
     * store a Blob
     */
    abstract storeCacheEntryByKey(keyArg: string, valueArg: CacheEntry): Promise<void>;
    /**
     * retrieve cache entry
     */
    abstract retrieveCacheEntryByKey(keyArg: string): Promise<CacheEntry>;
    /**
     * checks for the presence of a key
     * @param keyArg
     */
    abstract checkKeyPresence(keyArg: string): Promise<boolean>;
    /**
     * delete a key
     */
    abstract deleteCacheEntryByKey(keyArg: string): Promise<void>;
    /**
     * clean the cache
     */
    abstract cleanOutdated(): Promise<void>;
    /**
     * cleans the complete cache
     */
    abstract cleanAll(): Promise<void>;
}
