/**
 * autocreated commitinfo by @push.rocks/commitinfo
 */
export const commitinfo = {
  name: '@push.rocks/levelcache',
  version: '3.1.1',
  description: 'A versatile caching solution offering multi-level storage utilizing memory, disk, and Amazon S3 for efficient data management and backup.'
}
