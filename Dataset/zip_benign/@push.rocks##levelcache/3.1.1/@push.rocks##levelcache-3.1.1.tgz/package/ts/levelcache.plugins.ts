// node native scope
import * as path from 'path';

export { path };

// @push.rocks scope
import * as lik from '@push.rocks/lik';
import * as smartbucket from '@push.rocks/smartbucket';
import * as smartcache from '@push.rocks/smartcache';
import * as smartfile from '@push.rocks/smartfile';
import * as smartjson from '@push.rocks/smartjson';
import * as smartpath from '@push.rocks/smartpath';
import * as smartpromise from '@push.rocks/smartpromise';
import * as smartstring from '@push.rocks/smartstring';
import * as smartunique from '@push.rocks/smartunique';
import * as taskbuffer from '@push.rocks/taskbuffer';

export {
  lik,
  smartbucket,
  smartcache,
  smartfile,
  smartjson,
  smartpath,
  smartpromise,
  smartstring,
  smartunique,
  taskbuffer,
};

// @tsclass scope
import * as tsclass from '@tsclass/tsclass';

export {
  tsclass,
};
