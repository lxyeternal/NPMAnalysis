export declare function indexOf(str: string, regex: RegExp, pos?: number): number;
export declare function indexOfAll(str: string, regex: RegExp, pos?: number): number[];
