export default function findExprEnd(str: string, start: number, delimiter: RegExp, brackets?: RegExp[]): number;
