export declare function parseArgumentsIndex(str: string, delimiter: RegExp, argStartRegex: RegExp, brackets?: [RegExp, RegExp]): {
    start: number;
    end: number;
}[];
export default function parseArguments(str: string, delimiter?: RegExp, argStartRegex?: RegExp, brackets?: [RegExp, RegExp]): string[];
