export default function parseExpression(str: string): string[];
