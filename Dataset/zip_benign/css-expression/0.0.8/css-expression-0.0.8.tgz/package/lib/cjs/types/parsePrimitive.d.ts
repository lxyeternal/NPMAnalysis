export default function parsePrimitive(rawValue: string): {
    value: number | string;
    unit: string | null;
};
