import { ICSSExpression } from './types';
export default function parse(literal: string): ICSSExpression;
