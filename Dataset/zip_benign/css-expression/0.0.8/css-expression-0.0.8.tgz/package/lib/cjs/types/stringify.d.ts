import { ICSSLiteralAny } from './types';
export default function stringify(literal: ICSSLiteralAny): string | null;
