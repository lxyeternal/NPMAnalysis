# zrt

# 游戏

##### 安装

```
npm install game-zrt
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-zrt/zrt"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource1: JSON.stringify({
      baseOps: {
        speed: { min: 10, max: 15, step: 0 },//移动速度
        firstY: 200,//首次加载游戏第一个元素的底部坐标位置
        intervalStep: 0,//两个物体之间的间隔递减值
        intervalStepH: 50,//移动指定距离递减一次
        minIntervalH: 420,//两个物体之间的最小间隔距离
        maxIntervalH: 600,//两个物体之间的间隔距离
        angule: { min: 35, max: 75 },//角度
        renderPaddingX: { left: 10, right: 10, top: -200 },
        checkV: !false,//true:根据间隔距离生成元素 false:如果最后一个元素被吃掉，立即生成下一个元素
      },
      items: [
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019FZ9q01FJvebS6ucl_!!1080040467.png", bound: { left: 0, right: 0, bottom: 0, top: 0 }, probability: 1, val: 20, audioName: "default" },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN017CBaIc1FJvebS6i9a_!!1080040467.png", bound: { left: 0, right: 0, bottom: 0, top: 0 }, probability: 1, val: 30, audioName: "default" },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Li7Tsq1FJveXoYSzF_!!1080040467.png", bound: { left: 0, right: 0, bottom: 0, top: 0 }, probability: 1, val: 10, audioName: "default" },
      ],
      player: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01h0oz3A1FJveem2oQX_!!1080040467.png", bound: { left: 0, right: 0, bottom: 0, top: 0 }, moveY: !false, bottom: 0, },

      timePos: {
        align: "right",
        x: 270,
        y: 230,
        bg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aTRiLo1FJveXoYCMd_!!1080040467.png", x: 48, y: 206 },
        time: 20,//倒计时时间
        // 时间数字图片 0 - 9
        numOffset: -6,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Ve8sS1FJvebl5J0y_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017EHyrt1FJvebEo1q2_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cv0zNh1FJveOqYcST_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0147f9921FJveYuxkj9_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017CzUN31FJveaLpTeI_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IUNX0n1FJveZB36WB_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gphOoG1FJveZB1tga_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R9M8rn1FJvedU2Nd3_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IxZxFX1FJvecmGnwT_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zIjEmp1FJveVXvVsw_!!1080040467.png", val: 9 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EPJwbR1FJveUyNoyH_!!1080040467.png", val: "s" },
        ],
      },
      tipScorePos: {
        fadeTime: 0.5,//消失时间
        numOffset: -4,//数字两边空白太多，增加偏移量
        scale: "1",
        // bg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FM8QxU1FJveZ9Z9j1_!!1080040467.png", x: 0, y: -30 },
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01bKfga31FJvefiDgi3_!!1080040467.png", val: "+" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Uk6ILV1FJvejP28uq_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01SFCu5S1FJvej7jKha_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gxqiz41FJveZ0mVJ2_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012ld0fR1FJvefiBXek_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XcnWsR1FJvef87tV4_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Acs2WA1FJvejP1sHM_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01HWYtQ71FJvehmHwkq_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GADOky1FJvefiAbQj_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jjj0bW1FJveZ0nubV_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN017VdUL61FJveZ0mq4Y_!!1080040467.png", val: 9 },
        ],
      },
      scorePos: {
        align: "left",
        x: 558,
        y: 230,
        money: true,
        bg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IrhdMn1FJvef5MQEM_!!1080040467.png", x: 434, y: 206 },
        // 分数数字图片 0 - 9
        numOffset: -6,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Ve8sS1FJvebl5J0y_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017EHyrt1FJvebEo1q2_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cv0zNh1FJveOqYcST_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0147f9921FJveYuxkj9_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017CzUN31FJveaLpTeI_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IUNX0n1FJveZB36WB_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gphOoG1FJveZB1tga_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R9M8rn1FJvedU2Nd3_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IxZxFX1FJvecmGnwT_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zIjEmp1FJveVXvVsw_!!1080040467.png", val: 9 },
        ],
      },
      audioObj: {
        default: { audioSrc: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/NN6ynLVRxg2yYI1w4cm?auth_key=1626575816-0-0-c2ef7ed5876398b278f7124e608bc20f&w=0&h=0&e=sd&t=212aa32e16263166165925531ea5a0" },//默认音效
      },
    }),
    gameSource: {
      audioObj: {
        default: { audioSrc: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/6cnFJEwIj5AGWCcBlTf?auth_key=1627012339-0-0-4a77f2e1cb870623b7edc9d2a7975c0f&w=0&h=0&e=sd&t=212c89e516267531391503399e28a1" },//默认音效
      },
      baseOps: {
        speed: { min: 15, max: 40, step: 0 },//移动速度
        firstY: 200,//首次加载游戏第一个元素的底部坐标位置
        intervalStep: 0,//两个物体之间的间隔递减值
        intervalStepH: 50,//移动指定距离递减一次
        minIntervalH: 0,//两个物体之间的最小间隔距离
        maxIntervalH: 100,//两个物体之间的间隔距离
        stepNumRandomH: [
          { min: 1, max: 1, randomY: { min: 500, max: 1000 }, rangY: { min: 0, max: 10000 } },
          { min: 2, max: 4, randomY: { min: 500, max: 1000 }, rangY: { min: 10000 } },
        ],//随机间隔球数增加间隔的距离（每隔随机数的球与下一个球距离为随机randomY） rangY:执行区间（没有max就判断为大于min以上都符合），rangY区间不能有重复
        angule: { min: 35, max: 75 },//角度
        renderPaddingX: { left: 10, right: 10, top: -800 },
        checkV: !false,
        ballRandomY: { min: 0, max: 100 }
      },
      wallBound: {//用户移动的范围，不配置默认为游戏区域
        // left: 0,
        // right: 750,
        top: 500,
        // bottom: 1000,
      },
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01FxIHpd23c04WzY06N_!!555657275.png",
          bound: { left: 45, right: 45, bottom: 45, top: 45 },
          probability: 1,
          val: 20,
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01pURAPm23c04RXEmEj_!!555657275.png",
          bound: { left: 45, right: 45, bottom: 45, top: 45 },
          probability: 1,
          val: 30,
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN0105EEGx23c04NYcVIF_!!555657275.png",
          bound: { left: 45, right: 45, bottom: 45, top: 45 },
          probability: 1,
          val: 10,
          audioName: "default"
        },
      ],
      player: {
        src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01xoiEKf23c04TsH6fM_!!555657275.png",
        bound: { left: 0, right: 0, bottom: 0, top: 45 },
        moveY: !false,
        bottom: 0,
      },
      tipScorePos: {
        fadeTime: 0.5,//消失时间
        numOffset: -4,//数字两边空白太多，增加偏移量
        scale: "1",
        // bg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FM8QxU1FJveZ9Z9j1_!!1080040467.png", x: 0, y: -30 },
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01bKfga31FJvefiDgi3_!!1080040467.png", val: "+" },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Uk6ILV1FJvejP28uq_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01SFCu5S1FJvej7jKha_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gxqiz41FJveZ0mVJ2_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012ld0fR1FJvefiBXek_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XcnWsR1FJvef87tV4_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Acs2WA1FJvejP1sHM_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01HWYtQ71FJvehmHwkq_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GADOky1FJvefiAbQj_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jjj0bW1FJveZ0nubV_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN017VdUL61FJveZ0mq4Y_!!1080040467.png", val: 9 },
        ],
      },
      timePos: {
        align: "right",
        x: 270,
        y: 230,
        bg: {
          src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01SqKaAA23c04M4oqRY_!!555657275.png",
          x: 48,
          y: 206
        },
        time: 30,//倒计时时间
        // 时间数字图片 0 - 9
        numOffset: -6,//数字两边空白太多，增加偏移量
        numArr: [
          {
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Ve8sS1FJvebl5J0y_!!1080040467.png",
            val: 0
          },
          {
            "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017EHyrt1FJvebEo1q2_!!1080040467.png",
            val: 1
          },
          {
            "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cv0zNh1FJveOqYcST_!!1080040467.png",
            val: 2
          },
          {
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0147f9921FJveYuxkj9_!!1080040467.png",
            val: 3
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017CzUN31FJveaLpTeI_!!1080040467.png",
            val: 4
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IUNX0n1FJveZB36WB_!!1080040467.png",
            val: 5
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gphOoG1FJveZB1tga_!!1080040467.png",
            val: 6
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R9M8rn1FJvedU2Nd3_!!1080040467.png",
            val: 7
          },
          {
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IxZxFX1FJvecmGnwT_!!1080040467.png",
            val: 8
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zIjEmp1FJveVXvVsw_!!1080040467.png",
            val: 9
          },
          {
            "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EPJwbR1FJveUyNoyH_!!1080040467.png",
            val: "s"
          },
        ],
      },
      /* tipScorePos: {
        fadeTime: 0.5,//消失时间
        numOffset: -4,//数字两边空白太多，增加偏移量
        scale: "1.5",
        bg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FM8QxU1FJveZ9Z9j1_!!1080040467.png", x: 0, y: -30 },
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01T251Kg1FJveOa46G1_!!1080040467.png", val: "+" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yPU5CY1FJveWIxirL_!!1080040467.png", val: "s" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DPEQwk1FJveJhg5Vy_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lXNJlP1FJveZsuPSq_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ponlGV1FJveVBdVc5_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BR76pf1FJveYJ1Jul_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YOYyMu1FJveZsvLg6_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pq3Y1f1FJveSOfyl0_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uQqQ7v1FJveOLnbeu_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01coylPi1FJveQP6SyQ_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EwOq2Z1FJveZ9Y9LM_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01m44Vvm1FJveVBfFi3_!!1080040467.png", val: 9 },
        ],
      }, */
      scorePos: {
        align: "left",
        x: 595,
        y: 230,
        money: true,
        bg: {
          src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01kmrUWc23c04QDZMUn_!!555657275.png",
          x: 434,
          y: 206
        },
        // 分数数字图片 0 - 9
        numOffset: -6,//数字两边空白太多，增加偏移量
        numArr: [
          {
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013Ve8sS1FJvebl5J0y_!!1080040467.png",
            val: 0
          },
          {
            "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017EHyrt1FJvebEo1q2_!!1080040467.png",
            val: 1
          },
          {
            "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Cv0zNh1FJveOqYcST_!!1080040467.png",
            val: 2
          },
          {
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0147f9921FJveYuxkj9_!!1080040467.png",
            val: 3
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017CzUN31FJveaLpTeI_!!1080040467.png",
            val: 4
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IUNX0n1FJveZB36WB_!!1080040467.png",
            val: 5
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01gphOoG1FJveZB1tga_!!1080040467.png",
            val: 6
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R9M8rn1FJvedU2Nd3_!!1080040467.png",
            val: 7
          },
          {
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IxZxFX1FJvecmGnwT_!!1080040467.png",
            val: 8
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zIjEmp1FJveVXvVsw_!!1080040467.png",
            val: 9
          },
        ],
      },
    }
  },
  onLoad(query) {
  },

  playFun() {
    this.gameComponent.onEvent("start");
  },
  resetFun() {
    this.gameComponent.onEvent("reset");
  },
  pause() {
    // 暂停、继续
    this.gameComponent.onEvent("pause");
  },
  stop() {
    // 暂停、继续
    this.gameComponent.onEvent("gameOver");
  },

  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // this.playFun();
  },
  onUpdate(ops) {
    // { totalScore: 0, imgObj: { } }
    console.log(ops)
  },
  onGameOver({ totalScore }) {
    console.log(totalScore)
  }
})
```

- xaml

```
  <game gameSource="{{gameSource}}" 
    onRef="onRef"
    onInitDone="onInitDone" 
    onUpdate="onUpdate" 
    onGameOver="onGameOver"
    />

  <view onTap="playFun" style="position:absolute;left: 40%;bottom: 100rpx;">开始</view>
  <view onTap="resetFun" style="position:absolute;left: 50%;bottom: 100rpx;">重置</view>
  <view onTap="pause" style="position:absolute;left: 60%;bottom: 100rpx;">暂停</view>
  <view onTap="stop" style="position:absolute;left: 70%;bottom: 100rpx;">结束</view>
```