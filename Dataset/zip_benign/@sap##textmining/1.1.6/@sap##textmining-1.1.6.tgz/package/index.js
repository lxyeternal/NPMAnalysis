/*
 * (c) Copyright 2015-2016 SAP SE. All rights reserved
 */

'use strict';

module.exports = require('./lib/textmining');
