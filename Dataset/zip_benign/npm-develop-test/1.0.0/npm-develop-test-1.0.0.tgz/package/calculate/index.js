var convert = require("./convert");
var count = require("./count");
var joint = require("./joint");

exports.calculate=function (obj) {
    return count.count(convert.convert(joint.joint(obj)));
};