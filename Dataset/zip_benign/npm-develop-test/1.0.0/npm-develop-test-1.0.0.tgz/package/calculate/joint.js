exports.joint = function (dataobj) {
    var tems = dataobj.formula.split(/([+]|[-]|[*]|[/]|[(]|[)])/);
    var result = [];
    for (let tem of tems) {
        if (tem!=='') {
            if(tem!=='+'&&tem!=='-'&&tem!=='*'&&tem!=='/'&&tem!=='('&&tem!==')'){
                result.push(dataobj.data[tem]);
            }else{
                result.push(tem);
            }
        }
    }
    return result;
};