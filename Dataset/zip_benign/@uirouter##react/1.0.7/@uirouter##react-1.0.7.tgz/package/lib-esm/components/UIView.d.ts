import * as React from 'react';
import { ComponentType, ReactNode, Component } from 'react';
import { StateParams, Transition, ViewContext } from '@uirouter/core';
/** @internal */
export interface UIViewAddress {
    context: ViewContext;
    fqn: string;
}
/**
 * Interface for [[InjectedProps.resolves]]
 *
 * This Typescript interface shows what fields are available on the `resolves` field.
 */
export interface UIViewResolves {
    /**
     * Any key/value pair defined by a state's resolve
     *
     * If a state defines any [[ReactStateDeclaration.resolve]]s, they will be found on this object.
     */
    [key: string]: any;
    /**
     * The `StateParams` for the `Transition` that activated the component
     *
     * This is an alias for:
     * ```js
     * let $stateParams = $transition$.params("to");
     * ```
     */
    $stateParams: StateParams;
    /** The `Transition` that activated the component */
    $transition$: Transition;
}
/**
 * Function type for [[UIViewProps.render]]
 *
 * If the `render` function prop is provided, the `UIView` will use it instead of rendering the component by itself.
 * @internal
 */
export declare type RenderPropCallback = (Component: ComponentType<any>, Props: any) => JSX.Element | null;
export interface UIViewInjectedProps {
    transition?: Transition;
    resolves?: UIViewResolves;
    className?: string;
    style?: Object;
}
/** React Props for the [[UIView]] component */
export interface UIViewProps {
    /** default content that will be rendered when no child component is loaded into the UIView viewport */
    children?: ReactNode;
    /**
     * The name of the [[UIView]].
     *
     * Assigns a name to this [[UIView]] Portal.
     * see: [Multiple Named Views](https://ui-router.github.io/guide/views#multiple-named-uiviews)
     */
    name?: string;
    /** This prop will be applied to the routed component. */
    className?: string;
    /** This prop will be applied to the routed component. */
    style?: Object;
    /** This render prop can be used to customize the rendering of  routed components. */
    render?: RenderPropCallback;
}
export declare const TransitionPropCollisionError: string;
/** @internal */
export declare const UIViewContext: React.Context<UIViewAddress>;
/** @deprecated use [[useParentView]] or React.useContext(UIViewContext) */
export declare const UIViewConsumer: React.Consumer<UIViewAddress>;
/**
 * UIView Viewport
 *
 * The UIView component is a viewport for a routed components.
 * Routed components will be rendered inside the UIView viewport.
 *
 * ### Example
 * ```
 * function MyApp() {
 *   return (
 *     <div className="MyApp">
 *       <UIView />
 *     </div>
 *   );
 * }
 * ```
 *
 * See [[UIViewProps]] for details on the props this component takes.
 *
 * @noInheritDoc
 */
export declare class UIView extends Component<UIViewProps> {
    /** @internal */
    static displayName: string;
    /** @internal */
    static propTypes: React.WeakValidationMap<UIViewProps & React.RefAttributes<unknown>>;
    /** @internal */
    static __internalViewComponent: ComponentType<UIViewProps>;
    /** @internal */
    render(): JSX.Element;
}
