var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as React from 'react';
import { useState, useCallback, useContext, useMemo, cloneElement } from 'react';
import classNames from 'classnames';
import { useCurrentStateAndParams, useRouter } from '../hooks';
/** @internal */
var rootAddStateInfoFn = function () { return function () { return undefined; }; };
export var UISrefActiveContext = React.createContext(rootAddStateInfoFn);
/**
 * A component that applies an 'active' class when a [[UISref]] component's state is active.
 *
 * If you are using functional components, consider using the [[useSrefActive]] hook instead.
 *
 * This component works together with `[[UISref]]` child components.
 * It adds an active class to its child element when any of its children `[[UISref]]`'s state is active.
 *
 * This component can be used to highlight the active state in a navigation menu.
 *
 * ```jsx
 * <UISrefActive class="active-item">
 *   <UISref to="homestate"><a className="menu-item">Home</a></UISref>
 * </UISrefActive>
 *
 * // rendered when state is inactive
 * <a href="/path/to/homestate" class="menu-item">Home</a>
 *
 * // rendered when state is active
 * <a href="/path/to/homestate" class="menu-item active-item">Home</a>
 * ```
 *
 * Note: A `UISrefActive` will add the class if any child `UISref` is active.
 * This can be used to highlight a parent nav item if any nested child nav items are active.
 *
 *
 * ```jsx
 * <UISrefActive class="active">
 *   <div className="menu-item-dropdown">
 *     <span>Admin<span>
 *     <ul>
 *       <li><UISref to="users"><a className="menu-item">Users</a></UISref></li>
 *       <li><UISref to="groups"><a className="menu-item">Groups</a></UISref></li>
 *     </ul>
 *   </div>
 * </UISrefActive>
 *
 * // rendered with either users or groups states are active
 * <div className="active menu-item-dropdown">
 * ```
 */
export function UISrefActive(_a) {
    var children = _a.children, className = _a.className, classToApply = _a.class, exact = _a.exact;
    var stateService = useRouter().stateService;
    var parentAddStateInfo = useContext(UISrefActiveContext);
    // keep track of states to watch and their activeClasses
    var _b = useState([]), uiSrefs = _b[0], setUiSrefs = _b[1];
    var currentState = useCurrentStateAndParams();
    var isAnyUiSrefActive = useMemo(function () {
        return uiSrefs.some(function (_a) {
            var stateName = _a.stateName, params = _a.params;
            return exact ? stateService.is(stateName, params) : stateService.includes(stateName, params);
        });
    }, [uiSrefs, exact, stateService, currentState]);
    var addStateInfo = useCallback(function (stateName, params) {
        var parentDeregister = parentAddStateInfo(stateName, params);
        var addedUiSref = { stateName: stateName, params: params };
        setUiSrefs(function (uiSrefs) { return uiSrefs.concat(addedUiSref); });
        return function () {
            parentDeregister();
            setUiSrefs(function (uiSrefs) { return uiSrefs.filter(function (x) { return x !== addedUiSref; }); });
        };
    }, [parentAddStateInfo]);
    // If any active class is defined, apply it the children
    var childrenWithActiveClasses = isAnyUiSrefActive
        ? cloneElement(children, __assign(__assign({}, children.props), { className: classNames(className, children.props.className, classToApply) }))
        : children;
    return React.createElement(UISrefActiveContext.Provider, { value: addStateInfo }, childrenWithActiveClasses);
}
//# sourceMappingURL=UISrefActive.js.map