/** @internal Internal hook to support deep diffing in hook dependencies */
export declare function useDeepObjectDiff(obj: object): number;
