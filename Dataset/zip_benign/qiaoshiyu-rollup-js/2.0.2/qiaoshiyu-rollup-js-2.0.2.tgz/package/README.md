<!-- 解决js的精度问题。 -->
暂时未对  console.log(1+2);（不存在=赋值的情况）的处理
``
示例代码
import { PrecisionArea } from 'qiaoshiyu-rollup-js';
PrecisionArea(() => {
    let w = 0.1 + 0.2;
    console.log(w);//0.3
  }).then((res) => {
    eval(res);
  });
安装方式：npm install qiaoshiyu-rollup-js --save
``
<!-- 注册register方法，添加window的全局方法 -->