export { ApCalendarModule } from './calendar.module';
//# sourceMappingURL=index.js.map