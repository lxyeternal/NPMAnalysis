import * as i0 from "@angular/core";
import * as i1 from "./calendar.module";
import * as i2 from "./calendar.ngfactory";
import * as i3 from "@angular/common";
import * as i4 from "@ionic/angular";
import * as i5 from "./calendar.service";
var ApCalendarModuleNgFactory = i0.ɵcmf(i1.ApCalendarModule, [], function (_l) { return i0.ɵmod([i0.ɵmpd(512, i0.ComponentFactoryResolver, i0.ɵCodegenComponentFactoryResolver, [[8, [i2.CalendarComponentNgFactory]], [3, i0.ComponentFactoryResolver], i0.NgModuleRef]), i0.ɵmpd(4608, i3.NgLocalization, i3.NgLocaleLocalization, [i0.LOCALE_ID, [2, i3.ɵangular_packages_common_common_a]]), i0.ɵmpd(4608, i4.AngularDelegate, i4.AngularDelegate, [i0.NgZone, i0.ApplicationRef]), i0.ɵmpd(4608, i4.ModalController, i4.ModalController, [i4.AngularDelegate, i0.ComponentFactoryResolver, i0.Injector]), i0.ɵmpd(4608, i4.PopoverController, i4.PopoverController, [i4.AngularDelegate, i0.ComponentFactoryResolver, i0.Injector]), i0.ɵmpd(4608, i5.CalendarService, i5.CalendarService, []), i0.ɵmpd(1073742336, i3.CommonModule, i3.CommonModule, []), i0.ɵmpd(1073742336, i4.IonicModule, i4.IonicModule, []), i0.ɵmpd(1073742336, i1.ApCalendarModule, i1.ApCalendarModule, [])]); });
export { ApCalendarModuleNgFactory as ApCalendarModuleNgFactory };
//# sourceMappingURL=calendar.module.ngfactory.js.map