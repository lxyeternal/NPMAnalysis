import * as i0 from '@angular/core';
import * as i1 from './calendar.module';
export declare const ApCalendarModuleNgFactory: i0.NgModuleFactory<i1.ApCalendarModule>;
