var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import 'intl';
import 'intl/locale-data/jsonp/en';
import { MonthViewComponent } from './monthview';
import { WeekViewComponent } from './weekview';
import { DayViewComponent } from './dayview';
import { CalendarComponent } from './calendar';
import { CalendarService } from './calendar.service';
import { initPositionScrollComponent } from './init-position-scroll';
var ApCalendarModule = (function () {
    function ApCalendarModule() {
    }
    ApCalendarModule = __decorate([
        NgModule({
            declarations: [
                MonthViewComponent, WeekViewComponent, DayViewComponent, CalendarComponent, initPositionScrollComponent
            ],
            imports: [
                CommonModule,
                IonicModule
            ],
            providers: [
                CalendarService
            ],
            exports: [CalendarComponent],
            entryComponents: [CalendarComponent]
        })
    ], ApCalendarModule);
    return ApCalendarModule;
}());
export { ApCalendarModule };
//# sourceMappingURL=calendar.module.js.map