import * as i0 from "@angular/core";
import * as i1 from "../node_modules/@ionic/angular/dist/core.ngfactory";
import * as i2 from "@ionic/angular";
import * as i3 from "./init-position-scroll";
var styles_initPositionScrollComponent = [];
var RenderType_initPositionScrollComponent = i0.ɵcrt({ encapsulation: 2, styles: styles_initPositionScrollComponent, data: {} });
export { RenderType_initPositionScrollComponent as RenderType_initPositionScrollComponent };
export function View_initPositionScrollComponent_0(_l) { return i0.ɵvid(0, [(_l()(), i0.ɵeld(0, 0, null, null, 2, "ion-content", [["scrollY", "true"], ["style", "height:100%"], ["zoom", "false"]], null, null, null, i1.View_IonContent_0, i1.RenderType_IonContent)), i0.ɵdid(1, 49152, null, 0, i2.IonContent, [i0.ChangeDetectorRef, i0.ElementRef], { scrollY: [0, "scrollY"] }, null), i0.ɵncd(0, 0)], function (_ck, _v) { var currVal_0 = "true"; _ck(_v, 1, 0, currVal_0); }, null); }
export function View_initPositionScrollComponent_Host_0(_l) { return i0.ɵvid(0, [(_l()(), i0.ɵeld(0, 0, null, null, 1, "init-position-scroll", [], null, null, null, View_initPositionScrollComponent_0, RenderType_initPositionScrollComponent)), i0.ɵdid(1, 4898816, null, 0, i3.initPositionScrollComponent, [i0.ElementRef], null, null)], null, null); }
var initPositionScrollComponentNgFactory = i0.ɵccf("init-position-scroll", i3.initPositionScrollComponent, View_initPositionScrollComponent_Host_0, { initPosition: "initPosition", emitEvent: "emitEvent" }, { onScroll: "onScroll" }, ["*"]);
export { initPositionScrollComponentNgFactory as initPositionScrollComponentNgFactory };
//# sourceMappingURL=init-position-scroll.ngfactory.js.map