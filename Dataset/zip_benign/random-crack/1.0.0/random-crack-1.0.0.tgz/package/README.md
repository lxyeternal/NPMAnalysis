# Introduction
A NodeJS library to appoximate the next generated Math.random() <bold>50% chances</bold> value, won't 100% accurate though. Reminder that this only approximates if its above 0.5 or below 0.5, great for 50% games.
# Documentation
```.resolve(num: Array[])```<br>
To use this function, generate 15 (minimum) Math.random() values using ```Array.from(Array(15), Math.random))``` <bold>in terminal/browser console.</bold> (can be anything but do not close the session). After that copy the array the code outputs and put it into the `num` argument. 
# To use
If you are still in the same session, try doing `Math.random()` again and the output should be approximately as the resolve() function value (based on the 50% chances)<br>
Consider giving me a feedback to improve this!