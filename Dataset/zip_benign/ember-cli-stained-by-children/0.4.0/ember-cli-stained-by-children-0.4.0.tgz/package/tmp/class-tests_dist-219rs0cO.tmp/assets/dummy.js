/* jshint ignore:start */

/* jshint ignore:end */

define('dummy/app', ['exports', 'ember', 'ember/resolver', 'ember/load-initializers', 'dummy/config/environment'], function (exports, Ember, Resolver, loadInitializers, config) {

  'use strict';

  Ember['default'].MODEL_FACTORY_INJECTIONS = true;

  var App = Ember['default'].Application.extend({
    modulePrefix: config['default'].modulePrefix,
    podModulePrefix: config['default'].podModulePrefix,
    Resolver: Resolver['default']
  });

  loadInitializers['default'](App, config['default'].modulePrefix);

  exports['default'] = App;

});
define('dummy/initializers/app-version', ['exports', 'dummy/config/environment', 'ember'], function (exports, config, Ember) {

  'use strict';

  var classify = Ember['default'].String.classify;

  exports['default'] = {
    name: "App Version",
    initialize: function (container, application) {
      var appName = classify(application.toString());
      Ember['default'].libraries.register(appName, config['default'].APP.version);
    }
  };

});
define('dummy/initializers/export-application-global', ['exports', 'ember', 'dummy/config/environment'], function (exports, Ember, config) {

  'use strict';

  exports.initialize = initialize;

  function initialize(container, application) {
    var classifiedName = Ember['default'].String.classify(config['default'].modulePrefix);

    if (config['default'].exportApplicationGlobal && !window[classifiedName]) {
      window[classifiedName] = application;
    }
  };

  exports['default'] = {
    name: "export-application-global",

    initialize: initialize
  };

});
define('dummy/models/bar', ['exports', 'ember-data'], function (exports, DS) {

  'use strict';

  exports['default'] = DS['default'].Model.extend({
    foo: DS['default'].belongsTo("foo"),
    val: DS['default'].attr("boolean", { defaultValue: false })
  });

});
define('dummy/models/baz', ['exports', 'ember-data', 'stained-by-children/stained-by-children', 'stained-by-children/clean-embedded-children'], function (exports, DS, StainedByChildrenMixin, CleanEmbeddedChildrenMixin) {

  'use strict';

  exports['default'] = DS['default'].Model.extend(StainedByChildrenMixin['default'], CleanEmbeddedChildrenMixin['default'], {
    foo: DS['default'].belongsTo("foo"),
    quux: DS['default'].belongsTo("quux", { stains: true, embeddedChild: true }),
    val: DS['default'].attr("boolean", { defaultValue: false })
  });

});
define('dummy/models/foo', ['exports', 'ember-data', 'stained-by-children/stained-by-children', 'stained-by-children/clean-embedded-children'], function (exports, DS, StainedByChildrenMixin, CleanEmbeddedChildrenMixin) {

  'use strict';

  exports['default'] = DS['default'].Model.extend(StainedByChildrenMixin['default'], CleanEmbeddedChildrenMixin['default'], {
    bars: DS['default'].hasMany("bar", { stains: true, embeddedChild: true }),
    baz: DS['default'].belongsTo("baz", { stains: true, embeddedChild: true }),
    val: DS['default'].attr("boolean", { defaultValue: false })
  });

});
define('dummy/models/quux', ['exports', 'ember-data'], function (exports, DS) {

  'use strict';

  exports['default'] = DS['default'].Model.extend({
    baz: DS['default'].belongsTo("baz"),
    val: DS['default'].attr("boolean", { defaultValue: false })
  });

});
define('dummy/router', ['exports', 'ember', 'dummy/config/environment'], function (exports, Ember, config) {

  'use strict';

  var Router = Ember['default'].Router.extend({
    location: config['default'].locationType
  });

  Router.map(function () {});

  exports['default'] = Router;

});
define('dummy/routes/index', ['exports', 'ember'], function (exports, Ember) {

  'use strict';

  exports['default'] = Ember['default'].Route.extend({
    model: function () {
      this.store.push("foo", { id: 1 });
      this.store.push("bar", { id: 1, foo: 1 });
      this.store.push("bar", { id: 2, foo: 1 });
      this.store.push("baz", { id: 1, foo: 1 });

      return this.store.find("foo", 1);
    }
  });

});
define('dummy/stained-by-children/tests/modules/stained-by-children/clean-embedded-children.jshint', function () {

  'use strict';

  module("JSHint - modules/stained-by-children");
  test("modules/stained-by-children/clean-embedded-children.js should pass jshint", function () {
    ok(true, "modules/stained-by-children/clean-embedded-children.js should pass jshint.");
  });

});
define('dummy/stained-by-children/tests/modules/stained-by-children/stained-by-children.jshint', function () {

  'use strict';

  module("JSHint - modules/stained-by-children");
  test("modules/stained-by-children/stained-by-children.js should pass jshint", function () {
    ok(true, "modules/stained-by-children/stained-by-children.js should pass jshint.");
  });

});
define('dummy/templates/application', ['exports'], function (exports) {

  'use strict';

  exports['default'] = Ember.HTMLBars.template((function() {
    return {
      isHTMLBars: true,
      blockParams: 0,
      cachedFragment: null,
      hasRendered: false,
      build: function build(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createElement("h2");
        dom.setAttribute(el1,"id","title");
        var el2 = dom.createTextNode("Welcome to Ember.js, yo");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        return el0;
      },
      render: function render(context, env, contextualElement) {
        var dom = env.dom;
        var hooks = env.hooks, content = hooks.content;
        dom.detectNamespace(contextualElement);
        var fragment;
        if (env.useFragmentCache && dom.canClone) {
          if (this.cachedFragment === null) {
            fragment = this.build(dom);
            if (this.hasRendered) {
              this.cachedFragment = fragment;
            } else {
              this.hasRendered = true;
            }
          }
          if (this.cachedFragment) {
            fragment = dom.cloneNode(this.cachedFragment, true);
          }
        } else {
          fragment = this.build(dom);
        }
        var morph0 = dom.createMorphAt(fragment,1,2,contextualElement);
        content(env, morph0, context, "outlet");
        return fragment;
      }
    };
  }()));

});
define('dummy/templates/index', ['exports'], function (exports) {

  'use strict';

  exports['default'] = Ember.HTMLBars.template((function() {
    var child0 = (function() {
      var child0 = (function() {
        return {
          isHTMLBars: true,
          blockParams: 0,
          cachedFragment: null,
          hasRendered: false,
          build: function build(dom) {
            var el0 = dom.createDocumentFragment();
            var el1 = dom.createTextNode("      ");
            dom.appendChild(el0, el1);
            var el1 = dom.createElement("li");
            var el2 = dom.createTextNode("\n        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("p");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("p");
            var el3 = dom.createTextNode("isDirty: ");
            dom.appendChild(el2, el3);
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n        ");
            dom.appendChild(el1, el2);
            var el2 = dom.createElement("p");
            dom.appendChild(el1, el2);
            var el2 = dom.createTextNode("\n      ");
            dom.appendChild(el1, el2);
            dom.appendChild(el0, el1);
            var el1 = dom.createTextNode("\n");
            dom.appendChild(el0, el1);
            return el0;
          },
          render: function render(context, env, contextualElement) {
            var dom = env.dom;
            var hooks = env.hooks, content = hooks.content, get = hooks.get, inline = hooks.inline;
            dom.detectNamespace(contextualElement);
            var fragment;
            if (env.useFragmentCache && dom.canClone) {
              if (this.cachedFragment === null) {
                fragment = this.build(dom);
                if (this.hasRendered) {
                  this.cachedFragment = fragment;
                } else {
                  this.hasRendered = true;
                }
              }
              if (this.cachedFragment) {
                fragment = dom.cloneNode(this.cachedFragment, true);
              }
            } else {
              fragment = this.build(dom);
            }
            var element0 = dom.childAt(fragment, [1]);
            var morph0 = dom.createMorphAt(dom.childAt(element0, [1]),-1,-1);
            var morph1 = dom.createMorphAt(dom.childAt(element0, [3]),0,-1);
            var morph2 = dom.createMorphAt(dom.childAt(element0, [5]),-1,-1);
            content(env, morph0, context, "bar");
            content(env, morph1, context, "bar.isDirty");
            inline(env, morph2, context, "input", [], {"type": "checkbox", "checked": get(env, context, "bar.val")});
            return fragment;
          }
        };
      }());
      return {
        isHTMLBars: true,
        blockParams: 0,
        cachedFragment: null,
        hasRendered: false,
        build: function build(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("  ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("h2");
          var el2 = dom.createTextNode("Bars:");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n  ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("ul");
          var el2 = dom.createTextNode("\n");
          dom.appendChild(el1, el2);
          var el2 = dom.createTextNode("  ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        render: function render(context, env, contextualElement) {
          var dom = env.dom;
          var hooks = env.hooks, get = hooks.get, block = hooks.block;
          dom.detectNamespace(contextualElement);
          var fragment;
          if (env.useFragmentCache && dom.canClone) {
            if (this.cachedFragment === null) {
              fragment = this.build(dom);
              if (this.hasRendered) {
                this.cachedFragment = fragment;
              } else {
                this.hasRendered = true;
              }
            }
            if (this.cachedFragment) {
              fragment = dom.cloneNode(this.cachedFragment, true);
            }
          } else {
            fragment = this.build(dom);
          }
          var morph0 = dom.createMorphAt(dom.childAt(fragment, [3]),0,1);
          block(env, morph0, context, "each", [get(env, context, "bars")], {"keyword": "bar"}, child0, null);
          return fragment;
        }
      };
    }());
    var child1 = (function() {
      return {
        isHTMLBars: true,
        blockParams: 0,
        cachedFragment: null,
        hasRendered: false,
        build: function build(dom) {
          var el0 = dom.createDocumentFragment();
          var el1 = dom.createTextNode("  ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("h2");
          var el2 = dom.createTextNode("Baz:");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n  ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n  ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          var el2 = dom.createTextNode("isDirty: ");
          dom.appendChild(el1, el2);
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n  ");
          dom.appendChild(el0, el1);
          var el1 = dom.createElement("p");
          dom.appendChild(el0, el1);
          var el1 = dom.createTextNode("\n");
          dom.appendChild(el0, el1);
          return el0;
        },
        render: function render(context, env, contextualElement) {
          var dom = env.dom;
          var hooks = env.hooks, content = hooks.content, get = hooks.get, inline = hooks.inline;
          dom.detectNamespace(contextualElement);
          var fragment;
          if (env.useFragmentCache && dom.canClone) {
            if (this.cachedFragment === null) {
              fragment = this.build(dom);
              if (this.hasRendered) {
                this.cachedFragment = fragment;
              } else {
                this.hasRendered = true;
              }
            }
            if (this.cachedFragment) {
              fragment = dom.cloneNode(this.cachedFragment, true);
            }
          } else {
            fragment = this.build(dom);
          }
          var morph0 = dom.createMorphAt(dom.childAt(fragment, [3]),-1,-1);
          var morph1 = dom.createMorphAt(dom.childAt(fragment, [5]),0,-1);
          var morph2 = dom.createMorphAt(dom.childAt(fragment, [7]),-1,-1);
          content(env, morph0, context, "baz");
          content(env, morph1, context, "baz.isDirty");
          inline(env, morph2, context, "input", [], {"type": "checkbox", "checked": get(env, context, "baz.val")});
          return fragment;
        }
      };
    }());
    return {
      isHTMLBars: true,
      blockParams: 0,
      cachedFragment: null,
      hasRendered: false,
      build: function build(dom) {
        var el0 = dom.createDocumentFragment();
        var el1 = dom.createTextNode("");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        var el2 = dom.createTextNode("isDirty: ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        var el2 = dom.createTextNode("areChildrenDirty: ");
        dom.appendChild(el1, el2);
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createElement("p");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("\n");
        dom.appendChild(el0, el1);
        var el1 = dom.createTextNode("");
        dom.appendChild(el0, el1);
        return el0;
      },
      render: function render(context, env, contextualElement) {
        var dom = env.dom;
        var hooks = env.hooks, content = hooks.content, get = hooks.get, inline = hooks.inline, block = hooks.block;
        dom.detectNamespace(contextualElement);
        var fragment;
        if (env.useFragmentCache && dom.canClone) {
          if (this.cachedFragment === null) {
            fragment = this.build(dom);
            if (this.hasRendered) {
              this.cachedFragment = fragment;
            } else {
              this.hasRendered = true;
            }
          }
          if (this.cachedFragment) {
            fragment = dom.cloneNode(this.cachedFragment, true);
          }
        } else {
          fragment = this.build(dom);
        }
        if (this.cachedFragment) { dom.repairClonedNode(fragment,[0,11]); }
        var morph0 = dom.createMorphAt(fragment,0,1,contextualElement);
        var morph1 = dom.createMorphAt(dom.childAt(fragment, [2]),-1,-1);
        var morph2 = dom.createMorphAt(dom.childAt(fragment, [4]),0,-1);
        var morph3 = dom.createMorphAt(dom.childAt(fragment, [6]),0,-1);
        var morph4 = dom.createMorphAt(dom.childAt(fragment, [8]),-1,-1);
        var morph5 = dom.createMorphAt(fragment,9,10,contextualElement);
        var morph6 = dom.createMorphAt(fragment,10,11,contextualElement);
        content(env, morph0, context, "outlet");
        content(env, morph1, context, "model");
        content(env, morph2, context, "isDirty");
        content(env, morph3, context, "areChildrenDirty");
        inline(env, morph4, context, "input", [], {"type": "checkbox", "checked": get(env, context, "val")});
        block(env, morph5, context, "if", [get(env, context, "bars.length")], {}, child0, null);
        block(env, morph6, context, "if", [get(env, context, "baz")], {}, child1, null);
        return fragment;
      }
    };
  }()));

});
define('dummy/tests/app.jshint', function () {

  'use strict';

  module('JSHint - .');
  test('app.js should pass jshint', function() { 
    ok(true, 'app.js should pass jshint.'); 
  });

});
define('dummy/tests/helpers/resolver', ['exports', 'ember/resolver', 'dummy/config/environment'], function (exports, Resolver, config) {

  'use strict';

  var resolver = Resolver['default'].create();

  resolver.namespace = {
    modulePrefix: config['default'].modulePrefix,
    podModulePrefix: config['default'].podModulePrefix
  };

  exports['default'] = resolver;

});
define('dummy/tests/helpers/resolver.jshint', function () {

  'use strict';

  module('JSHint - helpers');
  test('helpers/resolver.js should pass jshint', function() { 
    ok(true, 'helpers/resolver.js should pass jshint.'); 
  });

});
define('dummy/tests/helpers/start-app', ['exports', 'ember', 'dummy/app', 'dummy/router', 'dummy/config/environment'], function (exports, Ember, Application, Router, config) {

  'use strict';



  exports['default'] = startApp;
  function startApp(attrs) {
    var application;

    var attributes = Ember['default'].merge({}, config['default'].APP);
    attributes = Ember['default'].merge(attributes, attrs); // use defaults, but you can override;

    Ember['default'].run(function () {
      application = Application['default'].create(attributes);
      application.setupForTesting();
      application.injectTestHelpers();
    });

    return application;
  }

});
define('dummy/tests/helpers/start-app.jshint', function () {

  'use strict';

  module('JSHint - helpers');
  test('helpers/start-app.js should pass jshint', function() { 
    ok(true, 'helpers/start-app.js should pass jshint.'); 
  });

});
define('dummy/tests/models/bar.jshint', function () {

  'use strict';

  module('JSHint - models');
  test('models/bar.js should pass jshint', function() { 
    ok(true, 'models/bar.js should pass jshint.'); 
  });

});
define('dummy/tests/models/baz.jshint', function () {

  'use strict';

  module('JSHint - models');
  test('models/baz.js should pass jshint', function() { 
    ok(true, 'models/baz.js should pass jshint.'); 
  });

});
define('dummy/tests/models/foo.jshint', function () {

  'use strict';

  module('JSHint - models');
  test('models/foo.js should pass jshint', function() { 
    ok(true, 'models/foo.js should pass jshint.'); 
  });

});
define('dummy/tests/models/quux.jshint', function () {

  'use strict';

  module('JSHint - models');
  test('models/quux.js should pass jshint', function() { 
    ok(true, 'models/quux.js should pass jshint.'); 
  });

});
define('dummy/tests/router.jshint', function () {

  'use strict';

  module('JSHint - .');
  test('router.js should pass jshint', function() { 
    ok(true, 'router.js should pass jshint.'); 
  });

});
define('dummy/tests/routes/index.jshint', function () {

  'use strict';

  module('JSHint - routes');
  test('routes/index.js should pass jshint', function() { 
    ok(true, 'routes/index.js should pass jshint.'); 
  });

});
define('dummy/tests/test-helper', ['dummy/tests/helpers/resolver', 'ember-qunit'], function (resolver, ember_qunit) {

	'use strict';

	ember_qunit.setResolver(resolver['default']);

});
define('dummy/tests/test-helper.jshint', function () {

  'use strict';

  module('JSHint - .');
  test('test-helper.js should pass jshint', function() { 
    ok(true, 'test-helper.js should pass jshint.'); 
  });

});
define('dummy/tests/unit/models/foo-test', ['ember', 'ember-qunit'], function (Ember, ember_qunit) {

  'use strict';

  ember_qunit.moduleForModel("foo", "Foo", {
    // Specify the other units that are required for this test.
    needs: ["model:bar", "model:baz", "model:quux"]
  });

  var setupTestData = function (store) {
    // foo
    store.push("foo", { id: "1", bars: ["1", "2"], baz: "1" });

    // bar
    store.pushMany("bar", [{ id: "1", foo: "1" }, { id: "2", foo: "1" }, { id: "3", foo: "1" }]);

    // baz
    store.push("baz", { id: "1", foo: "1", quux: "1" });

    // quux
    store.push("quux", { id: "1", baz: "1", str: "quux" });

    return store;
  };

  ember_qunit.test("it exists", function (assert) {
    var model = this.subject();
    // var store = this.store();
    assert.ok(!!model);
  });

  ember_qunit.test("StainedByChildrenMixin: Changing a grandchild quux should stain parent foo", function (assert) {
    Ember['default'].run((function () {
      var store = setupTestData(this.store());

      var foo = store.all("foo").findBy("id", "1");
      var bar1 = store.all("bar").findBy("id", "1");
      var baz = store.all("baz").findBy("id", "1");
      var quux = store.all("quux").findBy("id", "1");

      assert.ok(!foo.get("isDirty"));

      quux.set("val", true);

      assert.ok(baz.get("isDirty"));
      assert.ok(foo.get("isDirty"));
      assert.ok(!bar1.get("isDirty"));
    }).bind(this));
  });


  ember_qunit.test("CleanEmbeddedChildrenMixin: Triggering _commitChildren on parent should clean children", function (assert) {
    Ember['default'].run((function () {
      var store = setupTestData(this.store());

      var foo = store.all("foo").findBy("id", "1");
      var bar1 = store.all("bar").findBy("id", "1");
      var baz = store.all("baz").findBy("id", "1");
      var quux = store.all("quux").findBy("id", "1");

      bar1.set("val", true);
      baz.set("val", true);
      quux.set("val", true);

      foo._cleanChildren();

      assert.ok(!bar1.get("isDirty"));
      assert.ok(!baz.get("isDirty"));
      assert.ok(!quux.get("isDirty"));
    }).bind(this));
  });


  ember_qunit.test("CleanEmbeddedChildrenMixin: Should not crash on empty relationships", function (assert) {
    Ember['default'].run((function () {
      var store = this.store();

      store.push("foo", { id: "2" });
      var foo = store.all("foo").findBy("id", "2");

      foo._cleanChildren();

      assert.ok(true, "Should not error out");
    }).bind(this));
  });

  ember_qunit.test("CleanEmbeddedChildrenMixin: call save() on root record should process childs 'isDirty' state", function (assert) {
    var done = assert.async();
    Ember['default'].run((function () {
      var store = setupTestData(this.store());

      var foo = store.all("foo").findBy("id", "1");
      var bar1 = store.all("bar").findBy("id", "1");
      var bar2 = store.all("bar").findBy("id", "2");

      assert.ok(!foo.get("isDirty"), "foo isn't dirty");
      assert.ok(!bar1.get("isDirty"), "bar1 isn't dirty");
      assert.ok(!bar2.get("isDirty"), "bar2 isn't dirty");

      assert.ok(!bar2.get("val"), "bar2 default value of `val` is `false`");
      bar2.set("val", true);
      assert.ok(bar2.get("val"), "set bar2 value of `val` to `true`");

      assert.ok(foo.get("isDirty"), "foo is dirty");
      assert.ok(!bar1.get("isDirty"), "bar1 isn't dirty");
      assert.ok(bar2.get("isDirty"), "bar2 is dirty");

      foo.save().then(function () {
        assert.ok(!foo.get("isDirty"), "foo isn't dirty after foo.save()");
        assert.ok(!bar1.get("isDirty"), "bar1 isn't dirty after foo.save()");
        assert.ok(!bar2.get("isDirty"), "bar2 isn't dirty after foo.save()");

        assert.ok(bar2.get("val"), "bar2 value of `val` is persisted to `true` after foo.save()");

        done();
      });
    }).bind(this));
  });

  ember_qunit.test("CleanEmbeddedChildrenMixin: call rollback() on root record should rollback all dirty childs", function (assert) {
    Ember['default'].run((function () {
      var store = setupTestData(this.store());

      var foo = store.all("foo").findBy("id", "1");
      var bar = store.all("bar").findBy("id", "1");
      var baz = store.all("baz").findBy("id", "1");
      var quux = store.all("quux").findBy("id", "1");

      assert.ok(!foo.get("isDirty"), "foo isn't dirty");
      assert.ok(!bar.get("isDirty"), "bar isn't dirty");
      assert.ok(!baz.get("isDirty"), "baz isn't dirty");
      assert.ok(!quux.get("isDirty"), "quux isn't dirty");

      assert.ok(!quux.get("val"), "quux default value of `val` is `false`");
      quux.set("val", true);
      assert.ok(quux.get("val"), "set quux value of `val` to `true`");

      assert.ok(foo.get("isDirty"), "foo is dirty");
      assert.ok(!bar.get("isDirty"), "bar isn't dirty");
      assert.ok(baz.get("isDirty"), "baz is dirty");
      assert.ok(quux.get("isDirty"), "quux is dirty");

      foo.rollback();

      assert.ok(!foo.get("isDirty"), "foo isn't dirty after foo.rollback()");
      assert.ok(!bar.get("isDirty"), "bar isn't dirty after foo.rollback()");
      assert.ok(!baz.get("isDirty"), "baz isn't dirty after foo.rollback()");
      assert.ok(!quux.get("isDirty"), "quux isn't dirty after foo.rollback()");

      assert.ok(!quux.get("val"), "quux value of `val` is rollbacked to `false`");
    }).bind(this));
  });

});
define('dummy/tests/unit/models/foo-test.jshint', function () {

  'use strict';

  module('JSHint - unit/models');
  test('unit/models/foo-test.js should pass jshint', function() { 
    ok(true, 'unit/models/foo-test.js should pass jshint.'); 
  });

});
/* jshint ignore:start */

/* jshint ignore:end */

/* jshint ignore:start */

define('dummy/config/environment', ['ember'], function(Ember) {
  var prefix = 'dummy';
/* jshint ignore:start */

try {
  var metaName = prefix + '/config/environment';
  var rawConfig = Ember['default'].$('meta[name="' + metaName + '"]').attr('content');
  var config = JSON.parse(unescape(rawConfig));

  return { 'default': config };
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

/* jshint ignore:end */

});

if (runningTests) {
  require("dummy/tests/test-helper");
} else {
  require("dummy/app")["default"].create({"LOG_ACTIVE_GENERATION":false,"LOG_VIEW_LOOKUPS":false,"rootElement":"#ember-testing","name":"ember-cli-stained-by-children","version":"0.0.0.5efb132f"});
}

/* jshint ignore:end */
//# sourceMappingURL=dummy.map