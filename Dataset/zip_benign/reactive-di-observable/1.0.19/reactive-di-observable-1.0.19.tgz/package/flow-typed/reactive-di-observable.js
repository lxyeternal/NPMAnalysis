/* @flow */

import type {
    CreatePlugin,
    Plugin,
    Tag,
    Provider,
    Disposable as IDisposable,
    Annotation,
    DependencyKey,
    Container,
    PassiveProvider,
    CreateContainerManager
} from 'reactive-di'

import type {
    Notify,
    Meta as IMeta
} from 'reactive-di-observable/transaction/interfaces'

declare module 'reactive-di-observable' {
    // flow bug
    declare interface Disposable extends IDisposable {}

    declare type Meta = IMeta

    declare interface Resetter {
        reset(): void;
    }

    declare interface StyleSheet<Classes> {
        attach(): void;
        detach(): void;
        classes: Classes;
    }

    declare type CreateStyleSheet<Styles: Object, K> = (styles: Styles, id: K) => StyleSheet<*>;

    declare interface ComponentState<Props, State, El> {
        state: State;
        observable: Observable<State, Error>;
        Widget: Class<FullWidget<Props, State, El>>;
    }

    declare type GetComponentState<Props, State, El> = () => ComponentState<Props, State, El>

    declare class FullWidget<Props, State, El> {
        props: Props;
        state: State;

        render: () => El;
        onCreate?: (node: HTMLElement) => void;
        onUpdate?: (node: HTMLElement) => void;
        onRemove?: (node: HTMLElement) => void;
    }
    declare type StatelessWidget<Props, El> = (props: Props) => El;

    declare interface Collection<T: Disposable> {
        items: Array<T>;
        add(item: T): void;
    }

    declare interface ResetAnnotation extends Annotation {
        kind: 'reset';
    }

    declare interface MetaAnnotation extends Annotation {
        kind: 'meta';
        sources: Array<DependencyKey>;
    }

    declare interface ComputedAnnotation extends Annotation {
        kind: 'computed';
    }

    declare interface LoaderAnnotation<V> extends Annotation {
        kind: 'loader';
    }

    declare interface SetterAnnotation extends Annotation {
        kind: 'setter';
        qeue?: mixed;
        pending?: boolean;
    }

    declare interface ObservableParams<V> {
        loader?: ?DependencyKey;
        key?: string;
        serializable?: boolean;
    }

    declare interface ObservableAnnotation<V> extends Annotation {
        kind: 'observable';
        value?: ?V;
        observable?: ?Observable<V, Error>;
        loader?: ?DependencyKey;
        pending?: boolean;
    }

    declare type ListenerProvider<V> = {
        type: 'listener';
        notify(): void;

        displayName: string;
        tags: Array<Tag>;
        dependencies: Array<Provider>;
        isCached: boolean;
        isDisposed: boolean;
        value: V;
        dispose(): void;
        update(): void;
        addDependency(dependency: Provider): void;
        addDependant(dependant: Provider): void;
    }

    declare type EmiterProvider<V> = {
        type: 'emiter';
        meta: IMeta;

        displayName: string;
        tags: Array<Tag>;
        dependencies: Array<Provider>;
        isCached: boolean;
        isDisposed: boolean;
        value: V;
        dispose(): void;
        update(): void;
        addDependency(dependency: Provider): void;
        addDependant(dependant: Provider): void;
    }

    declare type MetaProvider = {
        type: 'meta';

        displayName: string;
        tags: Array<Tag>;
        dependencies: Array<AnyProvider>;
        isCached: boolean;
        isDisposed: boolean;
        value: IMeta;
        dispose(): void;
        update(): void;
        addDependency(dependency: AnyProvider): void;
        addDependant(dependant: AnyProvider): void;
    }

    declare type AsyncProvider<V> = {
        type: 'async';

        meta: IMeta;

        clone<A: ObservableAnnotation>(annotation: A, container: Container): AsyncProvider<V>;
        reset(): void;

        set(notify: Notify, value?: V): void;

        displayName: string;
        tags: Array<Tag>;
        dependencies: Array<AnyProvider>;
        isCached: boolean;
        isDisposed: boolean;
        value: V;
        dispose(): void;
        update(): void;
        addDependency(dependency: AnyProvider): void;
        addDependant(dependant: AnyProvider): void;
    }

    declare type AnyProvider =
        PassiveProvider
        | MetaProvider
        | ListenerProvider<any>
        | EmiterProvider<any>
        | AsyncProvider<any>;


    declare type PageComponent = Widget<?{error: Error}, mixed>;
    declare type PageMap = {
        [id: string]: Widget<*>;
    }
    declare type GetPage<Element> = (pageName: ?string) => Element;
    declare interface CachedStateTarget {
        createContainer(): Container;
        target: DependencyKey;
    }
    declare interface WidgetAnnotation extends Annotation {
        kind: 'widget';
        providers?: Array<ConfigItem>;
        cache?: CachedStateTarget;
    }
    declare type Renderer<Element, Widget> = (widget: Widget, error:? Error) => {
        data: Element,
        code: number,
        header: {[id: string]: string}
    }
    declare type createRenderer<TargetElement: Function, Widget: Function> = (
        di: Container,
        node: Element
    ) => Renderer

    declare type CreateWidget<State, Props, El> = (
        getState: GetComponentState<State, Props, El>,
        displayName: string
    ) => mixed

    declare interface ComponentPlugin extends Plugin {
        kind: 'component';
        createContainerManager: CreateContainerManager;
        constructor(createWidget: CreateWidget): ComponentPlugin;
    }

    declare interface ComputedPlugin extends Plugin {
        kind: 'computed';
    }

    declare interface MetaPlugin extends Plugin {
        kind: 'meta';
    }

    declare interface ObservablePlugin extends Plugin {
        kind: 'observable';
    }

    declare interface SetterPlugin extends Plugin {
        kind: 'setter';
    }

    declare interface ThemePlugin extends Plugin {
        kind: 'theme';
        constructor(createStyleSheet: CreateStyleSheet): ThemePlugin;
    }
}
