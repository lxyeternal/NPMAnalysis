/* @flow */

import type {
    ConfigItem,
    DepItem,
    DependencyKey
} from 'reactive-di'

import type {
    ObservableParams
} from 'reactive-di-observable'

declare module 'reactive-di-observable/annotations' {
    declare function computed<V: Function>(...deps: Array<DepItem>): (target: V) => V;
    declare function meta<V: Function>(...sources: Array<DependencyKey>): (target: V) => V;
    declare function observable<V: Function>(rec?: ObservableParams): (target: V) => V;
    declare function setterAnn<V: Function>(...deps: Array<DepItem>): (target: V) => V;

    declare function component<V: Function>(rec?: {
        providers?: Array<ConfigItem>
    }): (target: V) => V;
}
