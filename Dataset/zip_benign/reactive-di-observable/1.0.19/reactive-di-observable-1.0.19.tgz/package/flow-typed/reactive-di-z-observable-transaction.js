/* @flow */
/* eslint-disable */

type DependencyKey = Function|string;

declare module 'reactive-di-observable/transaction/interfaces' {
    declare interface Meta {
        promise: Promise<void>;
        pending: boolean;
        success: boolean;
        error: ?Error;
        combine(metas: Meta[]): Meta;
    }

    declare type NormalizedOperation = [DependencyKey, any];

    declare type SyncOperation<T> =
        {object: Object}
        | {key: DependencyKey, value: T};

    declare type AsyncOperation = {
        observable(): Observable<Array<Operation>, Error>;
    } | {
        promise(): Promise<Array<Operation>>
    }

    declare type Operation<T> = SyncOperation<T> | AsyncOperation;

    declare interface Notified {
        notify(): void;
    }

    declare type Notify = (notified: Notified) => void;

    declare interface OperationProcessor {
        add(ops: Array<Operation>): void;
        cancel(): void;
    }

    declare interface MetaState extends Meta {
        setPending(): void;
        setSuccess(): void;
        setError(err: Error): void;
    }

    declare type CreateObservable<AsyncOperation> = (op: AsyncOperation) => Observable<Array<Operation>, Error>;
    declare type ValueProvider<V> = {
        value: V;
        set(notify: Notify, value?: V): void;
    }
    declare type Value<V> = [ValueProvider<V>, V];
    declare type GetProvider<K> = (key: K) => ValueProvider;
}
