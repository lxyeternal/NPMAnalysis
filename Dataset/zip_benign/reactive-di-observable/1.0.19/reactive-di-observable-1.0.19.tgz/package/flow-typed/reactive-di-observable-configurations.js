/* @flow */

import type {
    ConfigItem,
    DependencyKey,
    RawAnnotation,
    DepItem
} from 'reactive-di'

import type {
    Widget,
    ObservableAnnotation,
    ObservableParams,
    MetaAnnotation
} from 'reactive-di-observable'

declare module 'reactive-di-observable/configurations' {
    declare function computed(target: Function, ...deps: Array<DepItem>): RawAnnotation;
    declare function meta(target: Function, ...sources: Array<DependencyKey>): MetaAnnotation;
    declare function observable<V>(
        target: Class<V>,
        rec?: ObservableParams<V>
    ): ObservableAnnotation<V>;
    declare function setter(target: Function, ...deps: Array<DepItem>): RawAnnotation;
    declare function component(
        target: Widget,
        rec?: {
            props?: {[id: string]: DependencyKey},
            providers?: Array<ConfigItem>
        }
    ): RawAnnotation;
}
