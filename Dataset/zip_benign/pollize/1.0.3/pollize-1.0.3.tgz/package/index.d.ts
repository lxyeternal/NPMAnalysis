/**
 * Created by Cooper on 2021/06/16.
 */
declare type Unpacked<T> = T extends (infer U)[] ? U : T extends (...args: any[]) => infer U ? U : T extends Promise<infer U> ? U : T;
declare const defaultPollOptions: {
    delay: number;
    interval: number;
    timeout: number;
};
declare type Options = Partial<typeof defaultPollOptions>;
export default function poll<T extends (...args: any[]) => any>(fn: T, opts: Options & {
    onFulfilled: (result: Unpacked<ReturnType<T>>) => boolean;
    onReject?: (result: Unpacked<ReturnType<T>>) => boolean;
}, ...args: Parameters<T>): Promise<unknown>;
export {};
