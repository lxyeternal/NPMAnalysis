"use strict";
/**
 * Created by Cooper on 2021/06/16.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const defaultPollOptions = {
    delay: 100,
    interval: 1000,
    timeout: 10 * 1000,
};
function poll(fn, opts, ...args) {
    let looper;
    let timer;
    mergeOption(opts, defaultPollOptions);
    const { delay, interval, timeout } = opts;
    return new Promise((resolve, reject) => {
        timer = setTimeout(reject, timeout, Error('polling timeout'));
        setTimeout(() => {
            looper = setInterval(async () => {
                try {
                    const result = await fn(...args);
                    if (opts.onFulfilled(result)) {
                        return resolve(result);
                    }
                    if (opts.onReject && opts.onReject(result)) {
                        return reject(result);
                    }
                }
                catch (err) {
                    reject(err);
                }
            }, interval);
        }, delay);
    })
        .then((ret) => {
        return ret;
    })
        .catch((err) => {
        throw err;
    })
        .finally(() => {
        clearInterval(looper);
        clearTimeout(timer);
    });
}
exports.default = poll;
function mergeOption(input, defaultOptions) {
    for (const k in defaultOptions) {
        if (input[k] === undefined) {
            input[k] = defaultOptions[k];
        }
    }
}
