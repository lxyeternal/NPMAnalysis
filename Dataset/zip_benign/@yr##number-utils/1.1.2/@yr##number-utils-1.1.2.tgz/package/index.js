'use strict';

/**
 * A collection of Number utility functions
 * https://github.com/yr/number-utils
 * @copyright Yr
 * @license MIT
 */

exports.TWO_PI = Math.PI * 2;
exports.HALF_PI = Math.PI * 0.5;

/**
 * Converts a given value in degrees to radians
 * @param {Number} deg
 * @returns {Number}
 */
exports.degreesToRadians = function (deg) {
  return deg * Math.PI / 180;
};

/**
 * Converts a given value in radians to degrees
 * @param {Number} rad
 * @returns {Number}
 */
exports.radiansToDegrees = function (rad) {
  return 180 * rad / Math.PI;
};

/**
 * Takes a 'value' within a given range and converts it to a number between 0 and 1.
 * @param {Number} value
 * @param {Number} min
 * @param {Number} max
 * @returns {Number}
 */
var normalize = exports.normalize = function (value, min, max) {
  if (min === max) return 1;
  return (value - min) / (max - min);
};

/**
 * Takes a normalized value and a range and returns the actual value in that range.
 * @param {Number} normValue
 * @param {Number} min
 * @param {Number} max
 * @returns {Number}
 */
var interpolate = exports.interpolate = function (normValue, min, max) {
  return min + (max - min) * normValue;
};

/**
 * Takes a value in a given range (min1, max1) and finds the corresonding value in the next range (min2, max2).
 * @param {Number} value
 * @param {Number} min1
 * @param {Number} max1
 * @param {Number} min2
 * @param {Number} max2
 * @returns {Number}
 */
var map = exports.map = function (value, min1, max1, min2, max2) {
  return interpolate(normalize(value, min1, max1), min2, max2);
};

/**
 * Takes a value and limits it to fall within a given range.
 * @param {Number} value
 * @param {Number} min
 * @param {Number} max
 * @returns {Number}
 */
exports.limit = function (value, min, max) {
  return Math.min(Math.max(min, value), max);
};

/**
 * Generates a random number between a given range.
 * @param {Number} min
 * @param {Number} max
 * @returns {Number}
 */
exports.rangedRandom = function (min, max) {
  return map(Math.random(), 0, 1, min, max);
};

/**
 * Rounds a value to the number of specified decimal places
 * @param {Number} value
 * @param {Number} decimalPlaces
 * @returns {Number}
 */
exports.round = function (value, decimalPlaces) {
  // Skip if integer
  if (value % 1 == 0) return value;

  var isNegative = value < 0;

  value = Math.abs(value);

  if (!decimalPlaces) return Math.round(value) * (isNegative ? -1 : 1);

  var parts = value.toString().split('.');
  var pre = parts[0] + parts[1].substr(0, decimalPlaces);
  var post = parts[1].slice(decimalPlaces);
  var postRound = Math.round(post / Math.pow(10, post.length));
  var places = Math.pow(10, decimalPlaces || 0);

  if (parts[1].length > decimalPlaces) value = (+pre + postRound) / places;

  return value * (isNegative ? -1 : 1);
};