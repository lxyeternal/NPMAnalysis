[![NPM Version](https://img.shields.io/npm/v/@yr/number-utils.svg?style=flat)](https://npmjs.org/package/@yr/number-utils)
[![Build Status](https://img.shields.io/travis/YR/number-utils.svg?style=flat)](https://travis-ci.org/YR/number-utils?branch=master)

A collection of Number utility functions.

## Usage

```javascript
var numberUtils = require('number-utils');

numberUtils.normalize(50, 0, 100); // => 0.5
numberUtils.interpolate(0.5, 0, 100); // => 50
numberUtils.map(5, 0, 10, 0, 100); // => 50
numberUtils.limit(5, 0, 1); // => 1
numberUtils.rangedRandom(1, 10); // => 6
```

## API

**TWO_PI**: 2x Pi

**HALF_PI**: 1/2 Pi

**degreesToRadians(deg)**: convert `deg` to radians

```javascript
numberUtils.degreesToRadians(360); // => 6.283185307179586
```

**radiansToDegrees(rad)**: convert `rad` to degrees

```javascript
numberUtils.radiansToDegrees(180); // => 114.59155902616465
```

**normalize(value, min, max)**: convert `value` between `min` and `max` to number between 0 and 1

`value` can lie outside of the `min` and `max` range

```javascript
numberUtils.normalize(5, 0, 10); // => 0.5
numberUtils.normalize(5, 10, 0); // => 0.5
numberUtils.normalize(5, 10, 10); // => 1
numberUtils.normalize(2, 5, 10); // => -0.6
```

**interpolate(normValue, min, max)**: convert a normalized `normValue` between 0 and 1 to number between `min` and `max`

```javascript
numberUtils.interpolate(0.5, 0, 10); // => 5
numberUtils.interpolate(0.5, 10, 0); // => 5
numberUtils.interpolate(0.5, 10, 10); // => 10
numberUtils.interpolate(2, 5, 10); // => 15
```

**map(value, min1, max1, min2, max2)**: convert a `value` in a range `min1`, `max1` to number between `min2` and `max2`

```javascript
numberUtils.map(0.5, 0, 1, 0, 100); // => 50
numberUtils.map(1.5, 0, 1, 0, 100); // => 150
```

**limit(value, min, max)**: limits a `value` to fall within a range `min` and `max`

```javascript
numberUtils.limit(12, 0, 10); // => 10
numberUtils.limit(-5, 0, 10); // => 0
numberUtils.limit(5, 0, 10); // => 5
```

**rangedRandom(min, max)**: generate a random number between `min` and `max`

```javascript
numberUtils.rangedRandom(0, 10); // => 5
numberUtils.rangedRandom(10, 20); // => 16
```

**round(value, decimalPlaces)**: round `value` to specified number of `decimalPlaces`. In addition, rounds negative numbers **away** from zero.

```javascript
numberUtils.round(1.005, 2); // => 1.01
numberUtils.round(1.4999999, 2); // => 1.5
numberUtils.round(1.4009999, 3); // => 1.401
numberUtils.round(1.005, 5); // => 1.005
numberUtils.round(-1.5); // => -2
```