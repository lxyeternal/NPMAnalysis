# @onekuma/preset.css

[![version](https://img.shields.io/npm/v/@onekuma/preset.css?color=rgb%2850%2C203%2C86%29&label=@onekuma/preset.css)](https://www.npmjs.com/package/@onekuma/preset.css)

OneKuma CSS Preset.

```bash
pnpm i @onekuma/preset.css
```

```ts
import '@onekuma/preset.css'
```

## Styles

+ OneKuma Utilities
+ Webkit Scrollbar
+ Selection

### Variables

```ts
:root {
  --c-selection-color: inherit;
  --c-selection-bg: #cce2ff;
  --c-input-selection-color: rgba(0, 0, 0, 0.87);
  --c-input-selection-bg: rgba(100, 100, 100, 0.4);
}
```

## License

MIT License © 2023 [XLor](https://github.com/yjl9903)
