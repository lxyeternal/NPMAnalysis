export declare function transpileAndSave(contracts: string[]): Promise<void>;
//# sourceMappingURL=transpiler.d.ts.map