declare function action(contractFullName: string, options: any): Promise<void>;
declare const _default: {
    name: string;
    signature: string;
    description: string;
    register: (program: any) => any;
    action: typeof action;
};
export default _default;
//# sourceMappingURL=create2.d.ts.map