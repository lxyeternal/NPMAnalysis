import { Options, Args } from './spec';
export declare function preAction(params: Options): Promise<void>;
export declare function action(params: Options & Args): Promise<void>;
export declare function deployRegular(params: Options & Args): Promise<string>;
//# sourceMappingURL=action.d.ts.map