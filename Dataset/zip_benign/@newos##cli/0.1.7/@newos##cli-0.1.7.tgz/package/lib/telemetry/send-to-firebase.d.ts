/// <reference lib="dom" />
import 'firebase/auth';
import 'firebase/firestore';
//# sourceMappingURL=send-to-firebase.d.ts.map