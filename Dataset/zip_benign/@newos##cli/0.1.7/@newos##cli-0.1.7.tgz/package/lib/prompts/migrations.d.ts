export declare function hasToMigrateProject(network: any): Promise<boolean>;
//# sourceMappingURL=migrations.d.ts.map