import { ContractMethodMutability as Mutability } from '@newos/upgrades';
export default function promptForMethodParams(contractFullName: string, options: any, additionalOpts?: {
    [key: string]: string;
}, constant?: Mutability): Promise<{
    methodName: string;
    methodArgs: string[];
}>;
//# sourceMappingURL=method-params.d.ts.map