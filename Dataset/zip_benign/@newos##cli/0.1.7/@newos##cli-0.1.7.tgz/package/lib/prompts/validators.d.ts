export declare function notEmpty(input: any): true | "Please enter a non-empty value";
//# sourceMappingURL=validators.d.ts.map