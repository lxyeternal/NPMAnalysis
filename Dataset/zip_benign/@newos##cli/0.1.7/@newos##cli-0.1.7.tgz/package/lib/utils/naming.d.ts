export declare function toContractFullName(packageName: string, contractName: string): string;
export declare function fromContractFullName(contractFullName: string): {
    contractName?: string;
    package?: string;
};
//# sourceMappingURL=naming.d.ts.map