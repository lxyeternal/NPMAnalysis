import { AbiItem } from 'web3-utils';
export declare const ERC20_PARTIAL_ABI: AbiItem[];
//# sourceMappingURL=constants.d.ts.map