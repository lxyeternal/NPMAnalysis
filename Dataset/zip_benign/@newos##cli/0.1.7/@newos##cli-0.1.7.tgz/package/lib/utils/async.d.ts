export declare function allPromisesOrError(promisesWithObjects: any[], toErrorMessage?: (error: any, object: any) => string): Promise<any[] | null | never>;
//# sourceMappingURL=async.d.ts.map