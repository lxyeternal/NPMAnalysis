export interface ParsedContractReference {
    proxyAddress: string | undefined;
    contractName: string | undefined;
    packageName: string | undefined;
}
export declare function parseContractReference(contractReference: string): ParsedContractReference;
//# sourceMappingURL=contract.d.ts.map