export declare function describeEvents(events: any): void;
//# sourceMappingURL=events.d.ts.map