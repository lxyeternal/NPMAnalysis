import { Contract } from '@newos/upgrades';
import ProjectFile from './ProjectFile';
import { ProxyType } from '../../scripts/interfaces';
export interface ContractInterface {
    address?: string;
    constructorCode?: string;
    localBytecodeHash?: string;
    deployedBytecodeHash?: string;
    bodyBytecodeHash?: string;
    types?: any;
    storage?: any;
    warnings?: any;
    [id: string]: any;
}
interface SolidityLibInterface {
    address: string;
    constructorCode: string;
    bodyBytecodeHash: string;
    localBytecodeHash: string;
    deployedBytecodeHash: string;
}
export interface ProxyInterface {
    contractName?: string;
    package?: string;
    address?: string;
    version?: string;
    implementation?: string;
    admin?: string;
    kind?: ProxyType;
    bytecodeHash?: string;
}
export interface DependencyInterface {
    name?: string;
    package?: string;
    version?: string;
    customDeploy?: boolean;
}
interface AddressWrapper {
    address?: string;
}
interface NetworkFileData {
    contracts: {
        [name: string]: ContractInterface;
    };
    solidityLibs: {
        [name: string]: SolidityLibInterface;
    };
    proxies: {
        [contractName: string]: ProxyInterface[];
    };
    manifestVersion?: string;
    zosversion?: string;
    proxyAdmin: AddressWrapper;
    proxyFactory: AddressWrapper;
    app: AddressWrapper;
    package: AddressWrapper;
    provider: AddressWrapper;
    version: string;
    frozen: boolean;
    dependencies: {
        [dependencyName: string]: DependencyInterface;
    };
}
export default class NetworkFile {
    projectFile: ProjectFile;
    network: any;
    filePath: string;
    data: NetworkFileData;
    static getManifestVersion(network: string): string | null;
    constructor(projectFile: ProjectFile, network: any, filePath?: string);
    set manifestVersion(version: string);
    get manifestVersion(): string;
    set version(version: string);
    get version(): string;
    set contracts(contracts: {
        [name: string]: ContractInterface;
    });
    get contracts(): {
        [name: string]: ContractInterface;
    };
    set solidityLibs(solidityLibs: {
        [name: string]: SolidityLibInterface;
    });
    get solidityLibs(): {
        [name: string]: SolidityLibInterface;
    };
    set frozen(frozen: boolean);
    get frozen(): boolean;
    set proxyAdmin(admin: AddressWrapper);
    get proxyAdmin(): AddressWrapper;
    set proxyFactory(factory: AddressWrapper);
    get proxyFactory(): AddressWrapper;
    set app(app: AddressWrapper);
    get app(): AddressWrapper;
    set provider(provider: AddressWrapper);
    get provider(): AddressWrapper;
    set package(_package: AddressWrapper);
    get package(): AddressWrapper;
    get proxyAdminAddress(): string;
    get proxyFactoryAddress(): string;
    get appAddress(): string;
    get packageAddress(): string;
    get providerAddress(): string;
    get isPublished(): boolean;
    get contractNames(): string[];
    addSolidityLib(libName: string, instance: Contract): void;
    unsetSolidityLib(libName: string): void;
    setSolidityLib(contractName: string, value: SolidityLibInterface): void;
    solidityLib(libName: string): SolidityLibInterface;
    getSolidityLibs(libs: string[]): {
        [name: string]: string;
    };
    hasSolidityLib(libName: string): boolean;
    solidityLibsMissing(libs: any): string[];
    getSolidityLibOrContract(contractName: string): ContractInterface | SolidityLibInterface;
    hasSolidityLibOrContract(contractName: string): boolean;
    updateImplementation(contractName: string, fn: (source: ContractInterface | SolidityLibInterface) => ContractInterface | SolidityLibInterface): void;
    get dependencies(): {
        [dependencyName: string]: DependencyInterface;
    };
    get dependenciesNames(): string[];
    getDependency(name: string): DependencyInterface | null;
    hasDependency(name: string): boolean;
    hasDependencies(): boolean;
    getProxies({ package: packageName, contractName, address, kind }?: ProxyInterface): ProxyInterface[];
    getProxy(address: string): ProxyInterface;
    contract(contractName: string): ContractInterface;
    contractsMissingFromPackage(): string[];
    isCurrentVersion(version: string): boolean;
    hasContract(contractName: string): boolean;
    hasContracts(): boolean;
    hasProxies(aFilter?: any): boolean;
    hasMatchingVersion(): boolean;
    dependenciesNamesMissingFromPackage(): any[];
    dependencyHasCustomDeploy(name: string): boolean;
    dependencySatisfiesVersionRequirement(name: string): boolean;
    dependencyHasMatchingCustomDeploy(name: string): boolean;
    hasSameBytecode(contractName: string, klass: any): boolean;
    setDependency(name: string, { package: thepackage, version, customDeploy }?: DependencyInterface): void;
    unsetDependency(name: string): void;
    updateDependency(name: string, fn: (...args: any[]) => any): void;
    addContract(contractName: string, instance: Contract, { warnings, types, storage }?: {
        warnings?: any;
        types?: any;
        storage?: any;
    }): void;
    setContract(contractName: string, value: ContractInterface): void;
    unsetContract(contractName: string): void;
    setProxies(packageName: string, contractName: string, value: ProxyInterface[]): void;
    addProxy(thepackage: string, contractName: string, info: ProxyInterface): void;
    removeProxy(thepackage: string, contractName: string, address: string): void;
    updateProxy({ package: proxyPackageName, contractName: proxyContractName, address: proxyAddress }: ProxyInterface, fn: (...args: any[]) => any): void;
    _indexOfProxy(fullname: string, address: string): number;
    _proxiesOf(fullname: string): ProxyInterface[];
    write(): void;
    static getExistingFilePath(network: string, dir?: string, ...paths: string[]): string;
    private hasChanged;
    private exists;
}
export {};
//# sourceMappingURL=NetworkFile.d.ts.map