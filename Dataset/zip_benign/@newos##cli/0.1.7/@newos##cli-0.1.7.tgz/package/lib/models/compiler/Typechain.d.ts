export default function typechain(files: string, outDir: string, target: string): Promise<void>;
//# sourceMappingURL=Typechain.d.ts.map