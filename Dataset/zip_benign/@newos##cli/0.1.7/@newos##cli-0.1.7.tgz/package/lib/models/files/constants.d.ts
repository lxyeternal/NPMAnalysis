export declare const OPEN_ZEPPELIN_FOLDER = ".newos";
export declare const LOCK_FILE = ".lock";
export declare const LOCK_FILE_PATH: string;
//# sourceMappingURL=constants.d.ts.map