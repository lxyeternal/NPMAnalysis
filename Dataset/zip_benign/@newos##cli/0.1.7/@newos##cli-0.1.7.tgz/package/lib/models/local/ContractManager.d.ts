import { Contract } from '@newos/upgrades';
import ProjectFile from '../files/ProjectFile';
export default class ContractManager {
    projectFile: ProjectFile;
    constructor(projectFile?: ProjectFile);
    getContractClass(packageName: string, contractName: string): Contract;
    hasContract(packageName: string, contractName: string): boolean;
    getContractNames(root?: string): string[];
    private isLocalContract;
    private isAbstractContract;
    private isLibrary;
}
//# sourceMappingURL=ContractManager.d.ts.map