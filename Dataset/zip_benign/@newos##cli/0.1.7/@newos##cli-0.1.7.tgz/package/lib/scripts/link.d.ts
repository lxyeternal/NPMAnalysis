import { LinkParams } from './interfaces';
export default function link({ dependencies, installDependencies, projectFile }: LinkParams): Promise<void>;
//# sourceMappingURL=link.d.ts.map