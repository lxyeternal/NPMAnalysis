import { PushParams } from './interfaces';
export default function push({ contracts, network, deployDependencies, deployProxyAdmin, deployProxyFactory, reupload, force, txParams, networkFile, }: PushParams): Promise<void | never>;
//# sourceMappingURL=push.d.ts.map