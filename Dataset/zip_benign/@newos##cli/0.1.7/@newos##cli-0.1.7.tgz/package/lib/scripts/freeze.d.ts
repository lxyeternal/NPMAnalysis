import { FreezeParams } from './interfaces';
export default function freeze({ network, txParams, networkFile }: FreezeParams): Promise<void | never>;
//# sourceMappingURL=freeze.d.ts.map