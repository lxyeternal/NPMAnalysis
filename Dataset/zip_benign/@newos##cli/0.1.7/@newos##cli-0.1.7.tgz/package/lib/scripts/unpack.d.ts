import { UnpackParams } from './interfaces';
export default function unpack({ repoOrName }: UnpackParams): Promise<void | never>;
//# sourceMappingURL=unpack.d.ts.map