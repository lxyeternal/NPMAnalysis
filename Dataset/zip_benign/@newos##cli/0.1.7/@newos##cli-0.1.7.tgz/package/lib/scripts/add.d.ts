import { AddParams } from './interfaces';
export default function add({ contracts, projectFile }: AddParams): void | never;
//# sourceMappingURL=add.d.ts.map