import { BalanceParams } from './interfaces';
export default function balance({ accountAddress, contractAddress }: BalanceParams): Promise<void | never>;
//# sourceMappingURL=balance.d.ts.map