import { UpdateParams } from './interfaces';
export default function update({ packageName, contractName, proxyAddress, methodName, methodArgs, all, network, force, txParams, networkFile, }: Partial<UpdateParams>): Promise<void>;
//# sourceMappingURL=update.d.ts.map