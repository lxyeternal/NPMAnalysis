export default function accounts({ network }: {
    network: string;
}): Promise<void | never>;
//# sourceMappingURL=accounts.d.ts.map