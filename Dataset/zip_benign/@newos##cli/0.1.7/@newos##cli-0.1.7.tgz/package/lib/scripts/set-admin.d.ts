import { SetAdminParams } from './interfaces';
export default function setAdmin({ newAdmin, packageName, contractName, proxyAddress, network, txParams, networkFile, }: SetAdminParams): Promise<void | never>;
//# sourceMappingURL=set-admin.d.ts.map