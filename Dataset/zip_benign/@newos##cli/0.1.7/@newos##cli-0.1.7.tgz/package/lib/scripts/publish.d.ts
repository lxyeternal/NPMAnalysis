import { PublishParams } from './interfaces';
export default function publish({ network, txParams, networkFile }: PublishParams): Promise<void | never>;
//# sourceMappingURL=publish.d.ts.map