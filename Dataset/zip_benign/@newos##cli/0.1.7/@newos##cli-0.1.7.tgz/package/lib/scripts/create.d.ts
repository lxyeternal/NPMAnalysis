import { CreateParams } from './interfaces';
import { Contract } from '@newos/upgrades';
export default function createProxy({ packageName, contractName, methodName, methodArgs, network, txParams, force, salt, signature, admin, kind, networkFile, }: Partial<CreateParams>): Promise<Contract | never>;
//# sourceMappingURL=create.d.ts.map