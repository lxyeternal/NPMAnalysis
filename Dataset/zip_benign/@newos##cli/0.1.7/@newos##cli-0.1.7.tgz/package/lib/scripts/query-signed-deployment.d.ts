import { CreateParams } from './interfaces';
export default function querySignedDeployment({ packageName, contractName, methodName, methodArgs, network, txParams, salt, signature, admin, networkFile, }: Partial<CreateParams>): Promise<string | never>;
//# sourceMappingURL=query-signed-deployment.d.ts.map