import { CheckParams } from './interfaces';
export default function check({ contractName, projectFile }: CheckParams): void;
//# sourceMappingURL=check.d.ts.map