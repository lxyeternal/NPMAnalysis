import { UnlinkParams } from './interfaces';
export default function unlink({ dependencies, projectFile }: UnlinkParams): Promise<void | never>;
//# sourceMappingURL=unlink.d.ts.map