import { SessionParams } from './interfaces';
export default function session({ network, from, timeout, blockTimeout, close, expires, }: SessionParams): void | never;
//# sourceMappingURL=session.d.ts.map