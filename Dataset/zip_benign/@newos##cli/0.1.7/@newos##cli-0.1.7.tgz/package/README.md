# NewOS Command-Line Interface _(@newos/cli)_

> Command-line interface for NewOS.

NewOS is a platform to develop, deploy and operate smart contract
projects on NewChain and every other EVM and eWASM-powered blockchain.

## Install

First, install [Node.js](http://nodejs.org/) and [npm](https://npmjs.com/).
Then, install the NewOS running:

```sh
npm install --global @newos/cli
```

## Usage

To start, create a directory for the project and access it:

```sh
mkdir my-project
cd my-project
```

Use `npm` to create a `package.json` file:

```sh
npm init
```

And initialize the NewOS project:

```sh
newos init my-project
```

Create file `Counter.sol` in directory `contracts`:
```java
// contracts/Counter.sol
pragma solidity ^0.5.0;

contract Counter {
	uint256 public value;

    function increase() public {
       value++;
     }
 }
```

Uncomment the testnet section in `networks.js` and fill your mnemonic on newchain testnet:
```javascript
const HDWalletProvider = require("newtruffle-hdwallet-provider");

module.exports = {
  networks: {
  	...
    testnet: {
      provider: function() { 
        return new HDWalletProvider("[Your mnemonic]", 'https://rpc1.newchain.newtonproject.org', "testnet") 
      },
      network_id: "1007"
    },
    ...
```

Deloy upgradeable contract to testnet:
```shell
$ newos deploy
✓ Compiled contracts with solc 0.5.17 (commit.d19bba13)
? Choose the kind of deployment upgradeable
? Pick a network testnet
? Pick a contract to deploy Counter
✓ Compiled contracts with solc 0.5.17 (commit.d19bba13)
✓ Contract CounterUpgradeable deployed
All implementations have been deployed
✓ Setting everything up to create contract instances
✓ Instance created at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4
To upgrade this instance run 'newos upgrade'
0x63Be78c0174A87Eadd50BffFD765889C07a38EA4
```

Execute the contract method:
```shell
$ newos send-tx
? Pick a network testnet
? Pick an instance Counter at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4
? Select which function increase()
✓ Transaction successful. Transaction hash: 0x7c4bbb1580f810017d0d2d158034ba3b38ae1cd053913bc3cec269c01b9e378c
```

Retrieve the variable value:
```shell
$ newos call
? Pick a network testnet
? Pick an instance Counter at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4
? Select which function value()
✓ Method 'value()' returned: 1
1
```

Change the contract `Counter.sol` to:
```java
// contracts/Counter.sol
pragma solidity ^0.5.0;

contract Counter {
  uint256 public value;

  function increase(uint256 amount) public {
    value += amount;
  }
}
```

Upgrade the `Counter` contract:
```shell
$ newos upgrade
? Pick a network testnet
? Which instances would you like to upgrade? Choose by name
? Pick an instance to upgrade Counter
? Call a function on the instance after upgrading it? No
✓ Compiled contracts with solc 0.5.17 (commit.d19bba13)
✓ Compiled contracts with solc 0.5.17 (commit.d19bba13)
✓ Contract CounterUpgradeable deployed
All implementations have been deployed
✓ Instance upgraded at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4. Transaction receipt: 0x7af93f8388bf1d08b36be915116d4f2aa8ff751ec0af6fce0363eba83ebf22f2
✓ Instance at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4 upgraded
```

Execute the new method of upgraded contract:
```shell
$ newos send-tx
? Pick a network testnet
? Pick an instance Counter at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4
? Select which function increase(amount: uint256)
? amount: uint256: 10
⠋ Calling: 'increase' with:
✓ Transaction successful. Transaction hash: 0x50179c575116ddd64fa56733818587d38cc6a892aa54cf8ca1a6507f6d128939
```

Retrieve the same variable value and verify whether the upgrade is success:
```shell
$ newos call
? Pick a network testnet
? Pick an instance Counter at 0x63Be78c0174A87Eadd50BffFD765889C07a38EA4
? Select which function value()
✓ Method 'value()' returned: 11
11
```


### License

[GPLv3](./LICENSE)
