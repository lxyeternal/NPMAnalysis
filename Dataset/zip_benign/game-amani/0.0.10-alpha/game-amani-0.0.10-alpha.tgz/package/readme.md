# amani

# 游戏

##### 安装

```
npm install game-amani
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-amani/amani"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: JSON.stringify({
      baseOps: {
        speed: { min: 5, max: 15, step: 0.01 },//移动速度
        firstY: 200,//首次加载游戏第一个元素的底部坐标位置
        intervalStep: 1,//两个物体之间的间隔递减值
        intervalStepH: 50,//移动指定距离递减一次
        minIntervalH: 200,//两个物体之间的最小间隔距离
        maxIntervalH: 300,//两个物体之间的间隔距离
      },
      wall: {
        x: { min: 200, max: 750 - 200 },
        y: { min: 200, max: 800 - 200 }
      },
      energy: [
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01rxjPOB1FJvdr7fzsr_!!1080040467.png", "width": "133", "height": "258", id: "1", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 5, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
        { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01FOEYsW1FJvdtNrcwD_!!1080040467.png", "width": "663", "height": "374", id: "2", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 1, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
        { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nHMbJQ1FJvdsYKUhR_!!1080040467.png", "width": "199", "height": "164", id: "3", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 1, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01oPWF2o1FJvdwOj5Po_!!1080040467.png", "width": "98", "height": "264", id: "4", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 1, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Tn5kWp1FJvdnuK8Yf_!!1080040467.png", "width": "147", "height": "263", id: "5", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 1, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
        { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ulNG9N1FJvdqPaXy5_!!1080040467.png", "width": "202", "height": "166", id: "6", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 1, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
        { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01akGlQ91FJvdqPYT5f_!!1080040467.png", "width": "93", "height": "267", id: "7", fadeTime: "0.4", bound: { left: 0, top: 0, right: 0, bottom: 0 }, probability: 1, val: 10, score: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0137Ujlh1FJvdnoPFSq_!!1080040467.png", width: 104, height: 47, scale: { time: "0.2", multiple: ["1.2"] }, alpha: { time: "0.1" }, delayTime: "0.2" } },
      ],
      timePos: {
        bgAni: {
          x: 750 / 2,
          y: 0,
          boomSpeed: 0.4,
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN010HZBpn1FJvdsnBNte_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01l81sIa1FJvdqJ5gT8_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01t5d5lv1FJvdktt8R6_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01XG5ta41FJvdmq09sq_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015A013v1FJvdoopghL_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN016zO5BR1FJvdqJ6kyp_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013LtaNZ1FJvdooq5dJ_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01E87V4B1FJvdoqnGSO_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mRbZ2L1FJvdqJ5TzL_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01geUQBz1FJvdgBZCXl_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Nexbl61FJvdpL8FG7_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01TrCG3i1FJvdvJu1Vv_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jfpLIZ1FJvdqJ6YV5_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01b2GjG41FJvdvJtp3b_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN010RRqle1FJvdq2ltkR_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CNO8hk1FJvdrTVu1y_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01cR1t661FJvdgBYGL5_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zmYElQ1FJvdmpyx1k_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Ic9y2N1FJvdoqowQd_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01iuLZ511FJvdktsbCG_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016quNQs1FJvdvwN73J_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YpIcop1FJvdoop9Rs_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01fVsvOi1FJvdqJ7xqt_!!1080040467.png", "width": "125", "height": "125" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EVxZdh1FJvdvwOr9F_!!1080040467.png", "width": "125", "height": "125" },
          ]
        },
        align: "center",
        x: 750 / 2,
        y: 42,
        time: 26,//倒计时时间
        // 时间数字图片 0 - 9
        numOffset: 0,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01qUK7AZ1FJvdgCJJy0_!!1080040467.png", "width": "34", "height": "41", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PqIwTf1FJvdq3aiS0_!!1080040467.png", "width": "16", "height": "41", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01mBIZLM1FJvdorXSBH_!!1080040467.png", "width": "29", "height": "41", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01DFiWDB1FJvdorXFiJ_!!1080040467.png", "width": "29", "height": "41", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01CCQumH1FJvdopWWOt_!!1080040467.png", "width": "33", "height": "41", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN014CMsMN1FJvdsJOmnG_!!1080040467.png", "width": "29", "height": "41", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011z32JP1FJvdrUIVdR_!!1080040467.png", "width": "30", "height": "41", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PQ3FpT1FJvdmqoVVL_!!1080040467.png", "width": "28", "height": "41", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tniWlI1FJvdmqm5o2_!!1080040467.png", "width": "30", "height": "41", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Huysm01FJvduVEnnu_!!1080040467.png", "width": "30", "height": "41", val: 9 },
        ],
      },
      scorePos: {
        x: 750 / 2,
        y: 200,
        fadeTime: 500,
        numOffset: 0,
        before: {
          add: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017c3LC71FJvddJzXkh_!!1080040467.png", width: 28, height: 43 },
          reduce: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01dILbNH1FJvdZt6yHo_!!1080040467.png", width: 28, height: 43 },
        },
        numArr: [
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01URyJ681FJvdZt6EYc_!!1080040467.png", width: 28, height: 43, val: 0 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011ijqSv1FJvdgKcEZz_!!1080040467.png", width: 28, height: 43, val: 1 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IKHtLM1FJvdcXpT98_!!1080040467.png", width: 28, height: 43, val: 2 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KXPB8C1FJvdgKaQKO_!!1080040467.png", width: 28, height: 43, val: 3 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012Pl3fT1FJvdW2dcEW_!!1080040467.png", width: 28, height: 43, val: 4 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01qh9wDG1FJvdaPct6B_!!1080040467.png", width: 28, height: 43, val: 5 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01pVG9ny1FJvddK0cGl_!!1080040467.png", width: 28, height: 43, val: 6 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015bn9Se1FJvdXNhhYx_!!1080040467.png", width: 28, height: 43, val: 7 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R0s5Ld1FJvdeodler_!!1080040467.png", width: 28, height: 43, val: 8 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01OAg3Rk1FJvdZt7Euk_!!1080040467.png", width: 28, height: 43, val: 9 },
        ]
      },
      shade: {
        moveSpeed: 0.8,//单位距离移动速度 值越小越快 只有moveTime不设置值时才生效
        // moveTime: 0.5,//移动时间 如果有moveTime,moveSpeed就不生效
        bg: {
          anchor: { x: 0.53, y: 0.5 },
          src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01NKouDF1FJvdvM51vo_!!1080040467.png",
          width: 2000,
          height: 4000
        },
        top: {
          anchor: { x: 0.53, y: 0.495 },
          src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01kIejwv1FJvdmJrGnp_!!1080040467.png",
          width: 2000,
          height: 4000
        }
      },
      circle: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CrjvXs1FJvdwA5A7k_!!1080040467.png", width: 146, height: 146, scale: { time: 0.2, multiple: [0.95, 1.2] }, alpha: { time: 0.1 } },
      touchRect: { width: 146, height: 146 },//点击命中区域范围
      playerPos: { x: 750 / 2, y: 500 }
    }),
  },
  onLoad(query) {
  },

  playFun() {
    // 传参图片id,数组格式
    this.gameComponent.onEvent("start", ["1", "2", "3", "4", "5", "6", "7"]);
  },
  resetFun() {
    this.gameComponent.onEvent("reset");
  },

  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // this.playFun();
  },
  onUpdate(ops) {
    // { totalScore: 0, imgObj: { } }
    console.log("update:", ops)
  },
  onGameOver(totalScore) {
    console.log("gameOver:", totalScore)
  }
})
```

- xaml

```
  <game gameSource="{{gameSource}}" 
    onRef="onRef"
    onInitDone="onInitDone" 
    onUpdate="onUpdate" 
    onGameOver="onGameOver"
    />
```