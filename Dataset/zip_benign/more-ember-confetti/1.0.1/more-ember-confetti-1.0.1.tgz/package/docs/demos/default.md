```handlebars
{{confetti}}
```
