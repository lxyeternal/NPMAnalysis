import { NgModule } from '@angular/core';
import { CaraouselComponent } from './caraousel.component';

@NgModule({
  imports: [
  ],
  declarations: [CaraouselComponent],
  exports: [CaraouselComponent]
})
export class CaraouselModule { }
