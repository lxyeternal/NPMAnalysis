import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngux-caraousel',
  template: `
    <p>
      caraousel works!
    </p>
  `,
  styles: []
})
export class CaraouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
