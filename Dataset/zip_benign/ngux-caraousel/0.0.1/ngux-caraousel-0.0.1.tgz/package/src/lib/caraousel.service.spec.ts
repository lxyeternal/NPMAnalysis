import { TestBed } from '@angular/core/testing';

import { CaraouselService } from './caraousel.service';

describe('CaraouselService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CaraouselService = TestBed.get(CaraouselService);
    expect(service).toBeTruthy();
  });
});
