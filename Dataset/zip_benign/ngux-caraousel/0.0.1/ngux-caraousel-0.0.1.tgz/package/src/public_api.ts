/*
 * Public API Surface of caraousel
 */

export * from './lib/caraousel.service';
export * from './lib/caraousel.component';
export * from './lib/caraousel.module';
