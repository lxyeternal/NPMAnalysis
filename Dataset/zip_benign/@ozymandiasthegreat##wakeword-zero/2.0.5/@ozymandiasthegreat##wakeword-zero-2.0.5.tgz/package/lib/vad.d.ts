import { VADMode, VAD } from "@ozymandiasthegreat/vad";
import type { DetectorOptions } from "./index.js";
export interface VoiceActivityFilterOptions extends DetectorOptions {
    debounce: number;
}
export declare class VoiceActivityFilter {
    private options;
    private debouncing;
    private vad;
    constructor(vad: VAD, options?: Partial<VoiceActivityFilterOptions>);
    get sampleRate(): number;
    get vadMode(): VADMode;
    get vadDebounceTime(): number;
    get debounce(): number;
    processAudio(audioBuffer: Uint8Array): boolean;
    destroy(err: Error): void;
}
export default function (options: Partial<VoiceActivityFilterOptions>, vad?: VAD): Promise<VoiceActivityFilter>;
