/// <reference types="node" />
import { Transform } from "stream";
import { MFCC } from "@ozymandiasthegreat/mfcc";
import type { DetectorOptions } from "./index.js";
export interface ExtractorOptions extends DetectorOptions {
    samplesPerFrame: number;
    samplesPerShift: number;
}
declare class FeatureExtractor extends Transform {
    private options;
    private samples;
    private extractor;
    private block;
    full: boolean;
    constructor(mfcc: MFCC, options: ExtractorOptions);
    get sampleRate(): number;
    get samplesPerFrame(): number;
    get samplesPerShift(): number;
    get preEmphasisCoefficient(): number;
    _write(audioData: ArrayBufferView, enc: BufferEncoding, done: any): void;
    error(err: Error): void;
    destroy(err: Error): void;
    preEmphasis(audioBuffer: ArrayBufferView): number[];
    extractFeatures(audioFrame: number[]): Float64Array;
}
export declare function createExtractor(options: ExtractorOptions): Promise<FeatureExtractor>;
export type { FeatureExtractor };
