import * as pcm from "pcm-util";
export declare function convertAudio(buffer: ArrayBufferView, formatFrom: Partial<pcm.PCMFormat>, formatTo: Partial<pcm.PCMFormat>): ArrayBuffer;
export declare function convertInt16ToFloat32(n: number): number;
export declare function cosineSimilarity(vectorA?: number[], vectorB?: number[]): number;
