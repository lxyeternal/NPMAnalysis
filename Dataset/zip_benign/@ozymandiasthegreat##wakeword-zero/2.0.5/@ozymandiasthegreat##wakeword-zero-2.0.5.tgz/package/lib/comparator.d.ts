import type { DetectorOptions } from "./index.js";
export interface ComparatorOptions extends DetectorOptions {
}
export declare class FeatureComparator {
    private options;
    private dtw;
    constructor(options: ComparatorOptions);
    static calculateDistance(ax: number[], bx: number[]): number;
    get bandSize(): number;
    get ref(): number;
    computeProbability(cost: number): number;
    compare(a: number[][], b: number[][]): number;
    destroy(): void;
}
