export interface DTWOptions {
    distanceFunction?: (x: any, y: any) => number;
}
export declare class DTW {
    private state;
    private distanceFunction;
    constructor(options: DTWOptions);
    private computeOptimalPath;
    private computeOptimalPathWithWindow;
    private retrieveOptimalPath;
    compute(firstSequence: number[][], secondSequence: number[][], window?: number): number;
    path(): number[][] | null;
}
