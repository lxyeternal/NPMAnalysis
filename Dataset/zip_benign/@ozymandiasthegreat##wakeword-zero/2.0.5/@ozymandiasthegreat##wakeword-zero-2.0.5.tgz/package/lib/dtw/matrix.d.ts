export declare function create<T>(m: number, n: number, value: T): T[][];
