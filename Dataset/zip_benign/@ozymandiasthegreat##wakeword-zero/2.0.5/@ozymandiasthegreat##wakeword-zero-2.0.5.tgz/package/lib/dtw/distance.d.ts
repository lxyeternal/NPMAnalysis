export declare function euclideanDistance(x: number, y: number): number;
