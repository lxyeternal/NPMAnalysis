export interface KeywordOptions {
    disableAveraging?: boolean;
    threshold?: number;
}
export declare class WakewordKeyword {
    private options?;
    private averagedTemplate;
    private _templates;
    keyword: string;
    enabled: boolean;
    constructor(keyword: string, options?: KeywordOptions);
    get disableAveraging(): boolean;
    get threshold(): number;
    get templates(): number[][][];
    private averageTemplates;
    addFeatures(features: number[][]): void;
}
