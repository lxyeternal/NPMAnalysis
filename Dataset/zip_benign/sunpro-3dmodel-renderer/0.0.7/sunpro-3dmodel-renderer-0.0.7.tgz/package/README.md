# SunPro 3d Model Renderer

Installation
```bash
npm install sunpro-3dmodel-renderer
```

Usage sample
```javascript
import { ModelRenderer } from 'sunpro-3dmodel-renderer';
import React, { useRef } from 'react';

const App = () => {

  const modelRendererRef = useRef();

  return (
    <div>

      <ModelRenderer
        ref={modelRendererRef}
        enableOrbitControls={true} 
        settings={{
          treesTrunkRadius: 10,
          roofAreaHeight: 30,
          defaultRoofAreaOpacity: 0.5
        }}
        base={{
          imageUrl: 'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/4f7e1cc4-5c30-47f1-bbaa-163fe8689cf7.jpeg',
          sizeX: 800,
          sizeY: 800,
        }}
        data={{..}}
        onComponentClick={(ev) => {
          // ..
        }}
      />

      <button onClick={() => {
        const imageSrc = modelRendererRef.current.exportToImage();
        const a = document.createElement('a');
        a.href = imageSrc;
        a.download = 'image.png';
        a.click();
      }}>Export image</button>

    </div>
  )
}
```
