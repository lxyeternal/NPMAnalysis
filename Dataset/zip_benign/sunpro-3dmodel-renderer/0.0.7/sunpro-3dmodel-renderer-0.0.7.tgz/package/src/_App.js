import { ModelRenderer } from './lib'
import React, { Fragment, useState, useEffect, useRef } from 'react';

const App = () => {

  const [ isShowingHeatmap, setIsShowingHeatmap ] = useState();
  const [ renderData, setRenderData ] = useState();
  const [ isShowingPanelsSetup, setIsShowingPanelsSetup ] = useState();
  const modelRendererRef = useRef();

  useEffect(() => {
    const dataUrl = (
      isShowingPanelsSetup ? 
      'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/solar_design_metadata.json' :
      'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/roof_design_metadata.json'
    )
    fetch(dataUrl, { method: 'GET' }).then(resp => resp.json()).then(data => {
      setRenderData({
        trees: data.trees.map(t => ({
          x: 1*t.position[0]-400,
          y: -1*t.position[1]+400,
          height: 50,
          topRadius: 40,
        })),
        roofAreas: data.surfaces.map(surface => ({
          color: Math.floor(Math.random()*16777215),
          path: surface.segments.map(s => ({
            x: s[0] - 400,
            y: -1 * s[1] + 400,
          })),
          panelGroups: !surface.panels.length ? [] : [
            {
              path: surface.segments.map(s => ({
                x: s[0] - 400,
                y: -1 * s[1] + 400,
              })),
              panels: surface.panels.map(p => ({
                x: p.bottom[0] - 400 +5,
                y: -1 * p.bottom[1] + 400 + 5,
                angle: p.baseline.angle * 2 * Math.PI / 360 + Math.PI *0.71 
              }))
            }
          ]
        })),
      })
    });
  }, [isShowingPanelsSetup]);

  return (
    <Fragment>
      {!!renderData && (
        <ModelRenderer 
          ref={modelRendererRef}
          enableOrbitControls={true} 
          settings={{
            treesTrunkRadius: 10,
            roofAreaHeight: 5,
            defaultRoofAreaOpacity: 0.5,
            cameraPosition: 500
          }}
          base={{
            imageUrl: (
              isShowingHeatmap ?
              'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/4f7e1cc4-5c30-47f1-bbaa-163fe8689cf7.jpeg' :
              'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/26991b47-e93d-4fbc-a526-8f24d78485b8.jpeg'
            ),
            sizeX: 800,
            sizeY: 800,
          }}
          data={renderData}
          onComponentClick={(ev) => {
            console.log(ev);
            // let itemPath = `renderData.${ev.path}`;
            // eval(`${itemPath}.selected = !${itemPath}.selected;`);
            // eval(`${itemPath}.opacity = ${itemPath}.selected ? 0.2 : 0.8;`);
            // setRenderData(JSON.parse(JSON.stringify(renderData)));
          }}
        />
      )}
      <button onClick={() => {
        setIsShowingHeatmap(!isShowingHeatmap);
      }}>{ !!isShowingHeatmap ? 'Hide' : 'Show' } heat map</button>
      <button onClick={() => {
        setIsShowingPanelsSetup(!isShowingPanelsSetup);
      }}>{ !!isShowingPanelsSetup ? 'Hide' : 'Show' } panels</button>
      <button onClick={() => {
        const imageSrc = modelRendererRef.current.exportToImage();
        const a = document.createElement('a');
        a.href = imageSrc;
        a.download = 'image.png';
        a.click();
      }}>Export image</button>
    </Fragment>
  );
}

export default App;
