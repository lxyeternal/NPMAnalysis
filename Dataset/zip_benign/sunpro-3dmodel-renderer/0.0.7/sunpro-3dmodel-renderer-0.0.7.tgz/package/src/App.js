import { SolargrafRenderer } from './lib'
import React, { Fragment, useState, useEffect, useRef } from 'react';

const App = () => {

  const [ solargrafData, setSolargrafData ] = useState();
  const [ rendererMode, setRendererMode ] = useState('panels');

  useEffect(() => {
    const solargrafSolarUrl = 'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/solar_design_metadata.json';
    const solargrafRoofUrl = 'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/roof_design_metadata.json';
    fetch(solargrafSolarUrl, { method: 'GET' }).then(resp => resp.json()).then(solarData => {
      fetch(solargrafRoofUrl, { method: 'GET' }).then(resp => resp.json()).then(roofData => {

        setSolargrafData({
          solarData: solarData,
          roofData: roofData,
          heatmapImageUrl: 'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/4f7e1cc4-5c30-47f1-bbaa-163fe8689cf7.jpeg',
          baseImageUrl: 'https://ds-test-pub-data.s3.amazonaws.com/solargraf_design_example/26991b47-e93d-4fbc-a526-8f24d78485b8.jpeg'
        });
      
      });
    });
  }, []);

  return (
    <Fragment>
      {!!solargrafData && (
        <Fragment>
          <SolargrafRenderer
            style={{ width: 700, height: 700 }}
            key={Math.random()}
            data={solargrafData}
            mode={rendererMode}
            onPanelGroupStatusChange={ev => {
              console.log('Panel group status change', ev);
            }}
            onPanelStatusChange={ev => {
              console.log('Panel status change', ev);
              console.log(ev);
            }}
          />
          <button onClick={() => {
            setRendererMode('heatmap')
          }}>Heatmap</button>
          <button onClick={() => {
            setRendererMode('panelgroups')
          }}>Panel groups</button>
          <button onClick={() => {
            setRendererMode('panels')
          }}>Panels</button>
          <button onClick={() => {
            setRendererMode('printview')
          }}>Print view</button>
        </Fragment>
      )}
    </Fragment>
  );
}

export default App;
