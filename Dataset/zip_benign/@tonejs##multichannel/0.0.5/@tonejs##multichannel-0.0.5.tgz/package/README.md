Tone.MultiChannel wraps Tone.js and adds some components specific to creating Multichannel audio from within the Web Audio API. 

It contains the latest Tone.js and adds a few new classes

## Tone.MultiChannelOutput

`new MultiChannelOutput(channels:number)`

Create an output node with the desired number of channels. If that number of channels is available on your current system, it will map to that output, otherwise it will simulate multichannel audio using Web Audio's binaural rendering using the assumption that all of the speakers are in a ring around ear level. 

Then all nodes can be connected to this output. 

## Tone.MultiChannelPanner

`new MultiChannelPanner(channels:number)`

The multichannel panner can be connected just like a normal StereoPannerNode and is meant to be connected to the MultiChannelOutput. 

Example:
```javascript
const output = new Tone.MultiChannelOutput(4)
const panner = new Tone.MultiChannelPanner(4)
panner.connect(output)

const osc = new Tone.Oscillator()
osc.connect(panner)

//pan towards the left two speakers. 
panner.pan.value = -0.5
```

### Tone.MultiChannelPanner.pan

The panner contains a `pan` signal which has a value between -1 and 1. It assumes a ring of speakers. Pan levels of -1 and 1 meet behind the listener, and a pan of 0 is directly in the front of the listener. 
