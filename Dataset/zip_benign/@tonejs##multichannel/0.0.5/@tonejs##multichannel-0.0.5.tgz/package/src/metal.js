import Tone from './index'

const width = 4
const height = 4

const output = new Tone.GridMultiChannelOutput(width, height)
output.gain.value = 0.05

const panner = new Tone.GridPanner(width, height)
panner.connect(output)

const meter = document.createElement('multichannel-meter')
meter.setAttribute('channels', 16)
document.body.appendChild(meter)
panner.connect(meter)

window.panner = panner

const button = document.createElement('button')
button.textContent = 'start'
document.body.appendChild(button)

button.addEventListener('click', () => {
	Tone.Transport.toggle()
})

const notes = ['C3', 'G3', 'E4', 'F#4', 'A4', 'D5']
let noteIndex = 0
const osc = new Tone.Oscillator(200, 'square').connect(panner)
osc.volume.value = -10

Tone.Transport.scheduleRepeat(time => {
	osc.frequency.setValueAtTime(notes[noteIndex], time)
	noteIndex = (noteIndex + 1) % notes.length
	osc.start(time).stop(time + 0.49)
}, 0.5)

const modRate = 'C0'
const oscX = new Tone.Oscillator(modRate).connect(panner.panX)
oscX.volume.value = -1
oscX.start()
const oscY = new Tone.Oscillator(modRate).connect(panner.panY)
oscY.volume.value = -1
oscY.phase = 90
oscY.start()

const controller = document.createElement('div')
controller.style = 'width: 100px; height: 100px; background-color: black'
document.body.appendChild(controller)
controller.addEventListener('mousemove', e => {
	if (e.buttons){
		const x = (e.clientX - controller.offsetLeft) / controller.offsetWidth
		const y = (e.clientY - controller.offsetTop) / controller.offsetHeight
		panner.panX.value = x * 2 - 1
		panner.panY.value = y * 2 - 1
	}
})

const bottomRing = new Tone.MultiChannelOutput(16, 16)
bottomRing.gain.value = 0.01
const ringPanner = new Tone.MultiChannelPanner(16)
ringPanner.connect(bottomRing)

const delay = new Tone.FeedbackDelay(0.1, 0.7).connect(bottomRing)
ringPanner.connect(delay)

const ringOsc = new Tone.Oscillator('C2', 'square').connect(ringPanner)

new Tone.Oscillator('C2', 'sine').start().connect(ringPanner.pan)

const ringNotes = ['C2', 'C1', 'A2', 'B1', 'E3', 'F#2', 'D2', 'B4']
let ringNoteIndex = 0

Tone.Transport.scheduleRepeat(time => {
	ringOsc.frequency.setValueAtTime(ringNotes[ringNoteIndex], time)
	ringOsc.start(time).stop(time + 0.8)
	ringNoteIndex = (ringNoteIndex + 1) % ringNotes.length
}, 1, 0.05)
