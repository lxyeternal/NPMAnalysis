const Tone = require('tone')
Tone.MultiChannelOutput = require('./output/Output').MultiChannelOutput
Tone.GridMultiChannelOutput = require('./output/GridOutput').GridMultiChannelOutput
Tone.MultiChannelPanner = require('./output/Panner').MultiChannelPanner
Tone.MultiChannelPanner = require('./output/Panner').MultiChannelPanner
Tone.GridPanner = require('./output/GridPanner').GridPanner
Tone.AmbisonicOutput = require('./output/Ambisonic').AmbisonicOutput
require('./ui/Meter')
module.exports = Tone
