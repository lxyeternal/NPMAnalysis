import { WaveShaper, AudioNode, Merge, Signal, Gain } from 'tone'

export class MultiChannelPanner extends AudioNode {
	constructor(channels = 2, wrap = true){
		super()
		//create a multichannel output
		this._merge = this.output = new Merge(channels)

		this.input = new Gain()

		this.pan = new Signal(0)

		//create a gain for each channel and connect it to the merge
		this._gains = []
		for (let i = 0; i < channels; i++){
			//fan the input to each of the outputs
			this._gains[i] = new Gain()
			this.input.connect(this._gains[i])
			this._gains[i].connect(this._merge, 0, i)
		}

		//create all of the waveshaper curves
		this._waveshapers = []
		for (let i = 0; i < channels; i++){
			const peak = ((i + 0.5) / (channels)) * 2 - 1
			// console.log('peak', peak)
			this._waveshapers[i] = new WaveShaper(input => {
				const scalar = Math.abs(peak - input) > 1 && !wrap ? 0 : 1
				let phase = Math.cos((input - peak) * Math.PI) * scalar
				return Math.max(phase, 0)
			})
			this._waveshapers[i].connect(this._gains[i].gain)
			this.pan.connect(this._waveshapers[i])
		}
	}
}
