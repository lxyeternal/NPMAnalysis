import { AudioNode, Gain } from 'tone'
import { AmbisonicSource } from './Source'

export class AmbisonicOutput extends AudioNode {
	constructor(order=3){
		super()

		if (order !== 3 && order !== 1){
			throw new Error('only first and third order ambisonics are supported')
		}
		this._ambisonicOrder = order

		const channels = order === 3 ? 16 : 4

		const destination = this.context.rawContext.destination

		this.input = this.output = new Gain()
		this.input.channelCount = channels
		this.input.channelCountMode = 'explicit'
		this.input.channelInterpretation = 'discrete'

		this.gain = this.input.gain

		this._useFallback = destination.maxChannelCount < channels

		if (destination.maxChannelCount >= channels){

			destination.channelCount = channels
			destination.channelCountMode = 'explicit'
			destination.channelInterpretation = 'discrete'

		} 
		this.input.connect(destination)
	}

	/**
	 * @returns {AmbisonicSource} Control the azimuth and elevation of the source
	 */
	createSource(){
		const source = new AmbisonicSource(this._ambisonicOrder, this._useFallback)
		source.connect(this.input)
		return source
	}
}

