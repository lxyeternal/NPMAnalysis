import Tone, { Param, Type, Gain, Merge, Panner3D, AudioNode } from 'tone'
import Tables from 'resonance-audio/src/tables'

/**
 * @license
 * Modified from resonance-audio
 * Copyright 2017 Google Inc, Apache-2.0 
 * http://www.apache.org/licenses/LICENSE-2.0
 * @author Andrew Allen <bitllama@google.com>
 */
export class AmbisonicSource extends AudioNode {
	constructor(order, fallback=false){

		super()

		this._width = 0
		this._ambisonicOrder = order
		this._fallback = fallback

		this._azimuth = new Param({
			param : new Gain().gain,
			units : Type.Degrees
		})

		this._elevation = new Param({
			param : new Gain().gain,
			units : Type.Degrees
		})

		this.input = new Gain()
		
		if (!this._fallback){
			const numChannels = (this._ambisonicOrder + 1) * (this._ambisonicOrder + 1)

			this._merger = this.output = new Merge(numChannels)

			this._channelGains = []
			for (let i = 0; i < numChannels; i++){
				this._channelGains[i] = new Gain()
				this.input.connect(this._channelGains[i])
				this._channelGains[i].connect(this._merger, 0, i)
			}
		} else {
			this.output = this.context.createPanner()
			this.output.panningModel = 'HRTF'
			this.input.connect(this.output)
		}
		
		//set initially
		this.setPositionAtTime(0, 0, 0)
	}

	/**
	 * Cancel events scheduled after the given time.
	 * @param {Time} [time=Tone.now()] 
	 */
	cancelScheduledValues(time=Tone.now()){
		this._azimuth.cancelScheduledValues(time)
		this._elevation.cancelScheduledValues(time)

		if (!this._fallback){
			this._channelGains.forEach(gainNode => gainNode.gain.cancelScheduledValues())
		} else {
			this.output.positionX.cancelScheduledValues(time)
			this.output.positionY.cancelScheduledValues(time)
			this.output.positionZ.cancelScheduledValues(time)
		}
	}

	/**
	 * @private
	 */
	_setAtTime(azimuth, elevation, fn, time){
		// Format direction for index lookups.
		azimuth = Math.round(azimuth % 360)
		if (azimuth < 0){
			azimuth += 360
		}
		elevation = Math.round(Math.min(90, Math.max(-90, elevation))) + 90

		this._azimuth[fn](azimuth, time)
		this._elevation[fn](elevation, time)

		if (!this._fallback){
			// Assign gains to each output.
			this._channelGains[0].gain[fn](Tables.MAX_RE_WEIGHTS[this._width][0], time)
			for (let i = 1; i <= this._ambisonicOrder; i++){
				const degreeWeight = Tables.MAX_RE_WEIGHTS[this._width][i]
				for (let j = -i; j <= i; j++){
					const acnChannel = (i * i) + i + j
					const elevationIndex = i * (i + 1) / 2 + Math.abs(j) - 1
					let val = Tables.SPHERICAL_HARMONICS[1][elevation][elevationIndex]
					if (j != 0){
						let azimuthIndex = Tables.SPHERICAL_HARMONICS_MAX_ORDER + j - 1
						if (j < 0){
							azimuthIndex = Tables.SPHERICAL_HARMONICS_MAX_ORDER + j
						}
						val *= Tables.SPHERICAL_HARMONICS[0][azimuth][azimuthIndex]
					}
					this._channelGains[acnChannel].gain[fn](val * degreeWeight, time)
				}
			}
		} else {
			const radius = Math.SQRT2
			elevation = Math.PI * (elevation/180)
			azimuth = Math.PI * (azimuth/180)
			const x = radius * Math.cos(elevation) * Math.cos(azimuth)
			const y = radius * Math.cos(elevation) * Math.sin(azimuth)
			const z = radius * Math.sin(elevation)
			this.output.positionX[fn](x, time)
			this.output.positionY[fn](y, time)
			this.output.positionZ[fn](z, time)
		}
	}

	/**
	 * Set the elevation and azimuth of the source
	 * @param {number} azimuth the rotational direction of the audio source. between 0-360
	 * @param {number} elevation the height of the object, -90 (below the listener) to 90 degrees above the listener
	 * @param {Time} [time=Tone.now()] The time when the event should occur
	 */
	setPositionAtTime(azimuth, elevation, time=Tone.now()){
		this._setAtTime(azimuth, elevation, 'setValueAtTime', time)
	}

	/**
	 * Linear ramp to the elevation and azimuth of the source at the given time
	 * @param {number} azimuth the rotational direction of the audio source. between 0-360
	 * @param {number} elevation the height of the object, -90 (below the listener) to 90 degrees above the listener
	 * @package {Time} [time=Tone.now()] The time when the event should occur
	 */
	rampToPositionAtTime(azimuth, elevation, time = Tone.now()){
		this._setAtTime(azimuth, elevation, 'linearRampToValueAtTime', time)
	}

	/**
	 * How wide or pinpointed the sound is. 
	 * @type {number} 0-360
	 */
	set width(w){
		this._width = Math.min(359, Math.max(0, Math.round(w)))
		this.setPositionAtTime(this._azimuth.getValueAtTime(Tone.now()), this._elevation.getValueAtTime(Tone.now()), Tone.now())
	}

	get width(){
		return this._width
	}
}
