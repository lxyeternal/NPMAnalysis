import { AudioNode, Split, Merge, Signal } from 'tone'
import { MultiChannelPanner } from './Panner'

export class GridPanner extends AudioNode {
	constructor(width = 2, height = 2){
		super()
		//create a multichannel output
				
		this._xPanner = this.input = new MultiChannelPanner(width, false)
		this._merge = this.output = new Merge(width * height)
		this._split = new Split(width)
		this.panX = this._xPanner.pan

		this._xPanner.connect(this._split)

		this.panY = new Signal(0)
        
		this._panners = []
		for (let x = 0; x < width; x++){
			const yPanner = new MultiChannelPanner(height, false)
			this._panners.push(yPanner)
			this.panY.connect(yPanner.pan)
			this._split.connect(yPanner, x, 0)
			const innerSplit = new Split(height)
			yPanner.connect(innerSplit)
			for (let y = 0; y < height; y++){
				innerSplit.connect(this._merge, y, x * width + y)
			}
		}
	}
}
