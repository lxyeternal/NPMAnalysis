import { AudioNode, Gain, Panner3D, Split, Merge } from 'tone'

export class MultiChannelOutput extends AudioNode {
	constructor(channels, offset = 0){
		super()

		const destination = this.context.rawContext.destination

		this.input = this.output = new Gain()
		this.input.channelCount = channels
		this.input.channelCountMode = 'explicit'
		this.input.channelInterpretation = 'discrete'

		this.gain = this.input.gain

		if (destination.maxChannelCount >= channels + offset){

			destination.channelCount = channels + offset
			destination.channelCountMode = 'explicit'
			destination.channelInterpretation = 'discrete'

			if (offset > 0){
				const split = new Split(channels)
				const merge = new Merge(channels + offset)
				for (let i = 0; i < channels; i++){
					split.connect(merge, i, i + offset)
				}
				this.input.connect(split)
				merge.connect(destination)
			} else {
				this.input.connect(destination)
			}

		} else {

			this._split = new Split(channels)
			this._split.channelCount = channels
			this._split.channelCountMode = 'explicit'
			this._split.channelInterpretation = 'discrete'

			this.input.connect(this._split)

			this._channels = []

			//make a bunch of virtual speakers positioned around the listener
			for (let i = 0; i < channels; i++){
				//add 4 speakers to the room and put the listener in the center
				const angle = 2 * Math.PI * (i / channels)
				const x = Math.SQRT2 * Math.cos(angle)
				const y = Math.SQRT2 * Math.sin(angle)
				const virtualOutput = new Panner3D(x, y, 0).connect(this.context.destination)
				virtualOutput.panningModel = 'HRTF'
				this._split.connect(virtualOutput, i, 0)

				this._channels.push(virtualOutput)
			}
		}

	}
}

