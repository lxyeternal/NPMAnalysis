import { AudioNode, Gain, Panner3D, Split } from 'tone'

export class GridMultiChannelOutput extends AudioNode {
	constructor(width, height){
		super()

		const channels = width * height

		const destination = this.context.rawContext.destination

		this.input = this.output = new Gain()
		this.input.channelCount = channels
		this.input.channelCountMode = 'explicit'
		this.input.channelInterpretation = 'discrete'

		this.gain = this.input.gain

		if (destination.maxChannelCount >= channels){

			destination.channelCount = destination.maxChannelCount
			destination.channelCountMode = 'explicit'
			destination.channelInterpretation = 'discrete'

			this.input.connect(destination)

		} else {

			this._split = new Split(channels)
			this._split.channelCount = channels
			this._split.channelCountMode = 'explicit'
			this._split.channelInterpretation = 'discrete'

			this.input.connect(this._split)

			this._channels = []

			//make a bunch of virtual speakers positioned around the listener
			let inputNum = 0
			for (let x = 0; x < width; x++){
				for (let y = 0; y < height; y++){
					//add 4 speakers to the room and put the listener in the center
					const dist = 2
					const xPos = ((x / (width-1)) - 0.5) * dist
					const yPos = ((y / (height-1)) - 0.5) * dist
					const virtualOutput = new Panner3D(xPos, -dist, yPos).connect(this.context.destination)
					virtualOutput.panningModel = 'HRTF'
					this._split.connect(virtualOutput, inputNum++, 0)
					this._channels.push(virtualOutput)
				}
			}
		}

	}
}

