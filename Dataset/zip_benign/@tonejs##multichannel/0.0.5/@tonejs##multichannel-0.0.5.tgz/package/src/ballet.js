import Tone from './index'

const output = new Tone.AmbisonicOutput()
output.gain.value = 0.5

const meter = document.createElement('multichannel-meter')
meter.setAttribute('channels', 16)
document.body.appendChild(meter)
output.connect(meter)

const source = output.createSource()
window.source = source

const button = document.createElement('button')
button.textContent = 'start'
document.body.appendChild(button)
button.addEventListener('click', () => {
	Tone.Transport.toggle()
})

let azimuth = 0
const notes = ['C4', 'E4', 'B4', 'D3']
const notes2 = ['E4', 'B4', 'G4', 'B2']
const notes3 = ['B4', 'A5', 'D5', 'F#3']
let noteIndex = 0
const osc = new Tone.Oscillator('C3', 'sawtooth').connect(source)
const osc2 = new Tone.Oscillator('C3', 'sine').connect(source)
const osc3 = new Tone.Oscillator('C3', 'sawtooth').connect(source)
Tone.Transport.scheduleRepeat(time => {
	osc.start(time).stop(time + 0.05)
	osc.frequency.setValueAtTime(notes[noteIndex])
	osc2.start(time + 0.05).stop(time + 0.1)
	osc2.frequency.setValueAtTime(notes2[noteIndex])
	osc3.start(time + 0.05).stop(time + 0.1)
	osc3.frequency.setValueAtTime(notes3[noteIndex])
	noteIndex = (noteIndex + 1) % notes.length

	azimuth += 10
	source.setPositionAtTime(azimuth % 360, 20, time)
}, 0.4)

const chordSource = output.createSource()
const chords = new Tone.PolySynth(3).connect(chordSource)
new Tone.Sequence((time, note) => {
	chords.triggerAttackRelease(note, '8n', time)
	// chordSource.setPositionAtTime()
}, [['C4', 'E4', 'B4'], ['E4', 'B4', 'A5', ['B4', 'G4', 'D5'], ['D3', 'B2', 'F#3']], '8n']).start(0)

const slider = document.createElement('input')
slider.type = 'range'
slider.min = 0
slider.max = 360
document.body.appendChild(slider)
slider.addEventListener('input', (e) => {
	console.log(e.target.value)
	source.setPositionAtTime(azimuth % 360, 0)
})

const bassSource = output.createSource()

let bassAngle = 0
const bassSynth = new Tone.FMSynth().connect(bassSource)
const feedbackDelay = new Tone.FeedbackDelay('4n', 0.4).connect(bassSource)
bassSynth.connect(feedbackDelay)
new Tone.Sequence((time, note) => {
	bassSynth.triggerAttackRelease(note, '4n', time)
	bassSource.setPositionAtTime(bassAngle % 360, -10, time)
	bassAngle += 10
}, ['C2', 'E1', 'C2', 'B1'], '2n').start(0)

Tone.Transport.bpm.value = 135
window.Transport = Tone.Transport
