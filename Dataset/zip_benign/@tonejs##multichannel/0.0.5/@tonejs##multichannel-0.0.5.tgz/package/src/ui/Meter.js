import Tone, { Meter, Split, Gain } from 'tone'
import { LitElement, html } from 'lit-element'

export class MeterElement extends LitElement {

	static get properties(){
		return {
			channels : { type : Number }
		}
	}

	constructor(){
		super()

		this._meters = []

		this.input = new Gain()

	}
	
	_loop(){
		this._animationFrame = requestAnimationFrame(this._loop.bind(this))
		this.performUpdate()
	}
	
	connectedCallback(){
		this._loop()
	}

	disconnectedCallback(){
		cancelAnimationFrame(this._animationFrame)
	}

	updated(changed){
		if (changed.has('channels')){
			//if it was previously set
			if (typeof changed.get('channels') !== 'undefined'){
				this._split.dispose()
				this._meters.forEach(meter => meter.dispose())
				this.input.disconnect()
			}
			
			this._split = new Split(this.channels)
			this.input.connect(this._split)
			
			this._meters = []
			for (let i = 0; i < this.channels; i++){
				const meter = new Meter()
				this._split.connect(meter, i, 0)
				this._meters.push(meter)
			}
		}
	}

	_renderMeter(meter){
		const value = Tone.dbToGain(meter.getLevel())
		return html`
			<div class="meter">
				<div id="fill" style="height:${(value*100).toFixed(2)}%"></div>
			</div>
		`
	}

	render(){
		return html`
			<style>
				:host {
					display: block;
					height: 60px;
					width: 100px;
				}
				#container {
					width: 100%;
					height: 100%;
					background-color: black;
					display: flex;
				}
				.meter {
					flex: 1;
					height: calc(100% - 2px);
					background-color: white;
					margin: 1px;
					position: relative;
				}

				.meter #fill {
					position: absolute;
					background-color: green;
					height: 0px;
					bottom: 0px;
					width: 100%;
				}
			</style>
			<div id="container">
				${this._meters.map(meter => this._renderMeter(meter))}
			</div>
		`
	}
}

customElements.define('multichannel-meter', MeterElement)
