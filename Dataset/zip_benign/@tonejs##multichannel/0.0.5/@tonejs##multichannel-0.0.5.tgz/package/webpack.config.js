const { resolve } = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')

const commonConfig = {
	context : resolve(__dirname, 'src'),
	module : {
		rules : [
			{
				test : /\.js$/,
				exclude : /(node_modules)/,
				use : {
					loader : 'babel-loader',
					options : {
						presets : [
							[
								'@babel/preset-env',
								{
									targets : {
										esmodules : true
									}
								}
							]
						]
					}
				}
			}
		]
	},
	plugins : [
		new HtmlWebpackPlugin({ title : 'MultiChannel' })
	],
	devtool : 'cheap-source-map',
}

module.exports = [
	Object.assign({}, commonConfig, {
		entry : './index.js',
		output : {
			path : resolve(__dirname, 'build'),
			filename : 'Tone.MultiChannel.js',
			library : 'Tone',
			libraryTarget : 'umd',
			globalObject : 'typeof self !== \'undefined\' ? self : this',
		},
		plugins : [
			new HtmlWebpackPlugin({ title : 'MultiChannel' })
		]
	}),
	Object.assign({}, commonConfig, {
		entry : './test.js',
		output : {
			path : resolve(__dirname, 'build'),
			filename : 'test.js',
		},
		plugins : [
			new HtmlWebpackPlugin({ title : 'MultiChannel Test', filename : 'test.html' })
		]
	})
]
