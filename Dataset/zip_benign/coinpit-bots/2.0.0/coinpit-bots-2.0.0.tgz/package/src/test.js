var fs = require('fs')

function readWallet(walletFile) {
  var stats      = walletFile && fs.statSync(walletFile)
  var wallet     = fs.readFileSync(walletFile)
  var walletData = JSON.parse(wallet)
  return walletData
}

// live.coinpit.io is production
// live.coinpit.me is testnet

var privKey = readWallet(process.argv[2]);
console.log(privKey);

var cc = require('coinpit-client')('https://live.coinpit.io')
var account;
cc.getAccount(privKey.privateKey).then(function (acc) {
  console.log("got account");
  account = acc
});