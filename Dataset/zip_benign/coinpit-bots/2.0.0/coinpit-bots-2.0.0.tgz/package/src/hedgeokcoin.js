var bluebird = require('bluebird')
var mangler  = require('mangler')
var affirm   = require('affirm.js')
var params   = require('./botParams')(process.argv[2])
var Rest = require('rest.js')


var hedge = bluebird.coroutine(function* mmHedge(params) {
  var baseurl         = params.baseurl
  var wallet          = params.wallet
  var cc              = require("coinpit-client")(baseurl)
  var account         = yield cc.getAccount(wallet.privateKey)
  account.logging     = true
  var listener        = {}
  listener.orderPatch = bluebird.coroutine(function*(response) {
    console.log('orderPatch', response)
  })

  listener.userMessage = bluebird.coroutine(function*() {
    updatePositionThrottle()
  })

  var positionTimer
  function updatePositionThrottle(){
    if(positionTimer) clearTimeout(positionTimer)
    positionTimer = setTimeout(updatePosition, 2000)
  }


  function* updatePosition() {
    var position = account.getPositions()[instrument.symbol]


  }



  function* init() {
    require('./coinpitFeed')(listener, account.socket)

  }

  yield* init()
})

hedge(params)
