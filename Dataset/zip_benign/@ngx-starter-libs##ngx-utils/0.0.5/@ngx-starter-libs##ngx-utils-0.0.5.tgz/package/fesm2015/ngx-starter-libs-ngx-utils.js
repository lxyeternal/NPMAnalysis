import { __decorate, __metadata, __param } from 'tslib';
import { Input, Directive, ViewContainerRef, TemplateRef, NgModule, Renderer2, ElementRef, ɵɵdefineInjectable, Injectable, EventEmitter, Output, Inject, PLATFORM_ID, HostListener, Pipe, ChangeDetectorRef } from '@angular/core';
import { CommonModule, isPlatformBrowser, AsyncPipe } from '@angular/common';
import { NavigationEnd, Router } from '@angular/router';
import { Observable, Subject, combineLatest, of, interval } from 'rxjs';
import { takeUntil, pluck as pluck$1, map, filter, finalize, take, repeatWhen, delayWhen, takeWhile, tap } from 'rxjs/operators';
import { Validators, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { formatDistance, differenceInMinutes, parseISO } from 'date-fns';

class NgLetContext {
    constructor() {
        this.$implicit = null;
        this.ngLet = null;
    }
}
let NgLetDirective = class NgLetDirective {
    constructor(vcr, templateRef) {
        this.vcr = vcr;
        this.templateRef = templateRef;
        this.context = new NgLetContext();
    }
    set ngLet(value) {
        this.context.$implicit = this.context.ngLet = value;
    }
    ngOnInit() {
        this.vcr.createEmbeddedView(this.templateRef, this.context);
    }
};
__decorate([
    Input(),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], NgLetDirective.prototype, "ngLet", null);
NgLetDirective = __decorate([
    Directive({
        selector: '[ngLet]',
    }),
    __metadata("design:paramtypes", [ViewContainerRef, TemplateRef])
], NgLetDirective);

let NgLetModule = class NgLetModule {
};
NgLetModule = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [NgLetDirective],
        exports: [NgLetDirective],
    })
], NgLetModule);

// create a symbol identify the observable I add to
// the component so it doesn't conflict with anything.
// I need this so I'm able to add the desired behaviour to the component.
const destroy$ = Symbol('destroy$');
/**
 * An operator that takes until destroy it takes a components this a parameter
 * returns a pipeable RxJS operator.
 */
const untilDestroy = (component) => {
    if (component[destroy$] === undefined) {
        // only hookup each component once.
        addDestroyObservableToComponent(component);
    }
    // pipe in the takeUntil destroy$ and return the source unaltered
    return takeUntil(component[destroy$]);
};
/**
 * @internal
 */
function addDestroyObservableToComponent(component) {
    component[destroy$] = new Observable(observer => {
        // keep track of the original destroy function,
        // the user might do something in there
        const orignalDestroy = component.ngOnDestroy;
        if (orignalDestroy == null) {
            // Angular does not support dynamic added destroy methods
            // so make sure there is one.
            throw new Error('untilDestroy operator needs the component to have an ngOnDestroy method');
        }
        // replace the ngOndestroy
        component.ngOnDestroy = () => {
            // fire off the destroy observable
            observer.next();
            // complete the observable
            observer.complete();
            // and at last, call the original destroy
            orignalDestroy.call(component);
        };
        // return cleanup function.
        return (_) => (component[destroy$] = undefined);
    });
}

function pluck(...props) {
    return pluck$1(...props);
}

let RouterLinkMatchDirective = class RouterLinkMatchDirective {
    constructor(router, renderer, ngEl) {
        this.renderer = renderer;
        this.ngEl = ngEl;
        this.onChangesHook = new Subject();
        combineLatest([router.events, this.onChangesHook])
            .pipe(map(([e]) => e), filter(e => e instanceof NavigationEnd), untilDestroy(this))
            .subscribe(e => {
            this.curRoute = e.urlAfterRedirects;
            this._updateClass(this.matchExp);
        });
    }
    set routerLinkMatch(v) {
        if (v && typeof v === 'object') {
            this.matchExp = v;
        }
        else {
            throw new TypeError(`Unexpected type '${typeof v}' of value for ` + `input of routerLinkMatch directive, expected 'object'`);
        }
    }
    ngOnChanges(changes) {
        if (changes.routerLinkMatch) {
            this.onChangesHook.next(changes.routerLinkMatch.currentValue);
        }
    }
    _updateClass(v) {
        Object.keys(v).forEach(cls => {
            if (v[cls] && typeof v[cls] === 'string') {
                const regexp = new RegExp(v[cls]);
                if (this.curRoute.match(regexp)) {
                    this._toggleClass(cls, true);
                }
                else {
                    this._toggleClass(cls, false);
                }
            }
            else {
                throw new TypeError(`Could not convert match value to Regular Expression. ` +
                    `Unexpected type '${typeof v[cls]}' for value of key '${cls}' ` +
                    `in routerLinkMatch directive match expression, expected 'non-empty string'`);
            }
        });
    }
    _toggleClass(classes, enabled) {
        classes = classes.trim();
        classes.split(/\s+/g).forEach(cls => {
            if (enabled) {
                this.renderer.addClass(this.ngEl.nativeElement, cls);
            }
            else {
                this.renderer.removeClass(this.ngEl.nativeElement, cls);
            }
        });
    }
    ngOnDestroy() { }
};
__decorate([
    Input('routerLinkMatch'),
    __metadata("design:type", Object),
    __metadata("design:paramtypes", [Object])
], RouterLinkMatchDirective.prototype, "routerLinkMatch", null);
RouterLinkMatchDirective = __decorate([
    Directive({
        selector: '[routerLinkMatch]',
    }),
    __metadata("design:paramtypes", [Router, Renderer2, ElementRef])
], RouterLinkMatchDirective);

let RouterLinkMatchModule = class RouterLinkMatchModule {
};
RouterLinkMatchModule = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [RouterLinkMatchDirective],
        exports: [RouterLinkMatchDirective],
    })
], RouterLinkMatchModule);

let ViewportService = class ViewportService {
    constructor() {
        this.options = {
            rootMargin: '0px 0px 0px 0px',
            threshold: [0.5],
        };
        this.callback$ = new Subject();
        this.observer = new IntersectionObserver(this.handler.bind(this), this.options);
    }
    observe(element) {
        this.observer.observe(element);
        return this.callback$.asObservable().pipe(filter((entry) => entry.target === element), finalize(() => this.observer.unobserve(element)));
    }
    handler(entries) {
        entries.forEach(entry => this.callback$.next(entry));
    }
};
ViewportService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ViewportService_Factory() { return new ViewportService(); }, token: ViewportService, providedIn: "root" });
ViewportService = __decorate([
    Injectable({
        providedIn: 'root',
    }),
    __metadata("design:paramtypes", [])
], ViewportService);

let InViewportDirective = class InViewportDirective {
    constructor(elementRef, viewportService, 
    // tslint:disable-next-line: ban-types
    platformId) {
        this.elementRef = elementRef;
        this.viewportService = viewportService;
        this.platformId = platformId;
        this.preRender = true;
        this.oneTime = false;
        this.inViewport = new EventEmitter();
    }
    ngOnInit() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.oneTime) {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this), filter(entry => entry.intersectionRatio >= 0.5), take(1))
                    .subscribe((entry) => {
                    this.inViewport.emit(entry);
                });
            }
            else {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this))
                    .subscribe((entry) => {
                    this.inViewport.emit(entry);
                });
            }
        }
        else {
            if (this.preRender) {
                this.inViewport.emit({ isIntersecting: true, intersectionRatio: 1 });
            }
        }
    }
    ngOnDestroy() { }
};
__decorate([
    Input(),
    __metadata("design:type", Object)
], InViewportDirective.prototype, "preRender", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], InViewportDirective.prototype, "oneTime", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], InViewportDirective.prototype, "inViewport", void 0);
InViewportDirective = __decorate([
    Directive({
        selector: '[inViewport]',
    }),
    __param(2, Inject(PLATFORM_ID)),
    __metadata("design:paramtypes", [ElementRef,
        ViewportService,
        Object])
], InViewportDirective);

let InViewportModule = class InViewportModule {
};
InViewportModule = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [InViewportDirective],
        exports: [InViewportDirective],
    })
], InViewportModule);

let ClickOutsideDirective = class ClickOutsideDirective {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.ngxClickOutside = new EventEmitter();
    }
    onClick(event, targetElement) {
        if (!targetElement) {
            return;
        }
        const clickedInside = this.elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.ngxClickOutside.emit(event);
        }
    }
};
__decorate([
    Output(),
    __metadata("design:type", Object)
], ClickOutsideDirective.prototype, "ngxClickOutside", void 0);
__decorate([
    HostListener('document:click', ['$event', '$event.target']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [MouseEvent, HTMLElement]),
    __metadata("design:returntype", void 0)
], ClickOutsideDirective.prototype, "onClick", null);
ClickOutsideDirective = __decorate([
    Directive({
        selector: '[ngxClickOutside]',
    }),
    __metadata("design:paramtypes", [ElementRef])
], ClickOutsideDirective);

let ClickOutsideModule = class ClickOutsideModule {
};
ClickOutsideModule = __decorate([
    NgModule({
        declarations: [ClickOutsideDirective],
        imports: [CommonModule],
        exports: [ClickOutsideDirective],
    })
], ClickOutsideModule);

var MinValidatorDirective_1;
let MinValidatorDirective = MinValidatorDirective_1 = class MinValidatorDirective {
    validate(control) {
        return this.min ? Validators.min(this.min)(control) : null;
    }
};
__decorate([
    Input(),
    __metadata("design:type", Number)
], MinValidatorDirective.prototype, "min", void 0);
MinValidatorDirective = MinValidatorDirective_1 = __decorate([
    Directive({
        selector: '[appMin],[formControlName],[formControl],[ngModel]',
        providers: [{ provide: NG_VALIDATORS, useExisting: MinValidatorDirective_1, multi: true }],
        exportAs: 'min',
    })
], MinValidatorDirective);

let MinModule = class MinModule {
};
MinModule = __decorate([
    NgModule({
        declarations: [MinValidatorDirective],
        imports: [CommonModule],
        exports: [MinValidatorDirective],
    })
], MinModule);

const MASK_FLAGS = ['C', '&', 'a', 'A', '?', 'L', '9', '0', '#'];
const KEYS = {
    Ctrl: 17,
    Z: 90,
    Y: 89,
    X: 88,
    BACKSPACE: 8,
    DELETE: 46,
};
class MaskHelper {
    get cursor() {
        return this.cursorPrivate;
    }
    parseValueByMask(value, maskOptions, cursor) {
        let inputValue = value;
        const mask = maskOptions.format;
        const literals = this.getMaskLiterals(mask);
        const literalKeys = Array.from(literals.keys());
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (inputValue.length < mask.length) {
            // BACKSPACE, DELETE
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (nonLiteralIndeces.indexOf(cursor + 1) !== -1) {
                inputValue = this.insertCharAt(inputValue, cursor + 1, maskOptions.promptChar);
                this.cursorPrivate = cursor + 1;
            }
            else {
                inputValue = this.insertCharAt(inputValue, cursor + 1, mask[cursor + 1]);
                this.cursorPrivate = cursor + 1;
                for (let i = this.cursorPrivate; i < 0; i--) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate--;
                    }
                    else {
                        break;
                    }
                }
            }
        }
        else {
            const char = inputValue[cursor];
            let isCharValid = this.validateCharOnPostion(char, cursor, mask);
            if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                if (isCharValid) {
                    inputValue = this.replaceCharAt(inputValue, cursor, char);
                    this.cursorPrivate = cursor + 1;
                }
                else {
                    this.cursorPrivate = cursor;
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                this.cursorPrivate = ++cursor;
                for (let i = cursor; i < mask.length; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate = ++cursor;
                    }
                    else {
                        isCharValid = this.validateCharOnPostion(char, cursor, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, cursor, char);
                            this.cursorPrivate = ++cursor;
                            break;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }
        return inputValue;
    }
    parseMask(maskOptions) {
        let outputVal = '';
        const mask = maskOptions.format;
        const literals = this.getMaskLiterals(mask);
        for (const maskSym of mask) {
            outputVal += maskOptions.promptChar;
        }
        literals.forEach((val, key) => {
            outputVal = this.replaceCharAt(outputVal, key, val);
        });
        return outputVal;
    }
    parseValueByMaskOnInit(inputVal, maskOptions) {
        let outputVal = '';
        let value = '';
        const mask = maskOptions.format;
        const literals = this.getMaskLiterals(mask);
        const literalKeys = Array.from(literals.keys());
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        const literalValues = Array.from(literals.values());
        if (inputVal != null) {
            value = inputVal.toString();
        }
        for (const maskSym of mask) {
            outputVal += maskOptions.promptChar;
        }
        literals.forEach((val, key) => {
            outputVal = this.replaceCharAt(outputVal, key, val);
        });
        if (!value) {
            return outputVal;
        }
        const nonLiteralValues = this.getNonLiteralValues(value, literalValues);
        for (let i = 0; i < nonLiteralValues.length; i++) {
            const char = nonLiteralValues[i];
            const isCharValid = this.validateCharOnPostion(char, nonLiteralIndeces[i], mask);
            if (!isCharValid && char !== maskOptions.promptChar) {
                nonLiteralValues[i] = maskOptions.promptChar;
            }
        }
        if (nonLiteralValues.length > nonLiteralIndeces.length) {
            nonLiteralValues.splice(nonLiteralIndeces.length);
        }
        let pos = 0;
        for (const nonLiteralValue of nonLiteralValues) {
            const char = nonLiteralValue;
            outputVal = this.replaceCharAt(outputVal, nonLiteralIndeces[pos++], char);
        }
        return outputVal;
    }
    restoreValueFromMask(value, maskOptions) {
        let outputVal = '';
        const mask = maskOptions.format;
        const literals = this.getMaskLiterals(mask);
        const literalValues = Array.from(literals.values());
        for (const val of value) {
            if (literalValues.indexOf(val) === -1) {
                if (val !== maskOptions.promptChar) {
                    outputVal += val;
                }
            }
        }
        return outputVal;
    }
    parseValueByMaskUponSelection(value, maskOptions, cursor, selection) {
        let isCharValid;
        let inputValue = value;
        const char = inputValue[cursor];
        const mask = maskOptions.format;
        const literals = this.getMaskLiterals(mask);
        const literalKeys = Array.from(literals.keys());
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (!this.data) {
            this.cursorPrivate = cursor < 0 ? ++cursor : cursor;
            if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                inputValue = isCharValid
                    ? this.replaceCharAt(inputValue, this.cursorPrivate++, char)
                    : (inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar));
                selection--;
                if (selection > 0) {
                    for (let i = 0; i < selection; i++) {
                        cursor++;
                        inputValue =
                            nonLiteralIndeces.indexOf(cursor) !== -1
                                ? this.insertCharAt(inputValue, cursor, maskOptions.promptChar)
                                : this.insertCharAt(inputValue, cursor, mask[cursor]);
                    }
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, this.cursorPrivate, mask[this.cursorPrivate]);
                this.cursorPrivate++;
                selection--;
                let isMarked = false;
                if (selection > 0) {
                    cursor = this.cursorPrivate;
                    for (let i = 0; i < selection; i++) {
                        if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                            isCharValid = this.validateCharOnPostion(char, cursor, mask);
                            if (isCharValid && !isMarked) {
                                inputValue = this.insertCharAt(inputValue, cursor, char);
                                cursor++;
                                this.cursorPrivate++;
                                isMarked = true;
                            }
                            else {
                                inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                                cursor++;
                            }
                        }
                        else {
                            inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                            if (cursor === this.cursorPrivate) {
                                this.cursorPrivate++;
                            }
                            cursor++;
                        }
                    }
                }
            }
        }
        else {
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (this.cursorPrivate < 0) {
                this.cursorPrivate++;
                cursor++;
            }
            cursor++;
            this.cursorPrivate = cursor;
            for (let i = 0; i < selection; i++) {
                if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                    inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                    cursor++;
                }
                else {
                    inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                    cursor++;
                }
            }
        }
        return inputValue;
    }
    parseValueByMaskUponCopyPaste(value, maskOptions, cursor, clipboardData, selection) {
        let inputValue = value;
        const mask = maskOptions.format;
        const literals = this.getMaskLiterals(mask);
        const literalKeys = Array.from(literals.keys());
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        const selectionEnd = cursor + selection;
        this.cursorPrivate = cursor;
        for (const clipboardSym of clipboardData) {
            const char = clipboardSym;
            if (this.cursorPrivate > mask.length) {
                return inputValue;
            }
            if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                const isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                if (isCharValid) {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                }
            }
            else {
                for (let i = cursor; i < mask.length; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate++;
                    }
                    else {
                        const isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                        }
                        break;
                    }
                }
            }
            selection--;
        }
        if (selection > 0) {
            for (let i = this.cursorPrivate; i < selectionEnd; i++) {
                if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                    this.cursorPrivate++;
                }
                else {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                }
            }
        }
        return inputValue;
    }
    validateCharOnPostion(inputChar, position, mask) {
        let regex;
        let isValid;
        const letterOrDigitRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        const letterDigitOrSpaceRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        const letterRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        const letteSpaceRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        const digitRegEx = '[\\d]';
        const digitSpaceRegEx = '[\\d\\u0020]';
        const digitSpecialRegEx = '[\\d-\\+]';
        switch (mask.charAt(position)) {
            case 'C':
                isValid = inputChar !== '';
                break;
            case '&':
                regex = new RegExp('[\\u0020]');
                isValid = !regex.test(inputChar);
                break;
            case 'a':
                regex = new RegExp(letterDigitOrSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'A':
                regex = new RegExp(letterOrDigitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '?':
                regex = new RegExp(letteSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'L':
                regex = new RegExp(letterRegEx);
                isValid = regex.test(inputChar);
                break;
            case '0':
                regex = new RegExp(digitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '9':
                regex = new RegExp(digitSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case '#':
                regex = new RegExp(digitSpecialRegEx);
                isValid = regex.test(inputChar);
                break;
            default: {
                isValid = null;
            }
        }
        return isValid;
    }
    replaceCharAt(strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index + 1);
        }
    }
    insertCharAt(strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index);
        }
    }
    getMaskLiterals(mask) {
        const literals = new Map();
        for (let i = 0; i < mask.length; i++) {
            const char = mask.charAt(i);
            if (MASK_FLAGS.indexOf(char) === -1) {
                literals.set(i, char);
            }
        }
        return literals;
    }
    getNonLiteralIndeces(mask, literalKeys) {
        const nonLiteralsIndeces = new Array();
        for (let i = 0; i < mask.length; i++) {
            if (literalKeys.indexOf(i) === -1) {
                nonLiteralsIndeces.push(i);
            }
        }
        return nonLiteralsIndeces;
    }
    getNonLiteralValues(value, literalValues) {
        const nonLiteralValues = new Array();
        for (const val of value) {
            if (literalValues.indexOf(val) === -1) {
                nonLiteralValues.push(val);
            }
        }
        return nonLiteralValues;
    }
}

var MaskDirective_1;
function isIE() {
    return navigator.appVersion.indexOf('Trident/') > 0;
}
const noop = () => { };
const ɵ0 = noop;
let MaskDirective = MaskDirective_1 = class MaskDirective {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.valueChange = new EventEmitter();
        this.maskOptions = {
            format: '',
            promptChar: '',
        };
        this.onTouchedCallback = noop;
        this.onChangeCallback = noop;
        this.maskHelper = new MaskHelper();
    }
    get value() {
        return this.nativeElement.value;
    }
    set value(val) {
        this.nativeElement.value = val;
    }
    get nativeElement() {
        return this.elementRef.nativeElement;
    }
    get selectionStart() {
        return this.nativeElement.selectionStart;
    }
    get selectionEnd() {
        return this.nativeElement.selectionEnd;
    }
    ngOnInit() {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar = this.promptChar.substring(0, 1);
        }
        this.maskOptions.format = this.mask ? this.mask : 'CCCCCCCCCC';
        this.maskOptions.promptChar = this.promptChar ? this.promptChar : '_';
        this.nativeElement.setAttribute('placeholder', this.placeholder ? this.placeholder : this.maskOptions.format);
    }
    onKeydown(event) {
        const key = event.keyCode || event.charCode;
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
        }
        if (key === KEYS.Ctrl) {
            this.ctrlDown = true;
        }
        if ((this.ctrlDown && key === KEYS.Z) || (this.ctrlDown && key === KEYS.Y)) {
            event.preventDefault();
        }
        this.key = key;
        this.selection = Math.abs(this.selectionEnd - this.selectionStart);
    }
    onKeyup(event) {
        const key = event.keyCode || event.charCode;
        if (key === KEYS.Ctrl) {
            this.ctrlDown = false;
        }
    }
    onPaste(event) {
        this.paste = true;
        this.valOnPaste = this.value;
        this.cursorOnPaste = this.getCursorPosition();
    }
    onInputChanged(event) {
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
            return;
        }
        if (this.paste) {
            this.paste = false;
            const clipboardData = this.value.substring(this.cursorOnPaste, this.getCursorPosition());
            this.value = this.maskHelper.parseValueByMaskUponCopyPaste(this.valOnPaste, this.maskOptions, this.cursorOnPaste, clipboardData, this.selection);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        else {
            const currentCursorPos = this.getCursorPosition();
            this.maskHelper.data = this.key === KEYS.BACKSPACE || this.key === KEYS.DELETE;
            this.value =
                this.selection && this.selection !== 0
                    ? this.maskHelper.parseValueByMaskUponSelection(this.value, this.maskOptions, currentCursorPos - 1, this.selection)
                    : this.maskHelper.parseValueByMask(this.value, this.maskOptions, currentCursorPos - 1);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        const rawVal = this.maskHelper.restoreValueFromMask(this.value, this.maskOptions);
        this.dataValue = this.includeLiterals ? this.value : rawVal;
        this.onChangeCallback(this.dataValue);
        this.valueChange.emit({ rawValue: rawVal, formattedValue: this.value });
    }
    onFocus(value) {
        if (this.focusedValuePipe) {
            if (isIE()) {
                this.stopPropagation = true;
            }
            this.value = this.focusedValuePipe.transform(value);
        }
        else {
            this.value = this.maskHelper.parseValueByMaskOnInit(this.value, this.maskOptions);
        }
    }
    onBlur(value) {
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(value);
        }
        else if (value === this.maskHelper.parseMask(this.maskOptions)) {
            this.value = '';
        }
    }
    getCursorPosition() {
        return this.nativeElement.selectionStart;
    }
    setCursorPosition(start, end = start) {
        this.nativeElement.setSelectionRange(start, end);
    }
    writeValue(value) {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar.substring(0, 1);
        }
        this.value = value ? this.maskHelper.parseValueByMaskOnInit(value, this.maskOptions) : '';
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(this.value);
        }
        this.dataValue = this.includeLiterals ? this.value : value;
        this.onChangeCallback(this.dataValue);
        this.valueChange.emit({ rawValue: value, formattedValue: this.value });
    }
    registerOnChange(fn) {
        this.onChangeCallback = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedCallback = fn;
    }
};
__decorate([
    Input('ngxMask'),
    __metadata("design:type", String)
], MaskDirective.prototype, "mask", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], MaskDirective.prototype, "promptChar", void 0);
__decorate([
    Input(),
    __metadata("design:type", Boolean)
], MaskDirective.prototype, "includeLiterals", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], MaskDirective.prototype, "placeholder", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], MaskDirective.prototype, "displayValuePipe", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], MaskDirective.prototype, "focusedValuePipe", void 0);
__decorate([
    Input(),
    __metadata("design:type", String)
], MaskDirective.prototype, "dataValue", void 0);
__decorate([
    Output(),
    __metadata("design:type", Object)
], MaskDirective.prototype, "valueChange", void 0);
__decorate([
    HostListener('keydown', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MaskDirective.prototype, "onKeydown", null);
__decorate([
    HostListener('keyup', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MaskDirective.prototype, "onKeyup", null);
__decorate([
    HostListener('paste', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MaskDirective.prototype, "onPaste", null);
__decorate([
    HostListener('input', ['$event']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MaskDirective.prototype, "onInputChanged", null);
__decorate([
    HostListener('focus', ['$event.target.value']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MaskDirective.prototype, "onFocus", null);
__decorate([
    HostListener('blur', ['$event.target.value']),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MaskDirective.prototype, "onBlur", null);
MaskDirective = MaskDirective_1 = __decorate([
    Directive({
        providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: MaskDirective_1, multi: true }],
        selector: '[ngxMask]',
    }),
    __metadata("design:paramtypes", [ElementRef])
], MaskDirective);

let MaskModule = class MaskModule {
};
MaskModule = __decorate([
    NgModule({
        declarations: [MaskDirective],
        imports: [CommonModule],
        exports: [MaskDirective],
    })
], MaskModule);

let FilterPipe = class FilterPipe {
    transform(itemList, filterTerm, filterBy) {
        if (!filterBy) {
            return itemList;
        }
        if (filterTerm === '') {
            return itemList;
        }
        filterBy = filterBy.toString();
        return itemList.filter((item) => {
            if (item[filterBy]) {
                return item[filterBy]
                    .toString()
                    .toLowerCase()
                    .includes(filterTerm.toLowerCase());
            }
        });
    }
};
FilterPipe = __decorate([
    Pipe({ name: 'filter' })
], FilterPipe);

/**
 * <ul>
 *   <li *ngFor="let object of myArray | groupBy:'color'"></li>
 * </ul>
 */
let GroupByPipe = class GroupByPipe {
    transform(collection, property) {
        // prevents the application from breaking if the array of objects doesn't exist yet
        if (!collection) {
            return null;
        }
        const groupedCollection = collection.reduce((previous, current) => {
            if (!previous[current[property]]) {
                previous[current[property]] = [current];
            }
            else {
                previous[current[property]].push(current);
            }
            return previous;
        }, {});
        // this will return an array of objects, each object containing a group of objects
        return Object.keys(groupedCollection).map(key => ({
            key,
            value: groupedCollection[key],
        }));
    }
};
GroupByPipe = __decorate([
    Pipe({ name: 'groupBy' })
], GroupByPipe);

let SafeHtmlPipe = class SafeHtmlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(value, args) {
        return this.sanitizer.bypassSecurityTrustHtml(value);
    }
};
SafeHtmlPipe = __decorate([
    Pipe({ name: 'safeHtml' }),
    __metadata("design:paramtypes", [DomSanitizer])
], SafeHtmlPipe);

let HelperModule = class HelperModule {
};
HelperModule = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [FilterPipe, GroupByPipe, SafeHtmlPipe],
        exports: [FilterPipe, GroupByPipe, SafeHtmlPipe],
    })
], HelperModule);

let CharactersPipe = class CharactersPipe {
    transform(value, limit = 40, trail = '…') {
        if (!value) {
            value = '';
        }
        if (limit < 0) {
            limit *= -1;
            return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
        }
        else {
            return value.length > limit ? value.substring(0, limit) + trail : value;
        }
    }
};
CharactersPipe = __decorate([
    Pipe({
        pure: true,
        name: 'characters',
    })
], CharactersPipe);

let WordsPipe = class WordsPipe {
    transform(value, limit = 40, trail = '…') {
        let result = value || '';
        if (value) {
            const words = value.split(/\s+/);
            if (words.length > Math.abs(limit)) {
                if (limit < 0) {
                    limit *= -1;
                    result = trail + words.slice(words.length - limit, words.length).join(' ');
                }
                else {
                    result = words.slice(0, limit).join(' ') + trail;
                }
            }
        }
        return result;
    }
};
WordsPipe = __decorate([
    Pipe({
        pure: true,
        name: 'words',
    })
], WordsPipe);

let TruncateModule = class TruncateModule {
};
TruncateModule = __decorate([
    NgModule({
        imports: [CommonModule],
        declarations: [CharactersPipe, WordsPipe],
        exports: [CharactersPipe, WordsPipe],
    })
], TruncateModule);

var FormatTimeInWordsPipe_1;
const defaultConfig = { addSuffix: true };
/**
 * impure pipe, which in general can lead to bad performance
 * but the backoff function limits the frequency the pipe checks for updates
 * so the performance is close to that of a pure pipe
 * the downside of this is that if you change the value of the input, the pipe might not notice for a while
 * so this pipe is intended for static data
 *
 * expected input is a time (number, string or Date)
 * output is a string expressing distance from that time to now, plus the suffix 'ago'
 * output refreshes at dynamic intervals, with refresh rate slowing down as the input time gets further away from now
 */
let FormatTimeInWordsPipe = FormatTimeInWordsPipe_1 = class FormatTimeInWordsPipe {
    constructor(cdr) {
        this.cdr = cdr;
        this.isDestroyed = false;
        this.async = new AsyncPipe(this.cdr);
    }
    ngOnDestroy() {
        this.isDestroyed = true; // pipe will stop executing after next iteration
    }
    transform(date, options) {
        if (date == null) {
            throw new Error(FormatTimeInWordsPipe_1.NO_ARGS_ERROR);
        }
        // set the pipe to the Observable if not yet done, and return an async pipe
        if (!this.agoExpression) {
            this.agoExpression = this.timeAgo(date, Object.assign({}, defaultConfig, options));
        }
        return this.async.transform(this.agoExpression);
    }
    timeAgo(date, options) {
        let nextBackoff = this.backoff(date);
        return of(true).pipe(
        // will not recheck input until delay completes
        repeatWhen(notify => notify.pipe(delayWhen(() => interval(nextBackoff)))), takeWhile(_ => !this.isDestroyed), map(_ => formatDistance(this.stringToDate(date), new Date(), options)), tap(_ => (nextBackoff = this.backoff(date))));
    }
    backoff(date) {
        const minutesElapsed = Math.abs(differenceInMinutes(new Date(), this.stringToDate(date))); // this will always be positive
        let backoffAmountInSeconds;
        if (minutesElapsed < 2) {
            backoffAmountInSeconds = 5;
        }
        else if (minutesElapsed >= 2 && minutesElapsed < 5) {
            backoffAmountInSeconds = 15;
        }
        else if (minutesElapsed >= 5 && minutesElapsed < 60) {
            backoffAmountInSeconds = 30;
        }
        else if (minutesElapsed >= 60) {
            backoffAmountInSeconds = 300; // 5 minutes
        }
        return backoffAmountInSeconds * 1000; // return an amount of milliseconds
    }
    stringToDate(date) {
        function isString(x) {
            return Object.prototype.toString.call(x) === '[object String]';
        }
        return isString(date) ? parseISO(date) : date;
    }
};
FormatTimeInWordsPipe.NO_ARGS_ERROR = 'formatTimeInWords: missing required arguments';
FormatTimeInWordsPipe = FormatTimeInWordsPipe_1 = __decorate([
    Pipe({ name: 'formatTimeInWords', pure: false }),
    __metadata("design:paramtypes", [ChangeDetectorRef])
], FormatTimeInWordsPipe);

const PIPES = [FormatTimeInWordsPipe];
let DateFnsModule = class DateFnsModule {
};
DateFnsModule = __decorate([
    NgModule({
        declarations: [PIPES],
        imports: [CommonModule],
        exports: [PIPES],
    })
], DateFnsModule);

// export * from './lib/decorators/index';

/**
 * Generated bundle index. Do not edit.
 */

export { ClickOutsideModule, DateFnsModule, HelperModule, InViewportModule, MaskModule, MinModule, NgLetModule, RouterLinkMatchModule, TruncateModule, ViewportService, pluck, untilDestroy, NgLetContext as ɵa, NgLetDirective as ɵb, RouterLinkMatchDirective as ɵc, InViewportDirective as ɵd, destroy$ as ɵdestroy$, ClickOutsideDirective as ɵe, MinValidatorDirective as ɵf, MaskDirective as ɵg, FilterPipe as ɵh, GroupByPipe as ɵi, SafeHtmlPipe as ɵj, CharactersPipe as ɵk, WordsPipe as ɵl, FormatTimeInWordsPipe as ɵm };
//# sourceMappingURL=ngx-starter-libs-ngx-utils.js.map
