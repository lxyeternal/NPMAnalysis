export declare const fontFamily: (name: string) => string;
export declare const remMap: Record<string, string>;
export declare const rem: (value: number) => string;
export declare const rgbaMap: Record<string, string>;
/**
 * Curried function to generate RGBA.
 */
export declare const rgb: (red: number, green: number, blue: number) => (alpha?: number) => string;
//# sourceMappingURL=utils.d.ts.map