import breakpoints from './breakpoints';
import colors from './colors';
import fonts from './fonts';
export { breakpoints, colors, fonts };
declare const _default: {
    breakpoints: {
        readonly xs: 375;
        readonly sm: 550;
        readonly md: 768;
        readonly lg: 1000;
        readonly xl: 1200;
        readonly xxl: 1440;
        readonly mobile: 0;
        readonly tablet: 768;
        readonly desktop: 1000;
        readonly up: (minWidth: number, css?: string | undefined) => string;
        readonly down: (maxWidth: number, css?: string | undefined) => string;
        readonly minWidth: (minWidth: number, css?: string | undefined) => string;
        readonly maxWidth: (maxWidth: number, css?: string | undefined) => string;
    };
    colors: {
        alert: {
            success: {
                success10: (alpha?: number) => string;
                success20: (alpha?: number) => string;
                success30: (alpha?: number) => string;
                success40: (alpha?: number) => string;
                success50: (alpha?: number) => string;
            };
            warning: {
                warning10: (alpha?: number) => string;
                warning20: (alpha?: number) => string;
                warning30: (alpha?: number) => string;
                warning40: (alpha?: number) => string;
                warning50: (alpha?: number) => string;
            };
            critical: {
                critical10: (alpha?: number) => string;
                critical20: (alpha?: number) => string;
                critical30: (alpha?: number) => string;
                critical40: (alpha?: number) => string;
                critical50: (alpha?: number) => string;
            };
            informative: {
                informative10: (alpha?: number) => string;
                informative20: (alpha?: number) => string;
                informative30: (alpha?: number) => string;
                informative40: (alpha?: number) => string;
                informative50: (alpha?: number) => string;
            };
        };
        primary: {
            brand: {
                brand10: (alpha?: number) => string;
                brand20: (alpha?: number) => string;
                brand30: (alpha?: number) => string;
                brand40: (alpha?: number) => string;
                brand50: (alpha?: number) => string;
                brand60: (alpha?: number) => string;
                brand70: (alpha?: number) => string;
                brand80: (alpha?: number) => string;
                brand90: (alpha?: number) => string;
                brand100: (alpha?: number) => string;
            };
            primaryBlue: {
                blue10: (alpha?: number) => string;
                blue20: (alpha?: number) => string;
                blue30: (alpha?: number) => string;
                blue40: (alpha?: number) => string;
                blue50: (alpha?: number) => string;
                blue60: (alpha?: number) => string;
                blue70: (alpha?: number) => string;
                blue80: (alpha?: number) => string;
                blue90: (alpha?: number) => string;
                blue100: (alpha?: number) => string;
            };
        };
        secondary: {
            secondaryDeepGreen: {
                deepGreen10: (alpha?: number) => string;
                deepGreen20: (alpha?: number) => string;
                deepGreen30: (alpha?: number) => string;
                deepGreen40: (alpha?: number) => string;
                deepGreen50: (alpha?: number) => string;
                deepGreen60: (alpha?: number) => string;
                deepGreen70: (alpha?: number) => string;
                deepGreen80: (alpha?: number) => string;
                deepGreen90: (alpha?: number) => string;
                deepGreen100: (alpha?: number) => string;
            };
            secondaryPurple: {
                purple10: (alpha?: number) => string;
                purple20: (alpha?: number) => string;
                purple30: (alpha?: number) => string;
                purple40: (alpha?: number) => string;
                purple50: (alpha?: number) => string;
                purple60: (alpha?: number) => string;
                purple70: (alpha?: number) => string;
                purple80: (alpha?: number) => string;
                purple90: (alpha?: number) => string;
                purple100: (alpha?: number) => string;
                visitedLinkPurple: (alpha?: number) => string;
            };
            secondaryGold: {
                gold10: (alpha?: number) => string;
                gold20: (alpha?: number) => string;
                gold30: (alpha?: number) => string;
                gold40: (alpha?: number) => string;
                gold50: (alpha?: number) => string;
                gold60: (alpha?: number) => string;
                gold70: (alpha?: number) => string;
                gold80: (alpha?: number) => string;
                gold90: (alpha?: number) => string;
                gold100: (alpha?: number) => string;
            };
            secondaryBlue: {
                blue10: (alpha?: number) => string;
                blue20: (alpha?: number) => string;
                blue30: (alpha?: number) => string;
                blue40: (alpha?: number) => string;
                blue50: (alpha?: number) => string;
                blue60: (alpha?: number) => string;
                blue70: (alpha?: number) => string;
                blue80: (alpha?: number) => string;
                blue90: (alpha?: number) => string;
                blue100: (alpha?: number) => string;
            };
            secondaryPeach: {
                peach10: (alpha?: number) => string;
                peach20: (alpha?: number) => string;
                peach30: (alpha?: number) => string;
                peach40: (alpha?: number) => string;
                peach50: (alpha?: number) => string;
                peach60: (alpha?: number) => string;
                peach70: (alpha?: number) => string;
                peach80: (alpha?: number) => string;
                peach90: (alpha?: number) => string;
                peach100: (alpha?: number) => string;
            };
            secondaryPink: {
                pink10: (alpha?: number) => string;
                pink20: (alpha?: number) => string;
                pink30: (alpha?: number) => string;
                pink40: (alpha?: number) => string;
                pink50: (alpha?: number) => string;
                pink60: (alpha?: number) => string;
                pink70: (alpha?: number) => string;
                pink80: (alpha?: number) => string;
                pink90: (alpha?: number) => string;
                pink100: (alpha?: number) => string;
            };
            secondaryLimeGreen: {
                limeGreen10: (alpha?: number) => string;
                limeGreen20: (alpha?: number) => string;
                limeGreen30: (alpha?: number) => string;
                limeGreen40: (alpha?: number) => string;
                limeGreen50: (alpha?: number) => string;
                limeGreen60: (alpha?: number) => string;
                limeGreen70: (alpha?: number) => string;
                limeGreen80: (alpha?: number) => string;
                limeGreen90: (alpha?: number) => string;
                limeGreen100: (alpha?: number) => string;
            };
            secondaryMintGreen: {
                mintGreen10: (alpha?: number) => string;
                mintGreen20: (alpha?: number) => string;
                mintGreen30: (alpha?: number) => string;
                mintGreen40: (alpha?: number) => string;
                mintGreen50: (alpha?: number) => string;
                mintGreen60: (alpha?: number) => string;
                mintGreen70: (alpha?: number) => string;
                mintGreen80: (alpha?: number) => string;
                mintGreen90: (alpha?: number) => string;
                mintGreen100: (alpha?: number) => string;
            };
            secondaryNeutralGrey: {
                grey10: (alpha?: number) => string;
                grey20: (alpha?: number) => string;
                grey30: (alpha?: number) => string;
                grey40: (alpha?: number) => string;
                grey50: (alpha?: number) => string;
                grey60: (alpha?: number) => string;
                grey70: (alpha?: number) => string;
                grey80: (alpha?: number) => string;
                grey90: (alpha?: number) => string;
                grey100: (alpha?: number) => string;
            };
        };
        token: {
            brand: string;
            shadeBlack: string;
            shadeWhite: string;
            surfacePrimary: string;
            surfaceSecondary: string;
            surfaceStrong: string;
            surfaceContrast: string;
            surfaceOverlay: string;
            subSurfaceSuccess: string;
            subSurfaceInformative: string;
            subSurfaceCritical: string;
            subSurfaceWarning: string;
            subSurfaceDull: (alpha?: number) => string;
            borderMinimal: string;
            borderSubtle: string;
            borderModerate: string;
            borderBold: string;
            borderContrast: string;
            borderSuccess: string;
            borderInformative: string;
            borderCritical: string;
            borderWarning: string;
        };
        brand: string;
        shadeBlack: string;
        shadeWhite: string;
        surfacePrimary: string;
        surfaceSecondary: string;
        surfaceStrong: string;
        surfaceContrast: string;
        surfaceOverlay: string;
        subSurfaceSuccess: string;
        subSurfaceInformative: string;
        subSurfaceCritical: string;
        subSurfaceWarning: string;
        subSurfaceDull: (alpha?: number) => string;
        borderMinimal: string;
        borderSubtle: string;
        borderModerate: string;
        borderBold: string;
        borderContrast: string;
        borderSuccess: string;
        borderInformative: string;
        borderCritical: string;
        borderWarning: string;
        pink10: (alpha?: number) => string;
        pink20: (alpha?: number) => string;
        pink30: (alpha?: number) => string;
        pink40: (alpha?: number) => string;
        pink50: (alpha?: number) => string;
        pink60: (alpha?: number) => string;
        pink70: (alpha?: number) => string;
        pink80: (alpha?: number) => string;
        pink90: (alpha?: number) => string;
        pink100: (alpha?: number) => string;
        peach10: (alpha?: number) => string;
        peach20: (alpha?: number) => string;
        peach30: (alpha?: number) => string;
        peach40: (alpha?: number) => string;
        peach50: (alpha?: number) => string;
        peach60: (alpha?: number) => string;
        peach70: (alpha?: number) => string;
        peach80: (alpha?: number) => string;
        peach90: (alpha?: number) => string;
        peach100: (alpha?: number) => string;
        grey10: (alpha?: number) => string;
        grey20: (alpha?: number) => string;
        grey30: (alpha?: number) => string;
        grey40: (alpha?: number) => string;
        grey50: (alpha?: number) => string;
        grey60: (alpha?: number) => string;
        grey70: (alpha?: number) => string;
        grey80: (alpha?: number) => string;
        grey90: (alpha?: number) => string;
        grey100: (alpha?: number) => string;
        mintGreen10: (alpha?: number) => string;
        mintGreen20: (alpha?: number) => string;
        mintGreen30: (alpha?: number) => string;
        mintGreen40: (alpha?: number) => string;
        mintGreen50: (alpha?: number) => string;
        mintGreen60: (alpha?: number) => string;
        mintGreen70: (alpha?: number) => string;
        mintGreen80: (alpha?: number) => string;
        mintGreen90: (alpha?: number) => string;
        mintGreen100: (alpha?: number) => string;
        limeGreen10: (alpha?: number) => string;
        limeGreen20: (alpha?: number) => string;
        limeGreen30: (alpha?: number) => string;
        limeGreen40: (alpha?: number) => string;
        limeGreen50: (alpha?: number) => string;
        limeGreen60: (alpha?: number) => string;
        limeGreen70: (alpha?: number) => string;
        limeGreen80: (alpha?: number) => string;
        limeGreen90: (alpha?: number) => string;
        limeGreen100: (alpha?: number) => string;
        gold10: (alpha?: number) => string;
        gold20: (alpha?: number) => string;
        gold30: (alpha?: number) => string;
        gold40: (alpha?: number) => string;
        gold50: (alpha?: number) => string;
        gold60: (alpha?: number) => string;
        gold70: (alpha?: number) => string;
        gold80: (alpha?: number) => string;
        gold90: (alpha?: number) => string;
        gold100: (alpha?: number) => string;
        deepGreen10: (alpha?: number) => string;
        deepGreen20: (alpha?: number) => string;
        deepGreen30: (alpha?: number) => string;
        deepGreen40: (alpha?: number) => string;
        deepGreen50: (alpha?: number) => string;
        deepGreen60: (alpha?: number) => string;
        deepGreen70: (alpha?: number) => string;
        deepGreen80: (alpha?: number) => string;
        deepGreen90: (alpha?: number) => string;
        deepGreen100: (alpha?: number) => string;
        blue10: (alpha?: number) => string;
        blue20: (alpha?: number) => string;
        blue30: (alpha?: number) => string;
        blue40: (alpha?: number) => string;
        blue50: (alpha?: number) => string;
        blue60: (alpha?: number) => string;
        blue70: (alpha?: number) => string;
        blue80: (alpha?: number) => string;
        blue90: (alpha?: number) => string;
        blue100: (alpha?: number) => string;
        brand10: (alpha?: number) => string;
        brand20: (alpha?: number) => string;
        brand30: (alpha?: number) => string;
        brand40: (alpha?: number) => string;
        brand50: (alpha?: number) => string;
        brand60: (alpha?: number) => string;
        brand70: (alpha?: number) => string;
        brand80: (alpha?: number) => string;
        brand90: (alpha?: number) => string;
        brand100: (alpha?: number) => string;
        warning10: (alpha?: number) => string;
        warning20: (alpha?: number) => string;
        warning30: (alpha?: number) => string;
        warning40: (alpha?: number) => string;
        warning50: (alpha?: number) => string;
        success10: (alpha?: number) => string;
        success20: (alpha?: number) => string;
        success30: (alpha?: number) => string;
        success40: (alpha?: number) => string;
        success50: (alpha?: number) => string;
        informative10: (alpha?: number) => string;
        informative20: (alpha?: number) => string;
        informative30: (alpha?: number) => string;
        informative40: (alpha?: number) => string;
        informative50: (alpha?: number) => string;
        critical10: (alpha?: number) => string;
        critical20: (alpha?: number) => string;
        critical30: (alpha?: number) => string;
        critical40: (alpha?: number) => string;
        critical50: (alpha?: number) => string;
    };
    fonts: {
        primary: {
            button: {
                readonly xlarge: {
                    readonly letterSpacing: string;
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly large: {
                    readonly letterSpacing: string;
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly medium: {
                    readonly letterSpacing: string;
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly small: {
                    readonly letterSpacing: string;
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
            };
            caption: {
                readonly caption1: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly medium: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
            };
            family: string;
            paragraph: {
                p1: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                xlarge: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                p2: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                large: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                p3: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                medium: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                p4: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                small: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
            };
            weight: {
                readonly normal: 400;
                readonly bold: 700;
            };
        };
        secondary: {
            display: {
                readonly display1: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly display2: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
            };
            family: string;
            heading: {
                readonly h1: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly h2: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly h3: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly h4: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly h5: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
                readonly h6: {
                    readonly fontSize: string;
                    readonly lineHeight: string;
                };
            };
            weight: {
                readonly bold: 700;
                readonly extraBold: 800;
                readonly black: 900;
            };
        };
    };
};
export default _default;
//# sourceMappingURL=index.d.ts.map