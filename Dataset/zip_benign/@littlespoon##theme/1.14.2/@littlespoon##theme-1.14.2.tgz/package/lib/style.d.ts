import type { StyledProps } from 'styled-components';
export interface StyleProps {
    /**
     * CSS properties.
     */
    sx?: StyledProps<any>;
}
/**
 * Gets style.
 */
export declare function getStyle({ sx }: StyleProps): Record<string, string | number>;
//# sourceMappingURL=style.d.ts.map