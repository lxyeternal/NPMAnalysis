/**
 * Buttons
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/55397a}
 */
export declare const button: {
    readonly xlarge: {
        readonly letterSpacing: string;
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly large: {
        readonly letterSpacing: string;
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly medium: {
        readonly letterSpacing: string;
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly small: {
        readonly letterSpacing: string;
        readonly fontSize: string;
        readonly lineHeight: string;
    };
};
/**
 * Caption 1
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/4725bd}
 */
export declare const caption1: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
export declare const caption: {
    readonly caption1: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly medium: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
};
/**
 * Font-family
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/626dbf}
 */
export declare const family: string;
/**
 * Paragraph
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/294b11}
 */
export declare const paragraph: {
    p1: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    xlarge: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    p2: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    large: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    p3: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    medium: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    p4: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    small: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
};
/**
 * Font-weight
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/34024f}
 */
export declare const weight: {
    readonly normal: 400;
    readonly bold: 700;
};
declare const _default: {
    button: {
        readonly xlarge: {
            readonly letterSpacing: string;
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly large: {
            readonly letterSpacing: string;
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly medium: {
            readonly letterSpacing: string;
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly small: {
            readonly letterSpacing: string;
            readonly fontSize: string;
            readonly lineHeight: string;
        };
    };
    caption: {
        readonly caption1: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly medium: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
    };
    family: string;
    paragraph: {
        p1: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        xlarge: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        p2: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        large: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        p3: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        medium: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        p4: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        small: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
    };
    weight: {
        readonly normal: 400;
        readonly bold: 700;
    };
};
export default _default;
//# sourceMappingURL=primary.d.ts.map