/**
 * Display 1
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/158618}
 */
export declare const display1: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
/**
 * Display 2
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/615eab}
 */
export declare const display2: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
export declare const display: {
    readonly display1: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly display2: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
};
/**
 * Font-family
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/626dbf}
 */
export declare const family: string;
/**
 * Headings
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/440937}
 */
export declare const heading: {
    readonly h1: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly h2: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly h3: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly h4: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly h5: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    readonly h6: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
};
/**
 * Font-weight
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/34024f}
 */
export declare const weight: {
    readonly bold: 700;
    readonly extraBold: 800;
    readonly black: 900;
};
declare const _default: {
    display: {
        readonly display1: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly display2: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
    };
    family: string;
    heading: {
        readonly h1: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly h2: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly h3: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly h4: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly h5: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
        readonly h6: {
            readonly fontSize: string;
            readonly lineHeight: string;
        };
    };
    weight: {
        readonly bold: 700;
        readonly extraBold: 800;
        readonly black: 900;
    };
};
export default _default;
//# sourceMappingURL=secondary.d.ts.map