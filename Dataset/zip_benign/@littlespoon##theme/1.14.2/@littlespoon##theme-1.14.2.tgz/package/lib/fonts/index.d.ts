/**
 * Fonts
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/b/655ccf}
 */
import primary from './primary';
import secondary from './secondary';
export { primary, secondary };
declare const _default: {
    primary: {
        button: {
            readonly xlarge: {
                readonly letterSpacing: string;
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly large: {
                readonly letterSpacing: string;
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly medium: {
                readonly letterSpacing: string;
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly small: {
                readonly letterSpacing: string;
                readonly fontSize: string;
                readonly lineHeight: string;
            };
        };
        caption: {
            readonly caption1: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly medium: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
        };
        family: string;
        paragraph: {
            p1: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            xlarge: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            p2: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            large: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            p3: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            medium: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            p4: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            small: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
        };
        weight: {
            readonly normal: 400;
            readonly bold: 700;
        };
    };
    secondary: {
        display: {
            readonly display1: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly display2: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
        };
        family: string;
        heading: {
            readonly h1: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly h2: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly h3: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly h4: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly h5: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
            readonly h6: {
                readonly fontSize: string;
                readonly lineHeight: string;
            };
        };
        weight: {
            readonly bold: 700;
            readonly extraBold: 800;
            readonly black: 900;
        };
    };
};
export default _default;
//# sourceMappingURL=index.d.ts.map