/**
 * Paragraph 1
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/9540b4}
 */
export declare const p1: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
export declare const xlarge: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
/**
 * Paragraph 2
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/41a82b}
 */
export declare const p2: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
export declare const large: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
/**
 * Paragraph 3
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/48491c}
 */
export declare const p3: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
export declare const medium: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
/**
 * Paragraph 4
 *
 * {@link https://zeroheight.com/3ddd0f892/p/211297-typography/t/7711fe}
 */
export declare const p4: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
export declare const small: {
    readonly fontSize: string;
    readonly lineHeight: string;
};
declare const _default: {
    p1: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    xlarge: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    p2: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    large: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    p3: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    medium: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    p4: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
    small: {
        readonly fontSize: string;
        readonly lineHeight: string;
    };
};
export default _default;
//# sourceMappingURL=paragraph.d.ts.map