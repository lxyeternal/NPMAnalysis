/**
 * This enum is somehow based on https://mui.com/material-ui/customization/z-index
 */
declare enum zIndex {
    backdrop = 1100,
    drawer = 1200
}
export default zIndex;
//# sourceMappingURL=z-index.d.ts.map