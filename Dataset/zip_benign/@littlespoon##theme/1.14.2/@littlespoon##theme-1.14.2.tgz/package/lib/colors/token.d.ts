/**
 * Brand
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/619a9a}
 */
export declare const brand: string;
/**
 * Shade
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/b/036155/t/492c47}
 */
export declare const shadeBlack = "#000000";
export declare const shadeWhite = "#FFFFFF";
/**
 * Surface
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/13b601}
 */
export declare const surfacePrimary = "#FFFFFF";
export declare const surfaceSecondary: string;
export declare const surfaceStrong: string;
export declare const surfaceContrast: string;
export declare const surfaceOverlay: string;
export declare const surfaceOverlay60: string;
/**
 * Sub-surface
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/51c262}
 */
export declare const subSurfaceSuccess: string;
export declare const subSurfaceInformative: string;
export declare const subSurfaceCritical: string;
export declare const subSurfaceWarning: string;
export declare const subSurfaceDull: (alpha?: number) => string;
/**
 * Border
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/115206}
 */
export declare const borderMinimal: string;
export declare const borderSubtle: string;
export declare const borderModerate: string;
export declare const borderBold: string;
export declare const borderContrast: string;
export declare const borderSuccess: string;
export declare const borderInformative: string;
export declare const borderCritical: string;
export declare const borderWarning: string;
declare const _default: {
    brand: string;
    shadeBlack: string;
    shadeWhite: string;
    surfacePrimary: string;
    surfaceSecondary: string;
    surfaceStrong: string;
    surfaceContrast: string;
    surfaceOverlay: string;
    subSurfaceSuccess: string;
    subSurfaceInformative: string;
    subSurfaceCritical: string;
    subSurfaceWarning: string;
    subSurfaceDull: (alpha?: number) => string;
    borderMinimal: string;
    borderSubtle: string;
    borderModerate: string;
    borderBold: string;
    borderContrast: string;
    borderSuccess: string;
    borderInformative: string;
    borderCritical: string;
    borderWarning: string;
};
export default _default;
//# sourceMappingURL=token.d.ts.map