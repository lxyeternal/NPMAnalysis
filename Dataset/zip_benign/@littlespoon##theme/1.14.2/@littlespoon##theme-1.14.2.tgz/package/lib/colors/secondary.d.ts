/**
 * Secondary Deep Green
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/06560c}
 */
export declare const deepGreen10: (alpha?: number) => string;
export declare const deepGreen20: (alpha?: number) => string;
export declare const deepGreen30: (alpha?: number) => string;
export declare const deepGreen40: (alpha?: number) => string;
export declare const deepGreen50: (alpha?: number) => string;
export declare const deepGreen60: (alpha?: number) => string;
export declare const deepGreen70: (alpha?: number) => string;
export declare const deepGreen80: (alpha?: number) => string;
export declare const deepGreen90: (alpha?: number) => string;
export declare const deepGreen100: (alpha?: number) => string;
export declare const secondaryDeepGreen: {
    deepGreen10: (alpha?: number) => string;
    deepGreen20: (alpha?: number) => string;
    deepGreen30: (alpha?: number) => string;
    deepGreen40: (alpha?: number) => string;
    deepGreen50: (alpha?: number) => string;
    deepGreen60: (alpha?: number) => string;
    deepGreen70: (alpha?: number) => string;
    deepGreen80: (alpha?: number) => string;
    deepGreen90: (alpha?: number) => string;
    deepGreen100: (alpha?: number) => string;
};
/**
 * Secondary Purple
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/02ea9b}
 */
export declare const purple10: (alpha?: number) => string;
export declare const purple20: (alpha?: number) => string;
export declare const purple30: (alpha?: number) => string;
export declare const purple40: (alpha?: number) => string;
export declare const purple50: (alpha?: number) => string;
export declare const purple60: (alpha?: number) => string;
export declare const purple70: (alpha?: number) => string;
export declare const purple80: (alpha?: number) => string;
export declare const purple90: (alpha?: number) => string;
export declare const purple100: (alpha?: number) => string;
export declare const visitedLinkPurple: (alpha?: number) => string;
export declare const secondaryPurple: {
    purple10: (alpha?: number) => string;
    purple20: (alpha?: number) => string;
    purple30: (alpha?: number) => string;
    purple40: (alpha?: number) => string;
    purple50: (alpha?: number) => string;
    purple60: (alpha?: number) => string;
    purple70: (alpha?: number) => string;
    purple80: (alpha?: number) => string;
    purple90: (alpha?: number) => string;
    purple100: (alpha?: number) => string;
    visitedLinkPurple: (alpha?: number) => string;
};
/**
 * Secondary Gold
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/65e259}
 */
export declare const gold10: (alpha?: number) => string;
export declare const gold20: (alpha?: number) => string;
export declare const gold30: (alpha?: number) => string;
export declare const gold40: (alpha?: number) => string;
export declare const gold50: (alpha?: number) => string;
export declare const gold60: (alpha?: number) => string;
export declare const gold70: (alpha?: number) => string;
export declare const gold80: (alpha?: number) => string;
export declare const gold90: (alpha?: number) => string;
export declare const gold100: (alpha?: number) => string;
export declare const secondaryGold: {
    gold10: (alpha?: number) => string;
    gold20: (alpha?: number) => string;
    gold30: (alpha?: number) => string;
    gold40: (alpha?: number) => string;
    gold50: (alpha?: number) => string;
    gold60: (alpha?: number) => string;
    gold70: (alpha?: number) => string;
    gold80: (alpha?: number) => string;
    gold90: (alpha?: number) => string;
    gold100: (alpha?: number) => string;
};
/**
 * Secondary Blue
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/41aa9a}
 */
export declare const blue10: (alpha?: number) => string;
export declare const blue20: (alpha?: number) => string;
export declare const blue30: (alpha?: number) => string;
export declare const blue40: (alpha?: number) => string;
export declare const blue50: (alpha?: number) => string;
export declare const blue60: (alpha?: number) => string;
export declare const blue70: (alpha?: number) => string;
export declare const blue80: (alpha?: number) => string;
export declare const blue90: (alpha?: number) => string;
export declare const blue100: (alpha?: number) => string;
export declare const secondaryBlue: {
    blue10: (alpha?: number) => string;
    blue20: (alpha?: number) => string;
    blue30: (alpha?: number) => string;
    blue40: (alpha?: number) => string;
    blue50: (alpha?: number) => string;
    blue60: (alpha?: number) => string;
    blue70: (alpha?: number) => string;
    blue80: (alpha?: number) => string;
    blue90: (alpha?: number) => string;
    blue100: (alpha?: number) => string;
};
/**
 * Secondary Peach
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/98887f}
 */
export declare const peach10: (alpha?: number) => string;
export declare const peach20: (alpha?: number) => string;
export declare const peach30: (alpha?: number) => string;
export declare const peach40: (alpha?: number) => string;
export declare const peach50: (alpha?: number) => string;
export declare const peach60: (alpha?: number) => string;
export declare const peach70: (alpha?: number) => string;
export declare const peach80: (alpha?: number) => string;
export declare const peach90: (alpha?: number) => string;
export declare const peach100: (alpha?: number) => string;
export declare const secondaryPeach: {
    peach10: (alpha?: number) => string;
    peach20: (alpha?: number) => string;
    peach30: (alpha?: number) => string;
    peach40: (alpha?: number) => string;
    peach50: (alpha?: number) => string;
    peach60: (alpha?: number) => string;
    peach70: (alpha?: number) => string;
    peach80: (alpha?: number) => string;
    peach90: (alpha?: number) => string;
    peach100: (alpha?: number) => string;
};
/**
 * Secondary Pink
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/80226f}
 */
export declare const pink10: (alpha?: number) => string;
export declare const pink20: (alpha?: number) => string;
export declare const pink30: (alpha?: number) => string;
export declare const pink40: (alpha?: number) => string;
export declare const pink50: (alpha?: number) => string;
export declare const pink60: (alpha?: number) => string;
export declare const pink70: (alpha?: number) => string;
export declare const pink80: (alpha?: number) => string;
export declare const pink90: (alpha?: number) => string;
export declare const pink100: (alpha?: number) => string;
export declare const secondaryPink: {
    pink10: (alpha?: number) => string;
    pink20: (alpha?: number) => string;
    pink30: (alpha?: number) => string;
    pink40: (alpha?: number) => string;
    pink50: (alpha?: number) => string;
    pink60: (alpha?: number) => string;
    pink70: (alpha?: number) => string;
    pink80: (alpha?: number) => string;
    pink90: (alpha?: number) => string;
    pink100: (alpha?: number) => string;
};
/**
 * Secondary Lime Green
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/22380a}
 */
export declare const limeGreen10: (alpha?: number) => string;
export declare const limeGreen20: (alpha?: number) => string;
export declare const limeGreen30: (alpha?: number) => string;
export declare const limeGreen40: (alpha?: number) => string;
export declare const limeGreen50: (alpha?: number) => string;
export declare const limeGreen60: (alpha?: number) => string;
export declare const limeGreen70: (alpha?: number) => string;
export declare const limeGreen80: (alpha?: number) => string;
export declare const limeGreen90: (alpha?: number) => string;
export declare const limeGreen100: (alpha?: number) => string;
export declare const secondaryLimeGreen: {
    limeGreen10: (alpha?: number) => string;
    limeGreen20: (alpha?: number) => string;
    limeGreen30: (alpha?: number) => string;
    limeGreen40: (alpha?: number) => string;
    limeGreen50: (alpha?: number) => string;
    limeGreen60: (alpha?: number) => string;
    limeGreen70: (alpha?: number) => string;
    limeGreen80: (alpha?: number) => string;
    limeGreen90: (alpha?: number) => string;
    limeGreen100: (alpha?: number) => string;
};
/**
 * Secondary Mint Green
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/565cf7}
 */
export declare const mintGreen10: (alpha?: number) => string;
export declare const mintGreen20: (alpha?: number) => string;
export declare const mintGreen30: (alpha?: number) => string;
export declare const mintGreen40: (alpha?: number) => string;
export declare const mintGreen50: (alpha?: number) => string;
export declare const mintGreen60: (alpha?: number) => string;
export declare const mintGreen70: (alpha?: number) => string;
export declare const mintGreen80: (alpha?: number) => string;
export declare const mintGreen90: (alpha?: number) => string;
export declare const mintGreen100: (alpha?: number) => string;
export declare const secondaryMintGreen: {
    mintGreen10: (alpha?: number) => string;
    mintGreen20: (alpha?: number) => string;
    mintGreen30: (alpha?: number) => string;
    mintGreen40: (alpha?: number) => string;
    mintGreen50: (alpha?: number) => string;
    mintGreen60: (alpha?: number) => string;
    mintGreen70: (alpha?: number) => string;
    mintGreen80: (alpha?: number) => string;
    mintGreen90: (alpha?: number) => string;
    mintGreen100: (alpha?: number) => string;
};
/**
 * Neutral Grey
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/69d367}
 */
export declare const grey10: (alpha?: number) => string;
export declare const grey20: (alpha?: number) => string;
export declare const grey30: (alpha?: number) => string;
export declare const grey40: (alpha?: number) => string;
export declare const grey50: (alpha?: number) => string;
export declare const grey60: (alpha?: number) => string;
export declare const grey70: (alpha?: number) => string;
export declare const grey80: (alpha?: number) => string;
export declare const grey90: (alpha?: number) => string;
export declare const grey100: (alpha?: number) => string;
export declare const secondaryNeutralGrey: {
    grey10: (alpha?: number) => string;
    grey20: (alpha?: number) => string;
    grey30: (alpha?: number) => string;
    grey40: (alpha?: number) => string;
    grey50: (alpha?: number) => string;
    grey60: (alpha?: number) => string;
    grey70: (alpha?: number) => string;
    grey80: (alpha?: number) => string;
    grey90: (alpha?: number) => string;
    grey100: (alpha?: number) => string;
};
declare const _default: {
    secondaryDeepGreen: {
        deepGreen10: (alpha?: number) => string;
        deepGreen20: (alpha?: number) => string;
        deepGreen30: (alpha?: number) => string;
        deepGreen40: (alpha?: number) => string;
        deepGreen50: (alpha?: number) => string;
        deepGreen60: (alpha?: number) => string;
        deepGreen70: (alpha?: number) => string;
        deepGreen80: (alpha?: number) => string;
        deepGreen90: (alpha?: number) => string;
        deepGreen100: (alpha?: number) => string;
    };
    secondaryPurple: {
        purple10: (alpha?: number) => string;
        purple20: (alpha?: number) => string;
        purple30: (alpha?: number) => string;
        purple40: (alpha?: number) => string;
        purple50: (alpha?: number) => string;
        purple60: (alpha?: number) => string;
        purple70: (alpha?: number) => string;
        purple80: (alpha?: number) => string;
        purple90: (alpha?: number) => string;
        purple100: (alpha?: number) => string;
        visitedLinkPurple: (alpha?: number) => string;
    };
    secondaryGold: {
        gold10: (alpha?: number) => string;
        gold20: (alpha?: number) => string;
        gold30: (alpha?: number) => string;
        gold40: (alpha?: number) => string;
        gold50: (alpha?: number) => string;
        gold60: (alpha?: number) => string;
        gold70: (alpha?: number) => string;
        gold80: (alpha?: number) => string;
        gold90: (alpha?: number) => string;
        gold100: (alpha?: number) => string;
    };
    secondaryBlue: {
        blue10: (alpha?: number) => string;
        blue20: (alpha?: number) => string;
        blue30: (alpha?: number) => string;
        blue40: (alpha?: number) => string;
        blue50: (alpha?: number) => string;
        blue60: (alpha?: number) => string;
        blue70: (alpha?: number) => string;
        blue80: (alpha?: number) => string;
        blue90: (alpha?: number) => string;
        blue100: (alpha?: number) => string;
    };
    secondaryPeach: {
        peach10: (alpha?: number) => string;
        peach20: (alpha?: number) => string;
        peach30: (alpha?: number) => string;
        peach40: (alpha?: number) => string;
        peach50: (alpha?: number) => string;
        peach60: (alpha?: number) => string;
        peach70: (alpha?: number) => string;
        peach80: (alpha?: number) => string;
        peach90: (alpha?: number) => string;
        peach100: (alpha?: number) => string;
    };
    secondaryPink: {
        pink10: (alpha?: number) => string;
        pink20: (alpha?: number) => string;
        pink30: (alpha?: number) => string;
        pink40: (alpha?: number) => string;
        pink50: (alpha?: number) => string;
        pink60: (alpha?: number) => string;
        pink70: (alpha?: number) => string;
        pink80: (alpha?: number) => string;
        pink90: (alpha?: number) => string;
        pink100: (alpha?: number) => string;
    };
    secondaryLimeGreen: {
        limeGreen10: (alpha?: number) => string;
        limeGreen20: (alpha?: number) => string;
        limeGreen30: (alpha?: number) => string;
        limeGreen40: (alpha?: number) => string;
        limeGreen50: (alpha?: number) => string;
        limeGreen60: (alpha?: number) => string;
        limeGreen70: (alpha?: number) => string;
        limeGreen80: (alpha?: number) => string;
        limeGreen90: (alpha?: number) => string;
        limeGreen100: (alpha?: number) => string;
    };
    secondaryMintGreen: {
        mintGreen10: (alpha?: number) => string;
        mintGreen20: (alpha?: number) => string;
        mintGreen30: (alpha?: number) => string;
        mintGreen40: (alpha?: number) => string;
        mintGreen50: (alpha?: number) => string;
        mintGreen60: (alpha?: number) => string;
        mintGreen70: (alpha?: number) => string;
        mintGreen80: (alpha?: number) => string;
        mintGreen90: (alpha?: number) => string;
        mintGreen100: (alpha?: number) => string;
    };
    secondaryNeutralGrey: {
        grey10: (alpha?: number) => string;
        grey20: (alpha?: number) => string;
        grey30: (alpha?: number) => string;
        grey40: (alpha?: number) => string;
        grey50: (alpha?: number) => string;
        grey60: (alpha?: number) => string;
        grey70: (alpha?: number) => string;
        grey80: (alpha?: number) => string;
        grey90: (alpha?: number) => string;
        grey100: (alpha?: number) => string;
    };
};
export default _default;
//# sourceMappingURL=secondary.d.ts.map