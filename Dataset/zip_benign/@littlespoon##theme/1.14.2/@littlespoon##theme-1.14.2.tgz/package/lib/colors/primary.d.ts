/**
 * Brand Blue
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/12d188}
 */
export declare const brand10: (alpha?: number) => string;
export declare const brand20: (alpha?: number) => string;
export declare const brand30: (alpha?: number) => string;
export declare const brand40: (alpha?: number) => string;
export declare const brand50: (alpha?: number) => string;
export declare const brand60: (alpha?: number) => string;
export declare const brand70: (alpha?: number) => string;
export declare const brand80: (alpha?: number) => string;
export declare const brand90: (alpha?: number) => string;
export declare const brand100: (alpha?: number) => string;
export declare const brand: {
    brand10: (alpha?: number) => string;
    brand20: (alpha?: number) => string;
    brand30: (alpha?: number) => string;
    brand40: (alpha?: number) => string;
    brand50: (alpha?: number) => string;
    brand60: (alpha?: number) => string;
    brand70: (alpha?: number) => string;
    brand80: (alpha?: number) => string;
    brand90: (alpha?: number) => string;
    brand100: (alpha?: number) => string;
};
/**
 * @deprecated Use brand instead.
 */
export declare const blue10: (alpha?: number) => string;
export declare const blue20: (alpha?: number) => string;
export declare const blue30: (alpha?: number) => string;
export declare const blue40: (alpha?: number) => string;
export declare const blue50: (alpha?: number) => string;
export declare const blue60: (alpha?: number) => string;
export declare const blue70: (alpha?: number) => string;
export declare const blue80: (alpha?: number) => string;
export declare const blue90: (alpha?: number) => string;
export declare const blue100: (alpha?: number) => string;
/**
 * @deprecated Use brand instead.
 */
export declare const primaryBlue: {
    blue10: (alpha?: number) => string;
    blue20: (alpha?: number) => string;
    blue30: (alpha?: number) => string;
    blue40: (alpha?: number) => string;
    blue50: (alpha?: number) => string;
    blue60: (alpha?: number) => string;
    blue70: (alpha?: number) => string;
    blue80: (alpha?: number) => string;
    blue90: (alpha?: number) => string;
    blue100: (alpha?: number) => string;
};
declare const _default: {
    brand: {
        brand10: (alpha?: number) => string;
        brand20: (alpha?: number) => string;
        brand30: (alpha?: number) => string;
        brand40: (alpha?: number) => string;
        brand50: (alpha?: number) => string;
        brand60: (alpha?: number) => string;
        brand70: (alpha?: number) => string;
        brand80: (alpha?: number) => string;
        brand90: (alpha?: number) => string;
        brand100: (alpha?: number) => string;
    };
    primaryBlue: {
        blue10: (alpha?: number) => string;
        blue20: (alpha?: number) => string;
        blue30: (alpha?: number) => string;
        blue40: (alpha?: number) => string;
        blue50: (alpha?: number) => string;
        blue60: (alpha?: number) => string;
        blue70: (alpha?: number) => string;
        blue80: (alpha?: number) => string;
        blue90: (alpha?: number) => string;
        blue100: (alpha?: number) => string;
    };
};
export default _default;
//# sourceMappingURL=primary.d.ts.map