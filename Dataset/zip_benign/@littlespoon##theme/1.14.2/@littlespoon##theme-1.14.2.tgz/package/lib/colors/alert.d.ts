/**
 * Success
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/193927}
 */
export declare const success10: (alpha?: number) => string;
export declare const success20: (alpha?: number) => string;
export declare const success30: (alpha?: number) => string;
export declare const success40: (alpha?: number) => string;
export declare const success50: (alpha?: number) => string;
export declare const success: {
    success10: (alpha?: number) => string;
    success20: (alpha?: number) => string;
    success30: (alpha?: number) => string;
    success40: (alpha?: number) => string;
    success50: (alpha?: number) => string;
};
/**
 * Warning
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/76323f}
 */
export declare const warning10: (alpha?: number) => string;
export declare const warning20: (alpha?: number) => string;
export declare const warning30: (alpha?: number) => string;
export declare const warning40: (alpha?: number) => string;
export declare const warning50: (alpha?: number) => string;
export declare const warning: {
    warning10: (alpha?: number) => string;
    warning20: (alpha?: number) => string;
    warning30: (alpha?: number) => string;
    warning40: (alpha?: number) => string;
    warning50: (alpha?: number) => string;
};
/**
 * Critical
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/07d378}
 */
export declare const critical10: (alpha?: number) => string;
export declare const critical20: (alpha?: number) => string;
export declare const critical30: (alpha?: number) => string;
export declare const critical40: (alpha?: number) => string;
export declare const critical50: (alpha?: number) => string;
export declare const critical: {
    critical10: (alpha?: number) => string;
    critical20: (alpha?: number) => string;
    critical30: (alpha?: number) => string;
    critical40: (alpha?: number) => string;
    critical50: (alpha?: number) => string;
};
/**
 * Informative
 *
 * {@link https://zeroheight.com/3ddd0f892/p/028ae9-colors/t/90e5b5}
 */
export declare const informative10: (alpha?: number) => string;
export declare const informative20: (alpha?: number) => string;
export declare const informative30: (alpha?: number) => string;
export declare const informative40: (alpha?: number) => string;
export declare const informative50: (alpha?: number) => string;
export declare const informative: {
    informative10: (alpha?: number) => string;
    informative20: (alpha?: number) => string;
    informative30: (alpha?: number) => string;
    informative40: (alpha?: number) => string;
    informative50: (alpha?: number) => string;
};
declare const _default: {
    success: {
        success10: (alpha?: number) => string;
        success20: (alpha?: number) => string;
        success30: (alpha?: number) => string;
        success40: (alpha?: number) => string;
        success50: (alpha?: number) => string;
    };
    warning: {
        warning10: (alpha?: number) => string;
        warning20: (alpha?: number) => string;
        warning30: (alpha?: number) => string;
        warning40: (alpha?: number) => string;
        warning50: (alpha?: number) => string;
    };
    critical: {
        critical10: (alpha?: number) => string;
        critical20: (alpha?: number) => string;
        critical30: (alpha?: number) => string;
        critical40: (alpha?: number) => string;
        critical50: (alpha?: number) => string;
    };
    informative: {
        informative10: (alpha?: number) => string;
        informative20: (alpha?: number) => string;
        informative30: (alpha?: number) => string;
        informative40: (alpha?: number) => string;
        informative50: (alpha?: number) => string;
    };
};
export default _default;
//# sourceMappingURL=alert.d.ts.map