import Vue from 'vue'
import App from './App.vue'
import 'amfe-flexible'
import FormShow from '../lib/index'

Vue.use(FormShow)

new Vue({
  el: '#app',
  render: h => h(App)
})
