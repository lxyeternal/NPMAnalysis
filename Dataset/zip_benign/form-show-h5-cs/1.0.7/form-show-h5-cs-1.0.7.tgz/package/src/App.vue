<template>
  <div id="app">
    <form-show>
      <form-show-item label="工单类型">维修</form-show-item>
      <form-show-item label="预约时间">今日10:30 上门</form-show-item>
      <form-show-item label="设备信息">TT2763PP</form-show-item>
      <form-show-item label="故障分类故障分类故障分类故障分类">安装</form-show-item>
      <form-show-item label="故障描述">无法启动</form-show-item>
      <form-show-item label="解决方案">更换内存</form-show-item>
      <form-show-item label="备注信息">不能穿联想工装，不能穿联想工装不能穿联想工装不能穿联想工装不能穿联想工装,不能穿联想工装.</form-show-item>
      <form-show-item label="安装位置">位置</form-show-item>
      <form-show-item label="工单收入">100元</form-show-item>
    </form-show>
  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {}
  }
}
</script>

<style lang="scss" scoped>
  #app {
    width: 100%;
    height: 100%;
    background-color: #ffffff;
    padding: 10px 10px;
  }

  * {
    box-sizing: border-box;
  }
</style>

