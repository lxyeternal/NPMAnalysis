<template>
  <div ref="formItem" class="form-show_item">
    <label ref="label" class="form-show_item__label" :title="label" :style="labelStyle">
      <span class="form-show_item__label__text">{{ label }}{{ label ? form.labelSuffix : '' }}</span>
    </label>
    <div class="form-show_item__content">
      <slot />
    </div>
  </div>
</template>

<script>
export default {
  name: 'FormShowItem',
  props: {
    label: String
  },
  data () {
    return {
      // labelWidth: undefined
    }
  },
  computed: {
    form () {
      let parent = this.$parent
      let parentName = parent.$options.name
      while (parentName !== 'FormShow') {
        parent = parent.$parent
        parentName = parent.$options.name
      }
      return parent
    },
    labelWidth () {
      return this.form ? this.form.maxLabelWidth : undefined
    },
    labelStyle () {
      const ret = {}
      if (this.form.labelPosition === 'top') return ret
      const labelWidth = this.labelWidth
      const labelPosition = this.form.labelPosition
      if (labelWidth) {
        ret.width = labelWidth
      }
      if (labelPosition) {
        ret.textAlign = labelPosition
      }
      return ret
    }
  },
  activated () {
    this.setMaxLabelWidth()
  },
  created () {
    this.$nextTick(() => {
      this.setMaxLabelWidth()
    })
  },
  methods: {
    setMaxLabelWidth () {
      if (!this.form.labelWidth) {
        this.$refs.label.style.width = 'auto'
        this.$nextTick(() => {
          const dpi = Math.ceil(window.devicePixelRatio || 2)
          let labelWidth = this.$refs.label.clientWidth + dpi
          const maxWidth = this.$refs.formItem.clientWidth
          labelWidth = Math.min(labelWidth, maxWidth * Number(this.form.labelMaxWidth)) // label的宽度最大不超过30%
          this.$refs.label.style.width = this.form.maxLabelWidth
          this.form.setLabelWidth(labelWidth)
        })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .form-show_item {
    width: 100%;
    font-size: 12px;
    color: #303133;
    line-height: 1.5;
    display: flex;
    flex-direction: row;

    > .form-show_item__label {
      position: relative;
      color: #9E9E9E;
      font-size: 12px;
      padding: 4px 0px;
      display: flex;
      flex-direction: row;

      > .form-show_item__label__text {
        font-size: 12px;
        flex: 1;
        display: block;
        word-break: break-all;
        overflow: hidden;
      }
    }

    > .form-show_item__content {
      color: #000000;
      font-size: 12px;
      flex: 1;
      word-break: break-all;
      white-space: pre-wrap;
      padding: 4px 0px 4px 10px;
    }
  }
</style>
