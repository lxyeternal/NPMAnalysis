<template>
  <div class="form-show" :style="styleCss">
    <slot />
  </div>
</template>

<script>
export default {
  name: 'FormShow',
  props: {
    labelWidth: [String, Number],
    labelMaxWidth: {
      type: [String, Number],
      default: () => 0.3
    },
    labelSuffix: {
      type: String,
      default: '：'
    },
    labelPosition: {
      type: String,
      default: 'left'
    },
    backgroundColor: {
      type: String,
      default: '#F8F8F8'
    }
  },
  data () {
    return {
      maxLabelWidth: undefined
    }
  },
  computed: {
    styleCss () {
      return {
        backgroundColor: this.backgroundColor,
        borderColor: this.borderColor
      }
    }
  },
  created () {
    if (this.getObjectType(this.labelWidth) === 'String') {
      this.maxLabelWidth = this.labelWidth
    } else if (this.getObjectType(this.labelWidth) === 'Number') {
      this.maxLabelWidth = this.labelWidth + 'px'
    }
  },
  methods: {
    setLabelWidth (w) {
      const max = this.maxLabelWidth ? Number(this.maxLabelWidth.replace('px', '')) : 0
      this.maxLabelWidth = Math.max(max, w) + 'px'
    },
    getObjectType (s) {
      const str = Object.prototype.toString.call(s)
      const regex = /^\[object\s([a-zA-Z]+)\]$/
      return str.match(regex)[1]
    }
  }
}
</script>

<style lang="scss" scoped>
  .form-show {
    position: relative;
    width: 100%;
    border-bottom: none;
    border-right: none;
    background: #F8F8F8;
    padding: 10px;
  }
</style>
