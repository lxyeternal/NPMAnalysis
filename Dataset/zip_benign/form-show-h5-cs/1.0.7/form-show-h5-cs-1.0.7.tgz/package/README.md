# form-show-h5-cs

> 基于vue的H5表单详情组件

### Install

``` bash
npm install form-show-h5-cs --save
```

### Usage

``` bash
import FormShow from 'form-show-h5-cs'

Vue.use(FormShow);

<form-show background-color="#F8F8F8">
  <form-show-item label="工单类型">维修</form-show-item>
  <form-show-item label="预约时间">今日10:30 上门</form-show-item>
  <form-show-item label="解决方案">更换内存</form-show-item>
  <form-show-item label="备注信息">不能穿联想工装，不能穿联想工装不能穿联想</form-show-item>
</form-show>
```

### Props

##### FormShow

| 字段名称 | 类型 | 说明 | 默认值 |
| --- | --- | --- | --- |
| labelWidth | String/Number | Label宽度 | - |
| labelMaxWidth | String/Number | Label最大宽度 | 0.3 |
| labelSuffix | String | Label后缀 | ： |
| labelPosition | String | Label对齐方式（left/right） | right |
| backgroundColor | String | 背景色 | #ffffff |

##### FormShowItem

| 字段名称 | 类型 | 说明 | 默认值 |
| --- | --- | --- | --- |
| label | String | 字段名称 | - |

