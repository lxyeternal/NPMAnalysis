class Module

  constructor: (@name) ->