# ly-calculate

Used for js floating point calculation， include the following methods:
- accAdd 
- accSub
- accMul
- accDiv

Demo:
```javascript
import { accSub } from 'ly-calculate';

var num = 0.3;
console.log(num.accSub(0.1))  // 0.2
console.log(accSub(num, 0.1))  // 0.2
```

> Not original, NPM packages are only released for your own convenience