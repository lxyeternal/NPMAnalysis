import { defineConfig } from "vite";
import { resolve } from "path";
import react from "@vitejs/plugin-react-swc";
const packageJson = require("./package.json");

// https://vitejs.dev/config/
export default defineConfig({
  define: {
    "process.env.NODE_ENV": "'production'",
  },
  build: {
    lib: {
      entry: resolve(__dirname, "src/stories/index.tsx"),
      name: "alert-point",
      fileName: (format) => `${format}/index.js`,
      formats: ["es", "cjs", "umd", "iife"],
    },
    minify: "esbuild", //esbuild terser
    rollupOptions: {
      external: [
        ...Object.keys(packageJson.dependencies || {}),
        ...Object.keys(packageJson.devDependencies || {}),
        ...Object.keys(packageJson.peerDependencies || {}),
      ],
      output: {
        extend: true,
        globals: {
          react: "React",
          echarts: "echarts",
          "echarts-for-react": "ReactEcharts",
          clone:"clone",
          "@xintao1105/echarts-tool": "echartsTool",
        },
      },
    },
    outDir: "dist", //指定输出路径
  },
  resolve: {
    // 配置路径别名
    alias: {
      "@": resolve(__dirname, "./src"),
    },
  },
  plugins: [react()],
});
