# k-means

![](https://img.shields.io/npm/v/@cckim/k-means?color=yellowgreen&label=%20)

k-means Typescript language implementation


### Install

```shell
# pnpm
pnpm add @cckim/k-means

# yarn
yarn add @cckim/k-means

# npm
npm install @cckim/k-means
```

### Usage

create a set of points in a plane
```ts
const rawData = [[0, 0], [0, 1], [1, 3], [2, 0]]
```
use k-means clustering and specify the number of prime centers

```ts
import kMeans from '@cckim/k-means'

// number of centers of mass is 2
const result = kMeans(rawData, 2)
// Map(2) {
//   [ 1, 0 ] => [ [ 0, 0 ], [ 2, 0 ] ],
//   [ 0.5, 2 ] => [ [ 0, 1 ], [ 1, 3 ] ]
// }
```

#### point
the point is multi-dimensional, e.g:
```ts
// two-dimensional plane point
const twoRawData = [[0, 0], [0, 1], [1, 3], [2, 0]]
// three-dimensional plane point
const threeRawData = [[0, 0, 1], [0, 1, 1], [1, 3, 2], [2, 0, 3]]
// more...
```
