declare type Point = Array<number>;
declare const kMeans: <T extends Point>(data: T[], k?: number, threshold?: number) => Map<T, T[]>;
export default kMeans;
