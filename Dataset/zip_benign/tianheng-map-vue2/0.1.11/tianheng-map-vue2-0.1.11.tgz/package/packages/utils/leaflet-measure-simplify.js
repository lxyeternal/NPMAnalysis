/* eslint-disable */
import "./leaflet-measure-simplify.less";
import * as turf from "@turf/turf";
class leafletMeasureSimplify {
  constructor(map, options = {}) {
    this.layer = [];
    this.map = map;
    this.tipLanguage = options.tipLanguage || "zh-CN";
    this.showTip = options.showTip || true;
    this.showResult = options.showResult || true;
    this.color = options.color || "#039bec";
    this.weight = options.weight || 3;
    this.unitDistance = options.unitDistance || "kilometer";
    this.unitArea = options.unitArea || "kilometer";
    this.precisionDistance = options.precisionDistance || 2;
    this.precisionArea = options.precisionDistance || 2;
    this.precisionCoord = options.precisionDistance || 6;
    this.customTip = options.customTip;
  }

  distance() {
    this.close();
    this.measureBegin();
    let path = [];
    let line = null;
    let isMove = false;
    this.clickHandler = ({ latlng }) => {
      path.push(latlng);
      if (path.length == 1) {
        line = L.polyline(path, {
          color: this.color,
          weight: this.weight,
        }).addTo(this.map);
        this.layer.push(line);
        this.setTipText("step2");
      } else {
        isMove ? path.pop() : "";
        const current = path.at(-1);
        const prev = path.at(-2);
        const from = turf.point([prev.lng, prev.lat]);
        const to = turf.point([current.lng, current.lat]);
        let distance = turf.distance(from, to);
        let unit = "km";
        switch (this.unitDistance) {
          case "metre":
            unit = "m";
            distance = distance * 1000;
            break;
          case "kilometer":
            break;
          default:
            break;
        }
        if (this.showResult) {
          const result = L.marker(current, {
            zIndexOffset: 1,
            icon: L.divIcon({
              className: "leaflet-measure-simplify-result distance",
              html: `<div style="transform: translate(${
                4.5 * (this.weight / 3) + 17
              }px, -50%)">${Number(
                distance.toFixed(this.precisionDistance)
              )} ${unit}</div>`,
            }),
          }).addTo(this.map);
          this.layer.push(result);
        }

        this.setTipText("step3");
      }
      const icon = L.marker(latlng, {
        zIndexOffset: 0,
        icon: L.divIcon({
          className: "leaflet-measure-simplify-icon-box",
          html: `<div style="border-color:${this.color};zoom:${
            this.weight / 3
          }"></div>`,
        }),
      }).addTo(this.map);
      this.layer.push(icon);
      isMove = false;
    };
    this.moveHandler = ({ latlng }) => {
      if (path.length >= 1) {
        isMove && path.pop();
        path.push(latlng);
        line.setLatLngs(path);
        isMove = true;
      }
    };
    const promise = new Promise((resolve) => {
      this.rClickHandler = () => {
        if (path.length > 2 || (path.length == 2 && !isMove)) {
          isMove && path.pop();
          line.setLatLngs(path);
          path = [];
          this.measureEnd();
          isMove = false;
          resolve(line.getLatLngs());
        }
      };
    });

    this.map.on("click", this.clickHandler);
    this.map.on("mousemove", this.moveHandler);
    this.map.on("contextmenu", this.rClickHandler);
    return promise;
  }

  area() {
    this.close();
    this.measureBegin();
    let path = [];
    let polygon = null;
    let isMove = false;
    this.clickHandler = ({ latlng }) => {
      path.push(latlng);
      if (path.length == 1) {
        polygon = L.polygon(path, {
          color: this.color,
          weight: this.weight,
        }).addTo(this.map);
        this.layer.push(polygon);
        this.setTipText("step2");
      } else {
        isMove ? path.pop() : "";
      }
      if (path.length >= 3) {
        this.setTipText("step3");
      }
      const icon = L.marker(latlng, {
        zIndexOffset: 0,
        icon: L.divIcon({
          className: "leaflet-measure-simplify-icon-box",
          html: `<div style="border-color:${this.color};zoom:${
            this.weight / 3
          }"></div>`,
        }),
      }).addTo(this.map);
      this.layer.push(icon);
      isMove = false;
    };
    this.moveHandler = ({ latlng }) => {
      if (path.length >= 1) {
        isMove && path.pop();
        path.push(latlng);
        polygon.setLatLngs(path);
        isMove = true;
      }
    };
    const promise = new Promise((resolve) => {
      this.rClickHandler = () => {
        if (path.length > 3 || (path.length == 3 && !isMove)) {
          const formatPath = path.map(({ lng, lat }) => [lng, lat]);
          const polygonTurf = turf.polygon([[...formatPath, formatPath[0]]]);
          const center = turf.centroid(polygonTurf);
          let area = turf.area(polygonTurf);
          let unit = "㎡";
          switch (this.unitDistance) {
            case "metre":
              break;
            case "kilometer":
              unit = "km²";
              area = area / 1000000;
              break;
            default:
              break;
          }
          const [lng, lat] = center.geometry.coordinates;
          if (this.showResult) {
            const result = L.marker([lat, lng], {
              zIndexOffset: 1,
              icon: L.divIcon({
                className: "leaflet-measure-simplify-result area",
                html: `<div>${Number(
                  area.toFixed(this.precisionArea)
                )} ${unit}</div>`,
              }),
            }).addTo(this.map);
            this.layer.push(result);
          }

          isMove && path.pop();
          polygon.setLatLngs(path);
          this.measureEnd();
          path = [];
          isMove = false;
          resolve(polygon.getLatLngs());
        }
      };
    });

    this.map.on("click", this.clickHandler);
    this.map.on("mousemove", this.moveHandler);
    this.map.on("contextmenu", this.rClickHandler);
    return promise;
  }

  coord() {
    this.close();
    this.measureBegin();
    const promise = new Promise((resolve) => {
      this.clickHandler = ({ latlng }) => {
        const icon = L.marker(latlng, {
          zIndexOffset: 0,
          icon: L.divIcon({
            className: "leaflet-measure-simplify-icon-box",
            html: `<div style="border-color:${this.color};zoom:${
              this.weight / 3
            }"></div>`,
          }),
        }).addTo(this.map);
        this.layer.push(icon);
        if (this.showResult) {
          const result = L.marker(latlng, {
            zIndexOffset: 1,
            icon: L.divIcon({
              className: "leaflet-measure-simplify-result coord",
              html: `<div style="transform: translate(${
                4.5 * (this.weight / 3) + 17
              }px, -50%);">${Number(
                latlng.lng.toFixed(this.precisionCoord)
              )},${Number(latlng.lat.toFixed(this.precisionCoord))}</div>`,
            }),
          }).addTo(this.map);
          this.layer.push(result);
        }
        this.measureEnd();
        resolve(latlng);
      };
    });

    this.map.on("click", this.clickHandler);
    return promise;
  }

  measureBegin() {
    // 鼠标状态修改
    const mapContainer = this.map._container;
    mapContainer.style.cursor = "crosshair";
    this.setTipText("step1");
  }

  measureEnd() {
    this.map._container.style.removeProperty("cursor");
    this.setTipText();
    this.clickHandler && this.map.off("click", this.clickHandler);
    this.moveHandler && this.map.off("mousemove", this.moveHandler);
    this.rClickHandler && this.map.off("contextmenu", this.rClickHandler);
  }

  async setTipText(field) {
    if (!this.showTip) return;
    if (!field) {
      this.tip && this.tip.remove();
      this.tip = null;
      return;
    }
    if (!this.tipLanguageContent) {
      if (this.customTip) {
        this.tipLanguageContent = this.customTip;
      } else {
        this.tipLanguageContent = {
          step1: "单击开始绘制",
          step2: "单机继续绘制",
          step3: "右键单击结束绘制",
        };
      }
    }
    if (!this.tip) {
      const mapContainer = this.map._container;
      // 创建提醒元素
      const tip = document.createElement("span");
      tip.className = "leaflet-measure-simplify-tip";
      tip.style.display = "none";
      mapContainer.appendChild(tip);
      // 提醒元素随鼠标移动
      mapContainer.addEventListener("mousemove", (e) => {
        tip.style.display = "inline-block";
        tip.style.left =
          e.clientX - mapContainer.getBoundingClientRect().left + "px";
        tip.style.top =
          e.clientY - mapContainer.getBoundingClientRect().top + "px";
      });

      this.tip = tip;
    }
    this.tip.innerText = this.tipLanguageContent[field];
  }

  close() {
    this.measureEnd();
    this.rClickHandler && this.rClickHandler();
  }

  clear() {
    this.layer.forEach((item) => {
      item.remove();
    });
    this.layer = [];
    this.close();
  }
}
export default leafletMeasureSimplify;
