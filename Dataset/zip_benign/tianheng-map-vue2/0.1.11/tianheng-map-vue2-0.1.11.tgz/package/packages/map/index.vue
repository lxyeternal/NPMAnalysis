<template>
  <div class="th-map-view" ref="mainBox">
    <div ref="mapEl" class="th-map-content" />
    <slot />
  </div>
</template>
<script name="ThMap">
import * as L from 'leaflet'
import '@geoman-io/leaflet-geoman-free'
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css'
import '~/utils/leaflet-side-by-side.js'
import LeafletMeasureSimplify from '~/utils/leaflet-measure-simplify.js'
import ElementResizeDetectorMaker from 'element-resize-detector'
import utils from '~/utils/mapUtils'
utils.initLeafletWMTS(L) // 载入wmts加载方式
const erd = ElementResizeDetectorMaker()

export default {
  name: 'ThMap',
  props: {
    crs: {
      type: Object,
      default: null
    },
    zoom: {
      type: Number,
      default: 8
    },
    center: {
      type: Array,
      default: () => [30.987527, 112.271301]
    },
    zoomConfig: {
      type: Object,
      default: () => {
        return {
          control: true,
          doubleClickZoom: false,
          position: 'bottomright' // 'topleft', 'topright', 'bottomleft' or 'bottomright'
        }
      }
    },
    drawConfig: {
      type: Object,
      default: () => {
        return {
          color: '#409EFF',
          fillColor: '#409EFF',
          fillOpacity: 0.5
        }
      }
    },
    measureConfig: {
      type: Object,
      default: () => {
        return {
          weight: 3, // 线条宽度
          color: '#039bec', // 主题色
          showTip: true, // 是否显示操作提示
          showResult: true, // 是否显示测量结果
          unitDistance: 'kilometer', // 距离测量单位（kilometer：千米/metre：米）
          unitArea: 'kilometer', // 面积测量单位（kilometer：平方千米/metre：平方米）
          precisionDistance: 2, // 距离测量精度
          precisionArea: 2, // 面积测量精度
          precisionCoord: 6, // 经纬度测量精度
          customTip: {
            step1: '单击开始绘制',
            step2: '单机继续绘制',
            step3: '右键单击结束绘制'
          } // 自定义操作提示 例如：{"step1":"单击开始绘制","step2":"单机继续绘制","step3":"右键单击结束绘制"}
        }
      }
    }
  },
  data () {
    return {
      map: null,
      timer: null,
      drawing: false,
      drawType: '',
      drawLayer: null,
      drawLayerGroup: null,
      sideControl: null, // 卷帘组件
      sideLeft: null,
      sideRight: null,
      measureTools: null // 测量工具
    }
  },
  mounted () {
    erd.listenTo(this.$refs.mainBox, () => {
      this.debounce(() => {
        // 界面变化后 对地图进行重置
        this.resetMap()
      }, 50)
    })
    this.initMap()
  },
  beforeUnmount () {
    erd.uninstall(this.$refs.mainBox)
  },
  methods: {
    // 初始化地图
    initMap () {
      const mapOption = {
        center: this.center, // 地图中心 宜都市
        zoom: this.zoom, // 缩放比列
        zoomControl: false, // 缩放组件手动添加，方便控制方向
        doubleClickZoom: this.zoomConfig && this.zoomConfig.doubleClickZoom, // 禁用双击放大
        attributionControl: false // 移除右下角leaflet标识
      }
      if (this.crs) {
        mapOption.crs = this.crs
      }
      this.map = L.map(this.$refs.mapEl, mapOption)
      if (this.zoomConfig && this.zoomConfig.control) {
        // 添加缩放控件
        const zoomControl = L.control.zoom({
          position: this.zoomConfig.position
        })
        this.map.addControl(zoomControl)
      }
      // 设置绘制配置
      this.map.pm.setLang('zh') // 控件提示设置中文
      this.drawLayerGroup = L.layerGroup()
      this.map.addLayer(this.drawLayerGroup)
      this.map.pm.setGlobalOptions({
        snapable: false,
        layerGroup: this.drawLayerGroup
      })
      // 绘制样式设定
      if (this.drawConfig && this.drawConfig.color) {
        this.map.pm.setPathOptions({
          color: this.drawConfig.color,
          fillColor: this.drawConfig.fillColor
            ? this.drawConfig.fillColor
            : this.drawConfig.color,
          fillOpacity: this.drawConfig.fillOpacity
            ? this.drawConfig.fillOpacity
            : 0.5
        })
      } else {
        this.map.pm.setPathOptions({
          color: '#409EFF',
          fillColor: '#409EFF',
          fillOpacity: 0.5
        })
      }
      // 绘制事件监听
      this.map.on('pm:create', (e) => {
        console.log(e, '绘制完成时调用')
        this.drawLayer = e.layer
        this.drawing = false
        this.$emit('drawResult', {
          type: e.shape,
          data: e
        })
      })

      if (this.measureConfig) {
        this.measureTools = new LeafletMeasureSimplify(
          this.map,
          this.measureConfig
        )
      }

      this.$emit('mapReady', this.map)
    },
    // 启动测量
    enableMeasure (method = 'distance') {
      if (!this.measureTools) {
        return
      }
      if (!['distance', 'area', 'coord'].includes(method)) {
        console.error('Measure method参数错误')
        return
      }
      this.measureTools[method]().then((path) => {
        console.log(path) // 绘制完成后将返回路径
        this.$emit('measureResult', {
          type: method,
          data: path
        })
      })
    },
    // 关闭测量
    disableMeasure () {
      if (!this.measureTools) {
        return
      }
      this.measureTools.close()
      this.measureTools.clear()
    },
    // 添加图层
    addLayer (layer) {
      if (!this.map) {
        return
      }
      if (!layer) {
        return
      }
      const layers = this.asArray(layer)
      layers.forEach((e) => {
        if (!this.map.hasLayer(e)) {
          this.map.addLayer(e)
        }
      })
    },
    // 移除图层
    removeLayer (layer) {
      if (!this.map) {
        return
      }
      if (!layer) {
        return
      }
      const layers = this.asArray(layer)
      layers.forEach((e) => {
        if (this.map.hasLayer(e)) {
          this.map.removeLayer(e)
        }
      })
    },
    // 重置地图
    resetMap () {
      if (!this.map) {
        return
      }
      L.Util.requestAnimFrame(
        this.map.invalidateSize,
        this.map,
        !1,
        this.map._container
      )
    },
    // 创建层级设置zindex
    createPane (name, zIndex = 450) {
      if (!this.map) {
        return
      }
      this.map.createPane(name)
      this.map.getPane(name).style.zIndex = zIndex
    },
    // 启动pm绘制
    enableDraw (drawType = 'Polygon') {
      if (!['Line', 'Polygon', 'Rectangle', 'Circle'].includes(drawType)) {
        console.error('drawType参数错误')
        return
      }
      if (!this.drawing) {
        this.clearDraw()
        this.drawing = true
        this.drawType = drawType
        this.map.pm.enableDraw(drawType, {
          snappable: true,
          finishOn: 'contextmenu',
          allowSelfIntersection: false,
          tooltips: true
        })
      } else {
        this.clearDraw()
        this.$emit('drawResult', {
          type: this.drawType,
          data: []
        })
      }
    },
    // 清空绘制图层
    clearDraw () {
      this.drawing = false
      this.map.pm.disableDraw(this.drawType)
      if (this.drawLayer) {
        this.map.removeLayer(this.drawLayer)
        this.drawLayer = null
      }
    },
    // 启动卷帘模式
    enableSideBySide (leftLayers, rightLayers) {
      if (!this.map) {
        return
      }
      if (this.sideControl) {
        this.disableSideBySide()
      }
      this.sideLeft = leftLayers
      this.sideRight = rightLayers
      this.addLayer(this.sideLeft)
      this.addLayer(this.sideRight)
      this.sideControl = L.control.sideBySide(this.sideLeft, this.sideRight)
      this.map.addControl(this.sideControl)
    },
    asArray (arg) {
      return arg === 'undefined' ? [] : Array.isArray(arg) ? arg : [arg]
    },
    // 设置左侧图层
    setSideLeftLayer (layer) {
      if (!this.map) {
        return
      }
      this.removeLayer(this.sideLeft)
      this.sideLeft = layer
      this.addLayer(this.sideLeft)
      this.sideControl.setLeftLayers(this.sideLeft)
    },
    // 设置右侧图层
    setSideRightLayer (layer) {
      if (!this.map) {
        return
      }
      this.removeLayer(this.sideRight)
      this.sideRight = layer
      this.addLayer(this.sideRight)
      this.sideControl.setRightLayers(this.sideRight)
    },
    // 关闭卷帘模式
    disableSideBySide () {
      if (!this.map) {
        return
      }
      this.map.removeControl(this.sideControl)
      this.removeLayer(this.sideLeft)
      this.removeLayer(this.sideRight)
    },

    // 事件防抖
    debounce (fn, time) {
      if (this.timer !== null) {
        clearTimeout(this.timer)
      }
      this.timer = setTimeout(fn, time)
    },
    // 设置天地图为基础
    setTiandituMap (tk) {
      const baseLayer = L.layerGroup([
        L.tileLayer(
          `http://{s}.tianditu.gov.cn/DataServer?T=img_w&X={x}&Y={y}&L={z}&tk=${tk}`,
          {
            subdomains: ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7'],
            maxZoom: 18,
            minZoom: 6
          }
        ),
        L.tileLayer(
          `http://{s}.tianditu.gov.cn/DataServer?T=cia_w&X={x}&Y={y}&L={z}&tk=${tk}`,
          {
            subdomains: ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7'],
            maxZoom: 18,
            minZoom: 6
          }
        )
      ])
      this.map.addLayer(baseLayer)
    }
  }
}
</script>
<style lang="less" scoped>
.th-map-view {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
  .th-map-content {
    width: 100%;
    height: 100%;
    position: relative;
  }
}
</style>
