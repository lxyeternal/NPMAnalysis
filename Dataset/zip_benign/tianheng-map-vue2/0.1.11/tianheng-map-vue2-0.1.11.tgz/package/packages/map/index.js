import ThMap from './index.vue'

ThMap.install = (Vue) => {
  Vue.component(ThMap.name, ThMap)
}

export default ThMap
