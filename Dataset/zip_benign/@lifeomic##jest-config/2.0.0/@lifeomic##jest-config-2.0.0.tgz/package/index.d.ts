import { Matchers } from 'expect';
declare const invalidKeys: readonly ["resolves", "rejects", "not"];
export type InvalidKeys = typeof invalidKeys[number];
export type ValidKeys = keyof Omit<Matchers<any>, InvalidKeys>;
type RootMatchers = {
    [key in ValidKeys]: Matchers<any>[key];
};
declare global {
    namespace jest {
        interface Expect extends RootMatchers {
        }
        interface InverseAsymmetricMatchers extends RootMatchers {
        }
    }
}
export {};
