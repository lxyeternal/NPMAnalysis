import React, { useReducer, useEffect, useState } from 'react';
import { StyleSheet, Text, Dimensions, TextInput, View, TouchableHighlight,Switch,Platform, Button, ActionSheetIOS } from 'react-native';
import Checkbox from 'expo-checkbox';
import TimePicker from "react-native-24h-timepicker";
import RNDateTimePicker from '@react-native-community/datetimepicker';

import { Picker } from '@react-native-picker/picker';
import { setStatusBarBackgroundColor } from 'expo-status-bar';

/*exports.printMsg = function () {
    console.log("This is a message from the demo package");
}*/
const INPUT_CHANGE = 'INPUT_CHANGE';
const DATE_CHANGE = 'DATE_CHANGE';
const INPUT_BLUR = 'INPUT_BLUR';
const DATE_BLUR = 'DATE_BLUR';
const DATE_SHOW = 'DATE_SHOW';

const inputReducer = (state, action) => {
  switch (action.type) {
    case INPUT_CHANGE:
      return {
        ...state,
        value: action.value,
        isValid: action.isValid
      };
    case DATE_CHANGE:
      return {
        ...state,
        value: action.value,
        isValid: action.isValid,
        show: false
      };
    case INPUT_BLUR:
      return {
        ...state,
        touched: true
      };
    case DATE_BLUR:
      return {
        ...state,
        touched: true,
        show: false
      };
    case DATE_SHOW:
      return {
        ...state,
        show: action.show
      };
    default:
      return state;
  }
};

export function Input(props) {
  const [inputState, dispatch] = useReducer(inputReducer, {
    value: props.initialValue ? props.initialValue : '',
    isValid: props.initiallyValid,
    touched: false
  });

  const { onInputChange, id,onSubmitEditing,onSubmitReset } = props;


  useEffect(() => {
    //console.log("input change 37 ",inputState.value)
    if (inputState.touched || true) {
      //console.log("input test",inputState)
      onInputChange(id, inputState.value, inputState.isValid);
    }
  }, [inputState, onInputChange, id]);

  const textChangeHandler = text => {
    const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let isValid = true;
    if (props.required && text.trim().length === 0) {
      isValid = false;
    }
    if (props.email && !emailRegex.test(text.toLowerCase())) {
      isValid = false;
    }
    if (props.min != null && +text < props.min) {
      isValid = false;
    }
    if (props.max != null && +text > props.max) {
      isValid = false;
    }
    if (props.minLength != null && text.length < props.minLength) {
      isValid = false;
    }
    if (props.differentFrom != null && props.differentFrom.indexOf(text) != -1) {
      isValid = false;
    }
    dispatch({ type: INPUT_CHANGE, value: text, isValid: isValid });
  };

  const lostFocusHandler = () => {
    dispatch({ type: INPUT_BLUR });
  };
  const onSubmitEditingInternal = () =>{
    onSubmitEditing();
    if(onSubmitReset){
      dispatch({ type: INPUT_CHANGE, value: "", isValid: false });
    }
  }

  return <View style={styles.inputView}>
    <Text style={{ ...styles.inputText, ...props.styleText }}>{props.label}</Text>
    <TextInput
      {...props}
      ref={props.customRefInput}
      style={{ ...styles.input, ...props.styleInput }}
      onChangeText={textChangeHandler}
      onBlur={lostFocusHandler}
      onSubmitEditing={onSubmitEditingInternal}
      value={inputState.value}
    />
    {!inputState.isValid && inputState.touched && (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{props.errorText}</Text>
      </View>
    )}
  </View>;
};

export function InputDate(props) {
  const [inputState, dispatch] = useReducer(inputReducer, {
    value: props.initialValue!="" ? new Date(props.initialValue).toLocaleDateString() : new Date().toLocaleDateString(),
    isValid: props.initiallyValid,
    touched: false,
    show: false
  });
  //const [show, setShow] = useState(false);
  const [date, setDate] = useState(props.initialValue!="" ? new Date(props.initialValue) : new Date());

  const { onInputChange, id  } = props;


  const getDateString = (date)=>{
      //console.log("getData init",date)
      let dateTimePartsSlash= date.split(/[/ :]/); 
      return dateTimePartsSlash[1]+"/"+dateTimePartsSlash[0]+"/20"+dateTimePartsSlash[2];
  }
  //console.log("show ",inputState.show)
  useEffect(() => {
    //console.log("date change  ", inputState)
    if (inputState.touched || true) {
      //console.log(inputState.value)
      onInputChange(id, inputState.value, inputState.isValid);
    }
  }, [inputState, onInputChange, id]);

  const textChangeHandler = text => {
    //console.log("date to show",)
    //setShow(true);
    dispatch({ type: DATE_SHOW, show: true });
  };

  const onChangeHandler = (date) => {
    const currentDate = new Date(date.nativeEvent.timestamp).toLocaleDateString();
    console.log("onChangeHandler", currentDate)
    if (date!="") {
      //setShow(false);
      //setDate(currentDate);
      //setShow(Platform.OS === 'ios');
      dispatch({ type: DATE_CHANGE, value: currentDate, isValid: true, show: false });
    } else {
      dispatch({ type: DATE_BLUR });
    }
  };
  const lostFocusHandler = () => {
    dispatch({ type: INPUT_BLUR });
  };
  const setShow = () =>{
    let updatedShow = inputState.show;
    if(inputState.show){
      updatedShow = false;
    } else{
      updatedShow = true;
    }
    dispatch({ type: DATE_SHOW, show: updatedShow });
  }

  /*
  <DatePicker
      style={{ ...styles.inputDate, ...props.styleInput }}
      value={inputState.value}
      placeholder="select date"
      format="DD-MM-YYYY"
      minDate={new Date()}
      mode={'date'}
      is24Hour={true}
      display="default"
      onChange={onChangeHandler}
    />*/

  return <View style={{...styles.inputView,...props.style}}>
    <View>
      <Text style={{ ...styles.inputText, ...props.styleText }}>{props.label}</Text>
    </View>
    <TouchableHighlight style={{...props.styleInput, ...styles.inputDate }} onPress={setShow}>
      <Text style={styles.inputDateText}>{inputState.isValid ? getDateString(inputState.value) : "select date"}</Text>
    </TouchableHighlight>
    
    {inputState.show ? 
      <RNDateTimePicker
      style={{ ...styles.inputDate, ...props.styleInput }}
      value={date}
      onChange={onChangeHandler}
    />
    : null
    }
    {!inputState.isValid && inputState.touched && (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{props.errorText}</Text>
      </View>
    )}
  </View>;
};

export function InputHour(props) {
  const [timePicked, setTimePicked] = useState(props.value ? props.value : "00:00");
  const [timePickerRef, setTimePickerRef] = useState();
  const { onInputChange, id } = props;
  const onCancel = () => {
    timePickerRef.close();
  }
  const onConfirm = (hour, minute) => {
    //console.log("set Time ", hour + ":" + minute);
    setTimePicked(hour + ":" + minute);
    timePickerRef.close();
    let isValid = true;
    onInputChange(id, hour + ":" + minute, isValid);
  }
  return <View style={{ ...styles.inputView, ...props.style }}>
    <Text style={{ ...styles.inputText }}>{props.label}</Text>
    <TouchableHighlight style={styles.inputHour} onPress={() => { timePickerRef.open() }}><Text style={{ textAlign: 'center' }}>{timePicked}</Text></TouchableHighlight>
    <TimePicker
      ref={ref => {
        setTimePickerRef(ref);
      }}
      onCancel={() => onCancel()}
      onConfirm={(hour, minute) => onConfirm(hour, minute)}
    />
  </View>;
};


export function InputSelect(props) {
  const [inputState, dispatch] = useReducer(inputReducer, {
    value: props.initialValue ? props.initialValue : -1,
    isValid: props.initiallyValid,
    touched: false
  });
  const [currentValue,setCurrentValue] = useState(props.initialValue ? props.initialValue : 'Seleziona');
  const [currentIndex,setCurrentIndex] = useState(props.initialValue ? props.items.findIndex(e => props.initialValue==e.label) : -1);
  let values = ["Cancella"];
  props.items.forEach(element => {
    values.push(element.label)
  });

  const { onInputChange, id,required } = props;

  useEffect(() => {
    //console.log("input change 37 ",inputState.value)
    if (inputState.touched || true) {
      //console.log(inputState.value)
      onInputChange(id, inputState.value, inputState.isValid);
    }
  }, [inputState, onInputChange, id]);

  useEffect(()=>{
    if(currentIndex!=-1){
      onInputChange(id, props.items[currentIndex].value, required && props.items[currentIndex].label=="Seleziona"  ?false : true);
      setCurrentValue(props.items[currentIndex].label);
    }
  },[currentIndex])

  const onInputChangeHandler = (itemValue, itemIndex) => {
    dispatch({ type: INPUT_CHANGE, value: itemValue, isValid: true });
  }
  //console.log("inital value",props.initialValue)
  const IOSSelect = ()=>{
    ActionSheetIOS.showActionSheetWithOptions(
      {
          options : values,
          destructiveButtonIndex : 0,
          cancelButtonIndex : 0 
      },
      buttonIndex =>{
        if(buttonIndex!=0){
          console.log("pressed" ,props.items[buttonIndex-1].label, buttonIndex-1)
          setCurrentIndex(buttonIndex-1);
          //dispatch({ type: INPUT_CHANGE, value: props.items[buttonIndex].value, isValid: true });
        }
      })
  }
  return <View style={styles.inputView}>
    {(Platform.OS === "ios")?
    <View>
      <Button title={currentValue} onPress={IOSSelect} />
    </View>
    :
    <Picker
      selectedValue={props.initialValue}
      style={styles.inputSelect}
      onValueChange={onInputChangeHandler}>
         {(Platform.OS === 'android') ? 
            <Picker.Item label={'Seleziona'} value={-1} /> : null
        }
      {props.items.map((item, key) => (
        <Picker.Item label={item.label} value={item.value} key={key} />
      ))}
    </Picker>
    }
    {!inputState.isValid && inputState.touched && (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{props.errorText}</Text>
      </View>
    )}
  </View>;
};


export function InputSwitch(props) {
  const [inputState, dispatch] = useReducer(inputReducer, {
    value: props.initialValue ? props.initialValue : '',
    isValid: props.initiallyValid,
    touched: false
  });

  const { onInputChange, id } = props;

  useEffect(() => {
    //console.log("input change Switch ",inputState.value)
    if (inputState.touched || true) {
      //console.log(inputState.value)
      onInputChange(id, inputState.value, inputState.isValid);
    }
  }, [inputState, onInputChange, id]);

  const onInputChangeHandler = () => {
    dispatch({ type: INPUT_CHANGE, value: !inputState.value, isValid: true });
  }
  return <View style={{...styles.inputViewSwitch,...props.style}}>
    <Text style={{ ...styles.inputTextSwitch, ...props.textStyle }}>{props.label}</Text>
    <Switch
        trackColor={props.trackColor}
        thumbColor={inputState.value ? props.thumbColor.true: props.thumbColor.false}
        ios_backgroundColor={props.IOSBackgroundColor}
        onValueChange={onInputChangeHandler}
        value={inputState.value}
      />
  </View>;
};


export function InputCheckBox(props) {
  const [value, setValue] = useState(props.initialValue ? props.initialValue : false);
  const onChange = (value) => {
    setValue(value);
    //console.log("checkbox value", value);
    props.onChange(props.id, value, true);
  }

  return <View style={styles.section}>
    <Checkbox
      style={styles.checkbox}
      value={value}
      onValueChange={onChange}
      color={props.initialValue ? '#4630EB' : undefined}
    />
    <Text style={styles.paragraph}>{props.text}</Text>
  </View>;
};

export const FORM_INPUT_UPDATE = 'FORM_INPUT_UPDATE';
export const FORM_SELECT_UPDATE = 'FORM_SELECT_UPDATE';

export const formReducer = (state, action) => {
  if (action.type === FORM_INPUT_UPDATE) {
    //console.log("formReducer", action.value)
    const updatedValues = {
      ...state.inputValues,
      [action.input]: action.value
    };
    const updatedValidities = {
      ...state.inputValidities,
      [action.input]: action.isValid
    };
    let updatedFormIsValid = true;
    for (const key in updatedValidities) {
      updatedFormIsValid = updatedFormIsValid && updatedValidities[key];
    }
    //console.log("formReducer validity", updatedFormIsValid)
    return {
      formIsValid: updatedFormIsValid,
      inputValidities: updatedValidities,
      inputValues: updatedValues
    };
  }
  if (action.type === FORM_SELECT_UPDATE) {
    //console.log("formReducer", action.value)
    const updatedValues = {
      ...state.inputValues,
      [action.input]: action.value
    };
    const updatedValidities = {
      ...state.inputValidities,
      [action.input]: action.isValid
    };
    let updatedFormIsValid = true;
    for (const key in updatedValidities) {
      updatedFormIsValid = updatedFormIsValid && updatedValidities[key];
    }
    //console.log("formReducer validity", updatedFormIsValid)
    return {
      formIsValid: updatedFormIsValid,
      inputValidities: updatedValidities,
      inputValues: updatedValues
    };
  }
  return state;
};

const styles = StyleSheet.create({
  inputView: {
    width: 0.8 * Dimensions.get('window').width,
    padding: 5,
    margin: 5,
  },
  inputViewSwitch : {
    width: 0.8 * Dimensions.get('window').width,
    padding: 5,
    paddingRight : 10,
    margin: 5,
    flexDirection : 'row'
  },
  inputText: {
    fontSize: 15,
    textAlign: 'center',
    padding: 5
  },
  inputTextSwitch: {
    fontSize: 15,
    textAlign: 'left',
    padding: 5,
    width : "80%"
  },
  input: {
    height: 25,
    borderColor: "black",
    borderWidth: 1,
    padding: 5,
    textAlign: 'center',
    borderRadius: 10
  },
  inputDate: {
    height: 35,
    borderColor: "black",
    borderWidth: 1,
    padding: 5,
    textAlign: 'center',
    borderRadius: 10
  },
  inputDateText : {
    textAlign: 'center',
  },
  inputSelect: {
    marginVertical : -15
  },
  inputHour: {
    height: 25,
    borderColor: "black",
    borderWidth: 1,
    padding: 2,
    textAlign: 'center',
    borderRadius: 10
  },
  errorContainer: {
    marginVertical: 5
  },
  errorText: {
    color: 'red',
    fontSize: 13
  },
  section: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  paragraph: {
    fontSize: 15,
  },
  checkbox: {
    margin: 8,
  },
  inputDate : {
    width: "100%",

  }
})
