# asfy-npm-inputs

const [formState, dispatchFormState] = useReducer(formReducer, {
        inputValues: {
            amOpen0: currentInfo.amOpen0 ? "": '',
        },
        inputValidities: {
            amOpen0: currentInfo.amOpen0 ? true : false,
        },
        formIsValid: currentInfo.amOpen0 ? true : false
      });
    const inputChangeHandler = useCallback(
        (inputIdentifier, inputValue, inputValidity) => {
          console.log(inputIdentifier, inputValue,inputValidity)
          dispatchFormState({
            type: FORM_INPUT_UPDATE,
            value: inputValue,
            isValid: inputValidity,
            input: inputIdentifier
          });
        },
        [dispatchFormState]
      );

#text input
<Input 
id="test"
initialValue=""
initiallyValid={true}
onInputChange={(id, value, isValid)=>{}}
required={false}
email
min=""
max=""
minLength=""
styleText={{}}
styleInput={{}}
label="label"
errorText="error"
differentFrom={[]}
/>

<InputHour
id="test"
initialValue="00:00"
initiallyValid={true}
onInputChange={(id, value, isValid) => { console.log("hour ", value) }}
required={false}
label="Chiusura:"
errorText="error"
style={{ width: 0.4 * Dimensions.get('window').width }}
/>

<InputCheckBox id="test" text="Orario continuato" initialValue={false} onChange={(id,value)=>{console.log(id , value)}}/>


<InputSelect 
            id="item_id"
            text="Seleziona servizio"
            initialValue={currentBook.name && currentBook.name? currentBook.client.name : ""}
            initiallyValid={true}
            items={getSelectItems(services)}
            onInputChange={inputChangeHandler}
            />