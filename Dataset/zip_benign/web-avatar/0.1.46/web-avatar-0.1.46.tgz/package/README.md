# web-avatar
This is library for web 3d avatar base on three.js

### How to use in React
``` jsx
import { AvatarPreview } from 'web-avatar';

const Demo = () => {
    return (
        <AvatarPreview
            modelURL={'xxx/yyy.glb'}
            defaultCamera={{
                fov: 50,
                aspect: (320 / 640),
                near: 0.5,
                far: 1000,
                position: {
                    x: 0,
                    y: 1,
                    z: 300
                }
            }}
            defaultControl={{ x: 0, y: 60, z: 0 }}
            defaultTextures={[
                { model: 'blue_eyes' },
                { model: 'black_hat' },
            ]}
        />
    );
}
```
