# Micro ScrollSpy

A lightweight library for adding scrollspy functionality to your web pages. Automatically updates navigation links based on scroll position.

## Features

- Easy to use and integrate
- Utilizes IntersectionObserver for performance
- Smooth scroll implementation
- Throttled scroll events for better performance
- Dependency on modern and efficient libraries

## Installation

```
npm install micro-scrollspy
```

## Usage

First, include the library in your project:

```javascript
import LightweightScrollSpy from 'micro-scrollspy';
```

Then, initialize the library with your configuration:

```javascript
new LightweightScrollSpy({
sections: '.section-class', // Class of the sections to spy on
navLinks: 'nav a', // Selector for navigation links
activeClass: '.active', // Class to add/remove on navigation
offset: 0.4, // Scroll offset for activation
});
```

## Dependencies

- `scrollama` for handling scroll events
- `intersection-observer` as a polyfill for better browser support
- `lodash.throttle` to throttle scroll events for performance
- `smoothscroll-polyfill` to enable smooth scrolling in all browsers
- `delegate` for easy event delegation

## Contributing

Contributions are welcome! Please submit a pull request or create an issue for any features or bug fixes.

## License

MIT
