import './toast.css';

var wrapDom = document.createElement('div');
wrapDom.className = 'toast__wrapper';
wrapDom.innerHTML = '<p class="toast__text" id="j_toastText"></p>';
document.body.appendChild(wrapDom);

wrapDom.addEventListener('webkitAnimationEnd', function (e) {
  if (e.animationName === 'toast__leave') {
    wrapDom.className = 'toast__wrapper';
  }
});

var textDom = document.getElementById('j_toastText');

export default {
  timer: null,
  show(content, time, opt) {
    // 函数重载
    if (time && typeof time !== 'number') {
      opt = time;
      time = null;
    }
    time || (time = 500);
    clearTimeout(this.timer);
    this.changeStyle(opt);
    textDom.innerText = content;
    wrapDom.className = 'toast__wrapper toast__enter';
    this.timer = setTimeout(function () {
      wrapDom.classList.add('toast__leave');
    }, time + 200);
  },
  changeStyle(opt) {
    opt || (opt = {});
    textDom.style.color = opt.color || '#fff';
    textDom.style.fontSize = (opt.size && (opt.size + 'px')) || '15px';
    wrapDom.style.background = opt.background || 'rgba(0, 0, 0, .6)';
    wrapDom.style.borderRadius = (opt.size && (Math.ceil((opt.size + 24)/2) + 'px')) || '20px';
  }
};