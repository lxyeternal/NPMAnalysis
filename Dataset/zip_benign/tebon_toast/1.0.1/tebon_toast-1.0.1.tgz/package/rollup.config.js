import postcss from 'rollup-plugin-postcss';
import { terser } from "rollup-plugin-terser";
import url from 'postcss-url';
import cssnano from 'cssnano';

export default {
  entry: "./src/toast.js",
  output: [
    {
      name: 'toast',
      file: './dist/toast.esm.js',
      format: 'esm'
    },
    {
      name: 'toast',
      file: './dist/toast.min.js',
      format: 'iife'
    },
    {
      name: 'toast',
      file: './demo/toast.esm.js',
      format: 'esm'
    }
  ],
  plugins: [
    postcss({
      extensions: [".css"],
      plugins: [
        url({
          url: "inline"
        }),
        cssnano(),
      ]
    }),
    terser()
  ]
};
