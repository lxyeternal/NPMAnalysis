import toast from './toast.esm.js';

document.getElementById('j_a').addEventListener('click', () => {
  toast.show('默认样式');
});

document.getElementById('j_b').addEventListener('click', () => {
  toast.show('绿色背景，字号20px', 1000, {
    size: 40,
    color: 'white',
    background: 'green'
  });
});