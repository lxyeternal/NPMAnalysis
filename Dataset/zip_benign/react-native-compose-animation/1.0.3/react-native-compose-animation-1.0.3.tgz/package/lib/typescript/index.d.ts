import { Animated } from 'react-native';
import { AnimationSteps, InitialValuesMap, AnimatablePropertyMap } from './types';
export default function composeAnimation({ steps, initialValues, }: {
    steps: AnimationSteps;
    initialValues?: InitialValuesMap;
}): {
    reset: () => void;
    style: {
        transform: (import("react-native").PerpectiveTransform | import("react-native").RotateTransform | import("react-native").RotateXTransform | import("react-native").RotateYTransform | import("react-native").RotateZTransform | import("react-native").ScaleTransform | import("react-native").ScaleXTransform | import("react-native").ScaleYTransform | import("react-native").TranslateXTransform | import("react-native").TranslateYTransform | import("react-native").SkewXTransform | import("react-native").SkewYTransform)[];
        opacity: Animated.AnimatedInterpolation;
    };
    steps: AnimationSteps;
    interpolations: AnimatablePropertyMap<Animated.AnimatedInterpolation>;
    duplicate: () => any;
    start: (callback?: Animated.EndCallback) => void;
    stop: () => void;
};
