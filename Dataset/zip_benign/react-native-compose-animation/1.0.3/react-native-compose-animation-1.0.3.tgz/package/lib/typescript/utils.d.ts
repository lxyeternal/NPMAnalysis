import { Animated } from 'react-native';
import { AnimatablePropertyMap } from './types';
export declare const createValuesMap: <D extends (k?: "translateX" | "translateY" | "rotate" | "rotateX" | "rotateY" | "scale" | "scaleX" | "scaleY" | "opacity") => any, R extends ReturnType<D>>(value: D) => AnimatablePropertyMap<R>;
export declare const createDefaultOutputMap: () => AnimatablePropertyMap<number[]>;
export declare const createInitialAnimatedValuesMap: () => AnimatablePropertyMap<Animated.Value>;
