export declare const TRANSFORM_PROPERTIES: readonly ["translateX", "translateY", "rotate", "rotateX", "rotateY", "scale", "scaleX", "scaleY"];
export declare const OTHER_PROPERTIES: readonly ["opacity"];
export declare const NATIVELY_ANIMATABLE_STYLE_PROPERTIES: ("translateX" | "translateY" | "rotate" | "rotateX" | "rotateY" | "scale" | "scaleX" | "scaleY" | "opacity")[];
