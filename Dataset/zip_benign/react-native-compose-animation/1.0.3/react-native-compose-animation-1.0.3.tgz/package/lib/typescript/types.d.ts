import { EasingFunction, Animated } from 'react-native';
import { NATIVELY_ANIMATABLE_STYLE_PROPERTIES } from './constants';
export declare type NativelyAnimatableProperty = typeof NATIVELY_ANIMATABLE_STYLE_PROPERTIES[number];
export declare type AnimatablePropertyMap<T extends any> = {
    [key in NativelyAnimatableProperty]: T;
};
export declare type InitialValuesMap = Partial<AnimatablePropertyMap<[number]>>;
declare type NextValue = number | ((previous: number) => number);
declare type SingleTransformConfiguration = {
    to: NextValue;
    duration?: number;
    easing?: EasingFunction;
};
export declare type AnimationStep = Partial<AnimatablePropertyMap<SingleTransformConfiguration>> | Animated.CompositeAnimation;
export declare type AnimationSteps = AnimationStep[];
export {};
