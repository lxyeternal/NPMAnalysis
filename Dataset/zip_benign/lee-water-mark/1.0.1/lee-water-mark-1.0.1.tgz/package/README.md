# lee-water-mark

## install

```shell
npm i lee-water-mark
```

## Usage

```js
import Watermark from 'lee-water-mark';

waterMark.set('https://zc-lee.gitee.io/');
```

## methods

```js
import Watermark from 'lee-water-mark';
waterMark.init(options); // 初始化配置
waterMark.set(test,options); // 设置文字水印
waterMark.setImg(img,options); // 设置图片水印
```

## options

```js
    {
        text: 'water mark', // 水印内容
        dom: document.body, // 水印父节点
        fontSize: 24, // 字号
        color: 'rgba(200, 200, 200, 0.5)',
        width: 500, // canvas width
        height: 500, // canvas height
        fixed: false, // 水印固定位置
        zIndex: null,
        img: null,
        pushDom: true, // true 添加至尾部 false unshift // 头部
      },
```