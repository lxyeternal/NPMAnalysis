import React from 'react';
import { shallow } from 'enzyme';
import Image, { getMapToRatios, getTinyUrl, getVariantUrls } from '../Image';

describe('<Image />', () => {
  const props = {
    alt: 'alt',
    images: [
      'https://stuff.fendergarage.com/images/N/W/C/monkees-birds-bees-monkees.jpg',
      'https://stuff.fendergarage.com/images/N/W/C/monkees-birds-bees-monkees@2x.jpg',
    ],
    onLoaded: jest.fn(),
  };
  const TestComponent = () => <Image {...props} />;
  const container = shallow(<TestComponent />);
  it('should exist', () => {
    expect(Image).toBeDefined();
  });
  it('should render the component', () => {
    expect(container).toMatchSnapshot();
  });
  describe('getMapToRatios', () => {
    it('should exist', () => {
      expect(getMapToRatios).toBeDefined();
    });
    it('should return the correct ratio', () => {
      expect(getMapToRatios('banner')).toEqual(0.1236);
      expect(getMapToRatios('cinema')).toEqual(0.4255);
      expect(getMapToRatios('golden')).toEqual(0.635);
      expect(getMapToRatios('portrait')).toEqual(1.7863);
      expect(getMapToRatios('square')).toEqual(1);
      expect(getMapToRatios('wideScreen')).toEqual(0.5625);
    });
    it('should return the default', () => {
      expect(getMapToRatios('night-king')).toEqual(1);
      expect(getMapToRatios([])).toEqual(1);
      expect(getMapToRatios({})).toEqual(1);
      expect(getMapToRatios(57)).toEqual(1);
    });
  });
  describe('getTinyUrl', () => {
    it('should get the tiny url', () => {
      expect(getTinyUrl).toBeDefined();
      expect(getTinyUrl('foo.jpg')).toEqual('foo_tiny.jpg');
    });
  });
  describe('getVariantUrls', () => {
    it('should get the variant urls', () => {
      expect(getVariantUrls).toBeDefined();
      expect(getVariantUrls('foo.jpg', 'square', 'small')).toEqual([
        'foo_400x400.jpg',
        'foo_400x400@2x.jpg',
      ]);
    });
  });
});
