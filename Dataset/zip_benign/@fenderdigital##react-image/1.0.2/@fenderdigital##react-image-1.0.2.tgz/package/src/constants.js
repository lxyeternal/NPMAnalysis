const ratiosMap = {
  banner: 0.1236,
  cinema: 0.4255,
  golden: 0.635,
  portrait: 1.7863,
  square: 1,
  wideScreen: 0.5625,
};

const variantsMap = {
  banner: {
    large: '1440x178',
    medium: '800x99',
    small: '400x49',
    smallThumb: '400x49',
    tiny: '40x5',
  },
  cinema: {
    large: '1400x613',
    medium: '800x340',
    small: '400x170',
    smallThumb: '200x85',
    tiny: '40x17',
  },
  golden: {
    large: '1400x889',
    medium: '800x494',
    small: '400x247',
    smallThumb: '200x123',
    tiny: '40x25',
  },
  portrait: {
    large: '1600x2858',
    medium: '800x1429',
    small: '400x714',
    smallThumb: '200x357',
    tiny: '40x71',
  },
  square: {
    large: '1400x1400',
    medium: '800x800',
    small: '400x400',
    smallThumb: '200x200',
    tiny: '40x40',
  },
  wideScreen: {
    large: '1400x809',
    medium: '800x449',
    small: '400x225',
    smallThumb: '200x112',
    tiny: '40x22',
  },
};

export { ratiosMap, variantsMap };
