import isDomUsable from '@fenderdigital/dom';
import { variantsMap } from './constants';

/**
 * Takes in an image url and adds _tiny to the url.
 *
 * @param {String} imageUrl - image-url.jpg
 * @return image-url_tiny.jpg
 *
 */
function generateTinyUrl(imageUrl) {
  if (!imageUrl) return null;
  const fileExtension = getFileExtenstion(imageUrl);
  const withOutFileExtension = getWithOutFileExtension(imageUrl);
  return `${withOutFileExtension}_tiny.${fileExtension}`;
}
/**
 * Gets the value for the desired variant dimensions.
 *
 * @param {String} ratio - cinema
 * @param {String} variantType - small
 * @return _400x400
 *
 */
function getVariants(ratio, variantType) {
  if (variantsMap[ratio] && variantsMap[ratio][variantType]) {
    return `_${variantsMap[ratio][variantType]}`;
  }
  return '';
}
/**
 * Takes in an image url and generates a list of 1 and 2x images.
 * Also, it generates them with the desired variantType.
 * See: variantsMap in ./constants.
 *
 * @param {Array} imageUrl - image-1
 * @return ['image-1_400x400.jpg', 'image-1_400x400@2x.jpg']
 *
 */
function generateVariantUrls(
  imageUrl,
  ratio = 'square',
  variantType = 'small',
  sizes = ['@1x', '@2x'],
) {
  if (!imageUrl) return null;
  const fileExtension = getFileExtenstion(imageUrl);
  const withOutFileExtension = getWithOutFileExtension(imageUrl);
  const withVariant = getVariants(ratio, variantType);
  const images = [];
  sizes.forEach(size => {
    const sizeSuffix = size !== '@1x' ? size : '';
    const url = `${withOutFileExtension}${withVariant}${sizeSuffix}.${fileExtension}`;
    images.push(url);
  });
  return images;
}
/**
 * Itereates through images and generates image sizes,
 * for the `srcSet` attribute of the img tag.
 *
 * @param {Array} images - list of image urls.
 * @return `image.jpg 1x, image.jpg@2x 2x, image.jpg@3x 3x`
 *
 */
function generateSrcSet(images) {
  if (!Array.isArray(images)) return null;
  return images.map((image, key) => `${image} ${key + 1}x`);
}
/**
 * Takes in an image url and returns only the file extension.
 *
 * @param {String} imageUrl - image-url.jpg
 * @return jpg
 *
 */
function getFileExtenstion(imageUrl) {
  if (imageUrl && typeof imageUrl === 'string') {
    return imageUrl.split('.').pop();
  }
  return null;
}
/**
 * Takes in an image url and returns it without the file extension.
 *
 * @param {String} imageUrl - image-url.jpg
 * @return image-url
 *
 */
function getWithOutFileExtension(imageUrl) {
  if (imageUrl && typeof imageUrl === 'string') {
    return imageUrl.substring(0, imageUrl.lastIndexOf('.'));
  }
  return null;
}
/**
 * It will determine which image asset is needed for preloading.
 * It will return the 1x or 2x asset.
 *
 * @param {Array} images - an array of images
 * @return some-image@2x.jpg
 *
 */
function imageForLoad(images) {
  if (!Array.isArray(images) || !isDomUsable()) return null;
  return isRetina() && images.length > 1 ? images[1] : images[0];
}
/*
 * Returns a boolean, to determine, if the user is on a retina device.
 *
 * @return true / false
 *
 */
function isRetina() {
  return window.matchMedia(
    '(min--moz-device-pixel-ratio: 2), (-o-min-device-pixel-ratio: 2/1), (-webkit-min-device-pixel-ratio: 2), (min-device-pixel-ratio: 2), only screen and (min-resolution: 192dpi), (min-resolution: 2dppx)',
  ).matches;
}
/**
 * Returns a formatted ratio.
 *
 * @param {Number} ratio - 0.50
 * @return 50
 *
 */
function parseRatio(ratio) {
  return ratio && typeof ratio === 'number'
    ? Number(ratio * 100).toFixed(2)
    : 0;
}

export {
  generateTinyUrl,
  generateVariantUrls,
  generateSrcSet,
  getFileExtenstion,
  getWithOutFileExtension,
  imageForLoad,
  isRetina,
  parseRatio,
};
