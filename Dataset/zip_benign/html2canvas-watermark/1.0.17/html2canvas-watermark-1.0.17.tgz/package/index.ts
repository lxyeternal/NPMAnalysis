import html2canvas from "html2canvas";

import _canvasRender, { waterMarkProps, ARect } from "./dist";

const canvasRender: typeof _canvasRender = ({
  element,
  template,
  offset,
  onComplete,
  onClick: _onClick,
  options = {},
}) => {
  if (template) element.innerHTML = template;

  const a = html2canvas(element, {
    backgroundColor: options.backgroundColor || "transparent",
    allowTaint: true,
    useCORS: true,
  });

  element.style.opacity = "0";

  const [position] = element.getClientRects();

  a.then(async function (canvas) {
    const parent: any = element.parentNode;

    const aList = [
      // a标签跳转
      ...Array.from(element.querySelectorAll("a")).map((target) => {
        const [rects] = target.getClientRects();
        const _item: ARect = rects;
        _item.string = target.innerHTML;
        _item.href = target.href;
        return _item;
      }),
      // onclick
      ...Array.from(element.querySelectorAll("[data-clicked]")).map((target: Element) => {
        const _target = target as HTMLElement;
        const [rects] = _target.getClientRects();
        const _item: ARect = rects || {};
        _item.onclick = _onClick?.bind(null, _target, rects);
        return _item;
      }),
    ];

    parent.insertBefore(canvas, element);
    parent.removeChild(element);
    element.style.opacity = "1";

    const isA = (e) => {
      const [selected] = aList.filter(
        ({ top, height, left, width }) =>
          e.pageY > top && e.pageY < top + height && e.pageX > left && e.pageX < left + width
      );

      return selected;
    };

    type Timer = ReturnType<typeof setTimeout> | null;

    function throttle(func, wait = 100) {
      let timer: Timer;
      return (...args) => {
        if (timer) return;
        func(...args);
        timer = setTimeout(() => {
          timer && clearTimeout(timer);
          timer = null;
        }, wait);
      };
    }

    const onClick = (e) => {
      const selected = isA(e);
      if (selected) {
        const { href, onclick } = selected;
        onclick && onclick();
        href && window.open(href);
      }
    };

    const onMouseMove = throttle((e) => {
      const Pointer = "pointer";
      const selected = isA(e);
      const body = document.body;
      const cursor = body.style.cursor;
      const isPointer = cursor === Pointer;
      if (selected && !isPointer) body.style.cursor = Pointer;
      else if (!selected && isPointer) body.style.cursor = "auto";
    });

    try {
      canvas.onclick = onClick;
      canvas.onmousemove = onMouseMove;
      await drawLogo(canvas, options?.watertext, options.waterConf, {
        top: position.top + (offset?.top ?? 0),
      });
    } catch (e) {}
    onComplete && onComplete(canvas);
  });
};

export default canvasRender;

export async function drawLogo(
  canvas: HTMLCanvasElement,
  text?: string,
  options?: Partial<waterMarkProps>,
  pose?: Partial<DOMRect>
) {
  if (typeof text !== "string") {
    return;
  }

  const _font = {
    size: 16,
    color: "#999",
    family: "Verdana",
    ...options?.font,
  };

  const waterMark = {
    rotate: 0,
    opacity: 0.2,
    gapX: 100,
    gapY: 100,
    ...options,
    font: _font,
  };

  const { font, rotate, opacity, multiple, position, gapX, gapY, image } = waterMark;

  const { color, family, size } = font;

  if (text) {
    const ctx = canvas.getContext("2d")!;
    const boxWidth = pose?.width ?? parseInt(canvas.style.width);
    const boxHeight = pose?.height ?? parseInt(canvas.style.height);

    ctx.beginPath();
    ctx.globalAlpha = opacity;
    ctx.rotate(rotate);
    ctx.fillStyle = color;
    ctx.font = `${size}px ${family}`;

    const data = await isImage(text);
    const { img, isImg } = data;

    const fontNatrualWidth = !isImg
      ? ctx.measureText(text).width
      : image?.width || (img as HTMLImageElement).width;
    const fontNatrualHeight = !isImg ? size : image?.height || (img as HTMLImageElement).height;

    // 初始化点高度
    const fontDrawHeight = fontNatrualWidth * Math.abs(Math.sin(rotate)) + fontNatrualHeight;
    // 偏移量
    const offsetY = -((fontNatrualWidth + gapX) / Math.cos(rotate)) * Math.sin(rotate);
    const offsetX = ((gapY + fontNatrualHeight) / Math.cos(rotate)) * Math.sin(rotate);

    // 隔行偏移量
    const vix = (fontNatrualWidth + gapX) / 2;
    const viy = vix * Math.abs(Math.sin(rotate));

    const points = multiple
      ? getPoints(
          boxWidth,
          boxHeight,
          fontNatrualHeight,
          fontNatrualWidth,
          gapX,
          gapY,
          fontDrawHeight
        )
      : {
          x: [position?.x || 0],
          y: [position?.y || fontDrawHeight],
        };

    drawTextLogo(
      ctx,
      data.img,
      points,
      offsetY,
      offsetX,
      vix,
      viy,
      fontNatrualWidth,
      fontNatrualHeight,
      pose?.top
    );
    ctx.closePath();
  }
}

export async function isImage(url: string): Promise<{
  isImg: boolean;
  img: HTMLImageElement | string;
}> {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = url;

    img.onload = () => {
      resolve({
        isImg: true,
        img,
      });
    };

    img.onerror = () => {
      resolve({
        isImg: false,
        img: url,
      });
    };
  });
}

function getPoints(
  boxWidth: number,
  boxHeight: number,
  fontNatrualHeight: number,
  fontNatrualWidth: number,
  gapX: number,
  gapY: number,
  fontDrawHeight: number
): { x: number[]; y: number[] } {
  const x: number[] = [];
  const y: number[] = [];
  let _x = 0;
  let _y = fontDrawHeight;

  while (_x < boxWidth) {
    x.push(_x);
    _x += fontNatrualWidth + gapX;
  }
  while (_y < boxHeight + fontDrawHeight) {
    y.push(_y);
    _y += fontNatrualHeight + gapY;
  }
  return {
    x,
    y,
  };
}

function drawTextLogo(
  ctx: CanvasRenderingContext2D,
  text: string | HTMLImageElement,
  points: { x: number[]; y: number[] },
  offsetY: number,
  offsetX: number,
  vix: number,
  viy: number,
  fontNatrualWidth: number,
  fontNatrualHeight: number,
  top?: number
) {
  const { x, y } = points;
  y.forEach((_y, j) => {
    x.forEach((_x, i) => {
      const _vix = j % 2 ? vix : 0;
      const _viy = j % 2 ? viy : 0;

      const __x = _x + _vix + offsetX * j;
      const __y = _y + _viy + offsetY * i;

      if (typeof text === "string") {
        ctx.fillText(text, __x, __y + (top ?? 0));
      } else {
        ctx.drawImage(text, __x, __y, fontNatrualWidth, fontNatrualHeight);
      }
    });
  });
}
