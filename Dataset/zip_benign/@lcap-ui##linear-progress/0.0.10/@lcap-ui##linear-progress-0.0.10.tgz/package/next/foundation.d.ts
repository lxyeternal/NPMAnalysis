import { MDCLinearProgressFoundation } from '@material/linear-progress';
export declare const useLinearProgressFoundation: (props: any) => {
    rootEl: import("../base").FoundationElement<any, HTMLElement>;
    foundation: MDCLinearProgressFoundation;
};
