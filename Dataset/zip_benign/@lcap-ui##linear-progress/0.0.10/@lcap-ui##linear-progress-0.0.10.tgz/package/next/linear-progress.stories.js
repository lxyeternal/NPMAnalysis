import React from 'react';
import { storiesOf } from '@storybook/react';
import { boolean, number } from '@storybook/addon-knobs';
import { LinearProgress } from './';
storiesOf('Progress', module).add('LinearProgress', function () { return (React.createElement("div", null,
    React.createElement("div", { style: { margin: '30px 0' } },
        React.createElement(LinearProgress, null)),
    React.createElement("div", null,
        React.createElement(LinearProgress, { progress: number('progress', 0.5), buffer: number('buffer', 0), reversed: boolean('reversed', false), closed: boolean('closed', false), foundationRef: console.log })),
    React.createElement("div", { style: { margin: '30px 0' } },
        React.createElement(LinearProgress, { progress: 0.6, buffer: 0.8 })),
    React.createElement("div", null,
        React.createElement(LinearProgress, { progress: 0.2, reversed: true })))); });
