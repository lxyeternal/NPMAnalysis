const path = require("path");
const fs = require("fs");

/**
 *
 * @name json-dsl-parser
 * @description
 * json으로 정리된 SKP DSL 토큰명을 값으로 파싱해주는 도구입니다.
 *
 * @example
 * color: $globel-blue-100 -> color: #00f0ff
 */

export default function (source) {
  let dstJson = null;

  /**
   * @TODO
   * 웹팩 설정으로 로더를 불러올 때, 이 서비스가 OCB인지 시럽인지 파악할 수 있도록 인자를 넘겨줘야 합니다.
   * 지금은 알 수 없는 이유로 source 외의 인자가 넘어오지 않고 있어, 기본 서비스를 시럽으로 지정합니다.
   */

  const { service } = { service: "syrup" };
  if (service === "syrup") {
    dstJson = path.resolve(__dirname, "./tokens/syrup.json");
  } else {
    throw new Error("서비스의 DSL 토큰을 찾을 수 없습니다.");
  }

  const dstInfo = JSON.parse(fs.readFileSync(dstJson, "utf8"));
  const splittedCode = source.split("\n");
  const parsedDSTCode = splittedCode.map((line) => {
    if (line.includes("$")) {
      trimmedline = String(line).trim().replace(";", "");
      const tokenSeperator = "-";
      const dstStyleStartIndex = trimmedline.indexOf("$");
      const dstStyleText = trimmedline.substr(dstStyleStartIndex);
      const dstStyleToken = dstStyleText.replace("$", "").split(tokenSeperator);
      const dstStyle = dstStyleToken.reduce(
        (acc, dstStyle) => acc[dstStyle],
        dstInfo
      );
      const { value, type } = dstStyle;

      if (
        type === "color" ||
        type === "letterSpacing" ||
        type === "paragraphSpacing"
      ) {
        return line.replace(dstStyleText, value);
      }
      if (type === "boxShadow") {
        const { x, y, blur, spread, color } = value;
        const shorthandedShadow = `${pixelToRem({ pixel: x })}rem ${pixelToRem({
          pixel: y,
        })}rem ${pixelToRem({ pixel: blur })}rem ${pixelToRem({
          pixel: spread,
        })}rem ${color}`;
        return line.replace(dstStyleText, shorthandedShadow);
      }
      if (type === "typography") {
        const fontStyle = {};
        let stackTraceValue = null;
        // Note: {['fontFamily', '{fontFamilies.pretendard}'], ... }
        const fontStyleEntries = Object.entries(value);
        const trimmedFontStyleValues = fontStyleEntries.map((entry) => {
          const [key, value] = entry;
          const trimmedValue = getBracketTrimmedValue(value);
          const style = trimmedValue.split(".").reduce(
            (acc, fontStyleKey) => {
              try {
                if (acc[fontStyleKey]) {
                  if ("global" in dstInfo) {
                    return acc[fontStyleKey];
                  } else return acc[fontStyleKey];
                }
              } catch (err) {
                console.error(
                  `DSL 파싱 실패! : ${key} 키 하위에는 ${fontStyleKey}가 존재하지 않습니다.`
                );
                throw new Error(
                  `DSL 파싱 실패! : ${key} 키 하위에는 ${fontStyleKey}가 존재하지 않습니다.`
                );
              }
            },
            "global" in dstInfo ? dstInfo.global : dstInfo
          );
          return { ...style, type: key };
        });

        trimmedFontStyleValues.forEach(
          (trimmedValue) => (fontStyle[trimmedValue.type] = trimmedValue.value)
        );

        const combinedFontStyle = `
          font-family: ${fontStyle.fontFamily};
          font-weight: ${fontStyle.fontWeight};
          font-size: ${pixelToRem({
            pixel: fontStyle.fontSize,
          })}rem;
          line-height: ${pixelToRem({ pixel: fontStyle.lineHeight })}rem;
          text-decoration: ${fontStyle.textDecoration};
          letter-spacing: ${pixelToRem({ pixel: fontStyle.letterSpacing })}rem;
        `;

        return combinedFontStyle;
      }
    }
    return line;
  });

  return parsedDSTCode.join("\n").trim();
}

const pixelToRem = ({ pixel, basePixel = 10 }) => {
  return Number(pixel / basePixel);
};

const getBracketTrimmedValue = (key) => {
  let trimmedKey = key;
  if (trimmedKey.includes("{")) {
    trimmedKey = trimmedKey.replace("{", "");
  }
  if (trimmedKey.includes("}")) {
    trimmedKey = trimmedKey.replace("}", "");
  }
  return trimmedKey;
};

const getValueByPropertyType = (target, key) => {
  Object.keys(target).find(key);
};
