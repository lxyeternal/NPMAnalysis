const path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = {
  entry: "./src/styles/style-test-scss.scss",
  output: {
    path: path.resolve(__dirname, "dist"),
  },
  plugins: [new MiniCssExtractPlugin({ filename: "style.css" })],
  module: {
    rules: [
      {
        test: /\.s[ac]ss$/i,
        // Note: 웹팩에서 사용하는 파서 순위는 오른쪽에서 왼쪽으로 결정되므로, json-loader가 제일 마지막에 위치해야 한다.
        use: [
          MiniCssExtractPlugin.loader,
          {
            loader: "css-loader",
            options: { url: false },
          },
          "sass-loader",
          {
            loader: "@skp-wpteam/json-dsl-parser",
            options: { service: "syrup" },
          },
        ],
        exclude: /node_modules/,
      },
      {
        test: /\.css$/,
        exclude: /node_modules/,
        use: [
          MiniCssExtractPlugin.loader,
          {
            loader: "css-loader",
            options: { url: false },
          },
        ],
      },
    ],
  },
  resolve: {
    extensions: [".ts", ".js"],
  },
  resolveLoader: {
    alias: {
      "@skp-wpteam/json-dsl-parser": path.resolve(__dirname, "src/index.js"),
    },
  },
};
