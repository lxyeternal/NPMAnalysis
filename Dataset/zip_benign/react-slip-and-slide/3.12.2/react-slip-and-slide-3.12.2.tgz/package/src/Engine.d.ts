import { type ReactSlipAndSlideProps } from '@react-slip-and-slide/models';
export type EngineProps<T extends object> = {
    onItemPress: (index: number) => void;
} & Pick<ReactSlipAndSlideProps<T>, 'renderItem'>;
export declare const Engine: <T extends object>({ onItemPress, renderItem, }: EngineProps<T>) => JSX.Element;
