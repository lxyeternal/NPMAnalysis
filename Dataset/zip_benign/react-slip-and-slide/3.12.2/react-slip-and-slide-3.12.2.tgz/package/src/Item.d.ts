import { type BaseDimensions, type BoxRef, type ItemProps } from '@react-slip-and-slide/models';
import React from 'react';
declare function ItemBaseComponent<T extends object>({ index, item, renderItem, onPress }: ItemProps<T>, ref?: React.Ref<BoxRef>): React.JSX.Element;
export declare const LazyLayout: ({ isLazy, itemDimensions, children, }: React.PropsWithChildren<{
    isLazy: boolean;
    itemDimensions: Required<BaseDimensions>;
}>) => JSX.Element;
export declare const ItemBase: <T extends object>(props: ItemProps<T> & {
    ref?: React.Ref<BoxRef> | undefined;
}) => ReturnType<typeof ItemBaseComponent>;
export {};
