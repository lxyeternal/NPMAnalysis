import { AnimatedBox, Box, Context, elementDimensionStyles, } from '@react-slip-and-slide/utils';
import React from 'react';
export const LayoutManager = ({ children, }) => {
    const { state: { itemDimensions, itemDimensionMode, engineMode, centered, OffsetX }, } = Context.useDataContext();
    /**
     * Infinite = false
     * EngineMode = 'single'
     * itemDimensionMode = 'fixed' | 'dynamic'
     */
    if (engineMode === 'single') {
        const dynamicCenteredCorrectionStyles = {
            transform: itemDimensionMode === 'dynamic' && centered
                ? `translateX(${itemDimensions.width / 2}px)`
                : undefined,
        };
        return (React.createElement(Box, { styles: dynamicCenteredCorrectionStyles },
            React.createElement(AnimatedBox, { style: {
                    transform: [{ translateX: OffsetX }],
                }, styles: Object.assign({ display: 'flex', flexDirection: 'row', alignItems: 'center' }, elementDimensionStyles(itemDimensions)) }, children)));
    }
    /**
     * Infinite = true
     * EngineMode = 'multi'
     * itemDimensionMode = 'fixed'
     */
    return React.createElement(React.Fragment, null, children);
};
