import { Context, GestureContainer, elementDimensionStyles, typedMemo, useEngine, } from '@react-slip-and-slide/utils';
import React from 'react';
import { Engine } from './Engine';
function ReactSlipAndSlideComponent({ snap, containerWidth, pressToSlide, animateStartup = true, rubberbandElasticity = 0.1, overflowHidden = true, intentionalDragThreshold = 20, useWheel, initialIndex, loadingTime, onChange, onEdges, onReady, onItemPress, renderItem, }, ref) {
    const { handlers, state, signals, containerRef, Opacity } = useEngine({
        snap,
        containerWidth,
        pressToSlide,
        animateStartup,
        rubberbandElasticity,
        instanceRef: ref,
        initialIndex,
        loadingTime,
        onChange,
        onEdges,
        onReady,
        onItemPress,
    });
    const gestureContainerStyles = Object.assign(Object.assign({ justifyContent: state.centered ? 'center' : 'flex-start' }, elementDimensionStyles(state.container)), { width: containerWidth || '100%', minWidth: containerWidth || '100%', overflow: overflowHidden ? 'hidden' : undefined });
    return (React.createElement(GestureContainer, { ref: containerRef, direction: signals.direction, isDragging: signals.isDragging, isIntentionalDrag: signals.isIntentionalDrag, lastOffset: signals.lastOffset, lastValidDirection: signals.lastValidDirection, useWheel: useWheel, style: { opacity: Opacity }, styles: gestureContainerStyles, snap: snap, intentionalDragThreshold: intentionalDragThreshold, onDrag: handlers.onDrag, onRelease: handlers.onRelease, navigate: handlers.navigate },
        React.createElement(Engine, { onItemPress: handlers.onItemPress, renderItem: renderItem })));
}
export const ForwardReactSlipAndSlideRef = React.forwardRef(ReactSlipAndSlideComponent);
function ReactSlipAndSlideWithContext(props, ref) {
    return (React.createElement(Context.DataProvider, { props: props },
        props.childrenPosition === 'above' && props.children,
        React.createElement(ForwardReactSlipAndSlideRef, Object.assign({ ref: ref }, props)),
        (!props.childrenPosition || props.childrenPosition === 'below') &&
            props.children));
}
const ForwardReactSlipAndSlideWithContextRef = React.forwardRef(ReactSlipAndSlideWithContext);
export const ReactSlipAndSlide = typedMemo(ForwardReactSlipAndSlideWithContextRef);
