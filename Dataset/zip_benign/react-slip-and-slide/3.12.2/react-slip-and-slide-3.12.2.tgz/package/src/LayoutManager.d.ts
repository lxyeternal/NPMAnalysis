import React from 'react';
export declare const LayoutManager: <T extends object>({ children, }: React.PropsWithChildren) => JSX.Element;
