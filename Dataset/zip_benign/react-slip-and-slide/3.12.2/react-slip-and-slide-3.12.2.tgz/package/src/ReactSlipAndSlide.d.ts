import { type ReactSlipAndSlideProps, type ReactSlipAndSlideRef } from '@react-slip-and-slide/models';
import React from 'react';
declare function ReactSlipAndSlideComponent<T extends object>({ snap, containerWidth, pressToSlide, animateStartup, rubberbandElasticity, overflowHidden, intentionalDragThreshold, useWheel, initialIndex, loadingTime, onChange, onEdges, onReady, onItemPress, renderItem, }: ReactSlipAndSlideProps<T>, ref: React.Ref<ReactSlipAndSlideRef>): React.JSX.Element;
export declare const ForwardReactSlipAndSlideRef: <T extends object>(props: {
    _testId?: string | undefined;
    data: T[];
    snap?: boolean | undefined;
    centered?: boolean | undefined;
    infinite?: boolean | undefined;
    pressToSlide?: boolean | undefined;
    initialIndex?: number | {
        index: number;
        centered?: boolean | undefined;
    } | undefined;
    containerWidth?: number | undefined;
    containerHeight?: number | undefined;
    overflowHidden?: boolean | undefined;
    fullWidthItem?: boolean | undefined;
    itemWidth?: number | undefined;
    itemHeight?: number | undefined;
    interpolators?: import("@react-slip-and-slide/models").Interpolators<number> | undefined;
    animateStartup?: boolean | undefined;
    loadingTime?: number | undefined;
    rubberbandElasticity?: number | undefined;
    visibleItems?: number | undefined;
    useWheel?: boolean | undefined;
    momentumMultiplier?: number | undefined;
    childrenPosition?: "above" | "below" | undefined;
    listener?: React.DependencyList | undefined;
    intentionalDragThreshold?: number | undefined;
    renderItem: import("@react-slip-and-slide/models").RenderItem<T>;
    onChange?: ((index: number) => void) | undefined;
    onEdges?: ((props: import("@react-slip-and-slide/models").Edges) => void) | undefined;
    onReady?: ((ready: boolean) => void) | undefined;
    onItemPress?: ((item: {
        currentIndex: number;
        pressedItemIndex: number;
    }) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ReactSlipAndSlideRef> | undefined;
}) => ReturnType<typeof ReactSlipAndSlideComponent>;
declare function ReactSlipAndSlideWithContext<T extends object>(props: ReactSlipAndSlideProps<T>, ref: React.Ref<ReactSlipAndSlideRef>): React.JSX.Element;
export declare const ReactSlipAndSlide: <T extends object>(props: {
    _testId?: string | undefined;
    data: T[];
    snap?: boolean | undefined;
    centered?: boolean | undefined;
    infinite?: boolean | undefined;
    pressToSlide?: boolean | undefined;
    initialIndex?: number | {
        index: number;
        centered?: boolean | undefined;
    } | undefined;
    containerWidth?: number | undefined;
    containerHeight?: number | undefined;
    overflowHidden?: boolean | undefined;
    fullWidthItem?: boolean | undefined;
    itemWidth?: number | undefined;
    itemHeight?: number | undefined;
    interpolators?: import("@react-slip-and-slide/models").Interpolators<number> | undefined;
    animateStartup?: boolean | undefined;
    loadingTime?: number | undefined;
    rubberbandElasticity?: number | undefined;
    visibleItems?: number | undefined;
    useWheel?: boolean | undefined;
    momentumMultiplier?: number | undefined;
    childrenPosition?: "above" | "below" | undefined;
    listener?: React.DependencyList | undefined;
    intentionalDragThreshold?: number | undefined;
    renderItem: import("@react-slip-and-slide/models").RenderItem<T>;
    onChange?: ((index: number) => void) | undefined;
    onEdges?: ((props: import("@react-slip-and-slide/models").Edges) => void) | undefined;
    onReady?: ((ready: boolean) => void) | undefined;
    onItemPress?: ((item: {
        currentIndex: number;
        pressedItemIndex: number;
    }) => void) | undefined;
} & {
    children?: React.ReactNode;
} & {
    ref?: React.Ref<ReactSlipAndSlideRef> | undefined;
}) => ReturnType<typeof ReactSlipAndSlideWithContext>;
export {};
