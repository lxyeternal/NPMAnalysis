/**
 * Created by bear on 15-4-29.
 */
'use strict';

var gulp = require('gulp');
var jshint = require('gulp-jshint');
var jscs = require('gulp-jscs');

var paths = {
    lint: ['./lib/*.js', './*.js'],
    jscs: ['./index.js', './test.js', './lib/*.js']
};

// http://jshint.com/docs/options/
gulp.task('lint', function() {
    return gulp.src(paths.lint)
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

// http://jscs.info/rules.html
gulp.task('jscs', function() {
    return gulp.src(paths.jscs)
        .pipe(jscs());
});

// The default task (called when you run `gulp` from cli)
gulp.task('default', ['lint', 'jscs']);