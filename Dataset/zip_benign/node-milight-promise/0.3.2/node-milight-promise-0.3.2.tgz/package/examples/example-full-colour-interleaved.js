var Milight = require('../src/index').MilightController;
var commands = require('../src/index').commandsV6;

// Important Notes:
// *  Instead of providing the global broadcast address which is the default, you should provide the IP address
//    of the Milight Controller for unicast mode. Don't use the global broadcast address on Windows as this may give
//    unexpected results. On Windows, global broadcast packets will only be routed via the first network adapter. If
//    you want to use a broadcast address though, use a network-specific address, e.g. for `192.168.0.1/24` use
//    `192.168.0.255`.

var light = new Milight({
    ip: "192.168.178.84",
    type: 'v6'
  }),
  zone = 4;

var light2 = new Milight({
  ip: "192.168.178.84",
  type: 'v6'
});

function pause() {
  return light2.pause(1000);
}

Promise.all([light.ready(), light2.ready()]).then(function() {

  light.sendCommands(commands.fullColor.on(zone), commands.fullColor.whiteMode(zone), commands.fullColor.brightness(zone, 100));
  light2.sendCommands(commands.bridge.on(), commands.bridge.whiteMode(), commands.bridge.brightness(100));
  pause(1000);

  light.sendCommands(commands.fullColor.off(zone));
  light2.sendCommands(commands.bridge.off());
  pause(1000);

  // Setting Hue
  light.sendCommands(commands.fullColor.on(zone));
  light2.sendCommands(commands.bridge.on());
  pause(1000);
  for (var x = 0; x < 256; x += 5) {
    light.sendCommands(commands.fullColor.hue(zone, x));
    light2.sendCommands(commands.bridge.hue(x));
    if (x === 0) {
      light.sendCommands(commands.fullColor.brightness(zone, 100))
      light2.sendCommands(commands.bridge.brightness(100))
    }
  }
  pause(1000);

  light.sendCommands(commands.fullColor.off(zone));
  light2.sendCommands(commands.bridge.off());
  pause(1000);

// Setting Brightness (dimming down)
  light.sendCommands(commands.fullColor.on(zone));
  light2.sendCommands(commands.bridge.on());
  for (var x = 100; x >= 0; x -= 5) {
    light.sendCommands(commands.fullColor.brightness(zone, x));
    light2.sendCommands(commands.bridge.brightness(x));
  }
  pause(1000);

  light.sendCommands(commands.fullColor.off(zone));
  light2.sendCommands(commands.bridge.off());
  pause(1000);

  Promise.all([light.close(), light2.close()]).then(function () {
    console.log("All command have been executed - closing Milight");
  });
  console.log("Invocation of asynchronous Milight commands done");
}).catch(function(error) {
  console.log(error);
});

