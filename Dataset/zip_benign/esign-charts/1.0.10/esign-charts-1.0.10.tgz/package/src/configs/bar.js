function bar(theme, title, subtext) {
  return {
    backgroundColor: theme.backgroundColor || '#fff',
    color: theme.color || [
      '#c23531',
      '#2f4554',
      '#61a0a8',
      '#d48265',
      '#91c7ae',
      '#749f83',
      '#ca8622',
      '#bda29a',
      '#6e7074',
      '#546570',
      '#c4ccd3',
    ],
    title: {
      show: theme.title && theme.title.show && true,
      text: title,
      textStyle: (theme.title && theme.title.textStyle) || {
        color: '#333',
      },
      subtext,
      subtextStyle: (theme.title &&
        theme.title.subtextStyle) || {
        color: '#aaaaaa',
      },
      left: (theme.title && theme.title.left) || '50%',
      top: (theme.title && theme.title.top) || 'auto',
    },
    tooltip: theme.tooltip || {
      show: false,
    },
    legend: theme.legend || {
      show: true,
      type: 'scroll',
      bottom: 0,
      left: '4%',
      selector: ['all', 'inverse'],
    },
    grid: {
      left: '8%',
      top: 80,
    },
    xAxis: {
      // x轴
      type: (theme.bar && theme.bar.xType) || 'category',
      boundaryGap: true, // 两边留白
      axisLine:
        theme.categoryAxis && theme.categoryAxis.axisLine,
      axisTick: (theme.categoryAxis &&
        theme.categoryAxis.axisTick) || {
        show: false,
      }, // 刻度
      axisLabel:
        theme.categoryAxis && theme.categoryAxis.axisLabel,
      splitLine: (theme.categoryAxis &&
        theme.categoryAxis.splitLine) || {
        show: false,
      },
      rotate:
        theme.categoryAxis && theme.categoryAxis.rotate,
    },
    yAxis: {
      // y轴
      type: (theme.bar && theme.bar.yType) || 'value',
      axisTick: (theme.categoryAxis &&
        theme.categoryAxis.axisTick) || {
        show: false,
      },
      axisLine: (theme.categoryAxis &&
        theme.categoryAxis.axisLine) || {
        // 轴线的设置
        show: false,
      },
      axisLabel:
        theme.categoryAxis && theme.categoryAxis.axisLabel
          ? Object.assign(
              {},
              theme.categoryAxis.axisLabel,
              { rotate: 0 }
            )
          : {},
      splitLine: {
        // 分隔线
        show: true,
        lineStyle: (theme.categoryAxis &&
          theme.categoryAxis.splitLine &&
          theme.categoryAxis.splitLine.lineStyle &&
          theme.categoryAxis.splitLine.lineStyle.color) || {
          color: '#ccc',
        },
      },
    },
    toolbox: theme.toolbox || {
      // 工具栏
      show: false,
    },
    series: [
      {
        barWidth:
          (theme.bar && theme.bar.barWidth) || 'auto',
        type: 'bar',
        data: [],
        itemStyle: theme.bar && theme.bar.itemStyle,
      },
    ],
    dataZoom: theme.dataZoom || {
      show: false,
    },
  }
}

export default bar
