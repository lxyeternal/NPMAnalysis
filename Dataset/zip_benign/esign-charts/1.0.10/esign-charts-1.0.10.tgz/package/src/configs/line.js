function line(theme, title, subtext) {
  return {
    backgroundColor: theme.backgroundColor || '#fff',
    title: {
      show: theme.title && theme.title.show && true,
      text: title,
      textStyle: (theme.title && theme.title.textStyle) || {
        color: '#333',
      },
      subtext,
      subtextStyle: (theme.title &&
        theme.title.subtextStyle) || {
        color: '#aaaaaa',
      },
      left: (theme.title && theme.title.left) || '50%',
      top: (theme.title && theme.title.top) || 'auto',
    },
    color: theme.color || [
      '#c23531',
      '#2f4554',
      '#61a0a8',
      '#d48265',
      '#91c7ae',
      '#749f83',
      '#ca8622',
      '#bda29a',
      '#6e7074',
      '#546570',
      '#c4ccd3',
    ],
    tooltip: {
      // hover提示
      show: theme.tooltip && theme.tooltip.show && true,
      trigger: 'axis',
      axisPointer:
        theme.tooltip && theme.tooltip.axisPointer,
      confine: false,
    },
    legend: theme.legend || {
      show: true,
      type: 'scroll',
      bottom: 0,
      left: '4%',
      selector: ['all', 'inverse'],
    },
    grid: {
      left: '8%',
      top: 80,
    },
    xAxis: {
      // x轴
      type: 'category',
      boundaryGap: true, // 两边留白
      axisLine:
        theme.categoryAxis && theme.categoryAxis.axisLine,
      axisTick: (theme.categoryAxis &&
        theme.categoryAxis.axisTick) || {
        show: false,
      }, // 刻度
      axisLabel:
        theme.categoryAxis && theme.categoryAxis.axisLabel,
      splitLine: (theme.categoryAxis &&
        theme.categoryAxis.splitLine) || {
        show: false,
      },
      rotate:
        theme.categoryAxis && theme.categoryAxis.rotate,
      data: [],
    },
    yAxis: {
      // y轴
      axisTick: (theme.categoryAxis &&
        theme.categoryAxis.axisTick) || {
        show: false,
      },
      axisLine: (theme.categoryAxis &&
        theme.categoryAxis.axisLine) || {
        // 轴线的设置
        show: false,
      },
      axisLabel:
        theme.categoryAxis && theme.categoryAxis.axisLabel
          ? Object.assign(
              {},
              theme.categoryAxis.axisLabel,
              { rotate: 0 }
            )
          : {},
      splitLine: {
        // 分隔线
        show: true,
        lineStyle: (theme.categoryAxis &&
          theme.categoryAxis.splitLine &&
          theme.categoryAxis.splitLine.lineStyle &&
          theme.categoryAxis.splitLine.lineStyle.color) || {
          color: '#ccc',
        },
      },
    },
    toolbox: theme.toolbox || {
      // 工具栏
      show: false,
    },
    series: [
      {
        type: 'line',
        smooth: theme.line && theme.line.smooth && true, // 平滑曲线
        data: [],
        label: (theme.line &&
          theme.line.series &&
          theme.line.series.label) || {
          show: true,
        },
        areaStyle: (theme.line &&
          theme.line.series &&
          theme.line.series.areaStyle) || {
          opacity: 0,
        },
        itemStyle:
          theme.line &&
          theme.line.series &&
          theme.line.series.itemStyle,
      },
    ],
    dataZoom: theme.dataZoom || [
      {
        show: false,
        type: 'slider',
        height: 8,
        bottom: 20,
        borderColor: 'transparent',
        backgroundColor: '#e2e2e2',
        handleIcon:
          'M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7v-1.2h6.6z M13.3,22H6.7v-1.2h6.6z M13.3,19.6H6.7v-1.2h6.6z', // jshint ignore:line
        handleSize: 20,
        handleStyle: {
          shadowBlur: 6,
          shadowOffsetX: 1,
          shadowOffsetY: 2,
          shadowColor: '#aaa',
        },
      },
      {
        type: 'inside',
      },
    ],
  }
}

export default line
