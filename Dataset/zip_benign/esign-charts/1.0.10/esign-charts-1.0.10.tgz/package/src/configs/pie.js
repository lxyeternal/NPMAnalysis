function pie(theme, title, subtext) {
  return {
    backgroundColor: theme.backgroundColor || '#fff',
    color: theme.color || [
      '#c23531',
      '#2f4554',
      '#61a0a8',
      '#d48265',
      '#91c7ae',
      '#749f83',
      '#ca8622',
      '#bda29a',
      '#6e7074',
      '#546570',
      '#c4ccd3',
    ],
    title: {
      show: theme.title && theme.title.show && true,
      text: title,
      textStyle: (theme.title && theme.title.textStyle) || {
        color: '#333',
      },
      subtext,
      subtextStyle: (theme.title &&
        theme.title.subtextStyle) || {
        color: '#aaaaaa',
      },
      left: (theme.title && theme.title.left) || '50%',
      top: (theme.title && theme.title.top) || 'auto',
    },
    tooltip: {
      // hover提示
      trigger: 'item',
      formatter: '{b} : {c} ({d}%)',
    },
    legend: theme.legend || {
      show: true,
      type: 'scroll',
      orient: 'vertical',
      right: 10,
      top: 20,
      bottom: 20,
    },
    toolbox: theme.toolbox || {
      // 工具栏
      show: false,
    },
    series: [
      {
        type: 'pie',
        data: [],
        label: {
          formatter(text) {
            const label = text.name.replace(
              /\S{8}/g,
              match => {
                return `${match}\n`
              }
            )

            return label
          },
        },
        radius: (theme.pie && theme.pie.radius) || [
          '0',
          '75%',
        ],
        itemStyle: theme.pie && theme.pie.itemStyle,
        emphasis: theme.pie && theme.emphasis,
      },
    ],
  }
}

export default pie
