function china(type, theme, title, subtext) {
  return {
    backgroundColor: theme.backgroundColor || '#051b4a',
    color: theme.color || [
      '#c23531',
      '#2f4554',
      '#61a0a8',
      '#d48265',
      '#91c7ae',
      '#749f83',
      '#ca8622',
      '#bda29a',
      '#6e7074',
      '#546570',
      '#c4ccd3',
    ],
    title: {
      show: theme.title && theme.title.show && true,
      text: title,
      textStyle: (theme.title && theme.title.textStyle) || {
        color: '#fff',
      },
      subtext,
      subtextStyle: (theme.title &&
        theme.title.subtextStyle) || {
        color: '#aaaaaa',
      },
      left: (theme.title && theme.title.left) || '50%',
      top: (theme.title && theme.title.top) || 'auto',
    },
    visualMap: theme.visualMap || {
      min: 0,
      max: 200,
      calculable: false,
      show: false,
      color: ['#d94e5d', '#eac736', '#50a3ba'],
      textStyle: {
        color: '#fff',
      },
    },
    tooltip: theme.tooltip || {
      trigger: 'item',
      formatter: '{b}',
      textStyle: {
        fontSize: 12,
      },
    },
    geo: {
      map: type || 'china',
      roam: true, // 是否开启鼠标缩放和平移漫游
      layoutCenter: (theme.geo &&
        theme.geo.layoutCenter) || ['50%', '50%'], // 地图位置
      layoutSize:
        (theme.geo && theme.geo.layoutSize) || '180%',
      label: (theme.geo && theme.geo.label) || {
        normal: {
          show: false,
        },
        emphasis: {
          show: true,
          color: '#fff',
        },
      },
      itemStyle: (theme.geo && theme.geo.itemStyle) || {
        normal: {
          show: true,
          areaColor: {
            type: 'radial',
            x: 0.5,
            y: 0.5,
            r: 0.9,
            colorStops: [
              {
                offset: 0,
                color: 'rgba(147, 235, 248, 0)', // 0% 处的颜色
              },
              {
                offset: 1,
                color: 'rgba(147, 235, 248, .2)', // 100% 处的颜色
              },
            ],
            globalCoord: false, // 缺省为 false
          },
          borderColor: 'rgba(147, 235, 248, 1)',
          shadowColor: 'rgba(128, 217, 248, 1)',

          // shadowColor: 'rgba(255, 255, 255, 1)',
          shadowOffsetX: -2,
          shadowOffsetY: 2,
          shadowBlur: 10,
          borderType: 'solid',
        },
        emphasis: {
          areaColor: '#2B91B7',
          borderWidth: 0,
        },
      },
    },
    series: [
      {
        // 文字和标志
        type: 'scatter',
        coordinateSystem: 'geo',
        symbolSize:
          theme.scatter && theme.scatter.symbolSize,
        hoverAnimation: true,
        label: {
          normal: {
            formatter: '{b}',
            position: 'right',
            show: true,
          },
          emphasis: {
            show: true,
          },
        },
      },
      {
        type: 'effectScatter',
        coordinateSystem: 'geo',
        symbolSize:
          theme.effectScatter &&
          theme.effectScatter.symbolSize,
        showEffectOn: 'render',
        rippleEffect: {
          brushType: 'stroke',
        },
        hoverAnimation: true,
        label: {
          normal: {
            formatter: '{b}',
            position: 'right',
            show: true,
          },
        },
        rippleEffect: (theme.effectScatter &&
          theme.effectScatter.rippleEffect) || {
          scale: 2.5,
          brushType: 'stroke',
        },
        zlevel: 1,
      },
    ],
  }
}
export default china
