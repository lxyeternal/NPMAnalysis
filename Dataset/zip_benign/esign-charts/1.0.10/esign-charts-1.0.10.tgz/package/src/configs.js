const fs = require('fs')
const path = require('path')

try {
  const dirPath = path.join(__dirname, 'configs')
  const files = fs.readdirSync(dirPath)
  let str = ''
  let types = 'const options = {\n'
  files.forEach(file => {
    const filePath = `./configs/${file}`
    const fileName = file.substring(0, file.length - 3)
    str += `import ${fileName} from '${filePath}'\n`
    types += `  ${fileName},\n`
  })
  const data = `${str}\n${types}}\nexport default options\n`
  fs.writeFileSync(path.join(__dirname, 'options.js'), data)
  console.log(str, types)
} catch (e) {
  console.log(e)
}
