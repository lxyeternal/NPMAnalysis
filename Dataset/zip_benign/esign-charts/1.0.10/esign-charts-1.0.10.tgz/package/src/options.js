import bar from './configs/bar.js'
import line from './configs/line.js'
import map from './configs/map.js'
import pie from './configs/pie.js'

const options = {
  bar,
  line,
  map,
  pie,
}
export default options
