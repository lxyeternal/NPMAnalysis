const theme = {
  /**
   * 全局颜色的配置
   * 颜色按使用的优先级依次放入color数组中
   */
  color: [
    '#58eeff',
    '#06799b',
    '#ffb248',
    '#8dc1a9',
    '#516b91',
    '#eedd78',
    '#73a373',
    '#73b9bc',
    '#7289ab',
    '#91ca8c',
    '#f49f42',
    '#ff6347',
    '#a092f1',
    '#0a915d',
    '#eaf889',
    '#6699FF',
    '#ff6666',
    '#3cb371',
    '#d5b158',
    '#38b6b6',
  ],

  // 背景色
  // backgroundColor: '#fff',

  // 标题
  title: {
    show: true,
    textStyle: {
      // fontSize: 24,
      // color: 'red',
    },
    subtextStyle: {
      // fontSize: 12,
      // color: '#aaaaaa',
    },

    // left: '50%',
    // top: '10%',
  },

  // 折线图的配置
  line: {
    itemStyle: {
      normal: {
        borderWidth: '2',
      },
    },
    lineStyle: {
      normal: {
        width: '2',
      },
    },
    smooth: false,
    series: {
      label: {
        show: false,
        color: '#86C9F4',
      },

      /**
       * 区域阴影
       * 默认全部透明，既无阴影
       */
      // areaStyle: {},
      /**
       * 曲线上线和点的颜色
       */
      itemStyle: {
        // borderColor: '#1E1F2C',
        // color: '#76D3FF',
      },
    },
  },

  // 柱状图的配置
  bar: {
    // xType: 'value', // 竖的柱子还是横的柱子
    // yType: 'category',
    itemStyle: {
      normal: {
        barBorderWidth: 0,
        barBorderColor: '#cccccc',
      },
      emphasis: {
        barBorderWidth: 0,
        barBorderColor: '#cccccc',
      },
    },
  },

  // 饼图的配置
  pie: {
    itemStyle: {
      normal: {
        borderWidth: 0,
        borderColor: '#cccccc',
      },
      emphasis: {
        borderWidth: 0,
        borderColor: '#cccccc',
      },
    },
    radius: ['30%', '50%'],
  },
  /**
   * 世界地图和中国地图的样式配置
   */
  map: {
    itemStyle: {
      normal: {
        areaColor: '#eeeeee',
        borderColor: '#444444',
        borderWidth: 0.5,
      },
      emphasis: {
        areaColor: 'rgba(255,215,0,0.8)',
        borderColor: '#444444',
        borderWidth: 1,
      },
    },
    label: {
      normal: {
        textStyle: {
          color: '#000000',
        },
      },
      emphasis: {
        textStyle: {
          color: 'rgb(100,0,0)',
        },
      },
    },
  },

  /**
   * 设置地图样式，区块样式，以及高亮的样式
   */
  // geo: {
  //   itemStyle: {
  //     normal: {
  //       areaColor: '#eeeeee',
  //       borderColor: '#444444',
  //       borderWidth: 0.5,
  //     },
  //     emphasis: {
  //       areaColor: 'rgba(255,215,0,0.8)',
  //       borderColor: '#444444',
  //       borderWidth: 1,
  //     },
  //   },
  //   label: {
  //     normal: {
  //       textStyle: {
  //         color: '#000000',
  //       },
  //     },
  //     emphasis: {
  //       textStyle: {
  //         color: 'rgb(100,0,0)',
  //       },
  //     },
  //   },

  //   // 设置地图放大尺寸
  //   layoutCenter: ['50%', '50%'],
  //   layoutSize: '120%',
  // },

  /**
   * 带有涟漪特效动画的散点（气泡）图
   */
  // effectScatter: {
  //   itemStyle: {
  //     normal: {
  //       borderWidth: 0,
  //       borderColor: '#cccccc',
  //     },
  //     emphasis: {
  //       borderWidth: 0,
  //       borderColor: '#cccccc',
  //     },
  //   },
  // },

  /**
   * 散点（气泡）图
   */
  // scatter: {
  //   itemStyle: {
  //     normal: {
  //       borderWidth: 0,
  //       borderColor: '#cccccc',
  //     },
  //     emphasis: {
  //       borderWidth: 0,
  //       borderColor: '#cccccc',
  //     },
  //   },
  // },
  categoryAxis: {
    axisLine: {
      show: true,
      lineStyle: {
        color: '#e4e4e4',
      },
    },
    axisTick: {
      show: true,
      lineStyle: {
        color: '#e4e4e4',
      },
    },
    axisLabel: {
      show: true,
      textStyle: {
        color: '#333',
      },
      rotate: 20,
    },
    splitLine: {
      show: false,
      lineStyle: {
        color: ['#ccc'],
      },
    },
    splitArea: {
      show: false,
      areaStyle: {
        color: [
          'rgba(250,250,250,0.3)',
          'rgba(200,200,200,0.3)',
        ],
      },
    },
  },
  /**
   * 工具栏
   * 默认隐藏了，需要使用的时候配置
   * pie bar line  可以设置
   */
  toolbox: {
    iconStyle: {
      normal: {
        borderColor: '#999999',
      },
      emphasis: {
        borderColor: '#666666',
      },
    },
  },

  // 图例
  // legend: {
  //   show: true,
  //   type: 'scroll',
  //   top: '10%',
  //   selector: ['all', 'inverse'],
  // },

  /**
   * 图例的弹出信息框
   * line bar 可以设置
   */
  // tooltip: {
  //   show: true,
  //   axisPointer: {
  //     type: 'cross',
  //     lineStyle: {
  //       color: '#cccccc',
  //       width: 1,
  //     },
  //     crossStyle: {
  //       color: '#cccccc',
  //       width: 1,
  //     },
  //   },
  // },

  /**
   * 滚动条样式设置
   * 默认隐藏滚动条
   */
  // dataZoom: {
  //   backgroundColor: 'rgba(47,69,84,0)',
  //   dataBackgroundColor: 'rgba(47,69,84,0.3)',
  //   fillerColor: 'rgba(167,183,204,0.4)',
  //   handleColor: '#a7b7cc',
  //   handleSize: '100%',
  //   textStyle: {
  //     color: '#333333',
  //   },
  // },
}

export default theme
