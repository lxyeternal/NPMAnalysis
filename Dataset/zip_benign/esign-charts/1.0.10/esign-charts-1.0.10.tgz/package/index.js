import echarts from 'echarts/lib/echarts'
import options from './src/options'
import 'echarts/map/js/china'
import 'echarts/map/js/world'

function initOption(type, title, subtext, theme) {
  let config = {}
  if (type === 'world' || type === 'china') {
    config = options['map'](type, theme, title, subtext)
  } else {
    config = options[type](theme, title, subtext)
  }

  return config
}

/**
 *
 * @param {*} $dom
 * @param {*} params
 * done 'line' 'pie' 'bar’
 */
function create($dom, params) {
  const myChart = echarts.init($dom)
  const { dataSource, type, title } = params
  let config = initOption(
    type,
    title,
    params.subtext || '',
    params.theme || {}
  )
  if (type === 'china' || type === 'world') {
    config.series[0].data = dataSource.scatter
    config.series[1].data = dataSource.effectScatter
    myChart.setOption(config)

    return myChart
  }
  if (type === 'bar' || type === 'line') {
    const status =
      (config.yAxis && config.yAxis.type === 'category') ||
      (config.xAxis && config.xAxis.Type === 'value')
    if (type === 'bar' && status) {
      config = setData(config, 'yAxis', dataSource)
    } else {
      config = setData(config, 'xAxis', dataSource)
    }
  } else {
    config.series[0].data = dataSource
  }
  myChart.setOption(config)

  return myChart
}

/**
 * 设置数据
 * @param {*} config 配置项
 * @param {*} type 横纵坐标设置哪个
 * @param {*} dataSource 数据源
 */
function setData(config, type, dataSource) {
  // 设置横纵坐标
  const { data } = dataSource[0]
  config[type].data = data.map(i => {
    return i.name
  })

  Object.assign(config, type, config[type])

  // 设置图例
  if (config.legend.show) {
    config.legend.data = dataSource.map(el => el.name)
  }

  // set series
  const series = config.series[0]
  const list = []

  // 往series里放数据
  dataSource.map((el, index) => {
    list[index] = Object.assign({}, series, {
      name: el.name,
    })
    const array = []
    el.data.map(i => {
      array.push(i.value)
    })
    list[index].data = array
  })
  config.series = list

  return config
}

const chart = {
  create,
}

export default chart
