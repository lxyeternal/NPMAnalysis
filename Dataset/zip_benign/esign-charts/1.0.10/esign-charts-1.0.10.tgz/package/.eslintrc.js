module.exports = {
  root: true,
  env: {
    node: true,
  },
  extends: '@tsign/eslint-config-esign',
  rules: {},
  parserOptions: {
    parser: 'babel-eslint',
  },
}
