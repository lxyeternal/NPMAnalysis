declare function css(...args: any): void;
export default css;
