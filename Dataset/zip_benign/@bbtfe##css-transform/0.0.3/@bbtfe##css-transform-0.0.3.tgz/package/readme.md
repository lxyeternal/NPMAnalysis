# css-transform 组件

获取/设置transform的某个属性值

transform中所有的变换都是基于矩阵来实现的， 但是这块也存在一个问题，就是没法获取样式中设置的动画属性值。通过 getComputedStyle(div[0])["transform"] 方式获取到的是一个矩阵数据，如：matrix(0.5, 0, 0, 0.5, 50, 0)；通过 div[0].style.transform 方式获取到是所有的与transform相关的操作，比如： scale(0.5) translateX(100px)，是一个字符串，但是需要我们进一步的处理才能获取到相应的值。

现在定义一个获取/设置transform属性值及属性的函数。

注意：如果要获取transform相关的属性，那transform相关的设置也必须是通过CssTransform()该方法进行设置。

CssTransform(element,attr,value);

# es6引入使用方法

import CssTransform from '@bbtfe/css-transform';

# url引入使用方法

暂不支持