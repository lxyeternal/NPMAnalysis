# 目录

1. multArray 二维数组转换
2. flatten 扁平化数组
3. flattenDeep 指定层级扁平化数组
4. isArrayEqual 检查两个数组各项相等
5. allEqual 检查数组各项相等
6. diffArray 具有唯一 array 值的数组
7. haveArr 具有共同 array 值的数组
8. uniqueArray 数组去重
9. uniqueArrayObject 数组对象去重
10. ascArr 数组升序
11. descArr 数组降序
12. shuffle 随机排序
13. maxArray 数组中最大值
14. validArray 去除数组中的无效值
15. 防抖
16. 节流
17. 判断数据类型
18. JS 精度问题
19. 将树转成一维数组

#### 示例

1. multArray([1, 2, 3, 4, 5, 6, 7], 2) => [[1, 2], [3, 4], [5, 6], [7]]

2. flatten([1, [2], [3], [4, 5]]) => [1, 2, 3, 4, 5]

3. flattenDeep([1, [2, [3, [4]], 5]], 1) => [1, 2, [3, [4]], 5]

4. isArrayEqual(array, array)、

5. allEqual(array)

6. diffArray([1, 2, 6, 7], [1, 2, 9, 5]) => [ 6, 7 ]

7. haveArr([1, 2, 6, 7], [1, 2, 9, 5]) => [ 1, 2 ]

8. uniqueArray([1, 2, 2, 3, 4, 4, 5])=> [ 1, 2, 3, 4, 5 ]

9. debounce(fn, wait) //防抖

10. throttle(fn, wait) //节流

11. //判断函数类型
    typeFn.String('1')
    typeFn.Number(1)
    typeFn.Boolean(false)
    typeFn.Null(null)
    typeFn.Array([1, 2])
    typeFn.Object({ a: 1 })
    typeFn.Function(() => {})

12. 解决 0.1+0.2 !== 0.3 问题
    //加法
    calcFn.add(0.1, 0.2) // 0.3

//减法
calcFn.sub(0.1, 0.2) // 0.1

//乘法
calcFn.mul(0.2, 0.3) // 0.06

//乘法
calcFn.div(0.4, 0.2) // 2 13. 解决菜单中含有 children 的对象转化为一维数组
