/*
 * @Description: 入口文件
 * @Author: Poet
 * @Date: 2021-07-02 15:22:26
 * @LastEditors: Poet
 * @LastEditTime: 2021-07-02 15:42:27
 */
const poetKit = require( './lib/util.js' );
module.exports = poetKit; //暴漏出去