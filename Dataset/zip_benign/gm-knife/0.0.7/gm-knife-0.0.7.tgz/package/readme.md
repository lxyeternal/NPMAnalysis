# gm-knife

# laya 3D军刀

##### 安装

```
npm install gm-knife
```

##### 使用

- app.json
```
必须开启 "enableSkia": "true"
```

- json

```
{
    "usingComponents": {
        "gm-knife": "gm-knife/knife"
    }
}
```

- js

```
<!-- 复制test/TestScene.json 到对应目录 -->
<!-- 设置对应目录 -->
$global.window.Laya.TBMiniAdapter.baseDir = "/pages/knife/";{{对应目录}}
<!-- 模型 -->
[
    {
      host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/1/",
      // host: "res/LayaScene_SampleScene/Conventional/",
      sceneUrl: "SampleScene.ls",
      sprite3DName: "1",
      scale: 87,
      tipObj: {
        "zhudao": "",
        "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip4.atlas",
        "yaoshihuan": "",
      },
      startAnimation: {
        x: 0.2,
        stepX: -10,
        y: -0.5,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      frontAnimation: {
        x: 0.2,
        stepX: -10,
        y: -0.5,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      backAnimation: {
        x: -0.7,
        stepX: -10,
        y: 0.4,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0,
      },
      spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
        {
          baseName: "fengke02-1-gai",
          name: "daobaUp",//刀把上
        },
        {
          baseName: "upFont",
          name: "upFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 26,
              xPer: 0.8,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "downFont",
          name: "downFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: -0.0001
            },
            style: {
              rotate: 0,
              fontSize: 26,
              xPer: 1,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "daoFont",
          name: "daoFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 20,
              xPer: 0.8,
              yPer: 1.15,
              color: "#000",
            }
          }
        },
        {
          baseName: "fengke02-1-bian01",
          name: "daobaUpBian01",
        },
        {
          baseName: "fengke02-1-bian02",
          name: "daobaUpBian02",
        },
        {
          baseName: "fengke01-gai",
          name: "daobaDown",//刀把下
        },
        {
          baseName: "fengke01-bian01",
          name: "daobaDownBian01",
        },
        {
          baseName: "fengke01-bian02",
          name: "daobaDownBian02",
        },
        {
          baseName: "dao05",
          name: "daojian",//刀尖
          tipSprite: {
            name: "tip1",
            pos: {
              x: 0.6,
              y: 1
            },
            clone: {
              x: -0.04,
              y: 0.04,
              z: 0.0001
            }
          },
        },
        {
          baseName: "group1",
          name: "zhudaoArr",//主刀+logo
          setObj: {
            direction: "y",
            animaVal: 44,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao06",
          name: "cuodao",//锉刀
          setObj: {
            animaVal: 22,//展开刀动画的最大值
          }
        },
        {
          baseName: "mosha",
          name: "mosha1",//锉刀
          textureImg: {
            "textureType": "normalTexture",
            "smoothness": "0.01",
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GAeLQO1FJvbPQtbvy_!!1080040467.jpg",
            "metallic": "1",
          }
        },
        {
          baseName: "dao03",
          name: "jiaodao",//铰刀
          setObj: {
            animaVal: 20,//展开刀动画的最大值
          },
          tipSprite: {
            name: "tip3",
            pos: {
              x: 0.4,
              y: 1
            },
            clone: {
              x: 0.06,
              y: -0.03,
              z: 0.0001
            }
          },
        },
        {
          baseName: "yaoshihuan",
          name: "yaoshihuan",//钥匙环
          tipSprite: {
            name: "tip2",
            pos: {
              x: 0.6,
              y: 1
            },
          }
        },
      ],
      onLoad: function () {
        console.log("加载完成...");
        let img = {
          "cost": 15,
          "smoothness": "0.5",
          "albedoColor": "0.674,0.147,0.184,1",
          "color": "red",
          "thumb": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01DUyNOl23c00iEeIaW_!!555657275.jpg",
          "name": "红色",
          "metallic": "1",
        };
        img = {
          "bian2Color": "0.500,0.039,0.086,1",
          "cost": 15,
          "albedoColor": "0.670,0.053,0.117,1",
          "smoothness": "0.65",
          "color": "red",
          "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01DUyNOl23c00iEeIaW_!!555657275.jpg",
          "thumb": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01DUyNOl23c00iEeIaW_!!555657275.jpg",
          "bian1Color": "0.500,0.039,0.086,1",
          "name": "红色",
          "metallic": "0.2",
          "shelf": true
        };
        my.Knife.showImg("daobaUp", img);
        my.Knife.showImg("daobaDown", img);
      }
    },
    {
      host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/2/",
      // host: "res/LayaScene_SampleScene/Conventional/",
      sceneUrl: "SampleScene.ls",
      sprite3DName: "2",
      scale: 87,
      tipObj: {
        "zhudao": "",
        "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip5.atlas",
        "yaoshihuan": "",
      },
      startAnimation: {
        x: 0.2,
        stepX: -10,
        y: -0.5,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      frontAnimation: {
        x: 0.2,
        stepX: -10,
        y: -0.5,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      backAnimation: {
        x: -0.7,
        stepX: -10,
        y: 0.4,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0,
      },
      spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
        {
          baseName: "fengke02-gai",
          name: "daobaUp",//刀把上
        },
        {
          baseName: "upFont",
          name: "upFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 26,
              xPer: 0.8,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "downFont",
          name: "downFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: -0.0001
            },
            style: {
              rotate: 0,
              fontSize: 26,
              xPer: 1,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "daoFont",
          name: "daoFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 20,
              xPer: 0.8,
              yPer: 1.15,
              color: "#000",
            }
          }
        },
        {
          baseName: "fengke02-bian01",
          name: "daobaUpBian01",
        },
        {
          baseName: "fengke02-bian02",
          name: "daobaUpBian02",
        },
        {
          baseName: "fengke01-gai",
          name: "daobaDown",//刀把下
        },
        {
          baseName: "fengke01-bian01",
          name: "daobaDownBian01",
        },
        {
          baseName: "fengke01-bian02",
          name: "daobaDownBian02",
        },
        {
          baseName: "dao05",
          name: "daojian",//刀尖
          tipSprite: {
            name: "tip1",
            pos: {
              x: 0.6,
              y: 1
            },
            clone: {
              x: 0.02,
              y: 0.025,
              z: 0.0001
            }
          },
        },
        {
          baseName: "group2",
          name: "zhudaoArr1",//主刀+logo
          setObj: {
            direction: "y",
            defaultStep: -1,
            animaVal: 44,//展开刀动画的值
          }
        },
        {
          baseName: "dao06",
          name: "cuodao",//锉刀
          setObj: {
            defaultStep: -1,
            animaVal: 34,//展开刀动画的值
          }
        },
        {
          baseName: "mosha",
          name: "mosha1",//锉刀
          textureImg: {
            "smoothness": "0.01",
            "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GAeLQO1FJvbPQtbvy_!!1080040467.jpg",
            "metallic": "1",
          }
        },
        {
          baseName: "group1",
          name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
          setObj: {
            direction: "y",
            animaVal: 40,//展开刀动画的最大值
            openDoneName: "jiandao2"
          }
        },
        {
          baseName: "jiandao06",
          name: "jiandao2",//剪刀副刀
          setObj: {
            animaVal: 10,//展开刀动画的最大值
            closeDoneName: "jiandaoArr1"
          }
        },
        {
          baseName: "dao03",
          name: "jiaodao",//铰刀
          setObj: {
            animaVal: 44,//展开刀动画的最大值
          },
          tipSprite: {
            name: "tip3",
            pos: {
              x: 0.4,
              y: 1
            },
            clone: {
              x: -0.05,
              y: 0.052,
              z: 0.0001
            }
          },
        },
        {
          baseName: "yaoshihuan",
          name: "yaoshihuan",//钥匙环
          tipSprite: {
            name: "tip2",
            pos: {
              x: 0.6,
              y: 1
            },
          }
        },
      ],
      onLoad: function () {
        console.log("加载完成...");
      }
    },
    {
      host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/3/",
      // host: "res/LayaScene_SampleScene/Conventional/",
      sceneUrl: "SampleScene.ls",
      sprite3DName: "3",
      scale: 60,
      tipObj: {
        "zhudao": "",
        "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
        "yaoshihuan": "",
      },
      startAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      frontAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      backAnimation: {
        x: -0.7,
        stepX: -10,
        y: 0.4,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0,
      },
      spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
        {
          baseName: "000SBDR-gai",
          name: "daobaUp",//刀把上
        },
        {
          baseName: "upFont",
          name: "upFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.8,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "downFont",
          name: "downFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: -0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.5,
              yPer: 1.25,
            }
          }
        },
        {
          baseName: "daoFont",
          name: "daoFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 24,
              xPer: 0.8,
              yPer: 1.15,
              color: "#000",
            }
          }
        },
        {
          baseName: "000SBDR-bian01",
          name: "daobaUpBian01",
        },
        {
          baseName: "001zSBDR-gai",
          name: "daobaDown",//刀把下
        },
        {
          baseName: "000SBDR-bian02",
          name: "daobaUpBian02",
        },
        {
          baseName: "001zSBDR-bian01",
          name: "daobaDownBian01",
        },
        {
          baseName: "001zSBDR-bian02",
          name: "daobaDownBian02",
        },
        {
          baseName: "dao05",
          name: "daojian",//刀尖
          // setObj: {
          //     animaVal: 44,//展开刀动画的最大值
          // },
          tipSprite: {
            name: "tip1",
            pos: {
              x: 0.6,
              y: 1
            },
            clone: {
              x: -0.01,
              y: 0.075,
              z: 0.02
            }
          },
        },
        {
          baseName: "group2",
          name: "zhudaoArr1",//主刀+logo
          setObj: {
            direction: "y",
            animaVal: 44,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao06",
          name: "xiaodao",//小刀
          setObj: {
            defaultStep: -1,
            animaVal: 40,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao03",
          name: "kaipingqi",//开瓶器
          setObj: {
            animaVal: 90,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao02",
          name: "xiaogaizui",//小一字改锥
          setObj: {
            defaultStep: -1,
            animaVal: 90,//展开刀动画的最大值
          }
        },
        {
          baseName: "polySurface013",
          name: "hongjiuzhuan",//红酒钻
          setObj: {
            defaultStep: -1,
            animaVal: 40,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao1",
          name: "jiaodao",//铰刀
          setObj: {
            defaultStep: -1,
            animaVal: 85,//展开刀动画的最大值
          },
          tipSprite: {
            name: "tip3",
            pos: {
              x: 0.4,
              y: 1
            },
            clone: {
              x: 0,
              y: -0.04,
              z: 0.001
            }
          },
        },
        {
          baseName: "yaoshihuan",
          name: "yaoshihuan",//钥匙环
          tipSprite: {
            name: "tip2",
            pos: {
              x: 0.6,
              y: 1
            },
          }
        },
      ],
      onLoad: function () {
        console.log("加载完成...");
      }
    },
    {
      host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/4/",
      // host: "res/LayaScene_SampleScene/Conventional/",
      sceneUrl: "SampleScene.ls",
      sprite3DName: "4",
      scale: 60,
      tipObj: {
        "zhudao": "",
        "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
        "yaoshihuan": "",
      },
      startAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      frontAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      backAnimation: {
        x: -0.7,//斜向
        stepX: -10,
        y: 0.4,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0,
        /* x: -0.9,//横向
        stepX: -10,
        y: 0.1,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0, */
      },
      spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
        {
          baseName: "000PDZ-gai",
          name: "daobaUp",//刀把上
        },
        {
          baseName: "upFont",
          name: "upFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.8,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "downFont",
          name: "downFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: -0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.5,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "daoFont",
          name: "daoFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 24,
              xPer: 0.8,
              yPer: 1.15,
              color: "#000",
            }
          }
        },
        {
          baseName: "000PDZ-bian01",
          name: "daobaUpBian01",
        },
        {
          baseName: "000PDZ-bian02",
          name: "daobaUpBian02",
        },
        {
          baseName: "001zPDZ-gai",
          name: "daobaDown",//刀把下
        },
        {
          baseName: "001zPDZ-bian01",
          name: "daobaDownBian01",
        },
        {
          baseName: "001zPDZ-bian02",
          name: "daobaDownBian02",
        },
        {
          baseName: "dao05",
          name: "daojian",//刀尖
          // setObj: {
          //     animaVal: 30,//展开刀动画的最大值
          // },
          tipSprite: {
            name: "tip1",
            pos: {
              x: 0.6,
              y: 1
            },
            clone: {
              x: -0.04,
              y: 0.03,
              z: 0.0001
            }
          },
        },
        {
          baseName: "group6",
          name: "zhudaoArr1",//主刀+logo
          setObj: {
            direction: "y",
            animaVal: 30,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao07",
          name: "jiaodao",//铰刀
          setObj: {
            defaultStep: -1,
            animaVal: 85,//展开刀动画的最大值
          },
          tipSprite: {
            name: "tip3",
            pos: {
              x: 0.4,
              y: 1
            },
            clone: {
              x: 0,
              y: -0.04,
              z: 0.001
            }
          },
        },
        {
          baseName: "dao06",
          name: "xiaodao",//小刀
          setObj: {
            defaultStep: -1,
            animaVal: 65,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao02",
          name: "kaipingqi",//开瓶器
          setObj: {
            animaVal: 83,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao04",
          name: "xiaogaizui",//小一字改锥
          setObj: {
            defaultStep: -1,
            animaVal: 85,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao01",
          name: "gouzi",//多用钩
          setObj: {
            defaultStep: -1,
            animaVal: 24,//展开刀动画的最大值
          }
        },
        {
          baseName: "polySurface7",
          name: "hongjiuzhuan",//红酒钻
          setObj: {
            defaultStep: -1,
            animaVal: 50,//展开刀动画的最大值
          }
        },
        {
          baseName: "group5",
          name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
          setObj: {
            direction: "y",
            defaultStep: -1,
            animaVal: 40,//展开刀动画的最大值
            openDoneName: "jiandao2"
          }
        },
        {
          baseName: "jiandao06",
          name: "jiandao2",//剪刀副刀
          setObj: {
            direction: "y",
            defaultStep: -1,
            animaVal: 28,//展开刀动画的最大值
            closeDoneName: "jiandaoArr1"
          }
        },
        {
          baseName: "group5",
          name: "剪刀",//剪刀
          setObj: {
            animaVal: 0,//展开刀动画的最大值
          }
        },
        {
          baseName: "yaoshihuan",
          name: "yaoshihuan",//钥匙环
          tipSprite: {
            name: "tip2",
            pos: {
              x: 0.6,
              y: 1
            },
          }
        },
      ],
      onLoad: function () {
        console.log("加载完成...");
      }
    },
    {
      host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/5/",
      // host: "res/LayaScene_SampleScene/Conventional/",
      sceneUrl: "SampleScene.ls",
      sprite3DName: "5",
      scale: 60,
      tipObj: {
        "zhudao": "",
        "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
        "yaoshihuan": "",
      },
      startAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      frontAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      backAnimation: {
        x: -0.7,
        stepX: -10,
        y: 0.4,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0,
      },
      spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
        {
          baseName: "000CJXBJ-gai",
          name: "daobaUp",//刀把上
        },
        {
          baseName: "upFont",
          name: "upFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.8,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "downFont",
          name: "downFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: -0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.5,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "daoFont",
          name: "daoFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 24,
              xPer: 0.8,
              yPer: 1.15,
              color: "#000",
            }
          }
        },
        {
          baseName: "000CJXBJ-bian01",
          name: "daobaUpBian01",
        },
        {
          baseName: "000CJXBJ-bian02",
          name: "daobaUpBian02",
        },
        {
          baseName: "001zCJXBJ-gai",
          name: "daobaDown",//刀把下
        },
        {
          baseName: "001zCJXBJ-bian01",
          name: "daobaDownBian01",
        },
        {
          baseName: "001zCJXBJ-bian02",
          name: "daobaDownBian02",
        },
        {
          baseName: "dao05",
          name: "daojian",//刀尖，主刀
          // setObj: {
          //     animaVal: 40,//展开刀动画的最大值
          // },
          tipSprite: {
            name: "tip1",
            pos: {
              x: 0.6,
              y: 1
            },
            clone: {
              x: -0.04,
              y: 0.04,
              z: 0.0001
            }
          },
        },
        {
          baseName: "group1",
          name: "zhudaoArr1",//主刀logo
          setObj: {
            direction: "y",
            animaVal: 44,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao07",
          name: "jiaodao",//铰刀
          setObj: {
            defaultStep: -1,
            animaVal: 90,//展开刀动画的最大值
          },
          tipSprite: {
            name: "tip3",
            pos: {
              x: 0.4,
              y: 1
            },
            clone: {
              x: 0,
              y: -0.04,
              z: 0.0001
            }
          },
        },
        {
          baseName: "dao06",
          name: "xiaodao",//小刀
          setObj: {
            defaultStep: -1,
            animaVal: 70,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao02",
          name: "kaipingqi",//开瓶器
          setObj: {
            animaVal: 90,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao01",
          name: "xiaogaizui",//小一字改锥
          setObj: {
            defaultStep: -1,
            animaVal: 86,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao08",
          name: "gouzi",//多用钩
          setObj: {
            defaultStep: -1,
            animaVal: 24,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao016",
          name: "luosidao",//十字螺丝刀
          setObj: {
            defaultStep: -1,
            animaVal: 48,//展开刀动画的最大值
          }
        },
        {
          baseName: "group5",
          name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
          setObj: {
            direction: "y",
            defaultStep: -1,
            animaVal: 40,//展开刀动画的最大值
            openDoneName: "jiandao2"
          }
        },
        {
          baseName: "jiandao06",
          name: "jiandao2",//剪刀
          setObj: {
            direction: "y",
            defaultStep: -1,
            animaVal: 28,//展开刀动画的最大值
            closeDoneName: "jiandaoArr1"
          }
        },
        {
          baseName: "yaoshihuan",
          name: "yaoshihuan",//钥匙环
          tipSprite: {
            name: "tip2",
            pos: {
              x: 0.6,
              y: 1
            },
          }
        },
      ],
      onLoad: function () {
        console.log("加载完成...");
      }
    },
    {
      // host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/6/",
      host: "res/LayaScene_SampleScene/Conventional/",
      sceneUrl: "SampleScene.ls",
      sprite3DName: "6",
      scale: 55,
      tipObj: {
        "zhudao": "",
        "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
        "yaoshihuan": "",
      },
      startAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      frontAnimation: {
        x: 0.15,
        stepX: -10,
        y: 1,
        stepY: -0.1,
        z: 0,
        stepZ: 0,
      },
      backAnimation: {
        x: -0.7,
        stepX: -10,
        y: 0.4,
        stepY: -0.1,
        z: 0.4,
        stepZ: 0,
      },
      spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
        {
          baseName: "000DDJ-gai",
          name: "daobaUp",//刀把上
        },
        {
          baseName: "upFont",
          name: "upFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.8,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "downFont",
          name: "downFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: -0.0001
            },
            style: {
              rotate: 0,
              fontSize: 32,
              xPer: 0.5,
              yPer: 1.15,
            }
          }
        },
        {
          baseName: "daoFont",
          name: "daoFont",
          font: {
            clone: {
              x: 0,
              y: 0,
              z: 0.0001
            },
            style: {
              rotate: 0,
              fontSize: 24,
              xPer: 0.8,
              yPer: 1.15,
              color: "#000",
            }
          }
        },
        {
          baseName: "000DDJ-bian01",
          name: "daobaUpBian01",
        },
        {
          baseName: "000DDJ-bian02",
          name: "daobaUpBian02",
        },
        {
          baseName: "001zDDJ-gai",
          name: "daobaDown",//刀把下
        },
        {
          baseName: "001zDDJ-bian01",
          name: "daobaDownBian01",
        },
        {
          baseName: "001zDDJ-bian02",
          name: "daobaDownBian02",
        },
        {
          baseName: "dao07",
          name: "daojian",//刀尖，主刀
          // setObj: {
          //     animaVal: 50,//展开刀动画的最大值
          // },
          tipSprite: {
            name: "tip1",
            pos: {
              x: 0.6,
              y: 1
            },
            clone: {
              x: -0.02,
              y: 0.04,
              z: 0.0001
            }
          },
        },
        {
          baseName: "group1",
          name: "zhudaoArr1",//主刀+logo
          setObj: {
            direction: "y",
            animaVal: 54,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao03",
          name: "jiaodao",//铰刀
          setObj: {
            defaultStep: -1,
            animaVal: 90,//展开刀动画的最大值
          },
          tipSprite: {
            name: "tip3",
            pos: {
              x: 0.4,
              y: 1
            },
            clone: {
              x: 0,
              y: -0.04,
              z: 0.0001
            }
          },
        },
        {
          baseName: "dao06",
          name: "xiaodao",//小刀
          setObj: {
            defaultStep: -1,
            animaVal: 120,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao05",
          name: "kaipingqi",//开瓶器
          setObj: {
            animaVal: 110,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao04",
          name: "xiaogaizui",//小一字改锥
          setObj: {
            defaultStep: -1,
            animaVal: 126,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao01",
          name: "gouzi",//多用钩
          setObj: {
            defaultStep: -1,
            animaVal: 22,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao12",
          name: "luosidao",//十字螺丝刀
          setObj: {
            defaultStep: -1,
            animaVal: 44,//展开刀动画的最大值
          }
        },
        {
          baseName: "dao02",
          name: "juzi",//锯子
          setObj: {
            defaultStep: -1,
            animaVal: 66,//展开刀动画的最大值
          }
        },
        {
          baseName: "group5",
          name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
          setObj: {
            direction: "y",
            defaultStep: -1,
            animaVal: 58,//展开刀动画的最大值
            openDoneName: "jiandao2"
          }
        },
        {
          baseName: "jiandao06",
          name: "jiandao2",//剪刀
          setObj: {
            defaultStep: -1,
            direction: "y",
            animaVal: 28,//展开刀动画的最大值
            closeDoneName: "jiandaoArr1"
          }
        },
        {
          baseName: "yaoshihuan",
          name: "yaoshihuan",//钥匙环
          tipSprite: {
            name: "tip2",
            pos: {
              x: 0.6,
              y: 1
            },
          }
        },
      ],
      onLoad: function () {
        console.log("加载完成...");
      }
    }
  ]
1.初始化场景
my.Knife.loadScene({
  sceneUrl: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201019/1/SampleScene.ls",
  startAnimation: {
    x: 0.5,
    stepX: -10,
    y: -0.4,
    stepY: -0.1,
    z: 0,
    stepZ: 0,
  },
  spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
    {
      baseName: "sihaoyuan:sihaoyuan:sihaoyuan:sihaoyuan:fengke02-1",
      name: "daobaUp",//刀把上
      font: {
        clone: {
          x: 0,
          y: 0,
          z: 0.0001
        },
        style: {
          rotate: 90,
          fontSize: 36,
          xPer: 1.14,
          yPer: 0.38,
        }
      }
    },
    {
      baseName: "sihaoyuan:sihaoyuan:sihaoyuan:sihaoyuan:fengke01",
      name: "daobaDown",//刀把下
      font: {
        clone: {
          x: 0,
          y: 0,
          z: -0.0001
        },
        style: {
          rotate: 90,
          fontSize: 36,
          xPer: 1.14,
          yPer: 0.38,
        }
      }
    },
    {
      baseName: "sihaoyuan:sihaoyuan:sihaoyuan:sihaoyuan:dao05",
      name: "daojian",//刀尖
      tipSprite: {
        name: "tip1",
        pos: {
          x: 0.6,
          y: 1
        },
        clone: {
          x: -0.04,
          y: 0.04,
          z: 0.0001
        }
      },
      font: {
        clone: {
          x: 0,
          y: 0,
          z: 0.0001
        },
        style: {
          rotate: 90,
          fontSize: 36,
          xPer: 1.14,
          yPer: 0.98,
          color: "#000",
        }
      }
    },
    {
      baseName: "group1",
      name: "zhudaoArr",//主刀+logo
      setObj: {
        direction: "y",
        animaVal: 44,//展开刀动画的最大值
      }
    },
    {
      baseName: "ZJD:xiaoyaopai:xiaoyaopai:xiaoyaopai:xiaoyaopai:xiaoyaopai:xiaoyaopai:zujian:dao06",
      name: "cuodao",//锉刀
      setObj: {
        animaVal: 22,//展开刀动画的最大值
      }
    },
    {
      baseName: "sihaoyuan:sihaoyuan:sihaoyuan:sihaoyuan:dao03",
      name: "jiaodao",//铰刀
      setObj: {
        animaVal: 20,//展开刀动画的最大值
      },
      tipSprite: {
        name: "tip3",
        pos: {
          x: 0.4,
          y: 1
        },
        clone: {
          x: 0.06,
          y: -0.03,
          z: 0.0001
        }
      },
      textureImg: {
        // 贴图
        src: "res/1.jpg",
      }
    },
    {
      baseName: "sihaoyuan:sihaoyuan:sihaoyuan:sihaoyuan:yaoshihuan",
      name: "yaoshihuan",//钥匙环
      tipSprite: {
        name: "tip2",
        pos: {
          x: 0.6,
          y: 1
        },
      }
    },
  ],
  onLoad: function () {
    console.log("加载完成...");
  }
});
2.文字
my.Knife.addFont("daobaUp", {
  rotate: 90,
  fontSize: 36,
  xPer: 1.14,
  yPer: 0.38,
  text: "我是文字" + num
});
3.贴图
my.Knife.showImg("jiaodao", "res/2.jpg");

```

- xaml

```
  <gm-knife onInit="onInit" />
```