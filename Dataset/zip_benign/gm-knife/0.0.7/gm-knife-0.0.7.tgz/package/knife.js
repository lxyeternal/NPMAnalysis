var touchstartCB;
var touchcancelCB;
var touchendCB;
var touchmoveCB;

// $global.window.canvas.$realCanvas //创建的canvas对象
Component({
  mixins: [],
  data: {},
  props: {},
  didMount() { },
  didUpdate() { },
  didUnmount() {
    $global.window.cancelAnimationFrame();
    $global.$isAdapterInjected = false;
    $global.window = null;
    my.Knife = null;
  },
  methods: {
    onTouchStart(e) {
      // console.log("touch start",e);
      touchstartCB && touchstartCB(e)
    },
    onTouchCancel(e) {
      // console.log("touch cancel",e)
      touchcancelCB && touchcancelCB(e)
    },
    onTouchEnd(e) {
      // console.log("touch end",e)
      touchendCB && touchendCB(e)
    },
    onTouchMove(e) {
      // console.log("touch move",e);
      touchmoveCB && touchmoveCB(e)
    },
    canvasOnReady() {
      my.onTouchStart = function (cb) {
        touchstartCB = cb;
      }
      my.onTouchCancel = function (cb) {
        touchcancelCB = cb;
      }
      my.onTouchEnd = function (cb) {
        touchendCB = cb;
      }
      my.onTouchMove = function (cb) {
        touchmoveCB = cb;
      }

      this.deleteCacheFun("gm-knife/adapter.js");
      require("./layaengine/adapter.js");
      this.deleteCacheFun("gm-knife/laya.tbmini.min.js");
      require("./layaengine/libs/min/laya.tbmini.min.js");
      this.deleteCacheFun("gm-knife/index.js");
      require("./index.js");

      this.checkKnife();
    },
    deleteCacheFun(endStr) {
      if (!endStr) { return false; }
      let cacheArr = require.cache || {};
      for (let name in cacheArr) {
        if (name.lastIndexOf(endStr) == (name.length - endStr.length)) {
          // 查找到endStr
          delete require.cache[name];
        }
      }
    },
    getWin() {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.getSystemInfo({
          success(res) {
            resolve(res);
          }
        });
      })
    },
    dom(className) {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.createSelectorQuery()
          .select(className)
          .boundingClientRect()
          .exec(([ret]) => {
            if (ret) {
              result.success = true;
              result.data = ret;
            } else {
              result.success = false;
            }
            resolve(result);
          })
      })
    },
    async checkKnife() {
      clearTimeout(this.checkTimer);
      console.log("检测knife...")
      if (!!my.Knife) {
        my.Knife.getCanvasImg = this.getCanvasImg;
        let domData = await this.dom(".canvas-element");
        let win = await this.getWin();
        let dom = domData.data;
        dom.winW = win.windowWidth;
        dom.winH = win.windowHeight;
        my.canvas_dom = dom;

        try {
          this.props.onInit();
        } catch (e) { }
      } else {
        this.checkTimer = setTimeout(() => {
          this.checkKnife();
        }, 50)
      }
    },
    getCanvasImg() {
      return new Promise(function (resolve, reject) {
        let canvas = $global.window.canvas.$realCanvas;
        canvas.toTempFilePath({
          x: 0,
          y: 0,
          width: canvas.width - 10,
          destWidth: canvas.width - 10,
          height: canvas.height - 10,
          destHeight: canvas.height - 10,
          saveToPhotosAlbum: true,
          fileType: "png",
          success: (res) => {
            // res.apFilePath
            resolve(res.apFilePath);
            /* my.alert({ content: res.apFilePath });
            this.setData({
              picSrc: res.apFilePath
            }) */
          },
          fail: (res) => {
            my.alert({ content: JSON.stringify(res) });
            reject(res);
          }
        });
      })
    }
  },
});