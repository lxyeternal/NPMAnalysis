/**
 * 设置LayaNative屏幕方向，可设置以下值
 * landscape           横屏
 * portrait            竖屏
 * sensor_landscape    横屏(双方向)
 * sensor_portrait     竖屏(双方向)
 */
/**window.screenOrientation = "sensor_landscape";*/

function deleteCacheFun(endStr) {
  if (!endStr) { return false; }
  let cacheArr = require.cache || {};
  for (let name in cacheArr) {
    if (name.lastIndexOf(endStr) == (name.length - endStr.length)) {
      // 查找到endStr
      delete require.cache[name];
    }
  }
}
// ----- libs - begin-----
deleteCacheFun("laya.core.min.js");
require("./layaengine/libs/min/laya.core.min.js");
deleteCacheFun("laya.ui.min.js");
require("./layaengine/libs/min/laya.ui.min.js");
deleteCacheFun("laya.d3.min.js");
require("./layaengine/libs/min/laya.d3.min.js")
deleteCacheFun("laya.physics3D.min.js");
require("./layaengine/libs/min/laya.physics3D.min.js")
//-----libs-end-------
deleteCacheFun("bundle.js");
require("./js/bundle.js");