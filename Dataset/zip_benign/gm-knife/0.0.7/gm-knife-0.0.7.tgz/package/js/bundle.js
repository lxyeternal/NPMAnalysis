var window = $global.window;
var document = window.document;
var XMLHttpRequest = window.XMLHttpRequest;
var Laya = window.Laya;
var Laya3D = window.Laya3D;
(function () {
  'use strict';

  class RotationScript extends Laya.Script3D {
    constructor() {
      super();
      this._mouseDown = false;

      this._lastMouseY = 0.0;
      this._rotate = new Laya.Vector3();

      this._lastMouseX = 0.0;
      this._rotate1 = new Laya.Vector3();

      this.lastPosition = new Laya.Vector2(0, 0);
      this.distance = 0.0;
      this.disVector1 = new Laya.Vector2(0, 0);
      this.disVector2 = new Laya.Vector2(0, 0);
      this.isTwoTouch = false;
      this.first = true;
      this.twoFirst = true;
      this.sprite3DSacle = new Laya.Vector3(0, 0, 0);

      this.baseScale = 0;
      this.maxScale = 2;
      this.minScale = 0.8;

      this.model = null;
      this.scene = null;

      this.meshSprite = null;
    }

    onAwake() {
      this.meshSprite = this.owner;
    }

    onUpdate() {
      if (!this.tip2Ani || !this.tip2Ani.visible) { return false; }
      let touchCount = this.scene.input.touchCount();
      if (1 === touchCount) {
        //判断是否为两指触控，撤去一根手指后引发的touchCount===1
        if (this.isTwoTouch) {
          return;
        }
        //获取当前的触控点，数量为1
        let touch = this.scene.input.getTouch(0);
        //是否为新一次触碰，并未发生移动
        if (this.first) {
          //获取触碰点的位置
          this.lastPosition.x = touch._position.x;
          this.lastPosition.y = touch._position.y;
          this.first = false;
        } else {
          //移动触碰点
          let deltaY = touch._position.y - this.lastPosition.y;
          let deltaX = touch._position.x - this.lastPosition.x;
          this.lastPosition.x = touch._position.x;
          this.lastPosition.y = touch._position.y;
          //根据移动的距离进行旋转
          this._rotate.setValue(-deltaY / 4, 0, 0);
          this._rotate1.setValue(0, deltaX / 4, 0);
          this.model.transform.rotate(this._rotate, false, false);
          this.model.transform.rotate(this._rotate1, true, false);
        }
      } else if (2 === touchCount) {
        this.isTwoTouch = true;
        //获取两个触碰点
        let touch = this.scene.input.getTouch(0);
        let touch2 = this.scene.input.getTouch(1);
        //是否为新一次触碰，并未发生移动
        if (this.twoFirst) {
          //获取触碰点的位置
          this.disVector1.x = touch.position.x - touch2.position.x;
          this.disVector1.y = touch.position.y - touch2.position.y;
          this.distance = Laya.Vector2.scalarLength(this.disVector1);
          this.sprite3DSacle = this.model.transform.scale;
          this.twoFirst = false;
        } else {
          this.disVector2.x = touch.position.x - touch2.position.x;
          this.disVector2.y = touch.position.y - touch2.position.y;
          let distance2 = Laya.Vector2.scalarLength(this.disVector2);
          //根据移动的距离进行缩放
          let factor = 0.6 * (distance2 - this.distance);
          if (!this.baseScale) {
            this.baseScale = this.sprite3DSacle.x;
          }
          this.sprite3DSacle.x += factor;
          this.sprite3DSacle.y += factor;
          this.sprite3DSacle.z += factor;
          if (this.minScale < this.sprite3DSacle.x / this.baseScale && this.sprite3DSacle.x / this.baseScale < this.maxScale) {
            this.model.transform.scale = this.sprite3DSacle;
          }
          this.distance = distance2;
        }
      } else if (0 === touchCount) {
        this.first = true;
        this.twoFirst = true;
        this.lastPosition.x = 0;
        this.lastPosition.y = 0;
        this.isTwoTouch = false;
      }
      if (touchCount != 0) {
        this.loadedAllTip();
      }
    }

    loadedAllTip() {
      this.loadedTip("tip1");
      this.loadedTip("tip2");
      this.loadedTip("tip3");
    }

    loadedTip(name) {
      if (!!this[`${name}`]) {
        let val = this.WorldToScreen2(this[`${name}`].transform.position);
        let x = val.x;
        let y = val.y;

        let pos = this[`${name}`].pos || { x: 0, y: 0 };
        try {
          let bounds = this[`${name}Ani`].getBounds();
          if (name == "tip1") {
            x = x - pos.x * bounds.width;
            y = y - pos.y * bounds.height / 2;
          } else if (name == "tip2") {
            x = x - pos.x * bounds.width;
            y = y - pos.y * bounds.height / 2;
          } else if (name == "tip3") {
            x = x - pos.x * bounds.width + 50;
            y = y - pos.y * bounds.height / 2;
          }

          this[`${name}Ani`].pos(x, y);
        } catch (e) { }
      }
    }

    WorldToScreen2(point) {
      let camera = this.camera;

      var out = new Laya.Vector3();
      camera.viewport.project(point, camera.projectionViewMatrix, out);
      var value = new Laya.Vector3(out.x / Laya.stage.clientScaleX, out.y / Laya.stage.clientScaleY, 0);
      return value;
    }
  }
  class Knife {
    constructor() {
      let bl = true;
      try {
        my.Knife = this;
        bl = !false;
      } catch (e) { }
      if (!!bl) {
        // 1.读取场景
        let sceneArr = [
          {
            host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/test-model/1/",
            // host: "res/LayaScene_SampleScene/Conventional/",
            sceneUrl: "SampleScene.ls",
            sprite3DName: "1",
            scale: 87,
            tipObj: {
              "zhudao": "",
              "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip4.atlas",
              "yaoshihuan": "",
            },
            startAnimation: {
              x: 0.2,
              stepX: -10,
              y: -0.5,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            frontAnimation: {
              x: 0.2,
              stepX: -10,
              y: -0.5,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            backAnimation: {
              x: -0.7,
              stepX: -10,
              y: 0.4,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0,
            },
            spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
              {
                baseName: "fengke02-1-gai",
                name: "daobaUp",//刀把上
              },
              {
                baseName: "upFont",
                name: "upFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 26,
                    xPer: 0.8,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "downFont",
                name: "downFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: -0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 26,
                    xPer: 1,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "daoFont",
                name: "daoFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 20,
                    xPer: 0.8,
                    yPer: 1.15,
                    color: "#000",
                  }
                }
              },
              {
                baseName: "fengke02-1-bian01",
                name: "daobaUpBian01",
              },
              {
                baseName: "fengke02-1-bian02",
                name: "daobaUpBian02",
              },
              {
                baseName: "fengke01-gai",
                name: "daobaDown",//刀把下
              },
              {
                baseName: "fengke01-bian01",
                name: "daobaDownBian01",
              },
              {
                baseName: "fengke01-bian02",
                name: "daobaDownBian02",
              },
              {
                baseName: "dao05",
                name: "daojian",//刀尖
                tipSprite: {
                  name: "tip1",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                  clone: {
                    x: -0.04,
                    y: 0.04,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "group1",
                name: "zhudaoArr",//主刀+logo
                setObj: {
                  direction: "y",
                  animaVal: 44,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao06",
                name: "cuodao",//锉刀
                setObj: {
                  animaVal: 22,//展开刀动画的最大值
                }
              },
              {
                baseName: "mosha",
                name: "mosha1",//锉刀
                textureImg: {
                  "textureType": "normalTexture",
                  "smoothness": "0.01",
                  "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GAeLQO1FJvbPQtbvy_!!1080040467.jpg",
                  "metallic": "1",
                }
              },
              {
                baseName: "dao03",
                name: "jiaodao",//铰刀
                setObj: {
                  animaVal: 20,//展开刀动画的最大值
                },
                tipSprite: {
                  name: "tip3",
                  pos: {
                    x: 0.4,
                    y: 1
                  },
                  clone: {
                    x: 0.06,
                    y: -0.03,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "yaoshihuan",
                name: "yaoshihuan",//钥匙环
                tipSprite: {
                  name: "tip2",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                }
              },
            ],
            onLoad: function () {
              console.log("加载完成...");
            }
          },
          {
            // host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/2/",
            host: "res/LayaScene_SampleScene/Conventional/",
            sceneUrl: "SampleScene.ls",
            sprite3DName: "2",
            scale: 87,
            tipObj: {
              "zhudao": "",
              "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip5.atlas",
              "yaoshihuan": "",
            },
            startAnimation: {
              x: 0.2,
              stepX: -10,
              y: -0.5,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            frontAnimation: {
              x: 0.2,
              stepX: -10,
              y: -0.5,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            backAnimation: {
              x: -0.7,
              stepX: -10,
              y: 0.4,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0,
            },
            spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
              {
                baseName: "fengke02-gai",
                name: "daobaUp",//刀把上
              },
              {
                baseName: "upFont",
                name: "upFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 26,
                    xPer: 0.8,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "downFont",
                name: "downFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: -0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 26,
                    xPer: 1,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "daoFont",
                name: "daoFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 20,
                    xPer: 0.8,
                    yPer: 1.15,
                    color: "#000",
                  }
                }
              },
              {
                baseName: "fengke02-bian01",
                name: "daobaUpBian01",
              },
              {
                baseName: "fengke02-bian02",
                name: "daobaUpBian02",
              },
              {
                baseName: "fengke01-gai",
                name: "daobaDown",//刀把下
              },
              {
                baseName: "fengke01-bian01",
                name: "daobaDownBian01",
              },
              {
                baseName: "fengke01-bian02",
                name: "daobaDownBian02",
              },
              {
                baseName: "dao05",
                name: "daojian",//刀尖
                tipSprite: {
                  name: "tip1",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                  clone: {
                    x: 0.02,
                    y: 0.025,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "group2",
                name: "zhudaoArr1",//主刀+logo
                setObj: {
                  direction: "y",
                  defaultStep: -1,
                  animaVal: 44,//展开刀动画的值
                }
              },
              {
                baseName: "dao06",
                name: "cuodao",//锉刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 34,//展开刀动画的值
                }
              },
              {
                baseName: "mosha",
                name: "mosha1",//锉刀
                textureImg: {
                  "smoothness": "0.01",
                  "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GAeLQO1FJvbPQtbvy_!!1080040467.jpg",
                  "metallic": "1",
                }
              },
              {
                baseName: "group1",
                name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
                setObj: {
                  direction: "y",
                  animaVal: 40,//展开刀动画的最大值
                  openDoneName: "jiandao2"
                }
              },
              {
                baseName: "jiandao06",
                name: "jiandao2",//剪刀副刀
                setObj: {
                  animaVal: 10,//展开刀动画的最大值
                  closeDoneName: "jiandaoArr1"
                }
              },
              {
                baseName: "dao03",
                name: "jiaodao",//铰刀
                setObj: {
                  animaVal: 44,//展开刀动画的最大值
                },
                tipSprite: {
                  name: "tip3",
                  pos: {
                    x: 0.4,
                    y: 1
                  },
                  clone: {
                    x: -0.05,
                    y: 0.052,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "yaoshihuan",
                name: "yaoshihuan",//钥匙环
                tipSprite: {
                  name: "tip2",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                }
              },
            ],
            onLoad: function () {
              console.log("加载完成...");
            }
          },
          {
            // host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/3/",
            host: "res/LayaScene_SampleScene/Conventional/",
            sceneUrl: "SampleScene.ls",
            sprite3DName: "3",
            scale: 60,
            tipObj: {
              "zhudao": "",
              "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
              "yaoshihuan": "",
            },
            startAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            frontAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            backAnimation: {
              x: -0.7,
              stepX: -10,
              y: 0.4,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0,
            },
            spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
              {
                baseName: "000SBDR-gai",
                name: "daobaUp",//刀把上
              },
              {
                baseName: "upFont",
                name: "upFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.8,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "downFont",
                name: "downFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: -0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.5,
                    yPer: 1.25,
                  }
                }
              },
              {
                baseName: "daoFont",
                name: "daoFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 24,
                    xPer: 0.8,
                    yPer: 1.15,
                    color: "#000",
                  }
                }
              },
              {
                baseName: "000SBDR-bian01",
                name: "daobaUpBian01",
              },
              {
                baseName: "001zSBDR-gai",
                name: "daobaDown",//刀把下
              },
              {
                baseName: "000SBDR-bian02",
                name: "daobaUpBian02",
              },
              {
                baseName: "001zSBDR-bian01",
                name: "daobaDownBian01",
              },
              {
                baseName: "001zSBDR-bian02",
                name: "daobaDownBian02",
              },
              {
                baseName: "dao05",
                name: "daojian",//刀尖
                // setObj: {
                //     animaVal: 44,//展开刀动画的最大值
                // },
                tipSprite: {
                  name: "tip1",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                  clone: {
                    x: -0.01,
                    y: 0.075,
                    z: 0.02
                  }
                },
              },
              {
                baseName: "group2",
                name: "zhudaoArr1",//主刀+logo
                setObj: {
                  direction: "y",
                  animaVal: 44,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao06",
                name: "xiaodao",//小刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 40,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao03",
                name: "kaipingqi",//开瓶器
                setObj: {
                  animaVal: 90,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao02",
                name: "xiaogaizui",//小一字改锥
                setObj: {
                  defaultStep: -1,
                  animaVal: 90,//展开刀动画的最大值
                }
              },
              {
                baseName: "polySurface013",
                name: "hongjiuzhuan",//红酒钻
                setObj: {
                  defaultStep: -1,
                  animaVal: 40,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao1",
                name: "jiaodao",//铰刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 85,//展开刀动画的最大值
                },
                tipSprite: {
                  name: "tip3",
                  pos: {
                    x: 0.4,
                    y: 1
                  },
                  clone: {
                    x: 0,
                    y: -0.04,
                    z: 0.001
                  }
                },
              },
              {
                baseName: "yaoshihuan",
                name: "yaoshihuan",//钥匙环
                tipSprite: {
                  name: "tip2",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                }
              },
            ],
            onLoad: function () {
              console.log("加载完成...");
            }
          },
          {
            // host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/4/",
            host: "res/LayaScene_SampleScene/Conventional/",
            sceneUrl: "SampleScene.ls",
            sprite3DName: "4",
            scale: 60,
            tipObj: {
              "zhudao": "",
              "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
              "yaoshihuan": "",
            },
            startAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            frontAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            backAnimation: {
              x: -0.7,//斜向
              stepX: -10,
              y: 0.4,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0,
              /* x: -0.9,//横向
              stepX: -10,
              y: 0.1,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0, */
            },
            spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
              {
                baseName: "000PDZ-gai",
                name: "daobaUp",//刀把上
              },
              {
                baseName: "upFont",
                name: "upFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.8,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "downFont",
                name: "downFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: -0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.5,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "daoFont",
                name: "daoFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 24,
                    xPer: 0.8,
                    yPer: 1.15,
                    color: "#000",
                  }
                }
              },
              {
                baseName: "000PDZ-bian01",
                name: "daobaUpBian01",
              },
              {
                baseName: "000PDZ-bian02",
                name: "daobaUpBian02",
              },
              {
                baseName: "001zPDZ-gai",
                name: "daobaDown",//刀把下
              },
              {
                baseName: "001zPDZ-bian01",
                name: "daobaDownBian01",
              },
              {
                baseName: "001zPDZ-bian02",
                name: "daobaDownBian02",
              },
              {
                baseName: "dao05",
                name: "daojian",//刀尖
                // setObj: {
                //     animaVal: 30,//展开刀动画的最大值
                // },
                tipSprite: {
                  name: "tip1",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                  clone: {
                    x: -0.04,
                    y: 0.03,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "group6",
                name: "zhudaoArr1",//主刀+logo
                setObj: {
                  direction: "y",
                  animaVal: 30,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao07",
                name: "jiaodao",//铰刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 85,//展开刀动画的最大值
                },
                tipSprite: {
                  name: "tip3",
                  pos: {
                    x: 0.4,
                    y: 1
                  },
                  clone: {
                    x: 0,
                    y: -0.04,
                    z: 0.001
                  }
                },
              },
              {
                baseName: "dao06",
                name: "xiaodao",//小刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 65,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao02",
                name: "kaipingqi",//开瓶器
                setObj: {
                  animaVal: 83,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao04",
                name: "xiaogaizui",//小一字改锥
                setObj: {
                  defaultStep: -1,
                  animaVal: 85,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao01",
                name: "gouzi",//多用钩
                setObj: {
                  defaultStep: -1,
                  animaVal: 24,//展开刀动画的最大值
                }
              },
              {
                baseName: "polySurface7",
                name: "hongjiuzhuan",//红酒钻
                setObj: {
                  defaultStep: -1,
                  animaVal: 50,//展开刀动画的最大值
                }
              },
              {
                baseName: "group5",
                name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
                setObj: {
                  direction: "y",
                  defaultStep: -1,
                  animaVal: 40,//展开刀动画的最大值
                  openDoneName: "jiandao2"
                }
              },
              {
                baseName: "jiandao06",
                name: "jiandao2",//剪刀副刀
                setObj: {
                  direction: "y",
                  defaultStep: -1,
                  animaVal: 28,//展开刀动画的最大值
                  closeDoneName: "jiandaoArr1"
                }
              },
              {
                baseName: "group5",
                name: "剪刀",//剪刀
                setObj: {
                  animaVal: 0,//展开刀动画的最大值
                }
              },
              {
                baseName: "yaoshihuan",
                name: "yaoshihuan",//钥匙环
                tipSprite: {
                  name: "tip2",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                }
              },
            ],
            onLoad: function () {
              console.log("加载完成...");
            }
          },
          {
            // host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/5/",
            host: "res/LayaScene_SampleScene/Conventional/",
            sceneUrl: "SampleScene.ls",
            sprite3DName: "5",
            scale: 60,
            tipObj: {
              "zhudao": "",
              "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
              "yaoshihuan": "",
            },
            startAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            frontAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            backAnimation: {
              x: -0.7,
              stepX: -10,
              y: 0.4,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0,
            },
            spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
              {
                baseName: "000CJXBJ-gai",
                name: "daobaUp",//刀把上
              },
              {
                baseName: "upFont",
                name: "upFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.8,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "downFont",
                name: "downFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: -0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.5,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "daoFont",
                name: "daoFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 24,
                    xPer: 0.8,
                    yPer: 1.15,
                    color: "#000",
                  }
                }
              },
              {
                baseName: "000CJXBJ-bian01",
                name: "daobaUpBian01",
              },
              {
                baseName: "000CJXBJ-bian02",
                name: "daobaUpBian02",
              },
              {
                baseName: "001zCJXBJ-gai",
                name: "daobaDown",//刀把下
              },
              {
                baseName: "001zCJXBJ-bian01",
                name: "daobaDownBian01",
              },
              {
                baseName: "001zCJXBJ-bian02",
                name: "daobaDownBian02",
              },
              {
                baseName: "dao05",
                name: "daojian",//刀尖，主刀
                // setObj: {
                //     animaVal: 40,//展开刀动画的最大值
                // },
                tipSprite: {
                  name: "tip1",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                  clone: {
                    x: -0.04,
                    y: 0.04,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "group1",
                name: "zhudaoArr1",//主刀logo
                setObj: {
                  direction: "y",
                  animaVal: 44,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao07",
                name: "jiaodao",//铰刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 90,//展开刀动画的最大值
                },
                tipSprite: {
                  name: "tip3",
                  pos: {
                    x: 0.4,
                    y: 1
                  },
                  clone: {
                    x: 0,
                    y: -0.04,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "dao06",
                name: "xiaodao",//小刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 70,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao02",
                name: "kaipingqi",//开瓶器
                setObj: {
                  animaVal: 90,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao01",
                name: "xiaogaizui",//小一字改锥
                setObj: {
                  defaultStep: -1,
                  animaVal: 86,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao08",
                name: "gouzi",//多用钩
                setObj: {
                  defaultStep: -1,
                  animaVal: 24,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao016",
                name: "luosidao",//十字螺丝刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 48,//展开刀动画的最大值
                }
              },
              {
                baseName: "group5",
                name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
                setObj: {
                  direction: "y",
                  defaultStep: -1,
                  animaVal: 40,//展开刀动画的最大值
                  openDoneName: "jiandao2"
                }
              },
              {
                baseName: "jiandao06",
                name: "jiandao2",//剪刀
                setObj: {
                  direction: "y",
                  defaultStep: -1,
                  animaVal: 28,//展开刀动画的最大值
                  closeDoneName: "jiandaoArr1"
                }
              },
              {
                baseName: "yaoshihuan",
                name: "yaoshihuan",//钥匙环
                tipSprite: {
                  name: "tip2",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                }
              },
            ],
            onLoad: function () {
              console.log("加载完成...");
            }
          },
          {
            host: "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/20201204/6/",
            // host: "res/LayaScene_SampleScene/Conventional/",
            sceneUrl: "SampleScene.ls",
            sprite3DName: "6",
            scale: 55,
            tipObj: {
              "zhudao": "",
              "jiaodao": "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas",
              "yaoshihuan": "",
            },
            startAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            frontAnimation: {
              x: 0.15,
              stepX: -10,
              y: 1,
              stepY: -0.1,
              z: 0,
              stepZ: 0,
            },
            backAnimation: {
              x: -0.7,
              stepX: -10,
              y: 0.4,
              stepY: -0.1,
              z: 0.4,
              stepZ: 0,
            },
            spriteArr: [//和模型对应的元素精灵名称 {"模型元素name"：{"放在全局的精灵name 和对应的参数"}}
              {
                baseName: "000DDJ-gai",
                name: "daobaUp",//刀把上
              },
              {
                baseName: "upFont",
                name: "upFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.8,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "downFont",
                name: "downFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: -0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 32,
                    xPer: 0.5,
                    yPer: 1.15,
                  }
                }
              },
              {
                baseName: "daoFont",
                name: "daoFont",
                font: {
                  clone: {
                    x: 0,
                    y: 0,
                    z: 0.0001
                  },
                  style: {
                    rotate: 0,
                    fontSize: 24,
                    xPer: 0.8,
                    yPer: 1.15,
                    color: "#000",
                  }
                }
              },
              {
                baseName: "000DDJ-bian01",
                name: "daobaUpBian01",
              },
              {
                baseName: "000DDJ-bian02",
                name: "daobaUpBian02",
              },
              {
                baseName: "001zDDJ-gai",
                name: "daobaDown",//刀把下
              },
              {
                baseName: "001zDDJ-bian01",
                name: "daobaDownBian01",
              },
              {
                baseName: "001zDDJ-bian02",
                name: "daobaDownBian02",
              },
              {
                baseName: "dao07",
                name: "daojian",//刀尖，主刀
                // setObj: {
                //     animaVal: 50,//展开刀动画的最大值
                // },
                tipSprite: {
                  name: "tip1",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                  clone: {
                    x: -0.02,
                    y: 0.04,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "group1",
                name: "zhudaoArr1",//主刀+logo
                setObj: {
                  direction: "y",
                  animaVal: 54,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao03",
                name: "jiaodao",//铰刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 90,//展开刀动画的最大值
                },
                tipSprite: {
                  name: "tip3",
                  pos: {
                    x: 0.4,
                    y: 1
                  },
                  clone: {
                    x: 0,
                    y: -0.04,
                    z: 0.0001
                  }
                },
              },
              {
                baseName: "dao06",
                name: "xiaodao",//小刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 120,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao05",
                name: "kaipingqi",//开瓶器
                setObj: {
                  animaVal: 110,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao04",
                name: "xiaogaizui",//小一字改锥
                setObj: {
                  defaultStep: -1,
                  animaVal: 126,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao01",
                name: "gouzi",//多用钩
                setObj: {
                  defaultStep: -1,
                  animaVal: 22,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao12",
                name: "luosidao",//十字螺丝刀
                setObj: {
                  defaultStep: -1,
                  animaVal: 44,//展开刀动画的最大值
                }
              },
              {
                baseName: "dao02",
                name: "juzi",//锯子
                setObj: {
                  defaultStep: -1,
                  animaVal: 66,//展开刀动画的最大值
                }
              },
              {
                baseName: "group5",
                name: "jiandaoArr1",//剪刀整体---------------------------------------------------------------------
                setObj: {
                  direction: "y",
                  defaultStep: -1,
                  animaVal: 58,//展开刀动画的最大值
                  openDoneName: "jiandao2"
                }
              },
              {
                baseName: "jiandao06",
                name: "jiandao2",//剪刀
                setObj: {
                  defaultStep: -1,
                  direction: "y",
                  animaVal: 28,//展开刀动画的最大值
                  closeDoneName: "jiandaoArr1"
                }
              },
              {
                baseName: "yaoshihuan",
                name: "yaoshihuan",//钥匙环
                tipSprite: {
                  name: "tip2",
                  pos: {
                    x: 0.6,
                    y: 1
                  },
                }
              },
            ],
            onLoad: function () {
              console.log("加载完成...");
            }
          }
        ];
        let textureImgs = [
          {
            "bian2Color": "0.500,0.039,0.086,1",
            "cost": 15,
            "albedoColor": "0.670,0.053,0.117,1",
            "smoothness": "0.65",
            "color": "red",
            "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01DUyNOl23c00iEeIaW_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01DUyNOl23c00iEeIaW_!!555657275.jpg",
            "bian1Color": "0.500,0.039,0.086,1",
            "name": "红色",
            "metallic": "0.2",
            "shelf": true
          },
          {
            "albedoColor": "1,0,0,0.7",
            "cost": 15,
            "color": "transRed",
            "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01kQhQSY23c00vfbVoL_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01kQhQSY23c00vfbVoL_!!555657275.jpg",
            "bianMetallic": "0.5",
            "metallic": "1",
            "transparent": true,
            "colorType": "red",
            "shelf": true,
            "smoothness": "0.8",
            "name": "透明红",
            "bianSmoothness": "0.8"
          },
          {
            "albedoColor": "0.0,0.292,0.500,1",
            "cost": 15,
            "smoothness": "0.75",
            "color": "blue",
            "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01eJIRZY23c00dPBvOK_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01eJIRZY23c00dPBvOK_!!555657275.jpg",
            "name": "蓝色",
            "metallic": "0.2",
            "shelf": true
          },
          {
            "albedoColor": "0.0,0.305,0.704,0.8",
            "cost": 15,
            "smoothness": "0.75",
            "color": "transBlue",
            "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01pzFKUj23c00vfderi_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01pzFKUj23c00vfderi_!!555657275.jpg",
            "name": "透明蓝",
            "transparent": true,
            "metallic": "0.6",
            "colorType": "blue",
            "shelf": true
          },
          {
            "albedoColor": "0.012,0.400,0.297,1",
            "cost": 15,
            "smoothness": "0.65",
            "color": "green",
            "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01rKCIR323c00Yxp1Qi_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01rKCIR323c00Yxp1Qi_!!555657275.jpg",
            "name": "绿色",
            "metallic": "0.45",
            "shelf": true
          },
          {
            "bian2Color": "0.818,0.795,0.739,1",
            "noLight": false,
            "albedoColor": "0.9,0.9,0.9,1",
            "cost": 15,
            "color": "white",
            "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01QTh87Z23c00xX7DcR_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01QTh87Z23c00xX7DcR_!!555657275.jpg",
            "metallic": "-0.1",
            "shelf": true,
            "smoothness": "0.85",
            "bian1Color": "0.720,0.7,0.650,1",
            "name": "白色",
            "logoSmoothness": "0.3"
          },
          {
            "bian2Color": "0.899,0.716,0.165,1",
            "albedoColor": "1,0.810,0.186,1",
            "cost": 15,
            "smoothness": "0.7",
            "color": "yellow",
            "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01WDKvTG23c00fVNm3M_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01WDKvTG23c00fVNm3M_!!555657275.jpg",
            "bian1Color": "0.849,0.676,0.155,1",
            "name": "黄色",
            "logoSmoothness": "0.3",
            "metallic": "0.1",
            "shelf": true
          },
          {
            "albedoColor": "0.22,0.22,0.22,1",
            "cost": 15,
            "smoothness": "0.65",
            "color": "black",
            "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01EQvhvB23c00cfSlaY_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01EQvhvB23c00cfSlaY_!!555657275.jpg",
            "name": "黑色",
            "metallic": "0.5",
            "shelf": true
          },
          {
            "cost": 35,
            "smoothness": "0.7",
            "color": "jungle",
            "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01LEdMhC1FJvbVQlXtv_!!1080040467.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01RHeR8b23c00dDVPSA_!!555657275.jpg",
            "name": "丛林迷彩",
            "logoColor": "0.984,0.984,0.843,1",
            "metallic": "-1",
            "shelf": true
          },
          {
            "cost": 35,
            "smoothness": "0.7",
            "color": "navy",
            "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01QbT1y023c00dDX1Da_!!555657275.jpg",
            "thumb": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01QbT1y023c00dDX1Da_!!555657275.jpg",
            "name": "海军迷彩",
            "logoColor": "0.698,0.784,0.867,1",
            "metallic": "-1",
            "shelf": true
          }
        ];
        // 1没显示
        let index = 0;
        if (!!sceneArr[index]) {
          let textureImg = textureImgs[1];
          let up = sceneArr[index].spriteArr.find(item => item.name == "daobaUp");
          up.textureImg = textureImg;
          let down = sceneArr[index].spriteArr.find(item => item.name == "daobaDown");
          down.textureImg = textureImg;
          this.loadScene(sceneArr[index]);
        }
      }
    }

    loadScene(opts) {
      this.options = Object.assign({ resource: [] }, opts);
      let resource = this.options.resource;
      if (resource.length > 0) {
        let tempUrls = [];
        resource.forEach(url => {
          tempUrls.push(this.options.host + url);
        });
        Laya.loader.create(tempUrls, Laya.Handler.create(this, this.onPreLoadFinish));
      } else {
        this.onPreLoadFinish();
      }
    }

    onPreLoadFinish() {
      Laya.Scene3D.load(this.options.host + this.options.sceneUrl, Laya.Handler.create(null, (scene) => {
        if (!scene) { return false; }
        this.scene = scene;
        Laya.stage.addChild(this.scene);
        this.scene.ambientColor = new Laya.Vector4(1, 1, 1, 1);

        this.camera = this.scene.getChildByName("Main Camera");

        this.dingLight = this.scene.getChildByName("ding");
        this.dingLight.intensity = 0;
        this.pxg = this.scene.getChildByName("pxg");
        this.pxg.intensity = 0.4;
        this.zuoLight = this.scene.getChildByName("zuo");
        this.zuoLight.intensity = 5.5;
        this.youLight = this.scene.getChildByName("you");
        this.youLight.intensity = 5.5;

        console.log(scene);
        var spriteArr = this.scene.getChildByName(this.options.sprite3DName);
        // 添加转动事件
        var rotationScript = spriteArr.addComponent(RotationScript);
        this.rotationScript = rotationScript;
        rotationScript.scene = this.scene;
        spriteArr.isKinematic = true;
        rotationScript.model = spriteArr;
        rotationScript.camera = this.camera;

        if (!!this.options.scale) {
          this.tempScale = spriteArr.transform.scale;
          this.tempScale.x += this.options.scale;
          this.tempScale.y += this.options.scale;
          this.tempScale.z += this.options.scale;
          spriteArr.transform.scale = this.tempScale;
        }

        // 创建提示动画
        this.createTipAni();

        let showImgSpriteArr = [];
        spriteArr._children.forEach(t1Sprite => {
          let tSprite = t1Sprite;
          let tempArr = [];
          if (tSprite._children.length == 0) {
            tempArr.push(tSprite);
          } else {
            // 此为精灵组
            if (tSprite._children.length == 1) {
              // 此数组下面还有数组
              tSprite = tSprite._children[0];
            }
            tempArr = tSprite._children;
            let spriteObj = this.options.spriteArr.find(item => item.baseName == tSprite.name);// 有设置参数
            if (!!spriteObj) {
              let sprite = tSprite;
              sprite.options = spriteObj;
              this[`${spriteObj.name}`] = sprite;

              // 设置对应参数
              if (!!spriteObj.setObj) {
                for (let tname in spriteObj.setObj) {
                  sprite[tname] = spriteObj.setObj[tname];
                }
              }
            }
          }
          tempArr.forEach(sprite => {
            try {
              if (sprite.name == "logo1" || sprite.name == "logo") {
                // logo不需要反光材质
                this.logoSprite = sprite;
              }
            } catch (e) { }
            let spriteObj = this.options.spriteArr.find(item => item.baseName == sprite.name);

            try {
              sprite.meshRenderer.material.metallic = 0.65;
              sprite.meshRenderer.material.smoothness = 0.65;
              if (!(!!spriteObj && (spriteObj.name == "daobaUp" || spriteObj.name == "daobaDown"))) {
                sprite.meshRenderer.material.albedoColor = new Laya.Vector4(1, 1, 1, 1);
              }
            } catch (e) { }
            // 有设置参数
            if (!!spriteObj) {
              sprite.options = spriteObj;
              this[`${spriteObj.name}`] = sprite;
              if (spriteObj.name == "daobaUp") {
                let tempSprite = Laya.Sprite3D.instantiate(sprite, tempArr.length > 1 ? tSprite : spriteArr);
                tempSprite.transform.translate(new Laya.Vector3(10000, 10000, 10000));

                // 默认模型上面的盖子为透明需要的材质
                this.transUpSprite = tempSprite;
              }
              if (spriteObj.name == "daobaDown") {
                let tempSprite = Laya.Sprite3D.instantiate(sprite, tempArr.length > 1 ? tSprite : spriteArr);
                tempSprite.transform.translate(new Laya.Vector3(10000, 10000, 10000));

                // 默认模型上面的盖子为透明需要的材质
                this.transDownSprite = tempSprite;
              }

              // 设置对应参数
              if (!!spriteObj.setObj) {
                for (let tname in spriteObj.setObj) {
                  sprite[tname] = spriteObj.setObj[tname];
                }
              }
              // 提示
              let tipSprite = spriteObj.tipSprite;
              if (!!tipSprite) {
                let sprite_clone1;
                if (!!tipSprite.clone) {
                  sprite_clone1 = Laya.Sprite3D.instantiate(sprite, tempArr.length > 1 ? tSprite : spriteArr);
                  sprite_clone1.transform.translate(new Laya.Vector3(tipSprite.clone.x, tipSprite.clone.y, tipSprite.clone.z));
                  sprite_clone1.transform.setWorldLossyScale(new Laya.Vector3(0, 0, 0));
                }
                rotationScript[tipSprite.name] = sprite_clone1 || sprite;
                if (!!tipSprite.pos) {
                  rotationScript[tipSprite.name].pos = tipSprite.pos;
                }

                this.loadedTip(tipSprite.name);
              }
              // 贴图
              if (!!spriteObj.textureImg) {
                showImgSpriteArr.push(spriteObj);
              }
              // 文字
              if (!!spriteObj.font) {
                // 1.复制图层 克隆sprite3d
                let sprite_clone1;
                if (spriteObj.name == "upFont" || spriteObj.name == "downFont" || spriteObj.name == "daoFont") {
                  sprite_clone1 = sprite;
                } else {
                  sprite_clone1 = Laya.Sprite3D.instantiate(sprite, tempArr.length > 1 ? tSprite : spriteArr);
                  sprite_clone1.transform.translate(new Laya.Vector3(spriteObj.font.clone.x, spriteObj.font.clone.y, spriteObj.font.clone.z));
                  sprite_clone1.name = "txt_1";
                }

                this[`${spriteObj.name}_txt`] = sprite_clone1;

                setTimeout(() => {
                  this.addFont(spriteObj.name, spriteObj.font.style);
                }, 0);
                // 如果有动画
                if (!!spriteObj.setObj) {
                  this[`${spriteObj.name}_clone`] = sprite_clone1;
                }
              }
            }
          });
        });
        showImgSpriteArr.forEach(spriteObj => {
          this.showImg(spriteObj.name, spriteObj.textureImg);
        });

        if (this.options.startAnimation) {
          this.rotateModelFun(this.options.startAnimation, "front");
        }

        this.bindEventFun();

        try {
          this.options.onLoad();
        } catch (e) { }

        // setTimeout(() => {
        //     this.toPos("back")
        // }, 3000)
        // window.tt = this;
      }));
    }

    bindEventFun() {
      this.tip1Ani.on(Laya.Event.MOUSE_DOWN, this, this.mouseDownFun);
      this.tip1Ani.on(Laya.Event.MOUSE_UP, this, this.mouseUpFun);

      this.tip2Ani.on(Laya.Event.MOUSE_DOWN, this, this.mouseDownFun);
      this.tip2Ani.on(Laya.Event.MOUSE_UP, this, this.mouseUpFun);

      this.tip3Ani.on(Laya.Event.MOUSE_DOWN, this, this.mouseDownFun);
      this.tip3Ani.on(Laya.Event.MOUSE_UP, this, this.mouseUpFun);
    }
    // 到达指定位置
    toPos(type) {
      let animation;
      if (type == "front" || type == "back") {
        // 关闭提示
        let tempArr = ["tip1Ani", "tip2Ani", "tip3Ani"];
        tempArr.forEach(name => {
          if (!!this[name].visible) {
            this[name].visible = false;
          }
        });
        // 禁止触摸
        if (type == "front") {
          // 正面
          animation = this.options.frontAnimation;
        } else if (type == "back") {
          // 背面
          animation = this.options.backAnimation;
        }
      } else {
        // 360°互动
        // 显示提示
        this.tip2Ani.visible = true;
        if (this.curOpenStstus == "close") {
          this.tip1Ani.visible = !true;
          this.tip3Ani.visible = !true;
        } else {
          this.tip1Ani.visible = true;
          this.tip3Ani.visible = true;
        }
        clearTimeout(this.timer);
      }

      if (!!animation) {
        this.rotateModelFun(animation, type);
      }
    }

    wcFun(num1, num2) {
      let val = num1 - num2;
      let wcVal = 0.1;
      if (Math.abs(val) <= wcVal) {
        return true;
      }
      return false;
    }

    rotateModelFun(animation, type) {
      let _this = this;
      clearTimeout(this.timer1);
      clearTimeout(this.timer);
      // x轴
      let stepX = this.rotationScript.model.transform.rotation.x > animation.x ? -1 : 1;
      let stepY = this.rotationScript.model.transform.rotation.y > animation.y ? -1 : 1;
      let stepZ = this.rotationScript.model.transform.rotation.z > animation.z ? -1 : 1;
      this.timer = setTimeout(() => {
        if ((stepX == 1 && this.wcFun(this.rotationScript.model.transform.rotation.x, animation.x)) || (stepX == -1 && this.wcFun(this.rotationScript.model.transform.rotation.x, animation.x))) {
          stepX = 0;
        }
        if ((stepY == 1 && this.wcFun(this.rotationScript.model.transform.rotation.y, animation.y)) || (stepY == -1 && this.wcFun(this.rotationScript.model.transform.rotation.y, animation.y))) {
          stepY = 0;
        }
        if ((stepZ == 1 && this.wcFun(this.rotationScript.model.transform.rotation.z, animation.z)) || (stepZ == -1 && this.wcFun(this.rotationScript.model.transform.rotation.z, animation.z))) {
          stepZ = 0;
        }
        if (!((animation.stepX * stepX) == 0 && (animation.stepY * stepY) == 0 && (animation.stepZ * stepZ) == 0)) {
          let poX = new Laya.Vector3();
          let poY = new Laya.Vector3();
          let poZ = new Laya.Vector3();
          poX.x = animation.stepX * stepX;
          poX.w = 0;
          poY.y = animation.stepY * stepY;
          poY.w = 0;
          poZ.z = animation.stepZ * stepZ;
          poZ.w = 0;

          this.rotationScript.model.transform.rotate(poX, false, false);
          this.rotationScript.model.transform.rotate(poY, true, true);
          this.rotationScript.model.transform.rotate(poZ, true, true);
          this.rotationScript.loadedAllTip();

          this.rotateModelFun(animation, type);
        } else {
          if (type == "front") {
            let count = 1;
            function tFun() {
              _this.rotationScript.model.transform.rotate(new Laya.Vector3(-2, 0, 0), false, false);
              _this.rotationScript.loadedAllTip();
              count++;
              if (count <= 25) {
                _this.timer1 = setTimeout(() => {
                  tFun();
                }, 1);
              }
            }

            tFun();
          }
        }
      }, 100);
    }
    // 缩放
    scaleFun(type) {
      let step = type == "max" ? 0.1 : -0.1;
      let scale = this.rotationScript.model.transform.scale;
      scale.x += step;
      scale.y += step;
      scale.z += step;

      this.rotationScript.model.transform.scale = scale;
      this.rotationScript.loadedAllTip();
    }
    // 贴图
    showImg(spriteName, imgObj) {
      // 贴图
      let mater = new Laya.PBRStandardMaterial();
      if (!!imgObj.noLight) {
        mater = new Laya.UnlitMaterial();
      }
      // logo颜色设置
      try {
        let logoColor = "0.85,0.85,0.85,1";
        if (!!imgObj.logoColor) {
          logoColor = imgObj.logoColor;
        }
        let logoArr = logoColor.split(",");
        let logoMater = new Laya.PBRStandardMaterial();
        if (!!imgObj.logoMetallic) {
          logoMater.metallic = parseFloat(imgObj.logoMetallic);
        } else {
          logoMater.metallic = 0.65;
        }
        if (!!imgObj.logoSmoothness) {
          logoMater.smoothness = parseFloat(imgObj.logoSmoothness);
        } else {
          logoMater.smoothness = 0.75;
        }
        logoMater.albedoColor = new Laya.Vector4(parseFloat(logoArr[0]), parseFloat(logoArr[1]), parseFloat(logoArr[2]), parseFloat(logoArr[3]));
        this.logoSprite.meshRenderer.material = logoMater;
      } catch (e) { }
      // 透明设置
      if (!!imgObj.transparent) {
        if (imgObj.colorType == "red" && !!this.transUpSprite) {
          mater = this.transUpSprite.meshRenderer.material;
          this.setImgDone(spriteName, mater, imgObj);
          return false;
        } else if (imgObj.colorType == "blue" && !!this.transDownSprite) {
          mater = this.transDownSprite.meshRenderer.material;
          this.setImgDone(spriteName, mater, imgObj);
          return false;
        }
        // mater = new Laya.BlinnPhongMaterial();
        mater.renderMode = Laya.BlinnPhongMaterial.RENDERMODE_TRANSPARENT;
        // mater.albedoIntensity = 0.5;
      }
      // 金属度
      if (!!imgObj.metallic) {
        mater.metallic = parseFloat(imgObj.metallic);
      }
      // 光滑度
      if (!!imgObj.smoothness) {
        mater.smoothness = parseFloat(imgObj.smoothness);
      }

      if (!!imgObj.albedoColor) {
        let color = imgObj.albedoColor.split(",");
        mater.albedoColor = new Laya.Vector4(parseFloat(color[0]), parseFloat(color[1]), parseFloat(color[2]), parseFloat(color[3]));
        this.setImgDone(spriteName, mater, imgObj);
      } else {
        Laya.Texture2D.load(imgObj.src, Laya.Handler.create(this, function (texture) {
          if (!!imgObj.textureType) {
            mater[imgObj.textureType] = texture;
          } else {
            mater.albedoTexture = texture;
          }
          this.setImgDone(spriteName, mater, imgObj);
        }));
      }
    }

    setImgDone(spriteName, mater, imgObj) {
      this[`${spriteName}`].meshRenderer.material = mater;

      let bianName = "";
      let tImg = Object.assign({}, imgObj);
      if (spriteName == "daobaUp") {
        bianName = "daobaUpBian01";
        if (!!tImg.bian1Color) {
          tImg.albedoColor = tImg.bian1Color;
        }
      } else if (spriteName == "daobaUpBian01") {
        bianName = "daobaUpBian02";
        if (!!tImg.bian2Color) {
          tImg.albedoColor = tImg.bian2Color;
        }
      } else if (spriteName == "daobaDown") {
        bianName = "daobaDownBian01";
        if (!!tImg.bian1Color) {
          tImg.albedoColor = tImg.bian1Color;
        }
      } else if (spriteName == "daobaDownBian01") {
        bianName = "daobaDownBian02";
        if (!!tImg.bian2Color) {
          tImg.albedoColor = tImg.bian2Color;
        }
      }

      if (!!bianName) {
        this.showImg(bianName, tImg);
      }
    }

    closeAllFun(type, callback) {
      if (!!this.closeStatus) { return false; }
      this.curOpenStstus = type;
      // 关闭
      this.closeNum = 0;
      this.closeStatus = true;
      let arr = [];
      this.options.spriteArr.forEach(item => {
        if (!!item.setObj && !!item.setObj.animaVal) {
          arr.push(item);
        }
      });
      let total = arr.length;
      arr.forEach(item => {
        if ((type == "close" && !item.setObj.openDoneName) || (type == "open" && !item.setObj.closeDoneName)) {
          this.openOrCloseFun(item.name, { type, total: total, callback: () => this.closeDoneFun(), calFun: callback });
        }
      });
    }

    closeDoneFun(ops) {
      this.closeStatus = false;

      try {
        ops.calFun();
      } catch (e) { }
    }

    openOrCloseFun(name, ops) {
      let sprite = this[`${name}`];
      if (!sprite) { return false; }
      let step = ops.type == "close" ? sprite.defaultStep || 1 : -1 * (sprite.defaultStep || 1);
      let tempRotate = step > 0 ? new Laya.Vector3(0, 0, Math.abs(step)) : new Laya.Vector3(0, 0, -1 * Math.abs(step));
      if (!!sprite.options.setObj.direction && sprite.options.setObj.direction == "x") {
        tempRotate = step > 0 ? new Laya.Vector3(Math.abs(step), 0, 0) : new Laya.Vector3(-1 * Math.abs(step), 0, 0);
      } else if (!!sprite.options.setObj.direction && sprite.options.setObj.direction == "y") {
        tempRotate = step > 0 ? new Laya.Vector3(0, Math.abs(step), 0) : new Laya.Vector3(0, -1 * Math.abs(step), 0);
      }

      if (typeof sprite.stepNum == "undefined") {
        sprite.stepNum = 0;
      }
      if (ops.type == "close") {
        // 收起 close
        if (!!this.tip1Ani.visible) {
          // 隐藏刀尖提示
          this.tip1Ani.visible = false;
        }
        if (!!this.tip3Ani.visible) {
          // 隐藏铰刀提示
          this.tip3Ani.visible = false;
        }
      } else {
      }
      sprite.stepNum = sprite.stepNum + 1;
      sprite.transform.rotate(tempRotate, true, false);
      this.rotationScript.loadedAllTip();
      if (!!this[`${name}_clone`]) {
        this[`${name}_clone`].transform.rotate(tempRotate, true, false);
      }
      if (sprite.stepNum < sprite.animaVal) {
        // 继续执行
        setTimeout(() => {
          this.openOrCloseFun(name, ops);
        }, 10);
      } else {
        sprite.stepNum = undefined;

        this.closeNum++;
        // 关闭完成，检测是否有关闭下一个属性
        if ((ops.type == "close" && !!sprite.closeDoneName) || (ops.type == "open" && !!sprite.openDoneName)) {
          this.openOrCloseFun(sprite[`${ops.type}DoneName`], ops);
        }
        if (this.closeNum == ops.total) {
          if (ops.type == "open") {
            // 展开 open
            if (!this.tip1Ani.visible) {
              // 显示刀尖提示
              this.tip1Ani.visible = true;
            }
            if (!this.tip3Ani.visible) {
              // 显示铰刀提示
              this.tip3Ani.visible = true;
            }
          }
          try {
            ops.callback(ops);
          } catch (e) { }
        }
      }
    }

    mouseDownFun(e) {
      if (!this.tip2Ani.visible) { return false; }
      this.startMouseX = Laya.MouseManager.instance.mouseX;
      this.startMouseY = Laya.MouseManager.instance.mouseY;
      this.clickTypeName = e.target.tName;
    }

    mouseUpFun() {
      if (!this.clickTypeName) { return false; }
      let tyName = this.clickTypeName;
      this.clickTypeName = "";
      let endX = Laya.MouseManager.instance.mouseX;
      let endY = Laya.MouseManager.instance.mouseY;

      let moveX = Math.abs(endX - this.startMouseX),
        moveY = Math.abs(endY - this.startMouseY);
      // 误差值
      let wcz = 0;
      if (moveX <= wcz && moveY <= wcz && !!tyName) {
        // 此次操作为点击
        switch (tyName) {
          case "tip2Ani":
            // 开
            if (!this.closeStatus && !this.tip1Ani.visible) {
              this.closeAllFun("open");
            }
            break;
          case "tip1Ani":
          case "tip3Ani":
            // 关
            if (!this.closeStatus && !!this.tip1Ani.visible) {
              this.closeAllFun("close");
            }
            break;
        }
      }
    }

    /**[SixGod]
     * 世界坐标转屏幕坐标
     * @param {Laya.Camera} camera   参照相机
     * @param {Laya.Vector3} point   需要转换的点
     */
    WorldToScreen2(point) {
      let camera = this.camera;

      var out = new Laya.Vector3();
      camera.viewport.project(point, camera.projectionViewMatrix, out);
      var value = new Laya.Vector3(out.x / Laya.stage.clientScaleX, out.y / Laya.stage.clientScaleY, 0);
      return value;
    }

    loadedTip(name) {
      let bounds = this[`${name}Ani`].getBounds();
      if (!!this.rotationScript[`${name}`] && !!bounds.width) {
        this.rotationScript[`${name}Ani`] = this[`${name}Ani`];
        let pos = this.rotationScript[`${name}`].pos || { x: 0, y: 0 };

        let val = this.WorldToScreen2(this.rotationScript[`${name}`].transform.position);
        let x = val.x;
        let y = val.y;
        if (name == "tip1") {
          x = x - pos.x * bounds.width;
          y = y - pos.y * bounds.height / 2;
        } else if (name == "tip2") {
          x = x - pos.x * bounds.width;
          y = y - pos.y * bounds.height / 2;
        } else if (name == "tip3") {
          x = x - pos.x * bounds.width + 50;
          y = y - pos.y * bounds.height / 2;
        }
        this[`${name}Ani`].pos(x, y);

        return bounds;
      }
    }

    createTipAni() {
      //创建动画实例
      this.options.tipObj = this.options.tipObj || {};
      if (!this.tip1Ani) {
        this.tip1Ani = new Laya.Animation();
        this.tip1Ani.tName = "tip1Ani";
        this.tip1Ani.autoSize = true;
        // 主刀
        //加载动画图集，加载成功后执行回调方法
        this.tip1Ani.loadAtlas(this.options.tipObj.zhudao || "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip1.atlas", Laya.Handler.create(this, (e) => {
          //添加到舞台
          Laya.stage.addChild(this.tip1Ani);
          this.tip1Ani.interval = 200;
          this.tip1Ani.play(0, true, "");

          this.loadedTip("tip1");
        }));
      }

      //创建动画实例
      if (!this.tip2Ani) {
        this.tip2Ani = new Laya.Animation();
        this.tip2Ani.tName = "tip2Ani";
        this.tip2Ani.autoSize = true;
        this.rotationScript.tip2Ani = this.tip2Ani;
        // 钥匙环
        //加载动画图集，加载成功后执行回调方法
        this.tip2Ani.loadAtlas(this.options.tipObj.yaoshihuan || "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip2.atlas", Laya.Handler.create(this, () => {
          //添加到舞台
          Laya.stage.addChild(this.tip2Ani);
          this.tip2Ani.interval = 200;
          this.tip2Ani.play(0, true, "");

          this.loadedTip("tip2");
        }));
      }

      //创建动画实例
      if (!this.tip3Ani) {
        this.tip3Ani = new Laya.Animation();
        this.tip3Ani.tName = "tip3Ani";
        this.tip3Ani.autoSize = true;
        // 铰刀
        //加载动画图集，加载成功后执行回调方法
        this.tip3Ani.loadAtlas(this.options.tipObj.jiaodao || "https://guanmeicdn.oss-cn-beijing.aliyuncs.com/3D/knife/atlas/tip3.atlas", Laya.Handler.create(this, () => {
          //添加到舞台
          Laya.stage.addChild(this.tip3Ani);
          this.tip3Ani.interval = 200;
          this.tip3Ani.play(0, true, "");

          this.loadedTip("tip3");
        }));
      }
    }

    addFont(name, obj) {
      obj = Object.assign({
        width: 512,
        height: 512,
        color: "#fff",
        fontWeight: "normal",
        fontSize: 50,
        textAlign: "center",
        textBaseline: "center",
        text: "请输入文字",
        rotate: 0,
        xPer: 1,//文字 x位置百分比 默认居中位置
        yPer: 1,
      }, obj);
      if (name == "upFont" || name == "downFont" || name == "daoFont" || name == "daobaUp" || name == "daobaDown" || name == "daojian") {
        obj.height = obj.height / 6;
      }
      //画布cavans
      let cav = Laya.Browser.createElement("canvas");
      var cxt = cav.getContext("2d");
      cav.width = obj.width;
      cav.height = obj.height;

      cxt.fillStyle = "transparent";
      cxt.fillRect(0, 0, cav.width, cav.height);

      cxt.fillStyle = obj.color;
      cxt.font = `${obj.fontWeight} ${obj.fontSize}px 宋体`;
      cxt.textAlign = obj.textAlign;//文本的对齐方式
      cxt.textBaseline = obj.textBaseline;//文本相对于起点的位置
      cxt.translate(obj.width / 2, obj.height / 2);
      cxt.rotate(obj.rotate * Math.PI / 180);
      cxt.translate(-obj.width / 2, -obj.height / 2);

      // 中心线
      /* cxt.strokeStyle = "red";
      cxt.moveTo(cav.width / 2 * obj.xPer, 0);
      cxt.lineTo(cav.width / 2 * obj.xPer, cav.height);
      cxt.stroke(); */

      //设置文字,位置
      cxt.fillText(obj.text, cav.width / 2 * obj.xPer, cav.height / 2 * obj.yPer);//有填充cxt.font="bold 60px 宋体";

      let texture2D = new Laya.Texture2D(cav.width, cav.height);
      texture2D.loadImageSource(cav);
      texture2D.anisoLevel = 2;

      let mater = new Laya.UnlitMaterial();
      mater.albedoTexture = texture2D;
      //设置反照率强度
      mater.albedoIntensity = 1;

      // 透明
      mater.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;

      if (name == "daobaUp") {
        name = "upFont";
      } else if (name == "daobaDown") {
        name = "downFont";
      } else if (name == "daojian") {
        name = "daoFont";
      }
      let tt = this[`${name}_txt`];
      if (!!tt) {
        tt.meshRenderer.material = mater;
      }

      if (!true && name == "daojian") {
        //设置一个面板用来渲染=========================================
        this.plane = new Laya.MeshSprite3D(Laya.PrimitiveMesh.createPlane(obj.width / 30, obj.height / 30));
        this.plane.transform.rotate(new Laya.Vector3(-90, 0, 0), true, false);
        this.plane.transform.translate(new Laya.Vector3(0, 0, 2), true, false);
        this.scene.addChild(this.plane);
        //材质
        let mat = new Laya.UnlitMaterial();
        this.plane.meshRenderer.sharedMaterial = mat;
        mat.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;
        //给材质贴图
        mat.albedoTexture = texture2D;
        this.plane.meshRenderer.sharedMaterial.cull = Laya.RenderState.CULL_NONE;

        this.plane1 = new Laya.MeshSprite3D(Laya.PrimitiveMesh.createPlane(obj.width / 30, obj.height / 30));
        this.plane1.transform.rotate(new Laya.Vector3(-90, 0, 0), true, false);
        this.plane1.transform.translate(new Laya.Vector3(0, -0.1, 2), true, false);
        this.scene.addChild(this.plane1);
        let src = "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01w13E7X1FJvbSyfRVB_!!1080040467.png";
        src = "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01b8l3sB1FJvbTqaTCw_!!1080040467.png";
        Laya.Texture2D.load(src, Laya.Handler.create(this, (texture) => {
          //材质
          let mat = new Laya.UnlitMaterial();
          this.plane1.meshRenderer.sharedMaterial = mat;
          // mat.renderMode = Laya.UnlitMaterial.RENDERMODE_TRANSPARENT;
          //给材质贴图
          mat.albedoTexture = texture;
          this.plane1.meshRenderer.sharedMaterial.cull = Laya.RenderState.CULL_NONE;
        }));
      }
    }
  }

  /**
   * 本示例采用非脚本的方式实现，而使用继承页面基类，实现页面逻辑。在IDE里面设置场景的Runtime属性即可和场景进行关联
   * 相比脚本方式，继承式页面类，可以直接使用页面定义的属性（通过IDE内var属性定义），比如this.tipLbll，this.scoreLbl，具有代码提示效果
   * 建议：如果是页面级的逻辑，需要频繁访问页面内多个元素，使用继承式写法，如果是独立小模块，功能单一，建议用脚本方式实现，比如子弹脚本。
   */
  class GameUI extends Laya.Scene {
    constructor() {
      super();

      new Knife();
    }

  }

  let GameConfig = {
    width: 750,
    height: 800,
    scaleMode: "showall",
    screenMode: "none",
    alignV: "top",
    alignH: "left",
    debug: false,
    stat: false,
    physicsDebug: false,
    exportSceneToJson: true,
  };

  class Main {
    constructor() {
      //根据IDE设置初始化引擎		
      if (window["Laya3D"]) Laya3D.init(GameConfig.width, GameConfig.height);
      else Laya.init(GameConfig.width, GameConfig.height, Laya["WebGL"]);
      Laya["Physics"] && Laya["Physics"].enable();
      Laya["DebugPanel"] && Laya["DebugPanel"].enable();
      Laya.stage.scaleMode = GameConfig.scaleMode;
      Laya.stage.screenMode = GameConfig.screenMode;
      Laya.stage.alignV = GameConfig.alignV;
      Laya.stage.alignH = GameConfig.alignH;
      //兼容微信不支持加载scene后缀场景
      Laya.URL.exportSceneToJson = GameConfig.exportSceneToJson;

      //打开调试面板（通过IDE设置调试模式，或者url地址增加debug=true参数，均可打开调试面板）
      if (GameConfig.debug || Laya.Utils.getQueryString("debug") == "true") Laya.enableDebugPanel();
      if (GameConfig.physicsDebug && Laya["PhysicsDebugDraw"]) Laya["PhysicsDebugDraw"].enable();
      if (GameConfig.stat) Laya.Stat.show();
      Laya.alertGlobalError(true);

      new GameUI();
    }
  }
  //激活启动类
  new Main();

}());
