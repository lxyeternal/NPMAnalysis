
// A map for all contexts. 
// Map<Error, Context>
/**
 * @type { Map<Error, Any> }
 */
const contexts = new Map();

/*
 * God someone pls halp me write this doc fuck my life x((((

 * @template ...T, R, E // ...T is the parameter types, R is the return type, 
 *     // and E is the peaceful error type that normally wont be used.
 * 
 * @param {Function(...T) : R} function // The function you want to guard, 
 *     // read the usage and you'll get the idea.
 * 
 * @returns : Function(...T) : R {
 * 
 *     willBeCaughtBy(...catchers: Function(Error): E): (Function(...T) : R) {
 * 
 *         and(...catchers: Function(Error): E): itself 
 * 
 *     } // This is a brand new funtion wrapped with a catch guard. 
 * 
 * } // It returns the function itself but with an extra method. The original 
 *     // function will also get modified since they refer to the same address. 
 * 
 */
module.exports = function errorsIn(originalFn) {

    // Don't pollute the original funciton, copy it.
    fn = function(...args) { return originalFn.call(this, ...args) };

    fn.willBeCaughtBy = function(catcher, ...moreCatchers) {

        /**
         * @type {Function}
         */
        const run = this;
        const catchers = [catcher, ...moreCatchers];

        const wrappedFn = function(...args) {

            const context = {};

            try {
                const result = run.__useContext ? run.call(this, context, ...args) : run.call(this, ...args);
                // const result = run(...args); 

                if (result instanceof Promise) {
                    return resolveResult(result, args, catchers, context);
                } else return result;

            } catch (err) {

                contexts.set(err, context);

                for (let i=0; i<catchers.length; i++) {

                    try {

                        const result = catchers[i](err, ...args);

                        if (result instanceof Promise) {
                            return resolveError(result, args, catchers, err, i + 1);
                        } else {
                            contexts.delete(err);
                            return result;
                        }

                    } catch (nextErr) {
                        if (err !== nextErr) {
                            // contexts[nextErr] = contexts[err]; shall we do this :\?
                            contexts.delete(err);
                            err = nextErr;
                        }
                        
                    }

                }

                contexts.delete(err);
                throw err;
            }
        }

        wrappedFn.and = function(catcher, ...moreCatchers) {
            catchers.push(catcher, ...moreCatchers);
            return this;
        }

        return wrappedFn;
    };

    // +
    fn.withContext = function() {
        this.__useContext = true;
        return this;
    }

    fn.withoutContext = function() {
        this.__useContext = undefined; // or false
        return this;
    }
    // +

    return fn;
} 

async function resolveResult(resultOnTheWay, args, catchers, context) {

    try {

        return await resultOnTheWay; // return await run();

    } catch (err) {

        contexts.set(err, context);

        for (let i=0; i<catchers.length; i++) {

            try {

                const result = await catchers[i](err, ...args);
                contexts.delete(err)
                return result;

            } catch (nextErr) {
                if (err !== nextErr) {
                    // contexts[nextErr] = contexts[err]; and this?
                    contexts.delete(err);
                    err = nextErr;
                }
            }

        }
        contexts.delete(err);
        throw err;
    }
    
};

async function resolveError(resultOnTheWay, args, catchers, lastErr, i) {

    try {

        const result = await resultOnTheWay; // result = await catchers[i]()
        contexts.delete(lastErr);
        return result;

    } catch (err) {

        if (lastErr !== err) {
            // contexts[err] = contexts[lastErr]; and this?
            contexts.delete(lastErr);
        }

        for (; i<catchers.length; i++) {

            try {

                const result = await catchers[i](err, ...args);
                contexts.delete(err)
                return result;

            } catch (nextErr) {
                if (err !== nextErr) {
                    // contexts[nextErr] = contexts[err]; and this??
                    contexts.delete(err);
                    err = nextErr;
                }
            }

        }
        contexts.delete(err);
        throw err;
    }
}

module.exports.contextOf = err => contexts.get(err);


