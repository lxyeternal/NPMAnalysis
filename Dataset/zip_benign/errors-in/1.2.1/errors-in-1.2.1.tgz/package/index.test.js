const errorsIn = require("./index.js");

// Sorry for the shit code.

describe("errors in the function", () => {
    it("will be caught by the catcher in order", () => {
        let lastCatcher = "nobody"
        const catcher1 = jest.fn( err => { 
            //console.log("catcher 1 caught the error but thrown it."); 
            lastCatcher = "catcher 1";
            throw err; 
        });
        const catcher2 = jest.fn( err => {
            //console.log("catcher2 caught the error and dealt with it responsibly.");
            lastCatcher = "catcher 2";
        })
        const f = errorsIn((arg1, arg2) => { 
            //console.log(arg1);
            //console.log(arg2);
            throw new Error("Ouch!");
        }).willBeCaughtBy(catcher1).and(catcher2);

        f("Alice", "Bob");
        
        expect(lastCatcher).toBe("catcher 2");
    });

    it("will be caught by the catcher and promise will be returned when catchers went async", async () => {
        const catcher1 = jest.fn( err => { 
            //console.log("catcher 1 caught the error but thrown it."); 
            throw err; 
        });
        const catcher2 = jest.fn( async err => {
            //console.log("catcher 2 caught the error and he needs a bit of time, but at the end he find he can't deal with this problem so he throwed it again.");
            throw err;
        });
        const catcher3 = jest.fn( async err => {
            //console.log("catcher 3 caught the error and dealt with it responsibly.");
        })
        const f = errorsIn(async (arg1, arg2) => { 
            //console.log(arg1);
            //console.log(arg2);
            throw new Error("Ouch!");
        }).willBeCaughtBy(catcher1).and(catcher2);

        const result = f("Alice", "Bob");
        
        expect(result).toBeInstanceOf(Promise);

        await expect(result).rejects.toThrow();

        expect(catcher1).toBeCalled();
    });

    it("will be caught by the catcher and promise will be returned when function went async", async () => {
        const catcher1 = jest.fn( err => { 
            //console.log("catcher 1 caught the error but thrown it."); 
            throw err; 
        });
        const catcher2 = jest.fn( async err => {
            //console.log("catcher 2 caught the error and he needs a bit of time, but at the end he find he can't deal with this problem so he throwed it again.");
            throw err;
        });
        const catcher3 = jest.fn( async err => {
            //console.log("catcher 3 caught the error and dealt with it responsibly.");
        })
        const f = errorsIn((arg1, arg2) => { 
            //console.log(arg1);
            //console.log(arg2);
            throw new Error("Ouch!");
        }).willBeCaughtBy(catcher1).and(catcher2).and(catcher3);

        const result = f("Alice", "Bob");
        
        expect(result).toBeInstanceOf(Promise);

        expect(catcher1).toBeCalled();
    });

    it("should have context by a shared object and the context should be invalid afterwards", () => {
        const contextOf = errorsIn.contextOf;

        const theNumber = 101; // Just a random number

        let theError;

        const catcher = jest.fn((err, ...args) => {
            theError = err;
            expect(contextOf(err).number).toBe(theNumber);
        });

        const f = errorsIn(($var, ...args) => {
            $var.number = theNumber;
            throw new Error("Boop");
        }).withContext().willBeCaughtBy(catcher);

        f();

        expect(contextOf(theError)).toBeUndefined();

    });

    it("should do its job while the function should not be unbound.", () => {
        class Person {
            name;
            constructor(name) {
                this.name = name;
            }
            getName() {
                console.log(this);
                return this.name;
            }
        }

        const bob = new Person("Bob");
        const getName = errorsIn(bob.getName).willBeCaughtBy(err => {});
        bob.getName = getName;
        expect(bob.getName()).toBe("Bob");

    });
});