const tf = require('@tensorflow/tfjs-node');
const { sampleSize } = require("lodash")
const { random, floor } = Math;
const fs = require("fs");
const { resolve } = require("path");
class Memory {
    /**
     * @param {number} maxMemory
     */
    constructor(maxMemory) {
        this.maxMemory = maxMemory;
        this.samples = new Array();
    }

    /**
     * @param {Array} sample
     */
    addSample(sample) {
        this.samples.push(sample);
        if (this.samples.length > this.maxMemory) {
            let [state,,,] = this.samples.shift();
            state.dispose();
        }
    }

    /**
     * @param {number} nSamples
     * @returns {Array} Randomly selected samples
     */
    sample(nSamples) {
        return sampleSize(this.samples, nSamples);
    }
}
class RN {
  constructor({numInputs, gamma, learningRate, epsilon, maxMem }) {
    this.numInputs = numInputs;
    this.gamma = gamma || 0.1;
    this.memory = new Memory(maxMem || 256)
    this.learningRate = learningRate || 0.8;
    this.epsilon = epsilon || 0.5;
    this.oEp = epsilon
    this.layers = [];
    this.isCompiled = false;
    this.currentState = null;
    this.currentAction = null;
    this.currentReward = null;
    this.nextStateValue = null;
    this.nextRan = 0;
    this.loaded = false;
  }

  addLayer(numNodes, activation = 'relu') {
    if(!this.model) this.model = tf.sequential();

    
    this.model.add(tf.layers.dense({ units: numNodes, activation, inputShape: (this.layers.length == 0) ? [this.numInputs] : undefined}));
    this.layers.push({ numNodes, activation });
  }
  compile(loss="meanSquaredError") {
    if (this.layers.length == 0 && !this.loaded) {
      throw new Error('Cannot compile the model without any layers. Please add layers using the `addLayer` method.');
    }
    if(!this.loaded){
      this.model.compile({
        loss: loss,
        optimizer: tf.train.adam(this.learningRate),
      });
    }
    this.isCompiled = true;
  }
  async save(path="model"){
   await this.model.save("file://"+resolve(path));
  }
  async load(path="model"){
    this.model = await tf.loadLayersModel("file://"+resolve(path +"/model.json"));
    this.layers.push({ numNodes: this.model.layers[0].kernel.shape[0] })
    this.model.layers.forEach(layer=>{
      this.layers.push({ numNodes: layer.kernel.shape[1] });
    });
    this.loaded = true;
  }
  async getRandomAction(){
    var outputLength = this.layers[this.layers.length-1].numNodes;
    var action = Math.floor(Math.random() * outputLength);
    return action;
  }
  async getAction(input) {
    if (!this.isCompiled && !this.loaded) {
      throw new Error('The model is not compiled yet. Please call the `compile` method before using the model.');
    }

    if (!this.currentState) {
      this.currentState = tf.tensor2d([input]);
    } else {
      this.currentState.dispose();
      this.currentState = tf.tensor2d([input])
    }
    this.currentStateRef = tf.clone(this.currentState)
    const predictResult = this.model.predict(this.currentState);
    var predictArray = predictResult.arraySync()[0];
    predictResult.dispose();

    if (Math.random() < this.epsilon) {
      this.currentAction = Math.floor(Math.random() * predictArray.length);
      predictArray = new Array(predictArray.length);
      predictArray.fill(0);
      predictArray[this.currentAction] = 1;
    } else {
      this.currentAction = predictArray.indexOf(Math.max(...predictArray));
    }
    this.currentActionArray = predictArray;

    return this.currentAction;
  }

  async reward(reward) {
    if (!this.currentState || this.currentActionArray === null) {
      throw new Error('Invalid call to `next` method. Please ensure you have set the current state, action, and next state using the corresponding methods.');
    }
    this.memory.addSample([this.currentStateRef, this.currentActionArray, reward])
  }
  decay(initial, rate, time){
      return initial * (1-rate)**time
  }

  async next({ batchSize, decayRate, trainingOpts }) {
    this.epsilon = this.decay(this.oEp, decayRate || 0.08, ++this.nextRan)

    const batch = this.memory.sample(batchSize || 64);

    var compiledQ = batch.map(sample=>{
      let x = tf.clone(sample[0]);
      let predicted = sample[1];
      let reward = sample[2];
      let actionIndex = predicted.indexOf(Math.max(...predicted));
      let qaction = [...predicted];
      qaction[actionIndex] = reward * this.gamma + predicted[actionIndex];
      var y = tf.tensor2d(qaction,[1,qaction.length]);
      return [x,y]
    });
    var xs = compiledQ.map(([x,])=>{
      var data = x.dataSync();
      x.dispose()
      return data;
    })
    var ys = compiledQ.map(([,y])=>{
      var data = y.dataSync();
      y.dispose();
      return data
    })
    var xsTensor = tf.tensor(xs,[batch.length,xs[0].length])
    var ysTensor = tf.tensor(ys,[batch.length,ys[0].length])
    await this.model.fit(xsTensor, ysTensor, {epochs: 1, verbose: 0, ...(trainingOpts || {}) });
    
    this.currentActionArray = null;
    this.currentReward = null;
  }
}

module.exports = {
  RN
}
