const calculator = require('./Index'); 

console.log("My sum is " + calculator.operations.add(1, 2, 3, 4, 5, 6, 7, 8, 9)); // Output: 45
console.log("My subtract is " + calculator.operations.subtract(2, 3)); // Output: -1
console.log("My multiplication is " + calculator.operations.multiply(2, 3, 4)); // Output: 24
console.log("My division is " + calculator.operations.divide(10, 2)); // Output: 5
console.log("My modulus is " + calculator.operations.modulus(10, 3)); // Output: 1
console.log("Factorial of 5 is " + calculator.operations.factorial(5)); // Output: 120
console.log("Average of numbers is " + calculator.operations.average(10, 20, 30)); // Output: 20
console.log("Random number between 1 and 100: " + calculator.operations.random(1, 100)); // Output: Random number