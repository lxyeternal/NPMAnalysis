exports.operations = {
    // Basic Arithmetic Operations
    add: function (...args) {
        return args.reduce((a, b) => a + b, 0);
    },

    subtract: function (...args) {
        return args.reduce((a, b) => a - b);
    },

    multiply: function (...args) {
        return args.reduce((a, b) => a * b, 1);
    },

    divide: function (...args) {
        return args.reduce((a, b) => {
            if (b === 0) {
                throw new Error("Cannot divide by zero");
            }
            return a / b;
        });
    },

    modulus: function (...args) {
        return args.reduce((a, b) => a % b);
    },

    // Power and Root Functions
    power: function (base, exponent) {
        return Math.pow(base, exponent);
    },

    sqrt: function (num) {
        if (num < 0) {
            throw new Error("Cannot find square root of a negative number");
        }
        return Math.sqrt(num);
    },

    abs: function (num) {
        return Math.abs(num);
    },

    // Factorial (Recursive Function)
    factorial: function (num) {
        if (num < 0) return "Undefined for negative numbers";
        if (num === 0) return 1;
        return num * this.factorial(num - 1);
    },

    // Statistical Operations
    average: function (...args) {
        return args.reduce((a, b) => a + b, 0) / args.length;
    },

    median: function (...args) {
        args.sort((a, b) => a - b);
        const mid = Math.floor(args.length / 2);
        return args.length % 2 !== 0 ? args[mid] : (args[mid - 1] + args[mid]) / 2;
    },

    mode: function (...args) {
        const counts = {};
        args.forEach(num => counts[num] = (counts[num] || 0) + 1);
        const maxFreq = Math.max(...Object.values(counts));
        return Object.keys(counts).filter(num => counts[num] === maxFreq).map(Number);
    },

    // Trigonometric Functions (Degrees to Radians Conversion)
    sin: function (deg) {
        return Math.sin(deg * (Math.PI / 180));
    },

    cos: function (deg) {
        return Math.cos(deg * (Math.PI / 180));
    },

    tan: function (deg) {
        return Math.tan(deg * (Math.PI / 180));
    },

    // Random Number Generator
    random: function (min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
};
