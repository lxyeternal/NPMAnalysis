Calculator-ish-k-pro 📟
A simple and powerful calculator module for performing arithmetic and statistical operations in Node.js.

Installation
Install the package using npm:
npm install calculator-ish-k-pro

Usage
Require the package in your Node.js project:
const calculator = require("calculator-ish-k-pro");

Addition:
calculator.operations.add(1, 2, 3, 4); // Output: 10

Subtraction:
calculator.operations.subtract(10, 3, 2); // Output: 5

Multiplication:
calculator.operations.multiply(2, 3, 4); // Output: 24

Division:
calculator.operations.divide(10, 2); // Output: 5

Modulus:
calculator.operations.modulus(10, 3); // Output: 1

Factorial:
calculator.operations.factorial(5); // Output: 120

Average:
calculator.operations.average(10, 20, 30); // Output: 20

Median:
calculator.operations.median(10, 20, 30, 40); // Output: 25

Mode:
calculator.operations.mode(1, 2, 2, 3, 3, 3, 4, 4, 4); // Output: [3, 4]

Trigonometry:
calculator.operations.sin(30); // Output: 0.5
calculator.operations.cos(60); // Output: 0.5
calculator.operations.tan(45); // Output: 1

Random Number Generator:
calculator.operations.random(1, 100); // Output: Random number between 1 and 100

Features
Supports unlimited arguments for addition, subtraction, multiplication, and statistical operations.
Includes power, square root, absolute value, and factorial calculations.
Trigonometric functions (sin, cos, tan in degrees).
Random number generator within a range.
Keywords
Calculator, Mathematics, Arithmetic, Statistical Functions, Node.js

Author
Created by Ish k pro

License
This package is licensed under the ISC License.