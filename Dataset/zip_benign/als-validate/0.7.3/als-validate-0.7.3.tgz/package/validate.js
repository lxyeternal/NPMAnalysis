class Validate {
   static init = true
   static stylesAdded = false
   static styles() {
      if(Validate.stylesAdded) return
      let style = document.createElement('style')
      style.innerHTML = `
      .show-password {
         appearance: none;
         display: inline-block;
         width: 40px;
         height: 20px;
         background-repeat: no-repeat;
      }
      .show-password:not(:checked) {
         background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='25' height='20' style='fill:gray;' %3E%3Cpath d='M279.6 160.4C282.4 160.1 285.2 160 288 160C341 160 384 202.1 384 256C384 309 341 352 288 352C234.1 352 192 309 192 256C192 253.2 192.1 250.4 192.4 247.6C201.7 252.1 212.5 256 224 256C259.3 256 288 227.3 288 192C288 180.5 284.1 169.7 279.6 160.4zM480.6 112.6C527.4 156 558.7 207.1 573.5 243.7C576.8 251.6 576.8 260.4 573.5 268.3C558.7 304 527.4 355.1 480.6 399.4C433.5 443.2 368.8 480 288 480C207.2 480 142.5 443.2 95.42 399.4C48.62 355.1 17.34 304 2.461 268.3C-.8205 260.4-.8205 251.6 2.461 243.7C17.34 207.1 48.62 156 95.42 112.6C142.5 68.84 207.2 32 288 32C368.8 32 433.5 68.84 480.6 112.6V112.6zM288 112C208.5 112 144 176.5 144 256C144 335.5 208.5 400 288 400C367.5 400 432 335.5 432 256C432 176.5 367.5 112 288 112z' style='transform:scale(0.04)'/%3ESorry, your browser does not support inline SVG.%3C/svg%3E");      
      }
      .show-password:checked {
         background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='25' height='20' style='fill:gray;' %3E%3Cpath d='M150.7 92.77C195 58.27 251.8 32 320 32C400.8 32 465.5 68.84 512.6 112.6C559.4 156 590.7 207.1 605.5 243.7C608.8 251.6 608.8 260.4 605.5 268.3C592.1 300.6 565.2 346.1 525.6 386.7L630.8 469.1C641.2 477.3 643.1 492.4 634.9 502.8C626.7 513.2 611.6 515.1 601.2 506.9L9.196 42.89C-1.236 34.71-3.065 19.63 5.112 9.196C13.29-1.236 28.37-3.065 38.81 5.112L150.7 92.77zM223.1 149.5L313.4 220.3C317.6 211.8 320 202.2 320 191.1C320 180.5 316.1 169.7 311.6 160.4C314.4 160.1 317.2 159.1 320 159.1C373 159.1 416 202.1 416 255.1C416 269.7 413.1 282.7 407.1 294.5L446.6 324.7C457.7 304.3 464 280.9 464 255.1C464 176.5 399.5 111.1 320 111.1C282.7 111.1 248.6 126.2 223.1 149.5zM320 480C239.2 480 174.5 443.2 127.4 399.4C80.62 355.1 49.34 304 34.46 268.3C31.18 260.4 31.18 251.6 34.46 243.7C44 220.8 60.29 191.2 83.09 161.5L177.4 235.8C176.5 242.4 176 249.1 176 255.1C176 335.5 240.5 400 320 400C338.7 400 356.6 396.4 373 389.9L446.2 447.5C409.9 467.1 367.8 480 320 480H320z' style='transform:scale(0.04)'/%3E Sorry, your browser does not support inline SVG. %3C/svg%3E%0A");
      }
      `
      document.querySelector('head').appendChild(style)
      Validate.stylesAdded = true
   }

   static forms() {
      window.addEventListener('DOMContentLoaded', (event) => {
         let forms = [...document.querySelectorAll('form[validate]')]
         forms.forEach(form => {
            let classes = form.getAttribute('validate')
            form.addEventListener('input',(e) => new Validate(form,...classes.split('|')))
            new Validate(form,...classes.split('|'))
         });
     });
   }
   constructor(form,invalid='',valid='') {
      let submit = form.querySelector('[type=submit]')
      submit.setAttribute('disabled','')
      this.errors = []
      this.allErrors = []
      this.form = form
      this.inputs = [...form.querySelectorAll('input')]
      this.invalid = invalid
      this.valid = valid
      this.search()
      if(this.allErrors.length == 0) submit.removeAttribute('disabled')
      Validate.init = false
   }

   search() {
      this.inputs.forEach(input => {
         let type = input.getAttribute('type')
         this.msg = input.getAttribute('msg') || ''
         let errorId = input.getAttribute('error')
         if(errorId !== null) this.msgElement = document.getElementById(errorId)
         else this.msgElement = null
         this.input = input
         if(type == 'captcha') this.captcha()
         if(Validate.init) {
            let show = input.getAttribute('show')
            if(show !== null) this.showPassword(show)
         }
         if(!input.classList.contains('show-password'))
            this.checkAttributes()
         this.allErrors = this.allErrors.concat(this.errors)
         this.errors = []
      });
   }

   showPassword(show) {
      if(show == 'true') this.input.setAttribute('type','text')
      Validate.styles()
      this.input.insertAdjacentHTML('afterend',
      /*html*/`
      <input type="checkbox" class="show-password" ${show=='false' ? 'checked' : ''}
      title="Show the field"
      onclick="this.previousElementSibling.setAttribute('type',(this.checked) ? 'password' : 'text')">
      `)
   }

   isValid() {
      if(this.errors.length == 0) {
         this.invalid.split(' ').forEach(invalid => {
            this.input.classList.remove(invalid)   
         })
         this.valid.split(' ').forEach(valid => {
            this.input.classList.add(valid)   
         })
      } else {
         this.valid.split(' ').forEach(valid => {
            this.input.classList.remove(valid)   
         })
         this.invalid.split(' ').forEach(invalid => {
            this.input.classList.add(invalid)   
         })
         this.msg = this.errors.join(',')
      }
      if(this.msgElement !== null) this.msgElement.innerHTML = this.msg
   }

   checkAttributes(input=this.input) {
      let min = input.getAttribute('min')
      let max = input.getAttribute('max')
      let upper = input.getAttribute('upper')
      let lower = input.getAttribute('lower')
      let number = input.getAttribute('number')
      let special = input.getAttribute('special')
      let confirm = input.getAttribute('confirm')
      let required = input.getAttribute('required')

      if(required !== null) {
         if(input.type == 'checkbox' && input.checked == false) this.errors.push('required')
         if(input.value == '') this.errors.push('required')
      }
      if(lower && lower!=="0") if((input.value.match(/[a-z]/g) || []).length < lower) 
         this.errors.push(`${lower} lowercase characters`)
      if(upper && upper!=="0") if((input.value.match(/[A-Z]/g) || []).length < upper) 
         this.errors.push(`${upper} uppercase characters`)
      if(number && number!=="0") if((input.value.match(/\d/g) || []).length < number) 
         this.errors.push(`${number} numbers`)
      if(special && special!=="0") if((input.value.match(/[@$!%*?&]/g) || []).length < special) 
         this.errors.push(`${special} special(@$!%*?&) characters`)
      if(min && input.type !== 'number') if(input.value.length < min) 
         this.errors.push(`minimum ${min} characters`)
      if(max && input.type !== 'number') if(input.value.length > max) 
         this.errors.push(`maximum ${max} characters`)
      if(input.type == 'email') if(input.value.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/) == null)
            this.errors.push('Email is invalid')
      if(confirm) {
         let value = document.getElementById(confirm).value
         if(value !== this.input.value) this.errors.push('Password not match')
      }

      this.isValid()
   }
   
   captcha() {
      if(Validate.init) {
         let tCtx = document.createElement("canvas")
         tCtx.setAttribute('height','10')
         tCtx.setAttribute('width','30')
         tCtx = tCtx.getContext('2d')
         
         let first = Math.floor(Math.random() * 10)
         let second = Math.floor(Math.random() * 10)
         let operations = ['*','-','+']
         let o = Math.floor(Math.random() * 3)
         Validate.captchaResult = (o == 0) ? first*second : (o == 1) ? first-second : first+second
         tCtx.fillText(`${first} ${operations[o]} ${second} = `, 0, 10);
         let imgSrc = tCtx.canvas.toDataURL()
         this.input.insertAdjacentHTML('beforebegin',`<img src="${imgSrc}">`)
      }
      if(parseInt(this.input.value, 10) !== Validate.captchaResult) 
         this.errors.push('Captcha is wrong')
      this.isValid()
   }
}