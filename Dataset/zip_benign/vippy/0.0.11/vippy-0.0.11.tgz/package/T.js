var vippy = require('./index.js'),
    os = require('os'),
    util = require('util');

function NoIfeConfig(config, hostname) {
  vippy.Config.call(this, config, hostname);
}
util.inherits(NoIfeConfig, vippy.Config);
NoIfeConfig.prototype.refresh_arpcache = function() {
  console.log("noop arp collect");
}

function NoIfeManager(config) {
  vippy.Manager.call(this, config);
}
util.inherits(NoIfeManager, vippy.Manager);
NoIfeManager.prototype.reconcile_interfaces = function() {}

var config_file = 'vippy.conf';
var hostname = os.hostname();
var config = new NoIfeConfig(config_file, hostname),
    manager = new NoIfeManager(config),
    controller = new vippy.Controller(config, manager);

config.run();
