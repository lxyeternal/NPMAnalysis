import * as React from "react";
import { IconProps } from '../lib';
declare const AlignLeft: (props: IconProps) => React.JSX.Element;
export default AlignLeft;
//# sourceMappingURL=AlignLeft.d.ts.map