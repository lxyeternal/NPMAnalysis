import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendDownRight: (props: IconProps) => React.JSX.Element;
export default ArrowBendDownRight;
//# sourceMappingURL=ArrowBendDownRight.d.ts.map