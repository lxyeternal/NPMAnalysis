import React from 'react';
import { IconProps } from '../lib';
declare function AirplaneTakeoff({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AirplaneTakeoff;
//# sourceMappingURL=AirplaneTakeoff.d.ts.map