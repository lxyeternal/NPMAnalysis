import React from 'react';
import { IconProps } from '../lib';
declare function AlignLeftSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignLeftSimple;
//# sourceMappingURL=AlignLeftSimple.d.ts.map