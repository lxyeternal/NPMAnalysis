import React from 'react';
import { IconProps } from '../lib';
declare function AlignBottom({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignBottom;
//# sourceMappingURL=AlignBottom.d.ts.map