import * as React from "react";
import { IconProps } from '../lib';
declare const ArchiveTray: (props: IconProps) => React.JSX.Element;
export default ArchiveTray;
//# sourceMappingURL=ArchiveTray.d.ts.map