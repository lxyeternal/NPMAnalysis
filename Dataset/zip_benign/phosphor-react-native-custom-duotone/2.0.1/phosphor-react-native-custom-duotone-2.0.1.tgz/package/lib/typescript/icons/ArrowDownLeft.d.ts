import React from 'react';
import { IconProps } from '../lib';
declare function ArrowDownLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowDownLeft;
//# sourceMappingURL=ArrowDownLeft.d.ts.map