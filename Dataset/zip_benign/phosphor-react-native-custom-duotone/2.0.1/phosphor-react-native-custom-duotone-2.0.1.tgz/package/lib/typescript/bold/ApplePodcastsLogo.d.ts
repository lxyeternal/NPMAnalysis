import * as React from "react";
import { IconProps } from '../lib';
declare const ApplePodcastsLogo: (props: IconProps) => React.JSX.Element;
export default ApplePodcastsLogo;
//# sourceMappingURL=ApplePodcastsLogo.d.ts.map