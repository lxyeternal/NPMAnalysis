import React from 'react';
import { IconProps } from '../lib';
declare function AlignCenterHorizontal({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignCenterHorizontal;
//# sourceMappingURL=AlignCenterHorizontal.d.ts.map