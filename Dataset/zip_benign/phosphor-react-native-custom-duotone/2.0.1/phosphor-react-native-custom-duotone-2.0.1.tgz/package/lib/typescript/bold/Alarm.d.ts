import * as React from "react";
import { IconProps } from '../lib';
declare const Alarm: (props: IconProps) => React.JSX.Element;
export default Alarm;
//# sourceMappingURL=Alarm.d.ts.map