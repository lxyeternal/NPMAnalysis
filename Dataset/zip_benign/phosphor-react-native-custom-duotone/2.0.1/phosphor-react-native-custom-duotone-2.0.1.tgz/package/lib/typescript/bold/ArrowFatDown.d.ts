import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowFatDown: (props: IconProps) => React.JSX.Element;
export default ArrowFatDown;
//# sourceMappingURL=ArrowFatDown.d.ts.map