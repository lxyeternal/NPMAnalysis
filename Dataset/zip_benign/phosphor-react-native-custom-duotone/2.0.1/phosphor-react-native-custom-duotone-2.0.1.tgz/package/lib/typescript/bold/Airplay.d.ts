import * as React from "react";
import { IconProps } from '../lib';
declare const Airplay: (props: IconProps) => React.JSX.Element;
export default Airplay;
//# sourceMappingURL=Airplay.d.ts.map