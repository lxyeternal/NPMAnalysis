import React from 'react';
import { IconProps } from '../lib';
declare function ArrowDown({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowDown;
//# sourceMappingURL=ArrowDown.d.ts.map