import * as React from "react";
import { IconProps } from '../lib';
declare const AirplaneInFlight: (props: IconProps) => React.JSX.Element;
export default AirplaneInFlight;
//# sourceMappingURL=AirplaneInFlight.d.ts.map