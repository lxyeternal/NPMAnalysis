import * as React from "react";
import { IconProps } from '../lib';
declare const AlignRightSimple: (props: IconProps) => React.JSX.Element;
export default AlignRightSimple;
//# sourceMappingURL=AlignRightSimple.d.ts.map