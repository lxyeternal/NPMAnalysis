import React from 'react';
import { IconProps } from '../lib';
declare function Aperture({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Aperture;
//# sourceMappingURL=Aperture.d.ts.map