import React from 'react';
import { IconProps } from '../lib';
declare function AirTrafficControl({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AirTrafficControl;
//# sourceMappingURL=AirTrafficControl.d.ts.map