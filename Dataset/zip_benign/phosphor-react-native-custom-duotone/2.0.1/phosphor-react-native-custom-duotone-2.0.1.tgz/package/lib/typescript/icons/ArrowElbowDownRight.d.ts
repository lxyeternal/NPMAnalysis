import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowDownRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowDownRight;
//# sourceMappingURL=ArrowElbowDownRight.d.ts.map