import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendDownLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendDownLeft;
//# sourceMappingURL=ArrowBendDownLeft.d.ts.map