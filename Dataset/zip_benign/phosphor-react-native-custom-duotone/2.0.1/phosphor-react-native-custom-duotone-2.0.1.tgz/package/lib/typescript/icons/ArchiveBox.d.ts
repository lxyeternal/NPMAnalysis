import React from 'react';
import { IconProps } from '../lib';
declare function ArchiveBox({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArchiveBox;
//# sourceMappingURL=ArchiveBox.d.ts.map