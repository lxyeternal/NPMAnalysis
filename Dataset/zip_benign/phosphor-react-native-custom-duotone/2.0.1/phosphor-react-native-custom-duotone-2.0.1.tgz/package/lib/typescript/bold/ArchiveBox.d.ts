import * as React from "react";
import { IconProps } from '../lib';
declare const ArchiveBox: (props: IconProps) => React.JSX.Element;
export default ArchiveBox;
//# sourceMappingURL=ArchiveBox.d.ts.map