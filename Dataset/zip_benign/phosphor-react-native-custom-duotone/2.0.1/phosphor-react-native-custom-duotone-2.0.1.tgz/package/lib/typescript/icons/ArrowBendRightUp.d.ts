import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendRightUp({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendRightUp;
//# sourceMappingURL=ArrowBendRightUp.d.ts.map