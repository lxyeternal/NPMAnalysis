import React from 'react';
import { IconProps } from '../lib';
declare function AlignRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignRight;
//# sourceMappingURL=AlignRight.d.ts.map