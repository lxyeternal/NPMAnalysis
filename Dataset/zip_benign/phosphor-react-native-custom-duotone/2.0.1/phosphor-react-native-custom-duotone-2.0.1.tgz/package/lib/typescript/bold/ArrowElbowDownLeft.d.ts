import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowDownLeft: (props: IconProps) => React.JSX.Element;
export default ArrowElbowDownLeft;
//# sourceMappingURL=ArrowElbowDownLeft.d.ts.map