import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowUpLeft: (props: IconProps) => React.JSX.Element;
export default ArrowElbowUpLeft;
//# sourceMappingURL=ArrowElbowUpLeft.d.ts.map