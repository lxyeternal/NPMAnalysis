import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowDownLeft: (props: IconProps) => React.JSX.Element;
export default ArrowDownLeft;
//# sourceMappingURL=ArrowDownLeft.d.ts.map