import * as React from "react";
import { IconProps } from '../lib';
declare const AlignBottom: (props: IconProps) => React.JSX.Element;
export default AlignBottom;
//# sourceMappingURL=AlignBottom.d.ts.map