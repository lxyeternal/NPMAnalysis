import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleDown({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleDown;
//# sourceMappingURL=ArrowCircleDown.d.ts.map