import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleUpRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleUpRight;
//# sourceMappingURL=ArrowCircleUpRight.d.ts.map