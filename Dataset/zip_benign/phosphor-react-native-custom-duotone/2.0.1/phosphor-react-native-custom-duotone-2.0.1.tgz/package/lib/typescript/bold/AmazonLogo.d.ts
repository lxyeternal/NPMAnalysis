import * as React from "react";
import { IconProps } from '../lib';
declare const AmazonLogo: (props: IconProps) => React.JSX.Element;
export default AmazonLogo;
//# sourceMappingURL=AmazonLogo.d.ts.map