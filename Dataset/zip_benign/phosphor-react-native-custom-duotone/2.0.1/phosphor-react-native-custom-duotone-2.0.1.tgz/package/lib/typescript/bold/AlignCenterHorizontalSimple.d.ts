import * as React from "react";
import { IconProps } from '../lib';
declare const AlignCenterHorizontalSimple: (props: IconProps) => React.JSX.Element;
export default AlignCenterHorizontalSimple;
//# sourceMappingURL=AlignCenterHorizontalSimple.d.ts.map