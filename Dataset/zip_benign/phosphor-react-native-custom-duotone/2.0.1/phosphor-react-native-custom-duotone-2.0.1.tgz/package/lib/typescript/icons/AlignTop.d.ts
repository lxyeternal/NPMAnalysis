import React from 'react';
import { IconProps } from '../lib';
declare function AlignTop({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignTop;
//# sourceMappingURL=AlignTop.d.ts.map