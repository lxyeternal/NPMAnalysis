import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowRightDown: (props: IconProps) => React.JSX.Element;
export default ArrowElbowRightDown;
//# sourceMappingURL=ArrowElbowRightDown.d.ts.map