import * as React from "react";
import { IconProps } from '../lib';
declare const AirplaneLanding: (props: IconProps) => React.JSX.Element;
export default AirplaneLanding;
//# sourceMappingURL=AirplaneLanding.d.ts.map