import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleUpRight: (props: IconProps) => React.JSX.Element;
export default ArrowCircleUpRight;
//# sourceMappingURL=ArrowCircleUpRight.d.ts.map