import React from 'react';
import { IconProps } from '../lib';
declare function AlignRightSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignRightSimple;
//# sourceMappingURL=AlignRightSimple.d.ts.map