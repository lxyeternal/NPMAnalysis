import * as React from "react";
import { IconProps } from '../lib';
declare const AppleLogo: (props: IconProps) => React.JSX.Element;
export default AppleLogo;
//# sourceMappingURL=AppleLogo.d.ts.map