import * as React from "react";
import { IconProps } from '../lib';
declare const AlignCenterVerticalSimple: (props: IconProps) => React.JSX.Element;
export default AlignCenterVerticalSimple;
//# sourceMappingURL=AlignCenterVerticalSimple.d.ts.map