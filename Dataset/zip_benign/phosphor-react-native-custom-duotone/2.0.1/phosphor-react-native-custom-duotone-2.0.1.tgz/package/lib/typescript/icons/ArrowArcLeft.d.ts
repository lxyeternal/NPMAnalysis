import React from 'react';
import { IconProps } from '../lib';
declare function ArrowArcLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowArcLeft;
//# sourceMappingURL=ArrowArcLeft.d.ts.map