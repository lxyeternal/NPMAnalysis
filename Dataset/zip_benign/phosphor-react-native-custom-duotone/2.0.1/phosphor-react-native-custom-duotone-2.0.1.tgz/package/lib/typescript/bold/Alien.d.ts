import * as React from "react";
import { IconProps } from '../lib';
declare const Alien: (props: IconProps) => React.JSX.Element;
export default Alien;
//# sourceMappingURL=Alien.d.ts.map