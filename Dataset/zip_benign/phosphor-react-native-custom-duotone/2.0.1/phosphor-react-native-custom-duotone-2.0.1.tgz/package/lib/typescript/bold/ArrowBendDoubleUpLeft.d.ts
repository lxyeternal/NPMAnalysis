import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendDoubleUpLeft: (props: IconProps) => React.JSX.Element;
export default ArrowBendDoubleUpLeft;
//# sourceMappingURL=ArrowBendDoubleUpLeft.d.ts.map