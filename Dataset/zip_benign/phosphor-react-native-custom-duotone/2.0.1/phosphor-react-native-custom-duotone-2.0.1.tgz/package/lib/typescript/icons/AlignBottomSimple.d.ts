import React from 'react';
import { IconProps } from '../lib';
declare function AlignBottomSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignBottomSimple;
//# sourceMappingURL=AlignBottomSimple.d.ts.map