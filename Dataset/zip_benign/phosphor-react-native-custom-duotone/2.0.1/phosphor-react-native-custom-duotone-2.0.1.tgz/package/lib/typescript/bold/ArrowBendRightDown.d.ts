import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendRightDown: (props: IconProps) => React.JSX.Element;
export default ArrowBendRightDown;
//# sourceMappingURL=ArrowBendRightDown.d.ts.map