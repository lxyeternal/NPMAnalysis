import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleUpLeft: (props: IconProps) => React.JSX.Element;
export default ArrowCircleUpLeft;
//# sourceMappingURL=ArrowCircleUpLeft.d.ts.map