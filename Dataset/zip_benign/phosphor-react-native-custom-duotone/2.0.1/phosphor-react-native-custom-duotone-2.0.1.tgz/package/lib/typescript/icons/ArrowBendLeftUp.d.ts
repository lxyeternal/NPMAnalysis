import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendLeftUp({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendLeftUp;
//# sourceMappingURL=ArrowBendLeftUp.d.ts.map