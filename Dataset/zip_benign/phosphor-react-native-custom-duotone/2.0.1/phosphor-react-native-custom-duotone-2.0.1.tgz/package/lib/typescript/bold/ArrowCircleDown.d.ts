import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleDown: (props: IconProps) => React.JSX.Element;
export default ArrowCircleDown;
//# sourceMappingURL=ArrowCircleDown.d.ts.map