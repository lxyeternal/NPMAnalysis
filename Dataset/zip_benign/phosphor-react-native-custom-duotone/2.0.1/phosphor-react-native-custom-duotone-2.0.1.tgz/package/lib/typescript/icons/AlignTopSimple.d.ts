import React from 'react';
import { IconProps } from '../lib';
declare function AlignTopSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignTopSimple;
//# sourceMappingURL=AlignTopSimple.d.ts.map