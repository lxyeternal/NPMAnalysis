import React from 'react';
import { IconProps } from '../lib';
declare function ApplePodcastsLogo({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ApplePodcastsLogo;
//# sourceMappingURL=ApplePodcastsLogo.d.ts.map