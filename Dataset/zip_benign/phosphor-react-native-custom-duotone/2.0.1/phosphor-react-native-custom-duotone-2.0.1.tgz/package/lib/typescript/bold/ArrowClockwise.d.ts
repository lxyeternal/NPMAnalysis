import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowClockwise: (props: IconProps) => React.JSX.Element;
export default ArrowClockwise;
//# sourceMappingURL=ArrowClockwise.d.ts.map