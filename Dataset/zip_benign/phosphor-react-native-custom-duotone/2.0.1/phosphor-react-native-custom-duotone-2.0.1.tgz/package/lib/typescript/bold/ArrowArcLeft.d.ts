import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowArcLeft: (props: IconProps) => React.JSX.Element;
export default ArrowArcLeft;
//# sourceMappingURL=ArrowArcLeft.d.ts.map