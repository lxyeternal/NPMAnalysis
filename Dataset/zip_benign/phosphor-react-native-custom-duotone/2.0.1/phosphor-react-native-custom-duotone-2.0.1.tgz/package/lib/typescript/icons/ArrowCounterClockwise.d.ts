import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCounterClockwise({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCounterClockwise;
//# sourceMappingURL=ArrowCounterClockwise.d.ts.map