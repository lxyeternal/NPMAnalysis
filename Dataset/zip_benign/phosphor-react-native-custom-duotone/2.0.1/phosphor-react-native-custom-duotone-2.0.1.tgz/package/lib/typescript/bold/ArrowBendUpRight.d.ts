import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendUpRight: (props: IconProps) => React.JSX.Element;
export default ArrowBendUpRight;
//# sourceMappingURL=ArrowBendUpRight.d.ts.map