import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleDownLeft: (props: IconProps) => React.JSX.Element;
export default ArrowCircleDownLeft;
//# sourceMappingURL=ArrowCircleDownLeft.d.ts.map