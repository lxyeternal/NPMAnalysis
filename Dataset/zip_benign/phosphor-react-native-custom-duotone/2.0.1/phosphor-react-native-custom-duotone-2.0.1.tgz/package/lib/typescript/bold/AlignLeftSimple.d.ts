import * as React from "react";
import { IconProps } from '../lib';
declare const AlignLeftSimple: (props: IconProps) => React.JSX.Element;
export default AlignLeftSimple;
//# sourceMappingURL=AlignLeftSimple.d.ts.map