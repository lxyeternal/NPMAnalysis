import * as React from "react";
import { IconProps } from '../lib';
declare const AndroidLogo: (props: IconProps) => React.JSX.Element;
export default AndroidLogo;
//# sourceMappingURL=AndroidLogo.d.ts.map