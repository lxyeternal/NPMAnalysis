import * as React from "react";
import { IconProps } from '../lib';
declare const AirplaneTilt: (props: IconProps) => React.JSX.Element;
export default AirplaneTilt;
//# sourceMappingURL=AirplaneTilt.d.ts.map