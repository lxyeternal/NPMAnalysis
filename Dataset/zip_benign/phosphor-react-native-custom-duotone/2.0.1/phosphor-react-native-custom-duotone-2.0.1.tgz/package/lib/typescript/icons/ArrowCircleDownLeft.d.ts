import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleDownLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleDownLeft;
//# sourceMappingURL=ArrowCircleDownLeft.d.ts.map