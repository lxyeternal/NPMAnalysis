import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowRight: (props: IconProps) => React.JSX.Element;
export default ArrowElbowRight;
//# sourceMappingURL=ArrowElbowRight.d.ts.map