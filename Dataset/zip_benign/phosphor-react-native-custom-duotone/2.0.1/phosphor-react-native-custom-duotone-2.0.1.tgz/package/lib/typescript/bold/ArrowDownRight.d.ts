import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowDownRight: (props: IconProps) => React.JSX.Element;
export default ArrowDownRight;
//# sourceMappingURL=ArrowDownRight.d.ts.map