import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendUpLeft: (props: IconProps) => React.JSX.Element;
export default ArrowBendUpLeft;
//# sourceMappingURL=ArrowBendUpLeft.d.ts.map