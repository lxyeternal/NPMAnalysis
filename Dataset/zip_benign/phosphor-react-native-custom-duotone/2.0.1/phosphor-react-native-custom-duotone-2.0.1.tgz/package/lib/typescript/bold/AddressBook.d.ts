import * as React from "react";
import { IconProps } from '../lib';
declare const AddressBook: (props: IconProps) => React.JSX.Element;
export default AddressBook;
//# sourceMappingURL=AddressBook.d.ts.map