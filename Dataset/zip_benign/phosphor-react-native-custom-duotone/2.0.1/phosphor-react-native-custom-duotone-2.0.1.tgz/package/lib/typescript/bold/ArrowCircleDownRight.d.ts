import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleDownRight: (props: IconProps) => React.JSX.Element;
export default ArrowCircleDownRight;
//# sourceMappingURL=ArrowCircleDownRight.d.ts.map