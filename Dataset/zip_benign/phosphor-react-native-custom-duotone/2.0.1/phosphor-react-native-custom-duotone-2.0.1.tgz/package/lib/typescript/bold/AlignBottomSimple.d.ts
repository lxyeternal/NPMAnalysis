import * as React from "react";
import { IconProps } from '../lib';
declare const AlignBottomSimple: (props: IconProps) => React.JSX.Element;
export default AlignBottomSimple;
//# sourceMappingURL=AlignBottomSimple.d.ts.map