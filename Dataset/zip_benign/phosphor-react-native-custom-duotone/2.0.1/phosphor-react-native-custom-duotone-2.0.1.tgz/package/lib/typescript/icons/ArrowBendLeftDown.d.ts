import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendLeftDown({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendLeftDown;
//# sourceMappingURL=ArrowBendLeftDown.d.ts.map