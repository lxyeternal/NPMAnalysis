import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendDoubleUpRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendDoubleUpRight;
//# sourceMappingURL=ArrowBendDoubleUpRight.d.ts.map