import React from 'react';
import { IconProps } from '../lib';
declare function AppleLogo({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AppleLogo;
//# sourceMappingURL=AppleLogo.d.ts.map