import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleRight;
//# sourceMappingURL=ArrowCircleRight.d.ts.map