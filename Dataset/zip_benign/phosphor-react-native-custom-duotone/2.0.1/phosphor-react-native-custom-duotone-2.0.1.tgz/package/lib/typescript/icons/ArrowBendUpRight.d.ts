import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendUpRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendUpRight;
//# sourceMappingURL=ArrowBendUpRight.d.ts.map