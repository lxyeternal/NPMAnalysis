import React from 'react';
import { IconProps } from '../lib';
declare function AlignCenterVerticalSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignCenterVerticalSimple;
//# sourceMappingURL=AlignCenterVerticalSimple.d.ts.map