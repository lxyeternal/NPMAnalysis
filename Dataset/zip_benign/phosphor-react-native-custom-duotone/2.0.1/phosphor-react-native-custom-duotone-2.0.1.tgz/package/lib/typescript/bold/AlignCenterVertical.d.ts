import * as React from "react";
import { IconProps } from '../lib';
declare const AlignCenterVertical: (props: IconProps) => React.JSX.Element;
export default AlignCenterVertical;
//# sourceMappingURL=AlignCenterVertical.d.ts.map