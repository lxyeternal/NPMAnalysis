import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowLeft;
//# sourceMappingURL=ArrowElbowLeft.d.ts.map