import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowLeftUp({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowLeftUp;
//# sourceMappingURL=ArrowElbowLeftUp.d.ts.map