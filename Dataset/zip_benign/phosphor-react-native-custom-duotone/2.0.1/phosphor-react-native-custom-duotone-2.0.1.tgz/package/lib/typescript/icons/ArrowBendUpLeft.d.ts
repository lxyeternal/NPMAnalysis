import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendUpLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendUpLeft;
//# sourceMappingURL=ArrowBendUpLeft.d.ts.map