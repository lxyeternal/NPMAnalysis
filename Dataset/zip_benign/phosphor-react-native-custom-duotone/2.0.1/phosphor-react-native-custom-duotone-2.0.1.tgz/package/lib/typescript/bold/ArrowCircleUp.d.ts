import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleUp: (props: IconProps) => React.JSX.Element;
export default ArrowCircleUp;
//# sourceMappingURL=ArrowCircleUp.d.ts.map