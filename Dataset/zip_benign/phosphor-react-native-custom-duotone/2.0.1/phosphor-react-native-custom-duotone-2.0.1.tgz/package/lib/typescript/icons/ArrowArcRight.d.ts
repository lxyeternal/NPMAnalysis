import React from 'react';
import { IconProps } from '../lib';
declare function ArrowArcRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowArcRight;
//# sourceMappingURL=ArrowArcRight.d.ts.map