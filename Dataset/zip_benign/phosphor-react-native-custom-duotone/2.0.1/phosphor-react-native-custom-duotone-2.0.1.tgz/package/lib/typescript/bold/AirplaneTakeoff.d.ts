import * as React from "react";
import { IconProps } from '../lib';
declare const AirplaneTakeoff: (props: IconProps) => React.JSX.Element;
export default AirplaneTakeoff;
//# sourceMappingURL=AirplaneTakeoff.d.ts.map