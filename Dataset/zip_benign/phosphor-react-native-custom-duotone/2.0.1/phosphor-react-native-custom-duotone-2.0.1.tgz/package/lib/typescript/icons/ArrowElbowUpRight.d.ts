import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowUpRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowUpRight;
//# sourceMappingURL=ArrowElbowUpRight.d.ts.map