import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCounterClockwise: (props: IconProps) => React.JSX.Element;
export default ArrowCounterClockwise;
//# sourceMappingURL=ArrowCounterClockwise.d.ts.map