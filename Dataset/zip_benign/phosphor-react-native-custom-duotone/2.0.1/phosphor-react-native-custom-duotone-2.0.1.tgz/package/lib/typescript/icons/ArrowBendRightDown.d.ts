import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendRightDown({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendRightDown;
//# sourceMappingURL=ArrowBendRightDown.d.ts.map