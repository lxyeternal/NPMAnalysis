import React from 'react';
import { IconProps } from '../lib';
declare function AmazonLogo({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AmazonLogo;
//# sourceMappingURL=AmazonLogo.d.ts.map