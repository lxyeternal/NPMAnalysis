import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowLeft: (props: IconProps) => React.JSX.Element;
export default ArrowElbowLeft;
//# sourceMappingURL=ArrowElbowLeft.d.ts.map