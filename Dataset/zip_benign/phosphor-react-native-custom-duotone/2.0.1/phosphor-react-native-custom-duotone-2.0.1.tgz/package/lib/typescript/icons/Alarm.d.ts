import React from 'react';
import { IconProps } from '../lib';
declare function Alarm({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Alarm;
//# sourceMappingURL=Alarm.d.ts.map