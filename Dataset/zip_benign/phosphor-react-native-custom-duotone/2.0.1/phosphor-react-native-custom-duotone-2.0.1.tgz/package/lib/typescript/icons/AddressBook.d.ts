import React from 'react';
import { IconProps } from '../lib';
declare function AddressBook({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AddressBook;
//# sourceMappingURL=AddressBook.d.ts.map