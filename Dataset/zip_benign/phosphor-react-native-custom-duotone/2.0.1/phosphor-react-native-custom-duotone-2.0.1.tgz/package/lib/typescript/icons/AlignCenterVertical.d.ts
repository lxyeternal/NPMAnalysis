import React from 'react';
import { IconProps } from '../lib';
declare function AlignCenterVertical({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignCenterVertical;
//# sourceMappingURL=AlignCenterVertical.d.ts.map