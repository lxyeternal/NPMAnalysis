import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowRightDown({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowRightDown;
//# sourceMappingURL=ArrowElbowRightDown.d.ts.map