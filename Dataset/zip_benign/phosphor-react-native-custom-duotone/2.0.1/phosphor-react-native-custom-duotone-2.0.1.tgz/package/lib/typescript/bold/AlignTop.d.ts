import * as React from "react";
import { IconProps } from '../lib';
declare const AlignTop: (props: IconProps) => React.JSX.Element;
export default AlignTop;
//# sourceMappingURL=AlignTop.d.ts.map