import * as React from "react";
import { IconProps } from '../lib';
declare const Archive: (props: IconProps) => React.JSX.Element;
export default Archive;
//# sourceMappingURL=Archive.d.ts.map