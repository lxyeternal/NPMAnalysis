import * as React from "react";
import { IconProps } from '../lib';
declare const AlignTopSimple: (props: IconProps) => React.JSX.Element;
export default AlignTopSimple;
//# sourceMappingURL=AlignTopSimple.d.ts.map