import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleLeft: (props: IconProps) => React.JSX.Element;
export default ArrowCircleLeft;
//# sourceMappingURL=ArrowCircleLeft.d.ts.map