import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendDownLeft: (props: IconProps) => React.JSX.Element;
export default ArrowBendDownLeft;
//# sourceMappingURL=ArrowBendDownLeft.d.ts.map