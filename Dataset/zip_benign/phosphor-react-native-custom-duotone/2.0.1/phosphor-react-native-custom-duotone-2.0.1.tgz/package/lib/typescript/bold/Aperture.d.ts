import * as React from "react";
import { IconProps } from '../lib';
declare const Aperture: (props: IconProps) => React.JSX.Element;
export default Aperture;
//# sourceMappingURL=Aperture.d.ts.map