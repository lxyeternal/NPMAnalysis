import * as React from "react";
import { IconProps } from '../lib';
declare const AppWindow: (props: IconProps) => React.JSX.Element;
export default AppWindow;
//# sourceMappingURL=AppWindow.d.ts.map