import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowRightUp: (props: IconProps) => React.JSX.Element;
export default ArrowElbowRightUp;
//# sourceMappingURL=ArrowElbowRightUp.d.ts.map