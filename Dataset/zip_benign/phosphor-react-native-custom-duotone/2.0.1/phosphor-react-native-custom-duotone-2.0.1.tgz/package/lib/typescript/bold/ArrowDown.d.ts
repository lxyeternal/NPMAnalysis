import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowDown: (props: IconProps) => React.JSX.Element;
export default ArrowDown;
//# sourceMappingURL=ArrowDown.d.ts.map