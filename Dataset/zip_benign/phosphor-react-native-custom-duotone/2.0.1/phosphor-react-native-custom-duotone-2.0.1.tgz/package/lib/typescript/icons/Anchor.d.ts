import React from 'react';
import { IconProps } from '../lib';
declare function Anchor({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Anchor;
//# sourceMappingURL=Anchor.d.ts.map