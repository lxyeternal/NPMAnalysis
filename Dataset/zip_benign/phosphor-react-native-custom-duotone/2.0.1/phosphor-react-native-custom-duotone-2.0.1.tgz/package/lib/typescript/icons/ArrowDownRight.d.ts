import React from 'react';
import { IconProps } from '../lib';
declare function ArrowDownRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowDownRight;
//# sourceMappingURL=ArrowDownRight.d.ts.map