import React from 'react';
import { IconProps } from '../lib';
declare function Airplay({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Airplay;
//# sourceMappingURL=Airplay.d.ts.map