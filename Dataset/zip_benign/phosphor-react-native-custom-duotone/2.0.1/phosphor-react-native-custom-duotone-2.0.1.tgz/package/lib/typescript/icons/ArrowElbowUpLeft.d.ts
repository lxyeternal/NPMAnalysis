import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowUpLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowUpLeft;
//# sourceMappingURL=ArrowElbowUpLeft.d.ts.map