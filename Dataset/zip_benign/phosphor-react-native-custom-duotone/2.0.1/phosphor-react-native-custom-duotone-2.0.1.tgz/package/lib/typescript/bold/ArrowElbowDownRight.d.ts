import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowDownRight: (props: IconProps) => React.JSX.Element;
export default ArrowElbowDownRight;
//# sourceMappingURL=ArrowElbowDownRight.d.ts.map