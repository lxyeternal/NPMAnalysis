import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowUpRight: (props: IconProps) => React.JSX.Element;
export default ArrowElbowUpRight;
//# sourceMappingURL=ArrowElbowUpRight.d.ts.map