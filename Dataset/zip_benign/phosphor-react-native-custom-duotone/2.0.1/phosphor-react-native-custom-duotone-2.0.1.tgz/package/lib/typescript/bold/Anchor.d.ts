import * as React from "react";
import { IconProps } from '../lib';
declare const Anchor: (props: IconProps) => React.JSX.Element;
export default Anchor;
//# sourceMappingURL=Anchor.d.ts.map