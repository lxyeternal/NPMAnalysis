import * as React from "react";
import { IconProps } from '../lib';
declare const AnchorSimple: (props: IconProps) => React.JSX.Element;
export default AnchorSimple;
//# sourceMappingURL=AnchorSimple.d.ts.map