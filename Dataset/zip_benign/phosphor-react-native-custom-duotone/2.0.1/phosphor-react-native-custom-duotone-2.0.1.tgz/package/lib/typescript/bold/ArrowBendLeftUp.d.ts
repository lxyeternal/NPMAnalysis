import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendLeftUp: (props: IconProps) => React.JSX.Element;
export default ArrowBendLeftUp;
//# sourceMappingURL=ArrowBendLeftUp.d.ts.map