import * as React from "react";
import { IconProps } from '../lib';
declare const AlignCenterHorizontal: (props: IconProps) => React.JSX.Element;
export default AlignCenterHorizontal;
//# sourceMappingURL=AlignCenterHorizontal.d.ts.map