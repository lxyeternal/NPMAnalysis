import * as React from "react";
import { IconProps } from '../lib';
declare const AlignRight: (props: IconProps) => React.JSX.Element;
export default AlignRight;
//# sourceMappingURL=AlignRight.d.ts.map