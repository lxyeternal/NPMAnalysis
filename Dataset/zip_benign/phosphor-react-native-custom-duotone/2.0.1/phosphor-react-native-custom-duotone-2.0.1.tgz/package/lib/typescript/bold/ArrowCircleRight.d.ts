import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowCircleRight: (props: IconProps) => React.JSX.Element;
export default ArrowCircleRight;
//# sourceMappingURL=ArrowCircleRight.d.ts.map