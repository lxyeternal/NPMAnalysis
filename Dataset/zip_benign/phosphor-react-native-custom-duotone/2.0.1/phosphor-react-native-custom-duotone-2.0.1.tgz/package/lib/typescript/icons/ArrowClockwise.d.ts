import React from 'react';
import { IconProps } from '../lib';
declare function ArrowClockwise({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowClockwise;
//# sourceMappingURL=ArrowClockwise.d.ts.map