import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowArcRight: (props: IconProps) => React.JSX.Element;
export default ArrowArcRight;
//# sourceMappingURL=ArrowArcRight.d.ts.map