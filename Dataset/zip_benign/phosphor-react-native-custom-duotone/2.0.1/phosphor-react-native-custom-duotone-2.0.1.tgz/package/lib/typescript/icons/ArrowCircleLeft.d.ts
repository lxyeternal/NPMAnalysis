import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleLeft;
//# sourceMappingURL=ArrowCircleLeft.d.ts.map