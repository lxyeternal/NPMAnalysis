import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowLeftDown: (props: IconProps) => React.JSX.Element;
export default ArrowElbowLeftDown;
//# sourceMappingURL=ArrowElbowLeftDown.d.ts.map