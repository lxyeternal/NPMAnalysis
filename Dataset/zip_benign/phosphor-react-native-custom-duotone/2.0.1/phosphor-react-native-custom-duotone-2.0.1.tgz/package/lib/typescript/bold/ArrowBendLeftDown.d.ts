import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendLeftDown: (props: IconProps) => React.JSX.Element;
export default ArrowBendLeftDown;
//# sourceMappingURL=ArrowBendLeftDown.d.ts.map