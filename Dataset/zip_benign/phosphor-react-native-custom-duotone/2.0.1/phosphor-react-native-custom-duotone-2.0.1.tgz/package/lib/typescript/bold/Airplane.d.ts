import * as React from "react";
import { IconProps } from '../lib';
declare const Airplane: (props: IconProps) => React.JSX.Element;
export default Airplane;
//# sourceMappingURL=Airplane.d.ts.map