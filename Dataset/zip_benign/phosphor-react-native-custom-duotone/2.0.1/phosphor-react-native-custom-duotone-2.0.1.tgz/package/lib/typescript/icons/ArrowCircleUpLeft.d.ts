import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleUpLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleUpLeft;
//# sourceMappingURL=ArrowCircleUpLeft.d.ts.map