import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendDoubleUpRight: (props: IconProps) => React.JSX.Element;
export default ArrowBendDoubleUpRight;
//# sourceMappingURL=ArrowBendDoubleUpRight.d.ts.map