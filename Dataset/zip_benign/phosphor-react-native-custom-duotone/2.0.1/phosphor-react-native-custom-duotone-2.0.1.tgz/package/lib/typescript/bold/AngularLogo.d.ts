import * as React from "react";
import { IconProps } from '../lib';
declare const AngularLogo: (props: IconProps) => React.JSX.Element;
export default AngularLogo;
//# sourceMappingURL=AngularLogo.d.ts.map