import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowRightUp({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowRightUp;
//# sourceMappingURL=ArrowElbowRightUp.d.ts.map