import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowDownLeft({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowDownLeft;
//# sourceMappingURL=ArrowElbowDownLeft.d.ts.map