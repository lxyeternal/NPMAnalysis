import * as React from "react";
import { IconProps } from '../lib';
declare const AirTrafficControl: (props: IconProps) => React.JSX.Element;
export default AirTrafficControl;
//# sourceMappingURL=AirTrafficControl.d.ts.map