import React from 'react';
import { IconProps } from '../lib';
declare function ArrowElbowLeftDown({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowElbowLeftDown;
//# sourceMappingURL=ArrowElbowLeftDown.d.ts.map