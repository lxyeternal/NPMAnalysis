import * as React from "react";
import { IconProps } from '../lib';
declare const Armchair: (props: IconProps) => React.JSX.Element;
export default Armchair;
//# sourceMappingURL=Armchair.d.ts.map