import React from 'react';
import { IconProps } from '../lib';
declare function ArrowBendDownRight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowBendDownRight;
//# sourceMappingURL=ArrowBendDownRight.d.ts.map