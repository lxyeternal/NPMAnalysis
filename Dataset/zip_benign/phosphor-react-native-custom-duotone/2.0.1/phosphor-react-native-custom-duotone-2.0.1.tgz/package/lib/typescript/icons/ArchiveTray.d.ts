import React from 'react';
import { IconProps } from '../lib';
declare function ArchiveTray({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArchiveTray;
//# sourceMappingURL=ArchiveTray.d.ts.map