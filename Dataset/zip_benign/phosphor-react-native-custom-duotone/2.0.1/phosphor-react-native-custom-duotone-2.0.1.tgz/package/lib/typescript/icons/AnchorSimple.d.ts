import React from 'react';
import { IconProps } from '../lib';
declare function AnchorSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AnchorSimple;
//# sourceMappingURL=AnchorSimple.d.ts.map