import React from 'react';
import { IconProps } from '../lib';
declare function ArrowCircleUp({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default ArrowCircleUp;
//# sourceMappingURL=ArrowCircleUp.d.ts.map