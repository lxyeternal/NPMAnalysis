import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowBendRightUp: (props: IconProps) => React.JSX.Element;
export default ArrowBendRightUp;
//# sourceMappingURL=ArrowBendRightUp.d.ts.map