import React from 'react';
import { IconProps } from '../lib';
declare function AirplaneInFlight({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AirplaneInFlight;
//# sourceMappingURL=AirplaneInFlight.d.ts.map