import * as React from "react";
import { IconProps } from '../lib';
declare const ArrowElbowLeftUp: (props: IconProps) => React.JSX.Element;
export default ArrowElbowLeftUp;
//# sourceMappingURL=ArrowElbowLeftUp.d.ts.map