import * as React from "react";
import { IconProps } from '../lib';
declare const AppStoreLogo: (props: IconProps) => React.JSX.Element;
export default AppStoreLogo;
//# sourceMappingURL=AppStoreLogo.d.ts.map