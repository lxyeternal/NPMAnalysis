import React from 'react';
import { IconProps } from '../lib';
declare function AirplaneTilt({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AirplaneTilt;
//# sourceMappingURL=AirplaneTilt.d.ts.map