import React from 'react';
import { IconProps } from '../lib';
declare function Airplane({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Airplane;
//# sourceMappingURL=Airplane.d.ts.map