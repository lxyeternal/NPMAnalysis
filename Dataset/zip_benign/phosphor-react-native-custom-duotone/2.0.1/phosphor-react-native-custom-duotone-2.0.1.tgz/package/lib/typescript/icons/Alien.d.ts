import React from 'react';
import { IconProps } from '../lib';
declare function Alien({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Alien;
//# sourceMappingURL=Alien.d.ts.map