import React from 'react';
import { IconProps } from '../lib';
declare function Armchair({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default Armchair;
//# sourceMappingURL=Armchair.d.ts.map