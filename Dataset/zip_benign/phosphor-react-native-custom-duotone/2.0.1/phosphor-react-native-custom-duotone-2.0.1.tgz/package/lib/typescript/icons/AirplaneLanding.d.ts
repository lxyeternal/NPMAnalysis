import React from 'react';
import { IconProps } from '../lib';
declare function AirplaneLanding({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AirplaneLanding;
//# sourceMappingURL=AirplaneLanding.d.ts.map