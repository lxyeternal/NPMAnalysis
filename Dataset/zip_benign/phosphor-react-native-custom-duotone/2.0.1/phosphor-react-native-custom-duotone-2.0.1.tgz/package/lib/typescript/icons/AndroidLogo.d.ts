import React from 'react';
import { IconProps } from '../lib';
declare function AndroidLogo({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AndroidLogo;
//# sourceMappingURL=AndroidLogo.d.ts.map