import React from 'react';
import { IconProps } from '../lib';
declare function AlignCenterHorizontalSimple({ weight, color, size, style, mirrored, duotoneColor, duotoneOpacity }: IconProps): React.JSX.Element;
export default AlignCenterHorizontalSimple;
//# sourceMappingURL=AlignCenterHorizontalSimple.d.ts.map