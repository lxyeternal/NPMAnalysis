import * as i0 from '@angular/core';
import { Component, Inject, NgModule, Injectable } from '@angular/core';
import * as i4 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';

class MessageBoxComponent {
    constructor(_matDialogRef, _data) {
        this._matDialogRef = _matDialogRef;
        this._data = _data;
        this.title = "Mensaje";
        this.contents = [];
        this.backdropClick = false;
        this.icon = "";
        this.ngStyle = {};
        this.buttonCancelHidden = true;
        this.buttonCancelText = "No";
        this.buttonCancelIconHidden = true;
        this.buttonConfirmText = "Si";
        this.buttonConfirmIconHidden = true;
        this.actionAlign = "center";
        this._matDialogRef.addPanelClass('nv-message-box');
        this.title = this._data.title;
        this.ngStyle = this._data.ngStyle ?? {};
        if (this._data.type == 0) {
        }
        else if (this._data.type == 1) {
            this._matDialogRef.addPanelClass('nv-message-box-alert');
            this.icon = "warning";
        }
        else if (this._data.type == 2) {
            this._matDialogRef.addPanelClass('nv-message-box-error');
            this.icon = "error";
        }
        if (this._data.confirm) {
            this.buttonCancelHidden = false;
            this.buttonCancelText = "No";
            this.buttonConfirmText = "Si";
            this.actionAlign = "end";
        }
        this.actionAlign = this._data.actionAlign ?? this.actionAlign;
        if (this._matDialogRef.disableClose) {
            this._matDialogRef.backdropClick().subscribe(() => {
                if (!this.backdropClick) {
                    this.backdropClick = true;
                    this._matDialogRef.addPanelClass('nv-message-box-disable-close-lock');
                    setTimeout(() => {
                        this.backdropClick = false;
                        this._matDialogRef.removePanelClass('nv-message-box-disable-close-lock');
                    }, 500);
                }
            });
        }
        if (typeof this._data.content == "string") {
            this.contents.push(this._data.content);
        }
        else {
            this.contents = this._data.content;
        }
        console.log(this._data);
        this.buttonCancelText = this._data.buttonCancelText ?? 'No';
        this.buttonConfirmText = this._data.buttonConfirmText ?? 'Si';
    }
    ngOnInit() {
    }
    isString(value) {
        return typeof value == "string";
    }
    getList(value) {
        return value;
    }
}
MessageBoxComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxComponent, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
MessageBoxComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.2.4", type: MessageBoxComponent, selector: "nv-message-box", ngImport: i0, template: "<h2 mat-dialog-title>\r\n    <mat-icon *ngIf=\"icon != ''\" class=\"nv-message-box-icon\">{{icon}}</mat-icon>\r\n    <span>{{title}}</span>\r\n</h2>\r\n<mat-dialog-content [ngStyle]=\"ngStyle\">\r\n    <div *ngFor=\"let content of contents\" >\r\n        <ng-container *ngIf=\"isString(content); else list\">\r\n            <p style=\"white-space: pre;\">{{content}}</p>\r\n        </ng-container>\r\n        <ng-template #list>\r\n            <ul>\r\n                <li *ngFor=\"let sub of getList(content)\" style=\"white-space: pre;\">{{sub}}</li>\r\n            </ul>\r\n        </ng-template>\r\n    </div>\r\n</mat-dialog-content>\r\n<mat-dialog-actions [ngClass]=\"actionAlign\">\r\n    <!-- Bot\u00F3n cancelar -->\r\n    <button mat-stroked-button [mat-dialog-close]=\"false\"\r\n    *ngIf=\"!buttonCancelHidden\">\r\n        <div class=\"nv-message-box-bton-content\">\r\n            <span>{{buttonCancelText}}</span>\r\n        </div>\r\n    </button>\r\n\r\n    <!-- Bot\u00F3n confirmar -->\r\n    <button mat-stroked-button [mat-dialog-close]=\"true\">\r\n        <div class=\"nv-message-box-bton-content\">\r\n            <span>{{buttonConfirmText}}</span>\r\n        </div>\r\n    </button>\r\n</mat-dialog-actions>\r\n\r\n<button class=\"nv-message-box-btn-close\" mat-icon-button [mat-dialog-close]=\"false\"><mat-icon>close</mat-icon></button>", styles: ["::ng-deep .nv-message-box .mat-dialog-container{padding-top:5px;position:relative;min-width:300px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-title{display:flex;align-items:center;column-gap:5px;margin:0;padding-right:25px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-content{margin-top:8px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions{display:flex;align-items:center;column-gap:10px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions.center{justify-content:center}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions.end{justify-content:flex-end}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions .nv-message-box-bton-content{display:flex;justify-content:center;align-items:center}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions .nv-message-box-btn-icon-cancel{color:#d40e0ebd}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions .nv-message-box-btn-icon-ok{color:#008000bd}::ng-deep .nv-message-box-alert .mat-dialog-container .nv-message-box-icon{color:#9c9c15}::ng-deep .nv-message-box-alert .mat-dialog-container .nv-message-box-btn-close{color:#9c9c15}::ng-deep .nv-message-box-error .mat-dialog-container .nv-message-box-icon{color:#800707}::ng-deep .nv-message-box-error .mat-dialog-container .nv-message-box-btn-close{color:#800707}::ng-deep .nv-message-box-disable-close-lock .mat-dialog-container{animation-name:nv-message-box-disable-close-lock-show;animation-duration:.5s}.nv-message-box-btn-close{position:absolute;top:2px;right:4px}.nv-message-box-btn-close mat-icon{font-weight:600}@keyframes nv-message-box-disable-close-lock-show{0%{transform:scale(1)}50%{transform:scale(1.1)}to{transform:scale(1)}}\n"], components: [{ type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }], directives: [{ type: i1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { type: i4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { type: i4.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { type: i4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]" }, { type: i4.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'nv-message-box', template: "<h2 mat-dialog-title>\r\n    <mat-icon *ngIf=\"icon != ''\" class=\"nv-message-box-icon\">{{icon}}</mat-icon>\r\n    <span>{{title}}</span>\r\n</h2>\r\n<mat-dialog-content [ngStyle]=\"ngStyle\">\r\n    <div *ngFor=\"let content of contents\" >\r\n        <ng-container *ngIf=\"isString(content); else list\">\r\n            <p style=\"white-space: pre;\">{{content}}</p>\r\n        </ng-container>\r\n        <ng-template #list>\r\n            <ul>\r\n                <li *ngFor=\"let sub of getList(content)\" style=\"white-space: pre;\">{{sub}}</li>\r\n            </ul>\r\n        </ng-template>\r\n    </div>\r\n</mat-dialog-content>\r\n<mat-dialog-actions [ngClass]=\"actionAlign\">\r\n    <!-- Bot\u00F3n cancelar -->\r\n    <button mat-stroked-button [mat-dialog-close]=\"false\"\r\n    *ngIf=\"!buttonCancelHidden\">\r\n        <div class=\"nv-message-box-bton-content\">\r\n            <span>{{buttonCancelText}}</span>\r\n        </div>\r\n    </button>\r\n\r\n    <!-- Bot\u00F3n confirmar -->\r\n    <button mat-stroked-button [mat-dialog-close]=\"true\">\r\n        <div class=\"nv-message-box-bton-content\">\r\n            <span>{{buttonConfirmText}}</span>\r\n        </div>\r\n    </button>\r\n</mat-dialog-actions>\r\n\r\n<button class=\"nv-message-box-btn-close\" mat-icon-button [mat-dialog-close]=\"false\"><mat-icon>close</mat-icon></button>", styles: ["::ng-deep .nv-message-box .mat-dialog-container{padding-top:5px;position:relative;min-width:300px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-title{display:flex;align-items:center;column-gap:5px;margin:0;padding-right:25px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-content{margin-top:8px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions{display:flex;align-items:center;column-gap:10px}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions.center{justify-content:center}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions.end{justify-content:flex-end}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions .nv-message-box-bton-content{display:flex;justify-content:center;align-items:center}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions .nv-message-box-btn-icon-cancel{color:#d40e0ebd}::ng-deep .nv-message-box .mat-dialog-container .mat-dialog-actions .nv-message-box-btn-icon-ok{color:#008000bd}::ng-deep .nv-message-box-alert .mat-dialog-container .nv-message-box-icon{color:#9c9c15}::ng-deep .nv-message-box-alert .mat-dialog-container .nv-message-box-btn-close{color:#9c9c15}::ng-deep .nv-message-box-error .mat-dialog-container .nv-message-box-icon{color:#800707}::ng-deep .nv-message-box-error .mat-dialog-container .nv-message-box-btn-close{color:#800707}::ng-deep .nv-message-box-disable-close-lock .mat-dialog-container{animation-name:nv-message-box-disable-close-lock-show;animation-duration:.5s}.nv-message-box-btn-close{position:absolute;top:2px;right:4px}.nv-message-box-btn-close mat-icon{font-weight:600}@keyframes nv-message-box-disable-close-lock-show{0%{transform:scale(1)}50%{transform:scale(1.1)}to{transform:scale(1)}}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }]; } });

class MessageBoxModule {
}
MessageBoxModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
MessageBoxModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxModule, declarations: [MessageBoxComponent], imports: [CommonModule,
        MatDialogModule,
        MatButtonModule,
        MatIconModule] });
MessageBoxModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxModule, imports: [[
            CommonModule,
            MatDialogModule,
            MatButtonModule,
            MatIconModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MessageBoxComponent
                    ],
                    imports: [
                        CommonModule,
                        MatDialogModule,
                        MatButtonModule,
                        MatIconModule
                    ]
                }]
        }] });

class NovaModule {
}
NovaModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: NovaModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
NovaModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: NovaModule, imports: [MessageBoxModule] });
NovaModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: NovaModule, imports: [[
            MessageBoxModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: NovaModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        MessageBoxModule
                    ],
                    exports: []
                }]
        }] });

class MessageBoxService {
    constructor(_matDialog) {
        this._matDialog = _matDialog;
    }
    /**
     * Ejecuta Digalog box con el mensaje
     */
    show(data) {
        let dataDialog = {
            title: data.title ?? 'Mensaje',
            content: data.content,
            buttonConfirmText: data.buttonConfirmText,
            buttonCancelText: data.buttonCancelText,
            confirm: data.confirm,
            type: 0,
            ngStyle: data.ngStyle
        };
        return this._matDialog.open(MessageBoxComponent, {
            data: dataDialog,
            disableClose: data.disableClose,
            panelClass: data.panelClass,
            backdropClass: data.backdropClass,
            autoFocus: data.autoFocus
        });
    }
    /** Llama un cuadro de dialogo de alerta */
    alert(data) {
        let dataDialog = {
            title: data.title ?? 'Alerta',
            content: data.content,
            buttonConfirmText: data.buttonConfirmText,
            buttonCancelText: data.buttonCancelText,
            confirm: data.confirm,
            type: 1,
            ngStyle: data.ngStyle
        };
        return this._matDialog.open(MessageBoxComponent, {
            data: dataDialog,
            disableClose: data.disableClose,
            panelClass: data.panelClass,
            backdropClass: data.backdropClass,
            autoFocus: data.autoFocus
        });
    }
    /** Llama un cuadro de dialogo de error */
    error(data) {
        let dataDialog = {
            title: data.title ?? 'Error',
            content: data.content,
            buttonConfirmText: data.buttonConfirmText,
            buttonCancelText: data.buttonCancelText,
            confirm: data.confirm,
            type: 2,
            ngStyle: data.ngStyle
        };
        return this._matDialog.open(MessageBoxComponent, {
            data: dataDialog,
            disableClose: data.disableClose,
            panelClass: data.panelClass,
            backdropClass: data.backdropClass,
            autoFocus: data.autoFocus
        });
    }
}
MessageBoxService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxService, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
MessageBoxService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.2.4", ngImport: i0, type: MessageBoxService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1.MatDialog }]; } });

/*
 * Public API Surface of nova
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MessageBoxService, NovaModule };
//# sourceMappingURL=ng-nova.mjs.map
