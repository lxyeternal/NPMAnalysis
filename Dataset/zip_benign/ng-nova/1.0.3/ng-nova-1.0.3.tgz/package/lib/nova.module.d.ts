import * as i0 from "@angular/core";
import * as i1 from "./message-box/message-box.module";
export declare class NovaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NovaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NovaModule, never, [typeof i1.MessageBoxModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NovaModule>;
}
