import { OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class MessageBoxComponent implements OnInit {
    private _matDialogRef;
    private _data;
    title: string;
    contents: (string | string[])[];
    backdropClick: boolean;
    icon: string;
    ngStyle: {};
    buttonCancelHidden: boolean;
    buttonCancelText: string;
    buttonCancelIconHidden: boolean;
    buttonConfirmText: string;
    buttonConfirmIconHidden: boolean;
    actionAlign: string;
    constructor(_matDialogRef: MatDialogRef<MessageBoxComponent>, _data: {
        title: string;
        content: string | (string | string[])[];
        confirm?: boolean;
        type: number;
        buttonConfirmText?: string;
        buttonCancelText?: string;
        ngStyle?: {};
        actionAlign?: 'center' | 'end' | 'right';
    });
    ngOnInit(): void;
    isString(value: any): boolean;
    getList(value: any): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessageBoxComponent, "nv-message-box", never, {}, {}, never, never>;
}
