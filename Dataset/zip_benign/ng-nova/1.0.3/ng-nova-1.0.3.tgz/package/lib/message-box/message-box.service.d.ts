import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MessageBoxComponent } from './message-box.component';
import * as i0 from "@angular/core";
export declare class MessageBoxService {
    private _matDialog;
    constructor(_matDialog: MatDialog);
    /**
     * Ejecuta Digalog box con el mensaje
     */
    show(data: {
        content: string | string[];
        title?: string;
        disableClose?: boolean;
        confirm?: boolean;
        panelClass?: string | string[];
        buttonConfirmText?: string;
        buttonCancelText?: string;
        backdropClass?: string | string[];
        autoFocus?: boolean;
        ngStyle?: {};
    }): MatDialogRef<MessageBoxComponent, undefined | boolean>;
    /** Llama un cuadro de dialogo de alerta */
    alert(data: {
        content: string | string[];
        title?: string;
        disableClose?: boolean;
        confirm?: boolean;
        panelClass?: string | string[];
        buttonConfirmText?: string;
        buttonCancelText?: string;
        backdropClass?: string | string[];
        autoFocus?: boolean;
        ngStyle?: {};
    }): MatDialogRef<MessageBoxComponent, undefined | boolean>;
    /** Llama un cuadro de dialogo de error */
    error(data: {
        content: string | string[];
        title?: string;
        disableClose?: boolean;
        confirm?: boolean;
        panelClass?: string | string[];
        buttonConfirmText?: string;
        buttonCancelText?: string;
        backdropClass?: string | string[];
        autoFocus?: boolean;
        ngStyle?: {};
    }): MatDialogRef<MessageBoxComponent, undefined | boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MessageBoxService>;
}
