import * as i0 from "@angular/core";
import * as i1 from "./message-box.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/material/dialog";
import * as i4 from "@angular/material/button";
import * as i5 from "@angular/material/icon";
export declare class MessageBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MessageBoxModule, [typeof i1.MessageBoxComponent], [typeof i2.CommonModule, typeof i3.MatDialogModule, typeof i4.MatButtonModule, typeof i5.MatIconModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MessageBoxModule>;
}
