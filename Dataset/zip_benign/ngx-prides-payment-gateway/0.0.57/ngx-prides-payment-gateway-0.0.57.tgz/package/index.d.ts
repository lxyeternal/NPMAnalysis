/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-prides-payment-gateway" />
export * from './public-api';
