import * as i0 from '@angular/core';
import { Injectable, Component, EventEmitter, Input, Output, ViewEncapsulation, NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { from, switchMap, BehaviorSubject, map, catchError, of, timeout } from 'rxjs';
import * as i1 from '@angular/common/http';
import { HttpClientModule, provideHttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import * as i1$1 from '@angular/fire/compat/database';
import { AngularFireDatabaseModule } from '@angular/fire/compat/database';
import { faQrcode, faExclamationCircle, faCommentSms, faCopy, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import * as i5 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i11 from '@fortawesome/angular-fontawesome';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import 'swiper/css';
import * as i3 from 'ngx-toastr';
import { ToastrModule } from 'ngx-toastr';
import * as i12 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i13 from 'angularx-qrcode';
import { QRCodeModule } from 'angularx-qrcode';
import * as i8 from 'ngx-mask';
import { NgxMaskModule } from 'ngx-mask';
import * as i2 from '@angular/fire/compat';
import { AngularFireModule } from '@angular/fire/compat';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

var CardTypes;
(function (CardTypes) {
    CardTypes["none"] = "none";
    CardTypes["danger"] = "danger";
    CardTypes["warning"] = "warning";
    CardTypes["success"] = "success";
    CardTypes["info"] = "info";
})(CardTypes || (CardTypes = {}));

var PaymentGatewaySteps;
(function (PaymentGatewaySteps) {
    PaymentGatewaySteps[PaymentGatewaySteps["ValidateSecret"] = 0] = "ValidateSecret";
    PaymentGatewaySteps[PaymentGatewaySteps["PaymentGateway"] = 1] = "PaymentGateway";
    PaymentGatewaySteps[PaymentGatewaySteps["TranxConfirm"] = 2] = "TranxConfirm";
})(PaymentGatewaySteps || (PaymentGatewaySteps = {}));

var selectTab;
(function (selectTab) {
    selectTab[selectTab["none"] = 0] = "none";
    selectTab[selectTab["qr"] = 1] = "qr";
    selectTab[selectTab["sms"] = 2] = "sms";
})(selectTab || (selectTab = {}));

var TranxResponseCode;
(function (TranxResponseCode) {
    TranxResponseCode["Ok"] = "PP-200";
    TranxResponseCode["Created"] = "PP-201";
    TranxResponseCode["Unauthorized"] = "PP-401";
    TranxResponseCode["NotFoundData"] = "PP-404";
    TranxResponseCode["ProviderTimeOut"] = "PP-408";
    TranxResponseCode["InvalidAmount"] = "PP-409";
    TranxResponseCode["ServerError"] = "PP-500";
})(TranxResponseCode || (TranxResponseCode = {}));

const environment = {
    backendSecret: "A7683A8A-424E-4D6E-A151-8B5B8D81680D",
    production: false,
    fbBaseUrl: "https://prides-payments-dev.firebaseio.com/",
    secretStorage: "AES-GCM",
    pridesPaymentBaseUrlApi: "http://172.16.109.31:5002/api/v1",
    firebaseConfig: {
        apiKey: "AIzaSyD4lfSelO2NnjkVw3ceMe2f1zDPPXVidUs",
        authDomain: "prides-payments.firebaseapp.com",
        databaseURL: "https://prides-payments-dev.firebaseio.com",
        projectId: "prides-payments",
        storageBucket: "prides-payments.appspot.com",
        messagingSenderId: "184463861301",
        appId: "1:184463861301:web:aa83228d416842797cf37c",
        measurementId: "G-H2R8XVRZ0C"
    },
    fbApiKey: "ohpOGyMYCL0znhQeNDNHOmshgAImU93I8fYQ61aV"
};

class CryptoService {
    constructor() {
        this.secretKey = null;
        this.generateKey();
    }
    async generateKey() {
        this.secretKey = await window.crypto.subtle.generateKey({
            name: environment.secretStorage,
            length: 256,
        }, true, ["encrypt", "decrypt"]);
    }
    async encrypt(data) {
        if (!this.secretKey)
            return "";
        const encodedData = new TextEncoder().encode(data);
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        const encryptedData = await window.crypto.subtle.encrypt({
            name: environment.secretStorage,
            iv: iv,
        }, this.secretKey, encodedData);
        const buffer = new Uint8Array(encryptedData);
        const ivAndData = new Uint8Array(iv.length + buffer.length);
        ivAndData.set(iv);
        ivAndData.set(buffer, iv.length);
        return btoa(String.fromCharCode(...ivAndData));
    }
    async decrypt(encryptedData) {
        if (!this.secretKey)
            return "";
        const ivAndData = new Uint8Array(atob(encryptedData).split('').map(char => char.charCodeAt(0)));
        const iv = ivAndData.slice(0, 12);
        const data = ivAndData.slice(12);
        const decryptedData = await window.crypto.subtle.decrypt({
            name: environment.secretStorage,
            iv: iv,
        }, this.secretKey, data);
        return new TextDecoder().decode(decryptedData);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: CryptoService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: CryptoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: CryptoService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class AuthInterceptorService {
    constructor(_cryptoService) {
        this._cryptoService = _cryptoService;
    }
    intercept(req, next) {
        const authToken = sessionStorage.getItem('jwt_token');
        if (authToken) {
            return from(this._cryptoService.decrypt(authToken)).pipe(switchMap((decryptToken) => {
                const authReq = req.clone({
                    headers: req.headers.set('Authorization', `Bearer ${decryptToken}`)
                });
                return next.handle(authReq);
            }));
        }
        else {
            // No token present, proceed with the request without authorization header
            return next.handle(req);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: AuthInterceptorService, deps: [{ token: CryptoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: AuthInterceptorService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: AuthInterceptorService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: CryptoService }] });

class FbAccountBankServiceService {
    constructor(http) {
        this.http = http;
        this.baseUrl = environment.fbBaseUrl;
        this.apiKey = environment.fbApiKey;
    }
    getAccountBanks() {
        const tableName = "AccountBanks.json";
        const url = `${this.baseUrl}${tableName}?auth=${this.apiKey}`;
        return this.http.get(url);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbAccountBankServiceService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbAccountBankServiceService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbAccountBankServiceService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

class FbAppSettingsService {
    constructor(http) {
        this.http = http;
        this.baseUrl = environment.fbBaseUrl;
        this.apiKey = environment.fbApiKey;
    }
    getAppSettings() {
        const tableName = "AppSettings.json";
        const url = `${this.baseUrl}${tableName}?auth=${this.apiKey}`;
        return this.http.get(url);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbAppSettingsService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbAppSettingsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbAppSettingsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

class AuthService {
    constructor(http, _cryptoService) {
        this.http = http;
        this._cryptoService = _cryptoService;
        this.controllerName = "Auth";
        this.apiURL = `${environment.pridesPaymentBaseUrlApi}/${this.controllerName}`;
    }
    validateSecret(secretKey) {
        const methodName = "ValidarSecret";
        const url = `${this.apiURL}/${methodName}/secretKey?secretKey=${secretKey}`;
        return this.http.get(url).pipe(switchMap((data) => this.storeTokens(data.definition.token, data.definition.refreshToken).then(() => data)));
    }
    async storeTokens(token, refreshToken) {
        const encryptedToken = await this._cryptoService.encrypt(token);
        sessionStorage.setItem('jwt_token', encryptedToken);
        const encryptedRefreshToken = await this._cryptoService.encrypt(refreshToken);
        sessionStorage.setItem('refresh_token', encryptedRefreshToken);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: AuthService, deps: [{ token: i1.HttpClient }, { token: CryptoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: AuthService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: AuthService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: CryptoService }] });

class OrderStateManagementService {
    constructor(_cryptoService) {
        this._cryptoService = _cryptoService;
        const emptyModel = this.getEmptyTranxModel();
        this.tranxInfoState = new BehaviorSubject(emptyModel);
        this.orderTranxInfo$ = this.tranxInfoState.asObservable();
        this.initializeState();
    }
    async initializeState() {
        const initialState = await this.getDefaultState();
        this.tranxInfoState.next(initialState);
    }
    async getDefaultState() {
        let currentState;
        const currentStorageState = sessionStorage.getItem('tranxInfo');
        if (currentStorageState && currentStorageState !== '') {
            try {
                debugger;
                const decryptStorageState = await this._cryptoService.decrypt(currentStorageState);
                if (decryptStorageState !== '') {
                    currentState = JSON.parse(decryptStorageState);
                }
                else {
                    currentState = this.getEmptyTranxModel();
                }
            }
            catch (error) {
                console.error('Error decrypting storage state:', error);
                currentState = this.getEmptyTranxModel();
            }
        }
        else {
            currentState = this.getEmptyTranxModel();
        }
        return currentState;
    }
    updateOrderTranxInfo(newState) {
        this.tranxInfoState.next(newState);
        this._cryptoService
            .encrypt(JSON.stringify(newState))
            .then((encryptTranxData) => {
            sessionStorage.setItem('tranxInfo', encryptTranxData);
        });
    }
    getEmptyTranxModel() {
        const emptyDefaultState = {
            amount: 0,
            companyId: '',
            customer: '',
            detailTransaction: '',
            externalTransactionId: '',
            phoneNumber: '',
            referenceNumber: '',
            responseCode: '',
            status: '',
            transactionEnd: '',
            transactionId: '',
            transactionStart: '',
        };
        return emptyDefaultState;
    }
    clearTranxInfo() {
        this.tranxInfoState.next(this.getEmptyTranxModel());
        sessionStorage.removeItem('tranxInfo');
    }
    existTranxInfo() {
        let response = true;
        const emptyModel = this.getEmptyTranxModel();
        this.orderTranxInfo$.subscribe((data) => {
            if (data === emptyModel) {
                response = false;
            }
        });
        setTimeout(() => {
            const currentStorageState = sessionStorage.getItem('tranxInfo');
            if (!currentStorageState || currentStorageState === '') {
                response = false;
            }
        }, 1000);
        return response;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: OrderStateManagementService, deps: [{ token: CryptoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: OrderStateManagementService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: OrderStateManagementService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CryptoService }] });

class OrderService {
    constructor(http) {
        this.http = http;
        this.controllerName = "Order";
        this.apiURL = `${environment.pridesPaymentBaseUrlApi}/${this.controllerName}`;
    }
    createOrder(orderData) {
        const methodName = "CreateOrder";
        const url = `${this.apiURL}/${methodName}`;
        const response = this.http.post(url, orderData);
        return response;
    }
    validateOrder(orderData) {
        const methodName = "ValidateOrder";
        const url = `${this.apiURL}/${methodName}`;
        const response = this.http.post(url, orderData);
        return response;
    }
    reValidateOrder(orderData) {
        const methodName = "RevalidateOrder";
        const url = `${this.apiURL}/${methodName}`;
        const response = this.http.post(url, orderData);
        return response;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: OrderService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: OrderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: OrderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

class FbPaymentTransactionService {
    constructor(db) {
        this.db = db;
        this.pathRef = "PaymentTransaction";
        this.lstPaymentTranx = db.list(this.pathRef);
    }
    getAll() {
        return this.lstPaymentTranx;
    }
    getById(id) {
        const paymentRef = this.db.object(`${this.pathRef}/${id}`);
        return paymentRef.snapshotChanges().pipe(map(changes => {
            const data = changes.payload.val();
            if (data) {
                return data;
            }
            else {
                return null; // Retornar null si no hay datos
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbPaymentTransactionService, deps: [{ token: i1$1.AngularFireDatabase }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbPaymentTransactionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbPaymentTransactionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.AngularFireDatabase }] });

var DniTypes;
(function (DniTypes) {
    DniTypes[DniTypes["None"] = 0] = "None";
    DniTypes[DniTypes["Fisica"] = 1] = "Fisica";
    DniTypes[DniTypes["Juridica"] = 2] = "Juridica";
    DniTypes[DniTypes["DIMEX"] = 3] = "DIMEX";
})(DniTypes || (DniTypes = {}));

const validateMerchantInfo = (merchantPayTranxInfo) => {
    let errorMsgs = [];
    if (merchantPayTranxInfo.amount <= 0) {
        errorMsgs.push('Valor del monto inválido, debe ser mayor a 0');
    }
    if (!hasExactDecimals(merchantPayTranxInfo.amount, 2)) {
        errorMsgs.push('Formato del monto no válido. El monto debe tener un máximo de 2 decimales');
    }
    if (merchantPayTranxInfo.customer && !isValidDni(merchantPayTranxInfo.customer)) {
        errorMsgs.push('Debe validar el formato de identificación, el formato correcto es el siguiente: 0#-####-####');
    }
    if (merchantPayTranxInfo.phoneNumber && merchantPayTranxInfo.phoneNumber.length !== 8) {
        errorMsgs.push('Número de teléfono o celular debe ser de 8 dígitos');
    }
    if (merchantPayTranxInfo.redirectUrl && !isValidURL(merchantPayTranxInfo.redirectUrl)) {
        errorMsgs.push('El url ingresado no es válido');
    }
    return errorMsgs;
};
const isValidDni = (dni) => {
    const regex = /^(0[1-9])-\d{4}-\d{4}$/;
    const isValid = regex.test(dni);
    return isValid;
};
const hasExactDecimals = (num, n) => {
    const factor = Math.pow(10, n);
    return (num * factor) % 1 === 0;
};
const isValidURL = (string) => {
    const regex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;
    const isValid = regex.test(string);
    return isValid;
};
const fillCreateOrderData = (merchantData) => {
    return {
        amount: merchantData.amount,
        companyId: merchantData.companyId,
        customer: merchantData.customer,
        detailTransaction: merchantData.detailTransaction,
        externalTransactionId: merchantData.externalTransactionId,
        phoneNumber: merchantData.phoneNumber,
        referenceNumber: merchantData.referenceNumber,
        responseCode: merchantData.responseCode,
        status: merchantData.status,
        transactionEnd: merchantData.transactionEnd,
        transactionId: merchantData.transactionId,
        transactionStart: merchantData.transactionStart,
    };
};
const fillValidateOrderData = (orderInfo) => {
    const merchantData = orderInfo;
    const data = {
        transactionId: merchantData.transactionId
    };
    return data;
};
const fillRevalidateOrderData = (orderInfo) => {
    const merchantData = orderInfo;
    const data = {
        referenceNumber: merchantData.referenceNumber,
        transactionId: merchantData.transactionId
    };
    return data;
};
const getCurrentDatePath = () => {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const day = currentDate.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
};
const getCurrentISODateWithTimezone = () => {
    const date = new Date();
    const offset = -date.getTimezoneOffset();
    const sign = offset >= 0 ? '+' : '-';
    const pad = (num) => String(num).padStart(2, '0');
    const hours = pad(Math.floor(Math.abs(offset) / 60));
    const minutes = pad(Math.abs(offset) % 60);
    const isoString = date.toISOString();
    return isoString.replace('Z', `${sign}${hours}:${minutes}`);
};
const fillAuditLogsInsertParams = (orderInfo, desc, JsonResp, params, service) => {
    const logParams = {
        CompanyId: orderInfo.companyId,
        Description: desc,
        Detail: '',
        ExecutionTime: getCurrentISODateWithTimezone(),
        JsonResponse: JsonResp,
        Parameters: params,
        ServiceName: service,
        TransactionId: orderInfo.transactionId ? orderInfo.transactionId : "NODATA",
    };
    return logParams;
};
const fillTranxLogsInsertParams = (orderInfo, desc, JsonResp, params, service) => {
    const logParams = {
        CompanyId: orderInfo.companyId,
        Description: desc,
        Detail: '',
        ExecutionTime: getCurrentISODateWithTimezone(),
        JsonResponse: JsonResp,
        Parameters: params,
        ServiceName: service,
        TransactionId: orderInfo.transactionId ? orderInfo.transactionId : "NODATA",
    };
    return logParams;
};
const getDniTypes = () => {
    const dniTypes = [
        {
            id: DniTypes.Fisica,
            name: "Física"
        },
        {
            id: DniTypes.Juridica,
            name: "Jurídica"
        },
        {
            id: DniTypes.DIMEX,
            name: "DIMEX"
        }
    ];
    return dniTypes;
};
const getDniMaskAndPrefix = (dniType) => {
    let mask = "";
    let prefix = "";
    switch (dniType) {
        case DniTypes.Fisica:
            mask = "0-0000-0000";
            prefix = "0";
            break;
        case DniTypes.Juridica:
            mask = "0-000-000000";
            prefix = "0";
            break;
        case DniTypes.DIMEX:
            mask = "00000000000";
            prefix = "";
            break;
    }
    ;
    return [mask, prefix];
};

class FbLogsServiceService {
    constructor(db) {
        this.db = db;
        this.logTranxPathRef = 'LogTransaction';
        this.auditLogsPathRef = 'AuditLogs';
    }
    insertLogTransaction(logTransaction, tranxId) {
        let response = false;
        const pathRef = `${this.logTranxPathRef}/${tranxId}/Logs/NPM`;
        const logTranxList = this.db.list(pathRef);
        logTranxList
            .push(logTransaction)
            .then(() => {
            response = true;
        })
            .catch((err) => {
            console.error(err);
            response = false;
        });
        return response;
    }
    insertAuditLog(auditLog, date = getCurrentDatePath()) {
        let response = false;
        const pathRef = `${this.auditLogsPathRef}/${date}`;
        const auditLogsList = this.db.list(pathRef);
        auditLogsList
            .push(auditLog)
            .then(() => {
            response = true;
        })
            .catch(() => {
            response = false;
        });
        return response;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbLogsServiceService, deps: [{ token: i1$1.AngularFireDatabase }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbLogsServiceService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FbLogsServiceService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.AngularFireDatabase }] });

var DeviceTypes;
(function (DeviceTypes) {
    DeviceTypes["android"] = "Android";
    DeviceTypes["iOS"] = "iOS";
    DeviceTypes["windowsPhone"] = "Windows Phone";
    DeviceTypes["windows"] = "Windows";
    DeviceTypes["macOS"] = "Mac OS";
    DeviceTypes["linux"] = "Linux";
    DeviceTypes["unknown"] = "Unknownx";
})(DeviceTypes || (DeviceTypes = {}));

class UrlRedirectionService {
    constructor() { }
    doRedirectToCommerce(urlToRedirect, tranxId, status, total) {
        window.location.href = `${urlToRedirect}?tranxId=${tranxId}&orderStatus=${status}&total=${total}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: UrlRedirectionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: UrlRedirectionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: UrlRedirectionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class DeviceTypeService {
    constructor() { }
    getDeviceType() {
        const userAgent = navigator.userAgent || window.opera;
        if (/android/i.test(userAgent)) {
            return DeviceTypes.android;
        }
        if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
            return DeviceTypes.iOS;
        }
        if (/windows phone/i.test(userAgent)) {
            return DeviceTypes.windowsPhone;
        }
        if (/Win/.test(userAgent)) {
            return DeviceTypes.windows;
        }
        if (/Macintosh|MacIntel|MacPPC|Mac68K/.test(userAgent)) {
            return DeviceTypes.macOS;
        }
        if (/Linux/.test(userAgent)) {
            return DeviceTypes.linux;
        }
        return DeviceTypes.unknown;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: DeviceTypeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: DeviceTypeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: DeviceTypeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class FullScreenSpinnerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FullScreenSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.6", type: FullScreenSpinnerComponent, isStandalone: true, selector: "app-full-screen-spinner", ngImport: i0, template: "<div class=\"overlay\">\r\n    <div class=\"spinner-container\">\r\n        <div class=\"spinner\" role=\"status\">\r\n            <span class=\"sr-only\">Loading...</span>\r\n        </div>\r\n    </div>\r\n</div>", styles: [".overlay{width:100%;height:100%;position:fixed;top:0;left:0;background-color:#fff;opacity:.8;z-index:50}.spinner-container{display:flex;justify-content:center;align-items:center;margin-top:50vh}.spinner{display:inline-block;height:4rem;width:4rem;border:4px solid currentColor;border-top-color:transparent;border-radius:50%;animation:spin 1s linear infinite;color:#7c3aed}@media (prefers-reduced-motion: reduce){.spinner{animation:spin 1.5s linear infinite}}@keyframes spin{to{transform:rotate(360deg)}}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: FullScreenSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-full-screen-spinner', standalone: true, imports: [], template: "<div class=\"overlay\">\r\n    <div class=\"spinner-container\">\r\n        <div class=\"spinner\" role=\"status\">\r\n            <span class=\"sr-only\">Loading...</span>\r\n        </div>\r\n    </div>\r\n</div>", styles: [".overlay{width:100%;height:100%;position:fixed;top:0;left:0;background-color:#fff;opacity:.8;z-index:50}.spinner-container{display:flex;justify-content:center;align-items:center;margin-top:50vh}.spinner{display:inline-block;height:4rem;width:4rem;border:4px solid currentColor;border-top-color:transparent;border-radius:50%;animation:spin 1s linear infinite;color:#7c3aed}@media (prefers-reduced-motion: reduce){.spinner{animation:spin 1.5s linear infinite}}@keyframes spin{to{transform:rotate(360deg)}}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"] }]
        }] });

class PaymentRevalidationComponent {
    constructor(_currentTranxInfo, _order, _toastr, _fbLogService) {
        this._currentTranxInfo = _currentTranxInfo;
        this._order = _order;
        this._toastr = _toastr;
        this._fbLogService = _fbLogService;
        this.orderInfo = { amount: 0 };
        this.digitsInput = "";
        this.isLoading = false;
        this.flagDisableValButton = true;
        this.showModal = false;
        //It is responsible for communicating to the parent component that the modal was closed, so that it updates the flag on the parent's side
        this.closeModalEvent = new EventEmitter();
        this.onSuccessValidation = new EventEmitter();
    }
    ngOnInit() {
        this._currentTranxInfo.orderTranxInfo$.subscribe((data) => {
            this.orderInfo = data;
        });
    }
    ngOnDestroy() {
        if (this.tranxSubscription) {
            this.tranxSubscription.unsubscribe();
        }
    }
    closeModal() {
        this.showModal = false;
        this.closeModalEvent.emit(); // Notify the parent component
    }
    validateTranxDigitsFormat() {
        if (this.digitsInput.trim().length !== 8) {
            return false;
        }
        return true;
    }
    enableValidationButton() {
        const resultValidation = this.validateTranxDigitsFormat();
        this.flagDisableValButton = !resultValidation;
    }
    reValidateOrder() {
        this.isLoading = true;
        const digitsAreValid = this.validateTranxDigitsFormat();
        if (!digitsAreValid) {
            this.isLoading = false;
            return;
        }
        this.orderInfo.referenceNumber = this.digitsInput;
        const orderInfo = fillRevalidateOrderData(this.orderInfo);
        this._order.reValidateOrder(orderInfo).pipe(catchError(error => {
            const errorMsg = 'Error al revalidar la orden. Por favor, inténtelo de nuevo.';
            this.saveLogs(errorMsg, JSON.stringify(error), JSON.stringify(this.orderInfo), "OrderService");
            this._toastr.error(errorMsg);
            this.isLoading = false;
            return of(null);
        })).subscribe(data => {
            const responseMsg = data ? data.response.message : "data es null";
            this.saveLogs(responseMsg, JSON.stringify(data), JSON.stringify(this.orderInfo), "OrderService");
            if (data && !data.response.success) {
                this._toastr.warning("Orden no es válida, inténtelo nuevamente");
                this.isLoading = false;
                return;
            }
            this.isLoading = false;
            this.closeModal();
            //Execute method onSuccesValidation in the selectBankComponent      
            this.onSuccessValidation.emit();
        });
    }
    //#region logs
    saveLogs(desc, JsonResp, params, service) {
        this.saveAuditLog(desc, JsonResp, params, service);
        this.saveTranxLog(desc, JsonResp, params, service);
    }
    saveAuditLog(desc, JsonResp, params, service) {
        const logParams = fillAuditLogsInsertParams(this.orderInfo, desc, JsonResp, params, service);
        this._fbLogService.insertAuditLog(logParams);
    }
    saveTranxLog(desc, JsonResp, params, service) {
        const logParams = fillTranxLogsInsertParams(this.orderInfo, desc, JsonResp, params, service);
        this._fbLogService.insertLogTransaction(logParams, this.orderInfo.transactionId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentRevalidationComponent, deps: [{ token: OrderStateManagementService }, { token: OrderService }, { token: i3.ToastrService }, { token: FbLogsServiceService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.6", type: PaymentRevalidationComponent, selector: "app-payment-revalidation", inputs: { showModal: "showModal" }, outputs: { closeModalEvent: "closeModalEvent", onSuccessValidation: "onSuccessValidation" }, ngImport: i0, template: "<app-full-screen-spinner *ngIf=\"isLoading\"></app-full-screen-spinner>\r\n<div class=\"main-modal fixed w-full h-100 inset-0 z-40 overflow-hidden flex justify-center items-center\" \r\n     [ngClass]=\"{'fadeIn': showModal, 'fadeOut': !showModal, 'animated': true, 'faster': true}\"\r\n     [ngStyle]=\"{'display': showModal ? 'flex' : 'none', 'background': 'rgba(0,0,0,.7)'}\">\r\n<!-- Modal Content Here -->\r\n<div class=\"main-modal fixed w-auto h-100 inset-0 z-40 overflow-hidden flex justify-center items-center animated fadeIn faster\" style=\"background: rgba(0,0,0,.7);\">\r\n    <div class=\"border border-teal-500 modal-container rounded shadow-lg z-40 overflow-y-auto modalBgColor w-1/2\">\r\n        <div class=\"modal-content pt-1 pb-1\">\r\n            <!--Title-->\r\n            <div class=\"flex justify-between items-center mx-10\">                \r\n                <div class=\"modal-close z-40\">\r\n                    <p class=\"text-center text-lg text-white font-semibold pt-3\">Re-validar pago</p>                                                    \r\n                </div>\r\n                <div class=\"modal-close z-40\">\r\n                    <svg class=\"w-3 h-3 text-white cursor-pointer hover:text-gray-300\" aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 14 14\" (click)=\"closeModal()\">\r\n                        <path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6\"/>\r\n                    </svg>                                        \r\n                </div>                \r\n            </div>\r\n            <!--Body-->\r\n            <div class=\"my-2 text-white w-1/2 mx-auto\">\r\n                <label for=\"digitsInput\" class=\"mt-2  block text-center text-base font-medium\">Verificar pago, ingrese los \u00FAltimos <span class=\"font-semibold\">8 d\u00EDgitos</span>  del Num de Comprobante</label>\r\n                <input id=\"digitsInput\" maxlength=\"8\" mask=\"00000000\" [(ngModel)]=\"digitsInput\" class=\"w-full mt-2 h-8 p-1.5 border-0 border-gray-300 text-gray-500 text-base font-medium\" (input)=\"enableValidationButton()\"\r\n                    type=\"text\" placeholder=\"Ejemplo: 12345678 (solo n\u00FAmeros)\">                \r\n            </div>\r\n            <!--Footer-->\r\n            <div class=\"block mx-10 my-5\">\r\n                <button class=\"btnValidate p-3 rounded-sm text-white w-full text-center\" [disabled]=\"flagDisableValButton\" (click)=\"reValidateOrder()\">Verificar</button>                                 \r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>  \r\n", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n", "#digitsInput{border-style:solid;border-width:.1em;border-color:#d1d5db}#digitsInput:hover{outline-style:solid;outline-width:.2em;outline-color:#45008a80;border-color:#45008a80;outline-offset:.1cap}#digitsInput:focus{outline-style:solid;outline-width:.2em;outline-color:#45008a;border-color:#45008a80;border-width:.05em;outline-offset:.1cap}.btnValidate{background-color:#45008a}.btnValidate:hover{background-color:#34d399}.btnValidate:disabled{cursor:default;background-color:#6f00df;filter:brightness(50%)}.modalBgColor{background-color:#18181b}\n"], dependencies: [{ kind: "directive", type: i5.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i5.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i5.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i12.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i12.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i12.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i12.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: FullScreenSpinnerComponent, selector: "app-full-screen-spinner" }, { kind: "directive", type: i8.NgxMaskDirective, selector: "input[mask], textarea[mask]", inputs: ["mask", "specialCharacters", "patterns", "prefix", "suffix", "thousandSeparator", "decimalMarker", "dropSpecialCharacters", "hiddenInput", "showMaskTyped", "placeHolderCharacter", "shownMaskExpression", "showTemplate", "clearIfNotMatch", "validation", "separatorLimit", "allowNegativeNumbers", "leadZeroDateTime", "leadZero", "triggerOnMaskChange", "apm", "inputTransformFn", "outputTransformFn", "keepCharacterPositions"], outputs: ["maskFilled"], exportAs: ["mask", "ngxMask"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentRevalidationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-payment-revalidation', template: "<app-full-screen-spinner *ngIf=\"isLoading\"></app-full-screen-spinner>\r\n<div class=\"main-modal fixed w-full h-100 inset-0 z-40 overflow-hidden flex justify-center items-center\" \r\n     [ngClass]=\"{'fadeIn': showModal, 'fadeOut': !showModal, 'animated': true, 'faster': true}\"\r\n     [ngStyle]=\"{'display': showModal ? 'flex' : 'none', 'background': 'rgba(0,0,0,.7)'}\">\r\n<!-- Modal Content Here -->\r\n<div class=\"main-modal fixed w-auto h-100 inset-0 z-40 overflow-hidden flex justify-center items-center animated fadeIn faster\" style=\"background: rgba(0,0,0,.7);\">\r\n    <div class=\"border border-teal-500 modal-container rounded shadow-lg z-40 overflow-y-auto modalBgColor w-1/2\">\r\n        <div class=\"modal-content pt-1 pb-1\">\r\n            <!--Title-->\r\n            <div class=\"flex justify-between items-center mx-10\">                \r\n                <div class=\"modal-close z-40\">\r\n                    <p class=\"text-center text-lg text-white font-semibold pt-3\">Re-validar pago</p>                                                    \r\n                </div>\r\n                <div class=\"modal-close z-40\">\r\n                    <svg class=\"w-3 h-3 text-white cursor-pointer hover:text-gray-300\" aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 14 14\" (click)=\"closeModal()\">\r\n                        <path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6\"/>\r\n                    </svg>                                        \r\n                </div>                \r\n            </div>\r\n            <!--Body-->\r\n            <div class=\"my-2 text-white w-1/2 mx-auto\">\r\n                <label for=\"digitsInput\" class=\"mt-2  block text-center text-base font-medium\">Verificar pago, ingrese los \u00FAltimos <span class=\"font-semibold\">8 d\u00EDgitos</span>  del Num de Comprobante</label>\r\n                <input id=\"digitsInput\" maxlength=\"8\" mask=\"00000000\" [(ngModel)]=\"digitsInput\" class=\"w-full mt-2 h-8 p-1.5 border-0 border-gray-300 text-gray-500 text-base font-medium\" (input)=\"enableValidationButton()\"\r\n                    type=\"text\" placeholder=\"Ejemplo: 12345678 (solo n\u00FAmeros)\">                \r\n            </div>\r\n            <!--Footer-->\r\n            <div class=\"block mx-10 my-5\">\r\n                <button class=\"btnValidate p-3 rounded-sm text-white w-full text-center\" [disabled]=\"flagDisableValButton\" (click)=\"reValidateOrder()\">Verificar</button>                                 \r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>  \r\n", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n", "#digitsInput{border-style:solid;border-width:.1em;border-color:#d1d5db}#digitsInput:hover{outline-style:solid;outline-width:.2em;outline-color:#45008a80;border-color:#45008a80;outline-offset:.1cap}#digitsInput:focus{outline-style:solid;outline-width:.2em;outline-color:#45008a;border-color:#45008a80;border-width:.05em;outline-offset:.1cap}.btnValidate{background-color:#45008a}.btnValidate:hover{background-color:#34d399}.btnValidate:disabled{cursor:default;background-color:#6f00df;filter:brightness(50%)}.modalBgColor{background-color:#18181b}\n"] }]
        }], ctorParameters: () => [{ type: OrderStateManagementService }, { type: OrderService }, { type: i3.ToastrService }, { type: FbLogsServiceService }], propDecorators: { showModal: [{
                type: Input
            }], closeModalEvent: [{
                type: Output
            }], onSuccessValidation: [{
                type: Output
            }] } });

class PaymentSelectBankComponent {
    constructor(_fbAccountBankService, _toastr, _currentTranxInfo, _order, _appSettings, _fbPayTranx, _fbLogService, _urlRedirection, _deviceType) {
        this._fbAccountBankService = _fbAccountBankService;
        this._toastr = _toastr;
        this._currentTranxInfo = _currentTranxInfo;
        this._order = _order;
        this._appSettings = _appSettings;
        this._fbPayTranx = _fbPayTranx;
        this._fbLogService = _fbLogService;
        this._urlRedirection = _urlRedirection;
        this._deviceType = _deviceType;
        //general
        this.currentToken = '';
        this.accountBanks = [];
        this.currentSelectedTabType = selectTab.none;
        this.currentSelectedBankId = '0';
        this.bankIsSelected = false;
        this.qrdata = '';
        this.sinpeSms = '';
        this.buttonSize = 'small';
        this.isLoading = false;
        this.showRevalidationModal = false;
        this.orderInfo = { amount: 0 };
        this.numberSender = 0;
        this.currentDeviceType = DeviceTypes.unknown;
        this.deviceType = DeviceTypes;
        this.showValidationCard = false;
        this.showQrAndSmsCopyOptions = false;
        this.dniTypes = [];
        this.dniType = DniTypes.None;
        this.dniMask = "";
        this.dniMaskPrefix = "";
        //optional form values  
        this.optionalFormDniFlag = false;
        this.optionalFormDni = "";
        //Icons
        this.faQrcode = faQrcode;
        this.faExclamationCircle = faExclamationCircle;
        this.faCommentSms = faCommentSms;
        this.faCopy = faCopy;
        //decorators
        this.goToNextStep = new EventEmitter();
        //Breackpoints for swiper (slider component) reponsive
        this.breakpoints = {
            375: { slidesPerView: 1, spaceBetween: 0 },
            400: { slidesPerView: 1, spaceBetween: 0 },
            640: { slidesPerView: 1, spaceBetween: 0 },
            768: { slidesPerView: 1, spaceBetween: 0 },
            1024: { slidesPerView: 1, spaceBetween: 0 },
        };
        this.hasValidCredentials = true;
        //#endregion
        //#region create order
        this.createOrder = () => {
            const validationsResult = this.dniValidations();
            if (!validationsResult)
                return;
            const orderData = fillCreateOrderData(this.orderInfo);
            this.isLoading = true;
            this._order.createOrder(orderData).pipe(catchError((error) => {
                console.error('Error occurred:', error);
                this._toastr.error('An error occurred while creating the order. Please try again.');
                this.isLoading = false;
                return of(null);
            })).subscribe((data) => {
                if (!data.response.success) {
                    this._toastr.warning("Ocurrió un problema al generar la orden, por favor inténtelo nuevamente.");
                    this.isLoading = false;
                    return;
                }
                //update tranx id value, in the merchant data
                this.orderInfo.transactionId = data.definition.transactionId;
                this.orderInfo.companyId = data.definition.companyId;
                //save the reponse in a global state
                this._currentTranxInfo.updateOrderTranxInfo(this.orderInfo);
                const reponseMsg = data ? data.response.message : "data es null";
                this.saveLogs(reponseMsg, JSON.stringify(data), JSON.stringify(orderData), "OrderService");
                this._toastr.success("Orden creada correctamente.");
                this.showQrAndSmsCopyOptions = true;
                this.isLoading = false;
            });
        };
        this.putMaskValues = () => {
            let dniWithMaskString = "";
            if (this.dniType === DniTypes.Fisica) {
                const firstDniDigit = this.optionalFormDni.substring(0, 1);
                const nextFourDigits = this.optionalFormDni.substring(1, 5);
                const lastFourDigits = this.optionalFormDni.substring(5, 9);
                dniWithMaskString = `${this.dniMaskPrefix}${firstDniDigit}-${nextFourDigits}-${lastFourDigits}`;
            }
            if (this.dniType === DniTypes.Juridica) {
                const firstDniDigit = this.optionalFormDni.substring(0, 1);
                const nextThreeDigits = this.optionalFormDni.substring(1, 4);
                const lastFiveDigits = this.optionalFormDni.substring(4, 10);
                dniWithMaskString = `${this.dniMaskPrefix}${firstDniDigit}-${nextThreeDigits}-${lastFiveDigits}`;
            }
            if (this.dniType === DniTypes.DIMEX) {
                dniWithMaskString = this.dniMaskPrefix;
            }
            return dniWithMaskString;
        };
        this.dniValidations = () => {
            let result = true;
            if (this.optionalFormDni.trim() === "") {
                this._toastr.warning("La identificación es obligatoría");
                result = false;
            }
            const length = this.optionalFormDni.length;
            switch (this.dniType) {
                case DniTypes.Fisica:
                    if (length !== 9) {
                        this._toastr.warning("La identificación física debe contar con un mínimo de 9 caractares");
                        result = false;
                    }
                    break;
                case DniTypes.Juridica:
                    if (length !== 10) {
                        this._toastr.warning("La identificación jurídica debe contar con un mínimo de 10 caractares");
                        result = false;
                    }
                    break;
                case DniTypes.DIMEX:
                    if (length !== 11) {
                        this._toastr.warning("La identificación DIMEX debe contar con un mínimo de 11 caractares");
                        result = false;
                    }
                    break;
            }
            if (result)
                this.updateDniValues();
            return result;
        };
    }
    //#region  Oninit functions
    ngOnInit() {
        //get dni types 
        this.dniTypes = getDniTypes();
        this.dniMask = "0-0000-0000";
        this.dniMaskPrefix = "0";
        //get the validate secret token
        const hasValidCredentials = this.getIfHasValidCredentials();
        this.hasValidCredentials = hasValidCredentials;
        if (!hasValidCredentials) {
            this._toastr.warning('Credenciales de sesión no válidas');
            return;
        }
        this.getEnabledBanks();
        //get the merchant info
        this._currentTranxInfo.orderTranxInfo$.subscribe((order) => {
            this.orderInfo = order;
            this.setOptionalFormFlags(order);
        });
        //get number sender
        this._appSettings.getAppSettings().subscribe(data => {
            this.numberSender = data.NumberSender;
        });
        //get the device type
        this.currentDeviceType = this._deviceType.getDeviceType();
        if (this.orderInfo.customer && this.orderInfo.customer.trim() !== "") {
            this.showValidationCard = true;
            this.showQrAndSmsCopyOptions = true;
        }
    }
    setOptionalFormFlags(order) {
        if (!order.customer) {
            this.optionalFormDniFlag = true;
        }
        if (order.customer && order.customer.trim.length > 0) {
            this.optionalFormDniFlag = true;
        }
    }
    getIfHasValidCredentials() {
        const storageToken = sessionStorage.getItem('jwt_token');
        if (!storageToken || storageToken === "") {
            return false;
        }
        this.currentToken = storageToken;
        const hasValidTranxInfo = this._currentTranxInfo.existTranxInfo();
        if (!hasValidTranxInfo) {
            return false;
        }
        return true;
    }
    getEnabledBanks() {
        this._fbAccountBankService.getAccountBanks().subscribe((banks) => {
            let bankList = Object.values(banks);
            this.accountBanks = bankList.filter((bank) => bank.Enabled === true);
        });
    }
    //#endregion
    //#region  UI
    onSelectBank(bankId) {
        this.currentSelectedBankId = bankId;
        this.bankIsSelected = bankId == this.currentSelectedBankId && this.currentSelectedBankId != '0';
        this.currentSelectedBankId = bankId;
        this.showValidationCard = true;
        if (this.currentSelectedTabType !== selectTab.none) {
            this.onSelectTab(this.currentSelectedTabType);
        }
    }
    onSelectTab(tapOptionType) {
        const msg = this.getSmsMsg();
        if (msg.length == 0) {
            return;
        }
        const bankIsSelected = this.accountBanks.some((bank) => bank.Id == this.currentSelectedBankId);
        if (!bankIsSelected) {
            this._toastr.warning('Asegurese de seleccionar un banco');
            return;
        }
        if (tapOptionType == selectTab.sms) {
            this.currentSelectedTabType = selectTab.sms;
            this.sinpeSms = msg;
        }
        if (tapOptionType == selectTab.qr) {
            this.currentSelectedTabType = selectTab.qr;
            const encodeMsg = this.getEncodeSmsToQr(msg);
            this.qrdata = encodeMsg;
        }
    }
    getSmsMsg() {
        const smsMsg = `Pase ${this.orderInfo.amount} ${this.numberSender} ${this.orderInfo.transactionId}`;
        return smsMsg;
    }
    getSmsFormatType() {
        switch (this.currentDeviceType) {
            case DeviceTypes.android || DeviceTypes.windows || DeviceTypes.macOS || this.deviceType.linux || this.deviceType.unknown:
                return "?";
            case DeviceTypes.iOS:
                return "&";
            default:
                return "?";
        }
    }
    getEncodeSmsToQr(msg) {
        const currentBankSinpeNumber = this.accountBanks.find((bank) => bank.Id == this.currentSelectedBankId)?.PhoneReceptor;
        if (!currentBankSinpeNumber) {
            this._toastr.warning('Asegurese de seleccionar un banco');
            return '';
        }
        const bodyMsgFormat = this.getSmsFormatType();
        const encodeURISms = encodeURIComponent(msg);
        const sms = `sms:${currentBankSinpeNumber}${bodyMsgFormat}body=${encodeURISms}`;
        return sms;
    }
    copyMessage() {
        navigator.clipboard.writeText(this.sinpeSms)
            .then(() => {
            this._toastr.success("¡Mensaje copiado!");
        })
            .catch((error) => {
            this._toastr.error('Error al copiar el mensaje. Por favor, intente nuevamente.');
            console.error('Error al copiar el mensaje:', error);
        });
    }
    updateDniValues() {
        if (this.optionalFormDniFlag) {
            const dniWithMaskString = this.putMaskValues();
            this.orderInfo.customer = dniWithMaskString;
        }
        this._currentTranxInfo.updateOrderTranxInfo(this.orderInfo);
    }
    //#endregion
    //#region order validation
    validateOrder() {
        this.isLoading = true;
        //this model, should has the tranxIdInfo, this is assigned after create the order
        const orderInfoToValidate = fillValidateOrderData(this.orderInfo);
        this._order.validateOrder(orderInfoToValidate).pipe(catchError(() => {
            const errorDesc = 'Error al validar la orden. Por favor, inténtelo de nuevo.';
            this._toastr.error(errorDesc);
            this.saveLogs(errorDesc, "", JSON.stringify(this.orderInfo), "order");
            this.isLoading = false;
            return of(null);
        })).subscribe(data => {
            const dataMsg = data ? data.response.message : "data es null";
            this.saveLogs(dataMsg, JSON.stringify(data), JSON.stringify(this.orderInfo), "order");
            if (data && !data.response.success) {
                this.orderInfo.status = TranxResponseCode.Ok;
                this._currentTranxInfo.updateOrderTranxInfo(this.orderInfo);
                //Init the listen validation process
                this.listenPaymentTranInFb(orderInfoToValidate.transactionId ?? "");
            }
            if (data && data.response.success) {
                this.onSuccessValidation();
            }
        });
    }
    onSuccessValidation() {
        this.isLoading = false;
        const redirectUrl = this.orderInfo.redirectUrl;
        const tranxId = this.orderInfo.transactionId;
        const orderState = this.orderInfo.status;
        const total = this.orderInfo.amount.toString();
        //Clear token
        sessionStorage.setItem('jwt_token', '');
        //Clear tranxInfo
        this._currentTranxInfo.clearTranxInfo();
        const hasRedirectUrl = redirectUrl !== undefined && redirectUrl !== '';
        if (hasRedirectUrl) {
            this._urlRedirection.doRedirectToCommerce(redirectUrl, tranxId, orderState, total);
            return;
        }
        //Go to final step, currently is only a confirm page
        this.goToNextStep.emit(2);
    }
    closeRevalidationModal() {
        this.showRevalidationModal = false;
    }
    openRevalidationModal() {
        this.showRevalidationModal = true;
    }
    listenPaymentTranInFb(payTranxId) {
        this.paymentTranxListen = this._fbPayTranx.getById(payTranxId).pipe(timeout(30000) // 30 seconds
        ).subscribe({
            next: (data) => {
                //Update the state of order status
                this.orderInfo.status = data["ResponseCode"];
                this._currentTranxInfo.updateOrderTranxInfo(this.orderInfo);
                const currentResponseCode = data["ResponseCode"];
                if (currentResponseCode != TranxResponseCode.Created) {
                    this.actionsOnResponse(data["ResponseCode"]);
                }
                const logMsg = `Estado de transacción cambió de ${TranxResponseCode.Created} a ${currentResponseCode}`;
                this.saveLogs(logMsg, JSON.stringify(data), payTranxId, "FbPaymentTransactionService");
            },
            error: (err) => {
                if (err.name === 'TimeoutError') {
                    const logMsg = "Orden no ha sido creada correctamente, puede proceder a validar el estado de forma manual";
                    this._toastr.warning(logMsg);
                    this.showRevalidationModal = true;
                    this.isLoading = false;
                    this.saveLogs(`${logMsg}. ${err.name}.`, "", payTranxId, "FbPaymentTransactionService");
                }
                else {
                    const logMsg = "Ocurrió un problema en el servidor al realizar la solicitud, inténtelo nuevamente";
                    this._toastr.warning(logMsg);
                    this.saveLogs(logMsg, "", payTranxId, "FbPaymentTransactionService");
                }
            }
        });
    }
    actionsOnResponse(responseCode) {
        const incorrectResponses = [
            TranxResponseCode.InvalidAmount,
            TranxResponseCode.NotFoundData,
            TranxResponseCode.ProviderTimeOut,
            TranxResponseCode.ServerError,
            TranxResponseCode.Unauthorized
        ];
        const isIncorrectResponse = incorrectResponses.some(r => r === responseCode);
        if (isIncorrectResponse) {
            this._toastr.warning("No se pudo valida la orden, puede proceder a revalidar el estado de forma manual");
            //open the modal to revalidate order
            this.showRevalidationModal = true;
            this.isLoading = false;
            return;
        }
        if (responseCode === TranxResponseCode.Ok) {
            this.onSuccessValidation();
        }
    }
    onSelectDniType(event) {
        const target = event.target;
        this.dniType = Number(target.value);
        if (this.dniType === DniTypes.None) {
            this.optionalFormDni = "";
        }
        //get the dni mask, this is basically a tuple
        let dniMaskAndPrefix = getDniMaskAndPrefix(this.dniType);
        this.dniMask = dniMaskAndPrefix[0];
        this.dniMaskPrefix = dniMaskAndPrefix[1];
    }
    //#endregion
    //#region logs
    saveLogs(desc, JsonResp, params, service) {
        this.saveAuditLog(desc, JsonResp, params, service);
        this.saveTranxLog(desc, JsonResp, params, service);
    }
    saveAuditLog(desc, JsonResp, params, service) {
        const logParams = fillAuditLogsInsertParams(this.orderInfo, desc, JsonResp, params, service);
        this._fbLogService.insertAuditLog(logParams);
    }
    saveTranxLog(desc, JsonResp, params, service) {
        const logParams = fillTranxLogsInsertParams(this.orderInfo, desc, JsonResp, params, service);
        this._fbLogService.insertLogTransaction(logParams, this.orderInfo.transactionId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentSelectBankComponent, deps: [{ token: FbAccountBankServiceService }, { token: i3.ToastrService }, { token: OrderStateManagementService }, { token: OrderService }, { token: FbAppSettingsService }, { token: FbPaymentTransactionService }, { token: FbLogsServiceService }, { token: UrlRedirectionService }, { token: DeviceTypeService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.6", type: PaymentSelectBankComponent, selector: "app-payment-select-bank", outputs: { goToNextStep: "goToNextStep" }, ngImport: i0, template: "<app-full-screen-spinner *ngIf=\"isLoading\"></app-full-screen-spinner>\r\n<div *ngIf=\"!isLoading && hasValidCredentials\" class=\"bg-slate-100 rounded-lg shadow-md lg:m-5 lg:p-5 md:m-2 md:p-2 sm:m-0 sm:p-0\">        \r\n    <h2 class=\"text-center text-xl text-gray-600\">Por favor seleccione un banco</h2>\r\n    <swiper-container class=\"mx-8\" loop=\"false\" navigation=\"true\" [breakpoints]=\"breakpoints\">\r\n        <swiper-slide *ngFor=\"let bank of accountBanks\" class=\"swiper-slide text-center text-xl\">        \r\n            <div class=\"selectCard bg-white mx-auto my-8 p-5 lg:w-1/4 w-1/3\" [ngClass]=\"{selectedBank: bank.Id == currentSelectedBankId}\"  (click)=\"onSelectBank(bank.Id) \">\r\n                <!-- BANK INFORMATION AND SELECTION -->            \r\n                <img class=\"img-responsive rounded-sm p-1 shadow-sm\" src={{bank.Image}} alt={{bank.Name}}>\r\n                <div class=\"my-5\">\r\n                    <p class=\"text-center text-xl text-gray-600 mt-1\">{{bank.Name}}</p>                \r\n                    <p class=\"text-center text-xl text-gray-600 mt-1\">{{bank.PhoneReceptor}}</p>                                    \r\n                </div>                                    \r\n            </div>            \r\n        </swiper-slide>                           \r\n    </swiper-container>\r\n    <div *ngIf=\"showValidationCard\" class=\"block mt-3\">        \r\n        <div *ngIf=\"optionalFormDniFlag && !showQrAndSmsCopyOptions\" class=\" bg-white mx-auto px-5 pb-3 sm:w-full md:w-full lg:w-1/4 flex-1\">                \r\n            <p class=\"text-center text-lg text-gray-500 font-semibold bg-white pt-3\">Digite la informaci\u00F3n correspondiente</p>            \r\n            <div class=\"text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700\">                                \r\n                <div *ngIf=\"optionalFormDniFlag\">\r\n                    <label for=\"dniType\" class=\"mt-2 mb-2 block text-start text-base font-semibold\">Tipo de Identificaci\u00F3n</label>\r\n                    <select name=\"dniType\" id=\"dniType\" [(ngModel)]=\"dniType\" (change)=\"onSelectDniType($event)\" class=\"w-full h-10 p-2 border-0 border-gray-300 text-gray-500 text-base\">\r\n                        <option value=\"0\" class=\"text-gray-500 text-base font-medium\" selected>Seleccione</option>\r\n                        <option class=\"text-gray-500 text-base font-medium\" *ngFor=\"let item of dniTypes\" [value]=\"item.id\">\r\n                            {{item.name}}\r\n                        </option>\r\n                    </select>                                        \r\n                </div>                \r\n            </div>\r\n            <div class=\"text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700\">                                \r\n                <div *ngIf=\"optionalFormDniFlag && dniType !== 0\">                    \r\n                    <label for=\"optionalFormDni\" class=\"mt-2 mb-2 block text-start text-base font-semibold\">Identificaci\u00F3n</label>\r\n                    <input id=\"optionalFormDni\" [(ngModel)]=\"optionalFormDni\" prefix=\"{{dniMaskPrefix}}\" mask=\"{{dniMask}}\"\r\n                     class=\"w-full h-8 p-1.5 border-0 border-gray-300 text-gray-500 text-base font-medium\" type=\"text\" placeholder=\"{{dniMask}}\">                                                \r\n                </div>                \r\n            </div>\r\n            <div class=\"flex justify-center mt-2\">\r\n                <button class=\"btnValidate p-3 w-full text-center rounded-sm text-white\" (click)=\"createOrder()\">Continuar</button>\r\n            </div>\r\n        </div>\r\n        <div *ngIf=\"showQrAndSmsCopyOptions\" class=\" bg-white mx-auto px-5 pb-5 sm:w-full md:w-full lg:w-1/4 flex-1\">        \r\n            <!-- SEND NOTIFICATION QR OR SMS -->\r\n            <div class=\"text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700\">\r\n                <ul class=\"flex flex-wrap -mb-px\">\r\n                    <li class=\"me-2\">\r\n                        <button                            \r\n                            [ngClass]=\"{'active-tab' : currentSelectedTabType == 1 , 'inactive-tab' : !(currentSelectedTabType == 1)}\"\r\n                            (click)=\"onSelectTab(1)\">\r\n                            <fa-icon [icon]=\"faQrcode\" style=\"width: 1.3em;\"></fa-icon>\r\n                            &nbsp;\r\n                            QR\r\n                        </button>\r\n                    </li>\r\n                    <li class=\"me-2\">\r\n                        <button\r\n                            [ngClass]=\"{'active-tab' : currentSelectedTabType == 2 , 'inactive-tab' : !(currentSelectedTabType == 2)}\"\r\n                            (click)=\"onSelectTab(2)\">                            \r\n                            <fa-icon [icon]=\"faCommentSms\" style=\"width: 1.3em;\"></fa-icon>\r\n                            &nbsp;\r\n                            Sms\r\n                        </button>\r\n                    </li>\r\n                </ul>\r\n            </div>\r\n            \r\n            <!-- SOME VALIDATION MSGS -->\r\n            <div *ngIf=\"currentSelectedBankId == '0';else message_option_required\">\r\n                <div class=\"flex justify-center items-center h-20\">\r\n                    <p class=\"text-xl sm:text-sm\">Por favor seleccione un banco</p>\r\n                </div>                \r\n            </div>\r\n            <ng-template #message_option_required>\r\n                <div class=\"flex justify-center items-center h-20\" *ngIf=\"currentSelectedTabType == 0\">                \r\n                    <p class=\"text-xl sm:text-sm\">Seleccione una opci\u00F3n para efectuar el SINPE</p>\r\n                </div>\r\n            </ng-template>        \r\n    \r\n            <!-- QR SELECTION -->\r\n            <div *ngIf=\"currentSelectedTabType == 1\" class=\"mt-3\">                        \r\n                <div *ngIf=\"qrdata !== ''\" class=\"text-center\">\r\n                    <p class=\"text-sm font-semibold\">Por favor escanee el c\u00F3digo QR</p>\r\n                    <p class=\"text-sm\">La lectura de este c\u00F3digo QR lo llevar\u00E1 a la mensajer\u00EDa de texto</p>\r\n                    <qrcode style=\"text-align: -webkit-center\" [qrdata]=\"qrdata\" [width]=\"156\" [margin]=\"5\" [errorCorrectionLevel]=\"'M'\"></qrcode>\r\n                    <p class=\"text-sm mb-2\">Si ya escane\u00F3 el c\u00F3digo QR, haga clic en el siguiente bot\u00F3n para validar.</p>\r\n                    <button class=\"btnValidate p-3 rounded-sm text-white\" (click)=\"validateOrder()\">Validar</button>\r\n                </div>                        \r\n            </div>\r\n            \r\n            <!-- SMS SELECTION -->\r\n            <div *ngIf=\"currentSelectedTabType == 2\" class=\"mt-3\">                        \r\n                <div  class=\"text-center\"> \r\n                    <p class=\"text-sm font-semibold mt-2\">Por favor, enviar mensaje de texto a su entidad bancaria</p>\r\n                    <p>1. Dir\u00EDjase a su mensajer\u00EDa de texto, en el men\u00FA de su celular.</p>\r\n                    <p>2. Inicie o contin\u00FAe la conversaci\u00F3n con el n\u00FAmero de su entidad bancaria.</p>\r\n                    <p class=\"mb-2\">3. Digite el siguiente mensaje en su celular y env\u00EDelo a su banco como se muestra a continuaci\u00F3n:</p>\r\n                    <div class=\"w-4/3 border-solid border-1  border-gray-300 p-2 m-1 rounded-sm mx-auto\">\r\n                        <div class=\"flex justify-between items-center\">\r\n                            <div class=\"w-1/2\">\r\n                                <p class=\"w-4 h-4 float-start my-auto\">Banco</p>\r\n                            </div>\r\n                            <div class=\"w-1/2\">\r\n                                <img class=\"w-4 h-4 float-end\" src=\"https://imagenesqa1.blob.core.windows.net/imagenesqa1/CSCtickets/Front/933ad38b0d524237895a6d80b9a3b49d.png\" alt=\"m\u00E1s opciones sinpe\">                            \r\n                                <img class=\"w-4 h-4 float-end\" src=\"https://imagenesqa1.blob.core.windows.net/imagenesqa1/CSCtickets/Front/040aacafeaeb490c9f471d32d394d9b1.png\" alt=\"tel\u00E9fono sinpe\">                            \r\n                            </div>\r\n                        </div>\r\n                        <p class=\"text-center\">04:42 PM</p>\r\n                        <p class=\"bg-slate-400 text-white\"> Mensaje de texto</p>\r\n                        \r\n                        <div class=\"border-solid border-1 rounded-md shadow-md border-gray-300 pb-4 m-2 flex justify-center items-center\">\r\n                            <p class=\"text-sm h-3.5 mr-4\">{{sinpeSms}}</p>\r\n                            <div class=\"block\">                            \r\n                                <img class=\"w-4 h-4 block mx-auto\" src=\"https://imagenesqa1.blob.core.windows.net/imagenesqa1/CSCtickets/Front/e6b2e15c85a44e1098c97a80dac876cc.png\" alt=\"enviar sinpe\">\r\n                                <p class=\"smsText float-end h-0 mx-0 mt-0 block\">SMS</p>\r\n                            </div>\r\n                        </div>\r\n                        <!-- SHOW ONLY IF THE DEVICE IS OF PC -->\r\n                        <div                             \r\n                            *ngIf=\"currentDeviceType == deviceType.windows || currentDeviceType == deviceType.macOS || currentDeviceType == deviceType.linux\"\r\n                            class=\"flex justify-center\">\r\n                            <button class=\"bg-slate-500 p-2 rounded-sm hover:bg-slate-400 text-white flex\" (click)=\"copyMessage()\">\r\n                                <fa-icon [icon]=\"faCopy\" style=\"display: flex; width: 1em;\"></fa-icon>\r\n                                Copiar\r\n                            </button>\r\n                        </div>\r\n                    </div>                    \r\n                    <button class=\"btnValidate p-3 rounded-sm text-white\" (click)=\"validateOrder()\">Validar</button>\r\n                </div>                        \r\n            </div>\r\n        </div> \r\n    </div>\r\n</div>\r\n<div *ngIf=\"!hasValidCredentials\" class=\"w-100 flex justify-center items-center h-screen\">\r\n    <div class=\"bg-yellow-400 p-4 rounded-md shadow-md text-white\">        \r\n        <p class=\"text-3xl text-center\">\r\n            <fa-icon [icon]=\"faExclamationCircle\" style=\"display: flex; width: 2em;\"></fa-icon>\r\n            Las credenciales no son v\u00E1lidas\r\n        </p>\r\n    </div>\r\n</div>\r\n<app-payment-revalidation (closeModalEvent)=\"closeRevalidationModal()\" (onSuccessValidation)=\"onSuccessValidation()\" [showModal]=\"showRevalidationModal\"></app-payment-revalidation>", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n", ".img-responsive{box-shadow:2px 2px 5px #0000004d;max-width:90%;height:120px;border-radius:.125rem;padding:.25rem;margin-inline:auto}@media (width < 512px){.img-responsive{max-width:400px;max-height:40px}}@media (512px <= width < 1020){.img-responsive{max-width:50%;max-height:60px}}@media (1020px = width > 1020px){.img-responsive{max-width:90%;height:120px}}bank-notification{margin-inline:auto}.active-tab{display:flex;padding:1rem;border-bottom:2px solid rgb(69,0,138);border-radius:.5rem .5rem 0 0}.active-tab.active,.active-tab:focus,.active-tab:hover{color:#430088;border-color:#430088}.inactive-tab{display:flex;padding:1rem;border-bottom:2px solid transparent;border-radius:.5rem .5rem 0 0}.inactive-tab:hover{color:#4b5563;border-color:#d1d5db}@media (prefers-color-scheme: dark){.inactive-tab:hover{color:#d1d5db}}.smsText{font-size:.8em;list-style:.3em}.selectCard{outline-style:solid;outline-color:transparent;cursor:default;outline-offset:.2em;transition:.3s;outline-width:.15em}.selectCard:hover{outline-style:solid;outline-color:#45008a99;outline-width:.15em;outline-offset:.2em;cursor:pointer}#optionalFormDni,#dniType{border-style:solid;border-width:.1em;border-color:#d1d5db;outline-style:solid;outline-offset:.1cap;outline-color:transparent;transition:.2s}#optionalFormDni:hover,#dniType:hover{outline-style:solid;outline-color:#45008a80;outline-offset:.1cap}#optionalFormDni:focus,#dniType:focus{outline-style:solid;outline-width:.2em;outline-color:#45008a;outline-offset:.1cap}.btnValidate{background-color:#45008a;transition:.3s}.btnValidate:hover{background-color:#34d399}.selectedBank{outline-style:solid;outline-color:#45008a4d;outline-width:.15em;outline-offset:.2em}\n"], dependencies: [{ kind: "directive", type: i5.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i5.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i5.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i11.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "spin", "pulse", "mask", "styles", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "classes", "transform", "a11yRole"] }, { kind: "directive", type: i12.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i12.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i12.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i12.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i12.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i12.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: i13.QRCodeComponent, selector: "qrcode", inputs: ["allowEmptyString", "colorDark", "colorLight", "cssClass", "elementType", "errorCorrectionLevel", "imageSrc", "imageHeight", "imageWidth", "margin", "qrdata", "scale", "version", "width", "alt", "ariaLabel", "title"], outputs: ["qrCodeURL"] }, { kind: "component", type: FullScreenSpinnerComponent, selector: "app-full-screen-spinner" }, { kind: "directive", type: i8.NgxMaskDirective, selector: "input[mask], textarea[mask]", inputs: ["mask", "specialCharacters", "patterns", "prefix", "suffix", "thousandSeparator", "decimalMarker", "dropSpecialCharacters", "hiddenInput", "showMaskTyped", "placeHolderCharacter", "shownMaskExpression", "showTemplate", "clearIfNotMatch", "validation", "separatorLimit", "allowNegativeNumbers", "leadZeroDateTime", "leadZero", "triggerOnMaskChange", "apm", "inputTransformFn", "outputTransformFn", "keepCharacterPositions"], outputs: ["maskFilled"], exportAs: ["mask", "ngxMask"] }, { kind: "component", type: PaymentRevalidationComponent, selector: "app-payment-revalidation", inputs: ["showModal"], outputs: ["closeModalEvent", "onSuccessValidation"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentSelectBankComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-payment-select-bank', template: "<app-full-screen-spinner *ngIf=\"isLoading\"></app-full-screen-spinner>\r\n<div *ngIf=\"!isLoading && hasValidCredentials\" class=\"bg-slate-100 rounded-lg shadow-md lg:m-5 lg:p-5 md:m-2 md:p-2 sm:m-0 sm:p-0\">        \r\n    <h2 class=\"text-center text-xl text-gray-600\">Por favor seleccione un banco</h2>\r\n    <swiper-container class=\"mx-8\" loop=\"false\" navigation=\"true\" [breakpoints]=\"breakpoints\">\r\n        <swiper-slide *ngFor=\"let bank of accountBanks\" class=\"swiper-slide text-center text-xl\">        \r\n            <div class=\"selectCard bg-white mx-auto my-8 p-5 lg:w-1/4 w-1/3\" [ngClass]=\"{selectedBank: bank.Id == currentSelectedBankId}\"  (click)=\"onSelectBank(bank.Id) \">\r\n                <!-- BANK INFORMATION AND SELECTION -->            \r\n                <img class=\"img-responsive rounded-sm p-1 shadow-sm\" src={{bank.Image}} alt={{bank.Name}}>\r\n                <div class=\"my-5\">\r\n                    <p class=\"text-center text-xl text-gray-600 mt-1\">{{bank.Name}}</p>                \r\n                    <p class=\"text-center text-xl text-gray-600 mt-1\">{{bank.PhoneReceptor}}</p>                                    \r\n                </div>                                    \r\n            </div>            \r\n        </swiper-slide>                           \r\n    </swiper-container>\r\n    <div *ngIf=\"showValidationCard\" class=\"block mt-3\">        \r\n        <div *ngIf=\"optionalFormDniFlag && !showQrAndSmsCopyOptions\" class=\" bg-white mx-auto px-5 pb-3 sm:w-full md:w-full lg:w-1/4 flex-1\">                \r\n            <p class=\"text-center text-lg text-gray-500 font-semibold bg-white pt-3\">Digite la informaci\u00F3n correspondiente</p>            \r\n            <div class=\"text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700\">                                \r\n                <div *ngIf=\"optionalFormDniFlag\">\r\n                    <label for=\"dniType\" class=\"mt-2 mb-2 block text-start text-base font-semibold\">Tipo de Identificaci\u00F3n</label>\r\n                    <select name=\"dniType\" id=\"dniType\" [(ngModel)]=\"dniType\" (change)=\"onSelectDniType($event)\" class=\"w-full h-10 p-2 border-0 border-gray-300 text-gray-500 text-base\">\r\n                        <option value=\"0\" class=\"text-gray-500 text-base font-medium\" selected>Seleccione</option>\r\n                        <option class=\"text-gray-500 text-base font-medium\" *ngFor=\"let item of dniTypes\" [value]=\"item.id\">\r\n                            {{item.name}}\r\n                        </option>\r\n                    </select>                                        \r\n                </div>                \r\n            </div>\r\n            <div class=\"text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700\">                                \r\n                <div *ngIf=\"optionalFormDniFlag && dniType !== 0\">                    \r\n                    <label for=\"optionalFormDni\" class=\"mt-2 mb-2 block text-start text-base font-semibold\">Identificaci\u00F3n</label>\r\n                    <input id=\"optionalFormDni\" [(ngModel)]=\"optionalFormDni\" prefix=\"{{dniMaskPrefix}}\" mask=\"{{dniMask}}\"\r\n                     class=\"w-full h-8 p-1.5 border-0 border-gray-300 text-gray-500 text-base font-medium\" type=\"text\" placeholder=\"{{dniMask}}\">                                                \r\n                </div>                \r\n            </div>\r\n            <div class=\"flex justify-center mt-2\">\r\n                <button class=\"btnValidate p-3 w-full text-center rounded-sm text-white\" (click)=\"createOrder()\">Continuar</button>\r\n            </div>\r\n        </div>\r\n        <div *ngIf=\"showQrAndSmsCopyOptions\" class=\" bg-white mx-auto px-5 pb-5 sm:w-full md:w-full lg:w-1/4 flex-1\">        \r\n            <!-- SEND NOTIFICATION QR OR SMS -->\r\n            <div class=\"text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700\">\r\n                <ul class=\"flex flex-wrap -mb-px\">\r\n                    <li class=\"me-2\">\r\n                        <button                            \r\n                            [ngClass]=\"{'active-tab' : currentSelectedTabType == 1 , 'inactive-tab' : !(currentSelectedTabType == 1)}\"\r\n                            (click)=\"onSelectTab(1)\">\r\n                            <fa-icon [icon]=\"faQrcode\" style=\"width: 1.3em;\"></fa-icon>\r\n                            &nbsp;\r\n                            QR\r\n                        </button>\r\n                    </li>\r\n                    <li class=\"me-2\">\r\n                        <button\r\n                            [ngClass]=\"{'active-tab' : currentSelectedTabType == 2 , 'inactive-tab' : !(currentSelectedTabType == 2)}\"\r\n                            (click)=\"onSelectTab(2)\">                            \r\n                            <fa-icon [icon]=\"faCommentSms\" style=\"width: 1.3em;\"></fa-icon>\r\n                            &nbsp;\r\n                            Sms\r\n                        </button>\r\n                    </li>\r\n                </ul>\r\n            </div>\r\n            \r\n            <!-- SOME VALIDATION MSGS -->\r\n            <div *ngIf=\"currentSelectedBankId == '0';else message_option_required\">\r\n                <div class=\"flex justify-center items-center h-20\">\r\n                    <p class=\"text-xl sm:text-sm\">Por favor seleccione un banco</p>\r\n                </div>                \r\n            </div>\r\n            <ng-template #message_option_required>\r\n                <div class=\"flex justify-center items-center h-20\" *ngIf=\"currentSelectedTabType == 0\">                \r\n                    <p class=\"text-xl sm:text-sm\">Seleccione una opci\u00F3n para efectuar el SINPE</p>\r\n                </div>\r\n            </ng-template>        \r\n    \r\n            <!-- QR SELECTION -->\r\n            <div *ngIf=\"currentSelectedTabType == 1\" class=\"mt-3\">                        \r\n                <div *ngIf=\"qrdata !== ''\" class=\"text-center\">\r\n                    <p class=\"text-sm font-semibold\">Por favor escanee el c\u00F3digo QR</p>\r\n                    <p class=\"text-sm\">La lectura de este c\u00F3digo QR lo llevar\u00E1 a la mensajer\u00EDa de texto</p>\r\n                    <qrcode style=\"text-align: -webkit-center\" [qrdata]=\"qrdata\" [width]=\"156\" [margin]=\"5\" [errorCorrectionLevel]=\"'M'\"></qrcode>\r\n                    <p class=\"text-sm mb-2\">Si ya escane\u00F3 el c\u00F3digo QR, haga clic en el siguiente bot\u00F3n para validar.</p>\r\n                    <button class=\"btnValidate p-3 rounded-sm text-white\" (click)=\"validateOrder()\">Validar</button>\r\n                </div>                        \r\n            </div>\r\n            \r\n            <!-- SMS SELECTION -->\r\n            <div *ngIf=\"currentSelectedTabType == 2\" class=\"mt-3\">                        \r\n                <div  class=\"text-center\"> \r\n                    <p class=\"text-sm font-semibold mt-2\">Por favor, enviar mensaje de texto a su entidad bancaria</p>\r\n                    <p>1. Dir\u00EDjase a su mensajer\u00EDa de texto, en el men\u00FA de su celular.</p>\r\n                    <p>2. Inicie o contin\u00FAe la conversaci\u00F3n con el n\u00FAmero de su entidad bancaria.</p>\r\n                    <p class=\"mb-2\">3. Digite el siguiente mensaje en su celular y env\u00EDelo a su banco como se muestra a continuaci\u00F3n:</p>\r\n                    <div class=\"w-4/3 border-solid border-1  border-gray-300 p-2 m-1 rounded-sm mx-auto\">\r\n                        <div class=\"flex justify-between items-center\">\r\n                            <div class=\"w-1/2\">\r\n                                <p class=\"w-4 h-4 float-start my-auto\">Banco</p>\r\n                            </div>\r\n                            <div class=\"w-1/2\">\r\n                                <img class=\"w-4 h-4 float-end\" src=\"https://imagenesqa1.blob.core.windows.net/imagenesqa1/CSCtickets/Front/933ad38b0d524237895a6d80b9a3b49d.png\" alt=\"m\u00E1s opciones sinpe\">                            \r\n                                <img class=\"w-4 h-4 float-end\" src=\"https://imagenesqa1.blob.core.windows.net/imagenesqa1/CSCtickets/Front/040aacafeaeb490c9f471d32d394d9b1.png\" alt=\"tel\u00E9fono sinpe\">                            \r\n                            </div>\r\n                        </div>\r\n                        <p class=\"text-center\">04:42 PM</p>\r\n                        <p class=\"bg-slate-400 text-white\"> Mensaje de texto</p>\r\n                        \r\n                        <div class=\"border-solid border-1 rounded-md shadow-md border-gray-300 pb-4 m-2 flex justify-center items-center\">\r\n                            <p class=\"text-sm h-3.5 mr-4\">{{sinpeSms}}</p>\r\n                            <div class=\"block\">                            \r\n                                <img class=\"w-4 h-4 block mx-auto\" src=\"https://imagenesqa1.blob.core.windows.net/imagenesqa1/CSCtickets/Front/e6b2e15c85a44e1098c97a80dac876cc.png\" alt=\"enviar sinpe\">\r\n                                <p class=\"smsText float-end h-0 mx-0 mt-0 block\">SMS</p>\r\n                            </div>\r\n                        </div>\r\n                        <!-- SHOW ONLY IF THE DEVICE IS OF PC -->\r\n                        <div                             \r\n                            *ngIf=\"currentDeviceType == deviceType.windows || currentDeviceType == deviceType.macOS || currentDeviceType == deviceType.linux\"\r\n                            class=\"flex justify-center\">\r\n                            <button class=\"bg-slate-500 p-2 rounded-sm hover:bg-slate-400 text-white flex\" (click)=\"copyMessage()\">\r\n                                <fa-icon [icon]=\"faCopy\" style=\"display: flex; width: 1em;\"></fa-icon>\r\n                                Copiar\r\n                            </button>\r\n                        </div>\r\n                    </div>                    \r\n                    <button class=\"btnValidate p-3 rounded-sm text-white\" (click)=\"validateOrder()\">Validar</button>\r\n                </div>                        \r\n            </div>\r\n        </div> \r\n    </div>\r\n</div>\r\n<div *ngIf=\"!hasValidCredentials\" class=\"w-100 flex justify-center items-center h-screen\">\r\n    <div class=\"bg-yellow-400 p-4 rounded-md shadow-md text-white\">        \r\n        <p class=\"text-3xl text-center\">\r\n            <fa-icon [icon]=\"faExclamationCircle\" style=\"display: flex; width: 2em;\"></fa-icon>\r\n            Las credenciales no son v\u00E1lidas\r\n        </p>\r\n    </div>\r\n</div>\r\n<app-payment-revalidation (closeModalEvent)=\"closeRevalidationModal()\" (onSuccessValidation)=\"onSuccessValidation()\" [showModal]=\"showRevalidationModal\"></app-payment-revalidation>", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n", ".img-responsive{box-shadow:2px 2px 5px #0000004d;max-width:90%;height:120px;border-radius:.125rem;padding:.25rem;margin-inline:auto}@media (width < 512px){.img-responsive{max-width:400px;max-height:40px}}@media (512px <= width < 1020){.img-responsive{max-width:50%;max-height:60px}}@media (1020px = width > 1020px){.img-responsive{max-width:90%;height:120px}}bank-notification{margin-inline:auto}.active-tab{display:flex;padding:1rem;border-bottom:2px solid rgb(69,0,138);border-radius:.5rem .5rem 0 0}.active-tab.active,.active-tab:focus,.active-tab:hover{color:#430088;border-color:#430088}.inactive-tab{display:flex;padding:1rem;border-bottom:2px solid transparent;border-radius:.5rem .5rem 0 0}.inactive-tab:hover{color:#4b5563;border-color:#d1d5db}@media (prefers-color-scheme: dark){.inactive-tab:hover{color:#d1d5db}}.smsText{font-size:.8em;list-style:.3em}.selectCard{outline-style:solid;outline-color:transparent;cursor:default;outline-offset:.2em;transition:.3s;outline-width:.15em}.selectCard:hover{outline-style:solid;outline-color:#45008a99;outline-width:.15em;outline-offset:.2em;cursor:pointer}#optionalFormDni,#dniType{border-style:solid;border-width:.1em;border-color:#d1d5db;outline-style:solid;outline-offset:.1cap;outline-color:transparent;transition:.2s}#optionalFormDni:hover,#dniType:hover{outline-style:solid;outline-color:#45008a80;outline-offset:.1cap}#optionalFormDni:focus,#dniType:focus{outline-style:solid;outline-width:.2em;outline-color:#45008a;outline-offset:.1cap}.btnValidate{background-color:#45008a;transition:.3s}.btnValidate:hover{background-color:#34d399}.selectedBank{outline-style:solid;outline-color:#45008a4d;outline-width:.15em;outline-offset:.2em}\n"] }]
        }], ctorParameters: () => [{ type: FbAccountBankServiceService }, { type: i3.ToastrService }, { type: OrderStateManagementService }, { type: OrderService }, { type: FbAppSettingsService }, { type: FbPaymentTransactionService }, { type: FbLogsServiceService }, { type: UrlRedirectionService }, { type: DeviceTypeService }], propDecorators: { goToNextStep: [{
                type: Output
            }] } });

class PaymentValidateSecretComponent {
    constructor(_authService, _currentTranxInfo, _order, _fbLogService) {
        this._authService = _authService;
        this._currentTranxInfo = _currentTranxInfo;
        this._order = _order;
        this._fbLogService = _fbLogService;
        this.isLoading = false;
        this.secretIsValid = false;
        this.secretValidationDone = false;
        this.validationSecretErrors = [];
        //Icons
        this.faExclamationCircle = faExclamationCircle;
        //Decorators
        this.goToNextStep = new EventEmitter();
        this.merchantPayTranxInfo = {
            amount: 0,
        };
    }
    ngOnInit() {
        //Clear tranxInfo
        this._currentTranxInfo.clearTranxInfo();
        sessionStorage.removeItem("tranxInfo");
        this.validateSecret();
    }
    validateSecret() {
        this.isLoading = true;
        const msgErrors = validateMerchantInfo(this.merchantPayTranxInfo);
        this.validationSecretErrors = msgErrors;
        if (msgErrors.length > 0) {
            this.isLoading = false;
            return;
        }
        this._authService
            .validateSecret(environment.backendSecret)
            .subscribe({
            next: (data) => {
                this.secretIsValid = data.response.success;
                if (!this.secretIsValid) {
                    this.validationSecretErrors.push('Las credenciales del comercio no son válidas');
                    this.saveLogs("Validación secret inválida", JSON.stringify(data), environment.backendSecret, "AuthService");
                    this.isLoading = false;
                }
                const dniSubmited = this.merchantPayTranxInfo.customer !== undefined && this.merchantPayTranxInfo.customer !== "";
                if (msgErrors.length == 0 && dniSubmited) {
                    this.createOrder();
                    return;
                }
                //save the current tranx
                this._currentTranxInfo.updateOrderTranxInfo(this.merchantPayTranxInfo);
                this.goToNextStep.emit(Number(PaymentGatewaySteps.PaymentGateway));
            },
            error: (err) => {
                this.validationSecretErrors.push('Se produjo un error al validar las credenciales');
                this.saveLogs("Validación secret inválida", JSON.stringify(err), environment.backendSecret, "AuthService");
                this.isLoading = false;
            }
        });
    }
    createOrder() {
        const orderData = fillCreateOrderData(this.merchantPayTranxInfo);
        this._order.createOrder(orderData).subscribe((data) => {
            if (data.response.success) {
                //update tranx id value, in the merchant data
                this.merchantPayTranxInfo.transactionId = data.definition.transactionId;
                this.merchantPayTranxInfo.companyId = data.definition.companyId;
                //save the reponse in a global state
                this._currentTranxInfo.updateOrderTranxInfo(this.merchantPayTranxInfo);
                const reponseMsg = data ? data.response.message : "data es null";
                this.saveLogs(reponseMsg, JSON.stringify(data), JSON.stringify(orderData), "OrderService");
                //Go to next step
                this.goToNextStep.emit(Number(PaymentGatewaySteps.PaymentGateway));
            }
            else {
                this.validationSecretErrors.push('Error al crear la orden valide que haya pasado la información correctamente');
            }
        });
    }
    //#region logs
    saveLogs(desc, JsonResp, params, service) {
        this.saveAuditLog(desc, JsonResp, params, service);
        this.saveTranxLog(desc, JsonResp, params, service);
    }
    saveAuditLog(desc, JsonResp, params, service) {
        const logParams = fillAuditLogsInsertParams(this.merchantPayTranxInfo, desc, JsonResp, params, service);
        this._fbLogService.insertAuditLog(logParams);
    }
    saveTranxLog(desc, JsonResp, params, service) {
        const logParams = fillTranxLogsInsertParams(this.merchantPayTranxInfo, desc, JsonResp, params, service);
        this._fbLogService.insertLogTransaction(logParams, logParams.TransactionId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentValidateSecretComponent, deps: [{ token: AuthService }, { token: OrderStateManagementService }, { token: OrderService }, { token: FbLogsServiceService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.6", type: PaymentValidateSecretComponent, selector: "app-payment-validate-secret", inputs: { merchantPayTranxInfo: "merchantPayTranxInfo" }, outputs: { goToNextStep: "goToNextStep" }, ngImport: i0, template: "<app-full-screen-spinner *ngIf=\"isLoading\"></app-full-screen-spinner>\r\n\r\n<div *ngIf=\"!isLoading\">\r\n    <div *ngIf=\"validationSecretErrors.length > 0\">    \r\n        <div class=\"min-w-screen min-h-screen bg-gray-200 flex items-center justify-center\">\r\n            <div class=\"w-full mx-auto rounded-lg shadow-lg p-5 bg-yellow-500 text-white\" style=\"max-width: 600px;\">        \r\n                <p class=\"text-2xl mb-2\">                \r\n                    <fa-icon [icon]=\"faExclamationCircle\" style=\"display: flex; width: 2em;\"></fa-icon>\r\n                    La transacci\u00F3n presenta los siguientes problemas:\r\n                </p>\r\n                <div *ngFor=\"let error of validationSecretErrors\">            \r\n                    <p>\r\n                        {{error}}.\r\n                    </p>\r\n                </div>\r\n            </div>    \r\n        </div>        \r\n    </div>\r\n</div>\r\n", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n"], dependencies: [{ kind: "directive", type: i5.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i5.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i11.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "spin", "pulse", "mask", "styles", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "classes", "transform", "a11yRole"] }, { kind: "component", type: FullScreenSpinnerComponent, selector: "app-full-screen-spinner" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentValidateSecretComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-payment-validate-secret', template: "<app-full-screen-spinner *ngIf=\"isLoading\"></app-full-screen-spinner>\r\n\r\n<div *ngIf=\"!isLoading\">\r\n    <div *ngIf=\"validationSecretErrors.length > 0\">    \r\n        <div class=\"min-w-screen min-h-screen bg-gray-200 flex items-center justify-center\">\r\n            <div class=\"w-full mx-auto rounded-lg shadow-lg p-5 bg-yellow-500 text-white\" style=\"max-width: 600px;\">        \r\n                <p class=\"text-2xl mb-2\">                \r\n                    <fa-icon [icon]=\"faExclamationCircle\" style=\"display: flex; width: 2em;\"></fa-icon>\r\n                    La transacci\u00F3n presenta los siguientes problemas:\r\n                </p>\r\n                <div *ngFor=\"let error of validationSecretErrors\">            \r\n                    <p>\r\n                        {{error}}.\r\n                    </p>\r\n                </div>\r\n            </div>    \r\n        </div>        \r\n    </div>\r\n</div>\r\n", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n"] }]
        }], ctorParameters: () => [{ type: AuthService }, { type: OrderStateManagementService }, { type: OrderService }, { type: FbLogsServiceService }], propDecorators: { goToNextStep: [{
                type: Output
            }], merchantPayTranxInfo: [{
                type: Input
            }] } });

class PaymentPrincipalComponent {
    constructor() {
        this.faCheckCircle = faCheckCircle;
        this.paymentStep = PaymentGatewaySteps.ValidateSecret;
        this.merchantPayTranxInfo = {
            amount: 0,
        };
    }
    switchStep(step) {
        this.paymentStep = step;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentPrincipalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.6", type: PaymentPrincipalComponent, selector: "app-payment-principal", inputs: { merchantPayTranxInfo: "merchantPayTranxInfo" }, ngImport: i0, template: "<div *ngIf=\"paymentStep == 0\">    \r\n    <app-payment-validate-secret (goToNextStep)=\"switchStep($event)\" [merchantPayTranxInfo]=\"merchantPayTranxInfo\"></app-payment-validate-secret>\r\n</div>\r\n<div *ngIf=\"paymentStep == 1\">\r\n    <app-payment-select-bank (goToNextStep)=\"switchStep($event)\"></app-payment-select-bank>    \r\n</div>\r\n<div *ngIf=\"paymentStep == 2\" class=\"w-100 flex justify-center items-center h-screen\">\r\n    <div class=\"bg-green-500 p-4 rounded-md shadow-md text-white\">        \r\n        <p class=\"text-3xl text-center\">\r\n            <fa-icon [icon]=\"faCheckCircle\" style=\"display: flex; width: 2em;\"></fa-icon>\r\n            La orden es v\u00E1lida \r\n        </p>\r\n    </div>\r\n</div>", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n", "body{font-family:Arial,Helvetica,sans-serif}@layer reset;@layer reset{button{background:none;border:none;color:inherit;font:inherit;line-height:normal;overflow:visible;padding:0;cursor:pointer;box-shadow:none;text-align:left}li{list-style-type:none;margin:0;padding:0;outline:none}input[type=radio]{appearance:none;background-color:transparent;border:2px solid #ccc;border-radius:50%;width:16px;height:16px;cursor:pointer;outline:none;position:relative}input[type=radio]:checked{background-color:#005a9c;border-color:#005a9c}input[type=radio]:focus{box-shadow:0 0 0 3px #007bff80}input[type=radio]:checked:before{content:\"\";position:absolute;top:3px;left:3px;width:10px;height:10px;background-color:#fff;border-radius:50%}}\n"], dependencies: [{ kind: "directive", type: i5.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i11.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "animation", "spin", "pulse", "mask", "styles", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "classes", "transform", "a11yRole"] }, { kind: "component", type: PaymentSelectBankComponent, selector: "app-payment-select-bank", outputs: ["goToNextStep"] }, { kind: "component", type: PaymentValidateSecretComponent, selector: "app-payment-validate-secret", inputs: ["merchantPayTranxInfo"], outputs: ["goToNextStep"] }], encapsulation: i0.ViewEncapsulation.ShadowDom }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentPrincipalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-payment-principal', encapsulation: ViewEncapsulation.ShadowDom, template: "<div *ngIf=\"paymentStep == 0\">    \r\n    <app-payment-validate-secret (goToNextStep)=\"switchStep($event)\" [merchantPayTranxInfo]=\"merchantPayTranxInfo\"></app-payment-validate-secret>\r\n</div>\r\n<div *ngIf=\"paymentStep == 1\">\r\n    <app-payment-select-bank (goToNextStep)=\"switchStep($event)\"></app-payment-select-bank>    \r\n</div>\r\n<div *ngIf=\"paymentStep == 2\" class=\"w-100 flex justify-center items-center h-screen\">\r\n    <div class=\"bg-green-500 p-4 rounded-md shadow-md text-white\">        \r\n        <p class=\"text-3xl text-center\">\r\n            <fa-icon [icon]=\"faCheckCircle\" style=\"display: flex; width: 2em;\"></fa-icon>\r\n            La orden es v\u00E1lida \r\n        </p>\r\n    </div>\r\n</div>", styles: ["*,:before,:after{box-sizing:border-box;border-width:0;border-style:solid;border-color:#e5e7eb}:before,:after{--tw-content: \"\"}html,:host{line-height:1.5;-webkit-text-size-adjust:100%;-moz-tab-size:4;-o-tab-size:4;tab-size:4;font-family:ui-sans-serif,system-ui,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";font-feature-settings:normal;font-variation-settings:normal;-webkit-tap-highlight-color:transparent}body{margin:0;line-height:inherit}hr{height:0;color:inherit;border-top-width:1px}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,samp,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-feature-settings:normal;font-variation-settings:normal;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}table{text-indent:0;border-color:inherit;border-collapse:collapse}button,input,optgroup,select,textarea{font-family:inherit;font-feature-settings:inherit;font-variation-settings:inherit;font-size:100%;font-weight:inherit;line-height:inherit;letter-spacing:inherit;color:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:transparent;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:baseline}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dl,dd,h1,h2,h3,h4,h5,h6,hr,figure,p,pre{margin:0}fieldset{margin:0;padding:0}legend{padding:0}ol,ul,menu{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::-moz-placeholder,textarea::-moz-placeholder{opacity:1;color:#9ca3af}input::placeholder,textarea::placeholder{opacity:1;color:#9ca3af}button,[role=button]{cursor:pointer}:disabled{cursor:default}img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}[hidden]{display:none}*,:before,:after{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }::backdrop{--tw-border-spacing-x: 0;--tw-border-spacing-y: 0;--tw-translate-x: 0;--tw-translate-y: 0;--tw-rotate: 0;--tw-skew-x: 0;--tw-skew-y: 0;--tw-scale-x: 1;--tw-scale-y: 1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness: proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width: 0px;--tw-ring-offset-color: #fff;--tw-ring-color: rgb(59 130 246 / .5);--tw-ring-offset-shadow: 0 0 #0000;--tw-ring-shadow: 0 0 #0000;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fixed{position:fixed}.inset-0{inset:0}.z-40{z-index:40}.float-start{float:inline-start}.float-end{float:inline-end}.m-1{margin:.25rem}.m-2{margin:.5rem}.mx-0{margin-left:0;margin-right:0}.mx-10{margin-left:2.5rem;margin-right:2.5rem}.mx-8{margin-left:2rem;margin-right:2rem}.mx-auto{margin-left:auto;margin-right:auto}.my-2{margin-top:.5rem;margin-bottom:.5rem}.my-5{margin-top:1.25rem;margin-bottom:1.25rem}.my-8{margin-top:2rem;margin-bottom:2rem}.my-auto{margin-top:auto;margin-bottom:auto}.-mb-px{margin-bottom:-1px}.mb-2{margin-bottom:.5rem}.me-2{margin-inline-end:.5rem}.mr-4{margin-right:1rem}.mt-0{margin-top:0}.mt-1{margin-top:.25rem}.mt-2{margin-top:.5rem}.mt-3{margin-top:.75rem}.block{display:block}.flex{display:flex}.h-0{height:0px}.h-10{height:2.5rem}.h-20{height:5rem}.h-3{height:.75rem}.h-3\\.5{height:.875rem}.h-4{height:1rem}.h-8{height:2rem}.h-screen{height:100vh}.min-h-screen{min-height:100vh}.w-1\\/2{width:50%}.w-1\\/3{width:33.333333%}.w-3{width:.75rem}.w-4{width:1rem}.w-auto{width:auto}.w-full{width:100%}.flex-1{flex:1 1 0%}.cursor-pointer{cursor:pointer}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-lg{border-radius:.5rem}.rounded-md{border-radius:.375rem}.rounded-sm{border-radius:.125rem}.border{border-width:1px}.border-0{border-width:0px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235/var(--tw-border-opacity))}.border-gray-300{--tw-border-opacity: 1;border-color:rgb(209 213 219/var(--tw-border-opacity))}.border-teal-500{--tw-border-opacity: 1;border-color:rgb(20 184 166/var(--tw-border-opacity))}.bg-gray-200{--tw-bg-opacity: 1;background-color:rgb(229 231 235/var(--tw-bg-opacity))}.bg-green-500{--tw-bg-opacity: 1;background-color:rgb(34 197 94/var(--tw-bg-opacity))}.bg-slate-100{--tw-bg-opacity: 1;background-color:rgb(241 245 249/var(--tw-bg-opacity))}.bg-slate-400{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.bg-slate-500{--tw-bg-opacity: 1;background-color:rgb(100 116 139/var(--tw-bg-opacity))}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-yellow-400{--tw-bg-opacity: 1;background-color:rgb(250 204 21/var(--tw-bg-opacity))}.bg-yellow-500{--tw-bg-opacity: 1;background-color:rgb(234 179 8/var(--tw-bg-opacity))}.p-1{padding:.25rem}.p-1\\.5{padding:.375rem}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.px-5{padding-left:1.25rem;padding-right:1.25rem}.pb-1{padding-bottom:.25rem}.pb-3{padding-bottom:.75rem}.pb-4{padding-bottom:1rem}.pb-5{padding-bottom:1.25rem}.pt-1{padding-top:.25rem}.pt-3{padding-top:.75rem}.text-center{text-align:center}.text-start{text-align:start}.text-2xl{font-size:1.5rem;line-height:2rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}.text-base{font-size:1rem;line-height:1.5rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}.font-medium{font-weight:500}.font-semibold{font-weight:600}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128/var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99/var(--tw-text-opacity))}.text-white{--tw-text-opacity: 1;color:rgb(255 255 255/var(--tw-text-opacity))}.shadow-lg{--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-md{--tw-shadow: 0 4px 6px -1px rgb(0 0 0 / .1), 0 2px 4px -2px rgb(0 0 0 / .1);--tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.shadow-sm{--tw-shadow: 0 1px 2px 0 rgb(0 0 0 / .05);--tw-shadow-colored: 0 1px 2px 0 var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-ring-shadow, 0 0 rgba(0, 0, 0, 0)),var(--tw-shadow)}.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.hover\\:bg-slate-400:hover{--tw-bg-opacity: 1;background-color:rgb(148 163 184/var(--tw-bg-opacity))}.hover\\:text-gray-300:hover{--tw-text-opacity: 1;color:rgb(209 213 219/var(--tw-text-opacity))}@media (min-width: 640px){.sm\\:m-0{margin:0}.sm\\:w-full{width:100%}.sm\\:p-0{padding:0}.sm\\:text-sm{font-size:.875rem;line-height:1.25rem}}@media (min-width: 768px){.md\\:m-2{margin:.5rem}.md\\:w-full{width:100%}.md\\:p-2{padding:.5rem}}@media (min-width: 1024px){.lg\\:m-5{margin:1.25rem}.lg\\:w-1\\/4{width:25%}.lg\\:p-5{padding:1.25rem}}@media (prefers-color-scheme: dark){.dark\\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81/var(--tw-border-opacity))}.dark\\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175/var(--tw-text-opacity))}}\n", "body{font-family:Arial,Helvetica,sans-serif}@layer reset;@layer reset{button{background:none;border:none;color:inherit;font:inherit;line-height:normal;overflow:visible;padding:0;cursor:pointer;box-shadow:none;text-align:left}li{list-style-type:none;margin:0;padding:0;outline:none}input[type=radio]{appearance:none;background-color:transparent;border:2px solid #ccc;border-radius:50%;width:16px;height:16px;cursor:pointer;outline:none;position:relative}input[type=radio]:checked{background-color:#005a9c;border-color:#005a9c}input[type=radio]:focus{box-shadow:0 0 0 3px #007bff80}input[type=radio]:checked:before{content:\"\";position:absolute;top:3px;left:3px;width:10px;height:10px;background-color:#fff;border-radius:50%}}\n"] }]
        }], propDecorators: { merchantPayTranxInfo: [{
                type: Input
            }] } });

class PaymentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "17.3.6", ngImport: i0, type: PaymentModule, declarations: [PaymentPrincipalComponent,
            PaymentRevalidationComponent,
            PaymentSelectBankComponent,
            PaymentValidateSecretComponent], imports: [CommonModule,
            FontAwesomeModule,
            FormsModule,
            QRCodeModule,
            FullScreenSpinnerComponent, i3.ToastrModule, i2.AngularFireModule, AngularFireDatabaseModule,
            BrowserModule,
            HttpClientModule,
            BrowserAnimationsModule, i8.NgxMaskModule], exports: [PaymentPrincipalComponent,
            PaymentRevalidationComponent,
            PaymentSelectBankComponent,
            PaymentValidateSecretComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentModule, providers: [
            [provideHttpClient()],
            {
                provide: HTTP_INTERCEPTORS,
                useClass: AuthInterceptorService,
                multi: true
            }
        ], imports: [CommonModule,
            FontAwesomeModule,
            FormsModule,
            QRCodeModule,
            ToastrModule.forRoot(), // ToastrModule added,
            AngularFireModule.initializeApp(environment.firebaseConfig),
            AngularFireDatabaseModule,
            BrowserModule,
            HttpClientModule,
            BrowserAnimationsModule,
            NgxMaskModule.forRoot()] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.6", ngImport: i0, type: PaymentModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        PaymentPrincipalComponent,
                        PaymentRevalidationComponent,
                        PaymentSelectBankComponent,
                        PaymentValidateSecretComponent
                    ],
                    exports: [
                        PaymentPrincipalComponent,
                        PaymentRevalidationComponent,
                        PaymentSelectBankComponent,
                        PaymentValidateSecretComponent
                    ],
                    imports: [
                        CommonModule,
                        FontAwesomeModule,
                        FormsModule,
                        QRCodeModule,
                        FullScreenSpinnerComponent,
                        ToastrModule.forRoot(), // ToastrModule added,
                        AngularFireModule.initializeApp(environment.firebaseConfig),
                        AngularFireDatabaseModule,
                        BrowserModule,
                        HttpClientModule,
                        BrowserAnimationsModule,
                        NgxMaskModule.forRoot()
                    ],
                    schemas: [CUSTOM_ELEMENTS_SCHEMA],
                    providers: [
                        [provideHttpClient()],
                        {
                            provide: HTTP_INTERCEPTORS,
                            useClass: AuthInterceptorService,
                            multi: true
                        }
                    ],
                }]
        }] });

/*
 * Public API Surface of ngx-prides-payment-gateway.module
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AuthInterceptorService, AuthService, CardTypes, FbAccountBankServiceService, FbAppSettingsService, FbLogsServiceService, FbPaymentTransactionService, FullScreenSpinnerComponent, OrderService, OrderStateManagementService, PaymentGatewaySteps, PaymentModule, PaymentPrincipalComponent, PaymentRevalidationComponent, PaymentSelectBankComponent, PaymentValidateSecretComponent, TranxResponseCode, fillAuditLogsInsertParams, fillCreateOrderData, fillRevalidateOrderData, fillTranxLogsInsertParams, fillValidateOrderData, getCurrentDatePath, getCurrentISODateWithTimezone, getDniMaskAndPrefix, getDniTypes, selectTab, validateMerchantInfo };
//# sourceMappingURL=ngx-prides-payment-gateway.mjs.map
