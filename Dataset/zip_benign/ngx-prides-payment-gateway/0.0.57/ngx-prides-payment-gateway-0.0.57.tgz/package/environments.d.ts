export declare const environment: {
    backendSecret: string;
    production: boolean;
    fbBaseUrl: string;
    secretStorage: string;
    pridesPaymentBaseUrlApi: string;
    firebaseConfig: {
        apiKey: string;
        authDomain: string;
        databaseURL: string;
        projectId: string;
        storageBucket: string;
        messagingSenderId: string;
        appId: string;
        measurementId: string;
    };
    fbApiKey: string;
};
