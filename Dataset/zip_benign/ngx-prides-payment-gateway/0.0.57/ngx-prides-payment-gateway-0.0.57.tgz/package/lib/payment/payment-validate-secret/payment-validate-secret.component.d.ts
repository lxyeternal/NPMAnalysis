import { EventEmitter } from '@angular/core';
import { IMerchantPayTranxInfo } from '../../core/interfaces/order/iMerchantPayTranxInfo';
import { AuthService } from '../../core/services/auth/auth.service';
import { OrderStateManagementService } from '../../core/services/order/order-state-management.service';
import { OrderService } from '../../core/services/order/order.service';
import { FbLogsServiceService } from '../../core/services/tranxLogs/fb-logs-service.service';
import * as i0 from "@angular/core";
export declare class PaymentValidateSecretComponent {
    private _authService;
    private _currentTranxInfo;
    private _order;
    private _fbLogService;
    isLoading: boolean;
    secretIsValid: boolean;
    secretValidationDone: boolean;
    validationSecretErrors: string[];
    faExclamationCircle: import("@fortawesome/fontawesome-common-types").IconDefinition;
    goToNextStep: EventEmitter<number>;
    merchantPayTranxInfo: IMerchantPayTranxInfo;
    constructor(_authService: AuthService, _currentTranxInfo: OrderStateManagementService, _order: OrderService, _fbLogService: FbLogsServiceService);
    ngOnInit(): void;
    validateSecret(): void;
    createOrder(): void;
    private saveLogs;
    private saveAuditLog;
    private saveTranxLog;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentValidateSecretComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaymentValidateSecretComponent, "app-payment-validate-secret", never, { "merchantPayTranxInfo": { "alias": "merchantPayTranxInfo"; "required": false; }; }, { "goToNextStep": "goToNextStep"; }, never, never, false, never>;
}
