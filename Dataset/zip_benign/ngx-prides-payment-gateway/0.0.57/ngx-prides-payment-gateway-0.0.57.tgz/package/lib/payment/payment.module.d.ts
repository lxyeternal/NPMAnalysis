import * as i0 from "@angular/core";
import * as i1 from "./payment-principal/payment-principal.component";
import * as i2 from "./payment-revalidation/payment-revalidation.component";
import * as i3 from "./payment-select-bank/payment-select-bank.component";
import * as i4 from "./payment-validate-secret/payment-validate-secret.component";
import * as i5 from "@angular/common";
import * as i6 from "@fortawesome/angular-fontawesome";
import * as i7 from "@angular/forms";
import * as i8 from "angularx-qrcode";
import * as i9 from "../shared/full-screen-spinner/full-screen-spinner.component";
import * as i10 from "ngx-toastr";
import * as i11 from "@angular/fire/compat";
import * as i12 from "@angular/fire/compat/database";
import * as i13 from "@angular/platform-browser";
import * as i14 from "@angular/common/http";
import * as i15 from "@angular/platform-browser/animations";
import * as i16 from "ngx-mask";
export declare class PaymentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaymentModule, [typeof i1.PaymentPrincipalComponent, typeof i2.PaymentRevalidationComponent, typeof i3.PaymentSelectBankComponent, typeof i4.PaymentValidateSecretComponent], [typeof i5.CommonModule, typeof i6.FontAwesomeModule, typeof i7.FormsModule, typeof i8.QRCodeModule, typeof i9.FullScreenSpinnerComponent, typeof i10.ToastrModule, typeof i11.AngularFireModule, typeof i12.AngularFireDatabaseModule, typeof i13.BrowserModule, typeof i14.HttpClientModule, typeof i15.BrowserAnimationsModule, typeof i16.NgxMaskModule], [typeof i1.PaymentPrincipalComponent, typeof i2.PaymentRevalidationComponent, typeof i3.PaymentSelectBankComponent, typeof i4.PaymentValidateSecretComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaymentModule>;
}
