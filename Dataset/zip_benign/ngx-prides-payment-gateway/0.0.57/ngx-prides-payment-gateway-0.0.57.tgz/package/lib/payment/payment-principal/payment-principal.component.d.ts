import { PaymentGatewaySteps } from '../../core/enums/enumPaymentGatewaySteps';
import { IMerchantPayTranxInfo } from '../../core/interfaces/order/iMerchantPayTranxInfo';
import * as i0 from "@angular/core";
export declare class PaymentPrincipalComponent {
    faCheckCircle: import("@fortawesome/fontawesome-common-types").IconDefinition;
    paymentStep: PaymentGatewaySteps;
    merchantPayTranxInfo: IMerchantPayTranxInfo;
    switchStep(step: PaymentGatewaySteps): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentPrincipalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaymentPrincipalComponent, "app-payment-principal", never, { "merchantPayTranxInfo": { "alias": "merchantPayTranxInfo"; "required": false; }; }, {}, never, never, false, never>;
}
