export interface ILogTransaction {
    CompanyId: string;
    Description: string;
    Detail: string;
    ExecutionTime: string;
    JsonResponse: string;
    Parameters: string;
    ServiceName: string;
    TransactionId: string;
}
