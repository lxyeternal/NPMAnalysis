import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CryptoService } from '../services/crypto/crypto.service';
import * as i0 from "@angular/core";
export declare class AuthInterceptorService implements HttpInterceptor {
    private _cryptoService;
    constructor(_cryptoService: CryptoService);
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthInterceptorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthInterceptorService>;
}
