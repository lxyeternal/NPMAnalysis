import * as i0 from "@angular/core";
export declare class CryptoService {
    private secretKey;
    constructor();
    generateKey(): Promise<void>;
    encrypt(data: string): Promise<string>;
    decrypt(encryptedData: string): Promise<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CryptoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CryptoService>;
}
