import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IAppSettings } from '../../interfaces/appSettings/iAppSettings';
import * as i0 from "@angular/core";
export declare class FbAppSettingsService {
    private http;
    baseUrl: string;
    apiKey: string;
    constructor(http: HttpClient);
    getAppSettings(): Observable<IAppSettings>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FbAppSettingsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FbAppSettingsService>;
}
