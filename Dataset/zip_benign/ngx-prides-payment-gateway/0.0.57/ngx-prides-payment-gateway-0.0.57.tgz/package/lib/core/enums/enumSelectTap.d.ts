export declare enum selectTab {
    none = 0,
    qr = 1,
    sms = 2
}
