import { Observable } from 'rxjs';
import { IMerchantPayTranxInfo } from '../../interfaces/order/iMerchantPayTranxInfo';
import { CryptoService } from '../crypto/crypto.service';
import * as i0 from "@angular/core";
export declare class OrderStateManagementService {
    private _cryptoService;
    private tranxInfoState;
    orderTranxInfo$: Observable<IMerchantPayTranxInfo>;
    constructor(_cryptoService: CryptoService);
    private initializeState;
    getDefaultState(): Promise<IMerchantPayTranxInfo>;
    updateOrderTranxInfo(newState: IMerchantPayTranxInfo): void;
    getEmptyTranxModel(): IMerchantPayTranxInfo;
    clearTranxInfo(): void;
    existTranxInfo(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderStateManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderStateManagementService>;
}
