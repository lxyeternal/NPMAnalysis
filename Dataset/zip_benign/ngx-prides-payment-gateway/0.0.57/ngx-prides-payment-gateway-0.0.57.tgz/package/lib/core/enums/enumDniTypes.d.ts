export declare enum DniTypes {
    None = 0,
    Fisica = 1,
    Juridica = 2,
    DIMEX = 3
}
