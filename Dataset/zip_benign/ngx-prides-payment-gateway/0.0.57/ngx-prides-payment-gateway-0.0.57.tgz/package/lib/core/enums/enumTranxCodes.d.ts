export declare enum TranxResponseCode {
    Ok = "PP-200",
    Created = "PP-201",
    Unauthorized = "PP-401",
    NotFoundData = "PP-404",
    ProviderTimeOut = "PP-408",
    InvalidAmount = "PP-409",
    ServerError = "PP-500"
}
