export interface ICreateOrderRequest {
    transactionId?: string;
    companyId?: string;
    referenceNumber?: string;
    transactionStart?: string;
    transactionEnd?: string;
    amount: number;
    externalTransactionId?: string;
    detailTransaction?: string;
    customer?: string;
    phoneNumber?: string;
    status?: string;
    responseCode?: string;
}
