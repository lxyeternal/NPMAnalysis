import { DeviceTypes } from '../../enums/enumDeviceType';
import * as i0 from "@angular/core";
export declare class DeviceTypeService {
    constructor();
    getDeviceType(): DeviceTypes;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeviceTypeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeviceTypeService>;
}
