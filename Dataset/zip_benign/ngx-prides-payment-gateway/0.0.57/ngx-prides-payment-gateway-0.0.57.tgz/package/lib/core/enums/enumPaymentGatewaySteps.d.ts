export declare enum PaymentGatewaySteps {
    ValidateSecret = 0,
    PaymentGateway = 1,
    TranxConfirm = 2
}
