export declare enum DeviceTypes {
    android = "Android",
    iOS = "iOS",
    windowsPhone = "Windows Phone",
    windows = "Windows",
    macOS = "Mac OS",
    linux = "Linux",
    unknown = "Unknownx"
}
