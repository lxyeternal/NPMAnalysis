import { Observable } from 'rxjs';
import { IPaymentTranx } from '../../interfaces/payment/iPaymentTranx';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';
import * as i0 from "@angular/core";
export declare class FbPaymentTransactionService {
    private db;
    pathRef: string;
    lstPaymentTranx: AngularFireList<IPaymentTranx>;
    constructor(db: AngularFireDatabase);
    getAll(): AngularFireList<IPaymentTranx>;
    getById(id: string): Observable<IPaymentTranx | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FbPaymentTransactionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FbPaymentTransactionService>;
}
