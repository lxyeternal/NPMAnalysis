export interface ICreateOrderResponse {
    transactionId: string;
    amount: number;
    companyId: string;
}
