import { HttpClient } from '@angular/common/http';
import { IAccountBankItem } from '../../interfaces/accountBanks/iAccountBankItem';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class FbAccountBankServiceService {
    private http;
    baseUrl: string;
    apiKey: string;
    constructor(http: HttpClient);
    getAccountBanks(): Observable<IAccountBankItem[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FbAccountBankServiceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FbAccountBankServiceService>;
}
