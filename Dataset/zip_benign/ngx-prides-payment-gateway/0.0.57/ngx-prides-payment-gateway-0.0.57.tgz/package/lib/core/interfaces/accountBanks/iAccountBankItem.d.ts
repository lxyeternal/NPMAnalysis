export interface IAccountBankItem {
    Enabled: boolean;
    Id: string;
    Image: string;
    Name: string;
    PhoneReceptor: number;
}
