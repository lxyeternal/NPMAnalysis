export interface IBaseApiResponse<T> {
    response: IBaseResponseMessage;
    definition: T;
}
export interface IBaseResponseMessage {
    success: boolean;
    message: string;
}
