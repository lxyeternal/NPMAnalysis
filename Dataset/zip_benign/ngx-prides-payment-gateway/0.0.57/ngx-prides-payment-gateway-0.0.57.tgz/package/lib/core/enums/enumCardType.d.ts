export declare enum CardTypes {
    none = "none",
    danger = "danger",
    warning = "warning",
    success = "success",
    info = "info"
}
