export interface IPaymentTranx {
    Amount: number;
    CompanyId: string;
    Customer: string;
    DetailTransaction: string;
    ExternalTransactionId: string;
    PhoneNumber: string;
    ResponseCode: string;
    Status: string;
    TransactionEnd: string;
    TransactionId: string;
    TransactionStart: string;
}
export interface IPaymentTransactions {
    [key: string]: IPaymentTranx;
}
