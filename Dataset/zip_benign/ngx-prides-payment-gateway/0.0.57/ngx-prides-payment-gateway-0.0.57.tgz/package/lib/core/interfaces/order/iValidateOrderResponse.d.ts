export interface IValidateOrderResponse {
    transactionId: string;
    amount: number;
}
