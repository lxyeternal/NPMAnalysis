export interface IValidateOrderRequest {
    transactionId: string;
}
