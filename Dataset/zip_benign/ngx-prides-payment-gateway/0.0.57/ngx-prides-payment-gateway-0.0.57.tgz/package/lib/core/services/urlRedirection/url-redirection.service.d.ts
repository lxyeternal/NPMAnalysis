import * as i0 from "@angular/core";
export declare class UrlRedirectionService {
    constructor();
    doRedirectToCommerce(urlToRedirect: string, tranxId: string, status: string, total: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlRedirectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UrlRedirectionService>;
}
