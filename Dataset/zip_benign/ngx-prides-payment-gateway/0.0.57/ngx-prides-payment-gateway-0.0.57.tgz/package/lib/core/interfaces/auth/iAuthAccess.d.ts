export interface IAuthAccess {
    token?: string;
    refreshToken?: string;
    expiration?: string;
    userSession: string;
}
