export interface IRevalidateOrderRequest {
    transactionId?: string;
    referenceNumber?: string;
}
