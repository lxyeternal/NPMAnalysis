export interface IAppSettings {
    NumberSender: number;
}
