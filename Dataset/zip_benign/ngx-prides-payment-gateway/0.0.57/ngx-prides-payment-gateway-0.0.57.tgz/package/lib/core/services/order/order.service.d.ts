import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBaseApiResponse } from '../../interfaces/common/iBaseApiResponse';
import { ICreateOrderResponse } from '../../interfaces/order/iCreateOrderResponse';
import { ICreateOrderRequest } from '../../interfaces/order/iCreateOrderRequest';
import { IValidateOrderResponse } from '../../interfaces/order/iValidateOrderResponse';
import { IValidateOrderRequest } from '../../interfaces/order/iValidateOrderRequest';
import { IRevalidateOrderRequest } from '../../interfaces/order/iRevalidateOrderRequest';
import * as i0 from "@angular/core";
export declare class OrderService {
    private http;
    private controllerName;
    private apiURL;
    constructor(http: HttpClient);
    createOrder(orderData: ICreateOrderRequest): Observable<IBaseApiResponse<ICreateOrderResponse>>;
    validateOrder(orderData: IValidateOrderRequest): Observable<IBaseApiResponse<IValidateOrderResponse>>;
    reValidateOrder(orderData: IRevalidateOrderRequest): Observable<IBaseApiResponse<IValidateOrderResponse>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderService>;
}
