import { DniTypes } from "../../enums/enumDniTypes";
export interface IDniTypes {
    id: DniTypes;
    name: string;
}
