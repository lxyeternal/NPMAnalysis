import { AngularFireDatabase } from '@angular/fire/compat/database';
import { ILogTransaction } from '../../interfaces/logs/iLogTransaction';
import { IAuditLogs } from '../../interfaces/logs/iAuditLogs';
import * as i0 from "@angular/core";
export declare class FbLogsServiceService {
    private db;
    logTranxPathRef: string;
    auditLogsPathRef: string;
    constructor(db: AngularFireDatabase);
    insertLogTransaction(logTransaction: ILogTransaction, tranxId: string): boolean;
    insertAuditLog(auditLog: IAuditLogs, date?: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FbLogsServiceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FbLogsServiceService>;
}
