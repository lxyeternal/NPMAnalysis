import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBaseApiResponse } from '../../interfaces/common/iBaseApiResponse';
import { IAuthAccess } from '../../interfaces/auth/iAuthAccess';
import { CryptoService } from '../crypto/crypto.service';
import * as i0 from "@angular/core";
export declare class AuthService {
    private http;
    private _cryptoService;
    private controllerName;
    private apiURL;
    constructor(http: HttpClient, _cryptoService: CryptoService);
    validateSecret(secretKey: string): Observable<IBaseApiResponse<IAuthAccess>>;
    private storeTokens;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthService>;
}
