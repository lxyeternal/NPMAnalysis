import * as i0 from "@angular/core";
export declare class FullScreenSpinnerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FullScreenSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FullScreenSpinnerComponent, "app-full-screen-spinner", never, {}, {}, never, never, true, never>;
}
