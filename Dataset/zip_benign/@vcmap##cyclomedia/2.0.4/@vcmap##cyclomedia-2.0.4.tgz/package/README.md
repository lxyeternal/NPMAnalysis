# @vcmap/cyclomedia

> Part of the [VC Map Project](https://github.com/virtualcitySYSTEMS/map-ui)

This plugin adds a [cyclomedia](https://www.cyclomedia.com/) panorama viewer to the VC Map, which is rendered next to the VC Map canvas.
This enables a comparison of panorama images with 2D, 3D or oblique environment in the VC Map.

## Features

- VC Map is synchronized to Cyclomedia Viewer changes
- VC Map shows Cyclomedia recordings WFS, which allows to open specific images per click.
- size of Cyclomedia Viewer an VC Map can be adapted
- plugin state (active, current image) can be shared with create link plugin of VC Map

## Configuration

| Property               | Type                | default                                              | Description                                                                                                                                                 |
| ---------------------- | ------------------- | ---------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `username`             | `string`            | required                                             | Cyclomedia User                                                                                                                                             |
| `password`             | `string`            | required                                             | Cyclomedia Password                                                                                                                                         |
| `apiKey`               | `string`            | required                                             | Cyclomedia API Key                                                                                                                                          |
| `projection`           | `ProjectionOptions` | required                                             | Projection definition for Cyclomedia application and WFS.                                                                                                   |
| `activeOnStartup`      | `boolean`           | `false`                                              | Whether to open cyclomedia on startup.                                                                                                                      |
| `startingImage`        | `string`            | `undefined`                                          | Optional starting image ID. Takes precedence over starting position.                                                                                        |
| `startingPosition`     | `Coordinate`        | `undefined`                                          | Optional starting position in the configured projection.                                                                                                    |
| `startingMapName`      | `string`            | `undefined`                                          | Name of VC Map to be activated, when cyclomedia is activated.                                                                                               |
| `startingLayerNames`   | `string[]`          | `[]`                                                 | Name of layers to be activated, when cyclomedia is activated.                                                                                               |
| `startingZoomDistance` | `number`            | `undefined`                                          | Startup distance of camera to ground in meter (e.g. 150). This is equivalent to a zoom level parameter.                                                     |
| `panelSize`            | `string`            | `50%`                                                | Initial viewer width or height in percent. Defines the size of Cyclomedia viewer in relation to VC Map canvas.                                              |
| `panelLocation`        | `PanelLocation`     | `vcs-right`                                          | Defines in which VC Map panel the cyclomedia viewer is rendered. Allowed values: 'vcs-left', 'vcs-right' (default) and 'vcs-bottom'.                        |
| `configurationUrl`     | `string`            | https://atlas.cyclomedia.com/configuration/          | URL to Cyclomedia configuration                                                                                                                             |
| `recordingsBaseUrl`    | `string`            | https://atlas.cyclomedia.com/recording/wfs?          | Base URL of Cyclomedia recordings WFS                                                                                                                       |
| `recordingsColorRGBA`  | `Array<Number>`     | `[148, 181, 74, 0.4]`                                | Color of recordings (rgba)                                                                                                                                  |
| `locale`               | `string`            | `en-us`                                              | Cyclomedia locale                                                                                                                                           |
| `addressSettings`      | `Object`            | `{ "locale": "us", "database": "Nokia" }`            | Cyclomedia address settings                                                                                                                                 |
| `cameraOptions3D`      | `Object`            | `{ "cyclomediaHeightReference": true, "offset": 0 }` | Additional camera options for 3D map, offset to ground in meter. cyclomediaheightReference defines, whether to apply offset as absolute or relative offset. |

The projection for the Date `ETRS89 / UTM zone 32N + DHHN92 height` should be defined as:

```
"projection": {
    "epsg": "EPSG:5555",
    "proj4": "+proj=utm +zone=32 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs"
}
```
