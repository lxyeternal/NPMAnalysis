# v2.0.4

- Updates @cyclomedia/StreetSmartAPI to version 25.2.0
- Hides record features in VC Map not matching the date of the current image in the Cyclomedia viewer

# v2.0.3

- Fix panelSize not taken into account

# v2.0.2

- Make internal layer volatile

# v2.0.1

- Fix action reactivity and layer index issues

# v2.0.0

- Updates @vcmap/core and @vcmap/ui to version 6.x
- Updates @cyclomedia/StreetSmartAPI to version 24.11.0
- Fixes a bug where the Config Editor's viewer size was converted to a number when expecting a '%' symbol
- Fixes a bug where the Recordings color defined in the Config Editor was not applied
