<template>
  <AbstractConfigEditor @submit="apply">
    <VcsFormSection
      heading="cyclomedia.config.general"
      expandable
      :start-open="true"
      v-if="localConfig"
    >
      <v-container class="py-0 px-1">
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="username" required>
              {{ $t('cyclomedia.config.username') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="username"
              v-model="localConfig.username"
              :rules="[isRequired]"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="password" required>
              {{ $t('cyclomedia.config.password') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="password"
              v-model="localConfig.password"
              :rules="[isRequired]"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="apiKey" required>
              {{ $t('cyclomedia.config.apiKey') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="apiKey"
              v-model="localConfig.apiKey"
              :rules="[isRequired]"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="epsg" required>
              {{ $t('cyclomedia.config.projection.epsg') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="epsg"
              clearable
              v-model.number="localConfig.projection.epsg"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="proj4" required>
              {{ $t('cyclomedia.config.projection.proj4') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="proj4"
              clearable
              v-model.trim="localConfig.projection.proj4"
            />
          </v-col>
        </v-row>
      </v-container>
    </VcsFormSection>
    <VcsFormSection
      heading="cyclomedia.config.starting"
      expandable
      v-if="localConfig"
    >
      <v-container class="py-0 px-1">
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="activeOnStartup">
              {{ $t('cyclomedia.config.activeOnStartup') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsCheckbox
              id="activeOnStartup"
              v-model="localConfig.activeOnStartup"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsCheckbox
              id="startingImageCheckBox"
              label="cyclomedia.config.startingImage"
              true-value="startingImage"
              false-value="startingPosition"
              v-model="startingPositionOrImage"
            />
          </v-col>
          <v-col>
            <VcsTextField
              id="startingImage"
              clearable
              placeholder="imageId"
              v-model.trim="localConfig.startingImage"
              :disabled="startingPositionOrImage === 'startingPosition'"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsCheckbox
              id="startingPosition"
              label="cyclomedia.config.startingPosition"
              true-value="startingPosition"
              false-value="startingImage"
              v-model="startingPositionOrImage"
            />
          </v-col>
          <v-col>
            <VcsCoordinate
              v-model="localConfig.startingPosition"
              hide-z
              :units="posOptions.units"
              :steps="posOptions.steps"
              :extent="posOptions.extent"
              :disabled="startingPositionOrImage === 'startingImage'"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="startingMapName">
              {{ $t('cyclomedia.config.startingMapName') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsSelect
              id="startingMapName"
              :items="mapNames"
              v-model="localConfig.startingMapName"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="startingLayerNames">
              {{ $t('cyclomedia.config.startingLayerNames') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsSelect
              id="startingLayerNames"
              multiple
              :items="layerNames"
              v-model="localConfig.startingLayerNames"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="startingZoomDistance">
              {{ $t('cyclomedia.config.startingZoomDistance') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="startingZoomDistance"
              clearable
              v-model.number="localConfig.startingZoomDistance"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="panelSize">
              {{ $t('cyclomedia.config.panelSize') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="panelSize"
              clearable
              v-model="localConfig.panelSize"
              :rules="ensurePanelSize()"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="panelLocation">
              {{ $t('cyclomedia.config.panelLocation.title') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsSelect
              id="panelLocation"
              :items="panelLocations"
              v-model="localConfig.panelLocation"
            />
          </v-col>
        </v-row>
      </v-container>
    </VcsFormSection>
    <VcsFormSection
      heading="cyclomedia.config.extended"
      expandable
      v-if="localConfig"
    >
      <v-container class="py-0 px-1">
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="configurationUrl">
              {{ $t('cyclomedia.config.configurationUrl') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="configurationUrl"
              clearable
              v-model.trim="localConfig.configurationUrl"
              :rules="[isOptionalUrl]"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="recordingsBaseUrl">
              {{ $t('cyclomedia.config.recordingsBaseUrl') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="recordingsBaseUrl"
              clearable
              v-model.trim="localConfig.recordingsBaseUrl"
              :rules="[isOptionalUrl]"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="recordingsColorRGBA">
              {{ $t('cyclomedia.config.recordingsColorRGBA') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <v-color-picker
              v-model="color"
              @update:modelValue="setColor"
              mode="rgba"
            />
          </v-col>
        </v-row>
        <v-row no-gutters>
          <v-col>
            <VcsLabel html-for="locale">
              {{ $t('cyclomedia.config.locale') }}
            </VcsLabel>
          </v-col>
          <v-col>
            <VcsTextField
              id="locale"
              clearable
              v-model.trim="localConfig.locale"
            />
          </v-col>
        </v-row>
      </v-container>
    </VcsFormSection>
  </AbstractConfigEditor>
</template>

<script lang="ts">
  import { VContainer, VRow, VCol, VColorPicker } from 'vuetify/components';
  import {
    AbstractConfigEditor,
    VcsFormSection,
    VcsLabel,
    VcsTextField,
    VcsCheckbox,
    VcsCoordinate,
    VcsSelect,
    type VcsUiApp,
    PanelLocation,
  } from '@vcmap/ui';
  import {
    computed,
    defineComponent,
    inject,
    onUnmounted,
    PropType,
    Ref,
    ref,
  } from 'vue';
  import type { RGBA } from '@cyclomedia/streetsmart-api';
  import { wgs84Projection } from '@vcmap/core';
  import getDefaultOptions, { CyclomediaConfig } from './defaultOptions.js';

  type VColorPickerColorRGBA = {
    r: number;
    g: number;
    b: number;
    a: number;
  };

  function isRequired(value: string): boolean | string {
    return value !== '' || 'cyclomedia.config.isRequired';
  }

  function isUrl(value: string): boolean | string {
    try {
      return Boolean(new URL(value));
    } catch (e) {
      return 'cyclomedia.config.invalidUrl';
    }
  }

  function getPickerColor(colorRGBA: RGBA): VColorPickerColorRGBA {
    return {
      r: colorRGBA[0],
      g: colorRGBA[1],
      b: colorRGBA[2],
      a: colorRGBA[3],
    };
  }

  export default defineComponent({
    name: 'CyclomediaConfigEditor',
    components: {
      VcsSelect,
      VcsCoordinate,
      VContainer,
      VRow,
      VCol,
      AbstractConfigEditor,
      VcsFormSection,
      VcsLabel,
      VcsTextField,
      VcsCheckbox,
      VColorPicker,
    },
    props: {
      getConfig: {
        type: Function as PropType<() => CyclomediaConfig>,
        required: true,
      },
      setConfig: {
        type: Function as PropType<(config: object | undefined) => void>,
        required: true,
      },
    },
    setup(props) {
      const app = inject('vcsApp') as VcsUiApp;
      const defaultOptions = getDefaultOptions();
      const config = props.getConfig();
      const localConfig = ref<CyclomediaConfig>({
        ...defaultOptions,
        ...config,
      });
      const color = ref(getPickerColor(defaultOptions.recordingsColorRGBA!));
      const startingPositionOrImage = ref('startingImage');
      if (config.recordingsColorRGBA) {
        color.value = getPickerColor(config.recordingsColorRGBA);
      }
      if (
        Array.isArray(localConfig.value.startingPosition) &&
        localConfig.value.startingPosition.every((c) => c !== 0)
      ) {
        startingPositionOrImage.value = 'startingPosition';
      }

      const posOptions = computed(() => {
        if (localConfig.value.projection.epsg === wgs84Projection.epsg) {
          return {};
        }
        return {
          units: ['m', 'm', 'm'],
          steps: [1, 1, 1],
          extent: [-Infinity, -Infinity, Infinity, Infinity],
        };
      });

      const mapNames: Ref<string[]> = ref([]);
      const layerNames: Ref<string[]> = ref([]);
      const setMapNames = (): void => {
        mapNames.value = [...app.maps].map((m) => m.name);
      };
      const setLayerNames = (): void => {
        layerNames.value = [...app.layers].map((l) => l.name);
      };

      const listener = [
        app.maps.added.addEventListener(setMapNames),
        app.maps.removed.addEventListener(setMapNames),
        app.layers.added.addEventListener(setLayerNames),
        app.layers.removed.addEventListener(setLayerNames),
      ];
      setMapNames();
      setLayerNames();

      const panelLocations = Object.values(PanelLocation).map((v) => ({
        title: `cyclomedia.config.panelLocation.${v}`,
        value: v,
      }));

      onUnmounted(() => listener.forEach((cb) => cb()));

      return {
        localConfig,
        startingPositionOrImage,
        posOptions,
        mapNames,
        layerNames,
        panelLocations,
        color,
        ensurePanelSize(): (boolean | string)[] {
          const { panelSize } = localConfig.value;
          if (!panelSize) return [true];
          return [
            panelSize.endsWith('%') ||
              'cyclomedia.config.error.panelSizeLacksPercent',
            !!Number(panelSize.slice(0, -1)) ||
              'cyclomedia.config.error.panelSizeInvalid',
          ];
        },
        setColor(rgba: VColorPickerColorRGBA): void {
          localConfig.value.recordingsColorRGBA = [
            rgba.r,
            rgba.g,
            rgba.b,
            rgba.a,
          ];
        },
        isRequired,
        isOptionalUrl(v: string | undefined): boolean | string {
          return v === undefined || v === '' || isUrl(v);
        },
        apply(): void {
          if (startingPositionOrImage.value === 'startingPosition') {
            delete localConfig.value.startingImage;
          } else if (startingPositionOrImage.value === 'startingImage') {
            delete localConfig.value.startingPosition;
          }
          props.setConfig(localConfig.value);
        },
      };
    },
  });
</script>

<style scoped></style>
