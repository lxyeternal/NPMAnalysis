import { type ApiOptions, StreetSmartApi } from '@cyclomedia/streetsmart-api';
import { getLogger } from '@vcsuite/logger';
import { type CyclomediaConfig } from './defaultOptions.js';
import { name } from '../package.json';

// eslint-disable-next-line import/prefer-default-export
export async function initApi(
  targetElement: HTMLElement,
  config: CyclomediaConfig,
): Promise<() => void> {
  try {
    await StreetSmartApi.init({
      targetElement,
      username: config.username,
      password: config.password,
      apiKey: config.apiKey,
      srs: config.projection.epsg,
      locale: config.locale,
      addressSettings: config.addressSettings,
      configurationUrl: config.configurationUrl,
    } as ApiOptions);

    getLogger(name).info(
      `Initialized StreetSmartAPI version ${StreetSmartApi.getApplicationVersion()}`,
    );
  } catch (e) {
    getLogger(name).error('Failed initializing StreetSmartAPI', e);
  }

  return () => {
    // eslint-disable-next-line no-void
    void StreetSmartApi.destroy({
      targetElement,
      loginOauth: false,
    });
  };
}
