import type {
  ApiOptionsBase,
  BasicAuthOptions,
  Coordinate,
  Locale,
  RGBA,
} from '@cyclomedia/streetsmart-api';
import type { ProjectionOptions } from '@vcmap/core';
import { PanelLocation } from '@vcmap/ui';

export type CyclomediaConfig = Omit<ApiOptionsBase, 'targetElement' | 'srs'> &
  BasicAuthOptions & {
    projection: ProjectionOptions;
    activeOnStartup?: boolean;
    startingImage?: string;
    startingPosition?: Coordinate;
    startingMapName?: string;
    startingLayerNames?: string[];
    startingZoomDistance?: number;
    panelSize?: string;
    panelLocation?: PanelLocation;
    recordingsBaseUrl?: string;
    recordingsColorRGBA?: RGBA;
    cameraOptions3D?: {
      cyclomediaHeightReference: boolean;
      offset: number;
    };
  };

export default function getDefaultOptions(): CyclomediaConfig {
  return {
    username: '',
    password: '',
    apiKey: '',
    projection: {
      epsg: 'EPSG:55557837',
      proj4:
        '+proj=utm +zone=32 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +vunits=m +no_defs',
    },
    activeOnStartup: false,
    startingImage: undefined,
    startingPosition: undefined,
    startingMapName: undefined,
    startingLayerNames: [],
    startingZoomDistance: undefined,
    panelSize: '50%',
    panelLocation: PanelLocation.RIGHT,
    configurationUrl: 'https://atlas.cyclomedia.com/configuration/',
    recordingsBaseUrl: 'https://atlas.cyclomedia.com/recording/wfs?',
    recordingsColorRGBA: [148, 181, 74, 0.4],
    locale: 'en-Us' as Locale,
    addressSettings: {
      locale: 'us',
      database: 'Nokia',
    },
    cameraOptions3D: {
      cyclomediaHeightReference: true,
      offset: 0,
    },
  };
}
