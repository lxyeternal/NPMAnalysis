import '@cyclomedia/streetsmart-api';

declare module '@cyclomedia/streetsmart-api' {
  namespace StreetSmartApi {
    function closeViewer(wid: sting): Promise<void>;
  }
}
