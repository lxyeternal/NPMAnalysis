import {
  VcsPlugin,
  VcsUiApp,
  PluginConfigEditor,
  VcsAction,
  ButtonLocation,
  PanelComponentOptions,
  PanelLocation,
} from '@vcmap/ui';
import { Coordinate, StreetSmartApi } from '@cyclomedia/streetsmart-api';
import {
  markVolatile,
  maxZIndex,
  mercatorProjection,
  Projection,
  URLTemplateTileProvider,
  VectorLayer,
  VectorStyleItem,
  VectorTileLayer,
} from '@vcmap/core';
import { parseEnumValue } from '@vcsuite/parsers';
import { reactive, ref, UnwrapNestedRefs } from 'vue';
import { getLogger } from '@vcsuite/logger';
import { name, version, mapVersion } from '../package.json';
import getDefaultOptions, { type CyclomediaConfig } from './defaultOptions.js';
import CyclomediaConfigEditor from './CyclomediaConfigEditor.vue';
import RecordingsWFSLayer from './recordings/RecordingsWFSLayer.js';
import CyclomediaViewer from './CyclomediaViewer.vue';
import { getTileProviderURL } from './recordings/recordingsHelper.js';

export type CyclomediaState = {
  active: boolean;
  image?: string;
};

export type CyclomediaPlugin = VcsPlugin<CyclomediaConfig, CyclomediaState> & {
  config: CyclomediaConfig;
  state: CyclomediaState;
  readonly projection: Projection;
  readonly cameraIconLayer: VectorLayer;
  readonly recordingsTileLayer: VectorTileLayer;
  readonly recordingsWFSLayer: RecordingsWFSLayer;
  activate: (imageOrCoordinate?: string | Coordinate) => Promise<void>;
  deactivate: () => void;
};

function createCyclomediaAction(
  app: VcsUiApp,
  plugin: CyclomediaPlugin,
): {
  action: VcsAction;
  destroy: () => void;
} {
  const action: VcsAction = reactive({
    name: 'cyclomedia.title',
    title: 'cyclomedia.title',
    icon: 'mdi-panorama-horizontal',
    active: false,
    async callback() {
      if (this.active) {
        plugin.deactivate();
      } else {
        await plugin.activate();
      }
    },
  });

  const listener = [
    app.panelManager.added.addEventListener(({ id }) => {
      if (id === name) {
        action.active = true;
        plugin.activate().catch((err) => getLogger(name).error(err));
      }
    }),
    app.panelManager.removed.addEventListener(({ id }) => {
      if (id === name) {
        action.active = false;
        plugin.deactivate();
      }
    }),
  ];

  return { action, destroy: () => listener.forEach((cb) => cb()) };
}

export default function cyclomedia(
  options: CyclomediaConfig,
): CyclomediaPlugin {
  const defaultOptions = getDefaultOptions();
  if (options.panelLocation) {
    options.panelLocation = parseEnumValue(
      options.panelLocation,
      PanelLocation,
      defaultOptions.panelLocation,
    );
  }

  const config: CyclomediaConfig = { ...defaultOptions, ...options };
  const state: CyclomediaState = reactive({
    active: ref(false),
  });

  const projection = new Projection(config.projection);

  const cameraIconLayer = new VectorLayer({
    vectorProperties: { altitudeMode: 'clampToGround' },
    projection: mercatorProjection.toJSON(),
    zIndex: maxZIndex - 1,
  });
  markVolatile(cameraIconLayer);

  const defaultLayersProps = {
    headers: {
      Authorization: `Basic ${btoa(`${config.username}:${config.password}`)}`,
    },
    style: new VectorStyleItem({
      image: {
        radius: 5,
        fill: { color: config.recordingsColorRGBA },
        stroke: { color: config.recordingsColorRGBA, width: 1 },
      },
    }),
    zIndex: maxZIndex - 1,
  };
  const recordingsTileLayer = new VectorTileLayer({
    ...defaultLayersProps,
  });
  markVolatile(recordingsTileLayer);

  const recordingsWFSLayer = new RecordingsWFSLayer({
    ...defaultLayersProps,
    url: undefined,
    featureType: 'Recording',
    featureNS: 'http://www.cyclomedia.com/atlas',
    featurePrefix: 'atlas',
    minResolution: 0,
    maxResolution: 2,
    projection: mercatorProjection.toJSON(),
  });
  markVolatile(recordingsWFSLayer);

  const cyclomediaListener: Array<() => void> = [];

  let app: VcsUiApp | null = null;

  return {
    get name(): string {
      return name;
    },
    get version(): string {
      return version;
    },
    get mapVersion(): string {
      return mapVersion;
    },
    get config(): CyclomediaConfig {
      return config;
    },
    get state(): UnwrapNestedRefs<CyclomediaState> {
      return state;
    },
    get projection(): Projection {
      return projection;
    },
    get cameraIconLayer(): VectorLayer {
      return cameraIconLayer;
    },
    get recordingsTileLayer(): VectorTileLayer {
      return recordingsTileLayer;
    },
    get recordingsWFSLayer(): RecordingsWFSLayer {
      return recordingsWFSLayer;
    },
    async initialize(
      this: CyclomediaPlugin,
      vcsUiApp: VcsUiApp,
      pluginState?: CyclomediaState,
    ): Promise<void> {
      app = vcsUiApp;
      recordingsTileLayer.tileProvider = new URLTemplateTileProvider({
        url: getTileProviderURL(config.recordingsBaseUrl!),
      });
      const recordingsUrl = new URL(config.recordingsBaseUrl!);
      recordingsUrl.searchParams.append('apiKey', config.apiKey);
      recordingsUrl.searchParams.append(
        'nameVersion',
        `${StreetSmartApi.getApplicationName()}_${StreetSmartApi.getApplicationVersion()}`,
      );
      recordingsWFSLayer.url = recordingsUrl.toString();

      const { action, destroy: actionDestroy } = createCyclomediaAction(
        app,
        this,
      );

      cyclomediaListener.push(actionDestroy);
      app.navbarManager.add({ id: name, action }, name, ButtonLocation.MAP);

      app.layers.add(cameraIconLayer);
      app.layers.add(recordingsTileLayer);
      app.layers.add(recordingsWFSLayer);

      if (config.activeOnStartup || pluginState?.active) {
        await this.activate(
          pluginState?.image || config.startingImage || config.startingPosition,
        );
      }
    },
    async activate(imageOrCoordinate?: string | Coordinate): Promise<void> {
      if (app && !state.active) {
        state.active = true;
        const panelComponentOptions: PanelComponentOptions = {
          id: name,
          component: CyclomediaViewer,
          state: { styles: { zIndex: '0' } },
          props: { imageOrCoordinate },
        };

        if (config.panelSize) {
          if (config.panelLocation === PanelLocation.BOTTOM) {
            panelComponentOptions.position = { height: config.panelSize };
          } else {
            panelComponentOptions.position = { width: config.panelSize };
          }
        }
        app.panelManager.add(
          panelComponentOptions,
          name,
          config.panelLocation as PanelLocation,
        );

        if (config.startingMapName && app.maps.hasKey(config.startingMapName)) {
          await app.maps.setActiveMap(config.startingMapName);
        }
        await Promise.all(
          config.startingLayerNames!.map((layerName: string): Promise<void> => {
            const layer = app!.layers.getByKey(layerName);
            if (layer && !layer.active) {
              return layer.activate();
            }
            return Promise.resolve();
          }),
        );

        await cameraIconLayer.activate();
        await recordingsTileLayer.activate();
        await recordingsWFSLayer.activate();
      }
    },
    deactivate(): void {
      if (state.active) {
        state.active = false;
        cameraIconLayer.deactivate();
        recordingsTileLayer.deactivate();
        recordingsWFSLayer.deactivate();
        app?.panelManager.remove(name);
      }
    },
    getDefaultOptions,
    toJSON(): CyclomediaConfig {
      const configOptions: CyclomediaConfig = {
        username: config.username,
        password: config.password,
        apiKey: config.apiKey,
        projection: projection.toJSON(),
      };
      if (config.activeOnStartup !== defaultOptions.activeOnStartup) {
        configOptions.activeOnStartup = config.activeOnStartup;
      }
      if (config.startingImage !== defaultOptions.startingImage) {
        configOptions.startingImage = config.startingImage;
      }
      if (config.startingPosition !== defaultOptions.startingPosition) {
        configOptions.startingPosition = config.startingPosition;
      }
      if (config.startingMapName !== defaultOptions.startingMapName) {
        configOptions.startingMapName = config.startingMapName;
      }
      if (config.startingLayerNames!.length > 0) {
        configOptions.startingLayerNames = config.startingLayerNames;
      }
      if (config.startingZoomDistance !== defaultOptions.startingZoomDistance) {
        configOptions.startingZoomDistance = config.startingZoomDistance;
      }
      if (config.panelSize !== defaultOptions.panelSize) {
        configOptions.panelSize = config.panelSize;
      }
      if (config.panelLocation !== defaultOptions.panelLocation) {
        configOptions.panelLocation = config.panelLocation;
      }
      if (config.configurationUrl !== defaultOptions.configurationUrl) {
        configOptions.configurationUrl = config.configurationUrl;
      }
      if (config.recordingsBaseUrl !== defaultOptions.recordingsBaseUrl) {
        configOptions.recordingsBaseUrl = config.recordingsBaseUrl;
      }
      if (
        config.recordingsColorRGBA!.some(
          (v: number, idx: number) =>
            defaultOptions.recordingsColorRGBA?.[idx] !== v,
        )
      ) {
        configOptions.recordingsColorRGBA = config.recordingsColorRGBA;
      }
      if (config.locale !== defaultOptions.locale) {
        configOptions.locale = config.locale;
      }
      if (
        config.addressSettings?.locale !==
          defaultOptions.addressSettings?.locale ||
        config.addressSettings?.database !==
          defaultOptions.addressSettings?.database
      ) {
        configOptions.addressSettings = config.addressSettings;
      }
      if (
        config.cameraOptions3D?.cyclomediaHeightReference !==
          defaultOptions.cameraOptions3D?.cyclomediaHeightReference ||
        config.cameraOptions3D?.offset !==
          defaultOptions.cameraOptions3D?.offset
      ) {
        config.cameraOptions3D = configOptions.cameraOptions3D;
      }

      return configOptions;
    },
    getState(): CyclomediaState {
      return state;
    },
    i18n: {
      en: {
        cyclomedia: {
          title: 'Cyclomedia panorama viewer',
          activateToolTitle: 'Activate Cyclomedia image selection',
          deactivateToolTitle: 'Deactivate Cyclomedia image selection',
          loading: 'Loading Cyclomedia',
          config: {
            title: 'Cyclomedia Editor',
            general: 'General settings',
            username: 'User',
            password: 'Password',
            apiKey: 'API Key',
            projection: {
              epsg: 'EPSG Code',
              proj4: 'Proj4 Def',
            },
            starting: 'Startup settings',
            activeOnStartup: 'Open Cyclomedia',
            startingImage: 'Image ID',
            startingPosition: 'Position',
            startingMapName: 'Map',
            startingLayerNames: 'Layers',
            startingZoomDistance: 'Zoom distance',
            panelSize: 'Viewer size',
            panelLocation: {
              title: 'Viewer position',
              'vcs-left': 'Left',
              'vcs-right': 'Right',
              'vcs-bottom': 'Bottom',
            },
            extended: 'Extended settings',
            configurationUrl: 'Configuration URL',
            recordingsBaseUrl: 'Recordings URL',
            recordingsColorRGBA: 'Recordings color',
            locale: 'Locale',
            error: {
              openViewer: 'An error occurred while opening the viewer',
              panelSizeLacksPercent: "The '%' symbol is missing",
              panelSizeInvalid: 'Viewer size entered is invalid',
            },
          },
        },
      },
      de: {
        cyclomedia: {
          title: 'Cyclomedia Panorama Viewer',
          loading: 'Lade Cyclomedia',
          activateToolTitle: 'Cyclomedia Bildselektion aktivieren',
          deactivateToolTitle: 'Cyclomedia Bildselektion deaktivieren',
          config: {
            title: 'Cyclomedia Editor',
            general: 'Allgemeine Einstellungen',
            username: 'Nutzer',
            password: 'Passwort',
            apiKey: 'API Key',
            projection: {
              epsg: 'EPSG Code',
              proj4: 'Proj4 Def',
            },
            starting: 'Start Einstellungen',
            activeOnStartup: 'Öffne Cyclomedia',
            startingImage: 'Bild ID',
            startingPosition: 'Position',
            startingMapName: 'Karte',
            startingLayerNames: 'Ebenen',
            startingZoomDistance: 'Zoom Distanz',
            panelSize: 'Viewer Größe',
            panelLocation: {
              title: 'Viewer Position',
              'vcs-left': 'Links',
              'vcs-right': 'Rechts',
              'vcs-bottom': 'Unten',
            },
            extended: 'Erweiterte Einstellungen',
            configurationUrl: 'Konfigurations-URL',
            recordingsBaseUrl: 'Recordings-URL',
            recordingsColorRGBA: 'Recordings-Farbe',
            locale: 'Sprache',
            error: {
              openViewer: 'Beim Öffnen des Viewers ein Fehler aufgetreten ist',
              panelSizeLacksPercent: "Das '%'-Symbol fehlt",
              panelSizeInvalid: 'Die eingegebene Viewer Größe ist ungültig',
            },
          },
        },
      },
    },
    getConfigEditors(): PluginConfigEditor<object>[] {
      return [
        {
          component: CyclomediaConfigEditor,
          title: 'cyclomedia.config.title',
          infoUrlCallback: app?.getHelpUrlCallback(
            '/components/plugins/cyclomediaToolConfig.html',
            'app-configurator',
          ),
        },
      ];
    },
    destroy(this: CyclomediaPlugin): void {
      this.deactivate();
      cyclomediaListener.forEach((cb) => cb());
      cameraIconLayer.destroy();
      recordingsTileLayer.destroy();
    },
  };
}
