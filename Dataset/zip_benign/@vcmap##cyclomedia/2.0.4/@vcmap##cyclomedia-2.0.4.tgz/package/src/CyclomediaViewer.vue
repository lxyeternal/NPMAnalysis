<template>
  <div class="w-100 h-100">
    <div id="vcs-cyclomedia-viewer" ref="targetElement" class="w-100 h-100">
      <p class="ma-5">Cyclomedia Viewer</p>
    </div>
    <div v-if="loading" class="vcs-cyclomedia-loading">
      <p>{{ $t('cyclomedia.loading') }}</p>
      <v-progress-circular indeterminate color="primary" />
    </div>
  </div>
</template>
<script lang="ts">
  import { defineComponent, inject, onMounted, onUnmounted, ref } from 'vue';
  import type { VcsUiApp } from '@vcmap/ui';
  import { VProgressCircular } from 'vuetify/components';
  import { Coordinate } from '@cyclomedia/streetsmart-api';
  import { Projection, wgs84Projection } from '@vcmap/core';
  import type { Coordinate as OLCoordinate } from 'ol/coordinate';
  import { getLogger } from '@vcsuite/logger';
  import { name } from '../package.json';
  import { initApi } from './cyclomedia.js';
  import type { CyclomediaPlugin, CyclomediaState } from './index.js';
  import {
    closeViewer,
    openViewer,
    setupViewerListener,
  } from './panoramaViewer.js';
  import { setupFeatureInfoTool } from './recordings/recordingsHelper.js';

  async function getCurrentPosition(
    app: VcsUiApp,
    projection: Projection,
  ): Promise<OLCoordinate | undefined> {
    const vp = await app.maps.activeMap?.getViewpoint();
    if (vp) {
      return projection.transformFrom(
        wgs84Projection,
        (vp.groundPosition || vp.cameraPosition) as OLCoordinate,
      );
    }
    return undefined;
  }

  async function setupCyclomediaViewer(
    app: VcsUiApp,
    plugin: CyclomediaPlugin,
    imageOrCoordinate: string | Coordinate,
  ): Promise<() => void> {
    const getPluginState = plugin.getState!.bind(plugin);
    const synchronizationListener: Array<() => void> = [];
    const panoramaViewer = await openViewer(
      app,
      imageOrCoordinate ||
        ((await getCurrentPosition(app, plugin.projection)) as Coordinate),
      plugin.projection.epsg,
    );

    if (panoramaViewer) {
      synchronizationListener.push(
        setupViewerListener(
          app,
          plugin,
          panoramaViewer,
          plugin.cameraIconLayer,
        ),
        setupFeatureInfoTool(app, panoramaViewer, [
          plugin.recordingsTileLayer.name,
          plugin.recordingsWFSLayer.name,
        ]),
      );
      plugin.getState = (
        arg0?: boolean,
      ): Promise<CyclomediaState> | CyclomediaState => {
        const state = getPluginState(arg0) as CyclomediaState;
        state.image = panoramaViewer.getRecording().id;
        return state;
      };
    }

    return (): void => {
      if (panoramaViewer) {
        synchronizationListener.forEach((cb) => cb());
        closeViewer(panoramaViewer).catch((err) => getLogger(name).error(err));
      }
      plugin.getState = getPluginState;
    };
  }

  export default defineComponent({
    name: 'CyclomediaViewer',
    components: {
      VProgressCircular,
    },
    props: {
      imageOrCoordinate: {
        type: [String, Array],
        default: undefined,
      },
    },
    setup(props) {
      const app = inject<VcsUiApp>('vcsApp')!;
      const plugin = app.plugins.getByKey(name) as CyclomediaPlugin;
      const targetElement = ref();
      const loading = ref(true);
      const destroyFunctions: Array<() => void> = [];

      onMounted(() => {
        initApi(targetElement.value, plugin.config)
          .then((apiDestroy) => {
            destroyFunctions.push(apiDestroy);
            return setupCyclomediaViewer(
              app,
              plugin,
              props.imageOrCoordinate as string | Coordinate,
            );
          })
          .then((viewerDestroy) => {
            destroyFunctions.push(viewerDestroy);
            loading.value = false;
          })
          .catch((err) => {
            plugin.deactivate();
            getLogger(name).error('Failed setting up Cyclomedia Viewer', err);
          });
      });

      onUnmounted(() => destroyFunctions.forEach((cb) => cb()));

      return {
        targetElement,
        loading,
      };
    },
  });
</script>

<style scoped>
  .vcs-cyclomedia-loading {
    height: 50%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
</style>
