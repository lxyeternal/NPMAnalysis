import {
  AbstractInteraction,
  EventType,
  InteractionEvent,
  ModificationKeyType,
  vcsLayerName,
} from '@vcmap/core';
import { PanoramaViewer } from '@cyclomedia/streetsmart-api';
import { getLogger } from '@vcsuite/logger';
import { name } from '../../package.json';

export type RecordingInteractionOptions = {
  layerNames: string[];
  panoramaViewer: PanoramaViewer;
};

class RecordingInteractions extends AbstractInteraction {
  private readonly _layerNames: string[];

  private _panoramaViewer: PanoramaViewer;

  constructor(options: RecordingInteractionOptions) {
    super(EventType.CLICK, ModificationKeyType.NONE);
    this._layerNames = options.layerNames;
    this._panoramaViewer = options.panoramaViewer;
    this.setActive();
  }

  /**
   * Open PanoramaViewer by imageId on feature click
   * @param event
   */
  async pipe(event: InteractionEvent): Promise<InteractionEvent> {
    if (
      event.feature &&
      event.feature[vcsLayerName] &&
      this._layerNames.includes(event.feature[vcsLayerName])
    ) {
      event.stopPropagation = true;
      const imageId: string = event.feature.getProperty('imageId');
      if (imageId) {
        getLogger(name).info(`loading image ${imageId}`);
        await this._panoramaViewer.openByImageId(imageId);
      }
    }
    return event;
  }
}

export default RecordingInteractions;
