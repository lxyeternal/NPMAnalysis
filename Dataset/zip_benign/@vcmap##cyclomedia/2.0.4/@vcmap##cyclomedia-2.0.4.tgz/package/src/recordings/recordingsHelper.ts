import { EventType, VcsEvent } from '@vcmap/core';
import { ToolboxType, VcsUiApp } from '@vcmap/ui';
import { PanoramaViewer } from '@cyclomedia/streetsmart-api';
import { name } from '../../package.json';
import RecordingInteractions from './recordingInteractions.js';

type RecordingClickSession = { stop: () => void; stopped: VcsEvent<void> };

function createRecordingClickSession(
  app: VcsUiApp,
  panoramaViewer: PanoramaViewer,
  layerNames: string[],
): RecordingClickSession {
  const { eventHandler } = app.maps;

  let stop: () => void;
  const interaction = new RecordingInteractions({
    panoramaViewer,
    layerNames,
  });
  const listener = eventHandler.addExclusiveInteraction(interaction, () => {
    stop?.();
  });
  const currentFeatureInteractionEvent = eventHandler.featureInteraction.active;
  eventHandler.featureInteraction.setActive(EventType.CLICK);

  const stopped: VcsEvent<void> = new VcsEvent();
  stop = (): void => {
    listener();
    interaction.destroy();
    eventHandler.featureInteraction.setActive(currentFeatureInteractionEvent);
    stopped.raiseEvent();
    stopped.destroy();
  };

  return {
    stopped,
    stop,
  };
}

// eslint-disable-next-line import/prefer-default-export
export function setupFeatureInfoTool(
  app: VcsUiApp,
  panoramaViewer: PanoramaViewer,
  layerNames: string[],
): () => void {
  let session: RecordingClickSession | null = null;

  const action = {
    name: 'featureInfoToggle',
    title: 'cyclomedia.activateToolTitle',
    icon: 'mdi-cursor-default-click',
    active: false,
    callback(): void {
      if (session) {
        session.stop();
      } else {
        session = createRecordingClickSession(app, panoramaViewer, layerNames);
        session.stopped.addEventListener(() => {
          this.active = false;
          session = null;
          app.featureInfo.clear();
          this.title = 'cyclomedia.activateToolTitle';
        });
        this.active = true;
        this.title = 'cyclomedia.deactivateToolTitle';
      }
    },
  };

  action.callback();

  const id = `${name}-tool`;

  app.toolboxManager.add(
    {
      id,
      type: ToolboxType.SINGLE,
      action,
    },
    name,
  );

  return (): void => {
    if (session) {
      session.stop();
    }
    app.toolboxManager.remove(id);
  };
}

export function getTileProviderURL(
  recordingsBaseUrl: string,
  year?: number,
): string {
  const url = `${recordingsBaseUrl}service=WFS&version=1.1.0&request=GetFeature&typeName=atlas:Recording&srsName=EPSG:3857&bbox={minx},{miny},{maxx},{maxy},urn:ogc:def:crs:EPSG:4326&outputFormat=application/json`;
  if (year) {
    return `${url}&Filter=<Filter><PropertyIsEqualTo><PropertyName>year</PropertyName><Literal>${year}</Literal></PropertyIsEqualTo></Filter>`;
  }
  return url;
}
