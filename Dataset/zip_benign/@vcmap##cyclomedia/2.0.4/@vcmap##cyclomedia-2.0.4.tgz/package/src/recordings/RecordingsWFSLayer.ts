import {
  mercatorProjection,
  ObliqueImage,
  ObliqueMap,
  Projection,
  requestUrl,
  VcsMap,
  VectorLayer,
  type WFSOptions,
} from '@vcmap/core';
import { getLogger } from '@vcsuite/logger';
import WFSFormat from 'ol/format/WFS.js';
import { and, bbox, isNull } from 'ol/format/filter';
import { Feature } from 'ol';
import LRUCache from 'ol/structs/LRUCache';
import { Geometry } from 'ol/geom';
import { getInitForUrl } from '@vcmap/core/dist/src/util/fetch';
import { name } from '../../package.json';

class RecordingsWFSLayer extends VectorLayer {
  static get className(): string {
    return 'RecordingsWFSLayer';
  }

  featureType: string[];

  featureNS: string;

  featurePrefix: string;

  version: string | undefined;

  wfsFormat: WFSFormat;

  cache: LRUCache<Feature<Geometry>[]> = new LRUCache();

  private _activeObliqueMaps: Set<ObliqueMap>;

  private _imageChangedListeners: Map<ObliqueMap, () => void>;

  static getDefaultOptions(): WFSOptions {
    return {
      ...VectorLayer.getDefaultOptions(),
      featureType: [],
      featureNS: '',
      featurePrefix: '',
      version: undefined,
    };
  }

  constructor(options: WFSOptions) {
    const proj = new Projection(options.projection).toJSON();
    proj.alias = [
      `http://www.opengis.net/gml/srs/epsg.xml#${
        (proj.epsg as string).match(/\d+/)?.[0] as string
      }`,
    ];
    super({ ...options, projection: proj });

    this.featureType = Array.isArray(options.featureType)
      ? options.featureType
      : [options.featureType];

    this.featureNS = options.featureNS;
    this.featurePrefix = options.featurePrefix;
    this.version = options.version;
    this.wfsFormat = new WFSFormat({
      featureNS: this.featureNS,
      featureType: this.featureType,
      version: this.version,
    });

    this._supportedMaps = [ObliqueMap.className];

    this._activeObliqueMaps = new Set();

    this._imageChangedListeners = new Map();
  }

  async activate(): Promise<void> {
    await super.activate();
    await Promise.all(
      [...this._activeObliqueMaps].map((m) => {
        if (m.currentImage) {
          return this._imageChangedHandler(m, m.currentImage);
        }
        return Promise.resolve();
      }),
    );
  }

  /**
   * Adds features for current image.
   * Fetched feature are cached.
   * @param map
   * @param image
   */
  async _imageChangedHandler(
    map: ObliqueMap,
    image: ObliqueImage,
  ): Promise<void> {
    this.removeAllFeatures();
    if (this.cache.containsKey(image.name)) {
      this.addFeatures(this.cache.get(image.name));
      return Promise.resolve();
    } else if (this.url != null) {
      const extent = map
        .getExtentOfCurrentImage()
        .getCoordinatesInProjection(mercatorProjection);

      const requestDocument = this.wfsFormat.writeGetFeature({
        featureNS: this.featureNS,
        featurePrefix: this.featurePrefix,
        featureTypes: this.featureType,
        srsName: this.projection.epsg,
        filter: and(
          bbox('recordings', extent, 'EPSG:3857'),
          isNull('expiredAt'),
        ),
        resultType: 'results',
      });
      const postData = new XMLSerializer().serializeToString(requestDocument);
      const init = getInitForUrl(this.url, this.headers);
      init.method = 'POST';
      init.body = postData;
      init.headers = {
        ...init.headers,
        ...{
          'Content-Type': 'application/text+xml',
        },
      };

      try {
        const response = await requestUrl(this.url, init);
        const features = this.wfsFormat.readFeatures(await response.text());
        this.addFeatures(features);
        this.cache.set(image.name, features);
      } catch (err) {
        getLogger(name).info(
          `Could not send request for loading layer content (${String(err)})`,
        );
        return Promise.reject(err);
      }
      return Promise.resolve();
    }
    return Promise.reject(new Error('missing url in WFSLayer layer'));
  }

  async mapActivated(map: VcsMap): Promise<void> {
    await super.mapActivated(map);
    if (map instanceof ObliqueMap) {
      this._activeObliqueMaps.add(map);
      this._imageChangedListeners.get(map)?.();
      this._imageChangedListeners.set(
        map,
        map.imageChanged
          ? map.imageChanged?.addEventListener((image) =>
              this._imageChangedHandler(map, image),
            )
          : (): void => {},
      );
    }
  }

  mapDeactivated(map: VcsMap): void {
    super.mapDeactivated(map);
    if (map instanceof ObliqueMap) {
      this._activeObliqueMaps.delete(map);
      this._imageChangedListeners.get(map)?.();
    }
  }

  removedFromMap(map: VcsMap): void {
    super.removedFromMap(map);
    if (map instanceof ObliqueMap) {
      this._activeObliqueMaps.delete(map);
    }
  }

  destroy(): void {
    super.destroy();
    this._activeObliqueMaps.clear();
    this.cache.clear();
    this._imageChangedListeners.forEach((cb) => cb());
  }
}

export default RecordingsWFSLayer;
