import { NotificationType, VcsUiApp } from '@vcmap/ui';
import { getLogger } from '@vcsuite/logger';
import {
  type Coordinate,
  type PanoramaViewer,
  PanoramaViewerEvents,
  StreetSmartApi,
  ViewerEvent,
  ViewerType,
} from '@cyclomedia/streetsmart-api';
import {
  Cartesian3,
  HeadingPitchRange,
  Math as CesiumMath,
  Matrix4,
} from '@vcmap-cesium/engine';
import {
  CesiumMap,
  ObliqueMap,
  URLTemplateTileProvider,
  VcsMap,
  VectorLayer,
  wgs84Projection,
} from '@vcmap/core';
import { CyclomediaPlugin } from './index.js';
import type { CyclomediaConfig } from './defaultOptions.js';
import { synchronizeCameraIcon } from './cameraIconHelper.js';
import { getTileProviderURL } from './recordings/recordingsHelper.js';
import { name } from '../package.json';

export type PanoramaViewerState = {
  longitude: number;
  latitude: number;
  height: number;
  yaw: number;
  pitch: number;
  hFov: number;
};

function getViewerState(
  plugin: CyclomediaPlugin,
  map: VcsMap,
  panoramaViewer: PanoramaViewer,
): PanoramaViewerState | undefined {
  const recording = panoramaViewer.getRecording();
  if (recording) {
    const orientation = panoramaViewer.getOrientation();
    let yaw = CesiumMath.toRadians(orientation.yaw);
    const pitch = CesiumMath.toRadians(orientation.pitch);
    const hFov = CesiumMath.toRadians(orientation.hFov);
    const [longitude, latitude, height] = plugin.projection.transformTo(
      wgs84Projection,
      [...recording.xyz],
    );

    if (map instanceof ObliqueMap && map.currentImage?.viewDirectionAngle) {
      yaw -= Math.PI / 2 - map.currentImage.viewDirectionAngle;
    }

    return {
      longitude,
      latitude,
      height,
      yaw,
      pitch,
      hFov,
    };
  }
  return undefined;
}

async function synchronizeView(
  map: VcsMap,
  config: CyclomediaConfig,
  viewerState: PanoramaViewerState,
): Promise<void> {
  const { longitude, latitude, height, yaw, pitch } = viewerState;

  if (map instanceof CesiumMap) {
    const { camera } = map.getScene()!;
    const hpr = new HeadingPitchRange(yaw, pitch, 5.0);
    const cartPos = Cartesian3.fromDegrees(longitude, latitude);
    camera.lookAt(cartPos, hpr);
    camera.lookAtTransform(Matrix4.IDENTITY);
  }
  const viewpoint = await map.getViewpoint();
  if (viewpoint) {
    viewpoint.groundPosition = [longitude, latitude];
    const { cyclomediaHeightReference, offset } = config.cameraOptions3D!;
    viewpoint.cameraPosition = [
      longitude,
      latitude,
      cyclomediaHeightReference ? height + offset : offset,
    ];
    if (config.startingZoomDistance) {
      viewpoint.distance = config.startingZoomDistance;
    }
    await map.gotoViewpoint(viewpoint);
  }
}

export function setupViewerListener(
  app: VcsUiApp,
  plugin: CyclomediaPlugin,
  panoramaViewer: PanoramaViewer,
  cameraIconLayer: VectorLayer,
): () => void {
  const cb = (): void => {
    const { activeMap } = app.maps;
    if (activeMap) {
      const state = getViewerState(plugin, activeMap, panoramaViewer);
      if (state) {
        synchronizeCameraIcon(
          state,
          panoramaViewer.getViewerColor(),
          cameraIconLayer,
        );
        // eslint-disable-next-line no-void
        void synchronizeView(activeMap, plugin.config, state);
      }
    }
  };

  const setupImageChangedListener = (map: VcsMap | null): (() => void) => {
    let imageChangedListener: (() => void) | undefined = (): void => {};
    if (map && map instanceof ObliqueMap) {
      imageChangedListener = map.imageChanged?.addEventListener(cb);
    }
    return () => imageChangedListener?.();
  };

  const dateCb = (e?: ViewerEvent<{ date: Date }>): void => {
    const year =
      e?.detail?.date?.getFullYear() ?? panoramaViewer.getRecording().year;
    if (app.maps.activeMap instanceof ObliqueMap) {
      const url = new URL(plugin.recordingsWFSLayer.url);
      url.searchParams.set(
        'Filter',
        `<Filter><PropertyIsEqualTo><PropertyName>year</PropertyName><Literal>${year}</Literal></PropertyIsEqualTo></Filter>`,
      );
      plugin.recordingsWFSLayer.url = url.toString();
      plugin.recordingsWFSLayer.reload().catch((err) => {
        getLogger(name).error('Error while reloading records', err);
      });
    } else {
      plugin.recordingsTileLayer.tileProvider.clearCache().catch((err) => {
        getLogger(name).error('Error while clearing records cache', err);
      });
      (plugin.recordingsTileLayer.tileProvider as URLTemplateTileProvider).url =
        getTileProviderURL(plugin.config.recordingsBaseUrl!, year);
      plugin.recordingsTileLayer.reload().catch((err) => {
        getLogger(name).error('Error while reloading records', err);
      });
    }
  };
  dateCb();

  panoramaViewer.on(PanoramaViewerEvents.VIEW_CHANGE, cb);
  panoramaViewer.on(PanoramaViewerEvents.IMAGE_CHANGE, cb);
  panoramaViewer.on(PanoramaViewerEvents.TIME_TRAVEL_CHANGE, dateCb);
  let imageChangedListener = setupImageChangedListener(app.maps.activeMap);
  const mapActivatedListener = app.maps.mapActivated.addEventListener((map) => {
    cb();
    dateCb();
    imageChangedListener();
    imageChangedListener = setupImageChangedListener(map);
  });

  return (): void => {
    panoramaViewer.off(PanoramaViewerEvents.VIEW_CHANGE, cb);
    panoramaViewer.off(PanoramaViewerEvents.IMAGE_CHANGE, cb);
    panoramaViewer.off(PanoramaViewerEvents.TIME_TRAVEL_CHANGE, dateCb);
    mapActivatedListener();
    imageChangedListener();
  };
}

export async function openViewer(
  app: VcsUiApp,
  imageOrCoordinate: string | Coordinate,
  srs: string,
): Promise<PanoramaViewer | null> {
  try {
    const viewers = await StreetSmartApi.open(imageOrCoordinate, {
      viewerType: ViewerType.PANORAMA,
      srs,
      panoramaViewer: { closable: false },
    });

    return viewers[0] as PanoramaViewer;
  } catch (e) {
    app.notifier.add({
      type: NotificationType.ERROR,
      title: 'cyclomedia.error.openViewer',
      message: String((e as Error).message),
    });
  }
  return null;
}

export async function closeViewer(
  panoramaViewer: PanoramaViewer | undefined,
): Promise<void> {
  if (panoramaViewer) {
    await StreetSmartApi.closeViewer(panoramaViewer.getId());
  }
}
