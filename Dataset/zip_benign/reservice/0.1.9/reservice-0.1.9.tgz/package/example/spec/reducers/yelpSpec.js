import { yelpSearch, yelpBusiness } from '../../src/actions/yelp'
import reducer from '../../src/reducers/yelp'

describe('src/reducers/yelp', () => {
  const oState = {
    foo: 'bar',
    yelp: {
      search: [],
      business: {}
    }
  }

  describe('reducer()', () => {
    it('should skip start service action', () => expect(reducer(oState, yelpSearch())).toEqual(oState))
  })
})
