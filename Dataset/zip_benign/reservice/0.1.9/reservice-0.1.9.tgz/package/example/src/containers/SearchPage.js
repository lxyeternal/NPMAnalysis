import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

import { yelpSearch } from '../actions/yelp'

import YelpSearchList from '../components/YelpSearchList'
import YelpSearch from '../components/YelpSearch'

const mapStateToProps = state => ({
  search: state.yelp.search,
  query: state.routing.route.query,
  loading: state.pageStatus.isLoading
})

const mapDispatchToProps = dispatch => ({
  onSubmit: term => dispatch(yelpSearch({ term }))
})

const SearchPage = ({ search, query, loading, onSubmit }) => <div>
  <YelpSearch query={query} onSubmit={onSubmit} />
  {loading ? <div className='loading'>Now loading...</div> : <YelpSearchList search={search} />}
</div>

SearchPage.propTypes = {
  onSubmit: PropTypes.func.isRequired,
  query: PropTypes.object.isRequired,
  search: PropTypes.object.isRequired,
  loading: PropTypes.bool.isRequired
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchPage)
