import React from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

import YelpBusiness from '../components/YelpBusiness'

const mapStateToProps = state => ({
  business: state.yelp.business
})

const BusinessPage = ({ business }) => <div>
  <a className='home' href='/'>Back to Home</a>
  <YelpBusiness business={business} />
</div>

BusinessPage.propTypes = {
  business: PropTypes.object.isRequired
}

export default connect(mapStateToProps)(BusinessPage)
