'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMiddlewareByServiceList = exports.prodSelect = exports.devSelect = exports.serviceMiddleware = exports.settleRequest = exports.setupServiceEndpoint = exports.isService = exports.isBadService = exports.resetServiceList = exports.ReserviceError = exports.createService = exports.ACTION_SET_REQUEST = exports.STATE_END = exports.STATE_BEGIN = exports.STATE_CREATED = exports.ACTION_TYPE_RESERVICE = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _reduxActions = require('redux-actions');

var _yfetch = require('yfetch');

var _yfetch2 = _interopRequireDefault(_yfetch);

var _debug = require('debug');

var _debug2 = _interopRequireDefault(_debug);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _extendableBuiltin(cls) {
  function ExtendableBuiltin() {
    var instance = Reflect.construct(cls, Array.from(arguments));
    Object.setPrototypeOf(instance, Object.getPrototypeOf(this));
    return instance;
  }

  ExtendableBuiltin.prototype = Object.create(cls.prototype, {
    constructor: {
      value: cls,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });

  if (Object.setPrototypeOf) {
    Object.setPrototypeOf(ExtendableBuiltin, cls);
  } else {
    ExtendableBuiltin.__proto__ = cls;
  }

  return ExtendableBuiltin;
}

var ACTION_TYPE_RESERVICE = exports.ACTION_TYPE_RESERVICE = 'CALL_RESERVICE';
var STATE_CREATED = exports.STATE_CREATED = 'CREATED';
var STATE_BEGIN = exports.STATE_BEGIN = 'BEGIN';
var STATE_END = exports.STATE_END = 'END';
var ACTION_SET_REQUEST = exports.ACTION_SET_REQUEST = 'SERVICE_SET_REQUEST';

var DEFAULT_TRANSPORT_PATH = '/_reservice_/';
var DEFAULT_TRANSPORT_METHOD = 'PUT';
var SERVICE_TRANSPORT_PATH = DEFAULT_TRANSPORT_PATH;
var SERVICE_TRANSPORT_METHOD = DEFAULT_TRANSPORT_METHOD;

var SERVICE_LIST = 0;
var SELECTOR_LIST = {};

var debugStart = (0, _debug2.default)('reservice:start');
var debugReceive = (0, _debug2.default)('reservice:receive');
var debugSuccess = (0, _debug2.default)('reservice:success');
var debugSelect = (0, _debug2.default)('reservice:select');
var debugFail = (0, _debug2.default)('reservice:fail');
var debugError = (0, _debug2.default)('reservice:error');

// A helper function to help you to create actionCreator for a service
var createService = exports.createService = function createService() {
  for (var _len = arguments.length, options = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    options[_key - 1] = arguments[_key];
  }

  var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  var actionCreator = void 0;
  var name = params;
  var start = void 0;

  if (typeof params === 'string') {
    actionCreator = _reduxActions.createAction.apply(undefined, [ACTION_TYPE_RESERVICE].concat(options));
  } else {
    name = params.endType;
    start = params.startType;
    var payloadCreator = params.payloadCreator,
        metaCreator = params.metaCreator;

    actionCreator = (0, _reduxActions.createAction)(ACTION_TYPE_RESERVICE, payloadCreator, metaCreator);
  }

  var serviceCreator = function serviceCreator() {
    var action = actionCreator.apply(undefined, arguments);
    action.reservice = {
      name: name,
      start: start,
      state: STATE_CREATED
    };
    return action;
  };

  serviceCreator.toString = function () {
    return name;
  };

  return serviceCreator;
};

var ReserviceError = exports.ReserviceError = function (_extendableBuiltin2) {
  _inherits(ReserviceError, _extendableBuiltin2);

  function ReserviceError(message, action) {
    _classCallCheck(this, ReserviceError);

    var _this = _possibleConstructorReturn(this, (ReserviceError.__proto__ || Object.getPrototypeOf(ReserviceError)).call(this, message));

    if (action) {
      _this.action = action;
    }
    return _this;
  }

  return ReserviceError;
}(_extendableBuiltin(Error));

var resetServiceList = exports.resetServiceList = function resetServiceList() {
  if (global.window) {
    throw new ReserviceError('resetServiceList() should not be called at client side!');
  }

  if (process.env.NODE_ENV !== 'test') {
    /* eslint no-console: 0 */
    console.warn('resetServiceList() should only be called for testing but current NODE_ENV is "' + process.env.NODE_ENV + '"');
  }

  SERVICE_LIST = 0;
  Object.keys(SELECTOR_LIST).forEach(function (name) {
    return delete SELECTOR_LIST[name];
  });
};

var resultAction = function resultAction(action, payload) {
  var error = payload instanceof Error;
  var type = action.type,
      _action$reservice = action.reservice,
      reservice = _action$reservice === undefined ? {} : _action$reservice,
      meta = action.meta;

  var name = reservice.name || type;
  var ret = {
    type: name,
    reservice: _extends({}, reservice, {
      previous_action: action,
      state: STATE_END
    }),
    meta: meta,
    payload: payload,
    error: error
  };

  if (error) {
    debugFail('name: %s - payload: %o - error: %s', name, action.payload, payload);
    debugError('name: %s - payload: %o - stack: %s', name, action.payload, payload.stack);
  } else {
    debugSuccess('name: %s - payload: %o - result: %o', name, action.payload, payload);
    var selector = SELECTOR_LIST[name];
    if (selector) {
      ret.reservice.full_result = payload;
      ret.payload = selector(payload);
      debugSelect('name: %s - payload: %o - result: %o', name, action.payload, ret.payload);
    }
  }

  return ret;
};

var toErrorAction = function toErrorAction(action, message) {
  return resultAction(action, new ReserviceError(message, action));
};

// validate the format of service action, return an error action when it is invalid
var isBadService = exports.isBadService = function isBadService(action) {
  if (!action.reservice) {
    return toErrorAction(action, 'no action.reservice');
  }
  if (!action.reservice.name) {
    return toErrorAction(action, 'no action.reservice.name');
  }
  if (!action.reservice.state) {
    return toErrorAction(action, 'no action.reservice.state');
  }
  return false;
};

// check an action is service action or not, may return FSA error action if you like
var isService = exports.isService = function isService() {
  var action = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var returnErrorAction = arguments[1];

  if (!action.reservice && action.type !== ACTION_TYPE_RESERVICE) {
    return false;
  }

  var isBad = isBadService(action);
  if (isBad) {
    return returnErrorAction ? isBad : null;
  }

  return true;
};

var handleServiceResult = function handleServiceResult(store, next, action) {
  return function (result) {
    return store.dispatch(resultAction(action, result));
  };
};

var executeServiceAtServer = function executeServiceAtServer(action, request) {
  // service definition check
  var serviceName = action.reservice.name;
  var service = SERVICE_LIST[serviceName];

  if (!service) {
    return Promise.reject(new ReserviceError('can not find service named as "' + serviceName + '" in serviceList', action));
  }

  try {
    action.reservice.state = STATE_BEGIN;
    return Promise.resolve(service(action.payload, request));
  } catch (E) {
    return Promise.reject(E);
  }
};

var serializeError = function serializeError(key, value) {
  return value instanceof Error ? Object.getOwnPropertyNames(value).reduce(function (O, K) {
    if (process.env.NODE_ENV === 'development' || K !== 'stack') {
      O[K] = value[K];
    }
    return O;
  }, {}) : value;
};

var convertError = function convertError(err) {
  var E = err.action ? new ReserviceError(err.message, err.action) : new Error(err.message);

  delete err.action;
  delete err.message;
  Object.assign(E, err);

  return E;
};

var transportServiceToServer = function transportServiceToServer(action) {
  return (0, _yfetch2.default)({
    json: true,
    method: SERVICE_TRANSPORT_METHOD,
    url: SERVICE_TRANSPORT_PATH,
    credentials: 'include',
    body: JSON.stringify(action)
  }).then(function (response) {
    var act = response.body;
    if (act.error) {
      act.payload = convertError(act.payload);
    }
    return act;
  });
};

var setupServiceEndpoint = exports.setupServiceEndpoint = function setupServiceEndpoint(url) {
  var method = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : DEFAULT_TRANSPORT_METHOD;

  if (SERVICE_LIST) {
    throw new ReserviceError('Wrong setupServiceEndpoint() ! You should to it before serviceMiddleware(serviceList) !');
  }
  SERVICE_TRANSPORT_PATH = url;
  SERVICE_TRANSPORT_METHOD = method;
};

var settleRequest = exports.settleRequest = function settleRequest(req) {
  return {
    type: ACTION_SET_REQUEST,
    payload: req
  };
};

// A redux middleware
var serviceMiddleware = exports.serviceMiddleware = function serviceMiddleware(store) {
  return function (next) {
    return function (action) {
      if (action.type === ACTION_SET_REQUEST) {
        if (store.req) {
          throw new ReserviceError('Try to dispatch settleRequest(req) twice!');
        }
        store.req = action.payload;
      }
      var srv = isService(action, true);

      if (!srv) {
        return next(action);
      }

      // action format error handling, return promise.
      if (srv.error) {
        return Promise.resolve(next(srv));
      }

      var result = next(action);

      // just pass to next when the service is already done
      if (action.reservice.previous_action) {
        return result;
      }

      debugStart('name: %s - payload: %o', action.reservice.name, action.payload);
      if (action.reservice.start) {
        store.dispatch(_extends({}, action, {
          reservice: _extends({}, action.reservice, {
            previous_action: action
          }),
          type: action.reservice.start
        }));
      }

      var handle = handleServiceResult(store, next, action);

      // When no SERVICE_LIST, go client logic
      if (!SERVICE_LIST) {
        if (!global.window) {
          throw new ReserviceError('Wrong serviceMiddleware() at server side! You should create service middleware by serviceMiddleware(serviceList) !');
        }
        return transportServiceToServer(action).then(function (res) {
          return store.dispatch(res);
        }, handle);
      }

      return executeServiceAtServer(action, store.req || new ReserviceError('Access request without dispatching settleRequest(req) action!')).then(handle, handle);
    };
  };
};

var responseServiceResult = function responseServiceResult(res, action) {
  return function (result) {
    return res.send(JSON.stringify(resultAction(action, result), serializeError));
  };
};

var devSelect = exports.devSelect = function devSelect(selector) {
  return function (result) {
    return process.env.NODE_ENV === 'development' ? selector(result) : result;
  };
};
var prodSelect = exports.prodSelect = function prodSelect(selector) {
  return function (result) {
    return process.env.NODE_ENV === 'production' ? selector(result) : result;
  };
};

var refineServiceList = function refineServiceList(serviceList) {
  var services = {};

  Object.keys(serviceList).forEach(function (name) {
    var service = serviceList[name];

    if (typeof service === 'function') {
      services[name] = service;
      return;
    }

    if (!service.service || !service.selector) {
      throw new ReserviceError('The service named as "' + name + '" in serviceList should be a function or { service, selector }, it is ' + service + ' now');
    }

    if (typeof service.service !== 'function') {
      throw new ReserviceError('The service named as "' + name + '" in serviceList defined as { service, selector }, but the { service } is not a function, it is ' + service.service + ' now');
    }

    if (typeof service.selector !== 'function') {
      throw new ReserviceError('The service named as "' + name + '" in serviceList defined as { service, selector }, but the { selector } is not a function, it is ' + service.selector + ' now');
    }

    if (process.env.NODE_ENV === 'production') {
      services[name] = function (payload, req) {
        return Promise.resolve(service.service(payload, req)).then(service.selector);
      };
    } else {
      services[name] = service.service;
      SELECTOR_LIST[name] = service.selector;
    }
  });

  return services;
};

// create an express middleware to handle service action from client side
var createMiddlewareByServiceList = exports.createMiddlewareByServiceList = function createMiddlewareByServiceList(serviceList) {
  // no serviceList error
  if (!serviceList) {
    throw new ReserviceError('No serviceList for service middleware! Check the serviceList in your createMiddlewareByServiceList(serviceList)');
  }

  // double executed error
  if (SERVICE_LIST) {
    throw new ReserviceError('createMiddlewareByServiceList() should be executed once only!');
  }

  if (global.window) {
    throw new ReserviceError('createMiddlewareByServiceList() should not be executed at client side!');
  }

  SERVICE_LIST = refineServiceList(serviceList);

  return function (req, res, next) {
    // method or url different, pass
    if (req.originalUrl !== SERVICE_TRANSPORT_PATH || req.method !== SERVICE_TRANSPORT_METHOD) {
      return next();
    }

    // no body, pass
    var action = req.body;
    if (!action) {
      return next();
    }

    // not a service action, pass
    var srv = isService(action, true);
    if (!srv) {
      return next();
    }

    // not a valid service action, error
    if (srv.error) {
      return next(srv.payload);
    }

    debugReceive('name: %s - payload: %o', action.reservice.name, action.payload);

    // no matter success or failed, response result to client.
    var handle = responseServiceResult(res, action);
    return executeServiceAtServer(action, req).then(handle, handle);
  };
};
