var path = require("path"),
    webpack = require("webpack"),
    LodashModuleReplacementPlugin = require('lodash-webpack-plugin');

module.exports = {
    entry: ["./src/index.js"],
    devtool: "source-map",
    resolve: {
      extensions: [ ".js", ],
      modules: [ "node_modules" ],
    },
    output: {
       path: path.join(__dirname, "dist"),
       filename: "questlib.js",
       library: "questlib",
       libraryTarget: 'umd',
       umdNamedDefine: true,
    },
    module: {
      rules: [
        {
          test: /\.js$/,
          exclude: /node_modules/,
          loader: "babel-loader",
          options: {
            plugins: ['lodash'],
            presets: ["@babel/preset-env"],
            sourceType: "unambiguous",
          },
        },
      ],
    },
    plugins: [
      new webpack.optimize.LimitChunkCountPlugin({
          maxChunks: 1, // disable creating additional chunks
      }),
      new LodashModuleReplacementPlugin
    ],
};
