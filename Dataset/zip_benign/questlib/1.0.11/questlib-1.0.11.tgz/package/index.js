module.exports = require('./dist/questlib.js');
