# QuestLib
Javascript implementation of Quest
http://psychtoolbox.org/docs/Quest

## Usage
### Single staircase
```
var questlib = require('questlib');

const tGuess = 0.5,
      tGuessSd = 0.1,
      pThreshold = 0.75,
      beta = 3.5,
      delta = 0.01,
      gamma = 0.01,
      grain = 0.001,
      range = 20;
      
const q = new questlib.Quest(tGuess, tGuessSd, pThreshold, beta, delta, gamma, grain, range);

...

const tTest = q.quantile();
q.update(tTest, response);

...

const analysis = q.betaAnalysis();
```

### Double staircases
```
var questlib = require('questlib');

const tGuess = 0.5,
      tGuessSd = 0.1,
      pThreshold = 0.75,
      beta = 3.5,
      delta = 0.01,
      gamma = 0.01,
      grain = 0.001,
      range = 20;
      
const q1 = new questlib.Quest(tGuess + 0.1, tGuessSd, pThreshold, beta, delta, gamma, grain, range);
const q2 = new questlib.Quest(tGuess - 0.1, tGuessSd, pThreshold, beta, delta, gamma, grain, range);

...

const tTest = q1.quantile();
q1.update(tTest, response);

const tTest2 = q2.quantile();
q2.update(tTest2, response2);

...

const intensities = questlib.ProcessQuestData(q1, q2).intensities;
const c25 = intensities.c25;
```
