function myFunction()
{
    alert("This is a facial skincar devices");
}