# 🚀 @mgcloud/lib-utils

该库为项目提供了便捷的方法工具封装，方便开发人员进行各种操作。

## 功能模块

- **check**: 类型检查相关函数
- **color**: 包含了颜色相关的函数，用于在终端中添加样式和色彩
- **currency**: 提供货币格式化及计算相关功能
- **helpers**: 常用辅助函数集合
  - device-id: 设备 ID 相关操作 (used monitor uin field)
  - platform: 平台判断和处理
  - time-utils: 时间日期处理工具
- **number-precision**: 解决 JavaScript 数字精度问题的相关函数
- **token**: 提供了处理令牌和身份验证相关的功能
- **validate**: 包含了数据验证的工具函数，用于确保数据的合法性和正确性

## 安装

```bash
pnpm install @mgcloud/lib-utils
```

## 使用示例

```typescript
// 检查是否为 HTTP 链接
import { isHttp_RY } from '@mgcloud/lib-utils'
const result = isHttp_RY('https://example.com') // true

// 数字精度计算
import { plus } from '@mgcloud/lib-utils'
const sum = plus(0.1, 0.2) // 0.3

// 货币格式化
import { formatCurrency } from '@mgcloud/lib-utils'
const price = formatCurrency(1234.56) // ¥1,234.56
```
