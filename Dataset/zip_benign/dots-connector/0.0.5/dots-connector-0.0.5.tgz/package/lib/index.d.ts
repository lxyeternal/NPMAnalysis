export default function triangulate(points: number[][]): {
    triangles: Uint32Array;
    points: Float64Array;
};
