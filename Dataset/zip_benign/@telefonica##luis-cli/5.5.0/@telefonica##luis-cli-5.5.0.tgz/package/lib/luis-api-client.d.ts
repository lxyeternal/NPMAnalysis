/// <reference types="node" />
import { EventEmitter } from 'events';
export declare namespace LuisApi {
    interface AppInfoGET {
        id: string;
        name: string;
        description: string;
        culture: string;
    }
    interface IntentGET {
        id: string;
        name: string;
        typeId: number;
        readableType: string;
    }
    interface IntentPOST {
        name: string;
    }
    interface IntentDELETE {
        id: string;
    }
    interface EntityGET {
        id: string;
        name: string;
        typeId: number;
        readableType: string;
    }
    interface EntityPOST {
        name: string;
    }
    interface EntityDELETE {
        id: string;
    }
    interface PhraseListGET {
        id: number;
        name: string;
        isActive: boolean;
        isExchangeable: boolean;
        phrases: string;
    }
    interface PhraseListPOST {
        name: string;
        phrases: string;
        isExchangeable: boolean;
    }
    interface PhraseListDELETE {
        id: string;
    }
    interface EntityLabelExampleGET {
        entityName: string;
        startTokenIndex: number;
        endTokenIndex: number;
    }
    interface EntityLabelExamplePOST {
        entityName: string;
        startCharIndex: number;
        endCharIndex: number;
    }
    interface IntentPrediction {
        name: string;
        score: number;
    }
    interface EntityPrediction {
        entityName: string;
        startIndex: number;
        endIndex: number;
        phrase: string;
    }
    interface ExampleGET {
        id: number;
        text: string;
        tokenizedText: string[];
        intentLabel: string;
        entityLabels: EntityLabelExampleGET[];
        intentPredictions: IntentPrediction[];
        entityPredictions: EntityPrediction[];
    }
    interface ExamplePOST {
        text: string;
        intentName: string;
        entityLabels: EntityLabelExamplePOST[];
    }
    interface ExampleDELETE {
        id: number;
    }
    interface RecognizedIntent {
        intent: string;
        score: number;
    }
    interface RecognizedEntity {
        entity: string;
        type: string;
        startIndex: number;
        endIndex: number;
        score: number;
    }
    interface RecognitionResult {
        query: string;
        topScoringIntent: RecognizedIntent;
        intents: RecognizedIntent[];
        entities: RecognizedEntity[];
    }
    enum TrainingStatuses {
        Success = 0,
        Fail = 1,
        UpToDate = 2,
        InProgress = 3,
    }
    interface ModelTrainingStatus {
        modelId: string;
        status: TrainingStatuses;
        exampleCount: number;
        failureReason?: string;
    }
    type TrainingStatus = ModelTrainingStatus[];
    interface PublishResult {
        endpointUrl: string;
        subscriptionKey: string;
        endpointRegion: string;
        isStaging: boolean;
    }
}
export interface LuisApiClientConfig {
    baseUrl?: string;
    applicationId: string;
    subscriptionKey: string;
    requestsPerSecond?: number;
    timeout?: number;
}
export declare class LuisApiClient extends EventEmitter {
    private config;
    private readonly serviceReq;
    private readonly provisionReq;
    private readonly promiseThrottle;
    constructor(config: LuisApiClientConfig);
    private retryRequest(opts, expectedStatusCode);
    private throttler(fn, appVersion, items);
    private serializer(fn, appVersion, items);
    recognizeSentence(sentence: string): Promise<LuisApi.RecognitionResult>;
    recognizeSentences(queries: string[]): Promise<LuisApi.RecognitionResult[]>;
    getApp(): Promise<LuisApi.AppInfoGET>;
    getIntents(appVersion: string): Promise<LuisApi.IntentGET[]>;
    createIntent(appVersion: string, intent: LuisApi.IntentPOST): Promise<string>;
    createIntents(appVersion: string, intents: LuisApi.IntentPOST[]): Promise<string[]>;
    deleteIntent(appVersion: string, intent: LuisApi.IntentDELETE): Promise<void>;
    deleteIntents(appVersion: string, intents: LuisApi.IntentDELETE[]): Promise<void>;
    getEntities(appVersion: string): Promise<LuisApi.EntityGET[]>;
    createEntity(appVersion: string, entity: LuisApi.EntityPOST): Promise<string>;
    createEntities(appVersion: string, entities: LuisApi.EntityPOST[]): Promise<string[]>;
    deleteEntity(appVersion: string, entity: LuisApi.EntityDELETE): Promise<void>;
    deleteEntities(appVersion: string, entities: LuisApi.EntityDELETE[]): Promise<void>;
    getPhraseLists(appVersion: string): Promise<LuisApi.PhraseListGET[]>;
    createPhraseList(appVersion: string, phraseList: LuisApi.PhraseListPOST): Promise<string>;
    createPhraseLists(appVersion: string, phraseLists: LuisApi.PhraseListPOST[]): Promise<string[]>;
    deletePhraseList(appVersion: string, phraseList: LuisApi.PhraseListDELETE): Promise<void>;
    deletePhraseLists(appVersion: string, phraseLists: LuisApi.PhraseListDELETE[]): Promise<void>;
    getExamples(appVersion: string, skip: number, count: number): Promise<LuisApi.ExampleGET[]>;
    getAllExamples(appVersion: string): Promise<LuisApi.ExampleGET[]>;
    createExamples(appVersion: string, examples: LuisApi.ExamplePOST[]): Promise<{}[]>;
    deleteExample(appVersion: string, example: LuisApi.ExampleDELETE): Promise<void>;
    deleteExamples(appVersion: string, examples: LuisApi.ExampleDELETE[]): Promise<void>;
    private convertTrainingStatus(apiTrainingStatus);
    startTraining(appVersion: string): Promise<LuisApi.TrainingStatus>;
    getTrainingStatus(appVersion: string): Promise<LuisApi.TrainingStatus>;
    publish(appVersion: string, region?: string, isStaging?: boolean): Promise<LuisApi.PublishResult>;
    export(appVersion: string): Promise<any>;
}
