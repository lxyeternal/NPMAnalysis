/// <reference types="node" />
import { EventEmitter } from 'events';
import { LuisApiClientConfig, LuisApi } from './luis-api-client';
import { Luis as LuisModel } from '@telefonica/language-model-converter/lib/luis-model';
export interface UpdateEvent {
    create: number;
    delete: number;
}
export declare type PredictionStats = Map<string, {
    total: number;
    errors: number;
    ambiguities: number;
}>;
export interface PredictionError {
    text: string;
    tokenizedText?: string[];
    intent: string;
    intentPredictions?: LuisApi.IntentPrediction[];
    ambiguousPredictedIntent?: boolean;
    entities?: (LuisApi.EntityLabelExampleGET | LuisApi.EntityLabelExamplePOST)[];
    predictedEntities?: LuisApi.EntityLabelExamplePOST[];
}
export interface PredictionResult {
    stats: PredictionStats;
    errors: PredictionError[];
}
export interface LuisTrainerConfig {
    luisApiClientConfig: LuisApiClientConfig;
}
export declare class LuisTrainer extends EventEmitter {
    private readonly luisApiClient;
    constructor(config: LuisTrainerConfig);
    export(appVersion: string): Promise<LuisModel.Model>;
    update(appVersion: string, model: LuisModel.Model, region?: string, isStaging?: boolean): Promise<void>;
    checkPredictions(appVersion: string): Promise<PredictionResult>;
    testExamples(examples: LuisModel.Utterance[], luisSchemaVersion: string): Promise<PredictionResult>;
    private static wrapError(error, message);
    private checkCulture(appVersion, culture);
    private updateIntents(appVersion, intents);
    private updateEntities(appVersion, entities);
    private updatePhraseLists(appVersion, modelPhraseLists);
    private updateExamples(appVersion, modelExamples, luisSchemaVersion);
    private train(appVersion);
    private publish(appVersion, region?, isStaging?);
    private static splitSentenceByTokens(sentence);
    private static tokenizeSentence(sentence);
    private static findEntity(sentence, startPos, endPos, luisSchemaVersion);
}
