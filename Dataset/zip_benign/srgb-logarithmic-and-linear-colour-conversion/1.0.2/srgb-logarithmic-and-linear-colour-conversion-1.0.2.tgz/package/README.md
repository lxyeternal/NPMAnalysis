# Why

Because sRGB values are logarithmic they must first be converted to raw linear colour data between before any transformative calculations are done.

_You should never transform logarithmic sRGB colour values! Ps if its 0-255 it ain't linear_

The following blog post is required reading before working on colour or image processing.
http://blog.johnnovak.net/2016/09/21/what-every-coder-should-know-about-gamma/

sRGB/linear conversions from http://entropymine.com/imageworsener/srgbformula/

# Useage

This library exports two functions `logToLin` and `linToLog` for converting colour values between logarithmic and linear.

## logToLin

This function accepts an integer between 0 and 255, it then returns a float between 0 and 1.
188 is the actual half brightness value in logarithmic sRGB.
`logToLin(188) // 0.5028864580325687`

## linToLog

This function accepts an float between 0 and 1, it then returns a integer between 0 and 1.
`linToLog(0.5) // 188`

