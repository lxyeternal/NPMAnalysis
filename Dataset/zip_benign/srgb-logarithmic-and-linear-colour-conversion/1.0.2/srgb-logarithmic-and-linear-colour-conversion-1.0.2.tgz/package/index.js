module.exports = {
  logToLin: function(log) {
    log = log / 255
    return log <= 0.0404482362771082 ? log / 12.92 : Math.pow((log + 0.055) / 1.055, 2.4)
  },
  linToLog: function(lin) {
    var log = lin <= 0.00313066844250063 ? lin * 12.92 : 1.055 * Math.pow(lin, 1 / 2.4) - 0.055
    return Math.round(log * 255)
  }
}
