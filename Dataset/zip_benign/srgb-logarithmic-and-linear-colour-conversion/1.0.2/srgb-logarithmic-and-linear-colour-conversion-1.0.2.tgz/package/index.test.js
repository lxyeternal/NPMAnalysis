var logToLin = require('./index').logToLin
var linToLog = require('./index').linToLog

// Max Conversion
test('logToLin 255 equals 1', function() {
  expect(logToLin(255)).toBe(1)
})

test('linToLog 1 equals 255', function() {
  expect(linToLog(1)).toBe(255)
})

// Min Conversion
test('logToLin 0 equals 0', function() {
  expect(logToLin(0)).toBe(0)
})

test('linToLog 0 equals 0', function() {
  expect(linToLog(0)).toBe(0)
})

// Mid Conversion
test('logToLin 127 equals 0.21223075741405523', function() {
  expect(logToLin(127)).toBe(0.21223075741405523)
})

test('linToLog 0.21223075741405523 equals 127', function() {
  expect(linToLog(0.21223075741405523)).toBe(127)
})

// Second Mid Conversion
test('logToLin 188 equals 0.5028864580325687', function() {
  expect(logToLin(188)).toBe(0.5028864580325687)
})

test('linToLog 0.5 equals 188', function() {
  expect(linToLog(0.5)).toBe(188)
})

// Double Mid Conversion
test('logToLin->linToLog 127 equals 127', function() {
  expect(linToLog(logToLin(127))).toBe(127)
})

test('linToLog->logToLin 0.21223075741405523 equals 0.21223075741405523', function() {
  expect(logToLin(linToLog(0.21223075741405523))).toBe(0.21223075741405523)
})
