require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "react-native-xinge-push"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.description  = <<-DESC
                  react-native-xinge-push
                   DESC
  s.homepage     = "https://github.com/Jeepeng/react-native-xinge-push"
  s.license      = "MIT"
  # s.license    = { :type => "Apache License 2.0", :file => "FILE_LICENSE" }
  s.authors      = { "Jeepeng" => "jeepeng@jeepeng.com" }
  s.platforms    = { :ios => "9.0" }
  s.source       = { :git => "https://github.com/Jeepeng/react-native-xinge-push.git", :tag => "#{s.version}" }

  s.source_files = "ios/**/*.{h,m,swift}"
  s.requires_arc = true

  s.frameworks = "CoreTelephony", "SystemConfiguration", "UserNotifications"
  s.libraries =  "sqlite3.0", "z"
  s.dependency "React"
  # s.dependency "..."
  s.ios.vendored_library = "ios/SDK/libXG-SDK.a"
end

