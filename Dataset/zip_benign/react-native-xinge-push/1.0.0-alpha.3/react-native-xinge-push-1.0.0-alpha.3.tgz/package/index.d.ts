declare module "react-native-xinge-push" {
  export interface RNXingePush {
    init(accessId: number, accessKey: string): void;
    register(account: string): Promise<any>;
    unRegister(): void;
    addEventListener(eventType: string, callback: Function): void;
    removeEventListener(eventType: string, callback: Function): void;
    enableOtherPush(enable: boolean) : void;
    initXiaomi(appId: string, appKey: string): void;
    initMeizu(appId: string, appKey: string): void;
    setApplicationIconBadgeNumber(number: number): void;
    getApplicationIconBadgeNumber(account: string): Function;
    enableDebug(isDebug: boolean) : void;
  }
  const RNXingePush: RNXingePush;

  export default RNXingePush;
}
