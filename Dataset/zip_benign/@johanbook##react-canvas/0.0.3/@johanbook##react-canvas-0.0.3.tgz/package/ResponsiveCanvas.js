"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ResponsiveCanvas;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime/helpers/slicedToArray"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _propTypes = _interopRequireDefault(require("prop-types"));

var _Canvas = _interopRequireWildcard(require("./Canvas"));

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/** A responsive wrapper around `<Canvas/>` */
function ResponsiveCanvas(_ref) {
  var children = _ref.children,
      className = _ref.className,
      overlay = _ref.overlay,
      style = _ref.style,
      props = (0, _objectWithoutProperties2.default)(_ref, ["children", "className", "overlay", "style"]);
  var classes = {};
  var ref = (0, _react.useRef)();

  var _useState = (0, _react.useState)(0),
      _useState2 = (0, _slicedToArray2.default)(_useState, 2),
      height = _useState2[0],
      setHeight = _useState2[1];

  var _useState3 = (0, _react.useState)(0),
      _useState4 = (0, _slicedToArray2.default)(_useState3, 2),
      width = _useState4[0],
      setWidth = _useState4[1];

  (0, _react.useEffect)(function () {
    setHeight(ref.current.offsetHeight);
    setWidth(ref.current.offsetWidth);
  }, [setWidth]);
  var canvasStyle = {};

  if (overlay === undefined) {
    overlay = Boolean(children);
  }

  if (overlay) {
    canvasStyle.position = "absolute";
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    className: className,
    ref: ref,
    style: _objectSpread({
      height: "100%",
      width: "100%"
    }, style)
  }, /*#__PURE__*/_react.default.createElement(_Canvas.default, (0, _extends2.default)({
    height: height,
    width: width,
    style: canvasStyle
  }, props)), /*#__PURE__*/_react.default.createElement("div", {
    className: classes.children
  }, children));
}

ResponsiveCanvas.propypes = _objectSpread(_objectSpread({}, _Canvas.propTypes), {}, {
  /** If children should overlay canvas */
  overlay: _propTypes.default.bool
});