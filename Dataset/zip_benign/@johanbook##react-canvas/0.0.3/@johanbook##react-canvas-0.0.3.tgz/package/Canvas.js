"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Canvas;
exports.propTypes = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _propTypes = _interopRequireDefault(require("prop-types"));

var _renderer = _interopRequireDefault(require("./renderer"));

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0, _defineProperty2.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

var defaultRenderOptions = {
  clearOnUpdate: true,
  defaultColor: "rgb(150,150,150,0.8)",
  fps: 24,
  transform: null,
  virtualHeight: 1,
  virtualWidth: 1
};
/** A Canvas with simplified rendering functions */

function Canvas(_ref) {
  var items = _ref.items,
      height = _ref.height,
      _ref$onUpdate = _ref.onUpdate,
      onUpdate = _ref$onUpdate === void 0 ? function () {} : _ref$onUpdate,
      _ref$onUpdateItem = _ref.onUpdateItem,
      onUpdateItem = _ref$onUpdateItem === void 0 ? function () {} : _ref$onUpdateItem,
      _ref$renderOptions = _ref.renderOptions,
      renderOptions = _ref$renderOptions === void 0 ? {} : _ref$renderOptions,
      style = _ref.style,
      width = _ref.width,
      props = (0, _objectWithoutProperties2.default)(_ref, ["items", "height", "onUpdate", "onUpdateItem", "renderOptions", "style", "width"]);
  var canvas = (0, _react.useRef)();

  var _renderOptions = _objectSpread(_objectSpread({}, defaultRenderOptions), renderOptions);

  (0, _react.useEffect)(function () {
    // Do not create renderer if sizing is not complete
    if (canvas.current.offsetWidth === 0) {
      return;
    }

    var renderer = new _renderer.default(canvas.current);
    var timer = setInterval(function () {
      renderer.render(items, _objectSpread(_objectSpread({}, _renderOptions), {}, {
        onUpdate: onUpdate,
        onUpdateItem: onUpdateItem
      }));
    }, 1000 / renderOptions.fps);
    return function () {
      return clearInterval(timer);
    };
  });
  return /*#__PURE__*/_react.default.createElement("canvas", (0, _extends2.default)({
    ref: canvas,
    height: height,
    width: width,
    style: _objectSpread({
      zIndex: -1
    }, style)
  }, props));
}

var propTypes = {
  /** Rendered items */
  items: _propTypes.default.arrayOf(_propTypes.default.exact({
    /** Particle color */
    color: _propTypes.default.string,

    /** Particle size. Default 1 */
    size: _propTypes.default.number,

    /** Particle x position */
    x: _propTypes.default.number.isRequired,

    /** Particle y position */
    y: _propTypes.default.number.isRequired
  })).isRequired,

  /** Height of canvas */
  height: _propTypes.default.number.isRequired,

  /** Custom rendering options */
  renderOptions: _propTypes.default.shape({
    /** If canvas should be cleared in between
     * updates. Default `True` */
    clearOnUpdate: _propTypes.default.bool,

    /** Default item color */
    defaultColor: _propTypes.default.string,

    /** Frames per second. Default 24 */
    fps: _propTypes.default.number,

    /** Transform applied to positions */
    transform: _propTypes.default.oneOf([_propTypes.default.string, _propTypes.default.func]),

    /** What unit of the data correspond to a full width. Default 1 */
    virtualWidth: _propTypes.default.number,

    /** What unit of the data correspond to a full height. Default 1 */
    virtualHeight: _propTypes.default.number
  }),

  /** Function called on each rerender */
  onUpdate: _propTypes.default.func,

  /** Function called for each item on each rerender */
  onUpdateItem: _propTypes.default.func,

  /** Width of canvas */
  width: _propTypes.default.number.isRequired
};
exports.propTypes = propTypes;
Canvas.propTypes = propTypes;