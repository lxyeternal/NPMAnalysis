"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createItems = createItems;
exports.createGrid = createGrid;
Object.defineProperty(exports, "Canvas", {
  enumerable: true,
  get: function get() {
    return _Canvas.default;
  }
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _ResponsiveCanvas.default;
  }
});

var _Canvas = _interopRequireDefault(require("./Canvas"));

var _ResponsiveCanvas = _interopRequireDefault(require("./ResponsiveCanvas"));

function createItems(number) {
  var items = [];

  for (var idx = 0; idx < number; idx++) {
    items.push({
      x: idx / number,
      y: 0
    });
  }

  return items;
}
/** Create 2-dimensional grid */


function createGrid(numX, numY) {
  var items = [];

  for (var i = 0; i < numX; i++) {
    for (var j = 0; j < numX; j++) {
      items.push({
        x: i / numX,
        y: j / numY
      });
    }
  }

  return items;
}