"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.radial = radial;

/** Transform polar coordinates to Cartesian ones.
 * NB: Angle uses radians. */
function radial(r, theta) {
  var x = r * Math.cos(theta);
  var y = r * Math.sin(theta);
  return [x / 2 + 0.5, y / 2 + 0.5];
}