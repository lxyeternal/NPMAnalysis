"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime/helpers/toConsumableArray"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime/helpers/classCallCheck"));

var _createClass2 = _interopRequireDefault(require("@babel/runtime/helpers/createClass"));

var transforms = _interopRequireWildcard(require("./transform"));

/** Class that handles all canvas rendering */
var Renderer = /*#__PURE__*/function () {
  function Renderer(canvas) {
    (0, _classCallCheck2.default)(this, Renderer);
    this.canvas = canvas;
    this.t = 0;
  }

  (0, _createClass2.default)(Renderer, [{
    key: "render",
    value: function render(items, options) {
      if (!this.canvas) {
        return;
      }

      this.t += 0.01;
      var height = this.canvas.offsetHeight;
      var width = this.canvas.offsetWidth;
      var context = this.canvas.getContext("2d");
      var xScale = width / options.virtualWidth;
      var yScale = height / options.virtualHeight;

      if (options.clearOnUpdate) {
        context.clearRect(0, 0, this.canvas.width, this.canvas.height);
      }

      var transformFn;

      if (options.transform && options.transform in transforms) {
        transformFn = transforms[options.transform];
      }

      for (var idx in items) {
        var _items$idx = items[idx],
            _items$idx$color = _items$idx.color,
            color = _items$idx$color === void 0 ? options.defaultColor : _items$idx$color,
            _items$idx$size = _items$idx.size,
            size = _items$idx$size === void 0 ? 4 : _items$idx$size,
            x = _items$idx.x,
            y = _items$idx.y;
        var position = [x, y];

        if (transformFn) {
          position = transformFn.apply(void 0, (0, _toConsumableArray2.default)(position));
        }

        context.beginPath();
        context.strokeStyle = color;
        context.rect(xScale * position[0], yScale * position[1], size, size);
        context.stroke();
        options.onUpdateItem(items[idx], this.t);
      }

      options.onUpdate(this.t);
    }
  }]);
  return Renderer;
}();

exports.default = Renderer;