"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var transforms = _interopRequireWildcard(require("./transform"));

describe("transform", function () {
  it("handles radial", function () {
    expect(transforms.radial(1, 0)).toEqual([1, 0.5]);
  });
});