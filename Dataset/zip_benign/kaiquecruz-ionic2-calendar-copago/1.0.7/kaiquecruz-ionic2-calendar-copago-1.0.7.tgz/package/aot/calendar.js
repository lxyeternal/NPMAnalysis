"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var calendar_service_1 = require("./calendar.service");
var Step;
(function (Step) {
    Step[Step["QuarterHour"] = 15] = "QuarterHour";
    Step[Step["HalfHour"] = 30] = "HalfHour";
    Step[Step["Hour"] = 60] = "Hour";
})(Step = exports.Step || (exports.Step = {}));
var CalendarComponent = (function () {
    function CalendarComponent(calendarService, appLocale) {
        this.calendarService = calendarService;
        this.appLocale = appLocale;
        this.eventSource = [];
        this.calendarMode = 'month';
        this.formatDay = 'd';
        this.formatDayHeader = 'EEE';
        this.formatDayTitle = 'MMMM dd, yyyy';
        this.formatWeekTitle = 'MMMM yyyy, Week $n';
        this.formatMonthTitle = 'MMMM yyyy';
        this.formatWeekViewDayHeader = 'EEE d';
        this.formatHourColumn = 'j';
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = 'all day';
        this.noEventsLabel = 'No Events';
        this.queryMode = 'local';
        this.step = Step.Hour;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.spaceBetween = 0;
        this.onCurrentDateChanged = new core_1.EventEmitter();
        this.onRangeChanged = new core_1.EventEmitter();
        this.onEventSelected = new core_1.EventEmitter();
        this.onTimeSelected = new core_1.EventEmitter();
        this.onTitleChanged = new core_1.EventEmitter();
        this.hourParts = 1;
        this.locale = appLocale;
    }
    Object.defineProperty(CalendarComponent.prototype, "currentDate", {
        get: function () {
            return this._currentDate;
        },
        set: function (val) {
            if (!val) {
                val = new Date();
            }
            this._currentDate = val;
            this.calendarService.setCurrentDate(val, true);
            this.onCurrentDateChanged.emit(this._currentDate);
        },
        enumerable: true,
        configurable: true
    });
    CalendarComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.autoSelect) {
            if (this.autoSelect.toString() === 'false') {
                this.autoSelect = false;
            }
            else {
                this.autoSelect = true;
            }
        }
        this.hourParts = 60 / this.step;
        this.startHour = parseInt(this.startHour.toString());
        this.endHour = parseInt(this.endHour.toString());
        this.calendarService.queryMode = this.queryMode;
        this.currentDateChangedFromChildrenSubscription = this.calendarService.currentDateChangedFromChildren$.subscribe(function (currentDate) {
            _this._currentDate = currentDate;
            _this.onCurrentDateChanged.emit(currentDate);
        });
    };
    CalendarComponent.prototype.ngOnDestroy = function () {
        if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
        }
    };
    CalendarComponent.prototype.rangeChanged = function (range) {
        this.onRangeChanged.emit(range);
    };
    CalendarComponent.prototype.eventSelected = function (event) {
        this.onEventSelected.emit(event);
    };
    CalendarComponent.prototype.timeSelected = function (timeSelected) {
        this.onTimeSelected.emit(timeSelected);
    };
    CalendarComponent.prototype.titleChanged = function (title) {
        this.onTitleChanged.emit(title);
    };
    CalendarComponent.prototype.loadEvents = function () {
        this.calendarService.loadEvents();
    };
    return CalendarComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Date),
    __metadata("design:paramtypes", [Date])
], CalendarComponent.prototype, "currentDate", null);
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], CalendarComponent.prototype, "eventSource", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "calendarMode", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatDay", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatDayHeader", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatDayTitle", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatWeekTitle", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatMonthTitle", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatWeekViewDayHeader", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "formatHourColumn", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], CalendarComponent.prototype, "showEventDetail", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "startingDayMonth", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "startingDayWeek", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "allDayLabel", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "noEventsLabel", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "queryMode", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "step", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], CalendarComponent.prototype, "autoSelect", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Function)
], CalendarComponent.prototype, "markDisabled", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "monthviewDisplayEventTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "monthviewEventDetailTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "weekviewAllDayEventTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "weekviewNormalEventTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "dayviewAllDayEventTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "dayviewNormalEventTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", core_1.TemplateRef)
], CalendarComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], CalendarComponent.prototype, "dateFormatter", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "dir", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "scrollToHour", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], CalendarComponent.prototype, "preserveScrollPosition", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], CalendarComponent.prototype, "lockSwipeToPrev", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Boolean)
], CalendarComponent.prototype, "lockSwipes", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], CalendarComponent.prototype, "locale", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "startHour", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "endHour", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], CalendarComponent.prototype, "spaceBetween", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], CalendarComponent.prototype, "onCurrentDateChanged", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], CalendarComponent.prototype, "onRangeChanged", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], CalendarComponent.prototype, "onEventSelected", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], CalendarComponent.prototype, "onTimeSelected", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], CalendarComponent.prototype, "onTitleChanged", void 0);
CalendarComponent = __decorate([
    core_1.Component({
        selector: 'calendar',
        template: "<ng-template #monthviewDefaultDisplayEventTemplate let-view=\"view\" let-row=\"row\" let-col=\"col\">             {{view.dates[row*7+col].label}}         </ng-template>\n    <ng-template #monthviewDefaultEventDetailTemplate let-showEventDetail=\"showEventDetail\" let-selectedDate=\"selectedDate\" let-noEventsLabel=\"noEventsLabel\">\n       <ion-list class=\"event-detail-container\" has-bouncing=\"false\" *ngIf=\"showEventDetail\" overflow-scroll=\"false\">\n       <div class=\"container\">\n          <ul> \n            <ion-item-group>\n            \n            <ion-item *ngFor=\"let event of selectedDate?.events\" tappable  (click)=\"eventSelected(event)\">          \n                <li>\n                <span></span>\n                <div>\n                    <div class=\"title\">{{event.title}}</div>\n                </div> \n                <span class=\"number\">\n                    <span>{{event.startTime|date: 'HH:mm'}} </span>\n                    <span></span>\n                </span>\n                </li>\n            </ion-item>        \n            <ion-item *ngIf=\"selectedDate?.events.length==0\">\n                <div class=\"no-events-label\">{{noEventsLabel}}</div>\n            </ion-item>\n            </ion-item-group>\n        </ul>\n        </div>\n       </ion-list>\n    </ng-template>\n    <ng-template #defaultAllDayEventTemplate let-displayEvent=\"displayEvent\">\n       <div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>\n    </ng-template>\n    <ng-template #defaultNormalEventTemplate let-displayEvent=\"displayEvent\">\n       <div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>\n    </ng-template>\n    <div [ngSwitch]=\"calendarMode\" class=\"{{calendarMode}}view-container\">             <monthview *ngSwitchCase=\"'month'\"                 [formatDay]=\"formatDay\"                 [formatDayHeader]=\"formatDayHeader\"                 [formatMonthTitle]=\"formatMonthTitle\"                 [startingDayMonth]=\"startingDayMonth\"                 [showEventDetail]=\"showEventDetail\"                 [noEventsLabel]=\"noEventsLabel\"                 [autoSelect]=\"autoSelect\"                 [eventSource]=\"eventSource\"                 [markDisabled]=\"markDisabled\"                 [monthviewDisplayEventTemplate]=\"monthviewDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"                 [monthviewInactiveDisplayEventTemplate]=\"monthviewInactiveDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"                 [monthviewEventDetailTemplate]=\"monthviewEventDetailTemplate||monthviewDefaultEventDetailTemplate\"                 [locale]=\"locale\"                 [dateFormatter]=\"dateFormatter\"                 [dir]=\"dir\"                 [lockSwipeToPrev]=\"lockSwipeToPrev\"                 [lockSwipes]=\"lockSwipes\"                 [spaceBetween]=\"spaceBetween\"                        (onRangeChanged)=\"rangeChanged($event)\"                 (onEventSelected)=\"eventSelected($event)\"                 (onTimeSelected)=\"timeSelected($event)\"                 (onTitleChanged)=\"titleChanged($event)\">             </monthview>             <weekview *ngSwitchCase=\"'week'\"                 [formatWeekTitle]=\"formatWeekTitle\"                 [formatWeekViewDayHeader]=\"formatWeekViewDayHeader\"                 [formatHourColumn]=\"formatHourColumn\"                 [startingDayWeek]=\"startingDayWeek\"                 [allDayLabel]=\"allDayLabel\"                 [hourParts]=\"hourParts\"                 [eventSource]=\"eventSource\"                 [markDisabled]=\"markDisabled\"                 [weekviewAllDayEventTemplate]=\"weekviewAllDayEventTemplate||defaultAllDayEventTemplate\"                 [weekviewNormalEventTemplate]=\"weekviewNormalEventTemplate||defaultNormalEventTemplate\"                 [locale]=\"locale\"                 [dateFormatter]=\"dateFormatter\"                 [dir]=\"dir\"                 [scrollToHour]=\"scrollToHour\"                 [preserveScrollPosition]=\"preserveScrollPosition\"                 [lockSwipeToPrev]=\"lockSwipeToPrev\"                 [lockSwipes]=\"lockSwipes\"                 [startHour]=\"startHour\"                 [endHour]=\"endHour\"                 [spaceBetween]=\"spaceBetween\"                 (onRangeChanged)=\"rangeChanged($event)\"                 (onEventSelected)=\"eventSelected($event)\"                 (onTimeSelected)=\"timeSelected($event)\"                 (onTitleChanged)=\"titleChanged($event)\">             </weekview>             <dayview *ngSwitchCase=\"'day'\"                 [formatDayTitle]=\"formatDayTitle\"                 [formatHourColumn]=\"formatHourColumn\"                 [allDayLabel]=\"allDayLabel\"                 [hourParts]=\"hourParts\"                 [eventSource]=\"eventSource\"                 [markDisabled]=\"markDisabled\"                 [dayviewAllDayEventTemplate]=\"dayviewAllDayEventTemplate||defaultAllDayEventTemplate\"                 [dayviewNormalEventTemplate]=\"dayviewNormalEventTemplate||defaultNormalEventTemplate\"                 [locale]=\"locale\"                 [dateFormatter]=\"dateFormatter\"                 [dir]=\"dir\"                 [scrollToHour]=\"scrollToHour\"                 [preserveScrollPosition]=\"preserveScrollPosition\"                 [lockSwipeToPrev]=\"lockSwipeToPrev\"                 [lockSwipes]=\"lockSwipes\"                 [startHour]=\"startHour\"                 [endHour]=\"endHour\"                 [spaceBetween]=\"spaceBetween\"                 (onRangeChanged)=\"rangeChanged($event)\"                 (onEventSelected)=\"eventSelected($event)\"                 (onTimeSelected)=\"timeSelected($event)\"                 (onTitleChanged)=\"titleChanged($event)\">             </dayview>         </div>",
        styles: [":host > div { height: 100%; }        .event-detail-container {          border-top: 2px darkgrey solid;        }        .no-events-label {          font-weight: bold;          color: darkgrey;          text-align: center;        }        .event-detail {          cursor: pointer;          white-space: nowrap;          text-overflow: ellipsis;        }        .monthview-eventdetail-timecolumn {          width: 110px;          overflow: hidden;        }        .calendar-event-inner {          overflow: hidden;          background-color: #3a87ad;          color: white;          height: 100%;          width: 100%;          padding: 2px;          line-height: 15px;        }        @media (max-width: 750px) {          .calendar-event-inner {            font-size: 12px;          }        }\n    .container ul {\n        margin: 0;\n        padding: 0px;\n        list-style: none;\n        position: relative;\n        color: #fff;\n        font-size: 13px;\n        border: none!important;\n    }\n    .container ul:before {\n        content: \"\";\n        width: 1px;\n        height: 100%;\n        position: absolute;\n        border-left: 2px dashed #000;\n        margin-left: 36px;\n    }\n    .container ul li {\n        position: relative;\n        margin-left: 30px;\n        background-color: #FF619C;\n        padding: 14px;\n        margin-left: 65px;\n        border: none!important;\n        border-radius: 10px!important;\n    }\n    .container ul li:not(:first-child) {\n        margin-top: 60px;\n    }\n    .container ul li > span {\n        width: 2px;\n        height: 100%;\n        /*background: #000;*/\n        left: -30px;\n        top: 0;\n        position: absolute;\n    }\n    .container ul li > span:before, .container ul li > span:after {\n        content: \"\";\n        width: 8px;\n        height: 8px;\n        border-radius: 50%;\n        border: 2px solid #000;\n        position: absolute;\n        background: #FF619C;\n        left: -5px;\n        top: 0;\n    }\n    .container ul li span:after {\n        top: 100%;\n    }\n    .container ul li > div {\n        margin-left: 10px;\n    }\n    .container div .title, .container div .type {\n        font-weight: 600;\n        font-size: 12px;\n        color: #fff;\n    }\n    .container div .info {\n        font-weight: 300;\n    }\n    .container div > div {\n        margin-top: 5px;\n    }\n    .container span.number {\n        height: 100%;\n    }\n    .container span.number span {\n        position: absolute;\n        font-size: 10px;\n        left: -35px;\n        font-weight: bold;\n        color: #000;\n    }\n    .container span.number span:first-child {\n        top: 0;\n    }\n    .container span.number span:last-child {\n        top: 100%;     \n    }\n    .container ion-item .item-inner{\n        border: none!important;\n    }\n    .item.item-block {\n        background: transparent!important;\n        border: none!important;\n        padding: 0px!important;\n        margin: 0px!important;\n    }\n    .item-inner {\n        border: none!important;\n        background: transparent!important;\n        padding: 0px!important;\n        margin: 0px!important;\n    }\n    .input-wrapper ion-label {\n        border: none!important;\n        padding: 0px!important;\n        margin: 0px!important;\n    }\n    .input-wrapper {\n        border: none!important;\n        background: transparent!important;\n        padding: 0px!important;\n        margin: 0px!important;\n    }"],
        providers: [calendar_service_1.CalendarService]
    }),
    __param(1, core_1.Inject(core_1.LOCALE_ID)),
    __metadata("design:paramtypes", [calendar_service_1.CalendarService, String])
], CalendarComponent);
exports.CalendarComponent = CalendarComponent;
//# sourceMappingURL=calendar.js.map