import React, { useRef } from 'react';
import {
  Dimensions,
  Platform,
  PlatformColor,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';
import { useColorScheme } from '../../hooks/useColorSheme';
import { useColors } from '../../hooks/useColors';
import { observable, ObservableHint } from '@legendapp/state';
import { useMount } from '@legendapp/state/react';
import { Constants } from '../../utils/constants';
import type { LayoutChangeEvent } from 'react-native';

const SUPORTS_WINDOW = Platform.OS === 'macos' || Platform.OS === 'windows';

export const RootViewRef$ = observable<React.RefObject<View>>();

interface AppBackgroundProps {
  children: React.ReactNode;
  transparentBackground?: boolean;
  useAcrylic?: boolean;
}

export const AppBackground = (props: AppBackgroundProps) => {
  const {
    children,
    transparentBackground = Constants.IS_WINDOWS ? false : undefined,
    useAcrylic = Constants.IS_WINDOWS,
  } = props;
  const rootViewRef = useRef<View>(null);
  const currentTheme = useColorScheme();
  useMount(() => {
    RootViewRef$.set(ObservableHint.opaque(rootViewRef));
  });
  const colors = useColors();
  const isDark = currentTheme === 'dark';
  const backgroundColor = {
    backgroundColor:
      useAcrylic && Constants.IS_WINDOWS
        ? AcrylicBrush('AcrylicBackgroundFillColorDefaultBrush')
        : colors.backgroundFillColorSolidBackgroundBase,
  };

  const showBgColor = !(transparentBackground ?? SUPORTS_WINDOW);

  return (
    <View
      ref={rootViewRef}
      onLayout={updateRootViewDimensions}
      style={[
        styles.appContainer,
        // { paddingTop: statusbarHeight },
        showBgColor && backgroundColor,
      ]}>
      <StatusBar
        backgroundColor={'transparent'}
        barStyle={isDark ? 'light-content' : 'dark-content'}
        translucent={true}
      />
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
  },
});

interface RootSDKViewDimensions {
  /**
   * Root view start x position relative to window dimensions
   */
  x: number;
  /**
   * Root view start y position relative to window dimensions
   */
  y: number;
  /**
   * Root view height
   */
  height: number;
  /**
   * Root view width
   */
  width: number;
  left?: number;
  top?: number;
}

export const RootSDKViewDimensions$ = observable<RootSDKViewDimensions>({
  ...Dimensions.get('window'),
  x: 0,
  y: 0,
  left: 0,
  top: 0,
});

const updateRootViewDimensions = (event: LayoutChangeEvent) => {
  const layout = event.nativeEvent.layout;
  RootSDKViewDimensions$.set(layout);
};

// https://github.com/microsoft/microsoft-ui-xaml/blob/6aed8d97fdecfe9b19d70c36bd1dacd9c6add7c1/dev/Materials/Acrylic/AcrylicBrush_19h1_themeresources.xaml#L11

function AcrylicBrush(name: PreDefinedAcrylicBrush) {
  return PlatformColor(name);
}

type PreDefinedAcrylicBrush =
  | 'AcrylicBackgroundFillColorDefaultBrush'
  | 'AcrylicBackgroundFillColorDefaultInverseBrush'
  | 'AcrylicInAppFillColorDefaultInverseBrush'
  | 'AcrylicBackgroundFillColorBaseBrush'
  | 'AcrylicInAppFillColorBaseBrush'
  | 'AccentAcrylicBackgroundFillColorDefaultBrush'
  | 'AccentAcrylicInAppFillColorDefaultBrush'
  | 'AccentAcrylicBackgroundFillColorBaseBrush'
  | 'AccentAcrylicInAppFillColorBaseBrush'
  | 'AcrylicInAppFillColorDefaultBrush';
