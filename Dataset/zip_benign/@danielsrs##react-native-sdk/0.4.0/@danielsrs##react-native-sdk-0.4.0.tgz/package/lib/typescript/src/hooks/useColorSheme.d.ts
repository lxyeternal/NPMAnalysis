export declare function useColorScheme(): import("../contexts/colorScheme/color-scheme.types").ColorScheme;
//# sourceMappingURL=useColorSheme.d.ts.map