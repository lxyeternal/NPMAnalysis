import React from 'react';
import { View } from 'react-native';
export declare const RootViewRef$: import("@legendapp/state").Observable<React.RefObject<View> | undefined>;
interface AppBackgroundProps {
    children: React.ReactNode;
    transparentBackground?: boolean;
    useAcrylic?: boolean;
}
export declare const AppBackground: (props: AppBackgroundProps) => import("react/jsx-runtime").JSX.Element;
interface RootSDKViewDimensions {
    /**
     * Root view start x position relative to window dimensions
     */
    x: number;
    /**
     * Root view start y position relative to window dimensions
     */
    y: number;
    /**
     * Root view height
     */
    height: number;
    /**
     * Root view width
     */
    width: number;
    left?: number;
    top?: number;
}
export declare const RootSDKViewDimensions$: import("@legendapp/state").Observable<RootSDKViewDimensions>;
export {};
//# sourceMappingURL=AppBackground.d.ts.map