import type { Colors } from './colors.types';
import type { ReactNode, FC } from 'react';
interface ColorsContextProps {
    colors: Colors;
}
export declare const ColorsContext: import("use-context-selector").Context<ColorsContextProps>;
export declare const ColorsProvider: FC<{
    children?: ReactNode;
}>;
export {};
//# sourceMappingURL=colors.d.ts.map