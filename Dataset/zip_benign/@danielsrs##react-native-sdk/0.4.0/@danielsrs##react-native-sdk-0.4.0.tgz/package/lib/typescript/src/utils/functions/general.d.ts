/**
 * No operation funcion
 */
export declare const NOP: () => void;
/**
 * Async no operation functcion
 */
export declare const ANOP: () => Promise<void>;
//# sourceMappingURL=general.d.ts.map