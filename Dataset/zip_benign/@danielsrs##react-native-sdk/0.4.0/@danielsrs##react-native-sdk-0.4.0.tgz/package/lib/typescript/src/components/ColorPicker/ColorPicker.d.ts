interface ColorPickerProps {
}
export declare function ColorPicker(props: ColorPickerProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ColorPicker.d.ts.map