export declare const IS_FABRIC_ENABLED: boolean;
export declare const suportsBoxShadow: boolean;
export declare const Constants: {
    IS_FABRIC_ENABLED: boolean;
    SUPORTS_BOX_SHADOW: boolean;
    IS_MACOS: boolean;
    IS_IOS: boolean;
    IS_ANDROID: boolean;
    IS_WEB: boolean;
    IS_WINDOWS: boolean;
    RN_VERSION: number;
};
//# sourceMappingURL=constants.d.ts.map