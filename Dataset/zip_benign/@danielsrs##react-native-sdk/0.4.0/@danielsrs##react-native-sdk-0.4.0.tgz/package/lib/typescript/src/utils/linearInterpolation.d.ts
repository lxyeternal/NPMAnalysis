/**
 * Source https://stackoverflow.com/questions/41338506/how-do-i-linearly-interpolate-lerp-ranged-input-to-ranged-output
 */
export declare const interpolate: (inputMin: number, inputMax: number, outputMin: number, outputMax: number, input: number) => number;
/**
 * https://stackoverflow.com/questions/64591884/how-to-dynamically-generate-rgb-colors-based-on-a-color-scale-by-values
 */
//# sourceMappingURL=linearInterpolation.d.ts.map