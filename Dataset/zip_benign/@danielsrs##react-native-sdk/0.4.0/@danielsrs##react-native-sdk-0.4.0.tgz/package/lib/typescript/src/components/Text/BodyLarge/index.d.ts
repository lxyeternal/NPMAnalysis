export * from './BodyLarge';
//# sourceMappingURL=index.d.ts.map