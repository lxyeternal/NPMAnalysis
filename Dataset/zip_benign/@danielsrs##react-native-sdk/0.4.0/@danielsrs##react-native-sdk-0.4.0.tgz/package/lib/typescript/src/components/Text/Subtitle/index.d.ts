export * from './Subtitle';
//# sourceMappingURL=index.d.ts.map