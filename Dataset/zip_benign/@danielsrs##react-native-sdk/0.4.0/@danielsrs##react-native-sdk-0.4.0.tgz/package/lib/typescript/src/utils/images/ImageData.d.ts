/**
 * https://github.com/node-gfx/image-data/blob/master/index.js
 */
export interface ImageData {
    /**
     * A `Uint8ClampedArray` representing a one-dimensional array containing the data in the RGBA order, with integer values between `0` and `255` (included).
     */
    readonly data: Uint8ClampedArray;
    /**
     * An `unsigned` `long` representing the actual height, in pixels, of the `ImageData`.
     */
    readonly height: number;
    /**
     * An `unsigned` `long` representing the actual width, in pixels, of the `ImageData`.
     */
    readonly width: number;
}
export declare function ImageData(array: Uint8ClampedArray, width: number, height?: number): ImageData;
//# sourceMappingURL=ImageData.d.ts.map