export declare function useColors(): import("../contexts/colors/colors.types").Colors;
//# sourceMappingURL=useColors.d.ts.map