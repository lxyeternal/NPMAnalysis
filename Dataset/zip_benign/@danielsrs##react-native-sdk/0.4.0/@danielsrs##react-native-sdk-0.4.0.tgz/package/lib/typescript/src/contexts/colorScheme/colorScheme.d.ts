import React from 'react';
import type { ColorScheme, UserColorScheme } from './color-scheme.types';
interface ColorSchemeContextProps {
    systemColorScheme: ColorScheme;
    setAppColorScheme: (option: UserColorScheme) => void;
    colorScheme: ColorScheme;
    appColorScheme: UserColorScheme;
}
export declare const ColorSchemeContext: import("use-context-selector").Context<ColorSchemeContextProps>;
export declare const ColorSchemeProvider: React.FC<{
    children: React.ReactNode;
}>;
export {};
//# sourceMappingURL=colorScheme.d.ts.map