/**
 * Cria uma seção no espaço de cores HSV dado um determinado valor
 * @param radius Raio do cilindro
 * @param value Altura da seção (value of a HSV color). value is between 0 and 1 (inclusive)
 * @returns
 */
export declare function createCrossSectionofHSVCylinder(radius: number, value: number): string;
export declare function createCrossSectionofHSVCylinderArr(radius: number, value: number, buffer: Uint8ClampedArray): void;
//# sourceMappingURL=hsv.d.ts.map