interface SliderProps {
    /**
     * Called continuously while sliding
     * @param value Selected value between (inclusive) minimumValue and maximumValue range
     */
    onValueChange?: (value: number) => void;
    /**
     * Max value that can be selected
     */
    maximumValue?: number;
    /**
     * Min value that can be selected
     */
    minimumValue?: number;
}
export declare function Slider(props: SliderProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Slider.d.ts.map