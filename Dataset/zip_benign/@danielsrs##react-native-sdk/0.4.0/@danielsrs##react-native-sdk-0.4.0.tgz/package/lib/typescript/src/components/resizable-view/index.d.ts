export * from './resizable-view';
//# sourceMappingURL=index.d.ts.map