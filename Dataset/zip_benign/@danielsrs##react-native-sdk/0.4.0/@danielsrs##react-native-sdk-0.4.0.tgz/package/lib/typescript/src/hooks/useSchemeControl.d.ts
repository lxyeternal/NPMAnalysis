export declare function useSchemeControl(): {
    appColorScheme: import("../contexts/colorScheme/color-scheme.types").ColorScheme;
    setAppColorScheme: (option: import("../contexts/colorScheme/color-scheme.types").UserColorScheme) => void;
};
//# sourceMappingURL=useSchemeControl.d.ts.map