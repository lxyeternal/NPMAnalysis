import type { Colors } from './colors.types';
export declare const Colors$: import("@legendapp/state").Observable<Colors>;
export declare function setColors(light: Partial<Colors>, dark: Partial<Colors>): void;
//# sourceMappingURL=colors.values.d.ts.map