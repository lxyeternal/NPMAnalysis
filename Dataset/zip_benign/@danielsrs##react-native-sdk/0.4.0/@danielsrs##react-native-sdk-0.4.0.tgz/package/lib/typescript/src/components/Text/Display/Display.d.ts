import type { TextProps } from 'react-native';
export declare function Display(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Display.d.ts.map