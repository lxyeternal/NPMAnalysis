export interface Right<T> {
    _tag: 'Right';
    right: T;
}
export interface Left<T> {
    _tag: 'Left';
    left: T;
}
export type Either<L, R> = Left<L> | Right<R>;
export declare function isLeft<L, R>(val: Either<L, R>): val is Left<L>;
export declare function isRight<L, R>(val: Either<L, R>): val is Right<R>;
export declare function right<T>(val: T): {
    _tag: "Right";
    right: T;
};
export declare function left<T>(val: T): {
    _tag: "Left";
    left: T;
};
//# sourceMappingURL=Either.d.ts.map