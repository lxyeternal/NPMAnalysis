/**
 *
 *  Base64 encode / decode
 *
 *  modified from original, found at
 *  http://www.webtoolkit.info/
 *
 * but copied from here: https://github.com/wheany/js-png-encoder/blob/master/webtoolkit.base64.js
 *
 **/
export declare const Base64: {
    encode: (input: string) => string;
    fromBinaryString: (data: string) => string;
    fromUint8Array: (data: Uint8ClampedArray | Uint8Array) => string;
};
//# sourceMappingURL=base64.d.ts.map