export { Styled } from './Styled';
//# sourceMappingURL=index.d.ts.map