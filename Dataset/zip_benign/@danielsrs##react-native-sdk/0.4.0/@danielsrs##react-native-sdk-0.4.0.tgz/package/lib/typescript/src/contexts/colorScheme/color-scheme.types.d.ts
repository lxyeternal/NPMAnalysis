import type { ColorSchemeName } from 'react-native';
export type ColorScheme = NonNullable<ColorSchemeName>;
export type UserColorScheme = 'system' | 'light' | 'dark';
//# sourceMappingURL=color-scheme.types.d.ts.map