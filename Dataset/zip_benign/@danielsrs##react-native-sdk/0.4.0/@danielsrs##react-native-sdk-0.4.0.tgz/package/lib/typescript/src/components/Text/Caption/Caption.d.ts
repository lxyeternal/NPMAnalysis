import type { TextProps } from 'react-native';
export declare function Caption(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Caption.d.ts.map