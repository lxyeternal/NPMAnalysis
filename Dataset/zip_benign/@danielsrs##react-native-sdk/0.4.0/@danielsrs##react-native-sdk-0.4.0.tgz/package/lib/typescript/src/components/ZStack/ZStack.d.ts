import React from 'react';
import { View } from 'react-native';
import type { ViewProps } from 'react-native';
export declare const ZStack: React.MemoExoticComponent<React.ForwardRefExoticComponent<ViewProps & React.RefAttributes<View>>>;
//# sourceMappingURL=ZStack.d.ts.map