import { type TouchableOpacityProps } from 'react-native';
import { type ReactNode } from 'react';
interface MenuProps {
    children: React.ReactNode;
    target: React.ReactNode;
}
export declare const Menu: {
    (props: MenuProps): import("react/jsx-runtime").JSX.Element;
    MenuEntry: (props: MenuEntryProps) => import("react/jsx-runtime").JSX.Element;
};
interface MenuEntryProps extends Omit<TouchableOpacityProps, 'children'> {
    children: string;
    left?: ReactNode | (() => ReactNode);
    right?: ReactNode | (() => ReactNode);
}
export {};
//# sourceMappingURL=Menu.d.ts.map