export declare function hsv2rgb(h: number, s: number, v: number): {
    r: number;
    g: number;
    b: number;
};
//# sourceMappingURL=hsv2rgb.d.ts.map