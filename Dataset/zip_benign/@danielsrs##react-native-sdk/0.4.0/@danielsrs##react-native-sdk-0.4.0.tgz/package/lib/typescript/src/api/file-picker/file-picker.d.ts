import type { SingleFilePickerAutoBuilded } from './file-picker.types';
export declare let pickFile: SingleFilePickerAutoBuilded;
//# sourceMappingURL=file-picker.d.ts.map