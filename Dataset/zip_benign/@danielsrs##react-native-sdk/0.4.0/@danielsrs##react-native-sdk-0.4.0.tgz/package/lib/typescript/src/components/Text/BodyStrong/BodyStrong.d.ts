import type { TextProps } from 'react-native';
export declare function BodyStrong(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BodyStrong.d.ts.map