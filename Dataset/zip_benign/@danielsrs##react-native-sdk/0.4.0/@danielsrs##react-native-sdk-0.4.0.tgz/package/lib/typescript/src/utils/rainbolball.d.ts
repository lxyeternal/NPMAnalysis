/**
 * from https://github.com/wheany/js-png-encoder/blob/master/rainbow_ball.js
 */
export declare function createRainbowBall(radius: number, phases: number): string;
export declare const colorSqure: (width: number) => string;
//# sourceMappingURL=rainbolball.d.ts.map