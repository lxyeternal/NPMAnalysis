import type { TextProps } from 'react-native';
export declare function BodyLarge(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BodyLarge.d.ts.map