import type { PickSingleErrorCodes } from './file-picker.types';
import type { InvertRecord } from '../../types/Record';
/**
 * Código dos erros conhecidos
 */
export declare const pickerErrorCodes: InvertRecord<PickSingleErrorCodes>;
//# sourceMappingURL=file-picker.constants.d.ts.map