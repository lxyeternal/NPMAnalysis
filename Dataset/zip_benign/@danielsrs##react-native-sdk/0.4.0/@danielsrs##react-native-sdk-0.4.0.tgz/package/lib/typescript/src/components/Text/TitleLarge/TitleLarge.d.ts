import type { TextProps } from 'react-native';
export declare function TitleLarge(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TitleLarge.d.ts.map