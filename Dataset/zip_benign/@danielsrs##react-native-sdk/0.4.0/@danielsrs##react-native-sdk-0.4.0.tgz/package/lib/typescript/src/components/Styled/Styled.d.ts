import { View } from 'react-native';
import type { StyleProp, TextStyle, ImageStyle, ViewStyle } from 'react-native';
type StyleableProps = {
    style?: StyleProp<ViewStyle | TextStyle | ImageStyle>;
};
type InferStyle<T> = T extends {
    style?: infer S;
} ? S : never;
export declare const Styled: {
    createStyledView: (defaultStyles: false | "" | ViewStyle | import("react-native").RegisteredStyle<ViewStyle> | import("react-native").RecursiveArray<ViewStyle | import("react-native").Falsy | import("react-native").RegisteredStyle<ViewStyle>> | null, displayName?: string) => import("react").ForwardRefExoticComponent<import("react-native").ViewProps & import("react").RefAttributes<unknown>>;
    createStyledTouchableOpacity: (defaultStyles: false | "" | ViewStyle | import("react-native").RegisteredStyle<ViewStyle> | import("react-native").RecursiveArray<ViewStyle | import("react-native").Falsy | import("react-native").RegisteredStyle<ViewStyle>> | null, displayName?: string) => import("react").ForwardRefExoticComponent<Omit<import("react-native").TouchableOpacityProps & import("react").RefAttributes<View>, "ref"> & import("react").RefAttributes<unknown>>;
    createStyled: <P extends StyleableProps>(WrappedComponent: React.ComponentType<P>, defaultStyles: InferStyle<P>, displayName?: string) => import("react").ForwardRefExoticComponent<import("react").PropsWithoutRef<P> & import("react").RefAttributes<unknown>>;
    partialCreateStyled: <P extends StyleableProps>(WrappedComponent: React.ComponentType<P>) => (defaultStyles: InferStyle<P>, displayName?: string) => import("react").ForwardRefExoticComponent<import("react").PropsWithoutRef<P> & import("react").RefAttributes<unknown>>;
};
export {};
//# sourceMappingURL=Styled.d.ts.map