import { type ModalProps } from 'react-native';
export declare const VModalRoot: () => import("react/jsx-runtime").JSX.Element | null;
export declare const VModal: (props: ModalProps) => null;
//# sourceMappingURL=VModal.d.ts.map