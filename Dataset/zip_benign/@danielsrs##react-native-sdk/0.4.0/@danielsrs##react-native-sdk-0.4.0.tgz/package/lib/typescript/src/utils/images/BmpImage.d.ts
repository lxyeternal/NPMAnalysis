/**
 * Create a new Bitmap (bmp) image
 * @param width Width of the image to be created
 * @param height Height of the image to be created
 * @returns
 */
export declare function BmpImage(width: number, height: number): BmpImage;
/**
 * 32bit color bmp image with transparency
 */
export interface BmpImage {
    /**
     * full bpm image (in binary format)
     */
    readonly data: Uint8ClampedArray;
    /**
     * RGBA pixel array data with all pixels initialized
     * to 100% tarnsparent black
     *
     * - The pixel order starts form top left
     * - There is width * height pixels with 4 bytes each
     * - Each width * 4 bits represents a horizontal line in the image
     *
     * This array contents SHOULD be modified after BmpImage creation,
     * otherwise nothing will shown when rendering this image,
     * (since all pixels are transparent)
     */
    pixelArray: Uint8ClampedArray;
    /** Image width */
    readonly width: number;
    /** Image height */
    readonly height: number;
}
//# sourceMappingURL=BmpImage.d.ts.map