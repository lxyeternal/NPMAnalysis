import type { PressableProps, StyleProp, ViewStyle } from 'react-native';
export interface ButtonProps extends PressableProps {
    children?: string;
    style?: StyleProp<ViewStyle>;
    accent?: boolean;
    showIconOnLeft?: boolean;
    icon?: boolean;
}
export declare function Button(props: ButtonProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Button.d.ts.map