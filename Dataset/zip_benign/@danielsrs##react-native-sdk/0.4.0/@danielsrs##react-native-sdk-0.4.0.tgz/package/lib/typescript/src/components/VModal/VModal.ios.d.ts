import React from 'react';
import { Modal } from 'react-native';
export declare const VModal: typeof Modal;
export declare const VModalRoot: React.ExoticComponent<{
    children?: React.ReactNode | undefined;
}>;
//# sourceMappingURL=VModal.ios.d.ts.map