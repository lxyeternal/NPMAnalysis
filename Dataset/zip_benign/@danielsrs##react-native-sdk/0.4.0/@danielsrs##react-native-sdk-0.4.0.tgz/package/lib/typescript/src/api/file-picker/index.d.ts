export { pickFile } from './file-picker';
//# sourceMappingURL=index.d.ts.map