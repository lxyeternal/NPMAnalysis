export * from './TitleLarge';
//# sourceMappingURL=index.d.ts.map