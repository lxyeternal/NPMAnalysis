import type { UserColorScheme } from './color-scheme.types';
/**
 * Operating system current color scheme
 */
export declare const SystemColorScheme$: import("@legendapp/state").ObservablePrimitive<"light" | "dark">;
/**
 * Current app setted color scheme
 */
export declare const AppColorScheme$: import("@legendapp/state").ObservablePrimitive<UserColorScheme>;
/**
 * Current color scheme
 */
export declare const ColorScheme$: import("@legendapp/state").ObservablePrimitive<"light" | "dark">;
/**
 * Update app color scheme
 * @param colorScheme Color scheme to use
 */
export declare const SetColorScheme: (colorScheme: UserColorScheme) => void;
//# sourceMappingURL=color-scheme.d.ts.map