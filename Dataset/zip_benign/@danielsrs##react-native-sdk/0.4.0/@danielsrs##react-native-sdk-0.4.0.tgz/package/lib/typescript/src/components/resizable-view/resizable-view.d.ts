import type { ViewProps } from 'react-native';
interface ResizableContainerProps extends ViewProps {
    readonly maxWidthToResize?: number;
    readonly minWidthToResize?: number;
    readonly maxHeightToResize?: number;
    readonly minHeighToResize?: number;
    /**
     * Resize from right side
     */
    readonly fromRight?: boolean;
    /**
     * Resize from left side
     */
    readonly fromBottom?: boolean;
}
export declare const ResizableView: (props: ResizableContainerProps) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=resizable-view.d.ts.map