export { createContext, useContextSelector as useContext, } from 'use-context-selector';
//# sourceMappingURL=context.d.ts.map