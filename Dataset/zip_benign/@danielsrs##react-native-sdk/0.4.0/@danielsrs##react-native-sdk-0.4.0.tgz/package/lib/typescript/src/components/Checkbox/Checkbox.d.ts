interface CheckboxProps {
    value: boolean | undefined;
    onPress?: () => void;
    disabled?: boolean;
    label?: string;
}
export declare function Checkbox(props: CheckboxProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Checkbox.d.ts.map