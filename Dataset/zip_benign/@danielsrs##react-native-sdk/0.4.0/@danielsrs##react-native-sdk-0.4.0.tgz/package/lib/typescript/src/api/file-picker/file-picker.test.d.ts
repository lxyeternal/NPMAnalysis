export {};
//# sourceMappingURL=file-picker.test.d.ts.map