import type { TextProps } from 'react-native';
export declare function Body(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Body.d.ts.map