import type { ButtonProps } from '../Button/Button';
interface ToggleButtonProps extends Omit<ButtonProps, 'onPress' | 'onPressIn' | 'onPressOut' | 'accent'> {
    onChange?: (newValue: boolean) => void;
    initialValue?: boolean;
}
export declare function ToggleButton(props: ToggleButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ToggleButton.d.ts.map