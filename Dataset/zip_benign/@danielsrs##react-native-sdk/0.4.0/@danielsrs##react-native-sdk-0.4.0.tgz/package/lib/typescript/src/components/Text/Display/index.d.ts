export * from './Display';
//# sourceMappingURL=index.d.ts.map