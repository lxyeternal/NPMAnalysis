export type NonEmptyArray<T> = [T, ...T[]];
//# sourceMappingURL=Array.d.ts.map