interface RadioButtonProps {
    selected: boolean;
    label?: string;
    onPress?: () => void;
}
export declare function RadioButton(props: RadioButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=radio-button.d.ts.map