export declare function PNG(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=PNG.d.ts.map