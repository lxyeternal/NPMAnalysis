export * from './AppBackground';
//# sourceMappingURL=index.d.ts.map