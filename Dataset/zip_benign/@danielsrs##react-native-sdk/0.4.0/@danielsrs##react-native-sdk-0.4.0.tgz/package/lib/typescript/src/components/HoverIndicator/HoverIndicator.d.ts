import type { StyleProp, ViewStyle } from 'react-native';
export declare function HoverIndicator(props: {
    hoverStyles?: StyleProp<ViewStyle>;
    restStyles?: StyleProp<ViewStyle>;
}): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=HoverIndicator.d.ts.map