import type { RNDP_DocumentPickerResponse } from './file-picker.types';
import type { RNDP_CheckedResponse } from './file-picker.types';
import type { RNDP_CheckedError } from './file-picker.types';
import type { SingleFilePicker } from './file-picker.types';
/**
 * Valida resultado do picker retornado pela lib RNDP
 */
export declare const rndpCheckResponse: RNDP_CheckedResponse;
/**
 * Valida/Encapsula erro retornado pela implementação usando RNDP
 */
export declare const rndpCheckError: RNDP_CheckedError;
export declare const pickSinglebBuilder: (b: RNDP) => SingleFilePicker;
/**
 * Usar biblioteca react-native-document-picker com implementação
 */
interface RNDP {
    lib: 'react-native-document-picker';
    pickSingle: (params: {
        type?: string | string[];
    }) => Promise<RNDP_DocumentPickerResponse>;
}
export {};
//# sourceMappingURL=file-picker.builder.d.ts.map