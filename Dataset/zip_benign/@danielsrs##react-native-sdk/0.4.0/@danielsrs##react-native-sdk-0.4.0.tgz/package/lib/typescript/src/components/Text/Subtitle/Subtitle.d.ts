import type { TextProps } from 'react-native';
export declare function Subtitle(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Subtitle.d.ts.map