import type { TextProps } from 'react-native';
export declare function Title(props: TextProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Title.d.ts.map