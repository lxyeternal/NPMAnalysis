type BreakpointH = {
    SMALL_BREAKPOINT: 0;
    MEDIUM_BREAKPOINT: 1;
    LARGE_BREAKPOINT: 2;
    X_LARGE_BREAKPOINT: 3;
    XX_LARGE_BREAKPOINT: 4;
    XXX_LARGE_BREAKPOINT: 5;
};
declare const SMALL_BREAKPOINT: 0 & {
    name: "small";
} & BreakpointH;
declare const MEDIUM_BREAKPOINT: 1 & {
    name: "medium";
} & BreakpointH;
declare const LARGE_BREAKPOINT: 2 & {
    name: "large";
} & BreakpointH;
declare const X_LARGE_BREAKPOINT: 3 & {
    name: "x-large";
} & BreakpointH;
declare const XX_LARGE_BREAKPOINT: 4 & {
    name: "xx-large";
} & BreakpointH;
declare const XXX_LARGE_BREAKPOINT: 5 & {
    name: "xxx-large";
} & BreakpointH;
type Breakpoint = typeof SMALL_BREAKPOINT | typeof MEDIUM_BREAKPOINT | typeof LARGE_BREAKPOINT | typeof X_LARGE_BREAKPOINT | typeof XX_LARGE_BREAKPOINT | typeof XXX_LARGE_BREAKPOINT;
/**
 * Current breackpoint
 */
export declare const Breakpoint$: import("@legendapp/state").ObservablePrimitive<Breakpoint>;
export declare function calculateBreakpoint(width: number): Breakpoint;
export declare const useBreakpoints: () => Breakpoint;
export {};
//# sourceMappingURL=useBreakpoints.d.ts.map