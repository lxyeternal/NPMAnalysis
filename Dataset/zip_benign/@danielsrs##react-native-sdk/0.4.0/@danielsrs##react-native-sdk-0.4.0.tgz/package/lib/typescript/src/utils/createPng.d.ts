export declare function png(width: number, height: number, rgba: string): string;
//# sourceMappingURL=createPng.d.ts.map