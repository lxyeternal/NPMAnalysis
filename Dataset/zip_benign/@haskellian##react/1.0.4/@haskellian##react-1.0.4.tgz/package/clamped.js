import { useCallback, useState } from 'react';
import { clamp } from 'haskellian/util';
export const applyAction = (action, curr) => typeof action === 'function' ? action(curr) : action;
/** Like `useState<number>`, a but the number is bounded to `[min, max]` (closed interval) */
export function useClamped(start, config) {
    var _a, _b;
    const min = (_a = config === null || config === void 0 ? void 0 : config.min) !== null && _a !== void 0 ? _a : -Infinity;
    const max = (_b = config === null || config === void 0 ? void 0 : config.max) !== null && _b !== void 0 ? _b : Infinity;
    const [state, setState] = useState(start);
    const setClamped = useCallback((action, ignoreClamp) => {
        if (ignoreClamp)
            setState(action);
        else
            setState(x => {
                const curr = clamp(min, x, max);
                return clamp(min, applyAction(action, curr), max);
            });
    }, [min, max]);
    const clamped = clamp(min, state, max);
    return [clamped, setClamped];
}
