import React, { useCallback, useMemo } from 'react';
import { useResolvedPath, useMatch, useLocation, useNavigate, useParams } from 'react-router-dom';
const removeTrailingSlashes = (url) => url.replace(/\/$/, '');
/** Split the current path into parent and children routes
 *
 * - Both paths start with a slash, and end without one
 *
 * ```
 * function Parent() {
 *   return useRoutes([{
 *     path: '/nested/path/*',
 *     element: <Nested />
 *   }])
 * }
 *
 * function Nested() {
 *   const [pre, post] = useSplitPath() // ['/nested/path', '/children/path']
 *   return useRoutes([{
 *     path: '*',
 *     element: <Navigate to='children/path' />
 *   }])
 * }
 * ```
 */
export function useSplitPath() {
    var _a;
    const resolvedPath = useResolvedPath('');
    const { pathname } = useLocation();
    const match = useMatch({ path: resolvedPath.pathname, end: false });
    const basePath = removeTrailingSlashes((_a = match === null || match === void 0 ? void 0 : match.pathnameBase) !== null && _a !== void 0 ? _a : '');
    const complement = basePath ? pathname.substring(basePath.length) : pathname;
    return [basePath, complement];
}
/** Change the path whilst keeping query parameters and hash intact */
export function reroute(location, newPath) {
    return newPath + location.search + location.hash;
}
/** Like `useNavigate`, but keeping query parameters and hash intact */
export function useReroute() {
    const location = useLocation();
    const goto = useNavigate();
    return useCallback((to, options) => goto(reroute(location, to), options), [goto, location]);
}
/** HOC to bind path parameters  */
export function withParams(keys, Component) {
    function Wrapper(props) {
        const params = useParams();
        const allProps = useMemo(() => {
            const result = Object.assign({}, props);
            for (const key of keys)
                result[key] = params[key];
            return result;
        }, [params, props]);
        return React.createElement(Component, Object.assign({}, allProps));
    }
    return Wrapper;
}
