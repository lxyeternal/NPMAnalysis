export type Config = {
    delaySecs?: number;
};
export type RequestsHook = {
    schedule(reqId: any, config?: Config): Promise<boolean>;
    cancel(reqId: any): void;
};
/** Simple closure for scheduling and canceling requests
 * ```
 * const reqs = cancellableRequests({ delaySecs: 10 })
 *
 * async function request(id) {
 *    const ok = await reqs.schedule(id)
 *    if (ok)
 *      fetch(id)
 * }
 *
 * request(id)
 * request(id) // first one gets cancelled, second executed after `delaySecs`
 *
 * // or, one can cancel them manually using:
 * reqs.cancel(id)
 * ```
 *
 * ### React usage
 * ```
 * const reqs = useRef(cancellableRequests({ delaySecs: 10 }))
 * reqs.current.schedule(id) // etc.
 * ```
 */
export declare function cancellableRequests(defaultConfig?: Config): RequestsHook;
