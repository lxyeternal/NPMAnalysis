export type Rotation = 0 | 90 | 180 | -90;
export declare const toCSSdegrees: (rot: Rotation) => 0 | -90 | -180 | -270;
export declare function useRotation(start?: Rotation): {
    rotation: Rotation;
    clockwiseDegrees: number;
    /** CSS does angles backwards, it seems */
    rotate(to: 'left' | 'right' | Rotation): void;
};
