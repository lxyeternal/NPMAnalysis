import { SetStateAction } from 'react';
export type IntervalConfig = {
    autoplay?: boolean;
    delaySecs?: number;
};
export type IntervalHook = {
    setPlaying(action: SetStateAction<boolean>): void;
    playing: boolean;
};
/** Controllable `setInterval`
 * - Returns `{ playing, setPlaying }` to control whether the interval is active
 * - `callback(stop)`: called at every interval. Can call `stop` to prevent the next interval (exactly the same as `setInterval(false)`)
 * - `config.autoplay`: whether to start the interval on mount
 * - `config.delaySecs`: duh! The interval
 */
export declare function useInterval(callback: (stop: () => void) => void, config: IntervalConfig): IntervalHook;
