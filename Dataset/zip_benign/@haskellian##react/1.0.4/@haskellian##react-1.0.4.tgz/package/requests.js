var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { delay } from "haskellian/promise";
/** Simple closure for scheduling and canceling requests
 * ```
 * const reqs = cancellableRequests({ delaySecs: 10 })
 *
 * async function request(id) {
 *    const ok = await reqs.schedule(id)
 *    if (ok)
 *      fetch(id)
 * }
 *
 * request(id)
 * request(id) // first one gets cancelled, second executed after `delaySecs`
 *
 * // or, one can cancel them manually using:
 * reqs.cancel(id)
 * ```
 *
 * ### React usage
 * ```
 * const reqs = useRef(cancellableRequests({ delaySecs: 10 }))
 * reqs.current.schedule(id) // etc.
 * ```
 */
export function cancellableRequests(defaultConfig) {
    const counters = new Map();
    return {
        schedule(reqId, config) {
            return __awaiter(this, void 0, void 0, function* () {
                var _a, _b, _c;
                const delaySecs = (_b = (_a = config === null || config === void 0 ? void 0 : config.delaySecs) !== null && _a !== void 0 ? _a : defaultConfig === null || defaultConfig === void 0 ? void 0 : defaultConfig.delaySecs) !== null && _b !== void 0 ? _b : 15;
                const counter = ((_c = counters.get(reqId)) !== null && _c !== void 0 ? _c : 0) + 1;
                counters.set(reqId, counter);
                yield delay(delaySecs);
                return counters.get(reqId) === counter;
            });
        },
        cancel(reqId) {
            counters.delete(reqId);
        }
    };
}
