import { useEffect, useMemo } from 'react';
import { useRefState } from './ref-state.js';
/** Controllable `setInterval`
 * - Returns `{ playing, setPlaying }` to control whether the interval is active
 * - `callback(stop)`: called at every interval. Can call `stop` to prevent the next interval (exactly the same as `setInterval(false)`)
 * - `config.autoplay`: whether to start the interval on mount
 * - `config.delaySecs`: duh! The interval
 */
export function useInterval(callback, config) {
    var _a;
    const [playing, setPlaying, playingRef] = useRefState((_a = config.autoplay) !== null && _a !== void 0 ? _a : false);
    const delayMs = useMemo(() => { var _a; return 1e3 * ((_a = config.delaySecs) !== null && _a !== void 0 ? _a : 1); }, [config.delaySecs]);
    useEffect(() => {
        const id = setInterval(() => {
            if (playingRef.current)
                callback(() => setPlaying(false));
        }, delayMs);
        return () => clearInterval(id);
    }, [playing, delayMs, playingRef, setPlaying, callback]);
    return { playing, setPlaying };
}
