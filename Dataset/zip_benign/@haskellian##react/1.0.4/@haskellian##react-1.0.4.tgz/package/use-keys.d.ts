export declare function useKeys(keys: string[], handler: (e: KeyboardEvent) => void): void;
