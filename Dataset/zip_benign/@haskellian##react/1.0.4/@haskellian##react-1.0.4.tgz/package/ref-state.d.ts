import { Dispatch, MutableRefObject, SetStateAction } from "react";
export declare const applyAction: <T>(action: SetStateAction<T>, curr: T) => T;
export declare const initialValue: <T>(initialState: T | (() => T)) => T;
/** Like `useState` but returns `[state, setState, ref]`. `ref` is synchronously updated when calling `setState` */
export declare function useRefState<T>(initialState: T | (() => T)): [T, Dispatch<SetStateAction<T>>, MutableRefObject<T>];
/** Wrap a `useState` into a `useRef`
 * ```
 * const [state, _setState] = useState(...)
 * const [setState, ref] = useStateRef(state, _setState)
 * ```
 */
export declare function useStateRef<T>(initialState: T | (() => T), setter: Dispatch<SetStateAction<T>>): [Dispatch<SetStateAction<T>>, MutableRefObject<T>];
