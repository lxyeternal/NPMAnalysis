import { Location } from 'react-router-dom';
/** Split the current path into parent and children routes
 *
 * - Both paths start with a slash, and end without one
 *
 * ```
 * function Parent() {
 *   return useRoutes([{
 *     path: '/nested/path/*',
 *     element: <Nested />
 *   }])
 * }
 *
 * function Nested() {
 *   const [pre, post] = useSplitPath() // ['/nested/path', '/children/path']
 *   return useRoutes([{
 *     path: '*',
 *     element: <Navigate to='children/path' />
 *   }])
 * }
 * ```
 */
export declare function useSplitPath(): [string, string];
/** Change the path whilst keeping query parameters and hash intact */
export declare function reroute(location: Location, newPath: string): string;
/** Like `useNavigate`, but keeping query parameters and hash intact */
export declare function useReroute(): any;
/** HOC to bind path parameters  */
export declare function withParams<K extends string, Props extends object, T>(keys: K[], Component: (props: Props & Record<K, string>) => T): (props: Omit<Props, K>) => T;
