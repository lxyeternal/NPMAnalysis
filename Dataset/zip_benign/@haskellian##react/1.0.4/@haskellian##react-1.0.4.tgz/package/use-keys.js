import { useEffect } from 'react';
export function useKeys(keys, handler) {
    useEffect(() => {
        const listener = (e) => keys.includes(e.key) && !e.ctrlKey && handler(e);
        window.addEventListener('keydown', listener);
        return () => window.removeEventListener('keydown', listener);
    }, [keys, handler]);
}
