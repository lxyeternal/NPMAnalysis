import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
/** Parameter from URL or localStorage */
export function useParam(name) {
    var _a;
    const [params] = useSearchParams();
    const [value] = useState((_a = params.get(name)) !== null && _a !== void 0 ? _a : localStorage.getItem(name));
    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        if (params.has(name)) {
            params.delete(name);
            window.location.search = params.toString();
        }
    }, [name]);
    useEffect(() => {
        if (value !== null)
            localStorage.setItem(name, value);
    }, [name, value]);
    return value;
}
