/** Parameter from URL or localStorage */
export declare function useParam(name: string): string | null;
