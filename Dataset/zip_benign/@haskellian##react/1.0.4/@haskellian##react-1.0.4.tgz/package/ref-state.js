import { useCallback, useRef, useState } from "react";
export const applyAction = (action, curr) => typeof action === 'function' ? action(curr) : action;
export const initialValue = (initialState) => typeof initialState === 'function' ? initialState() : initialState;
/** Like `useState` but returns `[state, setState, ref]`. `ref` is synchronously updated when calling `setState` */
export function useRefState(initialState) {
    const [state, _setState] = useState(initialState);
    const ref = useRef(state);
    const setState = useCallback((action) => _setState(x => {
        const newState = applyAction(action, x);
        ref.current = newState;
        return newState;
    }), []);
    return [state, setState, ref];
}
/** Wrap a `useState` into a `useRef`
 * ```
 * const [state, _setState] = useState(...)
 * const [setState, ref] = useStateRef(state, _setState)
 * ```
 */
export function useStateRef(initialState, setter) {
    const ref = useRef(initialValue(initialState));
    const setState = useCallback((action) => setter(curr => {
        const next = applyAction(action, curr);
        ref.current = next;
        return next;
    }), [setter]);
    return [setState, ref];
}
