import { SetStateAction } from 'react';
export declare const applyAction: <T>(action: SetStateAction<T>, curr: T) => T;
export type ClampSetter = {
    (action: SetStateAction<number>, ignoreClamp?: boolean): void;
};
export type ClampConfig = {
    min?: number;
    max?: number;
};
/** Like `useState<number>`, a but the number is bounded to `[min, max]` (closed interval) */
export declare function useClamped(start: number, config?: ClampConfig): [number, ClampSetter];
