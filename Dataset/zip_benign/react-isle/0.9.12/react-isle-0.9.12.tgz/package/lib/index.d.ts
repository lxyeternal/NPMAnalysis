export * from "./archipelago";
export declare enum IsleViewModesEnum {
    Normal = 0,
    Minimized = 1
}
export { default } from "./isle";
