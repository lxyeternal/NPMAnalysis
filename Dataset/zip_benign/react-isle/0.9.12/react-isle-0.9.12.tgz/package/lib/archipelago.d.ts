import React, { Component } from 'react';
import Isle from "./isle";
import { ArchipelagoProps } from "./interfaces";
export declare class Archipelago extends Component<ArchipelagoProps> {
    isles: Isle[];
    minimizedIsles: Isle[];
    stackWidth: number;
    mapIsle: (k: number, isle: Isle) => void;
    minimizeIsle: (isle: Isle, scale?: number) => void;
    restoreIsle: (k: number, isle: Isle) => void;
    getStackBoundingRect: () => {
        top: number;
        left: number;
        width: number;
        right: number;
    };
    getBoundingClientRect: () => DOMRect | null;
    getHighestZIndex(): number;
    ref: React.RefObject<HTMLDivElement>;
    render(): JSX.Element;
}
