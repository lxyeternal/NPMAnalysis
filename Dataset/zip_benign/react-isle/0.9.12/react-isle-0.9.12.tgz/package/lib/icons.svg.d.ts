/// <reference types="react" />
declare const xmarkSvg: JSX.Element;
declare const expandSvg: JSX.Element;
export { xmarkSvg, expandSvg };
