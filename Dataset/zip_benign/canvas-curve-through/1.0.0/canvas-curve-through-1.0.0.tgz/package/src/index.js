export default function quadraticCurveThrough(ctx, x0, y0, x1, y1, x2, y2, time=0.5) {
  const tsq = time * time;
  const tsqinv = (1 - time) * (1 - time);
  const cx = (x1 - tsqinv*x0 - tsq*x2) / (2*time - 2*tsq)
  const cy = (y1 - tsqinv*y0 - tsq*y2) / (2*time - 2*tsq)
  ctx.quadraticCurveTo(cx, cy, x2, y2);
}
