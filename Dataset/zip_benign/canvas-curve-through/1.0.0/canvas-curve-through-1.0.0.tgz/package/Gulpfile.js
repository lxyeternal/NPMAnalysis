var gulp = require('gulp')
  , babel = require('gulp-babel')
  , rename = require('gulp-rename');

function build(moduleType, filename) {
  gulp.src('./src/index.js')
    .pipe(babel({ modules: moduleType }))
    .pipe(rename(filename))
    .pipe(gulp.dest('./dist/'));
}

gulp.task('default', ['common', 'global'], function() {});

gulp.task('common', function() {
  build('common', 'index.js');
});

gulp.task('global', function() {
  build('ignore', 'canvas-curve-through.js');
});
