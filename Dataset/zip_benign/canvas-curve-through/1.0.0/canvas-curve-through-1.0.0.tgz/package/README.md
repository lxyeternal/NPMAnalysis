# Quadratic Curve Through for Canvas
This is a simple utility function that draws a quadratic curve onto a `canvas`
element given a point that the curve must pass through at a given time along the curve.

## Illustration
![Various Curves](doc/illustration.png)

## Usage
This module provides a single function with the following signature:

    quadraticCurveThrough(ctx, startX, startY, midX, midY, endX, endY, time=0.5)

With Webpack or Node (for server-side canvas see https://github.com/Automattic/node-canvas):

    var quadraticCurveThrough = require('canvas-curve-through');
    quadraticCurveThrough(<your arguments>);

If you don't use Webpack download [this file](dist/canvas-curve-through.js).

**N.B. Unlike the standard path functions you must specify the start point when
using this function. This is because the canvas API does not provide a way to
retrieve the current point.**
