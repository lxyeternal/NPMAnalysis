declare namespace Ocpr {
  export interface Options {
    strict?: boolean;
    checkOrientation?: boolean;
    maxWidth?: number;
    maxHeight?: number;
    minWidth?: number;
    minHeight?: number;
    width?: number;
    height?: number;
    quality?: number;
    mimeType?: string;
    convertSize?: number;
    beforeDraw?(context: CanvasRenderingContext2D, canvas: HTMLCanvasElement): void;
    drew?(context: CanvasRenderingContext2D, canvas: HTMLCanvasElement): void;
    success?(file: Blob): void;
    error?(error: Error): void;
  }
}

declare class Ocpr {
  constructor(file: File | Blob, options?: Ocpr.Options);
  abort(): void;
  static noConflict(): Ocpr;
  static setDefaults(options: Ocpr.Options): void;
}

declare module 'ocprjs' {
  export default Ocpr;
}
