### Installation
```shell
npm install ocprjs
```


#### Usage


```html
<input type="file" id="file" accept="image/*">
```

```js
import axios from 'axios';
import Ocpr from 'ocprjs';

document.getElementById('file').addEventListener('change', (e) => {
  const file = e.target.files[0];

  if (!file) {
    return;
  }

  new Ocpr(file, {
    quality: 0.5,
    strict: true,
    width: 620,
    height: 620,
    mimeType: 'image/jpeg',
    success(result) {
      const formData = new FormData();

      // The third parameter is required for server
      formData.append('file', result, result.name);

      // Send the compressed image file to server with XMLHttpRequest.
      axios.post('/path/to/upload', formData).then(() => {
        console.log('Upload success');
      });
    },
    error(err) {
      console.log(err.message);
    },
  });
});
```