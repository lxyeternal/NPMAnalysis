# Back To Top Arrow

Simple customizable Vanilla JS back to top arrow.

## Installation

```bash
npm i back-to-top-arrow
```

## Usage

#### Import package

```js
import backToTop from 'back-to-top-arrow';
```

#### Import stylesheet

```js
import './node_modules/back-to-top-arrow/back-to-top.css';
```

#### Call the function

```js
backToTop();
```

Function can take 4 arguments, if none are passed, default values are used.

| No. | Property            | Default | Type   | Description                                     |
| --- | ------------------- | ------- | ------ | ----------------------------------------------- |
| 1.  | Depth               | 0.4     | Number | Scroll depth at which the arrow appears (0 - 1) |
| 2.  | Background color    | #a8a7a  | String | Color of the background area                    |
| 3.  | Background on hover | #ebe8e8 | String | Color of the background area on hover           |
| 4.  | Arrow color         | #1f1e1e | String | Color of the arrow                              |

#### Example usage with custom settings

```js
backToTop(0.6, '#000', '#2e2d2d', '#fff');
```

## License

[MIT](https://choosealicense.com/licenses/mit/)
