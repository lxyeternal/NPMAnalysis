const backToTop = (
  depth = 0.4,
  colorBckg = '#a8a7a7',
  colorBckgHover = '#ebe8e8',
  colorArrow = '#1f1e1e'
) => {
  const rootElement = document.documentElement;
  const body = document.querySelector('body');
  const scrollTotal = rootElement.scrollHeight - rootElement.clientHeight;

  rootElement.style.setProperty('--arrow-background-color', colorBckg);
  rootElement.style.setProperty('--arrow-background-hover', colorBckgHover);
  rootElement.style.setProperty('--arrow-color', colorArrow);

  const arrowContainer = document.createElement('div');
  arrowContainer.classList.add('arrow-container');
  //arrowContainer.href = '#';
  body.append(arrowContainer);

  const backArrow = document.createElement('span');
  backArrow.classList.add('arrow');
  arrowContainer.appendChild(backArrow);

  arrowContainer.addEventListener('click', () => {
    rootElement.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  });

  document.addEventListener('scroll', () => {
    if (rootElement.scrollTop / scrollTotal > depth) {
      arrowContainer.classList.contains('hide')
        ? arrowContainer.classList.replace('hide', 'show')
        : arrowContainer.classList.add('show');
    } else {
      arrowContainer.classList.replace('show', 'hide');
    }
  });
};

export default backToTop;
