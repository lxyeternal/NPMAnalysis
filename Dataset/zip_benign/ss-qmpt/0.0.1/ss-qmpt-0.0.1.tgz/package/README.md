## 📖 Detailed overview

Этот компонент включает в себя несколько изображений, которые плавно сменяются.

## 🎬 Live Demo

[Live demo link](https://quarkly-ui-components.netlify.app/slidersimple/)

## ⚙️ Usage

Добавьте компонент на страницу и посмотрите как он работает в режиме превью.

### Заменить изображения

Чтобы заменить изображения, задайте новые значения для свойства `Image URLs`. Для удаления или добавления, воспользуйтесь соостветствующими кнопками «+»‎ или «-».‎

### Скорость смены слайдов

Для изменения скорости анимации, задайте новое значение свойству `Animation duration`. Значение задается в миллисекундах.

## 🧩 Components and Props

| Props Name           |   Type   |                 Description                  | Default | Example  |
| -------------------- | :------: | :------------------------------------------: | :-----: | :------: |
| Arrows color         | `string` |                Цвет стрелочек                | `#eee`  |  `#fff`  |
| Arrows opacity       | `number` |            Прозрачность стрелочек            | `0.75`  |   `1`    |
| Points color         | `string` |             Цвет точек навигации             | `#eee`  | `black`  |
| Points opacity       | `number` |         Прозрачность точек навигации         |  `0.5`  |  `0.7`   |
| Height of the slider | `string` | Высота слайдера (процент от ширины слайдера) | `6.65%` | `420px` |
| Animation duration   | `number` |   Продолжительность перехода слайда (в мс)   | `1000`  |  `2000`  |
| Image URLs           | `union`  |            Ссылки на изображения             |  `[]`   |   `[]`   |

## 🗓 Changelog

- 16/03/2021 (v1.0)
  - Первая версия

## 📮 Feedback

If you encountered a bug, please contact us so we can fix it promptly. We’re rapidly developing, so don’t hesitate to send us your feedback and request new features you can’t stand missing. Feel free to share what you’re working on - we **love** to see what you’re building with Quarkly!

[Help with components](https://feedback.quarkly.io/communities/1-quarkly-forum/categories/7-components/topics)
[We're on Discord](https://discord.gg/f9KhSMGX)
[Our Twitter](https://twitter.com/quarklyapp)
[dev@quarkly.io](mailto:dev@quarkly.io)

## 📝 License

Licensed under the [MIT License](./LICENSE).
