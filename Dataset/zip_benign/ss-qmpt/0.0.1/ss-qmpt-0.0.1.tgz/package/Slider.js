"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _react = _interopRequireWildcard(require("react"));

var _atomize = _interopRequireDefault(require("@quarkly/atomize"));

var _components = require("@quarkly/components");

var _widgets = require("@quarkly/widgets");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var overrides = {
  'Arrow prev icon': {
    kind: 'Icon',
    props: {
      size: '52px',
      category: 'md',
      icon: 'MdKeyboardArrowLeft'
    }
  },
  'Arrow next icon': {
    kind: 'Icon',
    props: {
      size: '52px',
      category: 'md',
      icon: 'MdKeyboardArrowRight'
    }
  }
};

var Image = _atomize["default"].img(); // Get slide position


var getSide = function getSide(numb, opts) {
  var side = 0;

  if (numb > opts.active) {
    side = 1;
  }

  if (numb < opts.active) {
    side = -1;
  }

  if (numb === 1 && opts.active === opts.length) {
    side = 1;
  }

  if (opts.active === 1 && numb === opts.length) {
    side = -1;
  }

  if (opts.length === 1) {
    side = 0;
  }

  console.log(numb, opts);
  return side;
};

var Slide = function Slide(_ref) {
  var src = _ref.src,
      numb = _ref.numb,
      height = _ref.height,
      duration = _ref.duration,
      opts = _ref.opts;
  var isTarget = (0, _react.useMemo)(function () {
    return numb === opts.target;
  }, [numb, opts.target]);
  var isActive = (0, _react.useMemo)(function () {
    return numb === opts.active;
  }, [numb, opts.active]);
  var position = (0, _react.useMemo)(function () {
    if (isTarget && !isActive) {
      return '0';
    }

    if (isActive && !isTarget) {
      return -1 * getSide(opts.target, opts) * 100;
    }

    return getSide(numb, opts) * 100;
  }, [numb, opts]);
  return /*#__PURE__*/_react["default"].createElement(_widgets.Box, {
    left: "0",
    "padding-top": height,
    width: "100%",
    "margin-right": "-100%",
    "box-sizing": "border-box",
    "user-select": "none",
    position: "relative",
    display: "inline-block",
    overflow: "hidden",
    transition: "all ".concat(isActive || isTarget ? duration : 0, "ms ease"),
    transform: "translateX(".concat(position, "%)"),
    "z-index": isActive ? '3' : isTarget ? '2' : '1'
  }, /*#__PURE__*/_react["default"].createElement(Image, {
    src: src,
    top: "0",
    width: "100%",
    "min-heigh": "100%",
    "box-sizing": "border-box",
    "user-select": "none",
    position: "absolute",
    display: "block"
  }));
};

var Arrow = function Arrow(_ref2) {
  var type = _ref2.type,
      color = _ref2.color,
      alpha = _ref2.alpha,
      click = _ref2.click,
      override = _ref2.override;
  return /*#__PURE__*/_react["default"].createElement(_widgets.Box, _extends({
    top: "0",
    left: type === 'prev' ? '0' : 'auto',
    right: type === 'next' ? '0' : 'auto',
    width: "33%",
    "min-width": "5rem",
    height: "100%",
    transition: "opacity .3s ease",
    "pointer-events": "all",
    position: "absolute",
    cursor: "pointer",
    opacity: alpha,
    "z-index": "5",
    background: "\n        linear-gradient(\n          to ".concat(type === 'prev' ? 'right' : 'left', ",\n          rgba(0,0,0,0.25) 0,\n          rgba(0,0,0,0) 100%)\n          rgba(0,0,0,0)\n      "),
    "align-items": "center",
    "justify-content": type === 'prev' ? 'flex-start' : 'flex-end',
    display: "flex",
    "hover-opacity": "1",
    onClick: click
  }, override("Arrow ".concat(type))), /*#__PURE__*/_react["default"].createElement(_widgets.Icon, _extends({
    color: color || '#EEEEEE'
  }, override("Arrow ".concat(type, " icon")))));
};

var Point = function Point(_ref3) {
  var numb = _ref3.numb,
      color = _ref3.color,
      alpha = _ref3.alpha,
      opts = _ref3.opts,
      click = _ref3.click,
      override = _ref3.override;
  var isTarget = (0, _react.useMemo)(function () {
    return numb === opts.target;
  }, [numb, opts.target]);
  return /*#__PURE__*/_react["default"].createElement(_widgets.Box, _extends({
    margin: "0",
    width: "1rem",
    height: "1rem",
    border: "none",
    outline: "0",
    transition: "opacity .3s ease",
    "pointer-events": "all",
    "box-sizing": "border-box",
    "user-select": "none",
    position: "relative",
    display: "block",
    cursor: "pointer",
    opacity: isTarget ? '1' : alpha,
    "hover-opacity": "1",
    onClick: click
  }, override("Point ".concat(numb))), /*#__PURE__*/_react["default"].createElement(_widgets.Box, _extends({
    top: "calc(50% - .5rem)",
    left: "calc(50% - .5rem)",
    width: ".75rem",
    height: ".75rem",
    "min-width": "0",
    "min-height": "0",
    "border-radius": "50%",
    background: color || '#EEEEEE',
    transition: "background .2s ease, transform .2s ease",
    transform: "scale(".concat(isTarget ? 1 : 0.625, ")"),
    position: "absolute",
    display: "block"
  }, override("Point ".concat(numb, " dot")))));
};

var Slider = function Slider(_ref4) {
  var slides = _ref4.slides,
      height = _ref4.height,
      duration = _ref4.duration,
      colorArrows = _ref4.colorArrows,
      alphaArrows = _ref4.alphaArrows,
      colorPoints = _ref4.colorPoints,
      alphaPoints = _ref4.alphaPoints,
      props = _objectWithoutProperties(_ref4, ["slides", "height", "duration", "colorArrows", "alphaArrows", "colorPoints", "alphaPoints"]);

  var _useOverrides = (0, _components.useOverrides)(props, overrides),
      override = _useOverrides.override,
      rest = _useOverrides.rest;

  var _useState = (0, _react.useState)(slides.length > 0 ? slides.split(',').reverse() : []),
      _useState2 = _slicedToArray(_useState, 1),
      srcs = _useState2[0];

  var _useState3 = (0, _react.useState)(1),
      _useState4 = _slicedToArray(_useState3, 2),
      active = _useState4[0],
      setActive = _useState4[1];

  var _useState5 = (0, _react.useState)(1),
      _useState6 = _slicedToArray(_useState5, 2),
      target = _useState6[0],
      setTarget = _useState6[1];

  var _useState7 = (0, _react.useState)(false),
      _useState8 = _slicedToArray(_useState7, 2),
      isSwitch = _useState8[0],
      setSwitch = _useState8[1]; // Switch active slide


  (0, _react.useEffect)(function () {
    if (!isSwitch) return;
    setTimeout(function () {
      setActive(target);
      setSwitch(false);
    }, duration);
  }); // Click on 'prev' arrow

  var slidePrev = function slidePrev() {
    if (isSwitch) return;
    setTarget(target <= 1 ? srcs.length : active - 1);
    setSwitch(true);
  }; // Click on 'next' arrow


  var slideNext = function slideNext() {
    if (isSwitch) return;
    setTarget(target >= srcs.length ? 1 : active + 1);
    setSwitch(true);
  }; // Click on point


  var clickNumb = function clickNumb(numb) {
    if (isSwitch) return;
    setTarget(numb);
    setSwitch(true);
  };

  var touchStartX, touchStartY; // Start swipe on mobile

  var touchStart = function touchStart(e) {
    touchStartX = e.targetTouches[0].clientX;
    touchStartY = e.targetTouches[0].clientY;
  }; // Stop swipe and fire event


  var touchEnd = function touchEnd(e) {
    if (!touchStartX || !touchStartY) return;
    var touchEndX = e.changedTouches[0].clientX,
        touchEndY = e.changedTouches[0].clientY,
        diffX = Math.abs(touchEndX - touchStartX),
        diffY = Math.abs(touchEndY - touchStartY),
        diffP = diffX / e.target.offsetWidth;
    if (diffX < diffY || diffP < .1) return;

    if (touchStartX > touchEndX) {
      slideNext();
    } else {
      slidePrev();
    }
  };

  return /*#__PURE__*/_react["default"].createElement(_widgets.Box, _extends({}, rest, {
    position: "relative"
  }), /*#__PURE__*/_react["default"].createElement(_widgets.Box, {
    width: "100%",
    position: "relative",
    display: "flex",
    overflow: "hidden"
  }, srcs.map(function (src, i) {
    return /*#__PURE__*/_react["default"].createElement(Slide, {
      key: i,
      src: src,
      numb: i + 1,
      height: height,
      duration: duration,
      opts: {
        active: active,
        target: target,
        length: srcs.length
      }
    });
  })), /*#__PURE__*/_react["default"].createElement(_widgets.Box, {
    top: "0",
    left: "0",
    width: "100%",
    height: "100%",
    "box-sizing": "border-box",
    "user-select": "none",
    position: "absolute",
    onTouchStart: function onTouchStart(e) {
      return touchStart(e);
    },
    onTouchEnd: function onTouchEnd(e) {
      return touchEnd(e);
    }
  }, /*#__PURE__*/_react["default"].createElement(Arrow, {
    type: "prev",
    click: function click() {
      return slidePrev();
    },
    color: colorArrows,
    alpha: alphaArrows,
    override: override
  }), /*#__PURE__*/_react["default"].createElement(Arrow, {
    type: "next",
    click: function click() {
      return slideNext();
    },
    color: colorArrows,
    alpha: alphaArrows,
    override: override
  })), /*#__PURE__*/_react["default"].createElement(_widgets.Box, _extends({
    bottom: ".5rem",
    left: "0",
    width: "100%",
    height: "1.5rem",
    "align-content": "center",
    "justify-content": "center",
    "pointer-events": "none",
    "box-sizing": "border-box",
    "user-select": "none",
    position: "absolute",
    display: "flex",
    "z-index": "6"
  }, override('Points')), srcs.map(function (src, i) {
    return /*#__PURE__*/_react["default"].createElement(Point, {
      key: i,
      numb: i + 1,
      click: function click() {
        return clickNumb(i + 1);
      },
      color: colorPoints,
      alpha: alphaPoints,
      opts: {
        target: target
      },
      override: override
    });
  })));
};

var propInfo = {
  slides: {
    title: 'Image URLs',
    multiply: true,
    control: 'image',
    type: 'string',
    category: 'Slides',
    weight: 1
  },
  height: {
    title: 'Height of the slider',
    control: 'text',
    type: 'string',
    category: 'Slider',
    weight: 1
  },
  duration: {
    title: 'Animation duration',
    control: 'text',
    type: 'string',
    category: 'Slider',
    weight: 1
  },
  colorArrows: {
    title: 'Arrows color',
    control: 'color',
    type: 'string',
    category: 'Color',
    weight: .67
  },
  alphaArrows: {
    title: 'Opacity',
    control: 'text',
    type: 'string',
    category: 'Color',
    weight: .33
  },
  colorPoints: {
    title: 'Points color',
    control: 'color',
    type: 'string',
    category: 'Color',
    weight: .67
  },
  alphaPoints: {
    title: 'Opacity',
    control: 'text',
    type: 'string',
    category: 'Color',
    weight: .33
  }
};
var defaultProps = {
  slides: "\nhttps://images.pexels.com/photos/757183/pexels-photo-757183.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260,\nhttps://images.pexels.com/photos/803940/pexels-photo-803940.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260,\nhttps://images.pexels.com/photos/1045922/pexels-photo-1045922.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260,\nhttps://images.pexels.com/photos/1586154/pexels-photo-1586154.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260\n  ",
  height: '62.5%',
  duration: 1000,
  colorArrows: '#EEEEEE',
  colorPoints: '#EEEEEE',
  alphaArrows: '.75',
  alphaPoints: '.5'
};

var _default = Object.assign(Slider, {
  title: 'Slider',
  description: {
    en: 'Awesome swipe slider!'
  },
  overrides: overrides,
  propInfo: propInfo,
  defaultProps: defaultProps
});

exports["default"] = _default;