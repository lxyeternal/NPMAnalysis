export * from "./TechRadar";
