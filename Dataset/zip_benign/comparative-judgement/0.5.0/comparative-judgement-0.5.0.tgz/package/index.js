/* jshint -W024, expr:true */
/*jslint node: true */
/*global expect, fx, sinon*/
'use strict';

module.exports = {
    statutils : require('./lib/statutils'),
    estimation : require('./lib/estimation'),
    selection : require('./lib/selection'),
    simulation: require('./lib/simulation'),
    random: require('./lib/random'),
    btm: require('./lib/btm'),
    pearson: require('./lib/pearson'),
    interRater: require('./lib/interRater')
};

var simulation = require('./lib/simulation');
var byjudge = require('./lib/byjudge');
var program = require('commander');
var interRater = require('./lib/interRater');
var csvEstimation = require('./lib/csvEstimation');
var readCsv = require('./lib/readCsv');

program
  .version('0.0.1')
  .option('-c, --csvestimate', 'Estimate model from csv')
  .option('-f, --fixedplayers [character]', 'Fix player estimates')
  .option('-r, --inter', 'Inter-rater reliability')
  .option('-b, --byjudge', 'Analyse by judge')
  .option('-d, --decisions [integer]', 'Csv file with decisions')
  .option('-s --simulate', 'Simulate a judging session')
  .option('-i --iters [integer]', 'Number of iterations to simulate')
  .option('-p --players [integer]', 'Number of players to simulate')
  .option('-j --judgements [integer]', 'Number of judgements to simulate in total')
  .option('--selection [string]', 'Script selection method')
  .option('-t --thru [integer]', 'Number of decisions expected per script - adaptive methods only')
  .option('--ap [float]', 'Acceleration parameter - adaptive methods only')
  .option('--seed [integer]', 'Seed value for random parameters, integer value eg. 1234')
  .option('-e --exclude <items>', 'Items / Judges to be excluded')
  .option('--offset [float]','Adaptive offset')
  .option('--rnd','Simulate a random judgement')
  .option('--meanTheta [float]', 'Mean theta')
  .option('--sdTheta [float]', 'SD theta')
  .parse(process.argv);

if(program.csvestimate) {
  if(!program.decisions) {
    console.log('please supply a decisions file');
  } else {
    var estimateFromCsv = csvEstimation.estimateFromCsv;
    var decisionsCsv = program.decisions;
    var anchorsCsv;
    if(program.fixedplayers){
      var anchorsCsv = program.fixedplayers;
    }
    estimateFromCsv(decisionsCsv, anchorsCsv, function(err, result){
      console.log(err, result);
    });
  }
}

if (program.simulate) {
  var sim = simulation.simulate;
  console.log('players: ',program.players, 'judgements: ',program.judgements, 'selection: ', program.selection, 'thru: ', program.thru, 'ap: ',program.ap, 'iters: ',program.iters,'seed: ', program.seed, 'offset: ', program.offset, 'mean: ',parseFloat(program.meanTheta),'sd: ',parseFloat(program.sdTheta));
  sim(program.players, program.judgements, program.selection, program.thru, program.ap, program.iters, program.seed, parseFloat(program.offset),program.rnd,parseFloat(program.meanTheta),parseFloat(program.sdTheta), function(result){
    console.log('saved ',result, ' rows');
  });
}

if(program.inter) {
  var excluded =[];
  if (program.exclude){
    excluded = (program.exclude.split(','));
  }
  readCsv.irCsv(program.iters, program.decisions, excluded, function(err, msg){
    if(err) console.log(err);
    console.log(msg);
  });
}

if(program.byjudge){
  var excluded = (program.exclude.split(','));
  byjudge.estimateByJudge(program.decisions, excluded,function(err, msg){
    if(err) console.log(err);
    console.log(msg);
  });
}