export type RestFunc = <T>(...args: T[]) => void;
export declare function throttle<T extends RestFunc>(func: T, time?: number, immediate?: boolean): (this: unknown, ...args: Parameters<T>) => void;
export declare function RAFThrottle<T extends RestFunc>(func: T): (this: unknown, ...args: Parameters<T>) => void;
export declare const BSStartIndex: (arr: number[], num: number) => number;
