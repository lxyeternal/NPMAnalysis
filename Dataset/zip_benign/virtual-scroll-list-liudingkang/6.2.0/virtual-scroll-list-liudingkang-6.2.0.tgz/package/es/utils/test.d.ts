import { type ComponentMountingOptions } from '@vue/test-utils';
import type { ComponentProps } from 'vue-component-type-helpers';
import type { Component } from 'vue';
export declare const delay: (time?: number) => Promise<unknown>;
export declare const trigger: (target: HTMLElement, type: string) => Promise<void>;
export declare const triggerScrollTo: (target: HTMLElement, x?: number, y?: number) => Promise<void>;
export declare const prevMount: <T extends Component>(wrapper: Component, component: T) => (option: ComponentMountingOptions<T, ComponentProps<T>> | undefined) => import("@vue/test-utils").VueWrapper<ComponentProps<T> & (T extends {
    data?(...args: any): infer D;
} ? D : {}) & import("vue-component-type-helpers").ComponentExposed<T>, import("vue").ComponentPublicInstance<ComponentProps<T>, (T extends {
    data?(...args: any): infer D;
} ? D : {}) & import("vue-component-type-helpers").ComponentExposed<T> & Omit<ComponentProps<T>, keyof ComponentProps<T>>>>;
