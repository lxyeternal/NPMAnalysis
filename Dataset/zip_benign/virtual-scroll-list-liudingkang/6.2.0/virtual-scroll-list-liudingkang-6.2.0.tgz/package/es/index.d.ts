import type { Component } from 'vue';
export declare const components: Component[];
export declare const install: (app: unknown) => void;
export * from './packages/fixed-size-list';
export * from './packages/dynamic-list';
declare const _default: {
    install: (app: unknown) => void;
};
export default _default;
