import { type Ref } from 'vue';
export declare const useResizeObserver: (name: string | undefined, cb: ResizeObserverCallback) => void;
export declare const useResizeObserve: (name: string | undefined, targetRef: Ref<HTMLDivElement | null>) => void;
