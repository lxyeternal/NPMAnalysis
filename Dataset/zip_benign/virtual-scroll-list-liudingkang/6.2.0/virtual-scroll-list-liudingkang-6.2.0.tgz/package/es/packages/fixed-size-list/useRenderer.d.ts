import type { FixedSizeListProps } from '../fixed-size-list/props';
export interface ListItemPosition {
    top: number;
    height: number;
    index: number;
}
export declare const useRenderer: (props: FixedSizeListProps) => {
    positions: {
        top: number;
        height: number;
        index: number;
    }[];
    containerStyle: import("vue").ComputedRef<{
        width: string;
        height: string;
    }>;
    listStyle: import("vue").ComputedRef<{
        width: string;
        height: string;
    }>;
    renderData: import("vue").ComputedRef<{
        itemData: import("../list-item/props").ListItemData;
        top: number;
        height: number;
        index: number;
    }[]>;
    cacheStart: import("vue").Ref<number>;
    start: import("vue").Ref<number>;
    end: import("vue").Ref<number>;
    cacheEnd: import("vue").Ref<number>;
};
