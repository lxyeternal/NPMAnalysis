import type { ListItemPosition } from '../fixed-size-list/useRenderer';
export declare const useRO: (positions: ListItemPosition[]) => void;
