import type { FixedSizeListEmits, FixedSizeListProps } from '../fixed-size-list/props';
export declare const useScroller: (props: FixedSizeListProps, emits: FixedSizeListEmits) => {
    scrollTop: import("vue").Ref<number>;
    scrollHandler: (this: unknown, ...args: unknown[]) => void;
    scrollEndHandler: ({ target }: Event) => void;
};
