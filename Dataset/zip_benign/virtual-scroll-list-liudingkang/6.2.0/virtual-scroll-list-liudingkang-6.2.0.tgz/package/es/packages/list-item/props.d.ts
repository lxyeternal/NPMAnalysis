import type { ExtractPropTypes, PropType } from 'vue';
import type { AnyObject } from '../../utils';
export type ListItemData = AnyObject | number | string;
export declare const listItemProps: {
    itemClass: StringConstructor;
    itemData: PropType<ListItemData>;
    itemIndex: {
        type: NumberConstructor;
        default: number;
    };
};
export type ListItemProps = ExtractPropTypes<typeof listItemProps>;
