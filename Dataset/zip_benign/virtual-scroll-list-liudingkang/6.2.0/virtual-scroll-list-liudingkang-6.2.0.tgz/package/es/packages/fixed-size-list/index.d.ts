export declare const FixedSizeList: import("../../utils").WithInstall<{
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        itemSize: {
            type: NumberConstructor;
            default: number;
        };
        itemClass: StringConstructor;
        itemKey: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
        data: {
            type: import("vue").PropType<import("../list-item/props").ListItemData[]>;
            default: () => never[];
        };
        width: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
        height: {
            type: NumberConstructor;
            default: number;
        };
        cache: {
            type: NumberConstructor;
            default: number;
        };
        distance: {
            type: NumberConstructor;
            default: number;
        };
    }>> & {
        onLoad?: (() => any) | undefined;
    }, {}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        load: () => void;
    }, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        itemSize: {
            type: NumberConstructor;
            default: number;
        };
        itemClass: StringConstructor;
        itemKey: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
        data: {
            type: import("vue").PropType<import("../list-item/props").ListItemData[]>;
            default: () => never[];
        };
        width: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
        height: {
            type: NumberConstructor;
            default: number;
        };
        cache: {
            type: NumberConstructor;
            default: number;
        };
        distance: {
            type: NumberConstructor;
            default: number;
        };
    }>> & {
        onLoad?: (() => any) | undefined;
    }, {
        data: import("../list-item/props").ListItemData[];
        itemSize: number;
        itemKey: string | number;
        width: string | number;
        height: number;
        cache: number;
        distance: number;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        itemSize: {
            type: NumberConstructor;
            default: number;
        };
        itemClass: StringConstructor;
        itemKey: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
        data: {
            type: import("vue").PropType<import("../list-item/props").ListItemData[]>;
            default: () => never[];
        };
        width: {
            type: (StringConstructor | NumberConstructor)[];
            default: string;
        };
        height: {
            type: NumberConstructor;
            default: number;
        };
        cache: {
            type: NumberConstructor;
            default: number;
        };
        distance: {
            type: NumberConstructor;
            default: number;
        };
    }>> & {
        onLoad?: (() => any) | undefined;
    }, {}, {}, {}, {}, {
        data: import("../list-item/props").ListItemData[];
        itemSize: number;
        itemKey: string | number;
        width: string | number;
        height: number;
        cache: number;
        distance: number;
    }>;
    __isFragment?: undefined;
    __isTeleport?: undefined;
    __isSuspense?: undefined;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    itemSize: {
        type: NumberConstructor;
        default: number;
    };
    itemClass: StringConstructor;
    itemKey: {
        type: (StringConstructor | NumberConstructor)[];
        default: string;
    };
    data: {
        type: import("vue").PropType<import("../list-item/props").ListItemData[]>;
        default: () => never[];
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
        default: string;
    };
    height: {
        type: NumberConstructor;
        default: number;
    };
    cache: {
        type: NumberConstructor;
        default: number;
    };
    distance: {
        type: NumberConstructor;
        default: number;
    };
}>> & {
    onLoad?: (() => any) | undefined;
}, {}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    load: () => void;
}, string, {
    data: import("../list-item/props").ListItemData[];
    itemSize: number;
    itemKey: string | number;
    width: string | number;
    height: number;
    cache: number;
    distance: number;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        default?(_: {
            item: import("../list-item/props").ListItemData | undefined;
            index: number;
        }): any;
    };
})>;
export default FixedSizeList;
declare module 'vue' {
    interface GlobalComponents {
        LdkFixedSizeList: typeof FixedSizeList;
    }
}
