export declare const ListItem: import("../../utils").WithInstall<{
    new (...args: any[]): import("vue").CreateComponentPublicInstance<Readonly<import("vue").ExtractPropTypes<{
        itemClass: StringConstructor;
        itemData: import("vue").PropType<import("./props").ListItemData>;
        itemIndex: {
            type: NumberConstructor;
            default: number;
        };
    }>>, {}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & Readonly<import("vue").ExtractPropTypes<{
        itemClass: StringConstructor;
        itemData: import("vue").PropType<import("./props").ListItemData>;
        itemIndex: {
            type: NumberConstructor;
            default: number;
        };
    }>>, {
        itemIndex: number;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        itemClass: StringConstructor;
        itemData: import("vue").PropType<import("./props").ListItemData>;
        itemIndex: {
            type: NumberConstructor;
            default: number;
        };
    }>>, {}, {}, {}, {}, {
        itemIndex: number;
    }>;
    __isFragment?: undefined;
    __isTeleport?: undefined;
    __isSuspense?: undefined;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    itemClass: StringConstructor;
    itemData: import("vue").PropType<import("./props").ListItemData>;
    itemIndex: {
        type: NumberConstructor;
        default: number;
    };
}>>, {}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    itemIndex: number;
}, {}, string, {}> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        default?(_: {
            item: import("./props").ListItemData | undefined;
            index: number;
        }): any;
    };
})>;
export default ListItem;
declare module 'vue' {
    interface GlobalComponents {
        LdkListItem: typeof ListItem;
    }
}
