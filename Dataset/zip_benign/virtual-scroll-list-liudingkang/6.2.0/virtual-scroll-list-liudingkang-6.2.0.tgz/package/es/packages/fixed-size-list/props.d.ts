import { type ExtractPropTypes, type PropType } from 'vue';
import type { ListItemData } from '../list-item/props';
export declare const fixedSizeListProps: {
    itemSize: {
        type: NumberConstructor;
        default: number;
    };
    itemClass: StringConstructor;
    itemKey: {
        type: (StringConstructor | NumberConstructor)[];
        default: string;
    };
    data: {
        type: PropType<ListItemData[]>;
        default: () => never[];
    };
    width: {
        type: (StringConstructor | NumberConstructor)[];
        default: string;
    };
    height: {
        type: NumberConstructor;
        default: number;
    };
    cache: {
        type: NumberConstructor;
        default: number;
    };
    distance: {
        type: NumberConstructor;
        default: number;
    };
};
export type FixedSizeListProps = ExtractPropTypes<typeof fixedSizeListProps>;
export interface FixedSizeListEmits {
    (e: 'load'): void;
}
