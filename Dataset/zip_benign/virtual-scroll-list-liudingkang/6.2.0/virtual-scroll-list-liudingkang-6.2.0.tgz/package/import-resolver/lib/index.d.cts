interface LdkResolverOptions {
    /**
     * import components css
     *
     * @default true
     */
    importStyle?: boolean;
    /**
     * cjs module
     *
     * @default false
     */
    cjs?: boolean;
}
declare function LdkResolver(options?: LdkResolverOptions): {
    type: "component";
    resolve: (name: string) => {
        name: string;
        from: string;
        sideEffects: string | undefined;
    } | undefined;
};

export { LdkResolver, type LdkResolverOptions };
