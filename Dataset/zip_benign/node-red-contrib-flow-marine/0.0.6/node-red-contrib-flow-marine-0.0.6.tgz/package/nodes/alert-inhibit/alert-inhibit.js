module.exports = function(RED) {
    function Inhibit(config) {
        RED.nodes.createNode(this,config);

        this.threshold = config.threshold;
        this.triggersHigh = config.triggersHigh;
        
        var node = this;
        this.on('input', function(msg) {
            try
            {
                var value = msg.payload.hasOwnProperty('value') ? msg.payload.value : msg.payload;
                
                // console.log(RED._("checking whether inhibited for value: ") + value );
                var inhibit;
                switch(typeof(value))
                {
                    case 'boolean':
                        inhibit = value && node.triggersHigh || (!value && !node.triggersHigh);
                        break;
                    case 'number':
                        inhibit = node.triggersHigh ? value >= node.threshold : value <= node.threshold;
                        break;
                    default:
                        throw "Invalid value type: " + typeof(value);
                }

                // console.log(RED._("inhibit: " + inhibit));
                
                // Only send message if state has changed
                var context = node.context();
                // console.log(RED._("getting last inhibit state"));
                var lastState = context.get('lastState');
                if( lastState === null || inhibit != lastState)
                {
                    console.log(RED._("setting new inhibit state: " + inhibit));
                    
                    msg.payload = inhibit;
                    msg.topic = 'inhibit';
                    // console.log(RED._("Sending inhibit message: " + inhibit));
                    node.send(msg);
                    context.set('lastState', inhibit);
                }
                node.status({fill:"green",shape:"dot",text:"good"});
            }
            catch(err)
            {
                console.log(RED._(err));
                node.status({fill:"red",shape:"ring",text:err});                
            }
        });
    }
    RED.nodes.registerType("fm-alert-inhibit",Inhibit);
}