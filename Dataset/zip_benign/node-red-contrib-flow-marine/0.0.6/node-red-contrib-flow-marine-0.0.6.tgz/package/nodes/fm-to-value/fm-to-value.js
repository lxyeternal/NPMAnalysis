module.exports = function(RED) {
    function ToValue(config) {
        RED.nodes.createNode(this,config);
        
        var node = this;
        this.on('input', function(msg) {
            if( msg.payload.hasOwnProperty('value'))
            {
                msg.payload = msg.payload.value;
            }        
            node.send(msg);
        });
    }
    RED.nodes.registerType("fm-to-value",ToValue);
}