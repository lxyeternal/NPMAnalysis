module.exports = function(RED) {
    function FMAlert(config) {
        RED.nodes.createNode(this,config);
        
        this.threshold = config.threshold;
        this.triggersHigh = config.triggersHigh;
        this.alertType = config.alertType;
        this.alertCategory = config.alertCategory;
        this.delay = config.delay;
        this.deadband = config.deadband;
        this.requiresAck = config.requiresAck;
        this.disable = config.disable;
        this.debug = config.debug;
        

        var node = this;

        function Trace(val)
        {
            if( node.debug)
            {
                console.log(RED._(val));
            }            
        }

        function ProcessAck()
        {
            var context = node.context();
            var lastState = context.get('lastState');

            Trace(("Ack received"));
            switch( lastState  )
            {
                case 'active':
                    UpdateState( 'acknowledged');
                    break;
                case 'returned':
                    UpdateState( 'normal');
                    
            }
            return;
        }

        function UpdateState(state)
        {
            // Trace(("UpdateState invoked for state: " + state));
            var context = node.context();
            var lastState = context.get('lastState');
            if( state != lastState )
            {
                Trace(("Setting new state to: " + state ));
                
                var msg = { payload: { state:state } };
                node.send(msg);
                context.set('lastState', state )
            }
        }

        function IsTriggered( msg)
        {
            var context = node.context();

            // Setting and getting these so we can get back to them between trigger/inhibit messages
            // Is this actually necessary?
            var trigger = context.get('trigger');
            var inhibit = context.get('inhibit') || false;

            // Trace(("Checking for inhibit or channel"));
            var topic = msg.topic ? msg.topic : 'channel';

            switch( topic)
            {
                case 'inhibit':
                    Trace(("Inhibit received"));
                    inhibit = msg.payload;
                    context.set('inhibit', inhibit);
                    break;
                case 'channel':
                default:                    
                    trigger = msg.payload.hasOwnProperty('value') ? msg.payload.value : msg.payload;
                    Trace(("Channel received,  trigger value = " + trigger ));
                    context.set('trigger', trigger);
                    break;
            }

            if( inhibit )
            {
                return false;
            }
            else if( trigger === null )
            {
                throw "Trigger value is null"
                // We could CancelTriggerTimer here but let's not as a policy
            }
            else
            {
                // Trace(("checking whether triggered"));
                var triggered;
                if( inhibit )
                {
                    triggered = false;
                }
                else
                {
                    switch(typeof(trigger))
                    {
                        case 'boolean':
                            triggered = trigger && node.triggersHigh || (!trigger && !node.triggersHigh);
                            break;
                        case 'number':
                            // Trace(("it's a number"));
                            var lastState = context.get('lastState')
                            var bUseDeadband = lastState == 'active' || lastState == 'acknowledged';
                            if( node.triggersHigh)
                            {
                                // Trace(("triggers high"));
                                var adjustedThreshold = bUseDeadband ? node.threshold - node.deadband : node.threshold;
                                triggered = trigger >= adjustedThreshold;
                            }
                            else
                            {
                                var adjustedThreshold = bUseDeadband ? node.threshold + node.deadband : node.threshold;
                                triggered = trigger <= adjustedThreshold;
                                Trace(("triggers low, trigger: " + trigger + ", threshold: " +node.threshold + ", deadband: " + node.deadband + ", adjustedThreshold: " + adjustedThreshold + ", triggered: " + triggered ));
                            }
                            break;
                        default:
                            throw "Invalid trigger type: " + typeof(trigger);
                    }
                }
                return triggered;
            }
        }

        function ProcessTriggered( )
        {
            
            Trace(("Triggered!!!"));
            var context = node.context();
            var lastState = context.get('lastState');
            switch( lastState )
            {
                case 'returned':
                    Trace(("current state returned - going active"));
                    UpdateState( 'active')
                    break;
                case 'triggered':
                    // Do nothing - we assume the timer has already been set
                    break;
                case 'active':
                    // Do nothing - we want it to stay active
                    break;
                case 'acknowledged':
                    // do nothing - we want it stay acknowledged
                    break;
                case 'normal':
                default:
                    if( !node.delay || node.delay <= 0 )
                    {
                        Trace(("No Delay set, going active"));
                        UpdateState( "active" );
                    }
                    else 
                    {
                        Trace(("Delay set: going to triggered"));
                        UpdateState( "triggered" );
                        StartTriggerTimer(node);
                    }
                    break;
            }
        }

        function ProcessNotTriggered()
        {
            Trace(("NOT triggered"));            
            var context = node.context();
            var lastState = context.get('lastState');
            CancelTriggerTimer(node);
            UpdateState( ( (lastState == 'active' || lastState == 'returned') && node.requiresAck ) ? 'returned' : 'normal' );
        }

        function StartTriggerTimer()
        {
            context = node.context();
            Trace("Starting timer for " + node.delay + " s")
            var triggerTimer = setTimeout(function(){
                Trace("Timer expired, going active:")
                UpdateState( "active");
                context.set('triggerTimer', null);
            }, node.delay * 1000 );

            context.set('triggerTimer', triggerTimer);
        }

        function CancelTriggerTimer()
        {
            var context = node.context();
            // Cancel the trigger timer
            var triggerTimer = context.get('triggerTimer');
            if( triggerTimer )
            {
                Trace("Cancelling timer")
                clearTimeout(triggerTimer);
                context.set('triggerTimer', null);
            }
        }

        function ProcessNotDisabled(msg)
        {
            var topic = msg.topic ? msg.topic : 'channel';
            var context = node.context();
            var lastState = context.get('state');

            // First deal with any acknowledge message
            if( topic == 'ack' )
            {
                ProcessAck(node);
            }
            else
            {
                if( IsTriggered( msg) )
                {   
                    ProcessTriggered(msg );
                }
                else
                {
                    ProcessNotTriggered(msg)
                }
            }

        // node.status({fill:"green",shape:"dot",text:"good"});

        }
        
        this.on('input', function(msg) {
            try
            {
                if(  node.disable )
                {                    
                    UpdateState( 'normal');
                    CancelTriggerTimer(node);                    
                }
                else
                {          
                    ProcessNotDisabled( msg)
                }      

            }
            catch(err)
            {
                Trace((err));
                // node.status({fill:"red",shape:"ring",text:err});
                UpdateState( 'unknown');
            }
            
       });
    }
    RED.nodes.registerType("fm-alert",FMAlert);
}