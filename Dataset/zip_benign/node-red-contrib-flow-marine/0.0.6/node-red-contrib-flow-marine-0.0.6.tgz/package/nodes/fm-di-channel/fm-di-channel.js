module.exports = function(RED) {
    function DIChannel(config) {
        RED.nodes.createNode(this,config);
        
        this.wordoffset = config.wordoffset;
        this.bitoffset = config.bitoffset;
        this.invert = config.invert;

        var node = this;
        this.on('input', function(msg) {
            try
            {
                var arr = msg.payload; 
                if (!(arr.constructor === Array))
                {
                    throw "Message input not an array"
                }
                if( node.wordoffset >= arr.length )
                {
                    throw "Array too short"
                }
                if( node.bitoffset > 15 || node.bitoffset < 0 )
                {
                    throw "Bitoffset out of range"
                }
                var wordval = arr[node.wordoffset];
                /*
                if( isNaN(wordval) || (parseFloat(wordval) | 0 !== wordval) )
                {
                    throw "Array value not a word";
                }
                */
                var bitval = (wordval & (1 << node.bitoffset))>0 ? true : false;
                
                if( node.invert )
                {
                    bitval = !bitval;
                }
                
                msg.payload= { value:bitval };
                this.status({fill:"green",shape:"dot",text:"good"});
                node.send(msg); 
            }
            catch(err)
            {
                this.status({fill:"red",shape:"ring",text:err});
            }
        });
    }
    RED.nodes.registerType("fm-di-channel",DIChannel);
}