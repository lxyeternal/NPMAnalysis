module.exports = function(RED) {
    function SineGenerator(config) {
        RED.nodes.createNode(this,config);
        
        this.period = config.period;
        this.max = parseFloat(config.max);  // No idea why I need this but it's coming in as a string
        this.min = parseFloat(config.min); // No idea why I need this but it's coming in as a string
        this.noMetadata = config.noMetadata;

        var node = this;
        this.on('input', function(msg) {
            // Assume a timestamp in milliseconds as input
            // var period = 5; // 5s period
            var ts = msg.payload;
            var val = ((Math.sin(ts/1000 * 2 * Math.PI/node.period )+1)/2 * (node.max-node.min)) + node.min;
            // console.log(RED._("SineGenerator types min: " + typeof(node.min) + ", max: " + typeof(node.max) + ", period: " + typeof(node.period)));
            if(node.noMetadata)
            {
                msg.payload = val;
            }
            else
            {
                msg.payload = { value:val };
                msg.payload.units = "mA";
            }
            node.send(msg);
        });
    }
    RED.nodes.registerType("sine-generator",SineGenerator);
}