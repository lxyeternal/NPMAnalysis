module.exports = function(RED) {    
    function Calibrator(config) {
        RED.nodes.createNode(this,config);

        // this.xyValues = config.xyValues;
        this.xyValues = [{x:4,y:0},{x:20,y:100}];  // Temp
        this.targetUnits = config.targetUnits;
        this.debug = config.debug;
        
        var node = this;
        this.on('input', function(msg) {
            try
            {
                var arr = node.xyValues;
                if( node.debug)
                {
                    console.log("time: " + new Date() )
                }

                // Possibly we shouldn't throw errors for outside range or null
                var value = msg.payload.hasOwnProperty('value') ? msg.payload.value : msg.payload;
                if( !(typeof(value) === 'number'))
                {
                    throw "Input value must be a number, not: " + value + " which is " + typeof(value) ;
                }
                if( value < arr[0] || value > arr[arr.length])
                {
                    throw "Input value outside calibration range";
                }
                 // console.log(RED._( "Scanning through array of length " + arr.length));
                /*
                for( var i=0; i<arr.length; i++)
                {
                    // console.log("Item " + i + ": " + arr[i]);
                    // console.log(RED._("x: " & arr[i].x + ", y: " + arr[i].y));
                }
                */
                
                msg.payload.value = null;
                for( var i= 1; i<arr.length; i++)
                {
                    // console.log(RED._("iteration " + i + "xyvalue: " + arr[i].toJSON()));
                    // console.log(RED._("Comparing value " + value + " with xval: " + arr[i].x));
                    if( value <= arr[i].x)
                    {
                        var x1 = arr[i-1].x;
                        var y1 = arr[i-1].y;
                        var x2 = arr[i].x;
                        var y2 = arr[i].y;
                        var y = y1 + (value-x1) * ((y2-y1)/(x2-x1));
                        // console.log(RED._("Matched! x: " + value + " + y: " + y));
                        msg.payload.value = y;
                        break;
                    }
                }
                
                msg.payload.units = node.targetUnits;                
                node.send(msg);
                // node.status({fill:"green",shape:"dot",text:"good"});
            }
            catch(err)
            {
                console.log(RED._(err));
                // node.status({fill:"red",shape:"ring",text:err});                
            }
        });
    }

    RED.nodes.registerType("fm-calibrator",Calibrator);

}