module.exports = function(RED) {
    function Acknowledge(config) {
        RED.nodes.createNode(this,config);
        
        var node = this;
        this.on('input', function(msg) {
            msg.topic = 'ack';
            node.send(msg);
        });
    }
    RED.nodes.registerType("fm-acknowledge",Acknowledge);
}