let connect = require('./connect')
let Schema = require('./Schema')
let Model = require('./Model')

module.exports = {connect,Schema,Model}