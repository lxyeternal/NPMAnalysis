class Schema {
   constructor(source={}) {
      this.source = source
      this.values = [
         'id INTEGER DEFAULT AUTO_INCREMENT PRIMARY KEY',
         'createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP'
      ]
      this.schema = {}
      this.keys = Object.keys(source)
      this.keys.forEach(key => {
         let params = source[key]
         let type = params.type.toLowerCase().trim()
         let text = ['array','json'] // 'date','boolean'
         if(text.includes(type)) type = 'text'
         this.values.push(`${key} ${type.toUpperCase()}${params.unique ? ' type UNIQUE' :''}`)
      })
   }

   presave(obj,model) {return obj}
   get(obj,model) {return obj}
   all(array,model) {return array}
   
   static genPassword(passwordLength=12,password = '') {
      let chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      for (let i = 0; i <= passwordLength; i++) {
         let randomNumber = Math.floor(Math.random() * chars.length);
         password += chars.substring(randomNumber, randomNumber +1);
      }
      return password
   }
   
   static genToken() {return require('crypto').randomBytes(64).toString('hex')}
}


module.exports = Schema