module.exports = function(dbName='db.sqlite',options={}) {
   // options = {verbose: console.log}
   const Database = require('better-sqlite3');
   const db = new Database(dbName, options);
   return db
}