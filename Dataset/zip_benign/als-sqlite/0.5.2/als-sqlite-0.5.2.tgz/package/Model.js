const bcrypt = require('bcryptjs')
let colors = require('colors')
let Schema = require('./Schema')
class Model {
   static migrate = false
   static restore = false
   static deleteMissing = true
   static models = {}
   static table(tableName,schema={},dev=false) {
      if(tableName && schema) {
         try {
            if(schema instanceof Schema == false) schema = new Schema(Schema)
         } catch (error) {
            if(dev) console.log(error)
            return null
         }
         let model = new Model(tableName,schema)
         
         try {
            model.migrate()
            return model
         } catch (error) {
            if(dev) console.log(error,model.query)
            return null
         }
      } else {
         if(dev) console.log('tableName or schema is missing')
         return null
      }
   }

   static cli() {
      const { argv } = require('process')
      let tableName = argv[argv.length-1]
      let model = this.models[tableName]
      if(model) {
         let result = colors.red('Nothing done')
         if(argv.includes('drop')) result = model.drop()
         else if(argv.includes('migrate')) result = model.migrate()
         else if(argv.includes('restore')) result = model.restore()
         console.log(colors.green(result))
      } //else console.log(colors.red('Table name doesnt exist'))
   }

   constructor(tableName,schema,db=Model.db) {
      this.tableName = tableName
      this.schema = schema
      this.schema.keys.push('id')
      this.schema.keys.push('createdAt')
      this.db = db
      if(Model.migrate) this.migrate()
      if(Model.restore) this.restore()
      Model.models[tableName] = this
      this.errors = []
   }

   migrate() {
      let query = `CREATE TABLE IF NOT EXISTS ${this.tableName} (${this.schema.values.join()})`
      let pr = this.db.prepare(query)
      return pr.run()
   }

   drop() {
      let pr = this.db.prepare(`DROP TABLE IF EXISTS ${this.tableName}`)
      return pr.run()
   }

   restore() {
      let result = {}
      result.drop = this.drop()
      result.migrate = this.migrate()
      return result
   }

   create(obj,query=true,values=[],keys=[],newObj = {}) {
      if(query) this.queryReset()
      obj = this.schema.presave(obj,this)
      if(obj == null) return null
      let source = this.schema.source
      this.schema.keys.forEach(key => {
         let value = obj[key]
         if(value == undefined && source[key]) {
            let def = source[key].default
            if(typeof def === 'function') value = def()
            else if(def !== null && def !== undefined) value = def
         }
         if(value !== undefined && key !== 'id' && key !== 'createdAt') {
            value = this.createValue(key,value)
            values.push(`'${value}'`)
            keys.push(key)
            newObj[key] = value
         }
      })
      if(query) this.query = `INSERT INTO ${this.tableName} (${keys.join()}) VALUES (${values.join()})`
      return newObj
   }

   insertMany(array) {
      try {
         if(array.length > 0) {
            let Keys = this.schema.keys.slice(0,this.schema.keys.length-2)
            let keys = Keys.join(',')
            let values = Keys.map(key => '@'+key).join(',')
            const insert = this.db.prepare(`INSERT INTO ${this.tableName} (${keys}) VALUES (${values})`)
            const insertMany = this.db.transaction((array) => {
               for (let obj of array) {
                  obj = this.create(obj)
                  if(obj !== null) insert.run(obj);
               }
             });
            insertMany(array)
            return null
         }
      } catch (error) {return this.error(error)}
   }

   insert(obj) {
      obj = this.create(obj)
      if(obj == null) return null
      this.action = 'insert'
      let result = this.run()
      if(result.changes) return this.findById(this.last().id)
      else return result
   }

   updateById(id,set) {
      let {changes} = this.update({id},set)
      if(changes) return this.findById(id)
      else return null
   }
   update(where,set) {
      this.queryReset()
      set = this.schema.presave(set,this)
      this.where(where)
      set = Object.keys(set).map(key => {
         if(this.schema.keys.includes(key)) {
            let value = this.createValue(key,set[key])
            if(key !== 'id' && key !== 'createdAt' && !this.schema.source[key].immutable && value !== null)
               return `${key} = '${value}'`
            else return null
         } else return null
      }).filter(Boolean).join()
      this.action = 'update'
      this.query = `UPDATE ${this.tableName} SET ${set} ${this._where}`
      return this.run()
   }

   last() {
      let query = this.db.prepare(`SELECT rowid from ${this.tableName} order by ROWID DESC limit 1`)
      return query.get()
   }

   findById(id) {
      this.query = `SELECT * FROM ${this.tableName} WHERE id = ${id}`
      return this.get()
   }

   find(obj={}) {
      this.queryReset()
      this.where(obj)
      this.query = `SELECT * FROM ${this.tableName} ${this._where}`
      return this.all()
   }
   
   deleteById(id) {return this.delete({id})}
   delete(obj) {
      this.queryReset()
      this.action = 'delete'
      this.where(obj)
      this.query = `DELETE FROM ${this.tableName} ${this._where}`
      return this.run()
   }

   where(obj = {},where='') {
      this._where = ''
      let keys = Object.keys(obj)
      if(keys.length > 0) {
         where = 'WHERE ' + keys.map(key => {
            if(!this.schema.keys.includes(key)) return null
            let value = obj[key]
            if(Array.isArray(value)) {
               return `${key} IN (${value.map(element => `'${element}'`).join()})`
            } else if(value) {
               if(value.toString().match(/^(\>|\<|(\>\=)|(\<\=)|(\<\>))|BETWEEN|LIKE/)) 
                  return ` ${key} ${value} `
               else if(typeof value == 'number') return ` ${key} = ${value} `
               else return ` ${key} = '${value}' `
            }
         }).filter(Boolean).join(' AND ') 
      }
      this.query += where
      this._where = where
      return this
   }

   run() {
      try {
         let stmt = this.db.prepare(this.query)
         if(this.action == 'delete' || this.action == 'update' || this.action == 'insert') return stmt.run()
      } catch (error) {return this.error(error)}
   }

   get() {
      const stmt = this.db.prepare(this.query);
      try {
         let result = stmt.get()
         return this.readValues(result)
      } catch (error) {return this.error(error)}
   }

   all() {
      const stmt = this.db.prepare(this.query);
      try {
          let results = stmt.all()
          if(results[0] !== undefined) {
             let key = Object.keys(results[0])[0]
             if(key.includes('COUNT(')) return results[0][key]
          }
          results = results.map(result => this.readValues(result))
          if(typeof this.schema.all == 'function') results = this.schema.all(results)
          return results
      } catch (error) {return this.error(error)}
   }

   error(error) {
      this.errors.push({error,query:this.query})
      console.log(this.errors)
      return null
   }

   count() {return this.select('COUNT(*)')}

   select(keys = '*') {
      this.queryReset()
      this.query = ''
      if(keys.match(/\-/)) {
         let newKeys = []
         keys = keys.split('-')
         this.schema.keys.forEach(key => {
            if(!keys.includes(key.trim())) newKeys.push(key)
         });
         keys = newKeys.join(',')
      } else if(!keys.includes('*')) {
         keys = keys.split(' ').map(key=> key.trim()).join(',')
      }
      this.query = `SELECT ${keys} FROM ${this.tableName} `
      return this
   }

   orderBy(string='',order='') {
      let keys = string.split(' ')
      if(string !== '') 
         order += 'ORDER BY ' + keys.map(key => {
            let direction = 'ASC'
            key = key.trim()
            if(key.startsWith('-')) {
               direction = 'DESC'
               key = key.substring(1)
            }
            if(!this.schema.keys.includes(key)) return null
            else return `${key} ${direction}`
         }).filter(Boolean).join()
      this.query += order
      this._orderBy = order
      return this
   }

   limit(limit) {
      limit = ` LIMIT ${limit} `
      this.query += limit
      this._orderBy = limit
      return this
   }

   skip(skip) {
      skip = ` OFFSET ${skip}`
      this.query += skip
      this._skip = skip
      return this
   }

   encrypt(password) {
      const salt = bcrypt.genSaltSync(10)
      return bcrypt.hashSync(password,salt)
   }

   compare(enteredPassword,password) {
      return bcrypt.compareSync(enteredPassword,password)
   }

   pupulate(string) {
      let source = this.schema.source
      let keys = string.split(' ')
      keys.forEach(key => {
         if(this.schema.keys.includes(key)) {
            let ref = source[key].ref
            if(Model.models[ref]) this.population[key] = Model.models[ref]
            else this.error(`Can't populate ${key}, because ${ref} is not a name of existing in Model.models table.`)
         } else if(key !== '') this.error(`${key} does'nt exist in your schema`)
      });
      return this
   }

   createValue(key,value) {
      if(typeof value == 'boolean') 
         value = value == true ? 'true' : value == false ? 'false' : value
      let {encrypt,type,ref,transform} = this.schema.source[key]
      if(encrypt) value = this.encrypt(value)
      try {
         if(type == 'array' && Array.isArray(value)) {
            if(ref && value.length > 0) { // if it's array of id's
               let result = value.filter(e => Number.isInteger(e))
               if(result.length > value.length) {
                  this.error(`Some values for ${key} are not type of integer and can't be saved as id for table ${ref}`)
                  value = null
               } else value = JSON.stringify(value)
            } else {
               value = JSON.stringify(value)
            }
         }
         else if(type == 'json' && typeof value == 'object') {
            value = JSON.stringify(value)
         }
      } catch (error) {
         this.error(`${key}'s value is not valid json or array. Original error: `+error.message)
      }
      return value
   }

   readValues(obj) {
      if(obj == undefined) return null
      let keys = Object.keys(obj)
      keys.forEach(key => {
         if(key !== 'id' && key !== 'createdAt') {
            obj[key] = obj[key] == 'true' ? true : obj[key] == 'false' ? false : obj[key]
            let value = obj[key]
            let type = this.schema.source[key].type
            try {if(type == 'array' || type == 'json') {
               obj[key] = JSON.parse(value)
            }
            } catch (error) {this.error(`${key}'s value (${value}) is not valid json or array. Original error: `+error.message)}
            if(this.population[key] !== undefined) {
               value = obj[key]
               let refModel = this.population[key]
               if(type == 'array') {
                  let array = []
                  let newValue = []
                  if(Array.isArray(value)) value.forEach(id => {
                     let result = refModel.findById(id)
                     if(result !== null) {
                        array.push(result)
                        newValue.push(id)
                     }
                  });
                  if(JSON.stringify(value) !== JSON.stringify(newValue) && Model.deleteMissing) {
                     this.updateById(obj.id,{[key]:newValue})
                     let missing = value.filter(e => !newValue.includes(e))
                     this.error(`The folowing id's : ${missing.join()} has been removed from ${key} array, because not longer existed`)
                  }
                  obj[key] = array
               } else if(type == 'integer') {
                  if(Number.isInteger(obj[key])) {
                     let id = obj[key]
                     let result = refModel.findById(id)
                     if(result !== null) obj[key] = result
                     else if(Model.deleteMissing) {
                        this.updateById(id,{[key]:null})
                        this.error(`${key}'s value has changed to null because it's referenced object not longer exists`)
                     }
                  } else this.error(`${key}'s value can be used as id for reference to ${refModel.tableName} table because it's not integer.`)
               } else this.error(`${key} has to be type of array or type of integer for using ref parameter`)
            }
         }
         if(this.schema.get) obj = this.schema.get(obj,this)
      });
      return obj
   }

   queryReset() {
      this.population = {}
      this.errors = []
      this.action = undefined
      this.query = ''
   }

   static compareArrays(array1,array2) {
      return JSON.stringify(array1) !== JSON.stringify(array2)
   }
}

module.exports = Model