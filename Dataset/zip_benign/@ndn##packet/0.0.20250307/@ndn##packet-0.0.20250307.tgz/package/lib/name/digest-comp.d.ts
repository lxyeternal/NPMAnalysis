import { Component } from "./component.js";
import type { NamingConvention } from "./convention.js";
import type { Name } from "./name.js";
declare class DigestComp implements NamingConvention<Uint8Array>, NamingConvention.WithAltUri {
    protected readonly tt: number;
    private readonly altUriPrefix;
    private readonly altUriRegex;
    constructor(tt: number, altUriPrefix: string);
    match(comp: Component): boolean;
    create(v: Uint8Array): Component;
    parse(comp: Component): Uint8Array;
    toAltUri(comp: Component): string;
    fromAltUri(input: string): Component | undefined;
}
declare class ImplicitDigestComp extends DigestComp {
    /** Remove ImplicitDigest if present at last component. */
    strip(name: Name): Name;
}
/** ImplicitSha256DigestComponent. */
export declare const ImplicitDigest: ImplicitDigestComp;
declare class ParamsDigestComp extends DigestComp {
    /** ParamsDigest placeholder during Interest encoding. */
    readonly PLACEHOLDER: Component;
    /** Determine if comp is a ParamsDigest placeholder. */
    isPlaceholder(comp: Component): boolean;
    /** Find ParamsDigest or placeholder in name. */
    findIn(name: Name, matchPlaceholder?: boolean): number;
}
/** ParametersSha256DigestComponent */
export declare const ParamsDigest: ParamsDigestComp;
export {};
