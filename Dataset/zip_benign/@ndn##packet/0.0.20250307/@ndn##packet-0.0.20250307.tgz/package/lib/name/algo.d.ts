import type { Name } from "./name.js";
/**
 * Perform name longest prefix match on a container of entries.
 * @typeParam T - Entry type, which must not be `undefined`.
 * @param name - Lookup target name.
 * @param get - Callback function to retrieve entry by name prefix TLV-VALUE in hexadecimal format.
 * @returns Matched entries.
 * The first result is the longest prefix match. Subsequent results are matches on successively
 * shorter prefixes. The caller may early-return the iterator to ignore subsequent results.
 */
export declare function lpm<T>(name: Name, get: (prefixHex: string) => T | undefined): Iterable<T>;
