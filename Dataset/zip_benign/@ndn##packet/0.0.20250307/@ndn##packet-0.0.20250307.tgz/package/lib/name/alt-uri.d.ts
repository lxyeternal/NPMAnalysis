import { Component } from "./component.js";
import type { NamingConvention } from "./convention.js";
import { Name } from "./name.js";
/**
 * Functions to print and parse names in alternate/pretty URI syntax.
 *
 * @remarks
 * This class is constructed with a sequence of `NamingConvention`s. Each component is matched
 * against these conventions in order, and the first matching convention can determine how to
 * print that component in an alternate URI syntax, if available.
 *
 * Other than pre-constructed `AltUri` instances exported by this and naming convention packages,
 * you may construct an instance with only the naming conventions you have adopted, so that a
 * component that happens to match a convention that your application did not adopt is not
 * mistakenly interpreted with that convention.
 */
export declare class AltUriConverter {
    readonly conventions: ReadonlyArray<NamingConvention<any> & NamingConvention.WithAltUri>;
    constructor(conventions: ReadonlyArray<NamingConvention<any> & NamingConvention.WithAltUri>);
    /** Print component in alternate URI syntax */
    readonly ofComponent: (comp: Component) => string;
    /** Print name in alternate URI syntax. */
    readonly ofName: (name: Name) => string;
    /** Parse component from alternate URI syntax */
    readonly parseComponent: (input: string) => Component;
    /** Parse name from alternate URI syntax. */
    readonly parseName: (input: string) => Name;
}
/** Print Generic, ImplicitDigest, ParamsDigest in alternate URI syntax. */
export declare const AltUri: AltUriConverter;
