import { type Decoder, Encoder } from "@ndn/tlv";
import type { Except } from "type-fest";
import { FIELDS } from "./impl-public-fields.js";
import type { Interest } from "./interest.js";
import { Component, Name, type NameLike } from "./name/mod.js";
import { LLSign, LLVerify, type Signer, type Verifier } from "./security/signing.js";
import { SigInfo } from "./sig-info.js";
declare class Fields {
    constructor(...args: Array<Data | Data.CtorArg>);
    name: Name;
    get contentType(): number;
    set contentType(v: number);
    private contentType_;
    get freshnessPeriod(): number;
    set freshnessPeriod(v: number);
    private freshnessPeriod_;
    finalBlockId?: Component;
    /** Determine whether FinalBlockId equals the last name component. */
    get isFinalBlock(): boolean;
    /**
     * Setting to `false` deletes FinalBlockId.
     * Setting to `true` assigns FinalBlockId to be the last name component.
     *
     * @throws Error
     * Thrown if attempting to set `true` while the name is empty.
     */
    set isFinalBlock(v: boolean);
    content: Uint8Array;
    sigInfo: SigInfo;
    sigValue: Uint8Array;
    signedPortion?: Uint8Array;
    topTlv?: Uint8Array;
    topTlvDigest?: Uint8Array;
}
interface PublicFields extends Except<Fields, "signedPortion" | "topTlv" | "topTlvDigest"> {
}
/** Data packet. */
export declare class Data implements LLSign.Signable, LLVerify.Verifiable, Signer.Signable, Verifier.Verifiable {
    /**
     * Construct from flexible arguments.
     *
     * @remarks
     * Arguments can include, in any order unless otherwise specified:
     * - Data to copy from
     * - {@link Name} or name URI
     * - {@link Data.ContentType}`(v)`
     * - {@link Data.FreshnessPeriod}`(v)`
     * - {@link Data.FinalBlock} (must appear after Name)
     * - `Uint8Array` as Content
     */
    constructor(...args: Array<Data | Data.CtorArg>);
    readonly [FIELDS]: Fields;
    static decodeFrom(decoder: Decoder): Data;
    encodeTo(encoder: Encoder): void;
    private encodeSignedPortion;
    /** Return the implicit digest if it's already computed. */
    getImplicitDigest(): Uint8Array | undefined;
    /** Compute the implicit digest. */
    computeImplicitDigest(): Promise<Uint8Array>;
    /** Return the full name if the implicit digest is already computed. */
    getFullName(): Name | undefined;
    /** Compute the full name (name plus implicit digest). */
    computeFullName(): Promise<Name>;
    /**
     * Determine if this Data can satisfy an Interest.
     * @returns Promise that resolves with the result.
     */
    canSatisfy(interest: Interest, { isCacheLookup }?: Data.CanSatisfyOptions): Promise<boolean>;
    [LLSign.OP](sign: LLSign): Promise<void>;
    [LLVerify.OP](verify: LLVerify): Promise<void>;
}
export interface Data extends PublicFields {
}
declare const ctorAssign: unique symbol;
interface CtorTag {
    [ctorAssign]: (f: Fields) => void;
}
export declare namespace Data {
    /** Constructor argument to set ContentType field. */
    function ContentType(v: number): CtorTag;
    /** Constructor argument to set FreshnessPeriod field. */
    function FreshnessPeriod(v: number): CtorTag;
    /** Constructor argument to set the current packet as FinalBlock. */
    const FinalBlock: unique symbol;
    /** Constructor argument. */
    type CtorArg = NameLike | CtorTag | typeof FinalBlock | Uint8Array;
    /** {@link Data.canSatisfy} options. */
    interface CanSatisfyOptions {
        /**
         * Whether the Interest-Data matching is in the context of cache lookup.
         * If `true`, Data with zero FreshnessPeriod cannot satisfy Interest with MustBeFresh.
         * If `false`, this check does not apply.
         * @defaultValue false
         */
        isCacheLookup?: boolean;
    }
}
export {};
