import { type Decoder, Encoder } from "@ndn/tlv";
import { Name, type NameLike } from "./name/mod.js";
/** KeyLocator in SigInfo. */
export declare class KeyLocator {
    static decodeFrom(decoder: Decoder): KeyLocator;
    constructor(...args: KeyLocator.CtorArg[]);
    name?: Name;
    digest?: Uint8Array;
    encodeTo(encoder: Encoder): void;
}
export declare namespace KeyLocator {
    type CtorArg = KeyLocator | NameLike | Uint8Array;
    function isCtorArg(arg: unknown): arg is CtorArg;
    /**
     * Extract KeyLocator name.
     * @throws Error
     * Thrown if KeyLocator is missing or does not have Name.
     */
    function mustGetName(kl?: KeyLocator): Name;
}
