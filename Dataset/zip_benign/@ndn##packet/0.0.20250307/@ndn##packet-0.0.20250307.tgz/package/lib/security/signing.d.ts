import { KeyLocator } from "../key-locator.js";
import type { Name } from "../name/mod.js";
import { SigInfo } from "../sig-info.js";
/**
 * Low level signing function.
 * @param input - Buffer of signed portion.
 * @returns Promise resolves to signature value or rejects with error.
 */
export type LLSign = (input: Uint8Array) => Promise<Uint8Array>;
export declare namespace LLSign {
    const OP: unique symbol;
    /** Target packet compatible with low level signing function. */
    interface Signable {
        [OP]: (signer: LLSign) => Promise<void>;
    }
}
/**
 * Low level verification function.
 * @param input - Buffer of signed portion.
 * @param sig - Buffer of signature value.
 * @returns Promise resolves upon good signature or rejects upon bad signature.
 */
export type LLVerify = (input: Uint8Array, sig: Uint8Array) => Promise<void>;
export declare namespace LLVerify {
    const OP: unique symbol;
    /** Target packet compatible with low level verification function. */
    interface Verifiable {
        [OP]: (verifier: LLVerify) => Promise<void>;
    }
}
interface PacketWithSignature {
    readonly name: Name;
    sigInfo?: SigInfo;
    sigValue: Uint8Array;
}
/** High level signer, such as a named private key. */
export interface Signer {
    /** Sign a packet. */
    sign: (pkt: Signer.Signable) => Promise<void>;
}
export declare namespace Signer {
    /** Target packet compatible with high level signer. */
    interface Signable extends PacketWithSignature, LLSign.Signable {
    }
    /**
     * Put SigInfo on packet if it does not exist.
     * @param pkt - Target packet.
     * @param sigType - Optionally set sigType.
     * @param keyLocator - Optionally set keyLocator; `false` to delete KeyLocator.
     * @returns Existing or modified SigInfo.
     */
    function putSigInfo(pkt: PacketWithSignature, sigType?: number, keyLocator?: KeyLocator.CtorArg | false): SigInfo;
    /**
     * Create a Signer that signs a packet only if it does not already have a non-Null signature.
     * @param signer - Inner signer.
     */
    function onlyIfUnsigned(signer: Signer): Signer;
}
/** High level verifier, such as a named public key. */
export interface Verifier {
    /**
     * Verify a packet.
     * @returns Promise resolves upon good signature/policy or rejects upon bad signature/policy.
     */
    verify: (pkt: Verifier.Verifiable) => Promise<void>;
}
export declare namespace Verifier {
    /** Target packet compatible with high level verifier. */
    interface Verifiable extends Readonly<PacketWithSignature>, LLVerify.Verifiable {
    }
    /**
     * Ensure packet has the correct SigType.
     *
     * @throws Error
     * Thrown if `pkt` lacks SigInfo or its SigType differs from `expectedSigType`.
     */
    function checkSigType(pkt: Readonly<PacketWithSignature>, expectedSigType: number): void;
    /** Throw bad signature error if not OK. */
    function throwOnBadSig(ok: boolean): asserts ok;
}
/** Signer and Verifier that do nothing. */
export declare const noopSigning: Signer & Verifier;
/** Signer and Verifier for SigType.Sha256 digest. */
export declare const digestSigning: Signer & Verifier;
/**
 * Signer for SigType.Null, a packet that is not signed.
 * @see https://redmine.named-data.net/projects/ndn-tlv/wiki/NullSignature
 */
export declare const nullSigner: Signer;
export {};
