SANS 10108 The Classification Of Hazardous Locations And The Pdf


 DOWNLOAD ===== [https://urllie.com/2tjMrz](https://urllie.com/2tjMrz)


```


flammable vapors are mixtures of gases composed of one or more flammable gases. the major component of the vapour is determined by the calculated partial pressure of the gas after taking into account the lower explosive limit. any non-flammable gas components are considered to be insignificant and will not affect the classification of the vapour as a flammable gas. 


flammable mixtures are made up of a flammable gas and air. a mixture of a flammable gas and air may or may not include other gases; for example, combustion of hydrogen (one of the flammable gases), will usually produce oxygen, which may be referred to as “by-product” air. this by-product air and the remaining air will add to or subtract from the partial pressure of the flammable gas. the mixture may or may not contain a non-flammable gas; for example, it is possible for combustion of methane to produce an amount of carbon dioxide, which is non-flammable.


 the size of a hazardous area will depend on the type and quantity of the hazardous material involved. for example, dust concentrations of about 5 mg per cubic metre (mg/m3) would require a one-person area about two metres square to be provided for “indoor” use, the area for "outdoor" use being only one metre square. in some cases, a larger area may be required for the storage of chemicals used in a manufacturing or processing operation. the area should be considered adequate for the safe use of the product at typical concentrations. a section of area of 0.5 to 1 m2 is generally sufficient for the safe use of a flammable liquid or gas (flg). 84d34552a1


```