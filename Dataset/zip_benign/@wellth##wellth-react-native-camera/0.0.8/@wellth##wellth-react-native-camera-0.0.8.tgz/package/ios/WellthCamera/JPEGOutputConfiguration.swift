import Foundation
import CoreMedia

private func normalizeInput(_ value: CGFloat) -> CGFloat {
  return max(0.0, min(1.0, value))
}

extension CIImage {
  convenience init?(sampleBuffer: CMSampleBuffer) {
    guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
    else { return nil }
    
    self.init(cvImageBuffer: imageBuffer)
  }
}

extension UIImage {
  convenience init?(sampleBuffer: CMSampleBuffer) {
    guard let image = CIImage(sampleBuffer: sampleBuffer)
      else { return nil }
    
    self.init(ciImage: image)
  }
}

struct JPEGOutputConfiguration: OutputConfiguration {
  let name: String
  let directory: String
  let encoding: ScaleUIImageJPEGEncoding
}

extension JPEGOutputConfiguration {
  init(dictionary: NSDictionary) {
    let name: String = dictionary.value(forKey: "name") as! String
    let directoryString: String? =
      dictionary.value(forKey: "directory") as? String
    let qualityNumber: NSNumber? =
      dictionary.value(forKey: "quality") as? NSNumber
    let sizeNumber: NSNumber? = dictionary.value(forKey: "size") as? NSNumber
    
    let directory: String = directoryString ?? NSTemporaryDirectory()
    let quality: CGFloat = CGFloat(qualityNumber?.floatValue ?? 1.0)
    let sizeValue: CGFloat = CGFloat(sizeNumber?.floatValue ?? 1.0)
    
    self.name = name
    self.directory = directory
    self.encoding = ScaleUIImageJPEGEncoding(
      quality: quality,
      scale: normalizeInput(sizeValue)
    )
  }
}

