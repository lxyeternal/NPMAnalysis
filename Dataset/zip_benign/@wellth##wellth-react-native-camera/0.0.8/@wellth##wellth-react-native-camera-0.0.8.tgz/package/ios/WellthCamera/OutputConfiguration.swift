import Foundation


protocol OutputConfiguration: Encoding {
  associatedtype OutputEncoding: FileEncoding
  
  var name: String { get }
  var directory: String { get }
  var encoding: OutputEncoding { get }
}

extension OutputConfiguration {
  func encode(input: OutputEncoding.Input) -> Bool {
    if let data = encoding.encode(input: input) {
      do {
        try data.write(
          to: outputURL,
          options: .atomicWrite
        )
        
        return true
      } catch { }
    }
    
    return false
  }
}

extension OutputConfiguration {
  var outputURL: URL {
    return NSURL(fileURLWithPath: directory, isDirectory: true)
      .appendingPathComponent(name)!
      .appendingPathExtension(encoding.fileExtension)
  }
  
  var outputPath: String {
    return outputURL.absoluteString
  }
}
