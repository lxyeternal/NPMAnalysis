import Foundation

protocol Encoding {
  associatedtype Input
  associatedtype Output
  
  func encode(input: Input) -> Output
}

protocol FileEncoding: Encoding where Output == Data? {
  var fileExtension: String { get }
}
