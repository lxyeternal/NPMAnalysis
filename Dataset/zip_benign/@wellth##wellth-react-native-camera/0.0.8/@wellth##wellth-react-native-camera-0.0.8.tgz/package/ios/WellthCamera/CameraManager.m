#import <React/RCTBridgeModule.h>
#import <React/RCTViewManager.h>
#import <React/RCTComponent.h>

@interface RCT_EXTERN_MODULE(WRNCameraManager, RCTViewManager)

RCT_EXPORT_VIEW_PROPERTY(shouldCapture, BOOL)
RCT_EXPORT_VIEW_PROPERTY(outputConfiguration, NSArray)
RCT_EXPORT_VIEW_PROPERTY(onCaptureOutput, RCTDirectEventBlock)

@end

