import UIKit
import AVFoundation

protocol CameraViewManager {
  var previewLayer: AVCaptureVideoPreviewLayer? { get }
  
  func startSession()
  func stopSession()
}

class CameraView: UIView {
  @objc
  public var shouldCapture: Bool = false
  
  @objc
  public var outputConfiguration: [NSDictionary] = []
  
  @objc
  public var onCaptureOutput: RCTDirectEventBlock = { _ in }
  
  private var manager: CameraViewManager?
  
  public required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
  }
  
  public init(manager: CameraViewManager) {
    manager.startSession()
    self.manager = manager
    
    super.init(frame: .zero)
    
    /// Attempt to add the preview layer.
    if let previewLayer = manager.previewLayer {
      add(previewLayer: previewLayer)
    }
  }
  
  override func layoutSubviews() {
    super.layoutSubviews()
    
    for layer in layer.sublayers ?? [] {
      /// Resize the preview layer to `bounds`.
      if layer is AVCaptureVideoPreviewLayer {
        layer.frame = bounds
      }
    }
  }
  
  override func removeFromSuperview() {
    if let manager = self.manager {
      manager.stopSession()
    }
    
    super.removeFromSuperview()
  }
}

