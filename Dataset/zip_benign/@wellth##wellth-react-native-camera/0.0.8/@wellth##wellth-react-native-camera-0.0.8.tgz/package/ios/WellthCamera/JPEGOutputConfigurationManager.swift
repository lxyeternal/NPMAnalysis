import Foundation
import CoreMedia

struct JPEGOutputConfigurationManager: Encoding {
  let configurations: [JPEGOutputConfiguration]
  
  func encode(input: CMSampleBuffer) -> [AnyHashable: Any] {
    guard let image = UIImage(sampleBuffer: input)
    else {
      return [:]
    }
    
    return configurations.reduce([AnyHashable: Any]()) { value, configuration in
      if configuration.encode(input: image) {
        var newValue = value
        newValue[configuration.name] = configuration.outputPath
        return newValue
      }
      
      return value
    }
  }
}
