import UIKit
import AVFoundation
import CameraKit

private let FileWriteQueueIdentifier: String = "com.wellthapp.reactnative.camera.fileWriteQueue"

@objc(WRNCameraManager)
class CameraManager: RCTViewManager {
  private var cameraController: CameraController?
  private var cameraView: CameraView?
  
  private let writeQueue: DispatchQueue = DispatchQueue(label: FileWriteQueueIdentifier)
  
  override static func requiresMainQueueSetup() -> Bool {
    return false
  }
  
  @objc
  override public func view() -> UIView {
    if cameraController == nil {
      do {
        let controller = try CameraController(captureModes: [.video])
        controller.delegate = self
        cameraController = controller
      } catch let error as CameraController.Error {
        switch error {
        case .simulator:
          print("The camera will not work in the simulator")
        default:
          fatalError("Could not set up `CameraController`. Reason: \(error)")
        }
      } catch {
        fatalError("Could not set up `CameraController`. Reason: \(error)")
      }
    }
    
    if cameraView == nil {
      cameraView = CameraView(manager: self)
    }
    
    return cameraView!
  }
}

/// Need to figure out how to know if there's an observer for the capture
/// session or not.
extension CameraManager: CameraViewManager {
  var previewLayer: AVCaptureVideoPreviewLayer? {
    return cameraController?.previewLayer
  }
  
  func startSession() {
    cameraController?.startCaptureSession()
  }
  
  func stopSession() {
    cameraController?.stopCaptureSession()
  }
}

extension CameraManager: CameraControllerDelegate {
  func cameraController(
    _ controller: CameraController,
    didOutputImage image: UIImage
  ) { }
  
  func cameraController(
    _ controller: CameraController,
    didOutputSampleBuffer sampleBuffer: CMSampleBuffer,
    type: CameraController.FrameType
  ) {
    guard let cameraView = self.cameraView
    else {
      return
    }
    
    if type == .video {
      if cameraView.shouldCapture {
        var copyPointer: CMSampleBuffer?
        CMSampleBufferCreateCopy(
          kCFAllocatorDefault,
          sampleBuffer,
          &copyPointer
        )
        
        guard let sampleBufferCopy = copyPointer
        else {
          return
        }
        
        cameraView.shouldCapture = false
        
        let configurations = cameraView.outputConfiguration.map { JPEGOutputConfiguration(dictionary: $0) }
        let onCaptureOutput = cameraView.onCaptureOutput
        
        writeQueue.async {
          let configurationManager = JPEGOutputConfigurationManager(
            configurations: configurations
          )
          
          onCaptureOutput([
            "output": configurationManager.encode(input: sampleBufferCopy)
          ])
        }
      }
    }
  }
}

