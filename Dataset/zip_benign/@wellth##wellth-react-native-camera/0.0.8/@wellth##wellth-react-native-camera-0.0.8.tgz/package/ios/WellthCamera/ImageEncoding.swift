import UIKit

enum ImageEncoding: FileEncoding {
  /// Scales (if necessary) and encodes the image as a JPEG. `scale` is
  /// expected to be a size where the `width` and `height` represent a
  /// relative value between 0.0 and 1.0.
  case PNG
  case JPEG(quality: CGFloat)
  case Custom(String, ((UIImage) -> Data?))
  
  var fileExtension: String {
    switch self {
    case .JPEG:
      return "jpg"
    case .PNG:
      return "png"
    case .Custom(let ext, _):
      return ext
    }
  }
  
  func encode(input: UIImage) -> Data? {
    switch self {
    case .JPEG(let quality):
      return UIImageJPEGRepresentation(
        input,
        quality
      )
    case .PNG:
      return UIImagePNGRepresentation(
        input
      )
    case .Custom(_, let map):
      return map(input)
    }
  }
}
