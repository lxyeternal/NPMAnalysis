//
//  BridgingHeader.h
//  Camera
//
//  Created by Justin Makaila on 11/10/17.
//  Copyright © 2017 Wellth. All rights reserved.
//

#ifndef BridgingHeader_h
#define BridgingHeader_h

#import <React/RCTViewManager.h>

#endif /* BridgingHeader_h */
