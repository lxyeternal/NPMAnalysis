import Foundation

protocol JPEGEncoding: FileEncoding { }
extension JPEGEncoding {
  var fileExtension: String { return "jpg" }
}

struct ScaleUIImageJPEGEncoding: JPEGEncoding {
  let quality: CGFloat
  let scale: CGFloat
  
  func encode(input: UIImage) -> Data? {
    let size = CGSize(
      width: input.size.width * scale,
      height: input.size.height * scale
    )
    
    return ResizeUIImageJPEGEncoding(quality: quality, size: size)
      .encode(input: input)
  }
}

struct ResizeUIImageJPEGEncoding: JPEGEncoding {
  let quality: CGFloat
  let size: CGSize
  
  func encode(input: UIImage) -> Data? {
    UIGraphicsBeginImageContext(size)
    defer {
      UIGraphicsEndImageContext()
    }
    
    input.draw(in: CGRect(origin: .zero, size: size))
    
    guard let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
    else {
      return nil
    }
    
    return ImageEncoding.JPEG(quality: quality)
      .encode(input: scaledImage)
  }
}
