# `wellth-react-native-camera`

## Features

- Support iOS 9.3, Android level 16
- Allows for auto-captured stream of photos.
- Allows for multiple output formats for a single capture (including auto captured images!).

## Installation
1. `$ (yarn | npm) add @wellth/wellth-react-native-camera`
2. `$ react-native link`

#### iOS
1. In your main project (that is, the one requiring `wellth-react-native-camera`) create a new `.swift` file in the same directory as your `AppDelegate.h`. 
2. Xcode will prompt you to create a bridging header. Create the header.
3. Build and run

#### Android
_Coming Soon_

## Usage

Taken from `example/App.js`:
```
import * as React from 'react'
import Camera from "wellth-react-native-camera"
import type { OutputConfiguration } from "wellth-react-native-camera"

type Props = {
  style: ViewProps,
  shouldCapture: boolean,
}

export default (props: Props) => {
  return (
    <Camera
      style={props.style}
      readyForCapture={props.shouldCapture}
      outputConfigurations={[
        {
          name: "fullSize",
          size: 1,
          quality: 1,
        },
        {
          name: "thumbnail",
          size: 0.4,
          quality: 1,
        },
      ]}
      onCaptureOutput={output => {
        const { thumbnail, fullSize } = output;
        console.log(thumbnail.imagePath);
        console.log(fullSize.imagePath);
      }}
    />
  );
};
```

## Development

### Setup

__iOS__  
1. Install dev dependencies:  
```$ yarn install```

2. Open the `.xcworkspace` in `ios/`

3. Build `React` at least once.

4. Build `Camera`.


__Android__