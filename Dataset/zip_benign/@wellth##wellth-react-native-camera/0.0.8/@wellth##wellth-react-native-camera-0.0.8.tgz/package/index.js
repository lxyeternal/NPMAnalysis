// @flow
import * as React from "react";
import {
  DeviceEventEmitter,
  Platform,
  requireNativeComponent,
  EmitterSubscription,
} from "react-native";
import PropTypes from "prop-types";
import type { OutputConfiguration, CameraOutput } from "./src/types";

export type Props = {
  shouldCapture: boolean,
  outputConfiguration: Array<OutputConfiguration>,

  onCaptureOutput: (output: CameraOutput) => void,
};

export type { OutputConfiguration, CameraOutput };

const DefaultProps = {
  shouldCapture: false,
  outputConfiguration: [],
  onCaptureOutput: output => {},
};

export default class CameraView extends React.Component<Props> {
  static defaultProps: Props = DefaultProps;

  captureListener: ?EmitterSubscription;

  componentWillMount() {
    this.addListeners();
  }

  componentWillUnmount() {
    this.removeListeners();
  }

  componentWillReceiveProps(props: Props) {
    const { onCaptureOutput } = this.props;

    if (onCaptureOutput !== props.onCaptureOutput) {
      this.addListeners(props);
    }
  }

  addListeners(props: ?Props) {
    if (Platform.OS === "ios") {
      return;
    }

    this.removeListeners();

    const { onCaptureOutput } = props || this.props;
    if (onCaptureOutput) {
      this.captureListener = DeviceEventEmitter.addListener(
        "ContinuousCaptureOutput",
        onCaptureOutput,
      );
    }
  }

  removeListeners() {
    if (this.captureListener) {
      this.captureListener.remove();
      this.captureListener = null;
    }
  }

  render() {
    const props = {
      ...this.props,
      onCaptureOutput: data => {
        this.props.onCaptureOutput(data.nativeEvent.output || data.output);
      },
    };

    return <NativeCamera {...props} />;
  }
}

CameraView.propTypes = {
  shouldCapture: PropTypes.bool,
  outputConfiguration: PropTypes.array,
  onCaptureOutput: PropTypes.func,
};

const NativeCamera = requireNativeComponent("WRNCamera", CameraView);
