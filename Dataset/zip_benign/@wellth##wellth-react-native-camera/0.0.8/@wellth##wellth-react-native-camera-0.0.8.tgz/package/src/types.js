// @flow

export type OutputConfiguration = {
  name: string,
  directory?: string,
  size: number,
  quality: number,
};

export type CameraOutput = {
  [name: string]: string,
};
