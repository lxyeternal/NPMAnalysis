import EventManager from './game/EventManager'
import res from './game/res'
import LoadRes from "./game/loadRes";
import GameUi from "./game/GameUi";
import GameScene from "./game/GameScene";
Component({
  // 供pixi渲染的canvas
  pixiCanvas: null,
  mixins: [],
  data: {
    targetWidth: 0,
    targetHeight: 0,
    isShow: true,
    score: 0,
    foodList: [],
    killNum: 0,
    isComplete: false,
    isRunCanvas: false,
    appOptions: {
      // 手动指定application的尺寸
      width: 0,
      height: 0,
      // 全屏-以窗口宽高作为application的尺寸，当设置此选项后，手动设置的width\height会失效
      //isFullsrceen: true,
      // application是否背景透明
      transparent: true,
      // 背景颜色
      //backgroundColor: 0x1099bb,
      // 是否强制用2d上下文渲染，如果为false,则优先使用webgl渲染
      forceCanvas: true
    },
  },
  props: {
    options: null,
    onGameComplete: null,
    setGameState: null,
    onRestartGame: null,
    onRevive: null,
    onUpdateFood: null,
    onEatProp: null
  },
  didMount() {
    console.log = () => { };
    console.debug = () => { };
    console.warn = () => { };
    this.$page.snakeCom = this;
    var { options } = this.props;
    var appOptions = this.data.appOptions;
    appOptions.width = options.width;
    appOptions.height = options.height;
    this.setData({
      targetWidth: options.width,
      targetHeight: options.height,
      appOptions: appOptions,
      isRunCanvas: true,
    })
    res.res = options.gameConfig;
  },
  didUpdate() { },
  didUnmount() {
    console.log("退出");
    this.onSetGameState(true);
    if (this.eventManager && this.eventManager.handlers) this.eventManager.handlers = {};
    LoadRes.destroyTextureCache()
  },
  methods: {
    onSetGameState(e) {
      if (!this.data.isComplete) return;
      this.setGameState(e);
    },
    onRestartGame() {
      if (!this.data.isComplete) return;
      this.restartGame();
    },
    onRevive() {
      if (!this.data.isComplete) return;
      this.revive();
    },
    onGameComplete() {
      this.setData({
        isComplete: true
      })
      this.props.onGameComplete();
    },
    onAppInit(e) {
      const { canvas, context, options, application } = e
      console.log('onAppInit', e);
      this.canvas = canvas;
      this.context = context;
      LoadRes.loader(res.res, () => {
        console.log("资源加载完成");
        this.eventManager = EventManager.getInstance();
        this.gameScene = new GameScene(e);
        this.gameUi = new GameUi(e, this.gameScene, this.props.options);
        application.stage.addChild(this.gameScene.node);
        application.stage.addChild(this.gameUi.node);
        this.setGameState = (state) => {
          this.gameScene.setGameState(state);
        };
        this.restartGame = () => {
          this.eventManager.emit("onStartGame");
        }
        this.revive = () => {
          this.gameScene.revive();
        }
        this.eventManager.emit("onStartGame");
        this.eventManager.on("updateScore", (value) => {
          this.data.score = value;
        })
        this.eventManager.on("updateHaveFoodList", (foodList) => {
          this.data.foodList = foodList;
        })
        this.eventManager.on("updateKillNum", (killNum) => {
          this.data.killNum = killNum;
        })
        this.eventManager.on("gameOver", (value) => {
          this.props.onGameOver(this.data.score, this.data.foodList, this.data.killNum);
        })
        this.eventManager.on("updateFoodList", (data) => {
          this.props.onUpdateFood(data);
        })
        this.eventManager.on("updatePropList", (data) => {
          this.props.onEatProp(data);
        })
        this.onGameComplete();
      });
    },
  },
});
