import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
import EventManager from './EventManager'
import { res } from './res'
import Utils from './utils'
export default class GameMain {
  constructor(e) {
    this.eventManager = EventManager.getInstance();
    this.node = new PIXI.Container();
    var startBtn = Utils.getImage(res.game.startBtn);
    var bg = Utils.getImage(res.game.bg);
    bg.scale.set(3.5);
    startBtn.anchor.set(0.5);
    startBtn.position.set(e.options.width / 2, e.options.height / 2);
    startBtn.buttonMode = true;
    startBtn.interactive = true;
    startBtn.on("touchstart", () => {
      this.startGame();
    });
    this.node.addChild(bg);
    this.node.addChild(startBtn);
    this.eventManager.on("onGameOverClose", () => {
      this.node.visible = true;
    })
  }
  startGame() {
    // console.log("开始游戏");
    this.node.visible = false;
    //this.gameScene.node.visible=true;
    this.eventManager.emit("onStartGame");
  }
}