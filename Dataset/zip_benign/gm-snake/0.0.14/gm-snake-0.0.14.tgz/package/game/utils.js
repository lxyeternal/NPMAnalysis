import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
export default ({
  boxesIntersect(a, b) {
    var ab = a.getBounds();
    var bb = b.getBounds();
    return ab.x > bb.x && ab.x < bb.x + bb.width - ab.width && ab.y > bb.y && ab.y < bb.y + bb.height - ab.height;
  },
  hitTest(source, target) {
    /* 源物体和目标物体都包含 x, y 以及 width, height */
    return !(
      Math.pow((source.x - target.x), 2) + Math.pow((source.y - target.y), 2) > Math.pow((source.width / 2 + target.width / 2), 2)
    );
  },
  RandomNum(Min, Max) {
    var Range = Max - Min;
    var Rand = Math.random();
    var num = Min + Math.round(Rand * Range);
    return num;
  },
  add(pos1, pos2) {
    var out = { x: 0, y: 0 };
    out.x = pos1.x + pos2.x;
    out.y = pos1.y + pos2.y;
    return out;
  },
  sub(pos1, pos2) {
    var out = { x: 0, y: 0 };
    out.x = pos1.x - pos2.x;
    out.y = pos1.y - pos2.y;
    return out;
  },
  normalize(out) {
    var _x = out.x;
    var _y = out.y;
    let len = _x * _x + _y * _y;
    if (len > 0) {
      len = 1 / Math.sqrt(len);
      out.x = _x * len;
      out.y = _y * len;
    }
    return out;
  },
  mul(pos, num) {
    var out = { x: 0, y: 0 };
    out.x = pos.x * num;
    out.y = pos.y * num;
    return out;
  },
  mag(out) {
    var _x = out.x;
    var _y = out.y;
    return Math.sqrt(_x * _x + _y * _y);
  },
  magSqr(a) {
    var _x = a.x;
    var _y = a.y;
    return _x * _x + _y * _y;
  },
  lerp(a, b, t) {
    var out = { x: 0, y: 0 };
    var _x = a.x;
    var _y = a.y;
    out.x = _x + t * (b.x - _x);
    out.y = _y + t * (b.y - _y);
    return out;
  },
  getImage(data) {
    var image = new PIXI.Sprite(PIXI.Texture.fromImage(data.src));
    image.width = data.width;
    image.height = data.height;
    return image;
  },
  sortby(sort, desc) {
    const v = (sort ? 1 : 0) + (desc ? 2 : 0)
    switch (v) {
      case 0: return (a, b) => a - b
      case 1: return (a, b) => a[sort] - b[sort]
      case 2: return (a, b) => b - a
      case 3: return (a, b) => b[sort] - a[sort]
    }
  },
  /**
   * 二分法获取合适项
   *
   * @export
   * @param {*} lst
   * @param {*} check_fit
   */
  dichotomy(lst, check_fit) {
    if (!lst || lst.length === 0) return null
    const lstLen = lst.length - 1
    let result = 0
    let nxtIndex = 0
    while (!check_fit(lst, result)) {
      nxtIndex = Math.floor((result + lstLen) / 2)
      if (result === lstLen + 1 || result === nxtIndex) return result
      result = nxtIndex
    }
    return result
  },


  /**
   * 从指定集合中按权重选取
   *
   * @export
   * @param {*} range
   * @param {*} weights
   */
  getRandomByWeight(range, weights) {
    const dict = this.getSortedByWeight(range, weights)
    if (!dict) return null
    // 区间设定
    return this.getRandomByWeightWithSortedList(dict)
  },

  /**
   * 获取已排序的集合
   *
   * @export
   * @param {*} range
   * @param {*} weights
   * @returns
   */
  getSortedByWeight(range, weights) {
    const sortByWeight = this.sortby('w')
    if (!range || !weights || range.length !== weights.length) return null
    const mapped = Object.keys(range).map((i) => ({ v: range[i], w: weights[i] }))
    // 排序列表，首项为权重为0
    const dict = [{ w: 0, v: null }].concat(mapped)
    const sorted_dict = dict.sort(sortByWeight)
    for (let i = 1; i < dict.length; i++) {
      const curW = dict[i - 1].w
      if (curW < 0) throw new RangeError(`${dict[i - 1].v} -> ${dict[i - 1].w} out of range`)
      dict[i].w = Number(dict[i].w) + Number(curW)
    }
    return sorted_dict
  },
  /**
   * 从已按权值排序的集合获取
   *
   * @export
   * @param {*} dict
   * @returns
   */
  getRandomByWeightWithSortedList(dict) {
    // 总权重
    const total_weight = dict[dict.length - 1].w
    // 结果
    const val = Math.random() * total_weight
    const result = this.dichotomy(dict, (lst, i) => lst[i].w < val && lst[i + 1].w > val)
    return dict[result + 1].v
  },
})


