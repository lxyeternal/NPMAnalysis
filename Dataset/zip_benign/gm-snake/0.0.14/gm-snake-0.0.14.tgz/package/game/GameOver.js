import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
import EventManager from './EventManager'
import { res } from './res'
export default class GameOver {
  constructor(e) {
    this.eventManager = EventManager.getInstance();
    this.node = new PIXI.Container();
    var enterBtn = new PIXI.Text();
    var continueBtn=new PIXI.Text();
    var scoreLabel = new PIXI.Text();
    var tips = new PIXI.Text();
    scoreLabel.text = "得分:0";
    scoreLabel.anchor.set(0.5);
    scoreLabel.position.set(e.options.width / 2, 300);
    tips.text = "游戏结束!";
    tips.anchor.set(0.5);
    tips.position.set(e.options.width / 2, 500);
    continueBtn.text="继续游戏";
    continueBtn.anchor.set(0.5);
    continueBtn.position.set(e.options.width / 2, e.options.height / 2);
    continueBtn.buttonMode = true;
    continueBtn.interactive = true;
    continueBtn.on("touchstart", () => {
      this.continueBtnClick();
    });
    enterBtn.text="返回主页";
    enterBtn.anchor.set(0.5);
    enterBtn.position.set(e.options.width / 2, e.options.height / 2+100);
    enterBtn.buttonMode = true;
    enterBtn.interactive = true;
    enterBtn.on("touchstart", () => {
      this.enterBtnClick();
    });
    this.node.addChild(enterBtn);
    this.node.addChild(tips);
    this.node.addChild(scoreLabel);
    this.node.addChild(continueBtn);
    this.node.visible = false;
    this.eventManager.on("gameOver", (score) => {
      this.node.visible = true;
      scoreLabel.text="得分:"+score;
    })
  }
  enterBtnClick() {
    this.node.visible = false;
    this.eventManager.emit("onGameOverClose");
  }
  continueBtnClick(){
    this.node.visible = false;
    this.eventManager.emit("onContinue");
  }
}