export default  class EventManager {
  constructor() {
    this.handlers = {};
  }
  on(type, handler) {
    if (typeof this.handlers[type] == "undefined") {
      this.handlers[type] = [];//每个事件都可以绑定多次
    }
    this.handlers[type].push(handler);
  }
  off(type, handler) {
    var events = this.handlers[type];
    for (var i = 0, len = events.length; i < len; i++) {
      if (events[i] == handler) {
        events.splice(i, 1);
        break;
      }
    }
  }
  emit(type) {
    if (this.handlers[type] instanceof Array) {
      var handlers = this.handlers[type];
      var args = Array.prototype.slice.call(arguments, 1);
      for (var i = 0, len = handlers.length; i < len; i++) {
        handlers[i].apply(this, args);
      }
    }
  }
}
var instance;
EventManager.getInstance = () => {
  if (!instance) {
    instance = new EventManager();
  }
  return instance;
}