import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
import Utils from './utils'
import EventManager from './EventManager'
import { TweenMax } from '../greensock-js/src/esm/TweenMax';
import { res } from "./res";
const CELL_TIME = 1;
// 蛇身大小
const SNAKE_CELL_SIZE = 60;
// 蛇身数量
const SNAKE_BODY_COUNT = 4;

export default class Player {
  constructor(e, isBot, bg, options) {
    // 速度
    this.SNAKE_SPEED = res.snake.speed || 8;
    this.eventManager = EventManager.getInstance();
    this._snake_pos = [];
    this._now_time = 0;
    this.childList = [];
    this.gameBg = bg;
    this.options = options;
    //this.id = Utils.RandomNum(0, res.skin.head.length - 1);
    this.node = new PIXI.Container();
    this.node.script = this;
    this.rope = new PIXI.mesh.Rope(PIXI.Texture.fromImage(res.snake.body.src), this._snake_pos);
    this.node.addChild(this.rope);
    this.head = Utils.getImage(res.snake.head); //Utils.getImage(res.skin.head[this.id]);
    this.head.nodeName = 'head';
    this.head.anchor.set(0.5, 0.5);
    for (var i = 0; i < SNAKE_BODY_COUNT; i++) {
      var body = Utils.getImage(res.snake.head);
      //body.blendMode = PIXI.BLEND_MODES.LIGHTEN;
      body.visible = false;
      body.nodeName = "body";
      body.anchor.set(0.5, 0.5);
      body.width = this.head.width;
      body.height = this.head.height;
      body.tint = 0xff3300;
      body.position.set(this.head.x, this.head.y);
      this.node.addChild(body);
      this.childList.push(body);
      // var data = res.snake.head;//res.skin.body[this.id];
      // var body = {};
      // body.x = this.head.x;
      // body.y = this.head.y;
      // body.position = { x: body.x, y: body.y };
      // body.width = data.width;
      // body.height = data.height;
      // body.nodeName = "body";
      // body.parent = this.node;
      // this.childList.push(body);
    }
    this.childList.unshift(this.head);
    this.node.addChild(this.head);

    this.isDie = true;
    this.moveDir = { x: 0, y: 1 };
    this.isBot = isBot;
    this.time = 0;
    this.gameState = true;
    this.killNum = 0;
    //this.isInvincible = true;
    this.score = 0;
    this.haveFoodList = {};
    this.bodyPool = [];

    this.mapWidth = this.gameBg.width;
    this.mapHeight = this.gameBg.height;
    e.application.ticker.add((delta) => {
      this.update(delta);
    });
    this.foodList = [];
    this.eventManager.on('createrFood', (foodList) => {
      this.setFoodList(foodList)
    });
    if (!this.isBot) {
      this.eventManager.on('updateFoodList', (data) => {
        var foodId = data.id;
        if (!this.haveFoodList[foodId]) this.haveFoodList[foodId] = 0;
        this.haveFoodList[foodId]++;
        this.eventManager.emit("updateHaveFoodList", this.haveFoodList);
      });
    }


    this.head.parent = null;
    this.node.addChild(this.head);
    //this.rope.visible = false;
  }
  setGameState(state) {
    this.gameState = state;
  }
  init(randPos) {
    this.node.visible = true;
    this.isDie = false;
    this.moveDir = { x: 0, y: -1 };
    this.foodList = [];
    this.haveFoodList = {};
    this.time = 0;
    this.killNum = 0;
    //this.isInvincible = true;
    this.score = 0;
    //setTimeout(this.setIsInvincible.bind(this), 1500);
    if (!this.isBot) {
      if (randPos) {
        var width = this.mapWidth / 2;
        var height = this.mapHeight / 2;
        var maxX = width - this.options.width;
        var minX = -width + this.options.width;
        var maxY = height - this.options.height;
        var minY = -height + this.options.height;
        var posX = Utils.RandomNum(minX, maxX);
        var posY = Utils.RandomNum(minY, maxY);
        this.head.position.set(posX, posY);
        this.node.parent.x = -this.head.x + this.options.width / 2;
        this.node.parent.y = -this.head.y + this.options.height / 2;
      } else {
        this.head.position.set(0, 0);
        this.node.parent.x = this.options.width / 2
        this.node.parent.y = this.options.height / 2;
        for (var i = this.childList.length - 1; i > SNAKE_BODY_COUNT; i--) {
          this.childList[i].parent = null;
          this.childList[i].visible = false;
          this.bodyPool.push(this.childList[i]);
          this.childList.splice(i, 1);
        }
      }
    } else {
      var width = this.mapWidth / 2;
      var height = this.mapHeight / 2;
      var maxX = width - this.options.width;
      var minX = -width + this.options.width;
      var maxY = height - this.options.height;
      var minY = -height + this.options.height;
      var posX = Utils.RandomNum(minX, maxX);
      var posY = Utils.RandomNum(minY, maxY);
      this.head.position.set(posX, posY);
      for (var i = this.childList.length - 1; i > SNAKE_BODY_COUNT; i--) {
        this.childList[i].parent = null;
        this.childList[i].visible = false;
        this.bodyPool.push(this.childList[i]);
        this.childList.splice(i, 1);
      }
    }
    this.head.rotation = 0;

    // 蛇总长度 
    const snake_length = SNAKE_CELL_SIZE * (this.childList.length - 1);
    // 每次移动的距离
    const snake_move_delta = this.SNAKE_SPEED * CELL_TIME;
    // 总共点数
    const snake_pos_count = Math.ceil(snake_length / snake_move_delta) + 1;
    this._snake_pos = [];
    // 初始化位置信息，按照蛇头的位置往下排
    for (let index = 0; index < snake_pos_count; index++) {
      this._snake_pos.push({ x: this.head.x, y: this.head.y + index * snake_move_delta });
    }
    this.updateSnakeBodyPos();
    this._snake_pos.pop();
    this.rope.points = this._snake_pos;
    this.rope._refresh();
    this.node.visible = true;
    //this.rope.visible = true;
  }
  fix_update(dt) {
    if (this.isDie) return;
    this.time += dt;
    var r = Math.atan2(this.moveDir.y, this.moveDir.x);
    this.head.rotation = r + 1.5;
    if (this.isBot) {
      var tempX = this.moveDir.x * this.SNAKE_SPEED * dt;
      var tempY = this.moveDir.y * this.SNAKE_SPEED * dt;
      this.head.x += tempX;
      this.head.y += tempY;
      var randTime = Utils.RandomNum(30, 50);
      if (this.time >= randTime) {
        this.setTarget();
        this.time = 0;
      }
    } else {
      var tempX = this.moveDir.x * this.SNAKE_SPEED * dt;
      var tempY = this.moveDir.y * this.SNAKE_SPEED * dt;
      this.head.x += tempX;
      this.head.y += tempY;
    }
    this._snake_pos.unshift({ x: this.head.x, y: this.head.y });
    this.updateSnakeBodyPos();
    this._snake_pos.pop();
  }
  update(dt) {
    if (this.gameState) return;
    if (this.isDie) return;
    // this._now_time += dt;
    // while (this._now_time >= CELL_TIME) {
    //   this.fix_update(CELL_TIME);
    //   //this._now_time -= CELL_TIME;
    //   this._now_time = 0;
    // }
    //CELL_TIME = dt;
    this.fix_update(CELL_TIME);
    // while (this._now_time >= CELL_TIME) {

    //   this._now_time -= CELL_TIME;
    // }
    //this.fix_update(dt);
  }
  updateSnakeBodyPos() {
    const snake_move_delta = this.SNAKE_SPEED * CELL_TIME;
    this.childList.forEach((s, i) => {
      if (i == 0) return;
      // 计算当前身体在位置中的索引
      var pos_index = Math.floor((i - 1) * SNAKE_CELL_SIZE / snake_move_delta);
      var pos = this._snake_pos[pos_index];
      if (!pos) {
        pos = this._snake_pos[this._snake_pos.length - 1];
        this._snake_pos.push(pos);
      }
      s.x = pos.x;
      s.y = pos.y;
      s.position = { x: s.x, y: s.y };
      //s.alpha = (this._snake_pos.length - pos_index) / this._snake_pos.length;
    })
  }
  addSnakeLen() {
    // var data = res.skin.body[this.id];
    // var body = this.bodyPool.pop();
    // if (body) {
    //   var texture = PIXI.Texture.fromImage(data.src);
    //   body.texture = texture;
    //   body.visible = true;
    // } else {
    //   body = new PIXI.Sprite(PIXI.Texture.fromImage(data.src));
    // }
    // body.visible = false;
    // this.node.addChild(body);
    // body.nodeName = "body";
    // body.anchor.set(0.5, 0.5);
    //body.position.set(this.head.x, this.head.y);

    // var head = this.childList.shift();
    // head.parent = null;
    //this.node.addChild(head);
    // this.childList.unshift(body);
    // this.childList.unshift(head);
    // var data = res.skin.body[this.id];
    // var body = {};
    // body.x = this.head.x;
    // body.y = this.head.y;
    // body.position = { x: body.x, y: body.y };
    // body.width = data.width;
    // body.height = data.height;
    // body.nodeName = "body";
    // body.parent = this.node;
    // this.childList.push(body);
    // this.updateSnakeBodyPos();
    // this.rope.points = this._snake_pos;
    // this.rope._refresh();
  }
  // setIsInvincible() {
  //   this.isInvincible = false;
  // }
  setFoodList(foodList) {
    this.foodList = foodList;
  }
  setTarget() {
    if (!this.foodList.length) return;
    //if (this.outFood&&this.outFood.parent) return;
    this.outFood = this.foodList[Utils.RandomNum(0, this.foodList.length - 1)];
    if (this.outFood && this.outFood.parent) {
      //计算朝向
      let distance = Utils.sub(this.outFood, this.head);
      var p = Utils.normalize(distance);

      if (Math.abs(p.x) > Math.abs(p.y)) {
        if (p.x > 0) {
          p.x = 1;
        } else {
          p.x = -1;
        }
        p.y = 0;
      } else {
        if (p.y > 0) {
          p.y = 1;
        } else {
          p.y = -1;
        }
        p.x = 0;
      }
      //this.moveDir = p;
      TweenMax.to(this.moveDir, 0.1, { x: p.x, y: p.y })
    }

    // var list = this.foodList.concat();
    // list.sort((a, b) => {
    //     var dis1 = Math.sqrt(Math.pow((this.head.x-a.x),2)+Math.pow((this.head.y-a.y),2));
    //     var dis2 = Math.sqrt(Math.pow((this.head.x-b.x),2)+Math.pow((this.head.y-b.y),2));
    //     a.dis=dis1;
    //     b.dis=dis2;
    //     return dis1 - dis2;
    // })
    // this.outFood = list[0];
    // //计算朝向
    // let distance = Utils.sub(this.outFood , this.head);
    // var dir = Utils.normalize(distance);
    // TweenMax.to(this.moveDir, Utils.RandomNum(0.3, 1.5), { x: dir.x, y: dir.y })
  }
}