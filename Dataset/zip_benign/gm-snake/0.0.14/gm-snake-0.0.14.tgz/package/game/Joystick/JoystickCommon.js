export default {
  JoystickType: {
    FIXED: 0,
    FOLLOW: 1,
  },

  DirectionType: {
    FOUR: 4,
    EIGHT: 8,
    ALL: 0,
  },

  SpeedType: {
    STOP: 0,
    NORMAL: 1,
    FAST: 2
  }
};
