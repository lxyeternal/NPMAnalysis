import JoystickCommon from './JoystickCommon'
import Utils from '../utils'
import { TweenMax } from '../../greensock-js/src/esm/TweenMax';
var joystick;
class Joystick {
  constructor() {

  }
  init(dot, ring, gameScene) {
    console.log(111);
    this.dot = dot;
    this.ring = ring;
    this.player = gameScene.player;
    this.joystickType = JoystickCommon.JoystickType.FIXED;
    this.directionType = JoystickCommon.DirectionType.ALL;
    this._stickPos = null;
    this._touchLocation = null;
    this._radius = this.ring.width / 2;
    this.player._radius = this._radius;
    this.gameScene = gameScene;
    this._initTouchEvent(gameScene.node);
  }
  _initTouchEvent(node) {
    // set the size of joystick node to control scale
    var self = node;
    self.buttonMode = true;
    self.interactive = true;
    self.on("touchstart", this._touchStartEvent, this);
    self.on("touchstart", this._touchMoveEvent, this);
    self.on("touchmove", this._touchMoveEvent, this);
    self.on("touchend", this._touchEndEvent, this);
    self.on("touchendoutside", this._touchEndEvent, this);
  }

  _touchStartEvent(event) {
    var self = joystick;
    const touchPos = event.data.getLocalPosition(this.ring);
    if (self.joystickType === JoystickCommon.JoystickType.FIXED) {
      self._stickPos = self.ring.position;
      var out = Utils.sub(touchPos, self.ring.position);
      // 触摸点与圆圈中心的距离
      const distance = Math.sqrt(out.x * out.x + out.y * out.y);
      // 手指在圆圈内触摸,控杆跟随触摸点
      if (self._radius > distance) {
        self.dot.position.set(touchPos.x, touchPos.y);
      }

    } else if (self.joystickType === JoystickCommon.JoystickType.FOLLOW) {
      // 记录摇杆位置，给 touch move 使用
      self._stickPos = touchPos;
      self._touchLocation = event.position;
      // 更改摇杆的位置
      self.ring.position.set(touchPos.x, touchPos.y);
      self.dot.position.set(touchPos.x, touchPos.y);
    }
  }

  _touchMoveEvent(event) {
    if (this.gameScene.gameState) return;
    var self = joystick;
    if (!self._stickPos) return;

    // 以圆圈为锚点获取触摸坐标
    const touchPos = event.data.getLocalPosition(this.ring);

    const distance = Utils.mag(touchPos);
    // 由于摇杆的 postion 是以父节点为锚点，所以定位要加上 touch start 时的位置
    var pos = Utils.add(self._stickPos, touchPos);
    var out = Utils.sub(pos, self.ring);
    // 归一化
    const p = Utils.normalize(out);

    if (self._radius > distance) {
      self.dot.position.set(pos.x, pos.y);
    } else {
      // 控杆永远保持在圈内，并在圈内跟随触摸更新角度
      const x = self._stickPos.x + p.x * self._radius;
      const y = self._stickPos.y + p.y * self._radius;
      self.dot.position.set(x, y);
    }

    // p.x = Math.round(p.x);
    // p.y = Math.round(p.y); 
    if (this.isAni) return;
    if (Math.abs(p.x) > Math.abs(p.y)) {
      if (p.x > 0) {
        p.x = 1;
      } else {
        p.x = -1;
      }
      p.y = 0;
    } else {
      if (p.y > 0) {
        p.y = 1;
      } else {
        p.y = -1;
      }
      p.x = 0;
    }
    //self.player.moveDir = p;
    //if (self.player.moveDir.x == -p.x && self.player.moveDir.y == -p.y) return;
    this.isAni = true;
    TweenMax.to(self.player.moveDir, 0.1, {
      x: p.x, y: p.y, onComplete: () => {
        this.isAni = false;
      }
    })
  }

  _touchEndEvent() {
    var self = joystick;
    self.dot.position.set(self.ring.x, self.ring.y);
  }
}
joystick = new Joystick();
export default joystick;