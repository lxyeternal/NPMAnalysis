module.exports = {
  // "res": {
  //   "game": {
  //     "map": {
  //       "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01TBpcl923c03CukO8f_!!555657275.png",
  //       "width": 350,
  //       "height": 410
  //     },
  //     "food": {
  //       "1": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01QL5Sub23c03Ph7tct_!!555657275.png",
  //         "width": 281,
  //         "height": 247
  //       },
  //       "2": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN016qxFeu23c03BVc9Qx_!!555657275.png",
  //         "width": 298,
  //         "height": 221
  //       },
  //       "3": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01u8UO8F23c03I9vK56_!!555657275.png",
  //         "width": 205,
  //         "height": 228
  //       },
  //       "4": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN018iMsE023c03Ph8ERE_!!555657275.png",
  //         "width": 227,
  //         "height": 305
  //       },
  //       "5": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01sGIf0x23c03NWDHAL_!!555657275.png",
  //         "width": 231,
  //         "height": 278
  //       }
  //     },
  //     "timeIcon": {
  //       "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01DxatTk23c03QQe9hA_!!555657275.png",
  //       "width": 156,
  //       "height": 157
  //     },
  //     "skin_body": {
  //       "1": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01djiqJQ23c03BVXitR_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "2": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN013HzliY23c03Ph3OqO_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "3": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01afkAqK23c03KbyoMv_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "4": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01Byp7Sz23c03R6qzoe_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "5": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01JdjFs723c03I9rECV_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "6": {
  //         "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01BOIf9F23c03BVXFmw_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "7": {
  //         "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01YJol5o23c03R6pvIx_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "8": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01pfvH2O23c03Haa7Wr_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "9": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01LcLMXY23c03I9vFjA_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "10": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01I9dKjA23c03LbTaGW_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "11": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01R0EPbl23c03GFqyxW_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "12": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01uf3ueO23c03QWuGVy_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "13": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01kFGExn23c03P0XAEt_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       }
  //     },
  //     "skin_head": {
  //       "1": {
  //         "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01AVOa4B23c03HabOTY_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "2": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01SphokO23c03I9r5oc_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "3": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01WpQzEW23c03QWtBtE_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "4": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01eJaBq323c03O1CfQI_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "5": {
  //         "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01fmvPLf23c03P0Y6L8_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "6": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01Ca12hN23c03O1DPA1_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "7": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN013lZEMn23c03R6nJ3N_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "8": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01A8ESR123c03I9qDlA_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "9": {
  //         "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN0119LtWR23c03LbU3Jq_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "10": {
  //         "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN016puvzy23c03NW6tql_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "11": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01KW7t7723c03NW5xex_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "12": {
  //         "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN015VHvvr23c03HacGVv_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       },
  //       "13": {
  //         "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01KYZgX623c03O1DbdE_!!555657275.png",
  //         "width": 53,
  //         "height": 53
  //       }
  //     }
  //   },
  //   "joystick": {
  //     "wheel": {
  //       "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01SMyWGf23c03LKLeJR_!!555657275.png",
  //       "width": 150,
  //       "height": 150
  //     },
  //     "wheel_bg": {
  //       "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01bEH6WY23c03LKNOOz_!!555657275.png",
  //       "width": 280,
  //       "height": 280
  //     }
  //   }
  // },
  // "font": {
  //   "0": {
  //     "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01ZTTwJg23c03Hab3aw_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "1": {
  //     "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01Mj0bg723c03QWnxTF_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "2": {
  //     "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01cbDU5A23c03R6lUjF_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "3": {
  //     "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01yhaWgb23c03Ph0Vwg_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "4": {
  //     "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01p4iK7H23c03Ph3SrC_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "5": {
  //     "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN012GCNXu23c03MjkXbT_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "6": {
  //     "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01RMxzTq23c03QWpQx4_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "7": {
  //     "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN016UQm3I23c03I9px3l_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "8": {
  //     "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01j2OoQ023c03GFncr1_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "9": {
  //     "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKVBg823c03O1Amte_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  //   "defen": {
  //     "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN010mk1Bs23c03MjPRxX_!!555657275.png",
  //     "width": 278,
  //     "height": 112
  //   },
  //   "s": {
  //     "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKN1kT23c03R6nyYW_!!555657275.png",
  //     "width": 118,
  //     "height": 118
  //   },
  // }
}