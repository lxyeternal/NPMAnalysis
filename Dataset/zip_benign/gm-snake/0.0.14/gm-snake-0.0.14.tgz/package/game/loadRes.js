import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
class LoadRes {
  constructor() {
    this.Loader = new PIXI.loaders.Loader();
  }
  loader(res, callBack) {
    var result = [];
    this.getAllPath(res, result);
    result = this.unique22(result);
    for (var key in result) {
      this.Loader.add(key, result[key]);
    }
    this.Loader.load(callBack);
  }
  getAllPath(data, result) {
    if (data == undefined || typeof data != "object") return;
    for (var key in data) {
      if (data[key].src) {
        result.push(data[key].src);
      }
      this.getAllPath(data[key], result);
    }
  }
  unique22(arr) {
    var hash = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr.indexOf(arr[i]) == arr.lastIndexOf(arr[i])) {
        hash.push(arr[i]);
      }
    }
    return hash;
  }
  destroyTextureCache() {
    PIXI.utils.destroyTextureCache();
    this.Loader.destroy();
  }
}
export default new LoadRes();