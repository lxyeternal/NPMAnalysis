import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
import Joystick from './Joystick/Joystick'
import EventManager from './EventManager'
import { res } from './res'
import Utils from './utils'
export default class GameUi {
  constructor(e, gameScene, options) {
    this.options = options;
    this.gameScene = gameScene;
    this.eventManager = EventManager.getInstance();
    //this.nodePool = [];
    this.node = new PIXI.Container();
    this.setJoystickPanel();

    this.scorePanel = new PIXI.Container();
    this.timePanel = new PIXI.Container();
    //this.killPanel = new PIXI.Container();
    this.node.addChild(this.scorePanel);
    this.node.addChild(this.timePanel);
    // this.node.addChild(this.killPanel);

    this.scoreNumPanel = new PIXI.Container();
    //this.killNumPanel = new PIXI.Container();
    this.timeNumPanel = new PIXI.Container();

    this.defen = Utils.getImage(res.socre);
    this.setNodePos(this.defen, res.socre.pos);
    this.scorePanel.addChild(this.defen);
    this.scorePanel.addChild(this.scoreNumPanel);

    // this.icon = Utils.getImage(res.kill);
    // this.setNodePos(this.icon, res.kill.pos);
    // this.killPanel.addChild(this.icon);
    // this.killPanel.addChild(this.killNumPanel);

    this.timeIcon = Utils.getImage(res.time);
    this.setNodePos(this.timeIcon, res.time.pos);
    this.timePanel.addChild(this.timeIcon);
    this.timePanel.addChild(this.timeNumPanel);


    this.eventManager.on("updateScore", (value) => {
      this.scoreNumPanel.removeChildren(0, this.scoreNumPanel.children.length);
      var list = this.numToSprite(value);
      for (var key in list) {
        this.scoreNumPanel.addChild(list[key]);
      }
      this.setSpritePos(this.scoreNumPanel, res.socre.numPos);
    })
    // this.eventManager.on("updateKillNum", (value) => {
    //   this.killNumPanel.removeChildren(0, this.killNumPanel.children.length);
    //   var list = this.numToSprite(value);
    //   for (var key in list) {
    //     this.killNumPanel.addChild(list[key]);
    //   }
    //   this.setSpritePos(this.killNumPanel, res.kill.numPos);
    // })

    this.eventManager.on("onStartGame", () => {
      this.scorePanel.visible = true;
      this.timePanel.visible = true;
      //this.killPanel.visible = true;
      this.dot.position.set(this.options.width / 2, this.options.height - this.ring.height / 2 - 100);
      this.dot.visible = true;
      this.ring.visible = true;
    })
    this.eventManager.on("gameOver", () => {
      // this.scorePanel.visible = false;
      // this.timePanel.visible = false;
      // dot.visible = false;
      // ring.visible = false;
    })
    this.eventManager.on("onContinue", () => {
      this.scorePanel.visible = true;
      this.timePanel.visible = true;
      dot.visible = true;
      ring.visible = true;
    })
    this.eventManager.on("setGameTime", (time) => {
      this.timeNumPanel.removeChildren(0, this.timeNumPanel.children.length);
      var list = this.numToSprite(time);
      for (var key in list) {
        this.timeNumPanel.addChild(list[key]);
      }
      var s = Utils.getImage(res.time.numArr[10]);
      this.timeNumPanel.addChild(s);
      this.setSpritePos(this.timeNumPanel, res.time.numPos);
    })
  }
  numToSprite(value) {
    var list = [];
    var numList = value.toString().split("");
    for (var key in numList) {
      // var img = this.nodePool.pop();
      // if (img) {
      //   var texture = PIXI.Texture.fromImage(res.socre.numArr[numList[key]].src);
      //   img.texture = texture;
      //   img.visible = true;
      // } else {
      var img = Utils.getImage(res.socre.numArr[numList[key]]);
      list.push(img);
      //}
    }
    return list;
  }
  setSpritePos(node, pos) {
    var childList = node.children;
    var x = 0;
    for (var key in childList) {
      childList[key].position.set(0, 0);
      childList[key].position.x = x;
      x += childList[key].width
      if (pos.leftOffset) x -= pos.leftOffset
    }
    this.setNodePos(node, pos);
  }
  setNodePos(node, pos) {
    node.y = pos.y;
    switch (pos.align) {
      case 0://居左
        node.x = pos.x - node.width;
        break;
      case 1://居中
        node.x = pos.x - node.width / 2;
        break;
      case 2://居右
        node.x = pos.x;
        break;
    }
  }
  setJoystickPanel() {
    //创建摇杆
    this.dot = Utils.getImage(res.joystick.wheel);
    this.ring = Utils.getImage(res.joystick.wheel_bg);
    this.dot.position.set(this.options.width / 2, this.options.height - this.ring.height / 2 - 100);
    this.ring.position.set(this.options.width / 2, this.options.height - this.ring.height / 2 - 100);
    this.ring.anchor.set(0.5);
    this.dot.anchor.set(0.5);
    this.node.addChild(this.ring);
    this.node.addChild(this.dot);
    Joystick.init(this.dot, this.ring, this.gameScene);
  }
}