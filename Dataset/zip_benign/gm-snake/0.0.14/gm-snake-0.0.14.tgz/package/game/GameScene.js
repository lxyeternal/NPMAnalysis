import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
import Player from './player'
import Bump from './bump'
import Utils from './utils'
import EventManager from './EventManager'
import Quadtree from './quadtree'
import { res } from './res'
import { TweenMax } from '../greensock-js/src/esm/TweenMax';
export default class GameScene {
  constructor(e) {
    this.eventManager = EventManager.getInstance();
    this.options = e.options;
    this.e = e;
    this.canvas = e.canvas;
    this.bump = new Bump(PIXI);
    this.node = new PIXI.Container();
    this.foodPanel = new PIXI.Container();
    this.propPanel = new PIXI.Container();

    this.bg = Utils.getImage(res.map);
    this.bg.anchor.set(0.5, 0.5);
    this.player = new Player(e, false, this.bg, e.options);

    this.node.addChild(this.bg);
    this.node.addChild(this.foodPanel);
    this.node.addChild(this.propPanel);
    this.node.addChild(this.player.node);
    this._tree = new Quadtree({ x: this.bg.x, y: this.bg.y, width: this.bg.width, height: this.bg.height });
    this.time = 0;
    this.foodList = [];
    this.enemyList = [];
    this.score = 0;
    this.isOver = false;
    this.gameState = true;
    this.gameTime = 0;
    this.killNum = 0;
    this.surplusTime = res.time.value;
    this._now_time = 0;
    this.foodPool = [];
    this.propList = {};
    this.propPool = [];
    this.propTime = 0;
    this.doubleTime = 0;
    for (var i = 0; i < res.enemyNum; i++) {
      this.createEnemy();
    }
    this.eventManager.on("onStartGame", () => {
      this.setGameState(true);
      this.node.visible = true;
      this.score = 0;
      this.gameTime = 0;
      this.killNum = 0;
      this.propTime = 0;
      this.doubleTime = 0;
      this.surplusTime = res.time.value;
      this.propNumList = {};
      this.eventManager.emit('updateScore', this.score);
      this.eventManager.emit('setGameTime', this.surplusTime);
      this.eventManager.emit("updateKillNum", this.killNum);
      this.isOver = false;
      this.player.init();
      for (var key in this.enemyList) {
        this.reviveEnemy(this.enemyList[key]);
      }
      for (var key in this.foodList) {
        this.foodList[key].visible = false;
        this.foodPool.push(this.foodList[key]);
      }
      this.eventManager.emit('createrFood', this.foodList);
      this.foodList.splice(0, this.foodList.length);
      for (var key in this.propList) {
        for (var i = 0; i < this.propList[key].length; i++) {
          this.propList[key][i].visible = false;
          this.propPool.push(this.propList[key][i]);
        }
        this.propList[key].splice(0, this.propList[key].length);
      }
      for (var key in res.propList.list) {
        this.propList[res.propList.list[key].id] = [];
        this.propNumList[res.propList.list[key].id] = 0;
      }
      this.reviveProp = null;
    })
    this.eventManager.on("snakeDie", this.snakeDie);
    this.eventManager.on("setGameState", this.setGameState.bind(this));
    this.eventManager.on("onContinue", this.onContinueGame.bind(this));
    e.application.ticker.add((delta) => {
      this.update(delta);
    });
  }
  onContinueGame() {
    if (this.isOver) return;
    this.node.visible = true;
    this.player.init();
  }
  setGameState(state) {
    if (this.player.isDie) return;
    if (this.isOver) return;
    this.gameState = state;
    for (var i = 0; i < this.enemyList.length; i++) {
      this.enemyList[i].setGameState(this.gameState);
    }
    this.player.setGameState(this.gameState);
  }
  createFood() {
    if (this.foodList.length >= res.foodList.maxNum) return;
    // 初始化数据
    const member_list = res.foodList.list;
    // 数据预处理
    const member_list_list_sorted = Utils.getSortedByWeight(member_list.map(i => i.id), member_list.map(i => i.odds))
    // 输出按分布选中的结果
    var foodId = Utils.getRandomByWeightWithSortedList(member_list_list_sorted) - 1;
    var food = this.foodPool.pop();
    var data = res.foodList.list[foodId];
    if (food) {
      var texture = PIXI.Texture.fromImage(data.src);
      food.texture = texture;
      food.visible = true;
    } else {
      food = new PIXI.Sprite(PIXI.Texture.fromImage(data.src));
      this.foodPanel.addChild(food);
    }
    food.width = data.width;
    food.height = data.height;
    food.anchor.set(0.5);
    food.nodeName = "food";
    food.id = foodId;
    var pos = { x: Utils.RandomNum(-(this.bg.width / 2), this.bg.width / 2), y: Utils.RandomNum(-(this.bg.height / 2), this.bg.height / 2) };
    food.position.set(pos.x, pos.y);
    this.foodPanel.addChild(food);
    this.foodList.push(food);
  }
  createFoodByPos(pos) {
    // 初始化数据
    var member_list = res.foodList.list.concat();
    member_list.length--;
    if (!member_list.length) return;
    // 数据预处理
    const member_list_list_sorted = Utils.getSortedByWeight(member_list.map(i => i.id), member_list.map(i => i.odds))
    // 输出按分布选中的结果
    var foodId = Utils.getRandomByWeightWithSortedList(member_list_list_sorted) - 1;
    var food = this.foodPool.pop();
    var data = res.foodList.list[foodId];
    if (food) {
      var texture = PIXI.Texture.fromImage(data.src);
      food.texture = texture;
      food.visible = true;
    } else {
      food = new PIXI.Sprite(PIXI.Texture.fromImage(data.src));
      this.foodPanel.addChild(food);
    }
    food.width = data.width;
    food.height = data.height;
    food.anchor.set(0.5);
    food.position.set(pos.x, pos.y);
    food.nodeName = "food";
    food.id = foodId;
    this.foodList.push(food);
  }
  createProp() {
    var list = res.propList.list.concat();
    var propId = 0;
    if (this.reviveProp) {
      do {
        // 数据预处理
        const list_sorted = Utils.getSortedByWeight(list.map(i => i.id), list.map(i => i.odds))
        // 输出按分布选中的结果
        var propId = Utils.getRandomByWeightWithSortedList(list_sorted) - 1;
      } while (propId == 0);
    }
    var data = res.propList.list[propId];
    if (this.propNumList[data.id] >= data.maxCreaterNum) return;
    if (this.propList[data.id].length >= data.showMaxNum) return;
    this.propNumList[data.id]++;
    var prop = this.propPool.pop();
    if (prop) {
      var texture = PIXI.Texture.fromImage(data.src);
      prop.texture = texture;
      prop.visible = true;
    } else {
      prop = new PIXI.Sprite(PIXI.Texture.fromImage(data.src));
    }
    if (data.id == 1) this.reviveProp = prop
    prop.anchor.set(0.5);
    prop.width = data.width;
    prop.height = data.height;
    prop.nodeName = "prop";
    prop.id = propId;
    prop.visible = false;
    if (data.id == 2) {
      var fun = () => {
        if (this.propList[data.id].length >= data.showMaxNum) return;
        if (this.propNumList[data.id] >= data.maxCreaterNum) return;
        var pos = { x: Utils.RandomNum(-(this.bg.width / 2), this.bg.width / 2), y: Utils.RandomNum(-(this.bg.height / 2), this.bg.height / 2) };
        prop.position.set(pos.x, pos.y);
        if (!Utils.hitTest(prop, this.player.head)) {
          prop.visible = true;
          this.propPanel.addChild(prop);
          this.propList[data.id].push(prop);
          clearInterval(funId);
        }
      }
      var funId = setInterval(fun, 100)
    } else {
      prop.visible = true;
      var pos = { x: Utils.RandomNum(-(this.bg.width / 2), this.bg.width / 2), y: Utils.RandomNum(-(this.bg.height / 2), this.bg.height / 2) };
      prop.position.set(pos.x, pos.y);
      this.propPanel.addChild(prop);
      this.propList[data.id].push(prop);
    }
  }
  createEnemy() {
    var enemy = new Player(this.e, true, this.bg, this.options);
    this.node.addChild(enemy.node);
    this.enemyList.push(enemy);
  }

  snakeDie(snake) {
    if (snake.isDie) return;
    snake.isDie = true;
    snake.node.visible = false;
    var childList = snake.childList;
    for (var key in childList) {
      this.createFoodByPos(childList[key].position);
    }
    if (snake.isBot) {
      setTimeout(() => {
        this.reviveEnemy(snake);
      }, res.enemyReviveTime);
    } else {
      this.eventManager.emit('gameOver');
    }
  }
  reviveEnemy(snake) {
    snake.init();
    var colliders = snake.childList;
    //var temp = { x: this.player.head.x, y: this.player.head.y, width: this.player.head.width + 200, height: this.player.head.height + 200 };
    var { contacts } = this.check(colliders, this.player.head);
    if (contacts.length) {
      this.reviveEnemy(snake);
    }
    this.eventManager.emit('createrFood', this.foodList);
  }
  fix_update(delta) {
    var posX = -this.player.head.x + this.options.width / 2;
    var posY = -this.player.head.y + this.options.height / 2;
    var pos = Utils.lerp(this.node, { x: posX, y: posY }, 0.05);
    this.node.x = pos.x;
    this.node.y = pos.y;
    var width = this.bg.width / 2;
    var height = this.bg.height / 2;
    if (this.node.x > width) {
      this.node.x = width;
    }
    if (this.node.x < -width + this.options.width) {
      this.node.x = -width + this.options.width;
    }
    if (this.node.y > height) {
      this.node.y = height;
    } else if (this.node.y < -height + this.options.height) {
      this.node.y = -height + this.options.height;
    }

  }
  update(delta) {
    if (this.gameState) return;
    this.gameTime += delta;
    //this._now_time += delta;
    if (this.gameTime >= 100) {
      this.gameTime = 0;
      this.surplusTime--;
      this.eventManager.emit("setGameTime", this.surplusTime);
      if (this.doubleTime) this.doubleTime--;
    }
    if (this.surplusTime <= 0) {
      this.gameOver();
    }
    this.fix_update(delta);
    this.snakeHitTest(delta);
  }
  gameOver() {
    if (this.isOver) return;
    this.setGameState(true);
    this.isOver = true;
    this.eventManager.emit("gameOver", this.score);
  }
  revive() {
    if (!this.player.isDie) return;
    this.player.init(true);
    // //获取所有可碰撞物
    var colliders = [];
    for (var key in this.enemyList) {
      if (this.enemyList[key].isDie) continue;
      colliders = this.enemyList[key].childList.concat(colliders);
    }
    var temp = { x: this.player.head.x, y: this.player.head.y, wdith: this.player.head.width + 50, height: this.player.head.height + 50, parent: this.player.head.parent };
    //玩家碰撞
    var { contacts } = this.check(colliders, temp);
    if (contacts.length) {
      this.revive();
    }
  }
  check(colliders, testCollider) {
    const ret = { retrieve: [], contacts: [] };
    // 四叉树清理
    this._tree.clear();
    for (let i = 0, l = colliders.length; i < l; i++) {
      if (colliders[i].parent != testCollider.parent) {
        this._tree.insert(colliders[i]);
      }
    }
    // 四叉树抓出待检查的对象(属于那个块的所有节点)
    const retrieveObjects = this._tree.retrieve(testCollider);
    //return ret;
    retrieveObjects.forEach(element => {
      //ret.retrieve.push(element);
      // 抓出来后检查碰撞
      if (Utils.hitTest(element, testCollider)) {
        ret.contacts.push(element);
      }
    });
    return ret;
  }
  snakeHitTest(delta) {
    this.time += delta;
    this.propTime += delta;
    if (this.time >= res.foodList.createTime) {
      //setTimeout(this.createFood.bind(this), 10);
      this.createFood();
      this.eventManager.emit('createrFood', this.foodList);
      this.time = 0;
    }
    if (this.propTime >= res.propList.createTime) {
      // setTimeout(this.createProp.bind(this), 10);
      this.createProp();
      this.eventManager.emit('createrFood', this.foodList);
      this.propTime = 0;
    }
    if (!this.player.isDie && !Utils.boxesIntersect(this.player.head, this.bg)) {
      console.log("脱离地图!");
      this.eventManager.emit("setGameState", true);
      //this.player.isDie = true;
      this.snakeDie(this.player);
      return;
    }
    //获取所有可碰撞物
    var colliders = [];
    colliders = colliders.concat(this.foodList);
    colliders = colliders.concat(this.player.childList);
    for (var key in this.propList) {
      colliders = colliders.concat(this.propList[key]);
    }
    for (var key in this.enemyList) {
      if (this.enemyList[key].isDie || this.enemyList[key].isInvincible) continue;
      colliders = this.enemyList[key].childList.concat(colliders);
    }

    //玩家碰撞
    var { contacts } = this.check(colliders, this.player.head);
    if (contacts.length && !this.player.isDie) {
      if (contacts[0].nodeName == "body" || contacts[0].nodeName == "head") {
        this.eventManager.emit("setGameState", true);
        this.snakeDie(this.player);
        return;
      }
      if (contacts[0].nodeName == "food") {
        var data = res.foodList.list[contacts[0].id];
        var score = data.score;
        if (this.doubleTime) score = score * 2;
        this.score += score;
        this.player.score += score;
        this.eventManager.emit('updateScore', this.score);
        this.eventManager.emit('updateFoodList', data);
        // if (this.player.score % res.addLenScore.score == 0) {
        //   for (var j = 0; j < res.addLenScore.value; j++) {
        //     this.player.addSnakeLen();
        //   }
        // }
        contacts[0].visible = false;
        this.foodPool.push(contacts[0]);
        for (var key in this.foodList) {
          if (this.foodList[key] == contacts[0]) {
            this.foodList.splice(key, 1);
            return;
          }
        }
      }
      if (contacts[0].nodeName == "prop") {
        var data = res.propList.list[contacts[0].id];
        this.eventManager.emit("updatePropList", data);
        switch (data.id) {
          case 1://复活
            this.reviveProp = null;
            break;
          case 2://炸弹
            this.eventManager.emit("setGameState", true);
            this.snakeDie(this.player);
            break;
          case 3://双倍得分
            this.doubleTime = data.time;
            break;
        }
        contacts[0].visible = false;
        this.propPool.push(contacts[0]);
        for (var key in this.propList) {
          for (var i = 0; i < this.propList[key].length; i++) {
            if (this.propList[key][i] == contacts[0]) {
              this.propList[key].splice(i, 1);
              return;
            }
          }
        }
      }
    }
    //机器人碰撞
    for (var key in this.enemyList) {
      if (this.enemyList[key].isDie) continue;
      var { contacts } = this.check(colliders, this.enemyList[key].head);
      if (contacts.length) {
        if (contacts[0].nodeName == "body" || contacts[0].nodeName == "head") {
          this.snakeDie(this.enemyList[key]);
          var code = contacts[0].parent.script;
          if (!code.isBot) {
            this.killNum++;
            this.eventManager.emit("updateKillNum", this.killNum);
          }
          return;
        }
        if (contacts[0].nodeName == "food") {
          contacts[0].visible = false;
          this.foodPool.push(contacts[0]);
          for (var key in this.foodList) {
            if (this.foodList[key] == contacts[0]) {
              this.foodList.splice(key, 1);
              return;
            }
          }
        }
        if (contacts[0].nodeName == "prop") {
          var data = res.propList.list[contacts[0].id];
          if (data.id == 2) {
            this.snakeDie(this.enemyList[key]);
            contacts[0].visible = false;
            this.propPool.push(contacts[0]);
            for (var key in this.propList) {
              for (var i = 0; i < this.propList[key].length; i++) {
                if (this.propList[key][i] == contacts[0]) {
                  this.propList[key].splice(i, 1);
                  return;
                }
              }
            }
          }
        }
      }
    }
  }
}