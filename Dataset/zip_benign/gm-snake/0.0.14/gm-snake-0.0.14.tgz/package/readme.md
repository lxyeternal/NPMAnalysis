# 贪吃蛇

# 游戏

##### 安装

```
npm install gm-snake
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "gm-snake/snake_com"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "gm-snake"
  ]
}
```

- js

```
Page({
  data: {
    appOptions: {
      width: 750,
      height: 1200,
      gameConfig: {
        snake: {//蛇配置
          head: {//头
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01i2mQHy23c03Sb7T3X_!!555657275.png",
            width: 47,
            height: 48
          },
          body: {//身体
            src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01ggjzdG23c03aCS1Yf_!!555657275.png",
            width: 250,
            height: 47
          }
        },
        enemyNum: 0,//机器人数量
        enemyReviveTime: 3000,//机器人复活间隔1000=1秒
        joystick: {//摇杆配置
          wheel: {
            src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01wSHs9D23c03Y3Lzkz_!!555657275.png",
            width: 39,
            height: 39
          },
          wheel_bg: {
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Jm7jX623c03Y3Lzks_!!555657275.png",
            width: 190,
            height: 190
          }
        },
        map: {//地图配置
          src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01mESD4d23c03MCiFB1_!!555657275.png",
          width: 3500,
          height: 4100,
        },
        propList: {//物品配置
          createTime: 1,//生成间隔
          list: [//maxCreaterNum:一局最多生成道具数量 showMaxNum:同时存在的最大数量   time:双倍得分持续时间
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01sbcYCQ23c03P8l5fI_!!555657275.png", width: 49, height: 65, odds: 1, id: 1, maxCreaterNum: 10, showMaxNum: 1 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01f8nVT423c03RGpkcv_!!555657275.png", width: 38, height: 43, odds: 1, id: 2, maxCreaterNum: 100, showMaxNum: 10 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Wpstj323c03M60Xvx_!!555657275.png", width: 70, height: 70, odds: 1, id: 3, time: 10, maxCreaterNum: 100, showMaxNum: 10 }
          ]
        },
        foodList: {//食物配置
          createTime: 0.5,//生成间隔
          maxNum: 100,//最大食物数量(不包含死亡后生成的)
          list: [
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01J9OlkL23c03LUOgrs_!!555657275.png", width: 34, height: 48, score: 1, odds: "0.6", id: 1 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01Dmjq2T23c03QCgkSU_!!555657275.png", width: 25, height: 33, score: 1, odds: "0.5", id: 2 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01OBtNzY23c03aa5J4Q_!!555657275.png", width: 25, height: 33, score: 1, odds: "0.4", id: 3 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01PIdnzF23c03Zk1oac_!!555657275.png", width: 25, height: 33, score: 1, odds: "0.3", id: 4 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN0114B4iu23c03UcAlIY_!!555657275.png", width: 25, height: 33, score: 1, odds: "0.2", id: 5 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01u7lGmg23c03QCixhS_!!555657275.png", width: 25, height: 33, score: 1, odds: "0.1", id: 6 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Q5b1rO23c03U8xGUV_!!555657275.png", width: 25, height: 33, score: 1, odds: "0.1", id: 7 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01QsJA0o23c03U5l9t7_!!555657275.png", width: 34, height: 48, score: 1, odds: "0.1", id: 8 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01WQgTyO23c03aa6NZt_!!555657275.png", width: 34, height: 48, score: 1, odds: "0.1", id: 9 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01OjV45N23c03XZCyIl_!!555657275.png", width: 34, height: 48, score: 1, odds: "0.1", id: 10 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN016XQllX23c03G1LujA_!!555657275.png", width: 64, height: 63, score: 10, odds: "0.1", id: 11 }
          ]
        },
        socre: {//得分面板配置
          src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN015fzWWR23c03OD7BY4_!!555657275.png",
          width: 80,
          height: 80,
          pos: { x: 50, y: 120, align: 1, },//align:对齐方式 0左对齐1居中对齐2右对齐
          numPos: { x: 50, y: 200, align: 1, leftOffset: 10 },//leftOffset 靠左偏移量
          numArr: [
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01ZTTwJg23c03Hab3aw_!!555657275.png", width: 35, height: 35, val: 0 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01Mj0bg723c03QWnxTF_!!555657275.png", width: 35, height: 35, val: 1 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01cbDU5A23c03R6lUjF_!!555657275.png", width: 35, height: 35, val: 2 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01yhaWgb23c03Ph0Vwg_!!555657275.png", width: 35, height: 35, val: 3 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01p4iK7H23c03Ph3SrC_!!555657275.png", width: 35, height: 35, val: 4 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN012GCNXu23c03MjkXbT_!!555657275.png", width: 35, height: 35, val: 5 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01RMxzTq23c03QWpQx4_!!555657275.png", width: 35, height: 35, val: 6 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN016UQm3I23c03I9px3l_!!555657275.png", width: 35, height: 35, val: 7 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01j2OoQ023c03GFncr1_!!555657275.png", width: 35, height: 35, val: 8 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKVBg823c03O1Amte_!!555657275.png", width: 35, height: 35, val: 9 },
          ]
        },
        time: {
          src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01Me25Ji23c03Ld63hs_!!555657275.png",
          value: 90,
          width: 100,
          height: 80,
          pos: { x: 50, y: 0, align: 1 },//align:对齐方式 0左对齐1居中对齐2右对齐
          numPos: { x: 50, y: 80, align: 1, leftOffset: 10 },//leftOffset 靠左偏移量
          numArr: [
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01ZTTwJg23c03Hab3aw_!!555657275.png", width: 35, height: 35, val: 0 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01Mj0bg723c03QWnxTF_!!555657275.png", width: 35, height: 35, val: 1 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01cbDU5A23c03R6lUjF_!!555657275.png", width: 35, height: 35, val: 2 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01yhaWgb23c03Ph0Vwg_!!555657275.png", width: 35, height: 35, val: 3 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01p4iK7H23c03Ph3SrC_!!555657275.png", width: 35, height: 35, val: 4 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN012GCNXu23c03MjkXbT_!!555657275.png", width: 35, height: 35, val: 5 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01RMxzTq23c03QWpQx4_!!555657275.png", width: 35, height: 35, val: 6 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN016UQm3I23c03I9px3l_!!555657275.png", width: 35, height: 35, val: 7 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01j2OoQ023c03GFncr1_!!555657275.png", width: 35, height: 35, val: 8 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKVBg823c03O1Amte_!!555657275.png", width: 35, height: 35, val: 9 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKN1kT23c03R6nyYW_!!555657275.png", width: 35, height: 35, val: "s" },
          ]
        },
        kill: {
          src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01Vv5w1i23c03Ramlqz_!!555657275.png",
          width: 80,
          height: 80,
          pos: { x: 50, y: 240, align: 1 },//align:对齐方式 0左对齐1居中对齐2右对齐
          numPos: { x: 50, y: 320, align: 1, leftOffset: 10 },//leftOffset 靠左偏移量
          numArr: [
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01ZTTwJg23c03Hab3aw_!!555657275.png", width: 35, height: 35, val: 0 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01Mj0bg723c03QWnxTF_!!555657275.png", width: 35, height: 35, val: 1 },
            { src: "https://img.alicdn.com/imgextra/i1/555657275/O1CN01cbDU5A23c03R6lUjF_!!555657275.png", width: 35, height: 35, val: 2 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01yhaWgb23c03Ph0Vwg_!!555657275.png", width: 35, height: 35, val: 3 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01p4iK7H23c03Ph3SrC_!!555657275.png", width: 35, height: 35, val: 4 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN012GCNXu23c03MjkXbT_!!555657275.png", width: 35, height: 35, val: 5 },
            { src: "https://img.alicdn.com/imgextra/i4/555657275/O1CN01RMxzTq23c03QWpQx4_!!555657275.png", width: 35, height: 35, val: 6 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN016UQm3I23c03I9px3l_!!555657275.png", width: 35, height: 35, val: 7 },
            { src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01j2OoQ023c03GFncr1_!!555657275.png", width: 35, height: 35, val: 8 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKVBg823c03O1Amte_!!555657275.png", width: 35, height: 35, val: 9 },
            { src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01BKN1kT23c03R6nyYW_!!555657275.png", width: 35, height: 35, val: "s" },
          ]
        },
      }
    },
  },
  //暂停游戏
  onSuspendGame() {
    this.snakeCom.onSetGameState(1);
  },
  //继续游戏
  onContinueGame() {
    this.snakeCom.onSetGameState(0);
  },
  //重玩游戏
  onRestartGame() {
    this.snakeCom.onRestartGame();
  },
  //复活
  onRevive() {
    this.snakeCom.onRevive();
  },
  //游戏加载完成
  onGameComplete() {
    console.log("init...")
  },
  //游戏结束
  onGameOver(score, foodList, killNum) {
    console.log("得分:" + score);
    console.log("食物列表:", foodList);
    console.log("击败:" + killNum);
  },
  onUpdateFood(data) {
    console.log("吃到食物:", data);
  },
  onEatProp(data) {
    console.log("吃到道具", data);
  },
});
```

- xaml

```
  <game options="{{appOptions}}" onGameOver="onGameOver" onUpdateFood="onUpdateFood" onGameComplete="onGameComplete" onEatProp="onEatProp"/>
```