# polymm SDK

Forked from the [Uniswap SDK](https://github.com/Uniswap/uniswap-v2-sdk/commit/a88048e9c4198a5bdaea00883ca00c8c8e582605).

You can refer to the Uniswap SDK documentation [uniswap.org](https://uniswap.org/docs/v2/SDK/getting-started/).

## Running tests

To run the tests, follow these steps. You must have at least node v10 and [yarn](https://yarnpkg.com/) installed.

First clone the repository:

```sh
git clone https://github.com/polymmfin/pancake-swap-sdk.git
```

Move into the pancakeswap-sdk working directory

```sh
cd pancakeswap-sdk/
```

Install dependencies

```sh
yarn install
```

Run tests

```sh
yarn test
```

You should see output like the following:

```sh
yarn run v1.22.4
$ tsdx test
 PASS  test/constants.test.ts
 PASS  test/pair.test.ts
 PASS  test/fraction.test.ts
 PASS  test/miscellaneous.test.ts
 PASS  test/entities.test.ts
 PASS  test/trade.test.ts

Test Suites: 1 skipped, 6 passed, 6 of 7 total
Tests:       3 skipped, 82 passed, 85 total
Snapshots:   0 total
Time:        5.091s
Ran all test suites.
✨  Done in 6.61s.
```



Testnet details
RPC: https://rpc-testnet.mchain.dev/
Explorer: https://explorer-testnet.mchain.dev/

const MCHAIN_FACTORY = "0x89dBC8Bd9a6037Cbd6EC66C4bF4189c9747B1C56";
const MEERKAT_ROUTER = "0xfe3699303D3Eb460638e8aDA2bf1cFf092C33F22"
const WKAT = "0xE48105c589afdE658AA14b8B5bAd13D2b6B3437a";
const INIT_CODE_HASH = "0x396179b3f07869a07d1ea40712b9088df574ac13d11106ab1cfc7f7437050efe"

const MASTER_CHEF = "0xa73Ae666CEB460D5E884a20fb30DE2909604557A";

Trading fees: 0.3%
LP fees: 0.25%