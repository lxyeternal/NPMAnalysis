const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = {
    entry: "./src/index.jsx",
    output: {
        path: path.join(__dirname, "/dist"),
        filename: "index.js"
    },
    module: {
        rules: [{
                test: /\.(js|jsx)$/,
                include: [
                    /libs|src|sbx-.+/,
                ],
                use: [{
                    loader: "babel-loader",
                    options: {
                        presets: ['@babel/preset-env', '@babel/react'],
                        plugins: [
                            require('@babel/plugin-syntax-dynamic-import'),
                            require('@babel/plugin-proposal-object-rest-spread'),
                            [require('@babel/plugin-proposal-decorators'), {
                                "legacy": true
                            }],
                            [require('@babel/plugin-proposal-class-properties'), {
                                "loose": true
                            }],
                        ]
                    }
                }],
            },
            {
                test: /\.(svg)$/,
                use: [{
                    loader: 'url-loader',
                    query: {
                        name: '[name]-[hash].[ext]'
                    }
                }],
            },
            {
                test: /\.scss$/,
                use: ['style-loader', 'css-loader', 'sass-loader']
            },
            {
                test: /\.css$/,
                use: ['style!css']
            },
            {
                test: /\.(jpe?g|png|gif)$/,
                use: [{
                    loader: "file-loader",
                    options: {
                        name: '[name]-[hash].[ext]'
                    }
                }],
            }
        ]
    },
    resolve: {
        extensions: ['*', '.json', '.js', '.jsx'],
        alias: {
            libs: path.join(__dirname, "/libs"),
            src: path.join(__dirname, "/src"),
        }
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: "./src/index.html"
        })
    ],
    devServer: {
        historyApiFallback: true
    }
};