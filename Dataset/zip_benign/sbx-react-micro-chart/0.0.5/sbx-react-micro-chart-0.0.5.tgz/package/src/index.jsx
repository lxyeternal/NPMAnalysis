import './index.scss'
import React from "react";
import ReactDOM from "react-dom";
import Chart from '../libs/index';

function getData(){
    let data = [];
    for(let i = 0; i < 20; i++){
        data.push(
            Math.random() * 100,
        )
    }
    return data;
}

class App extends React.Component {
    render() {
        return <div className="container">
            <div className="row">
                <div className="col-12">
                    <Chart
                        limits={true}
                        digits={3}
                        data={[
                            20,
                            20,
                            20,
                            20,
                            20,
                            20,
                            20,
                            20,
                            10,
                            40,
                            30,
                            50,
                            60,
                            70,
                            90,
                        ]}
                        stroke={'rgb(32,205,32)'}
                        gradient={[
                            'rgb(32,205,32)',
                            'rgba(32,205,32, 0.3)',
                        ]}
                    />
                </div>
            </div>
        </div>
    }
}


ReactDOM.render(<App />, document.getElementById("root"));
