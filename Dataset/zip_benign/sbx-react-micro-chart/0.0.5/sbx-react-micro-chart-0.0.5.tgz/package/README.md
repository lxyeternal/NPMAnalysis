## SBX React MicroChart
***

```
sbx i --save sbx-react-micro-chart
```
---

#### Props

```
gradient: [
    'rgba(255, 255, 255, 0.5)',
    'rgba(255, 255, 255, 0.8)',
],
stroke: '#fff',
data: [],
width: 270,
height: 100,
strokeWidth: 2
```

```
import Chart from 'sbx-react-micro-chart';

<Chart data=[1,2,3,4,5] />
```