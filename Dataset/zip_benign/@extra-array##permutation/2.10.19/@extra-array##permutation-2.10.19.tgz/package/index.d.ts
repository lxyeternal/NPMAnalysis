declare module "@extra-array/permutation" {
/**
 * Picks an arbitrary permutation.
 * @param x an array
 * @param n number of values (-1 => any)
 * @param r random seed 0->1
 */
declare function permutation<T>(x: T[], n?: number, r?: number): T[];
export = permutation;
//# sourceMappingURL=permutation.d.ts.map}
