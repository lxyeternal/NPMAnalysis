# phoenix-video-player

<!-- START doctoc -->
<!-- END doctoc -->

## Usage

To include phoenix-video-player on your website or web application, use the following method.

```html
<script src="//path/to/phoenix-video-player.min.js"></script>
```

The `phoenixPlayer` function also accepts an `options` object and a callback to be invoked
when the player is ready:

```js

var options = {
	autoplay: false,
	controls: true,
	playbackRates: [0.5, 1, 1.25, 1.5, 3],
	language: 'fa',
	addLanguage: { fa: fa },
	poster: '',
	sources: [],

	info: { title: null, subTitle: null },
	returnUrl: null,
	pluginOptions: {
		seekThumbnailSrc: null,
		seekButtons: {
			forward: 30,
			back: 10,
			forwardIndex: 1,
			backIndex: 1
		},
		nextEpisode: {
			url: '',

			autoAdvance: true,
			showAutoAdvanceButton: true,
			autoAdvanceButtonText: 'قسمت بعدی',
			nextEpisodeDisplayTime: null,
			nextEpisodeDisplayDuration: 10,

			dialogData: {
				title: '',
				description: '',
				url: ``
			},
			dialogTemplate: ({ title, description, url }) => {
				return 'some htmlDom';
			}
			placementIndex: 9,
		},
		skipButton: {
			text: 'skipOpeningCredits',
			from: null,
			to: null,
			position: 'bottom-right',
			offsetH: 46,
			offsetV: 167
		},
		trafficUsage: {
			title: null,
			message: null,
			expireTime: 5, // minute
			position: 'top-right',
			offsetH: 46,
			offsetV: 46
		},
		subtitleSettings: {},
		seasonPlaylist: {
			seasons: null, // array of number
			getEpisode: (season, page, callback) => {
				callback({
					alias: '',
					duration: 0,
					link: '',
					part: 0,
					season: 0,
					thumbnail: '',
					title: null
				});
			}
		},
		vote: {
			submitVote: ({ likeStatus, callback }) => {}, //Tips: likeStatus returns 1 if liked and 2 if disliked
			from: null,
			to: null,
			position: 'bottom-right',
			offsetH: 46,
			offsetV: 167
		},
		collectData: {
			token: ''
		},
		markers: {
			markerTip: {
				display: false,
				skip: true
			},
			onMarkerReached: (marker, index) => {
				console.log(marker, index);
			},
			onMarkerSkipZone: (marker, index) => {
				console.log('onMarkerSkipZone');
			},
			markers: [{ time: null, duration: null }]
		}
	}
	initPlugins: {
	  ...pluginNames
	},
	controlBar: { children: ['componentName'] },
};

var phoenixPlayer = phoenixPlayer('my-player', options, function onPlayerReady() {
  videojs.log('Your player is ready!');

  // In this context, `this` is the player that was created by Video.js.
  this.play();

  // How about an event listener?
  this.on('ended', function() {
    videojs.log('Awww...over so soon?!');
  });
});
```

[videojs]: http://videojs.com/
