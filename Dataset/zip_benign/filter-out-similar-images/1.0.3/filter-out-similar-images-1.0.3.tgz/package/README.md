filter-out-similar-images
==================

Given a list of images, filters out images that are too similar to each other.

Installation
------------

    npm install filter-out-similar-images

Usage
-----

    var filterOutSimilarImages = require('filter-out-similar-images');
    filterOutSimilarImages(
      {
        images: [
          {
            id: 'a',
            buffer: <image buffer>
          },
          {
            id: 'b',
            buffer: <image buffer>
          },
          {
            id: 'c',
            buffer: <image buffer>
          },
          {
            id: 'd',
            buffer: <image buffer>
          }
        ],
        maximumCloseness: 0.3 // Value between 0 and 1, 1 being completely different, 0 being exactly the same.
      },
      done
    );

    function done(error, filtered) {
      if (error) {
        console.error(error);
      } else {
        console.log(filtered);
      }
    }

Output:

    [
      {
        id: 'a',
        buffer: <image buffer>,
        pHash: <some binary number in string form>
      },
      {
        id: 'c',
        buffer: <image buffer>,
        pHash: <some binary number in string form>
      }
    ]

Tests
-----

Run tests with `make test`.

License
-------

The MIT License (MIT)

Copyright (c) 2018 Jim Kang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
