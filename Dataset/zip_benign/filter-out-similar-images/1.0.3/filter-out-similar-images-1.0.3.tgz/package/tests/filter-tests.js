/* global __dirname */

var test = require('tape');
var filterOutSimilarImages = require('../index');
var fs = require('fs');
var assertNoError = require('assert-no-error');

const baseTestImagesPath = __dirname + '/fixtures/';

var testCases = [
  {
    opts: {
      images: [
        {
          id: 'a',
          buffer: fs.readFileSync(baseTestImagesPath + 'das-daf-man-nicht.jpg')
        },
        {
          id: 'b',
          buffer: fs.readFileSync(
            baseTestImagesPath + 'das-daf-man-nicht-single.jpg'
          )
        },
        {
          id: 'c',
          buffer: fs.readFileSync(
            baseTestImagesPath + 'weinger-sind-mehr-1.jpg'
          )
        },
        {
          id: 'd',
          buffer: fs.readFileSync(
            baseTestImagesPath + 'weinger-sind-mehr-2.jpg'
          )
        }
      ],
      maximumCloseness: 0.35, // Value between 0 and 1, 1 being completely different, 0 being exactly the same.
      debug: true
    },
    expectedIds: ['a', 'c']
  }
];

testCases.forEach(runTest);

function runTest(testCase) {
  test('Filter test', filterTest);

  function filterTest(t) {
    filterOutSimilarImages(testCase.opts, checkResult);

    function checkResult(error, filtered) {
      // console.log(filtered);
      assertNoError(
        t.ok,
        error,
        'No error when calling filterOutSimilarImages.'
      );
      t.deepEqual(
        filtered.map(i => i.id),
        testCase.expectedIds,
        'Filtered ids are correct.'
      );
      t.end();
    }
  }
}
