export declare function set(value: Record<string, any>): Record<string, any>;
export declare function play(value: string): string;
export declare function pick(action: Record<string, any>): string[];
export declare function scramble(action: Record<string, any>): string[];
export declare function callsign(action: Record<string, any>): string;
export declare function states(): string[];
export declare function letters(): string[];
export declare function numbers(): string[];
export declare function alphanumeric(): string[];
