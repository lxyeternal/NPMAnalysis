export interface TSubscriber {
    event: string;
    cb: Function;
}
export declare class Emitter {
    subscribers: TSubscriber[];
    constructor();
    on(event: string, cb: Function): () => void;
    emit(event: String, value: any): void;
}
