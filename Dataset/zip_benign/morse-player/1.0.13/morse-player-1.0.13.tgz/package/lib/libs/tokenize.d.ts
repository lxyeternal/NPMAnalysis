export declare function tokenize(script: string): {
    more: () => number;
    next: (regex: RegExp) => string;
    near: () => string;
};
