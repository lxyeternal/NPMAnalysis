import { BaseAudio, TAudioOptions } from './base-audio';
export declare class WebAudio extends BaseAudio {
    audioCtx: AudioContext;
    gainNode: GainNode;
    gainNodePlay: GainNode;
    gainNodeLimiter: GainNode;
    oscillator: OscillatorNode;
    biquadFilter: BiquadFilterNode;
    noiseFilterL: BiquadFilterNode;
    noiseFilterH: BiquadFilterNode;
    whiteNoise: AudioBufferSourceNode;
    gain: number;
    constructor(opts: TAudioOptions);
    setAudio(opts: TAudioOptions, time?: number): void;
    setPause(isPause: boolean): void;
    getTime(): number;
    playTone(time: number, duration: number): number;
    cancelPlay(): void;
}
