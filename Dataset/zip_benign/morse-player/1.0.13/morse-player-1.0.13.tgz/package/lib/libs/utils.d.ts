export declare function backoff(start: number, end: number): Float32Array;
export declare function rand(size: number): number;
export declare function countMap(count: number, cb: Function): any[];
export declare function scrambleList<Type>(list: Type[]): Type[];
export declare function randomEntry<Type>(list: Type[]): Type;
export declare function splitVocab(text: string): string[];
export declare function toList(list: string | string[]): string[];
export declare function toNumber(value: any): number;
export declare function randCallsign(min?: number, max?: number, vocabs?: string): string;
