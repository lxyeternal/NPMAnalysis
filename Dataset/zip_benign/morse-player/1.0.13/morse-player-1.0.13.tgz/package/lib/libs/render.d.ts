export type TActionResult = string | string[] | Record<string, any>;
export type TRenderResult = string | Record<string, any>;
export declare function render(script: string): TRenderResult[];
