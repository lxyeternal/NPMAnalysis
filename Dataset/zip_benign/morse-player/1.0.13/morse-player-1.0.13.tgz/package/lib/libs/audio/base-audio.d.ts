export interface TAudioOptions {
    q: number;
    freq: number;
    gain: number;
    volume: number;
}
export declare abstract class BaseAudio {
    constructor(opts: TAudioOptions);
    setAudio(opts: TAudioOptions, time?: number): void;
    setPause(isPause: boolean): void;
    getTime(): void;
    playTone(time: number, duration: number): void;
    cancelPlay(): void;
}
