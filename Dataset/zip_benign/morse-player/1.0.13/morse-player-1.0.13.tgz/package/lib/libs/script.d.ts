import { TRenderResult } from './render';
export type TScriptValue = (string | Record<string, any>);
export type TScriptPlay = (count: number, buffer?: TRenderResult) => string;
export interface TBufferEntry {
    index: number;
    charIndex: number;
    startPercent?: number;
    endPercent?: number;
    startTime?: number;
    endTime?: number;
    name: string;
    value: TScriptValue;
}
export declare class Script {
    input: string | TScriptPlay;
    cbMethod: TScriptPlay;
    cbCount: number;
    buffer: TRenderResult[];
    charIndices: number[];
    index: number;
    playTotal: number;
    playCount: number;
    constructor(input: string | TScriptPlay);
    _toCharIndices(buffer: TRenderResult[]): number[];
    _getPlayTotal(): number;
    _getPlayCount(): number;
    getNext(advance?: boolean): TBufferEntry;
    rollback(entry: TBufferEntry): void;
    rewind(words?: number): void;
    _seekLastSpace(index: number): number;
    _seekNextWord(index: number): number;
    _seekLastWord(index: number): number;
    _fetchMore(): void;
}
