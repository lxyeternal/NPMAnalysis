/// <reference types="node" />
import { Script, TScriptPlay } from './script';
import { Options } from './options';
import { Schedule } from './schedule';
import { Emitter } from './emitter';
import { WebAudio } from './audio/web-audio';
import { MockAudio } from './audio/mock-audio';
import { TAudioOptions } from './audio/base-audio';
export interface TPlayerOptions {
    volume: number;
    gain: number;
    freq: number;
    q: number;
    wpm: number;
    eff: number;
    color: string;
}
export declare class Player extends Emitter {
    options: Options;
    schedule: Schedule;
    id: string;
    mode: string;
    audio: WebAudio | MockAudio;
    script: Script;
    tickRef: number | NodeJS.Timeout;
    tickSpan: number;
    isPlaying: boolean;
    isPaused: boolean;
    dotTime: number;
    spaceTime: number;
    gapTime: number;
    constructor(defaultOptions?: Partial<TPlayerOptions>, mode?: string);
    getOptions(): Record<string, any>;
    setOptions(options: Record<string, any>, isScript?: boolean): void;
    _setOptions(options: Record<string, any>): Record<string, any>;
    init(): void;
    play(input: string | TScriptPlay, options?: Record<string, any>): void;
    _initAudio(opts: TAudioOptions): WebAudio | MockAudio;
    _playChar(event: Record<string, any>, time: number): any;
    _playTone(size: number, time: number): number;
    _onTick(): void;
    _stopTick(): void;
    stop(): void;
    pause(): void;
    replay(): void;
    rewind(wordCount?: number): void;
}
