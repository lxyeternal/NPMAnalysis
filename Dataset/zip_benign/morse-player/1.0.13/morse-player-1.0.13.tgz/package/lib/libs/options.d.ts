export declare class Options {
    defaults: Record<string, any>;
    user: Record<string, any>;
    script: Record<string, any>;
    options: Record<string, any>;
    constructor(opts: Record<string, any>);
    setUser(opts: Record<string, any>): Record<string, any>;
    setScript(opts?: Record<string, any>, isCombine?: boolean): Record<string, any>;
    get(): Record<string, any>;
    reduce(): {
        defaults: Record<string, any>;
        user: Record<string, any>;
        script: Record<string, any>;
        combined: {
            [x: string]: any;
        };
    };
    _prune<Type>(obj: any): Type;
}
