import { BaseAudio, TAudioOptions } from './base-audio';
export declare class MockAudio extends BaseAudio {
    opts: TAudioOptions;
    time: number;
    constructor(opts: TAudioOptions);
    setAudio(opts: TAudioOptions, time?: number): void;
    setPause(isPause: boolean): void;
    getTime(): number;
    playTone(time: number, duration: number): number;
    cancelPlay(): void;
}
