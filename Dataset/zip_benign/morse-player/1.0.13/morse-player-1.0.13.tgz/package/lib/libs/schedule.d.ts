import { Player } from './player';
import { TBufferEntry } from './script';
export declare class Schedule {
    queue: TBufferEntry[];
    event: TBufferEntry;
    headTime: number;
    tailTime: number;
    queueSize: number;
    player: Player;
    constructor(player: Player);
    reset(): TBufferEntry;
    canPush(currentTime: number): boolean;
    push(entry: TBufferEntry): void;
    advance(): boolean;
    _endCurrentEvent(): boolean;
    _startNextEvent(): boolean;
}
