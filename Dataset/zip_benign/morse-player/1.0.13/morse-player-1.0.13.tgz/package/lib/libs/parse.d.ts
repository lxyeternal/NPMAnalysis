export type TParseValue = (string | Record<string, any>);
export interface TParseAction {
    name: string;
    value: TParseValue;
    as: string;
}
export declare function parse(script: string): TParseAction[];
