export declare const callsigns: {
    name: string;
    size: number;
    format: string;
}[];
