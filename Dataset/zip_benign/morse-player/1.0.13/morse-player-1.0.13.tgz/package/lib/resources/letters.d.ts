export declare const letters: {
    name: string;
    value: string;
}[];
