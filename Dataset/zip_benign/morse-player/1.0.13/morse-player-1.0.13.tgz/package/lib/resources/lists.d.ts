export declare const ALPHA: string[];
export declare const NUMERIC: string[];
export declare const ALPHA_NUMERIC: string[];
export declare const CALLSIGN_FORMATS: string[];
export declare const CALLSIGN_VOCABS: {
    "1x1": string;
    "1x2": string;
    "1x3": string;
    "2x1": string;
    "2x2": string;
    "2x3": string;
    lnl: string;
    lnll: string;
    lnlll: string;
    llnl: string;
    llnll: string;
    llnlll: string;
    complex: string;
};
