export declare const numbers: {
    name: string;
    value: string;
}[];
