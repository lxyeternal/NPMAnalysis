export declare const states: ({
    name: string;
    value: string;
    zone: number;
    licenses: number;
} | {
    name: string;
    value: string;
    licenses: number;
    zone?: undefined;
})[];
