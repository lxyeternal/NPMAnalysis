# Mongoose-elastic

Do stuff with elastic and mongoose

## Version
0.3

## Tech
* Mongoose

## Directory Structure
```sh
|---mongoose-elastic
   |-lib
   |-test
```
## Install
```sh
npm install mongoose-elastic --save
```

## Setup

Add a mapping and prefix.
```sh
activitySchema.plugin(elastic, { prefix: 'dev',
  mapping: {

    message: String,
    event: {
      title: String
    }
  }
})
```

## syncAll

Sync things.
```sh
Activity.syncAll(function(err) {
   if (err) {
     console.log(err);
  }

  console.log('done!');
})
```

### sync

```sh
activity.sync(function() {})
```

## search
Global
```sh
elastic.search.config({ prefix: 'stage' });
elastic.search({ collections: ['activities'] }, function(err, results) {
  if (err) {
    console.log(err);
  }

  console.log(results);
})
```
Just a collection
```sh
Activity.search({ prefix: 'dev' }, function(err, results) {
  if (err) {
    console.log(err);
  }

  console.log(results);
})
```
## Tests
-----------
```sh
make test
```

