"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(require("./PhoneNumber"), exports);
__exportStar(require("./Webhook"), exports);
__exportStar(require("./VoiceId"), exports);
__exportStar(require("./Status"), exports);
__exportStar(require("./Tools"), exports);
__exportStar(require("./CallId"), exports);
__exportStar(require("./CustomTool"), exports);
__exportStar(require("./ErrorBody"), exports);
__exportStar(require("./ErrorDetail"), exports);
