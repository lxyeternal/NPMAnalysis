"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.webAgents = exports.voices = exports.sms = exports.outboundNumbers = exports.inboundNumbers = exports.commons = exports.calls = exports.batches = void 0;
exports.batches = __importStar(require("./batches"));
__exportStar(require("./batches/types"), exports);
exports.calls = __importStar(require("./calls"));
__exportStar(require("./calls/types"), exports);
exports.commons = __importStar(require("./commons"));
__exportStar(require("./commons/types"), exports);
exports.inboundNumbers = __importStar(require("./inboundNumbers"));
__exportStar(require("./inboundNumbers/types"), exports);
exports.outboundNumbers = __importStar(require("./outboundNumbers"));
__exportStar(require("./outboundNumbers/types"), exports);
exports.sms = __importStar(require("./sms"));
__exportStar(require("./sms/types"), exports);
exports.voices = __importStar(require("./voices"));
__exportStar(require("./voices/types"), exports);
exports.webAgents = __importStar(require("./webAgents"));
__exportStar(require("./webAgents/types"), exports);
__exportStar(require("./commons/errors"), exports);
__exportStar(require("./batches/client/requests"), exports);
__exportStar(require("./calls/client/requests"), exports);
__exportStar(require("./voices/client/requests"), exports);
