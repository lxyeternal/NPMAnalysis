import { TestScheduler } from 'rxjs/testing';
/**
 * Exported return type of TestMessage[] to avoid importing internal APIs.
 */
export declare type TestMessages = ReturnType<typeof TestScheduler.parseMarbles>;
/**
 * Exported return type of SubscriptionLog to avoid importing internal APIs.
 */
export declare type SubscriptionLogs = ReturnType<typeof TestScheduler.parseMarblesAsSubscriptions>;
