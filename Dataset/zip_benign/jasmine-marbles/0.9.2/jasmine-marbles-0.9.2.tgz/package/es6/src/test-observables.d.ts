import { Observable } from 'rxjs';
import { SubscriptionLogs } from './types';
export declare class TestColdObservable extends Observable<any> {
    marbles: string;
    values?: {
        [name: string]: any;
    } | undefined;
    error?: any;
    constructor(marbles: string, values?: {
        [name: string]: any;
    } | undefined, error?: any);
    getSubscriptions(): SubscriptionLogs[];
}
export declare class TestHotObservable extends Observable<any> {
    marbles: string;
    values?: {
        [name: string]: any;
    } | undefined;
    error?: any;
    constructor(marbles: string, values?: {
        [name: string]: any;
    } | undefined, error?: any);
    getSubscriptions(): SubscriptionLogs[];
}
export declare type TestObservable = TestColdObservable | TestHotObservable;
