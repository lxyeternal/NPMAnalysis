import { ObservableNotification } from 'rxjs';
import { TestMessages } from './types';
export declare function mapSymbolsToNotifications(marbles: string, messagesArg: TestMessages): {
    [key: string]: ObservableNotification<any>;
};
