/**
 * @see https://github.com/ReactiveX/rxjs/blob/master/spec/helpers/observableMatcher.ts
 */
export declare function observableMatcher(actual: any, expected: any): void;
