import { ObservableNotification } from 'rxjs';
import { TestMessages } from './types';
export declare function unparseMarble(result: TestMessages, assignSymbolFn: (a: ObservableNotification<any>) => string): string;
