import { Observable } from 'rxjs';
import { TestObservable } from './test-observables';
import { TestMessages } from './types';
export declare function materializeInnerObservable<T>(observable: Observable<T>, outerFrame: number): TestMessages;
export declare function toHaveSubscriptionsComparer(actual: TestObservable, marbles: string | string[]): {
    pass: boolean;
    message: () => string;
};
export declare function toBeObservableComparer(actual: TestObservable, fixture: TestObservable): {
    pass: boolean;
    message: () => string;
};
