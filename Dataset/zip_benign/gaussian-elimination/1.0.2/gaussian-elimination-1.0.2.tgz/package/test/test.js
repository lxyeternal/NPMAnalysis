/* global describe, it */
let chai = require('chai')
let expect = chai.expect

let gauss = require('..')

describe('tests', () => {
  it('solve simple system', () => {
    let arr = [[0.12, 0.18, -0.17, 5.5],
               [0.06, 0.09, 0.15, -1.95],
               [0.22, -0.1, 0.06, 0.5]]
    let res = gauss(arr)
    let cs = [ arr[0][0] * res[0] + arr[0][1] * res[1] + arr[0][2] * res[2],
      arr[1][0] * res[0] + arr[1][1] * res[1] + arr[1][2] * res[2],
      arr[2][0] * res[0] + arr[2][1] * res[1] + arr[2][2] * res[2] ]
    console.log('system:')
    console.log(arr)
    console.log('solution:')
    console.log(res)
    console.log('verification:')
    console.log(cs)
    expect(cs[0]).to.be.closeTo(arr[0][3], 0.000001)
    expect(cs[1]).to.be.closeTo(arr[1][3], 0.000001)
    expect(cs[2]).to.be.closeTo(arr[2][3], 0.000001)
  })
})
