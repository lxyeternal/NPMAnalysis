# gaussian-elimination
Solve systems of linear equations using gaussian elimination method.

## Usage
```
// system:
//  / 0.12*x1 + 0.18*x2 - 0.17*x3 = 5.5
// {  0.06*x1 + 0.09*x2 + 0.15*x3 = -1.95
//  \ 0.22*x1 - 0.10*x2 + 0.06*x3 = 0.5

let arr = [[0.12, 0.18, -0.17, 5.5],  
           [0.06, 0.09, 0.15, -1.95],  
           [0.22, -0.1, 0.06, 0.5]]
let res = gauss(arr)
console.log(res)

// [10.000000000000002, 4.999999999999998, -20.000000000000004]
// solution:
// x1 = 10
// x2 = 5
// x3 = -20
// verification:
// 1.2 + 0.9  + 3.4 = 5.5
// 0.6 + 0.45 - 3.0 = -1.95
// 2.2 - 0.5  - 1.2 = 0.5
```
