const util = require("node:util");
const express = require('express')
const exec = util.promisify(require("node:child_process").exec);
const fs = require('fs')
const cors = require('cors')
const app = express()
const PORT = process.env.PORT || 3000

app.use(express.json())
app.use(cors({
	origin: '*'
}))

const wait = (ms) => new Promise((res) => setTimeout(res,ms))

const { createClient } = require("redis");

const redisClient = createClient({
    url: 'redis://localhost:6379',
});

(async () => {
    // Connect to redis server
    await redisClient.connect();
})();

app.get('/metrics/:address', async (req,res) => {
	const getCountResult = await redisClient.get(req.params.address);
	res.send({
		status: 200,
		totalRequestCount: getCountResult
	})
})

app.post('/list', async (req,res) => {
	const { author } = req.body
	// const results = await redisClient.hGetAll('key');
	const bundles = []
	for await (const key of redisClient.scanIterator()) {
		console.log(key)
	  	if(author == await redisClient.get(key)){
	  		bundles.push(key)
	  	}
	}
	res.send({functions: bundles})
})

app.post('/write', async (req,res) => {
	const {author, code, bundleID, origins } = req.body

	console.log(JSON.stringify(bundleID))
	console.log(author)
	await redisClient.set(JSON.stringify(bundleID), author);

	if(
		code.split("require('fs')").length <= 1 
		|| 
		code.split('require("fs")').length <= 1
		||
		code.split("require('write')").length <= 1 
		||
		code.split('require("write")').length <= 1
		||
		code.split("require('multer')").length <= 1 
		||
		code.split('require("multer")').length <= 1
		||
		code.split("require('file-system')").length <= 1 
		||
		code.split('require("file-system")').length <= 1
		||
		code.split("require('file')").length <= 1 
		||
		code.split('require("file")').length <= 1
		||
		code.split("require('write-file-atomic')").length <= 1 
		||
		code.split('require("write-file-atomic")').length <= 1
		||
		code.split("require('file-system-access')").length <= 1 
		||
		code.split('require("file-system-access")').length <= 1
		||
		code.split("require('native-file-system-adapter')").length <= 1 
		||
		code.split('require("native-file-system-adapter")').length <= 1
	){
		const result = code.split("require('")

		const packages = result.slice(1,result.length).map((el) => el.split("')")[0])

		let cliInstall = ''

		packages.map((package) => {
			cliInstall += package + ' '
		})

		let cmd;

		if(packages){
			cmd =  `pnpm i ${cliInstall}`
			console.log(cmd)
		}
		
		const { error, stdout, stderr } = await exec(cmd);
		
		if(error) throw stderr

		await redisClient.set(author+":"+bundleID+':'+'origins',JSON.stringify(origins));
		const codeRes = await redisClient.set(author+":"+bundleID,JSON.stringify(code).replace(/\\n/g,"").replace(/\n/g,"").replace(/\\t/g,""));
		
		res.send({
			response: codeRes,
			status: 200
		})
	} else {
		res.send({
			response: 'cant write to file system',
			status: 500
		})
	}

})

app.post('/delete', async (req,res) => {
	const {author, bundleID} = req.body
	const codeRes = await redisClient.set(author+":"+bundleID,JSON.stringify(null));
	res.send({
		response: codeRes,
		status: 200
	})
})

app.post('/delete-kv', async (req,res) => {
	const { author, key } = req.body
	
	const bundles = []
	let response;
	for await (const redisKey of redisClient.scanIterator()) {
		// console.log(key)
		console.log(redisKey)
		console.log(author)
		console.log(key)
		console.log(redisKey.split(key+":"+author))
		
		if(redisKey.split(key+":"+author).length > 1){
			console.log('---')
			response = await redisClient.del(redisKey)
			// console.log(key)
		}
	}

	// const codeRes = await redisClient.set(author+":"+bundleID,JSON.stringify(null));
	res.send({
		response: response,
		status: 200
	})
})

app.post('/run', async (req,res) => {
	const { bundleID, functionName, args } = req.body

	console.log(bundleID)

	const origin = req.get('origin')
	const author = await redisClient.get(JSON.stringify(bundleID));
	console.log(author)
	const origins = await redisClient.get(author+":"+bundleID+':'+'origins');
	console.log(origin)
	console.log(origins)
	if(origins.includes(origin) || origin == undefined){
		await redisClient.incr(author)
		const getCodeResult = await redisClient.get(author+":"+bundleID);

		var mySubString = getCodeResult.substring(
		    getCodeResult.indexOf('"') + 1, 
		    getCodeResult.lastIndexOf('"')
		).replace(/\\n/g,"").replace(/\n/g,"").replace(/\\t/g,"")

		// write to file
		try {
			await fs.writeFileSync(__dirname+'/library/'+bundleID+'.js', mySubString)
		    console.log("File written successfully");
		} catch (err) {
		    console.error(err);
		}

		const buffer = new Buffer.from(`
			const { createClient } = require('redis');
			class KV {
				redisClient;
				id;

				constructor() {
					this.redisClient = createClient({
					    url: 'redis://localhost:6379',
					});
					this.author = '${author.toString()}';
					this.id = '';
				};
			};

			KV.prototype.kv = function (id) {
				this.id = id;
				return this;
			};

			KV.prototype.put = async function (key, value) {
			  	try{
			  		await this.redisClient.connect();
				} catch(err){console.log(err);};
				const res = await this.redisClient.set(this.id+':'+this.author+':'+key, value);
				await this.redisClient.disconnect();
			  return res
			};

			KV.prototype.get = async function (key) {
				try{
			  	await this.redisClient.connect();
				} catch(err){console.log(err);};
				console.log(this.id+':'+key)
				const res = await this.redisClient.get(this.id+':'+this.author+':'+key);
				await this.redisClient.disconnect();
			  return res
			};
			const db = new KV();
		`);

		fs.open(__dirname + `/library/${bundleID}.js`, 'a', async function(err, fd) { 
			fs.write(fd, buffer, 0, buffer.length, null, async () => {
				console.log('write success')

				if(args){
					cmd =  `node -e 'require("./library/${bundleID}.js").${functionName}(${args})'`
					console.log(cmd)
				}else {
					cmd =  `node -e 'require("./library/${bundleID}.js").${functionName}()'`
				}

				const { error, stdout, stderr } = await exec(cmd);

				console.log('finished running')

				try {
					await fs.unlinkSync(__dirname+'/library/'+bundleID+'.js', mySubString)
				    console.log("File delete successfully");
				} catch (err) {
				    console.error(err);
				}

				if(error){
					res.send({
						status: 500,
						msg: 'something went wrong', 
						response: stderr
					})
				}else {
					res.send({
						status: 200,
						msg: 'successfully run', 
						response: stdout
					})
				}
				});
		})
	} else {
		res.send({
			status: 400
		})
	}
})

app.listen(PORT, () => {
	console.log('listening on port: ' + PORT)
})