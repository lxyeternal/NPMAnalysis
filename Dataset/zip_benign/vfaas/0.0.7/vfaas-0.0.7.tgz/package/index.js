#!/usr/bin/env node
const { program } = require('commander');
const util = require("node:util");
const exec = util.promisify(require("node:child_process").exec);
const fs = require('fs')
const yaml = require('js-yaml');
const { ethers, Wallet } = require('ethers')
const axios = require('axios')
const { v4 } = require("uuid");
var figlet = require("figlet");

const HOST = 'https://vfaas.ngrok.dev'

figlet("versus faas", function (err, data) {
  if (err) {
    console.log("Something went wrong...");
    console.dir(err);
    return;
  }
  // console.log(data);

  program.command('init')
    .description('initialize a function')
    .argument('<filePath>', 'file path to working directory')
    .action(async (filePath) => {
    const code = 
  `
  module.exports.serverless = async function () {

  };
  `
      console.log(__dirname+'/src/')
    if (fs.existsSync(filePath+'/src/')) {
      const fileName = BigInt(ethers.hexlify(ethers.randomBytes(5)))
      await fs.writeFileSync(filePath+'/src/'+`${fileName}.js`, code, {encoding:'utf8',flag:'a'})
      console.log('success')
    }else {
      console.log(__dirname+'/src/')
      fs.mkdir(filePath+'/src/',
      async (err) => {
        if (err) {
            return console.error(err);
        }
        const fileName = BigInt(ethers.hexlify(ethers.randomBytes(5)))
        await fs.writeFileSync(filePath+'/src/'+`${fileName}.js`, code, {encoding:'utf8',flag:'a'})
        console.log('success')
      })
    }
    
  })

  program.command('key-gen')
    .argument('<destination>', 'directory to save credentials')
    .description('create a local keyfile storing a private key as an identity')
    .action(async (dest) => {

      const versusPath = dest+'/.versus'
      const path = dest+'/.versus/versus.yml'

      if (fs.existsSync(versusPath)) {
          const wallet = Wallet.createRandom()
          const privKey = wallet.privateKey
          
          let keyFile = {
            version: 3,
            evmAddress: wallet.address,
            privateKey: privKey,
            kvs: []
          }

          const yamlStr = yaml.dump(keyFile);
          fs.writeFileSync(path, yamlStr, {encoding:'utf8',flag:'w'})
          fs.readFile(path, (err, res) => {
            if(err) throw err
            console.log(res.toString())
          })
      }else {
        fs.mkdir(versusPath,
        (err) => {
          if (err) {
              return console.error(err);
          }
          console.log(`${versusPath} created successfully!`)

          const wallet = Wallet.createRandom()
          const privKey = wallet.privateKey
          
          let keyFile = {
            version: 3,
            evmAddress: wallet.address,
            privateKey: privKey,
            kvs: []
          }

          const yamlStr = yaml.dump(keyFile);
       
          fs.writeFileSync(path, yamlStr, {encoding:'utf8',flag:'w'})
          fs.readFile(path, (err, res) => {
            if(err) throw err
            console.log(res.toString())
          })
        })
      }
  })

  program.command('local')
    .description('run a function locally')
    .argument('<absolutePath>', 'function to run in relative file path (e.g. src/number.js)')
    .argument('<functionName>', 'function to run')
    .argument('<args>', 'function to run')
    .action(async (filePath, functionName, args) => {
      let cmd
      if(args.length>0){
          cmd =  `node -e 'require("./${filePath}").${functionName}(${args.split(',')})'`
        }else {
          cmd =  `node -e 'require("./${filePath}").${functionName}()'`
        }

        const { error, stdout, stderr } = await exec(cmd);
        console.log(stdout)
    })

  // write to library
  program.command('write')
    .description('store a faas function to the library for later computation')
    .argument('<home directory>', 'relative directory to import')
    .argument('<absolutePath>', 'relative directory to import')
    .argument('<origins>', 'display just the first substring')
    .action(async (home, src, origins) => {
      fs.readFile(src, async (err, resCode) => {
        if(err) throw err
        const path = home+'/.versus/versus.yml'
        fs.readFile(path, async (err, res) => {
          if(err) throw err
          const filePath = src.split('/')
          console.log((await axios.post(`${HOST}/write`, {
            origins: origins.split(','),
            code: resCode.toString(),
            author: yaml.load(res.toString()).evmAddress,
            bundleID: filePath[filePath.length-1].split('.js')[0]
          })).data)
        })
      })
    })

  program.command('list')
    .description('list the remote written functions')
    .argument('<home>', 'relative directory to import')
    .action(async (home, options) => {
      const path = home+'/.versus/versus.yml'
      fs.readFile(path, async (err, res) => {
        if(err) throw err
        const response = await axios.post(`${HOST}/list`, {
          author: yaml.load(res.toString()).evmAddress,
        })
        console.log('Bundle IDs')
        console.log('----------')
        response.data.functions.map((bundle) => {
          console.log(bundle)
        })
      })
    })

  // delete from library
  program.command('delete')
    .description('delete a function by bundleID')
    .argument('<home>', 'relative directory to import')
    .argument('<bundleID>', 'directory to import')
    .action(async (home,bundleID) => {
    	const path = home+'/.versus/versus.yml'
      fs.readFile(path, async (err, res) => {
        if(err) throw err
        console.log((await axios.post(`${HOST}/delete`, {
          author: yaml.load(res.toString()).evmAddress,
          bundleID: bundleID
        })).data)
      })
    })

  program.command('kv-create')
    .description('create a kv id that can be used across functions')
    .argument('<home>', 'home directory')
    .action(async (home) => {
        const path = home+'/.versus/versus.yml'
        fs.readFile(path, async (err, res) => {
          if(err) throw err
          const yamlJSON = yaml.load(res.toString())
          yamlJSON.kvs.push(v4())
          // console.log(yamlJSON)
          const yamlStr = yaml.dump(yamlJSON);
          fs.writeFileSync(path, yamlStr, {encoding:'utf8',flag:'w'})
          console.log(`use this in your code: ${yamlJSON.kvs[yamlJSON.kvs.length -1]}`)
          console.log(`like this: await db.kv('${yamlJSON.kvs[yamlJSON.kvs.length -1]}').put('test', JSON.stringify('~ronseg-hacsym'))`)
          console.log(`or this: await db.kv('${yamlJSON.kvs[yamlJSON.kvs.length -1]}').get('test')`)
        })
    })

  program.command('kv-list')
    .description('list the kv data keys stored locally')
    .argument('<home>', 'home directory')
    .action(async (home) => {
        const path = home+'/.versus/versus.yml'
        fs.readFile(path, async (err, res) => {
          if(err) throw err
          const yamlJSON = yaml.load(res.toString())
          // console.log(yamlJSON)
          console.log('KV IDs')
          console.log('----------')
          yamlJSON.kvs.map((bundle) => {
            console.log(bundle)
          })
        })
    })

  program.command('kv-delete')
    .description('delete a kv id')
    .argument('<home>', 'home directory')
    .argument('<key>', 'key to remove')
    .action(async (home, key) => {
        const path = home+'/.versus/versus.yml'
        fs.readFile(path, async (err, res) => {
          if(err) throw err
          const yamlJSON = yaml.load(res.toString())
          console.log('KV IDs')
          console.log('----------')

          // yamlJSON.kvs.

          const index = yamlJSON.kvs.indexOf(key);
          if (index > -1) { // only splice array when item is found
            yamlJSON.kvs.splice(index, 1); // 2nd parameter means remove one item only
          }

          const yamlStr = yaml.dump(yamlJSON);
          console.log(yamlStr)
          fs.writeFileSync(path, yamlStr, {encoding:'utf8',flag:'w'})

          console.log((await axios.post(`${HOST}/delete-kv`, {
            author: yaml.load(res.toString()).evmAddress,
            key: key
          })).data)
        })
    })

  program.parse()
});