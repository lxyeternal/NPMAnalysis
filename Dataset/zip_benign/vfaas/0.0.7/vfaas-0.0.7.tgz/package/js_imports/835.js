const _ = require('lodash');
const ethers = require('ethers');

module.exports.serverless = async function () {
	console.log(await db.kv('b8cbe364-d84b-4747-9de8-77124f067bd7').put('test', JSON.stringify('~ronseg-hacsym')));
	console.log(await db.kv('b8cbe364-d84b-4747-9de8-77124f067bd7').get('test'));
};