module.exports.serverless = function (args1, args2) {
	console.log(args1 / args2)
}