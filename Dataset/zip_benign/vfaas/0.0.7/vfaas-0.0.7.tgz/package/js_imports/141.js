module.exports.serverless = function () {
	console.log('howdy')
}