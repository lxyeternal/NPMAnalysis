# faas-poc
a simple way to run cloud serverless functions with http connections using cli deployments

## todo:
- requires authentication
- npm parsing for quick cache library running
- instantiate behind a load balancer

### testing execution: terminal 1
```javscript
$ node faas.js
```

### testing execution: terminal 2
```
$ curl --header "Content-Type: application/json" \
  --request POST \
  --data '{"bundleID":153,"functionName":"serverless", "args": [1,2]}' \
  http://localhost:3000/run
{"status":200,"msg":"successfully run","response":"0.5\n"}%
```

### testing cli: terminal 3
can be performed while faas server is running

```javascript
$ node cli.js write /js_imports/153.js
```