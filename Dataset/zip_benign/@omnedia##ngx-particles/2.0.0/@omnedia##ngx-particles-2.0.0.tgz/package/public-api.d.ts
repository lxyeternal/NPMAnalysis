export * from "./lib/ngx-particles.component";
