/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@omnedia/ngx-particles" />
export * from './public-api';
