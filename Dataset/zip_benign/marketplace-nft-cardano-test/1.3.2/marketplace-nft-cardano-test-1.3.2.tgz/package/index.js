import Loader from "./loader.js";
import {
  assetsToValue,
  fromAscii,
  fromHex,
  getTradeDetails,
  lovelacePercentage,
  toBytesNum,
  toHex,
  valueToAssets,
} from "./utils.js";
import { languageViews } from "./languageViews.js";
import { contract } from "./plutus.js";
import CoinSelection from "./coinSelection.js";
import {
  Address,
  PlutusData,
  TransactionUnspentOutput,
} from "./custom_modules/@emurgo/cardano-serialization-lib-nodejs/cardano_serialization_lib.js";

import { Buffer } from "buffer";
import fetch from "node-fetch";

const DATUM_LABEL = 405;
const ADDRESS_LABEL = 406;

// Validator
const CONTRACT = () => {
  const scripts = Loader.Cardano.PlutusScripts.new();
  scripts.add(Loader.Cardano.PlutusScript.new(fromHex(contract)));
  return scripts;
};

const CONTRACT_ADDRESS = () =>
  Loader.Cardano.Address.from_bech32("addr1wxwk0mlejasr005wh27pv6j2fgusruwkc7tcdvla3e8pcyqzrhpzs");


// Datums
const START_BID = () => {
  const datum = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(DATUM_TYPE.StartBid),
      Loader.Cardano.PlutusList.new()
    )
  );
  return datum;
};
const BID = ({ tradeOwner, budId }) => {
  const fieldsInner = Loader.Cardano.PlutusList.new();
  fieldsInner.add(Loader.Cardano.PlutusData.new_bytes(fromHex(tradeOwner)));
  fieldsInner.add(
    Loader.Cardano.PlutusData.new_bytes(fromHex(toBytesNum(budId)))
  );
  fieldsInner.add(
    Loader.Cardano.PlutusData.new_integer(Loader.Cardano.BigInt.from_str("1"))
  );
  const tradeDetails = Loader.Cardano.PlutusList.new();
  tradeDetails.add(
    Loader.Cardano.PlutusData.new_constr_plutus_data(
      Loader.Cardano.ConstrPlutusData.new(
        Loader.Cardano.Int.new_i32(0),
        fieldsInner
      )
    )
  );
  const datum = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(DATUM_TYPE.Bid),
      tradeDetails
    )
  );
  return datum;
};
const OFFER = ({ tradeOwner, budId, requestedAmount }) => {
  const fieldsInner = Loader.Cardano.PlutusList.new();
  fieldsInner.add(Loader.Cardano.PlutusData.new_bytes(fromHex(tradeOwner)));
  fieldsInner.add(
    Loader.Cardano.PlutusData.new_bytes(fromHex(toBytesNum(budId)))
  );
  fieldsInner.add(
    Loader.Cardano.PlutusData.new_integer(
      Loader.Cardano.BigInt.from_str(requestedAmount)
    )
  );
  const tradeDetails = Loader.Cardano.PlutusList.new();
  tradeDetails.add(
    Loader.Cardano.PlutusData.new_constr_plutus_data(
      Loader.Cardano.ConstrPlutusData.new(
        Loader.Cardano.Int.new_i32(0),
        fieldsInner
      )
    )
  );
  const datum = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(DATUM_TYPE.Offer),
      tradeDetails
    )
  );
  return datum;
};

const DATUM_TYPE = {
  StartBid: 0,
  Bid: 1,
  Offer: 2,
};

// Redeemers
const BUY = (index) => {
  const redeemerData = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(0),
      Loader.Cardano.PlutusList.new()
    )
  );
  const redeemer = Loader.Cardano.Redeemer.new(
    Loader.Cardano.RedeemerTag.new_spend(),
    Loader.Cardano.BigNum.from_str(index),
    redeemerData,
    Loader.Cardano.ExUnits.new(
      Loader.Cardano.BigNum.from_str("7000000"),
      Loader.Cardano.BigNum.from_str("3000000000")
    )
  );
  return redeemer;
};
const SELL = (index) => {
  const redeemerData = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(1),
      Loader.Cardano.PlutusList.new()
    )
  );
  const redeemer = Loader.Cardano.Redeemer.new(
    Loader.Cardano.RedeemerTag.new_spend(),
    Loader.Cardano.BigNum.from_str(index),
    redeemerData,
    Loader.Cardano.ExUnits.new(
      Loader.Cardano.BigNum.from_str("7000000"),
      Loader.Cardano.BigNum.from_str("3000000000")
    )
  );
  return redeemer;
};
const BID_HIGHER = (index) => {
  const redeemerData = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(2),
      Loader.Cardano.PlutusList.new()
    )
  );
  const redeemer = Loader.Cardano.Redeemer.new(
    Loader.Cardano.RedeemerTag.new_spend(),
    Loader.Cardano.BigNum.from_str(index),
    redeemerData,
    Loader.Cardano.ExUnits.new(
      Loader.Cardano.BigNum.from_str("7000000"),
      Loader.Cardano.BigNum.from_str("3000000000")
    )
  );
  return redeemer;
};
const CANCEL = (index) => {
  const redeemerData = Loader.Cardano.PlutusData.new_constr_plutus_data(
    Loader.Cardano.ConstrPlutusData.new(
      Loader.Cardano.Int.new_i32(3),
      Loader.Cardano.PlutusList.new()
    )
  );
  const redeemer = Loader.Cardano.Redeemer.new(
    Loader.Cardano.RedeemerTag.new_spend(),
    Loader.Cardano.BigNum.from_str(index),
    redeemerData,
    Loader.Cardano.ExUnits.new(
      Loader.Cardano.BigNum.from_str("5000000"),
      Loader.Cardano.BigNum.from_str("2000000000")
    )
  );
  return redeemer;
};

class PixelCatMarket {
  constructor({ base, projectId }, extraFeeRecipient) {
    this.provider = { base, projectId };
    this.extraFeeRecipient = extraFeeRecipient;
  }

  /**
   *
   * @typedef {Object} TradeUtxo
   * @property {PlutusData} datum
   * @property {Address} tradeOwnerAddress
   * @property {TransactionUnspentOutput} utxo
   * @property {string} budId
   * @property {string} lovelace bid amount or requested amount from offer
   */

  /**
   *@private
   */
  async blockfrostRequest(endpoint, headers, body) {
    return await fetch(this.provider.base + endpoint, {
      headers: {
        project_id: this.provider.projectId,
        ...headers,
        // "User-Agent": "spacebudz-marketplace",
      },
      method: body ? "POST" : "GET",
      body,
    }).then((res) => res.json());
  }

  /**
   * @private
   * @returns {TradeUtxo[]}
   */
  async getUtxo(policy, prefix, budId) {
    const asset = policy + fromAscii(prefix + budId);

    const utxos = await this.blockfrostRequest(
      `/addresses/${CONTRACT_ADDRESS().to_bech32()}/utxos/${asset}`
    );

    return await Promise.all(
      utxos.map(async (utxo) => {
        const metadata = await this.blockfrostRequest(
          `/txs/${utxo.tx_hash}/metadata`
        );
        let datum;
        let tradeOwnerAddress;
        try {
          datum = metadata
            .find((m) => m.label == DATUM_LABEL)
            .json_metadata[utxo.output_index].slice(2);
          if (datum != toHex(START_BID().to_bytes()))
            //STARTBID doesn't have a tradeOwner
            tradeOwnerAddress = metadata
              .find((m) => m.label == ADDRESS_LABEL)
              .json_metadata.address.slice(2);
        } catch (e) {
          throw new Error(e);
        }
        datum = Loader.Cardano.PlutusData.from_bytes(fromHex(datum));
        // console.log('get Offer Datum hash: ', toHex(Loader.Cardano.hash_plutus_data(datum).to_bytes()));
        if (
          toHex(Loader.Cardano.hash_plutus_data(datum).to_bytes()) !==
          utxo.data_hash
        )
          throw new Error("Datum hash doesn't match");

        return {
          datum,
          tradeOwnerAddress:
            tradeOwnerAddress &&
            Loader.Cardano.Address.from_bytes(fromHex(tradeOwnerAddress)),
          utxo: Loader.Cardano.TransactionUnspentOutput.new(
            Loader.Cardano.TransactionInput.new(
              Loader.Cardano.TransactionHash.from_bytes(fromHex(utxo.tx_hash)),
              utxo.output_index
            ),
            Loader.Cardano.TransactionOutput.new(
              CONTRACT_ADDRESS(),
              assetsToValue(utxo.amount)
            )
          ),
          budId,
        };
      })
    );
  }

  /**
   *@private
   */
  async initTx() {
    const txBuilder = Loader.Cardano.TransactionBuilder.new(
      Loader.Cardano.LinearFee.new(
        Loader.Cardano.BigNum.from_str(
          this.protocolParameters.linearFee.minFeeA
        ),
        Loader.Cardano.BigNum.from_str(
          this.protocolParameters.linearFee.minFeeB
        )
      ),
      Loader.Cardano.BigNum.from_str(this.protocolParameters.minUtxo),
      Loader.Cardano.BigNum.from_str(this.protocolParameters.poolDeposit),
      Loader.Cardano.BigNum.from_str(this.protocolParameters.keyDeposit),
      this.protocolParameters.maxValSize,
      this.protocolParameters.maxTxSize,
      this.protocolParameters.priceMem,
      this.protocolParameters.priceStep,
      Loader.Cardano.LanguageViews.new(Buffer.from(languageViews, "hex"))
    );
    const datums = Loader.Cardano.PlutusList.new();
    const metadata = { [DATUM_LABEL]: {}, [ADDRESS_LABEL]: {} };
    const outputs = Loader.Cardano.TransactionOutputs.new();
    return { txBuilder, datums, metadata, outputs };
  }

  /**
   * @private
   */
  policyBidLength(value) {
    if (!value.multiasset()) return 0;
    const policy = Loader.Cardano.ScriptHash.from_bytes(
      Loader.Cardano.Ed25519KeyHash.from_bytes(
        fromHex(this.contractInfo.policyBid)
      ).to_bytes()
    );
    return value.multiasset().get(policy).len();
  }

  /**
   * @private
   */
  policyBidRemaining(value, budId) {
    const assets = valueToAssets(value);
    return assetsToValue(
      assets.filter(
        (asset) =>
          asset.unit !=
          this.contractInfo.policyBid +
          fromAscii(this.contractInfo.prefixNftNameBid + budId) &&
          asset.unit.startsWith(this.contractInfo.policyBid)
      )
    );
  }

  /**
   * @private
   */
  createOutput(
    address,
    value,
    { datum, index, tradeOwnerAddress, metadata } = {}
  ) {
    const v = value;
    const minAda = Loader.Cardano.min_ada_required(
      v,
      Loader.Cardano.BigNum.from_str(this.protocolParameters.minUtxo),
      datum && Loader.Cardano.hash_plutus_data(datum)
    );
    if (minAda.compare(v.coin()) == 1) v.set_coin(minAda);
    const output = Loader.Cardano.TransactionOutput.new(address, v);
    // console.log('datum-output: ', toHex(Loader.Cardano.hash_plutus_data(datum).to_bytes()));

    if (datum) {
      output.set_data_hash(Loader.Cardano.hash_plutus_data(datum)); //IS THIS THE MAGIC NUMBER?
      metadata[DATUM_LABEL][index] = "0x" + toHex(datum.to_bytes());
    }
    if (tradeOwnerAddress) {
      metadata[ADDRESS_LABEL].address =
        "0x" + toHex(tradeOwnerAddress.to_address().to_bytes());
    }

    // console.log('metadata: ', metadata);
    // console.log('output: ', output);
    return output;
  }

  /**
   * @private
   */
  setCollateral(txBuilder, utxos) {
    const inputs = Loader.Cardano.TransactionInputs.new();
    utxos.forEach((utxo) => {
      inputs.add(utxo.input());
    });
    txBuilder.set_collateral(inputs);
  }

  /**
   * @private
   */
  async finalizeTx({
    txBuilder,
    changeAddress,
    utxos,
    outputs,
    datums,
    metadata,
    scriptUtxo,
    action,
  }, getCollateral) {
    const transactionWitnessSet = Loader.Cardano.TransactionWitnessSet.new();
    let { input, change } = CoinSelection.randomImprove(
      utxos,
      outputs,
      10,
      scriptUtxo ? [scriptUtxo] : []
    );
    input.forEach((utxo) => {
      // console.log(toHex(utxo.input().to_bytes()));
      txBuilder.add_input(
        utxo.output().address(),
        utxo.input(),
        utxo.output().amount()
      );
    });
    for (let i = 0; i < outputs.len(); i++) {
      txBuilder.add_output(outputs.get(i));
    }
    // console.log(scriptUtxo);
    if (scriptUtxo) {
      const redeemers = Loader.Cardano.Redeemers.new();
      const redeemerIndex = txBuilder.index_of_input(scriptUtxo.input()).toString();
      redeemers.add(action(redeemerIndex));
      txBuilder.set_redeemers(
        Loader.Cardano.Redeemers.from_bytes(redeemers.to_bytes())
      );
      txBuilder.set_plutus_data(
        Loader.Cardano.PlutusList.from_bytes(datums.to_bytes())
      );

      txBuilder.set_plutus_scripts(CONTRACT());
      transactionWitnessSet.set_plutus_scripts(CONTRACT());
      transactionWitnessSet.set_plutus_data(datums);
      transactionWitnessSet.set_redeemers(redeemers);

      // console.log('redeemers: ', toHex(Loader.Cardano.Redeemers.from_bytes(redeemers.to_bytes()).to_bytes()));
      // console.log('datums: ', toHex(Loader.Cardano.hash_plutus_data(datums)));

      const collateral = (getCollateral).map((utxo) =>
        Loader.Cardano.TransactionUnspentOutput.from_bytes(fromHex(utxo))
      );
      this.setCollateral(txBuilder, collateral);
    }
    let aux_data;
    if (metadata) {
      aux_data = Loader.Cardano.AuxiliaryData.new();
      const generalMetadata = Loader.Cardano.GeneralTransactionMetadata.new();
      Object.keys(metadata).forEach((label) => {
        Object.keys(metadata[label]).length > 0 &&
          generalMetadata.insert(
            Loader.Cardano.BigNum.from_str(label),
            Loader.Cardano.encode_json_str_to_metadatum(
              JSON.stringify(metadata[label]),
              1
            )
          );
      });
      aux_data.set_metadata(generalMetadata);
      txBuilder.set_auxiliary_data(aux_data);
    }
    // console.log(metadata);

    const changeMultiAssets = change.multiasset();

    // check if change value is too big for single output
    if (
      changeMultiAssets &&
      change.to_bytes().length * 2 > this.protocolParameters.maxValSize
    ) {
      const partialChange = Loader.Cardano.Value.new(
        Loader.Cardano.BigNum.from_str("0")
      );

      const partialMultiAssets = Loader.Cardano.MultiAsset.new();
      const policies = changeMultiAssets.keys();
      const makeSplit = () => {
        for (let j = 0; j < changeMultiAssets.len(); j++) {
          const policy = policies.get(j);
          const policyAssets = changeMultiAssets.get(policy);
          const assetNames = policyAssets.keys();
          const assets = Loader.Cardano.Assets.new();
          for (let k = 0; k < assetNames.len(); k++) {
            const policyAsset = assetNames.get(k);
            const quantity = policyAssets.get(policyAsset);
            assets.insert(policyAsset, quantity);
            //check size
            const checkMultiAssets = Loader.Cardano.MultiAsset.from_bytes(
              partialMultiAssets.to_bytes()
            );
            checkMultiAssets.insert(policy, assets);
            const checkValue = Loader.Cardano.Value.new(
              Loader.Cardano.BigNum.from_str("0")
            );
            checkValue.set_multiasset(checkMultiAssets);
            if (
              checkValue.to_bytes().length * 2 >=
              this.protocolParameters.maxValSize
            ) {
              partialMultiAssets.insert(policy, assets);
              return;
            }
          }
          partialMultiAssets.insert(policy, assets);
        }
      };
      makeSplit();
      partialChange.set_multiasset(partialMultiAssets);
      const minAda = Loader.Cardano.min_ada_required(
        partialChange,
        Loader.Cardano.BigNum.from_str(this.protocolParameters.minUtxo)
      );
      partialChange.set_coin(minAda);

      txBuilder.add_output(
        Loader.Cardano.TransactionOutput.new(
          changeAddress.to_address(),
          partialChange
        )
      );
    }

    txBuilder.add_change_if_needed(changeAddress.to_address());
    const txBody = txBuilder.build();
    const tx = Loader.Cardano.Transaction.new(
      txBody,
      Loader.Cardano.TransactionWitnessSet.from_bytes(
        transactionWitnessSet.to_bytes()
      ),
      aux_data
    );

    // console.log(tx);
    const size = tx.to_bytes().length * 2;
    // console.log(size);
    if (size > this.protocolParameters.maxTxSize)
      throw new Error("MAX_SIZE_REACHED");

    /* TODO: need to send to browser to sign with wallet and send back txVkey */
    // console.log('Valid cborHex: ', toHex(tx.to_bytes()));
    // console.log('ptr: ', transactionWitnessSet);
    if (scriptUtxo) {
      return {
        txHash: toHex(tx.to_bytes()),
        txWitnessSet: toHex(transactionWitnessSet.to_bytes())
      }
    }
    return toHex(tx.to_bytes());


    // let txVkeyWitnesses = await window.cardano.signTx(
    //   toHex(tx.to_bytes()),
    //   true
    // );
  }

  /**
   * @public
   */
  async submitTransactionPackage(transaction, txWitnessSet, txVkeyWitnesses) {
    try {
      const tx = Loader.Cardano.Transaction.from_bytes(fromHex(transaction));
      const txVkeyWitnessesSerialized = Loader.Cardano.TransactionWitnessSet.from_bytes(
        fromHex(txVkeyWitnesses)
      );
      let transactionWitnessSet;
      if (txWitnessSet) {
        transactionWitnessSet = Loader.Cardano.TransactionWitnessSet.from_bytes(fromHex(txWitnessSet));
      } else {
        transactionWitnessSet = Loader.Cardano.TransactionWitnessSet.new();
      }
      // console.log('vkey: ', toHex(txVkeyWitnessesSerialized.to_bytes()));
      transactionWitnessSet.set_vkeys(txVkeyWitnessesSerialized.vkeys());
      const signedTx = Loader.Cardano.Transaction.new(
        tx.body(),
        transactionWitnessSet,
        tx.auxiliary_data()
      );

      console.log("Full Tx Size", signedTx.to_bytes().length);
      // console.log("cboHex: ", toHex(signedTx.to_bytes()));

      /* TODO: need to send to browser to submit with wallet  */
      return toHex(signedTx.to_bytes());
    } catch (error) {
      return null;
    }
  }

  /**
   * @private
   */
  splitAmount(lovelaceAmount, address, outputs) {
    if (
      lovelaceAmount.compare(Loader.Cardano.BigNum.from_str("400000000")) ==
      1 ||
      lovelaceAmount.compare(Loader.Cardano.BigNum.from_str("400000000")) == 0
    ) {
      const [amount1, amount2, amount3] = [
        lovelacePercentage(lovelaceAmount, this.contractInfo.owner1.fee2),
        lovelacePercentage(lovelaceAmount, this.contractInfo.owner2.fee),
        lovelacePercentage(lovelaceAmount, this.contractInfo.extraFee),
      ];
      if (
        this.extraFeeRecipient.to_bech32() ==
        this.contractInfo.owner1.address.to_bech32() // if owner is same as fee recipient, no reason to split up utxo extra
      ) {
        outputs.add(
          this.createOutput(
            this.contractInfo.owner1.address,
            Loader.Cardano.Value.new(amount1.checked_add(amount3))
          )
        );
      } else {
        outputs.add(
          this.createOutput(
            this.contractInfo.owner1.address,
            Loader.Cardano.Value.new(amount1)
          )
        );
        outputs.add(
          this.createOutput(
            this.extraFeeRecipient,
            Loader.Cardano.Value.new(amount3)
          )
        );
      }

      outputs.add(
        this.createOutput(
          this.contractInfo.owner2.address,
          Loader.Cardano.Value.new(amount2)
        )
      );

      outputs.add(
        this.createOutput(
          address,
          Loader.Cardano.Value.new(
            lovelaceAmount
              .checked_sub(amount1)
              .checked_sub(amount2)
              .checked_sub(amount3)
          )
        )
      );
    } else {
      const amount1 = lovelacePercentage(
        lovelaceAmount,
        this.contractInfo.owner1.fee1
      );
      outputs.add(
        this.createOutput(
          this.contractInfo.owner1.address,
          Loader.Cardano.Value.new(amount1)
        )
      );
      outputs.add(
        this.createOutput(
          address,
          Loader.Cardano.Value.new(lovelaceAmount.checked_sub(amount1))
        )
      );
    }
  }

  async load() {
    await Loader.load();
    const p = await this.blockfrostRequest(`/epochs/latest/parameters`);
    // console.log(p);
    try {
      this.protocolParameters = {
        linearFee: {
          minFeeA: p.min_fee_a.toString(),
          minFeeB: p.min_fee_b.toString(),
        },
        minUtxo: "1000000",
        poolDeposit: p.pool_deposit,
        keyDeposit: p.key_deposit,
        maxValSize: parseInt(p.max_val_size),
        maxTxSize: parseInt(p.max_tx_size),
        priceMem: parseFloat(p.price_mem),
        priceStep: parseFloat(p.price_step),
      };
    } catch (error) {
      return null;
      //TODO: wait for blockfrost fix
      this.protocolParameters = {
        linearFee: {
          minFeeA: p.min_fee_a.toString(),
          minFeeB: p.min_fee_b.toString(),
        },
        minUtxo: "1000000",
        poolDeposit: "500000000",
        keyDeposit: "2000000",
        maxValSize: "5000",
        maxTxSize: 16384,
        priceMem: 5.77e-2,
        priceStep: 7.21e-5,
      };
    }

    this.contractInfo = {
      policyIdNft:
        "23e8f1b1e62da63b08b0c07b6fdf65d89e878cb70de03c6d6b0970e4",
      policyBid: "388d4c0196c599536db80265b259542032eff295d3e07f4d3e6794a2",
      prefixNftName: "PixelCat",
      prefixNftNameBid: "PixelCatBid",
      owner1: {
        address: Loader.Cardano.Address.from_bech32(
          "addr1q870d2pvhze7vctx55xaaeyytna07d8kj27q7acn34lq7ewc7uktdu462whtnjmxlcaq8q9j4094v0h7mn4e75tdhzsqvvsxsh"
        ),
        fee1: Loader.Cardano.BigNum.from_str("416"), // 2.4%
        fee2: Loader.Cardano.BigNum.from_str("625"), // 1.6%
      },
      owner2: {
        address: Loader.Cardano.Address.from_bech32(
          "addr1qxaudmw07kjqhw99m048tdmkevslrm68xm30psstn5lh26p2tdkapxy9e9ldx5myyyxl5jw4aycu9e8e05naj9t8cc7sgstdld"
        ),
        fee: Loader.Cardano.BigNum.from_str("2500"), // 0.4%
      },
      extraFee: Loader.Cardano.BigNum.from_str("2500"), // 0.4%
      minPrice: Loader.Cardano.BigNum.from_str("30000000"),
      bidStep: Loader.Cardano.BigNum.from_str("10000"),
    };
    this.extraFeeRecipient = Loader.Cardano.Address.from_bech32(
      this.extraFeeRecipient
    );

    CoinSelection.setProtocolParameters(
      this.protocolParameters.minUtxo,
      this.protocolParameters.linearFee.minFeeA,
      this.protocolParameters.linearFee.minFeeB,
      this.protocolParameters.maxTxSize.toString()
    );
  }

  /**
   *
   * @param {number} budId
   * @returns {TradeUtxo | TradeUtxo[] | undefined} Array if both twins are offered
   */
  async getOffer(budId) {
    try {
      const offerUtxo = await this.getUtxo(
        this.contractInfo.policyIdNft,
        this.contractInfo.prefixNftName,
        budId.toString()
      );
      if (offerUtxo.length === 1) {
        const lovelace = getTradeDetails(offerUtxo[0].datum).requestedAmount;
        if (lovelace.compare(this.contractInfo.minPrice) == -1) return null;
        // console.log('offer: ', { ...offerUtxo[0], lovelace: lovelace.to_str() });
        return { ...offerUtxo[0], lovelace: lovelace.to_str() };
      }
      return null;
    } catch (error) {
      return null
    }
  }

  /**
   *
   * @param {number} budId
   * @returns {TradeUtxo}
   */
  async getBid(budId) {
    const bidUtxo = await this.getUtxo(
      this.contractInfo.policyBid,
      this.contractInfo.prefixNftNameBid,
      budId.toString()
    );
    if (bidUtxo.length !== 1) return null;
    const lovelace = bidUtxo[0].utxo.output().amount().coin().to_str();
    return { ...bidUtxo[0], lovelace };
  }

  /**
   *
   * @param {number} budId
   * @param {string} requestedAmount lovelace
   * @param {BaseAddress} sellerAddress BaseAddress
   * @param {string[]} walletUtxos utxos
   * @returns {string} Transaction Id
   */
  async offer(budId, requestedAmount, sellerAddress, walletUtxos) {
    try {
      const { txBuilder, datums, metadata, outputs } = await this.initTx();
      budId = budId.toString();
      if (
        Loader.Cardano.BigNum.from_str(requestedAmount).compare(
          this.contractInfo.minPrice
        ) == -1
      )
        throw new Error("Amount too small");
      const walletAddress = Loader.Cardano.BaseAddress.from_address(
        Loader.Cardano.Address.from_bytes(
          fromHex(sellerAddress)
        )
      );

      const utxos = (walletUtxos).map((utxo) =>
        Loader.Cardano.TransactionUnspentOutput.from_bytes(fromHex(utxo))
      );
      const offerDatum = OFFER({
        tradeOwner: toHex(walletAddress.payment_cred().to_keyhash().to_bytes()),
        budId,
        requestedAmount,
      });
      outputs.add(
        this.createOutput(
          CONTRACT_ADDRESS(),
          assetsToValue([
            {
              unit:
                this.contractInfo.policyIdNft +
                fromAscii(this.contractInfo.prefixNftName + budId),
              quantity: "1",
            },
          ]),
          {
            datum: offerDatum,
            index: 0,
            tradeOwnerAddress: walletAddress,
            metadata,
          }
        )
      );
      datums.add(offerDatum);
      const txHash = await this.finalizeTx({
        txBuilder,
        changeAddress: walletAddress,
        utxos,
        outputs,
        datums,
        metadata,
      });
      return txHash;
    } catch (error) {
      return null
    }
  }

  /**
   * @param {TradeUtxo} offerUtxo
   * @param {BaseAddress} sellerAddress BaseAddress
   * @param {string[]} walletUtxos utxos
   * @returns {string} Transaction Id
   */
  async buy(offerUtxo, sellerAddress, walletUtxos, collateral) {
    try {
      const { txBuilder, datums, outputs } = await this.initTx();
      const walletAddress = Loader.Cardano.BaseAddress.from_address(
        Loader.Cardano.Address.from_bytes(
          fromHex(sellerAddress)
        )
      );
      // console.log('wallet address ', walletAddress);

      const utxos = (walletUtxos).map((utxo) =>
        Loader.Cardano.TransactionUnspentOutput.from_bytes(fromHex(utxo))
      );
      datums.add(offerUtxo.datum);

      const datumType = offerUtxo.datum.as_constr_plutus_data().tag().as_i32();
      const tradeDetails = getTradeDetails(offerUtxo.datum);
      const value = offerUtxo.utxo.output().amount();
      const lovelaceAmount = tradeDetails.requestedAmount;
      if (datumType !== DATUM_TYPE.Offer)
        throw new Error("Datum needs to be Offer");
      this.splitAmount(lovelaceAmount, offerUtxo.tradeOwnerAddress, outputs);

      outputs.add(this.createOutput(walletAddress.to_address(), value)); // buyer receiving SpaceBud

      const requiredSigners = Loader.Cardano.Ed25519KeyHashes.new();
      requiredSigners.add(walletAddress.payment_cred().to_keyhash());
      txBuilder.set_required_signers(requiredSigners);

      const txHash = await this.finalizeTx({
        txBuilder,
        changeAddress: walletAddress,
        utxos,
        outputs,
        datums: datums,
        scriptUtxo: offerUtxo.utxo,
        action: BUY
      }, collateral);
      return txHash;
    } catch (error) {
      return null
    }
  }

  /**
   * @param {TradeUtxo} offerUtxo
   * @param {BaseAddress} sellerAddress BaseAddress
   * @param {string[]} walletUtxos utxos
   * @returns {string} Transaction Id
   */
  async cancelOffer(offerUtxo, sellerAddress, walletUtxos, collateral) {
    try {
      const { txBuilder, datums, outputs } = await this.initTx();
      const walletAddress = Loader.Cardano.BaseAddress.from_address(
        Loader.Cardano.Address.from_bytes(
          fromHex(sellerAddress)
        )
      );

      const utxos = (walletUtxos).map((utxo) =>
        Loader.Cardano.TransactionUnspentOutput.from_bytes(fromHex(utxo))
      );
      datums.add(offerUtxo.datum);

      const datumType = offerUtxo.datum.as_constr_plutus_data().tag().as_i32();
      const value = offerUtxo.utxo.output().amount();
      if (datumType !== DATUM_TYPE.Offer)
        throw new Error("Datum needs to be Offer");
      const requiredSigners = Loader.Cardano.Ed25519KeyHashes.new();
      requiredSigners.add(getTradeDetails(offerUtxo.datum).tradeOwner);
      txBuilder.set_required_signers(requiredSigners);

      const txHash = await this.finalizeTx({
        txBuilder,
        changeAddress: walletAddress,
        utxos,
        outputs,
        datums,
        scriptUtxo: offerUtxo.utxo,
        action: CANCEL,
      }, collateral);
      return txHash;

    } catch (error) {
      return null;
    }
  }




  /**
   *
   * @param {string} txHash Transaction Id
   * @returns
   */
  async awaitConfirmation(txHash) {
    return new Promise((res, rej) => {
      const confirmation = setInterval(async () => {
        const isConfirmed = await this.blockfrostRequest(`/txs/${txHash}`);
        if (isConfirmed && !isConfirmed.error) {
          clearInterval(confirmation);
          res(txHash);
          return;
        }
      }, 5000);
    });
  }
}

export default PixelCatMarket;
