class Loader {
  async load() {
    if (this._wasm) return;
    /**
     * @private
     */
    this._wasm = await import(
      "./custom_modules/@emurgo/cardano-serialization-lib-nodejs/cardano_serialization_lib.js"
    );
  }

  get Cardano() {
    return this._wasm;
  }
}

export default new Loader();
