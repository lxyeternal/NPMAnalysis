# 使用方法:
# 1、npm install menu3d

# 2、import Menu3D from 'menu3d'

# 3、new Menu3D(导航的容器, params)
#    params = {
#     background: '#000'，// 背景颜色
#     speed: 0.3 // 旋转速度
#    }

