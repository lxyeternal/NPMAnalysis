import type { SegmentProps } from './types';
declare function Segment({ index, segment, selectedIndex, disabled, handleSegmentPress, segmentWidth, segmentStyle, }: SegmentProps): JSX.Element;
export { Segment };
