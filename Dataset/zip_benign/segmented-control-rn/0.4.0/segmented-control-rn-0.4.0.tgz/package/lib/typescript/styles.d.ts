declare const _default: {
    activeSegmentBackground: {
        borderRadius: number;
        position: "absolute";
        height: string;
    };
    segmentControlWrapper: {
        width: string;
        minHeight: number;
        borderRadius: number;
        flexDirection: "row";
        alignItems: "center";
    };
    center: {
        flexGrow: number;
        alignItems: "center";
        justifyContent: "center";
    };
    segmentControlInner: {
        margin: number;
        flexGrow: number;
        flexDirection: "row";
        alignItems: "center";
    };
    disabled: {
        opacity: number;
    };
};
export default _default;
