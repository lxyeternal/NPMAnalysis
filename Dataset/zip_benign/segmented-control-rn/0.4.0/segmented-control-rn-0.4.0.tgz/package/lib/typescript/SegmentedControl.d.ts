import type { SegmentedControlProps } from './types';
declare function SegmentedControl({ segments, backgroundColor, tintColor, selectedIndex, style, segmentStyle, activeSegmentStyle, disabled, onChange, onValueChange, }: SegmentedControlProps): JSX.Element;
export { SegmentedControl };
