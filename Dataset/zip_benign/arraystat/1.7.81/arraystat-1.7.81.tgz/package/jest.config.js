export default {
    transform: {},
    testTimeout: 60_000,
};
