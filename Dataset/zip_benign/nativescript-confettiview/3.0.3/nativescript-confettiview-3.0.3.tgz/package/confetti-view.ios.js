"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("./common");
var ConfettiView = (function (_super) {
    __extends(ConfettiView, _super);
    function ConfettiView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._colors = [
            UIColor.colorWithRedGreenBlueAlpha(0.95, 0.40, 0.27, 1.0),
            UIColor.colorWithRedGreenBlueAlpha(1.00, 0.78, 0.36, 1.0),
            UIColor.colorWithRedGreenBlueAlpha(0.48, 0.78, 0.64, 1.0),
            UIColor.colorWithRedGreenBlueAlpha(0.30, 0.76, 0.85, 1.0),
            UIColor.colorWithRedGreenBlueAlpha(0.58, 0.39, 0.55, 1.0)
        ];
        _this._intensity = 0.5;
        _this._active = false;
        _this._autoStart = false;
        _this._fullScreen = false;
        return _this;
    }
    ConfettiView.prototype.createNativeView = function () {
        var confetti = SAConfettiView.new();
        if (this._fullScreen) {
            this.nativeView = UIView.alloc().init();
            this._confetti = confetti;
            rootVC().view.addSubview(confetti);
        }
        else {
            this.nativeView = confetti;
        }
        return this.nativeView;
    };
    ConfettiView.prototype.initNativeView = function () {
        var confetti = this._confetti || this.nativeView;
        confetti.colors = this._colors;
        confetti.intensity = this._intensity;
        confetti.autoStart = this._autoStart;
        confetti.fullScreen = this._fullScreen;
        if (this._autoStart) {
            this.startConfetti();
        }
        else {
            this.stopConfetti();
        }
    };
    ConfettiView.prototype.destroyNativeView = function () {
        if (this.confetti) {
            this.stopConfetti();
            if (this._fullScreen) {
                this.confetti.removeFromSuperview();
            }
        }
    };
    ConfettiView.prototype.startConfetti = function () {
        if (this.confetti && !this._active) {
            this.confetti.startConfetti();
            this._active = true;
        }
    };
    ConfettiView.prototype.stopConfetti = function () {
        if (this.confetti && this._active) {
            this.confetti.stopConfetti();
            this._active = false;
        }
    };
    Object.defineProperty(ConfettiView.prototype, "colors", {
        set: function (value) {
            this._colors = value;
            if (this.confetti) {
                this.confetti.colors = value;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConfettiView.prototype, "intensity", {
        set: function (value) {
            this._intensity = value;
            if (this.confetti) {
                this.confetti.intensity = value;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConfettiView.prototype, "fullScreen", {
        get: function () {
            return this._fullScreen;
        },
        set: function (value) {
            this._fullScreen = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConfettiView.prototype, "autoStart", {
        get: function () {
            return this._autoStart;
        },
        set: function (value) {
            this._autoStart = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConfettiView.prototype, "confetti", {
        get: function () {
            return this._confetti || this.nativeView;
        },
        enumerable: true,
        configurable: true
    });
    ConfettiView.Types = {
        confetti: 0,
        triangle: 1,
        star: 2,
        diamond: 3,
        image: 4
    };
    return ConfettiView;
}(common_1.ConfettiViewBase));
exports.ConfettiView = ConfettiView;
var rootVC = function () {
    var appWindow = UIApplication.sharedApplication.keyWindow;
    return appWindow.rootViewController;
};
