(function () {
    // 校验数据
    function check(num1 = 0, num2 = 0) {
        let numb1 = num1,
            numb2 = num2;

        numb1 = Number(num1);
        numb2 = Number(num2);

        if (numb1.toString() === 'NaN') throw new Error(`'${num1}' is not a number.`);
        if (String(numb2) === 'NaN') throw new Error(`'${num2}' is not a number.`);

        numb1 = String(num1);
        numb2 = num2.toString();

        return { numb1, numb2 };
    }

    // 赋值
    function handleValue(numb1 = 0, numb2 = 0, type) {
        if (type === 'addition' || type === 'subtraction') {
            let numLen1 = 0,
                numLen2 = 0,
                maxLen;

            if (numb1.indexOf('.') !== -1) numLen1 = (numb1.split('.')[1]).length;
            if (numb2.indexOf('.') !== -1) numLen2 = (numb2.split('.')[1]).length;
            maxLen = Math.pow(10, Math.max(numLen1, numLen2));

            return maxLen;
        } else if (type === 'multiplication') {
            let maxLen = 0;
            if (numb1.indexOf('.') !== -1) maxLen += (numb1.split('.')[1]).length;
            if (numb2.indexOf('.') !== -1) maxLen += (numb2.split('.')[1]).length;

            return maxLen;
        } else if (type === 'division') {
            let numLen1 = 0,
                numLen2 = 0,
                number1,
                number2;

            if (numb1.indexOf('.') !== -1) (numLen1 = (numb1.split('.')[1]).length, number1 = numb1.toString().replace(".", ""));
            if (numb2.indexOf('.') !== -1) (numLen2 = (numb2.split('.')[1]).length, number2 = numb2.toString().replace(".", ""));

            return {
                numLen1,
                numLen2,
                number1,
                number2
            };
        }
    }

    let calculation = {
        // 加法
        addition: function addition(num1 = 0, num2 = 0) {
            let { numb1, numb2 } = check(num1, num2);

            if (!numb1 && !numb2) return 0;

            let maxLen = handleValue(numb1, numb2, 'addition');

            // 调用乘法函数实现乘法计算
            return (this.multiplication(numb1, maxLen) + this.multiplication(numb2, maxLen)) / maxLen;
        },

        // 减法
        subtraction: function subtraction(num1 = 0, num2 = 0) {
            let { numb1, numb2 } = check(num1, num2);

            if (!numb1 && !numb2) return 0;

            let maxLen = handleValue(numb1, numb2, 'subtraction');

            return ((this.multiplication(numb1, maxLen)) - (this.multiplication(numb2, maxLen))) / maxLen;
        },

        // 乘法
        multiplication: function multiplication(num1 = 0, num2 = 0) {
            let { numb1, numb2 } = check(num1, num2);

            if (!num1 || !num2) return 0;

            let maxLen = handleValue(numb1, numb2, 'multiplication');

            return numb1.replace(".", "") * numb2.replace(".", "") / Math.pow(10, maxLen);
        },

        // 除法
        division: function division(num1 = 0, num2 = 0) {
            let { numb1, numb2 } = check(num1, num2);

            if (numb1 === '0') return 0;
            if (numb2 === '0') throw new Error('0 cannot divide.');

            let { numLen1, numLen2, number1, number2 } = handleValue(numb1, numb2, 'division');

            return this.multiplication((number1 / number2), Math.pow(10, numLen2 - numLen1));
        }
    };

    if (typeof window !== 'undefined') window.calculation = calculation;
    if (typeof module === 'object' && typeof module.exports === 'object') module.exports = calculation;
})();