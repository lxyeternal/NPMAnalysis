# 前言
> **因为JavaScript这门语言在计算浮点数时存在精度丢失，所以封装了加减乘除四个方法，每个方法只允许传两个参数，参数之间需要用逗号隔开。**

# 1、下载安装指令
```javascript  
npm install mj-calculation --save
```

# 2、暴露的方法
> |方法名|描述|
> |--|--|
> |addition|加法|
> |subtraction|减法|
> |multiplication|乘法|
> |division|除法|

# 3、使用方式
**CDN**
```html  
<script src="./node_modules/mj-calculation/index.js"></script>

<script>
    console.log('calculation:', calculation.addition(0.1, 0.2));
    // 0.3
    console.log('calculation:', calculation.subtraction(0.1, 0.2));
    // -0.1
    console.log('calculation:', calculation.multiplication(0.1, 0.2));
    // 0.02
    console.log('calculation:', calculation.division(0.1, 0.2));
    // 0.5
</script>
```

---
**vue**
```javascript  
import { addition, subtraction, multiplication, division } from "mj-calculation";
// const calculation = require("mj-calculation");

export default {
    name: "App",
    data() {
        return {};
    },
    mounted() {
        // console.log("calculation:", calculation);
        // calculation: {addition: ƒ, subtraction: ƒ, multiplication: ƒ, division: ƒ}

        console.log(addition, subtraction, multiplication, division);
        // 使用方式与CDN一样
    },
};
```