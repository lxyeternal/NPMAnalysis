# ol-dynamic-curves

#### description
An extentsion for openlayers to draw a linear、dynamic curves

### gitee
https://gitee.com/li_zuo_hong/ol-dynamic-curves

### install
npm install ol-dynamic-curves --save

### use
put the map instance render a default option dynamic curves.
```javascript
let curves = new CurvesLayer({
  map: this.map,
});
```

### default options
```javascript
const defaultOptions = {
    pointPositions: [[[140.80, 15.90], [143.60, 33.00]], [[140.80, 15.90], [154.216463, 42.895035]], [[140.80, 15.90], [105.941956, 47.07053]], [[140.80, 15.90], [100.718274, 0.95006]]],
    splitLength: 180,
    oneFrameLimitTime: 0,
    radialColor: {
        0: '#BBFFFF',
        0.2: '#AEEEEE',
        0.4: '#96CDCD',
        0.6: '#668B8B',
        0.8: '#98F5FF',
        1: '#8EE5EE'
    },
    controlRatio: 1.0,
}
```

### params description(can assign option)
| name              |                                                                                                                            means |
| ----------------- | -------------------------------------------------------------------------------------------------------------------------------: |
| pointPositions    | start and end pos collection: [ [ lonlatArray,lonlatArray] , [ lonlatArray,lonlatArray] ] => [ [ point,point], [ point,point]  ] |
| splitLength       |                                                                                                          the curves divide times |
| oneFrameLimitTime |                                        how much times render once (not accurate control this time,  current fps influence this ) |
| radialColor       |                                                                                                          linearColor description |
| controlRatio      |                                                                                                           controlPoint pos ratio |

### 相关API

#### addCurves
> add such curves,receive an Array like pointPositions 

```javascript
curves.addCurves([[[140.80, 15.90],[151.498262,-18.690718]]])
```
### refreshCurvesCoords
> refresh curves coords , I want to provide a option to init the lineCoords when you use the addCurves API at frist , finally, I decide to make an API for someone use.

```javascript
//  maybe addCurves ...
curves.refreshCurvesCoords()
```

### removeFeatureByIndex
>  this index means pointPositions index

```javascript
curves.removeFeatureByIndex(0) // delete pointPosition[0] related features
```

### destroy
> delete the relevant layer and event 

```javascript
curves.destroy()
```