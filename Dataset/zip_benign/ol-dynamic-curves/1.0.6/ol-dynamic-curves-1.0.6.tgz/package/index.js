import CurvesLayer from "./src/curvesLayer";

export default CurvesLayer;