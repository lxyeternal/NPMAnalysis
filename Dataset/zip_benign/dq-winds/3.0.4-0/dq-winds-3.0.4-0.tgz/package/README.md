# 大气事业部风流场插件

此插件基于mapbox地图,命名规则基于dq (大气)拼音简写。

作者:张向阳 


## Getting started

```bash
npm  install  dq-winds

```
## 使用教程


1. 引入该模块
```bash
import  dqwind  from 'dq-winds'
```
2. 初始化风流场
```bash
  let option = {
        id: 'wind1', // 风流场id (必要参数)
        map: map, // 地图对象(必要参数)
        data: data.stream,// (必要参数)  数据结构位于node_modules/dq-winds/example/json.js
        wind: {
            frame: '60',// 渲染帧  越小越快
            ParticleNum: 2000,// 粒子数
            lineWith: 1,// 线条宽度
            globalAlpha: 0.5,//设置尾巴长短  值为0-1
            renderFundtion: ` 
            if(1<wspeed&&wspeed<3){
            g.strokeStyle="#000"
            }else if(3<=wspeed&&wspeed<5){
            g.strokeStyle="green"
            }else{
                
            g.strokeStyle="red"
            }`//  渲染函数其中wspeed风速 g为canvas 画布对象

        }
    }
  // 实例化风场
   var  wind = new dqwind(option)

```
3. 创建风场
```bash
  wind.create()
```
4. 销毁风场
```bash
   wind.remove()
```
5. 说明
```bash
  具体参考例子: node_modules/dq-winds/example/index.html
```











## License

[MIT](LICENSE).
