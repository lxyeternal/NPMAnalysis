"use strict";
module.exports = /** @class */ (function () {
    function UnequalProbabilityRandom() {}
    UnequalProbabilityRandom.findLongestValueLength = function (array) {
        var len = array.length;
        var valueLengths = [];
        for (var i = 0; i < len; i++) {
            valueLengths[i] = array[i].toString().length;
        }
        return this.findMaximum(valueLengths);
    };
    UnequalProbabilityRandom.findMaximum = function (array) {
        var maximum = array[0];
        array.forEach(function (element) {
            if (element > maximum) {
                maximum = element;
            }
        });
        return maximum;
    };
    UnequalProbabilityRandom.valuesOfOption = function (option) {
        var values = [];
        for (var key in option) {
            values.push(option[key]);
        }
        return values;
    };
    UnequalProbabilityRandom.validateProbabilities = function (values) {
        var totalProb = 0;
        var powerNum = this.findLongestValueLength(values);
        /**
         * a number that makes decimals to be integers, in order to avoid the situation
         * that some decimal values' summation is not exactly equal to 1 when they are added
         * in node.js > 0.1+0.2 = 0.30000000000000004
         * but > (0.1×10+0.2×10)÷10 = 0.3
         */
        var coefficient = Math.pow(10, powerNum);
        values.forEach(function (prob) {
            totalProb += prob * coefficient;
        });
        // to judge whether the total probabilities(options' values' summation) is equal to 1
        if (totalProb != 1 * coefficient) {
            var errorText = "the sumation of the option's probabilities(" + values + ") is unequal to 1";
            throw new Error(errorText);
        }
    };
    UnequalProbabilityRandom.randomStringFunction = function (options) {
        var keys = Object.keys(options);
        /**
         * Object.values() method has not been supported in es6,
         * and typescript could not complie the next generation method
         */
        // let values: number[] = Object.values(options);
        var values = this.valuesOfOption(options);
        var keysLength = keys.length;
        this.validateProbabilities(values);
        // set the breakpoints for each probability area
        var probs = [0];
        for (var i = 1; i < keysLength + 1; i++) {
            probs[i] = values[i - 1] + probs[i - 1];
        }
        return function () {
            var probability = Math.random();
            var result = '';
            var executedStr = '';
            for (var i = 0; i < keysLength; i++) {
                executedStr += "if (probs[" + i + "] < probability && probability <= probs[" + (i + 1) + "]) {\n\t\t\t\t\tresult = keys[" + i + "];\n\t\t\t\t}";
            }
            eval(executedStr);
            return result;
        };
    };
    UnequalProbabilityRandom.randomNumberFunction = function (options) {
        var keys = Object.keys(options);
        /**
         * Object.values() method has not been supported in es6,
         * and typescript could not complie the next generation method
         */
        // let values: number[] = Object.values(options);
        var values = this.valuesOfOption(options);
        var keysLength = keys.length;
        this.validateProbabilities(values);
        // set the breakpoints for each probability area
        var probs = [0];
        for (var i = 1; i < keysLength + 1; i++) {
            probs[i] = values[i - 1] + probs[i - 1];
        }
        // the following variables are used to parse the options' keys for different result's returning
        var minusCharIndex;
        for (var key in options) {
            minusCharIndex = key.indexOf('-');
            var minusLeft = parseFloat(key.slice(0, minusCharIndex));
            var minusRight = parseFloat(key.slice(minusCharIndex + 1));
            if (isNaN(minusLeft) || isNaN(minusRight)) {
                var errorText = "uncorrect format in inputed option's key(" + key + ")";
                throw new Error(errorText);
            }
        }
        var boundarys = [];
        for (var i = 0; i < keysLength + 1; i++) {
            if (i < keysLength) {
                minusCharIndex = keys[i].indexOf('-');
                boundarys[i] = parseFloat(keys[i].slice(0, minusCharIndex));
            } else {
                minusCharIndex = keys[i - 1].indexOf('-');
                boundarys[i] = parseFloat(keys[i - 1].slice(minusCharIndex + 1));
            }
        }
        return function () {
            var probability = Math.random();
            var result = 0;
            var executedStr = '';
            for (var i = 0; i < keysLength; i++) {
                executedStr += "if (probs[" + i + "] < probability && probability <= probs[" + (i + 1) + "]) {\n\t\t\t\t\tresult = boundarys[" + i + "] + Math.random() * (boundarys[" + (i + 1) + "] - boundarys[" + i + "]);\n\t\t\t\t}";
            }
            eval(executedStr);
            return result;
        };
    };
    return UnequalProbabilityRandom;
}());