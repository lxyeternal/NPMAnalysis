export = class UnequalProbabilityRandom {
    constructor() {

    }

    private static findLongestValueLength(array: number[]): number {
        let len: number = array.length;
        let valueLengths: number[] = [];

        for (let i = 0; i < len; i++) {
            valueLengths[i] = array[i].toString().length;
        }

        return this.findMaximum(valueLengths);
    }

    private static findMaximum(array: number[]): number {
        let maximum: number = array[0];

        array.forEach((element: number) => {
            if (element > maximum) {
                maximum = element;
            }
        });

        return maximum;
    }

    private static valuesOfOption(option: any): number[] {
        let values: number[] = [];

        for (const key in option) {
            values.push(option[key]);
        }

        return values;
    }

    private static validateProbabilities(values: number[]): void {
        let totalProb: number = 0;
        let powerNum = this.findLongestValueLength(values);
        /**
         * a number that makes decimals to be integers, in order to avoid the situation 
         * that some decimal values' summation is not exactly equal to 1 when they are added
         * in node.js > 0.1+0.2 = 0.30000000000000004
         * but > (0.1×10+0.2×10)÷10 = 0.3
         */
        let coefficient: number = 10 ** powerNum;

        values.forEach((prob: number) => {
            totalProb += prob * coefficient;
        });

        // to judge whether the total probabilities(options' values' summation) is equal to 1
        if (totalProb != 1 * coefficient) {
            let errorText: string = `the sumation of the option's probabilities(${values}) is unequal to 1`;
            throw new Error(errorText);
        }
    }

    static randomStringFunction(options: {}): () => string {
        let keys: string[] = Object.keys(options);
        /**
         * Object.values() method has not been supported in es6,
         * and typescript could not complie the next generation method
         */
        // let values: number[] = Object.values(options);
        let values: number[] = this.valuesOfOption(options);
        let keysLength: number = keys.length;

        this.validateProbabilities(values);

        // set the breakpoints for each probability area
        let probs: number[] = [0];

        for (let i = 1; i < keysLength + 1; i++) {
            probs[i] = values[i - 1] + probs[i - 1];
        }

        return function () {	//if the options' keys are strings(or some single number), return strings
            let probability: number = Math.random();
            let result: string = '';
            let executedStr: string = '';
            for (let i = 0; i < keysLength; i++) {
                executedStr += `if (probs[${i}] < probability && probability <= probs[${i + 1}]) {
					result = keys[${i}];
				}`
            }
            eval(executedStr);
            return result;
        }
    }

    static randomNumberFunction(options: {}): () => number {
        let keys: string[] = Object.keys(options);
        /**
         * Object.values() method has not been supported in es6,
         * and typescript could not complie the next generation method
         */
        // let values: number[] = Object.values(options);
        let values: number[] = this.valuesOfOption(options);
        let keysLength: number = keys.length;

        this.validateProbabilities(values);

        // set the breakpoints for each probability area
        let probs: number[] = [0];

        for (let i = 1; i < keysLength + 1; i++) {
            probs[i] = values[i - 1] + probs[i - 1];
        }

        // the following variables are used to parse the options' keys for different result's returning
        let minusCharIndex: number;

        for (const key in options) {
            minusCharIndex = key.indexOf('-');
            let minusLeft: number = parseFloat(key.slice(0, minusCharIndex));
            let minusRight: number = parseFloat(key.slice(minusCharIndex + 1));
            if (isNaN(minusLeft) || isNaN(minusRight)) {
                const errorText = `uncorrect format in inputed option's key(${key})`;
                throw new Error(errorText);
            }
        }

        let boundarys: number[] = [];

        for (let i = 0; i < keysLength + 1; i++) {
            if (i < keysLength) {
                minusCharIndex = keys[i].indexOf('-');
                boundarys[i] = parseFloat(keys[i].slice(0, minusCharIndex));
            } else {
                minusCharIndex = keys[i - 1].indexOf('-');
                boundarys[i] = parseFloat(keys[i - 1].slice(minusCharIndex + 1));
            }
        }

        return function () {
            let probability: number = Math.random();
            let result: number = 0;
            let executedStr: string = '';
            for (let i = 0; i < keysLength; i++) {
                executedStr += `if (probs[${i}] < probability && probability <= probs[${i + 1}]) {
					result = boundarys[${i}] + Math.random() * (boundarys[${i + 1}] - boundarys[${i}]);
				}`
            }
            eval(executedStr);
            return result;
        }
    }
}