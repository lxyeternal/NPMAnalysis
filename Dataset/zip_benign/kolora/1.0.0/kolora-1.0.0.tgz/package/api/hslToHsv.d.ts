import { HSL, HSV } from 'types.js';
export declare function hslToHsv(hsl: HSL): HSV;
//# sourceMappingURL=hslToHsv.d.ts.map