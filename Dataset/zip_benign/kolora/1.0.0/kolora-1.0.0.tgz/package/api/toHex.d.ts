import { Rgba } from '../types.js';
export declare function toHex(rgba: Rgba): string;
//# sourceMappingURL=toHex.d.ts.map