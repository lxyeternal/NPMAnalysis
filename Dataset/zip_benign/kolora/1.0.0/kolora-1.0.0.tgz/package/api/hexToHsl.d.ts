import { HSL } from 'types.js';
export declare function hexToHsl(hex: string): HSL;
//# sourceMappingURL=hexToHsl.d.ts.map