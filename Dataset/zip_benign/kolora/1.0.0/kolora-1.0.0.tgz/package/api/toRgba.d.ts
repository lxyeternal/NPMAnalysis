import { Rgba } from '../types.js';
export declare function toRgba(hex: string): Rgba;
//# sourceMappingURL=toRgba.d.ts.map