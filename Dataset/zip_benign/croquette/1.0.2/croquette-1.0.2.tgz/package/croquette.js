#! /usr/bin/env node
/**
 * Created by ltrillaud on 08/02/2016.
 */
'use strict';


var program  = require('commander');
var io       = require('socket.io-client');
var URI      = require('urijs');
var Plugin   = require('nagios-plugin');
var handlers = require('./handlers.js');
var helpers  = require('./helpers.js');
var pjson    = require('./package.json');

// --- parse commande line arguments
program
    .version(pjson.version)
    .arguments('<file>')
    .option('-H, --host [hostname]', 'Croqui host default [localhost]', 'localhost')
    .option('-P, --port [portnumber]', 'Croqui port default [80]', '80')
    .option('-t, --transport [websocket|polling]', 'Croqui transport mode default [websocket]', 'websocket')
    .option('-a, --maxNbrAttempt [number]', 'Number max of attempt of Croqui connection default [3]', parseInt, 3)
    .option('-T, --acceptTiff', 'Don\'t convert Tiff image')
    .option('-k, --keepImage', 'Store received images on disk. For debug only. No perfdata.')
    .option('-R, --resize [width,height]', 'Request a resized image')
    .option('-C, --crop [top,left,bottom,right]', 'Request a croped image')
    .option('-w, --warning [duration]', 'Warning duration in ms')
    .option('-c, --critical [duration]', 'Critical duration in ms')
    .option('-v, --verbose', 'Use up to three level -vvv', helpers.increaseVerbosity, 0)
    .parse(process.argv);
exports.verbose = program.verbose || 0;
exports.keepImage = program.keepImage || false;

// --- create nagios plugin
var np = new Plugin();
exports.np = np;

// --- process arguments
if( program.args.length !== 1) {
    np.nagiosExit( np.states.UNKNOWN, 'No image file given. Use --help for usage.');
}
if( program.warning === undefined ^ program.critical === undefined) {
    np.nagiosExit( np.states.UNKNOWN, 'Must have both -w and -c or not at all');
}
var imgUrl = new URI( program.args[0]);
if( program.resize) {
    var parts = program.resize.split( ',');
    if( parts.length !== 2) {
        np.nagiosExit( np.states.UNKNOWN, 'Resize must have width and height separated by a comma');
    }
    imgUrl.addSearch( {w: parts[0], h:parts[1]});
}

if( program.crop) {
    var parts = program.crop.split( ',');
    if( parts.length !== 4) {
        np.nagiosExit( np.states.UNKNOWN, 'Crop must have top, left, bottom, right separated by a comma');
    }
    imgUrl.addSearch( {t: parts[0], l:parts[1], b: parts[2], r:parts[3], cropMode: 'fit'});
}

// --- set threshold for nagios
var threshold = {};
if( program.critical) {
    threshold.critical = program.critical;
}
if( program.warning) {
    threshold.warning = program.warning;
}
if( Object.keys(threshold).length !== 0) {
    np.setThresholds( threshold);
}

var croquiRootPath = new URI({
    protocol:program.transport === 'websocket' ? 'ws':'http',
    hostname: program.host,
    port: program.port
}).toString();

helpers.clog( 1, np.getReturnMessage( np.states.UNKNOWN, 'try to connect to=('+croquiRootPath+')'))

var socket = io( croquiRootPath, {
    'force new connection':true,
    transports:[program.transport]
});
socket.on('connect', function() {
    helpers.clog( 2, 'onConnect socketId=('+socket.id+')');
    helpers.clog( 2, 'send getImages filename=('+imgUrl.toString()+')');
    socket.send( {
        cmd: 'getImages',
        org: 'push',
        urls: [imgUrl.toString()],
        accept: program.acceptTiff ? 'image/tiff' : '',
        imgIdxs: [0],
        altIdx: 0,
        uid: 'plr-1',
        deferId: Date.now(),
        withBlob: false,
        withPnacl: false,
        withTiff: program.acceptTiff || false,
        userId: socket.id
    });

});
socket.on('disconnect', function() {
    helpers.clog( 2, 'onDisonnect');
});
socket.on('connect_error', function( err) {
    helpers.clog( 1, 'onConnectError err=('+err.toString()+')');
});
socket.on('connect_timeout', function() {
    helpers.clog( 1, 'onConnectTimeout');
});
socket.on('reconnect', function( nbrAttempt) {
    helpers.clog( 2, 'onReconnect nbrAttempt=('+nbrAttempt+'/'+program.maxNbrAttempt+')');
});
socket.on('reconnect_attempt', function() {
    helpers.clog( 2, 'onReconnectAttempt');
});
socket.on('reconnecting', function( nbrAttempt) {
    helpers.clog( 2, 'reconnecting nbrAttempt=('+nbrAttempt+'/'+program.maxNbrAttempt+')');
    if( nbrAttempt === program.maxNbrAttempt) {
        np.nagiosExit( np.states.UNKNOWN, 'Unable to connect to Croqui ('+croquiRootPath+') after '+nbrAttempt+' attempts');
    }
});
socket.on('reconnect_error', function( err) {
    helpers.clog( 1, 'onReconnectError err=('+err.toString()+')');
});
socket.on('reconnect_failed', function() {
    helpers.clog( 1, 'onReconnectFailed');
});
socket.on('message', function( msg) {
    helpers.clog( 3, msg);
    if( msg.hasOwnProperty( 'cmd')) {
        helpers.clog( 2, 'onMessage cmd=('+msg.cmd+')');
        var cmds = ['image', 'error'];
        if( cmds.indexOf( msg.cmd) !== -1) {
            handlers[msg.cmd+'Handler']( msg);
        } else {
            np.nagiosExit( np.states.UNKNOWN, 'cmd=('+msg.cmd+') unknown');
        }
    } else {
        np.nagiosExit( np.states.UNKNOWN, 'onMessage cmd property must exist');
    }
});

