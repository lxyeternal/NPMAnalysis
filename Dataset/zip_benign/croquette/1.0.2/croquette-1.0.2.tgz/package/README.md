# Croquette
***Command Line Interface (CLI) client for Croqui***

## Requirement
You need to have nodejs and npm installed on your OS.

```
sudo yum install nodejs npm
```
## Installation

- Install it

```
$ cd /projet/
$ tar xvf luccqui_croquette_xyz.tgz
$ cd croquette
$ sudo npm link
```

- Use it

```
$ croquette --help

  Usage: croquette [options] <file>

  Options:

    -h, --help                           output usage information
    -V, --version                        output the version number
    -H, --host [hostname]                Croqui host default [localhost]
    -P, --port [portnumber]              Croqui port default [80]
    -t, --transport [websocket|polling]  Croqui transport mode default [websocket]
    -a, --maxNbrAttempt [number]         Number max of attempt of Croqui connection default [3]
    -T, --acceptTiff                     Don't convert Tiff image
    -k, --keepImage                      Store received images on disk. For debug only. No perfdata.
    -R, --resize [width,height]          Request a resized image
    -C, --crop [top,left,bottom,right]   Request a croped image
    -w, --warning [duration]             Warning duration in ms
    -c, --critical [duration]            Critical duration in ms
    -v, --verbose                        Use up to three level -vvv
```

## Samples
### Request a simple jpeg image without any image processing

```
$ croquette -vv -H red-may1-rapp01.dev.mayenne.l121 exquis_001/pages/0001.jpg
CROQUETTE UNKNOWN - try to connect to=(ws://red-may1-rapp01.dev.mayenne.l121:80)|
onConnect socketId=(Tb2GL4PbzKP6g6TvAAAK)
send getImages filename=(exquis_001/pages/0001.jpg)
onMessage cmd=(image)
onImageHandler filename=(exquis_001/pages/0001.jpg)
done, got 221257 bytes, in 49 ms, speed 10.8 KB/s
CROQUETTE OK - Got it|duration=49ms;;;;
``` 

### Request a simple tiff image without any image processing
```
$ croquette -vv -T -H red-may1-rapp01.dev.mayenne.l121 exquis_001/pages/binarisation/0001.tif
CROQUETTE UNKNOWN - try to connect to=(ws://red-may1-rapp01.dev.mayenne.l121:80)|
onConnect socketId=(TOLWYB3dMegnPen1AAAL)
send getImages filename=(exquis_001/pages/binarisation/0001.tif)
onMessage cmd=(image)
onImageHandler filename=(exquis_001/pages/binarisation/0001.tif)
done, got 12678 bytes, in 33 ms, speed 0.4 KB/s
CROQUETTE OK - Got it|duration=33ms;;;;
```

### Request a simple tiff image and convert it in png
```
$ croquette -vv -H red-may1-rapp01.dev.mayenne.l121 exquis_001/pages/binarisation/0001.tif
CROQUETTE UNKNOWN - try to connect to=(ws://red-may1-rapp01.dev.mayenne.l121:80)|
onConnect socketId=(FwcZW2i-vfZqdbZEAAAM)
send getImages filename=(exquis_001/pages/binarisation/0001.tif)
onMessage cmd=(image)
onImageHandler filename=(exquis_001/pages/binarisation/0001.tif)
done, got 40871 bytes, in 198 ms, speed 8.1 KB/s
CROQUETTE OK - Got it|duration=198ms;;;;
```

### Request a tiff image, convert it in png, resize it and keep it for debug
```
$ croquette -vvv -H red-may1-rapp01.dev.mayenne.l121 -k --resize=512,512 exquis_001/pages/binarisation/0001.tif
CROQUETTE UNKNOWN - try to connect to=(ws://red-may1-rapp01.dev.mayenne.l121:80)|
onConnect socketId=(rU0-N5K1VhNbX9mOAAAN)
send getImages filename=(exquis_001/pages/binarisation/0001.tif?w=512&h=512)
{ cmd: 'image',
  userId: 'rU0-N5K1VhNbX9mOAAAN',
  buffer: <Buffer 89 50 4e 47 0d 0a 1a 0a 00 00 00 0d 49 48 44 52 00 00 02 00 00 00 00 c2 08 02 00 00 00 b0 a5 ed 3b 00 00 00 09 70 48 59 73 00 00 1e c2 00 00 1e c2 01 6e ...>,
  metadata: 
   { format: 'tiff',
     width: 1645,
     height: 623,
     space: 'b-w',
     channels: 1,
     hasProfile: false,
     hasAlpha: false },
  org: 'push',
  contentType: 'image/png',
  url: 'exquis_001/pages/binarisation/0001.tif?w=512&h=512',
  imgIdx: 0,
  altIdx: 0,
  uid: 'plr-1',
  deferId: 1455117211951,
  withBlob: false,
  end: true }
onMessage cmd=(image)
onImageHandler filename=(exquis_001/pages/binarisation/0001.tif?w=512&h=512)
image recorded in (exquis_001_pages_binarisation_0001.tiff)
done, got 64459 bytes, in 82 ms, speed 5.3 KB/s
CROQUETTE OK - Got it|duration=82ms;;;;
You have new mail in /var/spool/mail/jcr
[jcr@ind-may1-ddev01 ~]$ ll exquis_001_pages_binarisation_0001.tiff 
-rw-rw-r-- 1 jcr jcr 64459 Feb 10 16:13 exquis_001_pages_binarisation_0001.tiff

```

### Request a jpeg image and crop it with few logs
```
$ croquette -v -H red-may1-rapp01.dev.mayenne.l121 --crop=100,100,300,900 exquis_001/pages/0001.jpg
CROQUETTE UNKNOWN - try to connect to=(ws://red-may1-rapp01.dev.mayenne.l121:80)|
CROQUETTE OK - Got it|duration=138ms;;;;
```

### Request a simple jpeg like Harmonie and configure thresholds for Nagios at 1 and 15 seconds
```
$ croquette -H red-may1-rapp01.dev.mayenne.l121 -w 1000 -c 15000  exquis_001/pages/0001.jpg
CROQUETTE OK - Got it|duration=48ms;1000;15000;;
```

