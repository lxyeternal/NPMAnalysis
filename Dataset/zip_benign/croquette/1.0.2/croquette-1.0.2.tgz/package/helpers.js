/**
 * Created by ltrillaud on 09/02/2016.
 */
'use strict';

var main = require('./croquette');

exports.increaseVerbosity = function( v, total) {
    return Math.min( total+1, 3);
};

exports.clog = function(level, msg) {
    if( level <= main.verbose) {
        console.log( msg);
    }
};