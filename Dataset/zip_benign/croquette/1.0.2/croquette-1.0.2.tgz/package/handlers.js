/**
 * Created by ltrillaud on 09/02/2016.
 */

var fs = require('fs');
var helpers  = require('./helpers.js');
var main = require('./croquette');

module.exports = {
    imageHandler : function (msg) {
        helpers.clog( 2, 'onImageHandler filename=('+msg.url+')');

        // image name is the name on the uid + url + query string
        var begin = msg.url.indexOf('://');
        var end = msg.url.indexOf('?');
        var path = msg.url.substring(begin + (begin === -1 ? 1 : 3), (end === -1 ? msg.url.length : end));
        var tmpName = path.replace(/\//g, '_');

        // substitute image extention
        var metadata = msg.metadata;
        var start = tmpName.lastIndexOf('.');
        var stop = tmpName.indexOf('?');
        if (stop === -1) {
            stop = tmpName.length;
        }
        var ext = tmpName.substring(start + 1, stop);

        var imageName = metadata ? tmpName.replace(ext, metadata.format) : tmpName;
        try {
            if( main.keepImage) {
                fs.writeFileSync(imageName, msg.buffer);
                helpers.clog( 2,  'image recorded in ('+imageName+')');
            }
        } catch (e) {
            main.np.nagiosExit( main.np.states.UNKNOWN, 'Unable to store image (' + e.toString() + ')');
        }

        if (msg.end) {
            var size = msg.buffer.length;
            var duration = Date.now() - msg.deferId;
            var speed = Math.round( (msg.buffer.length / 1000) * ((Date.now() - msg.deferId) / 1000) * 10) / 10;

            // --- add perf data
            main.np.addPerfData( {
                label: 'duration',
                value: duration,
                uom: 'ms',
                threshold: main.np.threshold
            });
            helpers.clog( 2, 'done, got '+ size +' bytes, in '+ duration +' ms, speed '+ speed +' KB/s');
            var state = main.np.threshold ? main.np.checkThreshold(duration) : main.np.states.OK;
            main.np.nagiosExit( state, 'Got it');
        } else {
            helpers.clog( 2, 'progress, got in '+ duration +' ms');
        }
    },

    errorHandler : function (msg) {
        helpers.clog( 2, ' handlers.js onErrorHandler');
        if (!msg.hasOwnProperty('end') || msg.end) {
            main.np.nagiosExit( main.np.states.UNKNOWN, msg.msg || 'Impossible de charger l\'image du serveur');
        }
    }
}