export declare type AreaData = [number, number, number, number];
export declare const pasi: (head_neck: AreaData, upper_limbs: AreaData, trunk: AreaData, lower_limbs: AreaData) => number;
