export declare type SIPAChildAge = 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16;
/**
 * Roughly estimates the possibility of occult shock in adults, especially
 * in trauma or acute hemorrhage.
 */
export declare const si: (heart_rate: number, systolic_BP: number) => number;
export declare const sipa: (age: SIPAChildAge, max_heart_rate: number, min_systolic_BP: number) => -1 | "sipa function called";
