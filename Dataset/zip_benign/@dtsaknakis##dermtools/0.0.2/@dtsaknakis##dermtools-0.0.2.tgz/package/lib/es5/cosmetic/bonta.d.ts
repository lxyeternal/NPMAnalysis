/** Returns the total Units per vial of a botulinum toxin brand */
export declare const brandUnits: (brandName?: string) => number;
/**
* Returns units in a syringe of a given size, given the BoNT-A brand and
* its dilution
* */
export declare const syringeUnits: (brandName?: string, dilution?: number, syringeVolume?: number) => number;
