export declare type GCSEyeEntry = 0 | 1 | 2 | 3 | 4;
export declare type GCSVerbalEntry = 0 | 1 | 2 | 3 | 4 | 5;
export declare type GCSMotorEntry = 0 | 1 | 2 | 3 | 4 | 5 | 6;
export declare type PGCSEyeEntry = 1 | 2 | 3 | 4;
export declare type PGCSVerbalEntry = 1 | 2 | 3 | 4 | 5;
export declare type PGCSMotorEntry = 1 | 2 | 3 | 4 | 5 | 6;
export interface GCSResult {
    e: GCSEyeEntry;
    v: GCSVerbalEntry;
    m: GCSMotorEntry;
    score: number;
}
export interface PGCSResult {
    e: PGCSEyeEntry;
    v: PGCSVerbalEntry;
    m: PGCSMotorEntry;
    score: number;
}
/** Glasgow Coma Scale calculation. */
export declare const gcs: (eye_response: GCSEyeEntry, verbal_response: GCSVerbalEntry, motor_response: GCSMotorEntry) => GCSResult | -1;
/** Pediatric Glasgow Coma Scale calculation (for < 2 years old). */
export declare const pgcs: (eye_response: PGCSEyeEntry, verbal_response: PGCSVerbalEntry, motor_response: PGCSMotorEntry) => PGCSResult | -1;
