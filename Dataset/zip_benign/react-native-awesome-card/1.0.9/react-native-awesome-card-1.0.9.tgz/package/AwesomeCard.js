import React, {Component} from 'react';
import {View, Platform} from 'react-native';
import PropTypes from 'prop-types';
import {moderateScale} from "./size_matters";

SPACE_TINY_2 = 4;
SPACE_SMALL_2 = 8;
SPACE_NORMAL = 10;

class AwesomeCard extends Component {


    render() {
        let margins = {
            marginLeft: this.props.marginLeft,
            marginRight: this.props.marginRight,
            marginTop: this.props.marginTop,
            marginBottom: this.props.marginBottom,
        };
        if (this.props.marginBottom == 0 && this.props.marginLeft == 0 && this.props.marginRight == 0 && this.props.marginTop == 0) {
            margins = {
                marginLeft: this.props.margin,
                marginRight: this.props.margin,
                marginTop: this.props.margin,
                marginBottom: this.props.margin,
            };
        }
        let paddings = {
            paddingLeft: this.props.paddingLeft,
            paddingRight: this.props.paddingRight,
            paddingTop: this.props.paddingTop,
            paddingBottom: this.props.paddingBottom,
        };
        if (this.props.paddingBottom == 0 && this.props.paddingLeft == 0 && this.props.paddingRight == 0 && this.props.paddingTop == 0) {
            paddings = {
                paddingLeft: this.props.padding,
                paddingRight: this.props.padding,
                paddingTop: this.props.padding,
                paddingBottom: this.props.padding,
            };
        }


        return (
            <View style={[{...this.styles.containerStyle, ...margins, ...paddings}, {...this.props.style}]}>
                {this.props.children}
            </View>
        )
    }

    styles = {
        containerStyle: (Platform.OS == 'ios') ? {
                backgroundColor: this.props.color,
                borderWidth: 0,
                borderRadius: moderateScale(this.props.radius),
                borderColor: '#ddd',
                borderBottomWidth: 0,
                shadowColor: this.props.shadowColor,
                shadowOffset: {
                    width: moderateScale(this.props.shadowWidth),
                    height: moderateScale(this.props.shadowHeight)
                },
                shadowOpacity: this.props.shadowOpacity,
                shadowRadius: moderateScale(this.props.shadowRadius),
                marginLeft: moderateScale(this.props.marginLeft),
                marginRight: moderateScale(this.props.marginRight),
                marginTop: moderateScale(this.props.marginTop),
                marginBottom: moderateScale(this.props.marginBottom),
                margin: moderateScale(this.props.margin),
                paddingLeft: moderateScale(this.props.paddingLeft),
                paddingRight: moderateScale(this.props.paddingRight),
                paddingTop: moderateScale(this.props.paddingTop),
                paddingBottom: moderateScale(this.props.paddingBottom),
                padding: moderateScale(this.props.padding),
            }
            : {
                backgroundColor: this.props.color,
                borderWidth: 0,
                borderRadius: moderateScale(this.props.radius),
                borderColor: '#ddd',
                borderBottomWidth: 0,
                elevation: moderateScale(this.props.androidElevation),
                marginLeft: moderateScale(this.props.marginLeft),
                marginRight: moderateScale(this.props.marginRight),
                marginTop: moderateScale(this.props.marginTop),
                marginBottom: moderateScale(this.props.marginBottom),
                margin: moderateScale(this.props.margin),
                paddingLeft: moderateScale(this.props.paddingLeft),
                paddingRight: moderateScale(this.props.paddingRight),
                paddingTop: moderateScale(this.props.paddingTop),
                paddingBottom: moderateScale(this.props.paddingBottom),
                padding: moderateScale(this.props.padding),
            }
    }

}

AwesomeCard.propTypes = {
    color: PropTypes.string,
    marginRight: PropTypes.number,
    marginLeft: PropTypes.number,
    marginTop: PropTypes.number,
    marginBottom: PropTypes.number,
    margin: PropTypes.number,
    paddingRight: PropTypes.number,
    paddingLeft: PropTypes.number,
    paddingTop: PropTypes.number,
    paddingBottom: PropTypes.number,
    padding: PropTypes.number,
    radius: PropTypes.number,
    shadowColor: PropTypes.string,
    shadowWidth: PropTypes.number,
    shadowHeight: PropTypes.number,
    shadowOpacity: PropTypes.number,
    shadowRadius: PropTypes.number,
    androidElevation: PropTypes.number,

}

AwesomeCard.defaultProps = {
    color: 'white',
    marginRight: 0,
    marginLeft: 0,
    marginTop: 0,
    marginBottom: 0,
    margin: 10,
    paddingLeft: 0,
    paddingRight: 0,
    paddingTop: 0,
    paddingBottom: 0,
    padding: 15,
    radius: 4,
    shadowColor: '#000000',
    shadowWidth: 0,
    shadowHeight: 1,
    shadowOpacity: 0.35,
    shadowRadius: 4,
    androidElevation:4
}

export default AwesomeCard;