# grunt-snockets

## This is a fork of the grunt-snockets project which only goal is to publish it on npmjs.org, since the 1.6 version compatible with Grunt 0.4 was never published, and furthermore, since the 1.5 was removed from npmjs.org in the beginning of April'16 for no reason.

[Snockets](https://github.com/TrevorBurnham/snockets) for grunt.js

## Getting Started
Install this grunt plugin next to your project's [grunt.js gruntfile][getting_started] with: `npm install grunt-snockets`

Then add this line to your project's `grunt.js` gruntfile:

```javascript
grunt.loadNpmTasks('grunt-snockets');
```

[grunt]: http://gruntjs.com/
[getting_started]: https://github.com/gruntjs/grunt/wiki

## Documentation (Basic Usage)
**coffee/components/ctabs.coffee**
```coffeescript
class CTabs
	constructor: (tabs) ->
		tabs.each (k, v) ->
			console.log k, v
```

**coffee/app.coffee**
```coffeescript
#= require_tree components
$ ->
	console.log 'Hello my friend ^^'
```

**grunt conifg**
```javascript
grunt.initConfig({
	snockets: {
		compile: {
			src: 'coffee/app.coffee',
			dest: 'public/js/app.js'
		}
	}
})
```

Finally **public/js/app.js** become:
```javascript
(function() {
  var CTabs;

  CTabs = (function() {

    function CTabs(tabs) {
      tabs.each(function(k, v) {
        return console.log(k, v);
      });
    }

    return CTabs;

  })();

}).call(this);

(function() {

  $(function() {
    return console.log('Hello my friend ^^');
  });

}).call(this);
```

## Contributing
In lieu of a formal styleguide, take care to maintain the existing coding style. Add unit tests for any new or changed functionality. Lint and test your code using [grunt][grunt].

## Release History
_(Nothing yet)_

## License
Copyright (c) 2013 Umur Gedik  
Licensed under the MIT license.
