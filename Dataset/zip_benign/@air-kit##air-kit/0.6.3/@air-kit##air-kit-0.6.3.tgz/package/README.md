# air-kit

Common ui components for Air Product Series. Build air products without tears😭

## Example

```javascript
import { Button, PageHeader } from '@air-kit/air-kit'

const MyComponent = () => (
  <div>
    <PageHeader
      title="ページタイトル"
      helpText="ページタイトルについての説明ページタイトルについての説明ページタイトルについての説明ページタイトルについての説明。"
      actions={<Button primary>新規登録</Button>}
      trigger="hover"
      placement="right"
      mouseLeaveDelay={0.3}
    />
  </div>
)
```

## Installation

### npm

`npm install @air-kit/air-kit --save-dev`

### yarn

`$yarn add @air-kit/air-kit`

### peer dependencies

`react react-dom styled-components`

## 連絡

不具合や要望があれば slackチャンネル #air-kit-fe へご連絡ください。
