import VideoContext from 'videocontext'
import Gibberish from 'gibberish-dsp'

import AST from './AST.js'
import Graph from './Graph.js'

let AC = null
let VC = null

const FlowAV = {
  _AC: null,
  _VC: null,
  _DSP: null,
  _AST: null,
  _Graph: null,
  setup(canvas) {
    // Keep a reference to these simply
    // for debugging purposes
    this._DSP = Gibberish
    this._VC = VC = new VideoContext(canvas)
    this._AC = AC = new AudioContext()
    this._AST = AST
    this._Graph = Graph
  },
  
  start(bg) {
    this._DSP.init(null, AC)
    // VideoContext stops when all clips have finished playing
    // this means we can't add more clips to the timeline (or maybe
    // it does, but I haven't worked out how yet). A black background
    // image plays forever to keep the VC in a constant playing state.
    var bgNode = VC.image(bg);
        bgNode.connect(VC.destination);
        bgNode.start(0);
    VC.play()
  },

  update(code) {
    this._AST.generate(code)
    
    for (let i = 0; i < this._AST.audio.new.length; i++) {
      let o = this._AST.audio.old[i]
      let n = this._AST.audio.new[i]
      let r = (!this._AST.compare(o, n) && (!o || n.arg !== o.arg))
      this._Graph.updateAudio(i, n, r)
    }
    
    
    for (let i = 0; i < this._AST.video.new.length; i++) {
      let o = this._AST.video.old[i]
      let n = this._AST.video.new[i]
      // r decides whether we replace a video node or just update it.
      // a node needs updating when its type (Video, Image etc..) or
      // arg change
      let r = (!this._AST.compare(o, n) && (!o || n.arg !== o.arg))
      this._Graph.updateVideo(i, n, r)
    }
    for (let i = this._AST.video.new.length; i < this._AST.video.old.length; i++) {
      this._Graph.destroyVideo(i)
    }
    
    this._AST.update()
  }
}

export default FlowAV
export { AC, VC }