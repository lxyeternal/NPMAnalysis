import { AC, VC } from './FlowAV'
import { VideoNode, ImageNode } from './Video/Nodes'

const Graph = {
  _audioGraph: [],
  _videoGraph: [],
  updateAudio(i, o, replace = false) {
    if (replace) {
    } else {
    }
  },
  destroyAudio(i) {
    
  },
  updateVideo(i, o, replace = false) {
    if (replace) {
      switch (o.type) {
        case 'Video':
          this._videoGraph[i] = new VideoNode(o.arg, o.props, o.connections)
          break;
        case 'Image':
          this._videoGraph[i] = new ImageNode(o.arg, o.props, o.connections)
          break;
        default:
          break;
      }
    } else {
      switch (o.type) {
        case 'Video':
        case 'Image':
          this._videoGraph[i].update(o.props, o.connections)
          break;
        default:
          break;
      }
    }
  },
  destroyVideo(i) {
    this._videoGraph[i].destroy()
  }
}

export default Graph