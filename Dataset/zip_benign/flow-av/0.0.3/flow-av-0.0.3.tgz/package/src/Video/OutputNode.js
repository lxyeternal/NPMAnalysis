import { VC } from '../FlowAV'
import { DEFINITIONS } from 'videocontext'
import BaseNode from './BaseNode'
import EffectNode from './EffectNode'

export default class OutputNode extends BaseNode {
  constructor () {
    super(null, [], [])
    this._type = 'Output'
    this._node = VC.destination
  }
}