import { DEFINITIONS } from 'videocontext'

export default (context, props) => {
  const node = context.effect(DEFINITIONS.VERTICAL_BLUR)
  
  for (let i = 0; i < props.length; i++) {
    const p = props[i]
    switch (Object.keys(p)[0]) {
      case 'amount':
        node.blurAmount = p.amount[0] || 1.0
        break;
      default:
        break;
    }
  }
  
  return node
}