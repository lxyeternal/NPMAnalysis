import { VC } from '../FlowAV'
import { DEFINITIONS } from 'videocontext'

export default class BaseNode {
  constructor (arg, props, connections) {
    this.params       = { arg, props, connections }
    this._type        = null
    this._node        = null
    this._props       = []
    // output node could either be the raw node or the last in a chain of
    // effects nodes created by _props
    this._output      = null
    this._connections = []
  }
  
  // --------------------------------------------------------------------------
  // some props are universal to all nodes so it makes sense to include a method
  // in the base node to handle them rather than repeat ourselves.
  _addBaseProp(prop) {
    // props come in as {key: value} pairs, where the key defines the type of
    // effect
    let opacity, pos, scale, crop;
    switch (Object.keys(prop)[0]) {
      case 'opacity':
        opacity = VC.effect(DEFINITIONS.OPACITY)
        opacity.opacity = prop.opacity[0] || 1
        this._props.push(opacity)
        break;
      case 'pos':
        pos = VC.effect(DEFINITIONS.AAF_VIDEO_POSITION)
        pos.positionOffsetX = prop.pos[0] || 0
        pos.positionOffsetY = prop.pos[1] || 0
        this._props.push(pos)
        break;
      case 'scale':
        scale = VC.effect(DEFINITIONS.AAF_VIDEO_SCALE)
        scale.scaleX = prop.scale[0] || 1
        scale.scaleY = prop.scale[1] || prop.scale[0] || 1
        this._props.push(scale)
        break;
      case 'crop':
        crop = VC.effect(DEFINITIONS.CROP)
        crop.width = prop.crop[0] || 1
        crop.height = prop.crop[1] || prop.crop[0] || 1
        crop.x = prop.crop[2] || 0
        crop.y = prop.crop[3] || prop.crop[2] || 0
        this._props.push(crop)
        scale = VC.effect(DEFINITIONS.AAF_VIDEO_SCALE)
        scale.scaleX = prop.crop[0] || 1
        scale.scaleY = prop.crop[1] || prop.crop[0] || 1
        this._props.push(scale)
        break;
      default:
        break;
    }
  }
  
  _connect() {
    // connect the base node to the first effect node created by _props
    if (this._props.length > 0)
      this._node.connect(this._props[0])
    // then, if there are more, connect each effect node in series
    if (this._props.length > 1)
      for (let i = 0; i < this._props.length - 1; i++) {
        this._props[i].connect(this._props[i + 1])
      }
    // for external purposes, the effects chain created from _props can be considered
    // all part of the base node. Update the outward facing output according to the
    // effects created
    this._output = this._props[this._props.length - 1] || this._node
    
    for (let c of this._connections) {
      this._output.connect(c.input())
    }
    
  }
  
  _disconnect() {
    if (this._props.length > 0)
      this._node.disconnect(this._props[0])
    if (this._props.length > 1) {
      for (let i = 0; i < this._props.length - 1; i++) {
        this._props[i].disconnect(this._props[i + 1])
        this._props[i].destroy()
      }
      this._props[this._props.length - 1].destroy()
    }
      
    this._output = this._node
    
    for (let c of this._connections) {
      this._output.disconnect(c.input())
      if (c.type() !== 'Output')
        c.destroy()
    }
    
    this._props = []
    this._connections = []
  }
  
  // --------------------------------------------------------------------------
  input() {
    return this._node
  }
  
  output() {
    return this._output
  }
  
  type() {
    return this._type
  }
  
  destroy() {
    this._disconnect()
    this._node.destroy()
  }
}
