import { DEFINITIONS } from 'videocontext'

export default (context, props) => {
  const node = context.effect(DEFINITIONS.COLORTHRESHOLD)
  
  for (let i = 0; i < props.length; i++) {
    const p = props[i]
    switch (Object.keys(p)[0]) {
      case 'color':
        node.colorAlphaThreshold = [p.color[0], p.color[1] || 0, p.color[2] || 0]
        break;
      default:
        break;
    }
  }
  
  return node
}