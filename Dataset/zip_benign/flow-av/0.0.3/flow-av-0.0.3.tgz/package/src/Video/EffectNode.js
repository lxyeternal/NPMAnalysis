import { VC } from '../FlowAV'

import ChromakeyEffect from './Effects/ChromakeyEffect'
import MonochromeEffect from './Effects/MonochromeEffect'
import HorizontalFlipEffect from './Effects/HorizontalFlipEffect'
import VerticalFlipEffect from './Effects/VerticalFlipEffect'
import HorizontalBlurEffect from './Effects/HorizontalBlurEffect'
import VerticalBlurEffect from './Effects/VerticalBlurEffect'

import BaseNode from './BaseNode'
import OutputNode from './OutputNode'

export default class EffectNode extends BaseNode {
  constructor (arg, props, connections) {
    super(arg, props, connections)
    this._type = 'Effect'
    this._createNode(arg, props)
    if (props)
      this._addProps(props)
    if (connections)
      this._addConnections(connections)
    this._connect()
  }

  // Private methods ----------------------------------------------------------
  _createNode(arg, props) {
    switch (arg) {
      case 'monochrome':
        this._node = MonochromeEffect(VC, props)
        break;
      case 'flipX':
        this._node = HorizontalFlipEffect(VC)
        break;
      case 'flipY':
        this._node = VerticalFlipEffect(VC)
        break;
      case 'blurX':
        this._node = HorizontalBlurEffect(VC, props)
        break;
      case 'blurY':
        this._node = VerticalBlurEffect(VC, props)
        break;
      case 'chroma':
      case 'chromaKey':
        this._node = ChromakeyEffect(VC, props)
        break;
      default:
        break;
    }
  }
  
  _addProps(props) {
    for (let i = 0; i < props.length; i++) {
      this._addBaseProp(props[i])
    }
  }
  
  _addConnections(connections) {
    for (let i = 0; i < connections.length; i++) {
      const c = connections[i]
      switch (c.type) {
        case 'Effect':
          this._connections.push(new EffectNode(VC, c.arg, c.props, c.connections))
          break;
        case 'Output':
          this._connections.push(new OutputNode(VC, c.props))
          break;
        default:
          break;
      }
    }
  }
  // Public methods -----------------------------------------------------------
  update(props, connections) {
    this._disconnect()
    this._createNode(this._type, props)
    if (props)
      this._addProps(props)
    if (connections)
      this._addConnections(connections)
  }
}