import { AC, VC } from '../FlowAV'
import BaseNode from './BaseNode'
import EffectNode from './EffectNode'
import OutputNode from './OutputNode'

export default class VideoNode extends BaseNode {
  constructor (arg, props, connections) {
    super(arg, props, connections)
    this._type = 'Video'
    // VideoVC supports loading clips from a URL. FlowAV may drop this in the future
    // but for now it's supported
    if (arg.substring(0, 4) === 'http' || arg.substring(0, 3) === 'www') {
      // apply the loop param if its supplied
      this._node =
        props.find(p => p.loop) ? VC.video(arg, 0, 5, { loop: true }) : VC.video(arg)
    } else {
      const path = `/video/${arg}`
      this._node =
        props.find(p => p.loop) ? VC.video(path, 0, 5, { loop: true }) : VC.video(path)
    }
    this._audioNode = null
    this._startTime = -1
    this._stopTime = -1
    
    if (props)
      this._addProps(props)
    if (connections)
      this._addConnections(connections)
    this._connect()
    this._node.start(this._startTime)
    if (this._stopTime > 0)
      this._node.stop(this._stopTime)
  }
  // Private methods ----------------------------------------------------------
  _addProps(props) {
    for (let i = 0; i < props.length; i++) {
      const p = props[i]
      switch (Object.keys(p)[0]) {
        case 'gain':
          this._node.volume = p.gain[0]
          break;
        case 'offset':
          this._node._sourceOffset = p.offset[0]
          break;
        case 'start':
          this._startTime = p.start[0]
          break;
        case 'stop':
          this._stopTime = p.stop[0]
          break;
        default:
          this._addBaseProp(p)
      }
    }
  }
  
  _addConnections(connections) {
    for (let i = 0; i < connections.length; i++) {
      const c = connections[i]
      switch (c.type) {
        case 'Effect':
          this._connections.push(new EffectNode(c.arg, c.props, c.connections))
          break;
        case 'Output':
          this._connections.push(new OutputNode())
          break;
        default:
          break;
      }
    }
  }
  // Public methods -----------------------------------------------------------
  update(props, connections) {
    this._disconnect()
    if (props)
      this._addProps(props)
    if (connections)
      this._addConnections(connections)
    this._connect()
  }
  
  stop(stopTime = 0) {
    this._disconnect()
    this._node.stop(time)
    this._node.destroy()
  }
}