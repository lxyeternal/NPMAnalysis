import BaseNode from './BaseNode'
import EffectNode from './EffectNode'
import OutputNode from './OutputNode'

export default class VideoNode extends BaseNode {
  constructor (context, arg, props, connections) {
    super(context, arg, props, connections)
    this._type = 'Video'
    // VideoContext supports loading clips from a URL. FlowAV may drop this in the future
    // but for now it's supported
    if (arg.substring(0, 4) === 'http' || arg.substring(0, 3) === 'www') {
      this._node = context.image(arg)
    } else {
      const path = `/img/${arg}`
      this._node = context.image(path)
    }
    if (props)
      this._addProps(props)
    if (connections)
      this._addConnections(connections)
    this._connect()
    this._node.start(-1)
  }
  // Private methods ----------------------------------------------------------
  _addProps(props) {
    for (let i = 0; i < props.length; i++) {
      const p = props[i]
      this._addBaseProp(p)
    }
  }
  
  _addConnections(connections) {
    for (let i = 0; i < connections.length; i++) {
      const c = connections[i]
      switch (c.type) {
        case 'Effect':
          this._connections.push(new EffectNode(this._context, c.arg, c.props, c.connections))
          break;
        case 'Output':
          this._connections.push(new OutputNode(this._context))
          break;
        default:
          break;
      }
    }
  }
  // Public methods -----------------------------------------------------------
  update(props, connections) {
    this._disconnect()
    if (props)
      this._addProps(props)
    if (connections)
      this._addConnections(connections)
    this._connect()
  }
  
  stop() {
    this._disconnect()
    this._node.stop()
    this._node.destroy()
  }
}