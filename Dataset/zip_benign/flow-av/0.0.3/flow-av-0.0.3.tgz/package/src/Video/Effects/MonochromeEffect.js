import { DEFINITIONS } from 'videocontext'

export default (context, props) => {
  const node = context.effect(DEFINITIONS.MONOCHROME)
  
  for (let i = 0; i < props.length; i++) {
    const p = props[i]
    switch (Object.keys(p)[0]) {
      case 'input':
        node.inputMix = [
          p.input[0] || 0.4,
          p.input[1] || p.input[0] || 0.6,
          p.input[2] || p.input[0] || 0.2
        ]
        break;
      case 'output':
        node.outputMix = [
          p.output[0] || 1.0,
          p.output[1] || p.output[0] || 1.0,
          p.output[2] || p.output[0] || 1.0
        ]
        break;
      default:
        break;
    }
  }
  
  return node
}