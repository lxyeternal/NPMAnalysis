import { DEFINITIONS } from 'videocontext'

export default (context) => {
  return context.effect(DEFINITIONS.AAF_VIDEO_FLOP)
}