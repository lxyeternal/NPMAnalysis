const moo = require('moo')
class TokenStream {
  constructor(input) {
    this._lexer = moo.compile({
      // contexts
      VIDEO: '$',
      AUDIO: '#',
      // syntax
      node: /[A-Z][a-z]+/,
      arg: { match: /\(.*\)/, value: x => (x.substring(2, x.length - 2) === '()' ? null : x.substring(2, x.length - 2)) },
      prop: { match: /: [a-z]+/, value: x => x.substring(2) },
      val: [
          { match: /->(?: -?\d+\.?\d*)+/, value: x => x.substring(3).split(' ').map(Number) },
          { match: /->(?: [a-z]+)+/, value: x => x.substring(3).split(' ') }
      ],
      connection: '|',
      // whitespace
      indent: { match: /\n +/, value: x => x.length - 1, lineBreaks: true },
      whitespace:  /[ \t]+/,
      newline: { match: /\n/, lineBreaks: true },
      // misc
      comment: /\/\/.*/,
      error: moo.error
    })
    this._tokens = Array.from( this._lexer.reset(input) )
      // remove { whitespace }, { newline }, and { comment } tokens
      .filter( el => !el.type.match(/whitespace|newline|comment/) )
      .map( el => ({ type: el.type, value: el.value, line: el.line, col: el.col }) )
    this._pos = 0
    this._line = 1
    this._col = 1
  }
  length () {
    return this._tokens.length
  }
  next() {
    return this._tokens[this._pos++]
  }
  peek() {
    return this._tokens[this._pos]
  }
  EOF() {
    return this.peek() === undefined
  }
}

function createNode(stream, level) {
  const parseType = () => {
    return (stream.peek().type === 'node' ? stream.next().value : null)
  }
  const parseArg = () => {
    return (stream.peek().type === 'arg' ? stream.next().value : null)
  }
  const parseProps = () => {
    const props = []
    while (!stream.EOF()) {
      if (stream.peek().type === 'indent') {
        if (stream.peek().value / 2 < level)
          return props
        else stream.next()
      }
      if (stream.peek().type === 'prop') {
        props.push({
          [stream.next().value]: (stream.peek().type === 'val' ? stream.next().value : true)
        })
      } else {
        break;
      }
    }
    return props
  }
  const parseConnections = () => {
    const connections = []
    while (!stream.EOF()) {
      if (stream.peek().type === 'indent') {
        if (stream.peek().value / 2 < level)
          return connections
        else stream.next()
      }
      if (stream.peek().type === 'connection') {
        stream.next()
        if (stream.peek().type === 'node') {
          connections.push( createNode(stream, level + 1) )
        }
      } else {
        break;
      }
    }
    return connections
  }
  
  let _type = parseType()
  let _arg = parseArg()
  let _props = []
  let _connections = []
  
  if (!stream.EOF()) {
    if (stream.peek().type === 'indent') {
      if (level) {
        _props = parseProps()
        _connections = parseConnections()
      } else {
        level = stream.next().value / 2
        _props = parseProps()
        _connections = parseConnections()
      }
    }
  }
  
  return {
    type:         _type,
    arg:          _arg,
    props:        _props,
    connections:  _connections
  }
}

const AST = {
  audio: {
    old: [],
    new: []
  },
  video: {
    old: [],
    new: []
  },
  generate(code) {
    const stream = new TokenStream(code)
    while (!stream.EOF()) {
      const token = stream.next()
      switch (token.type) {
        case 'AUDIO':
          this.audio.new.push( createNode(stream) )
          break;
        case 'VIDEO':
          this.video.new.push( createNode(stream) )
          break;
        default:
          break;
      }
    }
  },
  update() {
    this.audio.old = Array.from(this.audio.new)
    this.video.old = Array.from(this.video.new)
    this.audio.new = []
    this.video.new = []
  },
  // source: https://gist.github.com/nicbell/6081098
  compare(a, b) {
    return JSON.stringify(a) === JSON.stringify(b)
  }
}

export default AST