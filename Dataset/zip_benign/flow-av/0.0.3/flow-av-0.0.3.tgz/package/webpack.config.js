/* global __dirname, require, module*/

const webpack = require('webpack');
const UglifyJsPlugin = webpack.optimize.UglifyJsPlugin;
const path = require('path');
const pkg = require('./package.json');

let libraryName = pkg.name;
let plugins = [
  //new UglifyJsPlugin({ minimize: true })
]
let outputFile = libraryName + '.js';

module.exports = env => {
  let outputPath = ''
  
  if (process.env.NODE_ENV == 'prod')
    outputPath = '/dist'
  if (process.env.NODE_ENV == 'dev')
    outputPath = '/test'
  
  return {
    entry: __dirname + '/src/FlowAV.js',
    devtool: 'source-map',
    devServer: {
    contentBase: path.join(__dirname, "test"),
      compress: true,
      host: '0.0.0.0',
      port: 8000
    },
    output: {
      path: __dirname + outputPath,
      filename: outputFile,
      library: libraryName,
      libraryTarget: 'umd',
      umdNamedDefine: true
    },
    module: {
      rules: [
        {
          test: /(\.jsx|\.js)$/,
          loader: 'babel-loader',
          exclude: /(node_modules|bower_components)/
        }
      ]
    },
    resolve: {
      modules: [path.resolve('./node_modules'), path.resolve('./src')],
      extensions: ['.json', '.js']
    },
    plugins: plugins
  }
}