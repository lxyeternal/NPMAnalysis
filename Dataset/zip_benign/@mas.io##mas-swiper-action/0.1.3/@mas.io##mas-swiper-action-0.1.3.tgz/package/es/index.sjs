function getActionStyle(item){
    const map = {
        "delete": "background-color:#ff3b30;color:#fff",
        edit: "background-color:#ccc;color:#fff",
        other: "background-color:#1677FF;color:#fff"
    }
    if(item.style){
        return item.style;
    }
    return map[item.type] || map.other;
}
function getContentStyle(showAction,duration,actionWidth,useTransition,diffX,transitionDuration){
    if(useTransition){
        let result = `transition-duration:${duration/1000}s;`;
        if(showAction){
            result += `transform:translateX(-${actionWidth}px);`;
        }else{
        }
        return result;
    }else{
        let result=`transform:translateX(-${diffX}px);`;
        if(transitionDuration>0){
            result += `transition-duration:${transitionDuration/1000}s`;
        }
        return result;
    }

}
function getActionsStyle(showAction,duration,actionWidth,useTransition,diffX,transitionDuration){
    if(useTransition){
        let result = `transition-duration:${duration/1000}s;`;
        if(actionWidth>0){
            result += `right:-${actionWidth}px;`
        }
        if(showAction){
            result += `transform:translateX(-${actionWidth}px);`;
        }
        return result;
    }else{
        let result = `transform:translateX(-${diffX}px);`;
        if(actionWidth>0){
            result += `right:-${actionWidth}px;`
        }
        if(transitionDuration>0){
            result += `transition-duration:${transitionDuration/1000}s`;
        }
        return result;
    }

}
export default { getActionStyle, getContentStyle,getActionsStyle  };