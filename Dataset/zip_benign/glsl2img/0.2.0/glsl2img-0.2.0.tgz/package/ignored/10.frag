#ifdef GL_ES
precision mediump float;
#endif
#extension GL_OES_standard_derivatives : enable

uniform float time;
uniform vec2 mouse;
uniform vec2 resolution;

float metaball (in vec2 position, in float t) {
    float d = pow(sin(t * 2.),  3.) * 0.5;
    float dist1 = pow(max(1.0 - distance(position, vec2(0.5 + d, 0.5)) * 3.0, 0.0), 2.0);
    float dist2 = pow(max(1.0 - distance(position, vec2(0.5 - d, 0.5)) * 3.0, 0.0), 2.0);
    float dist3 = pow(max(1.0 - distance(position, vec2(-0.5 + d, 0.5)) * 3.0, 0.0), 2.0);
    float dist4 = pow(max(1.0 - distance(position, vec2(-0.5 - d, 0.5)) * 3.0, 0.0), 2.0);
    float dist5 = pow(max(1.0 - distance(position, vec2(1.5 + d, 0.5)) * 3.0, 0.0), 2.0);
    float dist6 = pow(max(1.0 - distance(position, vec2(1.5 - d, 0.5)) * 3.0, 0.0), 2.0);
    return smoothstep(0.1, 0.101, dist1 + dist2 + dist3 + dist4 + dist5 + dist6);
}

void main (void) {
    vec2 position = gl_FragCoord.xy / resolution.xy;
    vec2 pos = fract(position * 4.);

    float step = floor(position.y * 4.);
    float t = time + step;

    float g = metaball(pos + vec2(cos(time * 1.5), sin(time * 2.5)) * 0.03, t);
    float r = metaball(pos + vec2(cos(time * 3.), sin(time * 8.)) * 0.03, t);
    float b = metaball(pos + vec2(sin(time * 3.), cos(time * 4.) + step * 0.03) * 0.03, t);
    gl_FragColor = vec4(r, g, b, 1.0);
}
