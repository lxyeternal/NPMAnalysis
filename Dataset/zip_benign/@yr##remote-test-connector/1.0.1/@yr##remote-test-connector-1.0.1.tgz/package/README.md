# remote-test-connector

Run [Mocha](https://github.com/mochajs/mocha)/[Expect](https://github.com/Automattic/expect.js) unit tests remotely through SauceLabs and/or BrowserStack.

## Usage

First, add the dependencies and script hooks to your package.json:

```javascript
"devDependencies": {
  "@yr/remote-test-connector": "*"
  "expect.js": "~0.3",
  "mocha": "*",
  ...
},
"scripts": {
  "test-saucelabs": "./node_modules/@yr/remote-test-connector/bin/remote-test-connector saucelabs; true",
  "test-browserstack": "./node_modules/@yr/remote-test-connector/bin/remote-test-connector browserstack; true"
  ...
},
```

Then:
* Place the code that you want to test in test/lib.js (or a symblink to it).
* Place the unit tests in test/lib-test.js.
