# Changelog

All notable changes to NVL will be documented in this file. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.3.8] - 2025-03-18

This release contains a fix for the [NVL result transformer](https://neo4j.com/docs/api/nvl/current/functions/_neo4j_nvl_base.nvlResultTransformer.html).

### Fixed

* NVL result transformer to be able to handle deeply nested records

## [0.3.7] - 2025-02-28

### Added

* Export zoom functionalities as a named function
* Add a `positions` prop to the react wrapper
* Color custimzation options
* Aria attributes for NVL canvas and option to disable them
* Option to disable web workers

### Changed

* Change default threshold when relationship captions are displayed
* update default selection color and default node color to be aligned with the Neo4j Design Library

### Deprecated

* `selectedBorderColor` - use `styling.selectedBorderColor` instead
* `nodeDefaultBorderColor` - use `styling.nodeDefaultBorderColor` instead

### Fixed

* Fix icon colors not being inverted for dark node colors
* fix bug where selected border color was not processed if a default border color was not provided in options
* Address several warnings during initialization
* Address multi-select callback inconsistencies
* Canvas renderer performance improvements
* ensure properties provided via `nvlOptions` are also updated on prop change in React wrappers

## [0.3.6] - 2025-02-21

NVL 0.3.6 improves the API docs and adds a result transformer for the Neo4j JavaScript Driver, as well as small improvements and bug fixes.

### Added

- [result transformer for the Neo4j JavaScript Driver](https://neo4j.com/docs/api/nvl/current/functions/_neo4j_nvl_base.nvlResultTransformer.html)
- [option](https://neo4j.com/docs/api/nvl/current/types/_neo4j_nvl_base.ZoomOptions.html) to disable transition when fitting nodes

### Fixed

- lasso handler issues during initialization

## [0.3.5] - 2025-02-20

NVL 0.3.5 contains several bug fixes and changes the default rendering method of NVL from "webgl" to "canvas".

### Changed

- Change default value for renderer to canvas

### Fixed

- Self-referring relationship overlay icon rotation position issue
- Invalid lasso area calculation when segment from first to last point intersects

## [0.3.4] - 2025-02-19

With this release, we are updating our docs and READMEs and publishing NVL's API documentation and examples on neo4j.com/docs/api/nvl/current.

### Added

- NVL's API documentation and examples on [neo4j.com/docs/api/nvl/current](http://neo4j.com/docs/api/nvl/current).
- A fallback implementation for web workers when they aren't avilable in the current environment.
- A new onDrawStarted callback for the [draw interaction handler](https://neo4j.com/docs/api/nvl/current/classes/_neo4j_nvl_interaction_handlers.DrawInteraction.html)

### Fixed

- Issues with lasso shape when parts of it are close to each other
- NVL crash when sometimes position map and nodeToBundle are out of sync

## [0.3.3] - 2025-02-18

This is a patch release to address a dependency issue in 0.3.2

### Fixed

- Move Segment dependency from dev dependencies
- Ensure workspace version references point to exact version

## [0.3.2] - 2025-02-17

This is our first patch release since going GA in May.

### Added

- [Telemetry](https://neo4j.com/docs/api/nvl/current/interfaces/_neo4j_nvl_base.NvlOptions.html#disableTelemetry)
- [Examples](https://neo4j.com/docs/api/nvl/current/examples.html) in API documentation
- More information in package.json files
- Overlay icons for nodes and relationships
- Links to documentation websites in readme

### Fixed

- Fixed zoom to fit for self relationships
- Aalign selected border color
- Issues with WebGL error propagation
- Issue with key captures on mouse click in draw-interactions
- Zoom to fit finishing too early
- Improve imagecache error handling
- Minimap viewport box not rendering

## [0.3.1] - 2025-02-16

This is our first GA release of NVL.

### Added

- Expose callback types through interactive react wrapper
- Feature/adv interaction fw drag callbacks amendments
- Add [lasso select interaction module](https://neo4j.com/docs/api/nvl/current/classes/_neo4j_nvl_interaction_handlers.LassoInteraction.html)
- Configurable node ring styles
- Support React concurrent mode in React wrappers
- [`renderer`](https://neo4j.com/docs/api/nvl/current/interfaces/_neo4j_nvl_base.NvlOptions.html#renderer) and [`setRenderer`](https://neo4j.com/docs/api/nvl/current/classes/_neo4j_nvl_base.NVL.html#setRenderer) API option and method

### Deprecated

- `useWebGL` and `setUseWebGL` (use `renderer` and `setRenderer` instead).

### Changed

- Core library is now named "base" library
- All packages are published publicly
- Refactor rel validation method to improve performance
- Convert layout web workers to shared workers
- Don't check for WebGL availability if WebGL is disabled by NVL [`disableWebGL`](https://neo4j.com/docs/api/nvl/current/interfaces/_neo4j_nvl_base.NvlOptions.html#disableWebGL) option

### Removed

- Remove deprecated elements

### Fixed

- Wrong directions in a relationship bundle
- Issues with node and relationship id handling when strings are not numeric
- Zoom/pan jitter removal
- Ensure all interaction handlers return mouse events
- Cytoscape behaviour fixes
- Drag triggers too early
- Fix issue where right clicking sometime also triggers mouseup event
- Issues in dynamic zoom boundaries
- Don't trigger panning when mouse down was outside of NVL
- Only register callbacks if provided
- Ensure fit operation does not keep going on when zoom limit is reached
- Only update hover effect of elements when graph is not empty
- Ensure zoom to fit continues if panning has not finished yet
- Improve html overlay scaling
- Ensure Webgl context is released when NVL instance is destroyed
- Emoji in captions not rendering correctly
