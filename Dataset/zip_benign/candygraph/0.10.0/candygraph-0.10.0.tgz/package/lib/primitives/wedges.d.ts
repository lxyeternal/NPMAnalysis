import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface WedgesOptions {
    /** The interior color of the wedges. If this value is a single Vector4, it will apply to all the wedges. Default [0, 0, 0, 0.5]. */
    colors?: NumberArray | Dataset;
    /** The radius of the wedges in pixels. If this value is a single number, it will apply to all the wedges. Default 10. */
    radii?: number | NumberArray | Dataset;
}
/**
 * Useful for pie charts.
 */
export declare class Wedges extends Primitive {
    private cg;
    readonly xys: Dataset;
    readonly angles: Dataset;
    readonly colors: Dataset;
    readonly radii: Dataset;
    private positionBuffer;
    /**
     * @param xys The x, y coordinates of the wedge point in the form `[x0, y0, x1, y1, ...]`.
     * @param angles The angle and arclength of each wedge in the form `[angle0, arclength0, angle1, arclength1, ...]`.
     */
    constructor(cg: CandyGraph, xys: NumberArray | Dataset, angles: NumberArray | Dataset, options?: WedgesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
