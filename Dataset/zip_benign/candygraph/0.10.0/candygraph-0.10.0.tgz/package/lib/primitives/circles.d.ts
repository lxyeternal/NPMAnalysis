import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface CirclesOptions {
    /** The interior color of the circles. If this value is a single Vector4, it will apply to all the circles. Default [0, 0, 0, 0.5]. */
    colors?: NumberArray | Dataset;
    /** The radius of the circles (including border) in pixels. If this value is a single number, it will apply to all the circles. Default 10. */
    radii?: number | NumberArray | Dataset;
    /** The color of the borders. If this value is a single Vector4, it will apply to all the circles. Default [0, 0, 0, 1]. */
    borderColors?: NumberArray | Dataset;
    /** The width of the borders in pixels. If this value is a single number, it will apply to all the borders. Default 3. */
    borderWidths?: number | NumberArray | Dataset;
}
export declare class Circles extends Primitive {
    private cg;
    readonly xs: Dataset;
    readonly ys: Dataset;
    readonly colors: Dataset;
    readonly radii: Dataset;
    readonly borderWidths: Dataset;
    readonly borderColors: Dataset;
    private positionBuffer;
    /**
     *
     * @param cg
     * @param xs The x coordinates of the circle centers in the form `[x0, x1, ...]`.
     * @param ys The y coordinates of the circle centers in the form `[y0, y1, ...]`.
     * @param options
     */
    constructor(cg: CandyGraph, xs: NumberArray | Dataset, ys: NumberArray | Dataset, options?: CirclesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
