import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface VLinesOptions {
    /** The width of the lines in pixels. If this value is a single number, it will apply to all the lines. Default 1. */
    widths?: number | NumberArray | Dataset;
    /** The color of the lines. If this value is a single Vector4, it will apply to all the lines. Default [0, 0, 0, 1] */
    colors?: NumberArray | Dataset;
}
/**
 * Renders clean vertical lines. Line widths are rounded to the nearest pixel
 * (with a minimum of 1) so that the lines never appear blurry. This is useful
 * when rendering items like orthographic axes; without this approach, axis
 * lines or tick marks can consume different numbers of pixels and result in an
 * inconsistent appearance.
 */
export declare class VLines extends Primitive {
    private cg;
    readonly lines: Dataset;
    readonly widths: Dataset;
    readonly colors: Dataset;
    private segmentGeometry;
    /**
     * @param lines The line positions in the form `[x0, y0_0, y0_1, x1, y1_0,
     * y1_1, ...]` where each line is defined by three numbers.
     */
    constructor(cg: CandyGraph, lines: NumberArray | Dataset, options?: VLinesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
