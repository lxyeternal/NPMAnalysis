import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface OpaqueLineStripOptions {
    /** The width of the line strip segments. If this parameter is a single
     * number, it will apply to all segments. Default 1. */
    widths?: number | NumberArray | Dataset;
    /** The color of the line strip segments. If this parameter is a single
     * Vector3, it will apply to all segments. Default [0, 0, 0]. */
    colors?: NumberArray | Dataset;
}
export declare class OpaqueLineStrip extends Primitive {
    private cg;
    readonly xs: Dataset;
    readonly ys: Dataset;
    readonly widths: Dataset;
    readonly colors: Dataset;
    private roundCapJoin;
    /**
     * @param xs An array of points in the format `[x0, x1, ...]` that represent
     * the x-coordinates of the line strip to be rendered.
     * @param ys An array of points in the format `[y0, y1, ...]` that represent
     * the y-coordinates of the line strip to be rendered.
     */
    constructor(cg: CandyGraph, xs: NumberArray | Dataset, ys: NumberArray | Dataset, options?: OpaqueLineStripOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
