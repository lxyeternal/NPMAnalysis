import { DrawCommand } from "regl";
export declare type NamedDrawCommands = Record<string, DrawCommand>;
export declare abstract class Primitive {
    /** @internal */
    abstract commands(glsl: string): NamedDrawCommands;
    /** @internal */
    abstract render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    abstract dispose(): void;
}
