import { CandyGraph } from "../candygraph";
import { Vector2, Vector4 } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Font } from "../assets/font";
export interface TextOptions {
    /** A value between -1 and 1 that represents the alignment of multiple lines
     * of text. -1 is aligned fully to the left, 1 is aligned fully to the right,
     * and 0 is centered. Default 0. */
    align?: number;
    /** The x/y position of the anchor relative to the text quad, on the range
     * [-1, -1] (bottom left) to [1, 1] (top right). Default [0, 0]. */
    anchor?: Vector2;
    /** The angle at which the text will be rotated around the anchor. Default 0. */
    angle?: number;
    /** The color of the text. Default [0, 0, 0, 1]. */
    color?: Vector4;
    /** The size of the text. Default 12. */
    size?: number;
}
export declare class Text extends Primitive {
    private cg;
    private font;
    position: Vector2;
    size: number;
    angle: number;
    color: Vector4;
    readonly width: number;
    readonly height: number;
    private quad;
    private uv;
    private instances;
    private quadGeometry;
    constructor(cg: CandyGraph, font: Font, text: string, position: Vector2, options?: TextOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
