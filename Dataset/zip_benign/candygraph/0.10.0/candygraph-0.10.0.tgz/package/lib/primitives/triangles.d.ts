import { CandyGraph } from "../candygraph";
import { NumberArray, Vector4 } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface TrianglesOptions {
    /** The color of the triangles. Default [0, 0, 0, 0.5]. */
    color?: Vector4;
}
export declare class Triangles extends Primitive {
    private cg;
    private vertices;
    color: Vector4;
    /**
     * @param vertices Set of 2D points in the form `[x0, y0, x1, y1, ...]` that
     * describe the (unindexed) set of triangles to render.
     */
    constructor(cg: CandyGraph, vertices: NumberArray | Dataset, options?: TrianglesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
