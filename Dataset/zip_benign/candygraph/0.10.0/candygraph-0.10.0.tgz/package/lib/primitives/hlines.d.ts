import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface HLinesOptions {
    widths?: number | NumberArray | Dataset;
    colors?: NumberArray | Dataset;
}
/**
 * Renders clean horizontal lines. Line widths are rounded to the nearest pixel
 * (with a minimum of 1) so that the lines never appear blurry. This is useful
 * when rendering items like orthographic axes; without this approach, axis
 * lines or tick marks can consume different numbers of pixels and result in an
 * inconsistent appearance.
 */
export declare class HLines extends Primitive {
    private cg;
    readonly lines: Dataset;
    readonly widths: Dataset;
    readonly colors: Dataset;
    private segmentGeometry;
    /**
     * @param lines The line positions in the form `[x0_0, x0_1, y0, x1_0, x1_1,
     * y1, ...]` where each line is defined by three numbers.
     */
    constructor(cg: CandyGraph, lines: NumberArray | Dataset, options?: HLinesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
