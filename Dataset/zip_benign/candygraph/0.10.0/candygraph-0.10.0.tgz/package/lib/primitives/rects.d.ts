import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface RectsOptions {
    /** The color of the rectangles. If this value is a single Vector4, it will apply to all the rectangles. Default [0, 0, 0, 0.5]. */
    colors?: NumberArray | Dataset;
}
export declare class Rects extends Primitive {
    private cg;
    readonly rects: Dataset;
    readonly colors: Dataset;
    private positionBuffer;
    /**
     * @param rects The x, y position of the lower-left corner of the rectangle
     * and its width and height in the form `[x0, y0, w0, h0, x1, y1, w1, h1, ...]`.
     */
    constructor(cg: CandyGraph, rects: NumberArray | Dataset, options?: RectsOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
