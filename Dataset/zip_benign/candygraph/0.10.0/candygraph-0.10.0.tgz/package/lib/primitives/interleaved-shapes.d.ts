import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface InterleavedShapesOptions {
    /** The color of the shapes. If this value is a single Vector4, it will apply to all the shapes. Default [0, 0, 0, 0.5]. */
    colors?: NumberArray | Dataset;
    /** The scale of the shapes. If this value is a single Vector2, it will apply to all the shapes. Default [1, 1]. */
    scales?: NumberArray | Dataset;
    /** The rotation of the shapes in radians. If this value is a single float, it will apply to all the shapes. Default 0. */
    rotations?: number | NumberArray | Dataset;
}
/** Renders colored shapes. Useful for custom trace points. */
export declare class InterleavedShapes extends Primitive {
    private cg;
    shape: Dataset;
    xys: Dataset;
    scales: Dataset;
    rotations: Dataset;
    colors: Dataset;
    /**
     * @param shape Set of 2D points in the form `[x0, y0, x1, y1, ...]` that describe the (unindexed) set of triangles representing the shape to render.
     * @param xys The x, y coordinates of the shape positions in the form `[x0, y0, x1, y1, ...]`.
     */
    constructor(cg: CandyGraph, shape: NumberArray | Dataset, xys: NumberArray | Dataset, options?: InterleavedShapesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
