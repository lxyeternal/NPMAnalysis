import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface LineSegmentsOptions {
    /** The width of the line segments in pixels. If this parameter is a single
     * number, it will apply to all line segments. Default 1. */
    widths?: number | NumberArray | Dataset;
    /** The color of the line segments. If this parameter is a single Vector4, it
     * will apply to all line segments. Default [0, 0, 0, 1]. */
    colors?: NumberArray | Dataset;
}
export declare class LineSegments extends Primitive {
    private cg;
    readonly points: Dataset;
    readonly widths: Dataset;
    readonly colors: Dataset;
    private segmentGeometry;
    /**
     * @param points An array of points in the format `[x0, y0, x1, y1, ...]` that
     * represent the endpoints of the line segments to be rendered.
     */
    constructor(cg: CandyGraph, points: NumberArray | Dataset, options?: LineSegmentsOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
