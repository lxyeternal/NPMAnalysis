import { CandyGraph } from "../candygraph";
import { NumberArray, Vector4 } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface TransparentLineStripOptions {
    /** The width of the line strip. Default 1. */
    width?: number;
    /** The color of the line strip. Default [0, 0, 0, 1]. */
    color?: Vector4;
}
/**
 * Similar to LineStrip, but without the alpha overlap artifacts. Uses six times
 * as many draw calls as LineStrip, so can be slower if you're CPU bound. Unlike
 * LineStrip, per-vertex color and width is not supported; the color and width
 * is constant for each TransparentLineStrip.
 */
export declare class TransparentLineStrip extends Primitive {
    private cg;
    readonly xs: Dataset;
    readonly ys: Dataset;
    width: number;
    color: Vector4;
    private segmentPositions;
    private segmentCells;
    private joinIds;
    private joinCells;
    private capPositions;
    private capCells;
    /**
     * @param xs An array of points in the format `[x0, x1, ...]` that represent
     * the x-coordinates of the line strip to be rendered.
     * @param ys An array of points in the format `[y0, y1, ...]` that represent
     * the y-coordinates of the line strip to be rendered.
     */
    constructor(cg: CandyGraph, xs: NumberArray | Dataset, ys: NumberArray | Dataset, options?: TransparentLineStripOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
