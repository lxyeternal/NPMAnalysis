import { CandyGraph } from "../candygraph";
import { NumberArray } from "../common";
import { Primitive, NamedDrawCommands } from "./primitive";
import { Dataset } from "../dataset";
export interface InterleavedCirclesOptions {
    /** The interior color of the circles. If this value is a single Vector4, it will apply to all the circles. Default [0, 0, 0, 0.5]. */
    colors?: NumberArray | Dataset;
    /** The color of the borders. If this value is a single Vector4, it will apply to all the circles. Default [0, 0, 0, 1]. */
    borderColors?: NumberArray | Dataset;
    /** The radius of the circles (including border) in pixels. If this value is a single number, it will apply to all the circles. Default 10. */
    radii?: number | NumberArray | Dataset;
    /** The width of the borders in pixels. If this value is a single number, it will apply to all the borders. Default 3. */
    borderWidths?: number | NumberArray | Dataset;
}
/** Colored circles with optional borders. */
export declare class InterleavedCircles extends Primitive {
    private cg;
    readonly xys: Dataset;
    readonly colors: Dataset;
    readonly radii: Dataset;
    readonly borderWidths: Dataset;
    readonly borderColors: Dataset;
    private positionBuffer;
    /**
     * @param xys The x and y coordinates of the circle centers in the form `[x0, y0, x1, y1, ...]`.
     */
    constructor(cg: CandyGraph, xys: NumberArray | Dataset, options?: InterleavedCirclesOptions);
    /** @internal */
    commands(glsl: string): NamedDrawCommands;
    /** @internal */
    render(commands: NamedDrawCommands): void;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
}
