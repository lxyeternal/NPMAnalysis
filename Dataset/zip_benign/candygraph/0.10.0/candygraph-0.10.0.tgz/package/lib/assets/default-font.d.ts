import { CandyGraph } from "../candygraph";
import { Font } from "./font";
export declare function createDefaultFont(cg: CandyGraph): Promise<Font>;
