import { Texture } from "regl";
import { CandyGraph } from "../candygraph";
import { Vector2 } from "../common";
interface Glyph {
    id: number;
    xoffset: number;
    yoffset: number;
    width: number;
    height: number;
    xadvance: number;
    uv: Vector2;
}
/**
 * A `Font` is used in conjunction with the `Text` primitive to render text, such as axis labels.
 *
 * Font image and data files can be generated with `msdf-bmfont`:
 * ```sh
 * $ npm i -g msdf-bmfont-xml
 * $ msdf-bmfont -f json -s 24 -t sdf --smart-size Lato-Regular.ttf
 * ```
 */
export declare class Font {
    /** @internal */
    readonly texture: Texture;
    /** @internal */
    readonly lineHeight: number;
    /** @internal */
    readonly glyphs: Glyph[];
    private readonly kernTable;
    private readonly maxid;
    /**
     *
     * @param cg
     * @param image The image produced by msdf-bmfont.
     * @param json The json object produced by msdf-bmfont.
     */
    constructor(cg: CandyGraph, image: HTMLImageElement, json: any);
    /** @internal */
    kern(first: number, second: number): number;
    /** Release all GPU resources and render this Font instance unusable. */
    dispose(): void;
}
export {};
