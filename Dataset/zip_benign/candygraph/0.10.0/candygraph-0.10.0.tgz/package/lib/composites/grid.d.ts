import { CandyGraph } from "../candygraph";
import { Renderable, Vector4, Vector2, NumberArray } from "../common";
import { Composite } from "./composite";
export interface GridOptions {
    /** The width of the grid lines in pixels. Default 1. */
    width?: number;
    /** The color of the grid lines. Default [0.75, 0.75, 0.75, 1.0] */
    color?: Vector4;
}
/**
 * Renders a grid of HLines and VLines.
 */
export declare class Grid extends Composite {
    private grid;
    /**
     *
     * @param xPositions The x-coordinates of all the vertical lines of the grid in the format `[x0, x1, ...]`.
     * @param yPositions The y-coordinates of all the horizontal lines of the grid in the format `[y0, y1, ...]`.
     * @param xExtents The start and end points of all the horizontal lines of the grid.
     * @param yExtents The start and end points of all the vertical lines of the grid.
     */
    constructor(cg: CandyGraph, xPositions: NumberArray, yPositions: NumberArray, xExtents: Vector2, yExtents: Vector2, options?: GridOptions);
    /** @internal */
    children(): Renderable;
}
