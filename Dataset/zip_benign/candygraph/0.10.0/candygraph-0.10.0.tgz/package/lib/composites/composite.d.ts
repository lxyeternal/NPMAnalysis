import { DrawCommand } from "regl";
import { Renderable } from "../common";
import { CoordinateSystem } from "../coordinates/coordinate-system";
export declare abstract class Composite {
    /** @internal */
    abstract children(): Renderable;
    /** @internal */
    readonly scope: DrawCommand | null;
    /** @internal */
    props(coords: CoordinateSystem): {};
    /** Releases all GPU resources and renders this instance unusable. Also disposes any children. */
    dispose(): void;
}
