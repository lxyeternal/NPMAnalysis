import { CandyGraph } from "../candygraph";
import { Renderable, NumberArray } from "../common";
import { Composite } from "./composite";
import { CartesianCoordinateSystem } from "../coordinates/cartesian";
import { AxisOptions } from "./axis";
import { Font } from "../assets/font";
export interface OrthoAxisOptions extends AxisOptions {
    /** The maximum value encompassed by this axis. */
    axisHigh?: number;
    /** The position on the opposing axis that this axis intercepts. */
    axisIntercept?: number;
    /** The minimum value encompassed by this axis. */
    axisLow?: number;
    /** The function to use to format the ticks. Default `(n: number) => n.toString()`. */
    labelFormatter?: (n: number) => string;
    /** The number of minor ticks between major ticks. None if undefined. Default undefined. */
    minorTickCount?: number;
    /** Used to anchor ticks to the axis. Using a value of 0.1 and a tickStep of
     * 1.0 will result in ticks at `[... -1.9, -0.9, 0.1, 1.1 ... ]`. Default 0.*/
    tickOrigin?: number;
    /** The distance between ticks. Default 1. */
    tickStep?: number;
}
export interface OrthoAxisComputed {
    /** The position of the major ticks of this axis. */
    ticks: NumberArray;
    /** The position of the minor ticks of this axis. */
    minorTicks: NumberArray;
}
export declare class OrthoAxis extends Composite {
    readonly computed: OrthoAxisComputed;
    private axis;
    constructor(cg: CandyGraph, coords: CartesianCoordinateSystem, axis: "x" | "y", font: Font, options?: OrthoAxisOptions);
    /** @internal */
    children(): Renderable;
}
