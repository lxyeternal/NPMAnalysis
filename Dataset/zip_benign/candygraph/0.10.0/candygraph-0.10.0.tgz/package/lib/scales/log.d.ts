import { Scale, Kind } from "./scale";
import { Vector2 } from "../common";
export declare class LogScale extends Scale {
    readonly base: number;
    /** @internal */
    readonly kind = Kind.Log;
    /** @internal */
    readonly glsl: string;
    private _domain;
    private _range;
    private conversion;
    constructor(base: number, domain: Vector2, range: Vector2);
    get domain(): Vector2;
    set domain(v: Vector2);
    get range(): Vector2;
    set range(v: Vector2);
    toRange(value: number): number;
    toDomain(value: number): number;
}
