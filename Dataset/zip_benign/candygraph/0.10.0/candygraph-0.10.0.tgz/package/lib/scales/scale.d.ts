import { Vector2 } from "../common";
export declare enum Kind {
    Linear = 0,
    Log = 1
}
export declare abstract class Scale {
    /** @internal */
    abstract readonly kind: Kind;
    /** @internal */
    abstract readonly glsl: string;
    abstract get domain(): Vector2;
    abstract set domain(v: Vector2);
    abstract get range(): Vector2;
    abstract set range(v: Vector2);
    abstract toDomain(rangeValue: number): number;
    abstract toRange(domainValue: number): number;
}
