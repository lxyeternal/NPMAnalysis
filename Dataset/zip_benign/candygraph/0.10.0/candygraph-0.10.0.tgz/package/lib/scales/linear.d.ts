import { Scale, Kind } from "./scale";
import { Vector2 } from "../common";
export declare class LinearScale extends Scale {
    /** @internal */
    readonly kind = Kind.Linear;
    /** @internal */
    readonly glsl = "\n    float toDomain(float v, vec2 domain, vec2 range) {\n      float qDomain = (domain.y - domain.x) / (range.y - range.x);\n      return domain.x + qDomain * (v - range.x);\n    }\n\n    float toRange(float v, vec2 domain, vec2 range) {\n      float qRange = (range.y - range.x) / (domain.y - domain.x);\n      return range.x + qRange * (v - domain.x);\n    }\n  ";
    private _domain;
    private _range;
    private qDomain;
    private qRange;
    constructor(domain: Vector2, range: Vector2);
    get domain(): Vector2;
    set domain(v: Vector2);
    get range(): Vector2;
    set range(v: Vector2);
    toDomain(v: number): number;
    toRange(v: number): number;
    private updateQ;
}
