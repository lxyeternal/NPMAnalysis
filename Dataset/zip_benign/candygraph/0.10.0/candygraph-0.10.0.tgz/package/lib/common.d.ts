import { Primitive } from "./primitives/primitive";
import { Composite } from "./composites/composite";
export interface Viewport {
    x: number;
    y: number;
    width: number;
    height: number;
}
export declare type Renderable = Primitive | Composite | Renderable[];
export declare type NumberArray = number[] | Float32Array;
export declare type Vector2 = number[] | Float32Array;
export declare type Vector3 = number[] | Float32Array;
export declare type Vector4 = number[] | Float32Array;
