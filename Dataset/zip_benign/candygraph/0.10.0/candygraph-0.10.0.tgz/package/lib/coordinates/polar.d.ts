import { DrawCommand } from "regl";
import { Vector2 } from "../common";
import { CoordinateSystem, Kind } from "./coordinate-system";
import { LinearScale } from "../scales/linear";
import { LogScale } from "../scales/log";
import { CandyGraph } from "../candygraph";
interface Props {
    radialDomain: Vector2;
    radialRange: Vector2;
    angularDomain: Vector2;
    angularRange: Vector2;
    xDomain: Vector2;
    xRange: Vector2;
    yDomain: Vector2;
    yRange: Vector2;
}
export declare class PolarCoordinateSystem extends CoordinateSystem {
    readonly radialScale: LinearScale | LogScale;
    readonly angularScale: LinearScale | LogScale;
    readonly xScale: LinearScale | LogScale;
    readonly yScale: LinearScale | LogScale;
    /** @internal */
    readonly glsl: string;
    /** @internal */
    readonly kind = Kind.Polar;
    /** @internal */
    readonly scope: DrawCommand;
    constructor(cg: CandyGraph, radialScale: LinearScale | LogScale, angularScale: LinearScale | LogScale, xScale: LinearScale | LogScale, yScale: LinearScale | LogScale);
    toRange(v: Vector2): Vector2;
    toDomain(v: Vector2): Vector2;
    /** @internal */
    props(): Props;
}
export {};
