import { DrawCommand } from "regl";
import { Vector2 } from "../common";
import { CoordinateSystem, Kind } from "./coordinate-system";
import { LinearScale } from "../scales/linear";
import { LogScale } from "../scales/log";
import { CandyGraph } from "../candygraph";
interface Props {
    xdomain: Vector2;
    ydomain: Vector2;
    xrange: Vector2;
    yrange: Vector2;
}
export declare class CartesianCoordinateSystem extends CoordinateSystem {
    readonly xscale: LinearScale | LogScale;
    readonly yscale: LinearScale | LogScale;
    /** @internal */
    readonly glsl: string;
    /** @internal */
    readonly kind = Kind.Cartesian;
    /** @internal */
    readonly scope: DrawCommand;
    constructor(cg: CandyGraph, xscale: LinearScale | LogScale, yscale: LinearScale | LogScale);
    toRange(v: Vector2): Vector2;
    toDomain(v: Vector2): Vector2;
    /** @internal */
    props(): Props;
}
export {};
