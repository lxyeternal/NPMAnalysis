import { DrawCommand } from "regl";
import { Vector2 } from "../common";
export declare enum Kind {
    Cartesian = 0,
    Polar = 1
}
export declare abstract class CoordinateSystem {
    /** @internal */
    abstract readonly kind: Kind;
    /** @internal */
    abstract readonly glsl: string;
    /** @internal */
    abstract readonly scope: DrawCommand;
    /** @internal */
    abstract props(): Record<string, any>;
    abstract toDomain(rangeVector: Vector2): Vector2;
    abstract toRange(domainVector: Vector2): Vector2;
}
