import { Regl } from "regl";
import { CoordinateSystem } from "./coordinates/coordinate-system";
import { Viewport, Renderable } from "./common";
export interface CandyGraphOptions {
    /** The canvas element the webgl context will be created from. One will be created if not provided. */
    canvas?: HTMLCanvasElement;
    /** Indicates if the canvas contains an alpha buffer. Enable this if you would like to composite your graph with DOM elements. */
    alpha?: boolean;
}
export declare class CandyGraph {
    /** @internal */
    readonly regl: Regl;
    readonly canvas: HTMLCanvasElement;
    private commandsByCoords;
    private scope;
    constructor(options?: CandyGraphOptions);
    /** Clears the entire CandyGraph canvas.
     * @examples
     * Clear the canvas to solid white.
     * ```ts
     * cg.clear([1, 1, 1, 1]);
     * ```
     * Clear the canvas to blue.
     * ```ts
     * cg.clear([0, 0, 1, 1]);
     * ```
     * Clear the canvas to zero alpha for compositing with the page.
     * ```ts
     * const cg = new CandyGraph({ alpha: true });
     * cg.clear([0, 0, 0, 0]);
     * ```
     */
    clear: (color: [number, number, number, number]) => void;
    /** Renders the given Renderable(s) to the given Viewport with the provided CoordinateSystem.
     * @example
     * ```ts
     * // Create a viewport.
     * const viewport = { x: 0, y: 0, width: 384, height: 384 };
     *
     * // Create a coordinate system.
     * const coords = new CartesianCoordinateSystem(
     *   new LinearScale([0, 1], [32, viewport.width - 16]),
     *   new LinearScale([0, 1], [32, viewport.height - 16])
     * );
     *
     * // Render a line segment to the viewport.
     * cg.render(coords, viewport, new LineSegments(cg, [0, 0, 1, 1]));
     *
     * // Render a couple more line segments to the viewport.
     * cg.render(coords, viewport, [new LineSegments(cg, [0.5, 0, 0.5, 1]), new LineSegments(cg, [0, 1, 1, 0])]);
     * ```
     */
    render: (coords: CoordinateSystem, viewport: Viewport, renderable: Renderable) => void;
    /** Destroys the underlying `regl` instance and renders this `CandyGraph` instance unusable. */
    destroy(): void;
    /** Copies the contents of the CandyGraph canvas to another canvas. Returns the HTMLCanvasElement that was copied to.
     * @param sourceViewport The `Viewport` of the `CandyGraph` canvas that will be copied from.
     * @param destinationCanvas The canvas that will be copied to. If not provided, one will be created with the dimensions of `destinationViewport`.
     * @param destinationViewport If not provided, one will be created that is positioned at [0, 0] and with the width and height of `sourceViewport`.
     */
    copyTo(sourceViewport: Viewport, destinationCanvas?: HTMLCanvasElement, destinationViewport?: Viewport): HTMLCanvasElement;
    private getNamedCommands;
    private recursiveRender;
}
