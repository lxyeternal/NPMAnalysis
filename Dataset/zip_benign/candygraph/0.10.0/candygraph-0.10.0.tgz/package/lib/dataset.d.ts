import { Buffer } from "regl";
import { CandyGraph } from "./candygraph";
export declare function createDataset(cg: CandyGraph, data: number | number[] | number[][] | Float32Array | Dataset): Dataset;
/**
 * `Datasets` are used to store and reference data on the GPU. This is useful
 * for making some operations more efficient, such as animation or switching
 * between `CoordinateSystems`.
 *
 * @example
 * ```ts
 * // Create a reusable DataSet.
 * const data = new Dataset(cg, [0, 0, 1, 1]);
 *
 * // Render a line segment to the viewport.
 * cg.render(coords, viewport, [
 *   new LineSegment(cg, data, {colors: [1, 0, 0, 1], widths: 4]}), // red, width 4
 *   new LineSegment(cg, data, {colors: [0, 0, 1, 1], widths: 1]}), // blue, width 1
 * ]);
 * ```
 */
export declare class Dataset {
    /** @internal */
    readonly buffer: Buffer;
    private length;
    private disposed;
    constructor(cg: CandyGraph, data: number | number[] | number[][] | Float32Array);
    /** Update this Dataset with new data, in-place. */
    update: (data: number | number[] | number[][] | Float32Array) => this;
    /** Releases all GPU resources and renders this instance unusable. */
    dispose(): void;
    /** @internal */
    count(size: number): number;
    /** @internal */
    divisor(instances: number, size: number): number;
    private assertFits;
}
