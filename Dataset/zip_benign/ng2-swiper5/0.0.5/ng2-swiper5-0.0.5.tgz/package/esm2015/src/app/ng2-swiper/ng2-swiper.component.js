import { Component, Input, Output, EventEmitter } from '@angular/core';
import Swiper from 'swiper';
export class Ng2SwiperComponent {
    constructor() {
        // slideChangeTransitionStart 回调方法
        this.slideChangeStart = new EventEmitter();
        /**
         * basic 设置项
         */
        this.initialSlide = 0; // 设定初始化时slide的索引
        this.speed = 300; // 切换速度
        this.grabCursor = false; // 设置为true时，鼠标覆盖Swiper时指针会变成手掌形状，拖动时指针会变成抓手形状。
        this.parallax = false; // 开启视差效果
        this.parallaxPer = '-23%'; // data-swiper-parallax接受两种类型的参数。
        // number（单位：px），如-300，从右边300px进入左边出去。
        // percentage（百分比），移动距离=该元素宽度 * percentage。
        this.parallaxOpacity = 0.5; // 视差透明度变化
        this.parallaxScale = 0.5; // 视差缩放变化
        this.parallaxDuration = 3000; // 设定视差动画持续时间（ms）
        this.autoHeight = false; // 高度随内容变化
        this.uniqueNavElements = false; // 控制组件放在container外面的时候，需要用到
        this.runCallbacksOnInit = true; // 触发回调，如果不想触发，将此设置为false
        /**
         * Slides grid(网格分布)
         */
        this.centeredSlides = false; // 设定为true时，active slide会居中，而不是默认状态下的居左
        this.centeredSlidesBounds = false; // 当设置了Active Slide居中后，还可以配合设置此参数，使得第一个和最后一个Slide 始终贴合边缘。
        this.navigation = true; // 左右箭头切换开关
        this.slidesPerView = 1; // 设置slider容器能够同时显示的slides数量
        this.slidesPerGroup = 1; // 定义slides的数量多少为一组
        this.slidesPerGroupSkip = 0; // 设置跳过分组
        this.spaceBetween = 0; // 在slide之间设置距离（单位px）。
        this.slidesPerColumn = 1; // 设置多行布局里面每列的slide数量
        /**
         * Free Mode （free模式/抵抗反弹）
         */
        this.freeMode = false; // 设置为true则变为free模式 slide会根据惯性滑动可能不止一格且不会贴合
        this.freeModeMomentum = true; // free模式动量。free模式下，grabCursor需设置为false 若设置为false则关闭动量，释放slide之后立即停止不会滑动
        this.freeModeMomentumRatio = 1; // 设置的值越大，当释放slide时的滑动时间越长
        this.freeModeMomentumVelocityRatio = 1; // free模式惯性速度，设置越大，释放后滑得越快
        this.swiperCont = 'swiper-container'; // 设置swiper的id
        this.paginationShow = true; // 是否显示分页器
        this.isObserver = true; // 修改swiper自己或子元素时，自动初始化swiper
        this.autoplay = false; // 自动播放
        this.delay = 3; // 自动播放间隔时间(秒)
    }
    ngOnInit() {
    }
    // 自动播放判断
    setAutoplay() {
        if (this.autoplay == true) {
            this.autoplayObj = {
                disableOnInteraction: false,
                delay: this.delay * 1000,
            };
        }
        else {
            this.autoplayObj = this.autoplay;
        }
    }
    ;
    ngOnChanges(changes) {
        const that = this;
        // 轮播图
        setTimeout(() => {
            this.setAutoplay();
            that.swiperBox = new Swiper('#' + this.swiperCont, {
                loop: false,
                /**
                 * basic 设置项
                 */
                initialSlide: this.initialSlide,
                direction: this.direction,
                speed: this.speed,
                grabCursor: this.grabCursor,
                parallax: this.parallax,
                autoHeight: this.autoHeight,
                /**
                 * Slides grid(网格分布)
                 */
                centeredSlides: this.centeredSlides,
                centeredSlidesBounds: this.centeredSlidesBounds,
                slidesPerView: this.slidesPerView,
                slidesPerGroup: this.slidesPerGroup,
                slidesPerGroupSkip: this.slidesPerGroupSkip,
                spaceBetween: this.spaceBetween,
                slidesPerColumn: this.slidesPerColumn,
                slidesPerColumnFill: this.slidesPerColumnFill,
                /**
                 *
                 */
                freeMode: this.freeMode,
                freeModeMomentum: this.freeModeMomentum,
                freeModeMomentumRatio: this.freeModeMomentumRatio,
                mousewheel: true,
                // dynamicBullets: true,
                // dynamicMainBullets: 2,
                observer: this.isObserver,
                observeParents: this.isObserver,
                autoplay: this.autoplayObj,
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
                // loop: true,
                // 如果需要分页器
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true
                },
                uniqueNavElements: this.uniqueNavElements,
                runCallbacksOnInit: true,
                on: {
                    slideChangeTransitionStart: () => {
                        this.slideChangeStart.emit();
                    },
                },
            });
        });
    }
}
Ng2SwiperComponent.decorators = [
    { type: Component, args: [{
                selector: 'ng2-swiper',
                template: "<div #swiper class=\"swiper-container\" [id]=\"swiperCont\">\n  <ng-container *ngIf=\"parallax == true\">\n    <div \n    [ngStyle]=\"{ 'background': 'url(' + parallaxImgUrl + ')' }\" \n    [attr.data-swiper-parallax]=\"parallaxPer\" \n    [attr.data-swiper-parallax-opacity]=\"parallaxOpacity\"\n    [attr.data-swiper-parallax-scale]=\"parallaxScale\"\n    [attr.data-swiper-parallax-duration]=\"parallaxDuration\"\n    ></div>\n  </ng-container>\n  <div class=\"swiper-wrapper\">\n      <ng-content select=\"[swiperSlide]\"></ng-content>\n  </div>\n  <div class=\"swiper-scrollbar\"></div>\n  <!-- \u5982\u679C\u9700\u8981\u5206\u9875\u5668 -->\n  <div class=\"swiper-pagination\" *ngIf=\"paginationShow == true\">\n  </div>\n  <!-- \u5982\u679C\u9700\u8981\u5BFC\u822A\u6309\u94AE -->\n  <ng-container *ngIf=\"navigation == true\">\n      <div class=\"swiper-button-prev\"></div>\n      <div class=\"swiper-button-next\"></div>\n  </ng-container>\n  \n  \n</div>",
                styles: [".swiper-container{height:100%;overflow:hidden;width:100%}.swiper-button-next:after,.swiper-button-prev:after{font-size:2rem!important}"]
            },] }
];
Ng2SwiperComponent.ctorParameters = () => [];
Ng2SwiperComponent.propDecorators = {
    slideChangeStart: [{ type: Output }],
    initialSlide: [{ type: Input }],
    direction: [{ type: Input }],
    speed: [{ type: Input }],
    grabCursor: [{ type: Input }],
    parallax: [{ type: Input }],
    parallaxImgUrl: [{ type: Input }],
    parallaxPer: [{ type: Input }],
    parallaxOpacity: [{ type: Input }],
    parallaxScale: [{ type: Input }],
    parallaxDuration: [{ type: Input }],
    autoHeight: [{ type: Input }],
    uniqueNavElements: [{ type: Input }],
    runCallbacksOnInit: [{ type: Input }],
    slidesPerColumnFill: [{ type: Input }],
    centeredSlides: [{ type: Input }],
    centeredSlidesBounds: [{ type: Input }],
    navigation: [{ type: Input }],
    slidesPerView: [{ type: Input }],
    slidesPerGroup: [{ type: Input }],
    slidesPerGroupSkip: [{ type: Input }],
    spaceBetween: [{ type: Input }],
    slidesPerColumn: [{ type: Input }],
    freeMode: [{ type: Input }],
    freeModeMomentum: [{ type: Input }],
    freeModeMomentumRatio: [{ type: Input }],
    freeModeMomentumVelocityRatio: [{ type: Input }],
    swiperCont: [{ type: Input }],
    paginationShow: [{ type: Input }],
    isObserver: [{ type: Input }],
    autoplay: [{ type: Input }],
    delay: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmcyLXN3aXBlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiLi4vLi4vIiwic291cmNlcyI6WyJzcmMvYXBwL25nMi1zd2lwZXIvbmcyLXN3aXBlci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBVSxLQUFLLEVBQTRCLE1BQU0sRUFBRSxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekcsT0FBTyxNQUFNLE1BQU0sUUFBUSxDQUFDO0FBTTVCLE1BQU0sT0FBTyxrQkFBa0I7SUFtRDdCO1FBbERBLGtDQUFrQztRQUNoQixxQkFBZ0IsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO1FBRTdEOztXQUVHO1FBQ00saUJBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7UUFFbkMsVUFBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE9BQU87UUFDcEIsZUFBVSxHQUFHLEtBQUssQ0FBQyxDQUFDLDhDQUE4QztRQUNsRSxhQUFRLEdBQUcsS0FBSyxDQUFDLENBQUMsU0FBUztRQUUzQixnQkFBVyxHQUFHLE1BQU0sQ0FBQyxDQUFDLGlDQUFpQztRQUNoRSxzQ0FBc0M7UUFDdEMsMkNBQTJDO1FBQ2xDLG9CQUFlLEdBQUcsR0FBRyxDQUFDLENBQUMsVUFBVTtRQUNqQyxrQkFBYSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFNBQVM7UUFDOUIscUJBQWdCLEdBQUcsSUFBSSxDQUFDLENBQUMsaUJBQWlCO1FBQzFDLGVBQVUsR0FBRyxLQUFLLENBQUMsQ0FBQyxVQUFVO1FBQzlCLHNCQUFpQixHQUFHLEtBQUssQ0FBQyxDQUFDLDRCQUE0QjtRQUN2RCx1QkFBa0IsR0FBRyxJQUFJLENBQUMsQ0FBQyx5QkFBeUI7UUFFN0Q7O1dBRUc7UUFDTSxtQkFBYyxHQUFHLEtBQUssQ0FBQyxDQUFDLHVDQUF1QztRQUMvRCx5QkFBb0IsR0FBRyxLQUFLLENBQUMsQ0FBQyx5REFBeUQ7UUFDdkYsZUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDLFdBQVc7UUFDOUIsa0JBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyw0QkFBNEI7UUFDL0MsbUJBQWMsR0FBRyxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7UUFDdkMsdUJBQWtCLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUztRQUNqQyxpQkFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLHNCQUFzQjtRQUN4QyxvQkFBZSxHQUFHLENBQUMsQ0FBQyxDQUFDLHFCQUFxQjtRQUNuRDs7V0FFRztRQUNNLGFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQywyQ0FBMkM7UUFDN0QscUJBQWdCLEdBQUcsSUFBSSxDQUFDLENBQUMsd0VBQXdFO1FBQ2pHLDBCQUFxQixHQUFHLENBQUMsQ0FBQyxDQUFDLDBCQUEwQjtRQUNyRCxrQ0FBNkIsR0FBRyxDQUFDLENBQUMsQ0FBQywwQkFBMEI7UUFFN0QsZUFBVSxHQUFHLGtCQUFrQixDQUFDLENBQUMsY0FBYztRQUMvQyxtQkFBYyxHQUFHLElBQUksQ0FBQyxDQUFDLFVBQVU7UUFDakMsZUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDLDhCQUE4QjtRQUVqRCxhQUFRLEdBQUcsS0FBSyxDQUFDLENBQUMsT0FBTztRQUN6QixVQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsY0FBYztJQUlsQixDQUFDO0lBR2pCLFFBQVE7SUFDUixDQUFDO0lBQ0QsU0FBUztJQUNULFdBQVc7UUFDVCxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxXQUFXLEdBQUc7Z0JBQ2pCLG9CQUFvQixFQUFFLEtBQUs7Z0JBQzNCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUk7YUFDekIsQ0FBQTtTQUNGO2FBQU07WUFDTCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7U0FDbEM7SUFDSCxDQUFDO0lBQUEsQ0FBQztJQUVGLFdBQVcsQ0FBQyxPQUFzQjtRQUNoQyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsTUFBTTtRQUNOLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDakQsSUFBSSxFQUFFLEtBQUs7Z0JBQ1g7O21CQUVHO2dCQUNILFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtnQkFDL0IsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dCQUN6QixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7Z0JBQ2pCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtnQkFDM0IsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO2dCQUN2QixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7Z0JBQzNCOzttQkFFRztnQkFDSCxjQUFjLEVBQUUsSUFBSSxDQUFDLGNBQWM7Z0JBQ25DLG9CQUFvQixFQUFFLElBQUksQ0FBQyxvQkFBb0I7Z0JBQy9DLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtnQkFDakMsY0FBYyxFQUFFLElBQUksQ0FBQyxjQUFjO2dCQUNuQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsa0JBQWtCO2dCQUMzQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7Z0JBQy9CLGVBQWUsRUFBRSxJQUFJLENBQUMsZUFBZTtnQkFDckMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLG1CQUFtQjtnQkFDN0M7O21CQUVHO2dCQUNILFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtnQkFDdkIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtnQkFDdkMscUJBQXFCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtnQkFFakQsVUFBVSxFQUFFLElBQUk7Z0JBQ2hCLHdCQUF3QjtnQkFDeEIseUJBQXlCO2dCQUN6QixRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVU7Z0JBQ3pCLGNBQWMsRUFBRSxJQUFJLENBQUMsVUFBVTtnQkFDL0IsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXO2dCQUMxQixVQUFVLEVBQUU7b0JBQ1YsTUFBTSxFQUFFLHFCQUFxQjtvQkFDN0IsTUFBTSxFQUFFLHFCQUFxQjtpQkFDOUI7Z0JBQ0QsY0FBYztnQkFDZCxVQUFVO2dCQUNWLFVBQVUsRUFBRTtvQkFDVixFQUFFLEVBQUUsb0JBQW9CO29CQUN4QixTQUFTLEVBQUUsSUFBSTtpQkFDaEI7Z0JBQ0QsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjtnQkFDekMsa0JBQWtCLEVBQUUsSUFBSTtnQkFDeEIsRUFBRSxFQUFFO29CQUNGLDBCQUEwQixFQUFFLEdBQUcsRUFBRTt3QkFDL0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxDQUFDO29CQUMvQixDQUFDO2lCQUNGO2FBQ0YsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDOzs7WUFwSUYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxZQUFZO2dCQUN0QixpOUJBQTBDOzthQUUzQzs7OzsrQkFHRSxNQUFNOzJCQUtOLEtBQUs7d0JBQ0wsS0FBSztvQkFDTCxLQUFLO3lCQUNMLEtBQUs7dUJBQ0wsS0FBSzs2QkFDTCxLQUFLOzBCQUNMLEtBQUs7OEJBR0wsS0FBSzs0QkFDTCxLQUFLOytCQUNMLEtBQUs7eUJBQ0wsS0FBSztnQ0FDTCxLQUFLO2lDQUNMLEtBQUs7a0NBQ0wsS0FBSzs2QkFJTCxLQUFLO21DQUNMLEtBQUs7eUJBQ0wsS0FBSzs0QkFDTCxLQUFLOzZCQUNMLEtBQUs7aUNBQ0wsS0FBSzsyQkFDTCxLQUFLOzhCQUNMLEtBQUs7dUJBSUwsS0FBSzsrQkFDTCxLQUFLO29DQUNMLEtBQUs7NENBQ0wsS0FBSzt5QkFFTCxLQUFLOzZCQUNMLEtBQUs7eUJBQ0wsS0FBSzt1QkFFTCxLQUFLO29CQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgSW5wdXQsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcywgT3V0cHV0LCBFdmVudEVtaXR0ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCBTd2lwZXIgZnJvbSAnc3dpcGVyJztcbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ25nMi1zd2lwZXInLFxuICB0ZW1wbGF0ZVVybDogJy4vbmcyLXN3aXBlci5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL25nMi1zd2lwZXIuY29tcG9uZW50Lmxlc3MnXVxufSlcbmV4cG9ydCBjbGFzcyBOZzJTd2lwZXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XG4gIC8vIHNsaWRlQ2hhbmdlVHJhbnNpdGlvblN0YXJ0IOWbnuiwg+aWueazlVxuICBAT3V0cHV0KCkgcHJpdmF0ZSBzbGlkZUNoYW5nZVN0YXJ0ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XG5cbiAgLyoqXG4gICAqIGJhc2ljIOiuvue9rumhuVxuICAgKi9cbiAgQElucHV0KCkgaW5pdGlhbFNsaWRlID0gMDsgLy8g6K6+5a6a5Yid5aeL5YyW5pe2c2xpZGXnmoTntKLlvJVcbiAgQElucHV0KCkgZGlyZWN0aW9uPzogJ2hvcml6b250YWwnIHwgJ3ZlcnRpY2FsJzsgLy8g5ruR5Yqo5pa55ZCRXG4gIEBJbnB1dCgpIHNwZWVkID0gMzAwOyAvLyDliIfmjaLpgJ/luqZcbiAgQElucHV0KCkgZ3JhYkN1cnNvciA9IGZhbHNlOyAvLyDorr7nva7kuLp0cnVl5pe277yM6byg5qCH6KaG55uWU3dpcGVy5pe25oyH6ZKI5Lya5Y+Y5oiQ5omL5o6M5b2i54q277yM5ouW5Yqo5pe25oyH6ZKI5Lya5Y+Y5oiQ5oqT5omL5b2i54q244CCXG4gIEBJbnB1dCgpIHBhcmFsbGF4ID0gZmFsc2U7IC8vIOW8gOWQr+inhuW3ruaViOaenFxuICBASW5wdXQoKSBwYXJhbGxheEltZ1VybDogc3RyaW5nOyAvLyDop4blt67og4zmma/lm75cbiAgQElucHV0KCkgcGFyYWxsYXhQZXIgPSAnLTIzJSc7IC8vIGRhdGEtc3dpcGVyLXBhcmFsbGF45o6l5Y+X5Lik56eN57G75Z6L55qE5Y+C5pWw44CCXG4gIC8vIG51bWJlcu+8iOWNleS9je+8mnB477yJ77yM5aaCLTMwMO+8jOS7juWPs+i+uTMwMHB46L+b5YWl5bem6L655Ye65Y6744CCXG4gIC8vIHBlcmNlbnRhZ2XvvIjnmb7liIbmr5TvvInvvIznp7vliqjot53nprs96K+l5YWD57Sg5a695bqmICogcGVyY2VudGFnZeOAglxuICBASW5wdXQoKSBwYXJhbGxheE9wYWNpdHkgPSAwLjU7IC8vIOinhuW3rumAj+aYjuW6puWPmOWMllxuICBASW5wdXQoKSBwYXJhbGxheFNjYWxlID0gMC41OyAvLyDop4blt67nvKnmlL7lj5jljJZcbiAgQElucHV0KCkgcGFyYWxsYXhEdXJhdGlvbiA9IDMwMDA7IC8vIOiuvuWumuinhuW3ruWKqOeUu+aMgee7reaXtumXtO+8iG1z77yJXG4gIEBJbnB1dCgpIGF1dG9IZWlnaHQgPSBmYWxzZTsgLy8g6auY5bqm6ZqP5YaF5a655Y+Y5YyWXG4gIEBJbnB1dCgpIHVuaXF1ZU5hdkVsZW1lbnRzID0gZmFsc2U7IC8vIOaOp+WItue7hOS7tuaUvuWcqGNvbnRhaW5lcuWklumdoueahOaXtuWAme+8jOmcgOimgeeUqOWIsFxuICBASW5wdXQoKSBydW5DYWxsYmFja3NPbkluaXQgPSB0cnVlOyAvLyDop6blj5Hlm57osIPvvIzlpoLmnpzkuI3mg7Pop6blj5HvvIzlsIbmraTorr7nva7kuLpmYWxzZVxuICBASW5wdXQoKSBzbGlkZXNQZXJDb2x1bW5GaWxsOiAnY29sdW1uJyB8ICdyb3cnOyAvLyDlpJrooYzluIPlsYBcbiAgLyoqXG4gICAqIFNsaWRlcyBncmlkKOe9keagvOWIhuW4gylcbiAgICovXG4gIEBJbnB1dCgpIGNlbnRlcmVkU2xpZGVzID0gZmFsc2U7IC8vIOiuvuWumuS4unRydWXml7bvvIxhY3RpdmUgc2xpZGXkvJrlsYXkuK3vvIzogIzkuI3mmK/pu5jorqTnirbmgIHkuIvnmoTlsYXlt6ZcbiAgQElucHV0KCkgY2VudGVyZWRTbGlkZXNCb3VuZHMgPSBmYWxzZTsgLy8g5b2T6K6+572u5LqGQWN0aXZlIFNsaWRl5bGF5Lit5ZCO77yM6L+Y5Y+v5Lul6YWN5ZCI6K6+572u5q2k5Y+C5pWw77yM5L2/5b6X56ys5LiA5Liq5ZKM5pyA5ZCO5LiA5LiqU2xpZGUg5aeL57uI6LS05ZCI6L6557yY44CCXG4gIEBJbnB1dCgpIG5hdmlnYXRpb24gPSB0cnVlOyAvLyDlt6blj7Pnrq3lpLTliIfmjaLlvIDlhbNcbiAgQElucHV0KCkgc2xpZGVzUGVyVmlldyA9IDE7IC8vIOiuvue9rnNsaWRlcuWuueWZqOiDveWkn+WQjOaXtuaYvuekuueahHNsaWRlc+aVsOmHj1xuICBASW5wdXQoKSBzbGlkZXNQZXJHcm91cCA9IDE7IC8vIOWumuS5iXNsaWRlc+eahOaVsOmHj+WkmuWwkeS4uuS4gOe7hFxuICBASW5wdXQoKSBzbGlkZXNQZXJHcm91cFNraXAgPSAwOyAvLyDorr7nva7ot7Pov4fliIbnu4RcbiAgQElucHV0KCkgc3BhY2VCZXR3ZWVuID0gMDsgLy8g5Zyoc2xpZGXkuYvpl7Torr7nva7ot53nprvvvIjljZXkvY1weO+8ieOAglxuICBASW5wdXQoKSBzbGlkZXNQZXJDb2x1bW4gPSAxOyAvLyDorr7nva7lpJrooYzluIPlsYDph4zpnaLmr4/liJfnmoRzbGlkZeaVsOmHj1xuICAvKipcbiAgICogRnJlZSBNb2RlIO+8iGZyZWXmqKHlvI8v5oq15oqX5Y+N5by577yJXG4gICAqL1xuICBASW5wdXQoKSBmcmVlTW9kZSA9IGZhbHNlOyAvLyDorr7nva7kuLp0cnVl5YiZ5Y+Y5Li6ZnJlZeaooeW8jyBzbGlkZeS8muagueaNruaDr+aAp+a7keWKqOWPr+iDveS4jeatouS4gOagvOS4lOS4jeS8mui0tOWQiFxuICBASW5wdXQoKSBmcmVlTW9kZU1vbWVudHVtID0gdHJ1ZTsgLy8gZnJlZeaooeW8j+WKqOmHj+OAgmZyZWXmqKHlvI/kuIvvvIxncmFiQ3Vyc29y6ZyA6K6+572u5Li6ZmFsc2Ug6Iul6K6+572u5Li6ZmFsc2XliJnlhbPpl63liqjph4/vvIzph4rmlL5zbGlkZeS5i+WQjueri+WNs+WBnOatouS4jeS8mua7keWKqFxuICBASW5wdXQoKSBmcmVlTW9kZU1vbWVudHVtUmF0aW8gPSAxOyAvLyDorr7nva7nmoTlgLzotorlpKfvvIzlvZPph4rmlL5zbGlkZeaXtueahOa7keWKqOaXtumXtOi2iumVv1xuICBASW5wdXQoKSBmcmVlTW9kZU1vbWVudHVtVmVsb2NpdHlSYXRpbyA9IDE7IC8vIGZyZWXmqKHlvI/mg6/mgKfpgJ/luqbvvIzorr7nva7otorlpKfvvIzph4rmlL7lkI7mu5Hlvpfotorlv6tcblxuICBASW5wdXQoKSBzd2lwZXJDb250ID0gJ3N3aXBlci1jb250YWluZXInOyAvLyDorr7nva5zd2lwZXLnmoRpZFxuICBASW5wdXQoKSBwYWdpbmF0aW9uU2hvdyA9IHRydWU7IC8vIOaYr+WQpuaYvuekuuWIhumhteWZqFxuICBASW5wdXQoKSBpc09ic2VydmVyID0gdHJ1ZTsgLy8g5L+u5pS5c3dpcGVy6Ieq5bex5oiW5a2Q5YWD57Sg5pe277yM6Ieq5Yqo5Yid5aeL5YyWc3dpcGVyXG5cbiAgQElucHV0KCkgYXV0b3BsYXkgPSBmYWxzZTsgLy8g6Ieq5Yqo5pKt5pS+XG4gIEBJbnB1dCgpIGRlbGF5ID0gMzsgLy8g6Ieq5Yqo5pKt5pS+6Ze06ZqU5pe26Ze0KOenkilcbiAgYXV0b3BsYXlPYmo6IGFueTtcblxuXG4gIGNvbnN0cnVjdG9yKCkgeyB9XG4gIHN3aXBlckJveDogYW55O1xuXG4gIG5nT25Jbml0KCkge1xuICB9XG4gIC8vIOiHquWKqOaSreaUvuWIpOaWrVxuICBzZXRBdXRvcGxheSgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5hdXRvcGxheSA9PSB0cnVlKSB7XG4gICAgICB0aGlzLmF1dG9wbGF5T2JqID0ge1xuICAgICAgICBkaXNhYmxlT25JbnRlcmFjdGlvbjogZmFsc2UsXG4gICAgICAgIGRlbGF5OiB0aGlzLmRlbGF5ICogMTAwMCwgLy8gMeenkuWIh+aNouS4gOasoVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmF1dG9wbGF5T2JqID0gdGhpcy5hdXRvcGxheTtcbiAgICB9XG4gIH07XG5cbiAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xuICAgIGNvbnN0IHRoYXQgPSB0aGlzO1xuICAgIC8vIOi9ruaSreWbvlxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5zZXRBdXRvcGxheSgpO1xuICAgICAgdGhhdC5zd2lwZXJCb3ggPSBuZXcgU3dpcGVyKCcjJyArIHRoaXMuc3dpcGVyQ29udCwge1xuICAgICAgICBsb29wOiBmYWxzZSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGJhc2ljIOiuvue9rumhuVxuICAgICAgICAgKi9cbiAgICAgICAgaW5pdGlhbFNsaWRlOiB0aGlzLmluaXRpYWxTbGlkZSxcbiAgICAgICAgZGlyZWN0aW9uOiB0aGlzLmRpcmVjdGlvbixcbiAgICAgICAgc3BlZWQ6IHRoaXMuc3BlZWQsXG4gICAgICAgIGdyYWJDdXJzb3I6IHRoaXMuZ3JhYkN1cnNvcixcbiAgICAgICAgcGFyYWxsYXg6IHRoaXMucGFyYWxsYXgsXG4gICAgICAgIGF1dG9IZWlnaHQ6IHRoaXMuYXV0b0hlaWdodCxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNsaWRlcyBncmlkKOe9keagvOWIhuW4gylcbiAgICAgICAgICovXG4gICAgICAgIGNlbnRlcmVkU2xpZGVzOiB0aGlzLmNlbnRlcmVkU2xpZGVzLFxuICAgICAgICBjZW50ZXJlZFNsaWRlc0JvdW5kczogdGhpcy5jZW50ZXJlZFNsaWRlc0JvdW5kcyxcbiAgICAgICAgc2xpZGVzUGVyVmlldzogdGhpcy5zbGlkZXNQZXJWaWV3LFxuICAgICAgICBzbGlkZXNQZXJHcm91cDogdGhpcy5zbGlkZXNQZXJHcm91cCxcbiAgICAgICAgc2xpZGVzUGVyR3JvdXBTa2lwOiB0aGlzLnNsaWRlc1Blckdyb3VwU2tpcCxcbiAgICAgICAgc3BhY2VCZXR3ZWVuOiB0aGlzLnNwYWNlQmV0d2VlbixcbiAgICAgICAgc2xpZGVzUGVyQ29sdW1uOiB0aGlzLnNsaWRlc1BlckNvbHVtbixcbiAgICAgICAgc2xpZGVzUGVyQ29sdW1uRmlsbDogdGhpcy5zbGlkZXNQZXJDb2x1bW5GaWxsLFxuICAgICAgICAvKipcbiAgICAgICAgICogXG4gICAgICAgICAqL1xuICAgICAgICBmcmVlTW9kZTogdGhpcy5mcmVlTW9kZSxcbiAgICAgICAgZnJlZU1vZGVNb21lbnR1bTogdGhpcy5mcmVlTW9kZU1vbWVudHVtLFxuICAgICAgICBmcmVlTW9kZU1vbWVudHVtUmF0aW86IHRoaXMuZnJlZU1vZGVNb21lbnR1bVJhdGlvLFxuXG4gICAgICAgIG1vdXNld2hlZWw6IHRydWUsXG4gICAgICAgIC8vIGR5bmFtaWNCdWxsZXRzOiB0cnVlLFxuICAgICAgICAvLyBkeW5hbWljTWFpbkJ1bGxldHM6IDIsXG4gICAgICAgIG9ic2VydmVyOiB0aGlzLmlzT2JzZXJ2ZXIsIC8vIOS/ruaUuXN3aXBlcuiHquW3seaIluWtkOWFg+e0oOaXtu+8jOiHquWKqOWIneWni+WMlnN3aXBlclxuICAgICAgICBvYnNlcnZlUGFyZW50czogdGhpcy5pc09ic2VydmVyLCAvLyDkv67mlLlzd2lwZXLnmoTniLblhYPntKDml7bvvIzoh6rliqjliJ3lp4vljJZzd2lwZXJcbiAgICAgICAgYXV0b3BsYXk6IHRoaXMuYXV0b3BsYXlPYmosXG4gICAgICAgIG5hdmlnYXRpb246IHtcbiAgICAgICAgICBuZXh0RWw6ICcuc3dpcGVyLWJ1dHRvbi1uZXh0JyxcbiAgICAgICAgICBwcmV2RWw6ICcuc3dpcGVyLWJ1dHRvbi1wcmV2JyxcbiAgICAgICAgfSxcbiAgICAgICAgLy8gbG9vcDogdHJ1ZSxcbiAgICAgICAgLy8g5aaC5p6c6ZyA6KaB5YiG6aG15ZmoXG4gICAgICAgIHBhZ2luYXRpb246IHtcbiAgICAgICAgICBlbDogJy5zd2lwZXItcGFnaW5hdGlvbicsXG4gICAgICAgICAgY2xpY2thYmxlOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIHVuaXF1ZU5hdkVsZW1lbnRzOiB0aGlzLnVuaXF1ZU5hdkVsZW1lbnRzLFxuICAgICAgICBydW5DYWxsYmFja3NPbkluaXQ6IHRydWUsIC8v5aaC5p6c5LiN5oOz6Kem5Y+R77yM5bCG5q2k6K6+572u5Li6ZmFsc2VcbiAgICAgICAgb246IHtcbiAgICAgICAgICBzbGlkZUNoYW5nZVRyYW5zaXRpb25TdGFydDogKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zbGlkZUNoYW5nZVN0YXJ0LmVtaXQoKTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxufVxuIl19