(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('swiper')) :
    typeof define === 'function' && define.amd ? define('ng2-swiper5', ['exports', '@angular/core', '@angular/common', 'swiper'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['ng2-swiper5'] = {}, global.ng.core, global.ng.common, global.Swiper));
}(this, (function (exports, core, common, Swiper) { 'use strict';

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    var Swiper__default = /*#__PURE__*/_interopDefaultLegacy(Swiper);

    var Ng2SwiperComponent = /** @class */ (function () {
        function Ng2SwiperComponent() {
            // slideChangeTransitionStart 回调方法
            this.slideChangeStart = new core.EventEmitter();
            /**
             * basic 设置项
             */
            this.initialSlide = 0; // 设定初始化时slide的索引
            this.speed = 300; // 切换速度
            this.grabCursor = false; // 设置为true时，鼠标覆盖Swiper时指针会变成手掌形状，拖动时指针会变成抓手形状。
            this.parallax = false; // 开启视差效果
            this.parallaxPer = '-23%'; // data-swiper-parallax接受两种类型的参数。
            // number（单位：px），如-300，从右边300px进入左边出去。
            // percentage（百分比），移动距离=该元素宽度 * percentage。
            this.parallaxOpacity = 0.5; // 视差透明度变化
            this.parallaxScale = 0.5; // 视差缩放变化
            this.parallaxDuration = 3000; // 设定视差动画持续时间（ms）
            this.autoHeight = false; // 高度随内容变化
            this.uniqueNavElements = false; // 控制组件放在container外面的时候，需要用到
            this.runCallbacksOnInit = true; // 触发回调，如果不想触发，将此设置为false
            /**
             * Slides grid(网格分布)
             */
            this.centeredSlides = false; // 设定为true时，active slide会居中，而不是默认状态下的居左
            this.centeredSlidesBounds = false; // 当设置了Active Slide居中后，还可以配合设置此参数，使得第一个和最后一个Slide 始终贴合边缘。
            this.navigation = true; // 左右箭头切换开关
            this.slidesPerView = 1; // 设置slider容器能够同时显示的slides数量
            this.slidesPerGroup = 1; // 定义slides的数量多少为一组
            this.slidesPerGroupSkip = 0; // 设置跳过分组
            this.spaceBetween = 0; // 在slide之间设置距离（单位px）。
            this.slidesPerColumn = 1; // 设置多行布局里面每列的slide数量
            /**
             * Free Mode （free模式/抵抗反弹）
             */
            this.freeMode = false; // 设置为true则变为free模式 slide会根据惯性滑动可能不止一格且不会贴合
            this.freeModeMomentum = true; // free模式动量。free模式下，grabCursor需设置为false 若设置为false则关闭动量，释放slide之后立即停止不会滑动
            this.freeModeMomentumRatio = 1; // 设置的值越大，当释放slide时的滑动时间越长
            this.freeModeMomentumVelocityRatio = 1; // free模式惯性速度，设置越大，释放后滑得越快
            this.swiperCont = 'swiper-container'; // 设置swiper的id
            this.paginationShow = true; // 是否显示分页器
            this.isObserver = true; // 修改swiper自己或子元素时，自动初始化swiper
            this.autoplay = false; // 自动播放
            this.delay = 3; // 自动播放间隔时间(秒)
        }
        Ng2SwiperComponent.prototype.ngOnInit = function () {
        };
        // 自动播放判断
        Ng2SwiperComponent.prototype.setAutoplay = function () {
            if (this.autoplay == true) {
                this.autoplayObj = {
                    disableOnInteraction: false,
                    delay: this.delay * 1000,
                };
            }
            else {
                this.autoplayObj = this.autoplay;
            }
        };
        ;
        Ng2SwiperComponent.prototype.ngOnChanges = function (changes) {
            var _this = this;
            var that = this;
            // 轮播图
            setTimeout(function () {
                _this.setAutoplay();
                that.swiperBox = new Swiper__default['default']('#' + _this.swiperCont, {
                    loop: false,
                    /**
                     * basic 设置项
                     */
                    initialSlide: _this.initialSlide,
                    direction: _this.direction,
                    speed: _this.speed,
                    grabCursor: _this.grabCursor,
                    parallax: _this.parallax,
                    autoHeight: _this.autoHeight,
                    /**
                     * Slides grid(网格分布)
                     */
                    centeredSlides: _this.centeredSlides,
                    centeredSlidesBounds: _this.centeredSlidesBounds,
                    slidesPerView: _this.slidesPerView,
                    slidesPerGroup: _this.slidesPerGroup,
                    slidesPerGroupSkip: _this.slidesPerGroupSkip,
                    spaceBetween: _this.spaceBetween,
                    slidesPerColumn: _this.slidesPerColumn,
                    slidesPerColumnFill: _this.slidesPerColumnFill,
                    /**
                     *
                     */
                    freeMode: _this.freeMode,
                    freeModeMomentum: _this.freeModeMomentum,
                    freeModeMomentumRatio: _this.freeModeMomentumRatio,
                    mousewheel: true,
                    // dynamicBullets: true,
                    // dynamicMainBullets: 2,
                    observer: _this.isObserver,
                    observeParents: _this.isObserver,
                    autoplay: _this.autoplayObj,
                    navigation: {
                        nextEl: '.swiper-button-next',
                        prevEl: '.swiper-button-prev',
                    },
                    // loop: true,
                    // 如果需要分页器
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true
                    },
                    uniqueNavElements: _this.uniqueNavElements,
                    runCallbacksOnInit: true,
                    on: {
                        slideChangeTransitionStart: function () {
                            _this.slideChangeStart.emit();
                        },
                    },
                });
            });
        };
        return Ng2SwiperComponent;
    }());
    Ng2SwiperComponent.decorators = [
        { type: core.Component, args: [{
                    selector: 'ng2-swiper',
                    template: "<div #swiper class=\"swiper-container\" [id]=\"swiperCont\">\n  <ng-container *ngIf=\"parallax == true\">\n    <div \n    [ngStyle]=\"{ 'background': 'url(' + parallaxImgUrl + ')' }\" \n    [attr.data-swiper-parallax]=\"parallaxPer\" \n    [attr.data-swiper-parallax-opacity]=\"parallaxOpacity\"\n    [attr.data-swiper-parallax-scale]=\"parallaxScale\"\n    [attr.data-swiper-parallax-duration]=\"parallaxDuration\"\n    ></div>\n  </ng-container>\n  <div class=\"swiper-wrapper\">\n      <ng-content select=\"[swiperSlide]\"></ng-content>\n  </div>\n  <div class=\"swiper-scrollbar\"></div>\n  <!-- \u5982\u679C\u9700\u8981\u5206\u9875\u5668 -->\n  <div class=\"swiper-pagination\" *ngIf=\"paginationShow == true\">\n  </div>\n  <!-- \u5982\u679C\u9700\u8981\u5BFC\u822A\u6309\u94AE -->\n  <ng-container *ngIf=\"navigation == true\">\n      <div class=\"swiper-button-prev\"></div>\n      <div class=\"swiper-button-next\"></div>\n  </ng-container>\n  \n  \n</div>",
                    styles: [".swiper-container{height:100%;overflow:hidden;width:100%}.swiper-button-next:after,.swiper-button-prev:after{font-size:2rem!important}"]
                },] }
    ];
    Ng2SwiperComponent.ctorParameters = function () { return []; };
    Ng2SwiperComponent.propDecorators = {
        slideChangeStart: [{ type: core.Output }],
        initialSlide: [{ type: core.Input }],
        direction: [{ type: core.Input }],
        speed: [{ type: core.Input }],
        grabCursor: [{ type: core.Input }],
        parallax: [{ type: core.Input }],
        parallaxImgUrl: [{ type: core.Input }],
        parallaxPer: [{ type: core.Input }],
        parallaxOpacity: [{ type: core.Input }],
        parallaxScale: [{ type: core.Input }],
        parallaxDuration: [{ type: core.Input }],
        autoHeight: [{ type: core.Input }],
        uniqueNavElements: [{ type: core.Input }],
        runCallbacksOnInit: [{ type: core.Input }],
        slidesPerColumnFill: [{ type: core.Input }],
        centeredSlides: [{ type: core.Input }],
        centeredSlidesBounds: [{ type: core.Input }],
        navigation: [{ type: core.Input }],
        slidesPerView: [{ type: core.Input }],
        slidesPerGroup: [{ type: core.Input }],
        slidesPerGroupSkip: [{ type: core.Input }],
        spaceBetween: [{ type: core.Input }],
        slidesPerColumn: [{ type: core.Input }],
        freeMode: [{ type: core.Input }],
        freeModeMomentum: [{ type: core.Input }],
        freeModeMomentumRatio: [{ type: core.Input }],
        freeModeMomentumVelocityRatio: [{ type: core.Input }],
        swiperCont: [{ type: core.Input }],
        paginationShow: [{ type: core.Input }],
        isObserver: [{ type: core.Input }],
        autoplay: [{ type: core.Input }],
        delay: [{ type: core.Input }]
    };

    var Ng2SwiperModule = /** @class */ (function () {
        function Ng2SwiperModule() {
        }
        return Ng2SwiperModule;
    }());
    Ng2SwiperModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    declarations: [Ng2SwiperComponent],
                    exports: [Ng2SwiperComponent]
                },] }
    ];

    /**
     * Generated bundle index. Do not edit.
     */

    exports.Ng2SwiperModule = Ng2SwiperModule;
    exports.ɵa = Ng2SwiperComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng2-swiper5.umd.js.map
