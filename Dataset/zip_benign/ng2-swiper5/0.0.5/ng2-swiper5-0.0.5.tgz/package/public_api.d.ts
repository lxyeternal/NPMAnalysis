export * from './src/app/ng2-swiper/ng2-swiper.module';
