export declare class Ng2SwiperModule {
}
