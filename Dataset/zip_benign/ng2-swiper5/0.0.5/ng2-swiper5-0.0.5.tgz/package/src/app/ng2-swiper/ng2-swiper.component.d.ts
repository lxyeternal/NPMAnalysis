import { OnInit, OnChanges, SimpleChanges } from '@angular/core';
export declare class Ng2SwiperComponent implements OnInit, OnChanges {
    private slideChangeStart;
    /**
     * basic 设置项
     */
    initialSlide: number;
    direction?: 'horizontal' | 'vertical';
    speed: number;
    grabCursor: boolean;
    parallax: boolean;
    parallaxImgUrl: string;
    parallaxPer: string;
    parallaxOpacity: number;
    parallaxScale: number;
    parallaxDuration: number;
    autoHeight: boolean;
    uniqueNavElements: boolean;
    runCallbacksOnInit: boolean;
    slidesPerColumnFill: 'column' | 'row';
    /**
     * Slides grid(网格分布)
     */
    centeredSlides: boolean;
    centeredSlidesBounds: boolean;
    navigation: boolean;
    slidesPerView: number;
    slidesPerGroup: number;
    slidesPerGroupSkip: number;
    spaceBetween: number;
    slidesPerColumn: number;
    /**
     * Free Mode （free模式/抵抗反弹）
     */
    freeMode: boolean;
    freeModeMomentum: boolean;
    freeModeMomentumRatio: number;
    freeModeMomentumVelocityRatio: number;
    swiperCont: string;
    paginationShow: boolean;
    isObserver: boolean;
    autoplay: boolean;
    delay: number;
    autoplayObj: any;
    constructor();
    swiperBox: any;
    ngOnInit(): void;
    setAutoplay(): void;
    ngOnChanges(changes: SimpleChanges): void;
}
