/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { Ng2SwiperComponent as ɵa } from './src/app/ng2-swiper/ng2-swiper.component';
