$(function () {
	alert(1111);
	console.log(1111);
})