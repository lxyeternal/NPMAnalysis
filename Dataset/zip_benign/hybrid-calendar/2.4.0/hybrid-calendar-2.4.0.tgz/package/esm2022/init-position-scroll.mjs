import { Component, Input, Output, EventEmitter, ViewEncapsulation, } from "@angular/core";
import * as i0 from "@angular/core";
export class initPositionScrollComponent {
    constructor(el, ngZone) {
        this.ngZone = ngZone;
        this.onScroll = new EventEmitter();
        this.listenerAttached = false;
        this.element = el;
    }
    ngOnChanges(changes) {
        let initPosition = changes["initPosition"];
        if (initPosition &&
            initPosition.currentValue !== undefined &&
            this.scrollContent &&
            initPosition.currentValue != this.scrollContent.scrollTop) {
            const me = this;
            this.ngZone.run(() => {
                me.scrollContent.scrollTop = initPosition.currentValue;
            });
        }
    }
    ngAfterViewInit() {
        const scrollContent = (this.scrollContent =
            this.element.nativeElement.querySelector(".scroll-content"));
        if (this.initPosition !== undefined) {
            scrollContent.scrollTop = this.initPosition;
        }
        if (this.emitEvent && !this.listenerAttached) {
            let onScroll = this.onScroll;
            let me = this;
            this.handler = function () {
                if (me.initPosition != scrollContent.scrollTop) {
                    onScroll.emit(scrollContent.scrollTop);
                }
            };
            this.listenerAttached = true;
            scrollContent.addEventListener("scroll", this.handler);
        }
    }
    ngOnDestroy() {
        if (this.listenerAttached) {
            this.scrollContent.removeEventListener("scroll", this.handler);
            this.listenerAttached = false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: initPositionScrollComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.11", type: initPositionScrollComponent, selector: "init-position-scroll", inputs: { initPosition: "initPosition", emitEvent: "emitEvent" }, outputs: { onScroll: "onScroll" }, usesOnChanges: true, ngImport: i0, template: `
        <div class="scroll-content" style="height:100%">
            <ng-content></ng-content>
        </div>
    `, isInline: true, styles: [".scroll-content{overflow-y:auto;overflow-x:hidden}\n"], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.11", ngImport: i0, type: initPositionScrollComponent, decorators: [{
            type: Component,
            args: [{ selector: "init-position-scroll", template: `
        <div class="scroll-content" style="height:100%">
            <ng-content></ng-content>
        </div>
    `, encapsulation: ViewEncapsulation.None, styles: [".scroll-content{overflow-y:auto;overflow-x:hidden}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }], propDecorators: { initPosition: [{
                type: Input
            }], emitEvent: [{
                type: Input
            }], onScroll: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5pdC1wb3NpdGlvbi1zY3JvbGwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvaW5pdC1wb3NpdGlvbi1zY3JvbGwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFNWixpQkFBaUIsR0FFcEIsTUFBTSxlQUFlLENBQUM7O0FBbUJ2QixNQUFNLE9BQU8sMkJBQTJCO0lBWXBDLFlBQVksRUFBYyxFQUFVLE1BQWM7UUFBZCxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBUHhDLGFBQVEsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBS3hDLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUd0QyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQzlCLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUMzQyxJQUNJLFlBQVk7WUFDWixZQUFZLENBQUMsWUFBWSxLQUFLLFNBQVM7WUFDdkMsSUFBSSxDQUFDLGFBQWE7WUFDbEIsWUFBWSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFDM0Q7WUFDRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFO2dCQUNqQixFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNYLE1BQU0sYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWE7WUFDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUNqRSxJQUFJLElBQUksQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFO1lBQ2pDLGFBQWEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUMvQztRQUVELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUMxQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQzdCLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQztZQUNkLElBQUksQ0FBQyxPQUFPLEdBQUc7Z0JBQ1gsSUFBSSxFQUFFLENBQUMsWUFBWSxJQUFJLGFBQWEsQ0FBQyxTQUFTLEVBQUU7b0JBQzVDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUMxQztZQUNMLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7WUFDN0IsYUFBYSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDMUQ7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMvRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQzsrR0F4RFEsMkJBQTJCO21HQUEzQiwyQkFBMkIsc0xBZjFCOzs7O0tBSVQ7OzRGQVdRLDJCQUEyQjtrQkFqQnZDLFNBQVM7K0JBQ0ksc0JBQXNCLFlBQ3RCOzs7O0tBSVQsaUJBU2MsaUJBQWlCLENBQUMsSUFBSTtvR0FLNUIsWUFBWTtzQkFBcEIsS0FBSztnQkFDRyxTQUFTO3NCQUFqQixLQUFLO2dCQUNJLFFBQVE7c0JBQWpCLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICAgIENvbXBvbmVudCxcbiAgICBJbnB1dCxcbiAgICBPdXRwdXQsXG4gICAgRXZlbnRFbWl0dGVyLFxuICAgIEVsZW1lbnRSZWYsXG4gICAgU2ltcGxlQ2hhbmdlcyxcbiAgICBPbkNoYW5nZXMsXG4gICAgQWZ0ZXJWaWV3SW5pdCxcbiAgICBPbkRlc3Ryb3ksXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXG4gICAgTmdab25lLFxufSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogXCJpbml0LXBvc2l0aW9uLXNjcm9sbFwiLFxuICAgIHRlbXBsYXRlOiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzY3JvbGwtY29udGVudFwiIHN0eWxlPVwiaGVpZ2h0OjEwMCVcIj5cbiAgICAgICAgICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbiAgICAgICAgPC9kaXY+XG4gICAgYCxcbiAgICBzdHlsZXM6IFtcbiAgICAgICAgYFxuICAgICAgICAgICAgLnNjcm9sbC1jb250ZW50IHtcbiAgICAgICAgICAgICAgICBvdmVyZmxvdy15OiBhdXRvO1xuICAgICAgICAgICAgICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgYCxcbiAgICBdLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG59KVxuZXhwb3J0IGNsYXNzIGluaXRQb3NpdGlvblNjcm9sbENvbXBvbmVudFxuICAgIGltcGxlbWVudHMgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3lcbntcbiAgICBASW5wdXQoKSBpbml0UG9zaXRpb24hOiBudW1iZXI7XG4gICAgQElucHV0KCkgZW1pdEV2ZW50PzogYm9vbGVhbjtcbiAgICBAT3V0cHV0KCkgb25TY3JvbGwgPSBuZXcgRXZlbnRFbWl0dGVyPG51bWJlcj4oKTtcblxuICAgIHByaXZhdGUgZWxlbWVudDogRWxlbWVudFJlZjtcbiAgICBwcml2YXRlIHNjcm9sbENvbnRlbnQhOiBIVE1MRWxlbWVudDtcbiAgICBwcml2YXRlIGhhbmRsZXIhOiAoKSA9PiB2b2lkO1xuICAgIHByaXZhdGUgbGlzdGVuZXJBdHRhY2hlZDogYm9vbGVhbiA9IGZhbHNlO1xuXG4gICAgY29uc3RydWN0b3IoZWw6IEVsZW1lbnRSZWYsIHByaXZhdGUgbmdab25lOiBOZ1pvbmUpIHtcbiAgICAgICAgdGhpcy5lbGVtZW50ID0gZWw7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xuICAgICAgICBsZXQgaW5pdFBvc2l0aW9uID0gY2hhbmdlc1tcImluaXRQb3NpdGlvblwiXTtcbiAgICAgICAgaWYgKFxuICAgICAgICAgICAgaW5pdFBvc2l0aW9uICYmXG4gICAgICAgICAgICBpbml0UG9zaXRpb24uY3VycmVudFZhbHVlICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAgIHRoaXMuc2Nyb2xsQ29udGVudCAmJlxuICAgICAgICAgICAgaW5pdFBvc2l0aW9uLmN1cnJlbnRWYWx1ZSAhPSB0aGlzLnNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wXG4gICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgbWUgPSB0aGlzO1xuICAgICAgICAgICAgdGhpcy5uZ1pvbmUucnVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICBtZS5zY3JvbGxDb250ZW50LnNjcm9sbFRvcCA9IGluaXRQb3NpdGlvbi5jdXJyZW50VmFsdWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2Nyb2xsQ29udGVudCA9ICh0aGlzLnNjcm9sbENvbnRlbnQgPVxuICAgICAgICAgICAgdGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihcIi5zY3JvbGwtY29udGVudFwiKSk7XG4gICAgICAgIGlmICh0aGlzLmluaXRQb3NpdGlvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBzY3JvbGxDb250ZW50LnNjcm9sbFRvcCA9IHRoaXMuaW5pdFBvc2l0aW9uO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuZW1pdEV2ZW50ICYmICF0aGlzLmxpc3RlbmVyQXR0YWNoZWQpIHtcbiAgICAgICAgICAgIGxldCBvblNjcm9sbCA9IHRoaXMub25TY3JvbGw7XG4gICAgICAgICAgICBsZXQgbWUgPSB0aGlzO1xuICAgICAgICAgICAgdGhpcy5oYW5kbGVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGlmIChtZS5pbml0UG9zaXRpb24gIT0gc2Nyb2xsQ29udGVudC5zY3JvbGxUb3ApIHtcbiAgICAgICAgICAgICAgICAgICAgb25TY3JvbGwuZW1pdChzY3JvbGxDb250ZW50LnNjcm9sbFRvcCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMubGlzdGVuZXJBdHRhY2hlZCA9IHRydWU7XG4gICAgICAgICAgICBzY3JvbGxDb250ZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgdGhpcy5oYW5kbGVyKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgICAgICBpZiAodGhpcy5saXN0ZW5lckF0dGFjaGVkKSB7XG4gICAgICAgICAgICB0aGlzLnNjcm9sbENvbnRlbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCB0aGlzLmhhbmRsZXIpO1xuICAgICAgICAgICAgdGhpcy5saXN0ZW5lckF0dGFjaGVkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=