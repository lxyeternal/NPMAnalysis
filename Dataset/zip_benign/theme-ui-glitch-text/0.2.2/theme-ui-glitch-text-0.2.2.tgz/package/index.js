"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _themeUi = require("theme-ui");

var _core = require("@emotion/core");

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var randomInt = function randomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

var maxClipPath = function maxClipPath(limit) {
  return 1 / (2 - Math.pow(4 * (1 - limit), 0.25)) * 100;
};

var randClipPath = function randClipPath(maxClipPath, limit) {
  return randomInt(1, maxClipPath(limit)) + "%";
};

var randTextShadow = function randTextShadow(minShadow, maxShadow) {
  var shadow = randomInt(minShadow, maxShadow);
  return shadow === 0 ? randPosition() : shadow + "px";
};

var randColor = function randColor(colors) {
  return colors[randomInt(0, colors.length - 1)];
};

var randPosition = function randPosition(minPos, maxPos) {
  var pos = randomInt(minPos, maxPos);
  return pos === 0 ? randPosition() : pos + "px";
};

var clipPath = function clipPath(maxClipPath, limit) {
  return "inset(".concat(randClipPath(maxClipPath, limit), " 0 ").concat(randClipPath(maxClipPath, limit), " 0)");
};

var textShadow = function textShadow(minShadow, maxShadow, colors) {
  return "".concat(randTextShadow(minShadow, maxShadow), " 0 ").concat(randColor(colors));
};

var keys = function keys(keyframesNum) {
  return Array.from({
    length: keyframesNum + 1
  }).map(function (_, i) {
    return i * (100 / (keyframesNum + 1)) + '%';
  });
};

var getAnimation = function getAnimation(keyframesNum, limit, minShadow, maxShadow, minPos, maxPos, colors) {
  var animation = {};
  var animationKeys = keys(keyframesNum);
  animationKeys.forEach(function (key) {
    animation[key] = {
      clipPath: clipPath(maxClipPath, limit),
      textShadow: textShadow(minShadow, maxShadow, colors),
      left: randPosition(minPos, maxPos)
    };
  });
  return (0, _core.keyframes)(animation).toString();
};

var GlitchText = function GlitchText(props) {
  var children = props.children,
      text = props.text,
      _props$duration = props.duration,
      duration = _props$duration === void 0 ? "5000ms" : _props$duration,
      _props$limit = props.limit,
      limit = _props$limit === void 0 ? 0.5 : _props$limit,
      _props$keyframesNum = props.keyframesNum,
      keyframesNum = _props$keyframesNum === void 0 ? 20 : _props$keyframesNum,
      _props$shadow = props.shadow,
      shadow = _props$shadow === void 0 ? [-2, 2] : _props$shadow,
      _props$position = props.position,
      position = _props$position === void 0 ? [-5, 5] : _props$position,
      _props$colors = props.colors,
      colors = _props$colors === void 0 ? ["red", "green", "blue"] : _props$colors,
      _props$backgroundColo = props.backgroundColor,
      backgroundColor = _props$backgroundColo === void 0 ? "#fff" : _props$backgroundColo;
  var glitch1 = getAnimation(keyframesNum, limit, shadow[0], shadow[1], position[0], position[1], colors);
  var glitch2 = getAnimation(keyframesNum, limit, shadow[0], shadow[1], position[0], position[1], colors);
  return (0, _themeUi.jsx)("span", _extends({}, props, {
    sx: {
      '@media not screen and (prefers-reduced-motion: reduce)': {
        position: "relative",
        display: "inline-block",
        '&::before, &::after': {
          content: "\"".concat(text, "\""),
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%"
        },
        '&::before': {
          backgroundColor: backgroundColor,
          animationName: glitch1,
          animationTimingFunction: "linear",
          animationDuration: duration,
          animationIterationCount: "infinite"
        },
        '&::after': {
          backgroundColor: backgroundColor,
          animationName: glitch2,
          animationTimingFunction: "linear",
          animationDuration: duration,
          animationIterationCount: "infinite"
        }
      }
    }
  }), children);
};

var _default = GlitchText;
exports["default"] = _default;
