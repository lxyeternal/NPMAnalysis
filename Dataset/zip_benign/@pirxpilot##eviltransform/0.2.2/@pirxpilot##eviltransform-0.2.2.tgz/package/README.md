[![NPM version][npm-image]][npm-url]

This is a fork of javascript portion of the [eviltransform] project.
It cleans up strange export statements of the original.


````
npm install @pirxpilot/eviltransform
````

# Transform coordinate between earth(WGS-84) and mars in china(GCJ-02).

GCJ-02 coordiante is used by Google Maps, Autonavi Map and other china map service. (Baidu Map has an extra offset based on GCJ-02)

## WGStoGCJ/wgs2gcj

    wgs2gcj(wgsLat, wgsLng)

Input WGS-84 coordinate(wgsLat, wgsLng) and convert to GCJ-02 coordinate(gcjLat, gcjLng). The output of javascript is like:

    {"lat": xx.xxxx, "lng": yy.yyyy}

## GCJtoWGS/gcj2wgs

    gcj2wgs(gcjLat, gcjLng)

Input GCJ-02 coordinate(gcjLat, gcjLng) and convert to WGS-84 coordinate(wgsLat, wgsLng). The output of javascript is like:

    {"lat": xx.xxxx, "lng": yy.yyyy}

The output WGS-84 coordinate's accuracy is 1m to 2m. If you want more exactly result, use GCJtoWGSExact/gcj2wgs_exact.

## GCJtoWGSExact/gcj2wgs_exact

    gcj2wgs_exact(gcjLat, gcjLng)

Input GCJ-02 coordinate(gcjLat, gcjLng) and convert to WGS-84 coordinate(wgsLat, wgsLng). The output of javascript is like:

    {"lat": xx.xxxx, "lng": yy.yyyy}

The output WGS-84 coordinate's accuracy is less than 0.5m, but much slower than GCJtoWGS/gcj2wgs.

## Distance/distance

    distance(latA, lngA, latB, lngB)

Calculate the distance between point(latA, lngA) and point(latB, lngB), unit in meter.

# 地球坐标（WGS-84）与火星坐标（GCJ－2）转换.

GCJ-02坐标用在谷歌地图，高德地图等中国地图服务。（百度地图要在GCJ-02基础上再加转换）

## WGStoGCJ/wgs2gcj

    wgs2gcj(wgsLat, wgsLng)

输入WGS-84地球坐标(wgsLat, wgsLng)，转换为GCJ-02火星坐标(gcjLat, gcjLng)。javascript输出格式如下：

    {"lat": xx.xxxx, "lng": yy.yyyy}

## GCJtoWGS/gcj2wgs

    gcj2wgs(gcjLat, gcjLng)

输入GCJ-02火星坐标(gcjLat, gcjLng)，转换为WGS－84地球坐标(wgsLat, wgsLng)。javascript输出格式如下：

    {"lat": xx.xxxx, "lng": yy.yyyy}

输出的WGS-84坐标精度为1米到2米之间。如果要更精确的结果，使用GCJtoWGSExact/gcj2wgs_exact。

## GCJtoWGSExact/gcj2wgs_exact

    gcj2wgs_exact(gcjLat, gcjLng)

输入GCJ-02火星坐标(gcjLat, gcjLng)，转换为WGS－84地球坐标(wgsLat, wgsLng)。javascript输出格式如下：

    {"lat": xx.xxxx, "lng": yy.yyyy}

输出的WGS-84坐标精度为0.5米内，但是计算速度慢于GCJtoWGS/gcj2wgs。

## Distance/distance

    distance(latA, lngA, latB, lngB)

计算点(latA, lngA)和点(latB, lngB)之间的距离，单位为米。

[eviltransform]: https://github.com/googollee/eviltransform

[npm-image]: https://img.shields.io/npm/v/@pirxpilot/eviltransform.svg
[npm-url]: https://npmjs.org/package/@pirxpilot/eviltransform
