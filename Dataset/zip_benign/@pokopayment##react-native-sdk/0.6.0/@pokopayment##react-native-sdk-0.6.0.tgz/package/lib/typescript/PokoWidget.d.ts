import { ReactNode } from 'react';
export interface Props {
    children: ReactNode;
    apiKey?: string;
    environment?: WidgetEnv;
}
export type WidgetEnv = keyof typeof POKO_URL_CONST.BASE_URL;
export interface WidgetContextType {
    setApiKey: (apiKey: string) => void;
    setEnv: (env: WidgetEnv) => void;
    setUserId: (userId: string) => void;
    launchWidget: (params: WidgetLaunchParams) => string;
}
export type WidgetLaunchParams = Partial<{
    fiat: string;
    crypto: string;
    fiatAmount: number;
    cryptoAmount: number;
    strictMode: boolean;
    fiatList: string[];
    cryptoList: string[];
    excludeProviderIds: string[];
    signature: string;
    providerId: string;
    paymentMethodId: string;
    receiveWalletAddress: string;
}>;
declare const POKO_URL_CONST: {
    BASE_URL: {
        PRODUCTION: string;
        STAGING: string;
        DEVELOPMENT: string;
    };
    URL_KEYS: {
        API_KEY: string;
        CRYPTO: string;
        FIAT: string;
        CRYPTO_AMOUNT: string;
        FIAT_AMOUNT: string;
        USER_ID: string;
        RECEIVE_WALLET_ADDRESS: string;
        STRICT_MODE: string;
        FIAT_LIST: string;
        CRYPTO_LIST: string;
        EXCLUDE_PROVIDER_IDS: string;
        SIGNATURE: string;
        PROVIDER_ID: string;
        PAYMENT_METHOD_ID: string;
    };
};
export declare const WidgetProvider: ({ children, environment, apiKey }: Props) => JSX.Element;
export declare const useWidget: () => WidgetContextType;
export {};
//# sourceMappingURL=PokoWidget.d.ts.map