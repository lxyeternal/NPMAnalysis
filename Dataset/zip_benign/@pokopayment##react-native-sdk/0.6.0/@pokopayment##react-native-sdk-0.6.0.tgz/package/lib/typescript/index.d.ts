import { ViewStyle } from 'react-native';
type ReactNativeSdkProps = {
    color: string;
    style: ViewStyle;
};
export declare const ReactNativeSdkView: import("react-native").HostComponent<ReactNativeSdkProps> | (() => never);
export declare const PokoWidgetProvider: ({ children, environment, apiKey }: import("./PokoWidget").Props) => JSX.Element;
export declare const usePokoWidget: () => import("./PokoWidget").WidgetContextType;
export {};
//# sourceMappingURL=index.d.ts.map