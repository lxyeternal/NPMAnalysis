export interface Props {
    widgetUrl: string;
}
export type WidgetEnv = keyof typeof POKO_URL_CONST.BASE_URL;
export interface WidgetContextType {
    setApiKey: (apiKey: string) => void;
    setEnv: (env: WidgetEnv) => void;
    setUserId: (userId: string) => void;
    setReceiveWalletAddress: (receiveWalletAddress: string) => void;
    launchWidget: (params: WidgetLaunchParams) => string;
}
export type WidgetLaunchParams = Partial<{
    fiat: string;
    crypto: string;
    fiatAmount: number;
    cryptoAmount: number;
    strictMode: boolean;
}>;
declare const POKO_URL_CONST: {
    BASE_URL: {
        PRODUCTION: string;
        STAGING: string;
        DEVELOPMENT: string;
    };
    URL_KEYS: {
        API_KEY: string;
        CRYPTO: string;
        FIAT: string;
        CRYPTO_AMOUNT: string;
        FIAT_AMOUNT: string;
        USER_ID: string;
        RECEIVE_WALLET_ADDRESS: string;
        STRICT_MODE: string;
    };
};
export declare const WidgetWebView: ({}: Props) => JSX.Element;
export {};
//# sourceMappingURL=WidgetWebView.d.ts.map