# @pokopayment/react-native-sdk

Poko SDK for react native

## Installation

```sh
npm install @pokopayment/react-native-sdk
```

## Usage

```js
// Root component
import {PokoWidgetProvider} from '@pokopayment/react-native-sdk';

function App(): JSX.Element {
  return (
    <PokoWidgetProvider apiKey="your API_KEY (optional)" environment="DEVELOPMENT (default) | STAGING | PRODUCTION">
      <HelloWorld />
    </PokoWidgetProvider>
  );
}

// HelloWorld component
import {usePokoWidget} from '@pokopayment/react-native-sdk';

const {launchWidget, setApiKey, setEnv, setUserId} =
    usePokoWidget();

setApiKey('YOUR API KEY'); // required, can ignore if already provided from the PokoWidgetProvider
setUserId('Your user ID'); // required
setEnv('PRODUCTION' | 'STAGING' | 'DEVELOPMENT'); // default DEVELOPMENT

// See full list of options: https://pokoapp.gitbook.io/documentation/onramp-aggregator/sdk-integration-and-documentation/web-integration/parameters
const urlLaunched = launchWidget({
    fiat?: string; // VND, USD,..
    crypto?: string; // USDT-bsc, USDT-ethereum, BTC-bitcoin,...
    fiatAmount?: number; // 100.0
    cryptoAmount?: number; // 0.5
    strictMode?: boolean; // true | false (not allow users change fiat & crypto currency)
    fiatList?: string[]; // ['VND', 'USD']
    cryptoList?: string[]; // ['ETH-ethereum', 'BTC-bitcoin']
    excludeProviderIds?: string[]; // ['transak', 'payfura']
    signature?: string;
    providerId?: string;
    paymentMethodId?: string;
    receiveWalletAddress?: string;
});
```
