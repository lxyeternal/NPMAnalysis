import React, {
  createRef,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { TouchableOpacity } from 'react-native';
import { Alert } from 'react-native';
import { StatusBar } from 'react-native';
import { Text } from 'react-native';
import { StyleSheet } from 'react-native';
import { Modal } from 'react-native';
import { View } from 'react-native';
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';
import { WebView } from 'react-native-webview';

export interface Props {
  children: ReactNode;
  apiKey?: string;
  environment?: WidgetEnv;
}

export type WidgetEnv = keyof typeof POKO_URL_CONST.BASE_URL;

export interface WidgetContextType {
  setApiKey: (apiKey: string) => void;
  setEnv: (env: WidgetEnv) => void;
  setUserId: (userId: string) => void;
  launchWidget: (params: WidgetLaunchParams) => string;
}

export type WidgetLaunchParams = Partial<{
  fiat: string;
  crypto: string;
  fiatAmount: number;
  cryptoAmount: number;
  strictMode: boolean;
  fiatList: string[];
  cryptoList: string[];
  excludeProviderIds: string[];
  signature: string;
  providerId: string;
  paymentMethodId: string;
  receiveWalletAddress: string;
}>;

const WidgetContext = React.createContext<WidgetContextType>(
  {} as WidgetContextType
);

const POKO_URL_CONST = {
  BASE_URL: {
    PRODUCTION: 'https://onramp.pokoapp.xyz/',
    STAGING: 'https://stg.onramp.pokoapp.xyz',
    DEVELOPMENT: 'https://dev.onramp.pokoapp.xyz',
  },
  URL_KEYS: {
    API_KEY: 'apiKey',
    CRYPTO: 'crypto',
    FIAT: 'fiat',
    CRYPTO_AMOUNT: 'cryptoAmount',
    FIAT_AMOUNT: 'fiatAmount',
    USER_ID: 'userId',
    RECEIVE_WALLET_ADDRESS: 'receiveWalletAddress',
    STRICT_MODE: 'strictMode',
    FIAT_LIST: 'fiatList',
    CRYPTO_LIST: 'cryptoList',
    EXCLUDE_PROVIDER_IDS: 'excludeProviderIds',
    SIGNATURE: 'signature',
    PROVIDER_ID: 'providerId',
    PAYMENT_METHOD_ID: 'paymentMethodId',
  },
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    backgroundColor: '#ff9933',
  },
  headerTitle: {
    color: 'white',
    fontWeight: 'bold',
  },
  closeButton: {
    width: 80,
    borderColor: 'white',
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 4,
    paddingVertical: 4,
  },
  closeButtonText: {
    color: 'white',
  },
});

export const WidgetProvider = ({ children, environment, apiKey }: Props) => {
  const [showWidget, setShowWidget] = useState(false);
  const [widgetUrl, setWidgetUrl] = useState('');
  const userIdRef = useRef('');
  const envRef = useRef<WidgetEnv>(environment || 'DEVELOPMENT');
  const apiKeyRef = useRef<string>(apiKey || '');
  const webviewRef = createRef<WebView>();

  const log = useMemo(() => {
    if (envRef.current === 'DEVELOPMENT' || envRef.current === 'STAGING') {
      return console.log;
    }
    return () => null;
  }, []);

  useEffect(() => {
    if (widgetUrl) {
      webviewRef.current?.reload();
      log('Reload webview with URL', widgetUrl);
    }
  }, [webviewRef, widgetUrl, log]);

  useEffect(() => {
    handleNeededPermission();
  }, []);

  const genWidgetUrl = useCallback(
    (params: WidgetLaunchParams) => {
      log('Gen URL with params', params);
      if (apiKeyRef.current && userIdRef.current) {
        let url = POKO_URL_CONST.BASE_URL[envRef.current];
        const queryBuilder = [];

        // required params
        queryBuilder.push(
          [POKO_URL_CONST.URL_KEYS.API_KEY, apiKeyRef.current].join('=')
        );

        queryBuilder.push(
          [POKO_URL_CONST.URL_KEYS.USER_ID, userIdRef.current].join('=')
        );

        // optional params
        if (params.fiat) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.FIAT, params.fiat].join('=')
          );
        }

        if (params.crypto) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.CRYPTO, params.crypto].join('=')
          );
        }

        if (params.fiatAmount) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.FIAT_AMOUNT, params.fiatAmount].join('=')
          );
        }

        if (params.cryptoAmount) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.CRYPTO_AMOUNT, params.cryptoAmount].join(
              '='
            )
          );
        }

        if (params.strictMode) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.STRICT_MODE, params.strictMode].join('=')
          );
        }

        if (params.fiatList?.length) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.FIAT_LIST, params.fiatList.join(',')].join(
              '='
            )
          );
        }

        if (params.cryptoList?.length) {
          queryBuilder.push(
            [
              POKO_URL_CONST.URL_KEYS.CRYPTO_LIST,
              params.cryptoList.join(','),
            ].join('=')
          );
        }

        if (params.excludeProviderIds?.length) {
          queryBuilder.push(
            [
              POKO_URL_CONST.URL_KEYS.EXCLUDE_PROVIDER_IDS,
              params.excludeProviderIds.join(','),
            ].join('=')
          );
        }

        if (params.signature) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.SIGNATURE, params.signature].join('=')
          );
        }

        if (params.providerId) {
          queryBuilder.push(
            [POKO_URL_CONST.URL_KEYS.PROVIDER_ID, params.providerId].join('=')
          );
        }

        if (params.paymentMethodId) {
          queryBuilder.push(
            [
              POKO_URL_CONST.URL_KEYS.PAYMENT_METHOD_ID,
              params.paymentMethodId,
            ].join('=')
          );
        }

        if (params.receiveWalletAddress) {
          queryBuilder.push(
            [
              POKO_URL_CONST.URL_KEYS.RECEIVE_WALLET_ADDRESS,
              params.receiveWalletAddress,
            ].join('=')
          );
        }

        const finalUrl = `${url}?${queryBuilder.join('&')}`;

        log('Generated URL', finalUrl);

        return finalUrl;
      }
      throw new Error('Missing api key, user id');
    },
    [envRef, apiKeyRef, log]
  );

  const setUserId = useCallback(
    (userId: string) => {
      userIdRef.current = userId;
      log('Changed to new userID', userIdRef.current);
    },
    [log]
  );

  const setEnv = useCallback(
    (env: WidgetEnv) => {
      envRef.current = env;
      log('Changed to new env', envRef.current);
    },
    [log]
  );

  const setApiKey = useCallback(
    (key: string) => {
      apiKeyRef.current = key;
      log('Changed to new api key', apiKeyRef.current);
    },
    [log]
  );

  const launchWidget = useCallback(
    (params: WidgetLaunchParams) => {
      const url = genWidgetUrl(params);
      setShowWidget(true);

      // hide status bar to fix issue relates to some screens have a notch when open the modal
      StatusBar.setHidden(true);
      setWidgetUrl(url);

      return url;
    },
    [genWidgetUrl]
  );

  const handleCloseWidget = () => {
    Alert.alert(
      'Confirm',
      'All current actions will be canceled. Do you want to continue?',
      [
        {
          text: 'Cancel',
          style: 'default',
        },
        {
          text: 'Close widget',
          onPress: () => {
            setShowWidget(false);

            // unhide status bar
            StatusBar.setHidden(false);
          },
          style: 'cancel',
        },
      ]
    );
  };

  const handleNeededPermission = async () => {
    const permissionStatus = await check(PERMISSIONS.ANDROID.CAMERA);
    console.log('permissionStatus', { permissionStatus });
    if (
      permissionStatus === RESULTS.DENIED ||
      permissionStatus === RESULTS.LIMITED
    ) {
      Alert.alert(
        'Request permission',
        'To verify your identity and prevent future fraud, we need your camera.\nPlease tap "Allow" to grant us permission.',
        [
          {
            text: 'Cancel',
            style: 'default',
          },
          {
            text: 'Allow',
            onPress: async () => {
              const result = await request(PERMISSIONS.ANDROID.CAMERA);

              console.log('result', { result });
            },
            style: 'destructive',
          },
        ]
      );
    }
  };

  const memoedValue = useMemo<WidgetContextType>(
    () => ({
      setUserId,
      launchWidget,
      setEnv,
      setApiKey,
    }),
    [setUserId, launchWidget, setEnv, setApiKey]
  );

  return (
    <WidgetContext.Provider value={memoedValue}>
      <Modal visible={showWidget} onRequestClose={handleCloseWidget}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Poko Widget</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={handleCloseWidget}
          >
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.container}>
          <WebView
            source={{
              uri: widgetUrl,
            }}
          />
        </View>
      </Modal>

      {children}
    </WidgetContext.Provider>
  );
};

export const useWidget = () => {
  return useContext(WidgetContext);
};
