import {
  requireNativeComponent,
  UIManager,
  Platform,
  ViewStyle,
} from 'react-native';
import { useWidget, WidgetProvider } from './PokoWidget';

const LINKING_ERROR =
  `The package '@pokopayment/react-native-sdk' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';

type ReactNativeSdkProps = {
  color: string;
  style: ViewStyle;
};

const ComponentName = 'ReactNativeSdkView';

export const ReactNativeSdkView =
  UIManager.getViewManagerConfig(ComponentName) != null
    ? requireNativeComponent<ReactNativeSdkProps>(ComponentName)
    : () => {
        throw new Error(LINKING_ERROR);
      };

export const PokoWidgetProvider = WidgetProvider;
export const usePokoWidget = useWidget;
