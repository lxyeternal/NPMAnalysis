import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { Text } from 'react-native';

import { View } from 'react-native';

export interface Props {
  widgetUrl: string;
}

export type WidgetEnv = keyof typeof POKO_URL_CONST.BASE_URL;

export interface WidgetContextType {
  setApiKey: (apiKey: string) => void;
  setEnv: (env: WidgetEnv) => void;
  setUserId: (userId: string) => void;
  setReceiveWalletAddress: (receiveWalletAddress: string) => void;
  launchWidget: (params: WidgetLaunchParams) => string;
}

export type WidgetLaunchParams = Partial<{
  fiat: string;
  crypto: string;
  fiatAmount: number;
  cryptoAmount: number;
  strictMode: boolean;
}>;

const POKO_URL_CONST = {
  BASE_URL: {
    PRODUCTION: 'https://onramp.pokoapp.xyz/',
    STAGING: 'https://stg.onramp.pokoapp.xyz',
    DEVELOPMENT: 'https://dev.onramp.pokoapp.xyz',
  },
  URL_KEYS: {
    API_KEY: 'apiKey',
    CRYPTO: 'crypto',
    FIAT: 'fiat',
    CRYPTO_AMOUNT: 'cryptoAmount',
    FIAT_AMOUNT: 'fiatAmount',
    USER_ID: 'userId',
    RECEIVE_WALLET_ADDRESS: 'receiveWalletAddress',
    STRICT_MODE: 'strictMode',
  },
};

export const WidgetWebView = ({}: Props) => {
  // hide status bar if modal is opened
  useEffect(() => {
    StatusBar.setHidden(true);
  }, []);

  return (
    <View>
      <Text>Test</Text>
      {/* <View style={styles.header}>
        <Text style={styles.headerTitle}>Poko Widget</Text>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={handleCloseWidget}
        >
          <Text style={styles.closeButtonText}>Close</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.container}>
        <Button title="TE" onPress={() => setIsTest(() => !isTest)} />
        <WebView
          source={{
            uri: widgetUrl,
          }}
        />
      </View> */}
    </View>
  );
};
