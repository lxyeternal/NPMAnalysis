import * as math from 'mathjs';
export declare function zip(...args: any[]): {
    [key: string]: any[];
};
export declare function mapObjectValues(obj: any, fn: Function): any;
/**
 * Generate a function to extract/alter deeply nested data structures.
 * Takes a list of predefined symbols or custom functions,
 * and returns a function to be applied to the data.
 * Custom functions should accept two arguments, the first
 * being the returned element of the previous function, the second
 * being the next function in the invocation chain to be applied.
 *
 * Predefined symbols:
 *    :index    map over array elements
 *    :values   map over object values (turns result in array)
 *    :keys     iterate over object values (preserves keys)
 *    :zip      [a..n] --> [[a.0 .. n.0] .. [a.X .. n.X]]
 *    :flatten  [[a, b], [c, d]] --> [a, b, c, d]
 *    property  property access
 *
 * Example:
 * const EXAMPLE = [
 *   {a: 11, b: [1, 2, 3]},
 *   {a: 12, b: [4, 5, 6]},
 *   {a: 13, b: [7, 8, 9]},
 * ];
 * reshapeFn([':index', 'a'])(EXAMPLE);
 * --> [ 11, 12, 13 ]
 * reshapeFn([':flatten'])(reshapeFn([':index', 'b'])(EXAMPLE));
 * --> [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
 * reshapeFn([':index', ':keys',
 *   (el: any, fn: Function) => fn((el instanceof Array) ? el.map(n => ++n) : ++el)])(EXAMPLE);
 * --> [ { a: 12, b: [ 2, 3, 4 ] },
 *   { a: 13, b: [ 5, 6, 7 ] },
 *   { a: 14, b: [ 8, 9, 10 ] } ]
 *
 * @param symbols list of predefined symbols or functions
 */
export declare function reshapeFn(symbols: any[]): (data: any) => any;
export declare function descriptiveStats(array: number[] | number[][] | math.Matrix): {
    mean: any;
    median: any;
    dev: number;
    cv: number;
};
