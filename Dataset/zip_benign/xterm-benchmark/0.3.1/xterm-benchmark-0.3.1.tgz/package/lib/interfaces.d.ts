export interface IPerfOptions {
    [key: string]: any;
    fork?: boolean;
    forkArgs?: string[];
    forkOptions?: any;
    timeout?: number;
    repeat?: number;
    reportFullResults?: boolean;
}
export interface ICmdlineOverrides {
    repeat?: number;
    timeout?: number;
    reportFullResults?: boolean;
}
export interface IStackToken {
    type: PerfType;
    options?: IPerfOptions;
    name: string;
    callback(...args: any[]): void;
}
export interface IPerfCase extends IStackToken {
    summary: {
        [key: string]: any;
    };
    path: string[] | null;
    postEach(callback: (result: ICaseResult) => ICaseResult | void | null, perfCase?: this): this;
    postAll(callback: (results: ICaseResult[]) => ICaseResult[] | void, perfCase?: this): this;
    run(parentPath: string[], forked: boolean): Promise<void>;
    getIndent(): string;
}
export interface ICaseResult {
    name: string;
    path: string[];
    runtime: number[];
    returnValue: any;
    run: number;
    repeat: number;
    error?: any;
}
export interface IPerfTree {
    name: string;
    type: string;
    path: string;
    children?: IPerfTree[];
}
export declare enum PerfType {
    Context = 0,
    PerfCase = 1,
    before = 2,
    beforeEach = 3,
    after = 4,
    afterEach = 5
}
export declare enum EvalResultState {
    Success = 0,
    Missing = 1,
    Skipped = 2,
    Failed = 3
}
export interface IBaselineEntry {
    stat: string;
    base: number;
    tolerance?: null | number[];
    value?: number;
    eval?: EvalResultState;
    change?: number;
}
export interface IBaselineData {
    [treePath: string]: {
        [dataPath: string]: IBaselineEntry[];
    };
}
export interface IEvalStatsSummary {
    success: number;
    missing: number;
    skipped: number;
    failed: number;
}
export interface IBaselineReport {
    type: ReportType.Base;
    data: IBaselineData;
}
export interface IEvalStats {
    type: ReportType.Eval;
    data: IBaselineData;
    summary: IEvalStatsSummary;
}
export interface IEvalConfig {
    tolerance: {
        [key: string]: number[];
    };
    skip: string[];
}
export declare const enum ReportType {
    PerfCase = 0,
    Base = 1,
    Eval = 2,
    Error = 3
}
export interface IPerfResult {
    type: ReportType.PerfCase;
    name: string;
    path: string[];
    pathString: string;
    options: IPerfOptions;
    summary: {
        [key: string]: any;
    };
    results?: ICaseResult[];
}
