import { IPerfCase, ICaseResult } from './interfaces';
/**
 * Predefined mixins for PerfCase
 */
export declare type PerfCaseConstructor<T = IPerfCase> = new (...args: any[]) => T;
/**
 * Runtime mixin for PerfCase.
 * Appends `averageRuntime` to summary.
 */
export declare function Runtime<TBase extends PerfCaseConstructor>(Base: TBase): {
    new (...args: any[]): {
        showRuntime(): this;
        showAverageRuntime(): this;
        summary: {
            [key: string]: any;
        };
        path: string[] | null;
        postEach(callback: (result: ICaseResult) => void | ICaseResult | null, perfCase?: any | undefined): any;
        postAll(callback: (results: ICaseResult[]) => void | ICaseResult[], perfCase?: any | undefined): any;
        run(parentPath: string[], forked: boolean): Promise<void>;
        getIndent(): string;
        type: import("./interfaces").PerfType;
        options?: import("./interfaces").IPerfOptions | undefined;
        name: string;
        callback(...args: any[]): void;
    };
} & TBase;
/**
 * Throughput mixin for PerfCase.
 * Appends `throughput` to each ICaseResult and `averageThroughput` to summary in MB/s.
 * Expects the payload as {payloadSize: some_value} in the result.returnValue.
 */
export declare function Throughput<TBase extends PerfCaseConstructor>(Base: TBase): {
    new (...args: any[]): {
        showThroughput(): this;
        showAverageThroughput(): this;
        summary: {
            [key: string]: any;
        };
        path: string[] | null;
        postEach(callback: (result: ICaseResult) => void | ICaseResult | null, perfCase?: any | undefined): any;
        postAll(callback: (results: ICaseResult[]) => void | ICaseResult[], perfCase?: any | undefined): any;
        run(parentPath: string[], forked: boolean): Promise<void>;
        getIndent(): string;
        type: import("./interfaces").PerfType;
        options?: import("./interfaces").IPerfOptions | undefined;
        name: string;
        callback(...args: any[]): void;
    };
} & TBase;
