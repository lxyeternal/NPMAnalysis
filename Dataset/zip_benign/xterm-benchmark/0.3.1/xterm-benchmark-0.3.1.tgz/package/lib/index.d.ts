/**
 * TODO:
 *    - timeout option
 *    - test cases
 *    - TimelineRunner options
 */
import { IPerfOptions, ICmdlineOverrides, PerfType, IPerfCase, ICaseResult, IEvalConfig, IEvalStats } from './interfaces';
export declare const DEFAULT_OPTIONS: IPerfOptions;
export declare const CMDLINE_OVERRIDES: ICmdlineOverrides;
export declare const LOGPATHS: string[];
export declare const EVAL_CONFIG: IEvalConfig;
/**
 * PerfCase
 *
 * Base class for simple performance cases in nodejs.
 * Wraps a callback for runtime measuring and postprocessing.
 *
 * Possible Options:
 *
 *    - repeat
 *      Repeat callback n times. Defaults to 1. Forked perf cases repeat the callback
 *      within one child (no additional processes created).
 *
 *    - fork
 *      Run perf case in single mode in a child process. This is especially useful
 *      to get a clean process env without pending GC calls or busy event loop.
 *      The process is created by child_process.fork and can be customized with
 *      `forkArgs``and `forkOptions`.
 *      The results are send to the parent process via `process.send`.
 *      Note: The parent process will wait for forked perf cases results,
 *      they are not run in parallel to avoid false numbers due to heavy system usage.
 *
 * For a single run the runtime is measured with a high resolution timer, the result is stored
 * in ICaseResult along with the return value and additional run information.
 *
 * Postprocessing
 * After a single run post processing or filtering be can hooked in with `.postEach(cb)`,
 * after all runs it can be done with `.postAll(cb)`. The callbacks either get a single
 * ICaseResult or ICaseResult[] as argument. The callbacks are chained, thus for
 * `.postEach(cb1).postEach(cb2)` `cb2` will see the changes of `cb1`.
 * For often used or more complicated post actions consider using a mixin with convenient methods.
 * Note: ICaseResult is not set immutable, thus it is possible to alter and even to delete properties.
 * Altering entries is ok as long the expectations of following processors are still met.
 * Deleting is dangerous and likely to break things. Adding entries should be preferred.
 * `.postEach` has one special case - returning `null` will drop the current result,
 * thus later `.postEach` and all `postAll` callbacks will not see it
 * (useful as opt-out for unwanted results).
 *
 * TODO: Further data aggregation...
 */
export declare class PerfCase implements IPerfCase {
    name: string;
    callback: (...args: any[]) => void;
    type: PerfType;
    private _single;
    private _all;
    options: IPerfOptions;
    results: ICaseResult[];
    summary: {
        [key: string]: any;
    };
    path: string[];
    constructor(name: string, callback: (...args: any[]) => void, opts?: IPerfOptions);
    postEach(callback: (result: ICaseResult, perfCase: this) => ICaseResult | void | null): this;
    postAll(callback: (results: ICaseResult[], perfCase: this) => ICaseResult[] | void): this;
    protected _processSingle(result: ICaseResult): Promise<void>;
    protected _processFinal(): Promise<void>;
    protected _reportResults(): Promise<void>;
    run(parentPath: string[], forked?: boolean): Promise<void>;
    getIndent(): string;
}
/**
 * Called once after entering a context.
 * Also applies to top level (a top level `before` will run when the file is entered).
 */
export declare function before(callback: () => void): void;
/**
 * Called for every children before entering the child.
 * Also applies to top level.
 */
export declare function beforeEach(callback: () => void): void;
/**
 * Called once before leaving a context.
 * Also applies to top level.
 */
export declare function after(callback: () => void): void;
/**
 * Called for every children after leaving it.
 * Also applies to top level.
 */
export declare function afterEach(callback: () => void): void;
/**
 * Spawn a new perf context.
 */
export declare function perfContext(name: string, callback: () => void): void;
/**
 * Some default ctors and types.
 */
export declare const RuntimeCase: {
    new (...args: any[]): {
        showRuntime(): any;
        showAverageRuntime(): any;
        summary: {
            [key: string]: any;
        };
        path: string[] | null;
        postEach(callback: (result: ICaseResult) => void | ICaseResult | null, perfCase?: any | undefined): any;
        postAll(callback: (results: ICaseResult[]) => void | ICaseResult[], perfCase?: any | undefined): any;
        run(parentPath: string[], forked: boolean): Promise<void>;
        getIndent(): string;
        type: PerfType;
        options?: IPerfOptions | undefined;
        name: string;
        callback(...args: any[]): void;
    };
} & typeof PerfCase;
export declare type RuntimeCaseType = InstanceType<typeof RuntimeCase>;
export declare const ThroughputRuntimeCase: {
    new (...args: any[]): {
        showThroughput(): any;
        showAverageThroughput(): any;
        summary: {
            [key: string]: any;
        };
        path: string[] | null;
        postEach(callback: (result: ICaseResult) => void | ICaseResult | null, perfCase?: any | undefined): any;
        postAll(callback: (results: ICaseResult[]) => void | ICaseResult[], perfCase?: any | undefined): any;
        run(parentPath: string[], forked: boolean): Promise<void>;
        getIndent(): string;
        type: PerfType;
        options?: IPerfOptions | undefined;
        name: string;
        callback(...args: any[]): void;
    };
} & {
    new (...args: any[]): {
        showRuntime(): any;
        showAverageRuntime(): any;
        summary: {
            [key: string]: any;
        };
        path: string[] | null;
        postEach(callback: (result: ICaseResult) => void | ICaseResult | null, perfCase?: any | undefined): any;
        postAll(callback: (results: ICaseResult[]) => void | ICaseResult[], perfCase?: any | undefined): any;
        run(parentPath: string[], forked: boolean): Promise<void>;
        getIndent(): string;
        type: PerfType;
        options?: IPerfOptions | undefined;
        name: string;
        callback(...args: any[]): void;
    };
} & typeof PerfCase;
export declare type ThroughputRuntimeCaseType = InstanceType<typeof ThroughputRuntimeCase>;
/**
 * Run context tree path.
 * Main entry for the cli.
 */
export declare function run(treePath: string[]): Promise<void>;
/**
 * Log context tree to console.
 */
export declare function showTree(filename: string): void;
/**
 * Show baseline stats to be accounted.
 */
export declare function showBaselineData(basePath: string): void;
/**
 * Eval run against baseline.
 */
export declare function evalRun(basePath: string, evalPath: string): IEvalStats;
