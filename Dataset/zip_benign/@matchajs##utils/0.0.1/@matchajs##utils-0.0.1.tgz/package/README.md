<!--
 * @Author: Mengfan zhaomengfan44@sina.com
 * @Date: 2023-03-22 18:12:23
 * @LastEditors: Mengfan zhaomengfan44@sina.com
 * @LastEditTime: 2023-03-22 18:12:24
 * @FilePath: /tools/packages/matcha-utils/README.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->

## 工具库

### 安装项目依赖

`yarn install @flx/utils`

### Utils

### RegexUtils

### UrlHelper

### NumberPrecision

NP.strip(num) // strip a number to nearest right number <br>
NP.plus(num1, num2, num3, ...) // addition, num + num2 + num3, two numbers is required at least. <br>
NP.minus(num1, num2, num3, ...) // subtraction, num1 - num2 - num3 <br>
NP.times(num1, num2, num3, ...) // multiplication, num1 _num2_ num3 <br>
NP.divide(num1, num2, num3, ...) // division, num1 / num2 / num3 <br>
NP.round(num, ratio) // round a number based on ratio <br>

NP.strip(0.09999999999999998); // = 0.1 <br>
NP.plus(0.1, 0.2); // = 0.3, not 0.30000000000000004 <br>
NP.plus(2.3, 2.4); // = 4.7, not 4.699999999999999 <br>
NP.minus(1.0, 0.9); // = 0.1, not 0.09999999999999998 <br>
NP.times(3, 0.3); // = 0.9, not 0.8999999999999999 <br>
NP.times(0.362, 100); // = 36.2, not 36.199999999999996 <br>
NP.divide(1.21, 1.1); // = 1.1, not 1.0999999999999999 <br>
NP.round(0.105, 2); // = 0.11, not 0.1 <br>
