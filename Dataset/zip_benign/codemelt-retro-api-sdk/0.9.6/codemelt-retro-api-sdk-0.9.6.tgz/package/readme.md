# Retro API sdk

This SDK is generated using Nestia for the Retro API.

## Instalation

`npm install codemelt-retro-api-sdk`

## Usage

First, import the SDK:

`import api from 'codemelt-retro-api-sdk';`

## Setting up the connection

Before making any API calls, set up the connection:

```typescript
import { IConnection } from 'codemelt-retro-api-sdk';

const connection: IConnection = {
  host: '<https://api.example.com>',
  headers: {
    'Authorization': 'Bearer YOUR_TOKEN_HERE'
  }
};
```

## Get home data

`const homeInfo = await api.functional.appInfo(connection);`

## Get Currency endpoints

`const retroTokenDetails = await api.functional.currency.retro.getRetroTokenDetails(connection);`
`const partnerCurrencies = await api.functional.currency.partners.getPartners(connection, 'ethereum');`

## Make a swap

```typescript
const swapDetails: api.functional.swap.getSwapData.Input = {
  tokenA: '0x...',
  tokenB: '0x...',
  chain: 'ethereum',
  amount: 1000000000000000000,
  sender: '0x...',
  recipient: '0x...',
  slippage: 0.5
};

const swapResult = await api.functional.swap.getSwapData(connection, swapDetails);
```

## Error handling

TBD
