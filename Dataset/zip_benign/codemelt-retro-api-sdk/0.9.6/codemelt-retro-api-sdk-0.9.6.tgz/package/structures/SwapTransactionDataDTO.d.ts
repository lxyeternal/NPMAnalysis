import { TransactionType } from "./TransactionType";
export type SwapTransactionDataDTO = {
    type: TransactionType.Swap | TransactionType.Approve | TransactionType.Unwrap | TransactionType.Wrap | TransactionType.Bridge | TransactionType.ApproveMulticall;
    data: string;
    order: number;
    value: string;
    gasAmount?: undefined | number;
    gasUsd?: undefined | number;
    to: string;
};
