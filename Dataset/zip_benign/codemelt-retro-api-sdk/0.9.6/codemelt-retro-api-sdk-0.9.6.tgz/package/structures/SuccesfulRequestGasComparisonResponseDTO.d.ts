import type { GasComparisonResponseDTO } from "./GasComparisonResponseDTO";
export type SuccesfulRequestGasComparisonResponseDTO = {
    message: string;
    data: GasComparisonResponseDTO;
    status: true;
};
