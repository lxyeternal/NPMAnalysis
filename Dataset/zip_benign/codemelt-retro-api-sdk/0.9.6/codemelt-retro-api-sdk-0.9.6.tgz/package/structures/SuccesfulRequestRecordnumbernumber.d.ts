import type { Recordnumbernumber } from "./Recordnumbernumber";
export type SuccesfulRequestRecordnumbernumber = {
    message: string;
    data: Recordnumbernumber;
    status: true;
};
