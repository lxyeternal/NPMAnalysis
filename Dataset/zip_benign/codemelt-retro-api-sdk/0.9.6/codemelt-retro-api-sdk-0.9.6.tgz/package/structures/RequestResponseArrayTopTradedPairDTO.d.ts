import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayTopTradedPairDTO } from "./SuccesfulRequestArrayTopTradedPairDTO";
export type RequestResponseArrayTopTradedPairDTO = FailedRequest | SuccesfulRequestArrayTopTradedPairDTO;
