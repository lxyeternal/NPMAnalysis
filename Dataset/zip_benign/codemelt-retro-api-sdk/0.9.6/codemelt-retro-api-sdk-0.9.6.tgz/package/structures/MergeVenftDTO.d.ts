export type MergeVenftDTO = {
    fromLockId: string;
    toLockId: string;
};
