import { BlockchainType } from "./BlockchainType";
import type { TransactionType } from "./TransactionType";
export type TransactionDataDTOchainTypeBlockchainType = {
    type: TransactionType;
    data: string;
    order: number;
    value: string;
    gasAmount?: undefined | number;
    gasUsd?: undefined | number;
    to: string;
    chainType: BlockchainType.Evm;
    rpcUrl: string;
    chainId: number;
};
