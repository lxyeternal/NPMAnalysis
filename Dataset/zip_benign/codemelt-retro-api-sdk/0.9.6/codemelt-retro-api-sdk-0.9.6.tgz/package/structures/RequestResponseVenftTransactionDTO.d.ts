import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestVenftTransactionDTO } from "./SuccesfulRequestVenftTransactionDTO";
export type RequestResponseVenftTransactionDTO = FailedRequest | SuccesfulRequestVenftTransactionDTO;
