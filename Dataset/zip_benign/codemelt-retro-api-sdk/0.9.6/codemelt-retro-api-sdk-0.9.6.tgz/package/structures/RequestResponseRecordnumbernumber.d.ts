import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestRecordnumbernumber } from "./SuccesfulRequestRecordnumbernumber";
export type RequestResponseRecordnumbernumber = FailedRequest | SuccesfulRequestRecordnumbernumber;
