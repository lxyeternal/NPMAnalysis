export type PoolStatsData = {
    date: string;
    totaltvlusd: number;
    totaltxcount: number;
    totalfeeusd: number;
    totalvolumeusd: number;
};
