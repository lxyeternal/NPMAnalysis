export type AlgebraDatabasePositionDTO = {
    tokenId: number;
    token0Tvl: string;
    token1Tvl: string;
    tvlUsd: number;
    collectedFeesToken0: number;
    collectedFeesToken1: number;
    collectedToken0: number;
    collectedToken1: number;
    uncollectedFeesToken0: number;
    uncollectedFeesToken1: number;
    liquidity: string;
    lastTimestampChecked: number;
    mintedTimestamp: number;
};
