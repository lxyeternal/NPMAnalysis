import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestany } from "./SuccesfulRequestany";
export type RequestResponseany = FailedRequest | SuccesfulRequestany;
