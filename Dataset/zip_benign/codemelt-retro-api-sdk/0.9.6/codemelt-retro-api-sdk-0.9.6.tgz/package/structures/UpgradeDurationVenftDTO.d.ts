import type { Minimum } from "typia/lib/tags/Minimum";
export type UpgradeDurationVenftDTO = {
    lockId: string;
    duration: number & Minimum<1>;
};
