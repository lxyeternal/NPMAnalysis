export type PlatformQuote = {
    gasFeeUsd: number;
};
