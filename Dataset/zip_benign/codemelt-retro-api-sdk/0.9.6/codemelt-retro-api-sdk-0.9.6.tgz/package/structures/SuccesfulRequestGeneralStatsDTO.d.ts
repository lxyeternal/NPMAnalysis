import type { GeneralStatsDTO } from "./GeneralStatsDTO";
export type SuccesfulRequestGeneralStatsDTO = {
    message: string;
    data: GeneralStatsDTO;
    status: true;
};
