import type { Type } from "typia/lib/tags/Type";
export type GasDetailsDTO = {
    tokenAId: number & Type<"uint32">;
    tokenBId: number & Type<"uint32">;
};
