import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayPoolStatsDTO } from "./SuccesfulRequestArrayPoolStatsDTO";
export type RequestResponseArrayPoolStatsDTO = FailedRequest | SuccesfulRequestArrayPoolStatsDTO;
