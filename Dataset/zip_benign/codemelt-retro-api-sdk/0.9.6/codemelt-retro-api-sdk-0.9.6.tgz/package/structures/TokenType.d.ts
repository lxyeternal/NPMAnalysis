export declare enum TokenType {
    Native = "native",
    Erc20 = "erc20",
    Wrapped = "wrapped",
    ZetaBridge = "zeta-bridge",
    Meme = "memecoin"
}
