export type WithdrawVenftDTO = {
    lockId: string;
};
