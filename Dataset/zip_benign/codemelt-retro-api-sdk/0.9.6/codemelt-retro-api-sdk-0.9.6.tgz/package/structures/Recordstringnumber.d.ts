/**
 * Construct a type with a set of properties K of type T
 */
export type Recordstringnumber = 
/**
 * Construct a type with a set of properties K of type T
 */
{
    [key: string]: number;
};
