export type GetTicksDTO = {
    networkName: string;
    poolAddress: string;
};
