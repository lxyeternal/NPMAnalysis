export type TopTradedPairDTO = {
    tokenAId: number;
    tokenBId: number;
    volume: number;
};
