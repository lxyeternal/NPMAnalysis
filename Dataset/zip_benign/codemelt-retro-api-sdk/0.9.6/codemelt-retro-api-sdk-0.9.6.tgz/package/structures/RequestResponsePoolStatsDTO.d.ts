import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestPoolStatsDTO } from "./SuccesfulRequestPoolStatsDTO";
export type RequestResponsePoolStatsDTO = FailedRequest | SuccesfulRequestPoolStatsDTO;
