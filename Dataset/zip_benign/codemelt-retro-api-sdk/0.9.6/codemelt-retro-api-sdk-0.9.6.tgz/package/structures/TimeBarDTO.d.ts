export type TimeBarDTO = {
    timestamp: number;
    value: number;
};
