export type AlgebraAddLiquidityDTO = {
    amountA: number;
    amountB: number;
    tokenAId: number;
    tokenBId: number;
    tickLower: number;
    tickUpper: number;
    networkName: string;
    recipient: string;
    creationTick: number;
};
