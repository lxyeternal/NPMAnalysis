import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestAlgebraUserPositionsDTO } from "./SuccesfulRequestAlgebraUserPositionsDTO";
export type RequestResponseAlgebraUserPositionsDTO = FailedRequest | SuccesfulRequestAlgebraUserPositionsDTO;
