export type TransferLiquidityDTO = {
    from: string;
    to: string;
    tokenId: string;
    networkName: string;
};
