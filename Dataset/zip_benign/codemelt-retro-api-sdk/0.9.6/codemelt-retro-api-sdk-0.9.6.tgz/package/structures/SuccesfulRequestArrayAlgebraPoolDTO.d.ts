import type { AlgebraPoolDTO } from "./AlgebraPoolDTO";
export type SuccesfulRequestArrayAlgebraPoolDTO = {
    message: string;
    data: AlgebraPoolDTO[];
    status: true;
};
