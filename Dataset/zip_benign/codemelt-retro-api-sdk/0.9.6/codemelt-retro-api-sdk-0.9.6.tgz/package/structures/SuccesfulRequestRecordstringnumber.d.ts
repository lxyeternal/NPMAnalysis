import type { Recordstringnumber } from "./Recordstringnumber";
export type SuccesfulRequestRecordstringnumber = {
    message: string;
    data: Recordstringnumber;
    status: true;
};
