import type { ChainCurrencyDTO } from "./ChainCurrencyDTO";
export type SuccesfulRequestArrayChainCurrencyDTO = {
    message: string;
    data: ChainCurrencyDTO[];
    status: true;
};
