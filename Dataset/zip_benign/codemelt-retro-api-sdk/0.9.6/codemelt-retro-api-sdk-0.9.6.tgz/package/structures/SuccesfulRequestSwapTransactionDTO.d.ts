import type { SwapTransactionDTO } from "./SwapTransactionDTO";
export type SuccesfulRequestSwapTransactionDTO = {
    message: string;
    data: SwapTransactionDTO;
    status: true;
};
