import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestQuoteDTO } from "./SuccesfulRequestQuoteDTO";
export type RequestResponseQuoteDTO = FailedRequest | SuccesfulRequestQuoteDTO;
