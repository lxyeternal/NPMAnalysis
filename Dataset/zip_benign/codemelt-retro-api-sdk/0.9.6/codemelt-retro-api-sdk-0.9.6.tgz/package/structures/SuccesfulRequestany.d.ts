export type SuccesfulRequestany = {
    message: string;
    data: any;
    status: true;
};
