"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenType = void 0;
var TokenType;
(function (TokenType) {
    TokenType["Native"] = "native";
    TokenType["Erc20"] = "erc20";
    TokenType["Wrapped"] = "wrapped";
    TokenType["ZetaBridge"] = "zeta-bridge";
    TokenType["Meme"] = "memecoin";
})(TokenType || (exports.TokenType = TokenType = {}));
