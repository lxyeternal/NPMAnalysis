import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayPriceChartDTO } from "./SuccesfulRequestArrayPriceChartDTO";
export type RequestResponseArrayPriceChartDTO = FailedRequest | SuccesfulRequestArrayPriceChartDTO;
