import type { VenftTransactionDTO } from "./VenftTransactionDTO";
export type SuccesfulRequestVenftTransactionDTO = {
    message: string;
    data: VenftTransactionDTO;
    status: true;
};
