import type { TimeframeType } from "./TimeframeType";
export type TimeSeriesDTO = {
    startTime: number;
    endTime: number;
    timeframeType: TimeframeType;
    poolIds: number[];
};
