export type UpgradeAmountVenftDTO = {
    lockId: string;
    amount: string;
    recipient: string;
    chainId: number;
};
