import type { ChainCurrency } from "./ChainCurrency";
import type { PriceChart } from "./PriceChart";
export type Currency = {
    name: string;
    relativeImagePath: string;
    ticker: string;
    chainCurrencies: ChainCurrency[];
    price: number;
    priceCharts: PriceChart[];
    coinGeckoId: null | string;
    id: number;
    createdAt: Date;
    updatedAt: Date;
};
