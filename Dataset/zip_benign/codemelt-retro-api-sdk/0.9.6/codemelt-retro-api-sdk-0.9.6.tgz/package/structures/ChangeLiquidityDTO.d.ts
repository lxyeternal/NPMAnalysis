export type ChangeLiquidityDTO = {
    liquidityPercent: number;
    tokenId: number;
    recipient: string;
    tokenAId: number;
    tokenBId: number;
    networkName: string;
    liquidity: string;
    tickLower: number;
    tickUpper: number;
    amountA: number;
    amountB: number;
};
