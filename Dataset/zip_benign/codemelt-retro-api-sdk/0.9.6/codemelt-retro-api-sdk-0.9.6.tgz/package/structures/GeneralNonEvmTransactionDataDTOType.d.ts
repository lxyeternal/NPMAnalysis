import { BlockchainType } from "./BlockchainType";
import type { TransactionType } from "./TransactionType";
export type GeneralNonEvmTransactionDataDTOType = {
    data: string;
    type: TransactionType;
    chainType: Exclude<BlockchainType, BlockchainType.Evm>;
    rpcUrl: string;
};
