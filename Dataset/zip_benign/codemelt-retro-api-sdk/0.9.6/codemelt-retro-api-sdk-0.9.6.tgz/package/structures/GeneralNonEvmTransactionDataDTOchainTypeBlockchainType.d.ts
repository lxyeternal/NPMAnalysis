import type { TransactionType } from "./TransactionType";
export declare namespace GeneralNonEvmTransactionDataDTOchainTypeBlockchainType {
    namespace SolanaBlockchainType {
        type CosmosrpcUrlstring = {
            data: string;
            type: TransactionType;
            chainType: "solana" | "cosmos";
            rpcUrl: string;
        };
    }
}
