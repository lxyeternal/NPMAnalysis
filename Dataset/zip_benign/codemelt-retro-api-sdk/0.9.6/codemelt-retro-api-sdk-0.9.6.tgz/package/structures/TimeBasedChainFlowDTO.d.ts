export type TimeBasedChainFlowDTO = {
    startTime: number;
    endTime: number;
};
