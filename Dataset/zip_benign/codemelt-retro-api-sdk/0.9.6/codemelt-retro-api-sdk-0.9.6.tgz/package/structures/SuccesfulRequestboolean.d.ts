export type SuccesfulRequestboolean = {
    message: string;
    data: boolean;
    status: true;
};
