import type { TimeSeriesResponseDTO } from "./TimeSeriesResponseDTO";
export type SuccesfulRequestArrayTimeSeriesResponseDTO = {
    message: string;
    data: TimeSeriesResponseDTO[];
    status: true;
};
