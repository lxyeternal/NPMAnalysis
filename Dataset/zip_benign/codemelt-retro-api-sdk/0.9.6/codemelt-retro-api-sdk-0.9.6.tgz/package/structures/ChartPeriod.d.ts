export type ChartPeriod = "day" | "week" | "month";
