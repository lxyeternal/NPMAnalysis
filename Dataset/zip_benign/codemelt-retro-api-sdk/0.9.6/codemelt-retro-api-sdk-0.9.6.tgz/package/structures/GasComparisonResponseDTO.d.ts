import type { PlatformQuote } from "./PlatformQuote";
export type GasComparisonResponseDTO = {
    thorChain?: undefined | PlatformQuote;
    chainFlip?: undefined | PlatformQuote;
    eddyFinance?: undefined | PlatformQuote;
};
