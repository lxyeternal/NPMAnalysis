import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayAlgebraPositionDTO } from "./SuccesfulRequestArrayAlgebraPositionDTO";
export type RequestResponseArrayAlgebraPositionDTO = FailedRequest | SuccesfulRequestArrayAlgebraPositionDTO;
