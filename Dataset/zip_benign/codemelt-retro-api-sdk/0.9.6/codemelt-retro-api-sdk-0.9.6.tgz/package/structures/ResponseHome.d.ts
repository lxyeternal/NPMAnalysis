export type ResponseHome = {
    name?: undefined | string;
};
