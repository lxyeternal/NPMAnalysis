import type { Format } from "typia/lib/tags/Format";
export type FileDTO = {
    id: number;
    path: string;
    createdAt: string & Format<"date-time">;
    updatedAt: string & Format<"date-time">;
};
