import type { AlgebraPositionDTO } from "./AlgebraPositionDTO";
export type SuccesfulRequestArrayAlgebraPositionDTO = {
    message: string;
    data: AlgebraPositionDTO[];
    status: true;
};
