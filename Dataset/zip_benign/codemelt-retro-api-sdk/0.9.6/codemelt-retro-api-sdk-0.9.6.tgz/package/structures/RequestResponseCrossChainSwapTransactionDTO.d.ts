import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestCrossChainSwapTransactionDTO } from "./SuccesfulRequestCrossChainSwapTransactionDTO";
export type RequestResponseCrossChainSwapTransactionDTO = FailedRequest | SuccesfulRequestCrossChainSwapTransactionDTO;
