import type { Network } from "./Network";
export type EternalFarming = {
    id: number;
    hash: string;
    nativeAmount: number;
    lastApr: number;
    maxApr: number;
    network: Network;
};
