import type { CrosschainFlowDTO } from "./CrosschainFlowDTO";
export type SuccesfulRequestArrayCrosschainFlowDTO = {
    message: string;
    data: CrosschainFlowDTO[];
    status: true;
};
