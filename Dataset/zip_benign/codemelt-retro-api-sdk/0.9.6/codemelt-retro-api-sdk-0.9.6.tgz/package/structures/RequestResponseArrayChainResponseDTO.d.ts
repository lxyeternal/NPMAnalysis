import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayChainResponseDTO } from "./SuccesfulRequestArrayChainResponseDTO";
export type RequestResponseArrayChainResponseDTO = FailedRequest | SuccesfulRequestArrayChainResponseDTO;
