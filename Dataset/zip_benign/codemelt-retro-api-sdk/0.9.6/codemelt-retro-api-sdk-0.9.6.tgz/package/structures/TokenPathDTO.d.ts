export type TokenPathDTO = {
    tokenA: {
        id: number;
        address: string;
        symbol: string;
    };
    tokenB: {
        id: number;
        address: string;
        symbol: string;
    };
    pool: {
        id: number;
        address: string;
        title: string;
    };
};
