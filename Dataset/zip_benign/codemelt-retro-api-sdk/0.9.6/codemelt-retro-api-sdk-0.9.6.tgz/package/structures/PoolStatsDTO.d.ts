import type { AggregatedTotals } from "./AggregatedTotals";
import type { PoolStatsData } from "./PoolStatsData";
export type PoolStatsDTO = {
    totals: AggregatedTotals;
    data: PoolStatsData[];
};
