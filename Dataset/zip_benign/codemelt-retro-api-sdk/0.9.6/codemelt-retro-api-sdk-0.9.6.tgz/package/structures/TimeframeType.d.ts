export type TimeframeType = "oneMinute" | "oneHour" | "oneDay" | "oneWeek" | "oneMonth";
