export type AggregatedTotals = {
    aggregatedTvlUsd: number;
    aggregatedTxCount: number;
    aggregatedFeeUsd: number;
    aggregatedVolumeUsd: number;
};
