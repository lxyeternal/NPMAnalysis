export type ResetVotesDTO = {
    lockId: string;
};
