import type { Pattern } from "typia/lib/tags/Pattern";
export type CreateVenftDTO = {
    amount: string;
    duration: number;
    recipient: string & Pattern<"^0x[a-fA-F0-9]{40}$">;
    chainId: number;
};
