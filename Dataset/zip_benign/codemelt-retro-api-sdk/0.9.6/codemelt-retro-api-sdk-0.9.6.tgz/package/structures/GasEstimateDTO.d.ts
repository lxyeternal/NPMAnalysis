export type GasEstimateDTO = {
    raw: string;
    formatted: number;
};
