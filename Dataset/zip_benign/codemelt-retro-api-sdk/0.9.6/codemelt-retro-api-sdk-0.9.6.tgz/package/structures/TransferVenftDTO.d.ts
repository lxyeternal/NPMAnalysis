export type TransferVenftDTO = {
    lockId: string;
    recipient: string;
    from: string;
};
