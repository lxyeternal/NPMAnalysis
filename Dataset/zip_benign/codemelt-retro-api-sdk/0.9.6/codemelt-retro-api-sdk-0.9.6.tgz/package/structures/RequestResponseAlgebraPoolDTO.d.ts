import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestAlgebraPoolDTO } from "./SuccesfulRequestAlgebraPoolDTO";
export type RequestResponseAlgebraPoolDTO = FailedRequest | SuccesfulRequestAlgebraPoolDTO;
