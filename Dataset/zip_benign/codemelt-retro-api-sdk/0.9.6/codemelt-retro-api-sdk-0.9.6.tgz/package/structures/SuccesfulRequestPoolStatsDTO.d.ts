import type { PoolStatsDTO } from "./PoolStatsDTO";
export type SuccesfulRequestPoolStatsDTO = {
    message: string;
    data: PoolStatsDTO;
    status: true;
};
