import type { TopTradedPairDTO } from "./TopTradedPairDTO";
export type SuccesfulRequestArrayTopTradedPairDTO = {
    message: string;
    data: TopTradedPairDTO[];
    status: true;
};
