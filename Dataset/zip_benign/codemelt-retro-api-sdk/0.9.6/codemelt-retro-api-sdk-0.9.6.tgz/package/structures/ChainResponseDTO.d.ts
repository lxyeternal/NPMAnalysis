import type { Format } from "typia/lib/tags/Format";
import type { BlockchainType } from "./BlockchainType";
import type { ChainCurrencyDTO } from "./ChainCurrencyDTO";
export type ChainResponseDTO = {
    id: number;
    name: string;
    kyberSlug: string;
    chainId: number;
    messageReceiver: null | string;
    status: "disabled" | "active" | "not-started";
    type: BlockchainType;
    chainCurrencies: ChainCurrencyDTO[];
    createdAt: string & Format<"date-time">;
    updatedAt: string & Format<"date-time">;
};
