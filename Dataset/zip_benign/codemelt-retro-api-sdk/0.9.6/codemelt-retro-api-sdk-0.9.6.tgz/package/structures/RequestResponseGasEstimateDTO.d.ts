import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestGasEstimateDTO } from "./SuccesfulRequestGasEstimateDTO";
export type RequestResponseGasEstimateDTO = FailedRequest | SuccesfulRequestGasEstimateDTO;
