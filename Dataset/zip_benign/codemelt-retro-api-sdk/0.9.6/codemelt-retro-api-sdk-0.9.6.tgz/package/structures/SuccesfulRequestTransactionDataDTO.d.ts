import type { TransactionDataDTO } from "./TransactionDataDTO";
export type SuccesfulRequestTransactionDataDTO = {
    message: string;
    data: TransactionDataDTO;
    status: true;
};
