import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestboolean } from "./SuccesfulRequestboolean";
export type RequestResponseboolean = FailedRequest | SuccesfulRequestboolean;
