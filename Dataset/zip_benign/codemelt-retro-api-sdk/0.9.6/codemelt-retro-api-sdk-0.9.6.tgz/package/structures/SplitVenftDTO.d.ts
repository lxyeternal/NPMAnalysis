export type SplitVenftDTO = {
    lockId: string;
    weights: string[];
};
