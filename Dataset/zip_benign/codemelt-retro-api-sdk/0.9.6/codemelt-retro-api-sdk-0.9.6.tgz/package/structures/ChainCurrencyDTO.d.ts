import type { Format } from "typia/lib/tags/Format";
import type { CurrencyDTO } from "./CurrencyDTO";
import type { OmitChainResponseDTOchainCurrencies } from "./OmitChainResponseDTOchainCurrencies";
import type { TokenType } from "./TokenType";
export type ChainCurrencyDTO = {
    id: number;
    address: string;
    chainId: number;
    currencyId: number;
    chain: OmitChainResponseDTOchainCurrencies;
    type: TokenType;
    parentId: null | number;
    decimals: number;
    currency: CurrencyDTO;
    createdAt: string & Format<"date-time">;
    updatedAt: string & Format<"date-time">;
};
