/**
 * Construct a type with a set of properties K of type T
 */
export type Recordnumbernumber = 
/**
 * Construct a type with a set of properties K of type T
 */
{
    [key: number]: number;
};
