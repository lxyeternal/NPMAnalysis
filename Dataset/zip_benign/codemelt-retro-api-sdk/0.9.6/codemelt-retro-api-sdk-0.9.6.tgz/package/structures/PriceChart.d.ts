import type { Currency } from "./Currency";
export type PriceChart = {
    timestamp: number;
    price: number;
    currencyId: number;
    currency: Currency;
    id: number;
    createdAt: Date;
    updatedAt: Date;
};
