export type WhitelistNewPoolDTO = {
    poolAddress: string;
    tokenAAddress: string;
    tokenBAddress: string;
};
