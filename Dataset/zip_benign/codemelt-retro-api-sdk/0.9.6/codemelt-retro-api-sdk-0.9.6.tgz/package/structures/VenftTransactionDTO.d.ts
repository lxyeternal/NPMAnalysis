import type { TransactionDataDTO } from "./TransactionDataDTO";
export type VenftTransactionDTO = {
    transactions: TransactionDataDTO[];
};
