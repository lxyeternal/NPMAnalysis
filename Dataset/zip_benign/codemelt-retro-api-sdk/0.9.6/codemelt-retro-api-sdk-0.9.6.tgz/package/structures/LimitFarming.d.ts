import type { Network } from "./Network";
export type LimitFarming = {
    id: number;
    hash: string;
    nativeAmount: number;
    lastApr: number;
    network: Network;
};
