import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayTimeSeriesResponseDTO } from "./SuccesfulRequestArrayTimeSeriesResponseDTO";
export type RequestResponseArrayTimeSeriesResponseDTO = FailedRequest | SuccesfulRequestArrayTimeSeriesResponseDTO;
