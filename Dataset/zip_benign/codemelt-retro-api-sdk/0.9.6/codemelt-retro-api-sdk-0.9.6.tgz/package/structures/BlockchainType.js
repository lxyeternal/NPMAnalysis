"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BlockchainType = void 0;
var BlockchainType;
(function (BlockchainType) {
    BlockchainType["Evm"] = "evm";
    BlockchainType["Solana"] = "solana";
    BlockchainType["Btc"] = "btc";
    BlockchainType["Cosmos"] = "cosmos";
})(BlockchainType || (exports.BlockchainType = BlockchainType = {}));
