import type { BitcoinTransactionDTO } from "./BitcoinTransactionDTO";
import { GeneralNonEvmTransactionDataDTOType } from "./GeneralNonEvmTransactionDataDTOType";
import { TransactionDataDTOchainTypeBlockchainType } from "./TransactionDataDTOchainTypeBlockchainType";
export type CrossChainTransactionDataDTO = TransactionDataDTOchainTypeBlockchainType | GeneralNonEvmTransactionDataDTOType | BitcoinTransactionDTO;
