import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestGasComparisonResponseDTO } from "./SuccesfulRequestGasComparisonResponseDTO";
export type RequestResponseGasComparisonResponseDTO = FailedRequest | SuccesfulRequestGasComparisonResponseDTO;
