import type { Pool } from "./Pool";
export type Tick = {
    priceTokenA: string;
    priceTokenB: string;
    tickValue: number;
    volumeTokenA: string;
    volumeTokenB: string;
    liquidity: bigint;
    pool: Pool;
    poolId: number;
    id: number;
    createdAt: Date;
    updatedAt: Date;
};
