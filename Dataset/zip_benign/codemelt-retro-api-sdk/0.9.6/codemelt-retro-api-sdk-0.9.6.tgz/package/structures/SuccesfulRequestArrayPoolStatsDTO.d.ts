import type { PoolStatsDTO } from "./PoolStatsDTO";
export type SuccesfulRequestArrayPoolStatsDTO = {
    message: string;
    data: PoolStatsDTO[];
    status: true;
};
