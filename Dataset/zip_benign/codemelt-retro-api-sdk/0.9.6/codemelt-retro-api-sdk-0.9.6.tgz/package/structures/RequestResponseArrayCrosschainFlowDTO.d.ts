import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayCrosschainFlowDTO } from "./SuccesfulRequestArrayCrosschainFlowDTO";
export type RequestResponseArrayCrosschainFlowDTO = FailedRequest | SuccesfulRequestArrayCrosschainFlowDTO;
