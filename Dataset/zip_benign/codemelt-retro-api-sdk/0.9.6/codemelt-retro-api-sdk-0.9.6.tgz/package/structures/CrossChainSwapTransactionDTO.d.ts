import type { CrossChainTransactionDataDTO } from "./CrossChainTransactionDataDTO";
export type CrossChainSwapTransactionDTO = {
    path: string[];
    transactions: CrossChainTransactionDataDTO[];
    dexToUse: string;
    minAmountOut: number;
    expectedAmountOut: number;
    networkFeeUsd: number;
    priceImpact: number;
};
