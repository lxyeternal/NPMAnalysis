export type VoteWeightDTO = {
    value: string;
    address: string;
};
