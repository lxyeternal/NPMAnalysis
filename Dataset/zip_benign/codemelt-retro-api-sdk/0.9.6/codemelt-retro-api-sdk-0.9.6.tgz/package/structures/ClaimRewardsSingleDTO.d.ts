export type ClaimRewardsSingleDTO = {
    tokenId: number;
    recipient: string;
    networkName: string;
};
