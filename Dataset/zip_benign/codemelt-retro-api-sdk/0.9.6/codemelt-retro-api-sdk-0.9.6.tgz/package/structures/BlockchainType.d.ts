export declare enum BlockchainType {
    Evm = "evm",
    Solana = "solana",
    Btc = "btc",
    Cosmos = "cosmos"
}
