import type { TransactionDataDTO } from "./TransactionDataDTO";
export type LiquidityTransactionDTO = {
    transactions: TransactionDataDTO[];
    providerType: "retro" | "algebra" | "ichi" | "gamma" | "steer";
};
