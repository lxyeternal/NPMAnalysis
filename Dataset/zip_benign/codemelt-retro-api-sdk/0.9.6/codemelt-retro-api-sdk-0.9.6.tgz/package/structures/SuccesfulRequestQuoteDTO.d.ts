import type { QuoteDTO } from "./QuoteDTO";
export type SuccesfulRequestQuoteDTO = {
    message: string;
    data: QuoteDTO;
    status: true;
};
