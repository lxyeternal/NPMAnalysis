import type { LiquidityTransactionDTO } from "./LiquidityTransactionDTO";
export type SuccesfulRequestLiquidityTransactionDTO = {
    message: string;
    data: LiquidityTransactionDTO;
    status: true;
};
