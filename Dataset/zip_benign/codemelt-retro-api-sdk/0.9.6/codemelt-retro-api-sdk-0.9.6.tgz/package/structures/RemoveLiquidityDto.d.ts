export type RemoveLiquidityDto = {
    chainName: string;
    tokenId: string;
    tokenAId: number;
    tokenBId: number;
    liquidity: string;
    tickLower: number;
    tickUpper: number;
    recipient: string;
};
