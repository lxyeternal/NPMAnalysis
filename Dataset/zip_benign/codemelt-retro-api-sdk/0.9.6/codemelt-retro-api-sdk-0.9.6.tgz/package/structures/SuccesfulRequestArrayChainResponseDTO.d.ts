import type { ChainResponseDTO } from "./ChainResponseDTO";
export type SuccesfulRequestArrayChainResponseDTO = {
    message: string;
    data: ChainResponseDTO[];
    status: true;
};
