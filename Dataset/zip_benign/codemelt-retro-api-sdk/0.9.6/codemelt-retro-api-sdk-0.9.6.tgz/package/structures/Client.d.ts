import type { Chain } from "./Chain";
export type Client = {
    name: string;
    isActive: boolean;
    apiKey: string;
    enabledDomains: string[];
    maxRequests: number;
    windowMs: number;
    chains: Chain[];
    id: number;
    createdAt: Date;
    updatedAt: Date;
};
