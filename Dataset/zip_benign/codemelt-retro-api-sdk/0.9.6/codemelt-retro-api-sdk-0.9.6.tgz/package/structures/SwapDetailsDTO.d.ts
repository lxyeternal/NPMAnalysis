import type { Default } from "typia/lib/tags/Default";
import type { Minimum } from "typia/lib/tags/Minimum";
import type { Pattern } from "typia/lib/tags/Pattern";
import type { Type } from "typia/lib/tags/Type";
export type SwapDetailsDTO = {
    tokenAId: number & Type<"uint32">;
    tokenBId: number & Type<"uint32">;
    slippage: number & Default<50> & Minimum<1>;
    amount: number & Type<"double">;
    sender: string & Pattern<"^0x[a-fA-F0-9]{40}|^[A-HJ-NP-Za-km-z1-9]*|^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$">;
    recipient: string & Pattern<"^0x[a-fA-F0-9]{40}|^[A-HJ-NP-Za-km-z1-9]*|^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$">;
    skipNonSwapTransactions?: undefined | boolean;
};
