import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestSwapTransactionDTO } from "./SuccesfulRequestSwapTransactionDTO";
export type RequestResponseSwapTransactionDTO = FailedRequest | SuccesfulRequestSwapTransactionDTO;
