export type AlgebraPositionDTO = {
    nonce: string;
    liquidity: string;
    tickLower: string;
    fee: number;
    tickUpper: string;
    feeGrowthInside0LastX128: string;
    feeGrowthInside1LastX128: string;
    feeAmount0: string;
    feeAmount1: string;
    tokensOwed0: string;
    tokensOwed1: string;
    token0: string;
    token1: string;
    tokenId: string;
};
