import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayChainCurrencyDTO } from "./SuccesfulRequestArrayChainCurrencyDTO";
export type RequestResponseArrayChainCurrencyDTO = FailedRequest | SuccesfulRequestArrayChainCurrencyDTO;
