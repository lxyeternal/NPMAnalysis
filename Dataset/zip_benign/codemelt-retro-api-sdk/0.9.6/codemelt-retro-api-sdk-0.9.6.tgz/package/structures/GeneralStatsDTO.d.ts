export type GeneralStatsDTO = {
    volume: number;
    tvl: number;
    fee: number;
    tx: number;
};
