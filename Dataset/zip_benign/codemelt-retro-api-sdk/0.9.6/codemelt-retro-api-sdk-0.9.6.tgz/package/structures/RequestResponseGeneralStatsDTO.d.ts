import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestGeneralStatsDTO } from "./SuccesfulRequestGeneralStatsDTO";
export type RequestResponseGeneralStatsDTO = FailedRequest | SuccesfulRequestGeneralStatsDTO;
