import type { Format } from "typia/lib/tags/Format";
import type { FileDTO } from "./FileDTO";
export type CurrencyDTO = {
    id: number;
    name: string;
    ticker: string;
    price?: null | undefined | number;
    relativeImagePath: string;
    image: null | FileDTO;
    imageId: null | number;
    createdAt: string & Format<"date-time">;
    updatedAt: string & Format<"date-time">;
};
