import type { TimeBarDTO } from "./TimeBarDTO";
export type TimeSeriesResponseDTO = {
    bars: TimeBarDTO[];
    poolId: null | number;
};
