import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestTransactionDataDTO } from "./SuccesfulRequestTransactionDataDTO";
export type RequestResponseTransactionDataDTO = FailedRequest | SuccesfulRequestTransactionDataDTO;
