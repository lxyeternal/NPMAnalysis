import type { VoteWeightDTO } from "./VoteWeightDTO";
export type ExecuteVoteDTO = {
    weights: VoteWeightDTO[];
    lockId: number;
};
