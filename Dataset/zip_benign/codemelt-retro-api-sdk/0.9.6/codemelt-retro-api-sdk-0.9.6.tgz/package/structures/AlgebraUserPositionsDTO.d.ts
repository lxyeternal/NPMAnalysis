import type { AlgebraDatabasePositionDTO } from "./AlgebraDatabasePositionDTO";
import type { AlgebraPositionDTO } from "./AlgebraPositionDTO";
export type AlgebraUserPositionsDTO = {
    positions: AlgebraDatabasePositionDTO[];
    emissions: AlgebraPositionDTO[];
};
