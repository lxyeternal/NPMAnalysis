import type { GasEstimateDTO } from "./GasEstimateDTO";
export type SuccesfulRequestGasEstimateDTO = {
    message: string;
    data: GasEstimateDTO;
    status: true;
};
