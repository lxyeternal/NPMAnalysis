export type CrosschainFlowDTO = {
    sourceChainId: number;
    destinationChainId: number;
    volume: number;
};
