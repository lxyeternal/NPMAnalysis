import type { CrossChainSwapTransactionDTO } from "./CrossChainSwapTransactionDTO";
export type SuccesfulRequestCrossChainSwapTransactionDTO = {
    message: string;
    data: CrossChainSwapTransactionDTO;
    status: true;
};
