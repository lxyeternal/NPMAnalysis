import type { AlgebraPoolDTO } from "./AlgebraPoolDTO";
export type SuccesfulRequestAlgebraPoolDTO = {
    message: string;
    data: AlgebraPoolDTO;
    status: true;
};
