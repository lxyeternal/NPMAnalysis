import type { TransactionType } from "./TransactionType";
export type TransactionDataDTO = {
    type: TransactionType;
    data: string;
    order: number;
    value: string;
    gasAmount?: undefined | number;
    gasUsd?: undefined | number;
    to: string;
};
