import type { Format } from "typia/lib/tags/Format";
import type { BlockchainType } from "./BlockchainType";
/**
 * Construct a type with the properties of T except for those in type K.
 */
export type OmitChainResponseDTOchainCurrencies = 
/**
 * Construct a type with the properties of T except for those in type K.
 */
{
    id: number;
    name: string;
    kyberSlug: string;
    chainId: number;
    messageReceiver: null | string;
    status: "disabled" | "active" | "not-started";
    type: BlockchainType;
    createdAt: string & Format<"date-time">;
    updatedAt: string & Format<"date-time">;
};
