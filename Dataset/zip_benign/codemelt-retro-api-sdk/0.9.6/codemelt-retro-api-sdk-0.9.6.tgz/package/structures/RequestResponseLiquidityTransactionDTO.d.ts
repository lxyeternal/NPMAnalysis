import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestLiquidityTransactionDTO } from "./SuccesfulRequestLiquidityTransactionDTO";
export type RequestResponseLiquidityTransactionDTO = FailedRequest | SuccesfulRequestLiquidityTransactionDTO;
