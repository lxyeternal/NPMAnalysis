import type { AlgebraUserPositionsDTO } from "./AlgebraUserPositionsDTO";
export type SuccesfulRequestAlgebraUserPositionsDTO = {
    message: string;
    data: AlgebraUserPositionsDTO;
    status: true;
};
