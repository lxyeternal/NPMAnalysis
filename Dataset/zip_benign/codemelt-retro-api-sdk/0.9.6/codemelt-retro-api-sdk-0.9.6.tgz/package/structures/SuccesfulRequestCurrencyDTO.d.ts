import type { CurrencyDTO } from "./CurrencyDTO";
export type SuccesfulRequestCurrencyDTO = {
    message: string;
    data: CurrencyDTO;
    status: true;
};
