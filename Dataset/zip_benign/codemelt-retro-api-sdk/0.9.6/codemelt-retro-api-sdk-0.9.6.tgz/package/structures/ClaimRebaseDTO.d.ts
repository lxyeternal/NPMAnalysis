export type ClaimRebaseDTO = {
    lockIds: string[];
};
