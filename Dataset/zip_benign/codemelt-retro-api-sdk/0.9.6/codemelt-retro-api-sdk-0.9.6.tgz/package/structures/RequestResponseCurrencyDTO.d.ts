import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestCurrencyDTO } from "./SuccesfulRequestCurrencyDTO";
export type RequestResponseCurrencyDTO = FailedRequest | SuccesfulRequestCurrencyDTO;
