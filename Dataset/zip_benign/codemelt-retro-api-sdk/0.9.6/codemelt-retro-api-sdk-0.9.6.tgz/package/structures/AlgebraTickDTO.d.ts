export type AlgebraTickDTO = {
    tickValue: number;
    priceTokenA: string;
    priceTokenB: string;
    volumeTokenA: string;
    volumeTokenB: string;
    liquidity: string;
    poolId: number;
};
