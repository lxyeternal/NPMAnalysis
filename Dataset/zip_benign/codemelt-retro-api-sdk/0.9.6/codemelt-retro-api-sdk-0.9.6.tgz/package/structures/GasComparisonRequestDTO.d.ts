export type GasComparisonRequestDTO = {
    fromAssetId: number;
    toAssetId: number;
    amount: string;
};
