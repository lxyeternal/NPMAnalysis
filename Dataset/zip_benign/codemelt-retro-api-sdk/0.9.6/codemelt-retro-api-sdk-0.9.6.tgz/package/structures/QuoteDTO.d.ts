import type { TokenPathDTO } from "./TokenPathDTO";
export type QuoteDTO = {
    expectedAmount: {
        raw: string;
        formatted: number;
    };
    minAmount: {
        raw: string;
        formatted: number;
    };
    path: TokenPathDTO[];
    priceImpact: number;
    networkFeeUsd: number;
};
