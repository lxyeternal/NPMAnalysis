import type { PriceChartDTO } from "./PriceChartDTO";
export type SuccesfulRequestArrayPriceChartDTO = {
    message: string;
    data: PriceChartDTO[];
    status: true;
};
