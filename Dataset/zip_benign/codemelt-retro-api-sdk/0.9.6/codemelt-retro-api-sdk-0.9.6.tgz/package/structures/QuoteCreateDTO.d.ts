import type { Default } from "typia/lib/tags/Default";
import type { Minimum } from "typia/lib/tags/Minimum";
import type { Type } from "typia/lib/tags/Type";
export type QuoteCreateDTO = {
    tokenAId: number & Type<"uint32">;
    tokenBId: number & Type<"uint32">;
    slippage: number & Default<50> & Minimum<1>;
    amount: number & Type<"double">;
};
