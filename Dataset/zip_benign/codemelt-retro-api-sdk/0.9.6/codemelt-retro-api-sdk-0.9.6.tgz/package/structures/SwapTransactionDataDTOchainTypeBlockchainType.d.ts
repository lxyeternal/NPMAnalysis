export declare namespace SwapTransactionDataDTOchainTypeBlockchainType {
    type EvmrpcUrlstringchainIdnumber = {
        type: "swap" | "approve" | "wrap" | "unwrap" | "bridge" | "approve-multicall";
        data: string;
        order: number;
        value: string;
        gasAmount?: undefined | number;
        gasUsd?: undefined | number;
        to: string;
        chainType: "evm";
        rpcUrl: string;
        chainId: number;
    };
}
