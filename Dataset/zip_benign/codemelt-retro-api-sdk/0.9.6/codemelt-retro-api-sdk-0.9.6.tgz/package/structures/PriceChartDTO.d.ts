export type PriceChartDTO = {
    timestamp: number;
    price: number;
};
