import { BlockchainType } from "./BlockchainType";
import { TransactionType } from "./TransactionType";
export type BitcoinTransactionDTO = {
    memo: string;
    value: string;
    to: string;
    chainType: BlockchainType.Btc;
    type: TransactionType.Swap | TransactionType.Bridge;
};
