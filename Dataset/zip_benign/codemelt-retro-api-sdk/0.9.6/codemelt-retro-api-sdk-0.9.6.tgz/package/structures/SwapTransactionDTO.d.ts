import type { SwapTransactionDataDTO } from "./SwapTransactionDataDTO";
export type SwapTransactionDTO = {
    path: string[];
    transactions: SwapTransactionDataDTO[];
    dexToUse: string;
    minAmountOut: number;
};
