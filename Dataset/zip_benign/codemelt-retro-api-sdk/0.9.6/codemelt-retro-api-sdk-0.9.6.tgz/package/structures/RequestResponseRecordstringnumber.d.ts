import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestRecordstringnumber } from "./SuccesfulRequestRecordstringnumber";
export type RequestResponseRecordstringnumber = FailedRequest | SuccesfulRequestRecordstringnumber;
