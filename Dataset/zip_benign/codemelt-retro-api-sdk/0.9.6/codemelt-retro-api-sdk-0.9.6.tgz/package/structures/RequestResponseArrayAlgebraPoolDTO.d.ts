import type { FailedRequest } from "./FailedRequest";
import type { SuccesfulRequestArrayAlgebraPoolDTO } from "./SuccesfulRequestArrayAlgebraPoolDTO";
export type RequestResponseArrayAlgebraPoolDTO = FailedRequest | SuccesfulRequestArrayAlgebraPoolDTO;
