import { FFmpegShellCommand } from './types';
export declare function executeShellCommands(shellCommands: Array<FFmpegShellCommand>, parallel: number, debug: boolean): Promise<void>;
//# sourceMappingURL=execute-shell-commands.d.ts.map