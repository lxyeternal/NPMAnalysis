import { FFmpegShellCommand, Options } from '../types';
export declare function createFFmpegShellCommands(globPatterns: Array<string>, outputDirectory: string, options: Omit<Options, 'debug' | 'parallel' | 'output'>): Promise<Array<FFmpegShellCommand>>;
//# sourceMappingURL=create-ffmpeg-shell-commands.d.ts.map