export declare const defaultOptions: {
    crop: null;
    format: null;
    fps: null;
    resize: null;
    reverse: boolean;
    rotate: null;
    speed: null;
    trim: null;
    volume: null;
};
//# sourceMappingURL=default-options.d.ts.map