import { RotateOption } from '../../../types';
export declare function mapRotateOptionToVideoFilter(rotate: RotateOption): string;
//# sourceMappingURL=map-rotate-option-to-video-filter.d.ts.map