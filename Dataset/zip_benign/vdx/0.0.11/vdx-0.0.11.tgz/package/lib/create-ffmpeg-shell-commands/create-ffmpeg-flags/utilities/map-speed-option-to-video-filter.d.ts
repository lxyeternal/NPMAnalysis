export declare function mapSpeedOptionToVideoFilter(speed: number): string;
//# sourceMappingURL=map-speed-option-to-video-filter.d.ts.map