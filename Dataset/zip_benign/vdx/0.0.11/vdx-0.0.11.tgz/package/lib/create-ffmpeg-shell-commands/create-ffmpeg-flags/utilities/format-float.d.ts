export declare function formatFloat(value: number): string;
//# sourceMappingURL=format-float.d.ts.map