export declare function mapSpeedOptionToAudioFilter(speed: number): string;
//# sourceMappingURL=map-speed-option-to-audio-filter.d.ts.map