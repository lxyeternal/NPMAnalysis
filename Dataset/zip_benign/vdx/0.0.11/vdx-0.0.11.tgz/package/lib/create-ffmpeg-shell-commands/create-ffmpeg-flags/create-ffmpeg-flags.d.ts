import { FFmpegFlags, Options } from '../../types';
export declare function createFFmpegFlags(inputFile: string, { crop, format, fps, resize, reverse, rotate, speed, trim, volume }: Omit<Options, 'parallel' | 'debug' | 'output'>): FFmpegFlags;
//# sourceMappingURL=create-ffmpeg-flags.d.ts.map