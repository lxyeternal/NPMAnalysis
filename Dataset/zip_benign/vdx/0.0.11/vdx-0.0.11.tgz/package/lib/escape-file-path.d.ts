export declare function escapeFilePath(filePath: string): string;
//# sourceMappingURL=escape-file-path.d.ts.map