import { Options } from './types';
export declare function vdx(globPatterns: Array<string>, options: Options): Promise<void>;
//# sourceMappingURL=vdx.d.ts.map