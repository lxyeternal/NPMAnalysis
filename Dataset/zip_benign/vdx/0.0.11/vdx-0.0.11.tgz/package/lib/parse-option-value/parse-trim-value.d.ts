import { TrimOption } from '../types';
export declare function parseTrimValue(value: string, name: string): TrimOption;
//# sourceMappingURL=parse-trim-value.d.ts.map