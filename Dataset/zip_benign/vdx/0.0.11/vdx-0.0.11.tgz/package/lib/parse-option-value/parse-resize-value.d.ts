import { ResizeOption } from '../types';
export declare function parseResizeValue(value: string): ResizeOption;
//# sourceMappingURL=parse-resize-value.d.ts.map