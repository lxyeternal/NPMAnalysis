import { CropOption } from '../types';
export declare function parseCropValue(value: string): CropOption;
//# sourceMappingURL=parse-crop-value.d.ts.map