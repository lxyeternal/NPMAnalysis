# Plugins Arguments

- [pluginArguments](#pluginArguments) : <code>object</code>
  - [.layout](#pluginArguments.layout) : <code>object</code>
  - [.keys](#pluginArguments.keys) : <code>object</code>
    - [.SCALE](#pluginArguments.keys.SCALE) : <code>object</code>
      - [.DIMENSIONS](#pluginArguments.keys.SCALE.DIMENSIONS) : <code>string</code>
    - [.COMPONENT](#pluginArguments.keys.COMPONENT) : <code>object</code>
      - [.LABELS_TITLES](#pluginArguments.keys.COMPONENT.LABELS_TITLES) : <code>string</code>
      - [.LABELS](#pluginArguments.keys.COMPONENT.LABELS) : <code>string</code>

---

<a name="pluginArguments.layout"></a>

### pluginArguments.layout : <code>object</code>

The layout from the enigma model.

**Kind**: static property of [<code>pluginArguments</code>](#pluginArguments)  
<a name="pluginArguments.keys"></a>

### pluginArguments.keys : <code>object</code>

The keys (references) to different types of chart internals

**Kind**: static property of [<code>pluginArguments</code>](#pluginArguments)

- [.keys](#pluginArguments.keys) : <code>object</code>
  - [.SCALE](#pluginArguments.keys.SCALE) : <code>object</code>
    - [.DIMENSIONS](#pluginArguments.keys.SCALE.DIMENSIONS) : <code>string</code>
  - [.COMPONENT](#pluginArguments.keys.COMPONENT) : <code>object</code>
    - [.LABELS_TITLES](#pluginArguments.keys.COMPONENT.LABELS_TITLES) : <code>string</code>
    - [.LABELS](#pluginArguments.keys.COMPONENT.LABELS) : <code>string</code>

<a name="pluginArguments.keys.SCALE"></a>

#### keys.SCALE : <code>object</code>

The scales associated with the sankey chart.
They are useful if you want to, via plugin, add a new component that
uses the same scale as one of the measures.

**Kind**: static property of [<code>keys</code>](#pluginArguments.keys)  
<a name="pluginArguments.keys.SCALE.DIMENSIONS"></a>

##### SCALE.DIMENSIONS : <code>string</code>

The dimensions scale

**Kind**: static property of [<code>SCALE</code>](#pluginArguments.keys.SCALE)  
<a name="pluginArguments.keys.COMPONENT"></a>

#### keys.COMPONENT : <code>object</code>

The unique keys of the existing components available in the sankey chart.
They are useful if you want to extend or override the existing components.

**Kind**: static property of [<code>keys</code>](#pluginArguments.keys)

- [.COMPONENT](#pluginArguments.keys.COMPONENT) : <code>object</code>
  - [.LABELS_TITLES](#pluginArguments.keys.COMPONENT.LABELS_TITLES) : <code>string</code>
  - [.LABELS](#pluginArguments.keys.COMPONENT.LABELS) : <code>string</code>

<a name="pluginArguments.keys.COMPONENT.LABELS_TITLES"></a>

##### COMPONENT.LABELS_TITLES : <code>string</code>

The labels titles component

**Kind**: static property of [<code>COMPONENT</code>](#pluginArguments.keys.COMPONENT)  
<a name="pluginArguments.keys.COMPONENT.LABELS"></a>

##### COMPONENT.LABELS : <code>string</code>

The labels component

**Kind**: static property of [<code>COMPONENT</code>](#pluginArguments.keys.COMPONENT)

# Definitions
