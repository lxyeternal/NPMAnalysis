# API Reference

- [properties](#properties) : <code>object</code>
  - [.version](#properties.version) : <code>string</code>
  - [.footnote](#properties.footnote) : <code>string</code> \| <code>StringExpression</code>
  - [.link](#properties.link) : <code>object</code>
    - [.opacity](#properties.link.opacity) : <code>number</code>
  - [.node](#properties.node) : <code>object</code>
    - [.width](#properties.node.width) : <code>number</code>
    - [.padding](#properties.node.padding) : <code>number</code>
    - [.sort](#properties.node.sort) : <code>&#x27;valueA&#x27;</code> \| <code>&#x27;valueD&#x27;</code> \| <code>&#x27;data&#x27;</code>
  - [.qHyperCubeDef](#properties.qHyperCubeDef) ⇐ <code>HyperCubeDef</code>
    - [.qDimensions](#properties.qHyperCubeDef.qDimensions) : [<code>Array.&lt;DimensionProperties&gt;</code>](#DimensionProperties)
    - [.qMeasures](#properties.qHyperCubeDef.qMeasures) : [<code>Array.&lt;MeasureProperties&gt;</code>](#MeasureProperties)
    - [.qSuppressMissing](#properties.qHyperCubeDef.qSuppressMissing) : <code>boolean</code>
    - [.qSuppressZero](#properties.qHyperCubeDef.qSuppressZero) : <code>boolean</code>
  - [.showTitles](#properties.showTitles) : <code>boolean</code>
  - [.subtitle](#properties.subtitle) : <code>string</code> \| <code>StringExpression</code>
  - [.title](#properties.title) : <code>string</code> \| <code>StringExpression</code>

---

<a name="properties.version"></a>

### properties.version : <code>string</code>

Current version of this generic object definition

**Kind**: static property of [<code>properties</code>](#properties)  
<a name="properties.footnote"></a>

### properties.footnote : <code>string</code> \| <code>StringExpression</code>

Visualization footnote.

**Kind**: static property of [<code>properties</code>](#properties)  
**Default**: <code>&quot;&quot;</code>  
<a name="properties.link"></a>

### properties.link : <code>object</code>

Link style settings.

**Kind**: static property of [<code>properties</code>](#properties)  
<a name="properties.link.opacity"></a>

#### link.opacity : <code>number</code>

Opacity of the links in the chart. Between 0 and 1.

**Kind**: static property of [<code>link</code>](#properties.link)  
**Default**: <code>0.5</code>  
<a name="properties.node"></a>

### properties.node : <code>object</code>

Node settings.

**Kind**: static property of [<code>properties</code>](#properties)

- [.node](#properties.node) : <code>object</code>
  - [.width](#properties.node.width) : <code>number</code>
  - [.padding](#properties.node.padding) : <code>number</code>
  - [.sort](#properties.node.sort) : <code>&#x27;valueA&#x27;</code> \| <code>&#x27;valueD&#x27;</code> \| <code>&#x27;data&#x27;</code>

<a name="properties.node.width"></a>

#### node.width : <code>number</code>

Width of the nodes. Can be a value between 0 and 1.

**Kind**: static property of [<code>node</code>](#properties.node)  
**Default**: <code>0.2</code>  
<a name="properties.node.padding"></a>

#### node.padding : <code>number</code>

Padding between the nodes. Between 0 and 1.

**Kind**: static property of [<code>node</code>](#properties.node)  
**Default**: <code>0.2</code>  
<a name="properties.node.sort"></a>

#### node.sort : <code>&#x27;valueA&#x27;</code> \| <code>&#x27;valueD&#x27;</code> \| <code>&#x27;data&#x27;</code>

Sorting mode for nodes.

- `undefined` - Prioritize sorting for optimal layout.
- `'valueA'` - Sort according to value of each node, in ascending order.
- `'valueD'` - Sort according to value of each node, in descending order.
- `'data` - Sort according to the order of the data.

**Kind**: static property of [<code>node</code>](#properties.node)  
<a name="properties.qHyperCubeDef"></a>

### properties.qHyperCubeDef ⇐ <code>HyperCubeDef</code>

Extends `HyperCubeDef`, see Engine API: `HyperCubeDef`.

**Kind**: static property of [<code>properties</code>](#properties)  
**Extends**: <code>HyperCubeDef</code>

- [.qHyperCubeDef](#properties.qHyperCubeDef) ⇐ <code>HyperCubeDef</code>
  - [.qDimensions](#properties.qHyperCubeDef.qDimensions) : [<code>Array.&lt;DimensionProperties&gt;</code>](#DimensionProperties)
  - [.qMeasures](#properties.qHyperCubeDef.qMeasures) : [<code>Array.&lt;MeasureProperties&gt;</code>](#MeasureProperties)
  - [.qSuppressMissing](#properties.qHyperCubeDef.qSuppressMissing) : <code>boolean</code>
  - [.qSuppressZero](#properties.qHyperCubeDef.qSuppressZero) : <code>boolean</code>

<a name="properties.qHyperCubeDef.qDimensions"></a>

#### qHyperCubeDef.qDimensions : [<code>Array.&lt;DimensionProperties&gt;</code>](#DimensionProperties)

**Kind**: static property of [<code>qHyperCubeDef</code>](#properties.qHyperCubeDef)  
<a name="properties.qHyperCubeDef.qMeasures"></a>

#### qHyperCubeDef.qMeasures : [<code>Array.&lt;MeasureProperties&gt;</code>](#MeasureProperties)

**Kind**: static property of [<code>qHyperCubeDef</code>](#properties.qHyperCubeDef)  
<a name="properties.qHyperCubeDef.qSuppressMissing"></a>

#### qHyperCubeDef.qSuppressMissing : <code>boolean</code>

**Kind**: static property of [<code>qHyperCubeDef</code>](#properties.qHyperCubeDef)  
**Default**: <code>true</code>  
<a name="properties.qHyperCubeDef.qSuppressZero"></a>

#### qHyperCubeDef.qSuppressZero : <code>boolean</code>

**Kind**: static property of [<code>qHyperCubeDef</code>](#properties.qHyperCubeDef)  
**Default**: <code>false</code>  
<a name="properties.showTitles"></a>

### properties.showTitles : <code>boolean</code>

Show title for the visualization.

**Kind**: static property of [<code>properties</code>](#properties)  
**Default**: <code>true</code>  
<a name="properties.subtitle"></a>

### properties.subtitle : <code>string</code> \| <code>StringExpression</code>

Visualization subtitle.

**Kind**: static property of [<code>properties</code>](#properties)  
**Default**: <code>&quot;&quot;</code>  
<a name="properties.title"></a>

### properties.title : <code>string</code> \| <code>StringExpression</code>

Visualization title.

**Kind**: static property of [<code>properties</code>](#properties)  
**Default**: <code>&quot;&quot;</code>

# Definitions
