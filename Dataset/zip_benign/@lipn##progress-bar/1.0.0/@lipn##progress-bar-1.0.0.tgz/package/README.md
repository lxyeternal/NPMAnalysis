# Progress bar

Vuetify component that shows a progress bar.

## Dependencies

- [Vue](https://vuejs.org/)
- [Vuetify](https://vuetifyjs.com/en/)

## Install

```
yarn add @lipn/progress-bar

```

## Use


1. First of all, import the plugin.

```javascript
import Vue from 'vue';
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'
import ProgressBar from 'progress-bar';

Vue.use(Vuetify);
Vue.use(ProgressBar);

new Vue({
  el: '#app',
  vuetify: new Vuetify(),
  // Global access to the dialog via $root.$progressBar
  mounted() {
    this.$root.$progressBar = this.$refs.progressBar;
  },
  methods: {
    save() {
      this.$root.$progressBar.show({ rounded: false, height: 6, opacity: 0.3, color: "info" });
      setTimeout(() => (this.$root.$progressBar.hide()), 3000)
    }
  }
};
```

2. Insert component where you want to use it:

```html
<html>
<body>
  <div id="app">
    <v-app>
      <!-- progress bar -->
      <progress-bar ref="progressBar"></progress-bar>
      <v-container>
        <!-- rest of the code -->
      </v-container>
    </v-app>
  </div>
</html>
```

## Showcase

[![Showcase](https://j.gifs.com/GvrZN0.jpg)](https://gifs.com/gif/progress-bar-GvrZN0)
