# Authors

The **progress-bar** component was developed by:

- Jaime ARIAS (CNRS, LIPN, Université Paris 13) - arias@lipn.univ-paris13.fr
