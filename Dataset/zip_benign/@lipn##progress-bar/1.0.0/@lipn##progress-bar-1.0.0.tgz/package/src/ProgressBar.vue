<template>
  <v-progress-linear
    :active="visible"
    :indeterminate="visible"
    :rounded="options.rounded"
    :height="options.height"
    :opacity="options.opacity"
    :color="options.color"
  ></v-progress-linear>
</template>

<script>
export default {
  name: "ProgressBar",
  data: () => ({
    visible: false,
    options: {
      rounded: false,
      height: 6,
      opacity: 0.3,
      color: "info"
    }
  }),
  methods: {
    /**
     * Hide progress bar
     */
    hide () {
      this.visible = false;
    },
    /**
     * Show progress bar
     * @param {object} options progress bar options
     */
    show (options) {
      // Check that options is an Object
      if (typeof options === "object") {
        this.options = Object.assign(this.options, options)
      }

      this.visible = true;
    }
  }
}
</script>
