import ProgressBar from './ProgressBar.vue';

const ProgressBarPlugin = {
  install (Vue, options) {
    // Add the new component
    Vue.component(ProgressBar.name, ProgressBar);
  }
}

// Automatic installation if Vue has been added to the global scope.
if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(ProgressBarPlugin);
}

export default ProgressBarPlugin;
