export declare class Utils {
    msToString(ms: number, resolution?: string): string;
}
