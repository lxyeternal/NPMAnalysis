import { BehaviorSubject } from 'rxjs';
import { TimerData } from '../../timer.interface';
import * as i0 from "@angular/core";
export declare class CountDownTimerService {
    private subject;
    private startTime;
    private elapsedWhenPaused;
    private isPaused;
    private speed;
    private resolution;
    private duration;
    private rafId;
    private lastUpdateTime;
    private lastValue;
    private visualSmooth;
    start(startFrom?: number, duration?: number, resolution?: string, speed?: number, visualSmooth?: boolean): void;
    private tick;
    pause(): void;
    resume(): void;
    setSpeed(newSpeed: number): void;
    stop(): void;
    getObservable(): BehaviorSubject<TimerData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CountDownTimerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CountDownTimerService>;
}
