export interface TimerData {
    valueString: string;
    valueNumber: number;
}
