import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

class Utils {
    msToString(ms, resolution = 'm') {
        const pad = (n, z = 2) => ('00' + n).slice(-z);
        const msPart = Math.floor(ms % 1000);
        ms = Math.floor(ms / 1000);
        const secs = ms % 60;
        ms = Math.floor(ms / 60);
        const mins = ms % 60;
        ms = Math.floor(ms / 60);
        const hrs = ms % 24;
        const days = Math.floor(ms / 24);
        switch (resolution) {
            case 's': return `${pad(secs)}.${pad(msPart, 3)}`;
            case 'm': return `${pad(mins)}:${pad(secs)}.${pad(msPart, 3)}`;
            case 'h': return `${pad(hrs)}:${pad(mins)}:${pad(secs)}.${pad(msPart, 3)}`;
            case 'd': return `${days}d ${pad(hrs)}:${pad(mins)}:${pad(secs)}.${pad(msPart, 3)}`;
            default: return `${pad(mins)}:${pad(secs)}.${pad(msPart, 3)}`;
        }
    }
}

class CountDownTimerService {
    subject = new BehaviorSubject({ valueNumber: 0, valueString: '00:00.000' });
    startTime = 0;
    elapsedWhenPaused = 0;
    isPaused = false;
    speed = 1;
    resolution = 'm';
    duration = 0;
    rafId = null;
    lastUpdateTime = 0;
    lastValue = 0;
    visualSmooth = false;
    start(startFrom = 0, duration = 0, resolution = 'm', speed = 1, visualSmooth = false) {
        this.stop();
        this.isPaused = false;
        this.elapsedWhenPaused = startFrom;
        this.resolution = resolution;
        this.speed = speed;
        this.duration = duration;
        this.visualSmooth = visualSmooth;
        this.startTime = Date.now();
        this.lastUpdateTime = this.startTime;
        this.lastValue = startFrom;
        this.tick();
    }
    tick = () => {
        if (this.isPaused)
            return;
        const now = Date.now();
        const rawElapsed = this.elapsedWhenPaused + (now - this.startTime) * this.speed;
        const capped = Math.min(rawElapsed, this.duration);
        const remaining = Math.max(this.duration - capped, 0);
        let displayRemaining = remaining;
        if (this.visualSmooth) {
            const timeSinceLast = now - this.lastUpdateTime;
            const approxFps = 60;
            const frameInterval = 1000 / approxFps;
            const deltaPerFrame = frameInterval * this.speed;
            const estimatedElapsed = this.lastValue + deltaPerFrame;
            const estimatedRemaining = Math.max(this.duration - estimatedElapsed, 0);
            displayRemaining = Math.min(remaining, estimatedRemaining);
        }
        const formatted = new Utils().msToString(displayRemaining, this.resolution);
        this.subject.next({
            valueNumber: remaining,
            valueString: formatted
        });
        this.lastUpdateTime = now;
        this.lastValue = capped;
        if (remaining <= 0) {
            this.subject.complete();
        }
        else {
            this.rafId = requestAnimationFrame(this.tick);
        }
    };
    pause() {
        if (!this.isPaused) {
            this.isPaused = true;
            this.elapsedWhenPaused += (Date.now() - this.startTime) * this.speed;
            if (this.rafId)
                cancelAnimationFrame(this.rafId);
        }
    }
    resume() {
        if (this.isPaused) {
            this.isPaused = false;
            this.startTime = Date.now();
            this.lastUpdateTime = this.startTime;
            this.tick();
        }
    }
    setSpeed(newSpeed) {
        this.pause();
        this.speed = newSpeed;
        this.resume();
    }
    stop() {
        this.isPaused = true;
        if (this.rafId)
            cancelAnimationFrame(this.rafId);
        this.subject.complete();
        this.subject = new BehaviorSubject({ valueNumber: 0, valueString: '00:00.000' });
    }
    getObservable() {
        return this.subject;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.7", ngImport: i0, type: CountDownTimerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.7", ngImport: i0, type: CountDownTimerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.7", ngImport: i0, type: CountDownTimerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class CountUpTimerService {
    subject = new BehaviorSubject({ valueNumber: 0, valueString: '00:00.000' });
    startTime = 0;
    elapsedWhenPaused = 0;
    isPaused = false;
    speed = 1;
    resolution = 'm';
    maxValue = 0;
    rafId = null;
    lastUpdateTime = 0;
    lastValue = 0;
    visualSmooth = false;
    start(startFrom = 0, maxValue = 0, resolution = 'm', speed = 1, visualSmooth = false) {
        this.stop();
        this.isPaused = false;
        this.elapsedWhenPaused = startFrom;
        this.resolution = resolution;
        this.speed = speed;
        this.maxValue = maxValue;
        this.visualSmooth = visualSmooth;
        this.startTime = Date.now();
        this.lastUpdateTime = this.startTime;
        this.lastValue = startFrom;
        this.tick();
    }
    tick = () => {
        if (this.isPaused)
            return;
        const now = Date.now();
        const rawElapsed = this.elapsedWhenPaused + (now - this.startTime) * this.speed;
        const capped = this.maxValue > 0 ? Math.min(rawElapsed, this.maxValue) : rawElapsed;
        let displayElapsed = capped;
        if (this.visualSmooth) {
            const timeSinceLast = now - this.lastUpdateTime;
            const approxFps = 60;
            const frameInterval = 1000 / approxFps;
            const deltaPerFrame = frameInterval * this.speed;
            const estimatedElapsed = this.lastValue + deltaPerFrame;
            displayElapsed = Math.min(estimatedElapsed, capped);
        }
        const formatted = new Utils().msToString(displayElapsed, this.resolution);
        this.subject.next({
            valueNumber: capped,
            valueString: formatted
        });
        this.lastUpdateTime = now;
        this.lastValue = capped;
        if (this.maxValue > 0 && capped >= this.maxValue) {
            this.subject.complete();
        }
        else {
            this.rafId = requestAnimationFrame(this.tick);
        }
    };
    pause() {
        if (!this.isPaused) {
            this.isPaused = true;
            this.elapsedWhenPaused += (Date.now() - this.startTime) * this.speed;
            if (this.rafId)
                cancelAnimationFrame(this.rafId);
        }
    }
    resume() {
        if (this.isPaused) {
            this.isPaused = false;
            this.startTime = Date.now();
            this.lastUpdateTime = this.startTime;
            this.tick();
        }
    }
    setSpeed(newSpeed) {
        this.pause();
        this.speed = newSpeed;
        this.resume();
    }
    stop() {
        this.isPaused = true;
        if (this.rafId)
            cancelAnimationFrame(this.rafId);
        this.subject.complete();
        this.subject = new BehaviorSubject({ valueNumber: 0, valueString: '00:00.000' });
    }
    getObservable() {
        return this.subject;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.7", ngImport: i0, type: CountUpTimerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.7", ngImport: i0, type: CountUpTimerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.7", ngImport: i0, type: CountUpTimerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API Surface of ngx-timer
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CountDownTimerService, CountUpTimerService };
//# sourceMappingURL=tomaszatoo-ngx-timer.mjs.map
