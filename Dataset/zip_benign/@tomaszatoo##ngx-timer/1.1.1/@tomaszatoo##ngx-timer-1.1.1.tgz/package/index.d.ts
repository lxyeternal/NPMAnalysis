/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@tomaszatoo/ngx-timer" />
export * from './public-api';
