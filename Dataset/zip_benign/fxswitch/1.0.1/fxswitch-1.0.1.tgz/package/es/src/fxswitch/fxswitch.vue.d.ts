declare const _sfc_main: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    checked: {
        type: StringConstructor;
        required: false;
        default: undefined;
    };
    checkedValue: {
        type: (StringConstructor | BooleanConstructor | NumberConstructor)[];
        required: false;
        default: boolean;
    };
    unchecked: {
        type: StringConstructor;
        required: false;
        default: undefined;
    };
    uncheckedValue: {
        type: (StringConstructor | BooleanConstructor | NumberConstructor)[];
        required: false;
        default: boolean;
    };
    loading: {
        type: BooleanConstructor;
        required: false;
        default: boolean;
    };
    disabled: {
        type: BooleanConstructor;
        required: false;
        default: boolean;
    };
    size: {
        type: StringConstructor;
        required: false;
        default: string;
    };
    rippleColor: {
        type: StringConstructor;
        required: false;
        default: string;
    };
    circleStyle: {
        type: null;
        required: false;
        default: () => {};
    };
    modelValue: {
        type: (StringConstructor | BooleanConstructor | NumberConstructor)[];
        required: false;
        default: boolean;
    };
}>, {
    props: any;
    wave: import("vue").Ref<boolean, boolean>;
    emit: (event: "update:modelValue" | "change", ...args: any[]) => void;
    onSwitch: () => void;
    onWaveEnd: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:modelValue" | "change")[], "update:modelValue" | "change", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    checked: {
        type: StringConstructor;
        required: false;
        default: undefined;
    };
    checkedValue: {
        type: (StringConstructor | BooleanConstructor | NumberConstructor)[];
        required: false;
        default: boolean;
    };
    unchecked: {
        type: StringConstructor;
        required: false;
        default: undefined;
    };
    uncheckedValue: {
        type: (StringConstructor | BooleanConstructor | NumberConstructor)[];
        required: false;
        default: boolean;
    };
    loading: {
        type: BooleanConstructor;
        required: false;
        default: boolean;
    };
    disabled: {
        type: BooleanConstructor;
        required: false;
        default: boolean;
    };
    size: {
        type: StringConstructor;
        required: false;
        default: string;
    };
    rippleColor: {
        type: StringConstructor;
        required: false;
        default: string;
    };
    circleStyle: {
        type: null;
        required: false;
        default: () => {};
    };
    modelValue: {
        type: (StringConstructor | BooleanConstructor | NumberConstructor)[];
        required: false;
        default: boolean;
    };
}>> & Readonly<{
    "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    onChange?: ((...args: any[]) => any) | undefined;
}>, {
    size: string;
    checked: string;
    checkedValue: string | number | boolean;
    unchecked: string;
    uncheckedValue: string | number | boolean;
    loading: boolean;
    disabled: boolean;
    rippleColor: string;
    circleStyle: any;
    modelValue: string | number | boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _sfc_main;
