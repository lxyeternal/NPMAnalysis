/*
 * @Descripttion:
 * @Author: WuFengliang
 * @Date: 2022-03-03 16:43:13
 * @LastEditTime: 2022-03-04 14:27:21
 */
import path from "path";
import json from "@rollup/plugin-json";
import ts from "rollup-plugin-typescript2";
import resolvePlugin from "@rollup/plugin-node-resolve";
import { terser } from "rollup-plugin-terser";
import cleanup from "rollup-plugin-cleanup";
import packages from "./package.json";

const resolve = (p) => path.resolve(__dirname, p);

const outputs = {
  "esm-bunder": {
    name: "AMAudio",
    file: resolve(`dist/${packages.name}.esm-bunder.js`),
    format: "es",
  },
  cjs: {
    name: "AMAudio",
    file: resolve(`dist/${packages.name}.cjs.js`),
    format: "cjs",
  },
  global: {
    name: "AMAudio",
    file: resolve(`dist/${packages.name}.global.js`),
    format: "iife",
  },
};

const config = {
  input: resolve("./src/index.ts"),
  plugins: [
    json(),
    ts({ tsconfig: resolve("tsconfig.json") }),
    resolvePlugin(),
    terser(),
    cleanup(),
  ],
};

export default Object.keys(outputs).map((key) => ({
  ...config,
  output: outputs[key],
}));
