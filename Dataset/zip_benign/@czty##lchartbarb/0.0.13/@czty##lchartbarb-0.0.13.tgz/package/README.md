一：说明：
基础的柱状图组件

二：使用：
npm i @czty/lchartbarb

import React from 'react';
import Lchartbarb from '@czty/lchartbarb';

const MyComponent = () => {
  return (
    <Lchartbarb
      draggable={true}
      configer={
        x: 0,
        y: 0,
        clazz : '',
        params : {},
        url: '',
        method: 'get',
        data: [[43.3, 83.1, 86.4], [85.3, 73.1, 65.4]],
        name: ['2015', '2016'],
        xdata: ['4-1', '4-2', '4-3'],
        xFormatter: 'MM-dd',
        width: '400px',
        height: '200px',

        axisTextColor: 'rgb(137, 171, 205)',
        barWidth: 10,
        barGap: 0.5,
        barbackground: 'none',
        barItemColor: [['rgba(5, 255, 129, 1)', 'rgba(5, 255, 129, 1)'],['rgba(248, 160, 123, 1)', 'rgba(248, 160, 123, 1)']],
        
        options: {}
      }
    />
  )
}

三：字段说明
x: 
y:
clazz: 可添加的组件的className
params: 请求的传参参数
url: 请求的url地址
method: 请求方式
width: 组件的整体宽度
height: 组件的整体高度
name：每根柱子的名称数据
data：数据
xdata: x轴数据
xFormatter：x轴值格式方式 // 只作用xdata值是日期类型

axisTextColor：轴刻度值字体颜色
barWidth：柱子宽度
barGap：柱子之间的间距
barbackground：柱子背景层颜色
barItemColor：柱子颜色
options：饼图option选项