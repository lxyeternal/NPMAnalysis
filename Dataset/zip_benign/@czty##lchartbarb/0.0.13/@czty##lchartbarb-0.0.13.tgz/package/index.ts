import Lchartbarb from './src/component'
import configer, { cfgItem } from './configer'

export default { configer, cfgItem }

export { Lchartbarb }