import React, { FC } from 'react'
import 'antd/dist/antd.css'
// 文件夹命名得全小写的
import Lchartbarb from '@/component'

const App: FC = () => {
  return (
    <div className="app">
      <Lchartbarb /> 
    </div>
  )
}

export default App