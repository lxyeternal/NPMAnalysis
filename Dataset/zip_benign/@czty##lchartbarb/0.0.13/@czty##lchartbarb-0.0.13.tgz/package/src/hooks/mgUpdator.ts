import React, { memo } from 'react'


function useUpdator(component) {
    const newCp = memo(component, (prevProps, nextProps) => {
        // console.log('888:', prevProps, nextProps)
        // 暂时无论如何都不更新
        return true
    })

    return newCp
}

export default useUpdator