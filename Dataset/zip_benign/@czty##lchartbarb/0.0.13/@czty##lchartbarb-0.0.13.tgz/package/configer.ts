export const cfgItem = [{
  label: 'x',
  name: 'x',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'y',
  name: 'y',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'clazz',
  name: 'clazz',
  value: '',
  placeholder: '例如：cz-title',
  type: []
},{
  label: '请求参数',
  name: 'params',
  value: '',
  placeholder: '例如：{id: 2}',
  type: []
},{
  label: '请求方式',
  name: 'method',
  value: 'get',
  placeholder: '例如：get',
  type: [{
    id: 'get',
    name: 'get'
  }, {
    id: 'post',
    name: 'post'
  }, {
    id: 'put',
    name: 'put'
  }, {
    id: 'delete',
    name: 'delete'
  }]
},{
  label: '请求地址',
  name: 'url',
  value: '',
  placeholder: '例如：',
  type: []
},{
  label: '数据',
  name: 'ydata',
  value: [[43.3, 83.1, 86.4], [85.3, 73.1, 65.4]],
  placeholder: '例如：[[43.3, 83.1, 86.4], [85.3, 73.1, 65.4]]',
  type: []
}, {
  label: 'x轴数据',
  name: 'xdata',
  value: ['4-1', '4-2', '4-3'],
  placeholder: "例如：['4-1', '4-2', '4-3']",
  type: []
}, {
  label: '图例数据',
  name: 'legendData',
  value: ['2015', '2016'],
  placeholder: '例如：[2015, 2016]',
  type: []
}, {
  label: 'x轴值格式',
  name: 'xFormatter',
  value: 'MM-dd',
  placeholder: '例如：MM-dd',
  type: []
},{
  label: '宽度',
  name: 'width',
  value: '400px',
  placeholder: '例如：400px',
  type: []
}, {
  label: '高度',
  name: 'height',
  value: '202px',
  placeholder: '例如: 202px',
  type: []
}, {
  label: '轴字颜色',
  name: 'axisTextColor',
  value: 'rgb(137, 171, 205)',
  placeholder: '例如：rgb(137, 171, 205)',
  type: ['color']
},{
  label: '柱子宽度',
  name: 'barWidth',
  value: 10,
  placeholder: '例如：10',
  type: []
},{
  label: '柱子间距',
  name: 'barGap',
  value: 0.5,
  placeholder: '例如：0.5',
  type: []
},{
  label: '柱子背景',
  name: 'barbackground',
  value: 'none',
  placeholder: '例如：rgba(55, 95, 144, 0.5)',
  type: []
},{
  label: '柱子颜色',
  name: 'barItemColor',
  value: [['rgba(5, 255, 129, 1)', 'rgba(5, 255, 129, 1)'],['rgba(248, 160, 123, 1)', 'rgba(248, 160, 123, 1)']],
  placeholder: "例如：[['rgba(5, 255, 129, 1)', 'rgba(5, 255, 129, 1)'],['rgba(248, 160, 123, 1)', 'rgba(248, 160, 123, 1)']]",
  type: []
},{
  label: 'options',
  name: 'options',
  value: {},
  placeholder: '例如：{}',
  type: []
}]

export default  {
  x: 0,
  y: 0,
  clazz : '',
  params : {},
  url: '',
  method: 'get',
  ydata: [[43.3, 83.1, 86.4], [85.3, 73.1, 65.4]],
  xdata: ['4-1', '4-2', '4-3'],
  legendData: ['2015', '2016'],

  width: '400px',
  height: '200px',

  axisTextColor: 'rgb(137, 171, 205)',
  barWidth: 10,
  barGap: 0.5,
  barbackground: 'none',
  barItemColor: [['rgba(5, 255, 129, 1)', 'rgba(5, 255, 129, 1)'],['rgba(248, 160, 123, 1)', 'rgba(248, 160, 123, 1)']],
  
  options: {}
}