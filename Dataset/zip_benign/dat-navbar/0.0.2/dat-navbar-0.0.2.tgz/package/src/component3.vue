<template>

        <div class="sidepanel full" :style="{width:width}">
            <transition name="fade">
            <div class="full" v-show="display"  @click="touchEnd" :style="{background:background}">

            </div>
            </transition>
            <transition :name="effect">
                <div v-show="display" style="position: absolute;top:0">
                    <slot></slot>
                </div>

            </transition>
        </div>

</template>
<style scoped>
    .full{
        width: 100vw;
        height: 100vh;
    }
    .sidepanel {
        position: absolute;
        top: 0px;


    }
    .fade-enter-active, .fade-leave-active {
        transition: opacity .5s;
    }
    .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
        opacity: 0;
    }
    .fadeleft-enter-active, .fadeleft-leave-active {
        transition: transform .5s;
    }
    .fadeleft-enter, .fadeleft-leave-to /* .fadeleft-leave-active below version 2.1.8 */ {
        transform: translate(-100vw);
    }
    .faderight-enter-active, .faderight-leave-active {
        transition: transform .5s;
    }
    .faderight-enter, .faderight-leave-to /* .faderight-leave-active below version 2.1.8 */ {
        transform: translate(100vw);
    }


</style>

/*!
*
* Copyright 2013-2019 Johnny chen
*/
<script>

    // 注册
    export default {
        // 声明 props
        props: {
            background:{
                type:String,
                default:'rgba(0, 0, 0, 0.5)'

            },

            effect:{
                type:String,
                default:'fadeleft'

            }
        },
        data: function () {

            return {
                __minify: null, display: false

            }
        },
        computed:{
            width:function () {
                return this.display?'100vw':'0'
            }
        },


        methods: {
            touchEnd: function () {
                this.hide();
            },
            show: function () {
                this.display = true
                this.$emit('show')
            },
            hide: function () {
                this.display = false
                this.$emit('hide')

            }
        },

        mounted: function () {

        }


    }


</script>