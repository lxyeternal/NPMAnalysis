<template>
    <div ref="box" v-show="true" style="display: none;">
        <div ref="dom" :class="navClass" :style="styles">
            <slot></slot>
        </div>
    </div>
</template>
<style>



</style>

/*!
*
* Copyright 2013-2019 Johnny chen
*/
<script>
    function windowSize() {
        let dom = window;
        return {
            width: dom.innerWidth,
            height: dom.innerHeight
        }
    }

    /** 绑定事件到dom元素，返回解除绑定的函数
     * @param dom:Element
     * @param event:String
     * @param callback:Function
     * @param useCapture:Boolean 指定事件是否在捕获或冒泡阶段执行
     * @return:Function 解除绑定的函数
     */

    function bindEvent(dom, event, callback, useCapture) {
        function remove() {
            dom.removeEventListener(event, icc, useCapture)
        }

        function icc(e) {
            if (callback(e) === true) {
                remove();
            }
        }

        dom.addEventListener(event, icc, useCapture);
        return remove;
    };
    // 注册
    export default {
        // 声明 props
        props: {
            navClass:{
                type: String,
                default: ''
            },
            fixed: {
                type: Object,
                default: function () {
                    return {}
                }
            }, normal: {
                type: Object,
                default: function () {
                    return {}
                }
            }, time: {
                type: Number,
                default: 0.5
            }
        },
        data: function () {

            return {
                styles: {}, dom: null, box: null, show: false

            }
        },


        methods: {
            __update: function () {
                let size = this.box.getBoundingClientRect();
                let window_size = windowSize();
                let show = (size.top < 0 || size.bottom > window_size.height) || (size.left < 0 || size.right > window_size.width)
                this.normal.transition=this.time+'s';
                this.fixed.transition=this.time+'s';

                if (this.show !== show) {
                    this.show = show;
                    if (show) {
                        this.$emit('fixed')
                        this.styles = this.fixed;
                    } else {
                        this.$emit('normal')
                        this.styles = this.normal;

                    }
                }

            }
        },
        computed: {},
        mounted: function () {
            let self = this;
            self.dom = this.$refs.dom;
            self.box = this.$refs.box;

            self.styles = this.normal;
            self.normal.transition=self.time+'s';
            self.fixed.transition=self.time+'s';

            setTimeout(function () {
                self.box.style.height = self.box.getBoundingClientRect().height + 'px'
                let rm_widow = bindEvent(window, 'resize', function () {
                    self.__update();
                })
                let rm_scoll = bindEvent(window, 'scroll', function () {
                    self.__update();
                });

            })
        }


    }


</script>