<template>

        <div   class="navbar">
            <slot  name="left" v-show="show"></slot>
            <slot></slot>
            <slot  name="right"></slot>
        </div>

</template>
<style scoped>
    .navbar>div:first-child{
        float: left;
    }
    .navbar>div:last-child{
        float: right;
    }



</style>

/*!
*
* Copyright 2013-2019 Johnny chen
*/
<script>
    function windowSize() {
        let dom = window;
        return {
            width: dom.innerWidth,
            height: dom.innerHeight
        }
    }

    /** 绑定事件到dom元素，返回解除绑定的函数
     * @param dom:Element
     * @param event:String
     * @param callback:Function
     * @param useCapture:Boolean 指定事件是否在捕获或冒泡阶段执行
     * @return:Function 解除绑定的函数
     */

    function bindEvent(dom, event, callback, useCapture) {
        function remove() {
            dom.removeEventListener(event, icc, useCapture)
        }

        function icc(e) {
            if (callback(e) === true) {
                remove();
            }
        }

        dom.addEventListener(event, icc, useCapture);
        return remove;
    };
    // 注册
    export default {
        // 声明 props
        props: {
            miniWidth: {
                type: Number,
                default: 640
            }
        },
        data: function () {

            return {
              show: null

            }
        },


        methods: {
            __update: function () {

                let window_size = windowSize();
                let show = (window_size.width<this.miniWidth)
                if (this.show !== show) {
                    this.show = show;
                    if (show) {
                        this.$emit('minify')

                    } else {
                        this.$emit('normal')


                    }
                }

            }
        },
        computed: {},
        mounted: function () {
            let self = this;
            self.__update();

            setTimeout(function () {
                let rm_widow = bindEvent(window, 'resize', function () {
                    self.__update();
                })

            })
        }


    }


</script>