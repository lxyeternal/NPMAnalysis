/**
 * Created by johnny on 2017/12/25.
 */

import DatAutofixed from './component.vue'
import DatNavbar from './component2.vue'
import DatSidePanel from './component3.vue'
// Why don't you export default?
// https://github.com/webpack/webpack/issues/3560
export default DatNavbar
export { DatNavbar,DatAutofixed,DatSidePanel}