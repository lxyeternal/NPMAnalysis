# DatAutofixed
dat-autofixed

###参数
 fixed:Object {height:'100px"}
 
 //需要fixed的对象
 
 normal:Object {height:'50px"}
 
 //普通对象
 
 time:Number 1
 
 //变化时间
 
 ####事件
 fixed
 //浮层
 
 normal
 //页内
 
 # DatNavbar
 dat-autofixed
 
 ###参数
 miniWidth:Number 640
 
 //最小化宽度
 
  ####事件
  minify
  //最小化
  
  normal
  //普通
 #DatSidePanel
 
dat-side-panel

###参数
 background:String rgba(0, 0, 0, 0.5)
 //背景
 
 effect:String 'fadeleft'   fadeleft|faderight
 //出现效果
 
   ####方法
 show 显示
 
 hide 隐藏
 
 
 //最小化宽度
 
  ####事件
  show
  //显示
  
  hide
  //隐藏