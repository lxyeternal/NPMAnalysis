package <%= appPackage %>.domain.repo

interface CacheRepo {
}