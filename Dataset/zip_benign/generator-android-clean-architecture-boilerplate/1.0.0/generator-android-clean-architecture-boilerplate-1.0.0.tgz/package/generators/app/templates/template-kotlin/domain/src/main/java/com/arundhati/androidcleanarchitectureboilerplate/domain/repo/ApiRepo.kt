package <%= appPackage %>.domain.repo

interface ApiRepo {
}