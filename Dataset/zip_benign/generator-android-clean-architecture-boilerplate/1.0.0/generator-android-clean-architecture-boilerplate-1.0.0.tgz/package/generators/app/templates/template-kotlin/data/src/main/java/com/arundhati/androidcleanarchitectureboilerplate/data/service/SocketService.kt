package <%= appPackage %>.data.service

interface SocketService {

}