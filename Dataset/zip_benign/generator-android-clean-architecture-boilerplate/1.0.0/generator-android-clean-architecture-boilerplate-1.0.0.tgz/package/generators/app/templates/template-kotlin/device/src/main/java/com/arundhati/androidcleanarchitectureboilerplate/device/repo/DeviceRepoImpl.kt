package <%= appPackage %>.device.repo

import android.content.Context
import <%= appPackage %>.domain.repo.DeviceRepo
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DeviceRepoImpl @Inject constructor(private val context: Context) : DeviceRepo {
}