package <%= appPackage %>.domain.repo

interface DeviceRepo {
}