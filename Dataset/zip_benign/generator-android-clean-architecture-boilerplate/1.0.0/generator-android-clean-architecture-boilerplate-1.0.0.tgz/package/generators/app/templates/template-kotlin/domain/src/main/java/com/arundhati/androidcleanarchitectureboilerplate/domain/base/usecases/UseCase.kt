package <%= appPackage %>.domain.base.usecases

interface UseCase<R> {
    fun execute(): R
}