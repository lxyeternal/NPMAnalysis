package <%= appPackage %>.domain.repo

interface SocketRepo {
}