package <%= appPackage %>.data.repo

import <%= appPackage %>.domain.repo.SocketRepo
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SocketRepoImpl @Inject constructor() : SocketRepo {
}