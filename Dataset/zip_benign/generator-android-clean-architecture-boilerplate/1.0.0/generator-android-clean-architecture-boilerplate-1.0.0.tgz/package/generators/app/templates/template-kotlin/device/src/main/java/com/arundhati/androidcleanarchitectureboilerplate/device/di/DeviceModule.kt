package <%= appPackage %>.device.di

import dagger.Module

@Module
abstract class DeviceModule {

}