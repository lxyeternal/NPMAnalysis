package <%= appPackage %>.data.service

interface ApiService {

}