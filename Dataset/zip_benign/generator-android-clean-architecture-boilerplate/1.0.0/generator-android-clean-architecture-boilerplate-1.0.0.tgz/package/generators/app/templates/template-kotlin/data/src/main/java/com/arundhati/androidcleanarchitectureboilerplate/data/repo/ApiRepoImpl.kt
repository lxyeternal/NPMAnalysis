package <%= appPackage %>.data.repo

import <%= appPackage %>.domain.repo.ApiRepo
import javax.inject.Inject

class ApiRepoImpl @Inject constructor() : ApiRepo {
}