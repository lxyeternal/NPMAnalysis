package <%= appPackage %>.data.di

import dagger.Module

@Module(includes = [NetworkModule::class])
abstract class DataModule {
}