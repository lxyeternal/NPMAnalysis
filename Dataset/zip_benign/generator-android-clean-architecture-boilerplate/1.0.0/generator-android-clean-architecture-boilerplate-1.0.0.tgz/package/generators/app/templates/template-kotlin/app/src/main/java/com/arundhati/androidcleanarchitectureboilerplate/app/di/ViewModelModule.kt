package <%= appPackage %>.di

import androidx.lifecycle.ViewModelProvider
import <%= appPackage %>.di.ViewModelFactory
import dagger.Binds
import dagger.Module

@Module
abstract class ViewModelModule {

    @Binds
    abstract fun bindViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory
}