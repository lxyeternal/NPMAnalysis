/**
 * Split a command into an array.
 *
 * @example
 * ```js
 * const arr = split( 'git commit -m "some message with spaces"' );
 * console.log( arr ); // [ "git", "commit", "-m", "some message with spaces" ]
 * ```
 *
 * @param {string} command Command to split.
 * @returns {Array}
 */
export declare function split(command: string): string[];
/**
 * Split a command into an object with the attributes `command` and `args`.
 *
 * @example
 * ```js
 * const obj = splitToObject( 'git commit -m "some message with spaces"' );
 * console.log( obj.command ); // git
 * console.log( obj.args ); // [ "commit", "-m", "some message with spaces" ]
 * ```
 *
 * @param {string} command Command to split.
 * @returns {object}
 */
export declare function splitToObject(command: string): {
    command?: string;
    args?: string[];
};
