const lodash = require('lodash');


module.exports.arraySize = array => lodash.size(array);
module.exports.area = radius => Math.PI*radius*radius;
module.exports.perimeter = radius => Math.PI.radius;