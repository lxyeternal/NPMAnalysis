# 🔔 BellsWall CLI

Welcome to BellsWall - Your Friendly Neighborhood Bitcoin Inscription Manager! 🚀

## ✨ Features

- 🎨 Manage Artist Profiles
- 📜 Handle Inscriptions
- 💎 Collection Management
- 🏪 Marketplace Listings
- 🔐 Secure Wallet Integration

## 🚀 Installation

```bash
npm install -g @bellswall/cli
```

## 🎮 Commands

### 👩‍🎨 Artist Management

```bash
# Create a new artist profile (interactive mode)
bellswall artist create

# Create with all details upfront
bellswall artist create --name="Satoshi" --bio="Bitcoin Artist" --twitter="satoshi"

# Show artist details
bellswall artist show --wallet=bc1...
bellswall artist show --id=<artist_id>

# Update artist profile
bellswall artist update --id=<artist_id> --name="New Name"
```

### 📜 Inscriptions

```bash
# Get inscription details
bellswall inscription get --id=<txid>i<vin>

# Get JSON output
bellswall inscription get --id=<txid>i<vin> --json
```

### 💎 Collections

```bash
# View your collection (first 10 inscriptions)
bellswall collection get

# Paginate through collection
bellswall collection get --limit=20 --offset=40

# Get JSON format
bellswall collection get --json
```

### 🏪 Marketplace Listings

Turn your inscriptions into treasure! 💎

```bash
# Create a new listing
bellswall listing create --inscription=<txid>i<vin> --price=0.5

# Update listing price
bellswall listing update --id=<txid>i<vin> --price=0.5

# List all listings
bellswall listing list

# Get listing details
bellswall listing get --id=<txid>i<vin>

# Buy a Listing
bellswall listing buy --id=<txid>i<vin>
```

## 🎯 Tips and Tricks

- 💡 Use `--json` flag for machine-readable output
- 🔄 Most commands support both interactive and flag-based input
- 📝 IDs follow the format `<txid>i<vin>` (e.g., `1234...abcd`i0)
- 🎨 Artist profiles are linked to your wallet address

## 🛠 Development

```bash
# Clone the repo
git clone https://github.com/yourusername/bellswall.git

# Install dependencies
npm install

# Run locally
./bin/dev artist show --help
```

## 🤝 Contributing

We love contributions! 🎉 Feel free to:
- 🐛 Report bugs
- 💡 Suggest features
- 🔧 Submit PRs

## 📜 License

MIT © Your Name Here

## 🙏 Acknowledgments

Built with ❤️ using:
- [oclif](https://oclif.io) - The Open CLI Framework
- TypeScript
- And lots of ☕️

---

Made with 🔔 by the BellsWall Team

Remember: Not your keys, not your inscriptions! 🔑
