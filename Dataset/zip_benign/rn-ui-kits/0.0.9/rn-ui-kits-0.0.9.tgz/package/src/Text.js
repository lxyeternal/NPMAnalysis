import React from "react";
import { Text, Animated } from "react-native";
import { getMargins, getPaddings } from "./utils/helpers";
import { getStyles } from "./utils/styles";

export default function Typography(props) {
  const { children, animated, theme = {}, style = {}, ...rest } = props;
  const styles = [
    getMargins(props),
    getPaddings(props),
    getStyles(props),
    theme,
    style,
  ];
  if (animated) {
    return (
      <Animated.Text style={styles} {...rest}>
        {children}
      </Animated.Text>
    );
  }
  return (
    <Text style={styles} {...rest}>
      {children}
    </Text>
  );
}
