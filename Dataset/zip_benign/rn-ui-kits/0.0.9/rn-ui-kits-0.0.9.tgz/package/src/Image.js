import React from "react";
import { Image } from "react-native";
import { getMargins, getPaddings } from "./utils/helpers";
import { getStyles } from "./utils/styles";

export default function Img(props) {
  const { children, style, theme } = props;

  const stylesImage = [
    getMargins(props),
    getPaddings(props),
    getStyles(props),
    style,
    theme,
  ];
  return (
    <Image {...props} style={stylesImage}>
      {children}
    </Image>
  );
}
