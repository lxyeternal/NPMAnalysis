import React from "react";
import {
  TouchableHighlight,
  TouchableNativeFeedback,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from "react-native";
import { getMargins, getPaddings } from "./utils/helpers";
import rgba from "./utils/rgba";
import { getStyles } from "./utils/styles";

export default function Pressable(props) {
  const {
    children,
    outlined,
    highlight,
    nativeFeedback,
    withoutFeedback,
    disabled = false,
    theme = {},
    style = {},
    ...rest
  } = props;
  const styles = [
    {
      backgroundColor: "#4630EB",
      minHeight: 8 * 5.5,
      justifyContent: "center",
      paddingHorizontal: 10,
      borderRadius: 4,
    },
    getMargins(props),
    getPaddings(props),
    getStyles(props),
    style,
    theme,
  ];
  if (highlight) {
    return (
      <TouchableHighlight style={styles} {...rest} disabled={disabled}>
        {children}
      </TouchableHighlight>
    );
  }
  if (nativeFeedback) {
    return (
      <TouchableNativeFeedback style={styles} {...rest} disabled={disabled}>
        {children}
      </TouchableNativeFeedback>
    );
  }
  if (withoutFeedback) {
    return (
      <TouchableWithoutFeedback style={styles} {...rest} disabled={disabled}>
        {children}
      </TouchableWithoutFeedback>
    );
  }
  return (
    <TouchableOpacity style={styles} {...rest} disabled={disabled}>
      {children}
    </TouchableOpacity>
  );
}
