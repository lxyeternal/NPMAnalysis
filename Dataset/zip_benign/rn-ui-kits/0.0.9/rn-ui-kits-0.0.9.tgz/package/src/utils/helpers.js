export const getMargins = (props) => {
  const styles = {
    margin: getType(props.m),
    marginTop: getType(props.mt),
    marginBottom: getType(props.mb),
    marginLeft: getType(props.ml),
    marginRight: getType(props.mr),
    marginHorizontal: getType(props.mx),
    marginVertical: getType(props.my),
  };
  return styles;
};
export const getPaddings = (props) => {
  const styles = {
    padding: getType(props.p),
    paddingTop: getType(props.pt),
    paddingBottom: getType(props.pb),
    paddingLeft: getType(props.pl),
    paddingRight: getType(props.pr),
    paddingHorizontal: getType(props.px),
    paddingVertical: getType(props.py),
  };
  return styles;
};
export const getType = (value) => {
  if (typeof value === "number") {
    return value;
  }
  if (typeof value === "string") {
    if (value.includes("%")) {
      return value;
    } else {
      return parseInt(value);
    }
  }
};
