import { getType } from "./helpers";
import rgba from "./rgba";
export const getStyles = (props) => {
  const {
    align = null,
    alignContent = null,
    alignSelf = null,
    bc = null,
    bg = null,
    borderWidth = null,
    bw = null,
    center = false,
    column = false,
    direction = null,
    display = null,
    flex = null,
    h = null,
    disabled = false,
    outlined = false,
    height = null,
    justify = null,
    middle = false,
    opacity = null,
    radius = null,
    row = false,
    w = null,
    width = null,
    wrap = null,
    //fonts
    fontFamily = null,
    size = null,
    fontWeight = null,
    bold = false,
    lineHeight = null,
    letterSpacing = null,
    textTransform = null,
    textAlign = null,
    color = null,
  } = props;

  const style = {};
  if (w || width) {
    style.width = getType(w || width);
  }
  if (h || height) {
    style.height = getType(h || height);
  }
  if (bw || borderWidth) {
    style.borderWidth = getType(bw || borderWidth);
  }
  if (row) {
    style.flexDirection = "row";
  }
  if (column) {
    style.flexDirection = "column";
  }
  if (center) {
    style.alignItems = "center";
  }
  if (flex) {
    style.flex = getType(flex);
  }
  if (middle) {
    style.justifyContent = "center";
  }
  if (justify) {
    style.justifyContent = justify;
  }
  if (align) {
    style.alignItems = align;
  }
  if (alignSelf) {
    style.alignSelf = alignSelf;
  }
  if (direction) {
    style.fleDirection = direction;
  }
  if (alignContent) {
    style.alignContent = alignContent;
  }
  if (wrap) {
    style.flexWrap = "wrap";
  }
  if (radius) {
    style.borderRadius = radius;
  }
  if (bc) {
    style.borderColor = bc;
  }
  if (bg) {
    style.backgroundColor = bg;
  }
  if (opacity) {
    style.opacity = opacity;
  }
  if (display) {
    style.display = display;
  }
  if (fontFamily) {
    style.fontFamily = fontFamily;
  }
  if (size) {
    style.fontSize = getType(size);
  }
  if (fontWeight) {
    style.fontWeight = fontWeight;
  }
  if (bold) {
    style.fontWeight = "bold";
  }
  if (lineHeight) {
    style.lineHeight = lineHeight;
  }
  if (letterSpacing) {
    style.letterSpacing = letterSpacing;
  }
  if (textTransform) {
    style.textTransform = textTransform;
  }
  if (textAlign) {
    style.textAlign = textAlign;
  }
  if (color) {
    style.color = color;
  }
  if (outlined) {
    style.borderWidth = 1;
    style.borderColor = bg;
    style.backgroundColor = "transparent";
  }
  if (disabled) {
    style.backgroundColor = rgba(bg, 0.5);
  }
  return style;
};
