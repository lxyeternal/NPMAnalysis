import React, { useReducer } from "react";
import { TextInput } from "react-native";
import { getMargins, getPaddings } from "./utils/helpers";
import { getStyles } from "./utils/styles";
import rgba from "./utils/rgba";
const INITIAL_STATE = {
  value: null,
  focused: false,
  blurred: false,
};
export const change = (value) => {
  return { type: "change", payload: { value } };
};
export const focus = () => {
  return { type: "focus" };
};
export const blur = () => {
  return { type: "blur" };
};
const reducer = (state, action) => {
  switch (action.type) {
    case "change":
      return { ...state, value: action.payload?.value };
    case "focus":
      return { ...state, focused: true, blurred: false };
    case "blur":
      return { ...state, focused: false, blurred: true };
    default:
      return state;
  }
};

export default function Input(props) {
  const [state, dispatch] = useReducer(reducer, INITIAL_STATE);
  const {
    pattern = null,
    onFocus = null,
    onBlur = null,
    onChangeText = null,
    onValidation = null,
    placeholder = null,
    autoCorrect = false,
    autoCapitalize = "none",
    internalRef = null,
    theme = {},
    style = {},
    type,
    children,
    ...rest
  } = props;

  const handleTextType = (type) => {
    return type === "email"
      ? "emailAddress"
      : type === "phone"
      ? "telephoneNumber"
      : type;
  };
  const handleFocus = (event) => {
    dispatch(focus());
    onFocus && onFocus(event);
  };

  const handleBlur = (event) => {
    dispatch(blur());
    onBlur && onBlur(event);
  };
  const handleValidation = (value) => {
    const { pattern } = props;
    if (!pattern) return true;

    // string pattern, one validation rule
    if (typeof pattern === "string") {
      const condition = new RegExp(pattern, "g");
      return condition.test(value);
    }

    // array patterns, multiple validation rules
    if (typeof pattern === "object") {
      const conditions = pattern.map((rule) => new RegExp(rule, "g"));
      return conditions.map((condition) => condition.test(value));
    }
  };
  const handleChange = (value) => {
    const { onChangeText, onValidation } = props;
    const isValid = handleValidation(value);
    dispatch(change(value));
    onValidation && onValidation(isValid);
    onChangeText && onChangeText(value);
  };
  const textStyles = [
    {
      borderWidth: 1,
      height: 8 * 5.5,
      borderRadius: 4,
      borderColor: rgba("#4630EB", 0.4),
      paddingHorizontal: 8,
      fontSize: 16,
    },
    getStyles(props),
    getMargins(props),
    getPaddings(props),
    style,
    theme,
  ];
  const textType = handleTextType(type);
  const internalProps = {
    style: textStyles,
    autoCorrect,
    autoCapitalize,
    placeholder,
    textContentType: textType,
    value: state.value,
    onFocus: handleFocus,
    onBlur: handleBlur,
    onChangeText: handleChange,
  };
  return (
    <TextInput
      ref={internalRef}
      {...props}
      {...internalProps}
      testID="text-input"
    >
      {children}
    </TextInput>
  );
}
