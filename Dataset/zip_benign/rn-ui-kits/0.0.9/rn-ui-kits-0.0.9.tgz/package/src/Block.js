import React from "react";
import { Animated, SafeAreaView, ScrollView, View } from "react-native";
import { getMargins, getPaddings } from "./utils/helpers";
import { getStyles } from "./utils/styles";

export default function Block(props) {
  const { animated, children, safe, scroll, style, theme, ...rest } = props;
  const marginSpacing = getMargins(props);
  const paddingSpacing = getPaddings(props);
  const blockStyles = getStyles(props);
  if (animated) {
    return (
      <Animated.View
        style={[marginSpacing, paddingSpacing, blockStyles, style, theme]}
        {...rest}
      >
        {children}
      </Animated.View>
    );
  }
  if (safe) {
    return (
      <SafeAreaView
        style={[marginSpacing, paddingSpacing, blockStyles, style, theme]}
        {...rest}
      >
        {children}
      </SafeAreaView>
    );
  }
  if (scroll) {
    return (
      <ScrollView
        style={[marginSpacing, paddingSpacing, blockStyles, style, theme]}
        {...rest}
      >
        {children}
      </ScrollView>
    );
  }

  return (
    <View
      style={[marginSpacing, paddingSpacing, blockStyles, style, theme]}
      {...rest}
    >
      {children}
    </View>
  );
}
