import React from "react";
import { ViewStyle } from "react-native";

type FlexAlignType =
  | "flex-start"
  | "flex-end"
  | "center"
  | "stretch"
  | "baseline";
type FlexContent =
  | "flex-start"
  | "flex-end"
  | "center"
  | "space-between"
  | "space-around";
interface FlexStyle {
  align?: FlexAlignType;
  alignContent?: FlexContent;
  justify?: FlexContent | "stretch" | "space-evenly";
  wrap?: boolean;
  direction?: "row" | "column" | "row-reverse" | "column-reverse";
  flex?: number | string;
  alignSelf?: FlexAlignType;
  row?: boolean;
  column?: boolean;
  center?: boolean;
  middle?: boolean;
}

interface AlignmentProps {
  m?: number | string;
  mb?: number | string;
  mx?: number | string;
  ml?: number | string;
  mr?: number | string;
  mt?: number | string;
  my?: number | string;
  p?: number | string;
  pb?: number | string;
  px?: number | string;
  pl?: number | string;
  pr?: number | string;
  pt?: number | string;
  py?: number | string;
}
interface SizingProps {
  width?: string | number;
  w?: string | number;
  height?: string | number;
  h?: string | number;
  borderWidth?: number;
  bw?: number;
  display?: "none" | "flex";
  radius?: number;
}
interface StyleProps {
  bg?: string;
  bc?: string;
  color?: string;
  opacity?: string;
  style?: ViewStyle;
  theme?: any;
}
export interface BlockProps
  extends SizingProps,
    FlexStyle,
    StyleProps,
    AlignmentProps {
  children?: JSX.Element | JSX.Element[] | string | any;
  safe?: boolean;
  animated?: boolean;
  scroll?: boolean;
  style?: StyleProp<TextStyle> | undefined;
}
export interface TextProps
  extends StyleProps,
    SizingProps,
    AlignmentProps,
    FlexStyle {
  children?: JSX.Element | JSX.Element[] | string | any;
  animated?: boolean;
  fontFamily?: string;
  size?: number | string;
  fontWeight?:
    | "normal"
    | "bold"
    | "100"
    | "200"
    | "300"
    | "400"
    | "500"
    | "600"
    | "700"
    | "800"
    | "900"
    | undefined;
  bold?: boolean;
  lineHeight?: number;
  letterSpacing?: number;
  textTransform?: "none" | "capitalize" | "uppercase" | "lowercase" | undefined;
  textAlign?: "auto" | "left" | "right" | "center" | "justify" | undefined;
  style?: StyleProp<TextStyle> | undefined;
}
export interface ButtonProps
  extends StyleProps,
    SizingProps,
    AlignmentProps,
    FlexStyle {
  children?: JSX.Element | JSX.Element[] | string | any;
  outlined?: boolean;
  highlight?: boolean;
  nativeFeedback?: boolean;
  withoutFeedback?: boolean;
  disabled?: boolean;
  onPress?: ((event: GestureResponderEvent) => void) | undefined;
  onPressIn?: ((event: GestureResponderEvent) => void) | undefined;
  onPressOut?: ((event: GestureResponderEvent) => void) | undefined;
  style?: StyleProp<TextStyle> | undefined;
}

export interface InputProps
  extends SizingProps,
    AlignmentProps,
    FlexStyle,
    StyleProps {
  children?: JSX.Element | JSX.Element[] | string | any;
  pattern?: string | string[];
  autoCorrect?: any;
  autoCapitalize?: any;
  placeholder?: string;
  internalRef?: any;
  type?: string;
  onChangeText?(e: InputState);
  onFocus?(e: NativeSyntheticEvent<TextInputFocusEventData>);
  onBlur?(e: NativeSyntheticEvent<TextInputFocusEventData>);
  onValidation?(e: boolean | boolean[]);
  style?: StyleProp<TextStyle> | undefined;
}
export type InputState = {
  value?: any;
  focused?: boolean;
  blurred?: boolean;
};
export type InputAction = {
  type?: string;
  payload?: InputState;
};

export interface ImageProps
  extends SizingProps,
    AlignmentProps,
    FlexStyle,
    StyleProps {
  children?: JSX.Element | JSX.Element[] | string | any;
  source: ImageSourcePropType;
  style?: StyleProp<ImageStyle> | undefined;
  resizeMode?:
    | "cover"
    | "contain"
    | "stretch"
    | "repeat"
    | "center"
    | undefined;
  theme?: {};
}
export declare const Button: React.FC<ButtonProps>;
export declare const Block: React.FC<BlockProps>;
export declare const Text: React.FC<TextProps>;
export declare const Image: React.FC<ImageProps>;
export declare const INITIAL_STATE: InputState;
export declare const change: (value: any) => {
  type: string;
  payload: {
    value: any;
  };
};
export declare const focus: () => {
  type: string;
};
export declare const blur: () => {
  type: string;
};
export declare const reducer: (
  state: InputState,
  action: InputAction
) => InputState;
export declare const Input: React.FC<InputProps>;
