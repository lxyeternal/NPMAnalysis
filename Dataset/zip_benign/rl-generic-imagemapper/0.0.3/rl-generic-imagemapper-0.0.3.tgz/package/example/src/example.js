var React = require("react");
var ReactDOM = require("react-dom");
var ImageMapper = require("react-image-mapper");



var maps = {
            name: "ocr",
	        areas: [
                    {
                        name: "6",
                        shape: "rect",
                        coords: [288,130,217,113],
                        lineWidth: 2,
                        preFillColor: "rgba(255, 255, 255, 0.3)",
                        strokeColor: "#303F9F"
                    }
	            ]
        }
var MAP = {
	name: "my-map",
	areas: [
		{
			name: "1",
			shape: "poly",
			coords: [25, 33, 27, 300, 128, 240, 128, 94],
			preFillColor: "green",
			fillColor: "#0000ff"
		},
		{
			name: "2",
			shape: "poly",
			coords: [219, 118, 220, 210, 283, 210, 284, 119],
			preFillColor: "pink",
			lineWidth: 10,
			strokeColor: "#0000ff"
		},
		{
			name: "3",
			shape: "poly",
			coords: [381, 241, 383, 94, 462, 53, 457, 282],
			preFillColor: "yellow", // this is mandatory for stroke color to work
			lineWidth: 10,
			strokeColor: "#6afd09"
		},
		{
			name: "4",
			shape: "poly",
			coords: [245, 285, 290, 285, 274, 239, 249, 238],
			preFillColor: "red"
		},
		{
			name: "5",
			shape: "circle",
			coords: [170, 100, 25],
			preFillColor: "rgb(255,255,255,0.3)",
			lineWidth: 2
		},
		{
			name: "6",
			shape: "rect",
			coords: [270, 100, 200, 50],
			lineWidth: 2,
			preFillColor: "rgba(255, 255, 255, 0.3)",
			strokeColor: "#6afd09"
		}
	]
};

var URL = "https://spectrafiles.relevancelab.com/inova_pdf/AnaSantos-102[92]-1.png";

var App = React.createClass({
	
	render() {
		return (
			
				<span style={{width:"100%",height:"100%",position:"absolute"}}>
					<span style={{width:"30%",height:"50%",position:"absolute"}}>
						patient Name
					</span>
					<span style={{marginLeft:"30%",width:"50%",height:"50%",position:"absolute"}}>
					   <ImageMapper  src={URL} map={maps} width={570}  />
					</span>
				</span>
			
		);
	}
});

ReactDOM.render(<App />, document.getElementById("app"));
