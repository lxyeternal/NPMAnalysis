import { Config } from './src/models/config.model';
declare const config: Config;
export default config;
//# sourceMappingURL=npm-increaser-downloads.config.d.ts.map