export declare class Stats {
    successfulDownloads: number;
    failedDownloads: number;
    private startTime;
    constructor(startTime: number, successfulDownloads?: number, failedDownloads?: number);
    getDownloadSpeed(): number;
    getTimeRemaining(): number | null;
}
//# sourceMappingURL=stats.model.d.ts.map