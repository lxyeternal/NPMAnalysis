import { Config } from "../models/config.model";
export declare const getPackageName: () => Promise<string>;
export declare const getNumberOfDownloads: () => Promise<number>;
export declare const getMaxConcurrentDownloads: () => Promise<number>;
export declare const getDownloadTimeout: () => Promise<number>;
export declare const getConfigFromCli: () => Promise<Config>;
//# sourceMappingURL=prompts.d.ts.map