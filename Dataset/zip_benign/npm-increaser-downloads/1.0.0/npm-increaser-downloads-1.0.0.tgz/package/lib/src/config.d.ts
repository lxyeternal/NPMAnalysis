import { Config } from "./models/config.model";
export declare const getConfig: () => Config;
export declare const setConfig: (newConfig: Config) => void;
//# sourceMappingURL=config.d.ts.map