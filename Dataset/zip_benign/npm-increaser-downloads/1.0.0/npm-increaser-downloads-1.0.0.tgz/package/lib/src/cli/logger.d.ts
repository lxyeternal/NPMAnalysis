import { Ora } from "ora";
import { Stats } from "../models/stats.model";
export declare const terminalSpinner: Ora;
export declare const mapToString: (num: number) => string;
export declare const mapToDate: (seconds: number | null) => string;
export declare const logDownload: (stats: Stats) => void;
export declare const logComplete: () => void;
export declare const logError: (error: Error) => void;
//# sourceMappingURL=logger.d.ts.map