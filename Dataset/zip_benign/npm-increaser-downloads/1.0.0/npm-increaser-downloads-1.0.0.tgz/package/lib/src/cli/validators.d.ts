export declare const validatePackageName: (packageName: string) => string | boolean;
export declare const validateNumbers: (num: number | undefined) => string | boolean;
//# sourceMappingURL=validators.d.ts.map