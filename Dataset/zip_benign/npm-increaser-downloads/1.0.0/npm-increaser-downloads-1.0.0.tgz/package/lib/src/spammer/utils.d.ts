export declare const stripOrganisationFromPackageName: (packageName: string) => string;
export declare const getEncodedPackageName: (packageName: string) => string;
//# sourceMappingURL=utils.d.ts.map