import { NpmjsResponse } from "../models/npmjs-response.model";
import { NpmsioResponse } from "../models/npmsio-response.model";
import { Stats } from "../models/stats.model";
export declare const getNpmsioResponse: () => Promise<NpmsioResponse>;
export declare const getNpmjsResponse: () => Promise<NpmjsResponse>;
export declare const getVersionPackage: () => Promise<string>;
export declare const downloadPackage: (version: string, stats: Stats) => Promise<unknown>;
/**
 * Runs the download spammer.
 * @returns A Promise that resolves when the spamming is complete.
 */
export declare const run: () => Promise<void>;
//# sourceMappingURL=spammer.d.ts.map