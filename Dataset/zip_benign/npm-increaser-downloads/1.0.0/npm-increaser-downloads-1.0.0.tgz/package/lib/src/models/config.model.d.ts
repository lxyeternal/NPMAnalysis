export interface Config {
    numDownloads: number;
    packageName: string;
    maxConcurrentDownloads: number;
    downloadTimeout: number;
}
//# sourceMappingURL=config.model.d.ts.map