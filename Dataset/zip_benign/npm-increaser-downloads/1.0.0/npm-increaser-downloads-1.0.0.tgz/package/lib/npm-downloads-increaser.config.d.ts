export const packageName: string;
export const numDownloads: number;
export const maxConcurrentDownloads: number;
export const downloadTimeout: number;
//# sourceMappingURL=npm-downloads-increaser.config.d.ts.map