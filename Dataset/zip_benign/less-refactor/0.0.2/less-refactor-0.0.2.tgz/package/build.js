let esbuild = require('esbuild');

esbuild.buildSync({
  entryPoints: ['src/index.js', 'src/cli.js'],
  outdir: 'dist',
  bundle: true,
  // minify: true,
  format: 'cjs',
  sourcemap: true,
  external: ['fs', 'path', 'readline', 'events', 'child_process'],
})
