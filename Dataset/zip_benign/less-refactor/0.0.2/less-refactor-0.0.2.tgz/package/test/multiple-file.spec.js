const assert = require('assert');
const {analysisDir} = require('../');

describe('Files', function () {
  it('file testings', function () {
    let result = analysisDir('_fixtures/less/color');

    assert.strictEqual(result.issues.length, 5);
    assert.strictEqual(result.colorMappings['#ddd'], '@color1');
  });
});
