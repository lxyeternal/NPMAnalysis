const assert = require('assert');
const {refactorAnalysis} = require('../');

describe('Important', function () {
  it('important checker', function () {
    let result = refactorAnalysis(`
h1 {
  color: #dddddd !important;
  color: firebrick !important;
}

`, 'demo.less', 1);

    assert.strictEqual(Object.keys(result.importants).length, 2);
  });
});
