const assert = require('assert');
const {refactorAnalysis} = require('../');

describe('Box Shadow', function () {
  it('shadow color', function () {
    let result = refactorAnalysis(`
h1 {
  box-shadow: 60px -16px teal;
  box-shadow: 10px 5px 5px black;
  box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);
  box-shadow: inset 5em 1em gold;
  box-shadow: 3px 3px red, -1em 0 0.4em olive;

}
`, 'demo.less', 1);

    assert.strictEqual(Object.keys(result.colorMappings).length, 5);
  });
});
