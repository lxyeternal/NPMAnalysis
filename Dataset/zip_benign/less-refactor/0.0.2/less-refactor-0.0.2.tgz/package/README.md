# CSS/LESS/CSS Auto Refactor 

Features:

 - [x] Color refactor
   - [x] analysis colors
   - [x] auto-refactor colors

Todo:

 - [ ] migration to TypeScript
    - [ ] split ast packages
    - [ ] use lerna
    - [ ] use esbuild

## Refactor Color

1. analysis files

```
node dist/cli.js analysis _fixtures
```

2. modify `mappings.less` to current vars

```less
// _fixtures/less/color/border.less
@color1: #ddd;
// _fixtures/less/color/border.less
@color2: green;
// _fixtures/less/color/rgba.less
@color3: rgba(255, 0, 0, 0.3);
// _fixtures/less/color/sample.less
@color4: #FF7F50;
// _fixtures/less/color/sample.less
// _fixtures/less/color/sample2.less
@color5: #800080;
// _fixtures/less/color/sample.less
@color6: red;
// _fixtures/less/color/sample.less
// _fixtures/less/color/sample.less
@color7: #428bca;
// _fixtures/less/color/sample.less
@color8: #fff;
// _fixtures/less/color/sample2.less
@color9: #000000;
```

3. run refactoring

```
node dist/cli.js refactor _fixtures
```

## Todo

### Change to Less API

```javascript
var less = require('less'), fs = require('fs'), path = require('path');

var src = './test_import.less';
var result = less.parse(fs.readFileSync(src).toString(), {
  filename: path.resolve(src)
}, function(e, tree) {
  console.log(JSON.stringify(tree, null, 2));
});
```
