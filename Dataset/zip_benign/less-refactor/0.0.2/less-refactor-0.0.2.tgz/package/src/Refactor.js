import {spliceSlice} from './CodeModifer';
import mappingAnalysis from './MappingAnalysis';

const fs = require('fs');

function modifyFile(data, fileIssue, mappings) {
  const lines = data.split(/\r?\n/);

  for (let issue of fileIssue.issues) {
    let line = lines[issue.start.line - 1];
    line = spliceSlice(line, issue.start.column, issue.origin.length, mappings[issue.origin]);
    lines[issue.start.line - 1] = line;
  }
  return lines;
}

export function refactorDir(mappingFile, issuesFile) {
  const fileContents = fs.readFileSync(mappingFile, 'utf8');
  let mappings = mappingAnalysis(fileContents).mapping;

  const issues_text = fs.readFileSync(issuesFile, 'utf8');
  const allIssues = JSON.parse(issues_text).issues;

  for (let fileIssue of allIssues) {
    const data = fs.readFileSync(fileIssue.filePath, 'UTF-8');
    let lines = modifyFile(data, fileIssue, mappings);

    fs.writeFileSync(fileIssue.filePath, lines.join('\n'));
  }
}
