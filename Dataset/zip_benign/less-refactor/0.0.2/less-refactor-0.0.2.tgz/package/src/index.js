import refactorAnalysis from './RefactorAnalysis';
import mappingAnalysis from './MappingAnalysis';
import {analysisDir} from './Analysis';
import {refactorDir} from './Refactor';
import {hexThreeToSix} from './color/HexConvert';
import {colourNameToHex} from './CssColors';

const ColorSupport = {
  hexThreeToSix,
  colourNameToHex
}

export {
  refactorAnalysis,
  mappingAnalysis,
  analysisDir,
  refactorDir,
  ColorSupport
}
