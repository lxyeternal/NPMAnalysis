const fs = require('fs');

import {walkDir} from "./FileSupport";
import refactorAnalysis from "./RefactorAnalysis";

export function analysisDir(dir) {
  let data = {
    colorMappings: {},
    issues: [],
    fontFamily: [],
    importants: [],
    mediaQueries: [],
    colorFileMaps: {},
    summary: {}
  }

  let colorIndex = 1;
  walkDir(dir, function (filePath) {
    const filename = filePath.replace(/^.*[\\\/]/, '');

    if (!(filename.endsWith('.less') || filename.endsWith('.css'))) {
      return;
    }

    const fileContents = fs.readFileSync(filePath, 'utf8');
    let result = refactorAnalysis(fileContents, filePath, colorIndex);

    colorIndex = result.colorIndex;
    if (result.metadata.issues.length !== 0) {
      data.issues = data.issues.concat(result.metadata);
    }

    data.fontFamily = data.fontFamily.concat(result.metadata.fontFamily);
    data.importants = data.importants.concat(result.metadata.importants);
    data.mediaQueries = data.mediaQueries.concat(result.metadata.mediaQueries);

    Object.assign(data.colorMappings, result.colorMappings);
    Object.assign(data.colorFileMaps, result.colorFileMaps);
  });

  data.summary = {
    colors: Object.keys(data.colorMappings).length,
    importants: data.importants.length,
    mediaQueries: data.mediaQueries.length,
    issues: Object.keys(data.issues).length
  }

  fs.writeFileSync("results.json", JSON.stringify(data, null, '\t'));

  fs.writeFileSync("mappings.less", buildMappings(data.colorMappings, data.colorFileMaps));

  return data;
}

function buildMappings(json, colorFileMaps) {
  let ret = '';
  for (const key in json) {
    let files = colorFileMaps[key];
    for (let file of files) {
      ret = `${ret}// ${file}
`;
    }
    ret = `${ret + [json[key]]}: ${key};
`;
  }
  return ret;
}
