import {CSS_COLOR_NAMES} from "./CssColors";
import {LessParserListener} from "./ast/LessParserListener";

let Checker = {
  hasColor: function (value) {
    return value.startsWith('#')
      || CSS_COLOR_NAMES.includes(value.toLowerCase())
      || value.startsWith('rgba')
      || value.startsWith('rgb');
  },
  hasImportant: function (value) {
    return value.includes('!important');
  }
}

export class RefactorAnalysisListener extends LessParserListener {
  setMetaData(data) {
    this.metadata = data;
  }

  enterMedia(ctx) {
    if (!this.metadata.mediaQueries) {
      this.metadata.mediaQueries = [];
    }

    this.metadata.mediaQueries.push({
      type: '@media',
      file: this.metadata.filePath,
      start: ctx.start.line,
      end: ctx.stop.line
    })
  }

  enterBlock(ctx) {

  }

  enterProperty(ctx) {
    let propertyKey = ctx.children[0].getText();
    let valuesExpr = ctx.children[2];
    let propertyValue = valuesExpr.getText();

    if (Checker.hasImportant(propertyValue)) {
      if (!this.metadata.importants) {
        this.metadata.importants = [];
      }

      this.metadata.importants.push({
        type: '!important',
        file: this.metadata.filePath,
        line: valuesExpr.start.line
      })
    }

    switch (propertyKey) {
      case 'color':
      case 'background-color':
      case 'border-color':
        if (Checker.hasColor(propertyValue)) {
          this.append_issue(valuesExpr, 'color');
          this.updateColorMap(valuesExpr);
        }
        break;

      case 'border':
      case 'border-right':
      case 'border-left':
      case 'border-bottom':
      case 'border-top':
      case 'border-right-color':
      case 'border-left-color':
      case 'border-bottom-color':
      case 'border-top-color':
      case 'box-shadow':
      case 'background':
        if (!valuesExpr.children) {
          return;
        }

        let commandStatement = valuesExpr.children[0];
        for (let child of commandStatement.children) {
          if (Checker.hasColor(child.getText())) {
            this.append_issue(child, 'color');
            this.updateColorMap(child);
          }
        }
        break;
      case "font-family":
        if (!this.metadata.fontFamily) {
          this.metadata.fontFamily = [];
        }

        this.metadata.fontFamily.push({
          type: 'font-family',
          origin: this.getOriginText(valuesExpr),
          file: this.metadata.filePath,
          start: {
            line: valuesExpr.start.line,
            column: valuesExpr.start.column
          },
          stop: {
            line: valuesExpr.stop.line,
            column: valuesExpr.stop.column
          }
        })
        break;
    }
  }

  updateColorMap(valuesExpr) {
    let text = this.getOriginText(valuesExpr);
    if (!this.COLOR_MAPS[text]) {
      this.COLOR_MAPS[text] = '@color' + this.COLOR_INDEX;
      this.COLOR_INDEX = this.COLOR_INDEX + 1;
    }

    let line = valuesExpr.start.line;
    if (!this.COLOR_FILE_MAPS[text]) {
      this.COLOR_FILE_MAPS[text] = [this.metadata.filePath + ':' + line];
    } else {
      this.COLOR_FILE_MAPS[text].push(this.metadata.filePath + ':' + line);
    }
  }

  append_issue(node, type) {
    // todo: make get from input
    this.metadata.issues.push({
      type: type,
      origin: this.getOriginText(node),
      start: {
        line: node.start.line,
        column: node.start.column
      },
      stop: {
        line: node.stop.line,
        column: node.stop.column
      }
    })
  }

  getOriginText(node) {
    let inputStream = node.start.getInputStream();
    if (!inputStream) {
      return node.getText();
    }

    return inputStream.getText(node.start.start, node.stop.stop);
  }
}

RefactorAnalysisListener.prototype.metadata = {};
RefactorAnalysisListener.prototype.COLOR_MAPS = {};
RefactorAnalysisListener.prototype.COLOR_FILE_MAPS = {};
RefactorAnalysisListener.prototype.COLOR_INDEX = 0;
