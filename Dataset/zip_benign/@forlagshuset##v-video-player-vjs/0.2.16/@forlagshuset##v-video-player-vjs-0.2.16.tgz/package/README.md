# Customizable VideoPlayer component

## Installation

`npm install @forlagshuset/v-video-player-vjs`

## Usage
```javascript
import FHVideoPlayer from '@forlagshuset/v-video-player-vjs'

export default {
  data() {
    return {
      videoUrl: '',
      videoType: 'video/mp4',
      videoAttributes: {
        poster: '',
        crossorigin: '',
        playsinline: '',
        controls: ''
      },
      captions: [
        {
          label: 'Norwegian Nynorsk',
          srclang: 'nn',
          src: '',
        },
        {
          label: 'Norwegian Bokmål',
          srclang: 'nb',
          src: ''
        }
      ],
      options: {
        playbackRates: [0.5, 1, 1.5, 2],
        language: 'nb'
      }
    }
  },

  components: {
    FHVideoPlayer
  }
}
```

## Props
FHVideoPlayerVJS accepts these props:

```javascript
  props: {
    videoUrl: {
      type: String,
      default: null,
      required: true
    },
    videoType: {
      type: String,
      default: 'video/mp4'
    },
    videoAttributes: {
      type: Object,
      default: null
    },
    captions: {
      type: Array,
      default: null,
      required: true
    },
    chapters: {
      type: Array
    },
    options: {
      type: Object,
      default: obj => {
        /*
          Available options from VJS: https://docs.videojs.com/tutorial-options.html

          Component specific:
          skipTime: Number
        */
      }
    }
  },
```

Uses `video.js` plugin.
