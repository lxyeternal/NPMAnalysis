import videojs from 'video.js'


const getElementBounding = element => {
  let elementBounding
  const defaultBoundingRect = {
    top: 0,
    bottom: 0,
    left: 0,
    width: 0,
    height: 0,
    right: 0
  }

  try {
    elementBounding = element.getBoundingClientRect()
  } catch (e) {
    elementBounding = defaultBoundingRect
  }

  return elementBounding
}

class ChapterMarkers {
  constructor(player, chapters) {
    if (!chapters.length) return

    this.player = player
    this.chapters = chapters

    this.init()
  }

  init() {
    this.addMarkers(this.chapters)
  }

  addMarkers(newMarkers) {
    newMarkers.forEach(marker => {
      this.player.el().querySelector('.vjs-progress-holder')
        .appendChild(this.createMarkerDiv(marker))
    })
  }

  createMarkerDiv(marker) {
    const markerDiv = videojs.dom.createEl('div', {}, {
      'data-marker-title': marker.title,
      'data-marker-time': marker.start
    })

    this.setMarkerDivStyle(marker, markerDiv)

    markerDiv.addEventListener('click', () => {
      this.player.currentTime(marker.start)
    })

    return markerDiv
  }

  getPosition(marker) {
    return (marker.start / this.player.duration()) * 100
  }

  setMarkerDivStyle(marker, markerDiv) {
    markerDiv.className = 'vjs-marker'

    const ratio = marker.start / this.player.duration()
    if (ratio < 0 || ratio > 1) {
      markerDiv.style.display = 'none'
    }

    markerDiv.style.left = this.getPosition(marker) + '%'

    const markerDivBounding = getElementBounding(markerDiv)

    markerDiv.style.marginLeft = markerDivBounding.width / 2 + 'px'
  }
}

export default ChapterMarkers
