import videojs from 'video.js'

const Button = videojs.getComponent('Button')

const DEFAULT_SKIP_TIME = 30

class SkipButton extends Button {
  constructor(player, options = {}) {
    super(player, options)
    this.player = player
    this.skipType = options.type
    this.skipTime = options.skipTime || DEFAULT_SKIP_TIME
    this.controlText(`Skip ${this.skipType} ${this.skipTime}s`)
    this.setClass()
    this.el().querySelector('.vjs-icon-placeholder').dataset.skipTime = this.skipTime
  }

  handleClick() {
    const updatedTime = this.skipType === 'forward' ?
      this.player.currentTime() + this.skipTime :
      this.player.currentTime() - this.skipTime

    this.player.currentTime(updatedTime)
  }

  setClass() {
    this.addClass('c-video-player__skip-button')
    this.addClass(`c-video-player__skip-button--${this.skipType}`)
  }
}

export default SkipButton
