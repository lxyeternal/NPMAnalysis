import videojs from 'video.js'

const Button = videojs.getComponent('Button')

class ChaptersNav {
  constructor(player, chapters) {
    if (!chapters.length) return

    this.player = player
    this.chapters = chapters

    this.chaptersStartTimeList = []
    this.currentChapterIndex = null

    this.nextButton = null
    this.prevButton = null

    this.init()
  }

  init() {
    this.chaptersStartTimeList = this.chapters.map(chapter => chapter.start)

    this.prevButton = new Button(this.player)
    this.prevButton.on('click', () => {
      if (this.currentChapterIndex === 0) return
      this.player.currentTime(this.chaptersStartTimeList[this.currentChapterIndex - 1])
      this.currentChapterIndex = this.currentChapterIndex - 1
    })
    this.prevButton.addClass('vjs-chapters-nav')
    this.prevButton.addClass('vjs-chapters-nav__prev')
    this.prevButton.el().innerHTML = this.prevButton.localize('Previous chapter')

    this.nextButton = new Button(this.player)
    this.nextButton.on('click', () => {
      if (this.currentChapterIndex === this.chaptersStartTimeList.length - 1) return
      if (this.currentChapterIndex === null) {
        this.player.currentTime(this.chaptersStartTimeList[0])
        this.currentChapterIndex = 0

        return
      }
      this.player.currentTime(this.chaptersStartTimeList[this.currentChapterIndex + 1])
      this.currentChapterIndex = this.currentChapterIndex + 1
    })
    this.nextButton.addClass('vjs-chapters-nav')
    this.nextButton.addClass('vjs-chapters-nav__next')
    this.nextButton.el().innerHTML = this.nextButton.localize('Next chapter')

    this.player.addChild(this.prevButton)
    this.player.addChild(this.nextButton)
    this.player.on('timeupdate', () => {
      this.updateNav()
    })
  }

  updateNav() {
    const currentTime = this.player.currentTime()
    const filterTime = this.chaptersStartTimeList.filter(num => num <= currentTime)

    if (!filterTime.length) {
      this.currentChapterIndex = null
    } else {
      this.currentChapterIndex = this.chaptersStartTimeList.indexOf(Math.max(...filterTime))
    }

    this.handleButtonVisibility()
  }

  handleButtonVisibility() {
    if (!this.currentChapterIndex) {
      this.prevButton.hide()
    } else {
      this.prevButton.show()
    }
    if (this.currentChapterIndex === this.chaptersStartTimeList.length - 1) {
      this.nextButton.hide()
    } else {
      this.nextButton.show()
    }
  }
}

export default (player, chapters) => new ChaptersNav(player, chapters)
