<template>
  <video
    class="c-video-player video-js"
    v-if="videoUrl"
    v-bind="videoAttributes"
    ref="player"
  >
    <source
      :src="videoUrl"
      :type="videoType"
    />
    <track
      v-for="(track, index) in textTracks"
      :key="`${index}-${track.label}`"
      :label="track.label"
      :srclang="track.srclang"
      :src="track.src"
      :kind="track.kind"
    />
  </video>
</template>

<script>
import videojs from 'video.js'
import nb from 'video.js/dist/lang/nb.json'
import nn from 'video.js/dist/lang/nn.json'
import languages from './i18n/languages.json'
import 'video.js/dist/video-js.min.css'

import SkipButton from './src/extensions/SkipButton'
import ChapterMarkers from './src/extensions/ChapterMarkers'
import ChaptersNav from './src/extensions/ChaptersNav'

// Add support for languages
videojs.addLanguage('nb', nb)
videojs.addLanguage('nn', nn)

const DEFAULT_EVENTS = [
  'loadeddata',
  'loadedmetadata',
  'canplay',
  'canplaythrough',
  'play',
  'pause',
  'waiting',
  'playing',
  'ended',
  'error'
]

export default {
  name: 'fh-video-player',

  data() {
    return {
      player: null,
      mergedOptions: {},
      defaultOptions: {
        fluid: true,
        languages,
      }
    }
  },

  props: {
    events: {
      type: Array,
      default: () => []
    },
    videoUrl: {
      type: String,
      default: null,
      required: true
    },
    videoType: {
      type: String,
      default: 'video/mp4'
    },
    videoAttributes: {
      type: Object,
      default: null
    },
    textTracks: {
      type: Array,
      default: null
    },
    chapters: {
      type: Array,
      default: () => []
    },
    options: {
      type: Object,
      default: obj => {}
    }
  },

  mounted() {
    // Merge options
    Object.assign(this.mergedOptions, this.defaultOptions, this.options)

    // Instantiate player with skip buttons
    this.player = videojs(this.$refs.player, this.mergedOptions, () => {
      this.init()
    })
  },

  beforeDestroy() {
    if (this.player) {
      this.player.dispose()
    }
  },

  methods: {
    init() {
      const events = DEFAULT_EVENTS.concat(this.events)
      const checkForTracksLoad = () => setTimeout(() => {
        if (this.player.textTracks_.tracks_ !== null) {
          this.$emit('texttracksloaded', this.player.textTracks_.tracks_)

          return
        }

        checkForTracksLoad()
      }, 500)

      if (this.textTracks.length) {
        checkForTracksLoad()
      }

      if (this.chapters.length) {
        this.addChapterMarkers()
        this.addChaptersNav()
      }
      this.addSkipButtons()

      events.forEach(event => {
        if (typeof event === 'string') {
          this.player.on(event, () => {
            this.emitter(event)
          })
        }
      })
      this.player.on('timeupdate', () => {
        this.emitter('timeupdate', this.player.currentTime())
      })
      this.emitter('ready')
    },

    addChaptersNav() {
      ChaptersNav(this.player, this.chapters)
    },

    addChapterMarkers() {
      this.player.on('loadedmetadata', () => {
        const markers = new ChapterMarkers(this.player, this.chapters)
      })
    },

    addSkipButtons() {
      const btnBackward = new SkipButton(this.player, {
        type: 'backward',
        skipTime: this.mergedOptions.skipTimeBackward
      })
      const btnForward = new SkipButton(this.player, {
        type: 'forward',
        skipTime: this.mergedOptions.skipTimeForward
      })
      this.player.controlBar.addChild(btnBackward, {}, 1)
      this.player.controlBar.addChild(btnForward, {}, 2)
    },

    emitter(ev, value) {
      if (ev) {
        this.$emit(ev, value || this.player)
      }
    }
  }
}
</script>

<style lang="scss">
@import './src/scss/fonts';
@import './src/scss/skip-button';

.c-video-player {
  .vjs-big-play-button {
    top: 50%;
    transform: translateY(-50%);
    margin: 0 auto;
    left: 0;
    right: 0;

    height: 3em;

    border-radius: 50%;

    .vjs-icon-placeholder {
      display: flex;
      align-items: center;
      justify-content: center;

      &::before {
        font-size: 2.5em;
        position: relative;
      }
    }
  }

  .vjs-control-bar {
    font-size: 1.2em;
    height: 60px;
    padding-top: 18px;
    background: none;
    background-image: linear-gradient(0deg,#000,transparent);
  }

  .vjs-progress-control {
    position: absolute;
    width: 100%;
    top: 0;
    right: 0;
    left: 0;
    height: 20px;
  }

  .vjs-current-time,
  .vjs-time-divider,
  .vjs-duration {
    display: block;
  }

  .vjs-time-divider {
    padding: 0;
    min-width: auto;
  }

  .vjs-remaining-time {
    display: none;
  }

  .vjs-custom-control-spacer {
    display: block;
    width: 100%;
  }

  .vjs-slider-bar {
    color: #7D91F9;
  }

  .vjs-play-progress {
    background: #7D91F9;
    &::before {
      z-index: 4;
    }
  }

  .vjs-load-progress {
    background-color: #fff;

    > div {
      background: #C7D0FF;
    }
  }

  .vjs-marker {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 10px;
    height: 100%;
    background: #FF7A7A;
    z-index: 3;

    &:hover {
      transform: scale(1.3, 1.3);
      cursor: pointer;
    }
  }

  .vjs-chapters-nav {
    position: absolute;
    bottom: 75px;
    width: auto;
    height: auto;
    padding: 1em 1.5em;
    visibility: hidden;
    opacity: 0;
    transition: visibility 0.1s, opacity 0.1s;

    border: 1px solid #fff;
    background: rgba(33, 33, 33, 0.6);
    cursor: pointer;

    &:hover {
      background: #fff;
      color: #333;
    }
  }

  &.vjs-has-started.vjs-user-active .vjs-chapters-nav,
  &.vjs-has-started.vjs-user-inactive.vjs-paused .vjs-chapters-nav {
    visibility: visible;
    opacity: 1;
  }

  &.vjs-has-started.vjs-user-inactive .vjs-chapters-nav {
    visibility: visible;
    opacity: 0;
  }

  .vjs-chapters-nav__prev {
    left: 10px;
  }

  .vjs-chapters-nav__next {
    right: 10px;
  }
  
  .vjs-text-track-display {
    bottom: 1em;
    transform: translateY(0);
    transition: transform 0.5s;
  }

  &.vjs-user-active.vjs-playing,
  &.vjs-paused,
  &.vjs-ended {
    .vjs-text-track-display {
      transform: translateY(-4em);
    }
  }
}
</style>
