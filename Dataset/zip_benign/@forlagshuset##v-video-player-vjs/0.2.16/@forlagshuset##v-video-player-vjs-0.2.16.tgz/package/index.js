import FHVideoPlayer from './FHVideoPlayer.vue';
export default FHVideoPlayer
