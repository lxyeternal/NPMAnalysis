import { mount } from '@vue/test-utils'

import FHVideoPlayer from './FHVideoPlayer.vue'

let wrapper,
    video,
    source,
    track,
    videoUrl,
    videoType,
    videoAttributes,
    textTracks

beforeEach(() => {
  videoUrl = 'https://www.radiantmediaplayer.com/media/bbb-360p.mp4'
  videoType = 'video/mp4'
  videoAttributes = {
    poster: 'https://www.apexcartage.com/wp-content/uploads/2014/05/placeholder-red.png',
    preload: 'metadata',
    crossorigin: '',
    playsinline: '',
    controls: ''
  }
  textTracks = [
    {
      label: "Norwegian Nynorsk",
      srclang: "nn",
      src: "https://res.cloudinary.com/demo/raw/upload/outdoors.vtt",
      kind: "subtitles"
    },
    {
      label: "Norwegian Bokmål",
      srclang: "nb",
      src: "https://res.cloudinary.com/demo/raw/upload/outdoors.vtt",
      kind: "subtitles"
    }
  ]

  wrapper = mount(FHVideoPlayer, {
    propsData: {
      videoUrl,
      videoType,
      videoAttributes,
      textTracks
    },
    methods: {}
  })

  video = wrapper.find('video')
  source = wrapper.find('source')
  track = wrapper.find('track')
})

afterEach(() => {
  wrapper.destroy()
})

describe('FHVideoPlayer', () => {
  it('renders props when passed', () => {
    expect(wrapper.html()).toMatch('video')
    expect(wrapper.html()).toMatch('source')
    expect(wrapper.html()).toMatch('track')
    expect(video.attributes().poster).toBe('https://www.apexcartage.com/wp-content/uploads/2014/05/placeholder-red.png')
    expect(video.attributes().preload).toBe('metadata')
    expect(video.attributes().crossorigin).toBeDefined()
    expect(video.attributes().playsinline).toBeDefined()
    expect(source.attributes().src).toBe('https://www.radiantmediaplayer.com/media/bbb-360p.mp4')
    expect(source.attributes().type).toBe('video/mp4')
    expect(track.attributes().label).toBe('Norwegian Nynorsk')
    expect(track.attributes().srclang).toBe('nn')
    expect(track.attributes().src).toBe('https://res.cloudinary.com/demo/raw/upload/outdoors.vtt')
  })

  it('has player instance', () => {
    expect(wrapper.vm.player).toBeDefined()
  })

  it('has chapters property', () => {
    wrapper.setProps({
      chapters: [
        {
          title: 'Chapter 1',
          start: 20,
          end: 39
        },
        {
          title: 'Chapter 2',
          start: 40,
          end: 100
        }
      ]
    })

    expect(wrapper.props('chapters').length > 0).toBe(true)
  })
})
