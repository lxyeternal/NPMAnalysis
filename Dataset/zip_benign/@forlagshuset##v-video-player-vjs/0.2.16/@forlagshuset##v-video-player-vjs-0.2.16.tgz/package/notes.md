# FH Video Player VJS component

**FH Video Player VJS** uses video-js plugin.   

Attributes and captions can be send as props.

https://icomoon.io/ - icon font available to edit. Login with it.fagbok@gmail.com
