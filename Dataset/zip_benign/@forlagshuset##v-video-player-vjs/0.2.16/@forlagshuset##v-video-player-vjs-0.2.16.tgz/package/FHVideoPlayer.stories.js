import { withKnobs, text, object } from '@storybook/addon-knobs'
import { withA11y } from '@storybook/addon-a11y'
import FHVideoPlayer from './FHVideoPlayer.vue'
import notes from './notes.md'

export default {
  title: 'Components|v-video-player-vjs',
  decorators: [withKnobs, withA11y]
}

const textTracksArray = [
  {
    label: "Norwegian Nynorsk",
    srclang: "nn",
    src: "https://res.cloudinary.com/demo/raw/upload/outdoors.vtt",
    kind: "subtitles"
  },
  {
    label: "Norwegian Bokmål",
    srclang: "nb",
    src: "https://res.cloudinary.com/demo/raw/upload/outdoors.vtt",
    kind: "subtitles"
  }
]

const attributesObject = {
  poster: 'https://www.apexcartage.com/wp-content/uploads/2014/05/placeholder-red.png',
  controls: '',
  preload: 'metadata',
  crossorigin: '',
  playsinline: '',
}

const chapters = [
  {
    title: 'Chapter 1 🏓',
    start: 20,
    end: 39
  },
  {
    title: 'Chapter 2 🤠',
    start: 40,
    end: 100
  }
]

export const withAttributes = () => {
  return {
    components: { FHVideoPlayer },
    props: {
      videoUrl: {
        type: String,
        default: text('Video Url', 'https://www.radiantmediaplayer.com/media/bbb-360p.mp4')
      },
      videoType: {
        type: String,
        default: text('Video Type', 'video/mp4')
      },
      videoAttributes: {
        type: Object,
        default: object('Attributes', attributesObject)
      },
      textTracks: {
        type: Array,
        default: object('Captions Array', textTracksArray)
      }
    },
    template: `<FHVideoPlayer key="withAttributes" :video-url="videoUrl" :video-type="videoType" :text-tracks="textTracks" :video-attributes="videoAttributes"></FHVideoPlayer>`
  }
}

withAttributes.story = {
  name: 'With Attributes',
  parameters: { notes: notes }
}

export const withChapters = () => {
  return {
    components: { FHVideoPlayer },
    props: {
      videoUrl: {
        type: String,
        default: text('Video Url', 'https://www.radiantmediaplayer.com/media/bbb-360p.mp4')
      },
      videoType: {
        type: String,
        default: text('Video Type', 'video/mp4')
      },
      videoAttributes: {
        type: Object,
        default: object('Attributes', attributesObject)
      },
      captions: {
        type: Array,
        default: object('Captions Array', captionsArray)
      },
      chapters: {
        type: Array,
        default: object('Chapters', chapters)
      }
    },
    template: `<FHVideoPlayer :video-url="videoUrl" :video-type="videoType" :chapters="chapters" :captions="captions" :video-attributes="videoAttributes"></FHVideoPlayer>`
  }
}

withChapters.story = {
  name: 'With Chapters',
  parameters: { notes: notes }
}
