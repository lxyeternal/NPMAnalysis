/** Hex To RGBA Converter
 * * Hex must be 9/7/5/4 characters long ( With '#' )
 *
 * @param hex  hexadecimal color
 * @param alpha(optional) opacity
 * @returns rgba string
 * @example
 * ('#ffffff') => rgb(255,255,255);
 * ('#000',0.1) => rgba(0,0,0,.1)
 * ('#000C') => rgba(0,0,0,0.8)
 */
export declare const hexToRgb: (hex: string, alpha?: number) => string;
/**
 * Convert RGBA value to hex(#RRGGBBAA/#RRGGBB)
 *
 * @param   {number}  red      0-255
 * @param   {number}  blue     0-255
 * @param   {number}  green    0-255
 * @param   {number} alpha     0-1 (default 1)
 * @return  {string}  hex
 * @example
 * (255,255,255,1) => #ffffff
 * (255,255,255,.8) => #ffffffcc
 */
export declare const rgbToHex: (red: number, green: number, blue: number, alpha?: number) => string;
/**
 *
 * @param rgba rgba/rgb string
 * @returns hex
 * @example
 * 'rgb(0,0,0)' => #000000
 * 'rgba(0,0,0,.8)' => #000000CC
 */
export declare const rgbStrToHex: (rgba: string) => string;
/**
 *  @description Converts RGBA/RGB to HSLA/HSL
 * @param red (0-255)
 * @param green (0-255)
 * @param blue (0-255)
 * @param alpha (0-1) [optional]
 * @returns hsl string
 * @example
 *  (33,33,33) => 'hsl(0,0%,13%)'
 *  (0,0,0,.5) =>'hsla(0,0%,0%,0.5)'
 */
export declare const rgbToHsl: (red: number, green: number, blue: number, alpha?: number | undefined) => string;
/**
 *
 * @param rgba rgb/rgba string
 * @returns hsl string
 * @example
 * rgb(33,33,33) => 'hsl(0,0%,13%)'
 * rgba(0,0,0,.5) =>'hsla(0,0%,0%,0.5)'
 */
export declare const rgbStrToHsl: (rgba: string) => string;
/**
 *
 * @param hue 0-infinity
 * @param saturation 0-1(number) OR 0%-100%(string)
 * @param lightness 0-1(number) OR 0%-100%(string)
 * @param alpha 0-1 [optional]
 * @returns RGB/RGBA String
 * @example
 * (500, 0.5, 0.5) => rgb(64,191,106);
 * (200,0.5, 0.5) => rgb(64,149,191);
 * (100, '50%', '50%',.5) => rgba(106,191,64,.5)
 */
export declare const hslToRgb: (hue: number, saturation: string | number, lightness: string | number, alpha?: number) => string;
/**
 *
 * @param hex hexdecimal string
 * @returns hsl string
 * @example
 * '#fff' => hsl(0,0%,100%)
 * '#fffc' => hsla(0,0%,100%,.8)
 */
export declare const hexToHsl: (hex: string) => string;
/**
 *
 * @param hue 0-infinity
 * @param saturation 0-1(number) OR 0%-100%(string)
 * @param lightness 0-1(number) OR 0%-100%(string)
 * @param alpha 0-1
 * @returns hex string
 * @example
 * (50,'50%','50%') => #bfaa40
 * (150,.5,.5) => #40bf80
 */
export declare const hslToHex: (hue: number, saturation: number | string, lightness: number | string, alpha?: number) => string;
/**
 *
 * @param hsl hsl/hsla string
 * @returns rgb/rgba  string
 * @example
 * 'hsl(100,.5,.5)' => rgb(106,191,64)
 * 'hsl(200,50%,50%,.7)' => rgba(64,149,191,.7)
 */
export declare const hslStrToRgb: (hsl: string) => string;
/**
 *
 * @param hsl hsl/hsla string
 * @returns hex string
 * @example
 * 'hsl(100,50%,50%)' => #6abf40
 * 'hsl(233,.6,.5)' => #5c6ad6
 *
 */
export declare const hslStrToHex: (hsl: string) => string;
