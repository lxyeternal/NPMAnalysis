import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInQuart: Mapper<number>;
