import { Mapper } from './types';
/**
 * Maps `x` ∈ [0, 1] logarithmically to [0, 1].
 *
 * @example
 * easeLog(0)(x) === x
 *
 * @param stiffness Greater values produce more bent curve.
 * @group Easing
 */
export declare function easeLog(stiffness?: number): Mapper<number>;
