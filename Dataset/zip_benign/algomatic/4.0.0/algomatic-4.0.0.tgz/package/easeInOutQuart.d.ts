import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInOutQuart: Mapper<number>;
