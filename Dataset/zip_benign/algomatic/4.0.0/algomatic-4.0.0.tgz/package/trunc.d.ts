import { Mapper } from './types';
/**
 * Returns the integer part of a number by removing any fractional digits.
 *
 * @group Algebra
 */
export declare const trunc: Mapper<number>;
