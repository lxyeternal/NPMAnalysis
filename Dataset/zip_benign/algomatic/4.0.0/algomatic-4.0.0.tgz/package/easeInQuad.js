'use strict';

/**
 * @group Easing
 */
const easeInQuad = x => x * x;

exports.easeInQuad = easeInQuad;
