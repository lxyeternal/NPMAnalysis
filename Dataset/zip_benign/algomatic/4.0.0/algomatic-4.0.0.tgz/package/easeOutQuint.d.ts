import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeOutQuint: Mapper<number>;
