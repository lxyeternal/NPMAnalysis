'use strict';

/**
 * Always returns {@link NaN}.
 *
 * @group Utils
 */
function nan() {
    return NaN;
}

exports.nan = nan;
