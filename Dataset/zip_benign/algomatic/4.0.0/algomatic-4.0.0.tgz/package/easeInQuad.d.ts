import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInQuad: Mapper<number>;
