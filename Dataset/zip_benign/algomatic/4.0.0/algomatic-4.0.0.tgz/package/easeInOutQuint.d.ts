import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInOutQuint: Mapper<number>;
