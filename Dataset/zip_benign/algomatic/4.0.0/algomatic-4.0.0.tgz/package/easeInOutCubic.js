'use strict';

/**
 * @group Easing
 */
const easeInOutCubic = x => (x < 0.5 ? 4 * x * x * x : (x - 1) * (2 * x - 2) * (2 * x - 2) + 1);

exports.easeInOutCubic = easeInOutCubic;
