import { Mapper } from './types';
/**
 * Inverse cumulative distribution function for Gaussian (normal) distribution.
 *
 * @see [Inverse distribution function (quantile function)](https://en.wikipedia.org/wiki/Cumulative_distribution_function#Inverse_distribution_function_(quantile_function))
 * @group Distributions
 */
export declare const cdfGaussInv: Mapper<number>;
