'use strict';

var utils = require('./utils.js');

/**
 * Bitwise OR operator ({@link a} ^ {@link b}) for large unsigned integers.
 *
 * @example
 * or(0x10_aa_bb_00_00_00_ff, 0x10_00_bb_cc_00_00_ff);
 * // ⮕ 0x10_aa_bb_cc_00_00_ff
 *
 * @param a The left integer.
 * @param b The right integer.
 * @group Bitwise Operations
 */
function or(a, b) {
    return ((a / utils.MASK_UPPER) | (b / utils.MASK_UPPER)) * utils.MASK_UPPER + ((a & utils.MASK_LOWER) | (b & utils.MASK_LOWER));
}

exports.or = or;
