'use strict';

/**
 * Composes mapper functions into a single function.
 *
 * @param fs The composed mapper functions.
 * @group Utils
 */
function compose(...fs) {
    return x => {
        for (const f of fs) {
            x = f(x);
        }
        return x;
    };
}

exports.compose = compose;
