import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeOutCubic: Mapper<number>;
