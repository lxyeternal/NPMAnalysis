'use strict';

/**
 * Semantic shortcut for `x` \*\* 2.
 *
 * @group Algebra
 */
const sq = x => x * x;

exports.sq = sq;
