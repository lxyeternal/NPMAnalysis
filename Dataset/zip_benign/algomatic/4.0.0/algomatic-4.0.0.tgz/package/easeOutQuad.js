'use strict';

/**
 * @group Easing
 */
const easeOutQuad = x => x * (2 - x);

exports.easeOutQuad = easeOutQuad;
