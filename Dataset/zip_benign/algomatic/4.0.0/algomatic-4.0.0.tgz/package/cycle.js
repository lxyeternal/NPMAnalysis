'use strict';

var utils = require('./utils.js');

/**
 * Brings value to the range [{@link a}, {@link b}] by adding or subtracting the range size |{@link a} - {@link b}|.
 *
 * @example
 * cycle(0, 10)(12);
 * // ⮕ 2
 *
 * cycle(100, 33)(-333);
 * // ⮕ 69
 *
 * @param a Minimum range value.
 * @param b Maximum range value.
 * @group Algebra
 */
function cycle(a = 0, b = 1) {
    const d = b - a;
    return x => (x > a ? x - utils.ceil((x - b) / d) * d : x + utils.ceil((a - x) / d) * d);
}

exports.cycle = cycle;
