'use strict';

var utils = require('./utils.js');

/**
 * Converts degrees to radians.
 *
 * @group Algebra
 */
const deg = x => (x / utils.PI) * 180;

exports.deg = deg;
