import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeOutQuad: Mapper<number>;
