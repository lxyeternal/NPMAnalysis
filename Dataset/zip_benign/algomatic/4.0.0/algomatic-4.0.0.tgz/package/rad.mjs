import { PI } from './utils.mjs';

/**
 * Converts radians to degrees.
 *
 * @group Algebra
 */
const rad = x => (x * PI) / 180;

export { rad };
