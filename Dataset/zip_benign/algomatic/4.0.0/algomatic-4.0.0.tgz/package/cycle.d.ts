import { Mapper } from './types';
/**
 * Brings value to the range [{@link a}, {@link b}] by adding or subtracting the range size |{@link a} - {@link b}|.
 *
 * @example
 * cycle(0, 10)(12);
 * // ⮕ 2
 *
 * cycle(100, 33)(-333);
 * // ⮕ 69
 *
 * @param a Minimum range value.
 * @param b Maximum range value.
 * @group Algebra
 */
export declare function cycle(a?: number, b?: number): Mapper<number>;
