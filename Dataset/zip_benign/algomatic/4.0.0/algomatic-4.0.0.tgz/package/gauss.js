'use strict';

var utils = require('./utils.js');

/**
 * Gaussian (normal) distribution.
 *
 * @example
 * seq(3).map(gauss(0.5, 0.3));
 * // ⮕ [0.33, 1.32, 0.33]
 *
 * @param mean The mean value.
 * @param deviation Standard deviation.
 * @see [Normal distribution](https://en.wikipedia.org/wiki/Normal_distribution)
 * @group Distributions
 */
function gauss(mean = 0, deviation = 1) {
    const q = deviation * utils.sqrt(2 * utils.PI);
    return x => {
        x = (x - mean) / deviation;
        return utils.exp(-0.5 * x * x) / q;
    };
}

exports.gauss = gauss;
