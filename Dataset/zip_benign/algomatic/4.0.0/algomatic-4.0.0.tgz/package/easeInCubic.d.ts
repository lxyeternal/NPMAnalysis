import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInCubic: Mapper<number>;
