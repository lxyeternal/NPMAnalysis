'use strict';

var utils = require('./utils.js');

/**
 * Returns the logarithm of {@link x} with base {@link base}.
 *
 * @example
 * logx(64, 2);
 * // ⮕ 6
 *
 * logx(1000, 10);
 * // ⮕ 3
 *
 * logx(99, 10);
 * // ⮕ 1.99563519459755
 *
 * logx(0.01, 10);
 * // ⮕ -2
 *
 * @param x The number.
 * @param base The base.
 * @group Algebra
 */
function logx(x, base) {
    return utils.log10(x) / utils.log10(base);
}

exports.logx = logx;
