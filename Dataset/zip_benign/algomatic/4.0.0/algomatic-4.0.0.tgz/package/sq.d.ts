import { Mapper } from './types';
/**
 * Semantic shortcut for `x` \*\* 2.
 *
 * @group Algebra
 */
export declare const sq: Mapper<number>;
