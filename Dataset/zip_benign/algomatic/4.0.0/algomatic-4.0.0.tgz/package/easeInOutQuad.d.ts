import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInOutQuad: Mapper<number>;
