/**
 * @group Easing
 */
const easeOutQuad = x => x * (2 - x);

export { easeOutQuad };
