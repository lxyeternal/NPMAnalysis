'use strict';

/**
 * @group Easing
 */
const easeOutQuart = x => 1 - --x * x * x * x;

exports.easeOutQuart = easeOutQuart;
