import { ArrayLike, ArrayValue, Comparator } from './types';
/**
 * Sorts the array in-place using an optional comparator and invokes a callback after a pair of elements was swapped.
 *
 * {@link swap} or {@link comparator} callbacks are guaranteed to be called after the elements of {@link arr} are
 * swapped.
 *
 * @param arr The mutable array-like data structure that is sorted in-place.
 * @param swap The callback that is invoked with indices that were swapped.
 * @param comparator The callback that defines the sort order. If omitted, the array elements are compared using
 * comparison operators.
 * @returns The input array.
 * @template T The input array.
 * @group Sort
 */
export declare function qsort<T extends ArrayLike<any>>(arr: T, swap?: (i: number, j: number) => void, comparator?: Comparator<ArrayValue<T>>): T;
