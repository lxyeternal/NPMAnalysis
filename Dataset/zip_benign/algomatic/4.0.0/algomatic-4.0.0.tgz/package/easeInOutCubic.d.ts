import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInOutCubic: Mapper<number>;
