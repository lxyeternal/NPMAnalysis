/**
 * @group Easing
 */
const easeInQuint = x => x * x * x * x * x;

export { easeInQuint };
