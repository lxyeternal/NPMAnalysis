'use strict';

/**
 * @group Easing
 */
const easeInQuart = x => x * x * x * x;

exports.easeInQuart = easeInQuart;
