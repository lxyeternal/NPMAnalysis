'use strict';

/**
 * @group Easing
 */
const easeInOutQuad = x => (x < 0.5 ? 2 * x * x : -1 + (4 - 2 * x) * x);

exports.easeInOutQuad = easeInOutQuad;
