'use strict';

var utils = require('./utils.js');

/**
 * Maps `x` ∈ [0, 1] exponentially to [0, 1].
 *
 * @example
 * easeExp(0)(x) === x;
 *
 * @param stiffness Greater values produce more bent curve.
 * @group Easing
 */
function easeExp(stiffness = 1) {
    return x => (stiffness === 0 ? x : (utils.exp(stiffness * x) - 1) / (utils.exp(stiffness) - 1));
}

exports.easeExp = easeExp;
