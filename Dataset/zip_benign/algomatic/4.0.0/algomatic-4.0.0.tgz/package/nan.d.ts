/**
 * Always returns {@link NaN}.
 *
 * @group Utils
 */
export declare function nan(): number;
