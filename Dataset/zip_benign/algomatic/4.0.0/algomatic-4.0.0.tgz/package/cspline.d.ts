import { ArrayLike, Mapper } from './types';
/**
 * Returns a natural cubic spline interpolation function for given pivot points.
 *
 * **Notes:** Don't mutate {@link xs} and {@link ys} arrays after creating this function since data from these arrays
 * is read during interpolation.
 *
 * @example
 * const f = cspline(xs, ys);
 * const y = f(x);
 *
 * @param xs The array of X coordinates of pivot points in ascending order.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @returns The function that takes X coordinate and returns an interpolated Y coordinate.
 * @group Interpolation
 */
export declare function cspline(xs: ArrayLike<number>, ys: ArrayLike<number>): Mapper<number>;
/**
 * Interpolates {@link y} at {@link x} using a natural cubic spline algorithm for a set of pivot points.
 *
 * @example
 * const splines = new Float32Array(xs.length * 3);
 * populateCSplines(xs, ys, xs.length, splines);
 *
 * const y = interpolateCSpline(xs, ys, x, xs.length, splines);
 *
 * @param xs The array of X coordinates of pivot points in ascending order, length must be at least 2.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @param x The X coordinate of interpolated point.
 * @param n The number of pivot points, usually equals `xs.length`.
 * @param splines The array of spline components, length must be {@link n} * 3.
 * @returns Interpolated Y coordinate.
 *
 * @see {@link populateCSplines}
 * @see [Algorithm for computing natural cubic splines](https://en.wikipedia.org/wiki/Spline_(mathematics)#Algorithm_for_computing_natural_cubic_splines)
 * @group Interpolation
 * @internal
 */
export declare function interpolateCSpline(xs: ArrayLike<number>, ys: ArrayLike<number>, x: number, n: number, splines: ArrayLike<number>): number;
/**
 * Computes cubic splines for given pivot points.
 *
 * @example
 * const splines = new Float32Array(xs.length * 3);
 * populateCSplines(xs, ys, xs.length, splines);
 *
 * @param xs The array of X coordinates of pivot points in ascending order, length must be at least 2.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @param n The number of pivot points, usually equals `xs.length`.
 * @param splines Mutable array that would be populated with spline components, length must be at least {@link n} * 3.
 * @group Interpolation
 * @internal
 */
export declare function populateCSplines(xs: ArrayLike<number>, ys: ArrayLike<number>, n: number, splines: ArrayLike<number>): void;
