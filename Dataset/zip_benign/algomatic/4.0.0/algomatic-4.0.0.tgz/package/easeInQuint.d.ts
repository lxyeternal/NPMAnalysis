import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeInQuint: Mapper<number>;
