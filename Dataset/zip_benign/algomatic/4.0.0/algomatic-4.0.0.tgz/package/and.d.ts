/**
 * Bitwise AND operator ({@link a} & {@link b}) for large unsigned integers.
 *
 * @example
 * and(0x10_aa_bb_00_00_00_ff, 0x10_00_bb_cc_00_00_ff);
 * // ⮕ 0x10_00_bb_00_00_00_ff
 *
 * @param a The left integer.
 * @param b The right integer.
 * @group Bitwise Operations
 */
export declare function and(a: number, b: number): number;
