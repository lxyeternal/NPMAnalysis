/**
 * @group Easing
 */
const easeInQuad = x => x * x;

export { easeInQuad };
