import { Mapper } from './types';
/**
 * Gaussian (normal) distribution.
 *
 * @example
 * seq(3).map(gauss(0.5, 0.3));
 * // ⮕ [0.33, 1.32, 0.33]
 *
 * @param mean The mean value.
 * @param deviation Standard deviation.
 * @see [Normal distribution](https://en.wikipedia.org/wiki/Normal_distribution)
 * @group Distributions
 */
export declare function gauss(mean?: number, deviation?: number): Mapper<number>;
