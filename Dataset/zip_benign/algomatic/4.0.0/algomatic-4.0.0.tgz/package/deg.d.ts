import { Mapper } from './types';
/**
 * Converts degrees to radians.
 *
 * @group Algebra
 */
export declare const deg: Mapper<number>;
