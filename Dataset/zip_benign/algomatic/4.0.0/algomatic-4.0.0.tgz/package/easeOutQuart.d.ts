import { Mapper } from './types';
/**
 * @group Easing
 */
export declare const easeOutQuart: Mapper<number>;
