import { Mapper } from './types';
/**
 * Rounds `x` to the closest value that is divided by {@link divisor} without any remainder.
 *
 * @example
 * snap(10)(17);
 * // ⮕ 20
 *
 * snap(3)(-10);
 * // ⮕ -9
 *
 * @param divisor The divisor.
 * @group Algebra
 */
export declare function snap(divisor: number): Mapper<number>;
