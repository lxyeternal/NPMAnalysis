'use strict';

/**
 * @group Easing
 */
const easeOutCubic = x => --x * x * x + 1;

exports.easeOutCubic = easeOutCubic;
