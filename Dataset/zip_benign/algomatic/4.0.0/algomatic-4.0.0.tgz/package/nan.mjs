/**
 * Always returns {@link NaN}.
 *
 * @group Utils
 */
function nan() {
    return NaN;
}

export { nan };
