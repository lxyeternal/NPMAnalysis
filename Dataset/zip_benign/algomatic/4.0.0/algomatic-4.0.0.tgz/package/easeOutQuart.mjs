/**
 * @group Easing
 */
const easeOutQuart = x => 1 - --x * x * x * x;

export { easeOutQuart };
