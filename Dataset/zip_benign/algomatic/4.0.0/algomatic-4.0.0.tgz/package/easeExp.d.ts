import { Mapper } from './types';
/**
 * Maps `x` ∈ [0, 1] exponentially to [0, 1].
 *
 * @example
 * easeExp(0)(x) === x;
 *
 * @param stiffness Greater values produce more bent curve.
 * @group Easing
 */
export declare function easeExp(stiffness?: number): Mapper<number>;
