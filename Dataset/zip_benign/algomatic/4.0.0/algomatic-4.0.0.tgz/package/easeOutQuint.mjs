/**
 * @group Easing
 */
const easeOutQuint = x => 1 + --x * x * x * x * x;

export { easeOutQuint };
