import { ArrayLike, Mapper } from './types';
/**
 * Returns a monotonous cubic spline interpolation function for given pivot points, that prevent overshoot of
 * interpolated values.
 *
 * **Notes:** Don't mutate {@link xs} and {@link ys} arrays after creating this function since data from these arrays
 * is read during interpolation.
 *
 * @example
 * const f = csplineMonot(xs, ys);
 * const y = f(x);
 *
 * @param xs The array of X coordinates of pivot points in ascending order.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @returns The function that takes X coordinate and returns an interpolated Y coordinate.
 *
 * @see [Monotone cubic interpolation](https://en.wikipedia.org/wiki/Monotone_cubic_interpolation)
 * @group Interpolation
 */
export declare function csplineMonot(xs: ArrayLike<number>, ys: ArrayLike<number>): Mapper<number>;
/**
 * Computes {@link y} at {@link x} for a set of pivot points ({@link xs} and {@link ys}) using monotonous cubic spline
 * interpolation that prevents overshoot of interpolated values.
 *
 * @example
 * const splines = new Float32Array(xs.length * 3 - 2);
 * populateCSplinesMonot(xs, ys, xs.length, splines);
 *
 * const y = interpolateCSplineMonot(xs, ys, x, xs.length, splines);
 *
 * @param xs The array of X coordinates of pivot points in ascending order, length must be al least 2.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @param x The X coordinate of interpolated point.
 * @param n The number of pivot points, usually equals `xs.length`.
 * @param splines The array of spline components, length must be {@link n} * 3 - 2.
 * @returns Interpolated Y coordinate.
 *
 * @see [Monotone cubic interpolation](https://en.wikipedia.org/wiki/Monotone_cubic_interpolation)
 * @group Interpolation
 * @internal
 */
export declare function interpolateCSplineMonot(xs: ArrayLike<number>, ys: ArrayLike<number>, x: number, n: number, splines: ArrayLike<number>): number;
/**
 * Computes monotonous splines for {@link xs} and {@link ys} that prevents overshoot of interpolated values.
 *
 * @example
 * const splines = new Float32Array(xs.length * 3 - 2);
 * populateCSplinesMonot(xs, ys, xs.length, splines);
 *
 * @param xs The array of X coordinates of pivot points in ascending order, length must be at least 2.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @param n The number of pivot points, usually equals `xs.length`.
 * @param splines Mutable array that would be populated with spline components, length must be at least
 * {@link n} * 3 - 2.
 * @returns The {@link splines} array.
 *
 * @see [Monotone cubic interpolation](https://en.wikipedia.org/wiki/Monotone_cubic_interpolation)
 * @group Interpolation
 * @internal
 */
export declare function populateCSplinesMonot(xs: ArrayLike<number>, ys: ArrayLike<number>, n: number, splines: ArrayLike<number>): void;
