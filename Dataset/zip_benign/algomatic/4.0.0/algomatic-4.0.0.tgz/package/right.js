'use strict';

var utils = require('./utils.js');
var trunc = require('./trunc.js');

/**
 * Bitwise right shift operator ({@link x} >> {@link n}) for large unsigned integers.
 *
 * @example
 * right(0x11_22_22_44_55_66_77, 24);
 * // ⮕ 0x11_22_22_44
 *
 * @param x The integer.
 * @param n The number of bytes to shift to the right.
 * @group Bitwise Operations
 */
function right(x, n) {
    return trunc.trunc(x / utils.pow(2, n | 0)) || 0;
}

exports.right = right;
