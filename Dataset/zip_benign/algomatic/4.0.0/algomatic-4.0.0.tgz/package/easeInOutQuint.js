'use strict';

/**
 * @group Easing
 */
const easeInOutQuint = x => (x < 0.5 ? 16 * x * x * x * x * x : 1 + 16 * --x * x * x * x * x);

exports.easeInOutQuint = easeInOutQuint;
