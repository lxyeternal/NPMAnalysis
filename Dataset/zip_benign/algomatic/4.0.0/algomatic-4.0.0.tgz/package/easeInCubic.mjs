/**
 * @group Easing
 */
const easeInCubic = x => x * x * x;

export { easeInCubic };
