'use strict';

const { ceil, floor, abs, sqrt, log10, PI, exp, log, min, pow } = Math;
const MASK_UPPER = 2147483648;
const MASK_LOWER = 2147483647;

exports.MASK_LOWER = MASK_LOWER;
exports.MASK_UPPER = MASK_UPPER;
exports.PI = PI;
exports.abs = abs;
exports.ceil = ceil;
exports.exp = exp;
exports.floor = floor;
exports.log = log;
exports.log10 = log10;
exports.min = min;
exports.pow = pow;
exports.sqrt = sqrt;
