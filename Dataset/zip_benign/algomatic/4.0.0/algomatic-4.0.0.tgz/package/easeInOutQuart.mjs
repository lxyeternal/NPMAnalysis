/**
 * @group Easing
 */
const easeInOutQuart = x => (x < 0.5 ? 8 * x * x * x * x : 1 - 8 * --x * x * x * x);

export { easeInOutQuart };
