/**
 * @group Easing
 */
const easeOutCubic = x => --x * x * x + 1;

export { easeOutCubic };
