'use strict';

/**
 * @group Easing
 */
const easeInQuint = x => x * x * x * x * x;

exports.easeInQuint = easeInQuint;
