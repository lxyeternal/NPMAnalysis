import { ArrayLike, Mapper } from './types';
/**
 * Returns a linear interpolation function for given pivot points.
 *
 * **Notes:** Don't mutate {@link xs} and {@link ys} arrays after creating this function since data from these arrays
 * is read during interpolation.
 *
 * @example
 * const f = lerp(xs, ys);
 * const y = f(x);
 *
 * @param xs The array of X coordinates of pivot points in ascending order.
 * @param ys The array of corresponding Y coordinates of pivot points.
 * @returns The function that takes X coordinate and returns an interpolated Y coordinate.
 * @group Interpolation
 */
export declare function lerp(xs: ArrayLike<number>, ys: ArrayLike<number>): Mapper<number>;
