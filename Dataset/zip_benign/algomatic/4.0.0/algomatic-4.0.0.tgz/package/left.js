'use strict';

var utils = require('./utils.js');

/**
 * Bitwise left shift operator ({@link x} << {@link n}) for large unsigned integers.
 *
 * @example
 * left(0x11_22_33_44, 24)
 * // ⮕ 0x11_22_33_44_00_00_00
 *
 * @param x The integer.
 * @param n The number of bytes to shift to the left.
 * @group Bitwise Operations
 */
function left(x, n) {
    return x * utils.pow(2, n | 0) || 0;
}

exports.left = left;
