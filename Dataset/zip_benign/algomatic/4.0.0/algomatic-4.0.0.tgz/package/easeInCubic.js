'use strict';

/**
 * @group Easing
 */
const easeInCubic = x => x * x * x;

exports.easeInCubic = easeInCubic;
