import { ceil, floor } from './utils.mjs';

/**
 * Returns the integer part of a number by removing any fractional digits.
 *
 * @group Algebra
 */
const trunc = Math.trunc || (x => (x < 0 ? ceil(x) : floor(x)));

export { trunc };
