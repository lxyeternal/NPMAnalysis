/**
 * @group Easing
 */
const easeInQuart = x => x * x * x * x;

export { easeInQuart };
