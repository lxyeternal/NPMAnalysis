export declare const ceil: (x: number) => number, floor: (x: number) => number, abs: (x: number) => number, sqrt: (x: number) => number, log10: (x: number) => number, PI: number, exp: (x: number) => number, log: (x: number) => number, min: (...values: number[]) => number, pow: (x: number, y: number) => number;
export declare const MASK_UPPER = 2147483648;
export declare const MASK_LOWER = 2147483647;
