'use strict';

var utils = require('./utils.js');

/**
 * Converts radians to degrees.
 *
 * @group Algebra
 */
const rad = x => (x * utils.PI) / 180;

exports.rad = rad;
