import { Mapper } from './types';
/**
 * Cumulative distribution function for Gaussian (normal) distribution.
 *
 * @example
 * seq(3).map(cdfGauss(0.5, 0.3));
 * // ⮕ [ 0.04, 0.5, 0.95 ]
 *
 * @param mean Mean of the input value.
 * @param deviation The standard deviation of the input value.
 * @see [Cumulative distribution function](https://en.wikipedia.org/wiki/Cumulative_distribution_function)
 * @group Distributions
 */
export declare function cdfGauss(mean?: number, deviation?: number): Mapper<number>;
