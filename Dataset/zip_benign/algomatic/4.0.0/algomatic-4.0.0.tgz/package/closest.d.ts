import { ArrayLike, Mapper } from './types';
/**
 * Returns the closest value to `x` from {@link xs}.
 *
 * If {@link xs} is empty then `x` is returned as is.
 *
 * @example
 * closest([0, 3, 6])(1.8);
 * // ⮕ 3
 *
 * @group Algebra
 */
export declare function closest(xs: ArrayLike<number>): Mapper<number>;
