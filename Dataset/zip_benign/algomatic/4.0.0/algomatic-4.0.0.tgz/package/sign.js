'use strict';

var utils = require('./utils.js');

/**
 * Returns a +/- 1, indicating the sign of a number passed into the argument.
 *
 * If the number  passed into {@link sign} is 0, it will return a +/- 0. Note that if the number is positive,
 * an explicit (+) will not be returned.
 *
 * @group Algebra
 */
const sign = Math.sign || (x => utils.abs(x) / x);

exports.sign = sign;
