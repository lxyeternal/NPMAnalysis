import { Mapper } from './types';
/**
 * Composes mapper functions into a single function.
 *
 * @param fs The composed mapper functions.
 * @group Utils
 */
export declare function compose<T>(...fs: Mapper<T>[]): Mapper<T>;
