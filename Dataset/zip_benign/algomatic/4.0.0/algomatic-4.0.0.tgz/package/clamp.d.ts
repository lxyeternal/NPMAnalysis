import { Mapper } from './types';
/**
 * Clamps `x` to range [{@link a}, {@link b}].
 *
 * @example
 * clamp()(0.2);
 * // ⮕ 0.2
 *
 * clamp()(-2);
 * // ⮕ 0.5
 *
 * clamp(5, 10)(33);
 * // ⮕ 10
 *
 * @param a Minimum range value.
 * @param b Maximum range value.
 * @group Algebra
 */
export declare function clamp(a?: number, b?: number): Mapper<number>;
