import { PI } from './utils.mjs';

/**
 * Converts degrees to radians.
 *
 * @group Algebra
 */
const deg = x => (x / PI) * 180;

export { deg };
