'use strict';

var utils = require('./utils.js');

/**
 * Returns the integer part of a number by removing any fractional digits.
 *
 * @group Algebra
 */
const trunc = Math.trunc || (x => (x < 0 ? utils.ceil(x) : utils.floor(x)));

exports.trunc = trunc;
