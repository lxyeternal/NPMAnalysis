import { Mapper } from './types';
/**
 * Converts radians to degrees.
 *
 * @group Algebra
 */
export declare const rad: Mapper<number>;
