var ExtractTextPlugin = require("extract-text-webpack-plugin")
const VueLoaderPlugin = require('vue-loader/lib/plugin')

module.exports = {
    module: {
        rules: [
            {
                test: /\.(scss|sass|css)$/i,
                loader: ExtractTextPlugin.extract({
                  use: ['css-loader', 'sass-loader'],
                  fallback: 'vue-style-loader'
                })
            },
            {
                test: /\.js/,
                loader: 'babel-loader',
                exclude: /node_modules/,
            },
            {
                test: /\.vue$/,
                loader: 'vue-loader',
                options: {
                  extractCSS: true
                }
            },
        ],
    },

    context: __dirname,

    resolve: {
        extensions: ['.js', '.vue'],
    },

    plugins: [
      new ExtractTextPlugin('beta.css'),
      new VueLoaderPlugin()
    ]
};
