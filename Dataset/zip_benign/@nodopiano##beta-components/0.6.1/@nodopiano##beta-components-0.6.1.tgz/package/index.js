var board = new DrawingBoard.Board('board', {
	controls: [
		'Color',
		{ Size: {
			type: 'dropdown',
			min: 6
		} },
		'DrawingMode',
		{'Navigation': {
			back: false,
			forward: false,
			reset: true
		}}
    ],
    controlsPosition: 'top center',
    droppable: true,
	size: 1,
	webStorage: 'session',
	enlargeYourContainer: true
});

function refresh() {
    location.reload();
}

function sendPicture() {
	console.log(board.getImg());
	board.downloadImg();
}