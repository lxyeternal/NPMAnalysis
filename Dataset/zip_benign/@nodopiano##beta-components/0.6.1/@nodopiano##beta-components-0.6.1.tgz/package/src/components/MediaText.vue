<template>
  <div
    :id="$calcId(item)"
    :class="`block-${item.acf_fc_layout}__wrapper`"
    :style="`background-color:${item.bkgcolor}`"
  >
    <div :class="mediaTextClass">
      <div
        :class="`block-${item.acf_fc_layout}__text`"
        v-html="item.text"
      />
      <div :class="`block-${item.acf_fc_layout}__media`">
        <img
          v-if="item.media && item.media.sizes && item.media.url"
          :src="item.media.url"
          :srcset="`${item.media.sizes['medium_large']} 600w, ${item.media.sizes['large']} 900w`"
          :alt="item.media.alt"
          sizes="50vw" >
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  },

  computed: {
    mediaTextClass() {
      return `block-${
          this.item.acf_fc_layout
        } block__inner b-${this.index} ${
          this.item.text_on_right ? 'block-' + this.item.acf_fc_layout + '--text-right' : ''
        } ${
          this.item.grid_half ? 'block-' + this.item.acf_fc_layout + '--grid-half' : ''
        }`
    }
  }
}
</script>

<style lang="scss">
$text-padding: 2rem;

.block-media_text {
  align-items: center;
  display: grid;
  grid-template-areas: 'media' 'text';
  margin: 0 auto;
  max-width: 75rem;
  padding: 4rem 1rem;
  width: 100%;

  @media screen and (min-width: 600px) {
    grid-template-areas: 'text text media';
    grid-template-columns: 33% 33% auto;

    &.block-media_text--grid-half {
      grid-template-areas: 'text media';
      grid-template-columns: 50% 50%;
    }
  }

  &__text {
    grid-area: text;
    text-align: center;
    padding-top: $text-padding;

    @media screen and (min-width: 600px) {
      padding-top: 0;
      padding-right: $text-padding;
      text-align: initial;
    }

    ul {
      margin-left: 1.25rem;
      text-align: left;
    }

    & > * {
      padding: 1rem 0;
    }
  }

  &__media {
    align-items: center;
    display: flex;
    grid-area: media;
    justify-content: center;

    & img {
      height: auto;
      width: 100%;
    }
  }

  &--text-right {
    & .block-media_text__text {
      @media screen and (min-width: 600px) {
        padding-left: $text-padding;
        padding-right: 0;
      }
    }

    @media screen and (min-width: 600px) {
      grid-template-areas: 'media text text';

      &.block-media_text--grid-half {
        grid-template-areas: 'media text';
      }
    }

  }
}
</style>
