<template>
  <div
    :id="$calcId(item)"
    :class="`block-${item.acf_fc_layout} block__inner b-${index}`"
    :style="`background-color: ${item.cta_bkgcolor}`"
  >
    <div :class="`block-${item.acf_fc_layout}__wrapper`">
      <div :class="`block-${item.acf_fc_layout}__content`">
        <h2 :class="`block-${item.acf_fc_layout}__title`">
          {{ item.cta_title }}
        </h2>
        <h4 :class="`block-${item.acf_fc_layout}__subtitle`">
          {{ item.cta_subtitle }}
        </h4>
        <div
          :class="`block-${item.acf_fc_layout}__txt`"
          v-html="item.cta_txt"
        />
        <a
          v-if="!item.cta_modal"
          :href="item.cta_btnlink"
          class="button"
          target="_blank"
        >
          {{ item.cta_btnlabel }}
        </a>
        <button
          v-if="item.cta_modal"
          class="button"
          @click="showModal"
        >
          {{ item.cta_btnlabel }}
        </button>
      </div>
    </div>
    <modal
      :scrollable="true"
      class="contact"
      name="contact"
      width="90%"
      height="auto"
    >
      <h4
        class="contact__title"
        v-text="item.cta_modal_title"
      />
      <catcher class="contact__form"/>
    </modal>
  </div>
</template>

<script>
import catcher from './Catcher.vue'

export default {
  components: {
    catcher
  },

  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  },

  methods: {
    showModal() {
      this.$modal.show('contact')
    },
    hideModal() {
      this.$modal.hide('contact')
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';
.block-call_to_action {
  &__wrapper {
    @include pill-row();
    align-content: center;
    margin: 0 auto;
    padding: 2rem 1rem;
    width: 100%;

    @media screen and (min-width: 900px) {
      padding: 4rem 2rem;
    }

    @media screen and (min-width: 1200px) {
      padding: 4rem 1rem;
    }
  }

  &__content {
    text-align: center;
    width: 100%;
  }

  &__title {
    color: var(--primary_normal-darker);
    margin: 1rem 0;
  }

  &__subtitle {
    color: var(--primary_dark);
  }

  &__txt {
    padding: 1rem;
  }

  .contact {
    &__title {
      color: var(--primary_dark);
      font-weight: 500;
      padding: 0 0 1rem;
      text-align: center;
      width: 100%;
    }
  }
}
</style>
