<template>
  <div
    :id="$calcId(item)"
    :class="`block-${item.acf_fc_layout} block__inner b-${index}`"
    :style="`background-color:${item.testo_bkgcolor}`"
  >
    <div
      v-if="item.testo_two_col"
      :class="`block-${item.acf_fc_layout}__wrapper`">
      <h2 v-if="item.testo_title" :class="`block-${item.acf_fc_layout}__title`">
        {{ item.testo_title }}
      </h2>
      <h4 v-if="item.testo_subtitle" :class="`block-${item.acf_fc_layout}__subtitle`">
        {{ item.testo_subtitle }}
      </h4>
      <div :class="`block-${item.acf_fc_layout}__col-sx block-${item.acf_fc_layout}__col`">
        <div
          :class="`block-${item.acf_fc_layout}__txt`"
          v-html="item.testo_txt"
        />
      </div>
      <div :class="`block-${item.acf_fc_layout}__col-dx block-${item.acf_fc_layout}__col`">
        <div
          :class="`block-${item.acf_fc_layout}__txt`"
          v-html="item.testo_txt_dx"
        />
      </div>
    </div>
    <div
      v-else
      :class="`block-${item.acf_fc_layout}__wrapper`"
    >
      <div :class="`block-${item.acf_fc_layout}__content`">
        <h2  v-if="item.testo_title" :class="`block-${item.acf_fc_layout}__title`">
          {{ item.testo_title }}
        </h2>
        <h4 v-if="item.test_subtitle" :class="`block-${item.acf_fc_layout}__subtitle`">
          {{ item.testo_subtitle }}
        </h4>
        <div
          :class="`block-${item.acf_fc_layout}__txt`"
          v-html="item.testo_txt"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';
.block-testo {
  &__wrapper {
    @include pill-row();
    align-content: center;
    padding: 2rem 1rem;
    width: 100%;

    @media screen and (min-width: 900px) {
      padding: 4rem 2rem;
    }

    @media screen and (min-width: 1200px) {
      padding: 4rem 1rem;
    }
  }

  &__content {
    width: 100%;
  }

  &__col {
    padding: 0;
    width: 100%;

    @media screen and (min-width: 900px) {
      @include pill-column(6, 0, block);
      padding: 0 1rem;
    }
  }

  &__col-sx {
    @media screen and (min-width: 900px) {
      padding: 0 1rem 0 0;
    }
  }

  &__col-dx {
    @media screen and (min-width: 900px) {
      padding: 0 0 0 1rem;
    }
  }

  &__title {
    color: var(--primary_normal-darker);
    margin: 1rem 0;
    text-align: center;
    width: 100%;
  }

  &__subtitle {
    color: var(--primary_dark);
    text-align: center;
    width: 100%;
  }

  &__txt {
    padding: 1rem 0;
    & p > img {
      width: 100%;
      object-fit: cover;
    }
  }
}
</style>
