<template>
  <div :style="bgColor">
    <h2 :class="`block-${item.acf_fc_layout}__title`">
      {{ item.slideshow_title }}
    </h2>
    <div :class="`block-${item.acf_fc_layout}__txt`" >
      <div
        class="block-slideshow__txt__inner"
        v-html="item.slideshow_txt"
      />
    </div>
    <div class="single-img">
      <img
        v-if="item.slideshow_slides.length == 1"
        :src="item.slideshow_slides[0].slide.url"
        :srcset="`${item.slideshow_slides[0].slide.sizes['medium_large']} 600w,
                  ${item.slideshow_slides[0].slide.sizes['large']} 900w,
                  ${item.slideshow_slides[0].slide.sizes['large']} 1200w`"
        :alt="item.slideshow_slides[0].slide.alt"
        :height="item.slideshow_slides[0].slide.height"
        class="single-img__img"
        sizes="50vw"
      >
    </div>
    <client-only
      v-if="item.slideshow_slides.length > 1"
    >
      <div
        :id="$calcId(item)"
        :class="`block-${item.acf_fc_layout} block__inner b-${index}`"
      >
        <div v-swiper:mySwiper="swiperOption">
          <div
            :class="`block-${item.acf_fc_layout}__slides`"
            class="swiper-wrapper"
          >
            <div
              v-for="(slide, index) in item.slideshow_slides"
              :key="index"
              :class="`block-${item.acf_fc_layout}__slide`"
              class="swiper-slide"
            >
              <img
                :src="slide.slide.url"
                :srcset="`${slide.slide.sizes['medium']} 300w,
                          ${slide.slide.sizes['medium_large']} 600w,
                          ${slide.slide.sizes['large']} 900w,
                          ${slide.slide.sizes['large']} 1200w`"
                :width="slide.slide.width"
                :height="slide.slide.height"
                :alt="slide.slide.alt"
                class="swiper-lazy"
                sizes="50vw"
              >
            </div>
          </div>
          <div
            slot="button-prev"
            class="swiper-button-prev"
          />
          <div
            slot="button-next"
            class="swiper-button-next"
          />
          <div class="swiper-pagination swiper-pagination-bullets"/>
        </div>
      </div>
    </client-only>
  </div>
</template>

<script>
export default {
  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  },

  data() {
    return {
      swiperOption: {
        themeColor: '#FF0000',
        lazy: true,
        autoplay: 4000,
        autoplayDisableOnInteraction: false,
        pagination: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        paginationClickable: true,
        slidesPerView: 'auto',
        spaceBetween: 64,
        loop: true,
        centeredSlides: true,
        breakpoints: {
          // when window width is <= 600px
          600: {
            slidesPerView: 1,
            spaceBetween: 0
          },
          // when window width is <= 900px
          900: {
            slidesPerView: 'auto',
            spaceBetween: 12
          },
          // when window width is <= 1200px
          1200: {
            spaceBetween: 25
          }
        }
      }
    }
  },
  computed: {
    bgColor() {
      return this.item.bg_color
        ? `background-color: ${this.item.bg_color}`
        : false
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';
.block-slideshow {
  &__title {
    color: var(--primary_normal-darker);
    padding: 1rem 0;
    text-align: center;
    width: 100%;
  }
  &__txt {
    display: flex;
    justify-content: center;
    width: 100%;

    &__inner {
      max-width: 1024px;
      padding: 0.5rem;

      @media screen and (min-width: 900px) {
        padding: 0;
      }
    }
  }
}

.swiper-container {
  padding: 2rem 0;
}

.swiper-slide {
  width: 50vw;

  img {
    height: auto;
    min-width: 100%;
    width: 100%;
  }
}

.swiper-button-prev {
  background-image: none;
  left: 1rem;

  &:before {
    content: '\f104';
  }
}

.swiper-button-next {
  background-image: none;
  right: 1rem;

  &:before {
    content: '\f105';
  }
}

div[class^='swiper-button'] {
  &:before {
    color: primary(--primary_dark);
    display: block;
    font-family: 'FontAwesome', sans-serif;
    font-size: 2rem;
    left: 50%;
    position: absolute;
    top: 50%;
    transform: translate(-50%, -50%);
    z-index: 3;
  }
}

.swiper-pagination-bullet-active {
  background-color: var(--primary_normal);
}

.single-img {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;

  &__img {
    width: 100%;
    height: auto;
    object-fit: cover;
    max-width: 1024px;
    padding: 0.5rem;
    margin: 0;

    @media screen and (min-width: 900px) {
      padding: 1.5rem;
    }
  }
}
</style>
