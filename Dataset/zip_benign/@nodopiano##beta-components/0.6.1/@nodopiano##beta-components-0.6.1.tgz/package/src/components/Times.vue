<template>
  <div
    :id="$calcId(item)"
    :style="bgColor"
    class="block-times"
  >
    <h3 :class="`block-times__title`">
      {{ item.title }}
    </h3>
    <div
      v-for="(interval, index) in item.periods"
      :key="index"
      class="block-times__periods"
    >
      <div class="block-times__periods__interval">
          <span class="block-times__periods__interval__interval">
            {{ interval.interval }}:
          </span>
          <i class="far fa-clock" /> {{ interval.morning }}
          <span
            v-if="interval.afternoon"
            class="block-times__periods__interval__afternoon"
          >
            <i class="far fa-clock" /> {{ interval.afternoon }}
          </span>
        </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  },

  computed: {
    bgColor() {
      return this.item.bg_color
        ? `background-color: ${this.item.bg_color}`
        : false
    }
  }
}
</script>

<style lang="scss">
.far {
  padding: 0 0.25rem 0 0.5rem;

  @media screen and (min-width: 600px) {
    padding: .5rem .25rem .5rem .75rem;
  }
}

.block-times {
  &__title {
    color: var(--primary_normal-darker);
    padding: 1rem 0;
    text-align: center;
    width: 100%;
  }

  &__periods {
    padding: 0 0 0.5rem;

    &__interval {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-flow: row wrap;
      width: 100%;

      &__interval {
        text-align: center;
        width: 100%;

        @media screen and (min-width: 600px) {
          width: auto;
        }
      }

      &__afternoon {
        padding-left: 0.5rem;
        @media screen and (min-width: 600px) {
          padding-left: 0;
        }
      }
    }
  }
}
</style>
