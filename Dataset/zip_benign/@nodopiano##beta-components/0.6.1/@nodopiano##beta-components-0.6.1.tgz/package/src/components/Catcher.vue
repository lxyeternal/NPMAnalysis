<template>
  <div class="form">
    <form
      v-if="!success"
      action=""
      method="POST"
      enctype="multipart/form-data"
      name="landing-odar"
      autocomplete="off"
      @submit.prevent="validateBeforeSubmit"
    >
      <div class="row">
        <div class="col">
          <label for="nome">
            Nome e Cognome*
            <input
              v-validate="{ required: true }"
              :class="{'input': true, 'is-danger': errors.has('nome') }"
              v-model="formData.nome"
              type="text"
              class="form__field"
              name="nome"
              placeholder="Nome e Cognome"
            >
            <span
              v-show="errors.has('nome')"
              class="form__error"
            >
              Inserisci il tuo nome completo.
            </span>
          </label>
        </div>
        <div class="col">
          <label for="telefono">
            Telefono*
            <input
              v-validate="'required|numeric'"
              :class="{'input': true, 'is-danger': errors.has('telefono') }"
              v-model="formData.telefono"
              type="text"
              class="form__field"
              name="telefono"
              placeholder="Telefono"
            >
            <span
              v-show="errors.has('telefono')"
              class="form__error"
            >
              Inserisci un numero di telefono o di cellulare valido.
            </span>
          </label>
        </div>
      </div>
      <label for="email">
        Email*
        <input
          v-validate="'required|email'"
          :class="{'input': true, 'is-danger': errors.has('email') }"
          v-model="formData.email"
          type="email"
          class="form__field"
          name="email"
          placeholder="Email"
        >
        <span
          v-show="errors.has('email')"
          class="form__error"
        >
          L'indirizzo email è obbligatorio, controlla di averlo scritto correttamente.
        </span>
      </label>
      <label for="messaggio">
        Il tuo messaggio*
        <textarea
          v-validate="{ required: true }"
          :class="{'input': true, 'is-danger': errors.has('messaggio') }"
          v-model="formData.messaggio"
          :placeholder="textAreaPlaceholder"
          class="form__field textarea"
          name="messaggio"
          rows="5"
        />
        <span
          v-show="errors.has('messaggio')"
          class="form__error"
        >
          Non vuoi chiederci nulla?
        </span>
      </label>
      <label
        for="privacy"
        class="form__checkbox"
      >
        <input
          v-validate="{ required: true }"
          v-model="formData.privacy"
          type="checkbox"
          class="checkbox"
          name="privacy"
        >
        Accetto i
        <a
          :href="iubendaUrl"
          rel="roopener noreferrer"
          target="_blank"
        >
          Termini e le condizioni
        </a>
        <span
          v-show="errors.has('privacy')"
          class="form__error"
        >
          Accetta le nostre condizioni per poter proseguire.
        </span>
      </label>
      <div class="form__actions">
        <button
          type="submit"
          class="form__submit button">
          <span v-if="loading">
            <i
              class="fa fa-spinner fa-spin"
              aria-hidden="true"
            />
            &nbsp;&nbsp;
          </span>
          {{ submitText }}
        </button>
      </div>
    </form>
    <div
      v-if="success"
      class="form__success"
    >
      Grazie! Il tuo messaggio è stato inviato.<br>Sarai contattato al più presto.
    </div>
  </div>
</template>

<script>

export default {
  data() {
    return {
      formData: {
        nome: '',
        email: '',
        telefono: '',
        messaggio: '',
        privacy: false,
      },
      success: false,
      loading: false
    }
  },

  computed: {
    submitText() {
      return this.$safeGet(() => this.$store.getters.alphaPage.acf.form_submit_label)
        ? this.$store.getters.alphaPage.acf.form_submit_label
        : 'Invia'
    },
    textAreaPlaceholder() {
      let baseText = 'Scrivi qui il tuo messaggio'
      return this.$safeGet(() => this.$store.getters.alphaPage.title.rendered)
        ? `${baseText} per ${this.$store.getters.alphaPage.title.rendered}`
        : baseText
    },
    iubendaUrl() {
      return `${this.$alphaOptions.iubendaUrl}${this.$safeGet(() =>this.$store.getters.apiKeys.iubenda_id)}`
    }
  },

  methods: {
    resetForm: function() {
      this.loading = false
      this.success = true
      this.formData.nome = ''
      this.formData.email = ''
      this.formData.telefono = ''
      this.formData.messaggio = ''
      this.formData.privacy = false
    },
    submitForm: function() {
      this.formData.privacy = this.formData.privacy ? 'Accetto i termini e le condizioni sulla privacy' : false
      this.loading = true
      this.$axios
        .post(
          `${this.$alphaOptions.catcherUrl}${this.$store.getters.apiKeys.catcher_id}`,
          {
            _replyto: this.formData.email,
            debug: this.$alphaOptions.catcherDebug,
            data: this.formData
          },
          {
            headers: {
              'Content-type': 'application/json',
              'X-Api-Key': this.$store.getters.apiKeys.catcher_key
            }
          }
        )
        .then(response => {
          this.resetForm()
          return response
        })
        .then(response => {
          if (window.dataLayer && !this.debug) {
            window.dataLayer.push({ event: 'form-inviato' })
          }
        })
    },
    validateBeforeSubmit: function() {
      this.$validator.validateAll().then(result => {
        if (result)
          this.submitForm()
      })
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';
.form {
  width: 100%;

  label {
    font-size: 0.75rem;
    width: 100%;
  }

  .row {
    display: flex;
    flex-flow: row wrap;
    width: 100%;
  }

  .col {
    flex: 0 0 100%;
    max-width: 100%;
    width: 100%;

    @media screen and (min-width: 900px) {
      flex: 0 0 50%;
      max-width: 50%;

      &:first-child label {
        padding-left: 0;
      }

      &:last-child label {
        padding-right: 0;
      }
    }

    label {
      display: inline-block;
      padding: 0 0.5rem;
    }
  }

  &__field {
    border: 1px solid $medium-gray;
    font-family: inherit;
    margin: 0.5rem 0;
    min-height: 45px;
    transition: 0.4s all;
    width: 100%;

    &:not(textarea) {
      padding: 0 1rem;
    }

    &:focus {
      outline: 0;
    }

    &.is-danger {
      outline: 2px solid $danger;
      transition: 0.4s all;
    }
  }

  &__error {
    background-color: $danger;
    color: $white;
    display: block;
    padding: 0.25rem;
    width: 100%;
  }

  &__checkbox {
    display: block;
    margin: 1rem 0;
    width: 100%;
  }

  &:not(.contact__form) {
    input[type='checkbox'].checkbox ~ a {
      color: $white;
      text-decoration: underline;

      &:hover {
        opacity: 0.75;
      }
    }
  }

  &__actions {
    text-align: right;
  }

  &__submit {
    margin: 0.5rem 0;
  }

  &__success {
    background-color: $success;
    color: $white;
    font-weight: bold;
    margin: 1rem 0;
    padding: 1rem;
    text-align: center;
  }
}
</style>
