<template>
  <div
    :id="$calcId(item)"
    :class="`block-${item.acf_fc_layout} block__inner b-${index}`"
  >
    <div :class="`block-${item.acf_fc_layout}__wrapper`">
      <div :class="`block-${item.acf_fc_layout}__col-sx`">
        <h2 :class="`block-${item.acf_fc_layout}__title`">
          {{ item.pros_title }}
        </h2>
        <h4 :class="`block-${item.acf_fc_layout}__subtitle`">
          {{ item.pros_subtitle }}
        </h4>
        <div
          :class="`block-${item.acf_fc_layout}__txt`"
          v-html="item.pros_txt"
        />
      </div>
      <div :class="`block-${item.acf_fc_layout}__col-dx`">
        <ul
          :class="`block-${item.acf_fc_layout}__list`"
          class="pros-list"
        >
          <li
            v-for="(point, index) in item.pros_points"
            :key="index"
            class="pros-list__item point"
          >
            <i
              :class="point.point_icon"
              class="point__icon"
              aria-hidden="true"
            />
            <h3 class="point__title">
              {{ point.point_title }}
            </h3>
            <div
              class="point__txt"
              v-html="point.point_txt"
            />
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';

.block-pros {
  &__wrapper {
    @include pill-row();
    align-content: center;
    padding: 2rem 0 0;
    width: 100%;

    @media screen and (min-width: 600px) {
      padding: 2rem 0 2rem;
    }

    @media screen and (min-width: 900px) {
      padding: 2rem;
    }

    @media screen and (min-width: 1200px) {
      padding: 4rem 1rem;
    }
  }

  &__col-sx {
    @include pill-column(12, 0, block);
    padding: 0 1rem;

    @media screen and (min-width: 900px) {
      @include pill-column(5, 0, block);
      padding: 0 1rem 0 0;
    }

    @media screen and (min-width: 1200px) {
      @include pill-column(6, 0, block);
      padding: 0 1rem 0 0;
    }
  }

  &__col-dx {
    @include pill-column(12, 0, flex);
    padding: 0 1rem;

    @media screen and (min-width: 900px) {
      @include pill-column(7, 0, block);
      padding: 0 0 0 1rem;
    }

    @media screen and (min-width: 1200px) {
      @include pill-column(6, 0, block);
      padding: 0 0 0 1rem;
    }
  }

  &__title {
    color: var(--primary_normal-darker);
    margin: 1rem 0;
  }

  &__subtitle {
    color: var(--primary_dark);
  }

  &__txt {
    padding: 1rem 0;
  }

  .pros-list {
    @include pill-column(12, 0, flex);
    flex-flow: row wrap;
    list-style-type: none;

    .point {
      @include pill-column(12, 0);
      padding: 1rem 0;
      text-align: center;

      @media screen and (min-width: 600px) {
        @include pill-column(6, 0);
        padding: 1rem;
      }

      &__icon {
        color: var(--primary_dark);
        font-size: 4rem;
        width: 100%;
      }

      &__title {
        color: var(--primary_dark);
        font-size: 1.5rem;
        margin: 1rem 0;
      }
    }
  }
}
</style>
