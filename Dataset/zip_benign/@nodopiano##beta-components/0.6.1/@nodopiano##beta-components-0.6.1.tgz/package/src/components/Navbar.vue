<template>
  <header
    id="header"
    :class="{'is-fixed': $store.getters.scrolled}"
    class="header"
  >
    <div
      v-if="srcLogo"
      class="top-bar logo"
    >
      <a href="/">
        <img
          :alt="`Logo ${alphaPage.title.rendered}`"
          :src="srcLogo"
          width="200"
          height="68"
        >
      </a>
    </div>
    <nav class="main-menu">
      <a
        v-for="(item, index) in menuItems"
        :data-anchor="$slugify(item.menu_title)"
        :key="index"
        class="main-menu__item"
        @click="scrollToAnchor"
      >
        {{ item.menu_title }}
      </a>
    </nav>
  </header>
</template>
<script>

export default {
  beforeMount() {
    window.addEventListener('scroll', this.handleScroll)
  },

  computed: {
    srcLogo() {
      return this.$safeGet(() => this.acf.logo)
    },
    alphaPage() {
      return this.$store && this.$store.getters.alphaPage ? this.$store.getters.alphaPage : {}
    },
    acf() {
      return this.alphaPage.acf || {}
    },
    menuItems() {
      return (this.acf.builder || []).filter((item, index) => {
        return item.menu_title.length
      })
    }
  },

  methods: {
    handleScroll() {
      if (window.scrollY > 200) this.$store.dispatch('setScrolled', true)
      else this.$store.dispatch('setScrolled', false)
    },
    scrollToAnchor: function(event) {
      let anchor = event.target.getAttribute('data-anchor')
      let element = document.getElementById(anchor)
      let hmenu = document.getElementById('header').offsetHeight
      var bodycoord = document.body.getBoundingClientRect()
      var offsetTop =
        element.getBoundingClientRect().top - bodycoord.top - hmenu
      if (document.body.scrollTop === 0) {
        scrollTo(document.documentElement, offsetTop, 400)
      }
      if (document.documentElement.scrollTop === 0) {
        scrollTo(document.body, offsetTop, 400)
      }

      function scrollTo(element, to, duration) {
        if (duration <= 0) return
        var difference = to - element.scrollTop
        var perTick = (difference / duration) * 10

        setTimeout(function() {
          element.scrollTop = element.scrollTop + perTick
          if (element.scrollTop === to) return
          scrollTo(element, to, duration - 10)
        }, 10)
      }
    }
  }
}
</script>

<style lang="scss">
</style>
