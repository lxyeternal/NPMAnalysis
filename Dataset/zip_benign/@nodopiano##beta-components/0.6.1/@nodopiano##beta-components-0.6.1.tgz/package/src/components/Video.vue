<template>
  <div
    :id="$calcId(item)"
    :class="`block-${item.acf_fc_layout} block__inner b-${index}`"
    :style="`background-color:${item.video_bgcolor}`"
  >
    <div :class="`block-${item.acf_fc_layout}__wrapper`">
      <h2 v-if="item.video_title" :class="`block-${item.acf_fc_layout}__title`">
        {{ item.video_title }}
      </h2>
      <h4 v-if="item.video_subtitle" :class="`block-${item.acf_fc_layout}__subtitle`">
        {{ item.video_subtitle }}
      </h4>
      <div v-if="item.video_description" :class="`block-${item.acf_fc_layout}__text`" v-html="item.video_description" />
      <div :class="`block-${item.acf_fc_layout}__inner`">
        <div v-if="useCustomIframe" class="embedded-video" v-html="item.custom_iframe_code"/>
        <div v-if="showFrame" class="embedded-video">
          <iframe
            :src="iframeSrc"
            :height="iframeHeight"
            :width="iframeWidth"
            frameborder="0"
            allow="autoplay; encrypted-media; fullscreen"
            allowfullscreen
          ></iframe>
        </div>
        <div v-if="!useCustomIframe && showFrom.custom" class="embedded-video">
          <video :height="iframeHeight" :width="iframeWidth" controls>
            <source :src="videoMp4" type="video/mp4">
            <source :src="videoOgg" type="video/ogg">
            Il tuo browser non supporta la visualizzazione dei video.
          </video>
        </div>
        <div v-if="!useCustomIframe && showFrom.cloudinary" class="embedded-video">
          <cld-video
            :cloudName="cloudName"
            :publicId="cloudinaryVideoID"
            :height="iframeHeight"
            :width="iframeWidth"
            :posterOptions="cloudinaryPoster"
            controls
            fallbackContent="Il tuo browser non supporta la visualizzazione dei video."
            class="cloudinary-video"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { CldVideo } from 'cloudinary-vue';

export default {
  components: {
    CldVideo
  },

  props: {
    index: {
      type: Number,
      default: 0,
      required: false
    },
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  },

  data() {
    return {
      videoOrigin: {
        vimeo: 'https://player.vimeo.com/video/',
        youtube: 'https://www.youtube-nocookie.com/embed/'
      }
    }
  },

  computed: {
    useCustomIframe() {
      return this.item.use_custom_iframe
    },
    iframeSrc() {
      if (this.item.video_url) {
        if (!this.isUrlComplete(this.item.video_url))
          return `${this.videoOrigin[this.item.video_origin]}${this.item.video_url}`
        return this.item.video_url
      }
      return ''
    },
    iframeHeight() {
      return this.item.video_height || false
    },
    iframeWidth() {
      return this.item.video_width || false
    },
    videoMp4() {
      return this.item.video_url_mp4 || false
    },
    videoOgg() {
      return this.item.video_url_ogg || false
    },
    showFrom() {
      return {
        cloudinary: this.item.video_origin === 'cloudinary',
        custom: this.item.video_origin === 'custom',
        youtube: this.item.video_origin === 'youtube',
        vimeo: this.item.video_origin === 'vimeo'
      }
    },
    showFrame() {
      return !this.useCustomIframe && (this.showFrom.vimeo || this.showFrom.youtube)
    },
    cloudName() {
      return this.item.cloudinary_cloud_name || ''
    },
    cloudinaryVideoID() {
      return this.item.cloudinary_video_id || ''
    },
    cloudinaryPoster() {
      if (this.item.cloudinary_poster) {
        return {
          publicId: this.item.cloudinary_poster
        }
      }
      return false
    }
  },

  methods: {
    isUrlComplete(url) {
      return new RegExp(/((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/)
        .test(url)
    }
  }
}
</script>

<style lang="scss">
.block-video_embed {
  &__wrapper {
    align-content: center;
    padding: 2rem 1rem;
    width: 100%;
    margin: 0 auto;
    max-width: 1200px;

    @media screen and (min-width: 900px) {
      padding: 4rem 2rem;
    }

    @media screen and (min-width: 1200px) {
      padding: 4rem 1rem;
    }
  }

  &__title {
    color: var(--primary_normal-darker);
    margin: 1rem 0;
    text-align: center;
    width: 100%;
  }

  &__subtitle {
    color: var(--primary_dark);
    text-align: center;
    width: 100%;
  }
}

.embedded-video {
  padding: 1rem 0.5rem;
  margin: 0 auto;
  max-width: 75rem;
  width: 100%;

  iframe {
    height: calc(100vw * 9 / 16);
    width: 100%;

    @media screen and (min-width: 1200px) {
      height: calc(1200px * 9 / 16);
    }
  }

  video {
    width: 100%;
  }
}
</style>
