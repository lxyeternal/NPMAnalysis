<template>
  <div
    :id="$calcId(item)"
    :class="`block-${item.acf_fc_layout} block__inner`"
    :style="`background-image: url('${bgImage}')`"
  >
    <div :class="'block-'+item.acf_fc_layout+'__img'">
      <client-only>
        <Parallax
          :speed-factor="0.5"
          :section-height="ParallaxHeight"
          breakpoint="(min-width: 900px)"
          section-class="paraller"
          container-class="paraller__img"
        >
          <img
            :src="item.hero_img.url"
            :srcset="`${item.hero_img.sizes['medium']} 300w,
                      ${item.hero_img.sizes['medium_large']} 600w,
                      ${item.hero_img.sizes['large']} 900w,
                      ${item.hero_img.url} 1200w`"
            :width="item.hero_img.width"
            :height="item.hero_img.height"
            :alt="item.hero_img.alt"
            sizes="100vw"
          >
        </Parallax>
      </client-only>
      <div
        :class="`block-${item.acf_fc_layout}__scrolldown scrolldown`"
        @click="scrollPage"
      >
        <down-arrow />
      </div>
    </div>
    <div
      :class="`block-${item.acf_fc_layout}__wrapper`"
      :style="`min-height:${ParallaxHeight}vh`"
    >
      <div :class="`block-${item.acf_fc_layout}__content`">
        <h2
          :class="`block-${item.acf_fc_layout}__title`"
          v-html="item.hero_title"
        />
        <h4
          :class="`block-${item.acf_fc_layout}__subtitle`"
          v-html="item.hero_subtitle"
        />
        <div
          :class="`block-${item.acf_fc_layout}__txt`"
          v-html="item.hero_txt"
        />
      </div>
      <div
        v-if="showCatcher"
        :class="`block-${item.acf_fc_layout}__form`"
      >
        <div class="form-box">
          <h3
            class="form-box__title"
            v-html="$store.getters.alphaPage.acf.form_title"
          />
          <catcher />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Parallax from 'vue-parallaxy'
import catcher from './Catcher.vue'
import DownArrow from './DownArrow'

export default {
  components: {
    Parallax,
    catcher,
    DownArrow
  },

  props: {
    item: {
      type: Object,
      default: () => {
        return {}
      },
      required: false
    }
  },

  data() {
    return {
      ParallaxHeight: 95
    }
  },

  computed: {
    bgImage() {
      return this.item.hero_img_mobile.url
        ? this.item.hero_img_mobile.url
        : this.item.hero_img.sizes.medium_large
    },
    showCatcher() {
      return this.$safeGet(() => this.$store.getters.alphaPage.acf.show_form)
    }
  },


  methods: {
    scrollPage: function(event) {
      let hmenu = document.getElementById('header').offsetHeight
      let htot =
        Math.max(
          document.documentElement.clientHeight,
          window.innerHeight || 0
        ) - hmenu

      if (document.body.scrollTop === 0) {
        scrollTo(document.documentElement, htot, 400)
      }
      if (document.documentElement.scrollTop === 0) {
        scrollTo(document.body, htot, 400)
      }

      function scrollTo(element, to, duration) {
        if (duration <= 0) return
        var difference = to - element.scrollTop
        var perTick = (difference / duration) * 10

        setTimeout(function() {
          element.scrollTop = element.scrollTop + perTick
          if (element.scrollTop === to) return
          scrollTo(element, to, duration - 10)
        }, 10)
      }
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';
.block-hero {
  align-content: space-between;
  box-shadow: inset 0 100vh 50vh rgba(70, 42, 22, 0.5);
  background-size: cover;
  background-position: left center;
  width: 100%;

  @media screen and (min-width: 900px) {
    background-image: none !important;
    box-shadow: none;
  }

  &__img {
    background-color: #4c4a33;
    left: 0;
    position: absolute;
    top: 0;
    width: 100%;
    z-index: 0;

    .paraller {
      overflow: hidden;

      @media screen and (max-width: 900px) {
        height: auto !important;
      }
    }

    img {
      display: none;
      height: 100vh;
      min-width: 100vw;
      opacity: 0.6;
      vertical-align: middle;
      width: auto;

      @media screen and (min-width: 900px) {
        display: block;
        height: 95vh;
      }

      @media screen and (min-width: 1440px) {
        height: auto;
        width: 100%;
      }
    }
  }

  .scrolldown {
    bottom: 1rem;
    color: $white;
    cursor: pointer;
    font-size: 2rem;
    height: 50px;
    left: 50%;
    position: absolute;
    text-align: center;
    transform: translate(-50%, 0);

    & .down-arrow {
      height: 40px;
      width: 40px;

      & path {
        fill: white;
      }
    }
  }

  &__wrapper {
    @include pill-row();
    height: 100%;
    align-content: center;
    width: 100%;

    @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
      padding-top: 2rem;
    }

    @media screen and (min-width: 900px) {
      min-height: 95vh !important;

      @media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
        padding-top: 6rem;
      }
    }
  }

  &__content {
    @include pill-column(12, 0, block);
    align-self: center;
    padding: 2rem 1rem;
    position: relative;
    text-align: center;
    z-index: 1;

    @media screen and (min-width: 900px) {
      @include pill-column(6, 0, block);
      padding: 2rem;
      text-align: left;
    }
  }

  &__title {
    color: $white;
    margin: 0 0 0.5rem;
  }

  &__subtitle {
    color: $white;
  }

  &__txt {
    color: $white;
    padding: 1rem 0;
  }

  &__form {
    @include pill-column(12, 0, block);
    align-self: center;
    padding: 0;
    position: relative;
    z-index: 1;

    @media screen and (min-width: 900px) {
      @include pill-column(6, 0, block);
      padding: 2rem 2rem 2rem 0;
    }

    @media screen and (min-width: 1200px) {
      padding: 2rem 0;
    }

    .form-box {
      background-color: rgba($black, 0.33);
      padding: 2rem 1rem;

      @media screen and (min-width: 900px) {
        background-color: rgba(59, 70, 77, 0.9);
        padding: 1rem 2rem;
      }

      @media screen and (min-width: 1200px) {
        padding: 2rem;
      }

      &__title {
        color: $white;
        font-weight: 500;
        margin: 0 0 1rem;
        text-align: center;
      }
    }

    label {
      color: $white;
      font-size: 0.75rem;
    }
  }
}

.top-bar {
  position: absolute;
  top: 1rem;
  z-index: 50;
  left: 0;
  right: 0;

  & a {
    display: flex;
    justify-content: center;
  }
}
</style>
