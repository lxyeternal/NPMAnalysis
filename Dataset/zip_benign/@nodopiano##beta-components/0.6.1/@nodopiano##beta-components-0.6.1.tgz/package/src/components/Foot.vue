<template>
  <footer class="footer">
    <div class="footer__inner">
      <div class="footer__logo">
        <img
          v-if="srcLogo"
          :alt="altLogo"
          :src="srcLogo"
          width="241"
          height="75"
        >
      </div>
      <div
        class="footer__col-sx"
        v-html="$store.getters.alphaPage.acf.footer_txt"
      />
      <div class="footer__col-dx">
        <ul class="footer__data fdata">
          <li
            v-for="(fdata, index) in $store.getters.alphaPage.acf.footer_data"
            :key="index"
            class="fdata__item fitem">
            <a
              :href="fdata.link"
              class="fitem__link"
              target="_blank"
              rel="noopener noreferrer"
            >
              <i
                :class="fdata.icon"
                aria-hidden="true"
              />
              {{ fdata.label }}
            </a>
          </li>
        </ul>
      </div>
      <div class="footer__credits credits">
        <div class="credits__inner">
          <ul class="credits__list no-bullet">
            <li class="credits__item">
              <a
                :href="iubendaUrl"
                target="_blank"
                rel="noopener noreferrer"
              >
                Privacy Policy
              </a>
            </li>
            <li class="credits__item">
              <a
                :href="iubendaCookie"
                target="_blank"
                rel="noopener noreferrer"
              >
                Cookie Policy
              </a>
            </li>
            <li class="credits__item">
              <a
                href="https://www.nodopiano.it"
                target="_blank"
                rel="noopener noreferrer"
              >
                Made by Nodopiano
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
export default {
  computed: {
    altLogo() {
      return this.$safeGet(() => this.$store.alphaPage.title.rendered, 'Logo')
    },
    srcLogo() {
      let alphaPage = this.$store.state.alphaPage
      if (alphaPage && alphaPage.acf && alphaPage.acf.footer && alphaPage.acf.footer.logo)
        return alphaPage.acf.footer.logo
      return ''
    },
    iubendaUrl() {
      return `${this.$alphaOptions.iubendaUrl}${this.$safeGet(() => this.$store.getters.apiKeys.iubenda_id)}`
    },
    iubendaCookie() {
      return `${this.iubendaUrl}/cookie-policy`
    }
    }
}
</script>

<style lang="scss">
@import '../assets/scss/global.scss';
.footer {
  background-color: $black;
  color: $white;
  padding: 2rem 0;
  position: relative;
  width: 100%;

  @media screen and (min-width: 900px) {
    padding: 2rem 1rem;
  }

  &__inner {
    @include pill-row();
    padding: 0;
  }

  a:not(.button):link,
  a:not(.button):visited {
    color: var(--primary_normal);
    transition: $fast-animated;
  }

  a:not(.button):hover,
  a:not(.button):active {
    color: var(--primary_light);
    transition: $fast-animated;
  }

  &__logo {
    @include pill-column(12, 0);
    text-align: center;
    padding: 0 1rem;

    @media screen and (min-width: 900px) {
      text-align: left;
    }

    img {
      height: auto;
      width: 200px;
    }
  }

  &__col-sx {
    @include pill-column(12, 0);
    padding: 1rem;
    text-align: center;

    @media screen and (min-width: 900px) {
      @include pill-column(6, 0);
      padding: 1rem;
      text-align: left;
    }
  }

  &__col-dx {
    @include pill-column(12, 0);
    padding: 1rem;
    text-align: center;

    @media screen and (min-width: 900px) {
      @include pill-column(6, 0);
      padding: 1rem;
      text-align: left;
    }
  }

  ul {
    list-style-type: none;
  }
}

.credits {
  padding: 1rem 0;
  width: 100%;

  &__inner {
    @include pill-row();
    padding: 0 1rem;
  }

  &__list {
    display: flex;
    flex-flow: row wrap;
    justify-content: center;
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 100%;

    @media screen and (min-width: 900px) {
      justify-content: flex-start;
    }
  }

  &__item {
    a:not(.button) {
      border-right: 1px solid $white;
      //color: $white;
      font-size: 0.75rem;
      padding: 0 0.33rem;

      @media screen and (min-width: 600px) {
        font-size: 0.9rem;
        padding: 0 0.5rem;
      }

      @media screen and (min-width: 900px) {
        font-size: 1rem;
      }
    }

    &:first-child a {
      padding: 0 0.33rem 0 0;

      @media screen and (min-width: 600px) {
        padding: 0 0.5rem 0 0;
      }
    }

    &:last-child a {
      border: none;
    }
  }
}
</style>
