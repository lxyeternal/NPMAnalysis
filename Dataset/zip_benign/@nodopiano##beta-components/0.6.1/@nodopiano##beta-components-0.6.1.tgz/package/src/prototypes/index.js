import calcId from './calcId'
import safeGet from './safeGet'
import slugify from './slugify'

export { calcId, safeGet, slugify }

export default {
  calcId,
  safeGet,
  slugify
}
