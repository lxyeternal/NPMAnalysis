export default (toSlug) => {
  if (toSlug)
    return toSlug.replace(' ', '-').toLowerCase()
  return false
}
