import slugify from './slugify'

export default (item, defVal = false) => {
  return item.menu_title
    ? slugify(item.menu_title)
    : defVal
}
