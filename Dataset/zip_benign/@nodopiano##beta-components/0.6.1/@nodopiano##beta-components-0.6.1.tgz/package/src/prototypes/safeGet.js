export default (objFn, defVal = false) => {
  try {
    return objFn()
  } catch (e) {
    return defVal
  }
}
