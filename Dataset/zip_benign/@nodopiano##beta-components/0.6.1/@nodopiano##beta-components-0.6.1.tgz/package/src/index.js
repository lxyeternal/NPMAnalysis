import CallToAction from './components/CallToAction'
import Catcher from './components/Catcher'
import Foot from './components/Foot'
import Hero from './components/Hero'
import MediaText from './components/MediaText'
import Navbar from './components/Navbar'
import Pros from './components/Pros'
import Slideshow from './components/Slideshow'
import Testo from './components/Testo'
import Times from './components/Times'
import Video from './components/Video'

import VeeValidate from 'vee-validate'

import { calcId, safeGet, slugify } from './prototypes'

export { CallToAction, Catcher, Foot, Hero, MediaText, Navbar, Pros, Slideshow, Testo, Times, Video }

const defaultOpt = {
  catcherDebug: true,
  catcherUrl: '',
  iubendaUrl: ''
}

export default {
  install: function (Vue, options) {
    Vue.component('call_to_action', CallToAction)
    Vue.component('catcher', Catcher)
    Vue.component('foot', Foot)
    Vue.component('hero', Hero)
    Vue.component('media_text', MediaText)
    Vue.component('navbar', Navbar)
    Vue.component('pros', Pros)
    Vue.component('slideshow', Slideshow)
    Vue.component('testo', Testo)
    Vue.component('times', Times)
    Vue.component('video_embed', Video)
    Vue.use(VeeValidate)
    Vue.prototype.$alphaOptions = { ...defaultOpt, ...options }
    Vue.prototype.$calcId = calcId
    Vue.prototype.$safeGet = safeGet
    Vue.prototype.$slugify = slugify
  }
}
