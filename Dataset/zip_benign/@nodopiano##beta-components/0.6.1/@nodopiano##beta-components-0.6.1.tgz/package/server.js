const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults();

server.use(middlewares);
server.use(router);
server.listen(3000, () => {
    console.log('JSON Server is running');
});

// In this example, returned resources will be wrapped in a body property
router.render = (req, res) => {
    if (req.route.path == '/') {
        res.jsonp({
            data: res.locals.data,
            links: {
                first: '/api/groups?page=1',
                last: '/api/groups?page=1',
                prev: null,
                next: null,
            },
            meta: {
                current_page: 1,
                from: 1,
                last_page: 1,
                path: '/api/groups',
                per_page: 20,
                to: 4,
                total: 4,
            },
        });
    } else {
        res.jsonp(res.locals.data);
    }
};
