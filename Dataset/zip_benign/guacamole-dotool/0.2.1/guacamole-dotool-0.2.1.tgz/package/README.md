A command-line [Guacamole](https://guacamole.apache.org/) client and TypeScript/JavaScript library for headless scripting.
It’s exactly like [vncdotool](https://github.com/sibson/vncdotool) or [xdotool](https://github.com/jordansissel/xdotool), but over the Guacamole protocol.

## Installation

### On Alpine Linux

    apk add guacamole-dotool

### Using npm

    npm install --global guacamole-dotool

**Warning:** The [canvas](https://github.com/Automattic/node-canvas) package downloads pre-built native libraries (cairo, pango, libjpeg…) from npmjs.com by default.
If you want to build it from source instead (highly recommended), use option `--build-from-source`.
See [node-canvas installation](https://github.com/Automattic/node-canvas#installation) for details.

## Usage

### Command line

``` sh
guacamole-dotool --url wss://example.org/guacamole -- \
  key Cmd+t pause 2 type 'echo "Hello, world!"' key Enter pause 0.5 capture screenshot.png
```

Run `guacamole-dotool --help` to learn more.

### TypeScript / JavaScript

``` ts
import { Client, setDomGlobals } from 'guacamole-dotool'

// Set canvas, jsdom and ws to the global context.
setDomGlobals()

// Connect to Guacamole via WebSocket.
const c = await Client.connect('wss://example.org/guacamole')

// Run commands...
await c.keysPress('Cmd', 't')
await c.pause(2)
await c.type('echo "Hello, world!"')
await c.keysPress('Enter')
await c.pause(0.5)
await c.captureScreenToFile('screenshot.png')

c.disconnect()
```

See [src/client.ts](src/client.ts) to learn more.

## License

This project is licensed under [MIT License](http://opensource.org/licenses/MIT/).
For the full text of the license, see the [LICENSE](LICENSE) file.
