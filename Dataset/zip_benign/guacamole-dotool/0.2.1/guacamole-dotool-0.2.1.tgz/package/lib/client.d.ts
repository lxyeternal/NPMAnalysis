/// <reference types="node" resolution-mode="require"/>
import type { PngConfig } from 'canvas';
import Guacamole from 'guacamole-common-js';
import { KeyboardMapper } from './keyboard.js';
import type { Keymap, KeymapKey, ModifierKey, DefaultKeymap } from './keymaps.js';
import { MouseButton } from './mouse.js';
export interface ClientOptions {
    /**
     * Delay in milliseconds between key down and up.
     * @default 12
     */
    toggleDelay?: number;
    /**
     * Delay in milliseconds between repeated mouse clicks.
     * @default 100
     */
    doubleClickDelay?: number;
    /**
     * Delay in milliseconds between keystrokes.
     * @default 50
     */
    delayBetweenKeys?: number;
}
/** @see {@link Client.connect} */
export interface Client<TKeymap extends Keymap = DefaultKeymap> {
    /** Presses `keys` (`keysDown` followed by `keysUp`). */
    keysPress(keys: readonly KeymapKey<TKeymap>[]): Promise<void>;
    keysPress(...keys: KeymapKey<TKeymap>[]): Promise<void>;
    /** Holds down `keys` (all at once). */
    keysDown(keys: readonly KeymapKey<TKeymap>[]): void;
    keysDown(...keys: KeymapKey<TKeymap>[]): void;
    /** Releases `keys` (all at once). */
    keysUp(keys: readonly KeymapKey<TKeymap>[]): void;
    keysUp(...keys: KeymapKey<TKeymap>[]): void;
    /** Types `text` as if you had typed it. */
    type(text: string): Promise<void>;
    /** Sends a mouse `button` click. */
    mouseClick(button: MouseButton, count?: number, modifiers?: ModifierKey[]): Promise<void>;
    /** @deprecated This should be used only for commands. */
    mouseDoubleClick(button: MouseButton): Promise<void>;
    /** Holds down mouse `button`. */
    mouseButtonDown(button: MouseButton): void;
    /** Releases mouse `button`. */
    mouseButtonUp(button: MouseButton): void;
    /** Scrolls number of `lines` up (positive number) or down (negative number). */
    scroll(lines: number): Promise<void>;
    /** Moves the mouse cursor to `x`, `y` coordinates. */
    mouseMove(x: number, y: number): Promise<void>;
    /** Takes a screenshot of the current screen and returns PNG data. */
    captureScreen(config?: PngConfig): Promise<Buffer>;
    /** Takes a screenshot and saves PNG to the `filename`. */
    captureScreenToFile(filename: string, config?: PngConfig): Promise<void>;
    /** Waits `seconds`. */
    pause(seconds: number): Promise<void>;
    /** Disconnects from the remote host. */
    disconnect(): void;
}
/** @see {@link Client.connect} */
export declare const createClient: <TKeymap extends Keymap<string>>(client: Guacamole.Client, tunnel: Guacamole.Tunnel, keyboard: KeyboardMapper<TKeymap>, options?: ClientOptions) => Client<TKeymap>;
export declare namespace Client {
    /**
     * Connects to `websocketUrl` (`wss://` or `ws://` scheme) and returns
     * initialized Client.
     *
     * **IMPORTANT**: You have to invoke {@link setDomGlobals} before the first
     * time you connect!
     */
    function connect<TKeymap extends Keymap = DefaultKeymap>(websocketUrl: string, keymap?: TKeymap, options?: ClientOptions): Promise<Client<TKeymap>>;
}
