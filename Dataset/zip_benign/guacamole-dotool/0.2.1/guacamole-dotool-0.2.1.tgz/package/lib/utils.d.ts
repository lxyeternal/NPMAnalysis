/** @private */
export type Enum<T extends Record<string, string>> = T[keyof T];
/** @private Type of the `Object.entries()` return value. */
export type Entries<T> = {
    [K in keyof T]: [K, T[K]];
}[keyof T][];
