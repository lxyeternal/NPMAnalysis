import { Enum } from './utils.js';
type Keysyms<K extends string = string> = Readonly<Record<K, number | undefined>>;
/** Printable characters in the US keymap mapped to their code point. */
declare const PrintableKeysyms: Readonly<Record<"0" | "d" | "e" | "k" | "n" | "p" | "q" | "x" | "y" | "\\" | "/" | ";" | "a" | "b" | "i" | "s" | "u" | " " | "`" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "-" | "=" | "w" | "r" | "t" | "o" | "[" | "]" | "f" | "g" | "h" | "j" | "l" | "'" | "z" | "c" | "v" | "m" | "," | ".", number>>;
export declare const ModifierKey: Readonly<{
    LShift: "LShift";
    Shift: "Shift";
    RShift: "RShift";
    LCtrl: "LCtrl";
    Ctrl: "Ctrl";
    RCtrl: "RCtrl";
    CapsLock: "CapsLock";
    CapLk: "CapLk";
    LAlt: "LAlt";
    Alt: "Alt";
    RAlt: "RAlt";
    LSuper: "LSuper";
    Super: "Super";
    Cmd: "Cmd";
    Win: "Win";
    RSuper: "RSuper";
}>;
export type ModifierKey = Enum<typeof ModifierKey>;
declare const ControlKey: Readonly<{
    Space: "Space";
    Backspace: "Backspace";
    Bsp: "Bsp";
    Tab: "Tab";
    Enter: "Enter";
    Pause: "Pause";
    ScrollLock: "ScrollLock";
    ScrLk: "ScrLk";
    SysReq: "SysReq";
    SysRq: "SysRq";
    Escape: "Escape";
    Esc: "Esc";
    Home: "Home";
    Left: "Left";
    Up: "Up";
    Right: "Right";
    Down: "Down";
    PageUp: "PageUp";
    PgUp: "PgUp";
    PageDown: "PageDown";
    PgDown: "PgDown";
    PgDn: "PgDn";
    End: "End";
    PrintScreen: "PrintScreen";
    PrtSc: "PrtSc";
    Insert: "Insert";
    Ins: "Ins";
    Menu: "Menu";
    NumLock: "NumLock";
    NumLk: "NumLk";
    F1: "F1";
    F2: "F2";
    F3: "F3";
    F4: "F4";
    F5: "F5";
    F6: "F6";
    F7: "F7";
    F8: "F8";
    F9: "F9";
    F10: "F10";
    F11: "F11";
    F12: "F12";
    F13: "F13";
    F14: "F14";
    F15: "F15";
    F16: "F16";
    F17: "F17";
    F18: "F18";
    F19: "F19";
    F20: "F20";
    F21: "F21";
    F22: "F22";
    F23: "F23";
    F24: "F24";
    Delete: "Delete";
    Del: "Del";
}>;
type ControlKey = Enum<typeof ControlKey>;
/** Names of control and modifier keys. */
export declare const Key: {
    Space: "Space";
    Backspace: "Backspace";
    Bsp: "Bsp";
    Tab: "Tab";
    Enter: "Enter";
    Pause: "Pause";
    ScrollLock: "ScrollLock";
    ScrLk: "ScrLk";
    SysReq: "SysReq";
    SysRq: "SysRq";
    Escape: "Escape";
    Esc: "Esc";
    Home: "Home";
    Left: "Left";
    Up: "Up";
    Right: "Right";
    Down: "Down";
    PageUp: "PageUp";
    PgUp: "PgUp";
    PageDown: "PageDown";
    PgDown: "PgDown";
    PgDn: "PgDn";
    End: "End";
    PrintScreen: "PrintScreen";
    PrtSc: "PrtSc";
    Insert: "Insert";
    Ins: "Ins";
    Menu: "Menu";
    NumLock: "NumLock";
    NumLk: "NumLk";
    F1: "F1";
    F2: "F2";
    F3: "F3";
    F4: "F4";
    F5: "F5";
    F6: "F6";
    F7: "F7";
    F8: "F8";
    F9: "F9";
    F10: "F10";
    F11: "F11";
    F12: "F12";
    F13: "F13";
    F14: "F14";
    F15: "F15";
    F16: "F16";
    F17: "F17";
    F18: "F18";
    F19: "F19";
    F20: "F20";
    F21: "F21";
    F22: "F22";
    F23: "F23";
    F24: "F24";
    Delete: "Delete";
    Del: "Del";
    LShift: "LShift";
    Shift: "Shift";
    RShift: "RShift";
    LCtrl: "LCtrl";
    Ctrl: "Ctrl";
    RCtrl: "RCtrl";
    CapsLock: "CapsLock";
    CapLk: "CapLk";
    LAlt: "LAlt";
    Alt: "Alt";
    RAlt: "RAlt";
    LSuper: "LSuper";
    Super: "Super";
    Cmd: "Cmd";
    Win: "Win";
    RSuper: "RSuper";
};
export type Key = ModifierKey | ControlKey;
/**
 * @private
 * Extract a string union of all key names (except the combined) and a `number`
 * (direct keysym code).
 */
export type KeymapKey<T extends Keymap> = keyof T['modifiers'] | keyof T['control'] | keyof T['printable'] | number;
/** Mapping of keyboard keys to keysym codes. */
export interface Keymap<TPrintable extends string = string> {
    /**
     * Name of this keymap.
     */
    readonly name: string;
    /**
     * If a given character is not found in `printable` or `combined` maps and
     * this is `true`, it should be translated to its code point. If `false`, it
     * should throw an error.
     */
    readonly allowFallback: boolean;
    /**
     * Keysym codes of modifier keys.
     */
    readonly modifiers: Keysyms<ModifierKey>;
    /**
     * Keysym codes of Control keys.
     */
    readonly control: Keysyms<ControlKey>;
    /**
     * Keysym codes of printable characters that are available on the 1st level
     * (i.e. without any modifier key).
     */
    readonly printable: Keysyms<TPrintable>;
    /**
     * Keysym sequences of characters that can be typed with a modifier.
     */
    readonly combined: Record<string, readonly number[] | undefined>;
}
/** The default keymap (US). */
export type DefaultKeymap = Keymap<keyof typeof PrintableKeysyms>;
export declare const Keymaps: {
    /**
     * A special keymap with only control & modifier keys and allowed fallback -
     * the {@link Client} will map any printable ASCII and Unicode key to its
     * code point.
     *
     * This is unusable for QEMU/KVM VNC (Guacamole's “independent of keyboard
     * layout” is a lie), but it might work well on others.
     */
    DIRECT: Readonly<{
        name: "direct";
        allowFallback: true;
        combined: {};
        printable: Record<string, number>;
        modifiers: Keysyms<ModifierKey>;
        control: Keysyms<ControlKey>;
    }>;
    /** US QWERTY - PC variant (the default) */
    US: DefaultKeymap;
    /** US QWERTY - macOS variant */
    US_MAC: Readonly<{
        name: "us-mac";
        combined: {
            '~': undefined;
        };
        printable: {
            '`': number;
            0: number | undefined;
            d: number | undefined;
            e: number | undefined;
            k: number | undefined;
            n: number | undefined;
            p: number | undefined;
            q: number | undefined;
            x: number | undefined;
            y: number | undefined;
            "\\": number | undefined;
            "/": number | undefined;
            ";": number | undefined;
            a: number | undefined;
            b: number | undefined;
            i: number | undefined;
            s: number | undefined;
            u: number | undefined;
            " ": number | undefined;
            1: number | undefined;
            2: number | undefined;
            3: number | undefined;
            4: number | undefined;
            5: number | undefined;
            6: number | undefined;
            7: number | undefined;
            8: number | undefined;
            9: number | undefined;
            "-": number | undefined;
            "=": number | undefined;
            w: number | undefined;
            r: number | undefined;
            t: number | undefined;
            o: number | undefined;
            "[": number | undefined;
            "]": number | undefined;
            f: number | undefined;
            g: number | undefined;
            h: number | undefined;
            j: number | undefined;
            l: number | undefined;
            "'": number | undefined;
            z: number | undefined;
            c: number | undefined;
            v: number | undefined;
            m: number | undefined;
            ",": number | undefined;
            ".": number | undefined;
        };
        allowFallback: boolean;
        modifiers: Keysyms<ModifierKey>;
        control: Keysyms<ControlKey>;
    }>;
};
export {};
