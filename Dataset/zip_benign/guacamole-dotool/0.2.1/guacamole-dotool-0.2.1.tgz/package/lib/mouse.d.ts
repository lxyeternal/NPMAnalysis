import { Enum } from './utils.js';
export declare const MouseButton: Readonly<{
    Left: "Left";
    Right: "Right";
    Middle: "Middle";
    ScrollUp: "ScrollUp";
    ScrollDown: "ScrollDown";
}>;
export type MouseButton = Enum<typeof MouseButton>;
