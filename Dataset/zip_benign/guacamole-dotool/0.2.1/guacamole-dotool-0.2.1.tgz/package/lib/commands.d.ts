import { Client } from './client.js';
export type Command = [cmd: keyof Client, ...args: any[]];
export type CommandName = keyof typeof Commands;
export interface CommandInfo {
    desc: string;
    method: keyof Client | ((client: Client) => Promise<void>);
    params: Array<(value: string, command: string) => any>;
}
export declare const Commands: {
    key: {
        desc: string;
        method: "keysPress";
        params: (typeof Keystroke)[];
    };
    keydown: {
        desc: string;
        method: "keysDown";
        params: (typeof Keystroke)[];
    };
    keyup: {
        desc: string;
        method: "keysUp";
        params: (typeof Keystroke)[];
    };
    type: {
        desc: string;
        method: "type";
        params: StringConstructor[];
    };
    move: {
        desc: string;
        method: "mouseMove";
        params: (typeof UnsignedInt)[];
    };
    mousemove: {
        desc: string;
        method: "mouseMove";
        params: (typeof UnsignedInt)[];
    };
    click: {
        desc: string;
        method: "mouseClick";
        params: StringConstructor[];
    };
    doubleclick: {
        desc: string;
        method: "mouseClick";
        params: StringConstructor[];
    };
    mousedown: {
        desc: string;
        method: "mouseButtonDown";
        params: StringConstructor[];
    };
    mouseup: {
        desc: string;
        method: "mouseButtonUp";
        params: StringConstructor[];
    };
    scroll: {
        desc: string;
        method: "scroll";
        params: (typeof SignedInt)[];
    };
    capture: {
        desc: string;
        method: "captureScreenToFile";
        params: StringConstructor[];
    };
    pause: {
        desc: string;
        method: "pause";
        params: (typeof ValidNumber)[];
    };
};
/**
 * Parses the given script into commands that can be interpreted by
 * {@link interpretCommands}.
 *
 * Parsing follows very similar rules to _shell words_:
 *
 * - Each double-quoted substring is interpreted as a single argument.
 * - Backslash (`\`) is interpreted as an escape character. It can be used to
 *   escape double quotes (`"`) and whitespaces. It's always stripped, so
 *   to use a literal backslash, it must be doubled (`\\`).
 * - Everything after `#` to the end of the line is interpreted as a comment and
 *   stripped iif it's not inside a double-quoted substring and it's at the
 *   start of a line or comes after one or more whitespaces.
 *
 * @throws {@link GuacamoleCommandError} on unknown command and invalid arguments.
 */
export declare function parseScript(content: string): Command[];
/**
 * Parses the given list of `words` into commands that can be interpreted by
 * {@link interpretCommands}.
 *
 * @throws {@link GuacamoleCommandError} on unknown command and invalid arguments.
 */
export declare function parseCommands(words: string[]): Command[];
/**
 * Interprets the `commands` list using the given `client`.
 *
 * @see {@link parseCommands}
 * @see {@link parseScript}
 */
export declare function interpretCommands(client: Client, commands: Command[]): Promise<void>;
export { Keystroke as parseCombinedKeys };
/**
 * Splits the given sequence of keys separated by `+` or `-` (whichever is
 * found in the value first).
 */
declare function Keystroke(value: string): string[];
declare function SignedInt(value: string, command: string): number;
declare function UnsignedInt(value: string, command: string): number;
declare function ValidNumber(value: string, command: string): number;
