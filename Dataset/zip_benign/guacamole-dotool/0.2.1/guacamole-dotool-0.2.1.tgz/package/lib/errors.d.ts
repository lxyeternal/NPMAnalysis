import Guacamole from 'guacamole-common-js';
export declare class GuacamoleError extends Error {
}
export declare class GuacamoleProtocolError extends GuacamoleError {
    code: ProtocolErrorCode;
    constructor(status: Guacamole.Status);
}
export type ProtocolErrorCode = Exclude<keyof typeof Guacamole.Status.Code, 'fromHTTPCode' | 'fromWebSocketCode' | 'SUCCESS'> | 'UNKNOWN';
export declare class GuacamoleClientError extends GuacamoleError {
    code: ClientErrorCode;
    constructor(code: ClientErrorCode, message: string, opts?: ErrorOptions);
}
export type ClientErrorCode = 'CANVAS_NOT_INITIALIZED' | 'NOT_CONNECTED' | 'UNKNOWN_KEY';
export declare class GuacamoleCommandError extends GuacamoleError {
    code: CommandErrorCode;
    command: string;
    constructor(code: CommandErrorCode, command: string, message?: string, opts?: ErrorOptions);
}
export type CommandErrorCode = 'UNKNOWN' | 'INVALID_ARGUMENT';
