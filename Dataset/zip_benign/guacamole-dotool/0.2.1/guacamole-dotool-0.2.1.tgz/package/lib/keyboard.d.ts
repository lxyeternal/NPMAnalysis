import { Keymap } from './keymaps.js';
export interface KeyboardMapper<TKeymap extends Keymap> {
    readonly keymap: TKeymap;
    /**
     * Searches case-insensitive for the given `key` in the `keymap`'s `control`,
     * `modifiers`, and `printable` tables and returns its keysym code, or throws
     * error if not found.
     *
     * @throws {GuacamoleClientError} if the `key` was not found in the `keymap`.
     */
    translateKey(key: string): number;
    /**
     * Searches for the given `char` in the `keymap`'s `printable` and `combined`
     * tables and returns its keysym code sequence. If not found and
     * `keysym.allowFallback` is `true`, it returns the codepoint-based keysym
     * code of the character. If it's `false`, it throws an error.
     *
     * @throws {GuacamoleClientError} if the `char` was not found in the `keymap`.
     */
    translateChar(char: string): readonly number[];
}
export declare function KeyboardMapper<TKeymap extends Keymap>(keymap: TKeymap): KeyboardMapper<TKeymap>;
