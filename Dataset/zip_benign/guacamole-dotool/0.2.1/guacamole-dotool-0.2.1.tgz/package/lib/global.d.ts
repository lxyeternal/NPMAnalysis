/**
 * Sets `canvas`, `jsdom`, and `ws` to the `global` context - `window`,
 * `document`, `Image` and `WebSocket`. These are required by the
 * `guacamole-common-js` library.
 */
export declare function setDomGlobals(aGlobal?: typeof globalThis): void;
