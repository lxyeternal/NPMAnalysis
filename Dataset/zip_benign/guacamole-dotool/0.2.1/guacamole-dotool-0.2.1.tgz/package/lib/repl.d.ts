import { Client } from './client.js';
export declare function startRepl(client: Client, interactive: boolean): Promise<void>;
