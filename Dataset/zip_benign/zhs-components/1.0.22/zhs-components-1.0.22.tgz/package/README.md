# 智慧树定制化部门前端公用库

## 组件安装

```
npm install zhs-components --save
```

## 组件使用

### 主文件导入

```
import { Empty } from "zhs-components";
```

### 组件导入

```
import { Empty } from "zhs-components/components";
```

## 方法使用

### 主文件导入

```
import { getFileType } from "zhs-components";
```

### 方法导入

```
import { getFileType } from "zhs-components/utils";
```

## 组件详情

### 动态数字

* 导入

```
import { DynamicNumber } from "zhs-components";
```

* Attribute

|  字段   | 描述  | 默认值 |
|  ----  | ----  |----|
| start  | 起始数字 | 0|
| end  | 结束数字 |0|
| time  | 过渡时间，以秒为单位 | 0.5|

### 空状态

* 导入

```
import { Empty } from "zhs-components";
```

* 使用
1. 默认

```
<Empty />;
```

2. 暂无人员

```
<Empty type="people"/>;
```

3. 暂无消息

```
<Empty type="message"/>;
```

4. 自定义文案

```
<Empty type="message" text="我是有底线的~"/>;
```

* Attribute

|  字段   | 描述  | 默认 |
|  ----  | ----  | ----|
| type  | 空状态的类型，有 `course` 、 `people` 、 `messag` 三种状态 | `course` |
| text  | 暂无数据的文案 | `course` 时为“暂无课程”， `people` 时为“暂无人员”， `message` 时为“暂无消息”|

### 文件类型Icon

* 导入

```
import { FileIcon } from "zhs-components";
```

* 使用
1. word（`doc`、 `docx`）

```
<FileIcon suffix="xxx.doc" />;
```

2. excel（`xls`、 `xlsx`）

```
<FileIcon suffix="xxx.xls" />
```

3. ppt（`ppt`、 `pptx`）

```
<FileIcon suffix="xxx.ppt" />;
```

4. 文本（`txt`）

```
<FileIcon suffix="xxx.txt" />;
```

5. pdf（`pdf`）

```
<FileIcon suffix="xxx.pdf" />;

```

6. 压缩包（`rar`、 `zip`）

```
<FileIcon suffix="xxx.zip" />;
```

7. 图片（`gif`、 `jpg`、 `jpeg`、 `png`、 `bmp`）

```
<FileIcon suffix="xxx.jpg" />;
```

8. 视频（`asf`、 `avi`、 `flv`、 `m4v`、 `mov`、 `mp4`、 `rmvb`、 `wmv`、 `mkv`、 `mpeg`、 `rm`、 `mpg`）

```
<FileIcon suffix="xxx.mp4" />;
```

9. 音乐（`mp3`）

```
<FileIcon suffix="xxx.mp3" />;
```

10. 默认（其他类型）

```
<FileIcon suffix="xxx.json" />;
```

* Attribute

|  字段   | 描述  | 默认 |
|  ----  | ----  | ----|
| suffix  | 文件名称或路径 | - |