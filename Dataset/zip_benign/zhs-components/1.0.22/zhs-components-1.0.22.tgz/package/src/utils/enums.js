export const FILE_TYPE_LIST = {
    'word': ['doc', 'docx'],
    'excel': ['xls', 'xlsx'],
    'ppt': ['ppt', 'pptx'],
    'txt': ['txt'],
    'pdf': ['pdf'],
    'zip': ['rar', 'zip'],
    'image': ['gif', 'jpg', 'jpeg', 'png', 'bmp'],
    'video': ['asf', 'avi', 'flv', 'm4v', 'mov', 'mp4', 'rmvb', 'wmv', 'mkv', 'mpeg', 'rm', 'mpg'],
    'music': ['mp3'],
    'other':[]
};