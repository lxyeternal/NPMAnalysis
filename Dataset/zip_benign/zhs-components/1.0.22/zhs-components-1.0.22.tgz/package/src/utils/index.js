import { FILE_TYPE_LIST } from './enums';
// 根据文件后缀，判断文件类型
export function getFileType(suffix) {
    if (suffix != null) {
        suffix = suffix.toLowerCase();
    }
    for (const key in FILE_TYPE_LIST) {
        const type = FILE_TYPE_LIST[key];
        if (type.includes(suffix)) return key;
    }
    return 'other';
}


export function htmlToText(text) {
    return text.replace(/[<>"&]/g, function (match, pos, originalText) {
        switch (match) {
            case "<": return "&lt;";
            case ">": return "&gt;";
            case "&": return "&amp;";
            case "\"": return "&quot;";
        }
    });
}

// 过滤html标签，获取纯文本
export function getContentText(content) {
    if (!content) return '';
    let output = content.replace(/(\n)/g, "").replace(/(\t)/g, "").replace(/(\r)/g, "").replace(/<\/?[^>]*>/g, "").replace(/\s*/g, "").replace(/&nbsp;/g, " ");
    let temp = document.createElement("div");

    temp.innerHTML = output;
    output = temp.innerText || temp.textContent;
    temp = null;
    return output;
}