
import _Empty from "./components/Empty.vue";
import _FileIcon from "./components/FileIcon.vue";
import _DynamicNumber from "./components/DynamicNumber.vue";
import _WaveBackground from "./components/WaveBackground.vue"

export * from "./utils";

// export const version = VERSION;
export const Empty = _Empty;
export const FileIcon = _FileIcon;
export const DynamicNumber = _DynamicNumber;
export const WaveBackground = _WaveBackground;



export default {
    // version: VERSION,
    Empty: _Empty,
    FileIcon: _FileIcon,
    DynamicNumber: _DynamicNumber,
    WaveBackground: _WaveBackground
}

