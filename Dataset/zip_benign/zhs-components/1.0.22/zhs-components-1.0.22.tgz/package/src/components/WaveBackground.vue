<template>
  <div class="zhs-wave-container">
    <slot></slot>
    <div class="zhs-wave">
      <div
        v-for="i in 5"
        :key="i"
        :style="{ '--color': color, '--min': min }"
        class="circle"
      ></div>
    </div>
  </div>
</template>
<script>
import { defineComponent } from "vue";
export default defineComponent({
  props: {
    min: { type: String, default: "140px" },
    color: { type: String, default: "#f3d2d5" },
  },
});
</script>
<style lang="scss">
$min: v-bind(min);
$color: v-bind(color);
.zhs-wave-container {
  position: relative;
  overflow: hidden;
}

.zhs-wave {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 100%;
  height: 0;
  padding-bottom: 100%;
}

.zhs-wave .circle {
  opacity: 0;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 100%;
  height: 0;
  position: absolute;
  border-radius: 50%;
  padding-bottom: 100%;
  animation: circle-opacity 6s infinite;
}

.zhs-wave .circle:nth-child(2) {
  animation-delay: 0.8s;
}

.zhs-wave .circle:nth-child(3) {
  animation-delay: 1.6s;
}

.zhs-wave .circle:nth-child(4) {
  animation-delay: 2.4s;
}

.zhs-wave .circle:nth-child(5) {
  animation-delay: 3.2s;
}

.zhs-wave .circle {
  border: solid 1px var(--color);
}

@keyframes circle-opacity {
  from {
    opacity: 1;
    width: var(--min);
    padding-bottom: var(--min);
  }

  to {
    opacity: 0;
    width: 100%;
    padding-bottom: 100%;
  }
}
</style>