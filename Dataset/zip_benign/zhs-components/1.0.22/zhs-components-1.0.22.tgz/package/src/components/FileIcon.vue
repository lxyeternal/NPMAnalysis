<template>
  <div class="zhs-file-icon">
    <img :src="require(`../assets/images/types_icon/icon-${type}.png`)" alt="" />
  </div>
</template>
<script>
import { getFileType } from "./../utils";
import { defineComponent, ref } from "vue";
export default defineComponent({
  props: { suffix: { type: String, default: "other" } },
  setup(props) {
    const type = ref(getFileType(props.suffix));
    return { type };
    // console.log(require(`assets/images/types_icon/icon-${props.suffix}.png`));
  },
});
</script>
<style lang="scss">
$width: 40px;
.zhs-file-icon {
  display: inline-block;
  width: $width;
  height: $width;
  img {
    height: 100%;
  }
}
</style>