<template>
  <span style="margin-right: 50px">{{ num }}</span>
</template>
<script>
export default {
  props: {
    start: Number, //动画开始数字
    end: Number, //动画结束数字
    //动画持续时间，默认0.5s
    time: {
      type: Number,
      default: 0.5,
    },
  },
  data() {
    return {
      num: this.start,
      originNum: this.start,
      timer: null,
    };
  },
  methods: {
    addFunc(start) {
      start = start || new Date().getTime();
      this.timer = requestAnimationFrame(this.addFunc);
      cancelAnimationFrame(this.timer);
      if (this.num > this.end) {
        this.num = Math.max(this.end, this.num - this.count);
        this.timer = requestAnimationFrame(this.addFunc);
      } else if (this.num < this.end) {
        this.num = Math.min(this.end, this.num + this.count);
        this.timer = requestAnimationFrame(this.addFunc);
      } else {
        this.originNum = this.num;
      }
    },
  },
  watch: {
    start: {
      handler() {
        this.timer && cancelAnimationFrame(this.timer);
        this.num = this.start;
        this.originNum = this.start;
        this.addFunc();
      },
      immediate: true,
    },
    end: {
      handler() {
        this.timer && cancelAnimationFrame(this.timer);
        this.addFunc();
      },
      immediate: true,
    },
  },
  computed: {
    count() {
      let total = 60 * this.time;
      return Math.ceil(Math.abs(this.end - this.originNum) / total);
    },
  },
};
</script>