<template>
  <div class="zhs-no-data">
    <img :src="imgList[type]['img']" />
    <p class="label">{{ text || imgList[type]["text"] }}</p>
  </div>
</template>
<script>
export default {
  props: {
    type: {
      type: String,
      default: "course",
    },
    text: {
      type: String,
    },
  },
  data() {
    return {
      imgList: {
        course: {
          img: require("../assets/images/common/no_course.png"),
          text: "暂无课程",
        },
        message: {
          img: require("../assets/images/common/no_message.png"),
          text: "暂无消息",
        },
        people: {
          img: require("../assets/images/common/no_person.png"),
          text: "暂无人员",
        },
      },
    };
  },
};
</script>
<style lang="scss">
.zhs-no-data {
  height: 100%;
  width: 100%;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  img {
    height: 80px;
  }
  .label {
    color: #aaa;
    font-size: 16px;
    margin-top: 12px;
  }
}
</style>