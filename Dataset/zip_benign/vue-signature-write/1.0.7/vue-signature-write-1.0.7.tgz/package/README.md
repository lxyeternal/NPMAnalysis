# vue-signature-write

>基于canvas的签名插件

# Usage
```
npm install vue-signature-write
```
```
import  vueSignatureWrite from "vue-signature-write"
Vue.use(vueSignatureWrite)
```
```
<vueSignatureWrite />
```
# API
---
#### Props

|      name     |     type      |           default         |       description           |
|:-------------:|:-------------:|:-------------------------:|:---------------------------:|
|     bgcolor   |   `String`    |  "rgba(220,220,220,0.6)"  |   签名区背景颜色,支持rgba     |
|    lineColor  |   `String`    |          "#000"           |        线条颜色              |
|    lineWidth  |   `Number`    |           0.5             |        线条粗细              |

#### Methods

|          name              |        params         |       description       |
|:--------------------------:|:---------------------:|:-----------------------:|
|        clear( )            |          -            |        清空签名          |
|        reCall( )           |          -            |        撤回到上一步      |
|   downloadSignature(name)  |         name          | 下载签名,name为图片名称,默认值为"签名",非必填参数 |
|     getFile(filename)      |       filename        | filename为文件名,返回值为签名的File文件,非必填参数|


