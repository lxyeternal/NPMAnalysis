import { __awaiter, __generator } from 'tslib';
import { Component, Input, Inject, PLATFORM_ID, EventEmitter, Output, NgModule } from '@angular/core';
import { toDataURL } from 'qrcode';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var NgxQrcodeComponent = /** @class */ (function () {
    function NgxQrcodeComponent(platformId, sanitizer) {
        this.platformId = platformId;
        this.sanitizer = sanitizer;
        this.messageEvent = new EventEmitter();
        this.defaultOptions = {
            errorCorrectionLevel: 'H',
            // L, M, Q, H
            type: 'image/jpeg',
            rendererOpts: {
                quality: 0.3,
                margin: 4,
                scale: 4
            },
            color: {
                dark: '#000000ff',
                // Blue dots
                light: '#fff' // Transparent background
            },
            width: 300
        };
        this.isBrowser = isPlatformBrowser(platformId);
    }
    /**
     * @return {?}
     */
    NgxQrcodeComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @param {?} changes
     * @return {?}
     */
    NgxQrcodeComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if (this.isBrowser) {
            var /** @type {?} */ qrData = changes['text'];
            var /** @type {?} */ width = changes['width'];
            var /** @type {?} */ darkColor = changes['darkColor'];
            var /** @type {?} */ lightColor = changes['lightColor'];
            var /** @type {?} */ type = changes['type'];
            var /** @type {?} */ scale = changes['scale'];
            var /** @type {?} */ margin = changes['margin'];
            var /** @type {?} */ quality = changes['quality'];
            var /** @type {?} */ errorCorrectionLevel = changes['errorCorrectionLevel'];
            this.text = qrData ? qrData.currentValue : this.text;
            this.width = width ? width.currentValue : this.width;
            this.darkColor = darkColor ? darkColor.currentValue : this.darkColor;
            this.lightColor = lightColor ? lightColor.currentValue : this.lightColor;
            this.type = type ? type.currentValue : this.type;
            this.scale = scale ? scale.currentValue : this.scale;
            this.margin = margin ? margin.currentValue : this.margin;
            this.quality = quality ? quality.currentValue : this.quality;
            this.errorCorrectionLevel = errorCorrectionLevel ? errorCorrectionLevel.currentValue : this.lightColor;
            this.generateQRCode(this.text);
        }
    };
    /**
     * @param {?} text
     * @return {?}
     */
    NgxQrcodeComponent.prototype.generateQRCode = /**
     * @param {?} text
     * @return {?}
     */
    function (text) {
        return __awaiter(this, void 0, void 0, function () {
            var _a, err_1;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        _b.trys.push([0, 2, , 3]);
                        if (!this.isValidQRCodeText(text)) {
                            throw new Error('Empty QR Code data');
                        }
                        _a = this;
                        return [4 /*yield*/, toDataURL(text, this.getOptions())];
                    case 1:
                        _a.imageURL = _b.sent();
                        this.sendMessage(text, this.imageURL);
                        return [3 /*break*/, 3];
                    case 2:
                        err_1 = _b.sent();
                        console.error('Error Creating QRCode Image', err_1.message);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * @param {?} data
     * @return {?}
     */
    NgxQrcodeComponent.prototype.isValidQRCodeText = /**
     * @param {?} data
     * @return {?}
     */
    function (data) {
        return !(typeof data === 'undefined' || data === null || data === '');
    };
    /**
     * @return {?}
     */
    NgxQrcodeComponent.prototype.getOptions = /**
     * @return {?}
     */
    function () {
        if (typeof this.options === 'undefined') {
            this.qrcodeOpt = this.defaultOptions;
            this.qrcodeOpt.errorCorrectionLevel = this.errorCorrectionLevel ?
                this.errorCorrectionLevel : this.defaultOptions.errorCorrectionLevel;
            this.qrcodeOpt.type = this.type ? this.type : this.defaultOptions.type;
            this.qrcodeOpt.rendererOpts.margin = this.margin ? this.margin : this.defaultOptions.rendererOpts.margin;
            this.qrcodeOpt.rendererOpts.quality = this.quality ? this.quality : this.defaultOptions.rendererOpts.quality;
            this.qrcodeOpt.rendererOpts.scale = this.scale ? this.scale : this.defaultOptions.rendererOpts.scale;
            this.qrcodeOpt.color.dark = this.darkColor ? this.darkColor : this.defaultOptions.color.dark;
            this.qrcodeOpt.color.light = this.lightColor ? this.lightColor : this.defaultOptions.color.light;
            this.qrcodeOpt.width = this.width ? this.width : this.defaultOptions.width;
        }
        else {
            this.qrcodeOpt = this.defaultOptions;
            if (this.options.errorCorrectionLevel) {
                this.qrcodeOpt.errorCorrectionLevel = this.options.errorCorrectionLevel;
            }
            if (this.options.type) {
                this.qrcodeOpt.type = this.options.type;
            }
            if (this.options.quality) {
                this.qrcodeOpt.rendererOpts.quality = this.options.quality;
            }
            if (this.options.margin) {
                this.qrcodeOpt.rendererOpts.margin = this.options.margin;
            }
            if (this.options.scale) {
                this.qrcodeOpt.rendererOpts.scale = this.options.scale;
            }
            if (this.options.darkColor) {
                this.qrcodeOpt.color.dark = this.options.darkColor;
            }
            if (this.options.lightColor) {
                this.qrcodeOpt.color.light = this.options.lightColor;
            }
            if (this.options.width) {
                this.qrcodeOpt.width = this.options.width;
            }
        }
        return this.qrcodeOpt;
    };
    /**
     * @param {?} text
     * @param {?} imageURL
     * @return {?}
     */
    NgxQrcodeComponent.prototype.sendMessage = /**
     * @param {?} text
     * @param {?} imageURL
     * @return {?}
     */
    function (text, imageURL) {
        var /** @type {?} */ obj = { text: text, imageData: imageURL };
        this.messageEvent.emit(obj);
    };
    NgxQrcodeComponent.decorators = [
        { type: Component, args: [{
                    selector: 'scl-ngx-qrcode',
                    template: "<img *ngIf=\"imageURL\" [src]=\"sanitizer.bypassSecurityTrustUrl(imageURL)\"  />\n",
                    styles: [""]
                },] },
    ];
    /** @nocollapse */
    NgxQrcodeComponent.ctorParameters = function () { return [
        { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] },
        { type: DomSanitizer }
    ]; };
    NgxQrcodeComponent.propDecorators = {
        messageEvent: [{ type: Output }],
        options: [{ type: Input }],
        text: [{ type: Input }],
        errorCorrectionLevel: [{ type: Input }],
        type: [{ type: Input }],
        quality: [{ type: Input }],
        margin: [{ type: Input }],
        scale: [{ type: Input }],
        darkColor: [{ type: Input }],
        lightColor: [{ type: Input }],
        width: [{ type: Input }],
        outputType: [{ type: Input }]
    };
    return NgxQrcodeComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var NgxQrcodeModule = /** @class */ (function () {
    function NgxQrcodeModule() {
    }
    NgxQrcodeModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule
                    ],
                    declarations: [NgxQrcodeComponent],
                    exports: [NgxQrcodeComponent]
                },] },
    ];
    return NgxQrcodeModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

export { NgxQrcodeComponent, NgxQrcodeModule };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic21hcnRjb2RlbGFiLW5neC1xcmNvZGUuanMubWFwIiwic291cmNlcyI6WyJuZzovL0BzbWFydGNvZGVsYWIvbmd4LXFyY29kZS9saWIvbmd4LXFyY29kZS5jb21wb25lbnQudHMiLCJuZzovL0BzbWFydGNvZGVsYWIvbmd4LXFyY29kZS9saWIvbmd4LXFyY29kZS5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgRWxlbWVudFJlZixcbiAgSW5wdXQsXG4gIE9uQ2hhbmdlcyxcbiAgT25Jbml0LFxuICBTaW1wbGVDaGFuZ2UsXG4gIEluamVjdCxcbiAgUExBVEZPUk1fSUQsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFZpZXdDaGlsZCxcbiAgRXZlbnRFbWl0dGVyLFxuICBPdXRwdXRcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgKiBhcyBRUkNvZGUgZnJvbSAncXJjb2RlJztcbmltcG9ydCB7IGlzUGxhdGZvcm1Ccm93c2VyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IERvbVNhbml0aXplciB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdzY2wtbmd4LXFyY29kZScsXG4gIHRlbXBsYXRlOiBgPGltZyAqbmdJZj1cImltYWdlVVJMXCIgW3NyY109XCJzYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdFVybChpbWFnZVVSTClcIiAgLz5cbmAsXG4gIHN0eWxlczogW2BgXVxufSlcblxuZXhwb3J0IGNsYXNzIE5neFFyY29kZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcbiAgcHVibGljIGltYWdlVVJMOiBzdHJpbmc7XG4gIGlzQnJvd3NlcjogYm9vbGVhbjtcbiAgcHVibGljIHFyY29kZU9wdDogUVJDb2RlT3B0aW9ucztcbiAgQE91dHB1dCgpIG1lc3NhZ2VFdmVudCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBASW5wdXQoKSBwdWJsaWMgb3B0aW9uczogUXJjb2RlT3B0aW9uVXNlclRlbXBsYXRlO1xuICBASW5wdXQoKSBwdWJsaWMgdGV4dDogc3RyaW5nO1xuICBASW5wdXQoKSBwdWJsaWMgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IHN0cmluZztcbiAgQElucHV0KCkgcHVibGljIHR5cGU6IHN0cmluZztcbiAgQElucHV0KCkgcHVibGljIHF1YWxpdHk6IG51bWJlcjtcbiAgQElucHV0KCkgcHVibGljIG1hcmdpbjogbnVtYmVyO1xuICBASW5wdXQoKSBwdWJsaWMgc2NhbGU6IG51bWJlcjtcbiAgQElucHV0KCkgcHVibGljIGRhcmtDb2xvcjogc3RyaW5nO1xuICBASW5wdXQoKSBwdWJsaWMgbGlnaHRDb2xvcjogc3RyaW5nO1xuICBASW5wdXQoKSBwdWJsaWMgd2lkdGg6IG51bWJlcjtcbiAgQElucHV0KCkgcHVibGljIG91dHB1dFR5cGU6IHN0cmluZztcblxuICBkZWZhdWx0T3B0aW9uczogUVJDb2RlT3B0aW9ucyA9IHtcbiAgICBlcnJvckNvcnJlY3Rpb25MZXZlbDogJ0gnLCAvLyBMLCBNLCBRLCBIXG4gICAgdHlwZTogJ2ltYWdlL2pwZWcnLFxuICAgIHJlbmRlcmVyT3B0czoge1xuICAgICAgcXVhbGl0eTogMC4zLFxuICAgICAgbWFyZ2luOiA0LFxuICAgICAgc2NhbGU6IDRcbiAgICB9LFxuICAgIGNvbG9yOiB7XG4gICAgICBkYXJrOiAnIzAwMDAwMGZmJywgIC8vIEJsdWUgZG90c1xuICAgICAgbGlnaHQ6ICcjZmZmJyAvLyBUcmFuc3BhcmVudCBiYWNrZ3JvdW5kXG4gICAgfSxcbiAgICB3aWR0aDogMzAwXG4gIH07XG5cbiAgY29uc3RydWN0b3IoXG4gICAgQEluamVjdChQTEFURk9STV9JRCkgcHJpdmF0ZSBwbGF0Zm9ybUlkOiBPYmplY3QsXG4gICAgcHVibGljIHNhbml0aXplcjogRG9tU2FuaXRpemVyKSB7XG4gICAgdGhpcy5pc0Jyb3dzZXIgPSBpc1BsYXRmb3JtQnJvd3NlcihwbGF0Zm9ybUlkKTtcbiAgfVxuXG4gIG5nT25Jbml0KCkge1xuICB9XG5cbiAgcHVibGljIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICBpZiAodGhpcy5pc0Jyb3dzZXIpIHtcbiAgICAgIGNvbnN0IHFyRGF0YSA9IGNoYW5nZXNbJ3RleHQnXTtcbiAgICAgIGNvbnN0IHdpZHRoICA9IGNoYW5nZXNbJ3dpZHRoJ107XG4gICAgICBjb25zdCBkYXJrQ29sb3IgID0gY2hhbmdlc1snZGFya0NvbG9yJ107XG4gICAgICBjb25zdCBsaWdodENvbG9yICA9IGNoYW5nZXNbJ2xpZ2h0Q29sb3InXTtcbiAgICAgIGNvbnN0IHR5cGUgID0gY2hhbmdlc1sndHlwZSddO1xuICAgICAgY29uc3Qgc2NhbGUgID0gY2hhbmdlc1snc2NhbGUnXTtcbiAgICAgIGNvbnN0IG1hcmdpbiAgPSBjaGFuZ2VzWydtYXJnaW4nXTtcbiAgICAgIGNvbnN0IHF1YWxpdHkgID0gY2hhbmdlc1sncXVhbGl0eSddO1xuICAgICAgY29uc3QgZXJyb3JDb3JyZWN0aW9uTGV2ZWwgID0gY2hhbmdlc1snZXJyb3JDb3JyZWN0aW9uTGV2ZWwnXTtcbiAgICAgIHRoaXMudGV4dCA9IHFyRGF0YSA/IHFyRGF0YS5jdXJyZW50VmFsdWUgOiB0aGlzLnRleHQ7XG5cbiAgICAgIHRoaXMud2lkdGggPSB3aWR0aCA/IHdpZHRoLmN1cnJlbnRWYWx1ZSA6IHRoaXMud2lkdGg7XG4gICAgICB0aGlzLmRhcmtDb2xvciA9IGRhcmtDb2xvciA/IGRhcmtDb2xvci5jdXJyZW50VmFsdWUgOiB0aGlzLmRhcmtDb2xvcjtcbiAgICAgIHRoaXMubGlnaHRDb2xvciA9IGxpZ2h0Q29sb3IgPyBsaWdodENvbG9yLmN1cnJlbnRWYWx1ZSA6IHRoaXMubGlnaHRDb2xvcjtcbiAgICAgIHRoaXMudHlwZSA9IHR5cGUgPyB0eXBlLmN1cnJlbnRWYWx1ZSA6IHRoaXMudHlwZTtcbiAgICAgIHRoaXMuc2NhbGUgPSBzY2FsZSA/IHNjYWxlLmN1cnJlbnRWYWx1ZSA6IHRoaXMuc2NhbGU7XG4gICAgICB0aGlzLm1hcmdpbiA9IG1hcmdpbiA/IG1hcmdpbi5jdXJyZW50VmFsdWUgOiB0aGlzLm1hcmdpbjtcbiAgICAgIHRoaXMucXVhbGl0eSA9IHF1YWxpdHkgPyBxdWFsaXR5LmN1cnJlbnRWYWx1ZSA6IHRoaXMucXVhbGl0eTtcbiAgICAgIHRoaXMuZXJyb3JDb3JyZWN0aW9uTGV2ZWwgPSBlcnJvckNvcnJlY3Rpb25MZXZlbCA/IGVycm9yQ29ycmVjdGlvbkxldmVsLmN1cnJlbnRWYWx1ZSA6IHRoaXMubGlnaHRDb2xvcjtcbiAgICAgIHRoaXMuZ2VuZXJhdGVRUkNvZGUodGhpcy50ZXh0KTtcblxuICAgIH1cbiAgfVxuICBhc3luYyBnZW5lcmF0ZVFSQ29kZSh0ZXh0OiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgaWYgKCF0aGlzLmlzVmFsaWRRUkNvZGVUZXh0KHRleHQpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignRW1wdHkgUVIgQ29kZSBkYXRhJyk7XG4gICAgICB9XG4gICAgICB0aGlzLmltYWdlVVJMID0gYXdhaXQgUVJDb2RlLnRvRGF0YVVSTCh0ZXh0LCB0aGlzLmdldE9wdGlvbnMoKSk7XG4gICAgICB0aGlzLnNlbmRNZXNzYWdlKHRleHQsIHRoaXMuaW1hZ2VVUkwpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgQ3JlYXRpbmcgUVJDb2RlIEltYWdlJywgZXJyLm1lc3NhZ2UpO1xuICAgIH1cbiAgfVxuXG4gIGlzVmFsaWRRUkNvZGVUZXh0KGRhdGE6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAhKHR5cGVvZiBkYXRhID09PSAndW5kZWZpbmVkJyB8fCBkYXRhID09PSBudWxsIHx8IGRhdGEgPT09ICcnKTtcbiAgfVxuXG4gIGdldE9wdGlvbnMoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLm9wdGlvbnMgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICB0aGlzLnFyY29kZU9wdCA9IHRoaXMuZGVmYXVsdE9wdGlvbnM7XG4gICAgICB0aGlzLnFyY29kZU9wdC5lcnJvckNvcnJlY3Rpb25MZXZlbCA9IHRoaXMuZXJyb3JDb3JyZWN0aW9uTGV2ZWwgP1xuICAgICAgdGhpcy5lcnJvckNvcnJlY3Rpb25MZXZlbCA6IHRoaXMuZGVmYXVsdE9wdGlvbnMuZXJyb3JDb3JyZWN0aW9uTGV2ZWw7XG4gICAgICB0aGlzLnFyY29kZU9wdC50eXBlID0gdGhpcy50eXBlID8gdGhpcy50eXBlIDogdGhpcy5kZWZhdWx0T3B0aW9ucy50eXBlO1xuICAgICAgdGhpcy5xcmNvZGVPcHQucmVuZGVyZXJPcHRzLm1hcmdpbiA9IHRoaXMubWFyZ2luID8gdGhpcy5tYXJnaW4gOiB0aGlzLmRlZmF1bHRPcHRpb25zLnJlbmRlcmVyT3B0cy5tYXJnaW47XG4gICAgICB0aGlzLnFyY29kZU9wdC5yZW5kZXJlck9wdHMucXVhbGl0eSA9IHRoaXMucXVhbGl0eSA/IHRoaXMucXVhbGl0eSA6IHRoaXMuZGVmYXVsdE9wdGlvbnMucmVuZGVyZXJPcHRzLnF1YWxpdHk7XG4gICAgICB0aGlzLnFyY29kZU9wdC5yZW5kZXJlck9wdHMuc2NhbGUgPSB0aGlzLnNjYWxlID8gdGhpcy5zY2FsZSA6IHRoaXMuZGVmYXVsdE9wdGlvbnMucmVuZGVyZXJPcHRzLnNjYWxlO1xuICAgICAgdGhpcy5xcmNvZGVPcHQuY29sb3IuZGFyayA9IHRoaXMuZGFya0NvbG9yID8gdGhpcy5kYXJrQ29sb3IgOiB0aGlzLmRlZmF1bHRPcHRpb25zLmNvbG9yLmRhcms7XG4gICAgICB0aGlzLnFyY29kZU9wdC5jb2xvci5saWdodCA9IHRoaXMubGlnaHRDb2xvciA/IHRoaXMubGlnaHRDb2xvciA6IHRoaXMuZGVmYXVsdE9wdGlvbnMuY29sb3IubGlnaHQ7XG4gICAgICB0aGlzLnFyY29kZU9wdC53aWR0aCA9IHRoaXMud2lkdGggPyB0aGlzLndpZHRoIDogdGhpcy5kZWZhdWx0T3B0aW9ucy53aWR0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5xcmNvZGVPcHQgPSB0aGlzLmRlZmF1bHRPcHRpb25zO1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5lcnJvckNvcnJlY3Rpb25MZXZlbCkge1xuICAgICAgICB0aGlzLnFyY29kZU9wdC5lcnJvckNvcnJlY3Rpb25MZXZlbCA9IHRoaXMub3B0aW9ucy5lcnJvckNvcnJlY3Rpb25MZXZlbDtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMudHlwZSkge1xuICAgICAgICB0aGlzLnFyY29kZU9wdC50eXBlID0gdGhpcy5vcHRpb25zLnR5cGU7XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMucXVhbGl0eSkge1xuICAgICAgICB0aGlzLnFyY29kZU9wdC5yZW5kZXJlck9wdHMucXVhbGl0eSA9IHRoaXMub3B0aW9ucy5xdWFsaXR5O1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMub3B0aW9ucy5tYXJnaW4pIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQucmVuZGVyZXJPcHRzLm1hcmdpbiA9IHRoaXMub3B0aW9ucy5tYXJnaW47XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuc2NhbGUpIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQucmVuZGVyZXJPcHRzLnNjYWxlID0gdGhpcy5vcHRpb25zLnNjYWxlO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMub3B0aW9ucy5kYXJrQ29sb3IpIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQuY29sb3IuZGFyayA9IHRoaXMub3B0aW9ucy5kYXJrQ29sb3I7XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMubGlnaHRDb2xvcikge1xuICAgICAgICB0aGlzLnFyY29kZU9wdC5jb2xvci5saWdodCA9IHRoaXMub3B0aW9ucy5saWdodENvbG9yO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5vcHRpb25zLndpZHRoKSB7XG4gICAgICAgIHRoaXMucXJjb2RlT3B0LndpZHRoID0gdGhpcy5vcHRpb25zLndpZHRoO1xuICAgICAgfVxuXG4gICAgfVxuICAgIHJldHVybiB0aGlzLnFyY29kZU9wdDtcbiAgfVxuXG4gIHNlbmRNZXNzYWdlKHRleHQsIGltYWdlVVJMKSB7XG4gICAgY29uc3Qgb2JqID0geyB0ZXh0OiB0ZXh0ICwgaW1hZ2VEYXRhOiBpbWFnZVVSTCB9O1xuICAgIHRoaXMubWVzc2FnZUV2ZW50LmVtaXQob2JqKTtcbiAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFFSQ29kZU9wdGlvbnMge1xuICBlcnJvckNvcnJlY3Rpb25MZXZlbDogU3RyaW5nO1xuICB0eXBlOiBTdHJpbmc7XG4gIHJlbmRlcmVyT3B0czoge1xuICAgIHF1YWxpdHk6IE51bWJlcixcbiAgICBtYXJnaW46IE51bWJlcixcbiAgICBzY2FsZTogTnVtYmVyXG4gIH07XG4gIGNvbG9yOiB7XG4gICAgZGFyazogU3RyaW5nLFxuICAgIGxpZ2h0OiBTdHJpbmdcbiAgfTtcbiAgd2lkdGg6IE51bWJlcjtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUXJjb2RlT3B0aW9uVXNlclRlbXBsYXRlIHtcbiAgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IFN0cmluZztcbiAgdHlwZTogU3RyaW5nO1xuICBxdWFsaXR5OiBOdW1iZXI7XG4gIG1hcmdpbjogTnVtYmVyO1xuICBzY2FsZTogTnVtYmVyO1xuICBkYXJrQ29sb3I6IFN0cmluZztcbiAgbGlnaHRDb2xvcjogU3RyaW5nO1xuICB3aWR0aDogTnVtYmVyO1xufVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5neFFyY29kZUNvbXBvbmVudCB9IGZyb20gJy4vbmd4LXFyY29kZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW1xuICAgIENvbW1vbk1vZHVsZVxuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtOZ3hRcmNvZGVDb21wb25lbnRdLFxuICBleHBvcnRzOiBbTmd4UXJjb2RlQ29tcG9uZW50XVxufSlcbmV4cG9ydCBjbGFzcyBOZ3hRcmNvZGVNb2R1bGUgeyB9XG4iXSwibmFtZXMiOlsiUVJDb2RlLnRvRGF0YVVSTCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7SUEyREUsNEJBQytCLFVBQWtCLEVBQ3hDO1FBRHNCLGVBQVUsR0FBVixVQUFVLENBQVE7UUFDeEMsY0FBUyxHQUFULFNBQVM7NEJBL0JPLElBQUksWUFBWSxFQUFFOzhCQWNYO1lBQzlCLG9CQUFvQixFQUFFLEdBQUc7O1lBQ3pCLElBQUksRUFBRSxZQUFZO1lBQ2xCLFlBQVksRUFBRTtnQkFDWixPQUFPLEVBQUUsR0FBRztnQkFDWixNQUFNLEVBQUUsQ0FBQztnQkFDVCxLQUFLLEVBQUUsQ0FBQzthQUNUO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxXQUFXOztnQkFDakIsS0FBSyxFQUFFLE1BQU07YUFDZDtZQUNELEtBQUssRUFBRSxHQUFHO1NBQ1g7UUFLQyxJQUFJLENBQUMsU0FBUyxHQUFHLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDO0tBQ2hEOzs7O0lBRUQscUNBQVE7OztJQUFSO0tBQ0M7Ozs7O0lBRU0sd0NBQVc7Ozs7Y0FBQyxPQUFzQjtRQUN2QyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbEIscUJBQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMvQixxQkFBTSxLQUFLLEdBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hDLHFCQUFNLFNBQVMsR0FBSSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDeEMscUJBQU0sVUFBVSxHQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUMxQyxxQkFBTSxJQUFJLEdBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzlCLHFCQUFNLEtBQUssR0FBSSxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDaEMscUJBQU0sTUFBTSxHQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNsQyxxQkFBTSxPQUFPLEdBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3BDLHFCQUFNLG9CQUFvQixHQUFJLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQzlELElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUVyRCxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDckQsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ3JFLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUN6RSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDakQsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQ3JELElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUN6RCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sR0FBRyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDN0QsSUFBSSxDQUFDLG9CQUFvQixHQUFHLG9CQUFvQixHQUFHLG9CQUFvQixDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3ZHLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBRWhDOzs7Ozs7SUFFRywyQ0FBYzs7OztJQUFwQixVQUFxQixJQUFZOzs7Ozs7O3dCQUU3QixJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxFQUFFOzRCQUNqQyxNQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7eUJBQ3ZDO3dCQUNELEtBQUEsSUFBSSxDQUFBO3dCQUFZLHFCQUFNQSxTQUFnQixDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsRUFBQTs7d0JBQS9ELEdBQUssUUFBUSxHQUFHLFNBQStDLENBQUM7d0JBQ2hFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzs7Ozt3QkFFdEMsT0FBTyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxLQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7Ozs7OztLQUU3RDs7Ozs7SUFFRCw4Q0FBaUI7Ozs7SUFBakIsVUFBa0IsSUFBWTtRQUM1QixPQUFPLEVBQUUsT0FBTyxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0tBQ3ZFOzs7O0lBRUQsdUNBQVU7OztJQUFWO1FBQ0UsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUNyQyxJQUFJLENBQUMsU0FBUyxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxvQkFBb0I7Z0JBQy9ELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDO1lBQ3JFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQztZQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQztZQUN6RyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQztZQUM3RyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztZQUNyRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztZQUM3RixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUNqRyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7U0FDNUU7YUFBTTtZQUNMLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztZQUNyQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUU7Z0JBQ3JDLElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQzthQUN6RTtZQUNELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO2FBQ3pDO1lBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRTtnQkFDeEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO2FBQzVEO1lBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtnQkFDdkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2FBQzFEO1lBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRTtnQkFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO2FBQ3hEO1lBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTtnQkFDMUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO2FBQ3BEO1lBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtnQkFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO2FBQ3REO1lBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRTtnQkFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7YUFDM0M7U0FFRjtRQUNELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQztLQUN2Qjs7Ozs7O0lBRUQsd0NBQVc7Ozs7O0lBQVgsVUFBWSxJQUFJLEVBQUUsUUFBUTtRQUN4QixxQkFBTSxHQUFHLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFHLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM3Qjs7Z0JBNUlGLFNBQVMsU0FBQztvQkFDVCxRQUFRLEVBQUUsZ0JBQWdCO29CQUMxQixRQUFRLEVBQUUsb0ZBQ1g7b0JBQ0MsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDO2lCQUNiOzs7O2dCQW9DNEMsTUFBTSx1QkFBOUMsTUFBTSxTQUFDLFdBQVc7Z0JBM0NkLFlBQVk7OzsrQkFhbEIsTUFBTTswQkFFTixLQUFLO3VCQUNMLEtBQUs7dUNBQ0wsS0FBSzt1QkFDTCxLQUFLOzBCQUNMLEtBQUs7eUJBQ0wsS0FBSzt3QkFDTCxLQUFLOzRCQUNMLEtBQUs7NkJBQ0wsS0FBSzt3QkFDTCxLQUFLOzZCQUNMLEtBQUs7OzZCQTFDUjs7Ozs7OztBQ0FBOzs7O2dCQUlDLFFBQVEsU0FBQztvQkFDUixPQUFPLEVBQUU7d0JBQ1AsWUFBWTtxQkFDYjtvQkFDRCxZQUFZLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztvQkFDbEMsT0FBTyxFQUFFLENBQUMsa0JBQWtCLENBQUM7aUJBQzlCOzswQkFWRDs7Ozs7Ozs7Ozs7Ozs7OyJ9