export declare class NgxQrcodeModule {
}
