import { OnChanges, OnInit, SimpleChanges, EventEmitter } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
export declare class NgxQrcodeComponent implements OnInit, OnChanges {
    private platformId;
    sanitizer: DomSanitizer;
    imageURL: string;
    isBrowser: boolean;
    qrcodeOpt: QRCodeOptions;
    messageEvent: EventEmitter<{}>;
    options: QrcodeOptionUserTemplate;
    text: string;
    errorCorrectionLevel: string;
    type: string;
    quality: number;
    margin: number;
    scale: number;
    darkColor: string;
    lightColor: string;
    width: number;
    outputType: string;
    defaultOptions: QRCodeOptions;
    constructor(platformId: Object, sanitizer: DomSanitizer);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    generateQRCode(text: string): Promise<void>;
    isValidQRCodeText(data: string): boolean;
    getOptions(): QRCodeOptions;
    sendMessage(text: any, imageURL: any): void;
}
export interface QRCodeOptions {
    errorCorrectionLevel: String;
    type: String;
    rendererOpts: {
        quality: Number;
        margin: Number;
        scale: Number;
    };
    color: {
        dark: String;
        light: String;
    };
    width: Number;
}
export interface QrcodeOptionUserTemplate {
    errorCorrectionLevel: String;
    type: String;
    quality: Number;
    margin: Number;
    scale: Number;
    darkColor: String;
    lightColor: String;
    width: Number;
}
