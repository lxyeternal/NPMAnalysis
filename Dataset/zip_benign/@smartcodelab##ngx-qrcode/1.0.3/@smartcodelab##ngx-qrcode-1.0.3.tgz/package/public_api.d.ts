export * from './lib/ngx-qrcode.component';
export * from './lib/ngx-qrcode.module';
