/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/*
 * Public API Surface of ngx-qrcode
 */
export { NgxQrcodeComponent } from './lib/ngx-qrcode.component';
export { NgxQrcodeModule } from './lib/ngx-qrcode.module';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BzbWFydGNvZGVsYWIvbmd4LXFyY29kZS8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUlBLG1DQUFjLDRCQUE0QixDQUFDO0FBQzNDLGdDQUFjLHlCQUF5QixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBuZ3gtcXJjb2RlXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvbmd4LXFyY29kZS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbmd4LXFyY29kZS5tb2R1bGUnO1xuIl19