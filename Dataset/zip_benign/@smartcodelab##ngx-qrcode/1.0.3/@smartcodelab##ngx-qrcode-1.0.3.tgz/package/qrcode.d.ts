declare module 'qrcode';



