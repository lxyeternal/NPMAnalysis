(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('qrcode'), require('@angular/common'), require('@angular/platform-browser')) :
    typeof define === 'function' && define.amd ? define('@smartcodelab/ngx-qrcode', ['exports', '@angular/core', 'qrcode', '@angular/common', '@angular/platform-browser'], factory) :
    (factory((global.smartcodelab = global.smartcodelab || {}, global.smartcodelab['ngx-qrcode'] = {}),global.ng.core,null,global.ng.common,global.ng.platformBrowser));
}(this, (function (exports,core,QRCode,common,platformBrowser) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    function __awaiter(thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var NgxQrcodeComponent = (function () {
        function NgxQrcodeComponent(platformId, sanitizer) {
            this.platformId = platformId;
            this.sanitizer = sanitizer;
            this.messageEvent = new core.EventEmitter();
            this.defaultOptions = {
                errorCorrectionLevel: 'H',
                // L, M, Q, H
                type: 'image/jpeg',
                rendererOpts: {
                    quality: 0.3,
                    margin: 4,
                    scale: 4
                },
                color: {
                    dark: '#000000ff',
                    // Blue dots
                    light: '#fff' // Transparent background
                },
                width: 300
            };
            this.isBrowser = common.isPlatformBrowser(platformId);
        }
        /**
         * @return {?}
         */
        NgxQrcodeComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @param {?} changes
         * @return {?}
         */
        NgxQrcodeComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
            function (changes) {
                if (this.isBrowser) {
                    var /** @type {?} */ qrData = changes['text'];
                    var /** @type {?} */ width = changes['width'];
                    var /** @type {?} */ darkColor = changes['darkColor'];
                    var /** @type {?} */ lightColor = changes['lightColor'];
                    var /** @type {?} */ type = changes['type'];
                    var /** @type {?} */ scale = changes['scale'];
                    var /** @type {?} */ margin = changes['margin'];
                    var /** @type {?} */ quality = changes['quality'];
                    var /** @type {?} */ errorCorrectionLevel = changes['errorCorrectionLevel'];
                    this.text = qrData ? qrData.currentValue : this.text;
                    this.width = width ? width.currentValue : this.width;
                    this.darkColor = darkColor ? darkColor.currentValue : this.darkColor;
                    this.lightColor = lightColor ? lightColor.currentValue : this.lightColor;
                    this.type = type ? type.currentValue : this.type;
                    this.scale = scale ? scale.currentValue : this.scale;
                    this.margin = margin ? margin.currentValue : this.margin;
                    this.quality = quality ? quality.currentValue : this.quality;
                    this.errorCorrectionLevel = errorCorrectionLevel ? errorCorrectionLevel.currentValue : this.lightColor;
                    this.generateQRCode(this.text);
                }
            };
        /**
         * @param {?} text
         * @return {?}
         */
        NgxQrcodeComponent.prototype.generateQRCode = /**
         * @param {?} text
         * @return {?}
         */
            function (text) {
                return __awaiter(this, void 0, void 0, function () {
                    var _a, err_1;
                    return __generator(this, function (_b) {
                        switch (_b.label) {
                            case 0:
                                _b.trys.push([0, 2, , 3]);
                                if (!this.isValidQRCodeText(text)) {
                                    throw new Error('Empty QR Code data');
                                }
                                _a = this;
                                return [4 /*yield*/, QRCode.toDataURL(text, this.getOptions())];
                            case 1:
                                _a.imageURL = _b.sent();
                                this.sendMessage(text, this.imageURL);
                                return [3 /*break*/, 3];
                            case 2:
                                err_1 = _b.sent();
                                console.error('Error Creating QRCode Image', err_1.message);
                                return [3 /*break*/, 3];
                            case 3: return [2 /*return*/];
                        }
                    });
                });
            };
        /**
         * @param {?} data
         * @return {?}
         */
        NgxQrcodeComponent.prototype.isValidQRCodeText = /**
         * @param {?} data
         * @return {?}
         */
            function (data) {
                return !(typeof data === 'undefined' || data === null || data === '');
            };
        /**
         * @return {?}
         */
        NgxQrcodeComponent.prototype.getOptions = /**
         * @return {?}
         */
            function () {
                if (typeof this.options === 'undefined') {
                    this.qrcodeOpt = this.defaultOptions;
                    this.qrcodeOpt.errorCorrectionLevel = this.errorCorrectionLevel ?
                        this.errorCorrectionLevel : this.defaultOptions.errorCorrectionLevel;
                    this.qrcodeOpt.type = this.type ? this.type : this.defaultOptions.type;
                    this.qrcodeOpt.rendererOpts.margin = this.margin ? this.margin : this.defaultOptions.rendererOpts.margin;
                    this.qrcodeOpt.rendererOpts.quality = this.quality ? this.quality : this.defaultOptions.rendererOpts.quality;
                    this.qrcodeOpt.rendererOpts.scale = this.scale ? this.scale : this.defaultOptions.rendererOpts.scale;
                    this.qrcodeOpt.color.dark = this.darkColor ? this.darkColor : this.defaultOptions.color.dark;
                    this.qrcodeOpt.color.light = this.lightColor ? this.lightColor : this.defaultOptions.color.light;
                    this.qrcodeOpt.width = this.width ? this.width : this.defaultOptions.width;
                }
                else {
                    this.qrcodeOpt = this.defaultOptions;
                    if (this.options.errorCorrectionLevel) {
                        this.qrcodeOpt.errorCorrectionLevel = this.options.errorCorrectionLevel;
                    }
                    if (this.options.type) {
                        this.qrcodeOpt.type = this.options.type;
                    }
                    if (this.options.quality) {
                        this.qrcodeOpt.rendererOpts.quality = this.options.quality;
                    }
                    if (this.options.margin) {
                        this.qrcodeOpt.rendererOpts.margin = this.options.margin;
                    }
                    if (this.options.scale) {
                        this.qrcodeOpt.rendererOpts.scale = this.options.scale;
                    }
                    if (this.options.darkColor) {
                        this.qrcodeOpt.color.dark = this.options.darkColor;
                    }
                    if (this.options.lightColor) {
                        this.qrcodeOpt.color.light = this.options.lightColor;
                    }
                    if (this.options.width) {
                        this.qrcodeOpt.width = this.options.width;
                    }
                }
                return this.qrcodeOpt;
            };
        /**
         * @param {?} text
         * @param {?} imageURL
         * @return {?}
         */
        NgxQrcodeComponent.prototype.sendMessage = /**
         * @param {?} text
         * @param {?} imageURL
         * @return {?}
         */
            function (text, imageURL) {
                var /** @type {?} */ obj = { text: text, imageData: imageURL };
                this.messageEvent.emit(obj);
            };
        NgxQrcodeComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'scl-ngx-qrcode',
                        template: "<img *ngIf=\"imageURL\" [src]=\"sanitizer.bypassSecurityTrustUrl(imageURL)\"  />\n",
                        styles: [""]
                    },] },
        ];
        /** @nocollapse */
        NgxQrcodeComponent.ctorParameters = function () {
            return [
                { type: Object, decorators: [{ type: core.Inject, args: [core.PLATFORM_ID,] }] },
                { type: platformBrowser.DomSanitizer }
            ];
        };
        NgxQrcodeComponent.propDecorators = {
            messageEvent: [{ type: core.Output }],
            options: [{ type: core.Input }],
            text: [{ type: core.Input }],
            errorCorrectionLevel: [{ type: core.Input }],
            type: [{ type: core.Input }],
            quality: [{ type: core.Input }],
            margin: [{ type: core.Input }],
            scale: [{ type: core.Input }],
            darkColor: [{ type: core.Input }],
            lightColor: [{ type: core.Input }],
            width: [{ type: core.Input }],
            outputType: [{ type: core.Input }]
        };
        return NgxQrcodeComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var NgxQrcodeModule = (function () {
        function NgxQrcodeModule() {
        }
        NgxQrcodeModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule
                        ],
                        declarations: [NgxQrcodeComponent],
                        exports: [NgxQrcodeComponent]
                    },] },
        ];
        return NgxQrcodeModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    exports.NgxQrcodeComponent = NgxQrcodeComponent;
    exports.NgxQrcodeModule = NgxQrcodeModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic21hcnRjb2RlbGFiLW5neC1xcmNvZGUudW1kLmpzLm1hcCIsInNvdXJjZXMiOltudWxsLCJuZzovL0BzbWFydGNvZGVsYWIvbmd4LXFyY29kZS9saWIvbmd4LXFyY29kZS5jb21wb25lbnQudHMiLCJuZzovL0BzbWFydGNvZGVsYWIvbmd4LXFyY29kZS9saWIvbmd4LXFyY29kZS5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbkNvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxyXG5MaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpOyB5b3UgbWF5IG5vdCB1c2VcclxudGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGVcclxuTGljZW5zZSBhdCBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcclxuXHJcblRISVMgQ09ERSBJUyBQUk9WSURFRCBPTiBBTiAqQVMgSVMqIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcclxuS0lORCwgRUlUSEVSIEVYUFJFU1MgT1IgSU1QTElFRCwgSU5DTFVESU5HIFdJVEhPVVQgTElNSVRBVElPTiBBTlkgSU1QTElFRFxyXG5XQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgVElUTEUsIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLFxyXG5NRVJDSEFOVEFCTElUWSBPUiBOT04tSU5GUklOR0VNRU5ULlxyXG5cclxuU2VlIHRoZSBBcGFjaGUgVmVyc2lvbiAyLjAgTGljZW5zZSBmb3Igc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXHJcbmFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cclxuKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogKi9cclxuLyogZ2xvYmFsIFJlZmxlY3QsIFByb21pc2UgKi9cclxuXHJcbnZhciBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XHJcbiAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChiLmhhc093blByb3BlcnR5KHApKSBkW3BdID0gYltwXTsgfTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2V4dGVuZHMoZCwgYikge1xyXG4gICAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxuICAgIGZ1bmN0aW9uIF9fKCkgeyB0aGlzLmNvbnN0cnVjdG9yID0gZDsgfVxyXG4gICAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xyXG59XHJcblxyXG5leHBvcnQgdmFyIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XHJcbiAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcclxuICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xyXG4gICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVzdChzLCBlKSB7XHJcbiAgICB2YXIgdCA9IHt9O1xyXG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXHJcbiAgICAgICAgdFtwXSA9IHNbcF07XHJcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDApXHJcbiAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xyXG4gICAgcmV0dXJuIHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2RlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XHJcbiAgICB2YXIgYyA9IGFyZ3VtZW50cy5sZW5ndGgsIHIgPSBjIDwgMyA/IHRhcmdldCA6IGRlc2MgPT09IG51bGwgPyBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSkgOiBkZXNjLCBkO1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcclxuICAgIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XHJcbiAgICByZXR1cm4gYyA+IDMgJiYgciAmJiBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHIpLCByO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19wYXJhbShwYXJhbUluZGV4LCBkZWNvcmF0b3IpIHtcclxuICAgIHJldHVybiBmdW5jdGlvbiAodGFyZ2V0LCBrZXkpIHsgZGVjb3JhdG9yKHRhcmdldCwga2V5LCBwYXJhbUluZGV4KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSkge1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0Lm1ldGFkYXRhID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBSZWZsZWN0Lm1ldGFkYXRhKG1ldGFkYXRhS2V5LCBtZXRhZGF0YVZhbHVlKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXRlcih0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xyXG4gICAgICAgIGZ1bmN0aW9uIGZ1bGZpbGxlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvci5uZXh0KHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiByZWplY3RlZCh2YWx1ZSkgeyB0cnkgeyBzdGVwKGdlbmVyYXRvcltcInRocm93XCJdKHZhbHVlKSk7IH0gY2F0Y2ggKGUpIHsgcmVqZWN0KGUpOyB9IH1cclxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUocmVzdWx0LnZhbHVlKTsgfSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxyXG4gICAgICAgIHN0ZXAoKGdlbmVyYXRvciA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSkubmV4dCgpKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19nZW5lcmF0b3IodGhpc0FyZywgYm9keSkge1xyXG4gICAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZztcclxuICAgIHJldHVybiBnID0geyBuZXh0OiB2ZXJiKDApLCBcInRocm93XCI6IHZlcmIoMSksIFwicmV0dXJuXCI6IHZlcmIoMikgfSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChfKSB0cnkge1xyXG4gICAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XHJcbiAgICAgICAgICAgIGlmICh5ID0gMCwgdCkgb3AgPSBbb3BbMF0gJiAyLCB0LnZhbHVlXTtcclxuICAgICAgICAgICAgc3dpdGNoIChvcFswXSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IF8ubGFiZWwrKzsgcmV0dXJuIHsgdmFsdWU6IG9wWzFdLCBkb25lOiBmYWxzZSB9O1xyXG4gICAgICAgICAgICAgICAgY2FzZSA1OiBfLmxhYmVsKys7IHkgPSBvcFsxXTsgb3AgPSBbMF07IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBpZiAoISh0ID0gXy50cnlzLCB0ID0gdC5sZW5ndGggPiAwICYmIHRbdC5sZW5ndGggLSAxXSkgJiYgKG9wWzBdID09PSA2IHx8IG9wWzBdID09PSAyKSkgeyBfID0gMDsgY29udGludWU7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gNiAmJiBfLmxhYmVsIDwgdFsxXSkgeyBfLmxhYmVsID0gdFsxXTsgdCA9IG9wOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0ICYmIF8ubGFiZWwgPCB0WzJdKSB7IF8ubGFiZWwgPSB0WzJdOyBfLm9wcy5wdXNoKG9wKTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7IG9wID0gWzYsIGVdOyB5ID0gMDsgfSBmaW5hbGx5IHsgZiA9IHQgPSAwOyB9XHJcbiAgICAgICAgaWYgKG9wWzBdICYgNSkgdGhyb3cgb3BbMV07IHJldHVybiB7IHZhbHVlOiBvcFswXSA/IG9wWzFdIDogdm9pZCAwLCBkb25lOiB0cnVlIH07XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2V4cG9ydFN0YXIobSwgZXhwb3J0cykge1xyXG4gICAgZm9yICh2YXIgcCBpbiBtKSBpZiAoIWV4cG9ydHMuaGFzT3duUHJvcGVydHkocCkpIGV4cG9ydHNbcF0gPSBtW3BdO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX192YWx1ZXMobykge1xyXG4gICAgdmFyIG0gPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgb1tTeW1ib2wuaXRlcmF0b3JdLCBpID0gMDtcclxuICAgIGlmIChtKSByZXR1cm4gbS5jYWxsKG8pO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBuZXh0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmIChvICYmIGkgPj0gby5sZW5ndGgpIG8gPSB2b2lkIDA7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBvICYmIG9baSsrXSwgZG9uZTogIW8gfTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19yZWFkKG8sIG4pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXTtcclxuICAgIGlmICghbSkgcmV0dXJuIG87XHJcbiAgICB2YXIgaSA9IG0uY2FsbChvKSwgciwgYXIgPSBbXSwgZTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgd2hpbGUgKChuID09PSB2b2lkIDAgfHwgbi0tID4gMCkgJiYgIShyID0gaS5uZXh0KCkpLmRvbmUpIGFyLnB1c2goci52YWx1ZSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaCAoZXJyb3IpIHsgZSA9IHsgZXJyb3I6IGVycm9yIH07IH1cclxuICAgIGZpbmFsbHkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChyICYmICFyLmRvbmUgJiYgKG0gPSBpW1wicmV0dXJuXCJdKSkgbS5jYWxsKGkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmaW5hbGx5IHsgaWYgKGUpIHRocm93IGUuZXJyb3I7IH1cclxuICAgIH1cclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fc3ByZWFkKCkge1xyXG4gICAgZm9yICh2YXIgYXIgPSBbXSwgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspXHJcbiAgICAgICAgYXIgPSBhci5jb25jYXQoX19yZWFkKGFyZ3VtZW50c1tpXSkpO1xyXG4gICAgcmV0dXJuIGFyO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hd2FpdCh2KSB7XHJcbiAgICByZXR1cm4gdGhpcyBpbnN0YW5jZW9mIF9fYXdhaXQgPyAodGhpcy52ID0gdiwgdGhpcykgOiBuZXcgX19hd2FpdCh2KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXN5bmNHZW5lcmF0b3IodGhpc0FyZywgX2FyZ3VtZW50cywgZ2VuZXJhdG9yKSB7XHJcbiAgICBpZiAoIVN5bWJvbC5hc3luY0l0ZXJhdG9yKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmFzeW5jSXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xyXG4gICAgdmFyIGcgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSksIGksIHEgPSBbXTtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSwgaTtcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyBpZiAoZ1tuXSkgaVtuXSA9IGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAoYSwgYikgeyBxLnB1c2goW24sIHYsIGEsIGJdKSA+IDEgfHwgcmVzdW1lKG4sIHYpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gcmVzdW1lKG4sIHYpIHsgdHJ5IHsgc3RlcChnW25dKHYpKTsgfSBjYXRjaCAoZSkgeyBzZXR0bGUocVswXVszXSwgZSk7IH0gfVxyXG4gICAgZnVuY3Rpb24gc3RlcChyKSB7IHIudmFsdWUgaW5zdGFuY2VvZiBfX2F3YWl0ID8gUHJvbWlzZS5yZXNvbHZlKHIudmFsdWUudikudGhlbihmdWxmaWxsLCByZWplY3QpIDogc2V0dGxlKHFbMF1bMl0sIHIpOyB9XHJcbiAgICBmdW5jdGlvbiBmdWxmaWxsKHZhbHVlKSB7IHJlc3VtZShcIm5leHRcIiwgdmFsdWUpOyB9XHJcbiAgICBmdW5jdGlvbiByZWplY3QodmFsdWUpIHsgcmVzdW1lKFwidGhyb3dcIiwgdmFsdWUpOyB9XHJcbiAgICBmdW5jdGlvbiBzZXR0bGUoZiwgdikgeyBpZiAoZih2KSwgcS5zaGlmdCgpLCBxLmxlbmd0aCkgcmVzdW1lKHFbMF1bMF0sIHFbMF1bMV0pOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jRGVsZWdhdG9yKG8pIHtcclxuICAgIHZhciBpLCBwO1xyXG4gICAgcmV0dXJuIGkgPSB7fSwgdmVyYihcIm5leHRcIiksIHZlcmIoXCJ0aHJvd1wiLCBmdW5jdGlvbiAoZSkgeyB0aHJvdyBlOyB9KSwgdmVyYihcInJldHVyblwiKSwgaVtTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSwgaTtcclxuICAgIGZ1bmN0aW9uIHZlcmIobiwgZikgeyBpW25dID0gb1tuXSA/IGZ1bmN0aW9uICh2KSB7IHJldHVybiAocCA9ICFwKSA/IHsgdmFsdWU6IF9fYXdhaXQob1tuXSh2KSksIGRvbmU6IG4gPT09IFwicmV0dXJuXCIgfSA6IGYgPyBmKHYpIDogdjsgfSA6IGY7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXN5bmNWYWx1ZXMobykge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBtID0gb1tTeW1ib2wuYXN5bmNJdGVyYXRvcl0sIGk7XHJcbiAgICByZXR1cm4gbSA/IG0uY2FsbChvKSA6IChvID0gdHlwZW9mIF9fdmFsdWVzID09PSBcImZ1bmN0aW9uXCIgPyBfX3ZhbHVlcyhvKSA6IG9bU3ltYm9sLml0ZXJhdG9yXSgpLCBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSwgaSk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaVtuXSA9IG9bbl0gJiYgZnVuY3Rpb24gKHYpIHsgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHsgdiA9IG9bbl0odiksIHNldHRsZShyZXNvbHZlLCByZWplY3QsIHYuZG9uZSwgdi52YWx1ZSk7IH0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCBkLCB2KSB7IFByb21pc2UucmVzb2x2ZSh2KS50aGVuKGZ1bmN0aW9uKHYpIHsgcmVzb2x2ZSh7IHZhbHVlOiB2LCBkb25lOiBkIH0pOyB9LCByZWplY3QpOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX21ha2VUZW1wbGF0ZU9iamVjdChjb29rZWQsIHJhdykge1xyXG4gICAgaWYgKE9iamVjdC5kZWZpbmVQcm9wZXJ0eSkgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoY29va2VkLCBcInJhd1wiLCB7IHZhbHVlOiByYXcgfSk7IH0gZWxzZSB7IGNvb2tlZC5yYXcgPSByYXc7IH1cclxuICAgIHJldHVybiBjb29rZWQ7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnRTdGFyKG1vZCkge1xyXG4gICAgaWYgKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgcmV0dXJuIG1vZDtcclxuICAgIHZhciByZXN1bHQgPSB7fTtcclxuICAgIGlmIChtb2QgIT0gbnVsbCkgZm9yICh2YXIgayBpbiBtb2QpIGlmIChPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtb2QsIGspKSByZXN1bHRba10gPSBtb2Rba107XHJcbiAgICByZXN1bHQuZGVmYXVsdCA9IG1vZDtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydERlZmF1bHQobW9kKSB7XHJcbiAgICByZXR1cm4gKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgPyBtb2QgOiB7IGRlZmF1bHQ6IG1vZCB9O1xyXG59XHJcbiIsImltcG9ydCB7XG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDb21wb25lbnQsXG4gIEVsZW1lbnRSZWYsXG4gIElucHV0LFxuICBPbkNoYW5nZXMsXG4gIE9uSW5pdCxcbiAgU2ltcGxlQ2hhbmdlLFxuICBJbmplY3QsXG4gIFBMQVRGT1JNX0lELFxuICBTaW1wbGVDaGFuZ2VzLFxuICBWaWV3Q2hpbGQsXG4gIEV2ZW50RW1pdHRlcixcbiAgT3V0cHV0XG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0ICogYXMgUVJDb2RlIGZyb20gJ3FyY29kZSc7XG5pbXBvcnQgeyBpc1BsYXRmb3JtQnJvd3NlciB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBEb21TYW5pdGl6ZXIgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnc2NsLW5neC1xcmNvZGUnLFxuICB0ZW1wbGF0ZTogYDxpbWcgKm5nSWY9XCJpbWFnZVVSTFwiIFtzcmNdPVwic2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RVcmwoaW1hZ2VVUkwpXCIgIC8+XG5gLFxuICBzdHlsZXM6IFtgYF1cbn0pXG5cbmV4cG9ydCBjbGFzcyBOZ3hRcmNvZGVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XG4gIHB1YmxpYyBpbWFnZVVSTDogc3RyaW5nO1xuICBpc0Jyb3dzZXI6IGJvb2xlYW47XG4gIHB1YmxpYyBxcmNvZGVPcHQ6IFFSQ29kZU9wdGlvbnM7XG4gIEBPdXRwdXQoKSBtZXNzYWdlRXZlbnQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgQElucHV0KCkgcHVibGljIG9wdGlvbnM6IFFyY29kZU9wdGlvblVzZXJUZW1wbGF0ZTtcbiAgQElucHV0KCkgcHVibGljIHRleHQ6IHN0cmluZztcbiAgQElucHV0KCkgcHVibGljIGVycm9yQ29ycmVjdGlvbkxldmVsOiBzdHJpbmc7XG4gIEBJbnB1dCgpIHB1YmxpYyB0eXBlOiBzdHJpbmc7XG4gIEBJbnB1dCgpIHB1YmxpYyBxdWFsaXR5OiBudW1iZXI7XG4gIEBJbnB1dCgpIHB1YmxpYyBtYXJnaW46IG51bWJlcjtcbiAgQElucHV0KCkgcHVibGljIHNjYWxlOiBudW1iZXI7XG4gIEBJbnB1dCgpIHB1YmxpYyBkYXJrQ29sb3I6IHN0cmluZztcbiAgQElucHV0KCkgcHVibGljIGxpZ2h0Q29sb3I6IHN0cmluZztcbiAgQElucHV0KCkgcHVibGljIHdpZHRoOiBudW1iZXI7XG4gIEBJbnB1dCgpIHB1YmxpYyBvdXRwdXRUeXBlOiBzdHJpbmc7XG5cbiAgZGVmYXVsdE9wdGlvbnM6IFFSQ29kZU9wdGlvbnMgPSB7XG4gICAgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6ICdIJywgLy8gTCwgTSwgUSwgSFxuICAgIHR5cGU6ICdpbWFnZS9qcGVnJyxcbiAgICByZW5kZXJlck9wdHM6IHtcbiAgICAgIHF1YWxpdHk6IDAuMyxcbiAgICAgIG1hcmdpbjogNCxcbiAgICAgIHNjYWxlOiA0XG4gICAgfSxcbiAgICBjb2xvcjoge1xuICAgICAgZGFyazogJyMwMDAwMDBmZicsICAvLyBCbHVlIGRvdHNcbiAgICAgIGxpZ2h0OiAnI2ZmZicgLy8gVHJhbnNwYXJlbnQgYmFja2dyb3VuZFxuICAgIH0sXG4gICAgd2lkdGg6IDMwMFxuICB9O1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIEBJbmplY3QoUExBVEZPUk1fSUQpIHByaXZhdGUgcGxhdGZvcm1JZDogT2JqZWN0LFxuICAgIHB1YmxpYyBzYW5pdGl6ZXI6IERvbVNhbml0aXplcikge1xuICAgIHRoaXMuaXNCcm93c2VyID0gaXNQbGF0Zm9ybUJyb3dzZXIocGxhdGZvcm1JZCk7XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKHRoaXMuaXNCcm93c2VyKSB7XG4gICAgICBjb25zdCBxckRhdGEgPSBjaGFuZ2VzWyd0ZXh0J107XG4gICAgICBjb25zdCB3aWR0aCAgPSBjaGFuZ2VzWyd3aWR0aCddO1xuICAgICAgY29uc3QgZGFya0NvbG9yICA9IGNoYW5nZXNbJ2RhcmtDb2xvciddO1xuICAgICAgY29uc3QgbGlnaHRDb2xvciAgPSBjaGFuZ2VzWydsaWdodENvbG9yJ107XG4gICAgICBjb25zdCB0eXBlICA9IGNoYW5nZXNbJ3R5cGUnXTtcbiAgICAgIGNvbnN0IHNjYWxlICA9IGNoYW5nZXNbJ3NjYWxlJ107XG4gICAgICBjb25zdCBtYXJnaW4gID0gY2hhbmdlc1snbWFyZ2luJ107XG4gICAgICBjb25zdCBxdWFsaXR5ICA9IGNoYW5nZXNbJ3F1YWxpdHknXTtcbiAgICAgIGNvbnN0IGVycm9yQ29ycmVjdGlvbkxldmVsICA9IGNoYW5nZXNbJ2Vycm9yQ29ycmVjdGlvbkxldmVsJ107XG4gICAgICB0aGlzLnRleHQgPSBxckRhdGEgPyBxckRhdGEuY3VycmVudFZhbHVlIDogdGhpcy50ZXh0O1xuXG4gICAgICB0aGlzLndpZHRoID0gd2lkdGggPyB3aWR0aC5jdXJyZW50VmFsdWUgOiB0aGlzLndpZHRoO1xuICAgICAgdGhpcy5kYXJrQ29sb3IgPSBkYXJrQ29sb3IgPyBkYXJrQ29sb3IuY3VycmVudFZhbHVlIDogdGhpcy5kYXJrQ29sb3I7XG4gICAgICB0aGlzLmxpZ2h0Q29sb3IgPSBsaWdodENvbG9yID8gbGlnaHRDb2xvci5jdXJyZW50VmFsdWUgOiB0aGlzLmxpZ2h0Q29sb3I7XG4gICAgICB0aGlzLnR5cGUgPSB0eXBlID8gdHlwZS5jdXJyZW50VmFsdWUgOiB0aGlzLnR5cGU7XG4gICAgICB0aGlzLnNjYWxlID0gc2NhbGUgPyBzY2FsZS5jdXJyZW50VmFsdWUgOiB0aGlzLnNjYWxlO1xuICAgICAgdGhpcy5tYXJnaW4gPSBtYXJnaW4gPyBtYXJnaW4uY3VycmVudFZhbHVlIDogdGhpcy5tYXJnaW47XG4gICAgICB0aGlzLnF1YWxpdHkgPSBxdWFsaXR5ID8gcXVhbGl0eS5jdXJyZW50VmFsdWUgOiB0aGlzLnF1YWxpdHk7XG4gICAgICB0aGlzLmVycm9yQ29ycmVjdGlvbkxldmVsID0gZXJyb3JDb3JyZWN0aW9uTGV2ZWwgPyBlcnJvckNvcnJlY3Rpb25MZXZlbC5jdXJyZW50VmFsdWUgOiB0aGlzLmxpZ2h0Q29sb3I7XG4gICAgICB0aGlzLmdlbmVyYXRlUVJDb2RlKHRoaXMudGV4dCk7XG5cbiAgICB9XG4gIH1cbiAgYXN5bmMgZ2VuZXJhdGVRUkNvZGUodGV4dDogc3RyaW5nKSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICghdGhpcy5pc1ZhbGlkUVJDb2RlVGV4dCh0ZXh0KSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0VtcHR5IFFSIENvZGUgZGF0YScpO1xuICAgICAgfVxuICAgICAgdGhpcy5pbWFnZVVSTCA9IGF3YWl0IFFSQ29kZS50b0RhdGFVUkwodGV4dCwgdGhpcy5nZXRPcHRpb25zKCkpO1xuICAgICAgdGhpcy5zZW5kTWVzc2FnZSh0ZXh0LCB0aGlzLmltYWdlVVJMKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIENyZWF0aW5nIFFSQ29kZSBJbWFnZScsIGVyci5tZXNzYWdlKTtcbiAgICB9XG4gIH1cblxuICBpc1ZhbGlkUVJDb2RlVGV4dChkYXRhOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICByZXR1cm4gISh0eXBlb2YgZGF0YSA9PT0gJ3VuZGVmaW5lZCcgfHwgZGF0YSA9PT0gbnVsbCB8fCBkYXRhID09PSAnJyk7XG4gIH1cblxuICBnZXRPcHRpb25zKCkge1xuICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zID09PSAndW5kZWZpbmVkJykge1xuICAgICAgdGhpcy5xcmNvZGVPcHQgPSB0aGlzLmRlZmF1bHRPcHRpb25zO1xuICAgICAgdGhpcy5xcmNvZGVPcHQuZXJyb3JDb3JyZWN0aW9uTGV2ZWwgPSB0aGlzLmVycm9yQ29ycmVjdGlvbkxldmVsID9cbiAgICAgIHRoaXMuZXJyb3JDb3JyZWN0aW9uTGV2ZWwgOiB0aGlzLmRlZmF1bHRPcHRpb25zLmVycm9yQ29ycmVjdGlvbkxldmVsO1xuICAgICAgdGhpcy5xcmNvZGVPcHQudHlwZSA9IHRoaXMudHlwZSA/IHRoaXMudHlwZSA6IHRoaXMuZGVmYXVsdE9wdGlvbnMudHlwZTtcbiAgICAgIHRoaXMucXJjb2RlT3B0LnJlbmRlcmVyT3B0cy5tYXJnaW4gPSB0aGlzLm1hcmdpbiA/IHRoaXMubWFyZ2luIDogdGhpcy5kZWZhdWx0T3B0aW9ucy5yZW5kZXJlck9wdHMubWFyZ2luO1xuICAgICAgdGhpcy5xcmNvZGVPcHQucmVuZGVyZXJPcHRzLnF1YWxpdHkgPSB0aGlzLnF1YWxpdHkgPyB0aGlzLnF1YWxpdHkgOiB0aGlzLmRlZmF1bHRPcHRpb25zLnJlbmRlcmVyT3B0cy5xdWFsaXR5O1xuICAgICAgdGhpcy5xcmNvZGVPcHQucmVuZGVyZXJPcHRzLnNjYWxlID0gdGhpcy5zY2FsZSA/IHRoaXMuc2NhbGUgOiB0aGlzLmRlZmF1bHRPcHRpb25zLnJlbmRlcmVyT3B0cy5zY2FsZTtcbiAgICAgIHRoaXMucXJjb2RlT3B0LmNvbG9yLmRhcmsgPSB0aGlzLmRhcmtDb2xvciA/IHRoaXMuZGFya0NvbG9yIDogdGhpcy5kZWZhdWx0T3B0aW9ucy5jb2xvci5kYXJrO1xuICAgICAgdGhpcy5xcmNvZGVPcHQuY29sb3IubGlnaHQgPSB0aGlzLmxpZ2h0Q29sb3IgPyB0aGlzLmxpZ2h0Q29sb3IgOiB0aGlzLmRlZmF1bHRPcHRpb25zLmNvbG9yLmxpZ2h0O1xuICAgICAgdGhpcy5xcmNvZGVPcHQud2lkdGggPSB0aGlzLndpZHRoID8gdGhpcy53aWR0aCA6IHRoaXMuZGVmYXVsdE9wdGlvbnMud2lkdGg7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucXJjb2RlT3B0ID0gdGhpcy5kZWZhdWx0T3B0aW9ucztcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuZXJyb3JDb3JyZWN0aW9uTGV2ZWwpIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQuZXJyb3JDb3JyZWN0aW9uTGV2ZWwgPSB0aGlzLm9wdGlvbnMuZXJyb3JDb3JyZWN0aW9uTGV2ZWw7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5vcHRpb25zLnR5cGUpIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQudHlwZSA9IHRoaXMub3B0aW9ucy50eXBlO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5vcHRpb25zLnF1YWxpdHkpIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQucmVuZGVyZXJPcHRzLnF1YWxpdHkgPSB0aGlzLm9wdGlvbnMucXVhbGl0eTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMubWFyZ2luKSB7XG4gICAgICAgIHRoaXMucXJjb2RlT3B0LnJlbmRlcmVyT3B0cy5tYXJnaW4gPSB0aGlzLm9wdGlvbnMubWFyZ2luO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5vcHRpb25zLnNjYWxlKSB7XG4gICAgICAgIHRoaXMucXJjb2RlT3B0LnJlbmRlcmVyT3B0cy5zY2FsZSA9IHRoaXMub3B0aW9ucy5zY2FsZTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuZGFya0NvbG9yKSB7XG4gICAgICAgIHRoaXMucXJjb2RlT3B0LmNvbG9yLmRhcmsgPSB0aGlzLm9wdGlvbnMuZGFya0NvbG9yO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5vcHRpb25zLmxpZ2h0Q29sb3IpIHtcbiAgICAgICAgdGhpcy5xcmNvZGVPcHQuY29sb3IubGlnaHQgPSB0aGlzLm9wdGlvbnMubGlnaHRDb2xvcjtcbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMub3B0aW9ucy53aWR0aCkge1xuICAgICAgICB0aGlzLnFyY29kZU9wdC53aWR0aCA9IHRoaXMub3B0aW9ucy53aWR0aDtcbiAgICAgIH1cblxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5xcmNvZGVPcHQ7XG4gIH1cblxuICBzZW5kTWVzc2FnZSh0ZXh0LCBpbWFnZVVSTCkge1xuICAgIGNvbnN0IG9iaiA9IHsgdGV4dDogdGV4dCAsIGltYWdlRGF0YTogaW1hZ2VVUkwgfTtcbiAgICB0aGlzLm1lc3NhZ2VFdmVudC5lbWl0KG9iaik7XG4gIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBRUkNvZGVPcHRpb25zIHtcbiAgZXJyb3JDb3JyZWN0aW9uTGV2ZWw6IFN0cmluZztcbiAgdHlwZTogU3RyaW5nO1xuICByZW5kZXJlck9wdHM6IHtcbiAgICBxdWFsaXR5OiBOdW1iZXIsXG4gICAgbWFyZ2luOiBOdW1iZXIsXG4gICAgc2NhbGU6IE51bWJlclxuICB9O1xuICBjb2xvcjoge1xuICAgIGRhcms6IFN0cmluZyxcbiAgICBsaWdodDogU3RyaW5nXG4gIH07XG4gIHdpZHRoOiBOdW1iZXI7XG59XG5leHBvcnQgaW50ZXJmYWNlIFFyY29kZU9wdGlvblVzZXJUZW1wbGF0ZSB7XG4gIGVycm9yQ29ycmVjdGlvbkxldmVsOiBTdHJpbmc7XG4gIHR5cGU6IFN0cmluZztcbiAgcXVhbGl0eTogTnVtYmVyO1xuICBtYXJnaW46IE51bWJlcjtcbiAgc2NhbGU6IE51bWJlcjtcbiAgZGFya0NvbG9yOiBTdHJpbmc7XG4gIGxpZ2h0Q29sb3I6IFN0cmluZztcbiAgd2lkdGg6IE51bWJlcjtcbn1cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ3hRcmNvZGVDb21wb25lbnQgfSBmcm9tICcuL25neC1xcmNvZGUuY29tcG9uZW50JztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgICBDb21tb25Nb2R1bGVcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbTmd4UXJjb2RlQ29tcG9uZW50XSxcbiAgZXhwb3J0czogW05neFFyY29kZUNvbXBvbmVudF1cbn0pXG5leHBvcnQgY2xhc3MgTmd4UXJjb2RlTW9kdWxlIHsgfVxuIl0sIm5hbWVzIjpbIkV2ZW50RW1pdHRlciIsImlzUGxhdGZvcm1Ccm93c2VyIiwiUVJDb2RlLnRvRGF0YVVSTCIsIkNvbXBvbmVudCIsIkluamVjdCIsIlBMQVRGT1JNX0lEIiwiRG9tU2FuaXRpemVyIiwiT3V0cHV0IiwiSW5wdXQiLCJOZ01vZHVsZSIsIkNvbW1vbk1vZHVsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0lBQUE7Ozs7Ozs7Ozs7Ozs7O0FBY0EsdUJBNkMwQixPQUFPLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTO1FBQ3ZELE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQU8sQ0FBQyxFQUFFLFVBQVUsT0FBTyxFQUFFLE1BQU07WUFDckQsbUJBQW1CLEtBQUssSUFBSSxJQUFJO2dCQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7YUFBRTtZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFFLEVBQUU7WUFDM0Ysa0JBQWtCLEtBQUssSUFBSSxJQUFJO2dCQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzthQUFFO1lBQUMsT0FBTyxDQUFDLEVBQUU7Z0JBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUUsRUFBRTtZQUM5RixjQUFjLE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsVUFBVSxPQUFPLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUU7WUFDL0ksSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFVBQVUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1NBQ3pFLENBQUMsQ0FBQztJQUNQLENBQUM7QUFFRCx5QkFBNEIsT0FBTyxFQUFFLElBQUk7UUFDckMsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxjQUFhLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2pILE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxPQUFPLE1BQU0sS0FBSyxVQUFVLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxjQUFhLE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN6SixjQUFjLENBQUMsSUFBSSxPQUFPLFVBQVUsQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUU7UUFDbEUsY0FBYyxFQUFFO1lBQ1osSUFBSSxDQUFDO2dCQUFFLE1BQU0sSUFBSSxTQUFTLENBQUMsaUNBQWlDLENBQUMsQ0FBQztZQUM5RCxPQUFPLENBQUM7Z0JBQUUsSUFBSTtvQkFDVixJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUk7d0JBQUUsT0FBTyxDQUFDLENBQUM7b0JBQzdKLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUFFLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN4QyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7d0JBQ1QsS0FBSyxDQUFDLENBQUM7d0JBQUMsS0FBSyxDQUFDOzRCQUFFLENBQUMsR0FBRyxFQUFFLENBQUM7NEJBQUMsTUFBTTt3QkFDOUIsS0FBSyxDQUFDOzRCQUFFLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs0QkFBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUM7d0JBQ3hELEtBQUssQ0FBQzs0QkFBRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7NEJBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFBQyxTQUFTO3dCQUNqRCxLQUFLLENBQUM7NEJBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7NEJBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQzs0QkFBQyxTQUFTO3dCQUNqRDs0QkFDSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0NBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQ0FBQyxTQUFTOzZCQUFFOzRCQUM1RyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FBRSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FBQyxNQUFNOzZCQUFFOzRCQUN0RixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0NBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQ0FBQyxNQUFNOzZCQUFFOzRCQUNyRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FBRSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FBQyxNQUFNOzZCQUFFOzRCQUNuRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQzs0QkFDdEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQzs0QkFBQyxTQUFTO3FCQUM5QjtvQkFDRCxFQUFFLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQzlCO2dCQUFDLE9BQU8sQ0FBQyxFQUFFO29CQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUFFO3dCQUFTO29CQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUFFO1lBQzFELElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDO1NBQ3BGO0lBQ0wsQ0FBQzs7Ozs7OztRQ25DQyw0QkFDK0IsVUFBa0IsRUFDeEM7WUFEc0IsZUFBVSxHQUFWLFVBQVUsQ0FBUTtZQUN4QyxjQUFTLEdBQVQsU0FBUztnQ0EvQk8sSUFBSUEsaUJBQVksRUFBRTtrQ0FjWDtnQkFDOUIsb0JBQW9CLEVBQUUsR0FBRzs7Z0JBQ3pCLElBQUksRUFBRSxZQUFZO2dCQUNsQixZQUFZLEVBQUU7b0JBQ1osT0FBTyxFQUFFLEdBQUc7b0JBQ1osTUFBTSxFQUFFLENBQUM7b0JBQ1QsS0FBSyxFQUFFLENBQUM7aUJBQ1Q7Z0JBQ0QsS0FBSyxFQUFFO29CQUNMLElBQUksRUFBRSxXQUFXOztvQkFDakIsS0FBSyxFQUFFLE1BQU07aUJBQ2Q7Z0JBQ0QsS0FBSyxFQUFFLEdBQUc7YUFDWDtZQUtDLElBQUksQ0FBQyxTQUFTLEdBQUdDLHdCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ2hEOzs7O1FBRUQscUNBQVE7OztZQUFSO2FBQ0M7Ozs7O1FBRU0sd0NBQVc7Ozs7c0JBQUMsT0FBc0I7Z0JBQ3ZDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtvQkFDbEIscUJBQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDL0IscUJBQU0sS0FBSyxHQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDaEMscUJBQU0sU0FBUyxHQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDeEMscUJBQU0sVUFBVSxHQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDMUMscUJBQU0sSUFBSSxHQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDOUIscUJBQU0sS0FBSyxHQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDaEMscUJBQU0sTUFBTSxHQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDbEMscUJBQU0sT0FBTyxHQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDcEMscUJBQU0sb0JBQW9CLEdBQUksT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUM7b0JBQzlELElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztvQkFFckQsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO29CQUNyRCxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsR0FBRyxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7b0JBQ3JFLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztvQkFDekUsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO29CQUNqRCxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7b0JBQ3JELElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztvQkFDekQsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLEdBQUcsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO29CQUM3RCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsb0JBQW9CLEdBQUcsb0JBQW9CLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7b0JBQ3ZHLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUVoQzs7Ozs7O1FBRUcsMkNBQWM7Ozs7WUFBcEIsVUFBcUIsSUFBWTs7Ozs7OztnQ0FFN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQ0FDakMsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO2lDQUN2QztnQ0FDRCxLQUFBLElBQUksQ0FBQTtnQ0FBWSxxQkFBTUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFBOztnQ0FBL0QsR0FBSyxRQUFRLEdBQUcsU0FBK0MsQ0FBQztnQ0FDaEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzs7O2dDQUV0QyxPQUFPLENBQUMsS0FBSyxDQUFDLDZCQUE2QixFQUFFLEtBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQzs7Ozs7O2FBRTdEOzs7OztRQUVELDhDQUFpQjs7OztZQUFqQixVQUFrQixJQUFZO2dCQUM1QixPQUFPLEVBQUUsT0FBTyxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQyxDQUFDO2FBQ3ZFOzs7O1FBRUQsdUNBQVU7OztZQUFWO2dCQUNFLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtvQkFDdkMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO29CQUNyQyxJQUFJLENBQUMsU0FBUyxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxvQkFBb0I7d0JBQy9ELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDO29CQUNyRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7b0JBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO29CQUN6RyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQztvQkFDN0csSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7b0JBQ3JHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUM3RixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztvQkFDakcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO2lCQUM1RTtxQkFBTTtvQkFDTCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7b0JBQ3JDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRTt3QkFDckMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDO3FCQUN6RTtvQkFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO3dCQUNyQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztxQkFDekM7b0JBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRTt3QkFDeEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO3FCQUM1RDtvQkFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO3dCQUN2QixJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7cUJBQzFEO29CQUVELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUU7d0JBQ3RCLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztxQkFDeEQ7b0JBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTt3QkFDMUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO3FCQUNwRDtvQkFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFO3dCQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7cUJBQ3REO29CQUVELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUU7d0JBQ3RCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO3FCQUMzQztpQkFFRjtnQkFDRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUM7YUFDdkI7Ozs7OztRQUVELHdDQUFXOzs7OztZQUFYLFVBQVksSUFBSSxFQUFFLFFBQVE7Z0JBQ3hCLHFCQUFNLEdBQUcsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUcsU0FBUyxFQUFFLFFBQVEsRUFBRSxDQUFDO2dCQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM3Qjs7b0JBNUlGQyxjQUFTLFNBQUM7d0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjt3QkFDMUIsUUFBUSxFQUFFLG9GQUNYO3dCQUNDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQztxQkFDYjs7Ozs7d0JBb0M0QyxNQUFNLHVCQUE5Q0MsV0FBTSxTQUFDQyxnQkFBVzt3QkEzQ2RDLDRCQUFZOzs7O21DQWFsQkMsV0FBTTs4QkFFTkMsVUFBSzsyQkFDTEEsVUFBSzsyQ0FDTEEsVUFBSzsyQkFDTEEsVUFBSzs4QkFDTEEsVUFBSzs2QkFDTEEsVUFBSzs0QkFDTEEsVUFBSztnQ0FDTEEsVUFBSztpQ0FDTEEsVUFBSzs0QkFDTEEsVUFBSztpQ0FDTEEsVUFBSzs7aUNBMUNSOzs7Ozs7O0FDQUE7Ozs7b0JBSUNDLGFBQVEsU0FBQzt3QkFDUixPQUFPLEVBQUU7NEJBQ1BDLG1CQUFZO3lCQUNiO3dCQUNELFlBQVksRUFBRSxDQUFDLGtCQUFrQixDQUFDO3dCQUNsQyxPQUFPLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztxQkFDOUI7OzhCQVZEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7In0=