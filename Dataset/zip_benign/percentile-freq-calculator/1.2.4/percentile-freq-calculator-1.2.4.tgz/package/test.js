const percentile_freq_calculator = require('./index.js');

const data = [{myValue:1, freq: 1},{myValue:2, freq: 3},{myValue:3, freq: 6}] 
console.log(percentile_freq_calculator(data, 0.5, "myValue", 'freq')) 

