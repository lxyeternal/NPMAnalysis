'use strict';
require('./default.css');
var Bar = require('dchart-multi-gradient');
var d3 = require('d3');
var _ = require('dchart-core/util');

function BarGradient(container, options) {
  var opt = {
    margin: {left: 14, top: 30, right: 16, bottom: 98},
    xaxis: {
      padding: [0.5, 0.6],
      groupPadding: [0, 0],
      dy: 2,
      labelOrient: 'horizontal'
    },
    gradientColors: {
      from: 'rgb(155,255,0)',
      to: 'rgb(255,0,155)',
      orient: 'vertical',
    },
    background: {}
  };
  _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}

BarGradient = Bar.extend(BarGradient, {
  data: function (data) {
    if (!data) return this._data;
    var opt = this.options;
    var ykey = opt.yaxis.key;
    if (!data[0][ykey].length) {
      data.forEach(function (obj) {
        obj[ykey] = [obj[ykey]];
      });
      this._data = data;
    }
    if (!opt.gradientColors.length) {
      opt.gradientColors = [opt.gradientColors];
    }
  },
  beforeRender: function () {
    Bar.prototype.beforeRender.call(this);
    var opt = this.options;
    if (opt.background) {
      var bg = this.renderBG('bg', this.svg[0][0]);
    }
  },
  afterRender: function () {
    Bar.prototype.afterRender.call(this);
    var opt = this.options;
    if (opt.background) {
      var data = this.data();
      var x = this.getComs('axis', 'xaxis').getX();
      var bg = this.getComs('background', 'bg');
      bg.el.selectAll('.bg-serie')
        .data(data)
        .enter().append('rect')
        .attr({
          class: 'bg-serie',
          x: function (d) {
            return x(d[opt.xaxis.key]);
          },
          y: 0,
          width: x.rangeBand(),
          height: opt.innerHeight
        });
    }
  }
});

module.exports = BarGradient;
