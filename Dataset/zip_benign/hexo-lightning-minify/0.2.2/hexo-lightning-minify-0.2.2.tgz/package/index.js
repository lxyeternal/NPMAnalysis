"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const css_1 = require("./lib/css");
const js_1 = require("./lib/js");
const img_1 = require("./lib/img");
hexo.config.minify.js = Object.assign({
    enable: false,
    options: {
        comments: false,
        ecma: 2020,
        toplevel: false
    },
    exclude: []
}, hexo.config.minify?.js);
hexo.config.minify.css = Object.assign({
    enable: true,
    options: {
        targets: null
    },
    exclude: []
}, hexo.config.minify?.css);
hexo.config.minify.image = Object.assign({
    enable: true,
    options: {
        webp: false,
        avif: true,
        quality: 60,
        effort: 2,
        replaceSrc: true,
        destroyOldRoute: false,
        enableSubSampling: true
    },
    exclude: []
}, hexo.config.minify?.image);
if (hexo.config.minify.css.enable) {
    hexo.extend.filter.register('after_render:css', css_1.minifyCss);
}
if (hexo.config.minify.js.enable) {
    hexo.extend.filter.register('after_render:js', js_1.minifyJs);
}
if (hexo.config.minify.image.enable) {
    hexo.extend.filter.register('after_generate', img_1.transformImage, 50);
    if (hexo.config.minify.image.options.replaceSrc) {
        hexo.extend.filter.register('after_render:html', img_1.replaceSrc, 1);
    }
}
