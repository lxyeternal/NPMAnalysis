should = require 'should'
gooser = require '../domain/main'
{join} = require 'path'
{config, fordFocus, engine, piston} = require './sample/mocks'

describe 'main', ->

  describe 'initialize', ->

    it 'should connect to the database', (done) ->
      mongoose = require 'mongoose'
      gooser.initialize config, (err, models) ->
        should.exist mongoose.connection
        done()

    it 'should load my models', (done) ->
      gooser.initialize config, (err, models) ->
        should.not.exist err
        should.exist models
        should.exist models.Car
        should.exist models.Engine
        should.exist models.Piston
        done()

  describe 'wipe', ->

    it 'should remove all data', (done) ->
      gooser.initialize config, (err, models) ->
        {Car} = models
        (new Car fordFocus).save (err, car) ->
          gooser.wipe config, (err, rubble) ->
            Car.find name: 'Ford Focus', (err, cars) ->
              cars.length.should.equal 0
              done()

  describe 'helpers', ->
    describe 'hasMany', ->
      it 'should be a function', (done) ->
        should.exist gooser.helpers.hasMany
        gooser.helpers.hasMany.should.be.a 'function'
        done()
