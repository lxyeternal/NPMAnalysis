should = require 'should'
mongoose = require 'mongoose'

{config, fordFocus} = require './sample/mocks'
mongoose.connect config.database.main

describe 'loader', ->
  loader = require '../domain/loader'

  describe 'given nested models', ->
    it 'they should load properly', (done) ->
      loader.loadAll mongoose, config.app.models, (err, models) ->
        should.not.exist err
        should.exist models
        should.exist models.Car
        should.exist models.Engine
        should.exist models.Piston
        should.exist models.Sku
        should.exist models.Statistic
        done()

        describe 'given loaded nested models', ->
          it 'should save properly', (done) ->
            car = new models.Car fordFocus
            car.save (err, doc) ->
              should.not.exist err
              done()

  describe 'given a schema that is not a function', ->
    it 'should throw fireballs', (done) ->
      loader.loadAll mongoose, config.app.badModels, (err, models) ->
        should.exist err
        err.should.equal "Schema: Clunker is not a function."
        done()
