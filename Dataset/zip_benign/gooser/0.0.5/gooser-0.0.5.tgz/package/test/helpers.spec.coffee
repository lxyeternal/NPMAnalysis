should = require 'should'
mongoose = require 'mongoose'
gooser = require '../domain/main'

describe 'helpers', ->

  before (done) ->
    {config} = require './sample/mocks'
    gooser.initialize config, done

  describe 'hasMany', ->
    {hasMany} = require '../domain/helpers'

    it 'should return a collection retriever', (done) ->
      {Engine, Piston} = mongoose.models
      pistons = hasMany 'Engine', Piston
      pistons.should.be.a 'function'

      pistons.call (new Engine), (err, pistons) ->
        pistons.should.be.an.instanceof Array
        done()

  describe 'hasManyWithKeys', ->
    {hasManyWithKeys} = require '../domain/helpers'

    before (done) ->
      {Statistic} = mongoose.models
      Statistic.create
        product: 'foo'
        retailer: 'bar'
        packaging: 'baz'

        startDate: new Date '7/12/1984'
        endDate: new Date '7/26/1984'

        stocked: 8
        sold: 4
        done

    after (done) ->
      {Statistic} = mongoose.models
      Statistic.remove done

    it 'should link on parallel fields', (done) ->
      {Sku, Statistic} = mongoose.models

      statistics = hasManyWithKeys ['product', 'retailer', 'packaging'], Statistic
      statistics.should.be.a 'function'

      sku = new Sku
        product: 'foo'
        retailer: 'bar'
        packaging: 'baz'

      statistics.call sku, (err, statistics) ->
        statistics.should.be.an.instanceof Array
        statistics.length.should.equal 1
        done()

    it 'should allow extensible searching', (done) ->
      {Sku, Statistic} = mongoose.models

      statistics = hasManyWithKeys ['product', 'retailer', 'packaging'], Statistic
      statistics.should.be.a 'function'

      sku = new Sku
        product: 'foo'
        retailer: 'bar'
        packaging: 'baz'

      statistics.call sku, {startDate: {$lte: new Date '7/12/1984'}}, (err, statistics) ->
        statistics.should.be.an.instanceof Array
        statistics.length.should.equal 1
        done()

    it 'should return no results', (done) ->
      {Sku, Statistic} = mongoose.models

      statistics = hasManyWithKeys ['product', 'retailer', 'packaging'], Statistic
      statistics.should.be.a 'function'

      sku = new Sku
        product: 'foo'
        retailer: 'bar'
        packaging: 'baz'

      statistics.call sku, {startDate: new Date}, (err, statistics) ->
        statistics.should.be.an.instanceof Array
        statistics.length.should.equal 0
        done()
