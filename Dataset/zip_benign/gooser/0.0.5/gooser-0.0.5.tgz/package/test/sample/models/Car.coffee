module.exports = (conn) ->
  {Schema} = conn
  {ObjectId} = Schema

  new Schema
    name: String
