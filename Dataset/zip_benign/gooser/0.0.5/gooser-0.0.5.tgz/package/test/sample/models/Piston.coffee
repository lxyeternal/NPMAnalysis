module.exports = (conn) ->
  {Schema} = conn
  {ObjectId} = Schema

  new Schema
    name: String
    engine:
      type: ObjectId
      ref: 'Engine'
      sparse: true
