module.exports = (db) ->
  {Schema, hasManyWithKeys} = db
  {ObjectId} = Schema
  Statistic = db.model 'Statistic'

  new Schema
    name: String

    product: String
    retailer: String
    packaging: String
