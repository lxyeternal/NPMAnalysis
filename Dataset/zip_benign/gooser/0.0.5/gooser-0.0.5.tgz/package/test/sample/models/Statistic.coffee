module.exports = (db) ->
  {Schema} = db
  {ObjectId} = Schema

  new Schema
    name: String

    product: String
    retailer: String
    packaging: String

    startDate: Date
    endDate: Date

    stocked: Number
    sold: Number
