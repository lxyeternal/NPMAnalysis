{join} = require 'path'

module.exports =
  config:
    database:
      main: "mongodb://localhost/gooser_test"
    app:
      models: join __dirname, "./models"
      badModels: join __dirname, "./badModels"

  fordFocus:
    name: 'Ford Focus'

  engine:
    name: 'V8'

  piston:
    name: 'I dont know anything about cars'
