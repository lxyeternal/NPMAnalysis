module.exports = (conn) ->
  {Schema, hasMany} = conn
  {ObjectId} = Schema
  {Piston} = conn.models

  engine = new Schema
    name: String
    car:
      type: ObjectId
      ref: 'Car'
      sparse: true

  engine.methods.pistons = hasMany 'Engine', Piston

  return engine
