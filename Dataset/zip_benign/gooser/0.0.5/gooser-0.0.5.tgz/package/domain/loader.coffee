{inspect} = require 'util'
{join, basename, extname} = require 'path'
{readdir} = require 'fs'
helpers = require './helpers'

errors = []

module.exports =
  loadAll: (conn, dir, cb) ->
    # merge helpers into conn before passing to schema
    # NOTE: this should probably be in loadModel, but I couldn't get it to work there
    for name, fn of helpers
      conn[name] = fn

    readdir dir, (err, files) ->
      cb err if err?
      paths = {}
      paths[basename(file, extname(file))] = join dir, file for file in files
      module.exports.loadModel conn, paths, {}, 0, cb
    return

  loadModel: (conn, paths, models, count, cb) ->
    return cb "Failed to load the following dependencies: #{Object.keys paths}\nerrors:#{errors.join '\n'}" if count > 5
    for name, path of paths
      try
        schemaFn = (require path)
        return cb "Schema: #{name} is not a function." if typeof schemaFn != 'function'

        schema = schemaFn conn
        models[name] = conn.model name, schema
        delete paths[name]
      catch e
        errors.push "#{name}:#{e}"

    return cb null, models if Object.keys(paths).length is 0
    module.exports.loadModel conn, paths, models, ++count, cb
