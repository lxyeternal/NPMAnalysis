# this should be used to define a mongoose method
#   eg: agency.methods.users = hasMany 'Agency', User, 'username'
# `this` will be bound to the model instance
module.exports =
  hasMany: (source, relation, nameField='name') ->

    collection = (cb) ->
      search = {}
      # would like to determine source based on `this` but it doesn't seem to have that property?
      search[source.toLowerCase()] = this._id

      relation.find search, (err, result) ->
        return cb err if err?

        # pull out ID and name of result
        summary = for r in result
          item = {_id: r._id}
          item[nameField] = r[nameField] if nameField?
          item

        cb err, summary

    collection.relation = true

    return collection

  # hasMany extended with ability to specify foreign keys and additional search data
  hasManyWithKeys: (keys, relation) ->

    collection = (search={}, cb) ->

      search[key] = this[key] for key in keys

      relation.find search, (err, result) ->
        return cb err if err?

        # pull out ID and name of result
        summary = for r in result
          item = {id: r._id}
          item[nameField] = r[nameField] if nameField?
          item

        cb err, summary

    collection.relation = true

    return collection
