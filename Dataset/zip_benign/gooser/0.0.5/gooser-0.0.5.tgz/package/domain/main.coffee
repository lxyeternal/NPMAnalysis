mongoose = require 'mongoose'

module.exports =

  # Convenience for tests
  wipe: (config, cb) ->
    async = require 'async'

    mongoose.connect config.database.main

    destroyers = (m.remove.bind m for _, m of mongoose.models)
    async.parallel destroyers, cb

  initialize: (config, cb) ->
    loader = require './loader'

    # Create database connections
    mongoose.connect config.database.main
    module.exports.conn = mongoose

    load = -> loader.loadAll mongoose, config.app.models, cb

    if mongoose.connection.readyState is 2 # not connected yet
      mongoose.connection.on 'open', load
    else
      load()

  helpers: require './helpers'

  conn: null
