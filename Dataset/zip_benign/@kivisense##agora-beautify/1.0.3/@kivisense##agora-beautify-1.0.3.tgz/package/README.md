## @kivisense/agora-beautify

>提供了视频美颜和视频画面亮度调节功能。是[声网web](https://doc.shengwang.cn/doc/rtc/javascript/get-started/quick-start)插件，需要集成在声网Web的SDK中使用。可以在[Demo](https://meta.kivisense.com/agora-kivi-plugin-demo/index.html)查看具体美颜效果。[Demo源码](https://github.com/kivisense/agora-beautify-plugin-integration-demo)

### 使用方法
#### 1. 添加npm包
```
npm i @kivisense/agora-beautify --save
// 如果您的项目中还未添加声网的sdk，则执行以下命令添加
npm i agora-rtc-sdk-ng --save
```

#### 2. 使用插件
```
import AgoraRTC from "agora-rtc-sdk-ng";
import KiviBeautifyExtension from "@kivisense/agora-beautify";

const videoExtension = new KiviBeautifyExtension();

// 注册插件
AgoraRTC.registerExtensions([videoExtension]);

// 创建美颜插件的处理器
const processor = videoExtension.createProcessor();

// 使用声网sdk创建视频
const videoTrack = await AgoraRTC.createCameraVideoTrack();

// 设置视频的处理管道
videoTrack.pipe(processor).pipe(videoTrack.processorDestination);

// 启用美颜插件
processor.enable();

// 设置美颜插件的参数
processor.setOptions({
  beautifyEnabled: true, // 启用美颜功能
  brightnessEnabled: true, // 启用调节亮度功能
  brightness: 0.5, // 画面亮度，0.5表示不调节，范围：0 - 1，
  beautifyStyle: 2, // 美颜风格
})

// 在HTML元素上播放视频
videoTrack.play(document.querySelector('#video-container'));
```

#### 3. 其他
**上述代码仅在本地内网域名（localhost, 127.0.0.1, 192.168.0.*）有效。如需在其他域名使用，请联系op@kivisense.com （并注明标题：“声网美颜”）**

### API

#### KiviBeautifyExtension

*美颜插件类*

**Methods**

createProcessor()
创建一个插件处理器，返回KiviVideoProcessor实例

#### KiviVideoProcessor
*视频处理类*

**Methods**
enable()
启用插件

disable()
关闭插件

setOptions(options)
设置插件相关配置

**options参数说明：**

|参数名|默认值|参数类型|描述|
|-|:-|:-|:-|
|beautifyEnabled |	true |	Boolean |	启用美颜功能|
|beautifyStyle |	1 |	Number |	美颜风格：<br> 1: Beautify <br> 2: Moonlight <br> 3: Sienna <br> 4: Villa <br> 5: Linen <br> 6: Honey <br> 7: Marine <br> 8: Sable  <br> 9: VintageFilm <br> 10: Hongkong <br> 11: River <br> 12: Dusk|
|brightnessEnabled |	true |	Boolean |	启用调节亮度功能 |
|brightness |	0.5 |	Number |	画面亮度，0.5表示不调节，范围：0 - 1|

### 注意
Safari浏览器版本需要大于 15 才能有美颜效果