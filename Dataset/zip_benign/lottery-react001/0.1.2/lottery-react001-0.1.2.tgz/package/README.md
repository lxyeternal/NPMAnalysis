
# Introducing the lottery-react package

    import lottery from 'lottery-react'

# Start a backend service locally on port 9527 with the interface URL /lotterys. 

# Interface request parameter.
  > {  
  > &nbsp;id, // 唯一id  
  > &nbsp;timestamp // 当前的时间戳(秒)  
  > }

# Probabilistic logical interface custom implementation 

# Interface return value.
  ## Note that the value of each probability in the data array is given by itself. The names of each item in the data array must be the same as in the example, in a different order.
  for example:

  > {  
  >   &nbsp;code: 0,  
  >   &nbsp;data: [  
  >     &nbsp;&nbsp;{ name: 'noPrice', probability: 0.4 },  
  >     &nbsp;&nbsp;{ name: 'firstPrice', probability: 0.1},  
  >     &nbsp;&nbsp;{ name: 'secondPrices', probability: 0.1},  
  >     &nbsp;&nbsp;{ name: 'thirdPrices', probability: 0.2 }  
  >   &nbsp;]  
  > }  

# React mounts the node's page and needs to be configured

  `<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->`  
  `<meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport">`