module.exports = ($) ->
  $('.postingBody').html()
