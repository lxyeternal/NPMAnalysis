require('./default.css');
var DataV = require('dchart-force-image');
var d3 = require('d3');
var _ = require('dchart-core/util');

/**
 * 力引导图
 * @param container
 * @param options
 * @constructor
 */
function Force(container, options) {
  var opt = {
    maxRadius: 40,
    radius: 20,
    paxis : {
      key : 'pvalue'
    }
  };
  opt = _.deepMerge(opt, options);
  DataV.call(this, container, opt);
}

Force = DataV.extend(Force, {
  afterRender : function () {
    DataV.prototype.afterRender.call(this);
    var opt = this.options;
    var r = opt.radius;
    var pkey = opt.paxis.key;
    var arc = d3.svg.arc()
      .innerRadius(r)
      .outerRadius(r + 6)
      .startAngle(0)
      .endAngle(function(d) {
        var value = d[pkey] || 0;
        value = value > 1 ? 1 : value;
        return value * Math.PI;
      });
    this.nodeEnter.append("path")
      .attr({
        "d": arc
      }).style({
        "fill": "#3acee2",
        "stroke": "none"
      });
  },
  updateAfterRender : function () {
    DataV.prototype.updateAfterRender.call(this);
    this.afterRender();
  }
});

module.exports = Force;
