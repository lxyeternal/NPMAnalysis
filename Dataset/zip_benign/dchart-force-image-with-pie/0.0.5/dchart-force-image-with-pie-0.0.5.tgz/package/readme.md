dchart-force-image-with-pie

符合dchart规范的带图力引导图，外部有饼图

### 安装

```
npm install dchart-force-image-with-pie
```

### 用法
```
var Force = require('dchart-force-image-with-pie');
var force = new Force(this.selector, {
  paxis: {key: 'pvalue'}
});
force.render({
  nodes: [{
    index: 0,
    x: 250,
    y: 150,
    imgPath: '',
    name: 'hello',
    className: 'group1',
    pvalue: 0.6
  },{
    index: 1,
    x: 250,
    y: 150,
    imgPath: 'iconfont-yulan.png',
    name: 'hello',
    className: 'train',
    pvalue: 0.4
  }],
  links: [{
    source: 0,
    target: 1
  }]
});
```

### 案例
```
在根目录下, 启动
cube start
访问路径
http://localhost:9999/demo/test.html
```
