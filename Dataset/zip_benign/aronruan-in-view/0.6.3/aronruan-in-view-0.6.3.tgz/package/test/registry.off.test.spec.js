import test from 'ava';
import Registry from '../src/registry';

test('Registry.off removes all handlers', t => {

  let registry = Registry([]);
  const enter1 = () => {}
  registry.on('enter', enter1);
  t.true(registry.handlers.enter.length === 1);

  const exit1 = () => {}
  registry.on('exit', exit1);
  t.true(registry.handlers.exit.length === 1);

  registry.off('enter', enter1);
  t.true(registry.handlers.enter.length === 0);

  registry.off('exit', exit1);
  t.true(registry.handlers.exit.length === 0);

});

test('Registry.off returns the registry', t => {
  let registry = Registry([]);
  t.deepEqual(registry.off('enter'), registry);
});