# rainforest-echo-sounds

`rainforest-echo-sounds` is a JavaScript library that leverages the Howler.js API to play rainforest echo sounds. This library is designed to provide an easy-to-use interface for playing, stopping, and managing the volume of multiple sounds simultaneously, perfect for creating immersive audio experiences in web applications.

## Installation

You can install `rainforest-echo-sounds` via npm:

```bash
npm install rainforest-echo-sounds
```

## Usage

First, import `RainforestEchoSounds` into your project:

```javascript
import RainforestEchoSounds from 'rainforest-echo-sounds';
```

### Initializing

To use `RainforestEchoSounds`, start by creating an instance and passing an array of sound URLs you wish to play:

```javascript
const soundUrls = ['path/to/sound1.mp3', 'path/to/sound2.mp3'];
const rainforestSounds = new RainforestEchoSounds(soundUrls);
```

### Play All Sounds

To play all sounds simultaneously:

```javascript
rainforestSounds.playAll();
```

### Stop All Sounds

To stop all sounds:

```javascript
rainforestSounds.stopAll();
```

### Set Volume

To set the volume for all sounds (volume range is 0.0 to 1.0):

```javascript
rainforestSounds.setVolume(0.5); // Sets volume to 50%
```

### Mute/Unmute All Sounds

To mute all sounds:

```javascript
rainforestSounds.muteAll(true);
```

To unmute:

```javascript
rainforestSounds.muteAll(false);
```

## Contributing

Contributions are welcome! Please feel free to submit a pull request.

## License

`rainforest-echo-sounds` is MIT licensed.
