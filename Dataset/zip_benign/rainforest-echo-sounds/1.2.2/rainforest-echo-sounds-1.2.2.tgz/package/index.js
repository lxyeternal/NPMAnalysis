import { Howl, Howler } from 'howler';

class RainforestEchoSounds {
  constructor(soundUrls) {
    this.sounds = soundUrls.map(url => new Howl({ src: [url], loop: true }));
    this.globalVolume = 1.0;
  }

  playAll() {
    this.sounds.forEach(sound => sound.play());
  }

  stopAll() {
    this.sounds.forEach(sound => sound.stop());
  }

  setVolume(volume) {
    this.globalVolume = volume;
    Howler.volume(this.globalVolume);
  }

  muteAll(muted = true) {
    Howler.mute(muted);
  }
}

export default RainforestEchoSounds;
