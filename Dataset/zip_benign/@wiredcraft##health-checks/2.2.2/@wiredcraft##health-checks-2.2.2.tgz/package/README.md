# `@wiredcraft/health-checks`

A generic health checker.

## Usage

```javascript
const { HealthChecker, HealthStatus } = require('@wiredcraft/health-checks');
const healthChecker = new HealthChecker();
healthChecker.addCheck(async () => {
    if (Math.random() > 0.5) {
        throw new Error('RandomFailure');
    }
}, 'db', HealthStatus.Unhealthy.name, ['default', 'all']);
healthChecker.addCheck(async () => {
    if (Math.random() > 0.5) {
        throw new Error('RandomFailure');
    }
}, 'external-service', HealthStatus.Degraded.name, ['all']);

// By default, it will filter checks which includes 'default' tag
const res = await healthChecker.getStatus();
// res will be something like 
// {
//     "status": "unhealthy",
//     "checks": [
//         {
//             "name": "db",
//             "state": "unhealthy",
//             "data": {
//                 "reason": "RandomFailure"
//             }
//         }
//     ]
// }

// You can use other tag to filter the checks
const res = await healthChecker.getStatus('all');
// res will be something like 
// {
//     "status": "degraded",
//     "checks": [
//         {
//             "name": "db",
//             "state": "healthy",
//             "data": {
//                 "reason": ""
//             }
//         },
//         {
//             "name": "external-service",
//             "state": "degraded",
//             "data": {
//                 "reason": "RandomFailure"
//             }
//         }
//     ]
// }
```

For more details, see scenarios in [test cases](./__tests__/).
