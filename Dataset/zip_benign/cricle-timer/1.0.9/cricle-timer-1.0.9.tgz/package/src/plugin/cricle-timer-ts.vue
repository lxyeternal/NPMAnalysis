<template>
  <div class="circle-timer__wrapper">
    <svg
      class="circle-timer__svg"
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g class="circle-timer__circle">
        <circle
          class="circle-timer__path-elapsed"
          cx="50"
          cy="50"
          r="45"
        ></circle>
        <path
          :stroke-dasharray="strokeDashArray"
          class="circle-timer__path-remaining"
          :style="{ color: pathColor }"
          d="
            M 50, 50
            m -45, 0
            a 45,45 0 1,0 90,0
            a 45,45 0 1,0 -90,0
          "
        ></path>
      </g>
    </svg>
    <span class="circle-timer__label">
      {{ time }}
    </span>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";

@Component({
  name: "CricleTimer",
})
export default class extends Vue {
  // 结束时间，单位s
  @Prop({
    default: 0,
  })
  endTime!: number;

  // 开始时间，单位s
  @Prop({
    required: true,
    default: 10,
  })
  startTime!: number;

  // 间隔时间，单位s，倒计时为负数，正计时为正数
  @Prop({
    default: -1,
  })
  step!: number;

  // 计时结束事件
  @Prop({
    required: true,
    default: () => {
      console.log("结束");
    },
  })
  onFinished!: any;

  // 阶段阈值，以及颜色变化。
  @Prop({
    required: true,
  })
  thresholds!: any;

  FULL_DASH_ARRAY = 283;

  DEFAULT_COLOR = "#FFE2AA";

  time = 0;

  timer: any;

  timeLimit = 0;

  created() {
    this.time = this.startTime;
    this.timeLimit = Math.abs(Number(this.startTime) - Number(this.endTime));
  }
  // 路径颜色
  get pathColor() {
    let result = this.DEFAULT_COLOR;
    if (Array.isArray(this.thresholds)) {
      this.thresholds
        .sort((a: any, b: any) => a.threshold - b.threshold)
        .some((item: any) => {
          if (this.time <= Number(this.timeLimit) * item.threshold) {
            // 根据当前时间获取距离最近的阈值的颜色
            result = item.color;
            return true;
          }
          return false;
        });
    }
    return result;
  }

  // stroke虚线数组
  get strokeDashArray() {
    // 圆滑过渡
    const rawTimeFraction = Number(this.time) / Number(this.timeLimit);
    const timeFraction =
      rawTimeFraction - (1 / Number(this.timeLimit)) * (1 - rawTimeFraction);
    // console.log(111, Number(this.time), Number(this.timeLimit));
    return `${(timeFraction * this.FULL_DASH_ARRAY).toFixed(0)} ${
      this.FULL_DASH_ARRAY
    }`;
  }

  mounted() {
    this.timer = setInterval(() => {
      // step>0正计时 和 step<0倒计时
      if (
        (this.step < 0 && this.time <= this.endTime) ||
        (this.step > 0 && this.time >= this.endTime)
      ) {
        this.onFinished();
        clearInterval(this.timer);
      } else {
        const cur = Number(this.time) + Number(this.step);
        this.time = cur <= 0 ? 0 : cur;
      }
    }, Math.abs(Number(this.step)) * 1000);
  }

  beforeDestroye() {
    clearInterval(this.timer);
  }
}
</script>
<style scoped>
.circle-timer__wrapper {
  position: relative;
  width: 100px;
  height: 100px;
  margin: auto;
  text-align: center;
}

.circle-timer__svg {
  /* -1逆时针 1顺时针 */
  transform: scaleX(1);
}

.circle-timer__circle {
  fill: none;
  stroke: none;
}

.circle-timer__path-elapsed {
  stroke-width: 8px;
  stroke: rgba(255, 255, 255, 0.2);
}

.circle-timer__path-remaining {
  stroke-width: 8px;
  stroke-linecap: round;
  transform: rotate(90deg);
  transform-origin: center;
  transition: 1s linear all;
  fill-rule: nonzero;
  stroke: currentColor;
}

.circle-timer__label {
  position: absolute;
  width: 100px;
  height: 100px;
  top: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
}
</style>
