//把所有要注册的组件引入
import { Component } from "vue";
import CricleTimer from "./cricle-timer-ts.vue";

//定义接口，其中有一个install的方法
interface GlobalComponents {
  install: (app: any) => void;
}

//定义数组，存放所有引入的组件
const componentsArr: Component[] = [];
componentsArr.push(CricleTimer); //把准备注册的组件存入数组
console.log(componentsArr);
//  定义一个对象
const aiComponents: GlobalComponents = {
  install(Vue) {
    componentsArr.map((item: Component) => {
      //遍历注册全局组件
      Vue.component(item.name!, item);
    });
  },
};
//item.name  即组件的name （名字）

export default aiComponents; //导出对象
