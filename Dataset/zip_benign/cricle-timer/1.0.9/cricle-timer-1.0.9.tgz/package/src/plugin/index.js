import CricleTimer from "./cricle-timer-ts.vue";

export default {
  install(Vue) {
    Vue.component("cricle-timer", CricleTimer);
  },
};
