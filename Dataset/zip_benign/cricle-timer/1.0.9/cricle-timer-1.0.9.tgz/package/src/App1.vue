<template>
  <div id="app">
    <cricle-timer
      :start-time="5"
      :on-finished="finished"
      :thresholds="[
        { color: '#FFE2AA', threshold: 0.5 },
        { color: 'red', threshold: 0.25 },
      ]"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

export default class App extends Vue {
  circles: any = [
    {
      id: "1",
      steps: 10,
      size: 100,
      strokeColor: "green",
    },
  ];

  finished() {
    console.log("倒计时结束");
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
