import Vue from "vue";
import App from "./App1.vue";
// import CricleTimer from "cricle-timer";
import aiComponents from "./plugin/index";
// import { CricleTimer } from "./plugin/index.js";
Vue.use(aiComponents);
Vue.config.productionTip = false;

new Vue({
  render: (h) => h(App),
}).$mount("#app");
