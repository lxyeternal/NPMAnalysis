Tone Patch
===========

Simple ways to define and share tonejs patches.

A simple patch looks like the following:

```
export const create = (Tone, destination, opts, done) => {
  let bell = new Tone.MetalSynth({
    harmonicity : 12,
    resonance : 800,
    modulationIndex : 20,
    envelope : {
      decay : 0.4,
    },
    volume : -15
  })
  bell.connect(destination)

  let bellPart = new Tone.Sequence((time, freq) => {
    bell.frequency.setValueAtTime(freq, time, Math.random()*0.5 + 0.5)
    bell.triggerAttack(time)
  }, [[300, null, 200],
      [null, 200, 200],
      [null, 200, null],
      [200, null, 200]
  ], "4n")

  let start = when => bellPart.start(when)
  let stop = when => bellPart.stop(when)
  done(null, {start, stop})
}
```

The above patch will play a cowbell sound in a pattern (aligned to the bpm), when start is called, and stop when stop is called.

Now to load and start the patch, we would do the following

```
  const Tone = require('tone')
  const tonePatch = require('tone-patch')
  const patchUrl = 'http://localhost:51051/0.js'
  let channel = new Tone.Channel().toMaster()
  tonePatch.createPatch(Tone, channel, patchUrl, (err, patch) => {
    if (err) return console.log(err)
    Tone.Transport.start()
    patch.start()
    setTimeout(() => patch.stop(), 5000) // stop the patch after 5 seconds
  })
```
