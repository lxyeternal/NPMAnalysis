const _ = require('lodash')
const url = require('url')
const Joi = require('joi-browser')
const tonal = require('tonal')
const ScriptSchema = require('./schemas/script')
const AboutSchema = require('./schemas/about')
const InstanceSchema = require('./schemas/instance')
const getNextPosition = require('./getNextPosition')

exports.createPatch = function (Tone, destination, patchUrl, options, done) {
  if (!done && typeof options === 'function') {
    done = options
    options = {}
  }

  exports.readPatch(patchUrl, (err, patch) => {
    if (err) return done(err)
    let {patchDfn, basePath, resources, about} = patch

    let setup = { basePath, resources, tonal, options }
    setup.getNextPosition = getNextPosition.bind(Tone)

    patchDfn.create(Tone, destination, setup, (err, instance) => {
      if (err) return done(err)
      const instanceResult = Joi.validate(instance, InstanceSchema)
      if (instanceResult.error) return done(instanceResult.error)

      let wrappedInstance = exports.wrap(about, instance)

      done(err, wrappedInstance)
    })
  })
}

exports.wrap = function (about, instance) {
  instance.info = about || {}
  if (!instance.triggerAttackRelease) instance.triggerAttackRelease = () => {}
  if (!instance.triggerAttack) instance.triggerAttack = () => {}
  if (!instance.triggerRelease) instance.triggerRelease = () => {}
  if (instance.turnKnob) {
    let targetFunc = instance.turnKnob
    instance.turnKnob = (knob, value) => {
      if (typeof knob !== 'number') throw new Error('knob must be a number')
      if (knob < 0) throw new Error('knob must be greater than 0')
      if (about.knobs && about.knobs.length < knob) throw new Error(`knob must be a number less than ${about.knobs.length}`)
      if (typeof value !== 'number') throw new Error('value must be a number')
      if (value < 0 || value > 127) throw new Error('value must be a number between 0 and 127')
      targetFunc(knob, value)
    }
  }
  return instance
}


exports.readPatch = function (patchUrl, done) {
  import(patchUrl).catch(e => done(e)).then(patchDfn => {
    let basePath = url.resolve(patchUrl, '.')

    const result = Joi.validate(patchDfn, ScriptSchema)
    if (result.error) return done(result.error)
    if (!patchDfn.about) return done(null, {patchDfn, basePath, resources: [], about: {}})

    let about = patchDfn.about()
    const aboutResult = Joi.validate(about, AboutSchema)
    if (aboutResult.error) return done(result.error)

    let resources = resolvePatchResorces(basePath, about)
    done(null, {patchDfn, basePath, resources, about})
  })
}

function resolvePatchResorces (basePath, about) {
  let resources = []
  if (about.resources && about.resources.length) resources = about.resources.map(r => url.resolve(basePath, r))
  return resources
}
