const Joi = require('joi-browser')

module.exports = Joi.object().keys({
  name: Joi.string().description('a name'),
  resources: Joi.array().items(Joi.string()).description('relative or absoulte urls of resources'),
  knobs: Joi.array().items(Joi.object().keys({
    name: Joi.string().description('short name of the knob'),
    description: Joi.string().description('short description of the knob')
  }))
})
