const Joi = require('joi-browser')

module.exports = Joi.object().keys({
  about: Joi.func().arity(0), // should return an About schema
  create: Joi.func().arity(4) // creates a patch instance schema TODO: Make required
})
