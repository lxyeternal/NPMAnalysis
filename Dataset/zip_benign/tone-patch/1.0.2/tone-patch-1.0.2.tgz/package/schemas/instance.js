const Joi = require('joi-browser')

module.exports = Joi.object().keys({
  start: Joi.func().arity(1),
  stop: Joi.func().arity(1),
  dispose: Joi.func().arity(0),
  triggerAttackRelease: Joi.func().arity(4),
  triggerAttack: Joi.func().arity(2),
  triggerRelease: Joi.func().arity(1),
  turnKnob: Joi.func().arity(2)
})
