import Game from "./game.js";

Component({
  mixins: [],
  data: { show: false },
  props: { gameSource: null },
  didMount() {
    let uniId = this.uniId();
    my.fEvent = my.fEvent || {};
    this.fProps = this.props || {};
    if (Object.keys(this.fProps).length == 1) {
      this.fProps = this.$attrs;
    }
    for (let name in this.fProps) {
      if (name.indexOf("on") == 0) {
        // 事件
        // 当前组件的方法
        my.fEvent[`fc_component_${uniId}_${name}`] = () => { try { this[name](); } catch (e) { } };
        // 页面传进来的方法
        my.fEvent[`fc_${uniId}_${name}`] = this.fProps[name];
      }
    }
    this.setData({
      uniId: uniId,
      show: true
    })
  },
  didUpdate() { },
  didUnmount() {
    for (let name in this.fProps) {
      if (name.indexOf("on") == 0) {
        // 事件
        my.fEvent[`fc_${uniId}_${name}`] = null;
      }
    }
  },
  methods: {
    uniId: function () {
      let ranNum = parseInt(Math.random() * 10000 % 1000);
      let now = Date.now();
      return "unid-" + ranNum + "-" + now + "-" + now * ranNum;
    },
    onGetGame() {
      return Game;
    }
  },
});