import { expect } from "chai";
import { hexToRgba } from "./hex-to-rgba.js";

describe("hexToRgba", () => {
	it("returns RGB values correctly", () => {
		expect(hexToRgba("#000000")).eq("rgb(0, 0, 0)");
		expect(hexToRgba("#4328e7")).eq("rgb(67, 40, 231)");
		expect(hexToRgba("#9654e5")).eq("rgb(150, 84, 229)");
		expect(hexToRgba("#ff6283")).eq("rgb(255, 98, 131)");
		expect(hexToRgba("#1aa7ee")).eq("rgb(26, 167, 238)");
		expect(hexToRgba("#007d8e")).eq("rgb(0, 125, 142)");
		expect(hexToRgba("#c11f1f")).eq("rgb(193, 31, 31)");
		expect(hexToRgba("#730000")).eq("rgb(115, 0, 0)");
		expect(hexToRgba("#019c00")).eq("rgb(1, 156, 0)");
	});
	it("returns RGBA values correctly", () => {
		expect(hexToRgba("#000000", 0.2)).eq("rgba(0, 0, 0, 0.2)");
		expect(hexToRgba("#4328e7", 0.6)).eq("rgba(67, 40, 231, 0.6)");
		expect(hexToRgba("#9654e5", 0.8)).eq("rgba(150, 84, 229, 0.8)");
		expect(hexToRgba("#ff6283", 0.3)).eq("rgba(255, 98, 131, 0.3)");
		expect(hexToRgba("#1aa7ee", 0.25)).eq("rgba(26, 167, 238, 0.25)");
		expect(hexToRgba("#007d8e", 0.55)).eq("rgba(0, 125, 142, 0.55)");
		expect(hexToRgba("#c11f1f", 1)).eq("rgb(193, 31, 31)");
		expect(hexToRgba("#730000", 0.9)).eq("rgba(115, 0, 0, 0.9)");
		expect(hexToRgba("#019c00", 0.62)).eq("rgba(1, 156, 0, 0.62)");
	});
});
