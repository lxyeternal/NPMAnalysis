import { getAPCAContrast } from "./apca-contrast.js";

export function isPaleBackground(background_hex) {
	if (!background_hex) {
		console.warn("No valid color", background_hex);
		return;
	}

	const black_contrast = getAPCAContrast("#000000", background_hex);
	const white_contrast = getAPCAContrast("#ffffff", background_hex);
	return white_contrast < black_contrast ? true : false;
}
