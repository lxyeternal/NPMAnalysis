import { getAPCAContrast } from "./apca-contrast.js";

export function isPaleText(text_hex) {
	if (!text_hex) {
		console.warn("No valid color", text_hex);
		return;
	}

	const black_contrast = getAPCAContrast(text_hex, "#000000");
	const white_contrast = getAPCAContrast(text_hex, "#ffffff");
	return white_contrast < black_contrast ? true : false;
}
