import { sRGBtoY, APCAcontrast } from "apca-w3";
import { hexToColor } from "./hex-to-color.js";

export function getAPCAContrast(text_hex, background_hex) {
	if (!text_hex || !background_hex) {
		console.warn("No valid color", text_hex, background_hex);
		return;
	}
	const text_y = sRGBtoY(Object.values(hexToColor(text_hex)));
	const background_y = sRGBtoY(Object.values(hexToColor(background_hex)));
	return Math.abs(APCAcontrast(text_y, background_y));
}
