import { color } from "d3-color";

export function hexToColor(hex_string, opacity) {
	if (typeof hex_string != "string") return false;
	var c = color(hex_string);
	c.opacity = opacity !== undefined ? opacity : 1;

	return c;
}
