import { expect } from "chai";
import { rgb } from "d3-color";
import { hexToColor } from "./hex-to-color.js";

describe("hexToColor", () => {
	it("returns RGB colors correctly", () => {
		expect(hexToColor("#000000")).deep.eq(rgb(0, 0, 0));
		expect(hexToColor("#4328e7")).deep.eq(rgb(67, 40, 231));
		expect(hexToColor("#9654e5")).deep.eq(rgb(150, 84, 229));
		expect(hexToColor("#ff6283")).deep.eq(rgb(255, 98, 131));
		expect(hexToColor("#1aa7ee")).deep.eq(rgb(26, 167, 238));
		expect(hexToColor("#007d8e")).deep.eq(rgb(0, 125, 142));
		expect(hexToColor("#c11f1f")).deep.eq(rgb(193, 31, 31));
		expect(hexToColor("#730000")).deep.eq(rgb(115, 0, 0));
		expect(hexToColor("#019c00")).deep.eq(rgb(1, 156, 0));
	});
});
