import { expect } from "chai";
import { isPaleBackground } from "./is-pale-background.js";

describe("isPaleBackground", () => {
	it("returns false where the background color contrasts more with white than black", () => {
		expect(isPaleBackground("#000000")).eq(false);
		expect(isPaleBackground("#4328e7")).eq(false);
		expect(isPaleBackground("#9654e5")).eq(false);
		expect(isPaleBackground("#ff6283")).eq(false);
		expect(isPaleBackground("#1aa7ee")).eq(false);
		expect(isPaleBackground("#007d8e")).eq(false);
		expect(isPaleBackground("#c11f1f")).eq(false);
		expect(isPaleBackground("#730000")).eq(false);
		expect(isPaleBackground("#019c00")).eq(false);
	});
	it("returns true where the background color contrasts more with black than white", () => {
		expect(isPaleBackground("#ffffff")).eq(true);
		expect(isPaleBackground("#ff8800")).eq(true);
		expect(isPaleBackground("#ffc502")).eq(true);
		expect(isPaleBackground("#29dae4")).eq(true);
		expect(isPaleBackground("#88e99a")).eq(true);
	});
});
