import { expect } from "chai";
import { isPaleText } from "./is-pale-text.js";

describe("isPaleText", () => {
	it("returns false where the text color contrasts more with white than black", () => {
		expect(isPaleText("#000000")).eq(false);
		expect(isPaleText("#4328e7")).eq(false);
		expect(isPaleText("#9654e5")).eq(false);
		expect(isPaleText("#ff6283")).eq(false);
		expect(isPaleText("#1aa7ee")).eq(false);
		expect(isPaleText("#007d8e")).eq(false);
		expect(isPaleText("#c11f1f")).eq(false);
		expect(isPaleText("#730000")).eq(false);
		expect(isPaleText("#019c00")).eq(false);
	});
	it("returns true where the text color contrasts more with black than white", () => {
		expect(isPaleText("#ffffff")).eq(true);
		expect(isPaleText("#ff8800")).eq(true);
		expect(isPaleText("#ffc502")).eq(true);
		expect(isPaleText("#29dae4")).eq(true);
		expect(isPaleText("#88e99a")).eq(true);
	});
});
