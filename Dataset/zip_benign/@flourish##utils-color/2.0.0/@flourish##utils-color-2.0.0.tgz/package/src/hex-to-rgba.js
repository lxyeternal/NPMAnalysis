import { hexToColor } from "./hex-to-color.js";

export function hexToRgba(hex_string, opacity) {
	var c = hexToColor(hex_string, opacity);

	return c ? c.toString() : false;
}
