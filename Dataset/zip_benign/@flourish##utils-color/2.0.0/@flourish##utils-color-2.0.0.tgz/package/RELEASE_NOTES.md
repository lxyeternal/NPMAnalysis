# 2.0.0
* Switch to preferring ESM by default on recent versions of Node.js by adding an `exports` field to `package.json`.
* Run build script as part of `prepublishOnly` instead of `prepare`.

# 1.0.2
* Internal: use `.js` extension for importing modules.

# 1.0.1
* Use new module in templates (version number used to increment template versions)

# 1.0.0
* Add `hexToRgba`, `hexToColor`, `isPaleText` and `isPaleBackground`
