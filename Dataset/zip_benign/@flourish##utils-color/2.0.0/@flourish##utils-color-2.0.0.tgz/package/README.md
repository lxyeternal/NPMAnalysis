# flourish-utils-color

### hexToColor(hex_string, opacity)
Converts hex to d3 color object as described [here](https://github.com/d3/d3-color#color)
```
hexToColor("#00ff00", 0.5); // {r: 0, g: 255, b: 0, a: 0.5}
```

### hexToRgba(hex_string, opacity)
Converts hex to rgba string
```
hexToRgba("#00ff00", 0.5); // rgba(0, 255, 0, 0.5)
```

### isPaleBackground(background_color)
Returns if color is pale or not as a background color, according to APCA color contrast checking.

### isPaleText(text_color)
Returns if color is pale or not as a text color, according to APCA color contrast checking.