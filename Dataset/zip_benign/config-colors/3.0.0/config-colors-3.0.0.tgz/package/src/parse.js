function parseObject(obj) {
    let r, g, b;

    if (obj.hasOwnProperty('r') && Number.isInteger(obj.r) &&
        obj.hasOwnProperty('g') && Number.isInteger(obj.g) &&
        obj.hasOwnProperty('b') && Number.isInteger(obj.b)
    ) {
        r = obj.r;
        g = obj.g;
        b = obj.b
    } else {
        throw new Error("Invalid Color object passed.");
    }

    return {r, g, b};
}

function parseHex(hex) {
    let parse3 = /^#?([0-9a-fA-F])([0-9a-fA-F])([0-9a-fA-F])$/.exec(hex);
    let parse6 = /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/.exec(hex);

    let r, g, b;

    if (parse3) {
        r = parseInt(parse3[1], 16) * 17;
        g = parseInt(parse3[2], 16) * 17;
        b = parseInt(parse3[3], 16) * 17;
    } else if (parse6) {
        r = parseInt(parse6[1], 16);
        g = parseInt(parse6[2], 16);
        b = parseInt(parse6[3], 16);
    } else {
        throw new Error("Invalid hex string passed: " + hex);
    }

    return {r, g, b};
}

function parseRgb(r, g, b) {
    if (r < 0 || r > 255) {
        throw new Error("r value is out of range (0-255): " + r);
    }
    if (g < 0 || g > 255) {
        throw new Error("g value is out of range (0-255): " + g);
    }
    if (b < 0 || b > 255) {
        throw new Error("b value is out of range (0-255): " + b);
    }

    return {r, g, b};
}

export {parseObject, parseHex, parseRgb};
