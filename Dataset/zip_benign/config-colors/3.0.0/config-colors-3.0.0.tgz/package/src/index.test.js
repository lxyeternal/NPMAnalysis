import chai from 'chai';
import Color from './index.js';

const expect = chai.expect;

describe("Color", () => {
    describe("constructor() with numerical parameters", () => {
        it('returns a Color object when three in-range parameters are passed', () => {
            expect(new Color(0, 0, 0)).to.be.an.instanceOf(Color);
            expect(new Color(255, 255, 255)).to.be.an.instanceOf(Color);
        });

        it('throws an error if no parameters are specified', () => {
            expect(() => (new Color())).to.throw();
        });
        it('throws an error if only one parameter is specified', () => {
            expect(() => (new Color(1))).to.throw();
        });
        it('throws an error if only two parameters are specified', () => {
            expect(() => (new Color(1, 2))).to.throw();
        });

        it('throws an error if a parameter is less than 0', () => {
            expect(() => (new Color(-1, 0, 0))).to.throw();
            expect(() => (new Color(0, -1, 0))).to.throw();
            expect(() => (new Color(0, 0, -1))).to.throw();
        });

        it('throws an error if a parameter is greater than 255', () => {
            expect(() => (new Color(256, 0, 0))).to.throw();
            expect(() => (new Color(0, 256, 0))).to.throw();
            expect(() => (new Color(0, 0, 256))).to.throw();
        });
    });

    describe('constructor() with object parameter', () => {
        it('returns a Color object when a Color object is passed', () => {
            const input = new Color(0, 0, 0);
            expect(new Color(input)).to.be.an.instanceOf(Color);
        });

        it('returns a Color object when a Color-like structure is passed (including r, g and b)', () => {
            const input = {r: 0, g:0, b:0};
            expect(new Color(input)).to.be.an.instanceOf(Color);
        });

        it('thrown an error if additional parameters are supplied', () => {
            const input = new Color(0, 0, 0);
            expect(() => (new Color(input, 255, 255))).to.throw();
        });

        it('throws an error if the r property is missing', () => {
            let input = {g: 0, b: 0};
            expect(() => (new Color(input))).to.throw();
        });

        it('throws an error if the g property is missing', () => {
            let input = {r: 0, b: 0};
            expect(() => (new Color(input))).to.throw();
        });

        it('throws an error if the b property is missing', () => {
            let input = {r: 0, g: 0};
            expect(() => (new Color(input))).to.throw();
        })
    });

    describe('constructor() with hex string parameter', () => {
        it('returns a Color object when a valid 3-digit hex string is passed with leading #', () => {
            expect(new Color('#000')).to.be.an.instanceOf(Color);
            expect(new Color('#FFF')).to.be.an.instanceOf(Color);
            expect(new Color('#fff')).to.be.an.instanceOf(Color);
        });
        it('returns a Color object when a valid 3-digit hex string is passed without leading #', () => {
            expect(new Color('000')).to.be.an.instanceOf(Color);
            expect(new Color('FFF')).to.be.an.instanceOf(Color);
            expect(new Color('fff')).to.be.an.instanceOf(Color);
        });
        it('returns a Color object when a valid 6-digit hex string is passed with leading #', () => {
            expect(new Color('#000000')).to.be.an.instanceOf(Color);
            expect(new Color('#FFFFFF')).to.be.an.instanceOf(Color);
            expect(new Color('#ffffff')).to.be.an.instanceOf(Color);
        });
        it('returns a Color object when a valid 6-digit hex string is passed without leading #', () => {
            expect(new Color('000000')).to.be.an.instanceOf(Color);
            expect(new Color('FFFFFF')).to.be.an.instanceOf(Color);
            expect(new Color('ffffff')).to.be.an.instanceOf(Color);
        });

        it('throws an error if a different length hex string is passed with leading #', () => {
            expect(() => (new Color('#0'))).to.throw();
            expect(() => (new Color('#00'))).to.throw();
            expect(() => (new Color('#0000'))).to.throw();
            expect(() => (new Color('#00000'))).to.throw();
            expect(() => (new Color('#0000000'))).to.throw();
        });
        it('throws an error if a different length hex string is passed without leading #', () => {
            expect(() => (new Color('0'))).to.throw();
            expect(() => (new Color('00'))).to.throw();
            expect(() => (new Color('0000'))).to.throw();
            expect(() => (new Color('00000'))).to.throw();
            expect(() => (new Color('0000000'))).to.throw();
        });

        it('throws an error if a character in the hex string is out of range', () => {
            expect(() => (new Color('G00'))).to.throw();
            expect(() => (new Color('0G0'))).to.throw();
            expect(() => (new Color('00G'))).to.throw();
            expect(() => (new Color('G00000'))).to.throw();
            expect(() => (new Color('0G0000'))).to.throw();
            expect(() => (new Color('00G000'))).to.throw();
            expect(() => (new Color('000G00'))).to.throw();
            expect(() => (new Color('0000G0'))).to.throw();
            expect(() => (new Color('00000G'))).to.throw();
        });
    });

    describe('toString()', () => {
        let black, white, red, green, blue;

        beforeEach(() => {
            black = new Color('#000');
            white = new Color ('#FFF');
            red = new Color('#F00');
            green = new Color('#0F0');
            blue = new Color('#00F');
        });

        it('returns a string', () => {
            expect(black.toString()).to.be.a('string');
            expect(white.toString()).to.be.a('string');
            expect(red.toString()).to.be.a('string');
            expect(green.toString()).to.be.a('string');
            expect(blue.toString()).to.be.a('string');
        });

        it('returns a hex string', () => {
            expect(black.toString()).to.equal('#000000');
            expect(white.toString()).to.equal('#ffffff');
            expect(red.toString()).to.equal('#ff0000');
            expect(green.toString()).to.equal('#00ff00');
            expect(blue.toString()).to.equal('#0000ff');
        });
    });

    describe('toHsl()', () => {
        it('converts black correctly', () => {
            let black = new Color('#000');
            expect(black.toHsl()).to.deep.equal({h: 0, s: 0, l: 0});
        });
        it('converts white correctly', () => {
            let white = new Color('#fff');
            expect(white.toHsl()).to.deep.equal({h: 0, s: 0, l: 1});
        });
        it('converts red correctly', () => {
            let red = new Color('#f00');
            expect(red.toHsl()).to.deep.equal({h: 0, s: 1, l: 0.5});
        });
        it('converts green correctly', () => {
            let green = new Color('#0f0');
            expect(green.toHsl()).to.deep.equal({h: 1/3, s: 1, l: 0.5});
        });
        it('converts blue correctly', () => {
            let black = new Color('#00f');
            expect(black.toHsl()).to.deep.equal({h: 2/3, s: 1, l: 0.5});
        });
    });

    describe('adjust()', () => {
        let baseColor;

        beforeEach(() => {
            baseColor = new Color('#f00');
        });

        it('produces a darker colour with a negative input', () => {
            const darker = baseColor.adjust(-5);
            expect(darker.toHsl().l).to.be.at.most(baseColor.toHsl().l);
        });

        it('produces a lighter colour with a positive input', () => {
            const lighter = baseColor.adjust(5);
            expect(lighter.toHsl().l).to.be.at.least(baseColor.toHsl().l);
        });
    });

    describe('light(), lighter(), lightest()', () => {
        it('produces progressively lighter colours', () => {
            let baseColor = new Color('#f00');

            expect(baseColor.light().toHsl().l).to.be.at.least(baseColor.toHsl().l);
            expect(baseColor.lighter().toHsl().l).to.be.at.least(baseColor.light().toHsl().l);
            expect(baseColor.lightest().toHsl().l).to.be.at.least(baseColor.lighter().toHsl().l);

            baseColor = new Color('#777');

            expect(baseColor.light().toHsl().l).to.be.at.least(baseColor.toHsl().l);
            expect(baseColor.lighter().toHsl().l).to.be.at.least(baseColor.light().toHsl().l);
            expect(baseColor.lightest().toHsl().l).to.be.at.least(baseColor.lighter().toHsl().l);
        });
    });

    describe('dark(), darker(), darkest()', () => {
        it('produces progressively darker colours', () => {
            let baseColor = new Color('#f00');

            expect(baseColor.dark().toHsl().l).to.be.at.most(baseColor.toHsl().l);
            expect(baseColor.darker().toHsl().l).to.be.at.most(baseColor.dark().toHsl().l);
            expect(baseColor.darkest().toHsl().l).to.be.at.most(baseColor.darker().toHsl().l);

            baseColor = new Color('#777');

            expect(baseColor.dark().toHsl().l).to.be.at.most(baseColor.toHsl().l);
            expect(baseColor.darker().toHsl().l).to.be.at.most(baseColor.dark().toHsl().l);
            expect(baseColor.darkest().toHsl().l).to.be.at.most(baseColor.darker().toHsl().l);
        });
    });

    describe('getContrastText()', () => {
        it('returns a Color object', () => {
            const black = new Color('#000');
            expect(black.getContrastText()).to.be.instanceOf(Color);

            const white = new Color('#fff');
            expect(white.getContrastText()).to.be.instanceOf(Color);

            const grey = new Color('#777');
            expect(grey.getContrastText()).to.be.instanceOf(Color);

            const red = new Color('#f00');
            expect(red.getContrastText()).to.be.instanceOf(Color);
        });

        it('returns offWhite for pure black', () => {
            const color = new Color('#000');
            expect(color.getContrastText().toString()).to.equal('#f0f0f0');
        });

        it('returns offWhite up to 4.5:1 contrast with offWhite', () => {
            const color = new Color('#6d6d6d');
            expect(color.getContrastText().toString()).to.equal('#f0f0f0');
        });

        it('reverts to white at 4.5:1 contrast with offWhite', () => {
            const color = new Color('#6e6e6e');
            expect(color.getContrastText().toString()).to.equal('#ffffff');
        });

        it('returns white up to 4.5:1 contrast with pure white', () => {
            const color = new Color('#767676');
            expect(color.getContrastText().toString()).to.equal('#ffffff');
        });

        it('returns black from 4.5:1 contrast with pure white', () => {
            const color = new Color('#777777');
            expect(color.getContrastText().toString()).to.equal('#000000');
        });

        it('returns black up to 4.5:1 contrast with offBlack', () => {
            const color = new Color('#7b7b7b');
            expect(color.getContrastText().toString()).to.equal('#000000');
        });

        it('returns offBlack after 4.5:1 contrast with offBlack', () => {
            const color = new Color('#7c7c7c');
            expect(color.getContrastText().toString()).to.equal('#101010');
        });

        it('returns offBlack up to pure white', () => {
            const color = new Color('#ffffff');
            expect(color.getContrastText().toString()).to.equal('#101010');
        });
    });

    describe('mix()', () => {
        it('should correctly mix test colours', () => {
            const color1 = new Color(100, 100, 100);
            const color2 = new Color(0, 0, 0);

            expect(color1.mix(color2, 50).r).to.equal(50);
            expect(color1.mix(color2, 50).g).to.equal(50);
            expect(color1.mix(color2, 50).b).to.equal(50);

            expect(color1.mix(color2, 75).r).to.equal(75);
            expect(color1.mix(color2, 75).g).to.equal(75);
            expect(color1.mix(color2, 75).b).to.equal(75);

            const color3 = new Color(100, 0, 0);
            const color4 = new Color(0, 0, 100);

            expect(color3.mix(color4, 50).r).to.equal(50);
            expect(color3.mix(color4, 50).g).to.equal(0);
            expect(color3.mix(color4, 50).b).to.equal(50);
        });
    });

    describe('tint()', () => {
        let color;

        beforeEach(() => {
            color = new Color("#f00");
        });

        it('returns a Color object', () => {
            expect(color.tint(50)).to.be.an.instanceOf(Color);
        });

        it('returns the base colour where the `amount` is 1, 100 or greater than 100', () => {
            expect(color.tint(1).toString()).to.equal(color.toString());
            expect(color.tint(100).toString()).to.equal(color.toString());
            expect(color.tint(101).toString()).to.equal(color.toString());
            expect(color.tint(5000).toString()).to.equal(color.toString());
        });

        it('returns white where the `amount` is 0', () => {
            expect(color.tint(0).toString()).to.equal('#ffffff');
        });

        it('returns the same as `shade()` when the `amount` is negative', () => {
            expect(color.tint(-50).toString()).to.equal(color.shade(50).toString());
        });

        it('returns a lighter colour', () => {
            expect(color.tint(50).toHsl().l).to.be.at.least(color.toHsl().l);
        });
    });

    describe('shade()', () => {
        let color;

        beforeEach(() => {
            color = new Color("#f00");
        });

        it('returns a Color object', () => {
            expect(color.shade(50)).to.be.an.instanceOf(Color);
        });

        it('returns the base colour where the `amount` is 1, 100 or greater than 100', () => {
            expect(color.shade(1).toString()).to.equal(color.toString());
            expect(color.shade(100).toString()).to.equal(color.toString());
            expect(color.shade(101).toString()).to.equal(color.toString());
            expect(color.shade(5000).toString()).to.equal(color.toString());
        });

        it('returns black where the `amount` is 0', () => {
            expect(color.shade(0).toString()).to.equal('#000000');
        });

        it('returns the same as `tint()` when the `amount` is negative', () => {
            expect(color.shade(-50).toString()).to.equal(color.tint(50).toString());
        });

        it('returns a darker colour', () => {
            expect(color.shade(50).toHsl().l).to.be.at.most(color.toHsl().l);
        });
    });

    describe('addOpacity()', () => {
        let color;

        beforeEach(() => {
            color = new Color('#000');
        });

        it('adds opacity as a decimal (0-1) for values <= 1', () => {
            expect(color.addOpacity(0)).to.equal("rgba(0, 0, 0, 0)");
            expect(color.addOpacity(0.5)).to.equal("rgba(0, 0, 0, 0.5)");
            expect(color.addOpacity(0.99)).to.equal("rgba(0, 0, 0, 0.99)");
            expect(color.addOpacity(1)).to.equal("rgba(0, 0, 0, 1)");
        });

        it('adds opacity as a percentage (0-100) for values > 1', () => {
            expect(color.addOpacity(1.0001)).to.equal("rgba(0, 0, 0, 0.010001)");
            expect(color.addOpacity(50)).to.equal("rgba(0, 0, 0, 0.5)");
            expect(color.addOpacity(99)).to.equal("rgba(0, 0, 0, 0.99)");
            expect(color.addOpacity(100)).to.equal("rgba(0, 0, 0, 1)");
        });

        it('limits opacity to 100%', () => {
            expect(color.addOpacity(100.001)).to.equal("rgba(0, 0, 0, 1)");
            expect(color.addOpacity(99999)).to.equal("rgba(0, 0, 0, 1)");
        });
    });
});
