//https://www.w3.org/TR/WCAG20/#relativeluminancedef
function relativeLuminance(color) {
    const Rs = color.r / 255;
    const Gs = color.g / 255;
    const Bs = color.b / 255;

    const r = RsToR(Rs);
    const g = RsToR(Gs);
    const b = RsToR(Bs);

    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/**
 * @return {number}
 */
function RsToR(Rs) {
    if (Rs <= 0.03928) {
        return Rs / 12.92;
    } else {
        return Math.pow((Rs + 0.055) / 1.055, 2.4);
    }
}

//https://www.w3.org/TR/WCAG20/#contrast-ratiodef
function calculateContrast(c1, c2) {
    const l1 = relativeLuminance(c1);
    const l2 = relativeLuminance(c2);

    if (l1 > l2) {
        return (l1 + 0.05) / (l2 + 0.05);
    } else {
        return (l2 + 0.05) / (l1 + 0.05);
    }
}

function contrastColor(sampleColor, availableColors) {
    const MIN_CONTRAST = 4.5;

    //First off, do any of the items meet the required contrast level?
    //Keep track of the highest calculated value as we go
    let highestContrast = 0;
    let highestContrastColor = null;

    for (let i = 0; i < availableColors.length; i++) {
        let contrast = calculateContrast(availableColors[i], sampleColor);

        if (contrast >= MIN_CONTRAST) {
            return availableColors[i];
        }

        if (contrast > highestContrast) {
            highestContrast = contrast;
            highestContrastColor = availableColors[i];
        }
    }

    //If we get this far we didn't get a perfect match - return the best option
    //Here for completeness (and to prevent breaking if MIN_CONTRAST is changed)
    //Tests suggest that this condition is never experienced when MIN_CONTRAST == 4.5
    return highestContrastColor;
}

export default contrastColor;
export {relativeLuminance, calculateContrast, contrastColor}
