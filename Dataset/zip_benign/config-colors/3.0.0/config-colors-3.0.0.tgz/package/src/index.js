import {hslToRgb, rgbToHsl} from "./conversion.js";
import {parseObject, parseHex, parseRgb} from './parse.js';
import contrastColor from './contrast.js';

class Color {
    constructor(r, g, b) {
        if (typeof r === 'object' && g === undefined && b === undefined) {
            const parsed = parseObject(r);
            Object.assign(this, parsed);
            // this.r = parsed.r;
            // this.g = parsed.g;
            // this.b = parsed.b;
        } else if (typeof r === 'string' && g === undefined && b === undefined) {
            const parsed = parseHex(r);
            this.r = parsed.r;
            this.g = parsed.g;
            this.b = parsed.b;
        } else if (Number.isInteger(r) && Number.isInteger(g) && Number.isInteger(b)) {
            const parsed = parseRgb(r, g, b);
            this.r = parsed.r;
            this.g = parsed.g;
            this.b = parsed.b;
        } else {
            throw new Error("Invalid parameters passed. You need to specify a single hex value, " +
                "and existing Color object, or three Integers representing R, G and B.");
        }
    }

    toString() {
        return '#' +
            Number(this.r).toString(16).padStart(2, "0") +
            Number(this.g).toString(16).padStart(2, "0") +
            Number(this.b).toString(16).padStart(2, "0");
    }

    toHsl() {
        return rgbToHsl(this.r, this.g, this.b);
    }

    darkest() {
        return this.shade(40);
    }

    darker() {
        return this.shade(60);
    }

    dark() {
        return this.shade(80);
    }

    light() {
        return this.tint(80);
    }

    lighter() {
        return this.tint(60);
    }

    lightest() {
        return this.tint(40);
    }

    getContrastText() {
        //Off white and black should be preferred, if they meet the WCAG minimum contrast levels
        //Pure white and black are fallback values to maximise contrast
        //https://www.w3.org/TR/UNDERSTANDING-WCAG20/visual-audio-contrast-contrast.html
        const textColors = [
            new Color("#f0f0f0"),
            new Color("#101010"),
            new Color("#ffffff"),
            new Color("#000000"),
        ];

        return contrastColor(this, textColors);
    }

    mix(mixWith, amount) {
        if (!(mixWith instanceof Color)) {
            mixWith = new Color(mixWith);
        }

        //Amounts less than 0 are treated as 0
        if (amount < 0) {
            amount = 0;
        }

        //If amount is less than 1 divide it by 100 (convert percentage value to 'raw' 0-1 value)
        //If amount is above 100% treat as 100%
        if (amount > 1) {
            amount = Math.min(amount / 100, 1);
        }

        let r, g, b;
        r = Math.round((this.r * amount) + (mixWith.r * (1 - amount)));
        g = Math.round((this.g * amount) + (mixWith.g * (1 - amount)));
        b = Math.round((this.b * amount) + (mixWith.b * (1 - amount)));

        return new Color(r, g, b);
    }

    tint(amount) {
        if (amount < 0) {
            return this.shade(0 - amount);
        } else {
            return this.mix('#fff', amount);
        }
    }

    shade(amount) {
        if (amount < 0) {
            return this.tint(0 - amount);
        } else {
            return this.mix('#000', amount);
        }
    }

    addOpacity(opacity) {
        if (opacity > 100) {
            opacity = 100;
        }

        if (opacity > 1) {
            opacity = opacity / 100;
        }

        return 'rgba(' +
            this.r + ', ' +
            this.g + ', ' +
            this.b + ', ' +
            opacity +
            ')';
    }
}

export default Color;
