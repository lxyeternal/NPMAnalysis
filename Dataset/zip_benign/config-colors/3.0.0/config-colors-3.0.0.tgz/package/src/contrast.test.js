import chai from 'chai';
import Color from './index.js';
import {relativeLuminance, calculateContrast} from "./contrast.js";

const expect = chai.expect;

const black = new Color('#000000');
const white = new Color('#ffffff');
const red = new Color('#ff0000');
const green = new Color('#00ff00');
const blue = new Color('#0000ff');
const midGrey = new Color('#808080');

describe("Contrast", () => {
    describe("relativeLuminance()", () => {
        it('returns a number', () => {
            expect(relativeLuminance(black)).to.be.a('number');
            expect(relativeLuminance(white)).to.be.a('number');
        });
        it('calculates the relative luminance of black and white correctly', () => {
            expect(relativeLuminance(black)).to.equal(0);
            expect(relativeLuminance(white)).to.equal(1);
        });
        it('calculates the relative luminance of red, green and blue correctly', () => {
            expect(Math.round(relativeLuminance(red)*10000)/10000).to.equal(0.2126);
            expect(Math.round(relativeLuminance(green)*10000)/10000).to.equal(0.7152);
            expect(Math.round(relativeLuminance(blue)*10000)/10000).to.equal(0.0722);
        });
        it('calculates the relative luminance of mid-grey correctly', () => {
            expect(Math.round(relativeLuminance(midGrey)*10000)/10000).to.equal(0.2159);
        });
    });
    describe('calculateContrast()', function () {
        it('returns a number', function () {
            expect(calculateContrast(black, white)).to.be.a('number');
            expect(calculateContrast(red, green)).to.be.a('number');
        });
        it('should show maximum contrast between white and black', function () {
            expect(calculateContrast(black, white)).to.equal(21);
        });
        it('should show no contrast between the same colour', function () {
            expect(calculateContrast(black, black)).to.equal(1);
            expect(calculateContrast(white, white)).to.equal(1);
        });
        it('should calculate the correct contrast between various colours', function () {
            expect(Math.round(calculateContrast(red, green)*100)/100).to.equal(2.91);
            expect(Math.round(calculateContrast(green, blue)*100)/100).to.equal(6.26);
            expect(Math.round(calculateContrast(blue, red)*100)/100).to.equal(2.15);
            expect(Math.round(calculateContrast(midGrey, black)*100)/100).to.equal(5.32);
            expect(Math.round(calculateContrast(midGrey, white)*100)/100).to.equal(3.95);
        });
    });
});
