import React from 'react';
import type { TouchableOpacityProps, TouchableHighlightProps, TouchableWithoutFeedbackProps, PressableProps, StyleProp, ViewStyle } from 'react-native';
export declare const TouchableOpacityThrottle: (props: TouchableOpacityProps & {
    throttleTime?: number;
}) => React.JSX.Element;
export declare const TouchableHighlightThrottle: (props: TouchableHighlightProps & {
    throttleTime?: number;
}) => React.JSX.Element;
export declare const TouchableWithoutFeedbackThrottle: (props: TouchableWithoutFeedbackProps & {
    throttleTime?: number;
}) => React.JSX.Element;
export type PressableThrottleType = PressableProps & {
    style?: StyleProp<ViewStyle>;
    throttleTime?: number;
    opacity?: number;
};
export declare const PressableThrottle: (props: PressableThrottleType) => React.JSX.Element;
//# sourceMappingURL=BaseComponents.d.ts.map