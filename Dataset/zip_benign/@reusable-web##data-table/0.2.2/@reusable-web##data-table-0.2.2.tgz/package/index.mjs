import arrayify from 'array-back'
const π = document.createElement.bind(document)

const template = document.createElement('template')
template.innerHTML = `<style>
:host {
  display: block;
}

* { box-sizing: border-box }

table {
  border-spacing: 0;
}

td,
th
{
  border-bottom: 1px dotted var(--data-table-border-colour, silver);
  padding: var(--data-table-cell-padding, 0.5em);
}

td.editable {
  cursor: pointer;
}

th {
  background-color: var(--data-table-header-bg-colour);
  color: var(--data-table-header-colour);
}

:host(.sticky-header) table {
  position: relative;
  display: inline-block;
  max-height: 40em;
  overflow: auto;
}

:host(.sticky-header) th {
  position: sticky;
  top: 0;
}

input[type="checkbox"] {
  transform: scale(1.7);
}
</style><table></table>`

/** ∆ DataTable « HTMLElement
≈ A custom element to present the supplied array of objects in a table layout.
π data-table
√ --data-table-border-colour
√ --data-table-header-colour
√ --data-table-header-bg-colour
√ --data-table-cell-padding
*/
class DataTable extends HTMLElement {
  constructor () {
    super()
    const shadow = this.attachShadow({ mode: 'open' })
    shadow.appendChild(template.content.cloneNode(true))
    this.$ = this.shadowRoot.querySelector.bind(this.shadowRoot)

    /* click table */
    this.$('table').addEventListener('click', e => {
      /* click <td.editable> cell */
      if (e.target.nodeName === 'TD' && e.target.classList.contains('editable')) {
        const row = e.target.row
        const colOptions = e.target.colOptions
        const column = e.target.dataset.column
        const value = colOptions.get ? colOptions.get(row) : row[column]
        const newValue = window.prompt('Edit', value)
        this._dispatchEdit(newValue, row, column, colOptions)
      }

      /* click <input> */
      if (e.target.nodeName === 'INPUT') {
        const newValue = e.target.checked
        const td = e.target.parentElement
        const row = td.row
        const colOptions = td.colOptions
        const column = td.dataset.column
        this._dispatchEdit(newValue, row, column, colOptions)
      }

      /* click action */
      if (e.target.hasAttribute('action')) {
        const action = e.target.getAttribute('action')
        const td = e.target.parentElement
        const row = td.row
        const column = td.dataset.column
        const event = new CustomEvent('action', {
          bubbles: true,
          composed: true,
          detail: {
            action,
            column,
            row
          }
        })
        this.dispatchEvent(event)
      }
    })
  }

  _dispatchEdit (newValue, row, column, colOptions) {
    if (newValue !== null) {
      if (colOptions.set) {
        colOptions.set(row, newValue)
      } else {
        row[column] = newValue
      }
      this.setData(this.rows, this.options)
      const event = new CustomEvent('edit', {
        bubbles: true,
        composed: true,
        detail: {
          column,
          row
        }
      })
      this.dispatchEvent(event)
    }
  }

  loadModel (model) {
    this.setData(model)
  }

  /** † ColumnOption
  ≈ Passed into `options.columnOptions`.
  • onCellAdded :function
  • get :function(row)
  • set :function(row, propName)
  • input
  • editable
  • action :string
  • actionDisabledIf :function(row, columnName):boolean
  */

  /** ø dataTableEl.setData(rows, options)
  ≈ Supply the data for the table.
  • rows :Array<object>
  • [options] :object
  • [options.onRowAdded] :function - Callback when a row is added.
  • [options.onCellAdded] :function
  • [options.columnOptions] :Array<ColumnOption>
  • [options.noHead] :boolean
  */
  setData (rows, options = {}) {
    this.rows = rows
    this.options = options
    const tableEl = this.$('table')
    tableEl.innerHTML = ''
    options = Object.assign({
      onRowAdded: function (tr, obj) {},
      onCellAdded: function (td, value) {},
      columnOptions: []
    }, options)
    rows = arrayify(rows)
    if (!rows.length) return
    if (rows[0] === null) return

    /* As columns, use either the defined columnOptions or first object's properties */
    const propNames = options.columnOptions.length
      ? options.columnOptions.map(c => c.column)
      : Object.keys(rows[0])

    if (!options.noHead) {
      /* table head rows */
      const thead = π('thead')
      const tr = π('tr')
      for (const propName of propNames) {
        const th = π('th')
        th.innerHTML = propName
        tr.append(th)
      }
      thead.append(tr)
      tableEl.append(thead)
    }

    /* table body rows */
    const tbody = π('tbody')
    for (const row of rows) {
      const tr = π('tr')
      for (const propName of propNames) {
        const colOptions = options.columnOptions.find(c => c.column === propName) || {}
        const onCellAdded = colOptions.onCellAdded || options.onCellAdded || function () {}
        const td = π('td')
        td.dataset.column = propName
        td.row = row
        td.colOptions = colOptions
        let value = colOptions.get ? colOptions.get(row) : row[propName]
        if (value === null || value === undefined) {
          value = ''
        }

        /* display a ticked checkbox for truthy values with `checkbox` */
        if (colOptions.input === 'checkbox') {
          td.innerHTML = `<input type="checkbox" name="${propName}">`
          if (value) {
            td.children[0].setAttribute('checked', 'true')
          }

        /* display a button for actions */
        } else if (colOptions.action) {
          const isDisabled = (colOptions.actionDisabledIf && colOptions.actionDisabledIf(row, propName)) ? 'disabled' : ''
          td.innerHTML = `<button action="${colOptions.action}" ${isDisabled}>${value}</button>`
        } else {
          td.innerHTML = value
        }

        /* mark editable cells */
        const editable = colOptions.editable
        if (editable) {
          td.classList.add('editable')
        }

        /* add cell and invoke `colOptions.onCellAdded` callback */
        tr.append(td)
        onCellAdded(td, propName, value)
      }
      tbody.append(tr)
      options.onRowAdded(tr, row)
    }
    tableEl.append(tbody)

    /* table footer row */
    if (options.columnOptions.some(c => c.foot)) {
      const tfoot = π('tfoot')
      const trf = π('tr')
      for (const propName of propNames) {
        const colOptions = options.columnOptions.find(c => c.column === propName) || {}
        const onCellAdded = colOptions.onCellAdded || options.onCellAdded || function () {}
        const td = π('td')
        const foot = colOptions.foot
        let value
        if (foot) {
          value = foot(rows, propName)
          td.textContent = value
        }
        trf.append(td)
        onCellAdded(td, propName, value)
      }
      tfoot.append(trf)
      tableEl.append(tfoot)
    }
  }
}

customElements.define('data-table', DataTable)
export default DataTable
