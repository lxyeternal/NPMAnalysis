[![view on npm](https://badgen.net/npm/v/@reusable-web/data-table)](https://www.npmjs.org/package/@reusable-web/data-table)
[![npm module downloads](https://badgen.net/npm/dt/@reusable-web/data-table)](https://www.npmjs.org/package/@reusable-web/data-table)
[![Gihub repo dependents](https://badgen.net/github/dependents-repo/reusable-web/data-table)](https://github.com/reusable-web/data-table/network/dependents?dependent_type=REPOSITORY)
[![Gihub package dependents](https://badgen.net/github/dependents-pkg/reusable-web/data-table)](https://github.com/reusable-web/data-table/network/dependents?dependent_type=PACKAGE)
[![Build Status](https://travis-ci.org/reusable-web/data-table.svg?branch=master)](https://travis-ci.org/reusable-web/data-table)
[![Coverage Status](https://coveralls.io/repos/github/reusable-web/data-table/badge.svg)](https://coveralls.io/github/reusable-web/data-table)
[![js-standard-style](https://img.shields.io/badge/code%20style-standard-brightgreen.svg)](https://github.com/feross/standard)

# @reusable-web/data-table

***Project and documentation are a WIP***

Variables 

```css
:root {
  --data-table-border-colour: silver;
  --data-table-cell-padding: 0.5em;
  --data-table-header-bg-colour;
  --data-table-header-colour;
```

Examples

```js
$('data-table[one]').setData([
    { one: 1, two: 2, three: false },
    { one: 10, two: 20, three: true },
  ],
  {
    columnOptions: [
      {
        column: 'one'
      },
      {
        column: 'two'
      },
      {
        column: 'three',
        input: 'checkbox'
      },
    ]
  }
)

$('data-table[editable]').setData([
    { one: 1, three: false },
    { one: 10, three: true },
  ],
  {
    columnOptions: [
      {
        column: 'one',
        editable: true
      },
      {
        column: 'three',
        input: 'checkbox'
      }
    ]
  }
)

$('data-table[action]').setData([
    { one: 1, button: 'select' },
    { one: 10, button: 'select'},
  ],
  {
    columnOptions: [
      {
        column: 'one',
        editable: true
      },
      {
        column: 'button',
        action: 'select',
        actionDisabledIf: (row) => row.one === 10
      }
    ]
  }
)

$('data-table[css]').setData([
    { one: 1, two: 2, three: false },
    { one: 10, two: 20, three: true },
  ],
  {
    columnOptions: [
      {
        column: 'one'
      },
      {
        column: 'two'
      },
      {
        column: 'three',
        input: 'checkbox'
      },
    ]
  }
)
```
