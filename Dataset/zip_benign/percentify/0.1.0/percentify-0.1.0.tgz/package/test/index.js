import expect from 'expect';
import percentify from '../src';

describe('percentify', () => {
  describe("percentify('{ a: 5, b: 4, c: 1}')", () => {
    it('should return { a: 0.5, b: 0.4, c: 0.1}', () => {
      let result = percentify({ a: 5, b: 4, c: 1});
      expect(result).toEqual({ a: 0.5, b: 0.4, c: 0.1});
    });
  });
});
