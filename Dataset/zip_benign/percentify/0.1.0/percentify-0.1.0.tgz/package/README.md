# percentify [![Build Status](https://travis-ci.org/transedward/percentify.svg?branch=master)](https://travis-ci.org/transedward/percentify)

## Install

```
$ npm install --save percentify
```


## Usage

```js
import percentify from 'percentify';
let objectWithPercentage =  percentify({ a: 5, b: 4, c: 1})
// objectWithPercentage would deep equal { a: 0.5, b: 0.4, c: 0.1}

```

## API

### percentify(input, [options])

#### input

*Required*  
Type: `object`

the value of each key should be number



## License

MIT © [transedward](https://github.com/transedward)
