## 1.1.1 (2018-02-07)
[Compare `typedoc-plugin-external-module-name` versions 1.1.0 and 1.1.1](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.1.0...1.1.1)

### Bug Fixes

* **doublecomment:** Null check 'result' ([2b51576](https://github.com/christopherthielen/typedoc-plugin-external-module-name/commit/2b51576))




# 1.1.0 (2018-02-07)
[Compare `typedoc-plugin-external-module-name` versions 1.0.10 and 1.1.0](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.10...1.1.0)

### Bug Fixes

* **doublecomment:** Monkey patch getJSDocCommentRanges instead of duplicating all of getRawComment ([c39c924](https://github.com/christopherthielen/typedoc-plugin-external-module-name/commit/c39c924))




## 1.0.10 (2017-10-27)
[Compare `typedoc-plugin-external-module-name` versions 1.0.9 and 1.0.10](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.9...1.0.10)

### Bug Fixes

* **doublecomment:** Do not use 'getRawComment': better fix for not requiring a second comment block. ([a469ed4](https://github.com/christopherthielen/typedoc-plugin-external-module-name/commit/a469ed4)), closes [#6](https://github.com/christopherthielen/typedoc-plugin-external-module-name/issues/6)
* **peerDependencies:** Fix node v4 ([edaa68f](https://github.com/christopherthielen/typedoc-plugin-external-module-name/commit/edaa68f))



## 1.0.9 (2017-03-21)
[Compare `typedoc-plugin-external-module-name` versions 1.0.8 and 1.0.9](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.8...1.0.9)


## 1.0.8 (2017-01-17)
[Compare `typedoc-plugin-external-module-name` versions 1.0.7 and 1.0.8](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.7...1.0.8)

### Bug Fixes

* **regexp:** Fix the module match regexp. ([db4232d](https://github.com/christopherthielen/typedoc-plugin-external-module-name/commit/db4232d))



## 1.0.7 (2017-01-01)
[Compare `typedoc-plugin-external-module-name` versions 1.0.6 and 1.0.7](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.6...1.0.7)


## 1.0.6 (2017-01-01)
[Compare `typedoc-plugin-external-module-name` versions 1.0.5 and 1.0.6](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.5...1.0.6)


## 1.0.5 (2016-12-11)
[Compare `typedoc-plugin-external-module-name` versions 1.0.4 and 1.0.5](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.4...1.0.5)

### Features

* Remove tags from docs after processing ([ec6892c](https://github.com/christopherthielen/typedoc-plugin-external-module-name/commit/ec6892c))



## 1.0.4 (2016-10-16)
[Compare `typedoc-plugin-external-module-name` versions 1.0.3 and 1.0.4](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.3...1.0.4)


## 1.0.3 (2016-10-16)
[Compare `typedoc-plugin-external-module-name` versions 1.0.2 and 1.0.3](https://github.com/christopherthielen/typedoc-plugin-external-module-name/compare/1.0.2...1.0.3)


## 1.0.2 (2016-07-13)
