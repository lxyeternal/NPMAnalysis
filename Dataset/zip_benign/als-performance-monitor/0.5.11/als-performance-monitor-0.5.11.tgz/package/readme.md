# als-performance-monitor

The `als-performance-monitor` module offers an efficient performance monitoring tool tailored for Node.js applications. It encompasses a versatile suite of modules that track and oversee system-level performance metrics including CPU usage, RAM, RSS, and Swap memory.

## Installation

```shell
npm install als-performance-monitor
```

## Quick Start
To get started with als-performance-monitor, follow the example below:

```js
const PM = require('als-performance-monitor');

const preferences = {
   cpu: 0.8,           // Monitor CPU, set max threshold at 80%
   ram: 0.7,           // Monitor RAM, set max threshold at 70%
   rss: 500,           // Monitor RSS, set max threshold at 500MB
   swap: 0.5,          // Monitor Swap, set max threshold at 50% (checked once per minute)
   timesInMinute: 60,  // Specify frequency of checks and logs per minute
   errorThreshold: 20  // Reset pm.errors after this number of unique errors
};

const pm = new PM(preferences);

// Registering Events
pm.emitter.on('overload', () => console.log('Overloaded event'));  // Triggered when overloaded (only when watching)
pm.emitter.on('backToNormal', () => console.log('Back to normal event'));  // Triggered when returning to normal state (only when watching)
pm.emitter.on('next', logs => console.log(logs));  // Invoked on every measurement
pm.emitter.on('error', (error, pmObj) => {  // Invoked on every unique error occurrence
   console.error(error.message);
   if (pmObj.errors.length > 20) pmObj.stop();
});

pm.run();      // Start the monitor
pm.watch();    // Start the monitor with overload tracking (enables related events)

// Check if any module is overloaded
if (pm.overloaded()) {
   console.log('System Overloaded');
}

pm.stop();   // Stops the monitor
pm.avg();    // Returns average values for the last set duration
pm.errors;   // Retrieves the last 20 errors for all modules
```

> Note: The overloaded method determines overload based on averages, not current performance values.

> Note: pm.emitter is an instance of `als-event-emitter` and supports methods like: on, off, has, once, etc.


### Using Hooks
Providing both `onOverload` and `onBackToNormal` hooks as parameters prompts the monitor to check for overload at each interval. It will invoke the `onOverload` function upon detecting an overload and the `onBackToNormal` function once it returns to a normal state.