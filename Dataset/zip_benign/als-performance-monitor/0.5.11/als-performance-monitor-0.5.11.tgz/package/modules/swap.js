const getSwapMemory = require('als-swap-mem-info')

module.exports = async function() {
   if(this.lastCheckTime === undefined) this.lastCheckTime = Date.now() // Has to run only first time
   if(Date.now() - this.lastCheckTime > 60*1000 || this.lastResult === undefined) {
      this.lastResult = (await getSwapMemory()).perc
      this.lastCheckTime = Date.now()
   }
   return this.lastResult
}