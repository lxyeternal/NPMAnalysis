const {getCpu,calcCpuPerc} = require('als-cpu-usage')

module.exports = function() {
   if(this.start === undefined) {
      this.start = getCpu()
      return NaN
   } else if(this.start) {
      const end = getCpu()
      const start = this.start
      this.start = end
      return calcCpuPerc(start,end)
   }
}