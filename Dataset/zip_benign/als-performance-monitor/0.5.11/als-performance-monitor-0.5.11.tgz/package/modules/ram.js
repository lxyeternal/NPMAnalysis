const os = require('os')
module.exports = function() {
   if(this.totalMemory === undefined) this.totalMemory = os.totalmem();
   return 1-os.freemem() / this.totalMemory
}