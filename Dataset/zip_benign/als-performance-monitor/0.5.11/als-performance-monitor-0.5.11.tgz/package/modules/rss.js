module.exports = function() {
   return process.memoryUsage().rss/1024/1024
}