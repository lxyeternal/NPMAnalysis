const CheckCpu = require('./modules/cpu')
const CheckRam = require('./modules/ram')
const CheckSwap = require('./modules/swap')
const CheckRss = require('./modules/rss')
const MS_PER_MINUTE = 60 * 1000;
const EventEmitter = require('als-event-emitter')

class PM {
   constructor(performances={}) {
      const {cpu,ram,rss,swap,timesInMinute=60,errorThreshold = 20} = performances
      this.errorThreshold = errorThreshold
      this.timesInMinute = timesInMinute > 60 ? 60 : timesInMinute
      this.timeGap = (MS_PER_MINUTE) / this.timesInMinute // timeGap is a time for each interval in minute
      this.modules = []
      this.errors = []
      this.emitter = new EventEmitter()
      this.check(ram,'ram',CheckRam,1)
      this.check(swap,'swap',CheckSwap,1)
      this.check(cpu,'cpu',CheckCpu,1)
      this.check(rss,'rss',CheckRss)
      this.interval = null
   }

   check(max, name, fetchValueFn , to) {
      const errors = [];
      if (typeof max !== 'number') {
         console.warn(`Skipped ${name} because max is not a number.`);
         return;
      }
      
      if (max < 0) errors.push(`Skipped ${name} because max should be greater than 0.`);
      if (to && max > to) errors.push(`Skipped ${name} because max should be less than ${to}.`);
      if (errors.length === 0) this.modules.push({name, max, fetchValueFn , log: []});
      else console.warn(`Errors for ${name}:`, errors.join('\n'));
   }
   
   watchNext() {
      if(this.overloaded()) {
         this.waitForBackToNormal = true
         this.emitter.emit('overload')
      } else if(this.waitForBackToNormal){
         this.emitter.emit('backToNormal')
         this.waitForBackToNormal = false
      }
   }

   watch() {
      this.watching = true
      this.run()
   }

   run() {
      if(this.interval) return
      this.interval = setInterval(async () => {
         const logs = {}
         const hasNext = this.emitter.has('next')
         for (let {fetchValueFn ,log,name} of this.modules) {
            try {
               const result = await fetchValueFn()
               if(isNaN(result)) continue
               log.push(result)
               if(log.length > this.timesInMinute) log.shift() // remove first element if limit eceded
               if(hasNext) logs[name] = result
            } catch (error) {
               this.handleError(error)
            }
         }
         this.emitter.emit('next',logs)
         this.lastOverloaded = undefined
         if(this.watching) this.watchNext()
      },this.timeGap)
      return this
   }

   handleError(error) {
      if(this.errors.length > this.errorThreshold) this.errors = []
      const msg = error.message
      for(let err in this.errors) {
         if(err.message === msg) {
            err.times.push(Date.now())
            return
         }
      }
      error.times = [Date.now()]
      this.errors.push(error)
      this.emitter.emit('error',error,this)
   }

   overloaded() {
      if(this.lastOverloaded !== undefined) return this.lastOverloaded
      const avgs = this.avg()
      for(let mod of this.modules) {
         if(!avgs[mod.name]) continue
         if(avgs[mod.name] > mod.max) {
            this.lastOverloaded = true;
            return true;
         }
      }
      this.lastOverloaded = false
      return false
   }

   avg() {
      const avg = {}
      this.modules.forEach(({name,log}) => {
         avg[name] = log.reduce((a, b) => a + b, 0)/log.length
      })
      return avg
   }

   stop() {
      clearInterval(this.interval)
      this.interval = null
      this.lastOverloaded = undefined
      this.emitter.removeAllListeners()
   }
}

module.exports = PM