const SimpleTest = require('./test')
const { describe, runTests, it, expect, delay, beforeEach, afterEach } = SimpleTest
const getMemoryUsageProportion = require('../modules/ram')

describe('getMemoryUsageProportion function', function () {
   it('should return a number representing memory usage proportion', function () {
      const result = getMemoryUsageProportion();
      expect(typeof result).equalTo('number');
      expect(result).atLeast(0);  // Proportion should be >= 0
      expect(result).atMost(1);  // Proportion should be <= 1
   });
});

runTests()