const SimpleTest = require('./test')
const { describe, runTests, it, expect, delay, beforeEach, afterEach } = SimpleTest
SimpleTest.showFullError = true
const PM = require('../index')
const mockModule = async () => 0.5;

describe('PM class', function () {
   describe('constructor', function () {
      it('should initialize properties correctly', function () {
         const pm = new PM({ cpu: 0.8, timesInMinute: 10 });
         expect(pm.timesInMinute).equalTo(10);
         expect(pm.modules.length).equalTo(1);
         expect(pm.modules[0].name).equalTo('cpu');
         expect(pm.modules[0].max).equalTo(0.8);
      });
   });

   describe('check method', function () {
      it('should push valid module', function () {
         const pm = new PM();
         pm.check(0.7, 'test', mockModule, 1);
         expect(pm.modules.length).equalTo(1);
      });

      it('should not push invalid module', function () {
         const pm = new PM();
         pm.check(-0.1, 'test', mockModule, 1);
         expect(pm.modules.length).equalTo(0);
      });
   });

   describe('avg method', function () {
      it('should compute average correctly', function () {
         const pm = new PM();
         const log = [0.1, 0.2, 0.3]

         pm.modules.push({ name: 'test', log });
         const averages = pm.avg();
         expect(averages.test).equalTo(log.reduce((a, b) => a + b, 0) / log.length);
      });
   });

   describe('isOverLoad method with real data', function () {
      it('should return correct overload state based on max values', async function () {
         // 1. Run the monitor
         const pm = new PM({ cpu: 0.01, ram: 0.01 }); // start with very low max values
         let overload = false, normal = false
         pm.emitter.on('overload', () => overload = true)
         pm.emitter.on('backToNormal', () => normal = true)
         pm.watch();

         // 2. Wait for some time to collect data
         await delay(2 * 1000)

         // 3. Check isOverLoad. It should return true given our very low max values
         let result = pm.overloaded();
         expect(result).equalTo(true);
         // 4. Increase the max values and check again
         pm.modules.forEach(mod => mod.max = 1);  // setting to 1 (100%) to ensure it's higher than any average
         await delay(2 * 1000)
         result = pm.overloaded();
         expect(result).equalTo(false);

         // 5. Decrease the max values below the average and check again
         pm.modules.forEach(mod => mod.max = 0.01);  // setting back to a very low value
         await delay(2 * 1000)
         result = pm.overloaded();
         expect(result).equalTo(true);
         expect(overload).is('onOverload hook works').equalTo(true);
         expect(normal).is('onBackToNormal hook works').equalTo(true);
         pm.stop(); // Stop the monitor
      });
   });
});

describe('EventEmitter behavior', function () {
   it('should emit next event on each interval', async function () {
      const pm = new PM({ cpu: 0.8 });

      let nextEmitCount = 0;
      pm.emitter.on('next', () => {
         nextEmitCount += 1;
      });

      pm.watch();
      await delay(3 * pm.timeGap + 2);  // Wait for at least two intervals
      pm.stop();

      expect(nextEmitCount).is('next should be emitted for each interval').equalTo(3);
   });

   it('should handle errors correctly and emit error event', async function () {
      const mockErrorModule = async () => { throw new Error("Test Error"); };
      const pm = new PM();
      pm.check(0.7, 'errorModule', mockErrorModule, 1);

      let errorEmitted = false;
      pm.emitter.on('error', () => {
         errorEmitted = true;
      });

      pm.run();
      await delay(1001)
      expect(errorEmitted).is('error event should be emitted').equalTo(true);
      expect(pm.errors.length).is('errors array should contain the error').equalTo(1);

      pm.stop(); // Stop the monitor
   });

});

describe('Other tests', function () {
   it('should log metric values and remove the oldest value when limit is exceeded', async function () {
      const pm = new PM({ ram: 0.8, timesInMinute: 60 });
      pm.watch();
      await delay(3 * pm.timeGap + 2);  // Wait for at least four intervals
      pm.stop();

      const ramLog = pm.modules.find(m => m.name === 'ram').log;
      expect(ramLog.length).is('log length should not exceed timesInMinute').equalTo(3);
      expect(ramLog[0]).isNot('oldest log value should be removed').equalTo(0.8);
   });

   it('should stop collecting data', async function () {
      const pm = new PM({ cpu: 0.8 });

      let nextEmitCount = 0;
      pm.emitter.on('next', () => {
         nextEmitCount += 1;
      });

      pm.watch();
      await delay(2 * pm.timeGap + 2);  // Wait for two intervals
      pm.stop();
      await delay(2 * pm.timeGap + 2);  // Wait for two more intervals

      expect(nextEmitCount).is('next should be emitted only before stop is called').equalTo(2);
   });

   it('should handle multiple modules correctly', async function () {
      const mockModuleA = async () => 0.1;
      const mockModuleB = async () => 0.9;
      const pm = new PM();
      pm.check(0.5, 'moduleA', mockModuleA, 1);
      pm.check(1, 'moduleB', mockModuleB, 1);

      pm.watch();
      await delay(pm.timeGap);  // Wait for one interval
      pm.stop();

      const avgA = pm.avg().moduleA;
      const avgB = pm.avg().moduleB;

      expect(avgA).is('avg for moduleA should be correct').equalTo(0.1);
      expect(avgB).is('avg for moduleB should be correct').equalTo(0.9);
   });

});


runTests()