const SimpleTest = require('./test')
const { describe, runTests, it, expect, delay, beforeEach, afterEach } = SimpleTest
const getMemoryUsage = require('../modules/swap'); // Adjust the path to your module

describe('getMemoryUsage function', function() {
   it('should fetch memory usage percentage if lastResult is not defined', async function() {
       const result = await getMemoryUsage();
       expect(typeof result).equalTo('number');
       expect(result).atLeast(0);
       expect(result).atMost(1);
   });

   it('should not fetch memory usage again if called within the interval', async function() {
       const firstResult = await getMemoryUsage();
       const secondResult = await getMemoryUsage();
       expect(secondResult).equalTo(firstResult);
   });
});

runTests()