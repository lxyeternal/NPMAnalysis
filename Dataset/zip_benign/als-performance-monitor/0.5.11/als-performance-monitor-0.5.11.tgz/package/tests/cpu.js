const SimpleTest = require('./test')
const {describe, runTests, it, expect, delay, beforeEach, afterEach} = SimpleTest
const measureCpuUsage = require('../modules/cpu')

describe('measureCpuUsage function', function() {
   it('should return NaN on the first call', function() {
       const result = measureCpuUsage();
       expect(isNaN(result)).equalTo(true);
   });

   it('should return a number on the second call', function(done) {
       measureCpuUsage();  // First call, sets up the initial state

       // Introducing a small delay before the second call to simulate some CPU activity
       setTimeout(() => {
           const result = measureCpuUsage();
           expect(typeof result).equalTo('number');
           expect(result).atLeast(0);  // CPU usage should be >= 0
           expect(result).atMost(100); // CPU usage should be <= 100
       }, 1000);  // 1 second delay
   });
});

runTests()