export declare type DeepPartial<T> = T extends Function ? T : T extends object ? {
    [P in keyof T]?: DeepPartial<T[P]>;
} : T;
export declare type DeepRequied<T> = T extends Function ? T : T extends object ? {
    [P in keyof T]-?: DeepRequied<T[P]>;
} : T;
export declare type Color = CanvasFillStrokeStyles["fillStyle"] | "transparent";
export declare type Size = {
    width: number;
    height: number;
};
export declare type Position = {
    x: number;
    y: number;
};
export declare type Point = {
    x: number;
    y: number;
};
