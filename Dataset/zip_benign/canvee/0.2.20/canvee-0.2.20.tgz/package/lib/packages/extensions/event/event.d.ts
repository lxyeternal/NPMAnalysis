import { CanveeExtension, Component } from "../../core";
export declare const EVENT_MAP: {
    pointerdown: string[];
    pointerup: string[];
    pointermove: string[];
    pointerenter: string[];
    pointerleave: string[];
};
export declare enum HitAreaType {
    CIRCLE = 0,
    POLYGON = 1,
    DEFAULT = 2
}
export declare type HitArea = {
    type: HitAreaType;
    option: Array<number>;
};
export declare type EventArg = {
    hitArea?: HitArea;
};
declare type RawEvent = MouseEvent | UIEvent | TouchEvent | PointerEvent;
export declare type EventEmitter = {
    x: number;
    y: number;
    current: Component;
    targets: Array<Component>;
    stopPropgation: () => void;
    raw: RawEvent;
};
export declare type ListenerType = (e: EventEmitter) => void;
export declare type PointerEventName = keyof typeof EVENT_MAP;
export default class Event extends CanveeExtension {
    hitArea: HitArea;
    constructor(arg?: EventArg);
    beforeDiscard(c: Component): void;
    on(name: PointerEventName, fn: ListenerType): void;
    onGlobal(name: PointerEventName, fn: ListenerType): void;
    off(offName: PointerEventName, f: ListenerType): void;
}
export {};
