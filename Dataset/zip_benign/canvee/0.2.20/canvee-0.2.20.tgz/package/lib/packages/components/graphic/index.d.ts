import Component, { ComponentArg } from "../../core/component";
declare type GraphicArg = {
    draw: (ctx: CanvasRenderingContext2D) => void;
};
/**
 * @export
 * @class Graphic
 * @extends {Component}
 * 绘制画图组件，可以直接调用canvas context
 */
export default class Graphic extends Component {
    constructor({ ...arg }: ComponentArg & GraphicArg);
}
export {};
