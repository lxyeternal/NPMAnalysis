import { Resource } from "../../core";
declare type SoundArg = {
    audio: Resource<"audio">;
    autoplay?: boolean;
    loop?: boolean;
    volume?: number;
};
declare type PlayArg = {
    overlap?: boolean;
    offset?: number;
};
export default class Sound {
    #private;
    private buffer?;
    private source?;
    private gainNode?;
    private loop;
    private playTime?;
    private playedProgress;
    set volume(v: number);
    get volume(): number;
    constructor({ audio, autoplay, loop, volume }: SoundArg);
    private setGainNode;
    private setSourceNode;
    play(arg?: PlayArg): void;
    pause(): void;
    resume(): void;
    stop(): void;
    private destroyOldSource;
}
export {};
