import { CanveeExtension } from "../../core/extension";
/**
 *
 *
 * @export
 * @class Mask
 * @implements {CanveeExtension}
 * @description Mask组件会以添加其的组件的绘制线为边界作为遮罩
 */
export default class Mask extends CanveeExtension {
    afterRender(_c: any, ctx: CanvasRenderingContext2D): void;
}
