import { Size } from "../type";
declare const watchResize: (el: HTMLElement, callback: (s: Size) => void) => () => void;
declare function deepClone<T extends object | Array<unknown>>(obj: T): T;
declare const mergeConfig: <T extends object>(defaultConfig: T, custom?: Partial<T> | undefined) => T;
declare const _default: {};
export default _default;
export { watchResize, deepClone, mergeConfig };
