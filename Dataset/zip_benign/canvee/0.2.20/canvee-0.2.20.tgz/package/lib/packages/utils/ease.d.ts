export declare type CurveFunction = (...arg: Array<number>) => number;
export declare type Ease = "easeIn" | "easeOut" | "easeInOut";
declare type CombineCurveFunction = {
    [p in Ease]: CurveFunction;
};
export declare const Linear: CurveFunction;
export declare const Quad: CombineCurveFunction;
export declare const Cubic: CombineCurveFunction;
export declare const Quart: CombineCurveFunction;
export declare const Quint: CombineCurveFunction;
export declare const Sine: CombineCurveFunction;
export declare const Expo: CombineCurveFunction;
export declare const Circ: CombineCurveFunction;
export declare const Elastic: CombineCurveFunction;
export declare const Back: CombineCurveFunction;
export declare const Bounce: CombineCurveFunction;
export {};
