import { CanveeExtensionSystem, Component } from "../core";
import { Scene } from "../core/component";
export declare class Node {
    node: Component;
    children: Array<Node>;
    constructor(node: Component);
    pushChild(c: Component): Node;
    popChild(): void;
}
declare const getSubTree: (scene: Scene, match: (x: Component) => boolean) => Node;
declare const getSubTreeArr: (systems: Array<CanveeExtensionSystem>, scene: Scene) => (0 | Node)[];
export default getSubTree;
export { getSubTreeArr };
