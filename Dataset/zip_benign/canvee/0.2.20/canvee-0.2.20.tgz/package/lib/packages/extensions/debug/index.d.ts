/// <reference types="node" />
import Component from "../../core/component";
import CanveeExtensionSystem, { CanveeExtension } from "../../core/extension";
declare class Frames {
    frames: Array<number>;
    maxFrameLength: number;
    constructor();
    addFrame(frame: number): void;
    get averageFrame(): number;
}
declare type DebugArgs = {
    showBoundary?: boolean;
};
export declare class Debug extends CanveeExtension {
    showBoundary: boolean;
    constructor(arg?: DebugArgs);
    beforeRender(c: Component, ctx: CanvasRenderingContext2D): void;
}
export default class DebugSystem extends CanveeExtensionSystem {
    frameComp: Component;
    frames: Frames;
    flagCount: number;
    flagComp?: Component;
    flagTime?: Date;
    timer: NodeJS.Timeout;
    registedHooks: ("beforeSystemStart" | "beforeSystemNextLoop" | "beforeSystemReRender" | "beforeSystemStop" | "beforeComponentRender" | "afterSystemTreeRebuild" | "onSubExtensionAdded" | "onSubExtensionDiscarded")[];
    constructor();
    isMasterOf(usage: CanveeExtension): boolean;
    beforeSystemStop(): void;
    beforeSystemNextLoop(): void;
    beforeSystemStart(): void;
}
export {};
