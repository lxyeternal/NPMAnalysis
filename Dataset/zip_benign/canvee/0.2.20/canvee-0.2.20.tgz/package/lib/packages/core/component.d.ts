import type { CanveeExtension } from "./extension";
import type { Point, Size, Position, DeepRequied } from "../type";
import type { CanveeExtensionSystem } from ".";
import Dispatcher from "./dispatcher";
import Canvee from "./core";
declare type OriginType = Point;
declare type AnchorType = Point;
declare type ScaleType = Point;
declare type SkewType = Point;
export declare type ComponentArg = {
    name?: string;
    transform?: {
        size?: Size;
        position?: Position;
        scale?: ScaleType;
        zIndex?: number;
        origin?: OriginType;
        anchor?: AnchorType;
        rotate?: number;
        alpha?: number;
        skew?: SkewType;
    };
};
export default class Component extends Dispatcher {
    transform: DeepRequied<ComponentArg>["transform"];
    children: Array<Component>;
    name: string;
    parent?: Component;
    scene?: Scene;
    constructor({ transform, name }: ComponentArg);
    render(_ctx: CanvasRenderingContext2D): void;
    private addComponent;
    /**
     * @description add muiltiple child component at one time
     */
    addChildren(...components: Array<Component>): void;
    /**
     * @description add one component as child
     */
    addChild<T extends Component>(c: T): T;
    /**
     * @description remove child component
     */
    removeChild(c: Component): void;
    private notifyMasterSystemUsed;
    private notifyMasterSystemDiscarded;
    /**
     *
     * @returns 每个组件同类型的Extension只能有一个，多次添加仅返回第一个
     */
    use<T extends CanveeExtension>(extension: T): T;
    /**
     * @description remove added extension
     */
    discard<T extends CanveeExtension>(extension: T): void;
    forceUpdate(): void;
    destroy(): void;
}
export declare class Scene extends Component {
    isRoot: boolean;
    canvee: Canvee;
    constructor(arg: ComponentArg & {
        canvee: Canvee;
    });
    render(ctx: CanvasRenderingContext2D): void;
    getExtensionSystem<T extends CanveeExtensionSystem>(sys: new (arg?: any) => T): T;
}
export {};
