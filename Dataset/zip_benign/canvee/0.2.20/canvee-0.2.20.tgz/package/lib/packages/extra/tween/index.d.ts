import { CurveFunction } from "../../utils/ease";
declare type TweenArgs = {
    from: number;
    to: number;
    duration: number;
    curve: CurveFunction;
};
export default class Tween {
    #private;
    constructor(arg: TweenArgs);
    play(loop?: number): this;
    tween(arg: TweenArgs): this;
    slicing(fn: (v: number, p: number) => void): this;
    after(fn: () => void): this;
    pause(): void;
    resume(): void;
    stop(): void;
    getTotalDuration(): number;
}
export {};
