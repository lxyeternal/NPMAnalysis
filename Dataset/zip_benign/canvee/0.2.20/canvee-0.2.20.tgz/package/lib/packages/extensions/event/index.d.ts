import Component from "../../core/component";
import CanveeExtensionSystem, { CanveeExtension } from "../../core/extension";
import { Point } from "../../type";
declare type EventSystemArg = {
    preventScroll?: boolean;
};
export default class EventSystem extends CanveeExtensionSystem {
    #private;
    prventScroll: boolean;
    constructor(arg?: EventSystemArg);
    registedHooks: ("beforeSystemStart" | "beforeSystemNextLoop" | "beforeSystemReRender" | "beforeSystemStop" | "beforeComponentRender" | "afterSystemTreeRebuild" | "onSubExtensionAdded" | "onSubExtensionDiscarded")[];
    beforeSystemStop(): void;
    isMasterOf(usage: CanveeExtension): boolean;
}
declare type MoveType = {
    offset: Point;
    begin: Point;
};
declare const useDragUnder: (_globalComponent: Component, callback: (comp: Component, move: MoveType) => void) => (comp: Component) => void;
export { useDragUnder };
