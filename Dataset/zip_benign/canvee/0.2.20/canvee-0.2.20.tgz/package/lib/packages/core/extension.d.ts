import Component from "./component";
import Canvee from "./core";
export declare const ExtensionHooks: readonly ["onAdded", "beforeDiscard", "beforeRender", "afterRender"];
export declare type ExtensionHook = typeof ExtensionHooks[number];
export declare class CanveeExtension {
    masterSystem?: new (arg?: any) => CanveeExtensionSystem;
    beforeDiscard(_c: Component): void;
    beforeRender(_c: Component, _ctx: CanvasRenderingContext2D): void;
    afterRender(_c: Component, _ctx: CanvasRenderingContext2D): void;
    onAdded(_c: Component): void;
    beforeDestory(_c: Component): void;
}
export declare const SystemHooks: readonly ["beforeSystemStart", "beforeSystemNextLoop", "beforeSystemReRender", "beforeSystemStop", "beforeComponentRender", "afterSystemTreeRebuild", "onSubExtensionAdded", "onSubExtensionDiscarded"];
export declare type SystemHook = typeof SystemHooks[number];
export default class CanveeExtensionSystem {
    protected instance?: Canvee;
    readonly registedHooks: Array<SystemHook>;
    /**
     *
     *
     * @description is ExtensionSystem will use subtree which contains subExtension
     */
    willUseSubtree?: boolean;
    setInstance(c: Canvee): void;
    /**
     *
     * @description here can get canvee instance
     */
    beforeSystemStart(): void;
    beforeSystemNextLoop(): void;
    beforeSystemReRender(): void;
    beforeSystemStop(): void;
    beforeComponentRender(_c: Component): void;
    afterSystemTreeRebuild(): void;
    onSubExtensionAdded<T extends CanveeExtension>(_u: T, _c: Component): void;
    onSubExtensionDiscarded(_u: CanveeExtension, _c: Component): void;
    isMasterOf<T extends CanveeExtension>(_sys: T): boolean;
    get subtree(): 0 | import("../utils").Node | undefined;
}
