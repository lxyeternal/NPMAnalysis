import { Point } from "../../type";
import Graphic from "../graphic";
declare type SnakeMapArg = {
    points: Array<Point>;
};
export default function createBezierCurve({ points }: SnakeMapArg): Graphic;
export {};
