import { Scene } from "./component";
import CanveeExtensionSystem, { SystemHook } from "./extension";
import { Point, Size } from "../type";
import { Node } from "../utils";
declare type CanveeArg = {
    canvas: HTMLCanvasElement;
    size: Size;
    devicePixelRatio?: number;
    systems?: Array<CanveeExtensionSystem>;
};
export default class Canvee {
    #private;
    readonly canvas: HTMLCanvasElement;
    readonly scene: Scene;
    ratio: Point;
    readonly devicePixelRatio: number;
    systems: Array<CanveeExtensionSystem>;
    readonly sytemGroup: {
        [p in SystemHook]: Array<CanveeExtensionSystem>;
    };
    constructor({ canvas, size, systems, devicePixelRatio }: CanveeArg);
    onResize(fn: (s: Size) => void): void;
    getRatio: () => {
        x: number;
        y: number;
    };
    private init;
    private start;
    private rerender;
    stop(): void;
    private markAsDirty;
    updateSystemSubTreeArr(): void;
    getSubTreeForSystem(sys: CanveeExtensionSystem): 0 | Node;
    getExtensionSystem(sys: new () => CanveeExtensionSystem): CanveeExtensionSystem | undefined;
}
export {};
