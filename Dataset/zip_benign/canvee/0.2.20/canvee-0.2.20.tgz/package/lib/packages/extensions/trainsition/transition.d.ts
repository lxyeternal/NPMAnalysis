import { CanveeExtension, Component } from "../../core";
import { CurveFunction } from "../../utils/ease";
declare type TransiontionArg = {
    group: {
        [trainsitionNames: string]: {
            name: string;
            component: Component;
            values: Array<{
                time: number;
                tween?: CurveFunction;
                value: number;
            }>;
        }[];
    };
};
export default class Transition extends CanveeExtension {
    #private;
    readonly group: TransiontionArg["group"];
    constructor(args: TransiontionArg);
    private setTweenGroup;
    play(name: string, num: number, after?: () => void): void;
    stop(): void;
    pause(): void;
    resume(): void;
}
export {};
