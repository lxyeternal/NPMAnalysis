import { Component } from "../core";
declare type TreeAble<T> = {
    children: Array<TreeAble<T>>;
} & T;
declare const travelTreeable: <T>(root: TreeAble<T>, before: (c: TreeAble<T>) => void, after?: ((c: TreeAble<T>) => void) | undefined) => void;
declare const travelComponent: (root: Component, before: (c: Component) => void, after?: ((c: Component) => void) | undefined) => void;
export default travelTreeable;
export { travelComponent };
