import Component, { ComponentArg } from "../../core/component";
import { Color } from "../../type";
declare type RectArg = {
    transform: ComponentArg["transform"];
    name?: string;
    borderWidth?: number;
    borderColor?: string;
    backgroundColor?: string;
    borderRadius?: number;
};
export default class Rect extends Component {
    #private;
    constructor({ transform, borderWidth, borderColor, borderRadius, backgroundColor, name, }: RectArg);
    set borderWidth(v: number);
    get borderWidth(): number;
    set borderRadius(v: number);
    get borderRadius(): number;
    set borderColor(v: Color);
    get borderColor(): Color;
    set backgroundColor(v: Color);
    get backgroundColor(): Color;
}
export {};
