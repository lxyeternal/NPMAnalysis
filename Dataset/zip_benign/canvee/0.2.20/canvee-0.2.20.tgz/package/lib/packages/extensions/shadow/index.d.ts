import { CanveeExtension } from "../../core/extension";
declare type ShadowArg = {
    color: string;
    offset?: {
        x: number;
        y: number;
    };
    blur: number;
};
/**
 *
 *
 * @export
 * @class Shadow
 * @implements {CanveeExtension}
 * @description Shadow组件会为组件添加阴影
 */
export default class Shadow extends CanveeExtension {
    #private;
    offset: Required<ShadowArg>["offset"];
    constructor(arg: ShadowArg);
    private update;
    beforeRender(_c: any, ctx: CanvasRenderingContext2D): void;
    set color(s: string);
    get color(): string;
    set blur(s: number);
    get blur(): number;
}
export {};
