declare const reactive: <T extends object>(target: T, notifyChange: (v: any) => void) => T;
declare const reactiveProxy: <T extends object>(target: T, notifyChange: (v: any) => void) => T;
export default reactive;
export { reactiveProxy };
