import Component, { ComponentArg } from "../../core/component";
import { Resource } from "../../core/resource";
import { DeepRequied } from "../../type";
declare type ImgArg = {
    image: Resource;
    clip?: {
        x: number;
        y: number;
        w: number;
        h: number;
    };
};
/**
 *
 *
 * @export
 * @class Img
 * @extends {Component}
 * 加载图片组件，用于显示图片
 */
export default class Img extends Component {
    resource: Resource;
    clip: DeepRequied<ImgArg>["clip"];
    hasSizeInArg: boolean;
    constructor({ ...arg }: ComponentArg & ImgArg);
    get image(): any;
}
export {};
