import Graphic from "../graphic";
import { Size } from "../../type";
declare type RectArg = {
    grid?: [number, number];
    size: Size;
};
export default function createGrid({ grid, size }: RectArg): Graphic;
export {};
