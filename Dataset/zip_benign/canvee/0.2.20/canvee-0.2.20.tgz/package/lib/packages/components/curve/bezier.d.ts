declare type Point = {
    x: number;
    y: number;
};
export default function generateBezierControllPoints(generatePoints: Array<Point>): {
    bezierPoints: {
        beginPoint: Point;
        controllPointA: Point;
        controllPointB: Point;
        endPoint: Point;
    }[];
    getPoint: (p: number) => {
        index: number;
        x: number;
        y: number;
    };
    getProgressConfig: (progress: number) => {
        index: number;
        leading: number;
        trail: number;
    };
};
export {};
