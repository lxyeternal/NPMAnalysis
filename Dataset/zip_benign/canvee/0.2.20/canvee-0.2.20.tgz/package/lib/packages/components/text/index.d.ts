import Component, { ComponentArg } from "../../core/component";
import { Color, DeepRequied } from "../../type";
declare type TextArg = {
    text: string;
    style?: {
        color?: Color;
        fill?: Color;
        stroke?: Color;
        fontFamily?: string;
        fontSize?: number;
        textAign?: CanvasTextAlign;
        textBaseLine?: CanvasTextBaseline;
        fontWeight?: "normal" | "bold" | "bolder" | "lighter" | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900;
        fontStyle?: "normal" | "italic" | "oblique";
        strokeThickness?: number;
    };
};
/**
 *
 *
 * @export
 * @class Text
 * @extends {Component}
 * 加载文本组件，用于显示文本
 */
export default class Text extends Component {
    #private;
    style: DeepRequied<TextArg>["style"];
    measure?: TextMetrics;
    constructor({ ...arg }: ComponentArg & TextArg);
    set text(v: string);
    get text(): string;
}
export {};
