declare class Interval {
    #private;
    quene: Array<{
        name: string;
        fn: () => void;
    }>;
    constructor();
    add(name: string, fn: () => void): void;
    remove(n: string, f: () => void): void;
    getFrame(): number;
}
declare const interval: Interval;
export default interval;
