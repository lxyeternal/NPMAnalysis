import Component from "./component";
import Canvee from "./core";
import CanveeExtensionSystem, { CanveeExtension } from "./extension";
import ResourceHandler, { Resource } from "./resource";
export default Canvee;
export { CanveeExtensionSystem, CanveeExtension, Component, ResourceHandler, Resource, };
