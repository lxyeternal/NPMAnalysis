import Physics, { PhysicsType } from "./physics";
import PhysicsSystem from "./physicsSystem";
export default PhysicsSystem;
export { Physics, PhysicsType };
