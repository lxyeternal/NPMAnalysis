import { Composite, IWorldDefinition, Body } from "matter-js";
import { CanveeExtensionSystem, Component, CanveeExtension } from "../../core";
declare const collisionEvents: readonly ["collisionStart", "collisionActive", "collisionEnd"];
declare const bodyEvents: readonly ["tick", "beforeUpdate", "afterUpdate", "beforeRender", "afterRender", "afterTick"];
export declare type BodyEventsType = typeof collisionEvents[number] | typeof bodyEvents[number];
declare type PhysicsSystemArg = IWorldDefinition & {
    isTest?: boolean;
    el?: HTMLElement;
};
export default class PhysicsSystem extends CanveeExtensionSystem {
    private engine;
    private runner;
    private render?;
    private compositeIds;
    registedHooks: any;
    constructor(arg?: PhysicsSystemArg);
    private dealEvent;
    beforeSystemStart(): void;
    onSubExtensionAdded(p: CanveeExtension, c: Component): void;
    onSubExtensionDiscarded(p: CanveeExtension, _c: Component): void;
    beforeSystemNextLoop(): void;
    add(body: Body | Composite, _p: CanveeExtension): void;
    remove(body: Body | Composite): void;
    isMasterOf(u: CanveeExtension): boolean;
}
export {};
