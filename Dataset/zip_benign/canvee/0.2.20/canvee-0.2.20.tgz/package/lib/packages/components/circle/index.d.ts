import Component, { ComponentArg } from "../../core/component";
import { Color } from "../../type";
declare type CircleArg = {
    radius: number;
    style: {
        borderColor?: Color;
        backgroundColor: Color;
        borderWidth?: number;
    };
};
export default class Circle extends Component {
    #private;
    style: CircleArg["style"];
    constructor(arg: ComponentArg & CircleArg);
    set radius(r: number);
    get radius(): number;
}
export {};
