import { IChamfer, Body, Composite as Compose } from "matter-js";
import { Component, CanveeExtension } from "../../core";
import PhysicsSystem, { BodyEventsType } from "./physicsSystem";
export declare enum PhysicsType {
    Rectangle = 1,
    Circle = 2,
    Polygon = 3,
    Composite = 4
}
declare type BodyOptions = {
    chamfer?: IChamfer;
    angle?: number;
    isStatic?: boolean;
    density?: number;
    restitution?: number;
    velocity?: {
        x: number;
        y: number;
    };
    speed?: number;
    motion?: number;
    mass?: number;
    collisionFilter?: any;
    friction?: number;
};
declare type PhysicsArg = {
    body?: any;
    type?: PhysicsType;
    label?: string;
    arrs?: Array<number>;
    options?: BodyOptions;
};
declare type Emitter = {
    name: string;
    func: (e: any) => boolean | void;
};
export default class Physics extends CanveeExtension {
    private bodyParams;
    body?: Body | Compose;
    component?: Component;
    masterSystem: typeof PhysicsSystem;
    type: PhysicsType;
    protected eventMap: {
        [p in BodyEventsType]?: Array<Emitter["func"]>;
    };
    constructor(arg: PhysicsArg);
    create(component: Component): Body | Compose | undefined;
    onAdded(c: Component): void;
    beforeDestory(c: Component): void;
    beforeRender(comp: Component): void;
    on(name: BodyEventsType, fn: Emitter["func"]): void;
    /**
     *
     * @description stop listening
     */
    off(name: BodyEventsType, fn: Emitter["func"]): void;
    /**
     *
     * @param {EmitOption} [option] option.bubble set as true means to make the event
     * continual passed to the parent component until Scene
     */
    emit(name: BodyEventsType, value?: object): void;
}
export {};
