declare type ResourceType<T extends string = string> = {
    name: T;
    type: "audio" | "image";
    src: string;
};
declare type HandlerEvents = "progress" | "error" | "complete" | "loaded";
declare type HandlerEventsListener = {
    progress?: number;
    value?: any;
    error?: any;
};
declare type HandlerEventsCallback = (e: HandlerEventsListener) => void;
export declare class Resource<T extends string = string> {
    private resource;
    value?: T extends "audio" ? ArrayBuffer : T extends "image" ? HTMLCanvasElement : any;
    loaded: boolean;
    constructor(r: ResourceType<T>);
    load(): Promise<unknown> | null;
}
export default class ResourceHandler<T extends string = string> {
    private resources;
    private resourceMap;
    private eventMap;
    constructor(resources: Readonly<ResourceType<T>[]>);
    preload(): void;
    get(name: T): Resource<T>;
    getSrc(name: T): string;
    emit(eventName: HandlerEvents, e: HandlerEventsListener): void;
    on(eventName: HandlerEvents, fn: HandlerEventsCallback): void;
    off(eventName: HandlerEvents, fn: HandlerEventsCallback): void;
}
export {};
