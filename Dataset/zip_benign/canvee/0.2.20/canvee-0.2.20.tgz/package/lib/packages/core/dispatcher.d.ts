export declare type EmitOption = {
    bubble?: boolean;
};
declare type EmitListener = {
    target: unknown;
    value: unknown;
};
declare type Emitter = {
    name: string;
    func: (e: EmitListener) => boolean | void;
};
export default class Dispatcher<T extends string = string> {
    protected eventMap: {
        [propName: string]: Array<Emitter["func"]>;
    };
    parent?: Dispatcher;
    /**
     *
     * @description listen a emit event
     * the listener function return true means stop event buuble
     */
    on(name: T, fn: Emitter["func"]): void;
    /**
     *
     * @description stop listening
     */
    off(name: T, fn: Emitter["func"]): void;
    /**
     *
     * @param {EmitOption} [option] option.bubble set as true means to make the event
     * continual passed to the parent component until Scene
     */
    emit(name: T, value?: unknown, option?: EmitOption): void;
}
export {};
