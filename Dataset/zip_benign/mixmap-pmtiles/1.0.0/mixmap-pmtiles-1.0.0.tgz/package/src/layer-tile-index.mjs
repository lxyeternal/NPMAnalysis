import { tileToBBOX } from '@mapbox/tilebelt'

export function tileId (tile) {
  return tile.join('-')
}

export function tileIdToTile (tileId) {
  return tileId.split('-').map(Number)
}

export function layerTileIndex (tiles) {
  return tiles
    .map((tile) => {
      const key = tileId(tile)
      const bbox = tileToBBOX(tile)
      return {
        [key]: bbox
      }
    })
    .reduce((accum, curr) => {
      return {
        ...accum,
        ...curr,
      }
    }, {})

}