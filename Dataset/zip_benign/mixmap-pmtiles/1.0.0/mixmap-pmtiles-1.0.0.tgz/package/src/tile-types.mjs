import { PMTiles, TileType } from 'pmtiles'

export const rasterTileTypes = new Set([
  TileType.Png,
  TileType.Jpeg,
  TileType.Webp,
  TileType.Avif
])

export { TileType } from 'pmtiles'

export const isRasterTile = (x) => {
  return rasterTileTypes.has(x)
}

export const getTileType = async (source) => {
  const pmtiles = new PMTiles(source)
  const header = await pmtiles.getHeader()
  return header.tileType
}
