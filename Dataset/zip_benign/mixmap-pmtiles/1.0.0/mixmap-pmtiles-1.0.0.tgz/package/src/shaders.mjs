import glsl from 'glslify'

export function RasterShaders (map) {
  return {
    // for raster types, we can use this common shader setup
    raster: {
      attributes: {
        position: map.prop('points'),
        tcoord: [ // sw, se, nw, ne
          0, 1,
          0, 0,
          1, 1,
          1, 0
        ],
      },
      elements: [
        0, 1, 2,
        1, 2, 3
      ],
      uniforms: {
        raster: map.prop('raster'),
        texelSize: (context, props) => {
          const width = props.raster.width
          const height = props.raster.height
          if (width && height) return [1/width, 1/height]
          return [0, 0]
        },
      },
      blend: {
        enable: true,
        func: { src: 'src alpha', dst: 'one minus src alpha' },
      },
      vert: `
        precision highp float;

        attribute vec2 position;
        attribute vec2 tcoord;
        uniform vec4 viewbox;
        uniform vec2 offset;
        uniform float aspect, zindex;
        varying vec2 vtcoord;
        varying vec2 vpos;

        void main () {
          vec2 p = position + offset;
          vtcoord = tcoord;
          vpos = position;
          gl_Position = vec4(
            (p.x - viewbox.x) / (viewbox.z - viewbox.x) * 2.0 - 1.0,
            ((p.y - viewbox.y) / (viewbox.w - viewbox.y) * 2.0 - 1.0) * aspect,
            1.0/(1.0 + zindex),
            1.0
          );
        }
      `,
      frag: `
        precision highp float;

        uniform sampler2D raster;
        uniform vec2 texelSize;

        varying vec2 vtcoord;

        void main () {
          vec4 color = texture2D(raster, vtcoord);
          gl_FragColor = color;
        }
      `,
    },
  }
}

function stencilSetProps (refValue) {
  return {
    enable: true,
    mask: 0xff,
    // if a fragment is covered, set that fragment to 1 in the stencil buffer.
    func: {
      cmp: 'always',
      ref: refValue,
      mask: 0xff
    },
    op: {
      fail: 'keep',
      zfail: 'keep',
      zpass: 'replace'
    },
  }
}

export function StencilShaders (map) {
  return {
    tileStencilHonor: {
      stencil: {
        enable: true,
        mask: 0xff,
        func: {
          cmp: 'equal',
          ref: 1,
          mask: 0xff
        },
        op: {
          fail: 'keep',
          zfail: 'keep',
          zpass: 'replace'
        },
      },
      depth: {
        enable: true,
        mask: true,
        func: 'less',
      },
    },
    tileStencilReset: {
      attributes: {
        position: map.prop('positions'),
      },
      elements: map.prop('cells'),
      uniforms: {
        viewbox: map.prop('viewbox'),
        offset: map.prop('offset'),
        aspect: function (context) {
          return context.viewportWidth / context.viewportHeight
        },
      },
      vert: `
        precision highp float;
        attribute vec2 position;
        uniform vec4 viewbox;
        uniform vec2 offset;
        uniform float aspect;
        void main () {
          vec2 p = position + offset;
          gl_Position = vec4(
            (p.x - viewbox.x) / (viewbox.z - viewbox.x) * 2.0 - 1.0,
            ((p.y - viewbox.y) / (viewbox.w - viewbox.y) * 2.0 - 1.0) * aspect,
            0, 1);
        }
      `,
      frag: `
        precision highp float;
        void main () {
          gl_FragColor = vec4(1.0);
        }
      `,
      stencil: stencilSetProps(0),
      // we want to write only to the stencil buffer,
      // so disable these masks.
      colorMask: [false, false, false, false],
      depth: {
        enable: false,
        mask: false,
      },
    },
    tileStencilMark: {
      attributes: {
        position: map.prop('positions'),
      },
      elements: map.prop('cells'),
      uniforms: {
        viewbox: map.prop('viewbox'),
        offset: map.prop('offset'),
        aspect: function (context) {
          return context.viewportWidth / context.viewportHeight
        },
      },
      vert: `
        precision highp float;
        attribute vec2 position;
        uniform vec4 viewbox;
        uniform vec2 offset;
        uniform float aspect;
        void main () {
          vec2 p = position + offset;
          gl_Position = vec4(
            (p.x - viewbox.x) / (viewbox.z - viewbox.x) * 2.0 - 1.0,
            ((p.y - viewbox.y) / (viewbox.w - viewbox.y) * 2.0 - 1.0) * aspect,
            0, 1);
        }
      `,
      frag: `
        precision highp float;
        void main () {
          gl_FragColor = vec4(1.0);
        }
      `,
      stencil: stencilSetProps(1),
      // we want to write only to the stencil buffer,
      // so disable these masks.
      colorMask: [false, false, false, false],
      depth: {
        enable: false,
        mask: false,
      },
    },
  }
}
