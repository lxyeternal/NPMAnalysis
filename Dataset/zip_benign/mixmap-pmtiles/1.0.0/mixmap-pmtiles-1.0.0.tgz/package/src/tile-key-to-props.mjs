import { PMTiles, TileType } from 'pmtiles'
import vt from '@mapbox/vector-tile'
import Protobuf from 'pbf'
import geoPrepare from '@rubenrodriguez/mixmap-georender/prepare'
import { decode as pngDecode } from 'fast-png'
import featuresToProps from '@/src/features-to-props'
import { tileIdToTile } from '@/src/layer-tile-index'

// zindex, and additional options should be user defined
export function tilePropsRaster (raster, tileBbox, { zindex=2 }={}) {
  return {
    raster,
    points: [
      tileBbox[0], tileBbox[1], // sw
      tileBbox[0], tileBbox[3], // se
      tileBbox[2], tileBbox[1], // nw
      tileBbox[2], tileBbox[3], // ne
    ],
    zindex,
  }
}

export default async function tileKeyToProps ({
  mapProps,
  source,
  tileType,
  tileKey,
  tileBbox,
  prepare,
}) {
  const pmtiles = new PMTiles(source)
  if (tileType === undefined) {
    const header = await pmtiles.getHeader()
    tileType = header.tileType
  }
  const [x, y, z] = tileIdToTile(tileKey)
  const response = await pmtiles.getZxy(z, x, y)
  if (!response?.data) {
    return { tileProps: null }
  }
  if (tileType === TileType.Png) {
    const raster = pngDecode(response.data)
    const tileProps = tilePropsRaster(raster, tileBbox)
    return { tileProps }
  }
  else if (tileType === TileType.Jpeg) {
    throw new Error('implement Jpeg decode consider')
  }
  else if (tileType === TileType.Webp) {
    throw new Error('implement Webp decode')
  }
  else if (tileType === TileType.Avif) {
    throw new Error('implement Avif decode')
  }
  // assumes vector tile from here on out
  const vectorTile = new vt.VectorTile(new Protobuf(response.data))
  const geojson = { type: 'FeatureCollection', features: [] }
  for (const layerId in vectorTile.layers) {
    const layer = vectorTile.layers[layerId]
    for (let i = 0; i < layer.length; i++) {
      const feature = layer.feature(i).toGeoJSON(x, y, z)
      if (vectorTile.layers.length > 1) feature.properties.vtLayerId = layerId
      geojson.features.push(feature)
    }
  }
  // TODO how to externally configure consuming more than just baseline georender props
  // or maybe that is left to those who want to implement their own tile consumers?
  const p = featuresToProps(geojson)
  // TODO geoPrepare should be done once, and accept decoded data?
  const geodata = geoPrepare({
    ...prepare,
    decoded: p.data,
  })
  // map : { getZoom : () => zoom, viewbox, _size }
  const tileProps = geodata.update(mapProps)
  return { tileProps }
}
