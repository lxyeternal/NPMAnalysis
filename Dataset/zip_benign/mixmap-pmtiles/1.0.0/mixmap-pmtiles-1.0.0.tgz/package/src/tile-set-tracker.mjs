const STATUS = {
  QUEUED: 0,
  LOADED: 1,
}

export class TileSetTracker {
  #tileMeta = new Map()

  constructor () {

  }

  setKeysQueued (tileKeys) {
    // track to see if any keys were added
    let keyAdded = false
    for (const tileKey of tileKeys) {
      // if a key exists, we don't want to change its state
      if (this.#tileMeta.has(tileKey)) continue
      this.#tileMeta.set(tileKey, { status: STATUS.QUEUED })
      keyAdded = true
    }
    // remove keys from our list that are not accounted for
    for (const tileKey of this.#tileMeta.keys()) {
      if (!tileKeys.includes(tileKey)) this.remove(tileKey)
    }
    return { keyAdded }
  }

  setKeyLoaded (tileKey) {
    this.#tileMeta.set(tileKey, { status: STATUS.LOADED })
  }

  remove (tileKey) {
    this.#tileMeta.delete(tileKey)
  }

  isLoaded () {
    let loadedCount = 0
    for (const { status } of this.#tileMeta.values()) {
      if (status === STATUS.LOADED) loadedCount++
    }
    return this.#tileMeta.size > 0 && this.#tileMeta.size === loadedCount
  }
}
