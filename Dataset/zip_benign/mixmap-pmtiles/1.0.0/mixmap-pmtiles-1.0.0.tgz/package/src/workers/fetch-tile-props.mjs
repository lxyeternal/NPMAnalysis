import tileKeyToProps from '@/src/tile-key-to-props'

export default function fetchTileProps(self) {
  self.onmessage = async (msg) => {
    const { tileBbox, tileKey } = msg.data
    const { tileProps } = await tileKeyToProps(msg.data)
    if (tileProps?.label?.labelEngine) {
      delete tileProps.label.labelEngine
    }
    self.postMessage({ tileBbox,  tileKey, tileProps })
  }
}
