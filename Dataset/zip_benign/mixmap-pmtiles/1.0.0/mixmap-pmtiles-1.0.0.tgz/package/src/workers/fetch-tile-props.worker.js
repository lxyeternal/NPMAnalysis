import tileKeyToProps from '@/src/tile-key-to-props'

onmessage = async (msg) => {
  const { tileBbox, tileKey } = msg.data
  const { tileProps } = await tileKeyToProps(msg.data)
  if (tileProps?.label?.labelEngine) {
    delete tileProps.label.labelEngine
  }
  postMessage({ tileBbox,  tileKey, tileProps })
}
