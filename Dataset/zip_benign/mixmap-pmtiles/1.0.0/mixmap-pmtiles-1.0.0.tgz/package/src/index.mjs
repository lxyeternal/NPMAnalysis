import {
  pointToTile,
  tileToBBOX,
} from '@mapbox/tilebelt'
import GeorenderShaders from '@rubenrodriguez/mixmap-georender'
export { GeorenderShaders }
import { propsForMap, spreadStyleTexture } from '@rubenrodriguez/mixmap-georender/prepare'
export { propsForMap, spreadStyleTexture }
import { createGlyphProps, Label, LabelPropsWorker, updateOptions } from 'tiny-label'
import { PMTiles, TileType } from 'pmtiles'

import { RasterShaders, StencilShaders } from '@/src/shaders'
export { RasterShaders, StencilShaders }
import tileKeyToProps from '@/src/tile-key-to-props'
export { tileKeyToProps }
import { tilesForBbox } from '@/src/tiles-for-bbox'
export { tilesForBbox }
import { layerTileIndex } from '@/src/layer-tile-index'
export { layerTileIndex }

import featuresToProps from '@/src/features-to-props'
export { featuresToProps }

import { TileSetTracker } from '@/src/tile-set-tracker'
export { TileSetTracker }

import FetchTilePropsWorker from '@/src/workers/fetch-tile-props.worker.js'

import { WorkerBroker, noOpBrokerOptions } from '@/src/worker-broker'
export { WorkerBroker, noOpBrokerOptions}

import { mixmapUniforms, shadersToDraws } from '@/src/shader-opts-to-draw-cmd'
export { mixmapUniforms }
import { getTileType, isRasterTile, rasterTileTypes } from '@/src/tile-types.mjs'
export { getTileType }

export { TileType } from 'pmtiles'

export const defaultSpreadForVectorTiles = {
  areas: ['areaP', 'areaT'],
  areaBorders: ['areaBorderP', 'areaBorderT'],
  lineStroke: ['lineP', 'lineT'],
  lineFill: ['lineP', 'lineT'],
  points: ['pointP', 'pointT'], 
}

export const defaultWorkers = {
  tileProps: {
    source: FetchTilePropsWorker,
    options: { count: 4 },
  },
  labelProps: {
    source: LabelPropsWorker,
    options: { count: 1 },
  }
}

/**
 * new MixmapPMTiles(map, options)
 *
 * options.source - required, the URL of the PMTiles archive
 * options.style - required for Vector Tiles, this is the georender texture
 * options.style.data - UInt8Array of the pixel data of the style texture
 * options.style.width - width of style texture image
 * options.style.height - height of style texture image
 * options.tileType - required, the PMTiles header tileType, used to decode data
 * options.shaders - optional, an object whose keys (shaderKey) have values
 *   that configure a regl draw command. The shape of this object for raster
 *   tiles can include as many shaderKeys as you would like that map onto
 *   draw calls. For vector tiles, the default shape is:
 *   { areas, areaBorders, lineStroke, lineFill, points }.
 *   This can be different if paired with worker functions that produce different
 *   tileProps via options.workers = { tileProps : () => Worker }, and
 *   options.spreads that will spread the tileProps across the draw calls.
 *   Note: `options.shaders` or `options.draws` must be defined
 * options.draws - optional, an object with keys (drawKeys) whose
 *   values are regl draw commands. If options.shaders is used, then each
 *   shaderKey will have a corresponding drawKey in the draws object.
 *   Note: `options.shaders` or `options.draws` must be defined
 * options.spreads - optional, an object with keys that correspond to drawKey
 *   names with values that map onto `tileProps` key names. This is
 *   only needed for Vector Tile archives, since Raster Tile archives
 *   will only have one set of props to spread across the shaders provided
 *   Defaults to the `defaultSpreadForVectorTiles` exported here.
 * options.worker - optional, boolean or
 *   { tileProps : WorkerBrokerProps, labelProps : WorkerBrokerProps }
 *   WorkerBrokerProps : { source : SourceProp, options : { count : number } }
 *   SourceProp : WorkerUrl | () => Worker
 *   The default workers provided by this package turn pmtiles vector tiles
 *   into decoded georender compatible regl props. If you would like to render
 *   something other than georender, you will need to define a worker that
 *   produces tileProps in the shape that you want, and then use the
 *   options.spreads object to map those tileProps onto draw calls.
 *   For a more complicated draw pipeline it may be useful to extend this
 *   class with custom _drawTilesRaster or _drawTilesVector methods.
 */
export default class MixmapPMTiles {
  _map
  _source
  _tileKeyPropsMap = new Map()
  _tileType

  _stylePixels
  _styleImageSize
  _styleTexture

  _stencilShaders

  _shaders
  _draws
  _spreads

  _mixmapUniforms

  _labelUpdateOpts
  _labelShader
  _labelOpts
  _label
  _labelProps

  _tileSetTracker
  _workerOpts
  _workerBrokers
  _tilePropsWorkerCount = 4

  constructor (map, {
      source,
      tileType,
      style,
      labels,
      spreads,
      shaders={},
      draws={},
      workers=defaultWorkers,
    }) {
    this._map = map
    this._source = source
    this._workerOpts = workers

    // tileKey : { tileBbox, tileProps }
    this._tileType = tileType

    if (tileType === TileType.Mvt && style?.data) {
      this._stylePixels = style.data
      this._styleImageSize = [style.width, style.height]
      this._styleTexture = this._map.regl.texture(style)
    }

    const stencilShaders = StencilShaders(map)

    this._shaders = shaders
    this._draws = draws
    this._draws.stencil = {
      reset: this._map.regl(stencilShaders.tileStencilReset),
      mark: this._map.regl(stencilShaders.tileStencilMark),
    }
    this._spreads = spreads
      || tileType === TileType.Mvt
        ? defaultSpreadForVectorTiles
        : {}

    this._mixmapUniforms = mixmapUniforms(map)

    if (labels) {
      if (labels.update) {
        this._labelUpdateOpts = labels.update  
        delete labels.update
      }
      else {
        this._labelUpdateOpts = updateOptions
      }
      if (style?.data && !labels.style?.data) {
        labels.style = style
      }

      this._labelShader = labels.shader
      delete labels.shader
      
      this._labelOpts = labels
      if (this?._workerOpts?.labelProps) {
        this._label = true
      }
      else {
        this._label = new Label(labels)  
      }
      this._labelProps = []
    }

    this._createDraws()
    this._addDrawHook()
    this._addLayer()
  }
  _addDrawHook () {
    this._map.on('draw:end', () => {
      this._drawTiles()
    })
  }
  _createDraws () {
    this._draws = shadersToDraws(this._map, {
      tileType: this._tileType,
      shaders: this._shaders,
      draws: this._draws,
    })
    this._createDrawsLabels()
  }
  _createDrawsLabels () {
    if (!this._labelShader || !Array.isArray(this._labelOpts?.fontFamily)) return
    this._draws.label = this._labelOpts.fontFamily.map(() => {
      return this._map.regl({
        ...this._labelShader,
        uniforms: {
          ...this._labelShader.uniforms,
          ...this._mixmapUniforms,
        }
      })
    })
  }
  _addLayer () {
    this._tileSetTracker = new TileSetTracker()
    if (this._workerOpts) {
      this._addLayerInWorkers()
    }
    else {
      this._addLayerMainThread()
    }
  }
  _addLayerInWorkers () {
    const createWorkerBroker = (opts) => {
      if (!(opts?.source && opts?.options)) {
        opts = noOpBrokerOptions
      }
      const { source, options } = opts
      return new WorkerBroker(source, options)
    }

    this._workerBrokers = {
      tileProps: createWorkerBroker(this._workerOpts?.tileProps),
      labelProps: createWorkerBroker(this._workerOpts?.labelProps),
    }

    this._workerBrokers.tileProps.addEventListener('message', (msg) => this._workerHandlerTileProps(msg))
    this._workerBrokers.labelProps.addEventListener('message', (msg) => this._workerHandlerLabelProps(msg))

    this._workerBrokers.labelProps.postMessage({
      type: 'initialize',
      options: this._labelOpts,
    })

    this._map.addLayer({
      viewbox: (bbox, zoom, cb) => this._workerAddLayerViewbox(bbox, zoom, cb),
      add: (tileKey, tileBbox) => this._workerAddLayerAdd(tileKey, tileBbox),
      remove: (tileKey, tileBbox) => this._workerAddLayerRemove(tileKey, tileBbox),
    })
  }
  _workerHandlerTileProps (msg) {
    if (!msg.detail) return
    const { tileBbox, tileKey, tileProps } = msg.detail
    this._tileSetTracker.setKeyLoaded(tileKey)
    const processLabels = this._tileSetTracker.isLoaded()

    if (tileProps === null && processLabels) {
      this._getLabelPropsInWorker()
      return
    }
    else if (tileProps === null) {
      return
    }
    if (tileProps?.raster) {
      tileProps.raster = this._map.regl.texture(tileProps.raster)
    }
    else {
      // if we are dealing with georender props, we want to
      // spread our style texture within
      spreadStyleTexture(this._styleTexture, tileProps)
    }
    this._tileKeyPropsMap.set(tileKey, { tileBbox, tileProps })
    this._map.draw()
    if (processLabels) {
      this._getLabelPropsInWorker()
    }
  }
  _workerHandlerLabelProps (msg) {
    if (!this._tileSetTracker.isLoaded()) return
    if (msg.detail?.type !== 'update') return
    this._labelProps = msg.detail.labelProps
    this._spreadGlyphProps()
    this._map.draw()
  }
  _workerAddLayerViewbox (bbox, zoom, cb) {
    const tiles = tilesForBbox(bbox, zoom)
    const layerTiles = layerTileIndex(tiles)
    const { keyAdded } = this._tileSetTracker.setKeysQueued(Object.keys(layerTiles))
    if (!keyAdded && this._tileSetTracker.isLoaded()) {
      this._getLabelPropsInWorker()
    }
    cb(null, layerTiles)
  }
  async _workerAddLayerAdd (tileKey, tileBbox) {
    try {
      const mapProps = propsForMap(this._map)
      const msg = {
        mapProps,
        source: this._source,
        tileType: this._tileType,
        tileKey,
        tileBbox,
        prepare: {
          stylePixels: this._stylePixels,
          imageSize: this._styleImageSize,
        },
      }
      this._workerBrokers.tileProps.postMessage(msg, [], tileKey)
    }
    catch (error) {
      console.log(error)
    }
  }
  _workerAddLayerRemove (tileKey, tileBbox) {
    this._tileSetTracker.remove(tileKey)
    this._tileKeyPropsMap.delete(tileKey)
  }
  _addLayerMainThread () {
    this._map.addLayer({
      viewbox: (bbox, zoom, cb) => this._mainThreadAddLayerViewbox(bbox, zoom, cb),
      add: async (tileKey, tileBbox) => this._mainThreadAddLayerAdd(tileKey, tileBbox),
      remove: (tileKey, tileBbox) => this._mainThreadAddLayerRemove(tileKey, tileBbox),
    })
  }
  _mainThreadAddLayerViewbox (bbox, zoom, cb) {
    const tiles = tilesForBbox(bbox, zoom)
    const layerTiles = layerTileIndex(tiles)
    this._tileSetTracker.setKeysQueued(Object.keys(layerTiles))
    cb(null, layerTiles)
  }
  async _mainThreadAddLayerAdd(tileKey, tileBbox) {
    try {
      const mapProps = propsForMap(this._map)
      const { tileProps } = await tileKeyToProps({
        mapProps,
        source: this._source,
        tileType: this._tileType,
        tileKey,
        tileBbox,
        prepare: {
          stylePixels: this._stylePixels,
          imageSize: this._styleImageSize,
        },
      })
      this._tileSetTracker.setKeyLoaded(tileKey)
      if (!tileProps) return
      if (tileProps?.raster) {
        tileProps.raster = this._map.regl.texture(tileProps.raster)
      }
      else {
        // if we are dealing with georender props, we want to
        // spread our style texture within
        spreadStyleTexture(this._styleTexture, tileProps)
      }
      this._tileKeyPropsMap.set(tileKey, { tileBbox, tileProps })
      this._map.draw()
    }
    catch (error) {
      console.log(error)
    }
  }
  _mainThreadAddLayerRemove (tileKey, tileBbox) {
    this._tileSetTracker.remove(tileKey)
    this._tileKeyPropsMap.delete(tileKey)
  }
  _drawLabels () {
    if (!this._label) return
    if (this._workerOpts) {
      this._drawLabelsGlyphs()
    }
    else if (!this._workerOpts) {
      this._getLabelPropsMainThread()
      this._spreadGlyphProps()
      this._drawLabelsGlyphs()
    }
  }
  _getLabelPropsInWorker () {
    if (isRasterTile(this._tileType)) return
    const georenderPropsForLabels = []
    for (const [tileKey, { tileProps }] of this._tileKeyPropsMap) {
      const clone = {}
      for (const geomType in tileProps) {
        clone[geomType] = {}
        for (const propType in tileProps[geomType]) {
          if (typeof tileProps[geomType][propType] !== 'function') {
            clone[geomType][propType] = tileProps[geomType][propType]
          }
        }
      }
      georenderPropsForLabels.push(clone)
    }
    this._workerBrokers.labelProps.postMessage({
      type: 'update',
      options: [
        georenderPropsForLabels,
        propsForMap(this._map),
        this._labelUpdateOpts
      ]
    })
  }
  _getLabelPropsMainThread () {
    const georenderPropsForLabels = []
    for (const [tileKey, { tileProps }] of this._tileKeyPropsMap) {
      georenderPropsForLabels.push(tileProps)
    }
    this._labelProps = this._label.update(
      georenderPropsForLabels,
      propsForMap(this._map),
      this._labelUpdateOpts
    )
  }
  _spreadGlyphProps () {
    createGlyphProps(this._labelProps, this._map)
  }
  _drawLabelsGlyphs () {
    if (!(this?._labelProps?.glyphs?.length > 0) || !this._tileSetTracker.isLoaded()) return
    for (let i = 0; i < this._labelProps.glyphs.length; i++) {
      this._draws.label[i](this._labelProps.glyphs[i])
    }
  }
  _drawTilesVector () {
    for (const mapProps of this._map._props()) {
      const tileResetProps = {
        ...mapProps,
        ...fullEarthMesh(),
      }
      for (const [tileKey, { tileBbox, tileProps }] of this._tileKeyPropsMap) {
        const tileMarkProps = {
          ...mapProps,
          ...bboxToMesh(tileBbox),
        }
        this._draws.stencil.reset(tileResetProps)
        this._draws.stencil.mark(tileMarkProps)
        for (const drawKey in this._spreads) {
          for (const tilePropKey of this._spreads[drawKey]) {
            this._draws[drawKey]({
              ...mapProps,
              ...tileProps[tilePropKey],
            })
          }
        }
      } 
    }
  }
  _drawTilesRaster () {
    for (const mapProps of this._map._props()) {
      const tileResetProps = {
        ...mapProps,
        ...fullEarthMesh(),
      }
      for (const [tileKey, { tileBbox, tileProps }] of this._tileKeyPropsMap) {
        const tileMarkProps = {
          ...tileProps,
          ...mapProps,
          ...bboxToMesh(tileBbox),
        }
        const rasterProps = {
          ...mapProps,
          ...tileProps,
        }
        this._draws.stencil.reset(tileResetProps)
        this._draws.stencil.mark(tileMarkProps)
        for (const key in this._draws) {
          if (typeof this._draws[key] !== 'function') continue
          this._draws[key](rasterProps)
        }
      } 
    }
  }
  _drawTiles () {
    // ensure we got a pmtiles header and created draw calls in response to it
    if (!this._tileType || !this._draws) return
    if (rasterTileTypes.has(this._tileType)) this._drawTilesRaster()
    else {
      this._drawTilesVector()
      this._drawLabels()
    }
  }
}

export function bboxToMesh (bbox) {
  return {
    positions: [
      bbox[0], bbox[1],
      bbox[0], bbox[3],
      bbox[2], bbox[3],
      bbox[0], bbox[1],
      bbox[2], bbox[3],
      bbox[2], bbox[1]
    ],
    cells: [0, 1, 2, 3, 4, 5]
  }
}

export function fullEarthMesh () {
  const bbox = [-180, -90, 180, 90]
  return bboxToMesh(bbox)
}
