/*

WorkerBroker is used to create a series of workers to distribute work
to. It has the same interface as dealing with an individual Web Worker
but handles Worker state to parallelize work.

The typical `postMessage` method is extended to accept an optional 3rd
parameter, an `id`. This id can be used to terminate and re-create a
worker, or remove the message from the queue, or at the least it can
prevent the value from being returned.

*/

const WORKER_STATUS = {
  FREE: 0,
  BUSY: 1,
}

export class WorkerBroker extends EventTarget {
  #queuedMessages = []
  // workers : [WorkerSpec]
  // WorkerSpec : { worker : Web Worker, status : WORKER_STATUS, messageId }
  #workers = []

  #canceledMessageIds = []
  #fallbackMessageIdCounter = -1

  workerUrl = null
  workerFn = null

  constructor (source, opts) {
    super()
    if (typeof source === 'function') {
      this.initFn(source, opts)
    }
    else if (typeof source === 'string' || source instanceof URL) {
      this.initUrl(source, opts)
    }
  }
  initUrl (workerUrl, { count=1 }={}) {
    this.workerUrl = workerUrl

    for (let i = 0; i < count; i++) {
      const ws = this.#createWorker(i)
      this.#workers.push(ws)
    }
  }
  initFn (createFn, { count=1 }={}) {
    this.workerFn = createFn
    for (let i = 0; i < count; i++) {
      const worker = createFn()
      worker.addEventListener('message', this.#onmessage(i))
      this.#workers.push({
        worker,
        status: WORKER_STATUS.FREE,
      })
    }
  }
  #createWorker (workerIndex) {
    let worker
    if (this.workerUrl) {
      worker = new Worker(this.workerUrl)
    }
    else if (this.workerFn) {
      worker = this.workerFn()
    }
    worker.onmessage = this.#onmessage(workerIndex)
    const status = WORKER_STATUS.FREE
    return { worker, status}
  }
  postMessage (message, transfer, id) {
    if (typeof id === 'undefined') {
      this.#fallbackMessageIdCounter++
      id = this.#fallbackMessageIdCounter
    }
    const workerSpec = this.#workers.find(ws => ws.status === WORKER_STATUS.FREE)
    if (!workerSpec) {
      // no free workers, queue the message and 
      this.#queuedMessages.push({ message, transfer, id })
      // early exit
      return
    }
    workerSpec.messageId = id
    workerSpec.status = WORKER_STATUS.BUSY
    workerSpec.worker.postMessage(message, transfer)
  }
  cancelMessage (id) {
    // message is being worked on, terminate the worker, and keep a reference
    // to the canceled message id in case it finishes before it can be shut down
    const workerIndex = this.#workers.findIndex(ws => ws.messageId === id)
    if (workerIndex > -1) {
      this.#workers[workerIndex].worker.terminate()
      this.#workers[workerIndex] = this.#createWorker(workerIndex)
      this.#canceledMessageIds.push(id)
      return
    }

    // check to see if the message is in our queue, and we can remove
    // before it gets shifted and processed
    const queuedMessageIndex = this.#queuedMessages.findIndex(qm => qm.id === id)
    if (queuedMessageIndex > -1) {
      this.#queuedMessages.splice(queuedMessageIndex, 1)
      return
    }
  }
  #onmessage (workerIndex) {
    return (event) => {
      const worker = this.#workers[workerIndex]
      worker.status = WORKER_STATUS.FREE
      const id = worker.messageId
      worker.messageId = null

      let canceled = false
      const cancelIdIndex = this.#canceledMessageIds.indexOf(id)
      if (cancelIdIndex > -1) {
        canceled = true
        this.#canceledMessageIds.splice(cancelIdIndex, 1)
      }

      const ce = new CustomEvent('message', { detail: event.data })
      // user must create their own WorkerBroker.onmessage function
      if (canceled === false && typeof this?.onmessage === 'function') {
        this?.onmessage?.(ce)  
      }
      else if (canceled === false) {
        this.dispatchEvent(ce)
      }
      
      if (this.#queuedMessages.length > 0) {
        const { message, transfer, id } = this.#queuedMessages.shift()
        this.postMessage(message, transfer, id)
      }
    }
  }
}

export const noOpBrokerOptions = {
  source: () => {
    const blob = new Blob([
      `onmessage = () => postMessage(null)`
    ], { type: "text/javascript" })

    // Note: window.webkitURL.createObjectURL() in Chrome 10+.
    const worker = new Worker(window.URL.createObjectURL(blob))
    return worker  
  },
  options: { count: 1 },
}
