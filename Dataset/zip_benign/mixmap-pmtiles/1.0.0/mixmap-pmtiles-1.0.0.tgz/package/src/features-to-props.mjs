import earcut, { flatten } from 'earcut'
import getNormals from 'polyline-normals'

import featuresJson from '@rubenrodriguez/georender-pack/features.json'
import tagPriorities from '@rubenrodriguez/georender-pack/lib/tagpriorities.json'

const features = {}
for (var i = 0; i < featuresJson.length; i++) {
  features[featuresJson[i]] = i
}

export default function featuresToProps (fc) {
  const sizes = {
    point: { types: 0, ids: 0, positions: 0 },
    line: { types: 0, ids: 0, positions: 0, normals: 0 },
    area: { types: 0, ids: 0, positions: 0, cells: 0 },
    areaBorder: { types: 0, ids: 0, positions: 0, normals: 0 },
  }
  fc.features.forEach((feature) => addFeatureToSizes(feature, sizes))
  const offsets = {
    point: { types: 0, ids: 0, positions: 0, labels: 0 },
    line: { types: 0, ids: 0, positions: 0, normals: 0, labels: 0 },
    area: { types: 0, ids: 0, positions: 0, cells: 0, labels: 0 },
    areaBorder: { types: 0, ids: 0, positions: 0, normals: 0 },
  }
  const data = {
    point: {
      types: new Float32Array(sizes.point.types),
      ids: Array(sizes.point.ids).fill(0),
      positions: new Float32Array(sizes.point.positions),
      labels: {},
    },
    line: {
      types: new Float32Array(sizes.line.types),
      ids: Array(sizes.line.ids).fill(0),
      positions: new Float32Array(sizes.line.positions),
      normals: new Float32Array(sizes.line.normals),
      labels: {}
    },
    area: {
      types: new Float32Array(sizes.area.types),
      ids: Array(sizes.area.ids).fill(0),
      positions: new Float32Array(sizes.area.positions),
      cells: new Uint32Array(sizes.area.cells),
      labels: {}
    },
    areaBorder: {
      types: new Float32Array(sizes.areaBorder.types),
      ids: Array(sizes.areaBorder.ids).fill(0),
      positions: new Float32Array(sizes.areaBorder.positions),
      normals: new Float32Array(sizes.areaBorder.normals)
    },
  }
  fc.features.forEach((feature, index) => addFeatureToData(feature, data, offsets, index))
  return { sizes, data, offsets }
}

function addFeatureToSizes (feature, sizes) {
  if (feature.geometry.type === 'Point') {
    sizes.point.types++
    // sizes.point.ids += 2 // georender-pack/decode does this
    sizes.point.ids++ // but data appears to spread in this shape
    sizes.point.positions += 2
  }
  else if (feature.geometry.type === 'MultiPoint') {
    const pointCount = feature.geometry.coordinates.length
    sizes.point.types += pointCount
    sizes.point.ids += pointCount * 2
    sizes.point.positions += pointCount * 2
  }
  else if (feature.geometry.type === 'LineString') {
    const pointCount = feature.geometry.coordinates.length
    // additional points broken down:
    // - one coord the dupe the first position
    // - one coord to dupe the last position
    // - one coord that appears at the end with 0 values
    sizes.line.types += pointCount * 2 + 3
    sizes.line.ids += pointCount * 2 + 3
    sizes.line.positions += pointCount * 4 + 6
    sizes.line.normals += pointCount * 4 + 6
  }
  else if (feature.geometry.type === 'MultiLineString') {
    for (let i = 0; i < feature.geometry.coordinates.length; i++) {
      const pointCount = feature.geometry.coordinates[i].length
      sizes.line.types += pointCount * 2 + 3
      sizes.line.ids += pointCount * 2 + 3
      sizes.line.positions += pointCount * 4 + 6
      sizes.line.normals += pointCount * 4 + 6
    }
  }
  else if (feature.geometry.type === 'Polygon') {
    const data = flatten(feature.geometry.coordinates)
    const cells = earcut(data.vertices, data.holes, data.dimensions)
    sizes.area.types += data.vertices.length / 2
    sizes.area.ids += data.vertices.length / 2
    sizes.area.positions += data.vertices.length
    sizes.area.cells += cells.length
    sizes.areaBorder.types = data.vertices.length + 2
    sizes.areaBorder.ids = data.vertices.length + 2
    sizes.areaBorder.positions = data.vertices.length * 2 + 4
    sizes.areaBorder.normals = data.vertices.length * 2 + 4
  }
  else if (feature.geometry.type === 'MultiPolygon') {
    for (let i = 0; i < feature.geometry.coordinates.length; i++) {
      const polygon = feature.geometry.coordinates[i]
      const data = flatten(polygon)
      const cells = earcut(data.vertices, data.holes, data.dimensions)
      sizes.area.types += data.vertices.length / 2
      sizes.area.ids += data.vertices.length / 2
      sizes.area.positions += data.vertices.length
      sizes.area.cells += cells.length
      sizes.areaBorder.types = data.vertices.length + 2
      sizes.areaBorder.ids = data.vertices.length + 2
      sizes.areaBorder.positions = data.vertices.length * 2 + 4
      sizes.areaBorder.normals = data.vertices.length * 2 + 4
    }
  }
  return sizes
}

function addFeatureToData (feature, data, offsets, indexAsFallbackId) {
  let osmType = osmTypeForFeature(feature)
  const id = feature?.properties?.id || indexAsFallbackId
  if (feature.geometry.type === 'Point') {
    addPoint(feature.geometry.coordinates)
    data.point.labels[id] = featureLabels(feature)
  }
  else if (feature.geometry.type === 'MultiPoint') {
    for (let i = 0; i < feature.geometry.coordinates.length; i++) {
      addPoint(feature.geometry.coordinates[i])
    }
    data.point.labels[id] = featureLabels(feature)
  }
  else if (feature.geometry.type === 'LineString') {
    addLine(feature.geometry.coordinates)
    data.line.labels[id] = featureLabels(feature)
  }
  else if (feature.geometry.type === 'MultiLineString') {
    for (let i = 0; i < feature.geometry.coordinates.length; i++) {
      addLine(feature.geometry.coordinates[i])
    }
    data.line.labels[id] = featureLabels(feature)
  }
  else if (feature.geometry.type === 'Polygon') {
    addPolygon(feature.geometry.coordinates)
    data.area.labels[id] = featureLabels(feature)
  }
  else if (feature.geometry.type === 'MultiPolygon') {
    for (let i = 0; i < feature.geometry.coordinates.length; i++) {
      addPolygon(feature.geometry.coordinates[i])
    }
    data.area.labels[id] = featureLabels(feature)
  }
  return data

  function addPoint (pointCoords) {
    data.point.types[offsets.point.types++] = osmType
    data.point.ids[offsets.point.ids++] = id
    data.point.positions[offsets.point.positions++] = pointCoords[0]
    data.point.positions[offsets.point.positions++] = pointCoords[1]
  }

  function addLine (lineCoords) {
    data.line.types[offsets.line.types++] = osmType
    data.line.ids[offsets.line.ids++] = id
    let lon
    let lat
    const positions = []
    for (let i = 0; i < lineCoords.length; i++) {
      data.line.types[offsets.line.types++] = osmType
      data.line.types[offsets.line.types++] = osmType
      data.line.ids[offsets.line.ids++] = id
      data.line.ids[offsets.line.ids++] = id
      lon = lineCoords[i][0]
      lat = lineCoords[i][1]
      if (i === 0) {
        data.line.positions[offsets.line.positions++] = lon
        data.line.positions[offsets.line.positions++] = lat
      }
      data.line.positions[offsets.line.positions++] = lon
      data.line.positions[offsets.line.positions++] = lat
      data.line.positions[offsets.line.positions++] = lon
      data.line.positions[offsets.line.positions++] = lat
      positions.push([lon, lat])
    }
    data.line.types[offsets.line.types++] = osmType
    data.line.ids[offsets.line.ids++] = id
    data.line.positions[offsets.line.positions++] = lon
    data.line.positions[offsets.line.positions++] = lat
    const normals = getNormals(positions)
    let scale = Math.sqrt(normals[0][1])
    data.line.normals[offsets.line.normals++] = normals[0][0][0]*scale
    data.line.normals[offsets.line.normals++] = normals[0][0][1]*scale
    for (let i=0; i<normals.length; i++) {
      scale = Math.sqrt(normals[i][1])
      data.line.normals[offsets.line.normals++] = normals[i][0][0]*scale
      data.line.normals[offsets.line.normals++] = normals[i][0][1]*scale
      data.line.normals[offsets.line.normals++] = -1*normals[i][0][0]*scale
      data.line.normals[offsets.line.normals++] = -1*normals[i][0][1]*scale
    }
    var normOffset = offsets.line.normals
    data.line.normals[offsets.line.normals++] = data.line.normals[normOffset-2]
    data.line.normals[offsets.line.normals++] = data.line.normals[normOffset-1]
  }

  function addPolygon (polygonCoords) {
    const tris = flatten(polygonCoords)
    const cells = earcut(tris.vertices, tris.holes, tris.dimensions)
    let lon
    let lat
    const pindex = offsets.area.positions
    const positions = []
    for (let i = 0; i < tris.vertices.length-1; i+=2) {
      lon = tris.vertices[i + 0]
      lat = tris.vertices[i + 1]
      data.area.types[offsets.area.types++] = osmType
      data.area.ids[offsets.area.ids++] = id
      data.area.positions[offsets.area.positions++] = lon
      data.area.positions[offsets.area.positions++] = lat
      positions.push([lon, lat])
    }
    for (let i = 0; i < cells.length; i++) {
      data.area.cells[offsets.area.cells++] = pindex + cells[i]
    }
    const loops = getLoops(cells, positions)
    for (let i = 0; i < loops.length; i++) {
      addAreaBorderPositions(data, offsets, loops[i], id, osmType, false)
    }
  }
}

export function osmTypeForFeature (feature) {
  let osmType = features['place.other']
  const tags = Object.entries(feature.properties || {})
  if(tags.length !== 0){
    var arr = []
    var priorities = []
    for (var i=0; i<tags.length; i++) {
      if (features[tags[i][0] + '.' + tags[i][1]] !== undefined) {
        osmType = features[tags[i][0] + '.' + tags[i][1]]
        arr.push(tags[i][0] + '.' + tags[i][1])
      }
    }
    if (arr.length > 1) {
      arr.sort()
      for (var j=0; j<arr.length; j++) {
        if (tagPriorities[arr[j]] && tagPriorities[arr[j]].priority) {
          priorities.push(tagPriorities[arr[j]].priority)
        }
        else if (tagPriorities[arr[j].split('.')[0]+'.*'] &&
          tagPriorities[arr[j].split('.')[0]+'.*'].priority) {
            priorities.push(tagPriorities[arr[j].split('.')[0]+'.*'].priority)
        }
        else priorities.push(50)
      }
      osmType = features[arr[priorities.indexOf(Math.max(...priorities))]]
    }
  }
  return osmType
}

export const nameRegEx = /^([^:]+_|)name($|:)/
export const nameReplaceRegEx = /^(|[^:]+_)name($|:)/

export function featureLabels (feature) {
  const labels = []
  Object.keys(feature.properties).forEach((key) => {
    if (!nameRegEx.test(key)) return
    const pre = key.startsWith('alt_name:')
      ? key.replace(nameReplaceRegEx, 'alt:')
      : key.replace(nameReplaceRegEx, '')
    const label = `${pre}=${feature.properties[key]}`
    labels.push(label)
  })
  return labels
}

/* get-loops : start*/
// lifted from @rubenrodriguez/georender-pack
// - https://github.com/rubillionaire/georender-pack/blob/ca3813284cb68a398be04a2fc39628510cc50a14/lib/get-loops.js
// - https://www.npmjs.com/package/@rubenrodriguez/georender-pack
function getLoops(cells, positions) {
  var loops = [], loop = []
  var visited = Array(positions.length).fill(false)
  var edgeGraph = getEdgeGraph(cells)
  for (var i = 0; i < positions.length; i++) {
    if (visited[i]) continue
    var firstIndex = i, lastIndex = -1
    for (var d = 0; d < 2; d++) {
      var start = i, c = i, prev = -1
      do {
        if (visited[c]) break
        if (d === 0) {
          loop.push(positions[c])
          lastIndex = c
        } else {
          loop.unshift(positions[c])
          firstIndex = c
        }
        visited[c] = true
        var es = edgeGraph[c]
        if (es === undefined) break
        var e = -1
        if (d === 0) {
          for (var j = 0; j < es.length; j++) {
            var x = es[j]
            if (visited[x]) continue
            e = x
            break
          }
        } else {
          for (var j = es.length-1; j >= 0; j--) {
            var x = es[j]
            if (visited[x]) continue
            e = x
            break
          }
        }
        if (e < 0) break
        prev = c
        c = e
      } while (start !== c)
    }
    if (loop.length > 2) {
      if (firstIndex !== lastIndex) {
        loop.push(loop[0])
      }
      loops.push(loop)
      loop = []
    }
  }
  return loops
}

function getEdgeGraph(cells) {
  var graph = {}, count = {}
  for (var i = 0; i < cells.length; i+=3) {
    var c0 = cells[i+0]
    var c1 = cells[i+1]
    var c2 = cells[i+2]
    var k01 = ekey(c0,c1)
    var k02 = ekey(c0,c2)
    var k12 = ekey(c1,c2)
    count[k01] = (count[k01] || 0) + 1
    count[k02] = (count[k02] || 0) + 1
    count[k12] = (count[k12] || 0) + 1
  }
  for (var i = 0; i < cells.length; i+=3) {
    var c0 = cells[i+0]
    var c1 = cells[i+1]
    var c2 = cells[i+2]
    var k01 = ekey(c0,c1)
    var k02 = ekey(c0,c2)
    var k12 = ekey(c1,c2)
    if (count[k01] === 1) addGraph(graph,c0,c1)
    if (count[k02] === 1) addGraph(graph,c0,c2)
    if (count[k12] === 1) addGraph(graph,c1,c2)
  }
  return graph
}

function addGraph(graph,a,b) {
  if (graph[a] === undefined) graph[a] = [b]
  else if (graph[a][0] > b) graph[a].unshift(b)
  else graph[a].push(b)
  if (graph[b] === undefined) graph[b] = [a]
  else if (graph[b][0] > a) graph[b].unshift(a)
  else graph[b].push(a)
}

function ekey(a,b) { return Math.min(a,b) + ',' + Math.max(a,b) }
/* get-loops : end*/

// lifted from @rubenrodriguez/georender-pack
// - https://github.com/rubillionaire/georender-pack/blob/ca3813284cb68a398be04a2fc39628510cc50a14/decode.js#L384
// - https://www.npmjs.com/package/@rubenrodriguez/georender-pack
function addAreaBorderPositions(data, offsets, positions, id, type, closed) {
  if (positions.length < 2) return
  var positionsCount = 2+6+(4*positions.length)
  var ex = 1.5
  if (offsets.areaBorder.positions + positions.length + positionsCount >= data.areaBorder.positions.length) {
    var ndataTypes = new Float32Array(data.areaBorder.types.length*ex)
    for (var k=0; k<data.areaBorder.types.length; k++) {
      ndataTypes[k] = data.areaBorder.types[k]
    }
    data.areaBorder.types = ndataTypes
    var ndataPos = new Float32Array(data.areaBorder.positions.length*ex)
    for (var k=0; k<data.areaBorder.positions.length; k++) {
      ndataPos[k] = data.areaBorder.positions[k]
    }
    data.areaBorder.positions = ndataPos
    var ndataNorms = new Float32Array(data.areaBorder.normals.length*ex)
    for (var k=0; k<data.areaBorder.normals.length; k++) {
      ndataNorms[k] = data.areaBorder.normals[k]
    }
    data.areaBorder.normals = ndataNorms
  }
  var normals = getNormals(positions, closed)
  var scale = Math.sqrt(normals[0][1])
  data.areaBorder.ids[offsets.areaBorder.ids++] = id
  data.areaBorder.types[offsets.areaBorder.types++] = type
  data.areaBorder.positions[offsets.areaBorder.positions++] = positions[0][0]
  data.areaBorder.positions[offsets.areaBorder.positions++] = positions[0][1]
  data.areaBorder.normals[offsets.areaBorder.normals++] = normals[0][0][0]*scale
  data.areaBorder.normals[offsets.areaBorder.normals++] = normals[0][0][1]*scale
  for (var j = 0; j < positions.length; j++) {
    scale = Math.sqrt(normals[j][1])
    data.areaBorder.ids[offsets.areaBorder.ids++] = id
    data.areaBorder.ids[offsets.areaBorder.ids++] = id
    data.areaBorder.types[offsets.areaBorder.types++] = type
    data.areaBorder.types[offsets.areaBorder.types++] = type
    data.areaBorder.positions[offsets.areaBorder.positions++] = positions[j][0]
    data.areaBorder.positions[offsets.areaBorder.positions++] = positions[j][1]
    data.areaBorder.positions[offsets.areaBorder.positions++] = positions[j][0]
    data.areaBorder.positions[offsets.areaBorder.positions++] = positions[j][1]
    data.areaBorder.normals[offsets.areaBorder.normals++] = normals[j][0][0]*scale
    data.areaBorder.normals[offsets.areaBorder.normals++] = normals[j][0][1]*scale
    data.areaBorder.normals[offsets.areaBorder.normals++] = -normals[j][0][0]*scale
    data.areaBorder.normals[offsets.areaBorder.normals++] = -normals[j][0][1]*scale
  }
  data.areaBorder.ids[offsets.areaBorder.ids++] = id
  data.areaBorder.types[offsets.areaBorder.types++] = type
  data.areaBorder.positions[offsets.areaBorder.positions++] = positions[j-1][0]
  data.areaBorder.positions[offsets.areaBorder.positions++] = positions[j-1][1]
  data.areaBorder.normals[offsets.areaBorder.normals++] = -normals[j-1][0][0]*scale
  data.areaBorder.normals[offsets.areaBorder.normals++] = -normals[j-1][0][1]*scale
}