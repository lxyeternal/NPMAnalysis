import { pointToTile } from '@mapbox/tilebelt'

export function tilesForBbox (bbox, zoom) {
  const zoomRound = Math.round(zoom)
  const swTile = pointToTile(bbox[0], bbox[1], zoomRound)
  const neTile = pointToTile(bbox[2], bbox[3], zoomRound)
  const tiles = getTilesFromCorners({ swTile, neTile })
  return tiles
}

export function getTilesFromCorners ({ swTile, neTile }) {
  const tiles = []
  const z = swTile[2]
  const numTiles = Math.pow(2, z) // Number of tiles at this zoom level

  // Adjust for wrapping around the meridian
  // If neTile's longitude is less than swTile's longitude,
  // it indicates a wrap around the meridian.
  let xEnd = neTile[0]
  if (neTile[0] < swTile[0]) {
    xEnd += numTiles // Adjust end tile to wrap around
  }

  for (let x = swTile[0]; x <= xEnd; x++) {
    let wrappedX = x % numTiles // Wrap X to handle crossing the meridian
    // y values are stored from north to south, so we reverse
    // neTile and swTile
    for (let y = neTile[1]; y <= swTile[1]; y++) {
      tiles.push([wrappedX, y, z])
    }
  }
  return tiles
}