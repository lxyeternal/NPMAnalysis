import { StencilShaders } from "@/src/shaders"
import { isRasterTile } from "@/src/tile-types"

export const mixmapUniforms = (map) => {
  return {
    viewbox: map.prop('viewbox'),
    zoom: map.prop('zoom'),
    aspect: (context) => context.viewportWidth / context.viewportHeight,
    zindex: map.prop('zindex'),
    offset: map.prop('offset'),
  }
}

export function shaderOptsToTiledDrawCmd (map, shaderType, shaderOpts) {
  const stencil = StencilShaders(map)

  const mapUniforms = mixmapUniforms(map)
  
  const cmdOpts = {
    ...shaderOpts,
    ...stencil.tileStencilHonor,
    uniforms: {
      ...shaderOpts.uniforms,
      ...mapUniforms,
    },
  }

  // TODO add support for picking
  delete cmdOpts.pickFrag
  return map.regl(cmdOpts)
}

export const shadersToDraws = (map, {
    tileType,
    shaders,
    draws={},
  }) => {
  for (const key in shaders) {
    draws[key] = shaderOptsToTiledDrawCmd(map, tileType, shaders[key])
  }
  return draws
}
