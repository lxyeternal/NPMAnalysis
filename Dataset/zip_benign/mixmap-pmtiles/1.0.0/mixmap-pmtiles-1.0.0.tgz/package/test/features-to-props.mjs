import test from 'brittle'
import { featuresToProps } from '../dist/index.mjs'

const fc = {
  type: "FeatureCollection",
  features: [
    {
      type: "Feature",
      properties: {
        "name": "San Juan",
        "name:es": "San Juan",
        "population": 418140,
      },
      geometry: {
        type: "Point",
        coordinates: [5, 5],
      }
    },
    {
      type: "Feature",
      properties: {},
      geometry: {
        type: "LineString",
        coordinates: [[10, 10], [20, 20]],
      }
    },
    {
      type: "Feature",
      properties: {},
      geometry: {
        type: "MultiLineString",
        coordinates: [[[10, 10], [20, 20]], [[30, 30], [40, 40]]],
      }
    },
    {
      type: "Feature",
      properties: {},
      geometry: {
        type: "Polygon",
        coordinates: [
          [
            [2, 2], [12, 2], [12, 12], [2, 12], [2, 2], // counter-clockwise external
          ],
          [
            [5, 5], [5, 8], [8, 8], [8, 5], [5, 5] // clockwise hole
          ]
        ],
      }
    },
    {
      type: "Feature",
      properties: {},
      geometry: {
        type: "MultiPolygon",
        coordinates: [
          [
            [
              [-2, -2, -12, -2, -12, -12, -2, -12, -2, -2], // counter-clockwise external
            ],
            [
              [-5, -5, -5, -8, -8, -8, -8, -5, -5, -5], // clockwise hole
            ],
          ],
          [
            [
              [-2, 2, -12, 2, -12, 12, -2, 12, -2, 2], // counter-clockwise external
            ],
            [
              [-5, 5, -5, 8, -8, 8, -8, 5, -5, 5], // clockwise hole
            ],
          ],
        ],
      }
    },
  ]
}

test('size', (t) => {
  const { sizes, offsets, data} = featuresToProps(fc)
  console.log(sizes)
  console.log(offsets)
  console.log(data)
  t.ok(true, 'Finished without error')
  t.end()
})