import test from 'brittle'
import { getTilesFromCorners } from '../src/tiles-for-bbox.mjs'

test('tiles-for-bbox', (t) => {
  const tiles = getTilesFromCorners({
    swTile: [7, 4, 3],
    neTile: [1, 2, 3]
  })
  t.ok(tiles.length === 9, 'x wraps correctly')
  t.end()
})
