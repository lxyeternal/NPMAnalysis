import { glslifyInline } from '@rubenrodriguez/esbuild-plugin-glslify'
import aliasPlugin from 'esbuild-plugin-path-alias'
import stdLibBrowser from 'node-stdlib-browser'
import plugin from 'node-stdlib-browser/helpers/esbuild/plugin'
import inlineWorkerPlugin from 'esbuild-plugin-inline-worker'

const alias = aliasPlugin({
  '@': process.cwd(),
})

export const esm = {
  entryPoints: [
    'src/index.mjs',
    'src/workers/fetch-tile-props.mjs',
  ],
  globalName: 'MixmapPMtiles',
  target: 'es6',
  bundle: true,
  format: 'esm',
  outdir: 'dist',
  outExtension: { '.js': '.mjs' },
  inject: [
    'node_modules/node-stdlib-browser/helpers/esbuild/shim.js',
  ],
  define: {
    global: 'global',
    process: 'process',
    Buffer: 'Buffer',
  },
  plugins: [
    alias,
    inlineWorkerPlugin({ minify: false, plugins: [alias] }),
    glslifyInline(),
    plugin(stdLibBrowser),
  ],
}

export default esm

export const cjs = {
  ...esm,
  format: 'cjs',
  outExtension: { '.js': '.cjs' },
}
