import * as _Utils from "./_utils.js";
import { NumberRange } from "./number_range.js";
export declare const ZERO = 0;
export declare const isNumber: typeof _Utils._isNumber;
/**
 * Determines whether the `test` is a positive number.
 *
 * @param test - The value to be tested
 * @returns Whether the `test` is a positive number. (positive finite or positive infinity)
 */
export declare function isPositiveNumber(test: unknown): boolean;
/**
 * Determines whether the `test` is a non-negative number.
 *
 * @param test - The value to be tested
 * @returns Whether the `test` is a non-negative number. (non-negative finite or positive infinity)
 */
export declare function isNonNegativeNumber(test: unknown): boolean;
export declare function isNonPositiveNumber(test: unknown): boolean;
export declare function isNegativeNumber(test: unknown): boolean;
export declare function isOddInteger(test: unknown): boolean;
export declare function isEvenInteger(test: unknown): boolean;
export declare function normalizeNumber(source: number): number;
export declare function clampNumber(source: number, range: NumberRange): number;
export declare function inRange(test: number, range: NumberRange): boolean;
