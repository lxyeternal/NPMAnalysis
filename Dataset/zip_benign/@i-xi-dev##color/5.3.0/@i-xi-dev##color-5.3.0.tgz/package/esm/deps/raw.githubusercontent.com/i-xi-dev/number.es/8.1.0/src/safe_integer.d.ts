import { NumberRange } from "./number_range.js";
import { RoundingMode } from "./rounding_mode.js";
export type SafeInteger = number;
declare const _RESOLVED_MARKER: unique symbol;
export declare namespace SafeInteger {
    /**
     * Determines whether the `test` is a positive safe integer.
     *
     * @param test - The value to be tested
     * @returns Whether the `test` is a positive safe integer.
     */
    function isPositiveSafeInteger(test: unknown): boolean;
    /**
     * Determines whether the `test` is a non-negative safe integer.
     *
     * @param test - The value to be tested
     * @returns Whether the `test` is a non-negative safe integer.
     */
    function isNonNegativeSafeInteger(test: unknown): boolean;
    function isNonPositiveSafeInteger(test: unknown): boolean;
    function isNegativeSafeInteger(test: unknown): boolean;
    function isOddSafeInteger(test: unknown): boolean;
    function isEvenSafeInteger(test: unknown): boolean;
    function roundToSafeInteger(source: number, roundingMode: RoundingMode): SafeInteger;
    type FromOptions = {
        strict?: boolean;
        fallback?: SafeInteger;
        roundingMode?: RoundingMode;
        clampRange?: NumberRange;
    };
    namespace FromOptions {
        type Resolved = Readonly<{
            [_RESOLVED_MARKER]: true;
            strict: boolean;
            fallback: SafeInteger;
            roundingMode: RoundingMode;
            clampRange: NumberRange;
        }>;
        function resolve(options?: FromOptions | Resolved): Resolved;
    }
    function fromNumber(source?: number, options?: FromOptions): SafeInteger;
    function fromBigInt(source?: bigint, options?: FromOptions): SafeInteger;
    function fromString(source?: string, options?: FromOptions): SafeInteger;
    function toBigInt(source: SafeInteger): bigint;
    function toString(source: SafeInteger): string;
}
export {};
