import { SafeInteger } from "../deps.js";
/**
 * The zero-length string.
 */
export declare const EMPTY = "";
export declare function isString(test: unknown): test is string;
export declare function isNonEmptyString(test: unknown): boolean;
export declare function matches(input: string, pattern: string): boolean;
export declare function contains(input: string, pattern: string): boolean;
export declare function startsWith(input: string, pattern: string): boolean;
export declare function endsWith(input: string, pattern: string): boolean;
export declare function collectStart(input: string, pattern: string): string;
export declare function trim(input: string, pattern: string): string;
export declare function trimStart(input: string, pattern: string): string;
export declare function trimEnd(input: string, pattern: string): string;
export declare function segment(input: string, charCount: SafeInteger, paddingChar?: string): Generator<string, void, void>;
