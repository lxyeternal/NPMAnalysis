import { SafeInteger } from "./safe_integer.js";
import { Uint8 } from "./uint8.js";
/**
 * The type of 32-bit unsigned integer.
 */
export type Uint32 = number;
export declare namespace Uint32 {
    /**
     * The number of bytes used to represent a 32-bit unsigned integer.
     */
    const BYTES = 4;
    /**
     * The number of bits used to represent a 32-bit unsigned integer.
     */
    const SIZE = 32;
    /**
     * The minimum value of 32-bit unsigned integer.
     */
    const MIN_VALUE = 0;
    /**
     * The maximum value of 32-bit unsigned integer.
     */
    const MAX_VALUE = 4294967295;
    /**
     * Determines whether the passed `test` is a 32-bit unsigned integer.
     *
     * @param test - The value to be tested
     * @returns Whether the passed `test` is a 32-bit unsigned integer.
     */
    function isUint32(test: unknown): boolean;
    function rotateLeft(source: Uint32, amount: SafeInteger): Uint32;
    function saturateFromSafeInteger(source: SafeInteger): Uint32;
    function truncateFromSafeInteger(source: SafeInteger): Uint32;
    function toBytes(source: Uint32, littleEndian?: boolean): [Uint8, Uint8, Uint8, Uint8];
    function bitwiseAnd(a: Uint32, b: Uint32): Uint32;
    function bitwiseOr(a: Uint32, b: Uint32): Uint32;
    function bitwiseXOr(a: Uint32, b: Uint32): Uint32;
}
