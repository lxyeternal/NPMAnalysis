import { Radix } from "../deps.js";
export declare namespace BytesFormat {
    /**
     * The object with the following optional fields.
     */
    type Options = {
        /**
         * The radix of the formatted string.
         * 2, 8, 10, and 16 are available values.
         * The default is `16`.
         */
        radix?: Radix;
        /**
         * The length of the `"0"` padded formatted string for each byte.
         * The default is determined by `radix`.
         *
         * | `radix` | default of `minIntegralDigits` |
         * | ---: | ---: |
         * | `16` | `2` |
         * | `10` | `3` |
         * | `8` | `3` |
         * | `2` | `8` |
         */
        minIntegralDigits?: number;
        /**
         * Whether the formatted string is lowercase or not.
         * The default is `false`.
         */
        lowerCase?: boolean;
        /**
         * The prefix of the formatted string for each byte.
         * The default is `""`.
         */
        prefix?: string;
        /**
         * The suffix of the formatted string for each byte.
         * The default is `""`.
         */
        suffix?: string;
        /**
         * The separator between the formatted strings of each byte.
         * The default is `""`.
         */
        separator?: string;
    };
    /**
     * @param formattedBytes - The formatted string represents a byte sequence.
     * @param options
     * @returns The byte sequence represented by `formattedBytes`.
     * @throws {TypeError} The `formattedBytes` contains the character sequence that does not match the specified format.
     */
    function parse(formattedBytes: string, options?: BytesFormat.Options): Uint8Array;
    /**
     * @param bytes - The byte sequence.
     * @param options
     * @returns The formatted string represents a byte sequence.
     */
    function format(bytes: Uint8Array, options?: BytesFormat.Options): string;
}
