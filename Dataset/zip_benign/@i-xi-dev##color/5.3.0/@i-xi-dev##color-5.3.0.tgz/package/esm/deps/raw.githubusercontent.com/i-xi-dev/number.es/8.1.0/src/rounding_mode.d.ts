declare const UP: unique symbol;
declare const DOWN: unique symbol;
declare const TOWARD_ZERO: unique symbol;
declare const HALF_AWAY_FROM_ZERO: unique symbol;
declare const HALF_TO_EVEN: unique symbol;
export declare const RoundingMode: {
    readonly UP: typeof UP;
    readonly DOWN: typeof DOWN;
    readonly TOWARD_ZERO: typeof TOWARD_ZERO;
    readonly AWAY_FROM_ZERO: symbol;
    readonly HALF_UP: symbol;
    readonly HALF_DOWN: symbol;
    readonly HALF_TOWARD_ZERO: symbol;
    readonly HALF_AWAY_FROM_ZERO: typeof HALF_AWAY_FROM_ZERO;
    readonly HALF_TO_EVEN: typeof HALF_TO_EVEN;
    /** Alias for `UP`. */
    readonly CEILING: typeof UP;
    /** Alias for `DOWN`. */
    readonly FLOOR: typeof DOWN;
    /** Alias for `TOWARD_ZERO`. */
    readonly TRUNCATE: typeof TOWARD_ZERO;
    /** Alias for `HALF_AWAY_FROM_ZERO`. */
    readonly ROUND: typeof HALF_AWAY_FROM_ZERO;
    /** Alias for `HALF_TO_EVEN`. */
    readonly CONVERGENT: typeof HALF_TO_EVEN;
};
export type RoundingMode = typeof RoundingMode[keyof typeof RoundingMode];
export {};
