/**
 * 2, 8, 10, or 16.
 */
export declare const Radix: {
    readonly BINARY: 2;
    readonly DECIMAL: 10;
    readonly HEXADECIMAL: 16;
    readonly OCTAL: 8;
};
export type Radix = typeof Radix[keyof typeof Radix];
