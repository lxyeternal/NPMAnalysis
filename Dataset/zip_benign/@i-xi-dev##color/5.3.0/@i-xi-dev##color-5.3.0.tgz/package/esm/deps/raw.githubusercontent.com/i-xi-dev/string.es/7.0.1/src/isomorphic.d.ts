/**
 * Isomorphic encoding
 */
export declare namespace Isomorphic {
    /**
     * Implements [isomorphic decode](https://infra.spec.whatwg.org/#isomorphic-decode) defined in WHATWG Infra Standard.
     *
     * @param input A byte sequence.
     * @returns A string that represents a byte sequence by the code point.
     */
    function decode(input?: BufferSource): string;
    /**
     * Implements [isomorphic encode](https://infra.spec.whatwg.org/#isomorphic-encode) defined in WHATWG Infra Standard.
     *
     * @param input A string that does not contain code points greater than `U+00FF`.
     * @returns A byte sequence of isomorphic encoded `input`.
     */
    function encode(input?: string): Uint8Array;
}
