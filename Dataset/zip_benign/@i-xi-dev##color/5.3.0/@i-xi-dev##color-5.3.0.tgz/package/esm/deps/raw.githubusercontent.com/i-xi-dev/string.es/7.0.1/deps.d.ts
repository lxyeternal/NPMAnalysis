export { SafeInteger } from "../../number.es/8.1.0/mod.js";
