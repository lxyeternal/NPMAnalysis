export declare class Angle {
    #private;
    private constructor();
    static ofDegrees(degrees: Angle.Degrees): Angle;
    static ofRadians(radians: Angle.Radians): Angle;
    toDegrees(): Angle.Degrees;
    toRadians(): Angle.Radians;
    toDmsString(options?: Angle.DmsOptions): string;
    valueOf(): number;
}
export declare namespace Angle {
    type Degrees = number;
    namespace Degrees {
        const ZERO_TURN = 0;
        const ONE_TURN = 360;
    }
    type Radians = number;
    type Gradians = number;
    type Turns = number;
    function normalizeDegrees(degrees: Degrees): Degrees;
    function radiansToDegrees(radians: Radians): Degrees;
    function degreesToRadians(degrees: Degrees): Radians;
    function gradiansToDegrees(gradians: Gradians): Degrees;
    function turnsToDegrees(turns: Turns): Degrees;
    const DmsStringPrecision: {
        readonly AUTO: "auto";
        readonly DEGREE: "degree";
        readonly MINUTE: "minute";
        readonly SECOND: "second";
    };
    type DmsStringPrecision = typeof DmsStringPrecision[keyof typeof DmsStringPrecision];
    type DmsStringSecondFractionDigits = 0 | 1 | 2 | 3 | 4 | 5 | 6;
    type DmsOptions = {
        precision?: DmsStringPrecision;
        secondFractionDigits?: DmsStringSecondFractionDigits;
    };
    function degreesToDmsString(degrees: Degrees, options?: DmsOptions): string;
}
