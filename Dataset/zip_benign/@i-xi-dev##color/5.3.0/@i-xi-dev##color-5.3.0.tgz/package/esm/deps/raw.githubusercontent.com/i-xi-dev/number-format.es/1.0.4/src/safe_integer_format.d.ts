import { Radix, SafeInteger } from "../deps.js";
declare const _RESOLVED_MARKER: unique symbol;
export declare namespace SafeIntegerFormat {
    type Options = {
        radix?: Radix;
        minIntegralDigits?: SafeInteger;
        lowerCase?: boolean;
        prefix?: string;
        suffix?: string;
    };
    namespace Options {
        type Resolved = Readonly<{
            [_RESOLVED_MARKER]: {
                regex: RegExp;
            };
            radix: Radix;
            minIntegralDigits: SafeInteger;
            lowerCase: boolean;
            prefix: string;
            suffix: string;
        }>;
        function resolve(options?: Options | Resolved): Resolved;
    }
    function parse(str: string, options?: Options): SafeInteger;
    function format(int: SafeInteger, options?: Options): string;
}
export {};
