import { SafeInteger } from "./safe_integer.js";
import { Uint8 } from "./uint8.js";
/**
 * The type of 16-bit unsigned integer.
 */
export type Uint16 = number;
export declare namespace Uint16 {
    /**
     * The number of bytes used to represent a 16-bit unsigned integer.
     */
    const BYTES = 2;
    /**
     * The number of bits used to represent a 16-bit unsigned integer.
     */
    const SIZE = 16;
    /**
     * The minimum value of 16-bit unsigned integer.
     */
    const MIN_VALUE = 0;
    /**
     * The maximum value of 16-bit unsigned integer.
     */
    const MAX_VALUE = 65535;
    /**
     * Determines whether the passed `test` is a 16-bit unsigned integer.
     *
     * @param test - The value to be tested
     * @returns Whether the passed `test` is a 16-bit unsigned integer.
     */
    function isUint16(test: unknown): boolean;
    function rotateLeft(source: Uint16, amount: SafeInteger): Uint16;
    function saturateFromSafeInteger(source: SafeInteger): Uint16;
    function truncateFromSafeInteger(source: SafeInteger): Uint16;
    function toBytes(source: Uint16, littleEndian?: boolean): [Uint8, Uint8];
    function bitwiseAnd(a: Uint16, b: Uint16): Uint16;
    function bitwiseOr(a: Uint16, b: Uint16): Uint16;
    function bitwiseXOr(a: Uint16, b: Uint16): Uint16;
}
