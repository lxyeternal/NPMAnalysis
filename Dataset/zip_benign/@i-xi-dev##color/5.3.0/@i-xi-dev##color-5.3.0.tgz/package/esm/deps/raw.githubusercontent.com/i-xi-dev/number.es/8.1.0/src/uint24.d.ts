import { SafeInteger } from "./safe_integer.js";
/**
 * The type of 24-bit unsigned integer.
 */
export type Uint24 = number;
export declare namespace Uint24 {
    /**
     * The number of bytes used to represent a 24-bit unsigned integer.
     */
    const BYTES = 3;
    /**
     * The number of bits used to represent a 24-bit unsigned integer.
     */
    const SIZE = 24;
    /**
     * The minimum value of 24-bit unsigned integer.
     */
    const MIN_VALUE = 0;
    /**
     * The maximum value of 24-bit unsigned integer.
     */
    const MAX_VALUE = 16777215;
    /**
     * Determines whether the passed `test` is a 24-bit unsigned integer.
     *
     * @param test - The value to be tested
     * @returns Whether the passed `test` is a 24-bit unsigned integer.
     */
    function isUint24(test: unknown): boolean;
    function rotateLeft(source: Uint24, amount: SafeInteger): Uint24;
    function bitwiseAnd(a: Uint24, b: Uint24): Uint24;
    function bitwiseOr(a: Uint24, b: Uint24): Uint24;
    function bitwiseXOr(a: Uint24, b: Uint24): Uint24;
}
