export type NumberRange = [min: number, max: number] | [minmax: number];
export declare namespace NumberRange {
    type Resolved = [
        min: number,
        max: number
    ];
    function resolve(range: unknown): Resolved;
}
