export declare function _isNumber(test: unknown): test is number;
export declare function _isBigInt(test: unknown): test is bigint;
export declare function _max(...args: bigint[]): bigint;
export declare function _min(...args: bigint[]): bigint;
