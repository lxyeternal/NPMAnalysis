/**
 * The type of 64-bit unsigned integer.
 */
export type BigUint64 = bigint;
export declare namespace BigUint64 {
    /**
     * The number of bytes used to represent a 64-bit unsigned integer.
     */
    const BYTES = 8;
    /**
     * The number of bits used to represent a 64-bit unsigned integer.
     */
    const SIZE = 64;
    /**
     * The minimum value of 64-bit unsigned integer.
     */
    const MIN_VALUE = 0n;
    /**
     * The maximum value of 64-bit unsigned integer.
     */
    const MAX_VALUE = 18446744073709551615n;
    /**
     * Determines whether the passed `test` is a 64-bit unsigned integer.
     *
     * @param test - The value to be tested
     * @returns Whether the passed `test` is a 64-bit unsigned integer.
     */
    function isBigUint64(test: unknown): boolean;
}
