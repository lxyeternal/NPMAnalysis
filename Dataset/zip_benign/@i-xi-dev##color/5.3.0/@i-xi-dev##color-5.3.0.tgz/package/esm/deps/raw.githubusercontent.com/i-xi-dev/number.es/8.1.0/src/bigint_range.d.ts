export type BigIntRange = [min: bigint, max: bigint] | [minmax: bigint];
export declare namespace BigIntRange {
    type Resolved = [
        min: bigint,
        max: bigint
    ];
    function resolve(range: unknown): Resolved;
}
