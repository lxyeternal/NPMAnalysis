import { Hue } from "../color/hue.js";
import { Rgb } from "./rgb.js";
/**
 * The HSL object, that represents RGB color in hue, saturation, and lightness.
 */
type Hsl = {
    /**
     * Hue
     */
    h: number;
    /**
     * Saturation
     */
    s: number;
    /**
     * Lightness
     */
    l: number;
    /**
     * Alpha
     */
    a?: number;
};
declare namespace Hsl {
    type Saturation = number;
    namespace Saturation {
        const MIN_VALUE = 0;
        const MAX_VALUE = 1;
        function normalize(value: unknown): Saturation;
    }
    type Lightness = number;
    namespace Lightness {
        const MIN_VALUE = 0;
        const MAX_VALUE = 1;
        function normalize(value: unknown): Lightness;
    }
    type Normalized = {
        h: Hue;
        s: Saturation;
        l: Lightness;
    };
    function normalize(value: Hsl): Normalized;
    function fromRgb(rgb: Rgb): Normalized;
    function toRgb(hsl: Hsl): Rgb.Normalized;
}
export { Hsl };
