import { RgbColor } from "./rgb_color.js";
import { CssOptions } from "./css_color/options.js";
/**
 * The CSS color value format.
 *
 * CSS Color Level 3 values are supported except for the following values:
 * - `<system-color>`
 * - `currentcolor`
 * - `inherit`
 * - `initial`
 * - `revert`
 * - `unset`
 * - `var()`
 * - ...
 */
declare namespace CssColorFormat {
    type FormatOptions = CssOptions.FormatOptions;
    /**
     * Creates a new instance of `RgbColor` from a CSS color value.
     *
     * The following CSS Color Level 3 values are supported:
     * - `<hex-color>`
     * - `<named-color>`
     * - `transparent`
     * - `<rgb()>`
     * - `<rgba()>`
     * - `<hsl()>`
     * - `<hsla()>`
     *
     * The following CSS Color Level 4 values are experimentally supported:
     * - `<rgb()>`
     * - `<hsl()>`
     *
     * @param cssColor - A text representation of CSS color value.
     * @returns A `RgbColor`
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("#ff0000");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("#f00");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("#ff0000ff");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("rgb(255, 0, 0)");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("rgba(255, 0, 0, 1)");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * // parse the notation for CSS color level 4
     * const color = CssColorFormat.parse("rgb(255 0 0 / 1)");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("hsl(0, 100%, 50%)");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("hsla(0, 100%, 50%, 1)");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * // parse the notation for CSS color level 4
     * const color = CssColorFormat.parse("hsl(0 100% 50% / 1)");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("red");
     * // color.toHexString()
     * //   → "#FF0000FF"
     * ```
     * @example
     * ```javascript
     * const color = CssColorFormat.parse("transparent");
     * // color.toHexString()
     * //   → "#00000000"
     * ```
     */
    function parse(cssColor: string): RgbColor;
    /**
     * Creates CSS color value from an instance of `RgbColor`.
     *
     * The following CSS Color Level 3 values are supported:
     * - `<hex-color>`
     * - `<rgb()>`
     * - `<rgba()>`
     * - `<hsl()>`
     * - `<hsla()>`
     *
     * The following CSS Color Level 4 values are experimentally supported:
     * - `<rgb()>`
     * - `<hsl()>`
     *
     * @param color - A `RgbColor`
     * @param options - A `FormatOptions` dictionary.
     * @returns A text representation of CSS color value.
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color);
     * // cssText
     * //   → "#ff0000ff"
     * ```
     * @example
     * ```javascript
     * // format to the notation for CSS color level 4
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "rgb" });
     * // cssText
     * //   → "rgb(255 0 0 / 1.00)"
     * ```
     * @example
     * ```javascript
     * // format to the notation for CSS color level 4
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "rgb", shortenIfPossible: true });
     * // cssText
     * //   → "rgb(255 0 0)"
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "rgb", legacy: true });
     * // cssText
     * //   → "rgba(255, 0, 0, 1.00)"
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "rgb", legacy: true, shortenIfPossible: true });
     * // cssText
     * //   → "rgb(255, 0, 0)"
     * ```
     * @example
     * ```javascript
     * // format to the notation for CSS color level 4
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "hsl" });
     * // cssText
     * //   → "hsl(0.00deg 100.00% 50.00% / 1.00)"
     * ```
     * @example
     * ```javascript
     * // format to the notation for CSS color level 4
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "hsl", shortenIfPossible: true });
     * // cssText
     * //   → "hsl(0 100% 50%)"
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "hsl", legacy: true });
     * // cssText
     * //   → "hsla(0.00deg, 100.00%, 50.00%, 1.00)"
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const cssText = CssColorFormat.format(color, { notation: "hsl", legacy: true, shortenIfPossible: true });
     * // cssText
     * //   → "hsl(0, 100%, 50%)"
     * ```
     */
    function format(color: RgbColor, options?: FormatOptions): string;
}
export { CssColorFormat };
