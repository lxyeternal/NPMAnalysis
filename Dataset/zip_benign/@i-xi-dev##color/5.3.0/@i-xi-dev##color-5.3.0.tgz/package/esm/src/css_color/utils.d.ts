import { Angle } from "../../deps.js";
export declare function _floatStringify(input: number, shortenIfPossible: boolean): string;
export declare namespace _Pattern {
    const WHITESPACE = "[\\u0009\\u000A\\u000C\\u000D\\u0020]";
    const WS = "[\\u0009\\u000A\\u000C\\u000D\\u0020]*";
    function normalizeWs(input: string): string;
    function trimWs(input: string): string;
    const NUM = "[-+]?(?:[0-9]*\\.)?[0-9]+";
    const PERC = "[-+]?(?:[0-9]*\\.)?[0-9]+%";
    const CMS = "[\\u0009\\u000A\\u000C\\u000D\\u0020]*,[\\u0009\\u000A\\u000C\\u000D\\u0020]*";
    const SLS = "[\\u0009\\u000A\\u000C\\u000D\\u0020]*\\/[\\u0009\\u000A\\u000C\\u000D\\u0020]*";
    const ALPHA = "[-+]?(?:[0-9]*\\.)?[0-9]+%?";
    const HUE = "[-+]?(?:[0-9]*\\.)?[0-9]+(?:deg|grad|rad|turn)?";
    function parseHue(input: string): Angle.Degrees;
}
