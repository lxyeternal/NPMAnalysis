import { RgbColor } from "../rgb_color.js";
import { CssOptions } from "./options.js";
declare namespace _CssHex {
    function parse(source: string): RgbColor;
    function format(color: RgbColor, options?: CssOptions.FormatOptions): string;
}
export { _CssHex };
