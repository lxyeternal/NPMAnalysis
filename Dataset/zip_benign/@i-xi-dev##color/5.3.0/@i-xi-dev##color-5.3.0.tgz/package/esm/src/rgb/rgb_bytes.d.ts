import { Uint8 } from "../../deps.js";
import { Rgb } from "./rgb.js";
declare namespace RgbBytes {
    const Order: {
        readonly ARGB: "argb";
        readonly RGBA: "rgba";
    };
    type Order = typeof Order[keyof typeof Order];
    /**
     * A normalized RGB component bytes.
     */
    type Normalized = {
        /**
         * Red component.
         */
        r: Uint8;
        /**
         * Green component.
         */
        g: Uint8;
        /**
         * Blue component.
         */
        b: Uint8;
    };
    /**
     * Normalize RGB component bytes.
     *
     * @param bytes - RGB component bytes.
     * @returns RGB component bytes, where the byte value of each component is normalized to an integer from 0 to 255.
     * @example
     * ```javascript
     * const rgbBytes = RgbBytes.normalize({ r: -1, g: 500, b: 12.3 });
     * // rgbBytes.r
     * //   → 0
     * // rgbBytes.g
     * //   → 255
     * // rgbBytes.b
     * //   → 12
     * ```
     */
    function normalize(bytes: Rgb): Normalized;
    function fromRgb(rgb: Rgb): Normalized;
    function toRgb(rgbBytes: Rgb): Rgb.Normalized;
}
export { RgbBytes };
