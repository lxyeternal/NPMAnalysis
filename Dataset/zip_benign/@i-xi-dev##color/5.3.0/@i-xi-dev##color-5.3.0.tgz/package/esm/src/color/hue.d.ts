import { Angle } from "../../deps.js";
/**
 * The hue, represented as an angle in degrees on the hue circle.
 */
type Hue = Angle.Degrees;
declare namespace Hue {
    const NONE = 0;
    /**
     * If the `value` is a numeric type, returns the result rounded to `0` or more and less than `360`.
     * Otherwise, returns `0`.
     *
     * @param value - Hue.
     * @returns A normalized hue.
     * @example
     * ```javascript
     * const hue = Hue.normalize(90);
     * // hue
     * //   → 90
     * ```
     * @example
     * ```javascript
     * const hue = Hue.normalize(-90);
     * // hue
     * //   → 270
     * ```
     * @example
     * ```javascript
     * const hue = Hue.normalize(720);
     * // hue
     * //   → 0
     * ```
     */
    function normalize(value: unknown): Hue;
}
export { Hue };
