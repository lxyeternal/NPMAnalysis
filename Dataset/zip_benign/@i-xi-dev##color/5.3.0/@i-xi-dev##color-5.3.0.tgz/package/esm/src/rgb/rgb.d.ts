/**
 * The RGB object, that represents RGB color in red, green, and blue.
 */
type Rgb = {
    /**
     * Red component.
     */
    r: number;
    /**
     * Green component.
     */
    g: number;
    /**
     * Blue component.
     */
    b: number;
    /**
     * Alpha component.
     */
    a?: number;
};
declare namespace Rgb {
    /**
     * A component (r, g, or b) of RGB color.
     */
    type Component = number;
    namespace Component {
        /**
         * The minimum value of component.
         */
        const MIN_VALUE = 0;
        /**
         * The maximum value of component.
         */
        const MAX_VALUE = 1;
        /**
         * Normalize a component value to the range of 0 to 1.
         *
         * In the current version, normalized values are restricted to be greater than or equal to 0 and less than or equal to 1.
         *
         * @param component - A component value
         * @returns A component value normalized to the range of 0 to 1.
         * @example
         * ```javascript
         * const r = Rgb.Component.normalize(1);
         * // r
         * //   → 1
         * ```
         * @example
         * ```javascript
         * const r = Rgb.Component.normalize(2.5);
         * // r
         * //   → 1
         * ```
         * @example
         * ```javascript
         * const r = Rgb.Component.normalize(-5);
         * // r
         * //   → 0
         * ```
         */
        function normalize(component: unknown): Component;
    }
    /**
     * A normalized RGB components.
     */
    type Normalized = {
        /**
         * Red component.
         */
        r: Component;
        /**
         * Green component.
         */
        g: Component;
        /**
         * Blue component.
         */
        b: Component;
    };
    /**
     * Normalize RGB components.
     *
     * @param components - RGB components.
     * @returns RGB components where the value of each component is normalized from 0 to 1.
     * @example
     * ```javascript
     * const rgb = Rgb.normalize({ r: -1, g: 0.5, b: 3.2 });
     * // rgb.r
     * //   → 0
     * // rgb.g
     * //   → 0.5
     * // rgb.b
     * //   → 1
     * ```
     */
    function normalize(components: Rgb): Normalized;
}
export { Rgb };
