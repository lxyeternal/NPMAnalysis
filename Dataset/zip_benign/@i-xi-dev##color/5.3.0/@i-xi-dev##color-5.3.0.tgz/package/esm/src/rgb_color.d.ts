import { Options } from "./options.js";
import { ColorSpace } from "./color_space.js";
import { Alpha } from "./color/alpha.js";
import { Hue } from "./color/hue.js";
import { Rgb } from "./rgb/rgb.js";
import { Hsl } from "./rgb/hsl.js";
import { Hwb } from "./rgb/hwb.js";
/**
 * A color represented by red, green, and blue channels
 */
declare class RgbColor {
    #private;
    private constructor();
    /**
     * Gets the color space.
     *
     * Always returns `"srgb"` in the current version.
     */
    get space(): ColorSpace;
    /**
     * Gets the red component value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const r = color.red;
     * // r
     * //   → 1
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#88ffff");
     * const r = color.red;
     * // r
     * //   → 0.533333
     * ```
     */
    get red(): Rgb.Component;
    /**
     * Gets the green component value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#00ff00");
     * const g = color.green;
     * // g
     * //   → 1
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff88ff");
     * const g = color.green;
     * // g
     * //   → 0.533333
     * ```
     */
    get green(): Rgb.Component;
    /**
     * Gets the blue component value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#0000ff");
     * const b = color.blue;
     * // b
     * //   → 1
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ffff88");
     * const b = color.blue;
     * // b
     * //   → 0.533333
     * ```
     */
    get blue(): Rgb.Component;
    /**
     * Gets the alpha component value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#000000");
     * const a = color.alpha;
     * // a
     * //   → 1
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#00000000");
     * const a = color.alpha;
     * // a
     * //   → 0
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ffffff88");
     * const a = color.alpha;
     * // a
     * //   → 0.533333
     * ```
     */
    get alpha(): Alpha;
    /**
     * Get the hue value in degrees.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#598910");
     * const hue = color.hue;
     * // hue
     * //   → 83.801653
     * ```
     */
    get hue(): Hue;
    /**
     * Get the HSL saturation value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#598910");
     * const saturation = color.saturation;
     * // saturation
     * //   → 0.790850
     * ```
     */
    get saturation(): Hsl.Saturation;
    /**
     * Get the HSL lightness value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#598910");
     * const lightness = color.lightness;
     * // lightness
     * //   → 0.300000
     * ```
     */
    get lightness(): Hsl.Lightness;
    /**
     * Get the HWB whiteness value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#598910");
     * const whiteness = color.whiteness;
     * // whiteness
     * //   → 0.062745
     * ```
     */
    get whiteness(): Hwb.Whiteness;
    /**
     * Get the HWB blackness value.
     *
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#598910");
     * const blackness = color.blackness;
     * // blackness
     * //   → 0.462745
     * ```
     */
    get blackness(): Hwb.Blackness;
    static fromRgb(rgba: Rgb, options?: Options.FromRgbOptions): RgbColor;
    static fromHsl(hsla: Hsl, options?: Options.FromOptions): RgbColor;
    static fromHwb(hwba: Hwb, options?: Options.FromOptions): RgbColor;
    static fromUint8Array(rgbaBytes: Uint8Array | Uint8ClampedArray, options?: Options.FromArrayOptions): RgbColor;
    static fromHexString(hexString: string, options?: Options.FromHexStringOptions): RgbColor;
    toRgb(options?: Options.ToRgbOptions): Rgb;
    /**
     * Returns the triplet of `h` (hue), `s` (saturation), and `l` (lightness).
     *
     * @param options - An options object.
     * @returns A triplet of `h`, `s`, and `l`.
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const hsl = color.toHsl();
     * // hsl
     * //   → {
     * //       h: 0,
     * //       s: 1,
     * //       l: 0.5,
     * //       a: 1,
     * //     }
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff0000");
     * const hsl = color.toHsl({ omitAlphaIfOpaque: true });
     * // hsl
     * //   → {
     * //       h: 0,
     * //       s: 1,
     * //       l: 0.5,
     * //     }
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff000088");
     * const hsl = color.toHsl({ discardAlpha: true });
     * // hsl
     * //   → {
     * //       h: 0,
     * //       s: 1,
     * //       l: 0.5,
     * //     }
     * ```
     */
    toHsl(options?: Options.ToOptions): Hsl;
    /**
     * Returns the triplet of `h` (hue), `w` (whiteness), and `b` (blackness).
     *
     * @param options - An options object.
     * @returns A triplet of `h`, `w`, and `b`.
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff8888");
     * const hwb = color.toHwb();
     * // hwb
     * //   → {
     * //       h: 0,
     * //       w: 0.533333,
     * //       b: 0,
     * //       a: 1,
     * //     }
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff8888");
     * const hwb = color.toHwb({ omitAlphaIfOpaque: true });
     * // hwb
     * //   → {
     * //       h: 0,
     * //       w: 0.533333,
     * //       b: 0,
     * //     }
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#ff888888");
     * const hwb = color.toHwb({ discardAlpha: true });
     * // hwb
     * //   → {
     * //       h: 0,
     * //       w: 0.533333,
     * //       b: 0,
     * //     }
     * ```
     */
    toHwb(options?: Options.ToOptions): Hwb;
    /**
     * Returns the RGB expressed as a byte sequence.
     *
     * @param options - An options object.
     * @returns A RGB(A) byte sequence or the ARGB byte sequence.
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const bytes = color.toUint8Array();
     * // bytes
     * //   → Uint8Array[ 0x11, 0x22, 0x33, 0xFF ] // RGBA
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const bytes = color.toUint8Array({ discardAlpha: true });
     * // bytes
     * //   → Uint8Array[ 0x11, 0x22, 0x33 ] // RGB
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const bytes = color.toUint8Array({ order: "argb" });
     * // bytes
     * //   → Uint8Array[ 0xFF, 0x11, 0x22, 0x33 ] // ARGB
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const bytes = color.toUint8Array({ order: "argb", discardAlpha: true });
     * // bytes
     * //   → Uint8Array[ 0xFF, 0x11, 0x22, 0x33 ] // ARGB
     * //   If the `order` is "argb", the `discardAlpha` and `omitAlphaIfOpaque` are ignored.
     * ```
     */
    toUint8Array(options?: Options.ToArrayOptions): Uint8Array;
    /**
     * Returns the RGB expressed as a byte sequence.
     *
     * @param options - An options object.
     * @returns A RGB(A) byte sequence or the ARGB byte sequence.
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const bytes = color.toUint8ClampedArray();
     * // bytes
     * //   → Uint8ClampedArray[ 0x11, 0x22, 0x33, 0xFF ] // RGBA
     * ```
     */
    toUint8ClampedArray(options?: Options.ToArrayOptions): Uint8ClampedArray;
    /**
     * Returns the RGB expressed as a string contains hexadecimal formatted bytes.
     *
     * @param options - An options object.
     * @returns A RGB(A) byte sequence or the ARGB byte sequence.
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const hex = color.toHexString();
     * // hex
     * //   → "#112233FF" // RGBA
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const hex = color.toHexString({ discardAlpha: true });
     * // hex
     * //   → "#112233" // RGB
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const hex = color.toHexString({ order: "argb" });
     * // hex
     * //   → "#FF112233" // ARGB
     * ```
     * @example
     * ```javascript
     * const color = RgbColor.fromHexString("#112233");
     * const hex = color.toHexString({ order: "argb", discardAlpha: true });
     * // hex
     * //   → "#FF112233" // ARGB
     * //   If the `order` is "argb", the `discardAlpha` and `omitAlphaIfOpaque` are ignored.
     * ```
     */
    toHexString(options?: Options.ToHexStringOptions): string;
    /**
     * Equivalents to the `toHexString` method with no parameters.
     *
     * @returns
     */
    toString(): string;
    toJSON(): Rgb.Normalized & {
        a: Alpha;
    };
    equalsBytes(other: RgbColor, options?: Options.CompareOptions): boolean;
    /**
     * Alias for `toInverted` method.
     *
     * @deprecated
     */
    invert(): RgbColor;
    /**
     * Returns a inverted color.
     *
     * @returns A new instance of `Color` representing the inverted color of this color.
     */
    toInverted(): RgbColor;
    /**
     * Alias for `toComplementary` method.
     *
     * @deprecated
     */
    complementary(): RgbColor;
    /**
     * Returns a complementary color.
     *
     * @returns A new instance of `Color` representing the complementary color of this color.
     */
    toComplementary(): RgbColor;
    plusHue(relativeHue: number): RgbColor;
    withHue(absoluteHue: number): RgbColor;
    plusSaturation(relativeSaturation: number): RgbColor;
    withSaturation(absoluteSaturation: number): RgbColor;
    plusLightness(relativeLightness: number): RgbColor;
    withLightness(absoluteLightness: number): RgbColor;
    plusAlpha(relativeAlpha: number): RgbColor;
    withAlpha(absoluteAlpha: number): RgbColor;
    withoutAlpha(): RgbColor;
}
export { RgbColor };
