declare const ColorSpace: {
    readonly XYZ: "xyz";
    readonly XYZ_D50: "xyz-d50";
    readonly XYZ_D65: "xyz-d65";
    readonly A98_RGB: "a98-rgb";
    readonly DISPLAY_P3: "display-p3";
    readonly PROPHOTO_RGB: "prophoto-rgb";
    readonly REC2020: "rec2020";
    readonly SRGB: "srgb";
    readonly SRGB_LINEAR: "srgb-linear";
};
/**
 * The color space
 */
type ColorSpace = typeof ColorSpace[keyof typeof ColorSpace];
export { ColorSpace };
