import { Hue } from "../color/hue.js";
import { Rgb } from "./rgb.js";
/**
 * The HWB object, that represents RGB color in hue, whiteness, and blackness.
 */
type Hwb = {
    /**
     * Hue
     */
    h: number;
    /**
     * Whiteness
     */
    w: number;
    /**
     * Blackness
     */
    b: number;
    /**
     * Alpha
     */
    a?: number;
};
declare namespace Hwb {
    type Whiteness = number;
    namespace Whiteness {
        const MIN_VALUE = 0;
        const MAX_VALUE = 1;
        function normalize(value: unknown): Whiteness;
    }
    type Blackness = number;
    namespace Blackness {
        const MIN_VALUE = 0;
        const MAX_VALUE = 1;
        function normalize(value: unknown): Blackness;
    }
    type Normalized = {
        h: Hue;
        w: Whiteness;
        b: Blackness;
    };
    function normalize(value: Hwb): Normalized;
    function fromRgb(rgb: Rgb): Normalized;
    function toRgb(hwb: Hwb): Rgb.Normalized;
}
export { Hwb };
