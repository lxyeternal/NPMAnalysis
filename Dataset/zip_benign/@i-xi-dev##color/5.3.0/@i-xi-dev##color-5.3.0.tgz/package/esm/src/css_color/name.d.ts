import { Uint8 } from "../../deps.js";
/** @deprecated */
export declare function _rgbFromName(lowerCasedName: string): [r: Uint8, g: Uint8, b: Uint8] | null;
