declare namespace CssOptions {
    type FormatOptions = {
        notation?: "hex" | "rgb" | "hsl";
        upperCase?: boolean;
        shortenIfPossible?: boolean;
        legacy?: boolean;
    };
}
export { type CssOptions };
