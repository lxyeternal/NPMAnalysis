const Trigonometry = require('./src/trigonometry');

module.exports = Trigonometry;
