const Trigonometry = require('./index');

// Example Usage
console.log('Sin(30):', Trigonometry.sin(30)); // 0.5
console.log('Cos(60):', Trigonometry.cos(60)); // 0.5
console.log('Tan(45):', Trigonometry.tan(45)); // 1
