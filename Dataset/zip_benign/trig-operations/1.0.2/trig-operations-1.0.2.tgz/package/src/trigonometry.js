// Trigonometric Operations
const Trigonometry = {
    sin: (angleInDegrees) => Math.sin(angleInDegrees * (Math.PI / 180)),
    cos: (angleInDegrees) => Math.cos(angleInDegrees * (Math.PI / 180)),
    tan: (angleInDegrees) => Math.tan(angleInDegrees * (Math.PI / 180)),
    cot: (angleInDegrees) => 1 / Math.tan(angleInDegrees * (Math.PI / 180)),
    sec: (angleInDegrees) => 1 / Math.cos(angleInDegrees * (Math.PI / 180)),
    csc: (angleInDegrees) => 1 / Math.sin(angleInDegrees * (Math.PI / 180)),
  
    // Inverse Trigonometric Functions
    asin: (value) => (Math.asin(value) * 180) / Math.PI,
    acos: (value) => (Math.acos(value) * 180) / Math.PI,
    atan: (value) => (Math.atan(value) * 180) / Math.PI,
  
    // Conversions
    toRadians: (angleInDegrees) => angleInDegrees * (Math.PI / 180),
    toDegrees: (angleInRadians) => angleInRadians * (180 / Math.PI),
  };
  
  module.exports = Trigonometry;
  