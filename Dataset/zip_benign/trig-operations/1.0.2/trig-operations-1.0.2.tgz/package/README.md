# Trig Operations

A library for trigonometric operations.

## Installation

You can install this library using npm:

```sh
npm install trig-operations
```

## Usage

const Trigonometry = require('trig-operations');

console.log('Sin(30):', Trigonometry.sin(30)); // 0.5
console.log('Cos(60):', Trigonometry.cos(60)); // 0.5
console.log('Tan(45):', Trigonometry.tan(45)); // 1


## Trigonometric Functions
sin(angleInDegrees): Returns the sine of the given angle in degrees.
cos(angleInDegrees): Returns the cosine of the given angle in degrees.
tan(angleInDegrees): Returns the tangent of the given angle in degrees.
cot(angleInDegrees): Returns the cotangent of the given angle in degrees.
sec(angleInDegrees): Returns the secant of the given angle in degrees.
csc(angleInDegrees): Returns the cosecant of the given angle in degrees.

## Inverse Trigonometric Functions
asin(value): Returns the arcsine of the given value in degrees.
acos(value): Returns the arccosine of the given value in degrees.
atan(value): Returns the arctangent of the given value in degrees.

## Conversions
toRadians(angleInDegrees): Converts the given angle from degrees to radians.
toDegrees(angleInRadians): Converts the given angle from radians to degrees.

## License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.


