<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <br>
    Example of static output
    <br/>
    <br/>
    <rating value="3.4" partial="true" readonly="true"/>
    <br>
    <br>
    Example of read-only "Rating"
    <br/>
    <br/>
    <rating :value="value" partial="true" :key="value" readonly="true"/>
    <br>
    <br>
    Editable input "Rating"
    <br/>
    <br/>
    <rating v-model="value" min="1" :max="10" partial="true"
            name="form[name][first]"
            class="form-control" data-placeholder="renderer"/>
  </div>
</template>

<script>
import Rating from './components/Rating.vue'

export default {
  name: 'app',
  components: {
    Rating,
  },
  data() {
    return {
      value: null,
    }
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
