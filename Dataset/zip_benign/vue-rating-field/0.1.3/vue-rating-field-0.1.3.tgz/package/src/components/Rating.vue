<template>
    <div>
        <template v-if="!readonly">
            <select :name="name" v-model="mutatedValue"
                    @change="updateValue"
                    v-bind="attributes">
                <option v-for="option in options" :value="option"
                        :key="option.$index">
                    {{option}}
                </option>
            </select>
            &nbsp;
        </template>
        <template>
            <span v-for="star in stars"
                  :class="['fas',{
                  'fa-star':star==1,
                  'fa-star-half':star>0 && star<1
                  }]"
            :key="star.$index"></span>
        </template>
        <small v-if="readonly && this.value">
            &nbsp;
            ({{this.value}})
        </small>
    </div>
</template>

<script>
import Basefield from 'vue-dyno-field'

export default {
  extends: Basefield,
  props: {
    min: {
      type: [String, Number],
      default: 0,
    },
    max: {
      type: [String, Number],
      default: 5,
    },
    partial: {
      type: [Boolean, String, Number],
      default: false,
    },
  },
  mounted() {
    Basefield.mounted.apply(this)
    this.mutatedValue = parseFloat(this.mutatedValue)
  },
  computed: {
    options: function() {
      const options = []
      const min = parseFloat(this.min)
      const max = parseFloat(this.max)
      for (let i = min; i <= max; i += (this.partial ? 0.5 : 1)) {
        options.push(i)
      }
      return options
    },
    stars: function() {
      const stars = []
      const min = 0
      const max = parseFloat(this.max) < this.mutatedValue
          ? this.mutatedValue
          : parseFloat(this.max)
      for (let i = min; i <= max; i++) {
        const res = this.mutatedValue - (i) >= 1
            ? 1
            : (this.partial ? (this.mutatedValue - (i) > 0 ? 0.5 : 0) : 1)
        stars.push(res)
      }
      return stars
    },
  },
}
</script>

<style scoped>
    @import "~@fortawesome/fontawesome-free/css/all.css";
</style>
