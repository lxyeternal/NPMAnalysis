# Vue Rating field

Extends `vue-dyno-field`

Usage to display static data:
```
<rating value="4.4" partial="true" readonly="true"/>
```
Usage to display dynamic data:
```
<rating :value="value" :key="value" readonly="true"/>
```
Input usage
```
<rating v-model="value" min="1" max="10" partial="true"/>
```
Available attributes:

**partial** - use to react or omit the fraction part

**min** - minimal value allowed

**max** - maximum value allowed

### Dev TODO
- [ ] dynamic step parameter (instead of 0.5)
