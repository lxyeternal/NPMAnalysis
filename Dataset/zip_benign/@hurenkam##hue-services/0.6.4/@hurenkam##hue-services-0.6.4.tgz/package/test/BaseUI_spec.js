//const BaseUI = require("../src/ui/BaseUI.js");
//import {BaseUI} from "../src/ui/BaseUI"

describe('Base UI', function () {
    beforeEach(()=>{
        sandbox = sinon.createSandbox();
    });

    afterEach(function () {
        sandbox.restore();
    });

    it('should store config.name property', function (done) {
        //var ui = new BaseUI("label","category");
        done();
    });
});
