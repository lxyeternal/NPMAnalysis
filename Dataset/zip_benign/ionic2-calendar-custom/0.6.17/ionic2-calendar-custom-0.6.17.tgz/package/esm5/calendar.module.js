import { __decorate } from "tslib";
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { MonthViewComponent } from './monthview';
import { WeekViewComponent } from './weekview';
import { DayViewComponent } from './dayview';
import { CalendarComponent } from './calendar';
import { initPositionScrollComponent } from './init-position-scroll';
var NgCalendarModule = /** @class */ (function () {
    function NgCalendarModule() {
    }
    NgCalendarModule = __decorate([
        NgModule({
            declarations: [
                MonthViewComponent, WeekViewComponent, DayViewComponent, CalendarComponent, initPositionScrollComponent
            ],
            imports: [IonicModule, CommonModule],
            exports: [CalendarComponent]
        })
    ], NgCalendarModule);
    return NgCalendarModule;
}());
export { NgCalendarModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXIubW9kdWxlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vaW9uaWMyLWNhbGVuZGFyLWN1c3RvbS8iLCJzb3VyY2VzIjpbImNhbGVuZGFyLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzdDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGFBQWEsQ0FBQztBQUNqRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDL0MsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQzdDLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUMvQyxPQUFPLEVBQUUsMkJBQTJCLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQVNyRTtJQUFBO0lBQStCLENBQUM7SUFBbkIsZ0JBQWdCO1FBUDVCLFFBQVEsQ0FBQztZQUNOLFlBQVksRUFBRTtnQkFDVixrQkFBa0IsRUFBRSxpQkFBaUIsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSwyQkFBMkI7YUFDMUc7WUFDRCxPQUFPLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDO1lBQ3BDLE9BQU8sRUFBRSxDQUFDLGlCQUFpQixDQUFDO1NBQy9CLENBQUM7T0FDVyxnQkFBZ0IsQ0FBRztJQUFELHVCQUFDO0NBQUEsQUFBaEMsSUFBZ0M7U0FBbkIsZ0JBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBJb25pY01vZHVsZSB9IGZyb20gJ0Bpb25pYy9hbmd1bGFyJztcbmltcG9ydCB7IE1vbnRoVmlld0NvbXBvbmVudCB9IGZyb20gJy4vbW9udGh2aWV3JztcbmltcG9ydCB7IFdlZWtWaWV3Q29tcG9uZW50IH0gZnJvbSAnLi93ZWVrdmlldyc7XG5pbXBvcnQgeyBEYXlWaWV3Q29tcG9uZW50IH0gZnJvbSAnLi9kYXl2aWV3JztcbmltcG9ydCB7IENhbGVuZGFyQ29tcG9uZW50IH0gZnJvbSAnLi9jYWxlbmRhcic7XG5pbXBvcnQgeyBpbml0UG9zaXRpb25TY3JvbGxDb21wb25lbnQgfSBmcm9tICcuL2luaXQtcG9zaXRpb24tc2Nyb2xsJztcblxuQE5nTW9kdWxlKHtcbiAgICBkZWNsYXJhdGlvbnM6IFtcbiAgICAgICAgTW9udGhWaWV3Q29tcG9uZW50LCBXZWVrVmlld0NvbXBvbmVudCwgRGF5Vmlld0NvbXBvbmVudCwgQ2FsZW5kYXJDb21wb25lbnQsIGluaXRQb3NpdGlvblNjcm9sbENvbXBvbmVudFxuICAgIF0sXG4gICAgaW1wb3J0czogW0lvbmljTW9kdWxlLCBDb21tb25Nb2R1bGVdLFxuICAgIGV4cG9ydHM6IFtDYWxlbmRhckNvbXBvbmVudF1cbn0pXG5leHBvcnQgY2xhc3MgTmdDYWxlbmRhck1vZHVsZSB7fVxuIl19