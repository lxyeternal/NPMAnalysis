import { __decorate } from "tslib";
import { Component, Input, Output, EventEmitter, ElementRef, SimpleChanges, OnChanges, AfterViewInit, OnDestroy, ViewEncapsulation } from '@angular/core';
let initPositionScrollComponent = class initPositionScrollComponent {
    constructor(el) {
        this.onScroll = new EventEmitter();
        this.listenerAttached = false;
        this.element = el;
    }
    ngOnChanges(changes) {
        let initPosition = changes['initPosition'];
        if (initPosition && initPosition.currentValue !== undefined && this.scrollContent) {
            const me = this;
            setTimeout(function () {
                me.scrollContent.scrollTop = initPosition.currentValue;
            }, 0);
        }
    }
    ngAfterViewInit() {
        const scrollContent = this.scrollContent = this.element.nativeElement.querySelector('.scroll-content');
        if (this.initPosition !== undefined) {
            scrollContent.scrollTop = this.initPosition;
        }
        if (this.emitEvent && !this.listenerAttached) {
            let onScroll = this.onScroll;
            this.handler = function () {
                onScroll.emit(scrollContent.scrollTop);
            };
            this.listenerAttached = true;
            scrollContent.addEventListener('scroll', this.handler);
        }
    }
    ngOnDestroy() {
        if (this.listenerAttached) {
            this.scrollContent.removeEventListener('scroll', this.handler);
        }
    }
};
initPositionScrollComponent.ctorParameters = () => [
    { type: ElementRef }
];
__decorate([
    Input()
], initPositionScrollComponent.prototype, "initPosition", void 0);
__decorate([
    Input()
], initPositionScrollComponent.prototype, "emitEvent", void 0);
__decorate([
    Output()
], initPositionScrollComponent.prototype, "onScroll", void 0);
initPositionScrollComponent = __decorate([
    Component({
        selector: 'init-position-scroll',
        template: `
        <div class="scroll-content" style="height:100%">
            <ng-content></ng-content>
        </div>
    `,
        encapsulation: ViewEncapsulation.None,
        styles: [`
        .scroll-content {
            overflow-y: auto;
            overflow-x: hidden;
        }        
    `]
    })
], initPositionScrollComponent);
export { initPositionScrollComponent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5pdC1wb3NpdGlvbi1zY3JvbGwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9pb25pYzItY2FsZW5kYXItY3VzdG9tLyIsInNvdXJjZXMiOlsiaW5pdC1wb3NpdGlvbi1zY3JvbGwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osVUFBVSxFQUNWLGFBQWEsRUFDYixTQUFTLEVBQ1QsYUFBYSxFQUNiLFNBQVMsRUFDVCxpQkFBaUIsRUFDcEIsTUFBTSxlQUFlLENBQUM7QUFpQnZCLElBQWEsMkJBQTJCLEdBQXhDLE1BQWEsMkJBQTJCO0lBVXBDLFlBQVksRUFBYTtRQVBmLGFBQVEsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBS3hDLHFCQUFnQixHQUFXLEtBQUssQ0FBQztRQUdyQyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXFCO1FBQzdCLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUMzQyxJQUFJLFlBQVksSUFBSSxZQUFZLENBQUMsWUFBWSxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQy9FLE1BQU0sRUFBRSxHQUFFLElBQUksQ0FBQztZQUNmLFVBQVUsQ0FBQztnQkFDUCxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDO1lBQzNELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNUO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3ZHLElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUU7WUFDakMsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQy9DO1FBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQzFDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRztnQkFDWCxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN2QixJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDbEU7SUFDTCxDQUFDO0NBQ0osQ0FBQTs7WUFuQ2tCLFVBQVU7O0FBVGhCO0lBQVIsS0FBSyxFQUFFO2lFQUFxQjtBQUNwQjtJQUFSLEtBQUssRUFBRTs4REFBbUI7QUFDakI7SUFBVCxNQUFNLEVBQUU7NkRBQXVDO0FBSHZDLDJCQUEyQjtJQWZ2QyxTQUFTLENBQUM7UUFDUCxRQUFRLEVBQUUsc0JBQXNCO1FBQ2hDLFFBQVEsRUFBRTs7OztLQUlUO1FBT0QsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7aUJBTjVCOzs7OztLQUtSO0tBRUosQ0FBQztHQUNXLDJCQUEyQixDQTZDdkM7U0E3Q1ksMkJBQTJCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgSW5wdXQsXG4gICAgT3V0cHV0LFxuICAgIEV2ZW50RW1pdHRlcixcbiAgICBFbGVtZW50UmVmLFxuICAgIFNpbXBsZUNoYW5nZXMsXG4gICAgT25DaGFuZ2VzLFxuICAgIEFmdGVyVmlld0luaXQsXG4gICAgT25EZXN0cm95LFxuICAgIFZpZXdFbmNhcHN1bGF0aW9uXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2luaXQtcG9zaXRpb24tc2Nyb2xsJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8ZGl2IGNsYXNzPVwic2Nyb2xsLWNvbnRlbnRcIiBzdHlsZT1cImhlaWdodDoxMDAlXCI+XG4gICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgICAgIDwvZGl2PlxuICAgIGAsXG4gICAgc3R5bGVzOiBbYFxuICAgICAgICAuc2Nyb2xsLWNvbnRlbnQge1xuICAgICAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcbiAgICAgICAgICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgICAgICAgfSAgICAgICAgXG4gICAgYF0sXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZVxufSlcbmV4cG9ydCBjbGFzcyBpbml0UG9zaXRpb25TY3JvbGxDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XG4gICAgQElucHV0KCkgaW5pdFBvc2l0aW9uOm51bWJlcjtcbiAgICBASW5wdXQoKSBlbWl0RXZlbnQ6Ym9vbGVhbjtcbiAgICBAT3V0cHV0KCkgb25TY3JvbGwgPSBuZXcgRXZlbnRFbWl0dGVyPG51bWJlcj4oKTtcblxuICAgIHByaXZhdGUgZWxlbWVudDpFbGVtZW50UmVmO1xuICAgIHByaXZhdGUgc2Nyb2xsQ29udGVudDpIVE1MRWxlbWVudDtcbiAgICBwcml2YXRlIGhhbmRsZXI6KCk9PnZvaWQ7XG4gICAgcHJpdmF0ZSBsaXN0ZW5lckF0dGFjaGVkOmJvb2xlYW4gPSBmYWxzZTtcblxuICAgIGNvbnN0cnVjdG9yKGVsOkVsZW1lbnRSZWYpIHtcbiAgICAgICAgdGhpcy5lbGVtZW50ID0gZWw7XG4gICAgfVxuXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczpTaW1wbGVDaGFuZ2VzKSB7XG4gICAgICAgIGxldCBpbml0UG9zaXRpb24gPSBjaGFuZ2VzWydpbml0UG9zaXRpb24nXTtcbiAgICAgICAgaWYgKGluaXRQb3NpdGlvbiAmJiBpbml0UG9zaXRpb24uY3VycmVudFZhbHVlICE9PSB1bmRlZmluZWQgJiYgdGhpcy5zY3JvbGxDb250ZW50KSB7XG4gICAgICAgICAgICBjb25zdCBtZSA9dGhpcztcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgbWUuc2Nyb2xsQ29udGVudC5zY3JvbGxUb3AgPSBpbml0UG9zaXRpb24uY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIGNvbnN0IHNjcm9sbENvbnRlbnQgPSB0aGlzLnNjcm9sbENvbnRlbnQgPSB0aGlzLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc2Nyb2xsLWNvbnRlbnQnKTtcbiAgICAgICAgaWYgKHRoaXMuaW5pdFBvc2l0aW9uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wID0gdGhpcy5pbml0UG9zaXRpb247XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5lbWl0RXZlbnQgJiYgIXRoaXMubGlzdGVuZXJBdHRhY2hlZCkge1xuICAgICAgICAgICAgbGV0IG9uU2Nyb2xsID0gdGhpcy5vblNjcm9sbDtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBvblNjcm9sbC5lbWl0KHNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLmxpc3RlbmVyQXR0YWNoZWQgPSB0cnVlO1xuICAgICAgICAgICAgc2Nyb2xsQ29udGVudC5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCB0aGlzLmhhbmRsZXIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLmxpc3RlbmVyQXR0YWNoZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2Nyb2xsQ29udGVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCB0aGlzLmhhbmRsZXIpO1xuICAgICAgICB9XG4gICAgfVxufVxuIl19