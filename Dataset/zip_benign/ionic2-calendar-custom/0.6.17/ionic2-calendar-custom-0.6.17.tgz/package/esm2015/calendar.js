import { __decorate, __param } from "tslib";
import { Component, EventEmitter, Input, Output, Inject, LOCALE_ID } from '@angular/core';
import { CalendarService } from './calendar.service';
export var Step;
(function (Step) {
    Step[Step["QuarterHour"] = 15] = "QuarterHour";
    Step[Step["HalfHour"] = 30] = "HalfHour";
    Step[Step["Hour"] = 60] = "Hour";
})(Step || (Step = {}));
let CalendarComponent = class CalendarComponent {
    constructor(calendarService, appLocale) {
        this.calendarService = calendarService;
        this.appLocale = appLocale;
        this.eventSource = [];
        this.calendarMode = 'month';
        this.formatDay = 'd';
        this.formatDayHeader = 'EEE';
        this.formatDayTitle = 'MMMM dd, yyyy';
        this.formatWeekTitle = 'MMMM yyyy, \'Week\' w';
        this.formatMonthTitle = 'MMMM yyyy';
        this.formatWeekViewDayHeader = 'EEE d';
        this.formatHourColumn = 'ha';
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = 'all day';
        this.noEventsLabel = 'No Events';
        this.queryMode = 'local';
        this.step = Step.Hour;
        this.timeInterval = 60;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.onCurrentDateChanged = new EventEmitter();
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter();
        this.onDayHeaderSelected = new EventEmitter();
        this.onTitleChanged = new EventEmitter();
        this.hourParts = 1;
        this.hourSegments = 1;
        this.locale = appLocale;
    }
    get currentDate() {
        return this._currentDate;
    }
    set currentDate(val) {
        if (!val) {
            val = new Date();
        }
        this._currentDate = val;
        this.calendarService.setCurrentDate(val, true);
        this.onCurrentDateChanged.emit(this._currentDate);
    }
    ngOnInit() {
        if (this.autoSelect) {
            if (this.autoSelect.toString() === 'false') {
                this.autoSelect = false;
            }
            else {
                this.autoSelect = true;
            }
        }
        this.hourSegments = 60 / this.timeInterval;
        this.hourParts = 60 / this.step;
        if (this.hourParts <= this.hourSegments) {
            this.hourParts = 1;
        }
        else {
            this.hourParts = this.hourParts / this.hourSegments;
        }
        this.startHour = parseInt(this.startHour.toString());
        this.endHour = parseInt(this.endHour.toString());
        this.calendarService.queryMode = this.queryMode;
        this.currentDateChangedFromChildrenSubscription = this.calendarService.currentDateChangedFromChildren$.subscribe(currentDate => {
            this._currentDate = currentDate;
            this.onCurrentDateChanged.emit(currentDate);
        });
    }
    ngOnDestroy() {
        if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
        }
    }
    rangeChanged(range) {
        this.onRangeChanged.emit(range);
    }
    eventSelected(event) {
        this.onEventSelected.emit(event);
    }
    timeSelected(timeSelected) {
        this.onTimeSelected.emit(timeSelected);
    }
    daySelected(daySelected) {
        this.onDayHeaderSelected.emit(daySelected);
    }
    titleChanged(title) {
        this.onTitleChanged.emit(title);
    }
    loadEvents() {
        this.calendarService.loadEvents();
    }
    slideNext() {
        this.calendarService.slide(1);
    }
    slidePrev() {
        this.calendarService.slide(-1);
    }
    update() {
        this.calendarService.update();
    }
};
CalendarComponent.ctorParameters = () => [
    { type: CalendarService },
    { type: String, decorators: [{ type: Inject, args: [LOCALE_ID,] }] }
];
__decorate([
    Input()
], CalendarComponent.prototype, "currentDate", null);
__decorate([
    Input()
], CalendarComponent.prototype, "eventSource", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "calendarMode", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatDay", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatDayHeader", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatDayTitle", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatWeekTitle", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatMonthTitle", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatWeekViewDayHeader", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatHourColumn", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "showEventDetail", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "startingDayMonth", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "startingDayWeek", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "allDayLabel", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "noEventsLabel", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "queryMode", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "step", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "timeInterval", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "autoSelect", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "markDisabled", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "monthviewDisplayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "monthviewEventDetailTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewHeaderTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewAllDayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewNormalEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewAllDayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewNormalEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewInactiveAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewInactiveNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewInactiveAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewInactiveNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dateFormatter", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dir", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "scrollToHour", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "preserveScrollPosition", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "lockSwipeToPrev", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "lockSwipes", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "locale", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "startHour", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "endHour", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "sliderOptions", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onCurrentDateChanged", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onRangeChanged", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onEventSelected", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onTimeSelected", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onDayHeaderSelected", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onTitleChanged", void 0);
CalendarComponent = __decorate([
    Component({
        selector: 'calendar',
        template: `
        <ng-template #monthviewDefaultDisplayEventTemplate let-view="view" let-row="row" let-col="col">
            {{view.dates[row*7+col].label}}
        </ng-template>
        <ng-template #monthviewDefaultEventDetailTemplate let-showEventDetail="showEventDetail" let-selectedDate="selectedDate" let-noEventsLabel="noEventsLabel">
            <ion-list class="event-detail-container" has-bouncing="false" *ngIf="showEventDetail" overflow-scroll="false">
                <ion-item *ngFor="let event of selectedDate?.events" (click)="eventSelected(event)">
                        <span *ngIf="!event.allDay" class="monthview-eventdetail-timecolumn">{{event.startTime|date: 'HH:mm'}}
                            -
                            {{event.endTime|date: 'HH:mm'}}
                        </span>
                    <span *ngIf="event.allDay" class="monthview-eventdetail-timecolumn">{{allDayLabel}}</span>
                    <span class="event-detail">  |  {{event.title}}</span>
                </ion-item>
                <ion-item *ngIf="selectedDate?.events.length==0">
                    <div class="no-events-label">{{noEventsLabel}}</div>
                </ion-item>
            </ion-list>
        </ng-template>
        <ng-template #defaultWeekviewHeaderTemplate let-viewDate="viewDate">
            {{ viewDate.dayHeader }}
        </ng-template>
        <ng-template #defaultAllDayEventTemplate let-displayEvent="displayEvent">
            <div class="calendar-event-inner">{{displayEvent.event.title}}</div>
        </ng-template>
        <ng-template #defaultNormalEventTemplate let-displayEvent="displayEvent">
            <div class="calendar-event-inner">{{displayEvent.event.title}}</div>
        </ng-template>
        <ng-template #defaultWeekViewAllDayEventSectionTemplate let-day="day" let-eventTemplate="eventTemplate">
            <div [ngClass]="{'calendar-event-wrap': day.events}" *ngIf="day.events"
                 [ngStyle]="{height: 25*day.events.length+'px'}">
                <div *ngFor="let displayEvent of day.events" class="calendar-event" tappable
                     (click)="eventSelected(displayEvent.event)"
                     [ngStyle]="{top: 25*displayEvent.position+'px', width: 100*(displayEvent.endIndex-displayEvent.startIndex)+'%', height: '25px'}">
                    <ng-template [ngTemplateOutlet]="eventTemplate"
                                 [ngTemplateOutletContext]="{displayEvent:displayEvent}">
                    </ng-template>
                </div>
            </div>
        </ng-template>
        <ng-template #defaultDayViewAllDayEventSectionTemplate let-allDayEvents="allDayEvents" let-eventTemplate="eventTemplate">
            <div *ngFor="let displayEvent of allDayEvents; let eventIndex=index"
                 class="calendar-event" tappable
                 (click)="eventSelected(displayEvent.event)"
                 [ngStyle]="{top: 25*eventIndex+'px',width: '100%',height:'25px'}">
                <ng-template [ngTemplateOutlet]="eventTemplate"
                             [ngTemplateOutletContext]="{displayEvent:displayEvent}">
                </ng-template>
            </div>
        </ng-template>
        <ng-template #defaultNormalEventSectionTemplate let-tm="tm" let-hourParts="hourParts" let-eventTemplate="eventTemplate">
            <div [ngClass]="{'calendar-event-wrap': tm.events}" *ngIf="tm.events">
                <div *ngFor="let displayEvent of tm.events" class="calendar-event" tappable
                     (click)="eventSelected(displayEvent.event)"
                     [ngStyle]="{top: (37*displayEvent.startOffset/hourParts)+'px',left: 100/displayEvent.overlapNumber*displayEvent.position+'%', width: 100/displayEvent.overlapNumber+'%', height: 37*(displayEvent.endIndex -displayEvent.startIndex - (displayEvent.endOffset + displayEvent.startOffset)/hourParts)+'px'}">
                    <ng-template [ngTemplateOutlet]="eventTemplate"
                                 [ngTemplateOutletContext]="{displayEvent:displayEvent}">
                    </ng-template>
                </div>
            </div>
        </ng-template>
        <ng-template #defaultInactiveAllDayEventSectionTemplate>
        </ng-template>
        <ng-template #defaultInactiveNormalEventSectionTemplate>
        </ng-template>

        <div [ngSwitch]="calendarMode" class="{{calendarMode}}view-container">
            <monthview *ngSwitchCase="'month'"
                [formatDay]="formatDay"
                [formatDayHeader]="formatDayHeader"
                [formatMonthTitle]="formatMonthTitle"
                [startingDayMonth]="startingDayMonth"
                [showEventDetail]="showEventDetail"
                [noEventsLabel]="noEventsLabel"
                [autoSelect]="autoSelect"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [monthviewDisplayEventTemplate]="monthviewDisplayEventTemplate||monthviewDefaultDisplayEventTemplate"
                [monthviewInactiveDisplayEventTemplate]="monthviewInactiveDisplayEventTemplate||monthviewDefaultDisplayEventTemplate"
                [monthviewEventDetailTemplate]="monthviewEventDetailTemplate||monthviewDefaultEventDetailTemplate"
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipes]="lockSwipes"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)">
            </monthview>
            <weekview *ngSwitchCase="'week'"
                [formatWeekTitle]="formatWeekTitle"
                [formatWeekViewDayHeader]="formatWeekViewDayHeader"
                [formatHourColumn]="formatHourColumn"
                [startingDayWeek]="startingDayWeek"
                [allDayLabel]="allDayLabel"
                [hourParts]="hourParts"
                [autoSelect]="autoSelect"
                [hourSegments]="hourSegments"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [weekviewHeaderTemplate]="weekviewHeaderTemplate||defaultWeekviewHeaderTemplate"
                [weekviewAllDayEventTemplate]="weekviewAllDayEventTemplate||defaultAllDayEventTemplate"
                [weekviewNormalEventTemplate]="weekviewNormalEventTemplate||defaultNormalEventTemplate"
                [weekviewAllDayEventSectionTemplate]="weekviewAllDayEventSectionTemplate||defaultWeekViewAllDayEventSectionTemplate"
                [weekviewNormalEventSectionTemplate]="weekviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate"
                [weekviewInactiveAllDayEventSectionTemplate]="weekviewInactiveAllDayEventSectionTemplate||defaultInactiveAllDayEventSectionTemplate"
                [weekviewInactiveNormalEventSectionTemplate]="weekviewInactiveNormalEventSectionTemplate||defaultInactiveNormalEventSectionTemplate"
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [scrollToHour]="scrollToHour"
                [preserveScrollPosition]="preserveScrollPosition"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipes]="lockSwipes"
                [startHour]="startHour"
                [endHour]="endHour"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onDayHeaderSelected)="daySelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)">
            </weekview>
            <dayview *ngSwitchCase="'day'"
                [formatDayTitle]="formatDayTitle"
                [formatHourColumn]="formatHourColumn"
                [allDayLabel]="allDayLabel"
                [hourParts]="hourParts"
                [hourSegments]="hourSegments"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [dayviewAllDayEventTemplate]="dayviewAllDayEventTemplate||defaultAllDayEventTemplate"
                [dayviewNormalEventTemplate]="dayviewNormalEventTemplate||defaultNormalEventTemplate"
                [dayviewAllDayEventSectionTemplate]="dayviewAllDayEventSectionTemplate||defaultDayViewAllDayEventSectionTemplate"
                [dayviewNormalEventSectionTemplate]="dayviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate"
                [dayviewInactiveAllDayEventSectionTemplate]="dayviewInactiveAllDayEventSectionTemplate||defaultInactiveAllDayEventSectionTemplate"
                [dayviewInactiveNormalEventSectionTemplate]="dayviewInactiveNormalEventSectionTemplate||defaultInactiveNormalEventSectionTemplate"
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [scrollToHour]="scrollToHour"
                [preserveScrollPosition]="preserveScrollPosition"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipes]="lockSwipes"
                [startHour]="startHour"
                [endHour]="endHour"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)">
            </dayview>
        </div>
    `,
        providers: [CalendarService],
        styles: [`
        :host > div { height: 100%; }

        .event-detail-container {
          border-top: 2px darkgrey solid;
        }

        .no-events-label {
          font-weight: bold;
          color: darkgrey;
          text-align: center;
        }

        .event-detail {
          cursor: pointer;
          white-space: nowrap;
          text-overflow: ellipsis;
        }

        .monthview-eventdetail-timecolumn {
          width: 110px;
          overflow: hidden;
        }

        .calendar-event-inner {
          overflow: hidden;
          background-color: #3a87ad;
          color: white;
          height: 100%;
          width: 100%;
          padding: 2px;
          line-height: 15px;
          text-align: initial;
        }

        @media (max-width: 750px) {
          .calendar-event-inner {
            font-size: 12px;
          }
        }
    `]
    }),
    __param(1, Inject(LOCALE_ID))
], CalendarComponent);
export { CalendarComponent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9pb25pYzItY2FsZW5kYXItY3VzdG9tLyIsInNvdXJjZXMiOlsiY2FsZW5kYXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBVSxNQUFNLEVBQWUsTUFBTSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUcvRyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFpSnJELE1BQU0sQ0FBTixJQUFZLElBSVg7QUFKRCxXQUFZLElBQUk7SUFDWiw4Q0FBZ0IsQ0FBQTtJQUNoQix3Q0FBYSxDQUFBO0lBQ2IsZ0NBQVMsQ0FBQTtBQUNiLENBQUMsRUFKVyxJQUFJLEtBQUosSUFBSSxRQUlmO0FBMk1ELElBQWEsaUJBQWlCLEdBQTlCLE1BQWEsaUJBQWlCO0lBMEUxQixZQUFvQixlQUErQixFQUE2QixTQUFnQjtRQUE1RSxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7UUFBNkIsY0FBUyxHQUFULFNBQVMsQ0FBTztRQTFEdkYsZ0JBQVcsR0FBWSxFQUFFLENBQUM7UUFDMUIsaUJBQVksR0FBZ0IsT0FBTyxDQUFDO1FBQ3BDLGNBQVMsR0FBVSxHQUFHLENBQUM7UUFDdkIsb0JBQWUsR0FBVSxLQUFLLENBQUM7UUFDL0IsbUJBQWMsR0FBVSxlQUFlLENBQUM7UUFDeEMsb0JBQWUsR0FBVSx1QkFBdUIsQ0FBQztRQUNqRCxxQkFBZ0IsR0FBVSxXQUFXLENBQUM7UUFDdEMsNEJBQXVCLEdBQVUsT0FBTyxDQUFDO1FBQ3pDLHFCQUFnQixHQUFVLElBQUksQ0FBQztRQUMvQixvQkFBZSxHQUFXLElBQUksQ0FBQztRQUMvQixxQkFBZ0IsR0FBVSxDQUFDLENBQUM7UUFDNUIsb0JBQWUsR0FBVSxDQUFDLENBQUM7UUFDM0IsZ0JBQVcsR0FBVSxTQUFTLENBQUM7UUFDL0Isa0JBQWEsR0FBVSxXQUFXLENBQUM7UUFDbkMsY0FBUyxHQUFhLE9BQU8sQ0FBQztRQUM5QixTQUFJLEdBQVEsSUFBSSxDQUFDLElBQUksQ0FBQztRQUN0QixpQkFBWSxHQUFVLEVBQUUsQ0FBQztRQUN6QixlQUFVLEdBQVcsSUFBSSxDQUFDO1FBbUIxQixRQUFHLEdBQVUsRUFBRSxDQUFDO1FBQ2hCLGlCQUFZLEdBQVUsQ0FBQyxDQUFDO1FBQ3hCLDJCQUFzQixHQUFXLEtBQUssQ0FBQztRQUN2QyxvQkFBZSxHQUFXLEtBQUssQ0FBQztRQUNoQyxlQUFVLEdBQVcsS0FBSyxDQUFDO1FBQzNCLFdBQU0sR0FBVSxFQUFFLENBQUM7UUFDbkIsY0FBUyxHQUFVLENBQUMsQ0FBQztRQUNyQixZQUFPLEdBQVUsRUFBRSxDQUFDO1FBR25CLHlCQUFvQixHQUFHLElBQUksWUFBWSxFQUFRLENBQUM7UUFDaEQsbUJBQWMsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBQzVDLG9CQUFlLEdBQUcsSUFBSSxZQUFZLEVBQVUsQ0FBQztRQUM3QyxtQkFBYyxHQUFHLElBQUksWUFBWSxFQUFpQixDQUFDO1FBQ25ELHdCQUFtQixHQUFHLElBQUksWUFBWSxFQUFpQixDQUFDO1FBQ3hELG1CQUFjLEdBQUcsSUFBSSxZQUFZLEVBQVUsQ0FBQztRQUcvQyxjQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsaUJBQVksR0FBRyxDQUFDLENBQUM7UUFJcEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7SUFDNUIsQ0FBQztJQTFFRCxJQUFJLFdBQVc7UUFDWCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDN0IsQ0FBQztJQUVELElBQUksV0FBVyxDQUFDLEdBQVE7UUFDcEIsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNOLEdBQUcsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1NBQ3BCO1FBRUQsSUFBSSxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUM7UUFDeEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFnRUQsUUFBUTtRQUNKLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLEtBQUssT0FBTyxFQUFFO2dCQUN4QyxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzthQUMzQjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzthQUMxQjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUMzQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ2hDLElBQUcsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3BDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1NBQ3RCO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUN2RDtRQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUVoRCxJQUFJLENBQUMsMENBQTBDLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQywrQkFBK0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDM0gsSUFBSSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUM7WUFDaEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNoRCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxJQUFJLENBQUMsMENBQTBDLEVBQUU7WUFDakQsSUFBSSxDQUFDLDBDQUEwQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzlELElBQUksQ0FBQywwQ0FBMEMsR0FBRyxJQUFJLENBQUM7U0FDMUQ7SUFDTCxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQVk7UUFDckIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELGFBQWEsQ0FBQyxLQUFZO1FBQ3RCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxZQUFZLENBQUMsWUFBMEI7UUFDbkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVELFdBQVcsQ0FBQyxXQUF5QjtRQUNqQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBWTtRQUNyQixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsVUFBVTtRQUNOLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEMsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRUQsU0FBUztRQUNMLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVELE1BQU07UUFDRixJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2xDLENBQUM7Q0FDSixDQUFBOztZQXZFdUMsZUFBZTt5Q0FBRyxNQUFNLFNBQUMsU0FBUzs7QUF4RXRFO0lBREMsS0FBSyxFQUFFO29EQUdQO0FBWVE7SUFBUixLQUFLLEVBQUU7c0RBQTJCO0FBQzFCO0lBQVIsS0FBSyxFQUFFO3VEQUFxQztBQUNwQztJQUFSLEtBQUssRUFBRTtvREFBd0I7QUFDdkI7SUFBUixLQUFLLEVBQUU7MERBQWdDO0FBQy9CO0lBQVIsS0FBSyxFQUFFO3lEQUF5QztBQUN4QztJQUFSLEtBQUssRUFBRTswREFBa0Q7QUFDakQ7SUFBUixLQUFLLEVBQUU7MkRBQXVDO0FBQ3RDO0lBQVIsS0FBSyxFQUFFO2tFQUEwQztBQUN6QztJQUFSLEtBQUssRUFBRTsyREFBZ0M7QUFDL0I7SUFBUixLQUFLLEVBQUU7MERBQWdDO0FBQy9CO0lBQVIsS0FBSyxFQUFFOzJEQUE2QjtBQUM1QjtJQUFSLEtBQUssRUFBRTswREFBNEI7QUFDM0I7SUFBUixLQUFLLEVBQUU7c0RBQWdDO0FBQy9CO0lBQVIsS0FBSyxFQUFFO3dEQUFvQztBQUNuQztJQUFSLEtBQUssRUFBRTtvREFBK0I7QUFDOUI7SUFBUixLQUFLLEVBQUU7K0NBQXVCO0FBQ3RCO0lBQVIsS0FBSyxFQUFFO3VEQUEwQjtBQUN6QjtJQUFSLEtBQUssRUFBRTtxREFBMkI7QUFDMUI7SUFBUixLQUFLLEVBQUU7dURBQXFDO0FBQ3BDO0lBQVIsS0FBSyxFQUFFO3dFQUFrRjtBQUNqRjtJQUFSLEtBQUssRUFBRTtnRkFBMEY7QUFDekY7SUFBUixLQUFLLEVBQUU7dUVBQWdGO0FBQy9FO0lBQVIsS0FBSyxFQUFFO2lFQUE0RDtBQUMzRDtJQUFSLEtBQUssRUFBRTtzRUFBOEQ7QUFDN0Q7SUFBUixLQUFLLEVBQUU7c0VBQXdEO0FBQ3ZEO0lBQVIsS0FBSyxFQUFFO3FFQUE2RDtBQUM1RDtJQUFSLEtBQUssRUFBRTtxRUFBdUQ7QUFDdEQ7SUFBUixLQUFLLEVBQUU7NkVBQTRGO0FBQzNGO0lBQVIsS0FBSyxFQUFFOzZFQUE0RjtBQUMzRjtJQUFSLEtBQUssRUFBRTs0RUFBMEY7QUFDekY7SUFBUixLQUFLLEVBQUU7NEVBQTBGO0FBQ3pGO0lBQVIsS0FBSyxFQUFFO3FGQUFvRztBQUNuRztJQUFSLEtBQUssRUFBRTtxRkFBb0c7QUFDbkc7SUFBUixLQUFLLEVBQUU7b0ZBQWtHO0FBQ2pHO0lBQVIsS0FBSyxFQUFFO29GQUFrRztBQUNqRztJQUFSLEtBQUssRUFBRTt3REFBOEI7QUFDN0I7SUFBUixLQUFLLEVBQUU7OENBQWlCO0FBQ2hCO0lBQVIsS0FBSyxFQUFFO3VEQUF5QjtBQUN4QjtJQUFSLEtBQUssRUFBRTtpRUFBd0M7QUFDdkM7SUFBUixLQUFLLEVBQUU7MERBQWlDO0FBQ2hDO0lBQVIsS0FBSyxFQUFFO3FEQUE0QjtBQUMzQjtJQUFSLEtBQUssRUFBRTtpREFBb0I7QUFDbkI7SUFBUixLQUFLLEVBQUU7b0RBQXNCO0FBQ3JCO0lBQVIsS0FBSyxFQUFFO2tEQUFxQjtBQUNwQjtJQUFSLEtBQUssRUFBRTt3REFBbUI7QUFFakI7SUFBVCxNQUFNLEVBQUU7K0RBQWlEO0FBQ2hEO0lBQVQsTUFBTSxFQUFFO3lEQUE2QztBQUM1QztJQUFULE1BQU0sRUFBRTswREFBOEM7QUFDN0M7SUFBVCxNQUFNLEVBQUU7eURBQW9EO0FBQ25EO0lBQVQsTUFBTSxFQUFFOzhEQUF5RDtBQUN4RDtJQUFULE1BQU0sRUFBRTt5REFBNkM7QUFuRTdDLGlCQUFpQjtJQXpNN0IsU0FBUyxDQUFDO1FBQ1AsUUFBUSxFQUFFLFVBQVU7UUFDcEIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQTJKVDtRQTBDRCxTQUFTLEVBQUUsQ0FBQyxlQUFlLENBQUM7aUJBekNuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQXdDUjtLQUVKLENBQUM7SUEyRXdELFdBQUEsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFBO0dBMUU5RCxpQkFBaUIsQ0FpSjdCO1NBakpZLGlCQUFpQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25Jbml0LCBPdXRwdXQsIFRlbXBsYXRlUmVmLCBJbmplY3QsIExPQ0FMRV9JRCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5cbmltcG9ydCB7IENhbGVuZGFyU2VydmljZSB9IGZyb20gJy4vY2FsZW5kYXIuc2VydmljZSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSUV2ZW50IHtcbiAgICBhbGxEYXk6IGJvb2xlYW47XG4gICAgZW5kVGltZTogRGF0ZTtcbiAgICBzdGFydFRpbWU6IERhdGU7XG4gICAgdGl0bGU6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJUmFuZ2Uge1xuICAgIHN0YXJ0VGltZTogRGF0ZTtcbiAgICBlbmRUaW1lOiBEYXRlO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElWaWV3IHtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJRGF5VmlldyBleHRlbmRzIElWaWV3IHtcbiAgICBhbGxEYXlFdmVudHM6IElEaXNwbGF5QWxsRGF5RXZlbnRbXTtcbiAgICByb3dzOiBJRGF5Vmlld1Jvd1tdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElEYXlWaWV3Um93IHtcbiAgICBldmVudHM6IElEaXNwbGF5RXZlbnRbXTtcbiAgICB0aW1lOiBEYXRlO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElNb250aFZpZXcgZXh0ZW5kcyBJVmlldyB7XG4gICAgZGF0ZXM6IElNb250aFZpZXdSb3dbXTtcbiAgICBkYXlIZWFkZXJzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJTW9udGhWaWV3Um93IHtcbiAgICBjdXJyZW50PzogYm9vbGVhbjtcbiAgICBkYXRlOiBEYXRlO1xuICAgIGV2ZW50czogSUV2ZW50W107XG4gICAgaGFzRXZlbnQ/OiBib29sZWFuO1xuICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgc2Vjb25kYXJ5OiBib29sZWFuO1xuICAgIHNlbGVjdGVkPzogYm9vbGVhbjtcbiAgICBkaXNhYmxlZDogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJV2Vla1ZpZXcgZXh0ZW5kcyBJVmlldyB7XG4gICAgZGF0ZXM6IElXZWVrVmlld0RhdGVSb3dbXTtcbiAgICByb3dzOiBJV2Vla1ZpZXdSb3dbXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElXZWVrVmlld0RhdGVSb3cge1xuICAgIGN1cnJlbnQ/OiBib29sZWFuO1xuICAgIGRhdGU6IERhdGU7XG4gICAgZXZlbnRzOiBJRGlzcGxheUV2ZW50W107XG4gICAgaGFzRXZlbnQ/OiBib29sZWFuO1xuICAgIHNlbGVjdGVkPzogYm9vbGVhbjtcbiAgICBkYXlIZWFkZXI6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJV2Vla1ZpZXdSb3cge1xuICAgIGV2ZW50czogSURpc3BsYXlFdmVudFtdO1xuICAgIHRpbWU6IERhdGU7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURpc3BsYXlFdmVudCB7XG4gICAgZW5kSW5kZXg6IG51bWJlcjtcbiAgICBlbmRPZmZzZXQ/OiBudW1iZXI7XG4gICAgZXZlbnQ6IElFdmVudDtcbiAgICBzdGFydEluZGV4OiBudW1iZXI7XG4gICAgc3RhcnRPZmZzZXQ/OiBudW1iZXI7XG4gICAgb3ZlcmxhcE51bWJlcj86IG51bWJlcjtcbiAgICBwb3NpdGlvbj86IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJRGlzcGxheVdlZWtWaWV3SGVhZGVyIHtcbiAgICB2aWV3RGF0ZTogSVdlZWtWaWV3RGF0ZVJvdztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJRGlzcGxheUFsbERheUV2ZW50IHtcbiAgICBldmVudDogSUV2ZW50O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElDYWxlbmRhckNvbXBvbmVudCB7XG4gICAgY3VycmVudFZpZXdJbmRleDogbnVtYmVyO1xuICAgIGRpcmVjdGlvbjogbnVtYmVyO1xuICAgIGV2ZW50U291cmNlOiBJRXZlbnRbXTtcbiAgICBnZXRSYW5nZTogeyAoZGF0ZTpEYXRlKTogSVJhbmdlOyB9O1xuICAgIGdldFZpZXdEYXRhOiB7IChkYXRlOkRhdGUpOiBJVmlldyB9O1xuICAgIG1vZGU6IENhbGVuZGFyTW9kZTtcbiAgICByYW5nZTogSVJhbmdlO1xuICAgIHZpZXdzOiBJVmlld1tdO1xuICAgIG9uRGF0YUxvYWRlZDogeyAoKTogdm9pZCB9O1xuICAgIG9uUmFuZ2VDaGFuZ2VkOiBFdmVudEVtaXR0ZXI8SVJhbmdlPjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJVGltZVNlbGVjdGVkIHtcbiAgICBldmVudHM6IElFdmVudFtdO1xuICAgIHNlbGVjdGVkVGltZTogRGF0ZTtcbiAgICBkaXNhYmxlZDogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJTW9udGhWaWV3RGlzcGxheUV2ZW50VGVtcGxhdGVDb250ZXh0IHtcbiAgICB2aWV3OiBJVmlldztcbiAgICByb3c6IG51bWJlcjtcbiAgICBjb2w6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJTW9udGhWaWV3RXZlbnREZXRhaWxUZW1wbGF0ZUNvbnRleHQge1xuICAgIHNlbGVjdGVkRGF0ZTogSVRpbWVTZWxlY3RlZDtcbiAgICBub0V2ZW50c0xhYmVsOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVdlZWtWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0IHtcbiAgICBkYXk6IElXZWVrVmlld0RhdGVSb3csXG4gICAgZXZlbnRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SURpc3BsYXlBbGxEYXlFdmVudD5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBJV2Vla1ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQge1xuICAgIHRtOiBJV2Vla1ZpZXdSb3csXG4gICAgZXZlbnRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SURpc3BsYXlFdmVudD5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBJRGF5Vmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dCB7XG4gICAgYWxsZGF5RXZlbnRzOiBJRGlzcGxheUFsbERheUV2ZW50W10sXG4gICAgZXZlbnRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SURpc3BsYXlBbGxEYXlFdmVudD5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBJRGF5Vmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dCB7XG4gICAgdG06IElEYXlWaWV3Um93LFxuICAgIGV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5RXZlbnQ+XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURhdGVGb3JtYXR0ZXIge1xuICAgIGZvcm1hdE1vbnRoVmlld0RheT86IHsgKGRhdGU6RGF0ZSk6IHN0cmluZzsgfTtcbiAgICBmb3JtYXRNb250aFZpZXdEYXlIZWFkZXI/OiB7IChkYXRlOkRhdGUpOiBzdHJpbmc7IH07XG4gICAgZm9ybWF0TW9udGhWaWV3VGl0bGU/OiB7IChkYXRlOkRhdGUpOiBzdHJpbmc7IH07XG4gICAgZm9ybWF0V2Vla1ZpZXdEYXlIZWFkZXI/OiB7IChkYXRlOkRhdGUpOiBzdHJpbmc7IH07XG4gICAgZm9ybWF0V2Vla1ZpZXdUaXRsZT86IHsgKGRhdGU6RGF0ZSk6IHN0cmluZzsgfTtcbiAgICBmb3JtYXRXZWVrVmlld0hvdXJDb2x1bW4/OiB7IChkYXRlOkRhdGUpOiBzdHJpbmc7IH07XG4gICAgZm9ybWF0RGF5Vmlld1RpdGxlPzogeyAoZGF0ZTpEYXRlKTogc3RyaW5nOyB9O1xuICAgIGZvcm1hdERheVZpZXdIb3VyQ29sdW1uPzogeyAoZGF0ZTpEYXRlKTogc3RyaW5nOyB9O1xufVxuXG5leHBvcnQgdHlwZSBDYWxlbmRhck1vZGUgPSAnZGF5JyB8ICdtb250aCcgfCAnd2Vlayc7XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5TW9kZSA9ICdsb2NhbCcgfCAncmVtb3RlJztcblxuZXhwb3J0IGVudW0gU3RlcCB7XG4gICAgUXVhcnRlckhvdXIgPSAxNSxcbiAgICBIYWxmSG91ciA9IDMwLFxuICAgIEhvdXIgPSA2MFxufVxuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ2NhbGVuZGFyJyxcbiAgICB0ZW1wbGF0ZTogYFxuICAgICAgICA8bmctdGVtcGxhdGUgI21vbnRodmlld0RlZmF1bHREaXNwbGF5RXZlbnRUZW1wbGF0ZSBsZXQtdmlldz1cInZpZXdcIiBsZXQtcm93PVwicm93XCIgbGV0LWNvbD1cImNvbFwiPlxuICAgICAgICAgICAge3t2aWV3LmRhdGVzW3Jvdyo3K2NvbF0ubGFiZWx9fVxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8bmctdGVtcGxhdGUgI21vbnRodmlld0RlZmF1bHRFdmVudERldGFpbFRlbXBsYXRlIGxldC1zaG93RXZlbnREZXRhaWw9XCJzaG93RXZlbnREZXRhaWxcIiBsZXQtc2VsZWN0ZWREYXRlPVwic2VsZWN0ZWREYXRlXCIgbGV0LW5vRXZlbnRzTGFiZWw9XCJub0V2ZW50c0xhYmVsXCI+XG4gICAgICAgICAgICA8aW9uLWxpc3QgY2xhc3M9XCJldmVudC1kZXRhaWwtY29udGFpbmVyXCIgaGFzLWJvdW5jaW5nPVwiZmFsc2VcIiAqbmdJZj1cInNob3dFdmVudERldGFpbFwiIG92ZXJmbG93LXNjcm9sbD1cImZhbHNlXCI+XG4gICAgICAgICAgICAgICAgPGlvbi1pdGVtICpuZ0Zvcj1cImxldCBldmVudCBvZiBzZWxlY3RlZERhdGU/LmV2ZW50c1wiIChjbGljayk9XCJldmVudFNlbGVjdGVkKGV2ZW50KVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCIhZXZlbnQuYWxsRGF5XCIgY2xhc3M9XCJtb250aHZpZXctZXZlbnRkZXRhaWwtdGltZWNvbHVtblwiPnt7ZXZlbnQuc3RhcnRUaW1lfGRhdGU6ICdISDptbSd9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7e2V2ZW50LmVuZFRpbWV8ZGF0ZTogJ0hIOm1tJ319XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiZXZlbnQuYWxsRGF5XCIgY2xhc3M9XCJtb250aHZpZXctZXZlbnRkZXRhaWwtdGltZWNvbHVtblwiPnt7YWxsRGF5TGFiZWx9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJldmVudC1kZXRhaWxcIj4gIHwgIHt7ZXZlbnQudGl0bGV9fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2lvbi1pdGVtPlxuICAgICAgICAgICAgICAgIDxpb24taXRlbSAqbmdJZj1cInNlbGVjdGVkRGF0ZT8uZXZlbnRzLmxlbmd0aD09MFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibm8tZXZlbnRzLWxhYmVsXCI+e3tub0V2ZW50c0xhYmVsfX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2lvbi1pdGVtPlxuICAgICAgICAgICAgPC9pb24tbGlzdD5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZhdWx0V2Vla3ZpZXdIZWFkZXJUZW1wbGF0ZSBsZXQtdmlld0RhdGU9XCJ2aWV3RGF0ZVwiPlxuICAgICAgICAgICAge3sgdmlld0RhdGUuZGF5SGVhZGVyIH19XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdEFsbERheUV2ZW50VGVtcGxhdGUgbGV0LWRpc3BsYXlFdmVudD1cImRpc3BsYXlFdmVudFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhbGVuZGFyLWV2ZW50LWlubmVyXCI+e3tkaXNwbGF5RXZlbnQuZXZlbnQudGl0bGV9fTwvZGl2PlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICA8bmctdGVtcGxhdGUgI2RlZmF1bHROb3JtYWxFdmVudFRlbXBsYXRlIGxldC1kaXNwbGF5RXZlbnQ9XCJkaXNwbGF5RXZlbnRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYWxlbmRhci1ldmVudC1pbm5lclwiPnt7ZGlzcGxheUV2ZW50LmV2ZW50LnRpdGxlfX08L2Rpdj5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZhdWx0V2Vla1ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZSBsZXQtZGF5PVwiZGF5XCIgbGV0LWV2ZW50VGVtcGxhdGU9XCJldmVudFRlbXBsYXRlXCI+XG4gICAgICAgICAgICA8ZGl2IFtuZ0NsYXNzXT1cInsnY2FsZW5kYXItZXZlbnQtd3JhcCc6IGRheS5ldmVudHN9XCIgKm5nSWY9XCJkYXkuZXZlbnRzXCJcbiAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie2hlaWdodDogMjUqZGF5LmV2ZW50cy5sZW5ndGgrJ3B4J31cIj5cbiAgICAgICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cImxldCBkaXNwbGF5RXZlbnQgb2YgZGF5LmV2ZW50c1wiIGNsYXNzPVwiY2FsZW5kYXItZXZlbnRcIiB0YXBwYWJsZVxuICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImV2ZW50U2VsZWN0ZWQoZGlzcGxheUV2ZW50LmV2ZW50KVwiXG4gICAgICAgICAgICAgICAgICAgICBbbmdTdHlsZV09XCJ7dG9wOiAyNSpkaXNwbGF5RXZlbnQucG9zaXRpb24rJ3B4Jywgd2lkdGg6IDEwMCooZGlzcGxheUV2ZW50LmVuZEluZGV4LWRpc3BsYXlFdmVudC5zdGFydEluZGV4KSsnJScsIGhlaWdodDogJzI1cHgnfVwiPlxuICAgICAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGUgW25nVGVtcGxhdGVPdXRsZXRdPVwiZXZlbnRUZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie2Rpc3BsYXlFdmVudDpkaXNwbGF5RXZlbnR9XCI+XG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZhdWx0RGF5Vmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlIGxldC1hbGxEYXlFdmVudHM9XCJhbGxEYXlFdmVudHNcIiBsZXQtZXZlbnRUZW1wbGF0ZT1cImV2ZW50VGVtcGxhdGVcIj5cbiAgICAgICAgICAgIDxkaXYgKm5nRm9yPVwibGV0IGRpc3BsYXlFdmVudCBvZiBhbGxEYXlFdmVudHM7IGxldCBldmVudEluZGV4PWluZGV4XCJcbiAgICAgICAgICAgICAgICAgY2xhc3M9XCJjYWxlbmRhci1ldmVudFwiIHRhcHBhYmxlXG4gICAgICAgICAgICAgICAgIChjbGljayk9XCJldmVudFNlbGVjdGVkKGRpc3BsYXlFdmVudC5ldmVudClcIlxuICAgICAgICAgICAgICAgICBbbmdTdHlsZV09XCJ7dG9wOiAyNSpldmVudEluZGV4KydweCcsd2lkdGg6ICcxMDAlJyxoZWlnaHQ6JzI1cHgnfVwiPlxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBbbmdUZW1wbGF0ZU91dGxldF09XCJldmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntkaXNwbGF5RXZlbnQ6ZGlzcGxheUV2ZW50fVwiPlxuICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cbiAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZhdWx0Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGUgbGV0LXRtPVwidG1cIiBsZXQtaG91clBhcnRzPVwiaG91clBhcnRzXCIgbGV0LWV2ZW50VGVtcGxhdGU9XCJldmVudFRlbXBsYXRlXCI+XG4gICAgICAgICAgICA8ZGl2IFtuZ0NsYXNzXT1cInsnY2FsZW5kYXItZXZlbnQtd3JhcCc6IHRtLmV2ZW50c31cIiAqbmdJZj1cInRtLmV2ZW50c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgKm5nRm9yPVwibGV0IGRpc3BsYXlFdmVudCBvZiB0bS5ldmVudHNcIiBjbGFzcz1cImNhbGVuZGFyLWV2ZW50XCIgdGFwcGFibGVcbiAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJldmVudFNlbGVjdGVkKGRpc3BsYXlFdmVudC5ldmVudClcIlxuICAgICAgICAgICAgICAgICAgICAgW25nU3R5bGVdPVwie3RvcDogKDM3KmRpc3BsYXlFdmVudC5zdGFydE9mZnNldC9ob3VyUGFydHMpKydweCcsbGVmdDogMTAwL2Rpc3BsYXlFdmVudC5vdmVybGFwTnVtYmVyKmRpc3BsYXlFdmVudC5wb3NpdGlvbisnJScsIHdpZHRoOiAxMDAvZGlzcGxheUV2ZW50Lm92ZXJsYXBOdW1iZXIrJyUnLCBoZWlnaHQ6IDM3KihkaXNwbGF5RXZlbnQuZW5kSW5kZXggLWRpc3BsYXlFdmVudC5zdGFydEluZGV4IC0gKGRpc3BsYXlFdmVudC5lbmRPZmZzZXQgKyBkaXNwbGF5RXZlbnQuc3RhcnRPZmZzZXQpL2hvdXJQYXJ0cykrJ3B4J31cIj5cbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIFtuZ1RlbXBsYXRlT3V0bGV0XT1cImV2ZW50VGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntkaXNwbGF5RXZlbnQ6ZGlzcGxheUV2ZW50fVwiPlxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdEluYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG4gICAgICAgIDxuZy10ZW1wbGF0ZSAjZGVmYXVsdEluYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGU+XG4gICAgICAgIDwvbmctdGVtcGxhdGU+XG5cbiAgICAgICAgPGRpdiBbbmdTd2l0Y2hdPVwiY2FsZW5kYXJNb2RlXCIgY2xhc3M9XCJ7e2NhbGVuZGFyTW9kZX19dmlldy1jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxtb250aHZpZXcgKm5nU3dpdGNoQ2FzZT1cIidtb250aCdcIlxuICAgICAgICAgICAgICAgIFtmb3JtYXREYXldPVwiZm9ybWF0RGF5XCJcbiAgICAgICAgICAgICAgICBbZm9ybWF0RGF5SGVhZGVyXT1cImZvcm1hdERheUhlYWRlclwiXG4gICAgICAgICAgICAgICAgW2Zvcm1hdE1vbnRoVGl0bGVdPVwiZm9ybWF0TW9udGhUaXRsZVwiXG4gICAgICAgICAgICAgICAgW3N0YXJ0aW5nRGF5TW9udGhdPVwic3RhcnRpbmdEYXlNb250aFwiXG4gICAgICAgICAgICAgICAgW3Nob3dFdmVudERldGFpbF09XCJzaG93RXZlbnREZXRhaWxcIlxuICAgICAgICAgICAgICAgIFtub0V2ZW50c0xhYmVsXT1cIm5vRXZlbnRzTGFiZWxcIlxuICAgICAgICAgICAgICAgIFthdXRvU2VsZWN0XT1cImF1dG9TZWxlY3RcIlxuICAgICAgICAgICAgICAgIFtldmVudFNvdXJjZV09XCJldmVudFNvdXJjZVwiXG4gICAgICAgICAgICAgICAgW21hcmtEaXNhYmxlZF09XCJtYXJrRGlzYWJsZWRcIlxuICAgICAgICAgICAgICAgIFttb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZV09XCJtb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZXx8bW9udGh2aWV3RGVmYXVsdERpc3BsYXlFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbbW9udGh2aWV3SW5hY3RpdmVEaXNwbGF5RXZlbnRUZW1wbGF0ZV09XCJtb250aHZpZXdJbmFjdGl2ZURpc3BsYXlFdmVudFRlbXBsYXRlfHxtb250aHZpZXdEZWZhdWx0RGlzcGxheUV2ZW50VGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgIFttb250aHZpZXdFdmVudERldGFpbFRlbXBsYXRlXT1cIm1vbnRodmlld0V2ZW50RGV0YWlsVGVtcGxhdGV8fG1vbnRodmlld0RlZmF1bHRFdmVudERldGFpbFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbbG9jYWxlXT1cImxvY2FsZVwiXG4gICAgICAgICAgICAgICAgW2RhdGVGb3JtYXR0ZXJdPVwiZGF0ZUZvcm1hdHRlclwiXG4gICAgICAgICAgICAgICAgW2Rpcl09XCJkaXJcIlxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVUb1ByZXZdPVwibG9ja1N3aXBlVG9QcmV2XCJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlc109XCJsb2NrU3dpcGVzXCJcbiAgICAgICAgICAgICAgICBbc2xpZGVyT3B0aW9uc109XCJzbGlkZXJPcHRpb25zXCJcbiAgICAgICAgICAgICAgICAob25SYW5nZUNoYW5nZWQpPVwicmFuZ2VDaGFuZ2VkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvbkV2ZW50U2VsZWN0ZWQpPVwiZXZlbnRTZWxlY3RlZCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAob25UaW1lU2VsZWN0ZWQpPVwidGltZVNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvblRpdGxlQ2hhbmdlZCk9XCJ0aXRsZUNoYW5nZWQoJGV2ZW50KVwiPlxuICAgICAgICAgICAgPC9tb250aHZpZXc+XG4gICAgICAgICAgICA8d2Vla3ZpZXcgKm5nU3dpdGNoQ2FzZT1cIid3ZWVrJ1wiXG4gICAgICAgICAgICAgICAgW2Zvcm1hdFdlZWtUaXRsZV09XCJmb3JtYXRXZWVrVGl0bGVcIlxuICAgICAgICAgICAgICAgIFtmb3JtYXRXZWVrVmlld0RheUhlYWRlcl09XCJmb3JtYXRXZWVrVmlld0RheUhlYWRlclwiXG4gICAgICAgICAgICAgICAgW2Zvcm1hdEhvdXJDb2x1bW5dPVwiZm9ybWF0SG91ckNvbHVtblwiXG4gICAgICAgICAgICAgICAgW3N0YXJ0aW5nRGF5V2Vla109XCJzdGFydGluZ0RheVdlZWtcIlxuICAgICAgICAgICAgICAgIFthbGxEYXlMYWJlbF09XCJhbGxEYXlMYWJlbFwiXG4gICAgICAgICAgICAgICAgW2hvdXJQYXJ0c109XCJob3VyUGFydHNcIlxuICAgICAgICAgICAgICAgIFthdXRvU2VsZWN0XT1cImF1dG9TZWxlY3RcIlxuICAgICAgICAgICAgICAgIFtob3VyU2VnbWVudHNdPVwiaG91clNlZ21lbnRzXCJcbiAgICAgICAgICAgICAgICBbZXZlbnRTb3VyY2VdPVwiZXZlbnRTb3VyY2VcIlxuICAgICAgICAgICAgICAgIFttYXJrRGlzYWJsZWRdPVwibWFya0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdIZWFkZXJUZW1wbGF0ZV09XCJ3ZWVrdmlld0hlYWRlclRlbXBsYXRlfHxkZWZhdWx0V2Vla3ZpZXdIZWFkZXJUZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZV09XCJ3ZWVrdmlld0FsbERheUV2ZW50VGVtcGxhdGV8fGRlZmF1bHRBbGxEYXlFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdOb3JtYWxFdmVudFRlbXBsYXRlXT1cIndlZWt2aWV3Tm9ybWFsRXZlbnRUZW1wbGF0ZXx8ZGVmYXVsdE5vcm1hbEV2ZW50VGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXT1cIndlZWt2aWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGV8fGRlZmF1bHRXZWVrVmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJ3ZWVrdmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlfHxkZWZhdWx0Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVcIlxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld0luYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVdPVwid2Vla3ZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlfHxkZWZhdWx0SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3SW5hY3RpdmVOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJ3ZWVrdmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGV8fGRlZmF1bHRJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbbG9jYWxlXT1cImxvY2FsZVwiXG4gICAgICAgICAgICAgICAgW2RhdGVGb3JtYXR0ZXJdPVwiZGF0ZUZvcm1hdHRlclwiXG4gICAgICAgICAgICAgICAgW2Rpcl09XCJkaXJcIlxuICAgICAgICAgICAgICAgIFtzY3JvbGxUb0hvdXJdPVwic2Nyb2xsVG9Ib3VyXCJcbiAgICAgICAgICAgICAgICBbcHJlc2VydmVTY3JvbGxQb3NpdGlvbl09XCJwcmVzZXJ2ZVNjcm9sbFBvc2l0aW9uXCJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlVG9QcmV2XT1cImxvY2tTd2lwZVRvUHJldlwiXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZXNdPVwibG9ja1N3aXBlc1wiXG4gICAgICAgICAgICAgICAgW3N0YXJ0SG91cl09XCJzdGFydEhvdXJcIlxuICAgICAgICAgICAgICAgIFtlbmRIb3VyXT1cImVuZEhvdXJcIlxuICAgICAgICAgICAgICAgIFtzbGlkZXJPcHRpb25zXT1cInNsaWRlck9wdGlvbnNcIlxuICAgICAgICAgICAgICAgIChvblJhbmdlQ2hhbmdlZCk9XCJyYW5nZUNoYW5nZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uRXZlbnRTZWxlY3RlZCk9XCJldmVudFNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvbkRheUhlYWRlclNlbGVjdGVkKT1cImRheVNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvblRpbWVTZWxlY3RlZCk9XCJ0aW1lU2VsZWN0ZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgICAgKG9uVGl0bGVDaGFuZ2VkKT1cInRpdGxlQ2hhbmdlZCgkZXZlbnQpXCI+XG4gICAgICAgICAgICA8L3dlZWt2aWV3PlxuICAgICAgICAgICAgPGRheXZpZXcgKm5nU3dpdGNoQ2FzZT1cIidkYXknXCJcbiAgICAgICAgICAgICAgICBbZm9ybWF0RGF5VGl0bGVdPVwiZm9ybWF0RGF5VGl0bGVcIlxuICAgICAgICAgICAgICAgIFtmb3JtYXRIb3VyQ29sdW1uXT1cImZvcm1hdEhvdXJDb2x1bW5cIlxuICAgICAgICAgICAgICAgIFthbGxEYXlMYWJlbF09XCJhbGxEYXlMYWJlbFwiXG4gICAgICAgICAgICAgICAgW2hvdXJQYXJ0c109XCJob3VyUGFydHNcIlxuICAgICAgICAgICAgICAgIFtob3VyU2VnbWVudHNdPVwiaG91clNlZ21lbnRzXCJcbiAgICAgICAgICAgICAgICBbZXZlbnRTb3VyY2VdPVwiZXZlbnRTb3VyY2VcIlxuICAgICAgICAgICAgICAgIFttYXJrRGlzYWJsZWRdPVwibWFya0Rpc2FibGVkXCJcbiAgICAgICAgICAgICAgICBbZGF5dmlld0FsbERheUV2ZW50VGVtcGxhdGVdPVwiZGF5dmlld0FsbERheUV2ZW50VGVtcGxhdGV8fGRlZmF1bHRBbGxEYXlFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbZGF5dmlld05vcm1hbEV2ZW50VGVtcGxhdGVdPVwiZGF5dmlld05vcm1hbEV2ZW50VGVtcGxhdGV8fGRlZmF1bHROb3JtYWxFdmVudFRlbXBsYXRlXCJcbiAgICAgICAgICAgICAgICBbZGF5dmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXT1cImRheXZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZXx8ZGVmYXVsdERheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2RheXZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJkYXl2aWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGV8fGRlZmF1bHROb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2RheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXT1cImRheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlfHxkZWZhdWx0SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2RheXZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXT1cImRheXZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlfHxkZWZhdWx0SW5hY3RpdmVOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZVwiXG4gICAgICAgICAgICAgICAgW2xvY2FsZV09XCJsb2NhbGVcIlxuICAgICAgICAgICAgICAgIFtkYXRlRm9ybWF0dGVyXT1cImRhdGVGb3JtYXR0ZXJcIlxuICAgICAgICAgICAgICAgIFtkaXJdPVwiZGlyXCJcbiAgICAgICAgICAgICAgICBbc2Nyb2xsVG9Ib3VyXT1cInNjcm9sbFRvSG91clwiXG4gICAgICAgICAgICAgICAgW3ByZXNlcnZlU2Nyb2xsUG9zaXRpb25dPVwicHJlc2VydmVTY3JvbGxQb3NpdGlvblwiXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZVRvUHJldl09XCJsb2NrU3dpcGVUb1ByZXZcIlxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVzXT1cImxvY2tTd2lwZXNcIlxuICAgICAgICAgICAgICAgIFtzdGFydEhvdXJdPVwic3RhcnRIb3VyXCJcbiAgICAgICAgICAgICAgICBbZW5kSG91cl09XCJlbmRIb3VyXCJcbiAgICAgICAgICAgICAgICBbc2xpZGVyT3B0aW9uc109XCJzbGlkZXJPcHRpb25zXCJcbiAgICAgICAgICAgICAgICAob25SYW5nZUNoYW5nZWQpPVwicmFuZ2VDaGFuZ2VkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvbkV2ZW50U2VsZWN0ZWQpPVwiZXZlbnRTZWxlY3RlZCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgICAob25UaW1lU2VsZWN0ZWQpPVwidGltZVNlbGVjdGVkKCRldmVudClcIlxuICAgICAgICAgICAgICAgIChvblRpdGxlQ2hhbmdlZCk9XCJ0aXRsZUNoYW5nZWQoJGV2ZW50KVwiPlxuICAgICAgICAgICAgPC9kYXl2aWV3PlxuICAgICAgICA8L2Rpdj5cbiAgICBgLFxuICAgIHN0eWxlczogW2BcbiAgICAgICAgOmhvc3QgPiBkaXYgeyBoZWlnaHQ6IDEwMCU7IH1cblxuICAgICAgICAuZXZlbnQtZGV0YWlsLWNvbnRhaW5lciB7XG4gICAgICAgICAgYm9yZGVyLXRvcDogMnB4IGRhcmtncmV5IHNvbGlkO1xuICAgICAgICB9XG5cbiAgICAgICAgLm5vLWV2ZW50cy1sYWJlbCB7XG4gICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgY29sb3I6IGRhcmtncmV5O1xuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgfVxuXG4gICAgICAgIC5ldmVudC1kZXRhaWwge1xuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICAgICAgICB9XG5cbiAgICAgICAgLm1vbnRodmlldy1ldmVudGRldGFpbC10aW1lY29sdW1uIHtcbiAgICAgICAgICB3aWR0aDogMTEwcHg7XG4gICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jYWxlbmRhci1ldmVudC1pbm5lciB7XG4gICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2E4N2FkO1xuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgcGFkZGluZzogMnB4O1xuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxNXB4O1xuICAgICAgICAgIHRleHQtYWxpZ246IGluaXRpYWw7XG4gICAgICAgIH1cblxuICAgICAgICBAbWVkaWEgKG1heC13aWR0aDogNzUwcHgpIHtcbiAgICAgICAgICAuY2FsZW5kYXItZXZlbnQtaW5uZXIge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIGBdLFxuICAgIHByb3ZpZGVyczogW0NhbGVuZGFyU2VydmljZV1cbn0pXG5leHBvcnQgY2xhc3MgQ2FsZW5kYXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICAgIEBJbnB1dCgpXG4gICAgZ2V0IGN1cnJlbnREYXRlKCk6RGF0ZSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50RGF0ZTtcbiAgICB9XG5cbiAgICBzZXQgY3VycmVudERhdGUodmFsOkRhdGUpIHtcbiAgICAgICAgaWYgKCF2YWwpIHtcbiAgICAgICAgICAgIHZhbCA9IG5ldyBEYXRlKCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLl9jdXJyZW50RGF0ZSA9IHZhbDtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2Uuc2V0Q3VycmVudERhdGUodmFsLCB0cnVlKTtcbiAgICAgICAgdGhpcy5vbkN1cnJlbnREYXRlQ2hhbmdlZC5lbWl0KHRoaXMuX2N1cnJlbnREYXRlKTtcbiAgICB9XG5cbiAgICBASW5wdXQoKSBldmVudFNvdXJjZTpJRXZlbnRbXSA9IFtdO1xuICAgIEBJbnB1dCgpIGNhbGVuZGFyTW9kZTpDYWxlbmRhck1vZGUgPSAnbW9udGgnO1xuICAgIEBJbnB1dCgpIGZvcm1hdERheTpzdHJpbmcgPSAnZCc7XG4gICAgQElucHV0KCkgZm9ybWF0RGF5SGVhZGVyOnN0cmluZyA9ICdFRUUnO1xuICAgIEBJbnB1dCgpIGZvcm1hdERheVRpdGxlOnN0cmluZyA9ICdNTU1NIGRkLCB5eXl5JztcbiAgICBASW5wdXQoKSBmb3JtYXRXZWVrVGl0bGU6c3RyaW5nID0gJ01NTU0geXl5eSwgXFwnV2Vla1xcJyB3JztcbiAgICBASW5wdXQoKSBmb3JtYXRNb250aFRpdGxlOnN0cmluZyA9ICdNTU1NIHl5eXknO1xuICAgIEBJbnB1dCgpIGZvcm1hdFdlZWtWaWV3RGF5SGVhZGVyOnN0cmluZyA9ICdFRUUgZCc7XG4gICAgQElucHV0KCkgZm9ybWF0SG91ckNvbHVtbjpzdHJpbmcgPSAnaGEnO1xuICAgIEBJbnB1dCgpIHNob3dFdmVudERldGFpbDpib29sZWFuID0gdHJ1ZTtcbiAgICBASW5wdXQoKSBzdGFydGluZ0RheU1vbnRoOm51bWJlciA9IDA7XG4gICAgQElucHV0KCkgc3RhcnRpbmdEYXlXZWVrOm51bWJlciA9IDA7XG4gICAgQElucHV0KCkgYWxsRGF5TGFiZWw6c3RyaW5nID0gJ2FsbCBkYXknO1xuICAgIEBJbnB1dCgpIG5vRXZlbnRzTGFiZWw6c3RyaW5nID0gJ05vIEV2ZW50cyc7XG4gICAgQElucHV0KCkgcXVlcnlNb2RlOlF1ZXJ5TW9kZSA9ICdsb2NhbCc7XG4gICAgQElucHV0KCkgc3RlcDpTdGVwID0gU3RlcC5Ib3VyO1xuICAgIEBJbnB1dCgpIHRpbWVJbnRlcnZhbDpudW1iZXIgPSA2MDtcbiAgICBASW5wdXQoKSBhdXRvU2VsZWN0OmJvb2xlYW4gPSB0cnVlO1xuICAgIEBJbnB1dCgpIG1hcmtEaXNhYmxlZDooZGF0ZTpEYXRlKSA9PiBib29sZWFuO1xuICAgIEBJbnB1dCgpIG1vbnRodmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlOlRlbXBsYXRlUmVmPElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIG1vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGU6VGVtcGxhdGVSZWY8SU1vbnRoVmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgbW9udGh2aWV3RXZlbnREZXRhaWxUZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJTW9udGhWaWV3RXZlbnREZXRhaWxUZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIHdlZWt2aWV3SGVhZGVyVGVtcGxhdGU6VGVtcGxhdGVSZWY8SURpc3BsYXlXZWVrVmlld0hlYWRlcj47XG4gICAgQElucHV0KCkgd2Vla3ZpZXdBbGxEYXlFdmVudFRlbXBsYXRlOlRlbXBsYXRlUmVmPElEaXNwbGF5QWxsRGF5RXZlbnQ+O1xuICAgIEBJbnB1dCgpIHdlZWt2aWV3Tm9ybWFsRXZlbnRUZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGlzcGxheUV2ZW50PjtcbiAgICBASW5wdXQoKSBkYXl2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGlzcGxheUFsbERheUV2ZW50PjtcbiAgICBASW5wdXQoKSBkYXl2aWV3Tm9ybWFsRXZlbnRUZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGlzcGxheUV2ZW50PjtcbiAgICBASW5wdXQoKSB3ZWVrdmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlOlRlbXBsYXRlUmVmPElXZWVrVmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgd2Vla3ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJV2Vla1ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIGRheXZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGF5Vmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgZGF5dmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlOlRlbXBsYXRlUmVmPElEYXlWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSB3ZWVrdmlld0luYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU6VGVtcGxhdGVSZWY8SVdlZWtWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSB3ZWVrdmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGU6VGVtcGxhdGVSZWY8SVdlZWtWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcbiAgICBASW5wdXQoKSBkYXl2aWV3SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZTpUZW1wbGF0ZVJlZjxJRGF5Vmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XG4gICAgQElucHV0KCkgZGF5dmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGU6VGVtcGxhdGVSZWY8SURheVZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQ+O1xuICAgIEBJbnB1dCgpIGRhdGVGb3JtYXR0ZXI6SURhdGVGb3JtYXR0ZXI7XG4gICAgQElucHV0KCkgZGlyOnN0cmluZyA9IFwiXCI7XG4gICAgQElucHV0KCkgc2Nyb2xsVG9Ib3VyOm51bWJlciA9IDA7XG4gICAgQElucHV0KCkgcHJlc2VydmVTY3JvbGxQb3NpdGlvbjpib29sZWFuID0gZmFsc2U7XG4gICAgQElucHV0KCkgbG9ja1N3aXBlVG9QcmV2OmJvb2xlYW4gPSBmYWxzZTtcbiAgICBASW5wdXQoKSBsb2NrU3dpcGVzOmJvb2xlYW4gPSBmYWxzZTtcbiAgICBASW5wdXQoKSBsb2NhbGU6c3RyaW5nID0gXCJcIjtcbiAgICBASW5wdXQoKSBzdGFydEhvdXI6bnVtYmVyID0gMDtcbiAgICBASW5wdXQoKSBlbmRIb3VyOm51bWJlciA9IDI0O1xuICAgIEBJbnB1dCgpIHNsaWRlck9wdGlvbnM6YW55O1xuXG4gICAgQE91dHB1dCgpIG9uQ3VycmVudERhdGVDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxEYXRlPigpO1xuICAgIEBPdXRwdXQoKSBvblJhbmdlQ2hhbmdlZCA9IG5ldyBFdmVudEVtaXR0ZXI8SVJhbmdlPigpO1xuICAgIEBPdXRwdXQoKSBvbkV2ZW50U2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElFdmVudD4oKTtcbiAgICBAT3V0cHV0KCkgb25UaW1lU2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElUaW1lU2VsZWN0ZWQ+KCk7XG4gICAgQE91dHB1dCgpIG9uRGF5SGVhZGVyU2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElUaW1lU2VsZWN0ZWQ+KCk7XG4gICAgQE91dHB1dCgpIG9uVGl0bGVDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KCk7XG5cbiAgICBwcml2YXRlIF9jdXJyZW50RGF0ZTpEYXRlO1xuICAgIHB1YmxpYyBob3VyUGFydHMgPSAxO1xuICAgIHB1YmxpYyBob3VyU2VnbWVudHMgPSAxO1xuICAgIHByaXZhdGUgY3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuU3Vic2NyaXB0aW9uOlN1YnNjcmlwdGlvbjtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgY2FsZW5kYXJTZXJ2aWNlOkNhbGVuZGFyU2VydmljZSwgQEluamVjdChMT0NBTEVfSUQpIHByaXZhdGUgYXBwTG9jYWxlOnN0cmluZykge1xuICAgICAgICB0aGlzLmxvY2FsZSA9IGFwcExvY2FsZTtcbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgaWYgKHRoaXMuYXV0b1NlbGVjdCkge1xuICAgICAgICAgICAgaWYgKHRoaXMuYXV0b1NlbGVjdC50b1N0cmluZygpID09PSAnZmFsc2UnKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5hdXRvU2VsZWN0ID0gZmFsc2U7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuYXV0b1NlbGVjdCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5ob3VyU2VnbWVudHMgPSA2MCAvIHRoaXMudGltZUludGVydmFsO1xuICAgICAgICB0aGlzLmhvdXJQYXJ0cyA9IDYwIC8gdGhpcy5zdGVwO1xuICAgICAgICBpZih0aGlzLmhvdXJQYXJ0cyA8PSB0aGlzLmhvdXJTZWdtZW50cykge1xuICAgICAgICAgICAgdGhpcy5ob3VyUGFydHMgPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ob3VyUGFydHMgPSB0aGlzLmhvdXJQYXJ0cyAvIHRoaXMuaG91clNlZ21lbnRzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3RhcnRIb3VyID0gcGFyc2VJbnQodGhpcy5zdGFydEhvdXIudG9TdHJpbmcoKSk7XG4gICAgICAgIHRoaXMuZW5kSG91ciA9IHBhcnNlSW50KHRoaXMuZW5kSG91ci50b1N0cmluZygpKTtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2UucXVlcnlNb2RlID0gdGhpcy5xdWVyeU1vZGU7XG5cbiAgICAgICAgdGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW5TdWJzY3JpcHRpb24gPSB0aGlzLmNhbGVuZGFyU2VydmljZS5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW4kLnN1YnNjcmliZShjdXJyZW50RGF0ZSA9PiB7XG4gICAgICAgICAgICB0aGlzLl9jdXJyZW50RGF0ZSA9IGN1cnJlbnREYXRlO1xuICAgICAgICAgICAgdGhpcy5vbkN1cnJlbnREYXRlQ2hhbmdlZC5lbWl0KGN1cnJlbnREYXRlKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlblN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW5TdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuU3Vic2NyaXB0aW9uID0gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJhbmdlQ2hhbmdlZChyYW5nZTpJUmFuZ2UpIHtcbiAgICAgICAgdGhpcy5vblJhbmdlQ2hhbmdlZC5lbWl0KHJhbmdlKTtcbiAgICB9XG5cbiAgICBldmVudFNlbGVjdGVkKGV2ZW50OklFdmVudCkge1xuICAgICAgICB0aGlzLm9uRXZlbnRTZWxlY3RlZC5lbWl0KGV2ZW50KTtcbiAgICB9XG5cbiAgICB0aW1lU2VsZWN0ZWQodGltZVNlbGVjdGVkOklUaW1lU2VsZWN0ZWQpIHtcbiAgICAgICAgdGhpcy5vblRpbWVTZWxlY3RlZC5lbWl0KHRpbWVTZWxlY3RlZCk7XG4gICAgfVxuXG4gICAgZGF5U2VsZWN0ZWQoZGF5U2VsZWN0ZWQ6SVRpbWVTZWxlY3RlZCkge1xuICAgICAgICB0aGlzLm9uRGF5SGVhZGVyU2VsZWN0ZWQuZW1pdChkYXlTZWxlY3RlZCk7XG4gICAgfVxuXG4gICAgdGl0bGVDaGFuZ2VkKHRpdGxlOnN0cmluZykge1xuICAgICAgICB0aGlzLm9uVGl0bGVDaGFuZ2VkLmVtaXQodGl0bGUpO1xuICAgIH1cblxuICAgIGxvYWRFdmVudHMoKSB7XG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmxvYWRFdmVudHMoKTtcbiAgICB9XG5cbiAgICBzbGlkZU5leHQoKSB7XG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNsaWRlKDEpO1xuICAgIH1cblxuICAgIHNsaWRlUHJldigpIHtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2Uuc2xpZGUoLTEpO1xuICAgIH1cblxuICAgIHVwZGF0ZSgpIHtcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2UudXBkYXRlKCk7XG4gICAgfVxufVxuIl19