export declare class NgCalendarModule {
}
