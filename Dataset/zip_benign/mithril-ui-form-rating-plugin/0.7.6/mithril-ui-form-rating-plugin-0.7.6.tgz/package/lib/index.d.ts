import { PluginType } from 'mithril-ui-form-plugin';
export type RatingOptions = {
    /** Minimum value of the rating */
    min: number;
    /** Maximum value of the rating */
    max: number;
    /** Rating labels, for each specified key (typically, min, max and median value), a label will be shown */
    ratings: {
        [key: string | number]: string;
    };
};
/** Rating plugin, a list of numeric radio buttons between min and max. */
export declare const ratingPlugin: PluginType<number, RatingOptions>;
