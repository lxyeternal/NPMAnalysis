'use strict';

var Preview = require('../dist/preview/Preview');



module.exports = Preview;
