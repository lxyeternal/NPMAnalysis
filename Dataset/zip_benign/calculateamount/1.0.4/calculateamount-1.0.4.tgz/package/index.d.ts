type strOrnum = string | number

declare const calculateamount: {
    add: (arg1: strOrnum, arg2: strOrnum, decimal?: number) => number,
    sub: (arg1: strOrnum, arg2: strOrnum, decimal?: number) => number,
    mul: (arg1: strOrnum, arg2: strOrnum, decimal?: number) => number,
    div: (arg1: strOrnum, arg2: strOrnum, decimal?: number) => number,
}


export default calculateamount
