

calculateamount用于计算金额,有加减乘除4个方法

  add: (*arg1*: *strOrnum*, *arg2*: *strOrnum*, *decimal*?: *number*) => *number*,

  sub: (*arg1*: *strOrnum*, *arg2*: *strOrnum*, *decimal*?: *number*) => *number*,

  mul: (*arg1*: *strOrnum*, *arg2*: *strOrnum*, *decimal*?: *number*) => *number*,

  div: (*arg1*: *strOrnum*, *arg2*: *strOrnum*, *decimal*?: *number*) => *number*,



example------------------------------------------------------------------------------------------------------

calculateamount.add(0.1,0.2)   // 0.3

calculateamount.mul(1, 0.1234,2)  // 0.12