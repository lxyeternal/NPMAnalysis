# ProgressTracker
Multi-level progress tracking

## Example

### Simple
```js
const tracker = new ProgressTracker(
    (progress) => { console.log(progress); },
    (complete) => { console.log('complete'); }
);

setTimeout(() => {
  tracker.progress = 0.5;
}, 1000);

setTimeout(() => {
  tracker.progress = 1;
}, 2000);
```

### Multi-level with weighting
```js
const parentTracker = new ProgressTracker(
  (progress) => { console.log('parentTracker:' + progress); },
  () => { console.log('parentTracker: complete'); });

const childTracker1 = new ProgressTracker(
  (progress) => { console.log('childTracker1:' + progress) },
  () => { console.log('childTracker1: complete'); });

const childTracker2 = new ProgressTracker();

childTracker1.parent = parentTracker;
childTracker1.weight = 9; // childTracker 1 will consume 90% of the total load progress
childTracker2.parent = parentTracker;

setTimeout(() => {
  childTracker1.progress = 0.5;
}, 1000);

setTimeout(() => {
  childTracker1.progress = 1;
}, 2000);

setTimeout(() => {
  childTracker2.progress = 0.5;
}, 3000);

setTimeout(() => {
  childTracker2.progress = 1;
}, 4000);
```