class ProgressTracker {
  /**
   * Constructor
   *
   * @param {function} onChange
   * @param {function} onComplete
   */
  constructor(onChange = undefined, onComplete = undefined) {
    this._parent;
    this._children = [];
    this._progress = 0;
    this.onChange = onChange;
    this.onComplete = onComplete;
    this._weight = 1;

    if (onChange && typeof onChange !== 'function') {
      throw new Error('onChange must be a function or undefined.');
    }

    if (onComplete && typeof onComplete !== 'function') {
      throw new Error('onComplete must be a function or undefined.');
    }
  }

  /**
   * Get parent
   *
   * @returns {ProgressTracker|undefined}
   */
  get parent() {
    return this._parent;
  }

  /**
   * Set parent
   *
   * @param {ProgressTracker|undefined} parent
   * @throws {Error}
   */
  set parent(parent) {
    if (parent instanceof ProgressTracker) {
      this._parent = parent;
      parent._addChild(this);
    } else if (parent === undefined) {
      this._parent = undefined;
      parent._removeChild(this);
    } else {
      throw new Error('Parent must be a instance of ProgressTracker or undefined.');
    }
  }

  /**
   * Get progress
   *
   * @returns {number}
   */
  get progress() {
    return this._progress;
  }

  /**
   * Set progress
   *
   * @param {Number} progress
   * @throws {Error}
   */
  set progress(progress) {
    if (isNaN(progress)) {
      throw new Error('Progress must be a number.');
    }

    if (progress < 0 || progress > 1) {
      throw new Error('Progress must be a number between 0 and 1.');
    }

    if (this._children.length > 0) {
      throw new Error('Progress cannot be set on instances of ProgressTracker with children.');
    }

    this._progress = progress;

    this.update();
  }

  /**
   * Get weight
   *
   * @returns {number}
   */
  get weight() {
    return this._weight;
  }

  /**
   * Set weight
   *
   * @param {number}
   * @returns {number}
   * @throws Error
   */
  set weight(weight) {
    if (!Number.isInteger(weight)) {
      throw new Error('Weight must be an integer.');
    }

    if (weight < 1 || weight > 99) {
      throw new Error('Weight must be between 1 and 99.');
    }

    this._weight = weight;
  }

  /**
   * Add child
   *
   * @param {ProgressTracker} child
   */
  _addChild(child) {
    if (this._children.indexOf(child) === -1) {
      this._children.push(child);
    }
  }

  /**
   * Remove child
   * @param {ProgressTracker} child
   */
  _removeChild(child) {
    const index = this._children.indexOf(child);

    if (index !== -1) {
      this._children.splice(index, 1);
    }
  }

  /**
   * Update
   *
   * Can be manually called to force an update to the progress
   */
  update() {
    if (this._children.length) {
      let progress = 0;
      let totalWeight = this._children.reduce((i, child) => {
        return i + child.weight;
      }, 0);

      this._children.forEach((child) => {
        progress += (child.progress * child.weight);
      });

      this._progress = progress / totalWeight;
    }

    if (this.progress < 1 && this.onChange) {
      this.onChange(this.progress);
    } else if (this.progress >= 1 && this.onComplete) {
      this.onComplete();
    }

    if (this.parent) {
      this.parent.update();
    }
  }
}

export default ProgressTracker;