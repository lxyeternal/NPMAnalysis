import React, { CSSProperties } from 'react';
import { Graph as G6Graph, GraphOptions } from '@antv/g6';
/**
 * The props of the `Graph` component.
 */
export type GraphProps = {
    /**
     * The class name of the container element.
     */
    className?: string;
    /**
     * The options of the G6 graph. Copy from the website of G6.
     */
    options: Omit<GraphOptions, 'container'> | null;
    /**
     * The style of the container element.
     */
    style?: CSSProperties;
    /**
     * Callback that is called when the graph is ready.
     */
    onReady?: (graph: G6Graph) => void;
};
/**
 * A React component that wraps the G6 graph.
 */
export declare const Graph: React.ForwardRefExoticComponent<GraphProps & React.RefAttributes<G6Graph | undefined>>;
