"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
exports.validate = exports.MetalogValidationStatus = exports.variance = exports.mean = exports.upperBoundConstraintMatrix = exports.equalityConstraintMatrix = exports.fitMetalogLP = exports.fitMetalog = exports.pdf = exports.cdf = exports.quantileDoubleDiff = exports.quantileDiff = exports.quantile = exports.metalogBasisDiff = exports.metalogBasisFunction = void 0;
var mathjs_1 = require("mathjs");
var javascript_lp_solver_1 = __importDefault(require("@bygdle/javascript-lp-solver"));
var sum = function (x) { return x.reduce(function (a, b) { return a + b; }); };
function metalogBasisFunction(j, y) {
    var logy = Math.log(y / (1 - y));
    var yMinusHalf = y - 0.5;
    if (j === 0) {
        return 1;
    }
    else if (j === 1) {
        return logy;
    }
    else if (j === 2) {
        return yMinusHalf * logy;
    }
    else if (j === 3) {
        return yMinusHalf;
    }
    else if (j % 2 === 0) {
        return Math.pow(yMinusHalf, (j / 2));
    }
    else {
        return Math.pow(yMinusHalf, ((j - 1) / 2)) * logy;
    }
}
exports.metalogBasisFunction = metalogBasisFunction;
function metalogBasisDiff(i, y) {
    var logy = Math.log(y / (1 - y));
    var logyDeriv = 1 / (y * (1 - y));
    if (i === 0) {
        return 0;
    }
    else if (i === 1) {
        return logyDeriv;
    }
    else if (i === 2) {
        return (y - 0.5) * logyDeriv + logy;
    }
    else if (i === 3) {
        return 1;
    }
    else if (i % 2 === 0) {
        return (i / 2) * Math.pow((y - 0.5), (i / 2 - 1));
    }
    else {
        return (Math.pow((y - 0.5), ((i - 1) / 2)) * logyDeriv +
            ((i - 1) / 2) * Math.pow((y - 0.5), ((i - 3) / 2)) * logy);
    }
}
exports.metalogBasisDiff = metalogBasisDiff;
function quantile(a, q) {
    return sum(a.map(function (a_i, i) { return a_i * metalogBasisFunction(i, q); }));
}
exports.quantile = quantile;
function quantileDiff(a, y) {
    return sum(a.map(function (a_i, i) { return a_i * metalogBasisDiff(i, y); }));
}
exports.quantileDiff = quantileDiff;
// This is the derivitive of the above function, calculated by hand
// the rest by hand.
function quantileDoubleDiff(a, y) {
    var logy = Math.log(y / (1 - y));
    var logyDeriv = 1 / (y * (1 - y));
    var logyDeriv2 = (2 * y - 1) / (y * y * (y - 1) * (y - 1));
    return sum(a.map(function (a_i, i) {
        if (i === 0) {
            return 0;
        }
        else if (i === 1) {
            return a_i * logyDeriv2;
        }
        else if (i === 2) {
            return a_i * ((y - 0.5) * logyDeriv2 + 2 * logyDeriv);
        }
        else if (i === 3) {
            return 0;
        }
        else if (i % 2 === 0) {
            return (a_i * i * (i - 2) * Math.pow((y - 0.5), (i / 2 - 2))) / 4;
        }
        else {
            return (a_i *
                (Math.pow((y - 0.5), ((i - 1) / 2)) * logyDeriv2 +
                    (i - 1) * Math.pow((y - 0.5), ((i - 3) / 2)) * logyDeriv) +
                ((i - 1) * (i - 3) * Math.pow((y - 0.5), ((i - 5) / 2)) * logy) / 4);
        }
    }));
}
exports.quantileDoubleDiff = quantileDoubleDiff;
// This is a combination of Halley's method and binary search.
// It's basically a binary search, except we choose the "midpoint"
// through newton's method.
// In this case we are using the assumption that the quantile function
// is monotonic (which it is)
// Supports an error parameter (default is correct to 12 decimal places)
// If it can't meet the precision (due to floating point precision problems)
// it will return the best it can
function cdf(a, x, err) {
    if (err === void 0) { err = 0; }
    var alpha_step = 1;
    var y_now = 0.5;
    var i = 1;
    var max = 1;
    var min = 0;
    var temp_err = 0.5;
    while (err < temp_err) {
        var first_function = quantile(a, y_now) - x;
        if (first_function > 0) {
            max = y_now;
        }
        else if (first_function < 0) {
            min = y_now;
        }
        else {
            return y_now;
        }
        var derv_function = quantileDiff(a, y_now);
        var y_next = y_now - alpha_step * (first_function / derv_function);
        if (y_next >= max || y_next <= min) {
            y_next = (min + max) / 2;
            // Our most common break condition is when the finder can't find the difference between the highest
            // and smallest
            if (y_next === min || y_next === max) {
                if (Math.abs(quantile(a, max) - x) < Math.abs(quantile(a, min) - x)) {
                    return max;
                }
                else {
                    return min;
                }
            }
        }
        temp_err = Math.abs(y_next - y_now);
        y_now = y_next;
        i++;
        if (i > 100) {
            return y_now;
        }
    }
    // Iterate through possible floats until we get an answer that's as close as possible
    /*
    let diff = quantile(a, y_now) - x;
    while(diff > 0){
      const y_next = nextDown(y_now)
      diff = quantile(a, y_next) - x;
      if(diff > 0){
        y_now = y_next;
      }
    }
    while(diff < 0){
      const y_next = nextUp(y_now)
      diff = quantile(a, y_next) - x;
      if(diff < 0){
        y_now = y_next;
      }
    }*/
    return y_now;
}
exports.cdf = cdf;
function pdf(a, x) {
    return Math.max(1 / quantileDiff(a, cdf(a, x)), 0);
}
exports.pdf = pdf;
function fitMetalog(points, terms, validationPoints) {
    var Y = (0, mathjs_1.matrix)(points.map(function (_a) {
        var y = _a.y;
        return Array.from(Array(terms).keys()).map(function (i) { return metalogBasisFunction(i, y); });
    }));
    var X = (0, mathjs_1.matrix)(points.map(function (_a) {
        var x = _a.x;
        return [x];
    }));
    var multTran = (0, mathjs_1.multiply)((0, mathjs_1.transpose)(Y), Y);
    var invTran = (0, mathjs_1.inv)(multTran);
    var invMultTran = (0, mathjs_1.multiply)(invTran, (0, mathjs_1.transpose)(Y));
    var a = (0, mathjs_1.multiply)(invMultTran, X)
        .toArray()
        .map(function (x) {
        if (!(0, mathjs_1.isArray)(x)) {
            if ((0, mathjs_1.isComplex)(x)) {
                return 0;
            }
            else {
                return (0, mathjs_1.number)(x);
            }
        }
        else {
            var y = x[0];
            if ((0, mathjs_1.isComplex)(y)) {
                return 0;
            }
            else {
                return (0, mathjs_1.number)(y);
            }
        }
    });
    // Sometimes, for more extreme cases, metalog can't fit the points to the CDF. Other packages such as rmetalog
    // Or pymetalog try to get a "best guess" through Linear Programming. I decide not to go down that route and hand
    // the error back to the user
    if (validate(a, validationPoints) === MetalogValidationStatus.Success) {
        return a;
    }
    else {
        return undefined;
    }
}
exports.fitMetalog = fitMetalog;
// Sometimes, the above function will fail to find a solution. In this case,
// metalog cannot fit the distribution that you have given. This function
// attempts to find a close-as-we-can fit. Note that depending on the distribution
// being as "close as we can" can still be very far from what you may be aiming
// for! I use a WebAssembly port of glpk to do this
function fitMetalogLP(points, terms, diffError, validationPoints) {
    /* A matrix with the terms for all the differential points inside:
     * row count = number of points
     * column count = 2 * number of terms
     * Every second column is the same as the one before but negative.
     * Still don't know why. stop asking!
     */
    var _a, _b;
    if (diffError === void 0) { diffError = 0.01; }
    var A_eq = equalityConstraintMatrix(points, terms);
    var A_ub = upperBoundConstraintMatrix(points.length, terms, validationPoints);
    // This fascinates me, still don't get it!
    var objective = Array(2 * points.length)
        .fill(1)
        .concat(Array(2 * terms).fill(0));
    // I'm using a library called "javascript-lp-solve". It's tauted as "linear programming
    // for the rest of us". However, it's a tad annoying to work with as
    var names = objective.map(function (_, i) {
        if (i / 2 < points.length) {
            if (i % 2 === 0) {
                return "y" + i / 2;
            }
            else {
                return "y" + (i - 1) / 2 + "_neg";
            }
        }
        else {
            var j = i - points.length * 2;
            if (i % 2 === 0) {
                return "a" + j / 2;
            }
            else {
                return "a" + (j - 1) / 2 + "_neg";
            }
        }
    });
    var x = points.map(function (_a) {
        var x = _a.x;
        return x;
    });
    // This is a strange way to put a linear programming problem
    var model = {
        optimize: "c",
        opType: "min",
        constraints: Object.fromEntries(x
            .map(function (z, i) { return ["A_eq" + i, { equal: z }]; })
            .concat(A_ub.toArray().map(function (_, i) { return ["A_ub" + i, { max: -1 * diffError }]; }))),
        variables: Object.fromEntries(names.map(function (name, i) { return [
            name,
            Object.fromEntries([["c", objective[i]]]
                .concat(A_eq.toArray().map(function (row, j) { return ["A_eq" + j, row[i]]; }))
                .concat(A_ub.toArray().map(function (row, j) { return ["A_ub" + j, -1 * row[i]]; }))),
        ]; }))
    };
    var result = javascript_lp_solver_1["default"].Solve(model);
    var arr = [];
    for (var i = 0; i < terms; i++) {
        arr.push(((_a = result["a" + i]) !== null && _a !== void 0 ? _a : 0) - ((_b = result["a" + i + "_neg"]) !== null && _b !== void 0 ? _b : 0));
    }
    if (!result.feasible)
        return undefined;
    // Although I'm fairly sure the LP solver should never construct a distribution
    // that fails validation (as having a positive derivative is part of the constraint
    // matrix). Sometimes it actually does, so I'm just checking here so that
    // we don't pass an invalid distribution to the user.
    if (validate(arr, validationPoints) === MetalogValidationStatus.Success) {
        return arr;
    }
    else {
        return undefined;
    }
}
exports.fitMetalogLP = fitMetalogLP;
function equalityConstraintMatrix(points, terms) {
    // Construct error matrix
    // This looks like
    /* row count = number of points
     * column count = 2 * number of points
     * [ 1 -1 0  0 0  0 ]
     * [ 0  0 1 -1 0  0 ]
     * [ 0  0 0  0 1 -1 ]
     *
     * I have no idea what this is for, but it's part of the A_eq matrix
     */
    var err_mat = (0, mathjs_1.matrix)(points.map(function (_, j) {
        return Array.from(Array(points.length * 2)).map(function (_, i) {
            if (i / 2 === j) {
                return 1;
            }
            else if ((i - 1) / 2 === j) {
                return -1;
            }
            else {
                return 0;
            }
        });
    }));
    /* Construct Y matrix.
     * row count = number of points
     * column count = 2 * number of terms
     * Columns are positive and then negative interlaced
     *
     * I have no idea what this is for, but it's part of the A_eq matrix
     */
    var Y = (0, mathjs_1.matrix)(points.map(function (_a) {
        var y = _a.y;
        return Array.from(Array(terms * 2).keys()).map(function (i) {
            if (i % 2 === 0) {
                return metalogBasisFunction(i / 2, y);
            }
            else {
                return -1 * metalogBasisFunction((i - 1) / 2, y);
            }
        });
    }));
    var A_eq = (0, mathjs_1.concat)(err_mat, Y);
    return A_eq;
}
exports.equalityConstraintMatrix = equalityConstraintMatrix;
function upperBoundConstraintMatrix(points, terms, validationPoints) {
    // I concat some tail points to make sure that the solver doesn't put a point
    // mass at the end of the distribution
    var diffMat = metalogDiffMatrix(terms, validationPoints);
    /* A matrix of all 0s
     * row count = number of points in diff matrix
     * columns count = 2 * number of points
     *
     * Why? again. No idea. Part of A_ub
     */
    var zeroes = (0, mathjs_1.matrix)(Array.from(Array(diffMat.size()[0])).map(function () {
        return Array.from(Array(points * 2).keys()).map(function () { return 0; });
    }));
    var A_ub = (0, mathjs_1.concat)(zeroes, diffMat);
    return A_ub;
}
exports.upperBoundConstraintMatrix = upperBoundConstraintMatrix;
// Generates some reasonable validation points. These exist to try and ensure
// that a metalog is "feasible". If we chose bad points, then LP may generate
// paramaters that it thinks are valid but aren't in points that aren't included.
function defaultValidationPoints() {
    // I'm going to list max and min points that I hope no one is going to care about beyond
    var min = 0.00000000001;
    var max = 1 - min;
    // I'm then going to sample this by the logit function. This ensures we get
    // a decent number of points around the tails, which sometimes are the worst
    // candidates for going bad.
    var minLogit = logit(min);
    var maxLogit = logit(max);
    // A default number of validation points. I chose 1000 because that's what rMetalog uses
    var steps = 1000;
    var step_size = (maxLogit - minLogit) / steps;
    return Array.from(Array(steps).keys()).map(function (i) {
        return invlogit(minLogit + i * step_size);
    });
}
function logit(x) {
    return Math.log(x / (1 - x));
}
function invlogit(x) {
    return 1 / (1 + Math.exp(-1 * x));
}
// Returns all the terms for the derivitive of metalog for different values
// of y, without coefficients
function metalogDiffMatrix(terms, validationPoints) {
    var ys;
    if (!validationPoints) {
        ys = defaultValidationPoints();
    }
    else {
        ys = validationPoints;
    }
    return (0, mathjs_1.matrix)(ys.map(function (y) {
        return Array.from(Array(terms * 2).keys()).map(function (i) {
            if (i % 2 === 0) {
                return metalogBasisDiff(i / 2, y);
            }
            else if (i % 2 === 1) {
                return -1 * metalogBasisDiff((i - 1) / 2, y);
            }
        });
    }));
}
function mean(a) {
    return a[0] - a[2] / 2;
}
exports.mean = mean;
function variance(a) {
    return ((Math.PI * Math.PI * a[1] * a[1]) / 3 +
        (a[2] * a[2]) / 12 +
        (Math.PI * Math.PI * a[2] * a[2]) / 36);
}
exports.variance = variance;
var MetalogValidationStatus;
(function (MetalogValidationStatus) {
    MetalogValidationStatus[MetalogValidationStatus["Success"] = 0] = "Success";
    MetalogValidationStatus[MetalogValidationStatus["NotEnoughParamaters"] = 1] = "NotEnoughParamaters";
    MetalogValidationStatus[MetalogValidationStatus["NegativeDerivative"] = 2] = "NegativeDerivative";
})(MetalogValidationStatus = exports.MetalogValidationStatus || (exports.MetalogValidationStatus = {}));
// Not all combinations of a are valid, but perhaps even more annoyingly, the decision procedure
// to determine whether any combination of a is valid or not is not trivial. We basically need to make
// sure that the derivitave of the quantile function is always positive for all values of y given a set
// of a. I've basically litered this with shortcut functions to speed up some cases, but if it fails
// to work out whether it is valid from that, then it just has to go through all the value of y for the derivitave
// and check whether it's positive or not.
function validate(a, points) {
    if (points === void 0) { points = defaultValidationPoints(); }
    // must have at least 2 items in metalog array
    if (a.length < 2) {
        return MetalogValidationStatus.NotEnoughParamaters;
    }
    else {
        for (var i = 0; i < points.length; i++) {
            var point = points[i];
            if (quantileDiff(a, point) < 0) {
                return MetalogValidationStatus.NegativeDerivative;
            }
        }
        return MetalogValidationStatus.Success;
    }
}
exports.validate = validate;
