export declare function metalogBasisFunction(j: number, y: number): number;
export declare function metalogBasisDiff(i: number, y: number): number;
export declare function quantile(a: number[], q: number): number;
export declare function quantileDiff(a: number[], y: number): number;
export declare function quantileDoubleDiff(a: number[], y: number): number;
export declare function cdf(a: number[], x: number, err?: number): number;
export declare function pdf(a: number[], x: number): number;
export declare function fitMetalog(points: {
    x: number;
    y: number;
}[], terms: number, validationPoints?: number[]): number[] | undefined;
export declare function fitMetalogLP(points: {
    x: number;
    y: number;
}[], terms: number, diffError?: number, validationPoints?: number[]): number[] | undefined;
export declare function equalityConstraintMatrix(points: {
    x: number;
    y: number;
}[], terms: number): any;
export declare function upperBoundConstraintMatrix(points: number, terms: number, validationPoints?: number[]): any;
export declare function mean(a: number[]): number;
export declare function variance(a: number[]): number;
export declare enum MetalogValidationStatus {
    Success = 0,
    NotEnoughParamaters = 1,
    NegativeDerivative = 2
}
export declare function validate(a: number[], points?: number[]): MetalogValidationStatus;
