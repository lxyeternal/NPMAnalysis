(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/common'), require('@angular/core'), require('parallax-js')) :
	typeof define === 'function' && define.amd ? define(['exports', '@angular/common', '@angular/core', 'parallax-js'], factory) :
	(factory((global['ngx-parallax-mousemove'] = {}),global.ng.common,global.ng.core,global['parallax-js']));
}(this, (function (exports,common,core,Parallax) { 'use strict';

Parallax = Parallax && Parallax.hasOwnProperty('default') ? Parallax['default'] : Parallax;

var LayerDirective = (function () {
    /**
     * @param {?} element
     */
    function LayerDirective(element) {
    }
    /**
     * @return {?}
     */
    LayerDirective.prototype.ngOnInit = function () {
        // depth is required in parallax.js
        if (!this.depth) {
            throw new Error('depth is required');
        }
    };
    return LayerDirective;
}());
LayerDirective.decorators = [
    { type: core.Directive, args: [{
                selector: '[parallaxLayer]'
            },] },
];
/**
 * @nocollapse
 */
LayerDirective.ctorParameters = function () { return [
    { type: core.ElementRef, },
]; };
LayerDirective.propDecorators = {
    'depth': [{ type: core.Input }, { type: core.HostBinding, args: ['attr.data-depth',] },],
};
var WrapperDirective = (function () {
    /**
     * @param {?} document
     */
    function WrapperDirective(document) {
        this.document = document;
    }
    /**
     * @return {?}
     */
    WrapperDirective.prototype.ngOnInit = function () {
        if (!this.id) {
            throw new Error('id is required');
        }
    };
    /**
     * @return {?}
     */
    WrapperDirective.prototype.ngAfterViewInit = function () {
        console.log('this.id-------------------------' + this.id);
        var /** @type {?} */ container = this.document.getElementById(this.id);
        this.parallaxInstance = new Parallax(container, this.parallaxOptions);
    };
    /**
     * @return {?}
     */
    WrapperDirective.prototype.ngOnDestroy = function () {
        this.parallaxInstance.disable();
    };
    return WrapperDirective;
}());
/*
set parallaxOptions(parallaxOptions: ParallaxProperties) {
  this._parallaxOptions = parallaxOptions;
  const keys = Object.keys(parallaxOptions);
  for (const key in keys) {
    if (keys[key]) {
      this._parallaxOptions = Object.assign(this[key] !== undefined ? {[key]: this[key]} : {});
    }
  }
 this._parallaxOptions = Object.keys(parallaxOptions).reduce((acc, key) =>
       Object.assign(acc, this[key] !== undefined ? {[key]: this[key]} : {}),
     {});
}

get parallaxOptions(): ParallaxProperties {
  return this._parallaxOptions;
}*/
WrapperDirective.decorators = [
    { type: core.Directive, args: [{
                selector: '[parallaxWrapper]'
            },] },
];
/**
 * @nocollapse
 */
WrapperDirective.ctorParameters = function () { return [
    { type: undefined, decorators: [{ type: core.Inject, args: [common.DOCUMENT,] },] },
]; };
WrapperDirective.propDecorators = {
    'id': [{ type: core.Input },],
    'parallaxOptions': [{ type: core.Input },],
};
var ParallaxMousemoveModule = (function () {
    function ParallaxMousemoveModule() {
    }
    return ParallaxMousemoveModule;
}());
ParallaxMousemoveModule.decorators = [
    { type: core.NgModule, args: [{
                imports: [
                    common.CommonModule
                ],
                declarations: [WrapperDirective, LayerDirective],
                exports: [WrapperDirective, LayerDirective]
            },] },
];
/**
 * @nocollapse
 */
ParallaxMousemoveModule.ctorParameters = function () { return []; };

exports.ParallaxMousemoveModule = ParallaxMousemoveModule;
exports.ɵb = LayerDirective;
exports.ɵa = WrapperDirective;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-parallax-mousemove.umd.js.map
