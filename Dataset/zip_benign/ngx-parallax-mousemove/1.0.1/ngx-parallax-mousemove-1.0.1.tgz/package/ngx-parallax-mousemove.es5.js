import { CommonModule, DOCUMENT } from '@angular/common';
import { Directive, ElementRef, HostBinding, Inject, Input, NgModule } from '@angular/core';
import Parallax from 'parallax-js';
var LayerDirective = (function () {
    /**
     * @param {?} element
     */
    function LayerDirective(element) {
    }
    /**
     * @return {?}
     */
    LayerDirective.prototype.ngOnInit = function () {
        // depth is required in parallax.js
        if (!this.depth) {
            throw new Error('depth is required');
        }
    };
    return LayerDirective;
}());
LayerDirective.decorators = [
    { type: Directive, args: [{
                selector: '[parallaxLayer]'
            },] },
];
/**
 * @nocollapse
 */
LayerDirective.ctorParameters = function () { return [
    { type: ElementRef, },
]; };
LayerDirective.propDecorators = {
    'depth': [{ type: Input }, { type: HostBinding, args: ['attr.data-depth',] },],
};
var WrapperDirective = (function () {
    /**
     * @param {?} document
     */
    function WrapperDirective(document) {
        this.document = document;
    }
    /**
     * @return {?}
     */
    WrapperDirective.prototype.ngOnInit = function () {
        if (!this.id) {
            throw new Error('id is required');
        }
    };
    /**
     * @return {?}
     */
    WrapperDirective.prototype.ngAfterViewInit = function () {
        console.log('this.id-------------------------' + this.id);
        var /** @type {?} */ container = this.document.getElementById(this.id);
        this.parallaxInstance = new Parallax(container, this.parallaxOptions);
    };
    /**
     * @return {?}
     */
    WrapperDirective.prototype.ngOnDestroy = function () {
        this.parallaxInstance.disable();
    };
    return WrapperDirective;
}());
/*
set parallaxOptions(parallaxOptions: ParallaxProperties) {
  this._parallaxOptions = parallaxOptions;
  const keys = Object.keys(parallaxOptions);
  for (const key in keys) {
    if (keys[key]) {
      this._parallaxOptions = Object.assign(this[key] !== undefined ? {[key]: this[key]} : {});
    }
  }
 this._parallaxOptions = Object.keys(parallaxOptions).reduce((acc, key) =>
       Object.assign(acc, this[key] !== undefined ? {[key]: this[key]} : {}),
     {});
}

get parallaxOptions(): ParallaxProperties {
  return this._parallaxOptions;
}*/
WrapperDirective.decorators = [
    { type: Directive, args: [{
                selector: '[parallaxWrapper]'
            },] },
];
/**
 * @nocollapse
 */
WrapperDirective.ctorParameters = function () { return [
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] },] },
]; };
WrapperDirective.propDecorators = {
    'id': [{ type: Input },],
    'parallaxOptions': [{ type: Input },],
};
var ParallaxMousemoveModule = (function () {
    function ParallaxMousemoveModule() {
    }
    return ParallaxMousemoveModule;
}());
ParallaxMousemoveModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                declarations: [WrapperDirective, LayerDirective],
                exports: [WrapperDirective, LayerDirective]
            },] },
];
/**
 * @nocollapse
 */
ParallaxMousemoveModule.ctorParameters = function () { return []; };
/**
 * Generated bundle index. Do not edit.
 */
export { ParallaxMousemoveModule, LayerDirective as ɵb, WrapperDirective as ɵa };
//# sourceMappingURL=ngx-parallax-mousemove.es5.js.map
