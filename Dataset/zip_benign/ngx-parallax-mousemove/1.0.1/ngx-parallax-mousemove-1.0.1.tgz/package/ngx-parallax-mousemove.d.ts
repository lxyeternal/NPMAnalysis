/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { LayerDirective as ɵb } from './src/app/parallax-mousemove/layer.directive';
export { WrapperDirective as ɵa } from './src/app/parallax-mousemove/wrapper.directive';
