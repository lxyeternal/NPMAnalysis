import { AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import { ParallaxProperties } from './model/parallaxProperties';
export declare class WrapperDirective implements OnInit, AfterViewInit, OnDestroy {
    private document;
    id: string;
    parallaxOptions: ParallaxProperties;
    private parallaxInstance;
    constructor(document: any);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
}
