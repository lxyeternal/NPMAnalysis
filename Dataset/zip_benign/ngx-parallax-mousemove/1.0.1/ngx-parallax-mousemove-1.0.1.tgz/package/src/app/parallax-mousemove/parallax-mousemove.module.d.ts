export declare class ParallaxMousemoveModule {
}
