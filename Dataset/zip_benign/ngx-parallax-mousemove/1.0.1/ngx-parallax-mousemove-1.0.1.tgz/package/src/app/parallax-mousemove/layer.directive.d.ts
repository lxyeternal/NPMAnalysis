import { ElementRef, OnInit } from '@angular/core';
export declare class LayerDirective implements OnInit {
    depth: string;
    constructor(element: ElementRef);
    ngOnInit(): void;
}
