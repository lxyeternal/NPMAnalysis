import { CommonModule, DOCUMENT } from '@angular/common';
import { Directive, ElementRef, HostBinding, Inject, Input, NgModule } from '@angular/core';
import Parallax from 'parallax-js';

class LayerDirective {
    /**
     * @param {?} element
     */
    constructor(element) {
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        // depth is required in parallax.js
        if (!this.depth) {
            throw new Error('depth is required');
        }
    }
}
LayerDirective.decorators = [
    { type: Directive, args: [{
                selector: '[parallaxLayer]'
            },] },
];
/**
 * @nocollapse
 */
LayerDirective.ctorParameters = () => [
    { type: ElementRef, },
];
LayerDirective.propDecorators = {
    'depth': [{ type: Input }, { type: HostBinding, args: ['attr.data-depth',] },],
};

class WrapperDirective {
    /**
     * @param {?} document
     */
    constructor(document) {
        this.document = document;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (!this.id) {
            throw new Error('id is required');
        }
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        console.log('this.id-------------------------' + this.id);
        const /** @type {?} */ container = this.document.getElementById(this.id);
        this.parallaxInstance = new Parallax(container, this.parallaxOptions);
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.parallaxInstance.disable();
    }
}
/*
set parallaxOptions(parallaxOptions: ParallaxProperties) {
  this._parallaxOptions = parallaxOptions;
  const keys = Object.keys(parallaxOptions);
  for (const key in keys) {
    if (keys[key]) {
      this._parallaxOptions = Object.assign(this[key] !== undefined ? {[key]: this[key]} : {});
    }
  }
 this._parallaxOptions = Object.keys(parallaxOptions).reduce((acc, key) =>
       Object.assign(acc, this[key] !== undefined ? {[key]: this[key]} : {}),
     {});
}

get parallaxOptions(): ParallaxProperties {
  return this._parallaxOptions;
}*/
WrapperDirective.decorators = [
    { type: Directive, args: [{
                selector: '[parallaxWrapper]'
            },] },
];
/**
 * @nocollapse
 */
WrapperDirective.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] },] },
];
WrapperDirective.propDecorators = {
    'id': [{ type: Input },],
    'parallaxOptions': [{ type: Input },],
};

class ParallaxMousemoveModule {
}
ParallaxMousemoveModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule
                ],
                declarations: [WrapperDirective, LayerDirective],
                exports: [WrapperDirective, LayerDirective]
            },] },
];
/**
 * @nocollapse
 */
ParallaxMousemoveModule.ctorParameters = () => [];

/**
 * Generated bundle index. Do not edit.
 */

export { ParallaxMousemoveModule, LayerDirective as ɵb, WrapperDirective as ɵa };
//# sourceMappingURL=ngx-parallax-mousemove.js.map
