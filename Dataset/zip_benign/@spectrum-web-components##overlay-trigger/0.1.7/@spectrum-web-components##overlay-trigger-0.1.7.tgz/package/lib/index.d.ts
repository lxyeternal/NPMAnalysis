export * from './overlay-trigger.js';
import { OverlayTrigger } from './overlay-trigger.js';
declare global {
    interface HTMLElementTagNameMap {
        'overlay-trigger': OverlayTrigger;
    }
}
