import { LitElement, CSSResultArray, TemplateResult } from 'lit-element';
import { TriggerInteractions, Placement } from '@spectrum-web-components/overlay-root';
/**
 * A overlay trigger component for displaying overlays relative to other content.
 * @element overlay-trigger
 *
 * @slot hover-content - The content that will be displayed on hover
 * @slot click-content - The content that will be displayed on click
 */
export declare class OverlayTrigger extends LitElement {
    static readonly styles: CSSResultArray;
    placement: Placement;
    offset: number;
    disabled: boolean;
    private clickContent?;
    private hoverContent?;
    onOverlayOpen(event: Event, interaction: TriggerInteractions): void;
    onOverlayClose(event: Event, interaction: TriggerInteractions): void;
    onTriggerClick(event: Event): void;
    onTriggerMouseOver(event: Event): void;
    onTriggerMouseLeave(event: Event): void;
    protected render(): TemplateResult;
    private onClickSlotChange;
    private onHoverSlotChange;
    private extractSlotContent;
}
