let PIXI;
let Game = function (options) {
  this.options = Object.assign({
    colNum: 6,//一列个数
    rowNum: 6,//一行个数
    speed: 6,//精灵掉落或交换时，每次移动距离
    animateTime: 5,//精灵掉落延迟时间（毫秒）
    boomNum: 5,//连续消除5个生成一个炸弹
    selectShowAll: true,//选中状态是否撑满 默认true:撑满 false:不撑满
    spriteShowAll: false,//精灵是否撑满 默认false:不撑满 true:撑满
    // gameSteps: 30,//游戏步数
    gamePlayType: "time",//游戏类型 默认按倒计时
  }, options);

  let padding = Object.assign({
    left: 0,
    top: 0,
    right: 0,
    bottom: 0
  }, this.options.gameSource.padding);
  this.padding = {
    left: padding.left * this.options.$game.fObj.scale,
    right: padding.right * this.options.$game.fObj.scale,
    top: padding.top * this.options.$game.fObj.scale,
    bottom: padding.bottom * this.options.$game.fObj.scale,
  };


  if (!!this.options.gameSteps) {
    this.options.gamePlayType = "steps";
    // 传递了游戏步数，取消倒计时
    this.options.timePos = null;
  }
  PIXI = this.options.$game.fObj.PIXI;
  this.width = this.options.$game.fObj.size.windowWidth;
  this.height = this.options.$game.fObj.size.windowHeight;
  // 单个元素宽高
  this.spriteW = (this.width - this.padding.left - this.padding.right) / this.options.colNum;
  this.spriteH = (this.height - this.padding.top - this.padding.bottom) / this.options.rowNum;

  // 1.创建pixi需要的对象 容器
  // 精灵容器
  this.spriteContainer = new PIXI.Container();
  const graphics = new PIXI.Graphics();
  graphics.beginFill(0xFFFFFF);
  graphics.drawRect(0, this.padding.top, this.width, this.height - this.padding.top);
  graphics.endFill();
  this.spriteContainer.mask = graphics;
  // this.spriteContainer.filterArea = new PIXI.Rectangle(0, 50, this.width, this.height - 50)
  // this.spriteContainer.y = 50;
  this.options.$game.fObj.application.stage.addChild(this.spriteContainer);
  // 倒计时容器
  this.timeContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.timeContainer);
  // 分数容器
  this.scoreContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.scoreContainer);
  // 分数容器2
  this.score2Container = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.score2Container);
  // 动画容器
  this.animateContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.animateContainer);
  // 绘制个矩形，解决触摸事件
  let rect1 = new PIXI.Graphics();
  rect1.beginFill(0xff0000, 0);
  rect1.drawRect(0, 0, this.width, this.height);
  rect1.endFill();
  this.spriteContainer.addChild(rect1);
  this.spriteContainer.setChildIndex(rect1, 0);

  // 2.遍历图片资源 并 去重
  let imgArr = [];
  options.gameSource = JSON.parse(JSON.stringify(options.gameSource));
  this.traverse(options.gameSource, function (k, v) {
    if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
      imgArr.push(v);
    }
  })
  if (!!options.scorePos) {
    // 分数图片
    options.scorePos = JSON.parse(JSON.stringify(options.scorePos));
    this.traverse(options.scorePos, function (k, v) {
      if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
        imgArr.push(v);
      }
    })
  }
  if (!!options.timePos) {
    // 倒计时图片
    options.timePos = JSON.parse(JSON.stringify(options.timePos));
    this.traverse(options.timePos, function (k, v) {
      if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
        imgArr.push(v);
      }
    })
  }

  // 定时更新
  this.ticker = PIXI.ticker.shared;
  // this.ticker.speed = 5;
  this.ticker.autoStart = false;
  this.ticker.addOnce(() => { });

  // 3.加载图片资源
  if (imgArr.length > 0) {
    let loader = new PIXI.loaders.Loader();
    imgArr.forEach(item => {
      loader.add(this.uniId(), item);
    })
    this.pixiLoadFun(loader);
  } else {
    this.init({});
    this.options.initDone();
  }
  this.aniFun = () => {
    this.moveXFun();
    this.moveYFun();
  }
  // 绑定事件
  this.bindEvent();

  this.ticker.add(() => {
    this.moveXFun();
    this.moveYFun();
  });
}
Game.prototype = Object.assign(Game.prototype, {
  pixiLoadFun: function (loader) {
    let time1 = new Date().getTime();
    loader.on("progress", e => {
      this.options.progressFun(e.progress);
    })
    loader.on("error", e => {
      this.options.errorFun(e);
    })
    loader.load(() => {
      // 资源加载完成
      time1 = "";
      this.init({});
      this.options.initDone();
    });
    setTimeout(() => {
      // 5秒还没加载完，重新加载一遍
      if (!!time1) {
        console.log("重新加载资源...")
        this.pixiLoadFun(loader);
      }
    }, 5000)
  },
  uniId: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  },
  random: function (options) {
    let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
    let tempNum;
    do {
      let num = Math.random() * (opt.max - opt.min) + opt.min;
      tempNum = !!opt.isFloat ? num : parseInt(num);
    } while (opt.noNum.includes(tempNum));
    return tempNum;
  },
  isArray: function (obj) {
    return obj instanceof Array;
  },
  isObject: function (obj) {
    // 判断数组对象
    if (!(obj instanceof Array) && (obj instanceof Object)) {
      return true;
    }
    return false;
  },
  traverse: function (obj, callback) {
    // 遍历json
    for (let name in obj) {
      // 如果是json对象
      if (this.isObject(obj[name])) {
        this.traverse(obj[name], callback);
      } else if (this.isArray(obj[name])) {
        // 数组对象
        obj[name].forEach(item => {
          this.traverse(item, callback);
        })
      } else {
        callback(name, obj[name]);
      }
    }
  },
  touchEndFun: function () {
    // 移动结束后，调用此方法还原
    setTimeout(() => {
      this.changeStatus = false;
      this.writeClearStatus = false;
      this.moveStartCol = -1;
      this.moveStartRow = -1;
    }, 100)
  },
  selectSpriteFun: function (startRow, startCol) {
    // 添加选中动画
    if ((!!this.options.gameSource.selectAnimate && this.options.gameSource.selectAnimate.length > 0) || true) {
      this.hideSpriteArrFun("animateSpriteArr");

      this.spriteArr.forEach(sprite => {
        let imgObj = sprite.imgObj;
        if (!!sprite.visible && imgObj.row == startRow && imgObj.col == startCol) {
          // 此处添加选中动画
          let animateObj = Object.assign({}, {
            type: "animate",
            typeName: "selectAnimate",
            autoScale: this.options.selectShowAll,
            srcArr: imgObj.selectAnimate || this.options.gameSource.selectAnimate,
            boomSpeed: imgObj.selectAnimateSpeed || this.options.gameSource.selectAnimateSpeed || 0.01,
            width: imgObj.width,
            height: imgObj.height,
            x: sprite.x - (this.spriteW - sprite.width) / 2,
            y: sprite.y - (this.spriteH - sprite.height) / 2,
            loop: true
          });
          this.renderSprite(animateObj);
          this.tickerStart();
        }
      })
    }
  },
  bindEvent: function () {
    // 绑定事件
    this.moveNum = 3;//最小移动距离，小于此距离，就算无效移动
    this.spriteContainer.interactive = true;
    this.moveStartCol = -1, this.moveStartRow = -1;
    this.startX = -1, this.startY = -1;

    this.spriteContainer.on('touchstart', (e) => {
      if (!!this.changeDoneObj) { return false; }
      // 游戏还未开始或还没有准备好
      if (!!this.iStop || this.fsm != "A") { return false; }
      // 记录状态还未还原
      if (!!this.changeStatus) { return false; }
      this.changeStatus = true;

      let x = e.data.global.x,
        y = e.data.global.y;

      let tempCol = parseInt((x - this.padding.left) / this.spriteW);
      let tempRow = parseInt((y - this.padding.top) / this.spriteH);
      if (this.moveStartRow == -1 && this.moveStartCol == -1 && (0 <= tempCol && tempCol < this.options.colNum) && (0 <= tempRow && tempRow < this.options.rowNum)) {
        this.touchStartPos = "";
        this.touchEndPos = "";
        this.startX = x;
        this.startY = y;
        this.moveStartRow = tempRow;
        this.moveStartCol = tempCol;
      }

      if (this.moveStartRow == -1 || this.moveStartCol == -1) {
        this.touchEndFun();
        return false;
      }

      this.selectSpriteFun(this.moveStartRow, this.moveStartCol);
      this.changeStatus = "只有我才能进入end";
    })
    this.spriteContainer.on('touchmove', (e) => {
    })
    this.spriteContainer.on('touchcancel', (e) => {
      this.touchedFun(e);
    })
    this.spriteContainer.on('touchendoutside', (e) => {
      this.touchedFun(e);
    })
    this.spriteContainer.on('touchend', (e) => {
      this.touchedFun(e);
    })
  },
  touchedFun: function (e) {
    if (this.changeStatus != "只有我才能进入end") { return false; }
    this.changeStatus = true;
    let x = e.data.global.x,
      y = e.data.global.y;

    let moveX = x - this.startX, moveY = y - this.startY;
    if (!(Math.abs(moveX) > this.moveNum || Math.abs(moveY) > this.moveNum)) {
      // 移动距离小于指定距离，当作点击反应
      this.touchEndFun();
      return false;
    }
    let endRow = this.moveStartRow, endCol = this.moveStartCol;
    if (Math.abs(moveX) > Math.abs(moveY)) {
      // 水平方向移动
      if (moveX > 0) {
        // 向右移动
        endCol += 1;
      } else {
        // 向左移动
        endCol -= 1;
      }
    } else {
      // 垂直方向移动
      if (moveY > 0) {
        // 向下移动
        endRow += 1;
      } else {
        // 向上移动
        endRow -= 1;
      }
    }
    endRow = Math.min(Math.max(0, endRow), this.options.rowNum - 1);
    endCol = Math.min(Math.max(0, endCol), this.options.colNum - 1);
    if (this.moveStartRow == endRow && this.moveStartCol == endCol) {
      // 没有移动 或移除区域外了
      this.touchEndFun();
      return false;
    }
    this.touchStartPos = { row: this.moveStartRow, col: this.moveStartCol };
    this.touchEndPos = { row: endRow, col: endCol };

    this.changeSpriteFun(this.moveStartRow, this.moveStartCol, endRow, endCol)
  },
  changeSpriteFun: function (startRow, startCol, endRow, endCol) {
    let self = this;
    // 交换两个精灵位置
    let startSprite, endSprite;
    self.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        if (sprite.imgObj.row == startRow && sprite.imgObj.col == startCol) {
          startSprite = sprite;
        }
        if (sprite.imgObj.row == endRow && sprite.imgObj.col == endCol) {
          endSprite = sprite;
        }
      }
    })
    if (!startSprite || !endSprite) {
      self.touchEndFun();
      return false;
    }
    // 移动x轴 默认向右和向下正方向移动
    let xDirection = 1, yDirection = 1;
    if (startSprite.x > endSprite.x) {
      xDirection = -1;
    }
    if (startSprite.y > endSprite.y) {
      yDirection = -1;
    }
    startSprite.imgObj.row = endRow;
    startSprite.imgObj.col = endCol;

    endSprite.imgObj.row = startRow;
    endSprite.imgObj.col = startCol;
    // 取出选中动画精灵，一起交换位置
    let selectSprite;
    if (!!this.selectAnimateSprite && !!this.selectAnimateSprite.visible) {
      selectSprite = this.selectAnimateSprite;
    }
    self.changefunNum = 0;
    self.checkChangefunNum = 0;

    this.changeDoneObj = { endRow, endCol, startRow, startCol };

    let sX = startSprite.x, sY = startSprite.y;
    let eX = endSprite.x, eY = endSprite.y;
    if (startCol != endCol) {
      startSprite.moveXObj = {
        speed: xDirection * self.options.speed,
        maxNum: this.padding.left + endCol * this.spriteW + (this.spriteW - startSprite.width) / 2//eX
      };
      self.changefunNum++;
      endSprite.moveXObj = {
        speed: -1 * xDirection * self.options.speed,
        maxNum: this.padding.left + startCol * this.spriteW + (this.spriteW - endSprite.width) / 2//sX
      };
      self.changefunNum++;
      if (!!selectSprite) {
        let tx = !!self.options.selectShowAll ? (self.spriteW - startSprite.width) / 2 : 0;
        selectSprite.moveXObj = {
          speed: xDirection * self.options.speed,
          maxNum: this.padding.left + endCol * this.spriteW - tx + (this.spriteW - selectSprite.width) / 2
        };
        self.changefunNum++;
      }
    }
    if (startRow != endRow) {
      startSprite.moveYObj = {
        speed: yDirection * self.options.speed,
        maxNum: this.padding.top + endRow * this.spriteH + (this.spriteH - startSprite.height) / 2//eY
      };
      self.changefunNum++;
      endSprite.moveYObj = {
        speed: -1 * yDirection * self.options.speed,
        maxNum: this.padding.top + startRow * this.spriteH + (this.spriteH - endSprite.height) / 2//sY
      };
      self.changefunNum++;
      if (!!selectSprite) {
        let ty = !!self.options.selectShowAll ? (self.spriteH - startSprite.height) / 2 : 0;
        selectSprite.moveYObj = {
          speed: yDirection * self.options.speed,
          maxNum: this.padding.top + endRow * this.spriteH - ty + (this.spriteH - selectSprite.height) / 2
        };
        self.changefunNum++;
      }
    }
  },
  changeDone: function () {
    let self = this;
    if (!this.changeDoneObj) { return false; }
    self.checkChangefunNum++;
    if (self.checkChangefunNum == self.changefunNum) {
      let { endRow, endCol, startRow, startCol } = this.changeDoneObj;
      this.changeDoneObj = null;
      // 元素交换完
      // 检测是否可消除 不能消除则交换回原位置 可以消除则交换精灵图片对象
      self.fsm = "B";
      self.draw();
      // 刚移动了元素
      if (self.fadeArr.length > 0) {
        let over = false;
        // 此处判断游戏逻辑，可减游戏步数===========
        if (self.options.gamePlayType == "steps") {
          // 是用步数判断游戏状态
          self.curSteps--;
          if (self.curSteps <= 0) {
            self.iStop = true;
            over = true;
          }
        }
        // 有消除
        self.writeClearStatus = true;
        self.over = over;
      } else {
        if (!!self.tempStatus1) {
          // 滑动没消除，还原时会执行到此处
          this.changeDoneObj = null;
          self.tempStatus1 = false;
          self.touchEndFun();
          return false;
        }
        // 没有消除，还原
        self.tempStatus1 = true;
        this.tickerStart();
        self.changeSpriteFun(endRow, endCol, startRow, startCol);
      }
    }
  },
  checkXY(sprite1, sprite2) {
    if (!sprite1 || !sprite2) { return false; }
    if (!sprite1.visible || !sprite2.visible) { return false; }
    let s1X = sprite1.x, s1Y = sprite1.y;
    let center1X = sprite1.x + sprite1.width / 2, center1Y = sprite1.y + sprite1.height / 2;
    let s2X = sprite2.x, s2Y = sprite2.y;
    let center2X = sprite2.x + sprite2.width / 2, center2Y = sprite2.y + sprite2.height / 2;
    let roundCx1 = center2X - 1, roundCx2 = center2X + 1;
    let roundCy1 = center2Y - 1, roundCy2 = center2Y + 1;
    let roundX1 = s2X - 1, roundX2 = s2X + 1;
    let roundY1 = s2Y - 1, roundY2 = s2Y + 1;
    let blX = false;
    if ((roundX1 <= s1X && s1X <= roundX2) || (roundCx1 <= center1X && center1X <= roundCx2)) {
      blX = true;
    }
    let blY = false;
    if ((roundY1 <= s1Y && s1Y <= roundY2) || (roundCy1 <= center1Y && center1Y <= roundCy2)) {
      blY = true;
    }
    if (!!blX && !!blY) { return true; }
    return false;
  },
  moveXFun: function () {
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible && !!sprite.moveXObj) {
        let speed = sprite.moveXObj.speed;
        let maxNum = sprite.moveXObj.maxNum;
        // x轴移动
        let tempNum = sprite.x + speed;
        if (speed > 0) {
          // 精灵向右移动
          tempNum = Math.min(tempNum, maxNum);
        } else {
          // 精灵向左移动
          tempNum = Math.max(maxNum, tempNum);
        }
        if (this.checkXY(this.selectAnimateSprite, sprite)) {
          this.selectAnimateSprite.x = tempNum;
        }
        sprite.x = tempNum;
        if (sprite.x == maxNum) {
          sprite.moveXObj = null;
          try {
            this.changeDone();
          } catch (e) { }
        }
      }
    })
    this.animateSpriteArr.forEach(sprite => {
      if (!!sprite.visible && !!sprite.moveXObj) {
        let speed = sprite.moveXObj.speed;
        let maxNum = sprite.moveXObj.maxNum;
        // x轴移动
        let tempNum = sprite.x + speed;
        if (speed > 0) {
          // 精灵向右移动
          tempNum = Math.min(tempNum, maxNum);
        } else {
          // 精灵向左移动
          tempNum = Math.max(maxNum, tempNum);
        }
        if (this.checkXY(this.selectAnimateSprite, sprite)) {
          this.selectAnimateSprite.x = tempNum;
        }
        sprite.x = tempNum;
        if (sprite.x == maxNum) {
          sprite.moveXObj = null;
          try {
            this.changeDone();
          } catch (e) { }
        }
      }
    })
  },
  moveYFun: function () {
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible && !!sprite.moveYObj) {
        let speed = sprite.moveYObj.speed;
        let maxNum = sprite.moveYObj.maxNum;
        // y轴移动
        let tempNum = sprite.y + speed;
        if (speed > 0) {
          // 精灵向下移动
          tempNum = Math.min(tempNum, maxNum);
        } else {
          // 精灵向上移动
          tempNum = Math.max(maxNum, tempNum);
        }
        if (this.checkXY(this.selectAnimateSprite, sprite)) {
          this.selectAnimateSprite.y = tempNum;
        }
        sprite.y = tempNum;
        if (sprite.y == maxNum) {
          if (!!sprite.moveYObj.fdone) {
            // 下移完成
            this.fdoneCount++;
            if (this.fdoneCount == this.fanimateCount) {
              // 所有动画执行完成
              this.fsm = "B";
              // 因为是异步，手动调用
              this.draw();
            }
            sprite.moveYObj = null;
          } else {
            sprite.moveYObj = null;
            try {
              this.changeDone();
            } catch (e) { }
          }
        }
      }
    })
    this.animateSpriteArr.forEach(sprite => {
      if (!!sprite.visible && !!sprite.moveYObj) {
        let speed = sprite.moveYObj.speed;
        let maxNum = sprite.moveYObj.maxNum;
        // y轴移动
        let tempNum = sprite.y + speed;
        if (speed > 0) {
          // 精灵向下移动
          tempNum = Math.min(tempNum, maxNum);
        } else {
          // 精灵向上移动
          tempNum = Math.max(maxNum, tempNum);
        }
        if (this.checkXY(this.selectAnimateSprite, sprite)) {
          this.selectAnimateSprite.y = tempNum;
        }
        sprite.y = tempNum;
        if (sprite.y == maxNum) {
          if (!!sprite.moveYObj.fdone) {
            // 下移完成
            this.fdoneCount++;
            if (this.fdoneCount == this.fanimateCount) {
              // 所有动画执行完成
              this.fsm = "B";
              // 因为是异步，手动调用
              this.draw();
            }
            sprite.moveYObj = null;
          } else {
            sprite.moveYObj = null;
            try {
              this.changeDone();
            } catch (e) { }
          }
        }
      }
    })
  },
  frame: function (img, x, y) {
    // 返回texture
    let source = img.src, width = img.width - x, height = img.height - y;
    if (y > img.height) {
      y = img.height;
    }

    let texture, imageFrame;
    if (typeof source === "string") {
      if (PIXI.utils.TextureCache[source]) {
        texture = new PIXI.Texture(PIXI.utils.TextureCache[source]);
      }
    }
    if (!texture) { console.log(`Please load the ${source} texture into the cache.`, img); } else {
      imageFrame = new PIXI.Rectangle(x, y, width, height);
      texture.frame = imageFrame;
      return texture;
    }
  },
  renderSprite: function (img) {
    let imgArr = img;
    if (Object.prototype.toString.call(img) == "[object Array]") {
      // 数组
    } else {
      // 对象
      imgArr = [img];
    }
    for (let i = 0, total = imgArr.length; i < total; i++) {
      let tImg = imgArr[i];
      let sprite;
      if (!tImg.uniId) {
        // 没有唯一标识，说明第一次生成
        if (tImg.type == "animate") {
          // 动画
          let textures = [];
          tImg.srcArr.forEach(img => {
            textures.push(this.frame(img, 0, 0));
          })
          sprite = new PIXI.extras.AnimatedSprite(textures);
          sprite.animationSpeed = tImg.boomSpeed;
          sprite.loop = !!tImg.loop;
          sprite.onComplete = function () {
            this.visible = false;
            if (!!tImg.callback) {
              try {
                tImg.callback();
              } catch (e) { }
            }
            // console.log("动画播放完毕...");
          }
        } else {
          if (!!tImg.srcArr && tImg.srcArr.length > 0) {
            // 动画
            let textures = [];
            tImg.srcArr.forEach(img => {
              textures.push(this.frame(img, 0, 0));
            })
            sprite = new PIXI.extras.AnimatedSprite(textures);
            sprite.animationSpeed = tImg.srcArrSpeed || 0.1;
            sprite.loop = true;
            sprite.play();
          } else {
            sprite = new PIXI.Sprite();
            sprite.texture = this.frame(tImg, 0, 0);
          }
        }

        if (!!tImg.autoScale || (!!this.options.spriteShowAll && (tImg.type != "score" && tImg.type != "time" && tImg.type != "score2" && tImg.typeName != "allLine"))) {
          // 自适应宽高 选中框撑满
          sprite.width = this.spriteW;
          sprite.height = this.spriteH;
        } else {
          // 等比宽高
          sprite.width = tImg.width * this.options.$game.fObj.scale;
          sprite.height = tImg.height * this.options.$game.fObj.scale;
        }

        sprite.x = (tImg.x || 0) + (this.spriteW - sprite.width) / 2;
        sprite.y = (tImg.y || 0) + (this.spriteH - sprite.height) / 2;
        sprite.imgObj = tImg;

        tImg.sprite = sprite;
        tImg.uniId = this.uniId();

        if (tImg.type == "score") {
          sprite.x = (tImg.x || 0);
          sprite.y = (tImg.y || 0);
          sprite.type = tImg.type;
          if (!!tImg.isBg) {
            this.scoreBgSprite = sprite;
          } else {
            this.scoreSpriteArr.push(sprite);
          }
          this.scoreContainer.addChild(sprite);
        } else if (tImg.type == "score2") {
          sprite.type = tImg.type;
          if (typeof tImg.topY == "undefined" && !!tImg.top1) {
            sprite.y = sprite.y - this.spriteH;
          } else if (!!tImg.topY) {
            sprite.y = sprite.y + (tImg.topY * this.options.$game.fObj.scale);
          }

          setTimeout(() => {
            sprite.visible = false;
          }, tImg.fadeTime || 500)
          this.score2Container.addChild(sprite);
          this.score2SpriteArr.push(sprite);
        } else if (tImg.type == "time") {
          sprite.x = (tImg.x || 0)
          sprite.y = (tImg.y || 0);
          sprite.type = tImg.type;
          if (!!tImg.isBg) {
            this.timeBgSprite = sprite;
          } else {
            this.timeSpriteArr.push(sprite);
          }
          this.timeContainer.addChild(sprite);
        } else if (tImg.type == "animate") {
          if (tImg.typeName == "selectAnimate") {
            this.selectAnimateSprite = sprite;
          }
          if (tImg.typeName == "allLine") {
            sprite.x = tImg.x || 0;
            sprite.y = tImg.y || 0;
          }
          sprite.type = tImg.type;
          sprite.stop()
          sprite.gotoAndPlay(0)
          this.animateSpriteArr.push(sprite);
          this.animateContainer.addChild(sprite);
        } else {
          sprite.type = !!tImg.type;
          this.spriteArr.push(sprite);
          this.spriteContainer.addChild(sprite);
        }
      } else {
        sprite = tImg.sprite;
      }
    }
  },
  isJiNeng: function (sprite) {
    // 判断是否是特殊技能
    let imgObj = sprite.imgObj;

    if (imgObj.type == "cross" || imgObj.type == "sudoku") {
      return true;
    }
    return false;
  },
  // 获取了能量
  updateFun: function (obj) {
    // obj = {curSteps: 30}
    obj = Object.assign({ curSteps: this.curSteps, totalScore: this.totalScore, curScore: this.curScore }, obj);
    if (!!obj.curScore) {
      this.touchEndFun();
    } else {
      if (!!this.writeClearStatus) {
        this.writeClearStatus = false;
      }
    }
    this.curScore = 0;
    try {
      this.renderScore(this.totalScore);
    } catch (e) { }
    try {
      this.options.updateFun(obj);
    } catch (e) { }
  },
  audioFun: function (name) {
    if (!name) { return false; }
    let tempAudio;
    if (!!this.fAudio) {
      this.fAudio.destroy();
    }
    const innerAudioContext = my.createInnerAudioContext();
    this.fAudio = innerAudioContext;
    for (let audioName in this.options.audio) {
      let audioObj = this.options.audio[audioName];

      if (!!name && name == audioName) {
        tempAudio = audioObj;
      }
    }
    if (!!tempAudio) {
      this.fAudio.src = tempAudio.src;
      this.fAudio.play();
    }
  },
  statusfun_B: function (fadeName) {
    // 记录本次消除的分数
    this.curScore = this.curScore || 0;
    //检查是否能够消除，能，则进入状态C，不能则进入状态A
    let spriteArr1 = [];
    let tempArr = [];//用数组形式存临时数据
    let startSprite, endSprite;
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        // 只判断显示的精灵
        spriteArr1.push(sprite);

        let imgObj = sprite.imgObj;
        let row = imgObj.row;
        let col = imgObj.col;
        tempArr[row] = tempArr[row] || [];
        tempArr[row][col] = sprite;

        if (!!this.touchStartPos && !!this.touchEndPos) {
          if (this.touchStartPos.row == imgObj.row && this.touchStartPos.col == imgObj.col) {
            startSprite = sprite;
          }
          if (this.touchEndPos.row == imgObj.row && this.touchEndPos.col == imgObj.col) {
            endSprite = sprite;
          }
        }
      }
    });
    // 能够消除的元素数组
    let fadeArr = [];
    let type = "base";
    let audioName = "";
    // 此处如果不赋值，则只有移动的时候有音效 赋值后，有消除就有音效
    audioName = "default";

    if (fadeName == "clear") {
      // 全消
      fadeArr = spriteArr1;
      // 全消音乐
      audioName = "clearAudio";
    }

    // 此判断只能证明移动了
    if (!!this.changeStatus && fadeArr.length == 0) {
      // 检测是否移动了技能元素
      if (!!startSprite && !!endSprite) {
        try {
          // 默认开始触发的元素音效
          audioName = startSprite.imgObj.audioName;
        } catch (e) { }
        if (startSprite.imgObj.type == "cross" || endSprite.imgObj.type == "cross") {
          type = "teshu";
          // 移动十字消除
          let row1, col1, row2, col2;
          if (startSprite.imgObj.type == "cross") {
            row1 = startSprite.imgObj.row;
            col1 = startSprite.imgObj.col;
            fadeArr.push(tempArr[row1][col1]);
            audioName = startSprite.imgObj.audioName;
          }
          if (endSprite.imgObj.type == "cross") {
            row2 = endSprite.imgObj.row;
            col2 = endSprite.imgObj.col;
            fadeArr.push(tempArr[row2][col2]);
            audioName = endSprite.imgObj.audioName;
          }
        }
        if (startSprite.imgObj.type == "boom" || endSprite.imgObj.type == "boom") {
          type = "teshu";
          let row1, col1, row2, col2;
          if (startSprite.imgObj.type == "boom") {
            row1 = startSprite.imgObj.row;
            col1 = startSprite.imgObj.col;
            fadeArr.push(tempArr[row1][col1]);
            audioName = startSprite.imgObj.audioName;
          }
          if (endSprite.imgObj.type == "boom") {
            row2 = endSprite.imgObj.row;
            col2 = endSprite.imgObj.col;
            fadeArr.push(tempArr[row2][col2]);
            audioName = endSprite.imgObj.audioName;
          }
        }
        if (startSprite.imgObj.type == "horizontal" || endSprite.imgObj.type == "horizontal") {
          type = "teshu";
          let row1, col1, row2, col2;
          if (startSprite.imgObj.type == "horizontal") {
            row1 = startSprite.imgObj.row;
            col1 = startSprite.imgObj.col;
            fadeArr.push(tempArr[row1][col1]);
            audioName = startSprite.imgObj.audioName;
          }
          if (endSprite.imgObj.type == "horizontal") {
            row2 = endSprite.imgObj.row;
            col2 = endSprite.imgObj.col;
            fadeArr.push(tempArr[row2][col2]);
            audioName = endSprite.imgObj.audioName;
          }
        }
        if (startSprite.imgObj.type == "vertical" || endSprite.imgObj.type == "vertical") {
          type = "teshu";
          let row1, col1, row2, col2;
          if (startSprite.imgObj.type == "vertical") {
            row1 = startSprite.imgObj.row;
            col1 = startSprite.imgObj.col;
            fadeArr.push(tempArr[row1][col1]);
            audioName = startSprite.imgObj.audioName;
          }
          if (endSprite.imgObj.type == "vertical") {
            row2 = endSprite.imgObj.row;
            col2 = endSprite.imgObj.col;
            fadeArr.push(tempArr[row2][col2]);
            audioName = endSprite.imgObj.audioName;
          }
        }
      }
      if (fadeArr.length > 0) {
        // 证明进入了特殊技能
        fadeArr = this.checkAllJineng(tempArr, fadeArr);
      }
    }
    if (fadeArr.length == 0) {
      // 横向检测
      for (let row = 0; row < this.options.rowNum; row++) {
        let i = 0;
        let j = 1;
        while (j < this.options.colNum) {
          if (tempArr[row][i].imgObj.src != tempArr[row][j].imgObj.src || (j == this.options.colNum - 1 && tempArr[row][i].imgObj.src == tempArr[row][j].imgObj.src)) {
            if (j - i >= 3 || (j - i >= 2 && j == this.options.colNum - 1 && tempArr[row][i].imgObj.src == tempArr[row][j].imgObj.src)) {
              if (j - i >= 2 && j == this.options.colNum - 1 && tempArr[row][i].imgObj.src == tempArr[row][j].imgObj.src) {
                // 最后一个，而且和前面连续相同
                j = j + 1;
              }
              for (let m = i; m < j; m++) {
                if (!this.isJiNeng(tempArr[row][m])) {
                  fadeArr.push(tempArr[row][m]);
                }
              }
            }
            i = j;
          }
          j++;
        }
      }
      // 纵向检测
      for (let col = 0; col < this.options.colNum; col++) {
        let i = 0;
        let j = 1;
        while (j < this.options.rowNum) {
          if (tempArr[i][col].imgObj.src != tempArr[j][col].imgObj.src || (j == this.options.rowNum - 1 && tempArr[i][col].imgObj.src == tempArr[j][col].imgObj.src)) {
            if (j - i >= 3 || (j - i >= 2 && j == this.options.rowNum - 1 && tempArr[i][col].imgObj.src == tempArr[j][col].imgObj.src)) {
              if (j - i >= 2 && j == this.options.rowNum - 1 && tempArr[i][col].imgObj.src == tempArr[j][col].imgObj.src) {
                j = j + 1;
              }
              for (let m = i; m < j; m++) {
                //判断是否重复
                let isExist = false;
                fadeArr.forEach(function (sprite) {
                  let imgObj = sprite.imgObj;
                  if (imgObj.row == m && imgObj.col == col) {
                    isExist = true;
                  }
                })
                if (!isExist) {
                  if (!this.isJiNeng(tempArr[m][col])) {
                    fadeArr.push(tempArr[m][col]);
                  }
                }
              }
            }
            i = j;
          }
          j++;
        }
      }
    }
    if (!this.iStop) {
      // 游戏开始后才计分
      fadeArr.forEach(sprite => {
        this.curScore += (sprite.imgObj.val || 0);
        this.totalScore += (sprite.imgObj.val || 0);
      })
      if (!!this.options.scorePos) {
        this.renderScore(this.totalScore);
      }
    } else {
      // 游戏未开始
      if (!!this.options.gameStartPlayAudio) {
        audioName = "";
      }
    }
    this.fadeArr = fadeArr;
    if (fadeArr.length > 0) {
      if (type == "base") {
        // 此处判断连续消除的个数 是否应该生成技能元素
        if (fadeArr.length >= 4) {
          let spriteObj = {
            /* "sprite_src1": []//数组 */
          };
          fadeArr.forEach(sprite => {
            let imgObj = sprite.imgObj;
            spriteObj[`sprite_${imgObj.src}`] = spriteObj[`sprite_${imgObj.src}`] || [];
            spriteObj[`sprite_${imgObj.src}`].push(sprite);
          })
          for (let name in spriteObj) {
            let spriteArr = spriteObj[name];
            // 消除的同类元素个数，但此个数不代表是连续的个数
            if (spriteArr.length >= 4) {
              // 查找连续元素
              let tempArr = this.findNextSprite(spriteArr);

              if (tempArr.length == 4) {
                // 生成横向消除元素
                let teshuSprite, teshuImgObj;
                // 此时默认生成在第一个位置
                if (!!this.touchStartPos && !!this.touchEndPos) {
                  let startRow = this.touchStartPos.row,
                    startCol = this.touchStartPos.col;
                  let endRow = this.touchEndPos.row,
                    endCol = this.touchEndPos.col;
                  tempArr.forEach((tt, index) => {
                    // 如果用户交换了元素触发，则生成在交换的元素位置
                    try {
                      if (!teshuSprite && (tt.imgObj.row == startRow && tt.imgObj.col == startCol) || (tt.imgObj.row == endRow && tt.imgObj.col == endCol)) {
                        teshuSprite = tt;
                      }
                    } catch (e) { }
                  })
                }
                if (!teshuSprite) {
                  teshuSprite = tempArr[0];
                }

                if (tempArr[0].imgObj.row == tempArr[1].imgObj.row) {
                  // 竖向
                  if (!!this.options.gameSource.vertical) {
                    teshuImgObj = Object.assign({
                      type: "vertical",
                    }, this.options.gameSource.vertical);
                  }
                } else {
                  // 横向
                  if (!!this.options.gameSource.horizontal) {
                    teshuImgObj = Object.assign({
                      type: "horizontal",
                    }, this.options.gameSource.horizontal);
                  }
                }

                if (!!teshuImgObj) {
                  teshuImgObj.row = teshuSprite.imgObj.row;
                  teshuImgObj.col = teshuSprite.imgObj.col;
                  teshuImgObj.x = teshuSprite.x;
                  teshuImgObj.y = teshuSprite.y;

                  this.teshuImgObj = teshuImgObj;
                }
              }
              if (tempArr.length >= (this.options.boomNum || 5) && !!this.options.gameSource.sudoku) {
                // 此处判断是否生成炸弹
                // 生成炸弹
                let boomSprite, boomImgObj;
                if (!!tempArr && tempArr.length > 0) {
                  // 此时默认生成在第一个位置
                  if (!!this.touchStartPos && !!this.touchEndPos) {
                    let startRow = this.touchStartPos.row,
                      startCol = this.touchStartPos.col;
                    let endRow = this.touchEndPos.row,
                      endCol = this.touchEndPos.col;
                    tempArr.forEach((tt, index) => {
                      // 如果用户交换了元素触发，则生成在交换的元素位置
                      try {
                        if (!boomSprite && (tt.imgObj.row == startRow && tt.imgObj.col == startCol) || (tt.imgObj.row == endRow && tt.imgObj.col == endCol)) {
                          boomSprite = tt;
                        }
                      } catch (e) { }
                    })
                  }
                  if (!boomSprite) {
                    boomSprite = tempArr[0];
                  }
                  boomImgObj = Object.assign({
                    type: "sudoku",
                  }, this.options.gameSource.sudoku);

                  boomImgObj.row = boomSprite.imgObj.row;
                  boomImgObj.col = boomSprite.imgObj.col;
                  boomImgObj.x = boomSprite.x;
                  boomImgObj.y = boomSprite.y;

                  if (!!boomImgObj) {
                    this.boomImgObj = boomImgObj;
                  }
                }
              }
            }
          }
        }
      }
      this.touchStartPos = "";
      this.touchEndPos = "";
      this.fsm = "C";
      this.audioFun(audioName);
    } else {
      this.fsm = "A";
    }
  },
  checkAllJineng: function (tempArr, fadeArr) {
    // 检测fadeArr数组里面消除元素的特殊技能，并消除对应应该消除的元素
    let checkNext = false;
    let returnArr = fadeArr;
    fadeArr.forEach(sprite => {
      if (sprite.imgObj.type == "cross") {
        // 十字消除
        let row1, col1;
        if (sprite.imgObj.type == "cross") {
          row1 = sprite.imgObj.row;
          col1 = sprite.imgObj.col;
        }
        for (let row = 0; row < this.options.rowNum; row++) {
          for (let col = 0; col < this.options.colNum; col++) {
            if (row1 == row || col1 == col) {
              //判断是否重复
              let isExist = false;
              returnArr.forEach(function (sprite1) {
                let imgObj = sprite1.imgObj;
                if (imgObj.row == row && imgObj.col == col) {
                  isExist = true;
                }
              })
              if (!isExist) {
                let spr = tempArr[row][col];
                if (spr.imgObj.type == "cross" || spr.imgObj.type == "boom" || spr.imgObj.type == "vertical" || spr.imgObj.type == "horizontal") {
                  // 特殊技能元素
                  checkNext = true;
                }
                returnArr.push(spr);
              }
            }
          }
        }
      }
      if (sprite.imgObj.type == "vertical") {
        // 纵向消除
        let col1;
        if (sprite.imgObj.type == "vertical") {
          col1 = sprite.imgObj.col;
        }
        for (let row = 0; row < this.options.rowNum; row++) {
          for (let col = 0; col < this.options.colNum; col++) {
            if (col1 == col) {
              //判断是否重复
              let isExist = false;
              returnArr.forEach(function (sprite1) {
                let imgObj = sprite1.imgObj;
                if (imgObj.row == row && imgObj.col == col) {
                  isExist = true;
                }
              })
              if (!isExist) {
                let spr = tempArr[row][col];
                if (spr.imgObj.type == "cross" || spr.imgObj.type == "boom" || spr.imgObj.type == "vertical" || spr.imgObj.type == "horizontal") {
                  // 特殊技能元素
                  checkNext = true;
                }
                returnArr.push(spr);
              }
            }
          }
        }
      }
      if (sprite.imgObj.type == "horizontal") {
        // 横向消除
        let row1;
        if (sprite.imgObj.type == "horizontal") {
          row1 = sprite.imgObj.row;
        }
        for (let row = 0; row < this.options.rowNum; row++) {
          for (let col = 0; col < this.options.colNum; col++) {
            if (row1 == row) {
              //判断是否重复
              let isExist = false;
              returnArr.forEach(function (sprite1) {
                let imgObj = sprite1.imgObj;
                if (imgObj.row == row && imgObj.col == col) {
                  isExist = true;
                }
              })
              if (!isExist) {
                let spr = tempArr[row][col];
                if (spr.imgObj.type == "cross" || spr.imgObj.type == "boom" || spr.imgObj.type == "vertical" || spr.imgObj.type == "horizontal") {
                  // 特殊技能元素
                  checkNext = true;
                }
                returnArr.push(spr);
              }
            }
          }
        }
      }
      if (sprite.imgObj.type == "boom") {
        // 移动炸弹消除
        let row1, col1;
        if (sprite.imgObj.type == "boom") {
          row1 = sprite.imgObj.row;
          col1 = sprite.imgObj.col;
        }
        let arr1 = [
          { row: row1 - 1, col: col1 - 1 }, { row: row1 - 1, col: col1 - 0 }, { row: row1 - 1, col: col1 + 1 },
          { row: row1 - 0, col: col1 - 1 }, { row: row1 - 0, col: col1 - 0 }, { row: row1 - 0, col: col1 + 1 },
          { row: row1 + 1, col: col1 - 1 }, { row: row1 + 1, col: col1 - 0 }, { row: row1 + 1, col: col1 + 1 },
        ];
        arr1.forEach(pos => {
          // 坐标必须在有效值范围内
          if (pos.row >= 0 && pos.row < this.options.rowNum && pos.col >= 0 && pos.col < this.options.colNum) {
            //判断是否重复
            let isExist = false;
            returnArr.forEach(function (sprite1) {
              let imgObj = sprite1.imgObj;
              if (imgObj.row == pos.row && imgObj.col == pos.col) {
                isExist = true;
              }
            })
            if (!isExist) {
              let spr = tempArr[pos.row][pos.col];
              if (spr.imgObj.type == "cross" || spr.imgObj.type == "boom" || spr.imgObj.type == "vertical" || spr.imgObj.type == "horizontal") {
                // 特殊技能元素
                checkNext = true;
              }
              returnArr.push(spr);
            }
          }
        })
      }
    })
    if (!!checkNext) {
      // 继续读取
      returnArr = this.checkAllJineng(tempArr, returnArr);
    }
    return returnArr;
  },
  findNextSprite: function (spriteArr, notArr = [], sprite) {
    // 查找和sprite连续挨着的元素 并存储在returnArr数组内
    sprite = sprite || spriteArr[0];
    let imgObj = sprite.imgObj;
    let returnArr = [sprite];
    spriteArr.forEach(tSprite => {
      let tImgObj = tSprite.imgObj;
      if ((tImgObj.row == imgObj.row + 1 && tImgObj.col == imgObj.col) || (tImgObj.row == imgObj.row - 1 && tImgObj.col == imgObj.col) || (tImgObj.col == imgObj.col + 1 && tImgObj.row == imgObj.row) || (tImgObj.col == imgObj.col - 1 && tImgObj.row == imgObj.row)) {
        // 默认可以添加
        let bl = true;
        notArr.forEach(notSprite => {
          if (tImgObj.row == notSprite.imgObj.row && tImgObj.col == notSprite.imgObj.col) {
            bl = false;
          }
        })
        if (!!bl) {
          returnArr.push(tSprite);
          let tempArr = this.findNextSprite(spriteArr, returnArr.concat(notArr), tSprite);
          let tArr = [];
          tempArr.forEach(s1 => {
            let s1ImgObj = s1.imgObj;
            let bl1 = true;
            returnArr.forEach(s2 => {
              let s2ImgObj = s2.imgObj;
              if (s1.imgObj.row == s2ImgObj.row && s1.imgObj.col == s2ImgObj.col) {
                bl1 = false;
              }
            })
            if (!!bl1) {
              tArr.push(s1);
            }
          })
          returnArr = returnArr.concat(tArr);
        }
      }
    })
    return returnArr;
  },
  statusfun_C: function () {
    // 执行动画，消除精灵
    this.tickerStart();
    // 总消除个数
    this.totalCount = this.fadeArr.length;
    // 当前已消除个数
    this.tempCount = 0;
    // 需要补充的精灵，只需要列
    this.supplyArr = [];
    // 隐藏所有动画精灵
    this.hideSpriteArrFun("animateSpriteArr");
    // 1.隐藏静态精灵
    this.fadeArr.forEach(sprite => {
      if (!!sprite.visible) {
        let imgObj = sprite.imgObj;
        this.supplyArr.push({ row: imgObj.row, col: imgObj.col });
        sprite.visible = false;
        // 显示分数
        if (!!imgObj.scoreImg) {
          let score2Obj = Object.assign({}, imgObj.scoreImg, {
            type: "score2",
            x: sprite.x,
            y: sprite.y
          });
          this.renderSprite(score2Obj);
        }
        if (!!imgObj.boomArr && imgObj.boomArr.length > 0) {
          let width = imgObj.boomArr[0].width || imgObj.width,
            height = imgObj.boomArr[0].height || imgObj.height;
          let x = sprite.x, y = sprite.y;
          let typeName = "";
          if (width > imgObj.width || height > imgObj.height) {
            typeName = "allLine";
            if (width > height) {
              x = this.padding.left;
            } else {
              y = this.padding.top;
            }
          }
          let animateObj = Object.assign({}, {
            type: "animate",
            typeName: typeName,
            srcArr: imgObj.boomArr,
            boomSpeed: imgObj.boomSpeed,
            width: width,
            height: height,
            x: x,
            y: y,
            callback: () => {
              this.tempCount++;
              if (this.totalCount == this.tempCount) {
                // 2.生成动画精灵
                this.fsm = "D";
                // 因为是异步，手动调用
                this.draw();
              }
            }
          });
          this.renderSprite(animateObj);
        }
      }
    });
  },
  statusfun_D: function () {
    // 补齐精灵在容器外
    this.tempObj = {};//此列生成精灵的个数
    this.supplyArr.forEach(item => {
      let col = item.col;
      if (!this.tempObj[`check_${col}`]) {
        this.tempObj[`check_${col}`] = 1;
      } else {
        this.tempObj[`check_${col}`] += 1;
      }
      // 生成精灵
      let imgObj;

      if (!imgObj && !!this.options.gameSource.cross && !!this.options.gameSource.cross.probability) {
        // 有十字消除元素概率
        let tempNum1 = this.random({ max: 1000 });
        if (tempNum1 <= this.options.gameSource.cross.probability) {
          // 生成十字消除元素
          imgObj = Object.assign({
            type: "cross",
          }, this.options.gameSource.cross);
        }
      }
      if (!imgObj) {
        // 生成普通精灵元素
        let allImgs = this.options.gameSource.items;
        imgObj = Object.assign({
          type: "sprite",
        }, allImgs[this.random({ max: allImgs.length })]);
      }
      imgObj.row = -1;
      imgObj.col = col;
      imgObj.x = col * this.spriteW + this.padding.left;
      imgObj.y = -(this.tempObj[`check_${col}`] * this.spriteH + this.padding.top);
      if (!!imgObj) {
        if (!!this.boomImgObj) {
          if (this.boomImgObj.row == item.row && this.boomImgObj.col == item.col) {
            // 此处为炸弹
            imgObj = this.boomImgObj;
            imgObj.type = "boom";
            this.boomImgObj = "";
          }
        }
        if (!!this.teshuImgObj) {
          if (this.teshuImgObj.row == item.row && this.teshuImgObj.col == item.col) {
            // 此处为横向或纵向消除元素
            imgObj = this.teshuImgObj;
            this.teshuImgObj = "";
          }
        }
        this.renderSprite(imgObj);
      }
    })

    this.fsm = "E";
  },
  statusfun_E: function () {
    let self = this;
    // 将空位上方的精灵下移到空位上，然后继续检测是否有可消除元素
    // 1.监测每个元素是否下落
    for (let col = 0; col < this.options.colNum; col++) {
      // 临时存储当前列元素 个数为:this.options.rowNum
      let tempColArr = [];
      this.spriteArr.forEach(sprite => {
        if (!!sprite.visible && sprite.imgObj.col == col) {
          let tempIndex = tempColArr.length;
          tempColArr.forEach((tsprite, index) => {
            if (sprite.y < tsprite.y && index < tempIndex) {
              tempIndex = index;
            }
          })
          tempColArr.splice(tempIndex, 0, sprite);
        }
      })
      tempColArr.forEach((sprite, row) => {
        sprite.imgObj.row = row;
      })
    }
    this.fanimateCount = 0;
    this.fdoneCount = 0;
    // 循环 下落
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        let endY = sprite.imgObj.row * this.spriteH + (self.spriteH - sprite.height) / 2 + this.padding.top;
        if (sprite.y < endY) {
          this.fanimateCount++;
          // 此元素要下移
          sprite.moveYObj = {
            speed: this.options.speed,
            maxNum: endY,
            fdone: true
          }
        }
      }
    })

  },
  draw: function (fadeName) {
    let self = this;

    let enterFSM = self.fsm;

    //根据状态机状态决定做什么事情
    switch (self.fsm) {
      case "A":
        // 停止更新画布
        if (!!self.writeClearStatus) {
          self.updateFun();
          if (!!self.over) {
            self.gameOver();
          }
        }
        if (!!this.initStatus) {
          this.initStatus = false;
        }
        this.tickerStop();
        break;
      case "B":
        //检查是否能够消除，能，则进入状态C，不能则进入状态A
        self.statusfun_B(fadeName);
        break;
      case "C":
        //消除精灵，并补充新精灵
        self.statusfun_C();
        break;
      case "D":
        // 补齐精灵在容器外
        self.statusfun_D();
        break;
      case "E":
        // 将空位上方的精灵下移到空位上，然后继续检测是否有可消除元素
        self.statusfun_E();
        break;
    }

    if (enterFSM != self.fsm) {
      this.draw();
    }
  },
  hideSpriteArrFun(name, ops) {
    let options = Object.assign({ childs: [] }, ops);
    if (!!this[name]) {
      this[name].forEach(sprite => {
        if (!!sprite.visible) {
          sprite.visible = false;
        }
        options.childs.forEach(t => {
          if (!!sprite[t] && !!sprite[t].visible) {
            sprite[t].visible = false;
          }
        })
      })
    }
  },
  init: function (defaultData = {}) {//帧
    clearInterval(this.timerInterval);
    this.hideSpriteArrFun("scoreSpriteArr");
    this.hideSpriteArrFun("timeSpriteArr");
    this.hideSpriteArrFun("animateSpriteArr");
    this.hideSpriteArrFun("score2SpriteArr");
    // 数组
    this.spriteArr = defaultData.spriteArr || [];// 存放精灵数组
    this.scoreSpriteArr = defaultData.scoreSpriteArr || [];// 存放分数精灵数组
    this.score2SpriteArr = defaultData.score2SpriteArr || [];// 存放分数精灵数组2
    this.timeSpriteArr = defaultData.timeSpriteArr || [];// 存放倒计时精灵数组
    this.animateSpriteArr = defaultData.animateSpriteArr || [];// 存放动画精灵数组
    if (this.options.gamePlayType == "steps") {
      this.curSteps = this.options.gameSteps || 30;//游戏步数,默认30
    }
    // 总分数
    this.totalScore = defaultData.totalScore || 0;

    if (!!this.options.scorePos) {
      this.renderScore(this.totalScore);
    }
    if (!!this.options.timePos) {
      this.curTime = this.options.timePos.time;
      this.renderTime(this.curTime);
    }
    // 1.生成精灵
    for (let i = 0; i < this.options.rowNum; i++) {
      for (let j = 0; j < this.options.colNum; j++) {
        // 生成精灵
        let imgObj;
        if (!!this.options.gameSource.cross && !!this.options.gameSource.cross.probability) {
          // 有十字消除元素概率
          let tempNum1 = this.random({ max: 1000 });
          if (tempNum1 <= this.options.gameSource.cross.probability) {
            // 生成十字消除元素
            imgObj = Object.assign({
              type: "cross",
            }, this.options.gameSource.cross);
          }
        }
        if (!imgObj) {
          // 生成普通精灵元素
          let allImgs = this.options.gameSource.items;
          imgObj = Object.assign({
            type: "sprite",
          }, allImgs[this.random({ max: allImgs.length })]);
        }
        imgObj.row = i;
        imgObj.col = j;
        imgObj.x = j * this.spriteW + this.padding.left;
        imgObj.y = i * this.spriteH + this.padding.top;
        if (!!imgObj) {
          this.renderSprite(imgObj);
        }
      }
    }
    this.iStop = true;//默认游戏未开始
    //状态机
    this.fsm = "B"; // A--静稳状态  B--检查是否能够消除 C--消除 D--下落  E--补充新的
    // 2.精灵地图检测
    this.draw();

    this.initStatus = true;
    this.tickerStart();
  },
  renderTime: function (num) {
    // 1.判断是否渲染了时间背景图，如果没有，则渲染
    if (!this.timeBgSprite && !!this.options.timePos.src) {
      // 渲染背景底图
      let timeBgObj = Object.assign({}, {
        type: "time",
        isBg: true,
        src: this.options.timePos.src,
        width: this.options.timePos.width,
        height: this.options.timePos.height,
        x: this.options.timePos.left * this.options.$game.fObj.scale,
        y: this.options.timePos.top * this.options.$game.fObj.scale,
      });
      this.renderSprite(timeBgObj);
    }
    // 2.隐藏已显示的时间
    this.hideSpriteArrFun("timeSpriteArr");
    // 3.渲染分数
    let arr1 = (parseInt(num / 60) + '').padStart(2, '0').replace('.', '0').split('');
    let arr2 = (num % 60 + '').padStart(2, '0').split('');
    let numArr = this.options.timePos.numArr || [];
    // 第一位时间
    let timeObj = Object.assign({}, numArr[arr1[0]], {
      type: "time",
      x: ((this.options.timePos.timeleft || 0)) * this.options.$game.fObj.scale,
      y: (this.options.timePos.timeTop || 0) * this.options.$game.fObj.scale,
    });
    this.renderSprite(timeObj);
    // 第二位时间
    timeObj = Object.assign({}, numArr[arr1[1]], {
      type: "time",
      x: ((this.options.timePos.timeleft || 0) + numArr[arr1[0]].width) * this.options.$game.fObj.scale,
      y: (this.options.timePos.timeTop || 0) * this.options.$game.fObj.scale,
    });
    this.renderSprite(timeObj);
    // 第三位时间
    timeObj = Object.assign({}, numArr[arr2[0]], {
      type: "time",
      x: ((this.options.timePos.timeRight || 0) - numArr[arr2[0]].width * 2) * this.options.$game.fObj.scale,
      y: (this.options.timePos.timeTop || 0) * this.options.$game.fObj.scale,
    });
    this.renderSprite(timeObj);
    // 第四位时间
    timeObj = Object.assign({}, numArr[arr2[1]], {
      type: "time",
      x: ((this.options.timePos.timeRight || 0) - numArr[arr2[0]].width) * this.options.$game.fObj.scale,
      y: (this.options.timePos.timeTop || 0) * this.options.$game.fObj.scale,
    });
    this.renderSprite(timeObj);
  },
  renderScore: function (score = 0) {
    // 1.判断是否渲染了分数背景图，如果没有，则渲染
    if (!this.scoreBgSprite && !!this.options.scorePos.src) {
      // 渲染背景底图
      let scoreBgObj = Object.assign({}, {
        type: "score",
        isBg: true,
        src: this.options.scorePos.src,
        width: this.options.scorePos.width,
        height: this.options.scorePos.height,
        x: this.options.scorePos.left * this.options.$game.fObj.scale,
        y: this.options.scorePos.top * this.options.$game.fObj.scale,
      });
      this.renderSprite(scoreBgObj);
    }
    // 2.隐藏已显示的分数
    this.hideSpriteArrFun("scoreSpriteArr");
    // 3.渲染分数
    let scoreArr = (score + "").split("");
    scoreArr.forEach((num, index) => {
      let numArr = this.options.scorePos.numArr || [];
      // 渲染分数
      let scoreBgObj = Object.assign({}, numArr[num], {
        type: "score",
        x: ((this.options.scorePos.scoreRight || 0) - numArr[num].width * ((scoreArr.length - index) + 1)) * this.options.$game.fObj.scale,
        y: (this.options.scorePos.scoreTop || 0) * this.options.$game.fObj.scale,
      });
      this.renderSprite(scoreBgObj);
    });
  },
  tickerStart() {
    this.tickerStop();
    this.tickerStar();
  },
  tickerStar() {
    let _this = this;
    this.tickerStopStatus = false;
    this.ticker.stop();
    this.ticker.start();
    /* function ani() {
      _this.moveXFun();
      _this.moveYFun();

      if (!_this.tickerStopStatus) {
        _this.req = _this.options.$game.fObj.pixiCanvas.requestAnimationFrame(ani)
      }
    }

    ani(); */
  },
  tickerStop() {
    // this.ticker.stop();
    this.tickerStopStatus = true;
    /* this.options.$game.fObj.pixiCanvas.cancelAnimationFrame(this.req) */
  },
  renderRowCol(arr) {
    // 生成坐标
    let notArr = [];
    try {
      if (arr.length > 0) {
        notArr = arr;
      }
    } catch (e) { }
    let bl = false;
    let tempRow, tempCol;
    do {
      bl = false;
      tempRow = this.random({ max: this.options.rowNum });
      tempCol = this.random({ max: this.options.colNum });

      notArr.forEach(item => {
        if (item.row == tempRow && item.col == tempCol) {
          bl = true;
        }
      })
    } while (!!bl);

    return { row: tempRow, col: tempCol };
  },
})
// 刷新页面布局
Game.prototype.refresh = function () {
  let refreshBl = false;
  if (!this.iStop && this.fsm == "A") {
    // 刷新
    refreshBl = true;
    if (!!this.selectAnimateSprite) {
      this.selectAnimateSprite.visible = false;
    }
    let notArr = [];
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        let pos = this.renderRowCol(notArr);
        notArr.push(pos);

        sprite.imgObj.row = pos.row;
        sprite.imgObj.col = pos.col;
        sprite.x = pos.col * this.spriteW + this.padding.left + (this.spriteW - sprite.width) / 2;
        sprite.y = pos.row * this.spriteH + this.padding.top + (this.spriteH - sprite.height) / 2;
      }
    })
    this.fsm = "B";
    this.writeClearStatus = true;

    let over = false;
    // 此处判断游戏逻辑，可减游戏步数===========
    if (this.options.gamePlayType == "steps") {
      // 是用步数判断游戏状态
      this.curSteps--;
      if (this.curSteps <= 0) {
        this.iStop = true;
        over = true;
      }

      this.over = over;
    }

    this.draw();

    if (this.fadeArr.length > 0) {
      // 有消除
    } else {
    }
  }

  this.options.refreshFun(refreshBl);
}
// 全消
Game.prototype.clear = function () {
  if (!this.iStop && this.fsm == "A") {
    this.fsm = "B";
    this.writeClearStatus = true;
    this.draw("clear");
  } else {
    // console.log("游戏未开始...")
  }
}
// 游戏结束
Game.prototype.gameOver = function () {
  this.iStop = true;
  clearInterval(this.timerInterval);

  try {
    this.options.overFun(this.totalScore);
  } catch (e) { }
}
// 重置游戏
Game.prototype.reset = function () {
  this.touchEndFun();
  this.changeDoneObj = null;
  // 1.隐藏元素
  this.hideSpriteArrFun("spriteArr");
  // 3.重新生成新元素
  this.init();
}
Game.prototype.startGame = function () {
  this.touchEndFun();
  this.changeDoneObj = null;
  this.iStop = false;
  this.overSprite = null;
  this.hideSpriteArrFun("animateSpriteArr");

  this.tickerStart();

  if (this.options.gamePlayType == "time") {
    if (!!this.options.timePos) {
      this.timerInterval = setInterval(() => {
        this.curTime--;
        if (this.curTime >= 0) {
          this.renderTime(this.curTime);
        } else {
          // 游戏结束
          this.gameOver();
        }
      }, 1000);
    }
  }
}

export {
  Game
}