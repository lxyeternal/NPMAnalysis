# ur-game

# 消消乐小游戏

##### 安装

```
npm install ur-game
```

##### 使用

- app.json
```
必须开启 "enableSkia": "true"
```
```
```

- json

```
{
    "usingComponents": {
        "ur-game": "ur-game/ur-game"
    }
}
```

- js

```
Page({
  data: {
    dis: true,
    gameSteps: 3,
    gameSource: {
      // 游戏元素
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01VqbWkw1FJvdew0LOv_!!1080040467.png",
          val: 10,
          width: 118,
          height: 118,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomArr: [
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RDQSUE1FJvdeQOQD9_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01rrBKhO1FJvdi20pVo_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01owOUdk1FJvdfuz1IS_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014Qt0Q51FJvdhRSuMU_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01t6aZMz1FJvdgbwBC3_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PY9YAA1FJvdX88ZYo_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01bKH9J91FJvdcEIxcZ_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PlhBrz1FJvdZ2rawE_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019vRDli1FJvdhRUFWR_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01QKODzL1FJvdeuoMfF_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019nFDEj1FJvdb2xKZf_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01lOsZaq1FJvdeuoUzN_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01NF6heY1FJvdZ2rG9U_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01q9qBW51FJvdfuyLhZ_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01e7H6EZ1FJvdcV58w0_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01I9uHal1FJvdb2uB9l_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jj8YbE1FJvdeQRRJP_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01k5zTae1FJvdfuwXTS_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01uny0hw1FJvdb2vNzM_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Uk6Gme1FJvdeQP5oI_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Rw08S61FJvdX89e6H_!!1080040467.png", width: 118, height: 118 },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01A7nZUu1FJvdZ4Cdgk_!!1080040467.png",
          val: 10,
          width: 118,
          height: 118,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomArr: [
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ns7rcu1FJvdbVes0i_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01vYUWoQ1FJvdSOtRMA_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01kMpn661FJvdX87Qpw_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tdgSTC1FJvdeuplxR_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014XSA0Y1FJvdbVbv3L_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01IkNARd1FJvdi1zcfV_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01chXw4P1FJvdgbweHU_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PFIiKd1FJvdcEKZP5_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01LZxiPR1FJvdhRTF7j_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jqrrA91FJvdcV4sGe_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XQhdtb1FJvdcEIMCV_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JOH0lp1FJvdYTR1LK_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RjLyEY1FJvdYTQ0xF_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012gpzOS1FJvdZ2p74H_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jufwZ01FJvdX8AFTV_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aP3ArM1FJvdhRTAz4_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PlNpBf1FJvdcEKyMQ_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wAhOyA1FJvdSOtqKE_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jFFjsT1FJvdbVcvRa_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01C0bHUN1FJvdcV5c2Q_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01NJsYNS1FJvdaz5Olc_!!1080040467.png", width: 118, height: 118 },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cvb2LB1FJvdew0HF0_!!1080040467.png",
          val: 10,
          width: 118,
          height: 118,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomArr: [
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PEryVQ1FJvdbVd7ru_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tCEFEj1FJvdYTNnjG_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016IDQ9u1FJvdfux4eL_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01doi8U91FJvdaz4app_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01DMkSH91FJvdcV1myV_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ozAAez1FJvdbVenpY_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01uiWl1y1FJvdhRUBK8_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN016VcO9K1FJvdeupRA8_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01eU2ZRW1FJvdbVdGCY_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01N0GIht1FJvdcV23cs_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mL3oC01FJvdZ2puwn_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01icZyra1FJvdeuoA9p_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01rolrIl1FJvdZ2rzph_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01NUJsNv1FJvdbVdGCp_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Jf8dLE1FJvdeQPxoe_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01fLWn2S1FJvddduLF6_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RWv1qS1FJvdi21EQr_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01lZqvDp1FJvdcEHU84_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01gqUd6W1FJvdYTQU36_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jKhtxj1FJvdX8761c_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01QKnTWM1FJvdbVczZX_!!1080040467.png", width: 118, height: 118 },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01QZNfJV1FJvdfwD5RW_!!1080040467.png",
          val: 10,
          width: 118,
          height: 118,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomArr: [
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01T4VuSx1FJvdbVciur_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01fq4qeE1FJvdcV40AY_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01b8mUuU1FJvdhRSlxm_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01yxlV621FJvdSOumUi_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0125tvSf1FJvdX86Dxc_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01jtUGPl1FJvdeunI69_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01T6jWUQ1FJvdZ2rf1n_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN010jGHEY1FJvdaz4nJ5_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01DdqMuS1FJvdaz608q_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01sHvmIt1FJvdeuqF1q_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01s4ntaN1FJvdcEKlrA_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01j7pEOM1FJvdbVb2wt_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN013BvDBF1FJvdbVcO8c_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bHyZ2m1FJvdhRRtxT_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016M8msR1FJvdYTQcLR_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DLiwik1FJvdhRSq92_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01LUwbTv1FJvdX86Ykh_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01lYzfap1FJvdeuoy28_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01CvEKdQ1FJvdi1z1EY_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01xbIC4j1FJvdgbw2pB_!!1080040467.png", width: 118, height: 118 },
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01R7Cb6u1FJvddduTWH_!!1080040467.png", width: 118, height: 118 },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
          audioName: "default"
        }
      ],
      // 选中动画 序列帧
      selectAnimateSpeed: 0.5,
      selectAnimate: [
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01u7YlXw1FJvdfx32qE_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Ikbvge1FJvdi3vvZI_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01A2bZ9W1FJvdZ51C22_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01fB5ASo1FJvdb18cK8_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01MQ1Kgy1FJvdeSIJIv_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AFXaaW1FJvdi3ysXW_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01L31pbY1FJvdZ52w8M_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0168hogl1FJvdi3x8Q6_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01f1UgPN1FJvdSQwWXd_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pLn5kW1FJvdgdu5tf_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01MlMvE41FJvdcX1qqZ_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01GTcIi11FJvdcGQ0T6_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xCup0f1FJvdb1584v_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bhl4em1FJvdeSJv95_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01H964QZ1FJvdewphXO_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01jcj0KE1FJvdcX1W55_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ArKDsr1FJvdSQxjP6_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ldOUAk1FJvdb18x7n_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01INPOa61FJvdgdu1kh_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01UWtxyB1FJvdcX2vPO_!!1080040467.png", width: 118, height: 118 },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01liCGjs1FJvddg1zSq_!!1080040467.png", width: 118, height: 118 },
      ],
      padding: {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0
      }
    },
    audioObj: {
      default: { src: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/md0TVJ9FNFauX46iy5H?auth_key=1600418297-0-0-abfad5e2fa6d2a568be518189562d827" },//默认音效
    },
  },
  onLoad() { },
  onRef(game) {
    this.game = game;
  },
  beginFun() {
    my.alert({
      content: "游戏开始"
    })
    this.game.start();
  },
  resetFun() {
    this.game.reset();
  },
  refreshFun() {
    this.game.refresh();
  },

  onFinish() {
    my.alert({
      content: "游戏结束"
    })
  },
  onInitDone() {
    my.alert({
      content: "游戏初始化完成"
    })
  },
  onUpdate(item) {
    // {curScore,totalScore,curSteps}
    this.setData({
      curSteps: item.curSteps,
      totalScore: item.totalScore,
      curScore: item.curScore
    })
    // my.alert({
    //   content: "游戏消除了"
    // })
  }
});
```

- xaml

```
  <!-- 110
      gameSource:游戏资源
      gameSteps:游戏步数（游戏步数和倒计时是二选一，如果都传了，则取游戏步数）
      rowNum:行数
      colNum:列数
      audio:游戏音效地址
      gameStartPlayAudio:游戏进行中才播放音效 默认false：游戏渲染了消除就播放 true：游戏开始后消除才播放
      onInitDone:游戏渲染完回调 
      onUpdate:游戏消除回调
      onFinish:游戏结束回调
    -->
  <game 
    gameSource="{{gameSource}}"
    gameSteps="{{gameSteps}}"
    colNum="{{5}}"
    rowNum="{{7}}"
    audio="{{audioObj}}"
    spriteShowAll="{{true}}"
    gameStartPlayAudio="{{!true}}"
    onRef="onRef"
    onInitDone="onInitDone" 
    onUpdate="onUpdate" 
    onFinish="onFinish" 
    />
```