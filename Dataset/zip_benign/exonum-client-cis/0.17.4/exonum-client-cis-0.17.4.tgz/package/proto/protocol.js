/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
(function(global, factory) { /* global define, require, module */

    /* AMD */ if (typeof define === 'function' && define.amd)
        define(["protobufjs/minimal"], factory);

    /* CommonJS */ else if (typeof require === 'function' && typeof module === 'object' && module && module.exports)
        module.exports = factory(require("protobufjs/minimal"));

})(this, function($protobuf) {
    "use strict";

    // Common aliases
    var $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;
    
    // Exported root namespace
    var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});
    
    $root.exonum = (function() {
    
        /**
         * Namespace exonum.
         * @exports exonum
         * @namespace
         */
        var exonum = {};
    
        exonum.crypto = (function() {
    
            /**
             * Namespace crypto.
             * @memberof exonum
             * @namespace
             */
            var crypto = {};
    
            crypto.Hash = (function() {
    
                /**
                 * Properties of a Hash.
                 * @memberof exonum.crypto
                 * @interface IHash
                 * @property {Uint8Array|null} [data] Hash data
                 */
    
                /**
                 * Constructs a new Hash.
                 * @memberof exonum.crypto
                 * @classdesc Represents a Hash.
                 * @implements IHash
                 * @constructor
                 * @param {exonum.crypto.IHash=} [properties] Properties to set
                 */
                function Hash(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Hash data.
                 * @member {Uint8Array} data
                 * @memberof exonum.crypto.Hash
                 * @instance
                 */
                Hash.prototype.data = $util.newBuffer([]);
    
                /**
                 * Creates a new Hash instance using the specified properties.
                 * @function create
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {exonum.crypto.IHash=} [properties] Properties to set
                 * @returns {exonum.crypto.Hash} Hash instance
                 */
                Hash.create = function create(properties) {
                    return new Hash(properties);
                };
    
                /**
                 * Encodes the specified Hash message. Does not implicitly {@link exonum.crypto.Hash.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {exonum.crypto.IHash} message Hash message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Hash.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.data != null && message.hasOwnProperty("data"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.data);
                    return writer;
                };
    
                /**
                 * Encodes the specified Hash message, length delimited. Does not implicitly {@link exonum.crypto.Hash.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {exonum.crypto.IHash} message Hash message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Hash.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Hash message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.crypto.Hash} Hash
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Hash.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.crypto.Hash();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.data = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Hash message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.crypto.Hash} Hash
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Hash.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Hash message.
                 * @function verify
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Hash.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.data != null && message.hasOwnProperty("data"))
                        if (!(message.data && typeof message.data.length === "number" || $util.isString(message.data)))
                            return "data: buffer expected";
                    return null;
                };
    
                /**
                 * Creates a Hash message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.crypto.Hash} Hash
                 */
                Hash.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.crypto.Hash)
                        return object;
                    var message = new $root.exonum.crypto.Hash();
                    if (object.data != null)
                        if (typeof object.data === "string")
                            $util.base64.decode(object.data, message.data = $util.newBuffer($util.base64.length(object.data)), 0);
                        else if (object.data.length)
                            message.data = object.data;
                    return message;
                };
    
                /**
                 * Creates a plain object from a Hash message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.crypto.Hash
                 * @static
                 * @param {exonum.crypto.Hash} message Hash
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Hash.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults)
                        if (options.bytes === String)
                            object.data = "";
                        else {
                            object.data = [];
                            if (options.bytes !== Array)
                                object.data = $util.newBuffer(object.data);
                        }
                    if (message.data != null && message.hasOwnProperty("data"))
                        object.data = options.bytes === String ? $util.base64.encode(message.data, 0, message.data.length) : options.bytes === Array ? Array.prototype.slice.call(message.data) : message.data;
                    return object;
                };
    
                /**
                 * Converts this Hash to JSON.
                 * @function toJSON
                 * @memberof exonum.crypto.Hash
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Hash.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Hash;
            })();
    
            crypto.PublicKey = (function() {
    
                /**
                 * Properties of a PublicKey.
                 * @memberof exonum.crypto
                 * @interface IPublicKey
                 * @property {Uint8Array|null} [data] PublicKey data
                 */
    
                /**
                 * Constructs a new PublicKey.
                 * @memberof exonum.crypto
                 * @classdesc Represents a PublicKey.
                 * @implements IPublicKey
                 * @constructor
                 * @param {exonum.crypto.IPublicKey=} [properties] Properties to set
                 */
                function PublicKey(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * PublicKey data.
                 * @member {Uint8Array} data
                 * @memberof exonum.crypto.PublicKey
                 * @instance
                 */
                PublicKey.prototype.data = $util.newBuffer([]);
    
                /**
                 * Creates a new PublicKey instance using the specified properties.
                 * @function create
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {exonum.crypto.IPublicKey=} [properties] Properties to set
                 * @returns {exonum.crypto.PublicKey} PublicKey instance
                 */
                PublicKey.create = function create(properties) {
                    return new PublicKey(properties);
                };
    
                /**
                 * Encodes the specified PublicKey message. Does not implicitly {@link exonum.crypto.PublicKey.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {exonum.crypto.IPublicKey} message PublicKey message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PublicKey.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.data != null && message.hasOwnProperty("data"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.data);
                    return writer;
                };
    
                /**
                 * Encodes the specified PublicKey message, length delimited. Does not implicitly {@link exonum.crypto.PublicKey.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {exonum.crypto.IPublicKey} message PublicKey message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PublicKey.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a PublicKey message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.crypto.PublicKey} PublicKey
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PublicKey.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.crypto.PublicKey();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.data = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a PublicKey message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.crypto.PublicKey} PublicKey
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PublicKey.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a PublicKey message.
                 * @function verify
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                PublicKey.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.data != null && message.hasOwnProperty("data"))
                        if (!(message.data && typeof message.data.length === "number" || $util.isString(message.data)))
                            return "data: buffer expected";
                    return null;
                };
    
                /**
                 * Creates a PublicKey message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.crypto.PublicKey} PublicKey
                 */
                PublicKey.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.crypto.PublicKey)
                        return object;
                    var message = new $root.exonum.crypto.PublicKey();
                    if (object.data != null)
                        if (typeof object.data === "string")
                            $util.base64.decode(object.data, message.data = $util.newBuffer($util.base64.length(object.data)), 0);
                        else if (object.data.length)
                            message.data = object.data;
                    return message;
                };
    
                /**
                 * Creates a plain object from a PublicKey message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.crypto.PublicKey
                 * @static
                 * @param {exonum.crypto.PublicKey} message PublicKey
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                PublicKey.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults)
                        if (options.bytes === String)
                            object.data = "";
                        else {
                            object.data = [];
                            if (options.bytes !== Array)
                                object.data = $util.newBuffer(object.data);
                        }
                    if (message.data != null && message.hasOwnProperty("data"))
                        object.data = options.bytes === String ? $util.base64.encode(message.data, 0, message.data.length) : options.bytes === Array ? Array.prototype.slice.call(message.data) : message.data;
                    return object;
                };
    
                /**
                 * Converts this PublicKey to JSON.
                 * @function toJSON
                 * @memberof exonum.crypto.PublicKey
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                PublicKey.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return PublicKey;
            })();
    
            crypto.Signature = (function() {
    
                /**
                 * Properties of a Signature.
                 * @memberof exonum.crypto
                 * @interface ISignature
                 * @property {Uint8Array|null} [data] Signature data
                 */
    
                /**
                 * Constructs a new Signature.
                 * @memberof exonum.crypto
                 * @classdesc Represents a Signature.
                 * @implements ISignature
                 * @constructor
                 * @param {exonum.crypto.ISignature=} [properties] Properties to set
                 */
                function Signature(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Signature data.
                 * @member {Uint8Array} data
                 * @memberof exonum.crypto.Signature
                 * @instance
                 */
                Signature.prototype.data = $util.newBuffer([]);
    
                /**
                 * Creates a new Signature instance using the specified properties.
                 * @function create
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {exonum.crypto.ISignature=} [properties] Properties to set
                 * @returns {exonum.crypto.Signature} Signature instance
                 */
                Signature.create = function create(properties) {
                    return new Signature(properties);
                };
    
                /**
                 * Encodes the specified Signature message. Does not implicitly {@link exonum.crypto.Signature.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {exonum.crypto.ISignature} message Signature message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Signature.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.data != null && message.hasOwnProperty("data"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.data);
                    return writer;
                };
    
                /**
                 * Encodes the specified Signature message, length delimited. Does not implicitly {@link exonum.crypto.Signature.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {exonum.crypto.ISignature} message Signature message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Signature.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Signature message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.crypto.Signature} Signature
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Signature.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.crypto.Signature();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.data = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Signature message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.crypto.Signature} Signature
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Signature.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Signature message.
                 * @function verify
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Signature.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.data != null && message.hasOwnProperty("data"))
                        if (!(message.data && typeof message.data.length === "number" || $util.isString(message.data)))
                            return "data: buffer expected";
                    return null;
                };
    
                /**
                 * Creates a Signature message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.crypto.Signature} Signature
                 */
                Signature.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.crypto.Signature)
                        return object;
                    var message = new $root.exonum.crypto.Signature();
                    if (object.data != null)
                        if (typeof object.data === "string")
                            $util.base64.decode(object.data, message.data = $util.newBuffer($util.base64.length(object.data)), 0);
                        else if (object.data.length)
                            message.data = object.data;
                    return message;
                };
    
                /**
                 * Creates a plain object from a Signature message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.crypto.Signature
                 * @static
                 * @param {exonum.crypto.Signature} message Signature
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Signature.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults)
                        if (options.bytes === String)
                            object.data = "";
                        else {
                            object.data = [];
                            if (options.bytes !== Array)
                                object.data = $util.newBuffer(object.data);
                        }
                    if (message.data != null && message.hasOwnProperty("data"))
                        object.data = options.bytes === String ? $util.base64.encode(message.data, 0, message.data.length) : options.bytes === Array ? Array.prototype.slice.call(message.data) : message.data;
                    return object;
                };
    
                /**
                 * Converts this Signature to JSON.
                 * @function toJSON
                 * @memberof exonum.crypto.Signature
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Signature.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Signature;
            })();
    
            return crypto;
        })();
    
        exonum.Block = (function() {
    
            /**
             * Properties of a Block.
             * @memberof exonum
             * @interface IBlock
             * @property {number|Long|null} [chain_id] Block chain_id
             * @property {number|null} [proposer_id] Block proposer_id
             * @property {number|Long|null} [height] Block height
             * @property {number|null} [tx_count] Block tx_count
             * @property {exonum.crypto.IHash|null} [prev_hash] Block prev_hash
             * @property {exonum.crypto.IHash|null} [tx_hash] Block tx_hash
             * @property {exonum.crypto.IHash|null} [state_hash] Block state_hash
             */
    
            /**
             * Constructs a new Block.
             * @memberof exonum
             * @classdesc Represents a Block.
             * @implements IBlock
             * @constructor
             * @param {exonum.IBlock=} [properties] Properties to set
             */
            function Block(properties) {
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * Block chain_id.
             * @member {number|Long} chain_id
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.chain_id = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Block proposer_id.
             * @member {number} proposer_id
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.proposer_id = 0;
    
            /**
             * Block height.
             * @member {number|Long} height
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Block tx_count.
             * @member {number} tx_count
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.tx_count = 0;
    
            /**
             * Block prev_hash.
             * @member {exonum.crypto.IHash|null|undefined} prev_hash
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.prev_hash = null;
    
            /**
             * Block tx_hash.
             * @member {exonum.crypto.IHash|null|undefined} tx_hash
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.tx_hash = null;
    
            /**
             * Block state_hash.
             * @member {exonum.crypto.IHash|null|undefined} state_hash
             * @memberof exonum.Block
             * @instance
             */
            Block.prototype.state_hash = null;
    
            /**
             * Creates a new Block instance using the specified properties.
             * @function create
             * @memberof exonum.Block
             * @static
             * @param {exonum.IBlock=} [properties] Properties to set
             * @returns {exonum.Block} Block instance
             */
            Block.create = function create(properties) {
                return new Block(properties);
            };
    
            /**
             * Encodes the specified Block message. Does not implicitly {@link exonum.Block.verify|verify} messages.
             * @function encode
             * @memberof exonum.Block
             * @static
             * @param {exonum.IBlock} message Block message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            Block.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.proposer_id != null && message.hasOwnProperty("proposer_id"))
                    writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.proposer_id);
                if (message.height != null && message.hasOwnProperty("height"))
                    writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                if (message.tx_count != null && message.hasOwnProperty("tx_count"))
                    writer.uint32(/* id 3, wireType 0 =*/24).uint32(message.tx_count);
                if (message.prev_hash != null && message.hasOwnProperty("prev_hash"))
                    $root.exonum.crypto.Hash.encode(message.prev_hash, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                if (message.tx_hash != null && message.hasOwnProperty("tx_hash"))
                    $root.exonum.crypto.Hash.encode(message.tx_hash, writer.uint32(/* id 5, wireType 2 =*/42).fork()).ldelim();
                if (message.state_hash != null && message.hasOwnProperty("state_hash"))
                    $root.exonum.crypto.Hash.encode(message.state_hash, writer.uint32(/* id 6, wireType 2 =*/50).fork()).ldelim();
                if (message.chain_id != null && message.hasOwnProperty("chain_id"))
                    writer.uint32(/* id 7, wireType 0 =*/56).uint64(message.chain_id);
                return writer;
            };
    
            /**
             * Encodes the specified Block message, length delimited. Does not implicitly {@link exonum.Block.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.Block
             * @static
             * @param {exonum.IBlock} message Block message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            Block.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes a Block message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.Block
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.Block} Block
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            Block.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.Block();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 7:
                        message.chain_id = reader.uint64();
                        break;
                    case 1:
                        message.proposer_id = reader.uint32();
                        break;
                    case 2:
                        message.height = reader.uint64();
                        break;
                    case 3:
                        message.tx_count = reader.uint32();
                        break;
                    case 4:
                        message.prev_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                        break;
                    case 5:
                        message.tx_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                        break;
                    case 6:
                        message.state_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes a Block message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.Block
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.Block} Block
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            Block.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies a Block message.
             * @function verify
             * @memberof exonum.Block
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            Block.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.chain_id != null && message.hasOwnProperty("chain_id"))
                    if (!$util.isInteger(message.chain_id) && !(message.chain_id && $util.isInteger(message.chain_id.low) && $util.isInteger(message.chain_id.high)))
                        return "chain_id: integer|Long expected";
                if (message.proposer_id != null && message.hasOwnProperty("proposer_id"))
                    if (!$util.isInteger(message.proposer_id))
                        return "proposer_id: integer expected";
                if (message.height != null && message.hasOwnProperty("height"))
                    if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                        return "height: integer|Long expected";
                if (message.tx_count != null && message.hasOwnProperty("tx_count"))
                    if (!$util.isInteger(message.tx_count))
                        return "tx_count: integer expected";
                if (message.prev_hash != null && message.hasOwnProperty("prev_hash")) {
                    var error = $root.exonum.crypto.Hash.verify(message.prev_hash);
                    if (error)
                        return "prev_hash." + error;
                }
                if (message.tx_hash != null && message.hasOwnProperty("tx_hash")) {
                    var error = $root.exonum.crypto.Hash.verify(message.tx_hash);
                    if (error)
                        return "tx_hash." + error;
                }
                if (message.state_hash != null && message.hasOwnProperty("state_hash")) {
                    var error = $root.exonum.crypto.Hash.verify(message.state_hash);
                    if (error)
                        return "state_hash." + error;
                }
                return null;
            };
    
            /**
             * Creates a Block message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.Block
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.Block} Block
             */
            Block.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.Block)
                    return object;
                var message = new $root.exonum.Block();
                if (object.chain_id != null)
                    if ($util.Long)
                        (message.chain_id = $util.Long.fromValue(object.chain_id)).unsigned = true;
                    else if (typeof object.chain_id === "string")
                        message.chain_id = parseInt(object.chain_id, 10);
                    else if (typeof object.chain_id === "number")
                        message.chain_id = object.chain_id;
                    else if (typeof object.chain_id === "object")
                        message.chain_id = new $util.LongBits(object.chain_id.low >>> 0, object.chain_id.high >>> 0).toNumber(true);
                if (object.proposer_id != null)
                    message.proposer_id = object.proposer_id >>> 0;
                if (object.height != null)
                    if ($util.Long)
                        (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                    else if (typeof object.height === "string")
                        message.height = parseInt(object.height, 10);
                    else if (typeof object.height === "number")
                        message.height = object.height;
                    else if (typeof object.height === "object")
                        message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                if (object.tx_count != null)
                    message.tx_count = object.tx_count >>> 0;
                if (object.prev_hash != null) {
                    if (typeof object.prev_hash !== "object")
                        throw TypeError(".exonum.Block.prev_hash: object expected");
                    message.prev_hash = $root.exonum.crypto.Hash.fromObject(object.prev_hash);
                }
                if (object.tx_hash != null) {
                    if (typeof object.tx_hash !== "object")
                        throw TypeError(".exonum.Block.tx_hash: object expected");
                    message.tx_hash = $root.exonum.crypto.Hash.fromObject(object.tx_hash);
                }
                if (object.state_hash != null) {
                    if (typeof object.state_hash !== "object")
                        throw TypeError(".exonum.Block.state_hash: object expected");
                    message.state_hash = $root.exonum.crypto.Hash.fromObject(object.state_hash);
                }
                return message;
            };
    
            /**
             * Creates a plain object from a Block message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.Block
             * @static
             * @param {exonum.Block} message Block
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            Block.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.defaults) {
                    object.proposer_id = 0;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.height = options.longs === String ? "0" : 0;
                    object.tx_count = 0;
                    object.prev_hash = null;
                    object.tx_hash = null;
                    object.state_hash = null;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.chain_id = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.chain_id = options.longs === String ? "0" : 0;
                }
                if (message.proposer_id != null && message.hasOwnProperty("proposer_id"))
                    object.proposer_id = message.proposer_id;
                if (message.height != null && message.hasOwnProperty("height"))
                    if (typeof message.height === "number")
                        object.height = options.longs === String ? String(message.height) : message.height;
                    else
                        object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                if (message.tx_count != null && message.hasOwnProperty("tx_count"))
                    object.tx_count = message.tx_count;
                if (message.prev_hash != null && message.hasOwnProperty("prev_hash"))
                    object.prev_hash = $root.exonum.crypto.Hash.toObject(message.prev_hash, options);
                if (message.tx_hash != null && message.hasOwnProperty("tx_hash"))
                    object.tx_hash = $root.exonum.crypto.Hash.toObject(message.tx_hash, options);
                if (message.state_hash != null && message.hasOwnProperty("state_hash"))
                    object.state_hash = $root.exonum.crypto.Hash.toObject(message.state_hash, options);
                if (message.chain_id != null && message.hasOwnProperty("chain_id"))
                    if (typeof message.chain_id === "number")
                        object.chain_id = options.longs === String ? String(message.chain_id) : message.chain_id;
                    else
                        object.chain_id = options.longs === String ? $util.Long.prototype.toString.call(message.chain_id) : options.longs === Number ? new $util.LongBits(message.chain_id.low >>> 0, message.chain_id.high >>> 0).toNumber(true) : message.chain_id;
                return object;
            };
    
            /**
             * Converts this Block to JSON.
             * @function toJSON
             * @memberof exonum.Block
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            Block.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return Block;
        })();
    
        exonum.TxLocation = (function() {
    
            /**
             * Properties of a TxLocation.
             * @memberof exonum
             * @interface ITxLocation
             * @property {number|Long|null} [block_height] TxLocation block_height
             * @property {number|Long|null} [position_in_block] TxLocation position_in_block
             */
    
            /**
             * Constructs a new TxLocation.
             * @memberof exonum
             * @classdesc Represents a TxLocation.
             * @implements ITxLocation
             * @constructor
             * @param {exonum.ITxLocation=} [properties] Properties to set
             */
            function TxLocation(properties) {
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * TxLocation block_height.
             * @member {number|Long} block_height
             * @memberof exonum.TxLocation
             * @instance
             */
            TxLocation.prototype.block_height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * TxLocation position_in_block.
             * @member {number|Long} position_in_block
             * @memberof exonum.TxLocation
             * @instance
             */
            TxLocation.prototype.position_in_block = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Creates a new TxLocation instance using the specified properties.
             * @function create
             * @memberof exonum.TxLocation
             * @static
             * @param {exonum.ITxLocation=} [properties] Properties to set
             * @returns {exonum.TxLocation} TxLocation instance
             */
            TxLocation.create = function create(properties) {
                return new TxLocation(properties);
            };
    
            /**
             * Encodes the specified TxLocation message. Does not implicitly {@link exonum.TxLocation.verify|verify} messages.
             * @function encode
             * @memberof exonum.TxLocation
             * @static
             * @param {exonum.ITxLocation} message TxLocation message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            TxLocation.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.block_height != null && message.hasOwnProperty("block_height"))
                    writer.uint32(/* id 1, wireType 0 =*/8).uint64(message.block_height);
                if (message.position_in_block != null && message.hasOwnProperty("position_in_block"))
                    writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.position_in_block);
                return writer;
            };
    
            /**
             * Encodes the specified TxLocation message, length delimited. Does not implicitly {@link exonum.TxLocation.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.TxLocation
             * @static
             * @param {exonum.ITxLocation} message TxLocation message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            TxLocation.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes a TxLocation message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.TxLocation
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.TxLocation} TxLocation
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            TxLocation.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.TxLocation();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 1:
                        message.block_height = reader.uint64();
                        break;
                    case 2:
                        message.position_in_block = reader.uint64();
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes a TxLocation message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.TxLocation
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.TxLocation} TxLocation
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            TxLocation.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies a TxLocation message.
             * @function verify
             * @memberof exonum.TxLocation
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            TxLocation.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.block_height != null && message.hasOwnProperty("block_height"))
                    if (!$util.isInteger(message.block_height) && !(message.block_height && $util.isInteger(message.block_height.low) && $util.isInteger(message.block_height.high)))
                        return "block_height: integer|Long expected";
                if (message.position_in_block != null && message.hasOwnProperty("position_in_block"))
                    if (!$util.isInteger(message.position_in_block) && !(message.position_in_block && $util.isInteger(message.position_in_block.low) && $util.isInteger(message.position_in_block.high)))
                        return "position_in_block: integer|Long expected";
                return null;
            };
    
            /**
             * Creates a TxLocation message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.TxLocation
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.TxLocation} TxLocation
             */
            TxLocation.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.TxLocation)
                    return object;
                var message = new $root.exonum.TxLocation();
                if (object.block_height != null)
                    if ($util.Long)
                        (message.block_height = $util.Long.fromValue(object.block_height)).unsigned = true;
                    else if (typeof object.block_height === "string")
                        message.block_height = parseInt(object.block_height, 10);
                    else if (typeof object.block_height === "number")
                        message.block_height = object.block_height;
                    else if (typeof object.block_height === "object")
                        message.block_height = new $util.LongBits(object.block_height.low >>> 0, object.block_height.high >>> 0).toNumber(true);
                if (object.position_in_block != null)
                    if ($util.Long)
                        (message.position_in_block = $util.Long.fromValue(object.position_in_block)).unsigned = true;
                    else if (typeof object.position_in_block === "string")
                        message.position_in_block = parseInt(object.position_in_block, 10);
                    else if (typeof object.position_in_block === "number")
                        message.position_in_block = object.position_in_block;
                    else if (typeof object.position_in_block === "object")
                        message.position_in_block = new $util.LongBits(object.position_in_block.low >>> 0, object.position_in_block.high >>> 0).toNumber(true);
                return message;
            };
    
            /**
             * Creates a plain object from a TxLocation message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.TxLocation
             * @static
             * @param {exonum.TxLocation} message TxLocation
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            TxLocation.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.defaults) {
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.block_height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.block_height = options.longs === String ? "0" : 0;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.position_in_block = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.position_in_block = options.longs === String ? "0" : 0;
                }
                if (message.block_height != null && message.hasOwnProperty("block_height"))
                    if (typeof message.block_height === "number")
                        object.block_height = options.longs === String ? String(message.block_height) : message.block_height;
                    else
                        object.block_height = options.longs === String ? $util.Long.prototype.toString.call(message.block_height) : options.longs === Number ? new $util.LongBits(message.block_height.low >>> 0, message.block_height.high >>> 0).toNumber(true) : message.block_height;
                if (message.position_in_block != null && message.hasOwnProperty("position_in_block"))
                    if (typeof message.position_in_block === "number")
                        object.position_in_block = options.longs === String ? String(message.position_in_block) : message.position_in_block;
                    else
                        object.position_in_block = options.longs === String ? $util.Long.prototype.toString.call(message.position_in_block) : options.longs === Number ? new $util.LongBits(message.position_in_block.low >>> 0, message.position_in_block.high >>> 0).toNumber(true) : message.position_in_block;
                return object;
            };
    
            /**
             * Converts this TxLocation to JSON.
             * @function toJSON
             * @memberof exonum.TxLocation
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            TxLocation.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return TxLocation;
        })();
    
        exonum.ValidatorKeys = (function() {
    
            /**
             * Properties of a ValidatorKeys.
             * @memberof exonum
             * @interface IValidatorKeys
             * @property {exonum.crypto.IPublicKey|null} [consensus_key] ValidatorKeys consensus_key
             * @property {exonum.crypto.IPublicKey|null} [service_key] ValidatorKeys service_key
             */
    
            /**
             * Constructs a new ValidatorKeys.
             * @memberof exonum
             * @classdesc Represents a ValidatorKeys.
             * @implements IValidatorKeys
             * @constructor
             * @param {exonum.IValidatorKeys=} [properties] Properties to set
             */
            function ValidatorKeys(properties) {
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * ValidatorKeys consensus_key.
             * @member {exonum.crypto.IPublicKey|null|undefined} consensus_key
             * @memberof exonum.ValidatorKeys
             * @instance
             */
            ValidatorKeys.prototype.consensus_key = null;
    
            /**
             * ValidatorKeys service_key.
             * @member {exonum.crypto.IPublicKey|null|undefined} service_key
             * @memberof exonum.ValidatorKeys
             * @instance
             */
            ValidatorKeys.prototype.service_key = null;
    
            /**
             * Creates a new ValidatorKeys instance using the specified properties.
             * @function create
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {exonum.IValidatorKeys=} [properties] Properties to set
             * @returns {exonum.ValidatorKeys} ValidatorKeys instance
             */
            ValidatorKeys.create = function create(properties) {
                return new ValidatorKeys(properties);
            };
    
            /**
             * Encodes the specified ValidatorKeys message. Does not implicitly {@link exonum.ValidatorKeys.verify|verify} messages.
             * @function encode
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {exonum.IValidatorKeys} message ValidatorKeys message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            ValidatorKeys.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.consensus_key != null && message.hasOwnProperty("consensus_key"))
                    $root.exonum.crypto.PublicKey.encode(message.consensus_key, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                if (message.service_key != null && message.hasOwnProperty("service_key"))
                    $root.exonum.crypto.PublicKey.encode(message.service_key, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                return writer;
            };
    
            /**
             * Encodes the specified ValidatorKeys message, length delimited. Does not implicitly {@link exonum.ValidatorKeys.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {exonum.IValidatorKeys} message ValidatorKeys message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            ValidatorKeys.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes a ValidatorKeys message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.ValidatorKeys} ValidatorKeys
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            ValidatorKeys.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.ValidatorKeys();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 1:
                        message.consensus_key = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                        break;
                    case 2:
                        message.service_key = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes a ValidatorKeys message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.ValidatorKeys} ValidatorKeys
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            ValidatorKeys.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies a ValidatorKeys message.
             * @function verify
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            ValidatorKeys.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.consensus_key != null && message.hasOwnProperty("consensus_key")) {
                    var error = $root.exonum.crypto.PublicKey.verify(message.consensus_key);
                    if (error)
                        return "consensus_key." + error;
                }
                if (message.service_key != null && message.hasOwnProperty("service_key")) {
                    var error = $root.exonum.crypto.PublicKey.verify(message.service_key);
                    if (error)
                        return "service_key." + error;
                }
                return null;
            };
    
            /**
             * Creates a ValidatorKeys message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.ValidatorKeys} ValidatorKeys
             */
            ValidatorKeys.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.ValidatorKeys)
                    return object;
                var message = new $root.exonum.ValidatorKeys();
                if (object.consensus_key != null) {
                    if (typeof object.consensus_key !== "object")
                        throw TypeError(".exonum.ValidatorKeys.consensus_key: object expected");
                    message.consensus_key = $root.exonum.crypto.PublicKey.fromObject(object.consensus_key);
                }
                if (object.service_key != null) {
                    if (typeof object.service_key !== "object")
                        throw TypeError(".exonum.ValidatorKeys.service_key: object expected");
                    message.service_key = $root.exonum.crypto.PublicKey.fromObject(object.service_key);
                }
                return message;
            };
    
            /**
             * Creates a plain object from a ValidatorKeys message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.ValidatorKeys
             * @static
             * @param {exonum.ValidatorKeys} message ValidatorKeys
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            ValidatorKeys.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.defaults) {
                    object.consensus_key = null;
                    object.service_key = null;
                }
                if (message.consensus_key != null && message.hasOwnProperty("consensus_key"))
                    object.consensus_key = $root.exonum.crypto.PublicKey.toObject(message.consensus_key, options);
                if (message.service_key != null && message.hasOwnProperty("service_key"))
                    object.service_key = $root.exonum.crypto.PublicKey.toObject(message.service_key, options);
                return object;
            };
    
            /**
             * Converts this ValidatorKeys to JSON.
             * @function toJSON
             * @memberof exonum.ValidatorKeys
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            ValidatorKeys.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return ValidatorKeys;
        })();
    
        exonum.Config = (function() {
    
            /**
             * Properties of a Config.
             * @memberof exonum
             * @interface IConfig
             * @property {Array.<exonum.IValidatorKeys>|null} [validator_keys] Config validator_keys
             * @property {number|Long|null} [first_round_timeout] Config first_round_timeout
             * @property {number|Long|null} [status_timeout] Config status_timeout
             * @property {number|Long|null} [peers_timeout] Config peers_timeout
             * @property {number|null} [txs_block_limit] Config txs_block_limit
             * @property {number|null} [max_message_len] Config max_message_len
             * @property {number|Long|null} [min_propose_timeout] Config min_propose_timeout
             * @property {number|Long|null} [max_propose_timeout] Config max_propose_timeout
             * @property {number|null} [propose_timeout_threshold] Config propose_timeout_threshold
             */
    
            /**
             * Constructs a new Config.
             * @memberof exonum
             * @classdesc Represents a Config.
             * @implements IConfig
             * @constructor
             * @param {exonum.IConfig=} [properties] Properties to set
             */
            function Config(properties) {
                this.validator_keys = [];
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * Config validator_keys.
             * @member {Array.<exonum.IValidatorKeys>} validator_keys
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.validator_keys = $util.emptyArray;
    
            /**
             * Config first_round_timeout.
             * @member {number|Long} first_round_timeout
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.first_round_timeout = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Config status_timeout.
             * @member {number|Long} status_timeout
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.status_timeout = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Config peers_timeout.
             * @member {number|Long} peers_timeout
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.peers_timeout = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Config txs_block_limit.
             * @member {number} txs_block_limit
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.txs_block_limit = 0;
    
            /**
             * Config max_message_len.
             * @member {number} max_message_len
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.max_message_len = 0;
    
            /**
             * Config min_propose_timeout.
             * @member {number|Long} min_propose_timeout
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.min_propose_timeout = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Config max_propose_timeout.
             * @member {number|Long} max_propose_timeout
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.max_propose_timeout = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * Config propose_timeout_threshold.
             * @member {number} propose_timeout_threshold
             * @memberof exonum.Config
             * @instance
             */
            Config.prototype.propose_timeout_threshold = 0;
    
            /**
             * Creates a new Config instance using the specified properties.
             * @function create
             * @memberof exonum.Config
             * @static
             * @param {exonum.IConfig=} [properties] Properties to set
             * @returns {exonum.Config} Config instance
             */
            Config.create = function create(properties) {
                return new Config(properties);
            };
    
            /**
             * Encodes the specified Config message. Does not implicitly {@link exonum.Config.verify|verify} messages.
             * @function encode
             * @memberof exonum.Config
             * @static
             * @param {exonum.IConfig} message Config message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            Config.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.validator_keys != null && message.validator_keys.length)
                    for (var i = 0; i < message.validator_keys.length; ++i)
                        $root.exonum.ValidatorKeys.encode(message.validator_keys[i], writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                if (message.first_round_timeout != null && message.hasOwnProperty("first_round_timeout"))
                    writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.first_round_timeout);
                if (message.status_timeout != null && message.hasOwnProperty("status_timeout"))
                    writer.uint32(/* id 3, wireType 0 =*/24).uint64(message.status_timeout);
                if (message.peers_timeout != null && message.hasOwnProperty("peers_timeout"))
                    writer.uint32(/* id 4, wireType 0 =*/32).uint64(message.peers_timeout);
                if (message.txs_block_limit != null && message.hasOwnProperty("txs_block_limit"))
                    writer.uint32(/* id 5, wireType 0 =*/40).uint32(message.txs_block_limit);
                if (message.max_message_len != null && message.hasOwnProperty("max_message_len"))
                    writer.uint32(/* id 6, wireType 0 =*/48).uint32(message.max_message_len);
                if (message.min_propose_timeout != null && message.hasOwnProperty("min_propose_timeout"))
                    writer.uint32(/* id 7, wireType 0 =*/56).uint64(message.min_propose_timeout);
                if (message.max_propose_timeout != null && message.hasOwnProperty("max_propose_timeout"))
                    writer.uint32(/* id 8, wireType 0 =*/64).uint64(message.max_propose_timeout);
                if (message.propose_timeout_threshold != null && message.hasOwnProperty("propose_timeout_threshold"))
                    writer.uint32(/* id 9, wireType 0 =*/72).uint32(message.propose_timeout_threshold);
                return writer;
            };
    
            /**
             * Encodes the specified Config message, length delimited. Does not implicitly {@link exonum.Config.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.Config
             * @static
             * @param {exonum.IConfig} message Config message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            Config.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes a Config message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.Config
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.Config} Config
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            Config.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.Config();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 1:
                        if (!(message.validator_keys && message.validator_keys.length))
                            message.validator_keys = [];
                        message.validator_keys.push($root.exonum.ValidatorKeys.decode(reader, reader.uint32()));
                        break;
                    case 2:
                        message.first_round_timeout = reader.uint64();
                        break;
                    case 3:
                        message.status_timeout = reader.uint64();
                        break;
                    case 4:
                        message.peers_timeout = reader.uint64();
                        break;
                    case 5:
                        message.txs_block_limit = reader.uint32();
                        break;
                    case 6:
                        message.max_message_len = reader.uint32();
                        break;
                    case 7:
                        message.min_propose_timeout = reader.uint64();
                        break;
                    case 8:
                        message.max_propose_timeout = reader.uint64();
                        break;
                    case 9:
                        message.propose_timeout_threshold = reader.uint32();
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes a Config message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.Config
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.Config} Config
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            Config.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies a Config message.
             * @function verify
             * @memberof exonum.Config
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            Config.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.validator_keys != null && message.hasOwnProperty("validator_keys")) {
                    if (!Array.isArray(message.validator_keys))
                        return "validator_keys: array expected";
                    for (var i = 0; i < message.validator_keys.length; ++i) {
                        var error = $root.exonum.ValidatorKeys.verify(message.validator_keys[i]);
                        if (error)
                            return "validator_keys." + error;
                    }
                }
                if (message.first_round_timeout != null && message.hasOwnProperty("first_round_timeout"))
                    if (!$util.isInteger(message.first_round_timeout) && !(message.first_round_timeout && $util.isInteger(message.first_round_timeout.low) && $util.isInteger(message.first_round_timeout.high)))
                        return "first_round_timeout: integer|Long expected";
                if (message.status_timeout != null && message.hasOwnProperty("status_timeout"))
                    if (!$util.isInteger(message.status_timeout) && !(message.status_timeout && $util.isInteger(message.status_timeout.low) && $util.isInteger(message.status_timeout.high)))
                        return "status_timeout: integer|Long expected";
                if (message.peers_timeout != null && message.hasOwnProperty("peers_timeout"))
                    if (!$util.isInteger(message.peers_timeout) && !(message.peers_timeout && $util.isInteger(message.peers_timeout.low) && $util.isInteger(message.peers_timeout.high)))
                        return "peers_timeout: integer|Long expected";
                if (message.txs_block_limit != null && message.hasOwnProperty("txs_block_limit"))
                    if (!$util.isInteger(message.txs_block_limit))
                        return "txs_block_limit: integer expected";
                if (message.max_message_len != null && message.hasOwnProperty("max_message_len"))
                    if (!$util.isInteger(message.max_message_len))
                        return "max_message_len: integer expected";
                if (message.min_propose_timeout != null && message.hasOwnProperty("min_propose_timeout"))
                    if (!$util.isInteger(message.min_propose_timeout) && !(message.min_propose_timeout && $util.isInteger(message.min_propose_timeout.low) && $util.isInteger(message.min_propose_timeout.high)))
                        return "min_propose_timeout: integer|Long expected";
                if (message.max_propose_timeout != null && message.hasOwnProperty("max_propose_timeout"))
                    if (!$util.isInteger(message.max_propose_timeout) && !(message.max_propose_timeout && $util.isInteger(message.max_propose_timeout.low) && $util.isInteger(message.max_propose_timeout.high)))
                        return "max_propose_timeout: integer|Long expected";
                if (message.propose_timeout_threshold != null && message.hasOwnProperty("propose_timeout_threshold"))
                    if (!$util.isInteger(message.propose_timeout_threshold))
                        return "propose_timeout_threshold: integer expected";
                return null;
            };
    
            /**
             * Creates a Config message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.Config
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.Config} Config
             */
            Config.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.Config)
                    return object;
                var message = new $root.exonum.Config();
                if (object.validator_keys) {
                    if (!Array.isArray(object.validator_keys))
                        throw TypeError(".exonum.Config.validator_keys: array expected");
                    message.validator_keys = [];
                    for (var i = 0; i < object.validator_keys.length; ++i) {
                        if (typeof object.validator_keys[i] !== "object")
                            throw TypeError(".exonum.Config.validator_keys: object expected");
                        message.validator_keys[i] = $root.exonum.ValidatorKeys.fromObject(object.validator_keys[i]);
                    }
                }
                if (object.first_round_timeout != null)
                    if ($util.Long)
                        (message.first_round_timeout = $util.Long.fromValue(object.first_round_timeout)).unsigned = true;
                    else if (typeof object.first_round_timeout === "string")
                        message.first_round_timeout = parseInt(object.first_round_timeout, 10);
                    else if (typeof object.first_round_timeout === "number")
                        message.first_round_timeout = object.first_round_timeout;
                    else if (typeof object.first_round_timeout === "object")
                        message.first_round_timeout = new $util.LongBits(object.first_round_timeout.low >>> 0, object.first_round_timeout.high >>> 0).toNumber(true);
                if (object.status_timeout != null)
                    if ($util.Long)
                        (message.status_timeout = $util.Long.fromValue(object.status_timeout)).unsigned = true;
                    else if (typeof object.status_timeout === "string")
                        message.status_timeout = parseInt(object.status_timeout, 10);
                    else if (typeof object.status_timeout === "number")
                        message.status_timeout = object.status_timeout;
                    else if (typeof object.status_timeout === "object")
                        message.status_timeout = new $util.LongBits(object.status_timeout.low >>> 0, object.status_timeout.high >>> 0).toNumber(true);
                if (object.peers_timeout != null)
                    if ($util.Long)
                        (message.peers_timeout = $util.Long.fromValue(object.peers_timeout)).unsigned = true;
                    else if (typeof object.peers_timeout === "string")
                        message.peers_timeout = parseInt(object.peers_timeout, 10);
                    else if (typeof object.peers_timeout === "number")
                        message.peers_timeout = object.peers_timeout;
                    else if (typeof object.peers_timeout === "object")
                        message.peers_timeout = new $util.LongBits(object.peers_timeout.low >>> 0, object.peers_timeout.high >>> 0).toNumber(true);
                if (object.txs_block_limit != null)
                    message.txs_block_limit = object.txs_block_limit >>> 0;
                if (object.max_message_len != null)
                    message.max_message_len = object.max_message_len >>> 0;
                if (object.min_propose_timeout != null)
                    if ($util.Long)
                        (message.min_propose_timeout = $util.Long.fromValue(object.min_propose_timeout)).unsigned = true;
                    else if (typeof object.min_propose_timeout === "string")
                        message.min_propose_timeout = parseInt(object.min_propose_timeout, 10);
                    else if (typeof object.min_propose_timeout === "number")
                        message.min_propose_timeout = object.min_propose_timeout;
                    else if (typeof object.min_propose_timeout === "object")
                        message.min_propose_timeout = new $util.LongBits(object.min_propose_timeout.low >>> 0, object.min_propose_timeout.high >>> 0).toNumber(true);
                if (object.max_propose_timeout != null)
                    if ($util.Long)
                        (message.max_propose_timeout = $util.Long.fromValue(object.max_propose_timeout)).unsigned = true;
                    else if (typeof object.max_propose_timeout === "string")
                        message.max_propose_timeout = parseInt(object.max_propose_timeout, 10);
                    else if (typeof object.max_propose_timeout === "number")
                        message.max_propose_timeout = object.max_propose_timeout;
                    else if (typeof object.max_propose_timeout === "object")
                        message.max_propose_timeout = new $util.LongBits(object.max_propose_timeout.low >>> 0, object.max_propose_timeout.high >>> 0).toNumber(true);
                if (object.propose_timeout_threshold != null)
                    message.propose_timeout_threshold = object.propose_timeout_threshold >>> 0;
                return message;
            };
    
            /**
             * Creates a plain object from a Config message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.Config
             * @static
             * @param {exonum.Config} message Config
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            Config.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.arrays || options.defaults)
                    object.validator_keys = [];
                if (options.defaults) {
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.first_round_timeout = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.first_round_timeout = options.longs === String ? "0" : 0;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.status_timeout = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.status_timeout = options.longs === String ? "0" : 0;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.peers_timeout = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.peers_timeout = options.longs === String ? "0" : 0;
                    object.txs_block_limit = 0;
                    object.max_message_len = 0;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.min_propose_timeout = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.min_propose_timeout = options.longs === String ? "0" : 0;
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.max_propose_timeout = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.max_propose_timeout = options.longs === String ? "0" : 0;
                    object.propose_timeout_threshold = 0;
                }
                if (message.validator_keys && message.validator_keys.length) {
                    object.validator_keys = [];
                    for (var j = 0; j < message.validator_keys.length; ++j)
                        object.validator_keys[j] = $root.exonum.ValidatorKeys.toObject(message.validator_keys[j], options);
                }
                if (message.first_round_timeout != null && message.hasOwnProperty("first_round_timeout"))
                    if (typeof message.first_round_timeout === "number")
                        object.first_round_timeout = options.longs === String ? String(message.first_round_timeout) : message.first_round_timeout;
                    else
                        object.first_round_timeout = options.longs === String ? $util.Long.prototype.toString.call(message.first_round_timeout) : options.longs === Number ? new $util.LongBits(message.first_round_timeout.low >>> 0, message.first_round_timeout.high >>> 0).toNumber(true) : message.first_round_timeout;
                if (message.status_timeout != null && message.hasOwnProperty("status_timeout"))
                    if (typeof message.status_timeout === "number")
                        object.status_timeout = options.longs === String ? String(message.status_timeout) : message.status_timeout;
                    else
                        object.status_timeout = options.longs === String ? $util.Long.prototype.toString.call(message.status_timeout) : options.longs === Number ? new $util.LongBits(message.status_timeout.low >>> 0, message.status_timeout.high >>> 0).toNumber(true) : message.status_timeout;
                if (message.peers_timeout != null && message.hasOwnProperty("peers_timeout"))
                    if (typeof message.peers_timeout === "number")
                        object.peers_timeout = options.longs === String ? String(message.peers_timeout) : message.peers_timeout;
                    else
                        object.peers_timeout = options.longs === String ? $util.Long.prototype.toString.call(message.peers_timeout) : options.longs === Number ? new $util.LongBits(message.peers_timeout.low >>> 0, message.peers_timeout.high >>> 0).toNumber(true) : message.peers_timeout;
                if (message.txs_block_limit != null && message.hasOwnProperty("txs_block_limit"))
                    object.txs_block_limit = message.txs_block_limit;
                if (message.max_message_len != null && message.hasOwnProperty("max_message_len"))
                    object.max_message_len = message.max_message_len;
                if (message.min_propose_timeout != null && message.hasOwnProperty("min_propose_timeout"))
                    if (typeof message.min_propose_timeout === "number")
                        object.min_propose_timeout = options.longs === String ? String(message.min_propose_timeout) : message.min_propose_timeout;
                    else
                        object.min_propose_timeout = options.longs === String ? $util.Long.prototype.toString.call(message.min_propose_timeout) : options.longs === Number ? new $util.LongBits(message.min_propose_timeout.low >>> 0, message.min_propose_timeout.high >>> 0).toNumber(true) : message.min_propose_timeout;
                if (message.max_propose_timeout != null && message.hasOwnProperty("max_propose_timeout"))
                    if (typeof message.max_propose_timeout === "number")
                        object.max_propose_timeout = options.longs === String ? String(message.max_propose_timeout) : message.max_propose_timeout;
                    else
                        object.max_propose_timeout = options.longs === String ? $util.Long.prototype.toString.call(message.max_propose_timeout) : options.longs === Number ? new $util.LongBits(message.max_propose_timeout.low >>> 0, message.max_propose_timeout.high >>> 0).toNumber(true) : message.max_propose_timeout;
                if (message.propose_timeout_threshold != null && message.hasOwnProperty("propose_timeout_threshold"))
                    object.propose_timeout_threshold = message.propose_timeout_threshold;
                return object;
            };
    
            /**
             * Converts this Config to JSON.
             * @function toJSON
             * @memberof exonum.Config
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            Config.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return Config;
        })();
    
        exonum.AppliedConfig = (function() {
    
            /**
             * Properties of an AppliedConfig.
             * @memberof exonum
             * @interface IAppliedConfig
             * @property {number|Long|null} [actual_from] AppliedConfig actual_from
             * @property {exonum.crypto.IHash|null} [prev_hash] AppliedConfig prev_hash
             * @property {exonum.IConfig|null} [consensus_config] AppliedConfig consensus_config
             */
    
            /**
             * Constructs a new AppliedConfig.
             * @memberof exonum
             * @classdesc Represents an AppliedConfig.
             * @implements IAppliedConfig
             * @constructor
             * @param {exonum.IAppliedConfig=} [properties] Properties to set
             */
            function AppliedConfig(properties) {
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * AppliedConfig actual_from.
             * @member {number|Long} actual_from
             * @memberof exonum.AppliedConfig
             * @instance
             */
            AppliedConfig.prototype.actual_from = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
            /**
             * AppliedConfig prev_hash.
             * @member {exonum.crypto.IHash|null|undefined} prev_hash
             * @memberof exonum.AppliedConfig
             * @instance
             */
            AppliedConfig.prototype.prev_hash = null;
    
            /**
             * AppliedConfig consensus_config.
             * @member {exonum.IConfig|null|undefined} consensus_config
             * @memberof exonum.AppliedConfig
             * @instance
             */
            AppliedConfig.prototype.consensus_config = null;
    
            /**
             * Creates a new AppliedConfig instance using the specified properties.
             * @function create
             * @memberof exonum.AppliedConfig
             * @static
             * @param {exonum.IAppliedConfig=} [properties] Properties to set
             * @returns {exonum.AppliedConfig} AppliedConfig instance
             */
            AppliedConfig.create = function create(properties) {
                return new AppliedConfig(properties);
            };
    
            /**
             * Encodes the specified AppliedConfig message. Does not implicitly {@link exonum.AppliedConfig.verify|verify} messages.
             * @function encode
             * @memberof exonum.AppliedConfig
             * @static
             * @param {exonum.IAppliedConfig} message AppliedConfig message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            AppliedConfig.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.actual_from != null && message.hasOwnProperty("actual_from"))
                    writer.uint32(/* id 1, wireType 0 =*/8).uint64(message.actual_from);
                if (message.prev_hash != null && message.hasOwnProperty("prev_hash"))
                    $root.exonum.crypto.Hash.encode(message.prev_hash, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                if (message.consensus_config != null && message.hasOwnProperty("consensus_config"))
                    $root.exonum.Config.encode(message.consensus_config, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                return writer;
            };
    
            /**
             * Encodes the specified AppliedConfig message, length delimited. Does not implicitly {@link exonum.AppliedConfig.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.AppliedConfig
             * @static
             * @param {exonum.IAppliedConfig} message AppliedConfig message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            AppliedConfig.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes an AppliedConfig message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.AppliedConfig
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.AppliedConfig} AppliedConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            AppliedConfig.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.AppliedConfig();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 1:
                        message.actual_from = reader.uint64();
                        break;
                    case 2:
                        message.prev_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                        break;
                    case 3:
                        message.consensus_config = $root.exonum.Config.decode(reader, reader.uint32());
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes an AppliedConfig message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.AppliedConfig
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.AppliedConfig} AppliedConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            AppliedConfig.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies an AppliedConfig message.
             * @function verify
             * @memberof exonum.AppliedConfig
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            AppliedConfig.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.actual_from != null && message.hasOwnProperty("actual_from"))
                    if (!$util.isInteger(message.actual_from) && !(message.actual_from && $util.isInteger(message.actual_from.low) && $util.isInteger(message.actual_from.high)))
                        return "actual_from: integer|Long expected";
                if (message.prev_hash != null && message.hasOwnProperty("prev_hash")) {
                    var error = $root.exonum.crypto.Hash.verify(message.prev_hash);
                    if (error)
                        return "prev_hash." + error;
                }
                if (message.consensus_config != null && message.hasOwnProperty("consensus_config")) {
                    var error = $root.exonum.Config.verify(message.consensus_config);
                    if (error)
                        return "consensus_config." + error;
                }
                return null;
            };
    
            /**
             * Creates an AppliedConfig message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.AppliedConfig
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.AppliedConfig} AppliedConfig
             */
            AppliedConfig.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.AppliedConfig)
                    return object;
                var message = new $root.exonum.AppliedConfig();
                if (object.actual_from != null)
                    if ($util.Long)
                        (message.actual_from = $util.Long.fromValue(object.actual_from)).unsigned = true;
                    else if (typeof object.actual_from === "string")
                        message.actual_from = parseInt(object.actual_from, 10);
                    else if (typeof object.actual_from === "number")
                        message.actual_from = object.actual_from;
                    else if (typeof object.actual_from === "object")
                        message.actual_from = new $util.LongBits(object.actual_from.low >>> 0, object.actual_from.high >>> 0).toNumber(true);
                if (object.prev_hash != null) {
                    if (typeof object.prev_hash !== "object")
                        throw TypeError(".exonum.AppliedConfig.prev_hash: object expected");
                    message.prev_hash = $root.exonum.crypto.Hash.fromObject(object.prev_hash);
                }
                if (object.consensus_config != null) {
                    if (typeof object.consensus_config !== "object")
                        throw TypeError(".exonum.AppliedConfig.consensus_config: object expected");
                    message.consensus_config = $root.exonum.Config.fromObject(object.consensus_config);
                }
                return message;
            };
    
            /**
             * Creates a plain object from an AppliedConfig message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.AppliedConfig
             * @static
             * @param {exonum.AppliedConfig} message AppliedConfig
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            AppliedConfig.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.defaults) {
                    if ($util.Long) {
                        var long = new $util.Long(0, 0, true);
                        object.actual_from = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                    } else
                        object.actual_from = options.longs === String ? "0" : 0;
                    object.prev_hash = null;
                    object.consensus_config = null;
                }
                if (message.actual_from != null && message.hasOwnProperty("actual_from"))
                    if (typeof message.actual_from === "number")
                        object.actual_from = options.longs === String ? String(message.actual_from) : message.actual_from;
                    else
                        object.actual_from = options.longs === String ? $util.Long.prototype.toString.call(message.actual_from) : options.longs === Number ? new $util.LongBits(message.actual_from.low >>> 0, message.actual_from.high >>> 0).toNumber(true) : message.actual_from;
                if (message.prev_hash != null && message.hasOwnProperty("prev_hash"))
                    object.prev_hash = $root.exonum.crypto.Hash.toObject(message.prev_hash, options);
                if (message.consensus_config != null && message.hasOwnProperty("consensus_config"))
                    object.consensus_config = $root.exonum.Config.toObject(message.consensus_config, options);
                return object;
            };
    
            /**
             * Converts this AppliedConfig to JSON.
             * @function toJSON
             * @memberof exonum.AppliedConfig
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            AppliedConfig.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return AppliedConfig;
        })();
    
        exonum.consensus = (function() {
    
            /**
             * Namespace consensus.
             * @memberof exonum
             * @namespace
             */
            var consensus = {};
    
            consensus.CoreMessage = (function() {
    
                /**
                 * Properties of a CoreMessage.
                 * @memberof exonum.consensus
                 * @interface ICoreMessage
                 * @property {exonum.runtime.IAnyTx|null} [any_tx] CoreMessage any_tx
                 * @property {exonum.consensus.IPrecommit|null} [precommit] CoreMessage precommit
                 */
    
                /**
                 * Constructs a new CoreMessage.
                 * @memberof exonum.consensus
                 * @classdesc Represents a CoreMessage.
                 * @implements ICoreMessage
                 * @constructor
                 * @param {exonum.consensus.ICoreMessage=} [properties] Properties to set
                 */
                function CoreMessage(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * CoreMessage any_tx.
                 * @member {exonum.runtime.IAnyTx|null|undefined} any_tx
                 * @memberof exonum.consensus.CoreMessage
                 * @instance
                 */
                CoreMessage.prototype.any_tx = null;
    
                /**
                 * CoreMessage precommit.
                 * @member {exonum.consensus.IPrecommit|null|undefined} precommit
                 * @memberof exonum.consensus.CoreMessage
                 * @instance
                 */
                CoreMessage.prototype.precommit = null;
    
                // OneOf field names bound to virtual getters and setters
                var $oneOfFields;
    
                /**
                 * CoreMessage kind.
                 * @member {"any_tx"|"precommit"|undefined} kind
                 * @memberof exonum.consensus.CoreMessage
                 * @instance
                 */
                Object.defineProperty(CoreMessage.prototype, "kind", {
                    get: $util.oneOfGetter($oneOfFields = ["any_tx", "precommit"]),
                    set: $util.oneOfSetter($oneOfFields)
                });
    
                /**
                 * Creates a new CoreMessage instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {exonum.consensus.ICoreMessage=} [properties] Properties to set
                 * @returns {exonum.consensus.CoreMessage} CoreMessage instance
                 */
                CoreMessage.create = function create(properties) {
                    return new CoreMessage(properties);
                };
    
                /**
                 * Encodes the specified CoreMessage message. Does not implicitly {@link exonum.consensus.CoreMessage.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {exonum.consensus.ICoreMessage} message CoreMessage message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                CoreMessage.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.any_tx != null && message.hasOwnProperty("any_tx"))
                        $root.exonum.runtime.AnyTx.encode(message.any_tx, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.precommit != null && message.hasOwnProperty("precommit"))
                        $root.exonum.consensus.Precommit.encode(message.precommit, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified CoreMessage message, length delimited. Does not implicitly {@link exonum.consensus.CoreMessage.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {exonum.consensus.ICoreMessage} message CoreMessage message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                CoreMessage.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a CoreMessage message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.CoreMessage} CoreMessage
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                CoreMessage.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.CoreMessage();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.any_tx = $root.exonum.runtime.AnyTx.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.precommit = $root.exonum.consensus.Precommit.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a CoreMessage message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.CoreMessage} CoreMessage
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                CoreMessage.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a CoreMessage message.
                 * @function verify
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                CoreMessage.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    var properties = {};
                    if (message.any_tx != null && message.hasOwnProperty("any_tx")) {
                        properties.kind = 1;
                        {
                            var error = $root.exonum.runtime.AnyTx.verify(message.any_tx);
                            if (error)
                                return "any_tx." + error;
                        }
                    }
                    if (message.precommit != null && message.hasOwnProperty("precommit")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.Precommit.verify(message.precommit);
                            if (error)
                                return "precommit." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a CoreMessage message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.CoreMessage} CoreMessage
                 */
                CoreMessage.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.CoreMessage)
                        return object;
                    var message = new $root.exonum.consensus.CoreMessage();
                    if (object.any_tx != null) {
                        if (typeof object.any_tx !== "object")
                            throw TypeError(".exonum.consensus.CoreMessage.any_tx: object expected");
                        message.any_tx = $root.exonum.runtime.AnyTx.fromObject(object.any_tx);
                    }
                    if (object.precommit != null) {
                        if (typeof object.precommit !== "object")
                            throw TypeError(".exonum.consensus.CoreMessage.precommit: object expected");
                        message.precommit = $root.exonum.consensus.Precommit.fromObject(object.precommit);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a CoreMessage message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.CoreMessage
                 * @static
                 * @param {exonum.consensus.CoreMessage} message CoreMessage
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                CoreMessage.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (message.any_tx != null && message.hasOwnProperty("any_tx")) {
                        object.any_tx = $root.exonum.runtime.AnyTx.toObject(message.any_tx, options);
                        if (options.oneofs)
                            object.kind = "any_tx";
                    }
                    if (message.precommit != null && message.hasOwnProperty("precommit")) {
                        object.precommit = $root.exonum.consensus.Precommit.toObject(message.precommit, options);
                        if (options.oneofs)
                            object.kind = "precommit";
                    }
                    return object;
                };
    
                /**
                 * Converts this CoreMessage to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.CoreMessage
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                CoreMessage.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return CoreMessage;
            })();
    
            consensus.SignedMessage = (function() {
    
                /**
                 * Properties of a SignedMessage.
                 * @memberof exonum.consensus
                 * @interface ISignedMessage
                 * @property {Uint8Array|null} [chain_id_bytes] SignedMessage chain_id_bytes
                 * @property {Uint8Array|null} [payload] SignedMessage payload
                 * @property {exonum.crypto.IPublicKey|null} [author] SignedMessage author
                 * @property {exonum.crypto.ISignature|null} [signature] SignedMessage signature
                 */
    
                /**
                 * Constructs a new SignedMessage.
                 * @memberof exonum.consensus
                 * @classdesc Represents a SignedMessage.
                 * @implements ISignedMessage
                 * @constructor
                 * @param {exonum.consensus.ISignedMessage=} [properties] Properties to set
                 */
                function SignedMessage(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * SignedMessage chain_id_bytes.
                 * @member {Uint8Array} chain_id_bytes
                 * @memberof exonum.consensus.SignedMessage
                 * @instance
                 */
                SignedMessage.prototype.chain_id_bytes = $util.newBuffer([]);
    
                /**
                 * SignedMessage payload.
                 * @member {Uint8Array} payload
                 * @memberof exonum.consensus.SignedMessage
                 * @instance
                 */
                SignedMessage.prototype.payload = $util.newBuffer([]);
    
                /**
                 * SignedMessage author.
                 * @member {exonum.crypto.IPublicKey|null|undefined} author
                 * @memberof exonum.consensus.SignedMessage
                 * @instance
                 */
                SignedMessage.prototype.author = null;
    
                /**
                 * SignedMessage signature.
                 * @member {exonum.crypto.ISignature|null|undefined} signature
                 * @memberof exonum.consensus.SignedMessage
                 * @instance
                 */
                SignedMessage.prototype.signature = null;
    
                /**
                 * Creates a new SignedMessage instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {exonum.consensus.ISignedMessage=} [properties] Properties to set
                 * @returns {exonum.consensus.SignedMessage} SignedMessage instance
                 */
                SignedMessage.create = function create(properties) {
                    return new SignedMessage(properties);
                };
    
                /**
                 * Encodes the specified SignedMessage message. Does not implicitly {@link exonum.consensus.SignedMessage.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {exonum.consensus.ISignedMessage} message SignedMessage message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                SignedMessage.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.chain_id_bytes != null && message.hasOwnProperty("chain_id_bytes"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.chain_id_bytes);
                    if (message.payload != null && message.hasOwnProperty("payload"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.payload);
                    if (message.author != null && message.hasOwnProperty("author"))
                        $root.exonum.crypto.PublicKey.encode(message.author, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    if (message.signature != null && message.hasOwnProperty("signature"))
                        $root.exonum.crypto.Signature.encode(message.signature, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified SignedMessage message, length delimited. Does not implicitly {@link exonum.consensus.SignedMessage.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {exonum.consensus.ISignedMessage} message SignedMessage message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                SignedMessage.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a SignedMessage message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.SignedMessage} SignedMessage
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                SignedMessage.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.SignedMessage();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.chain_id_bytes = reader.bytes();
                            break;
                        case 2:
                            message.payload = reader.bytes();
                            break;
                        case 3:
                            message.author = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 4:
                            message.signature = $root.exonum.crypto.Signature.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a SignedMessage message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.SignedMessage} SignedMessage
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                SignedMessage.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a SignedMessage message.
                 * @function verify
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                SignedMessage.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.chain_id_bytes != null && message.hasOwnProperty("chain_id_bytes"))
                        if (!(message.chain_id_bytes && typeof message.chain_id_bytes.length === "number" || $util.isString(message.chain_id_bytes)))
                            return "chain_id_bytes: buffer expected";
                    if (message.payload != null && message.hasOwnProperty("payload"))
                        if (!(message.payload && typeof message.payload.length === "number" || $util.isString(message.payload)))
                            return "payload: buffer expected";
                    if (message.author != null && message.hasOwnProperty("author")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.author);
                        if (error)
                            return "author." + error;
                    }
                    if (message.signature != null && message.hasOwnProperty("signature")) {
                        var error = $root.exonum.crypto.Signature.verify(message.signature);
                        if (error)
                            return "signature." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a SignedMessage message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.SignedMessage} SignedMessage
                 */
                SignedMessage.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.SignedMessage)
                        return object;
                    var message = new $root.exonum.consensus.SignedMessage();
                    if (object.chain_id_bytes != null)
                        if (typeof object.chain_id_bytes === "string")
                            $util.base64.decode(object.chain_id_bytes, message.chain_id_bytes = $util.newBuffer($util.base64.length(object.chain_id_bytes)), 0);
                        else if (object.chain_id_bytes.length)
                            message.chain_id_bytes = object.chain_id_bytes;
                    if (object.payload != null)
                        if (typeof object.payload === "string")
                            $util.base64.decode(object.payload, message.payload = $util.newBuffer($util.base64.length(object.payload)), 0);
                        else if (object.payload.length)
                            message.payload = object.payload;
                    if (object.author != null) {
                        if (typeof object.author !== "object")
                            throw TypeError(".exonum.consensus.SignedMessage.author: object expected");
                        message.author = $root.exonum.crypto.PublicKey.fromObject(object.author);
                    }
                    if (object.signature != null) {
                        if (typeof object.signature !== "object")
                            throw TypeError(".exonum.consensus.SignedMessage.signature: object expected");
                        message.signature = $root.exonum.crypto.Signature.fromObject(object.signature);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a SignedMessage message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.SignedMessage
                 * @static
                 * @param {exonum.consensus.SignedMessage} message SignedMessage
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                SignedMessage.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if (options.bytes === String)
                            object.chain_id_bytes = "";
                        else {
                            object.chain_id_bytes = [];
                            if (options.bytes !== Array)
                                object.chain_id_bytes = $util.newBuffer(object.chain_id_bytes);
                        }
                        if (options.bytes === String)
                            object.payload = "";
                        else {
                            object.payload = [];
                            if (options.bytes !== Array)
                                object.payload = $util.newBuffer(object.payload);
                        }
                        object.author = null;
                        object.signature = null;
                    }
                    if (message.chain_id_bytes != null && message.hasOwnProperty("chain_id_bytes"))
                        object.chain_id_bytes = options.bytes === String ? $util.base64.encode(message.chain_id_bytes, 0, message.chain_id_bytes.length) : options.bytes === Array ? Array.prototype.slice.call(message.chain_id_bytes) : message.chain_id_bytes;
                    if (message.payload != null && message.hasOwnProperty("payload"))
                        object.payload = options.bytes === String ? $util.base64.encode(message.payload, 0, message.payload.length) : options.bytes === Array ? Array.prototype.slice.call(message.payload) : message.payload;
                    if (message.author != null && message.hasOwnProperty("author"))
                        object.author = $root.exonum.crypto.PublicKey.toObject(message.author, options);
                    if (message.signature != null && message.hasOwnProperty("signature"))
                        object.signature = $root.exonum.crypto.Signature.toObject(message.signature, options);
                    return object;
                };
    
                /**
                 * Converts this SignedMessage to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.SignedMessage
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                SignedMessage.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return SignedMessage;
            })();
    
            consensus.Connect = (function() {
    
                /**
                 * Properties of a Connect.
                 * @memberof exonum.consensus
                 * @interface IConnect
                 * @property {string|null} [host] Connect host
                 * @property {google.protobuf.ITimestamp|null} [time] Connect time
                 * @property {string|null} [user_agent] Connect user_agent
                 */
    
                /**
                 * Constructs a new Connect.
                 * @memberof exonum.consensus
                 * @classdesc Represents a Connect.
                 * @implements IConnect
                 * @constructor
                 * @param {exonum.consensus.IConnect=} [properties] Properties to set
                 */
                function Connect(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Connect host.
                 * @member {string} host
                 * @memberof exonum.consensus.Connect
                 * @instance
                 */
                Connect.prototype.host = "";
    
                /**
                 * Connect time.
                 * @member {google.protobuf.ITimestamp|null|undefined} time
                 * @memberof exonum.consensus.Connect
                 * @instance
                 */
                Connect.prototype.time = null;
    
                /**
                 * Connect user_agent.
                 * @member {string} user_agent
                 * @memberof exonum.consensus.Connect
                 * @instance
                 */
                Connect.prototype.user_agent = "";
    
                /**
                 * Creates a new Connect instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {exonum.consensus.IConnect=} [properties] Properties to set
                 * @returns {exonum.consensus.Connect} Connect instance
                 */
                Connect.create = function create(properties) {
                    return new Connect(properties);
                };
    
                /**
                 * Encodes the specified Connect message. Does not implicitly {@link exonum.consensus.Connect.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {exonum.consensus.IConnect} message Connect message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Connect.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.host != null && message.hasOwnProperty("host"))
                        writer.uint32(/* id 1, wireType 2 =*/10).string(message.host);
                    if (message.time != null && message.hasOwnProperty("time"))
                        $root.google.protobuf.Timestamp.encode(message.time, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.user_agent != null && message.hasOwnProperty("user_agent"))
                        writer.uint32(/* id 3, wireType 2 =*/26).string(message.user_agent);
                    return writer;
                };
    
                /**
                 * Encodes the specified Connect message, length delimited. Does not implicitly {@link exonum.consensus.Connect.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {exonum.consensus.IConnect} message Connect message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Connect.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Connect message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.Connect} Connect
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Connect.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.Connect();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.host = reader.string();
                            break;
                        case 2:
                            message.time = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
                            break;
                        case 3:
                            message.user_agent = reader.string();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Connect message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.Connect} Connect
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Connect.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Connect message.
                 * @function verify
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Connect.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.host != null && message.hasOwnProperty("host"))
                        if (!$util.isString(message.host))
                            return "host: string expected";
                    if (message.time != null && message.hasOwnProperty("time")) {
                        var error = $root.google.protobuf.Timestamp.verify(message.time);
                        if (error)
                            return "time." + error;
                    }
                    if (message.user_agent != null && message.hasOwnProperty("user_agent"))
                        if (!$util.isString(message.user_agent))
                            return "user_agent: string expected";
                    return null;
                };
    
                /**
                 * Creates a Connect message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.Connect} Connect
                 */
                Connect.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.Connect)
                        return object;
                    var message = new $root.exonum.consensus.Connect();
                    if (object.host != null)
                        message.host = String(object.host);
                    if (object.time != null) {
                        if (typeof object.time !== "object")
                            throw TypeError(".exonum.consensus.Connect.time: object expected");
                        message.time = $root.google.protobuf.Timestamp.fromObject(object.time);
                    }
                    if (object.user_agent != null)
                        message.user_agent = String(object.user_agent);
                    return message;
                };
    
                /**
                 * Creates a plain object from a Connect message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.Connect
                 * @static
                 * @param {exonum.consensus.Connect} message Connect
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Connect.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.host = "";
                        object.time = null;
                        object.user_agent = "";
                    }
                    if (message.host != null && message.hasOwnProperty("host"))
                        object.host = message.host;
                    if (message.time != null && message.hasOwnProperty("time"))
                        object.time = $root.google.protobuf.Timestamp.toObject(message.time, options);
                    if (message.user_agent != null && message.hasOwnProperty("user_agent"))
                        object.user_agent = message.user_agent;
                    return object;
                };
    
                /**
                 * Converts this Connect to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.Connect
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Connect.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Connect;
            })();
    
            consensus.Status = (function() {
    
                /**
                 * Properties of a Status.
                 * @memberof exonum.consensus
                 * @interface IStatus
                 * @property {number|Long|null} [height] Status height
                 * @property {exonum.crypto.IHash|null} [last_hash] Status last_hash
                 * @property {number|Long|null} [pool_size] Status pool_size
                 */
    
                /**
                 * Constructs a new Status.
                 * @memberof exonum.consensus
                 * @classdesc Represents a Status.
                 * @implements IStatus
                 * @constructor
                 * @param {exonum.consensus.IStatus=} [properties] Properties to set
                 */
                function Status(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Status height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.Status
                 * @instance
                 */
                Status.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Status last_hash.
                 * @member {exonum.crypto.IHash|null|undefined} last_hash
                 * @memberof exonum.consensus.Status
                 * @instance
                 */
                Status.prototype.last_hash = null;
    
                /**
                 * Status pool_size.
                 * @member {number|Long} pool_size
                 * @memberof exonum.consensus.Status
                 * @instance
                 */
                Status.prototype.pool_size = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Creates a new Status instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {exonum.consensus.IStatus=} [properties] Properties to set
                 * @returns {exonum.consensus.Status} Status instance
                 */
                Status.create = function create(properties) {
                    return new Status(properties);
                };
    
                /**
                 * Encodes the specified Status message. Does not implicitly {@link exonum.consensus.Status.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {exonum.consensus.IStatus} message Status message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Status.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint64(message.height);
                    if (message.last_hash != null && message.hasOwnProperty("last_hash"))
                        $root.exonum.crypto.Hash.encode(message.last_hash, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.pool_size != null && message.hasOwnProperty("pool_size"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint64(message.pool_size);
                    return writer;
                };
    
                /**
                 * Encodes the specified Status message, length delimited. Does not implicitly {@link exonum.consensus.Status.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {exonum.consensus.IStatus} message Status message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Status.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Status message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.Status} Status
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Status.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.Status();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.height = reader.uint64();
                            break;
                        case 2:
                            message.last_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 3:
                            message.pool_size = reader.uint64();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Status message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.Status} Status
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Status.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Status message.
                 * @function verify
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Status.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    if (message.last_hash != null && message.hasOwnProperty("last_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.last_hash);
                        if (error)
                            return "last_hash." + error;
                    }
                    if (message.pool_size != null && message.hasOwnProperty("pool_size"))
                        if (!$util.isInteger(message.pool_size) && !(message.pool_size && $util.isInteger(message.pool_size.low) && $util.isInteger(message.pool_size.high)))
                            return "pool_size: integer|Long expected";
                    return null;
                };
    
                /**
                 * Creates a Status message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.Status} Status
                 */
                Status.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.Status)
                        return object;
                    var message = new $root.exonum.consensus.Status();
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    if (object.last_hash != null) {
                        if (typeof object.last_hash !== "object")
                            throw TypeError(".exonum.consensus.Status.last_hash: object expected");
                        message.last_hash = $root.exonum.crypto.Hash.fromObject(object.last_hash);
                    }
                    if (object.pool_size != null)
                        if ($util.Long)
                            (message.pool_size = $util.Long.fromValue(object.pool_size)).unsigned = true;
                        else if (typeof object.pool_size === "string")
                            message.pool_size = parseInt(object.pool_size, 10);
                        else if (typeof object.pool_size === "number")
                            message.pool_size = object.pool_size;
                        else if (typeof object.pool_size === "object")
                            message.pool_size = new $util.LongBits(object.pool_size.low >>> 0, object.pool_size.high >>> 0).toNumber(true);
                    return message;
                };
    
                /**
                 * Creates a plain object from a Status message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.Status
                 * @static
                 * @param {exonum.consensus.Status} message Status
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Status.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                        object.last_hash = null;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.pool_size = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.pool_size = options.longs === String ? "0" : 0;
                    }
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    if (message.last_hash != null && message.hasOwnProperty("last_hash"))
                        object.last_hash = $root.exonum.crypto.Hash.toObject(message.last_hash, options);
                    if (message.pool_size != null && message.hasOwnProperty("pool_size"))
                        if (typeof message.pool_size === "number")
                            object.pool_size = options.longs === String ? String(message.pool_size) : message.pool_size;
                        else
                            object.pool_size = options.longs === String ? $util.Long.prototype.toString.call(message.pool_size) : options.longs === Number ? new $util.LongBits(message.pool_size.low >>> 0, message.pool_size.high >>> 0).toNumber(true) : message.pool_size;
                    return object;
                };
    
                /**
                 * Converts this Status to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.Status
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Status.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Status;
            })();
    
            consensus.Propose = (function() {
    
                /**
                 * Properties of a Propose.
                 * @memberof exonum.consensus
                 * @interface IPropose
                 * @property {number|null} [validator] Propose validator
                 * @property {number|Long|null} [height] Propose height
                 * @property {number|null} [round] Propose round
                 * @property {exonum.crypto.IHash|null} [prev_hash] Propose prev_hash
                 * @property {Array.<exonum.crypto.IHash>|null} [transactions] Propose transactions
                 */
    
                /**
                 * Constructs a new Propose.
                 * @memberof exonum.consensus
                 * @classdesc Represents a Propose.
                 * @implements IPropose
                 * @constructor
                 * @param {exonum.consensus.IPropose=} [properties] Properties to set
                 */
                function Propose(properties) {
                    this.transactions = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Propose validator.
                 * @member {number} validator
                 * @memberof exonum.consensus.Propose
                 * @instance
                 */
                Propose.prototype.validator = 0;
    
                /**
                 * Propose height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.Propose
                 * @instance
                 */
                Propose.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Propose round.
                 * @member {number} round
                 * @memberof exonum.consensus.Propose
                 * @instance
                 */
                Propose.prototype.round = 0;
    
                /**
                 * Propose prev_hash.
                 * @member {exonum.crypto.IHash|null|undefined} prev_hash
                 * @memberof exonum.consensus.Propose
                 * @instance
                 */
                Propose.prototype.prev_hash = null;
    
                /**
                 * Propose transactions.
                 * @member {Array.<exonum.crypto.IHash>} transactions
                 * @memberof exonum.consensus.Propose
                 * @instance
                 */
                Propose.prototype.transactions = $util.emptyArray;
    
                /**
                 * Creates a new Propose instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {exonum.consensus.IPropose=} [properties] Properties to set
                 * @returns {exonum.consensus.Propose} Propose instance
                 */
                Propose.create = function create(properties) {
                    return new Propose(properties);
                };
    
                /**
                 * Encodes the specified Propose message. Does not implicitly {@link exonum.consensus.Propose.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {exonum.consensus.IPropose} message Propose message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Propose.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.validator);
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                    if (message.round != null && message.hasOwnProperty("round"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint32(message.round);
                    if (message.prev_hash != null && message.hasOwnProperty("prev_hash"))
                        $root.exonum.crypto.Hash.encode(message.prev_hash, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    if (message.transactions != null && message.transactions.length)
                        for (var i = 0; i < message.transactions.length; ++i)
                            $root.exonum.crypto.Hash.encode(message.transactions[i], writer.uint32(/* id 5, wireType 2 =*/42).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified Propose message, length delimited. Does not implicitly {@link exonum.consensus.Propose.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {exonum.consensus.IPropose} message Propose message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Propose.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Propose message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.Propose} Propose
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Propose.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.Propose();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.validator = reader.uint32();
                            break;
                        case 2:
                            message.height = reader.uint64();
                            break;
                        case 3:
                            message.round = reader.uint32();
                            break;
                        case 4:
                            message.prev_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 5:
                            if (!(message.transactions && message.transactions.length))
                                message.transactions = [];
                            message.transactions.push($root.exonum.crypto.Hash.decode(reader, reader.uint32()));
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Propose message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.Propose} Propose
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Propose.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Propose message.
                 * @function verify
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Propose.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        if (!$util.isInteger(message.validator))
                            return "validator: integer expected";
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    if (message.round != null && message.hasOwnProperty("round"))
                        if (!$util.isInteger(message.round))
                            return "round: integer expected";
                    if (message.prev_hash != null && message.hasOwnProperty("prev_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.prev_hash);
                        if (error)
                            return "prev_hash." + error;
                    }
                    if (message.transactions != null && message.hasOwnProperty("transactions")) {
                        if (!Array.isArray(message.transactions))
                            return "transactions: array expected";
                        for (var i = 0; i < message.transactions.length; ++i) {
                            var error = $root.exonum.crypto.Hash.verify(message.transactions[i]);
                            if (error)
                                return "transactions." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a Propose message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.Propose} Propose
                 */
                Propose.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.Propose)
                        return object;
                    var message = new $root.exonum.consensus.Propose();
                    if (object.validator != null)
                        message.validator = object.validator >>> 0;
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    if (object.round != null)
                        message.round = object.round >>> 0;
                    if (object.prev_hash != null) {
                        if (typeof object.prev_hash !== "object")
                            throw TypeError(".exonum.consensus.Propose.prev_hash: object expected");
                        message.prev_hash = $root.exonum.crypto.Hash.fromObject(object.prev_hash);
                    }
                    if (object.transactions) {
                        if (!Array.isArray(object.transactions))
                            throw TypeError(".exonum.consensus.Propose.transactions: array expected");
                        message.transactions = [];
                        for (var i = 0; i < object.transactions.length; ++i) {
                            if (typeof object.transactions[i] !== "object")
                                throw TypeError(".exonum.consensus.Propose.transactions: object expected");
                            message.transactions[i] = $root.exonum.crypto.Hash.fromObject(object.transactions[i]);
                        }
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a Propose message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.Propose
                 * @static
                 * @param {exonum.consensus.Propose} message Propose
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Propose.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.transactions = [];
                    if (options.defaults) {
                        object.validator = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                        object.round = 0;
                        object.prev_hash = null;
                    }
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        object.validator = message.validator;
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    if (message.round != null && message.hasOwnProperty("round"))
                        object.round = message.round;
                    if (message.prev_hash != null && message.hasOwnProperty("prev_hash"))
                        object.prev_hash = $root.exonum.crypto.Hash.toObject(message.prev_hash, options);
                    if (message.transactions && message.transactions.length) {
                        object.transactions = [];
                        for (var j = 0; j < message.transactions.length; ++j)
                            object.transactions[j] = $root.exonum.crypto.Hash.toObject(message.transactions[j], options);
                    }
                    return object;
                };
    
                /**
                 * Converts this Propose to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.Propose
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Propose.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Propose;
            })();
    
            consensus.Prevote = (function() {
    
                /**
                 * Properties of a Prevote.
                 * @memberof exonum.consensus
                 * @interface IPrevote
                 * @property {number|null} [validator] Prevote validator
                 * @property {number|Long|null} [height] Prevote height
                 * @property {number|null} [round] Prevote round
                 * @property {exonum.crypto.IHash|null} [propose_hash] Prevote propose_hash
                 * @property {number|null} [locked_round] Prevote locked_round
                 */
    
                /**
                 * Constructs a new Prevote.
                 * @memberof exonum.consensus
                 * @classdesc Represents a Prevote.
                 * @implements IPrevote
                 * @constructor
                 * @param {exonum.consensus.IPrevote=} [properties] Properties to set
                 */
                function Prevote(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Prevote validator.
                 * @member {number} validator
                 * @memberof exonum.consensus.Prevote
                 * @instance
                 */
                Prevote.prototype.validator = 0;
    
                /**
                 * Prevote height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.Prevote
                 * @instance
                 */
                Prevote.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Prevote round.
                 * @member {number} round
                 * @memberof exonum.consensus.Prevote
                 * @instance
                 */
                Prevote.prototype.round = 0;
    
                /**
                 * Prevote propose_hash.
                 * @member {exonum.crypto.IHash|null|undefined} propose_hash
                 * @memberof exonum.consensus.Prevote
                 * @instance
                 */
                Prevote.prototype.propose_hash = null;
    
                /**
                 * Prevote locked_round.
                 * @member {number} locked_round
                 * @memberof exonum.consensus.Prevote
                 * @instance
                 */
                Prevote.prototype.locked_round = 0;
    
                /**
                 * Creates a new Prevote instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {exonum.consensus.IPrevote=} [properties] Properties to set
                 * @returns {exonum.consensus.Prevote} Prevote instance
                 */
                Prevote.create = function create(properties) {
                    return new Prevote(properties);
                };
    
                /**
                 * Encodes the specified Prevote message. Does not implicitly {@link exonum.consensus.Prevote.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {exonum.consensus.IPrevote} message Prevote message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Prevote.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.validator);
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                    if (message.round != null && message.hasOwnProperty("round"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint32(message.round);
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        $root.exonum.crypto.Hash.encode(message.propose_hash, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    if (message.locked_round != null && message.hasOwnProperty("locked_round"))
                        writer.uint32(/* id 5, wireType 0 =*/40).uint32(message.locked_round);
                    return writer;
                };
    
                /**
                 * Encodes the specified Prevote message, length delimited. Does not implicitly {@link exonum.consensus.Prevote.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {exonum.consensus.IPrevote} message Prevote message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Prevote.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Prevote message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.Prevote} Prevote
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Prevote.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.Prevote();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.validator = reader.uint32();
                            break;
                        case 2:
                            message.height = reader.uint64();
                            break;
                        case 3:
                            message.round = reader.uint32();
                            break;
                        case 4:
                            message.propose_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 5:
                            message.locked_round = reader.uint32();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Prevote message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.Prevote} Prevote
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Prevote.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Prevote message.
                 * @function verify
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Prevote.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        if (!$util.isInteger(message.validator))
                            return "validator: integer expected";
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    if (message.round != null && message.hasOwnProperty("round"))
                        if (!$util.isInteger(message.round))
                            return "round: integer expected";
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.propose_hash);
                        if (error)
                            return "propose_hash." + error;
                    }
                    if (message.locked_round != null && message.hasOwnProperty("locked_round"))
                        if (!$util.isInteger(message.locked_round))
                            return "locked_round: integer expected";
                    return null;
                };
    
                /**
                 * Creates a Prevote message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.Prevote} Prevote
                 */
                Prevote.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.Prevote)
                        return object;
                    var message = new $root.exonum.consensus.Prevote();
                    if (object.validator != null)
                        message.validator = object.validator >>> 0;
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    if (object.round != null)
                        message.round = object.round >>> 0;
                    if (object.propose_hash != null) {
                        if (typeof object.propose_hash !== "object")
                            throw TypeError(".exonum.consensus.Prevote.propose_hash: object expected");
                        message.propose_hash = $root.exonum.crypto.Hash.fromObject(object.propose_hash);
                    }
                    if (object.locked_round != null)
                        message.locked_round = object.locked_round >>> 0;
                    return message;
                };
    
                /**
                 * Creates a plain object from a Prevote message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.Prevote
                 * @static
                 * @param {exonum.consensus.Prevote} message Prevote
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Prevote.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.validator = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                        object.round = 0;
                        object.propose_hash = null;
                        object.locked_round = 0;
                    }
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        object.validator = message.validator;
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    if (message.round != null && message.hasOwnProperty("round"))
                        object.round = message.round;
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        object.propose_hash = $root.exonum.crypto.Hash.toObject(message.propose_hash, options);
                    if (message.locked_round != null && message.hasOwnProperty("locked_round"))
                        object.locked_round = message.locked_round;
                    return object;
                };
    
                /**
                 * Converts this Prevote to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.Prevote
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Prevote.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Prevote;
            })();
    
            consensus.Precommit = (function() {
    
                /**
                 * Properties of a Precommit.
                 * @memberof exonum.consensus
                 * @interface IPrecommit
                 * @property {number|null} [validator] Precommit validator
                 * @property {number|Long|null} [height] Precommit height
                 * @property {number|null} [round] Precommit round
                 * @property {exonum.crypto.IHash|null} [propose_hash] Precommit propose_hash
                 * @property {exonum.crypto.IHash|null} [block_hash] Precommit block_hash
                 * @property {google.protobuf.ITimestamp|null} [time] Precommit time
                 */
    
                /**
                 * Constructs a new Precommit.
                 * @memberof exonum.consensus
                 * @classdesc Represents a Precommit.
                 * @implements IPrecommit
                 * @constructor
                 * @param {exonum.consensus.IPrecommit=} [properties] Properties to set
                 */
                function Precommit(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Precommit validator.
                 * @member {number} validator
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 */
                Precommit.prototype.validator = 0;
    
                /**
                 * Precommit height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 */
                Precommit.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Precommit round.
                 * @member {number} round
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 */
                Precommit.prototype.round = 0;
    
                /**
                 * Precommit propose_hash.
                 * @member {exonum.crypto.IHash|null|undefined} propose_hash
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 */
                Precommit.prototype.propose_hash = null;
    
                /**
                 * Precommit block_hash.
                 * @member {exonum.crypto.IHash|null|undefined} block_hash
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 */
                Precommit.prototype.block_hash = null;
    
                /**
                 * Precommit time.
                 * @member {google.protobuf.ITimestamp|null|undefined} time
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 */
                Precommit.prototype.time = null;
    
                /**
                 * Creates a new Precommit instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {exonum.consensus.IPrecommit=} [properties] Properties to set
                 * @returns {exonum.consensus.Precommit} Precommit instance
                 */
                Precommit.create = function create(properties) {
                    return new Precommit(properties);
                };
    
                /**
                 * Encodes the specified Precommit message. Does not implicitly {@link exonum.consensus.Precommit.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {exonum.consensus.IPrecommit} message Precommit message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Precommit.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.validator);
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                    if (message.round != null && message.hasOwnProperty("round"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint32(message.round);
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        $root.exonum.crypto.Hash.encode(message.propose_hash, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    if (message.block_hash != null && message.hasOwnProperty("block_hash"))
                        $root.exonum.crypto.Hash.encode(message.block_hash, writer.uint32(/* id 5, wireType 2 =*/42).fork()).ldelim();
                    if (message.time != null && message.hasOwnProperty("time"))
                        $root.google.protobuf.Timestamp.encode(message.time, writer.uint32(/* id 6, wireType 2 =*/50).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified Precommit message, length delimited. Does not implicitly {@link exonum.consensus.Precommit.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {exonum.consensus.IPrecommit} message Precommit message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Precommit.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Precommit message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.Precommit} Precommit
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Precommit.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.Precommit();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.validator = reader.uint32();
                            break;
                        case 2:
                            message.height = reader.uint64();
                            break;
                        case 3:
                            message.round = reader.uint32();
                            break;
                        case 4:
                            message.propose_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 5:
                            message.block_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 6:
                            message.time = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Precommit message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.Precommit} Precommit
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Precommit.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Precommit message.
                 * @function verify
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Precommit.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        if (!$util.isInteger(message.validator))
                            return "validator: integer expected";
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    if (message.round != null && message.hasOwnProperty("round"))
                        if (!$util.isInteger(message.round))
                            return "round: integer expected";
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.propose_hash);
                        if (error)
                            return "propose_hash." + error;
                    }
                    if (message.block_hash != null && message.hasOwnProperty("block_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.block_hash);
                        if (error)
                            return "block_hash." + error;
                    }
                    if (message.time != null && message.hasOwnProperty("time")) {
                        var error = $root.google.protobuf.Timestamp.verify(message.time);
                        if (error)
                            return "time." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a Precommit message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.Precommit} Precommit
                 */
                Precommit.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.Precommit)
                        return object;
                    var message = new $root.exonum.consensus.Precommit();
                    if (object.validator != null)
                        message.validator = object.validator >>> 0;
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    if (object.round != null)
                        message.round = object.round >>> 0;
                    if (object.propose_hash != null) {
                        if (typeof object.propose_hash !== "object")
                            throw TypeError(".exonum.consensus.Precommit.propose_hash: object expected");
                        message.propose_hash = $root.exonum.crypto.Hash.fromObject(object.propose_hash);
                    }
                    if (object.block_hash != null) {
                        if (typeof object.block_hash !== "object")
                            throw TypeError(".exonum.consensus.Precommit.block_hash: object expected");
                        message.block_hash = $root.exonum.crypto.Hash.fromObject(object.block_hash);
                    }
                    if (object.time != null) {
                        if (typeof object.time !== "object")
                            throw TypeError(".exonum.consensus.Precommit.time: object expected");
                        message.time = $root.google.protobuf.Timestamp.fromObject(object.time);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a Precommit message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.Precommit
                 * @static
                 * @param {exonum.consensus.Precommit} message Precommit
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Precommit.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.validator = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                        object.round = 0;
                        object.propose_hash = null;
                        object.block_hash = null;
                        object.time = null;
                    }
                    if (message.validator != null && message.hasOwnProperty("validator"))
                        object.validator = message.validator;
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    if (message.round != null && message.hasOwnProperty("round"))
                        object.round = message.round;
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        object.propose_hash = $root.exonum.crypto.Hash.toObject(message.propose_hash, options);
                    if (message.block_hash != null && message.hasOwnProperty("block_hash"))
                        object.block_hash = $root.exonum.crypto.Hash.toObject(message.block_hash, options);
                    if (message.time != null && message.hasOwnProperty("time"))
                        object.time = $root.google.protobuf.Timestamp.toObject(message.time, options);
                    return object;
                };
    
                /**
                 * Converts this Precommit to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.Precommit
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Precommit.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Precommit;
            })();
    
            consensus.BlockResponse = (function() {
    
                /**
                 * Properties of a BlockResponse.
                 * @memberof exonum.consensus
                 * @interface IBlockResponse
                 * @property {exonum.crypto.IPublicKey|null} [to] BlockResponse to
                 * @property {exonum.IBlock|null} [block] BlockResponse block
                 * @property {Array.<Uint8Array>|null} [precommits] BlockResponse precommits
                 * @property {Array.<exonum.crypto.IHash>|null} [transactions] BlockResponse transactions
                 */
    
                /**
                 * Constructs a new BlockResponse.
                 * @memberof exonum.consensus
                 * @classdesc Represents a BlockResponse.
                 * @implements IBlockResponse
                 * @constructor
                 * @param {exonum.consensus.IBlockResponse=} [properties] Properties to set
                 */
                function BlockResponse(properties) {
                    this.precommits = [];
                    this.transactions = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * BlockResponse to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.BlockResponse
                 * @instance
                 */
                BlockResponse.prototype.to = null;
    
                /**
                 * BlockResponse block.
                 * @member {exonum.IBlock|null|undefined} block
                 * @memberof exonum.consensus.BlockResponse
                 * @instance
                 */
                BlockResponse.prototype.block = null;
    
                /**
                 * BlockResponse precommits.
                 * @member {Array.<Uint8Array>} precommits
                 * @memberof exonum.consensus.BlockResponse
                 * @instance
                 */
                BlockResponse.prototype.precommits = $util.emptyArray;
    
                /**
                 * BlockResponse transactions.
                 * @member {Array.<exonum.crypto.IHash>} transactions
                 * @memberof exonum.consensus.BlockResponse
                 * @instance
                 */
                BlockResponse.prototype.transactions = $util.emptyArray;
    
                /**
                 * Creates a new BlockResponse instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {exonum.consensus.IBlockResponse=} [properties] Properties to set
                 * @returns {exonum.consensus.BlockResponse} BlockResponse instance
                 */
                BlockResponse.create = function create(properties) {
                    return new BlockResponse(properties);
                };
    
                /**
                 * Encodes the specified BlockResponse message. Does not implicitly {@link exonum.consensus.BlockResponse.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {exonum.consensus.IBlockResponse} message BlockResponse message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BlockResponse.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.block != null && message.hasOwnProperty("block"))
                        $root.exonum.Block.encode(message.block, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.precommits != null && message.precommits.length)
                        for (var i = 0; i < message.precommits.length; ++i)
                            writer.uint32(/* id 3, wireType 2 =*/26).bytes(message.precommits[i]);
                    if (message.transactions != null && message.transactions.length)
                        for (var i = 0; i < message.transactions.length; ++i)
                            $root.exonum.crypto.Hash.encode(message.transactions[i], writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified BlockResponse message, length delimited. Does not implicitly {@link exonum.consensus.BlockResponse.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {exonum.consensus.IBlockResponse} message BlockResponse message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BlockResponse.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a BlockResponse message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.BlockResponse} BlockResponse
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BlockResponse.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.BlockResponse();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.block = $root.exonum.Block.decode(reader, reader.uint32());
                            break;
                        case 3:
                            if (!(message.precommits && message.precommits.length))
                                message.precommits = [];
                            message.precommits.push(reader.bytes());
                            break;
                        case 4:
                            if (!(message.transactions && message.transactions.length))
                                message.transactions = [];
                            message.transactions.push($root.exonum.crypto.Hash.decode(reader, reader.uint32()));
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a BlockResponse message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.BlockResponse} BlockResponse
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BlockResponse.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a BlockResponse message.
                 * @function verify
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                BlockResponse.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    if (message.block != null && message.hasOwnProperty("block")) {
                        var error = $root.exonum.Block.verify(message.block);
                        if (error)
                            return "block." + error;
                    }
                    if (message.precommits != null && message.hasOwnProperty("precommits")) {
                        if (!Array.isArray(message.precommits))
                            return "precommits: array expected";
                        for (var i = 0; i < message.precommits.length; ++i)
                            if (!(message.precommits[i] && typeof message.precommits[i].length === "number" || $util.isString(message.precommits[i])))
                                return "precommits: buffer[] expected";
                    }
                    if (message.transactions != null && message.hasOwnProperty("transactions")) {
                        if (!Array.isArray(message.transactions))
                            return "transactions: array expected";
                        for (var i = 0; i < message.transactions.length; ++i) {
                            var error = $root.exonum.crypto.Hash.verify(message.transactions[i]);
                            if (error)
                                return "transactions." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a BlockResponse message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.BlockResponse} BlockResponse
                 */
                BlockResponse.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.BlockResponse)
                        return object;
                    var message = new $root.exonum.consensus.BlockResponse();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.BlockResponse.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    if (object.block != null) {
                        if (typeof object.block !== "object")
                            throw TypeError(".exonum.consensus.BlockResponse.block: object expected");
                        message.block = $root.exonum.Block.fromObject(object.block);
                    }
                    if (object.precommits) {
                        if (!Array.isArray(object.precommits))
                            throw TypeError(".exonum.consensus.BlockResponse.precommits: array expected");
                        message.precommits = [];
                        for (var i = 0; i < object.precommits.length; ++i)
                            if (typeof object.precommits[i] === "string")
                                $util.base64.decode(object.precommits[i], message.precommits[i] = $util.newBuffer($util.base64.length(object.precommits[i])), 0);
                            else if (object.precommits[i].length)
                                message.precommits[i] = object.precommits[i];
                    }
                    if (object.transactions) {
                        if (!Array.isArray(object.transactions))
                            throw TypeError(".exonum.consensus.BlockResponse.transactions: array expected");
                        message.transactions = [];
                        for (var i = 0; i < object.transactions.length; ++i) {
                            if (typeof object.transactions[i] !== "object")
                                throw TypeError(".exonum.consensus.BlockResponse.transactions: object expected");
                            message.transactions[i] = $root.exonum.crypto.Hash.fromObject(object.transactions[i]);
                        }
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a BlockResponse message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.BlockResponse
                 * @static
                 * @param {exonum.consensus.BlockResponse} message BlockResponse
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                BlockResponse.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults) {
                        object.precommits = [];
                        object.transactions = [];
                    }
                    if (options.defaults) {
                        object.to = null;
                        object.block = null;
                    }
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    if (message.block != null && message.hasOwnProperty("block"))
                        object.block = $root.exonum.Block.toObject(message.block, options);
                    if (message.precommits && message.precommits.length) {
                        object.precommits = [];
                        for (var j = 0; j < message.precommits.length; ++j)
                            object.precommits[j] = options.bytes === String ? $util.base64.encode(message.precommits[j], 0, message.precommits[j].length) : options.bytes === Array ? Array.prototype.slice.call(message.precommits[j]) : message.precommits[j];
                    }
                    if (message.transactions && message.transactions.length) {
                        object.transactions = [];
                        for (var j = 0; j < message.transactions.length; ++j)
                            object.transactions[j] = $root.exonum.crypto.Hash.toObject(message.transactions[j], options);
                    }
                    return object;
                };
    
                /**
                 * Converts this BlockResponse to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.BlockResponse
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                BlockResponse.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return BlockResponse;
            })();
    
            consensus.TransactionsResponse = (function() {
    
                /**
                 * Properties of a TransactionsResponse.
                 * @memberof exonum.consensus
                 * @interface ITransactionsResponse
                 * @property {exonum.crypto.IPublicKey|null} [to] TransactionsResponse to
                 * @property {Array.<Uint8Array>|null} [transactions] TransactionsResponse transactions
                 */
    
                /**
                 * Constructs a new TransactionsResponse.
                 * @memberof exonum.consensus
                 * @classdesc Represents a TransactionsResponse.
                 * @implements ITransactionsResponse
                 * @constructor
                 * @param {exonum.consensus.ITransactionsResponse=} [properties] Properties to set
                 */
                function TransactionsResponse(properties) {
                    this.transactions = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * TransactionsResponse to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.TransactionsResponse
                 * @instance
                 */
                TransactionsResponse.prototype.to = null;
    
                /**
                 * TransactionsResponse transactions.
                 * @member {Array.<Uint8Array>} transactions
                 * @memberof exonum.consensus.TransactionsResponse
                 * @instance
                 */
                TransactionsResponse.prototype.transactions = $util.emptyArray;
    
                /**
                 * Creates a new TransactionsResponse instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {exonum.consensus.ITransactionsResponse=} [properties] Properties to set
                 * @returns {exonum.consensus.TransactionsResponse} TransactionsResponse instance
                 */
                TransactionsResponse.create = function create(properties) {
                    return new TransactionsResponse(properties);
                };
    
                /**
                 * Encodes the specified TransactionsResponse message. Does not implicitly {@link exonum.consensus.TransactionsResponse.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {exonum.consensus.ITransactionsResponse} message TransactionsResponse message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TransactionsResponse.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.transactions != null && message.transactions.length)
                        for (var i = 0; i < message.transactions.length; ++i)
                            writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.transactions[i]);
                    return writer;
                };
    
                /**
                 * Encodes the specified TransactionsResponse message, length delimited. Does not implicitly {@link exonum.consensus.TransactionsResponse.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {exonum.consensus.ITransactionsResponse} message TransactionsResponse message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TransactionsResponse.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a TransactionsResponse message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.TransactionsResponse} TransactionsResponse
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TransactionsResponse.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.TransactionsResponse();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            if (!(message.transactions && message.transactions.length))
                                message.transactions = [];
                            message.transactions.push(reader.bytes());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a TransactionsResponse message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.TransactionsResponse} TransactionsResponse
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TransactionsResponse.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a TransactionsResponse message.
                 * @function verify
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                TransactionsResponse.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    if (message.transactions != null && message.hasOwnProperty("transactions")) {
                        if (!Array.isArray(message.transactions))
                            return "transactions: array expected";
                        for (var i = 0; i < message.transactions.length; ++i)
                            if (!(message.transactions[i] && typeof message.transactions[i].length === "number" || $util.isString(message.transactions[i])))
                                return "transactions: buffer[] expected";
                    }
                    return null;
                };
    
                /**
                 * Creates a TransactionsResponse message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.TransactionsResponse} TransactionsResponse
                 */
                TransactionsResponse.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.TransactionsResponse)
                        return object;
                    var message = new $root.exonum.consensus.TransactionsResponse();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.TransactionsResponse.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    if (object.transactions) {
                        if (!Array.isArray(object.transactions))
                            throw TypeError(".exonum.consensus.TransactionsResponse.transactions: array expected");
                        message.transactions = [];
                        for (var i = 0; i < object.transactions.length; ++i)
                            if (typeof object.transactions[i] === "string")
                                $util.base64.decode(object.transactions[i], message.transactions[i] = $util.newBuffer($util.base64.length(object.transactions[i])), 0);
                            else if (object.transactions[i].length)
                                message.transactions[i] = object.transactions[i];
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a TransactionsResponse message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.TransactionsResponse
                 * @static
                 * @param {exonum.consensus.TransactionsResponse} message TransactionsResponse
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                TransactionsResponse.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.transactions = [];
                    if (options.defaults)
                        object.to = null;
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    if (message.transactions && message.transactions.length) {
                        object.transactions = [];
                        for (var j = 0; j < message.transactions.length; ++j)
                            object.transactions[j] = options.bytes === String ? $util.base64.encode(message.transactions[j], 0, message.transactions[j].length) : options.bytes === Array ? Array.prototype.slice.call(message.transactions[j]) : message.transactions[j];
                    }
                    return object;
                };
    
                /**
                 * Converts this TransactionsResponse to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.TransactionsResponse
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                TransactionsResponse.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return TransactionsResponse;
            })();
    
            consensus.ProposeRequest = (function() {
    
                /**
                 * Properties of a ProposeRequest.
                 * @memberof exonum.consensus
                 * @interface IProposeRequest
                 * @property {exonum.crypto.IPublicKey|null} [to] ProposeRequest to
                 * @property {number|Long|null} [height] ProposeRequest height
                 * @property {exonum.crypto.IHash|null} [propose_hash] ProposeRequest propose_hash
                 */
    
                /**
                 * Constructs a new ProposeRequest.
                 * @memberof exonum.consensus
                 * @classdesc Represents a ProposeRequest.
                 * @implements IProposeRequest
                 * @constructor
                 * @param {exonum.consensus.IProposeRequest=} [properties] Properties to set
                 */
                function ProposeRequest(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ProposeRequest to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.ProposeRequest
                 * @instance
                 */
                ProposeRequest.prototype.to = null;
    
                /**
                 * ProposeRequest height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.ProposeRequest
                 * @instance
                 */
                ProposeRequest.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * ProposeRequest propose_hash.
                 * @member {exonum.crypto.IHash|null|undefined} propose_hash
                 * @memberof exonum.consensus.ProposeRequest
                 * @instance
                 */
                ProposeRequest.prototype.propose_hash = null;
    
                /**
                 * Creates a new ProposeRequest instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {exonum.consensus.IProposeRequest=} [properties] Properties to set
                 * @returns {exonum.consensus.ProposeRequest} ProposeRequest instance
                 */
                ProposeRequest.create = function create(properties) {
                    return new ProposeRequest(properties);
                };
    
                /**
                 * Encodes the specified ProposeRequest message. Does not implicitly {@link exonum.consensus.ProposeRequest.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {exonum.consensus.IProposeRequest} message ProposeRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ProposeRequest.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        $root.exonum.crypto.Hash.encode(message.propose_hash, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified ProposeRequest message, length delimited. Does not implicitly {@link exonum.consensus.ProposeRequest.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {exonum.consensus.IProposeRequest} message ProposeRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ProposeRequest.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a ProposeRequest message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.ProposeRequest} ProposeRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ProposeRequest.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.ProposeRequest();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.height = reader.uint64();
                            break;
                        case 3:
                            message.propose_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a ProposeRequest message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.ProposeRequest} ProposeRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ProposeRequest.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a ProposeRequest message.
                 * @function verify
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ProposeRequest.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.propose_hash);
                        if (error)
                            return "propose_hash." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a ProposeRequest message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.ProposeRequest} ProposeRequest
                 */
                ProposeRequest.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.ProposeRequest)
                        return object;
                    var message = new $root.exonum.consensus.ProposeRequest();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.ProposeRequest.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    if (object.propose_hash != null) {
                        if (typeof object.propose_hash !== "object")
                            throw TypeError(".exonum.consensus.ProposeRequest.propose_hash: object expected");
                        message.propose_hash = $root.exonum.crypto.Hash.fromObject(object.propose_hash);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a ProposeRequest message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.ProposeRequest
                 * @static
                 * @param {exonum.consensus.ProposeRequest} message ProposeRequest
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ProposeRequest.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.to = null;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                        object.propose_hash = null;
                    }
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        object.propose_hash = $root.exonum.crypto.Hash.toObject(message.propose_hash, options);
                    return object;
                };
    
                /**
                 * Converts this ProposeRequest to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.ProposeRequest
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ProposeRequest.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ProposeRequest;
            })();
    
            consensus.TransactionsRequest = (function() {
    
                /**
                 * Properties of a TransactionsRequest.
                 * @memberof exonum.consensus
                 * @interface ITransactionsRequest
                 * @property {exonum.crypto.IPublicKey|null} [to] TransactionsRequest to
                 * @property {Array.<exonum.crypto.IHash>|null} [txs] TransactionsRequest txs
                 */
    
                /**
                 * Constructs a new TransactionsRequest.
                 * @memberof exonum.consensus
                 * @classdesc Represents a TransactionsRequest.
                 * @implements ITransactionsRequest
                 * @constructor
                 * @param {exonum.consensus.ITransactionsRequest=} [properties] Properties to set
                 */
                function TransactionsRequest(properties) {
                    this.txs = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * TransactionsRequest to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.TransactionsRequest
                 * @instance
                 */
                TransactionsRequest.prototype.to = null;
    
                /**
                 * TransactionsRequest txs.
                 * @member {Array.<exonum.crypto.IHash>} txs
                 * @memberof exonum.consensus.TransactionsRequest
                 * @instance
                 */
                TransactionsRequest.prototype.txs = $util.emptyArray;
    
                /**
                 * Creates a new TransactionsRequest instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {exonum.consensus.ITransactionsRequest=} [properties] Properties to set
                 * @returns {exonum.consensus.TransactionsRequest} TransactionsRequest instance
                 */
                TransactionsRequest.create = function create(properties) {
                    return new TransactionsRequest(properties);
                };
    
                /**
                 * Encodes the specified TransactionsRequest message. Does not implicitly {@link exonum.consensus.TransactionsRequest.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {exonum.consensus.ITransactionsRequest} message TransactionsRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TransactionsRequest.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.txs != null && message.txs.length)
                        for (var i = 0; i < message.txs.length; ++i)
                            $root.exonum.crypto.Hash.encode(message.txs[i], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified TransactionsRequest message, length delimited. Does not implicitly {@link exonum.consensus.TransactionsRequest.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {exonum.consensus.ITransactionsRequest} message TransactionsRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TransactionsRequest.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a TransactionsRequest message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.TransactionsRequest} TransactionsRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TransactionsRequest.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.TransactionsRequest();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            if (!(message.txs && message.txs.length))
                                message.txs = [];
                            message.txs.push($root.exonum.crypto.Hash.decode(reader, reader.uint32()));
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a TransactionsRequest message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.TransactionsRequest} TransactionsRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TransactionsRequest.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a TransactionsRequest message.
                 * @function verify
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                TransactionsRequest.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    if (message.txs != null && message.hasOwnProperty("txs")) {
                        if (!Array.isArray(message.txs))
                            return "txs: array expected";
                        for (var i = 0; i < message.txs.length; ++i) {
                            var error = $root.exonum.crypto.Hash.verify(message.txs[i]);
                            if (error)
                                return "txs." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a TransactionsRequest message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.TransactionsRequest} TransactionsRequest
                 */
                TransactionsRequest.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.TransactionsRequest)
                        return object;
                    var message = new $root.exonum.consensus.TransactionsRequest();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.TransactionsRequest.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    if (object.txs) {
                        if (!Array.isArray(object.txs))
                            throw TypeError(".exonum.consensus.TransactionsRequest.txs: array expected");
                        message.txs = [];
                        for (var i = 0; i < object.txs.length; ++i) {
                            if (typeof object.txs[i] !== "object")
                                throw TypeError(".exonum.consensus.TransactionsRequest.txs: object expected");
                            message.txs[i] = $root.exonum.crypto.Hash.fromObject(object.txs[i]);
                        }
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a TransactionsRequest message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.TransactionsRequest
                 * @static
                 * @param {exonum.consensus.TransactionsRequest} message TransactionsRequest
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                TransactionsRequest.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.txs = [];
                    if (options.defaults)
                        object.to = null;
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    if (message.txs && message.txs.length) {
                        object.txs = [];
                        for (var j = 0; j < message.txs.length; ++j)
                            object.txs[j] = $root.exonum.crypto.Hash.toObject(message.txs[j], options);
                    }
                    return object;
                };
    
                /**
                 * Converts this TransactionsRequest to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.TransactionsRequest
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                TransactionsRequest.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return TransactionsRequest;
            })();
    
            consensus.PrevotesRequest = (function() {
    
                /**
                 * Properties of a PrevotesRequest.
                 * @memberof exonum.consensus
                 * @interface IPrevotesRequest
                 * @property {exonum.crypto.IPublicKey|null} [to] PrevotesRequest to
                 * @property {number|Long|null} [height] PrevotesRequest height
                 * @property {number|null} [round] PrevotesRequest round
                 * @property {exonum.crypto.IHash|null} [propose_hash] PrevotesRequest propose_hash
                 * @property {exonum.common.IBitVec|null} [validators] PrevotesRequest validators
                 */
    
                /**
                 * Constructs a new PrevotesRequest.
                 * @memberof exonum.consensus
                 * @classdesc Represents a PrevotesRequest.
                 * @implements IPrevotesRequest
                 * @constructor
                 * @param {exonum.consensus.IPrevotesRequest=} [properties] Properties to set
                 */
                function PrevotesRequest(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * PrevotesRequest to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.PrevotesRequest
                 * @instance
                 */
                PrevotesRequest.prototype.to = null;
    
                /**
                 * PrevotesRequest height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.PrevotesRequest
                 * @instance
                 */
                PrevotesRequest.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * PrevotesRequest round.
                 * @member {number} round
                 * @memberof exonum.consensus.PrevotesRequest
                 * @instance
                 */
                PrevotesRequest.prototype.round = 0;
    
                /**
                 * PrevotesRequest propose_hash.
                 * @member {exonum.crypto.IHash|null|undefined} propose_hash
                 * @memberof exonum.consensus.PrevotesRequest
                 * @instance
                 */
                PrevotesRequest.prototype.propose_hash = null;
    
                /**
                 * PrevotesRequest validators.
                 * @member {exonum.common.IBitVec|null|undefined} validators
                 * @memberof exonum.consensus.PrevotesRequest
                 * @instance
                 */
                PrevotesRequest.prototype.validators = null;
    
                /**
                 * Creates a new PrevotesRequest instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {exonum.consensus.IPrevotesRequest=} [properties] Properties to set
                 * @returns {exonum.consensus.PrevotesRequest} PrevotesRequest instance
                 */
                PrevotesRequest.create = function create(properties) {
                    return new PrevotesRequest(properties);
                };
    
                /**
                 * Encodes the specified PrevotesRequest message. Does not implicitly {@link exonum.consensus.PrevotesRequest.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {exonum.consensus.IPrevotesRequest} message PrevotesRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PrevotesRequest.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                    if (message.round != null && message.hasOwnProperty("round"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint32(message.round);
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        $root.exonum.crypto.Hash.encode(message.propose_hash, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    if (message.validators != null && message.hasOwnProperty("validators"))
                        $root.exonum.common.BitVec.encode(message.validators, writer.uint32(/* id 5, wireType 2 =*/42).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified PrevotesRequest message, length delimited. Does not implicitly {@link exonum.consensus.PrevotesRequest.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {exonum.consensus.IPrevotesRequest} message PrevotesRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PrevotesRequest.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a PrevotesRequest message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.PrevotesRequest} PrevotesRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PrevotesRequest.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.PrevotesRequest();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.height = reader.uint64();
                            break;
                        case 3:
                            message.round = reader.uint32();
                            break;
                        case 4:
                            message.propose_hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 5:
                            message.validators = $root.exonum.common.BitVec.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a PrevotesRequest message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.PrevotesRequest} PrevotesRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PrevotesRequest.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a PrevotesRequest message.
                 * @function verify
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                PrevotesRequest.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    if (message.round != null && message.hasOwnProperty("round"))
                        if (!$util.isInteger(message.round))
                            return "round: integer expected";
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.propose_hash);
                        if (error)
                            return "propose_hash." + error;
                    }
                    if (message.validators != null && message.hasOwnProperty("validators")) {
                        var error = $root.exonum.common.BitVec.verify(message.validators);
                        if (error)
                            return "validators." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a PrevotesRequest message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.PrevotesRequest} PrevotesRequest
                 */
                PrevotesRequest.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.PrevotesRequest)
                        return object;
                    var message = new $root.exonum.consensus.PrevotesRequest();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.PrevotesRequest.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    if (object.round != null)
                        message.round = object.round >>> 0;
                    if (object.propose_hash != null) {
                        if (typeof object.propose_hash !== "object")
                            throw TypeError(".exonum.consensus.PrevotesRequest.propose_hash: object expected");
                        message.propose_hash = $root.exonum.crypto.Hash.fromObject(object.propose_hash);
                    }
                    if (object.validators != null) {
                        if (typeof object.validators !== "object")
                            throw TypeError(".exonum.consensus.PrevotesRequest.validators: object expected");
                        message.validators = $root.exonum.common.BitVec.fromObject(object.validators);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a PrevotesRequest message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.PrevotesRequest
                 * @static
                 * @param {exonum.consensus.PrevotesRequest} message PrevotesRequest
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                PrevotesRequest.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.to = null;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                        object.round = 0;
                        object.propose_hash = null;
                        object.validators = null;
                    }
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    if (message.round != null && message.hasOwnProperty("round"))
                        object.round = message.round;
                    if (message.propose_hash != null && message.hasOwnProperty("propose_hash"))
                        object.propose_hash = $root.exonum.crypto.Hash.toObject(message.propose_hash, options);
                    if (message.validators != null && message.hasOwnProperty("validators"))
                        object.validators = $root.exonum.common.BitVec.toObject(message.validators, options);
                    return object;
                };
    
                /**
                 * Converts this PrevotesRequest to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.PrevotesRequest
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                PrevotesRequest.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return PrevotesRequest;
            })();
    
            consensus.PeersRequest = (function() {
    
                /**
                 * Properties of a PeersRequest.
                 * @memberof exonum.consensus
                 * @interface IPeersRequest
                 * @property {exonum.crypto.IPublicKey|null} [to] PeersRequest to
                 */
    
                /**
                 * Constructs a new PeersRequest.
                 * @memberof exonum.consensus
                 * @classdesc Represents a PeersRequest.
                 * @implements IPeersRequest
                 * @constructor
                 * @param {exonum.consensus.IPeersRequest=} [properties] Properties to set
                 */
                function PeersRequest(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * PeersRequest to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.PeersRequest
                 * @instance
                 */
                PeersRequest.prototype.to = null;
    
                /**
                 * Creates a new PeersRequest instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {exonum.consensus.IPeersRequest=} [properties] Properties to set
                 * @returns {exonum.consensus.PeersRequest} PeersRequest instance
                 */
                PeersRequest.create = function create(properties) {
                    return new PeersRequest(properties);
                };
    
                /**
                 * Encodes the specified PeersRequest message. Does not implicitly {@link exonum.consensus.PeersRequest.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {exonum.consensus.IPeersRequest} message PeersRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PeersRequest.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified PeersRequest message, length delimited. Does not implicitly {@link exonum.consensus.PeersRequest.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {exonum.consensus.IPeersRequest} message PeersRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PeersRequest.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a PeersRequest message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.PeersRequest} PeersRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PeersRequest.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.PeersRequest();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a PeersRequest message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.PeersRequest} PeersRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PeersRequest.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a PeersRequest message.
                 * @function verify
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                PeersRequest.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a PeersRequest message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.PeersRequest} PeersRequest
                 */
                PeersRequest.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.PeersRequest)
                        return object;
                    var message = new $root.exonum.consensus.PeersRequest();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.PeersRequest.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a PeersRequest message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.PeersRequest
                 * @static
                 * @param {exonum.consensus.PeersRequest} message PeersRequest
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                PeersRequest.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults)
                        object.to = null;
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    return object;
                };
    
                /**
                 * Converts this PeersRequest to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.PeersRequest
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                PeersRequest.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return PeersRequest;
            })();
    
            consensus.BlockRequest = (function() {
    
                /**
                 * Properties of a BlockRequest.
                 * @memberof exonum.consensus
                 * @interface IBlockRequest
                 * @property {exonum.crypto.IPublicKey|null} [to] BlockRequest to
                 * @property {number|Long|null} [height] BlockRequest height
                 */
    
                /**
                 * Constructs a new BlockRequest.
                 * @memberof exonum.consensus
                 * @classdesc Represents a BlockRequest.
                 * @implements IBlockRequest
                 * @constructor
                 * @param {exonum.consensus.IBlockRequest=} [properties] Properties to set
                 */
                function BlockRequest(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * BlockRequest to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.BlockRequest
                 * @instance
                 */
                BlockRequest.prototype.to = null;
    
                /**
                 * BlockRequest height.
                 * @member {number|Long} height
                 * @memberof exonum.consensus.BlockRequest
                 * @instance
                 */
                BlockRequest.prototype.height = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Creates a new BlockRequest instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {exonum.consensus.IBlockRequest=} [properties] Properties to set
                 * @returns {exonum.consensus.BlockRequest} BlockRequest instance
                 */
                BlockRequest.create = function create(properties) {
                    return new BlockRequest(properties);
                };
    
                /**
                 * Encodes the specified BlockRequest message. Does not implicitly {@link exonum.consensus.BlockRequest.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {exonum.consensus.IBlockRequest} message BlockRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BlockRequest.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.height);
                    return writer;
                };
    
                /**
                 * Encodes the specified BlockRequest message, length delimited. Does not implicitly {@link exonum.consensus.BlockRequest.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {exonum.consensus.IBlockRequest} message BlockRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BlockRequest.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a BlockRequest message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.BlockRequest} BlockRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BlockRequest.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.BlockRequest();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.height = reader.uint64();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a BlockRequest message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.BlockRequest} BlockRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BlockRequest.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a BlockRequest message.
                 * @function verify
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                BlockRequest.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height) && !(message.height && $util.isInteger(message.height.low) && $util.isInteger(message.height.high)))
                            return "height: integer|Long expected";
                    return null;
                };
    
                /**
                 * Creates a BlockRequest message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.BlockRequest} BlockRequest
                 */
                BlockRequest.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.BlockRequest)
                        return object;
                    var message = new $root.exonum.consensus.BlockRequest();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.BlockRequest.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    if (object.height != null)
                        if ($util.Long)
                            (message.height = $util.Long.fromValue(object.height)).unsigned = true;
                        else if (typeof object.height === "string")
                            message.height = parseInt(object.height, 10);
                        else if (typeof object.height === "number")
                            message.height = object.height;
                        else if (typeof object.height === "object")
                            message.height = new $util.LongBits(object.height.low >>> 0, object.height.high >>> 0).toNumber(true);
                    return message;
                };
    
                /**
                 * Creates a plain object from a BlockRequest message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.BlockRequest
                 * @static
                 * @param {exonum.consensus.BlockRequest} message BlockRequest
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                BlockRequest.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.to = null;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.height = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.height = options.longs === String ? "0" : 0;
                    }
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (typeof message.height === "number")
                            object.height = options.longs === String ? String(message.height) : message.height;
                        else
                            object.height = options.longs === String ? $util.Long.prototype.toString.call(message.height) : options.longs === Number ? new $util.LongBits(message.height.low >>> 0, message.height.high >>> 0).toNumber(true) : message.height;
                    return object;
                };
    
                /**
                 * Converts this BlockRequest to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.BlockRequest
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                BlockRequest.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return BlockRequest;
            })();
    
            consensus.PoolTransactionsRequest = (function() {
    
                /**
                 * Properties of a PoolTransactionsRequest.
                 * @memberof exonum.consensus
                 * @interface IPoolTransactionsRequest
                 * @property {exonum.crypto.IPublicKey|null} [to] PoolTransactionsRequest to
                 */
    
                /**
                 * Constructs a new PoolTransactionsRequest.
                 * @memberof exonum.consensus
                 * @classdesc Represents a PoolTransactionsRequest.
                 * @implements IPoolTransactionsRequest
                 * @constructor
                 * @param {exonum.consensus.IPoolTransactionsRequest=} [properties] Properties to set
                 */
                function PoolTransactionsRequest(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * PoolTransactionsRequest to.
                 * @member {exonum.crypto.IPublicKey|null|undefined} to
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @instance
                 */
                PoolTransactionsRequest.prototype.to = null;
    
                /**
                 * Creates a new PoolTransactionsRequest instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {exonum.consensus.IPoolTransactionsRequest=} [properties] Properties to set
                 * @returns {exonum.consensus.PoolTransactionsRequest} PoolTransactionsRequest instance
                 */
                PoolTransactionsRequest.create = function create(properties) {
                    return new PoolTransactionsRequest(properties);
                };
    
                /**
                 * Encodes the specified PoolTransactionsRequest message. Does not implicitly {@link exonum.consensus.PoolTransactionsRequest.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {exonum.consensus.IPoolTransactionsRequest} message PoolTransactionsRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PoolTransactionsRequest.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.to != null && message.hasOwnProperty("to"))
                        $root.exonum.crypto.PublicKey.encode(message.to, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified PoolTransactionsRequest message, length delimited. Does not implicitly {@link exonum.consensus.PoolTransactionsRequest.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {exonum.consensus.IPoolTransactionsRequest} message PoolTransactionsRequest message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                PoolTransactionsRequest.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a PoolTransactionsRequest message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.PoolTransactionsRequest} PoolTransactionsRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PoolTransactionsRequest.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.PoolTransactionsRequest();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.to = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a PoolTransactionsRequest message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.PoolTransactionsRequest} PoolTransactionsRequest
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                PoolTransactionsRequest.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a PoolTransactionsRequest message.
                 * @function verify
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                PoolTransactionsRequest.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.to != null && message.hasOwnProperty("to")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.to);
                        if (error)
                            return "to." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a PoolTransactionsRequest message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.PoolTransactionsRequest} PoolTransactionsRequest
                 */
                PoolTransactionsRequest.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.PoolTransactionsRequest)
                        return object;
                    var message = new $root.exonum.consensus.PoolTransactionsRequest();
                    if (object.to != null) {
                        if (typeof object.to !== "object")
                            throw TypeError(".exonum.consensus.PoolTransactionsRequest.to: object expected");
                        message.to = $root.exonum.crypto.PublicKey.fromObject(object.to);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a PoolTransactionsRequest message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @static
                 * @param {exonum.consensus.PoolTransactionsRequest} message PoolTransactionsRequest
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                PoolTransactionsRequest.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults)
                        object.to = null;
                    if (message.to != null && message.hasOwnProperty("to"))
                        object.to = $root.exonum.crypto.PublicKey.toObject(message.to, options);
                    return object;
                };
    
                /**
                 * Converts this PoolTransactionsRequest to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.PoolTransactionsRequest
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                PoolTransactionsRequest.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return PoolTransactionsRequest;
            })();
    
            consensus.ExonumMessage = (function() {
    
                /**
                 * Properties of an ExonumMessage.
                 * @memberof exonum.consensus
                 * @interface IExonumMessage
                 * @property {exonum.runtime.IAnyTx|null} [any_tx] ExonumMessage any_tx
                 * @property {exonum.consensus.IConnect|null} [connect] ExonumMessage connect
                 * @property {exonum.consensus.IStatus|null} [status] ExonumMessage status
                 * @property {exonum.consensus.IPrecommit|null} [precommit] ExonumMessage precommit
                 * @property {exonum.consensus.IPropose|null} [propose] ExonumMessage propose
                 * @property {exonum.consensus.IPrevote|null} [prevote] ExonumMessage prevote
                 * @property {exonum.consensus.ITransactionsResponse|null} [transactions_response] ExonumMessage transactions_response
                 * @property {exonum.consensus.IBlockResponse|null} [block_response] ExonumMessage block_response
                 * @property {exonum.consensus.IProposeRequest|null} [propose_request] ExonumMessage propose_request
                 * @property {exonum.consensus.ITransactionsRequest|null} [transactions_request] ExonumMessage transactions_request
                 * @property {exonum.consensus.IPrevotesRequest|null} [prevotes_request] ExonumMessage prevotes_request
                 * @property {exonum.consensus.IPeersRequest|null} [peers_request] ExonumMessage peers_request
                 * @property {exonum.consensus.IBlockRequest|null} [block_request] ExonumMessage block_request
                 * @property {exonum.consensus.IPoolTransactionsRequest|null} [pool_transactions_request] ExonumMessage pool_transactions_request
                 */
    
                /**
                 * Constructs a new ExonumMessage.
                 * @memberof exonum.consensus
                 * @classdesc Represents an ExonumMessage.
                 * @implements IExonumMessage
                 * @constructor
                 * @param {exonum.consensus.IExonumMessage=} [properties] Properties to set
                 */
                function ExonumMessage(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ExonumMessage any_tx.
                 * @member {exonum.runtime.IAnyTx|null|undefined} any_tx
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.any_tx = null;
    
                /**
                 * ExonumMessage connect.
                 * @member {exonum.consensus.IConnect|null|undefined} connect
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.connect = null;
    
                /**
                 * ExonumMessage status.
                 * @member {exonum.consensus.IStatus|null|undefined} status
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.status = null;
    
                /**
                 * ExonumMessage precommit.
                 * @member {exonum.consensus.IPrecommit|null|undefined} precommit
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.precommit = null;
    
                /**
                 * ExonumMessage propose.
                 * @member {exonum.consensus.IPropose|null|undefined} propose
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.propose = null;
    
                /**
                 * ExonumMessage prevote.
                 * @member {exonum.consensus.IPrevote|null|undefined} prevote
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.prevote = null;
    
                /**
                 * ExonumMessage transactions_response.
                 * @member {exonum.consensus.ITransactionsResponse|null|undefined} transactions_response
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.transactions_response = null;
    
                /**
                 * ExonumMessage block_response.
                 * @member {exonum.consensus.IBlockResponse|null|undefined} block_response
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.block_response = null;
    
                /**
                 * ExonumMessage propose_request.
                 * @member {exonum.consensus.IProposeRequest|null|undefined} propose_request
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.propose_request = null;
    
                /**
                 * ExonumMessage transactions_request.
                 * @member {exonum.consensus.ITransactionsRequest|null|undefined} transactions_request
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.transactions_request = null;
    
                /**
                 * ExonumMessage prevotes_request.
                 * @member {exonum.consensus.IPrevotesRequest|null|undefined} prevotes_request
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.prevotes_request = null;
    
                /**
                 * ExonumMessage peers_request.
                 * @member {exonum.consensus.IPeersRequest|null|undefined} peers_request
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.peers_request = null;
    
                /**
                 * ExonumMessage block_request.
                 * @member {exonum.consensus.IBlockRequest|null|undefined} block_request
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.block_request = null;
    
                /**
                 * ExonumMessage pool_transactions_request.
                 * @member {exonum.consensus.IPoolTransactionsRequest|null|undefined} pool_transactions_request
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                ExonumMessage.prototype.pool_transactions_request = null;
    
                // OneOf field names bound to virtual getters and setters
                var $oneOfFields;
    
                /**
                 * ExonumMessage kind.
                 * @member {"any_tx"|"connect"|"status"|"precommit"|"propose"|"prevote"|"transactions_response"|"block_response"|"propose_request"|"transactions_request"|"prevotes_request"|"peers_request"|"block_request"|"pool_transactions_request"|undefined} kind
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 */
                Object.defineProperty(ExonumMessage.prototype, "kind", {
                    get: $util.oneOfGetter($oneOfFields = ["any_tx", "connect", "status", "precommit", "propose", "prevote", "transactions_response", "block_response", "propose_request", "transactions_request", "prevotes_request", "peers_request", "block_request", "pool_transactions_request"]),
                    set: $util.oneOfSetter($oneOfFields)
                });
    
                /**
                 * Creates a new ExonumMessage instance using the specified properties.
                 * @function create
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {exonum.consensus.IExonumMessage=} [properties] Properties to set
                 * @returns {exonum.consensus.ExonumMessage} ExonumMessage instance
                 */
                ExonumMessage.create = function create(properties) {
                    return new ExonumMessage(properties);
                };
    
                /**
                 * Encodes the specified ExonumMessage message. Does not implicitly {@link exonum.consensus.ExonumMessage.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {exonum.consensus.IExonumMessage} message ExonumMessage message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ExonumMessage.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.any_tx != null && message.hasOwnProperty("any_tx"))
                        $root.exonum.runtime.AnyTx.encode(message.any_tx, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.connect != null && message.hasOwnProperty("connect"))
                        $root.exonum.consensus.Connect.encode(message.connect, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.status != null && message.hasOwnProperty("status"))
                        $root.exonum.consensus.Status.encode(message.status, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    if (message.precommit != null && message.hasOwnProperty("precommit"))
                        $root.exonum.consensus.Precommit.encode(message.precommit, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    if (message.propose != null && message.hasOwnProperty("propose"))
                        $root.exonum.consensus.Propose.encode(message.propose, writer.uint32(/* id 5, wireType 2 =*/42).fork()).ldelim();
                    if (message.prevote != null && message.hasOwnProperty("prevote"))
                        $root.exonum.consensus.Prevote.encode(message.prevote, writer.uint32(/* id 6, wireType 2 =*/50).fork()).ldelim();
                    if (message.transactions_response != null && message.hasOwnProperty("transactions_response"))
                        $root.exonum.consensus.TransactionsResponse.encode(message.transactions_response, writer.uint32(/* id 7, wireType 2 =*/58).fork()).ldelim();
                    if (message.block_response != null && message.hasOwnProperty("block_response"))
                        $root.exonum.consensus.BlockResponse.encode(message.block_response, writer.uint32(/* id 8, wireType 2 =*/66).fork()).ldelim();
                    if (message.propose_request != null && message.hasOwnProperty("propose_request"))
                        $root.exonum.consensus.ProposeRequest.encode(message.propose_request, writer.uint32(/* id 9, wireType 2 =*/74).fork()).ldelim();
                    if (message.transactions_request != null && message.hasOwnProperty("transactions_request"))
                        $root.exonum.consensus.TransactionsRequest.encode(message.transactions_request, writer.uint32(/* id 10, wireType 2 =*/82).fork()).ldelim();
                    if (message.prevotes_request != null && message.hasOwnProperty("prevotes_request"))
                        $root.exonum.consensus.PrevotesRequest.encode(message.prevotes_request, writer.uint32(/* id 11, wireType 2 =*/90).fork()).ldelim();
                    if (message.peers_request != null && message.hasOwnProperty("peers_request"))
                        $root.exonum.consensus.PeersRequest.encode(message.peers_request, writer.uint32(/* id 12, wireType 2 =*/98).fork()).ldelim();
                    if (message.block_request != null && message.hasOwnProperty("block_request"))
                        $root.exonum.consensus.BlockRequest.encode(message.block_request, writer.uint32(/* id 13, wireType 2 =*/106).fork()).ldelim();
                    if (message.pool_transactions_request != null && message.hasOwnProperty("pool_transactions_request"))
                        $root.exonum.consensus.PoolTransactionsRequest.encode(message.pool_transactions_request, writer.uint32(/* id 14, wireType 2 =*/114).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified ExonumMessage message, length delimited. Does not implicitly {@link exonum.consensus.ExonumMessage.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {exonum.consensus.IExonumMessage} message ExonumMessage message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ExonumMessage.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an ExonumMessage message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.consensus.ExonumMessage} ExonumMessage
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ExonumMessage.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.consensus.ExonumMessage();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.any_tx = $root.exonum.runtime.AnyTx.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.connect = $root.exonum.consensus.Connect.decode(reader, reader.uint32());
                            break;
                        case 3:
                            message.status = $root.exonum.consensus.Status.decode(reader, reader.uint32());
                            break;
                        case 4:
                            message.precommit = $root.exonum.consensus.Precommit.decode(reader, reader.uint32());
                            break;
                        case 5:
                            message.propose = $root.exonum.consensus.Propose.decode(reader, reader.uint32());
                            break;
                        case 6:
                            message.prevote = $root.exonum.consensus.Prevote.decode(reader, reader.uint32());
                            break;
                        case 7:
                            message.transactions_response = $root.exonum.consensus.TransactionsResponse.decode(reader, reader.uint32());
                            break;
                        case 8:
                            message.block_response = $root.exonum.consensus.BlockResponse.decode(reader, reader.uint32());
                            break;
                        case 9:
                            message.propose_request = $root.exonum.consensus.ProposeRequest.decode(reader, reader.uint32());
                            break;
                        case 10:
                            message.transactions_request = $root.exonum.consensus.TransactionsRequest.decode(reader, reader.uint32());
                            break;
                        case 11:
                            message.prevotes_request = $root.exonum.consensus.PrevotesRequest.decode(reader, reader.uint32());
                            break;
                        case 12:
                            message.peers_request = $root.exonum.consensus.PeersRequest.decode(reader, reader.uint32());
                            break;
                        case 13:
                            message.block_request = $root.exonum.consensus.BlockRequest.decode(reader, reader.uint32());
                            break;
                        case 14:
                            message.pool_transactions_request = $root.exonum.consensus.PoolTransactionsRequest.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an ExonumMessage message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.consensus.ExonumMessage} ExonumMessage
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ExonumMessage.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an ExonumMessage message.
                 * @function verify
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ExonumMessage.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    var properties = {};
                    if (message.any_tx != null && message.hasOwnProperty("any_tx")) {
                        properties.kind = 1;
                        {
                            var error = $root.exonum.runtime.AnyTx.verify(message.any_tx);
                            if (error)
                                return "any_tx." + error;
                        }
                    }
                    if (message.connect != null && message.hasOwnProperty("connect")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.Connect.verify(message.connect);
                            if (error)
                                return "connect." + error;
                        }
                    }
                    if (message.status != null && message.hasOwnProperty("status")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.Status.verify(message.status);
                            if (error)
                                return "status." + error;
                        }
                    }
                    if (message.precommit != null && message.hasOwnProperty("precommit")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.Precommit.verify(message.precommit);
                            if (error)
                                return "precommit." + error;
                        }
                    }
                    if (message.propose != null && message.hasOwnProperty("propose")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.Propose.verify(message.propose);
                            if (error)
                                return "propose." + error;
                        }
                    }
                    if (message.prevote != null && message.hasOwnProperty("prevote")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.Prevote.verify(message.prevote);
                            if (error)
                                return "prevote." + error;
                        }
                    }
                    if (message.transactions_response != null && message.hasOwnProperty("transactions_response")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.TransactionsResponse.verify(message.transactions_response);
                            if (error)
                                return "transactions_response." + error;
                        }
                    }
                    if (message.block_response != null && message.hasOwnProperty("block_response")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.BlockResponse.verify(message.block_response);
                            if (error)
                                return "block_response." + error;
                        }
                    }
                    if (message.propose_request != null && message.hasOwnProperty("propose_request")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.ProposeRequest.verify(message.propose_request);
                            if (error)
                                return "propose_request." + error;
                        }
                    }
                    if (message.transactions_request != null && message.hasOwnProperty("transactions_request")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.TransactionsRequest.verify(message.transactions_request);
                            if (error)
                                return "transactions_request." + error;
                        }
                    }
                    if (message.prevotes_request != null && message.hasOwnProperty("prevotes_request")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.PrevotesRequest.verify(message.prevotes_request);
                            if (error)
                                return "prevotes_request." + error;
                        }
                    }
                    if (message.peers_request != null && message.hasOwnProperty("peers_request")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.PeersRequest.verify(message.peers_request);
                            if (error)
                                return "peers_request." + error;
                        }
                    }
                    if (message.block_request != null && message.hasOwnProperty("block_request")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.BlockRequest.verify(message.block_request);
                            if (error)
                                return "block_request." + error;
                        }
                    }
                    if (message.pool_transactions_request != null && message.hasOwnProperty("pool_transactions_request")) {
                        if (properties.kind === 1)
                            return "kind: multiple values";
                        properties.kind = 1;
                        {
                            var error = $root.exonum.consensus.PoolTransactionsRequest.verify(message.pool_transactions_request);
                            if (error)
                                return "pool_transactions_request." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates an ExonumMessage message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.consensus.ExonumMessage} ExonumMessage
                 */
                ExonumMessage.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.consensus.ExonumMessage)
                        return object;
                    var message = new $root.exonum.consensus.ExonumMessage();
                    if (object.any_tx != null) {
                        if (typeof object.any_tx !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.any_tx: object expected");
                        message.any_tx = $root.exonum.runtime.AnyTx.fromObject(object.any_tx);
                    }
                    if (object.connect != null) {
                        if (typeof object.connect !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.connect: object expected");
                        message.connect = $root.exonum.consensus.Connect.fromObject(object.connect);
                    }
                    if (object.status != null) {
                        if (typeof object.status !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.status: object expected");
                        message.status = $root.exonum.consensus.Status.fromObject(object.status);
                    }
                    if (object.precommit != null) {
                        if (typeof object.precommit !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.precommit: object expected");
                        message.precommit = $root.exonum.consensus.Precommit.fromObject(object.precommit);
                    }
                    if (object.propose != null) {
                        if (typeof object.propose !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.propose: object expected");
                        message.propose = $root.exonum.consensus.Propose.fromObject(object.propose);
                    }
                    if (object.prevote != null) {
                        if (typeof object.prevote !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.prevote: object expected");
                        message.prevote = $root.exonum.consensus.Prevote.fromObject(object.prevote);
                    }
                    if (object.transactions_response != null) {
                        if (typeof object.transactions_response !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.transactions_response: object expected");
                        message.transactions_response = $root.exonum.consensus.TransactionsResponse.fromObject(object.transactions_response);
                    }
                    if (object.block_response != null) {
                        if (typeof object.block_response !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.block_response: object expected");
                        message.block_response = $root.exonum.consensus.BlockResponse.fromObject(object.block_response);
                    }
                    if (object.propose_request != null) {
                        if (typeof object.propose_request !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.propose_request: object expected");
                        message.propose_request = $root.exonum.consensus.ProposeRequest.fromObject(object.propose_request);
                    }
                    if (object.transactions_request != null) {
                        if (typeof object.transactions_request !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.transactions_request: object expected");
                        message.transactions_request = $root.exonum.consensus.TransactionsRequest.fromObject(object.transactions_request);
                    }
                    if (object.prevotes_request != null) {
                        if (typeof object.prevotes_request !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.prevotes_request: object expected");
                        message.prevotes_request = $root.exonum.consensus.PrevotesRequest.fromObject(object.prevotes_request);
                    }
                    if (object.peers_request != null) {
                        if (typeof object.peers_request !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.peers_request: object expected");
                        message.peers_request = $root.exonum.consensus.PeersRequest.fromObject(object.peers_request);
                    }
                    if (object.block_request != null) {
                        if (typeof object.block_request !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.block_request: object expected");
                        message.block_request = $root.exonum.consensus.BlockRequest.fromObject(object.block_request);
                    }
                    if (object.pool_transactions_request != null) {
                        if (typeof object.pool_transactions_request !== "object")
                            throw TypeError(".exonum.consensus.ExonumMessage.pool_transactions_request: object expected");
                        message.pool_transactions_request = $root.exonum.consensus.PoolTransactionsRequest.fromObject(object.pool_transactions_request);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from an ExonumMessage message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.consensus.ExonumMessage
                 * @static
                 * @param {exonum.consensus.ExonumMessage} message ExonumMessage
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ExonumMessage.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (message.any_tx != null && message.hasOwnProperty("any_tx")) {
                        object.any_tx = $root.exonum.runtime.AnyTx.toObject(message.any_tx, options);
                        if (options.oneofs)
                            object.kind = "any_tx";
                    }
                    if (message.connect != null && message.hasOwnProperty("connect")) {
                        object.connect = $root.exonum.consensus.Connect.toObject(message.connect, options);
                        if (options.oneofs)
                            object.kind = "connect";
                    }
                    if (message.status != null && message.hasOwnProperty("status")) {
                        object.status = $root.exonum.consensus.Status.toObject(message.status, options);
                        if (options.oneofs)
                            object.kind = "status";
                    }
                    if (message.precommit != null && message.hasOwnProperty("precommit")) {
                        object.precommit = $root.exonum.consensus.Precommit.toObject(message.precommit, options);
                        if (options.oneofs)
                            object.kind = "precommit";
                    }
                    if (message.propose != null && message.hasOwnProperty("propose")) {
                        object.propose = $root.exonum.consensus.Propose.toObject(message.propose, options);
                        if (options.oneofs)
                            object.kind = "propose";
                    }
                    if (message.prevote != null && message.hasOwnProperty("prevote")) {
                        object.prevote = $root.exonum.consensus.Prevote.toObject(message.prevote, options);
                        if (options.oneofs)
                            object.kind = "prevote";
                    }
                    if (message.transactions_response != null && message.hasOwnProperty("transactions_response")) {
                        object.transactions_response = $root.exonum.consensus.TransactionsResponse.toObject(message.transactions_response, options);
                        if (options.oneofs)
                            object.kind = "transactions_response";
                    }
                    if (message.block_response != null && message.hasOwnProperty("block_response")) {
                        object.block_response = $root.exonum.consensus.BlockResponse.toObject(message.block_response, options);
                        if (options.oneofs)
                            object.kind = "block_response";
                    }
                    if (message.propose_request != null && message.hasOwnProperty("propose_request")) {
                        object.propose_request = $root.exonum.consensus.ProposeRequest.toObject(message.propose_request, options);
                        if (options.oneofs)
                            object.kind = "propose_request";
                    }
                    if (message.transactions_request != null && message.hasOwnProperty("transactions_request")) {
                        object.transactions_request = $root.exonum.consensus.TransactionsRequest.toObject(message.transactions_request, options);
                        if (options.oneofs)
                            object.kind = "transactions_request";
                    }
                    if (message.prevotes_request != null && message.hasOwnProperty("prevotes_request")) {
                        object.prevotes_request = $root.exonum.consensus.PrevotesRequest.toObject(message.prevotes_request, options);
                        if (options.oneofs)
                            object.kind = "prevotes_request";
                    }
                    if (message.peers_request != null && message.hasOwnProperty("peers_request")) {
                        object.peers_request = $root.exonum.consensus.PeersRequest.toObject(message.peers_request, options);
                        if (options.oneofs)
                            object.kind = "peers_request";
                    }
                    if (message.block_request != null && message.hasOwnProperty("block_request")) {
                        object.block_request = $root.exonum.consensus.BlockRequest.toObject(message.block_request, options);
                        if (options.oneofs)
                            object.kind = "block_request";
                    }
                    if (message.pool_transactions_request != null && message.hasOwnProperty("pool_transactions_request")) {
                        object.pool_transactions_request = $root.exonum.consensus.PoolTransactionsRequest.toObject(message.pool_transactions_request, options);
                        if (options.oneofs)
                            object.kind = "pool_transactions_request";
                    }
                    return object;
                };
    
                /**
                 * Converts this ExonumMessage to JSON.
                 * @function toJSON
                 * @memberof exonum.consensus.ExonumMessage
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ExonumMessage.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ExonumMessage;
            })();
    
            return consensus;
        })();
    
        exonum.common = (function() {
    
            /**
             * Namespace common.
             * @memberof exonum
             * @namespace
             */
            var common = {};
    
            common.BitVec = (function() {
    
                /**
                 * Properties of a BitVec.
                 * @memberof exonum.common
                 * @interface IBitVec
                 * @property {Uint8Array|null} [data] BitVec data
                 * @property {number|Long|null} [len] BitVec len
                 */
    
                /**
                 * Constructs a new BitVec.
                 * @memberof exonum.common
                 * @classdesc Represents a BitVec.
                 * @implements IBitVec
                 * @constructor
                 * @param {exonum.common.IBitVec=} [properties] Properties to set
                 */
                function BitVec(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * BitVec data.
                 * @member {Uint8Array} data
                 * @memberof exonum.common.BitVec
                 * @instance
                 */
                BitVec.prototype.data = $util.newBuffer([]);
    
                /**
                 * BitVec len.
                 * @member {number|Long} len
                 * @memberof exonum.common.BitVec
                 * @instance
                 */
                BitVec.prototype.len = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Creates a new BitVec instance using the specified properties.
                 * @function create
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {exonum.common.IBitVec=} [properties] Properties to set
                 * @returns {exonum.common.BitVec} BitVec instance
                 */
                BitVec.create = function create(properties) {
                    return new BitVec(properties);
                };
    
                /**
                 * Encodes the specified BitVec message. Does not implicitly {@link exonum.common.BitVec.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {exonum.common.IBitVec} message BitVec message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BitVec.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.data != null && message.hasOwnProperty("data"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.data);
                    if (message.len != null && message.hasOwnProperty("len"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint64(message.len);
                    return writer;
                };
    
                /**
                 * Encodes the specified BitVec message, length delimited. Does not implicitly {@link exonum.common.BitVec.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {exonum.common.IBitVec} message BitVec message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BitVec.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a BitVec message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.common.BitVec} BitVec
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BitVec.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.common.BitVec();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.data = reader.bytes();
                            break;
                        case 2:
                            message.len = reader.uint64();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a BitVec message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.common.BitVec} BitVec
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BitVec.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a BitVec message.
                 * @function verify
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                BitVec.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.data != null && message.hasOwnProperty("data"))
                        if (!(message.data && typeof message.data.length === "number" || $util.isString(message.data)))
                            return "data: buffer expected";
                    if (message.len != null && message.hasOwnProperty("len"))
                        if (!$util.isInteger(message.len) && !(message.len && $util.isInteger(message.len.low) && $util.isInteger(message.len.high)))
                            return "len: integer|Long expected";
                    return null;
                };
    
                /**
                 * Creates a BitVec message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.common.BitVec} BitVec
                 */
                BitVec.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.common.BitVec)
                        return object;
                    var message = new $root.exonum.common.BitVec();
                    if (object.data != null)
                        if (typeof object.data === "string")
                            $util.base64.decode(object.data, message.data = $util.newBuffer($util.base64.length(object.data)), 0);
                        else if (object.data.length)
                            message.data = object.data;
                    if (object.len != null)
                        if ($util.Long)
                            (message.len = $util.Long.fromValue(object.len)).unsigned = true;
                        else if (typeof object.len === "string")
                            message.len = parseInt(object.len, 10);
                        else if (typeof object.len === "number")
                            message.len = object.len;
                        else if (typeof object.len === "object")
                            message.len = new $util.LongBits(object.len.low >>> 0, object.len.high >>> 0).toNumber(true);
                    return message;
                };
    
                /**
                 * Creates a plain object from a BitVec message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.common.BitVec
                 * @static
                 * @param {exonum.common.BitVec} message BitVec
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                BitVec.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if (options.bytes === String)
                            object.data = "";
                        else {
                            object.data = [];
                            if (options.bytes !== Array)
                                object.data = $util.newBuffer(object.data);
                        }
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.len = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.len = options.longs === String ? "0" : 0;
                    }
                    if (message.data != null && message.hasOwnProperty("data"))
                        object.data = options.bytes === String ? $util.base64.encode(message.data, 0, message.data.length) : options.bytes === Array ? Array.prototype.slice.call(message.data) : message.data;
                    if (message.len != null && message.hasOwnProperty("len"))
                        if (typeof message.len === "number")
                            object.len = options.longs === String ? String(message.len) : message.len;
                        else
                            object.len = options.longs === String ? $util.Long.prototype.toString.call(message.len) : options.longs === Number ? new $util.LongBits(message.len.low >>> 0, message.len.high >>> 0).toNumber(true) : message.len;
                    return object;
                };
    
                /**
                 * Converts this BitVec to JSON.
                 * @function toJSON
                 * @memberof exonum.common.BitVec
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                BitVec.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return BitVec;
            })();
    
            return common;
        })();
    
        exonum.runtime = (function() {
    
            /**
             * Namespace runtime.
             * @memberof exonum
             * @namespace
             */
            var runtime = {};
    
            runtime.CallInfo = (function() {
    
                /**
                 * Properties of a CallInfo.
                 * @memberof exonum.runtime
                 * @interface ICallInfo
                 * @property {number|null} [instance_id] CallInfo instance_id
                 * @property {number|null} [method_id] CallInfo method_id
                 */
    
                /**
                 * Constructs a new CallInfo.
                 * @memberof exonum.runtime
                 * @classdesc Represents a CallInfo.
                 * @implements ICallInfo
                 * @constructor
                 * @param {exonum.runtime.ICallInfo=} [properties] Properties to set
                 */
                function CallInfo(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * CallInfo instance_id.
                 * @member {number} instance_id
                 * @memberof exonum.runtime.CallInfo
                 * @instance
                 */
                CallInfo.prototype.instance_id = 0;
    
                /**
                 * CallInfo method_id.
                 * @member {number} method_id
                 * @memberof exonum.runtime.CallInfo
                 * @instance
                 */
                CallInfo.prototype.method_id = 0;
    
                /**
                 * Creates a new CallInfo instance using the specified properties.
                 * @function create
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {exonum.runtime.ICallInfo=} [properties] Properties to set
                 * @returns {exonum.runtime.CallInfo} CallInfo instance
                 */
                CallInfo.create = function create(properties) {
                    return new CallInfo(properties);
                };
    
                /**
                 * Encodes the specified CallInfo message. Does not implicitly {@link exonum.runtime.CallInfo.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {exonum.runtime.ICallInfo} message CallInfo message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                CallInfo.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.instance_id != null && message.hasOwnProperty("instance_id"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.instance_id);
                    if (message.method_id != null && message.hasOwnProperty("method_id"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint32(message.method_id);
                    return writer;
                };
    
                /**
                 * Encodes the specified CallInfo message, length delimited. Does not implicitly {@link exonum.runtime.CallInfo.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {exonum.runtime.ICallInfo} message CallInfo message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                CallInfo.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a CallInfo message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.runtime.CallInfo} CallInfo
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                CallInfo.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.runtime.CallInfo();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.instance_id = reader.uint32();
                            break;
                        case 2:
                            message.method_id = reader.uint32();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a CallInfo message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.runtime.CallInfo} CallInfo
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                CallInfo.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a CallInfo message.
                 * @function verify
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                CallInfo.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.instance_id != null && message.hasOwnProperty("instance_id"))
                        if (!$util.isInteger(message.instance_id))
                            return "instance_id: integer expected";
                    if (message.method_id != null && message.hasOwnProperty("method_id"))
                        if (!$util.isInteger(message.method_id))
                            return "method_id: integer expected";
                    return null;
                };
    
                /**
                 * Creates a CallInfo message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.runtime.CallInfo} CallInfo
                 */
                CallInfo.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.runtime.CallInfo)
                        return object;
                    var message = new $root.exonum.runtime.CallInfo();
                    if (object.instance_id != null)
                        message.instance_id = object.instance_id >>> 0;
                    if (object.method_id != null)
                        message.method_id = object.method_id >>> 0;
                    return message;
                };
    
                /**
                 * Creates a plain object from a CallInfo message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.runtime.CallInfo
                 * @static
                 * @param {exonum.runtime.CallInfo} message CallInfo
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                CallInfo.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.instance_id = 0;
                        object.method_id = 0;
                    }
                    if (message.instance_id != null && message.hasOwnProperty("instance_id"))
                        object.instance_id = message.instance_id;
                    if (message.method_id != null && message.hasOwnProperty("method_id"))
                        object.method_id = message.method_id;
                    return object;
                };
    
                /**
                 * Converts this CallInfo to JSON.
                 * @function toJSON
                 * @memberof exonum.runtime.CallInfo
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                CallInfo.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return CallInfo;
            })();
    
            runtime.AnyTx = (function() {
    
                /**
                 * Properties of an AnyTx.
                 * @memberof exonum.runtime
                 * @interface IAnyTx
                 * @property {exonum.runtime.ICallInfo|null} [call_info] AnyTx call_info
                 * @property {Uint8Array|null} ["arguments"] AnyTx arguments
                 */
    
                /**
                 * Constructs a new AnyTx.
                 * @memberof exonum.runtime
                 * @classdesc Represents an AnyTx.
                 * @implements IAnyTx
                 * @constructor
                 * @param {exonum.runtime.IAnyTx=} [properties] Properties to set
                 */
                function AnyTx(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * AnyTx call_info.
                 * @member {exonum.runtime.ICallInfo|null|undefined} call_info
                 * @memberof exonum.runtime.AnyTx
                 * @instance
                 */
                AnyTx.prototype.call_info = null;
    
                /**
                 * AnyTx arguments.
                 * @member {Uint8Array} arguments
                 * @memberof exonum.runtime.AnyTx
                 * @instance
                 */
                AnyTx.prototype["arguments"] = $util.newBuffer([]);
    
                /**
                 * Creates a new AnyTx instance using the specified properties.
                 * @function create
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {exonum.runtime.IAnyTx=} [properties] Properties to set
                 * @returns {exonum.runtime.AnyTx} AnyTx instance
                 */
                AnyTx.create = function create(properties) {
                    return new AnyTx(properties);
                };
    
                /**
                 * Encodes the specified AnyTx message. Does not implicitly {@link exonum.runtime.AnyTx.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {exonum.runtime.IAnyTx} message AnyTx message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                AnyTx.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.call_info != null && message.hasOwnProperty("call_info"))
                        $root.exonum.runtime.CallInfo.encode(message.call_info, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message["arguments"] != null && message.hasOwnProperty("arguments"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message["arguments"]);
                    return writer;
                };
    
                /**
                 * Encodes the specified AnyTx message, length delimited. Does not implicitly {@link exonum.runtime.AnyTx.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {exonum.runtime.IAnyTx} message AnyTx message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                AnyTx.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an AnyTx message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.runtime.AnyTx} AnyTx
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                AnyTx.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.runtime.AnyTx();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.call_info = $root.exonum.runtime.CallInfo.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message["arguments"] = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an AnyTx message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.runtime.AnyTx} AnyTx
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                AnyTx.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an AnyTx message.
                 * @function verify
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                AnyTx.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.call_info != null && message.hasOwnProperty("call_info")) {
                        var error = $root.exonum.runtime.CallInfo.verify(message.call_info);
                        if (error)
                            return "call_info." + error;
                    }
                    if (message["arguments"] != null && message.hasOwnProperty("arguments"))
                        if (!(message["arguments"] && typeof message["arguments"].length === "number" || $util.isString(message["arguments"])))
                            return "arguments: buffer expected";
                    return null;
                };
    
                /**
                 * Creates an AnyTx message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.runtime.AnyTx} AnyTx
                 */
                AnyTx.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.runtime.AnyTx)
                        return object;
                    var message = new $root.exonum.runtime.AnyTx();
                    if (object.call_info != null) {
                        if (typeof object.call_info !== "object")
                            throw TypeError(".exonum.runtime.AnyTx.call_info: object expected");
                        message.call_info = $root.exonum.runtime.CallInfo.fromObject(object.call_info);
                    }
                    if (object["arguments"] != null)
                        if (typeof object["arguments"] === "string")
                            $util.base64.decode(object["arguments"], message["arguments"] = $util.newBuffer($util.base64.length(object["arguments"])), 0);
                        else if (object["arguments"].length)
                            message["arguments"] = object["arguments"];
                    return message;
                };
    
                /**
                 * Creates a plain object from an AnyTx message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.runtime.AnyTx
                 * @static
                 * @param {exonum.runtime.AnyTx} message AnyTx
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                AnyTx.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.call_info = null;
                        if (options.bytes === String)
                            object["arguments"] = "";
                        else {
                            object["arguments"] = [];
                            if (options.bytes !== Array)
                                object["arguments"] = $util.newBuffer(object["arguments"]);
                        }
                    }
                    if (message.call_info != null && message.hasOwnProperty("call_info"))
                        object.call_info = $root.exonum.runtime.CallInfo.toObject(message.call_info, options);
                    if (message["arguments"] != null && message.hasOwnProperty("arguments"))
                        object["arguments"] = options.bytes === String ? $util.base64.encode(message["arguments"], 0, message["arguments"].length) : options.bytes === Array ? Array.prototype.slice.call(message["arguments"]) : message["arguments"];
                    return object;
                };
    
                /**
                 * Converts this AnyTx to JSON.
                 * @function toJSON
                 * @memberof exonum.runtime.AnyTx
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                AnyTx.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return AnyTx;
            })();
    
            runtime.ArtifactId = (function() {
    
                /**
                 * Properties of an ArtifactId.
                 * @memberof exonum.runtime
                 * @interface IArtifactId
                 * @property {number|null} [runtime_id] ArtifactId runtime_id
                 * @property {string|null} [name] ArtifactId name
                 */
    
                /**
                 * Constructs a new ArtifactId.
                 * @memberof exonum.runtime
                 * @classdesc Represents an ArtifactId.
                 * @implements IArtifactId
                 * @constructor
                 * @param {exonum.runtime.IArtifactId=} [properties] Properties to set
                 */
                function ArtifactId(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ArtifactId runtime_id.
                 * @member {number} runtime_id
                 * @memberof exonum.runtime.ArtifactId
                 * @instance
                 */
                ArtifactId.prototype.runtime_id = 0;
    
                /**
                 * ArtifactId name.
                 * @member {string} name
                 * @memberof exonum.runtime.ArtifactId
                 * @instance
                 */
                ArtifactId.prototype.name = "";
    
                /**
                 * Creates a new ArtifactId instance using the specified properties.
                 * @function create
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {exonum.runtime.IArtifactId=} [properties] Properties to set
                 * @returns {exonum.runtime.ArtifactId} ArtifactId instance
                 */
                ArtifactId.create = function create(properties) {
                    return new ArtifactId(properties);
                };
    
                /**
                 * Encodes the specified ArtifactId message. Does not implicitly {@link exonum.runtime.ArtifactId.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {exonum.runtime.IArtifactId} message ArtifactId message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ArtifactId.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.runtime_id != null && message.hasOwnProperty("runtime_id"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.runtime_id);
                    if (message.name != null && message.hasOwnProperty("name"))
                        writer.uint32(/* id 2, wireType 2 =*/18).string(message.name);
                    return writer;
                };
    
                /**
                 * Encodes the specified ArtifactId message, length delimited. Does not implicitly {@link exonum.runtime.ArtifactId.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {exonum.runtime.IArtifactId} message ArtifactId message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ArtifactId.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an ArtifactId message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.runtime.ArtifactId} ArtifactId
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ArtifactId.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.runtime.ArtifactId();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.runtime_id = reader.uint32();
                            break;
                        case 2:
                            message.name = reader.string();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an ArtifactId message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.runtime.ArtifactId} ArtifactId
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ArtifactId.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an ArtifactId message.
                 * @function verify
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ArtifactId.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.runtime_id != null && message.hasOwnProperty("runtime_id"))
                        if (!$util.isInteger(message.runtime_id))
                            return "runtime_id: integer expected";
                    if (message.name != null && message.hasOwnProperty("name"))
                        if (!$util.isString(message.name))
                            return "name: string expected";
                    return null;
                };
    
                /**
                 * Creates an ArtifactId message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.runtime.ArtifactId} ArtifactId
                 */
                ArtifactId.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.runtime.ArtifactId)
                        return object;
                    var message = new $root.exonum.runtime.ArtifactId();
                    if (object.runtime_id != null)
                        message.runtime_id = object.runtime_id >>> 0;
                    if (object.name != null)
                        message.name = String(object.name);
                    return message;
                };
    
                /**
                 * Creates a plain object from an ArtifactId message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.runtime.ArtifactId
                 * @static
                 * @param {exonum.runtime.ArtifactId} message ArtifactId
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ArtifactId.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.runtime_id = 0;
                        object.name = "";
                    }
                    if (message.runtime_id != null && message.hasOwnProperty("runtime_id"))
                        object.runtime_id = message.runtime_id;
                    if (message.name != null && message.hasOwnProperty("name"))
                        object.name = message.name;
                    return object;
                };
    
                /**
                 * Converts this ArtifactId to JSON.
                 * @function toJSON
                 * @memberof exonum.runtime.ArtifactId
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ArtifactId.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ArtifactId;
            })();
    
            runtime.ArtifactSpec = (function() {
    
                /**
                 * Properties of an ArtifactSpec.
                 * @memberof exonum.runtime
                 * @interface IArtifactSpec
                 * @property {exonum.runtime.IArtifactId|null} [artifact] ArtifactSpec artifact
                 * @property {Uint8Array|null} [payload] ArtifactSpec payload
                 */
    
                /**
                 * Constructs a new ArtifactSpec.
                 * @memberof exonum.runtime
                 * @classdesc Represents an ArtifactSpec.
                 * @implements IArtifactSpec
                 * @constructor
                 * @param {exonum.runtime.IArtifactSpec=} [properties] Properties to set
                 */
                function ArtifactSpec(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ArtifactSpec artifact.
                 * @member {exonum.runtime.IArtifactId|null|undefined} artifact
                 * @memberof exonum.runtime.ArtifactSpec
                 * @instance
                 */
                ArtifactSpec.prototype.artifact = null;
    
                /**
                 * ArtifactSpec payload.
                 * @member {Uint8Array} payload
                 * @memberof exonum.runtime.ArtifactSpec
                 * @instance
                 */
                ArtifactSpec.prototype.payload = $util.newBuffer([]);
    
                /**
                 * Creates a new ArtifactSpec instance using the specified properties.
                 * @function create
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {exonum.runtime.IArtifactSpec=} [properties] Properties to set
                 * @returns {exonum.runtime.ArtifactSpec} ArtifactSpec instance
                 */
                ArtifactSpec.create = function create(properties) {
                    return new ArtifactSpec(properties);
                };
    
                /**
                 * Encodes the specified ArtifactSpec message. Does not implicitly {@link exonum.runtime.ArtifactSpec.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {exonum.runtime.IArtifactSpec} message ArtifactSpec message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ArtifactSpec.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.artifact != null && message.hasOwnProperty("artifact"))
                        $root.exonum.runtime.ArtifactId.encode(message.artifact, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.payload != null && message.hasOwnProperty("payload"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.payload);
                    return writer;
                };
    
                /**
                 * Encodes the specified ArtifactSpec message, length delimited. Does not implicitly {@link exonum.runtime.ArtifactSpec.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {exonum.runtime.IArtifactSpec} message ArtifactSpec message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ArtifactSpec.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an ArtifactSpec message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.runtime.ArtifactSpec} ArtifactSpec
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ArtifactSpec.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.runtime.ArtifactSpec();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.artifact = $root.exonum.runtime.ArtifactId.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.payload = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an ArtifactSpec message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.runtime.ArtifactSpec} ArtifactSpec
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ArtifactSpec.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an ArtifactSpec message.
                 * @function verify
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ArtifactSpec.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.artifact != null && message.hasOwnProperty("artifact")) {
                        var error = $root.exonum.runtime.ArtifactId.verify(message.artifact);
                        if (error)
                            return "artifact." + error;
                    }
                    if (message.payload != null && message.hasOwnProperty("payload"))
                        if (!(message.payload && typeof message.payload.length === "number" || $util.isString(message.payload)))
                            return "payload: buffer expected";
                    return null;
                };
    
                /**
                 * Creates an ArtifactSpec message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.runtime.ArtifactSpec} ArtifactSpec
                 */
                ArtifactSpec.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.runtime.ArtifactSpec)
                        return object;
                    var message = new $root.exonum.runtime.ArtifactSpec();
                    if (object.artifact != null) {
                        if (typeof object.artifact !== "object")
                            throw TypeError(".exonum.runtime.ArtifactSpec.artifact: object expected");
                        message.artifact = $root.exonum.runtime.ArtifactId.fromObject(object.artifact);
                    }
                    if (object.payload != null)
                        if (typeof object.payload === "string")
                            $util.base64.decode(object.payload, message.payload = $util.newBuffer($util.base64.length(object.payload)), 0);
                        else if (object.payload.length)
                            message.payload = object.payload;
                    return message;
                };
    
                /**
                 * Creates a plain object from an ArtifactSpec message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.runtime.ArtifactSpec
                 * @static
                 * @param {exonum.runtime.ArtifactSpec} message ArtifactSpec
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ArtifactSpec.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.artifact = null;
                        if (options.bytes === String)
                            object.payload = "";
                        else {
                            object.payload = [];
                            if (options.bytes !== Array)
                                object.payload = $util.newBuffer(object.payload);
                        }
                    }
                    if (message.artifact != null && message.hasOwnProperty("artifact"))
                        object.artifact = $root.exonum.runtime.ArtifactId.toObject(message.artifact, options);
                    if (message.payload != null && message.hasOwnProperty("payload"))
                        object.payload = options.bytes === String ? $util.base64.encode(message.payload, 0, message.payload.length) : options.bytes === Array ? Array.prototype.slice.call(message.payload) : message.payload;
                    return object;
                };
    
                /**
                 * Converts this ArtifactSpec to JSON.
                 * @function toJSON
                 * @memberof exonum.runtime.ArtifactSpec
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ArtifactSpec.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ArtifactSpec;
            })();
    
            runtime.InstanceSpec = (function() {
    
                /**
                 * Properties of an InstanceSpec.
                 * @memberof exonum.runtime
                 * @interface IInstanceSpec
                 * @property {number|null} [id] InstanceSpec id
                 * @property {string|null} [name] InstanceSpec name
                 * @property {exonum.runtime.IArtifactId|null} [artifact] InstanceSpec artifact
                 */
    
                /**
                 * Constructs a new InstanceSpec.
                 * @memberof exonum.runtime
                 * @classdesc Represents an InstanceSpec.
                 * @implements IInstanceSpec
                 * @constructor
                 * @param {exonum.runtime.IInstanceSpec=} [properties] Properties to set
                 */
                function InstanceSpec(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * InstanceSpec id.
                 * @member {number} id
                 * @memberof exonum.runtime.InstanceSpec
                 * @instance
                 */
                InstanceSpec.prototype.id = 0;
    
                /**
                 * InstanceSpec name.
                 * @member {string} name
                 * @memberof exonum.runtime.InstanceSpec
                 * @instance
                 */
                InstanceSpec.prototype.name = "";
    
                /**
                 * InstanceSpec artifact.
                 * @member {exonum.runtime.IArtifactId|null|undefined} artifact
                 * @memberof exonum.runtime.InstanceSpec
                 * @instance
                 */
                InstanceSpec.prototype.artifact = null;
    
                /**
                 * Creates a new InstanceSpec instance using the specified properties.
                 * @function create
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {exonum.runtime.IInstanceSpec=} [properties] Properties to set
                 * @returns {exonum.runtime.InstanceSpec} InstanceSpec instance
                 */
                InstanceSpec.create = function create(properties) {
                    return new InstanceSpec(properties);
                };
    
                /**
                 * Encodes the specified InstanceSpec message. Does not implicitly {@link exonum.runtime.InstanceSpec.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {exonum.runtime.IInstanceSpec} message InstanceSpec message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                InstanceSpec.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.id != null && message.hasOwnProperty("id"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.id);
                    if (message.name != null && message.hasOwnProperty("name"))
                        writer.uint32(/* id 2, wireType 2 =*/18).string(message.name);
                    if (message.artifact != null && message.hasOwnProperty("artifact"))
                        $root.exonum.runtime.ArtifactId.encode(message.artifact, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified InstanceSpec message, length delimited. Does not implicitly {@link exonum.runtime.InstanceSpec.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {exonum.runtime.IInstanceSpec} message InstanceSpec message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                InstanceSpec.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an InstanceSpec message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.runtime.InstanceSpec} InstanceSpec
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                InstanceSpec.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.runtime.InstanceSpec();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.id = reader.uint32();
                            break;
                        case 2:
                            message.name = reader.string();
                            break;
                        case 3:
                            message.artifact = $root.exonum.runtime.ArtifactId.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an InstanceSpec message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.runtime.InstanceSpec} InstanceSpec
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                InstanceSpec.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an InstanceSpec message.
                 * @function verify
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                InstanceSpec.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.id != null && message.hasOwnProperty("id"))
                        if (!$util.isInteger(message.id))
                            return "id: integer expected";
                    if (message.name != null && message.hasOwnProperty("name"))
                        if (!$util.isString(message.name))
                            return "name: string expected";
                    if (message.artifact != null && message.hasOwnProperty("artifact")) {
                        var error = $root.exonum.runtime.ArtifactId.verify(message.artifact);
                        if (error)
                            return "artifact." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates an InstanceSpec message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.runtime.InstanceSpec} InstanceSpec
                 */
                InstanceSpec.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.runtime.InstanceSpec)
                        return object;
                    var message = new $root.exonum.runtime.InstanceSpec();
                    if (object.id != null)
                        message.id = object.id >>> 0;
                    if (object.name != null)
                        message.name = String(object.name);
                    if (object.artifact != null) {
                        if (typeof object.artifact !== "object")
                            throw TypeError(".exonum.runtime.InstanceSpec.artifact: object expected");
                        message.artifact = $root.exonum.runtime.ArtifactId.fromObject(object.artifact);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from an InstanceSpec message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.runtime.InstanceSpec
                 * @static
                 * @param {exonum.runtime.InstanceSpec} message InstanceSpec
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                InstanceSpec.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.id = 0;
                        object.name = "";
                        object.artifact = null;
                    }
                    if (message.id != null && message.hasOwnProperty("id"))
                        object.id = message.id;
                    if (message.name != null && message.hasOwnProperty("name"))
                        object.name = message.name;
                    if (message.artifact != null && message.hasOwnProperty("artifact"))
                        object.artifact = $root.exonum.runtime.ArtifactId.toObject(message.artifact, options);
                    return object;
                };
    
                /**
                 * Converts this InstanceSpec to JSON.
                 * @function toJSON
                 * @memberof exonum.runtime.InstanceSpec
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                InstanceSpec.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return InstanceSpec;
            })();
    
            return runtime;
        })();
    
        exonum.KeyValue = (function() {
    
            /**
             * Properties of a KeyValue.
             * @memberof exonum
             * @interface IKeyValue
             * @property {string|null} [key] KeyValue key
             * @property {Uint8Array|null} [value] KeyValue value
             */
    
            /**
             * Constructs a new KeyValue.
             * @memberof exonum
             * @classdesc Represents a KeyValue.
             * @implements IKeyValue
             * @constructor
             * @param {exonum.IKeyValue=} [properties] Properties to set
             */
            function KeyValue(properties) {
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * KeyValue key.
             * @member {string} key
             * @memberof exonum.KeyValue
             * @instance
             */
            KeyValue.prototype.key = "";
    
            /**
             * KeyValue value.
             * @member {Uint8Array} value
             * @memberof exonum.KeyValue
             * @instance
             */
            KeyValue.prototype.value = $util.newBuffer([]);
    
            /**
             * Creates a new KeyValue instance using the specified properties.
             * @function create
             * @memberof exonum.KeyValue
             * @static
             * @param {exonum.IKeyValue=} [properties] Properties to set
             * @returns {exonum.KeyValue} KeyValue instance
             */
            KeyValue.create = function create(properties) {
                return new KeyValue(properties);
            };
    
            /**
             * Encodes the specified KeyValue message. Does not implicitly {@link exonum.KeyValue.verify|verify} messages.
             * @function encode
             * @memberof exonum.KeyValue
             * @static
             * @param {exonum.IKeyValue} message KeyValue message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            KeyValue.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.key != null && message.hasOwnProperty("key"))
                    writer.uint32(/* id 1, wireType 2 =*/10).string(message.key);
                if (message.value != null && message.hasOwnProperty("value"))
                    writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.value);
                return writer;
            };
    
            /**
             * Encodes the specified KeyValue message, length delimited. Does not implicitly {@link exonum.KeyValue.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.KeyValue
             * @static
             * @param {exonum.IKeyValue} message KeyValue message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            KeyValue.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes a KeyValue message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.KeyValue
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.KeyValue} KeyValue
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            KeyValue.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.KeyValue();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 1:
                        message.key = reader.string();
                        break;
                    case 2:
                        message.value = reader.bytes();
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes a KeyValue message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.KeyValue
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.KeyValue} KeyValue
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            KeyValue.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies a KeyValue message.
             * @function verify
             * @memberof exonum.KeyValue
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            KeyValue.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.key != null && message.hasOwnProperty("key"))
                    if (!$util.isString(message.key))
                        return "key: string expected";
                if (message.value != null && message.hasOwnProperty("value"))
                    if (!(message.value && typeof message.value.length === "number" || $util.isString(message.value)))
                        return "value: buffer expected";
                return null;
            };
    
            /**
             * Creates a KeyValue message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.KeyValue
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.KeyValue} KeyValue
             */
            KeyValue.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.KeyValue)
                    return object;
                var message = new $root.exonum.KeyValue();
                if (object.key != null)
                    message.key = String(object.key);
                if (object.value != null)
                    if (typeof object.value === "string")
                        $util.base64.decode(object.value, message.value = $util.newBuffer($util.base64.length(object.value)), 0);
                    else if (object.value.length)
                        message.value = object.value;
                return message;
            };
    
            /**
             * Creates a plain object from a KeyValue message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.KeyValue
             * @static
             * @param {exonum.KeyValue} message KeyValue
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            KeyValue.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.defaults) {
                    object.key = "";
                    if (options.bytes === String)
                        object.value = "";
                    else {
                        object.value = [];
                        if (options.bytes !== Array)
                            object.value = $util.newBuffer(object.value);
                    }
                }
                if (message.key != null && message.hasOwnProperty("key"))
                    object.key = message.key;
                if (message.value != null && message.hasOwnProperty("value"))
                    object.value = options.bytes === String ? $util.base64.encode(message.value, 0, message.value.length) : options.bytes === Array ? Array.prototype.slice.call(message.value) : message.value;
                return object;
            };
    
            /**
             * Converts this KeyValue to JSON.
             * @function toJSON
             * @memberof exonum.KeyValue
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            KeyValue.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return KeyValue;
        })();
    
        exonum.KeyValueSequence = (function() {
    
            /**
             * Properties of a KeyValueSequence.
             * @memberof exonum
             * @interface IKeyValueSequence
             * @property {Array.<exonum.IKeyValue>|null} [entry] KeyValueSequence entry
             */
    
            /**
             * Constructs a new KeyValueSequence.
             * @memberof exonum
             * @classdesc Represents a KeyValueSequence.
             * @implements IKeyValueSequence
             * @constructor
             * @param {exonum.IKeyValueSequence=} [properties] Properties to set
             */
            function KeyValueSequence(properties) {
                this.entry = [];
                if (properties)
                    for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                        if (properties[keys[i]] != null)
                            this[keys[i]] = properties[keys[i]];
            }
    
            /**
             * KeyValueSequence entry.
             * @member {Array.<exonum.IKeyValue>} entry
             * @memberof exonum.KeyValueSequence
             * @instance
             */
            KeyValueSequence.prototype.entry = $util.emptyArray;
    
            /**
             * Creates a new KeyValueSequence instance using the specified properties.
             * @function create
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {exonum.IKeyValueSequence=} [properties] Properties to set
             * @returns {exonum.KeyValueSequence} KeyValueSequence instance
             */
            KeyValueSequence.create = function create(properties) {
                return new KeyValueSequence(properties);
            };
    
            /**
             * Encodes the specified KeyValueSequence message. Does not implicitly {@link exonum.KeyValueSequence.verify|verify} messages.
             * @function encode
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {exonum.IKeyValueSequence} message KeyValueSequence message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            KeyValueSequence.encode = function encode(message, writer) {
                if (!writer)
                    writer = $Writer.create();
                if (message.entry != null && message.entry.length)
                    for (var i = 0; i < message.entry.length; ++i)
                        $root.exonum.KeyValue.encode(message.entry[i], writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                return writer;
            };
    
            /**
             * Encodes the specified KeyValueSequence message, length delimited. Does not implicitly {@link exonum.KeyValueSequence.verify|verify} messages.
             * @function encodeDelimited
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {exonum.IKeyValueSequence} message KeyValueSequence message or plain object to encode
             * @param {$protobuf.Writer} [writer] Writer to encode to
             * @returns {$protobuf.Writer} Writer
             */
            KeyValueSequence.encodeDelimited = function encodeDelimited(message, writer) {
                return this.encode(message, writer).ldelim();
            };
    
            /**
             * Decodes a KeyValueSequence message from the specified reader or buffer.
             * @function decode
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @param {number} [length] Message length if known beforehand
             * @returns {exonum.KeyValueSequence} KeyValueSequence
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            KeyValueSequence.decode = function decode(reader, length) {
                if (!(reader instanceof $Reader))
                    reader = $Reader.create(reader);
                var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.KeyValueSequence();
                while (reader.pos < end) {
                    var tag = reader.uint32();
                    switch (tag >>> 3) {
                    case 1:
                        if (!(message.entry && message.entry.length))
                            message.entry = [];
                        message.entry.push($root.exonum.KeyValue.decode(reader, reader.uint32()));
                        break;
                    default:
                        reader.skipType(tag & 7);
                        break;
                    }
                }
                return message;
            };
    
            /**
             * Decodes a KeyValueSequence message from the specified reader or buffer, length delimited.
             * @function decodeDelimited
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
             * @returns {exonum.KeyValueSequence} KeyValueSequence
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            KeyValueSequence.decodeDelimited = function decodeDelimited(reader) {
                if (!(reader instanceof $Reader))
                    reader = new $Reader(reader);
                return this.decode(reader, reader.uint32());
            };
    
            /**
             * Verifies a KeyValueSequence message.
             * @function verify
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {Object.<string,*>} message Plain object to verify
             * @returns {string|null} `null` if valid, otherwise the reason why it is not
             */
            KeyValueSequence.verify = function verify(message) {
                if (typeof message !== "object" || message === null)
                    return "object expected";
                if (message.entry != null && message.hasOwnProperty("entry")) {
                    if (!Array.isArray(message.entry))
                        return "entry: array expected";
                    for (var i = 0; i < message.entry.length; ++i) {
                        var error = $root.exonum.KeyValue.verify(message.entry[i]);
                        if (error)
                            return "entry." + error;
                    }
                }
                return null;
            };
    
            /**
             * Creates a KeyValueSequence message from a plain object. Also converts values to their respective internal types.
             * @function fromObject
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {Object.<string,*>} object Plain object
             * @returns {exonum.KeyValueSequence} KeyValueSequence
             */
            KeyValueSequence.fromObject = function fromObject(object) {
                if (object instanceof $root.exonum.KeyValueSequence)
                    return object;
                var message = new $root.exonum.KeyValueSequence();
                if (object.entry) {
                    if (!Array.isArray(object.entry))
                        throw TypeError(".exonum.KeyValueSequence.entry: array expected");
                    message.entry = [];
                    for (var i = 0; i < object.entry.length; ++i) {
                        if (typeof object.entry[i] !== "object")
                            throw TypeError(".exonum.KeyValueSequence.entry: object expected");
                        message.entry[i] = $root.exonum.KeyValue.fromObject(object.entry[i]);
                    }
                }
                return message;
            };
    
            /**
             * Creates a plain object from a KeyValueSequence message. Also converts values to other types if specified.
             * @function toObject
             * @memberof exonum.KeyValueSequence
             * @static
             * @param {exonum.KeyValueSequence} message KeyValueSequence
             * @param {$protobuf.IConversionOptions} [options] Conversion options
             * @returns {Object.<string,*>} Plain object
             */
            KeyValueSequence.toObject = function toObject(message, options) {
                if (!options)
                    options = {};
                var object = {};
                if (options.arrays || options.defaults)
                    object.entry = [];
                if (message.entry && message.entry.length) {
                    object.entry = [];
                    for (var j = 0; j < message.entry.length; ++j)
                        object.entry[j] = $root.exonum.KeyValue.toObject(message.entry[j], options);
                }
                return object;
            };
    
            /**
             * Converts this KeyValueSequence to JSON.
             * @function toJSON
             * @memberof exonum.KeyValueSequence
             * @instance
             * @returns {Object.<string,*>} JSON object
             */
            KeyValueSequence.prototype.toJSON = function toJSON() {
                return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
            };
    
            return KeyValueSequence;
        })();
    
        exonum.proofs = (function() {
    
            /**
             * Namespace proofs.
             * @memberof exonum
             * @namespace
             */
            var proofs = {};
    
            proofs.BlockProof = (function() {
    
                /**
                 * Properties of a BlockProof.
                 * @memberof exonum.proofs
                 * @interface IBlockProof
                 * @property {exonum.IBlock|null} [block] BlockProof block
                 * @property {Array.<exonum.consensus.ISignedMessage>|null} [precommits] BlockProof precommits
                 */
    
                /**
                 * Constructs a new BlockProof.
                 * @memberof exonum.proofs
                 * @classdesc Represents a BlockProof.
                 * @implements IBlockProof
                 * @constructor
                 * @param {exonum.proofs.IBlockProof=} [properties] Properties to set
                 */
                function BlockProof(properties) {
                    this.precommits = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * BlockProof block.
                 * @member {exonum.IBlock|null|undefined} block
                 * @memberof exonum.proofs.BlockProof
                 * @instance
                 */
                BlockProof.prototype.block = null;
    
                /**
                 * BlockProof precommits.
                 * @member {Array.<exonum.consensus.ISignedMessage>} precommits
                 * @memberof exonum.proofs.BlockProof
                 * @instance
                 */
                BlockProof.prototype.precommits = $util.emptyArray;
    
                /**
                 * Creates a new BlockProof instance using the specified properties.
                 * @function create
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {exonum.proofs.IBlockProof=} [properties] Properties to set
                 * @returns {exonum.proofs.BlockProof} BlockProof instance
                 */
                BlockProof.create = function create(properties) {
                    return new BlockProof(properties);
                };
    
                /**
                 * Encodes the specified BlockProof message. Does not implicitly {@link exonum.proofs.BlockProof.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {exonum.proofs.IBlockProof} message BlockProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BlockProof.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.block != null && message.hasOwnProperty("block"))
                        $root.exonum.Block.encode(message.block, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.precommits != null && message.precommits.length)
                        for (var i = 0; i < message.precommits.length; ++i)
                            $root.exonum.consensus.SignedMessage.encode(message.precommits[i], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified BlockProof message, length delimited. Does not implicitly {@link exonum.proofs.BlockProof.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {exonum.proofs.IBlockProof} message BlockProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                BlockProof.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a BlockProof message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proofs.BlockProof} BlockProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BlockProof.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proofs.BlockProof();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.block = $root.exonum.Block.decode(reader, reader.uint32());
                            break;
                        case 2:
                            if (!(message.precommits && message.precommits.length))
                                message.precommits = [];
                            message.precommits.push($root.exonum.consensus.SignedMessage.decode(reader, reader.uint32()));
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a BlockProof message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proofs.BlockProof} BlockProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                BlockProof.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a BlockProof message.
                 * @function verify
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                BlockProof.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.block != null && message.hasOwnProperty("block")) {
                        var error = $root.exonum.Block.verify(message.block);
                        if (error)
                            return "block." + error;
                    }
                    if (message.precommits != null && message.hasOwnProperty("precommits")) {
                        if (!Array.isArray(message.precommits))
                            return "precommits: array expected";
                        for (var i = 0; i < message.precommits.length; ++i) {
                            var error = $root.exonum.consensus.SignedMessage.verify(message.precommits[i]);
                            if (error)
                                return "precommits." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a BlockProof message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proofs.BlockProof} BlockProof
                 */
                BlockProof.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proofs.BlockProof)
                        return object;
                    var message = new $root.exonum.proofs.BlockProof();
                    if (object.block != null) {
                        if (typeof object.block !== "object")
                            throw TypeError(".exonum.proofs.BlockProof.block: object expected");
                        message.block = $root.exonum.Block.fromObject(object.block);
                    }
                    if (object.precommits) {
                        if (!Array.isArray(object.precommits))
                            throw TypeError(".exonum.proofs.BlockProof.precommits: array expected");
                        message.precommits = [];
                        for (var i = 0; i < object.precommits.length; ++i) {
                            if (typeof object.precommits[i] !== "object")
                                throw TypeError(".exonum.proofs.BlockProof.precommits: object expected");
                            message.precommits[i] = $root.exonum.consensus.SignedMessage.fromObject(object.precommits[i]);
                        }
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a BlockProof message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proofs.BlockProof
                 * @static
                 * @param {exonum.proofs.BlockProof} message BlockProof
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                BlockProof.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.precommits = [];
                    if (options.defaults)
                        object.block = null;
                    if (message.block != null && message.hasOwnProperty("block"))
                        object.block = $root.exonum.Block.toObject(message.block, options);
                    if (message.precommits && message.precommits.length) {
                        object.precommits = [];
                        for (var j = 0; j < message.precommits.length; ++j)
                            object.precommits[j] = $root.exonum.consensus.SignedMessage.toObject(message.precommits[j], options);
                    }
                    return object;
                };
    
                /**
                 * Converts this BlockProof to JSON.
                 * @function toJSON
                 * @memberof exonum.proofs.BlockProof
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                BlockProof.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return BlockProof;
            })();
    
            proofs.ConfigChangeProof = (function() {
    
                /**
                 * Properties of a ConfigChangeProof.
                 * @memberof exonum.proofs
                 * @interface IConfigChangeProof
                 * @property {exonum.proof.IListProof|null} [configs_proof] ConfigChangeProof configs_proof
                 * @property {exonum.proof.IMapProof|null} [configs_index_proof] ConfigChangeProof configs_index_proof
                 * @property {Array.<exonum.proofs.IBlockProof>|null} [blocks_proofs] ConfigChangeProof blocks_proofs
                 * @property {Uint8Array|null} [foreign_proof] ConfigChangeProof foreign_proof
                 */
    
                /**
                 * Constructs a new ConfigChangeProof.
                 * @memberof exonum.proofs
                 * @classdesc Represents a ConfigChangeProof.
                 * @implements IConfigChangeProof
                 * @constructor
                 * @param {exonum.proofs.IConfigChangeProof=} [properties] Properties to set
                 */
                function ConfigChangeProof(properties) {
                    this.blocks_proofs = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ConfigChangeProof configs_proof.
                 * @member {exonum.proof.IListProof|null|undefined} configs_proof
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @instance
                 */
                ConfigChangeProof.prototype.configs_proof = null;
    
                /**
                 * ConfigChangeProof configs_index_proof.
                 * @member {exonum.proof.IMapProof|null|undefined} configs_index_proof
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @instance
                 */
                ConfigChangeProof.prototype.configs_index_proof = null;
    
                /**
                 * ConfigChangeProof blocks_proofs.
                 * @member {Array.<exonum.proofs.IBlockProof>} blocks_proofs
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @instance
                 */
                ConfigChangeProof.prototype.blocks_proofs = $util.emptyArray;
    
                /**
                 * ConfigChangeProof foreign_proof.
                 * @member {Uint8Array} foreign_proof
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @instance
                 */
                ConfigChangeProof.prototype.foreign_proof = $util.newBuffer([]);
    
                /**
                 * Creates a new ConfigChangeProof instance using the specified properties.
                 * @function create
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {exonum.proofs.IConfigChangeProof=} [properties] Properties to set
                 * @returns {exonum.proofs.ConfigChangeProof} ConfigChangeProof instance
                 */
                ConfigChangeProof.create = function create(properties) {
                    return new ConfigChangeProof(properties);
                };
    
                /**
                 * Encodes the specified ConfigChangeProof message. Does not implicitly {@link exonum.proofs.ConfigChangeProof.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {exonum.proofs.IConfigChangeProof} message ConfigChangeProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ConfigChangeProof.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.configs_proof != null && message.hasOwnProperty("configs_proof"))
                        $root.exonum.proof.ListProof.encode(message.configs_proof, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.configs_index_proof != null && message.hasOwnProperty("configs_index_proof"))
                        $root.exonum.proof.MapProof.encode(message.configs_index_proof, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.blocks_proofs != null && message.blocks_proofs.length)
                        for (var i = 0; i < message.blocks_proofs.length; ++i)
                            $root.exonum.proofs.BlockProof.encode(message.blocks_proofs[i], writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    if (message.foreign_proof != null && message.hasOwnProperty("foreign_proof"))
                        writer.uint32(/* id 4, wireType 2 =*/34).bytes(message.foreign_proof);
                    return writer;
                };
    
                /**
                 * Encodes the specified ConfigChangeProof message, length delimited. Does not implicitly {@link exonum.proofs.ConfigChangeProof.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {exonum.proofs.IConfigChangeProof} message ConfigChangeProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ConfigChangeProof.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a ConfigChangeProof message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proofs.ConfigChangeProof} ConfigChangeProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ConfigChangeProof.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proofs.ConfigChangeProof();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.configs_proof = $root.exonum.proof.ListProof.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.configs_index_proof = $root.exonum.proof.MapProof.decode(reader, reader.uint32());
                            break;
                        case 3:
                            if (!(message.blocks_proofs && message.blocks_proofs.length))
                                message.blocks_proofs = [];
                            message.blocks_proofs.push($root.exonum.proofs.BlockProof.decode(reader, reader.uint32()));
                            break;
                        case 4:
                            message.foreign_proof = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a ConfigChangeProof message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proofs.ConfigChangeProof} ConfigChangeProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ConfigChangeProof.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a ConfigChangeProof message.
                 * @function verify
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ConfigChangeProof.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.configs_proof != null && message.hasOwnProperty("configs_proof")) {
                        var error = $root.exonum.proof.ListProof.verify(message.configs_proof);
                        if (error)
                            return "configs_proof." + error;
                    }
                    if (message.configs_index_proof != null && message.hasOwnProperty("configs_index_proof")) {
                        var error = $root.exonum.proof.MapProof.verify(message.configs_index_proof);
                        if (error)
                            return "configs_index_proof." + error;
                    }
                    if (message.blocks_proofs != null && message.hasOwnProperty("blocks_proofs")) {
                        if (!Array.isArray(message.blocks_proofs))
                            return "blocks_proofs: array expected";
                        for (var i = 0; i < message.blocks_proofs.length; ++i) {
                            var error = $root.exonum.proofs.BlockProof.verify(message.blocks_proofs[i]);
                            if (error)
                                return "blocks_proofs." + error;
                        }
                    }
                    if (message.foreign_proof != null && message.hasOwnProperty("foreign_proof"))
                        if (!(message.foreign_proof && typeof message.foreign_proof.length === "number" || $util.isString(message.foreign_proof)))
                            return "foreign_proof: buffer expected";
                    return null;
                };
    
                /**
                 * Creates a ConfigChangeProof message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proofs.ConfigChangeProof} ConfigChangeProof
                 */
                ConfigChangeProof.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proofs.ConfigChangeProof)
                        return object;
                    var message = new $root.exonum.proofs.ConfigChangeProof();
                    if (object.configs_proof != null) {
                        if (typeof object.configs_proof !== "object")
                            throw TypeError(".exonum.proofs.ConfigChangeProof.configs_proof: object expected");
                        message.configs_proof = $root.exonum.proof.ListProof.fromObject(object.configs_proof);
                    }
                    if (object.configs_index_proof != null) {
                        if (typeof object.configs_index_proof !== "object")
                            throw TypeError(".exonum.proofs.ConfigChangeProof.configs_index_proof: object expected");
                        message.configs_index_proof = $root.exonum.proof.MapProof.fromObject(object.configs_index_proof);
                    }
                    if (object.blocks_proofs) {
                        if (!Array.isArray(object.blocks_proofs))
                            throw TypeError(".exonum.proofs.ConfigChangeProof.blocks_proofs: array expected");
                        message.blocks_proofs = [];
                        for (var i = 0; i < object.blocks_proofs.length; ++i) {
                            if (typeof object.blocks_proofs[i] !== "object")
                                throw TypeError(".exonum.proofs.ConfigChangeProof.blocks_proofs: object expected");
                            message.blocks_proofs[i] = $root.exonum.proofs.BlockProof.fromObject(object.blocks_proofs[i]);
                        }
                    }
                    if (object.foreign_proof != null)
                        if (typeof object.foreign_proof === "string")
                            $util.base64.decode(object.foreign_proof, message.foreign_proof = $util.newBuffer($util.base64.length(object.foreign_proof)), 0);
                        else if (object.foreign_proof.length)
                            message.foreign_proof = object.foreign_proof;
                    return message;
                };
    
                /**
                 * Creates a plain object from a ConfigChangeProof message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @static
                 * @param {exonum.proofs.ConfigChangeProof} message ConfigChangeProof
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ConfigChangeProof.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.blocks_proofs = [];
                    if (options.defaults) {
                        object.configs_proof = null;
                        object.configs_index_proof = null;
                        if (options.bytes === String)
                            object.foreign_proof = "";
                        else {
                            object.foreign_proof = [];
                            if (options.bytes !== Array)
                                object.foreign_proof = $util.newBuffer(object.foreign_proof);
                        }
                    }
                    if (message.configs_proof != null && message.hasOwnProperty("configs_proof"))
                        object.configs_proof = $root.exonum.proof.ListProof.toObject(message.configs_proof, options);
                    if (message.configs_index_proof != null && message.hasOwnProperty("configs_index_proof"))
                        object.configs_index_proof = $root.exonum.proof.MapProof.toObject(message.configs_index_proof, options);
                    if (message.blocks_proofs && message.blocks_proofs.length) {
                        object.blocks_proofs = [];
                        for (var j = 0; j < message.blocks_proofs.length; ++j)
                            object.blocks_proofs[j] = $root.exonum.proofs.BlockProof.toObject(message.blocks_proofs[j], options);
                    }
                    if (message.foreign_proof != null && message.hasOwnProperty("foreign_proof"))
                        object.foreign_proof = options.bytes === String ? $util.base64.encode(message.foreign_proof, 0, message.foreign_proof.length) : options.bytes === Array ? Array.prototype.slice.call(message.foreign_proof) : message.foreign_proof;
                    return object;
                };
    
                /**
                 * Converts this ConfigChangeProof to JSON.
                 * @function toJSON
                 * @memberof exonum.proofs.ConfigChangeProof
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ConfigChangeProof.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ConfigChangeProof;
            })();
    
            proofs.ForeignTxProof = (function() {
    
                /**
                 * Properties of a ForeignTxProof.
                 * @memberof exonum.proofs
                 * @interface IForeignTxProof
                 * @property {Array.<exonum.consensus.ISignedMessage>|null} [txs] ForeignTxProof txs
                 * @property {exonum.proof.IMapProof|null} [results_proof] ForeignTxProof results_proof
                 * @property {exonum.proof.IMapProof|null} [results_index_proof] ForeignTxProof results_index_proof
                 */
    
                /**
                 * Constructs a new ForeignTxProof.
                 * @memberof exonum.proofs
                 * @classdesc Represents a ForeignTxProof.
                 * @implements IForeignTxProof
                 * @constructor
                 * @param {exonum.proofs.IForeignTxProof=} [properties] Properties to set
                 */
                function ForeignTxProof(properties) {
                    this.txs = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ForeignTxProof txs.
                 * @member {Array.<exonum.consensus.ISignedMessage>} txs
                 * @memberof exonum.proofs.ForeignTxProof
                 * @instance
                 */
                ForeignTxProof.prototype.txs = $util.emptyArray;
    
                /**
                 * ForeignTxProof results_proof.
                 * @member {exonum.proof.IMapProof|null|undefined} results_proof
                 * @memberof exonum.proofs.ForeignTxProof
                 * @instance
                 */
                ForeignTxProof.prototype.results_proof = null;
    
                /**
                 * ForeignTxProof results_index_proof.
                 * @member {exonum.proof.IMapProof|null|undefined} results_index_proof
                 * @memberof exonum.proofs.ForeignTxProof
                 * @instance
                 */
                ForeignTxProof.prototype.results_index_proof = null;
    
                /**
                 * Creates a new ForeignTxProof instance using the specified properties.
                 * @function create
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {exonum.proofs.IForeignTxProof=} [properties] Properties to set
                 * @returns {exonum.proofs.ForeignTxProof} ForeignTxProof instance
                 */
                ForeignTxProof.create = function create(properties) {
                    return new ForeignTxProof(properties);
                };
    
                /**
                 * Encodes the specified ForeignTxProof message. Does not implicitly {@link exonum.proofs.ForeignTxProof.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {exonum.proofs.IForeignTxProof} message ForeignTxProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ForeignTxProof.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.txs != null && message.txs.length)
                        for (var i = 0; i < message.txs.length; ++i)
                            $root.exonum.consensus.SignedMessage.encode(message.txs[i], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.results_proof != null && message.hasOwnProperty("results_proof"))
                        $root.exonum.proof.MapProof.encode(message.results_proof, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    if (message.results_index_proof != null && message.hasOwnProperty("results_index_proof"))
                        $root.exonum.proof.MapProof.encode(message.results_index_proof, writer.uint32(/* id 4, wireType 2 =*/34).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified ForeignTxProof message, length delimited. Does not implicitly {@link exonum.proofs.ForeignTxProof.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {exonum.proofs.IForeignTxProof} message ForeignTxProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ForeignTxProof.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a ForeignTxProof message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proofs.ForeignTxProof} ForeignTxProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ForeignTxProof.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proofs.ForeignTxProof();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 2:
                            if (!(message.txs && message.txs.length))
                                message.txs = [];
                            message.txs.push($root.exonum.consensus.SignedMessage.decode(reader, reader.uint32()));
                            break;
                        case 3:
                            message.results_proof = $root.exonum.proof.MapProof.decode(reader, reader.uint32());
                            break;
                        case 4:
                            message.results_index_proof = $root.exonum.proof.MapProof.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a ForeignTxProof message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proofs.ForeignTxProof} ForeignTxProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ForeignTxProof.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a ForeignTxProof message.
                 * @function verify
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ForeignTxProof.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.txs != null && message.hasOwnProperty("txs")) {
                        if (!Array.isArray(message.txs))
                            return "txs: array expected";
                        for (var i = 0; i < message.txs.length; ++i) {
                            var error = $root.exonum.consensus.SignedMessage.verify(message.txs[i]);
                            if (error)
                                return "txs." + error;
                        }
                    }
                    if (message.results_proof != null && message.hasOwnProperty("results_proof")) {
                        var error = $root.exonum.proof.MapProof.verify(message.results_proof);
                        if (error)
                            return "results_proof." + error;
                    }
                    if (message.results_index_proof != null && message.hasOwnProperty("results_index_proof")) {
                        var error = $root.exonum.proof.MapProof.verify(message.results_index_proof);
                        if (error)
                            return "results_index_proof." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a ForeignTxProof message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proofs.ForeignTxProof} ForeignTxProof
                 */
                ForeignTxProof.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proofs.ForeignTxProof)
                        return object;
                    var message = new $root.exonum.proofs.ForeignTxProof();
                    if (object.txs) {
                        if (!Array.isArray(object.txs))
                            throw TypeError(".exonum.proofs.ForeignTxProof.txs: array expected");
                        message.txs = [];
                        for (var i = 0; i < object.txs.length; ++i) {
                            if (typeof object.txs[i] !== "object")
                                throw TypeError(".exonum.proofs.ForeignTxProof.txs: object expected");
                            message.txs[i] = $root.exonum.consensus.SignedMessage.fromObject(object.txs[i]);
                        }
                    }
                    if (object.results_proof != null) {
                        if (typeof object.results_proof !== "object")
                            throw TypeError(".exonum.proofs.ForeignTxProof.results_proof: object expected");
                        message.results_proof = $root.exonum.proof.MapProof.fromObject(object.results_proof);
                    }
                    if (object.results_index_proof != null) {
                        if (typeof object.results_index_proof !== "object")
                            throw TypeError(".exonum.proofs.ForeignTxProof.results_index_proof: object expected");
                        message.results_index_proof = $root.exonum.proof.MapProof.fromObject(object.results_index_proof);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a ForeignTxProof message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proofs.ForeignTxProof
                 * @static
                 * @param {exonum.proofs.ForeignTxProof} message ForeignTxProof
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ForeignTxProof.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults)
                        object.txs = [];
                    if (options.defaults) {
                        object.results_proof = null;
                        object.results_index_proof = null;
                    }
                    if (message.txs && message.txs.length) {
                        object.txs = [];
                        for (var j = 0; j < message.txs.length; ++j)
                            object.txs[j] = $root.exonum.consensus.SignedMessage.toObject(message.txs[j], options);
                    }
                    if (message.results_proof != null && message.hasOwnProperty("results_proof"))
                        object.results_proof = $root.exonum.proof.MapProof.toObject(message.results_proof, options);
                    if (message.results_index_proof != null && message.hasOwnProperty("results_index_proof"))
                        object.results_index_proof = $root.exonum.proof.MapProof.toObject(message.results_index_proof, options);
                    return object;
                };
    
                /**
                 * Converts this ForeignTxProof to JSON.
                 * @function toJSON
                 * @memberof exonum.proofs.ForeignTxProof
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ForeignTxProof.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ForeignTxProof;
            })();
    
            return proofs;
        })();
    
        exonum.tests = (function() {
    
            /**
             * Namespace tests.
             * @memberof exonum
             * @namespace
             */
            var tests = {};
    
            tests.Point = (function() {
    
                /**
                 * Properties of a Point.
                 * @memberof exonum.tests
                 * @interface IPoint
                 * @property {number|null} [x] Point x
                 * @property {number|null} [y] Point y
                 */
    
                /**
                 * Constructs a new Point.
                 * @memberof exonum.tests
                 * @classdesc Represents a Point.
                 * @implements IPoint
                 * @constructor
                 * @param {exonum.tests.IPoint=} [properties] Properties to set
                 */
                function Point(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Point x.
                 * @member {number} x
                 * @memberof exonum.tests.Point
                 * @instance
                 */
                Point.prototype.x = 0;
    
                /**
                 * Point y.
                 * @member {number} y
                 * @memberof exonum.tests.Point
                 * @instance
                 */
                Point.prototype.y = 0;
    
                /**
                 * Creates a new Point instance using the specified properties.
                 * @function create
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {exonum.tests.IPoint=} [properties] Properties to set
                 * @returns {exonum.tests.Point} Point instance
                 */
                Point.create = function create(properties) {
                    return new Point(properties);
                };
    
                /**
                 * Encodes the specified Point message. Does not implicitly {@link exonum.tests.Point.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {exonum.tests.IPoint} message Point message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Point.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.x != null && message.hasOwnProperty("x"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint32(message.x);
                    if (message.y != null && message.hasOwnProperty("y"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint32(message.y);
                    return writer;
                };
    
                /**
                 * Encodes the specified Point message, length delimited. Does not implicitly {@link exonum.tests.Point.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {exonum.tests.IPoint} message Point message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Point.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Point message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.tests.Point} Point
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Point.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.tests.Point();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.x = reader.uint32();
                            break;
                        case 2:
                            message.y = reader.uint32();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Point message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.tests.Point} Point
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Point.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Point message.
                 * @function verify
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Point.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.x != null && message.hasOwnProperty("x"))
                        if (!$util.isInteger(message.x))
                            return "x: integer expected";
                    if (message.y != null && message.hasOwnProperty("y"))
                        if (!$util.isInteger(message.y))
                            return "y: integer expected";
                    return null;
                };
    
                /**
                 * Creates a Point message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.tests.Point} Point
                 */
                Point.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.tests.Point)
                        return object;
                    var message = new $root.exonum.tests.Point();
                    if (object.x != null)
                        message.x = object.x >>> 0;
                    if (object.y != null)
                        message.y = object.y >>> 0;
                    return message;
                };
    
                /**
                 * Creates a plain object from a Point message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.tests.Point
                 * @static
                 * @param {exonum.tests.Point} message Point
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Point.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.x = 0;
                        object.y = 0;
                    }
                    if (message.x != null && message.hasOwnProperty("x"))
                        object.x = message.x;
                    if (message.y != null && message.hasOwnProperty("y"))
                        object.y = message.y;
                    return object;
                };
    
                /**
                 * Converts this Point to JSON.
                 * @function toJSON
                 * @memberof exonum.tests.Point
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Point.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Point;
            })();
    
            tests.TestProtobufConvert = (function() {
    
                /**
                 * Properties of a TestProtobufConvert.
                 * @memberof exonum.tests
                 * @interface ITestProtobufConvert
                 * @property {exonum.crypto.IPublicKey|null} [key] TestProtobufConvert key
                 * @property {exonum.crypto.IHash|null} [hash] TestProtobufConvert hash
                 * @property {number|null} [unsigned_32] TestProtobufConvert unsigned_32
                 * @property {number|Long|null} [unsigned_64] TestProtobufConvert unsigned_64
                 * @property {number|null} [regular_i32] TestProtobufConvert regular_i32
                 * @property {number|Long|null} [regular_i64] TestProtobufConvert regular_i64
                 * @property {number|null} [fixed_u32] TestProtobufConvert fixed_u32
                 * @property {number|Long|null} [fixed_u64] TestProtobufConvert fixed_u64
                 * @property {number|null} [fixed_i32] TestProtobufConvert fixed_i32
                 * @property {number|Long|null} [fixed_i64] TestProtobufConvert fixed_i64
                 * @property {number|null} [float_32] TestProtobufConvert float_32
                 * @property {number|null} [float_64] TestProtobufConvert float_64
                 * @property {boolean|null} [boolean] TestProtobufConvert boolean
                 * @property {number|null} [s_i32] TestProtobufConvert s_i32
                 * @property {number|Long|null} [s_i64] TestProtobufConvert s_i64
                 * @property {Uint8Array|null} [bytes_field] TestProtobufConvert bytes_field
                 * @property {string|null} [string_field] TestProtobufConvert string_field
                 * @property {exonum.tests.IPoint|null} [message_field] TestProtobufConvert message_field
                 * @property {exonum.common.IBitVec|null} [bit_vec] TestProtobufConvert bit_vec
                 * @property {google.protobuf.ITimestamp|null} [time] TestProtobufConvert time
                 */
    
                /**
                 * Constructs a new TestProtobufConvert.
                 * @memberof exonum.tests
                 * @classdesc Represents a TestProtobufConvert.
                 * @implements ITestProtobufConvert
                 * @constructor
                 * @param {exonum.tests.ITestProtobufConvert=} [properties] Properties to set
                 */
                function TestProtobufConvert(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * TestProtobufConvert key.
                 * @member {exonum.crypto.IPublicKey|null|undefined} key
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.key = null;
    
                /**
                 * TestProtobufConvert hash.
                 * @member {exonum.crypto.IHash|null|undefined} hash
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.hash = null;
    
                /**
                 * TestProtobufConvert unsigned_32.
                 * @member {number} unsigned_32
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.unsigned_32 = 0;
    
                /**
                 * TestProtobufConvert unsigned_64.
                 * @member {number|Long} unsigned_64
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.unsigned_64 = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * TestProtobufConvert regular_i32.
                 * @member {number} regular_i32
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.regular_i32 = 0;
    
                /**
                 * TestProtobufConvert regular_i64.
                 * @member {number|Long} regular_i64
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.regular_i64 = $util.Long ? $util.Long.fromBits(0,0,false) : 0;
    
                /**
                 * TestProtobufConvert fixed_u32.
                 * @member {number} fixed_u32
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.fixed_u32 = 0;
    
                /**
                 * TestProtobufConvert fixed_u64.
                 * @member {number|Long} fixed_u64
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.fixed_u64 = $util.Long ? $util.Long.fromBits(0,0,false) : 0;
    
                /**
                 * TestProtobufConvert fixed_i32.
                 * @member {number} fixed_i32
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.fixed_i32 = 0;
    
                /**
                 * TestProtobufConvert fixed_i64.
                 * @member {number|Long} fixed_i64
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.fixed_i64 = $util.Long ? $util.Long.fromBits(0,0,false) : 0;
    
                /**
                 * TestProtobufConvert float_32.
                 * @member {number} float_32
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.float_32 = 0;
    
                /**
                 * TestProtobufConvert float_64.
                 * @member {number} float_64
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.float_64 = 0;
    
                /**
                 * TestProtobufConvert boolean.
                 * @member {boolean} boolean
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.boolean = false;
    
                /**
                 * TestProtobufConvert s_i32.
                 * @member {number} s_i32
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.s_i32 = 0;
    
                /**
                 * TestProtobufConvert s_i64.
                 * @member {number|Long} s_i64
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.s_i64 = $util.Long ? $util.Long.fromBits(0,0,false) : 0;
    
                /**
                 * TestProtobufConvert bytes_field.
                 * @member {Uint8Array} bytes_field
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.bytes_field = $util.newBuffer([]);
    
                /**
                 * TestProtobufConvert string_field.
                 * @member {string} string_field
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.string_field = "";
    
                /**
                 * TestProtobufConvert message_field.
                 * @member {exonum.tests.IPoint|null|undefined} message_field
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.message_field = null;
    
                /**
                 * TestProtobufConvert bit_vec.
                 * @member {exonum.common.IBitVec|null|undefined} bit_vec
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.bit_vec = null;
    
                /**
                 * TestProtobufConvert time.
                 * @member {google.protobuf.ITimestamp|null|undefined} time
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 */
                TestProtobufConvert.prototype.time = null;
    
                /**
                 * Creates a new TestProtobufConvert instance using the specified properties.
                 * @function create
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {exonum.tests.ITestProtobufConvert=} [properties] Properties to set
                 * @returns {exonum.tests.TestProtobufConvert} TestProtobufConvert instance
                 */
                TestProtobufConvert.create = function create(properties) {
                    return new TestProtobufConvert(properties);
                };
    
                /**
                 * Encodes the specified TestProtobufConvert message. Does not implicitly {@link exonum.tests.TestProtobufConvert.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {exonum.tests.ITestProtobufConvert} message TestProtobufConvert message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestProtobufConvert.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.key != null && message.hasOwnProperty("key"))
                        $root.exonum.crypto.PublicKey.encode(message.key, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.hash != null && message.hasOwnProperty("hash"))
                        $root.exonum.crypto.Hash.encode(message.hash, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.unsigned_32 != null && message.hasOwnProperty("unsigned_32"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint32(message.unsigned_32);
                    if (message.unsigned_64 != null && message.hasOwnProperty("unsigned_64"))
                        writer.uint32(/* id 4, wireType 0 =*/32).uint64(message.unsigned_64);
                    if (message.regular_i32 != null && message.hasOwnProperty("regular_i32"))
                        writer.uint32(/* id 5, wireType 0 =*/40).int32(message.regular_i32);
                    if (message.regular_i64 != null && message.hasOwnProperty("regular_i64"))
                        writer.uint32(/* id 6, wireType 0 =*/48).int64(message.regular_i64);
                    if (message.fixed_u32 != null && message.hasOwnProperty("fixed_u32"))
                        writer.uint32(/* id 7, wireType 5 =*/61).fixed32(message.fixed_u32);
                    if (message.fixed_u64 != null && message.hasOwnProperty("fixed_u64"))
                        writer.uint32(/* id 8, wireType 1 =*/65).fixed64(message.fixed_u64);
                    if (message.fixed_i32 != null && message.hasOwnProperty("fixed_i32"))
                        writer.uint32(/* id 9, wireType 5 =*/77).sfixed32(message.fixed_i32);
                    if (message.fixed_i64 != null && message.hasOwnProperty("fixed_i64"))
                        writer.uint32(/* id 10, wireType 1 =*/81).sfixed64(message.fixed_i64);
                    if (message.float_32 != null && message.hasOwnProperty("float_32"))
                        writer.uint32(/* id 11, wireType 5 =*/93).float(message.float_32);
                    if (message.float_64 != null && message.hasOwnProperty("float_64"))
                        writer.uint32(/* id 12, wireType 1 =*/97).double(message.float_64);
                    if (message.boolean != null && message.hasOwnProperty("boolean"))
                        writer.uint32(/* id 13, wireType 0 =*/104).bool(message.boolean);
                    if (message.s_i32 != null && message.hasOwnProperty("s_i32"))
                        writer.uint32(/* id 14, wireType 0 =*/112).sint32(message.s_i32);
                    if (message.s_i64 != null && message.hasOwnProperty("s_i64"))
                        writer.uint32(/* id 15, wireType 0 =*/120).sint64(message.s_i64);
                    if (message.bytes_field != null && message.hasOwnProperty("bytes_field"))
                        writer.uint32(/* id 16, wireType 2 =*/130).bytes(message.bytes_field);
                    if (message.string_field != null && message.hasOwnProperty("string_field"))
                        writer.uint32(/* id 17, wireType 2 =*/138).string(message.string_field);
                    if (message.message_field != null && message.hasOwnProperty("message_field"))
                        $root.exonum.tests.Point.encode(message.message_field, writer.uint32(/* id 18, wireType 2 =*/146).fork()).ldelim();
                    if (message.bit_vec != null && message.hasOwnProperty("bit_vec"))
                        $root.exonum.common.BitVec.encode(message.bit_vec, writer.uint32(/* id 19, wireType 2 =*/154).fork()).ldelim();
                    if (message.time != null && message.hasOwnProperty("time"))
                        $root.google.protobuf.Timestamp.encode(message.time, writer.uint32(/* id 20, wireType 2 =*/162).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified TestProtobufConvert message, length delimited. Does not implicitly {@link exonum.tests.TestProtobufConvert.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {exonum.tests.ITestProtobufConvert} message TestProtobufConvert message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestProtobufConvert.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a TestProtobufConvert message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.tests.TestProtobufConvert} TestProtobufConvert
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestProtobufConvert.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.tests.TestProtobufConvert();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.key = $root.exonum.crypto.PublicKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        case 3:
                            message.unsigned_32 = reader.uint32();
                            break;
                        case 4:
                            message.unsigned_64 = reader.uint64();
                            break;
                        case 5:
                            message.regular_i32 = reader.int32();
                            break;
                        case 6:
                            message.regular_i64 = reader.int64();
                            break;
                        case 7:
                            message.fixed_u32 = reader.fixed32();
                            break;
                        case 8:
                            message.fixed_u64 = reader.fixed64();
                            break;
                        case 9:
                            message.fixed_i32 = reader.sfixed32();
                            break;
                        case 10:
                            message.fixed_i64 = reader.sfixed64();
                            break;
                        case 11:
                            message.float_32 = reader.float();
                            break;
                        case 12:
                            message.float_64 = reader.double();
                            break;
                        case 13:
                            message.boolean = reader.bool();
                            break;
                        case 14:
                            message.s_i32 = reader.sint32();
                            break;
                        case 15:
                            message.s_i64 = reader.sint64();
                            break;
                        case 16:
                            message.bytes_field = reader.bytes();
                            break;
                        case 17:
                            message.string_field = reader.string();
                            break;
                        case 18:
                            message.message_field = $root.exonum.tests.Point.decode(reader, reader.uint32());
                            break;
                        case 19:
                            message.bit_vec = $root.exonum.common.BitVec.decode(reader, reader.uint32());
                            break;
                        case 20:
                            message.time = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a TestProtobufConvert message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.tests.TestProtobufConvert} TestProtobufConvert
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestProtobufConvert.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a TestProtobufConvert message.
                 * @function verify
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                TestProtobufConvert.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.key != null && message.hasOwnProperty("key")) {
                        var error = $root.exonum.crypto.PublicKey.verify(message.key);
                        if (error)
                            return "key." + error;
                    }
                    if (message.hash != null && message.hasOwnProperty("hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.hash);
                        if (error)
                            return "hash." + error;
                    }
                    if (message.unsigned_32 != null && message.hasOwnProperty("unsigned_32"))
                        if (!$util.isInteger(message.unsigned_32))
                            return "unsigned_32: integer expected";
                    if (message.unsigned_64 != null && message.hasOwnProperty("unsigned_64"))
                        if (!$util.isInteger(message.unsigned_64) && !(message.unsigned_64 && $util.isInteger(message.unsigned_64.low) && $util.isInteger(message.unsigned_64.high)))
                            return "unsigned_64: integer|Long expected";
                    if (message.regular_i32 != null && message.hasOwnProperty("regular_i32"))
                        if (!$util.isInteger(message.regular_i32))
                            return "regular_i32: integer expected";
                    if (message.regular_i64 != null && message.hasOwnProperty("regular_i64"))
                        if (!$util.isInteger(message.regular_i64) && !(message.regular_i64 && $util.isInteger(message.regular_i64.low) && $util.isInteger(message.regular_i64.high)))
                            return "regular_i64: integer|Long expected";
                    if (message.fixed_u32 != null && message.hasOwnProperty("fixed_u32"))
                        if (!$util.isInteger(message.fixed_u32))
                            return "fixed_u32: integer expected";
                    if (message.fixed_u64 != null && message.hasOwnProperty("fixed_u64"))
                        if (!$util.isInteger(message.fixed_u64) && !(message.fixed_u64 && $util.isInteger(message.fixed_u64.low) && $util.isInteger(message.fixed_u64.high)))
                            return "fixed_u64: integer|Long expected";
                    if (message.fixed_i32 != null && message.hasOwnProperty("fixed_i32"))
                        if (!$util.isInteger(message.fixed_i32))
                            return "fixed_i32: integer expected";
                    if (message.fixed_i64 != null && message.hasOwnProperty("fixed_i64"))
                        if (!$util.isInteger(message.fixed_i64) && !(message.fixed_i64 && $util.isInteger(message.fixed_i64.low) && $util.isInteger(message.fixed_i64.high)))
                            return "fixed_i64: integer|Long expected";
                    if (message.float_32 != null && message.hasOwnProperty("float_32"))
                        if (typeof message.float_32 !== "number")
                            return "float_32: number expected";
                    if (message.float_64 != null && message.hasOwnProperty("float_64"))
                        if (typeof message.float_64 !== "number")
                            return "float_64: number expected";
                    if (message.boolean != null && message.hasOwnProperty("boolean"))
                        if (typeof message.boolean !== "boolean")
                            return "boolean: boolean expected";
                    if (message.s_i32 != null && message.hasOwnProperty("s_i32"))
                        if (!$util.isInteger(message.s_i32))
                            return "s_i32: integer expected";
                    if (message.s_i64 != null && message.hasOwnProperty("s_i64"))
                        if (!$util.isInteger(message.s_i64) && !(message.s_i64 && $util.isInteger(message.s_i64.low) && $util.isInteger(message.s_i64.high)))
                            return "s_i64: integer|Long expected";
                    if (message.bytes_field != null && message.hasOwnProperty("bytes_field"))
                        if (!(message.bytes_field && typeof message.bytes_field.length === "number" || $util.isString(message.bytes_field)))
                            return "bytes_field: buffer expected";
                    if (message.string_field != null && message.hasOwnProperty("string_field"))
                        if (!$util.isString(message.string_field))
                            return "string_field: string expected";
                    if (message.message_field != null && message.hasOwnProperty("message_field")) {
                        var error = $root.exonum.tests.Point.verify(message.message_field);
                        if (error)
                            return "message_field." + error;
                    }
                    if (message.bit_vec != null && message.hasOwnProperty("bit_vec")) {
                        var error = $root.exonum.common.BitVec.verify(message.bit_vec);
                        if (error)
                            return "bit_vec." + error;
                    }
                    if (message.time != null && message.hasOwnProperty("time")) {
                        var error = $root.google.protobuf.Timestamp.verify(message.time);
                        if (error)
                            return "time." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a TestProtobufConvert message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.tests.TestProtobufConvert} TestProtobufConvert
                 */
                TestProtobufConvert.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.tests.TestProtobufConvert)
                        return object;
                    var message = new $root.exonum.tests.TestProtobufConvert();
                    if (object.key != null) {
                        if (typeof object.key !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvert.key: object expected");
                        message.key = $root.exonum.crypto.PublicKey.fromObject(object.key);
                    }
                    if (object.hash != null) {
                        if (typeof object.hash !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvert.hash: object expected");
                        message.hash = $root.exonum.crypto.Hash.fromObject(object.hash);
                    }
                    if (object.unsigned_32 != null)
                        message.unsigned_32 = object.unsigned_32 >>> 0;
                    if (object.unsigned_64 != null)
                        if ($util.Long)
                            (message.unsigned_64 = $util.Long.fromValue(object.unsigned_64)).unsigned = true;
                        else if (typeof object.unsigned_64 === "string")
                            message.unsigned_64 = parseInt(object.unsigned_64, 10);
                        else if (typeof object.unsigned_64 === "number")
                            message.unsigned_64 = object.unsigned_64;
                        else if (typeof object.unsigned_64 === "object")
                            message.unsigned_64 = new $util.LongBits(object.unsigned_64.low >>> 0, object.unsigned_64.high >>> 0).toNumber(true);
                    if (object.regular_i32 != null)
                        message.regular_i32 = object.regular_i32 | 0;
                    if (object.regular_i64 != null)
                        if ($util.Long)
                            (message.regular_i64 = $util.Long.fromValue(object.regular_i64)).unsigned = false;
                        else if (typeof object.regular_i64 === "string")
                            message.regular_i64 = parseInt(object.regular_i64, 10);
                        else if (typeof object.regular_i64 === "number")
                            message.regular_i64 = object.regular_i64;
                        else if (typeof object.regular_i64 === "object")
                            message.regular_i64 = new $util.LongBits(object.regular_i64.low >>> 0, object.regular_i64.high >>> 0).toNumber();
                    if (object.fixed_u32 != null)
                        message.fixed_u32 = object.fixed_u32 >>> 0;
                    if (object.fixed_u64 != null)
                        if ($util.Long)
                            (message.fixed_u64 = $util.Long.fromValue(object.fixed_u64)).unsigned = false;
                        else if (typeof object.fixed_u64 === "string")
                            message.fixed_u64 = parseInt(object.fixed_u64, 10);
                        else if (typeof object.fixed_u64 === "number")
                            message.fixed_u64 = object.fixed_u64;
                        else if (typeof object.fixed_u64 === "object")
                            message.fixed_u64 = new $util.LongBits(object.fixed_u64.low >>> 0, object.fixed_u64.high >>> 0).toNumber();
                    if (object.fixed_i32 != null)
                        message.fixed_i32 = object.fixed_i32 | 0;
                    if (object.fixed_i64 != null)
                        if ($util.Long)
                            (message.fixed_i64 = $util.Long.fromValue(object.fixed_i64)).unsigned = false;
                        else if (typeof object.fixed_i64 === "string")
                            message.fixed_i64 = parseInt(object.fixed_i64, 10);
                        else if (typeof object.fixed_i64 === "number")
                            message.fixed_i64 = object.fixed_i64;
                        else if (typeof object.fixed_i64 === "object")
                            message.fixed_i64 = new $util.LongBits(object.fixed_i64.low >>> 0, object.fixed_i64.high >>> 0).toNumber();
                    if (object.float_32 != null)
                        message.float_32 = Number(object.float_32);
                    if (object.float_64 != null)
                        message.float_64 = Number(object.float_64);
                    if (object.boolean != null)
                        message.boolean = Boolean(object.boolean);
                    if (object.s_i32 != null)
                        message.s_i32 = object.s_i32 | 0;
                    if (object.s_i64 != null)
                        if ($util.Long)
                            (message.s_i64 = $util.Long.fromValue(object.s_i64)).unsigned = false;
                        else if (typeof object.s_i64 === "string")
                            message.s_i64 = parseInt(object.s_i64, 10);
                        else if (typeof object.s_i64 === "number")
                            message.s_i64 = object.s_i64;
                        else if (typeof object.s_i64 === "object")
                            message.s_i64 = new $util.LongBits(object.s_i64.low >>> 0, object.s_i64.high >>> 0).toNumber();
                    if (object.bytes_field != null)
                        if (typeof object.bytes_field === "string")
                            $util.base64.decode(object.bytes_field, message.bytes_field = $util.newBuffer($util.base64.length(object.bytes_field)), 0);
                        else if (object.bytes_field.length)
                            message.bytes_field = object.bytes_field;
                    if (object.string_field != null)
                        message.string_field = String(object.string_field);
                    if (object.message_field != null) {
                        if (typeof object.message_field !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvert.message_field: object expected");
                        message.message_field = $root.exonum.tests.Point.fromObject(object.message_field);
                    }
                    if (object.bit_vec != null) {
                        if (typeof object.bit_vec !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvert.bit_vec: object expected");
                        message.bit_vec = $root.exonum.common.BitVec.fromObject(object.bit_vec);
                    }
                    if (object.time != null) {
                        if (typeof object.time !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvert.time: object expected");
                        message.time = $root.google.protobuf.Timestamp.fromObject(object.time);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a TestProtobufConvert message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.tests.TestProtobufConvert
                 * @static
                 * @param {exonum.tests.TestProtobufConvert} message TestProtobufConvert
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                TestProtobufConvert.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.key = null;
                        object.hash = null;
                        object.unsigned_32 = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.unsigned_64 = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.unsigned_64 = options.longs === String ? "0" : 0;
                        object.regular_i32 = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, false);
                            object.regular_i64 = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.regular_i64 = options.longs === String ? "0" : 0;
                        object.fixed_u32 = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, false);
                            object.fixed_u64 = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.fixed_u64 = options.longs === String ? "0" : 0;
                        object.fixed_i32 = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, false);
                            object.fixed_i64 = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.fixed_i64 = options.longs === String ? "0" : 0;
                        object.float_32 = 0;
                        object.float_64 = 0;
                        object.boolean = false;
                        object.s_i32 = 0;
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, false);
                            object.s_i64 = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.s_i64 = options.longs === String ? "0" : 0;
                        if (options.bytes === String)
                            object.bytes_field = "";
                        else {
                            object.bytes_field = [];
                            if (options.bytes !== Array)
                                object.bytes_field = $util.newBuffer(object.bytes_field);
                        }
                        object.string_field = "";
                        object.message_field = null;
                        object.bit_vec = null;
                        object.time = null;
                    }
                    if (message.key != null && message.hasOwnProperty("key"))
                        object.key = $root.exonum.crypto.PublicKey.toObject(message.key, options);
                    if (message.hash != null && message.hasOwnProperty("hash"))
                        object.hash = $root.exonum.crypto.Hash.toObject(message.hash, options);
                    if (message.unsigned_32 != null && message.hasOwnProperty("unsigned_32"))
                        object.unsigned_32 = message.unsigned_32;
                    if (message.unsigned_64 != null && message.hasOwnProperty("unsigned_64"))
                        if (typeof message.unsigned_64 === "number")
                            object.unsigned_64 = options.longs === String ? String(message.unsigned_64) : message.unsigned_64;
                        else
                            object.unsigned_64 = options.longs === String ? $util.Long.prototype.toString.call(message.unsigned_64) : options.longs === Number ? new $util.LongBits(message.unsigned_64.low >>> 0, message.unsigned_64.high >>> 0).toNumber(true) : message.unsigned_64;
                    if (message.regular_i32 != null && message.hasOwnProperty("regular_i32"))
                        object.regular_i32 = message.regular_i32;
                    if (message.regular_i64 != null && message.hasOwnProperty("regular_i64"))
                        if (typeof message.regular_i64 === "number")
                            object.regular_i64 = options.longs === String ? String(message.regular_i64) : message.regular_i64;
                        else
                            object.regular_i64 = options.longs === String ? $util.Long.prototype.toString.call(message.regular_i64) : options.longs === Number ? new $util.LongBits(message.regular_i64.low >>> 0, message.regular_i64.high >>> 0).toNumber() : message.regular_i64;
                    if (message.fixed_u32 != null && message.hasOwnProperty("fixed_u32"))
                        object.fixed_u32 = message.fixed_u32;
                    if (message.fixed_u64 != null && message.hasOwnProperty("fixed_u64"))
                        if (typeof message.fixed_u64 === "number")
                            object.fixed_u64 = options.longs === String ? String(message.fixed_u64) : message.fixed_u64;
                        else
                            object.fixed_u64 = options.longs === String ? $util.Long.prototype.toString.call(message.fixed_u64) : options.longs === Number ? new $util.LongBits(message.fixed_u64.low >>> 0, message.fixed_u64.high >>> 0).toNumber() : message.fixed_u64;
                    if (message.fixed_i32 != null && message.hasOwnProperty("fixed_i32"))
                        object.fixed_i32 = message.fixed_i32;
                    if (message.fixed_i64 != null && message.hasOwnProperty("fixed_i64"))
                        if (typeof message.fixed_i64 === "number")
                            object.fixed_i64 = options.longs === String ? String(message.fixed_i64) : message.fixed_i64;
                        else
                            object.fixed_i64 = options.longs === String ? $util.Long.prototype.toString.call(message.fixed_i64) : options.longs === Number ? new $util.LongBits(message.fixed_i64.low >>> 0, message.fixed_i64.high >>> 0).toNumber() : message.fixed_i64;
                    if (message.float_32 != null && message.hasOwnProperty("float_32"))
                        object.float_32 = options.json && !isFinite(message.float_32) ? String(message.float_32) : message.float_32;
                    if (message.float_64 != null && message.hasOwnProperty("float_64"))
                        object.float_64 = options.json && !isFinite(message.float_64) ? String(message.float_64) : message.float_64;
                    if (message.boolean != null && message.hasOwnProperty("boolean"))
                        object.boolean = message.boolean;
                    if (message.s_i32 != null && message.hasOwnProperty("s_i32"))
                        object.s_i32 = message.s_i32;
                    if (message.s_i64 != null && message.hasOwnProperty("s_i64"))
                        if (typeof message.s_i64 === "number")
                            object.s_i64 = options.longs === String ? String(message.s_i64) : message.s_i64;
                        else
                            object.s_i64 = options.longs === String ? $util.Long.prototype.toString.call(message.s_i64) : options.longs === Number ? new $util.LongBits(message.s_i64.low >>> 0, message.s_i64.high >>> 0).toNumber() : message.s_i64;
                    if (message.bytes_field != null && message.hasOwnProperty("bytes_field"))
                        object.bytes_field = options.bytes === String ? $util.base64.encode(message.bytes_field, 0, message.bytes_field.length) : options.bytes === Array ? Array.prototype.slice.call(message.bytes_field) : message.bytes_field;
                    if (message.string_field != null && message.hasOwnProperty("string_field"))
                        object.string_field = message.string_field;
                    if (message.message_field != null && message.hasOwnProperty("message_field"))
                        object.message_field = $root.exonum.tests.Point.toObject(message.message_field, options);
                    if (message.bit_vec != null && message.hasOwnProperty("bit_vec"))
                        object.bit_vec = $root.exonum.common.BitVec.toObject(message.bit_vec, options);
                    if (message.time != null && message.hasOwnProperty("time"))
                        object.time = $root.google.protobuf.Timestamp.toObject(message.time, options);
                    return object;
                };
    
                /**
                 * Converts this TestProtobufConvert to JSON.
                 * @function toJSON
                 * @memberof exonum.tests.TestProtobufConvert
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                TestProtobufConvert.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return TestProtobufConvert;
            })();
    
            tests.TestProtobufConvertRepeated = (function() {
    
                /**
                 * Properties of a TestProtobufConvertRepeated.
                 * @memberof exonum.tests
                 * @interface ITestProtobufConvertRepeated
                 * @property {Array.<exonum.crypto.IPublicKey>|null} [keys] TestProtobufConvertRepeated keys
                 * @property {Array.<Uint8Array>|null} [bytes_array] TestProtobufConvertRepeated bytes_array
                 * @property {Array.<string>|null} [string_array] TestProtobufConvertRepeated string_array
                 * @property {Array.<number>|null} [num_array] TestProtobufConvertRepeated num_array
                 */
    
                /**
                 * Constructs a new TestProtobufConvertRepeated.
                 * @memberof exonum.tests
                 * @classdesc Represents a TestProtobufConvertRepeated.
                 * @implements ITestProtobufConvertRepeated
                 * @constructor
                 * @param {exonum.tests.ITestProtobufConvertRepeated=} [properties] Properties to set
                 */
                function TestProtobufConvertRepeated(properties) {
                    this.keys = [];
                    this.bytes_array = [];
                    this.string_array = [];
                    this.num_array = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * TestProtobufConvertRepeated keys.
                 * @member {Array.<exonum.crypto.IPublicKey>} keys
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @instance
                 */
                TestProtobufConvertRepeated.prototype.keys = $util.emptyArray;
    
                /**
                 * TestProtobufConvertRepeated bytes_array.
                 * @member {Array.<Uint8Array>} bytes_array
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @instance
                 */
                TestProtobufConvertRepeated.prototype.bytes_array = $util.emptyArray;
    
                /**
                 * TestProtobufConvertRepeated string_array.
                 * @member {Array.<string>} string_array
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @instance
                 */
                TestProtobufConvertRepeated.prototype.string_array = $util.emptyArray;
    
                /**
                 * TestProtobufConvertRepeated num_array.
                 * @member {Array.<number>} num_array
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @instance
                 */
                TestProtobufConvertRepeated.prototype.num_array = $util.emptyArray;
    
                /**
                 * Creates a new TestProtobufConvertRepeated instance using the specified properties.
                 * @function create
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {exonum.tests.ITestProtobufConvertRepeated=} [properties] Properties to set
                 * @returns {exonum.tests.TestProtobufConvertRepeated} TestProtobufConvertRepeated instance
                 */
                TestProtobufConvertRepeated.create = function create(properties) {
                    return new TestProtobufConvertRepeated(properties);
                };
    
                /**
                 * Encodes the specified TestProtobufConvertRepeated message. Does not implicitly {@link exonum.tests.TestProtobufConvertRepeated.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {exonum.tests.ITestProtobufConvertRepeated} message TestProtobufConvertRepeated message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestProtobufConvertRepeated.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.keys != null && message.keys.length)
                        for (var i = 0; i < message.keys.length; ++i)
                            $root.exonum.crypto.PublicKey.encode(message.keys[i], writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.bytes_array != null && message.bytes_array.length)
                        for (var i = 0; i < message.bytes_array.length; ++i)
                            writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.bytes_array[i]);
                    if (message.string_array != null && message.string_array.length)
                        for (var i = 0; i < message.string_array.length; ++i)
                            writer.uint32(/* id 3, wireType 2 =*/26).string(message.string_array[i]);
                    if (message.num_array != null && message.num_array.length) {
                        writer.uint32(/* id 4, wireType 2 =*/34).fork();
                        for (var i = 0; i < message.num_array.length; ++i)
                            writer.uint32(message.num_array[i]);
                        writer.ldelim();
                    }
                    return writer;
                };
    
                /**
                 * Encodes the specified TestProtobufConvertRepeated message, length delimited. Does not implicitly {@link exonum.tests.TestProtobufConvertRepeated.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {exonum.tests.ITestProtobufConvertRepeated} message TestProtobufConvertRepeated message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestProtobufConvertRepeated.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a TestProtobufConvertRepeated message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.tests.TestProtobufConvertRepeated} TestProtobufConvertRepeated
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestProtobufConvertRepeated.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.tests.TestProtobufConvertRepeated();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            if (!(message.keys && message.keys.length))
                                message.keys = [];
                            message.keys.push($root.exonum.crypto.PublicKey.decode(reader, reader.uint32()));
                            break;
                        case 2:
                            if (!(message.bytes_array && message.bytes_array.length))
                                message.bytes_array = [];
                            message.bytes_array.push(reader.bytes());
                            break;
                        case 3:
                            if (!(message.string_array && message.string_array.length))
                                message.string_array = [];
                            message.string_array.push(reader.string());
                            break;
                        case 4:
                            if (!(message.num_array && message.num_array.length))
                                message.num_array = [];
                            if ((tag & 7) === 2) {
                                var end2 = reader.uint32() + reader.pos;
                                while (reader.pos < end2)
                                    message.num_array.push(reader.uint32());
                            } else
                                message.num_array.push(reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a TestProtobufConvertRepeated message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.tests.TestProtobufConvertRepeated} TestProtobufConvertRepeated
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestProtobufConvertRepeated.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a TestProtobufConvertRepeated message.
                 * @function verify
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                TestProtobufConvertRepeated.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.keys != null && message.hasOwnProperty("keys")) {
                        if (!Array.isArray(message.keys))
                            return "keys: array expected";
                        for (var i = 0; i < message.keys.length; ++i) {
                            var error = $root.exonum.crypto.PublicKey.verify(message.keys[i]);
                            if (error)
                                return "keys." + error;
                        }
                    }
                    if (message.bytes_array != null && message.hasOwnProperty("bytes_array")) {
                        if (!Array.isArray(message.bytes_array))
                            return "bytes_array: array expected";
                        for (var i = 0; i < message.bytes_array.length; ++i)
                            if (!(message.bytes_array[i] && typeof message.bytes_array[i].length === "number" || $util.isString(message.bytes_array[i])))
                                return "bytes_array: buffer[] expected";
                    }
                    if (message.string_array != null && message.hasOwnProperty("string_array")) {
                        if (!Array.isArray(message.string_array))
                            return "string_array: array expected";
                        for (var i = 0; i < message.string_array.length; ++i)
                            if (!$util.isString(message.string_array[i]))
                                return "string_array: string[] expected";
                    }
                    if (message.num_array != null && message.hasOwnProperty("num_array")) {
                        if (!Array.isArray(message.num_array))
                            return "num_array: array expected";
                        for (var i = 0; i < message.num_array.length; ++i)
                            if (!$util.isInteger(message.num_array[i]))
                                return "num_array: integer[] expected";
                    }
                    return null;
                };
    
                /**
                 * Creates a TestProtobufConvertRepeated message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.tests.TestProtobufConvertRepeated} TestProtobufConvertRepeated
                 */
                TestProtobufConvertRepeated.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.tests.TestProtobufConvertRepeated)
                        return object;
                    var message = new $root.exonum.tests.TestProtobufConvertRepeated();
                    if (object.keys) {
                        if (!Array.isArray(object.keys))
                            throw TypeError(".exonum.tests.TestProtobufConvertRepeated.keys: array expected");
                        message.keys = [];
                        for (var i = 0; i < object.keys.length; ++i) {
                            if (typeof object.keys[i] !== "object")
                                throw TypeError(".exonum.tests.TestProtobufConvertRepeated.keys: object expected");
                            message.keys[i] = $root.exonum.crypto.PublicKey.fromObject(object.keys[i]);
                        }
                    }
                    if (object.bytes_array) {
                        if (!Array.isArray(object.bytes_array))
                            throw TypeError(".exonum.tests.TestProtobufConvertRepeated.bytes_array: array expected");
                        message.bytes_array = [];
                        for (var i = 0; i < object.bytes_array.length; ++i)
                            if (typeof object.bytes_array[i] === "string")
                                $util.base64.decode(object.bytes_array[i], message.bytes_array[i] = $util.newBuffer($util.base64.length(object.bytes_array[i])), 0);
                            else if (object.bytes_array[i].length)
                                message.bytes_array[i] = object.bytes_array[i];
                    }
                    if (object.string_array) {
                        if (!Array.isArray(object.string_array))
                            throw TypeError(".exonum.tests.TestProtobufConvertRepeated.string_array: array expected");
                        message.string_array = [];
                        for (var i = 0; i < object.string_array.length; ++i)
                            message.string_array[i] = String(object.string_array[i]);
                    }
                    if (object.num_array) {
                        if (!Array.isArray(object.num_array))
                            throw TypeError(".exonum.tests.TestProtobufConvertRepeated.num_array: array expected");
                        message.num_array = [];
                        for (var i = 0; i < object.num_array.length; ++i)
                            message.num_array[i] = object.num_array[i] >>> 0;
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a TestProtobufConvertRepeated message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @static
                 * @param {exonum.tests.TestProtobufConvertRepeated} message TestProtobufConvertRepeated
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                TestProtobufConvertRepeated.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults) {
                        object.keys = [];
                        object.bytes_array = [];
                        object.string_array = [];
                        object.num_array = [];
                    }
                    if (message.keys && message.keys.length) {
                        object.keys = [];
                        for (var j = 0; j < message.keys.length; ++j)
                            object.keys[j] = $root.exonum.crypto.PublicKey.toObject(message.keys[j], options);
                    }
                    if (message.bytes_array && message.bytes_array.length) {
                        object.bytes_array = [];
                        for (var j = 0; j < message.bytes_array.length; ++j)
                            object.bytes_array[j] = options.bytes === String ? $util.base64.encode(message.bytes_array[j], 0, message.bytes_array[j].length) : options.bytes === Array ? Array.prototype.slice.call(message.bytes_array[j]) : message.bytes_array[j];
                    }
                    if (message.string_array && message.string_array.length) {
                        object.string_array = [];
                        for (var j = 0; j < message.string_array.length; ++j)
                            object.string_array[j] = message.string_array[j];
                    }
                    if (message.num_array && message.num_array.length) {
                        object.num_array = [];
                        for (var j = 0; j < message.num_array.length; ++j)
                            object.num_array[j] = message.num_array[j];
                    }
                    return object;
                };
    
                /**
                 * Converts this TestProtobufConvertRepeated to JSON.
                 * @function toJSON
                 * @memberof exonum.tests.TestProtobufConvertRepeated
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                TestProtobufConvertRepeated.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return TestProtobufConvertRepeated;
            })();
    
            tests.TestProtobufConvertMap = (function() {
    
                /**
                 * Properties of a TestProtobufConvertMap.
                 * @memberof exonum.tests
                 * @interface ITestProtobufConvertMap
                 * @property {Object.<string,number|Long>|null} [num_map] TestProtobufConvertMap num_map
                 * @property {Object.<string,string>|null} [string_map] TestProtobufConvertMap string_map
                 * @property {Object.<string,Uint8Array>|null} [bytes_map] TestProtobufConvertMap bytes_map
                 * @property {Object.<string,exonum.tests.IPoint>|null} [point_map] TestProtobufConvertMap point_map
                 * @property {Object.<string,number|Long>|null} [key_string_map] TestProtobufConvertMap key_string_map
                 */
    
                /**
                 * Constructs a new TestProtobufConvertMap.
                 * @memberof exonum.tests
                 * @classdesc Represents a TestProtobufConvertMap.
                 * @implements ITestProtobufConvertMap
                 * @constructor
                 * @param {exonum.tests.ITestProtobufConvertMap=} [properties] Properties to set
                 */
                function TestProtobufConvertMap(properties) {
                    this.num_map = {};
                    this.string_map = {};
                    this.bytes_map = {};
                    this.point_map = {};
                    this.key_string_map = {};
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * TestProtobufConvertMap num_map.
                 * @member {Object.<string,number|Long>} num_map
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @instance
                 */
                TestProtobufConvertMap.prototype.num_map = $util.emptyObject;
    
                /**
                 * TestProtobufConvertMap string_map.
                 * @member {Object.<string,string>} string_map
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @instance
                 */
                TestProtobufConvertMap.prototype.string_map = $util.emptyObject;
    
                /**
                 * TestProtobufConvertMap bytes_map.
                 * @member {Object.<string,Uint8Array>} bytes_map
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @instance
                 */
                TestProtobufConvertMap.prototype.bytes_map = $util.emptyObject;
    
                /**
                 * TestProtobufConvertMap point_map.
                 * @member {Object.<string,exonum.tests.IPoint>} point_map
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @instance
                 */
                TestProtobufConvertMap.prototype.point_map = $util.emptyObject;
    
                /**
                 * TestProtobufConvertMap key_string_map.
                 * @member {Object.<string,number|Long>} key_string_map
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @instance
                 */
                TestProtobufConvertMap.prototype.key_string_map = $util.emptyObject;
    
                /**
                 * Creates a new TestProtobufConvertMap instance using the specified properties.
                 * @function create
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {exonum.tests.ITestProtobufConvertMap=} [properties] Properties to set
                 * @returns {exonum.tests.TestProtobufConvertMap} TestProtobufConvertMap instance
                 */
                TestProtobufConvertMap.create = function create(properties) {
                    return new TestProtobufConvertMap(properties);
                };
    
                /**
                 * Encodes the specified TestProtobufConvertMap message. Does not implicitly {@link exonum.tests.TestProtobufConvertMap.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {exonum.tests.ITestProtobufConvertMap} message TestProtobufConvertMap message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestProtobufConvertMap.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.num_map != null && message.hasOwnProperty("num_map"))
                        for (var keys = Object.keys(message.num_map), i = 0; i < keys.length; ++i)
                            writer.uint32(/* id 1, wireType 2 =*/10).fork().uint32(/* id 1, wireType 0 =*/8).uint32(keys[i]).uint32(/* id 2, wireType 0 =*/16).uint64(message.num_map[keys[i]]).ldelim();
                    if (message.string_map != null && message.hasOwnProperty("string_map"))
                        for (var keys = Object.keys(message.string_map), i = 0; i < keys.length; ++i)
                            writer.uint32(/* id 2, wireType 2 =*/18).fork().uint32(/* id 1, wireType 0 =*/8).uint32(keys[i]).uint32(/* id 2, wireType 2 =*/18).string(message.string_map[keys[i]]).ldelim();
                    if (message.bytes_map != null && message.hasOwnProperty("bytes_map"))
                        for (var keys = Object.keys(message.bytes_map), i = 0; i < keys.length; ++i)
                            writer.uint32(/* id 4, wireType 2 =*/34).fork().uint32(/* id 1, wireType 0 =*/8).uint32(keys[i]).uint32(/* id 2, wireType 2 =*/18).bytes(message.bytes_map[keys[i]]).ldelim();
                    if (message.point_map != null && message.hasOwnProperty("point_map"))
                        for (var keys = Object.keys(message.point_map), i = 0; i < keys.length; ++i) {
                            writer.uint32(/* id 5, wireType 2 =*/42).fork().uint32(/* id 1, wireType 0 =*/8).uint32(keys[i]);
                            $root.exonum.tests.Point.encode(message.point_map[keys[i]], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim().ldelim();
                        }
                    if (message.key_string_map != null && message.hasOwnProperty("key_string_map"))
                        for (var keys = Object.keys(message.key_string_map), i = 0; i < keys.length; ++i)
                            writer.uint32(/* id 6, wireType 2 =*/50).fork().uint32(/* id 1, wireType 2 =*/10).string(keys[i]).uint32(/* id 2, wireType 0 =*/16).uint64(message.key_string_map[keys[i]]).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified TestProtobufConvertMap message, length delimited. Does not implicitly {@link exonum.tests.TestProtobufConvertMap.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {exonum.tests.ITestProtobufConvertMap} message TestProtobufConvertMap message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestProtobufConvertMap.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a TestProtobufConvertMap message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.tests.TestProtobufConvertMap} TestProtobufConvertMap
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestProtobufConvertMap.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.tests.TestProtobufConvertMap(), key;
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            reader.skip().pos++;
                            if (message.num_map === $util.emptyObject)
                                message.num_map = {};
                            key = reader.uint32();
                            reader.pos++;
                            message.num_map[key] = reader.uint64();
                            break;
                        case 2:
                            reader.skip().pos++;
                            if (message.string_map === $util.emptyObject)
                                message.string_map = {};
                            key = reader.uint32();
                            reader.pos++;
                            message.string_map[key] = reader.string();
                            break;
                        case 4:
                            reader.skip().pos++;
                            if (message.bytes_map === $util.emptyObject)
                                message.bytes_map = {};
                            key = reader.uint32();
                            reader.pos++;
                            message.bytes_map[key] = reader.bytes();
                            break;
                        case 5:
                            reader.skip().pos++;
                            if (message.point_map === $util.emptyObject)
                                message.point_map = {};
                            key = reader.uint32();
                            reader.pos++;
                            message.point_map[key] = $root.exonum.tests.Point.decode(reader, reader.uint32());
                            break;
                        case 6:
                            reader.skip().pos++;
                            if (message.key_string_map === $util.emptyObject)
                                message.key_string_map = {};
                            key = reader.string();
                            reader.pos++;
                            message.key_string_map[key] = reader.uint64();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a TestProtobufConvertMap message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.tests.TestProtobufConvertMap} TestProtobufConvertMap
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestProtobufConvertMap.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a TestProtobufConvertMap message.
                 * @function verify
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                TestProtobufConvertMap.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.num_map != null && message.hasOwnProperty("num_map")) {
                        if (!$util.isObject(message.num_map))
                            return "num_map: object expected";
                        var key = Object.keys(message.num_map);
                        for (var i = 0; i < key.length; ++i) {
                            if (!$util.key32Re.test(key[i]))
                                return "num_map: integer key{k:uint32} expected";
                            if (!$util.isInteger(message.num_map[key[i]]) && !(message.num_map[key[i]] && $util.isInteger(message.num_map[key[i]].low) && $util.isInteger(message.num_map[key[i]].high)))
                                return "num_map: integer|Long{k:uint32} expected";
                        }
                    }
                    if (message.string_map != null && message.hasOwnProperty("string_map")) {
                        if (!$util.isObject(message.string_map))
                            return "string_map: object expected";
                        var key = Object.keys(message.string_map);
                        for (var i = 0; i < key.length; ++i) {
                            if (!$util.key32Re.test(key[i]))
                                return "string_map: integer key{k:uint32} expected";
                            if (!$util.isString(message.string_map[key[i]]))
                                return "string_map: string{k:uint32} expected";
                        }
                    }
                    if (message.bytes_map != null && message.hasOwnProperty("bytes_map")) {
                        if (!$util.isObject(message.bytes_map))
                            return "bytes_map: object expected";
                        var key = Object.keys(message.bytes_map);
                        for (var i = 0; i < key.length; ++i) {
                            if (!$util.key32Re.test(key[i]))
                                return "bytes_map: integer key{k:uint32} expected";
                            if (!(message.bytes_map[key[i]] && typeof message.bytes_map[key[i]].length === "number" || $util.isString(message.bytes_map[key[i]])))
                                return "bytes_map: buffer{k:uint32} expected";
                        }
                    }
                    if (message.point_map != null && message.hasOwnProperty("point_map")) {
                        if (!$util.isObject(message.point_map))
                            return "point_map: object expected";
                        var key = Object.keys(message.point_map);
                        for (var i = 0; i < key.length; ++i) {
                            if (!$util.key32Re.test(key[i]))
                                return "point_map: integer key{k:uint32} expected";
                            {
                                var error = $root.exonum.tests.Point.verify(message.point_map[key[i]]);
                                if (error)
                                    return "point_map." + error;
                            }
                        }
                    }
                    if (message.key_string_map != null && message.hasOwnProperty("key_string_map")) {
                        if (!$util.isObject(message.key_string_map))
                            return "key_string_map: object expected";
                        var key = Object.keys(message.key_string_map);
                        for (var i = 0; i < key.length; ++i)
                            if (!$util.isInteger(message.key_string_map[key[i]]) && !(message.key_string_map[key[i]] && $util.isInteger(message.key_string_map[key[i]].low) && $util.isInteger(message.key_string_map[key[i]].high)))
                                return "key_string_map: integer|Long{k:string} expected";
                    }
                    return null;
                };
    
                /**
                 * Creates a TestProtobufConvertMap message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.tests.TestProtobufConvertMap} TestProtobufConvertMap
                 */
                TestProtobufConvertMap.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.tests.TestProtobufConvertMap)
                        return object;
                    var message = new $root.exonum.tests.TestProtobufConvertMap();
                    if (object.num_map) {
                        if (typeof object.num_map !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvertMap.num_map: object expected");
                        message.num_map = {};
                        for (var keys = Object.keys(object.num_map), i = 0; i < keys.length; ++i)
                            if ($util.Long)
                                (message.num_map[keys[i]] = $util.Long.fromValue(object.num_map[keys[i]])).unsigned = true;
                            else if (typeof object.num_map[keys[i]] === "string")
                                message.num_map[keys[i]] = parseInt(object.num_map[keys[i]], 10);
                            else if (typeof object.num_map[keys[i]] === "number")
                                message.num_map[keys[i]] = object.num_map[keys[i]];
                            else if (typeof object.num_map[keys[i]] === "object")
                                message.num_map[keys[i]] = new $util.LongBits(object.num_map[keys[i]].low >>> 0, object.num_map[keys[i]].high >>> 0).toNumber(true);
                    }
                    if (object.string_map) {
                        if (typeof object.string_map !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvertMap.string_map: object expected");
                        message.string_map = {};
                        for (var keys = Object.keys(object.string_map), i = 0; i < keys.length; ++i)
                            message.string_map[keys[i]] = String(object.string_map[keys[i]]);
                    }
                    if (object.bytes_map) {
                        if (typeof object.bytes_map !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvertMap.bytes_map: object expected");
                        message.bytes_map = {};
                        for (var keys = Object.keys(object.bytes_map), i = 0; i < keys.length; ++i)
                            if (typeof object.bytes_map[keys[i]] === "string")
                                $util.base64.decode(object.bytes_map[keys[i]], message.bytes_map[keys[i]] = $util.newBuffer($util.base64.length(object.bytes_map[keys[i]])), 0);
                            else if (object.bytes_map[keys[i]].length)
                                message.bytes_map[keys[i]] = object.bytes_map[keys[i]];
                    }
                    if (object.point_map) {
                        if (typeof object.point_map !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvertMap.point_map: object expected");
                        message.point_map = {};
                        for (var keys = Object.keys(object.point_map), i = 0; i < keys.length; ++i) {
                            if (typeof object.point_map[keys[i]] !== "object")
                                throw TypeError(".exonum.tests.TestProtobufConvertMap.point_map: object expected");
                            message.point_map[keys[i]] = $root.exonum.tests.Point.fromObject(object.point_map[keys[i]]);
                        }
                    }
                    if (object.key_string_map) {
                        if (typeof object.key_string_map !== "object")
                            throw TypeError(".exonum.tests.TestProtobufConvertMap.key_string_map: object expected");
                        message.key_string_map = {};
                        for (var keys = Object.keys(object.key_string_map), i = 0; i < keys.length; ++i)
                            if ($util.Long)
                                (message.key_string_map[keys[i]] = $util.Long.fromValue(object.key_string_map[keys[i]])).unsigned = true;
                            else if (typeof object.key_string_map[keys[i]] === "string")
                                message.key_string_map[keys[i]] = parseInt(object.key_string_map[keys[i]], 10);
                            else if (typeof object.key_string_map[keys[i]] === "number")
                                message.key_string_map[keys[i]] = object.key_string_map[keys[i]];
                            else if (typeof object.key_string_map[keys[i]] === "object")
                                message.key_string_map[keys[i]] = new $util.LongBits(object.key_string_map[keys[i]].low >>> 0, object.key_string_map[keys[i]].high >>> 0).toNumber(true);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a TestProtobufConvertMap message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @static
                 * @param {exonum.tests.TestProtobufConvertMap} message TestProtobufConvertMap
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                TestProtobufConvertMap.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.objects || options.defaults) {
                        object.num_map = {};
                        object.string_map = {};
                        object.bytes_map = {};
                        object.point_map = {};
                        object.key_string_map = {};
                    }
                    var keys2;
                    if (message.num_map && (keys2 = Object.keys(message.num_map)).length) {
                        object.num_map = {};
                        for (var j = 0; j < keys2.length; ++j)
                            if (typeof message.num_map[keys2[j]] === "number")
                                object.num_map[keys2[j]] = options.longs === String ? String(message.num_map[keys2[j]]) : message.num_map[keys2[j]];
                            else
                                object.num_map[keys2[j]] = options.longs === String ? $util.Long.prototype.toString.call(message.num_map[keys2[j]]) : options.longs === Number ? new $util.LongBits(message.num_map[keys2[j]].low >>> 0, message.num_map[keys2[j]].high >>> 0).toNumber(true) : message.num_map[keys2[j]];
                    }
                    if (message.string_map && (keys2 = Object.keys(message.string_map)).length) {
                        object.string_map = {};
                        for (var j = 0; j < keys2.length; ++j)
                            object.string_map[keys2[j]] = message.string_map[keys2[j]];
                    }
                    if (message.bytes_map && (keys2 = Object.keys(message.bytes_map)).length) {
                        object.bytes_map = {};
                        for (var j = 0; j < keys2.length; ++j)
                            object.bytes_map[keys2[j]] = options.bytes === String ? $util.base64.encode(message.bytes_map[keys2[j]], 0, message.bytes_map[keys2[j]].length) : options.bytes === Array ? Array.prototype.slice.call(message.bytes_map[keys2[j]]) : message.bytes_map[keys2[j]];
                    }
                    if (message.point_map && (keys2 = Object.keys(message.point_map)).length) {
                        object.point_map = {};
                        for (var j = 0; j < keys2.length; ++j)
                            object.point_map[keys2[j]] = $root.exonum.tests.Point.toObject(message.point_map[keys2[j]], options);
                    }
                    if (message.key_string_map && (keys2 = Object.keys(message.key_string_map)).length) {
                        object.key_string_map = {};
                        for (var j = 0; j < keys2.length; ++j)
                            if (typeof message.key_string_map[keys2[j]] === "number")
                                object.key_string_map[keys2[j]] = options.longs === String ? String(message.key_string_map[keys2[j]]) : message.key_string_map[keys2[j]];
                            else
                                object.key_string_map[keys2[j]] = options.longs === String ? $util.Long.prototype.toString.call(message.key_string_map[keys2[j]]) : options.longs === Number ? new $util.LongBits(message.key_string_map[keys2[j]].low >>> 0, message.key_string_map[keys2[j]].high >>> 0).toNumber(true) : message.key_string_map[keys2[j]];
                    }
                    return object;
                };
    
                /**
                 * Converts this TestProtobufConvertMap to JSON.
                 * @function toJSON
                 * @memberof exonum.tests.TestProtobufConvertMap
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                TestProtobufConvertMap.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return TestProtobufConvertMap;
            })();
    
            tests.TestFixedArrays = (function() {
    
                /**
                 * Properties of a TestFixedArrays.
                 * @memberof exonum.tests
                 * @interface ITestFixedArrays
                 * @property {Uint8Array|null} [fixed_array_8] TestFixedArrays fixed_array_8
                 * @property {Uint8Array|null} [fixed_array_16] TestFixedArrays fixed_array_16
                 * @property {Uint8Array|null} [fixed_array_32] TestFixedArrays fixed_array_32
                 */
    
                /**
                 * Constructs a new TestFixedArrays.
                 * @memberof exonum.tests
                 * @classdesc Represents a TestFixedArrays.
                 * @implements ITestFixedArrays
                 * @constructor
                 * @param {exonum.tests.ITestFixedArrays=} [properties] Properties to set
                 */
                function TestFixedArrays(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * TestFixedArrays fixed_array_8.
                 * @member {Uint8Array} fixed_array_8
                 * @memberof exonum.tests.TestFixedArrays
                 * @instance
                 */
                TestFixedArrays.prototype.fixed_array_8 = $util.newBuffer([]);
    
                /**
                 * TestFixedArrays fixed_array_16.
                 * @member {Uint8Array} fixed_array_16
                 * @memberof exonum.tests.TestFixedArrays
                 * @instance
                 */
                TestFixedArrays.prototype.fixed_array_16 = $util.newBuffer([]);
    
                /**
                 * TestFixedArrays fixed_array_32.
                 * @member {Uint8Array} fixed_array_32
                 * @memberof exonum.tests.TestFixedArrays
                 * @instance
                 */
                TestFixedArrays.prototype.fixed_array_32 = $util.newBuffer([]);
    
                /**
                 * Creates a new TestFixedArrays instance using the specified properties.
                 * @function create
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {exonum.tests.ITestFixedArrays=} [properties] Properties to set
                 * @returns {exonum.tests.TestFixedArrays} TestFixedArrays instance
                 */
                TestFixedArrays.create = function create(properties) {
                    return new TestFixedArrays(properties);
                };
    
                /**
                 * Encodes the specified TestFixedArrays message. Does not implicitly {@link exonum.tests.TestFixedArrays.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {exonum.tests.ITestFixedArrays} message TestFixedArrays message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestFixedArrays.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.fixed_array_8 != null && message.hasOwnProperty("fixed_array_8"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.fixed_array_8);
                    if (message.fixed_array_16 != null && message.hasOwnProperty("fixed_array_16"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.fixed_array_16);
                    if (message.fixed_array_32 != null && message.hasOwnProperty("fixed_array_32"))
                        writer.uint32(/* id 3, wireType 2 =*/26).bytes(message.fixed_array_32);
                    return writer;
                };
    
                /**
                 * Encodes the specified TestFixedArrays message, length delimited. Does not implicitly {@link exonum.tests.TestFixedArrays.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {exonum.tests.ITestFixedArrays} message TestFixedArrays message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                TestFixedArrays.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a TestFixedArrays message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.tests.TestFixedArrays} TestFixedArrays
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestFixedArrays.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.tests.TestFixedArrays();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.fixed_array_8 = reader.bytes();
                            break;
                        case 2:
                            message.fixed_array_16 = reader.bytes();
                            break;
                        case 3:
                            message.fixed_array_32 = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a TestFixedArrays message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.tests.TestFixedArrays} TestFixedArrays
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                TestFixedArrays.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a TestFixedArrays message.
                 * @function verify
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                TestFixedArrays.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.fixed_array_8 != null && message.hasOwnProperty("fixed_array_8"))
                        if (!(message.fixed_array_8 && typeof message.fixed_array_8.length === "number" || $util.isString(message.fixed_array_8)))
                            return "fixed_array_8: buffer expected";
                    if (message.fixed_array_16 != null && message.hasOwnProperty("fixed_array_16"))
                        if (!(message.fixed_array_16 && typeof message.fixed_array_16.length === "number" || $util.isString(message.fixed_array_16)))
                            return "fixed_array_16: buffer expected";
                    if (message.fixed_array_32 != null && message.hasOwnProperty("fixed_array_32"))
                        if (!(message.fixed_array_32 && typeof message.fixed_array_32.length === "number" || $util.isString(message.fixed_array_32)))
                            return "fixed_array_32: buffer expected";
                    return null;
                };
    
                /**
                 * Creates a TestFixedArrays message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.tests.TestFixedArrays} TestFixedArrays
                 */
                TestFixedArrays.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.tests.TestFixedArrays)
                        return object;
                    var message = new $root.exonum.tests.TestFixedArrays();
                    if (object.fixed_array_8 != null)
                        if (typeof object.fixed_array_8 === "string")
                            $util.base64.decode(object.fixed_array_8, message.fixed_array_8 = $util.newBuffer($util.base64.length(object.fixed_array_8)), 0);
                        else if (object.fixed_array_8.length)
                            message.fixed_array_8 = object.fixed_array_8;
                    if (object.fixed_array_16 != null)
                        if (typeof object.fixed_array_16 === "string")
                            $util.base64.decode(object.fixed_array_16, message.fixed_array_16 = $util.newBuffer($util.base64.length(object.fixed_array_16)), 0);
                        else if (object.fixed_array_16.length)
                            message.fixed_array_16 = object.fixed_array_16;
                    if (object.fixed_array_32 != null)
                        if (typeof object.fixed_array_32 === "string")
                            $util.base64.decode(object.fixed_array_32, message.fixed_array_32 = $util.newBuffer($util.base64.length(object.fixed_array_32)), 0);
                        else if (object.fixed_array_32.length)
                            message.fixed_array_32 = object.fixed_array_32;
                    return message;
                };
    
                /**
                 * Creates a plain object from a TestFixedArrays message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.tests.TestFixedArrays
                 * @static
                 * @param {exonum.tests.TestFixedArrays} message TestFixedArrays
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                TestFixedArrays.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if (options.bytes === String)
                            object.fixed_array_8 = "";
                        else {
                            object.fixed_array_8 = [];
                            if (options.bytes !== Array)
                                object.fixed_array_8 = $util.newBuffer(object.fixed_array_8);
                        }
                        if (options.bytes === String)
                            object.fixed_array_16 = "";
                        else {
                            object.fixed_array_16 = [];
                            if (options.bytes !== Array)
                                object.fixed_array_16 = $util.newBuffer(object.fixed_array_16);
                        }
                        if (options.bytes === String)
                            object.fixed_array_32 = "";
                        else {
                            object.fixed_array_32 = [];
                            if (options.bytes !== Array)
                                object.fixed_array_32 = $util.newBuffer(object.fixed_array_32);
                        }
                    }
                    if (message.fixed_array_8 != null && message.hasOwnProperty("fixed_array_8"))
                        object.fixed_array_8 = options.bytes === String ? $util.base64.encode(message.fixed_array_8, 0, message.fixed_array_8.length) : options.bytes === Array ? Array.prototype.slice.call(message.fixed_array_8) : message.fixed_array_8;
                    if (message.fixed_array_16 != null && message.hasOwnProperty("fixed_array_16"))
                        object.fixed_array_16 = options.bytes === String ? $util.base64.encode(message.fixed_array_16, 0, message.fixed_array_16.length) : options.bytes === Array ? Array.prototype.slice.call(message.fixed_array_16) : message.fixed_array_16;
                    if (message.fixed_array_32 != null && message.hasOwnProperty("fixed_array_32"))
                        object.fixed_array_32 = options.bytes === String ? $util.base64.encode(message.fixed_array_32, 0, message.fixed_array_32.length) : options.bytes === Array ? Array.prototype.slice.call(message.fixed_array_32) : message.fixed_array_32;
                    return object;
                };
    
                /**
                 * Converts this TestFixedArrays to JSON.
                 * @function toJSON
                 * @memberof exonum.tests.TestFixedArrays
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                TestFixedArrays.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return TestFixedArrays;
            })();
    
            return tests;
        })();
    
        exonum.proof = (function() {
    
            /**
             * Namespace proof.
             * @memberof exonum
             * @namespace
             */
            var proof = {};
    
            proof.ListProof = (function() {
    
                /**
                 * Properties of a ListProof.
                 * @memberof exonum.proof
                 * @interface IListProof
                 * @property {Array.<exonum.proof.IHashedEntry>|null} [proof] ListProof proof
                 * @property {Array.<exonum.proof.IListProofEntry>|null} [entries] ListProof entries
                 * @property {number|Long|null} [length] ListProof length
                 */
    
                /**
                 * Constructs a new ListProof.
                 * @memberof exonum.proof
                 * @classdesc Represents a ListProof.
                 * @implements IListProof
                 * @constructor
                 * @param {exonum.proof.IListProof=} [properties] Properties to set
                 */
                function ListProof(properties) {
                    this.proof = [];
                    this.entries = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ListProof proof.
                 * @member {Array.<exonum.proof.IHashedEntry>} proof
                 * @memberof exonum.proof.ListProof
                 * @instance
                 */
                ListProof.prototype.proof = $util.emptyArray;
    
                /**
                 * ListProof entries.
                 * @member {Array.<exonum.proof.IListProofEntry>} entries
                 * @memberof exonum.proof.ListProof
                 * @instance
                 */
                ListProof.prototype.entries = $util.emptyArray;
    
                /**
                 * ListProof length.
                 * @member {number|Long} length
                 * @memberof exonum.proof.ListProof
                 * @instance
                 */
                ListProof.prototype.length = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * Creates a new ListProof instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {exonum.proof.IListProof=} [properties] Properties to set
                 * @returns {exonum.proof.ListProof} ListProof instance
                 */
                ListProof.create = function create(properties) {
                    return new ListProof(properties);
                };
    
                /**
                 * Encodes the specified ListProof message. Does not implicitly {@link exonum.proof.ListProof.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {exonum.proof.IListProof} message ListProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ListProof.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.proof != null && message.proof.length)
                        for (var i = 0; i < message.proof.length; ++i)
                            $root.exonum.proof.HashedEntry.encode(message.proof[i], writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.entries != null && message.entries.length)
                        for (var i = 0; i < message.entries.length; ++i)
                            $root.exonum.proof.ListProofEntry.encode(message.entries[i], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    if (message.length != null && message.hasOwnProperty("length"))
                        writer.uint32(/* id 3, wireType 0 =*/24).uint64(message.length);
                    return writer;
                };
    
                /**
                 * Encodes the specified ListProof message, length delimited. Does not implicitly {@link exonum.proof.ListProof.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {exonum.proof.IListProof} message ListProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ListProof.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a ListProof message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.ListProof} ListProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ListProof.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.ListProof();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            if (!(message.proof && message.proof.length))
                                message.proof = [];
                            message.proof.push($root.exonum.proof.HashedEntry.decode(reader, reader.uint32()));
                            break;
                        case 2:
                            if (!(message.entries && message.entries.length))
                                message.entries = [];
                            message.entries.push($root.exonum.proof.ListProofEntry.decode(reader, reader.uint32()));
                            break;
                        case 3:
                            message.length = reader.uint64();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a ListProof message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.ListProof} ListProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ListProof.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a ListProof message.
                 * @function verify
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ListProof.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.proof != null && message.hasOwnProperty("proof")) {
                        if (!Array.isArray(message.proof))
                            return "proof: array expected";
                        for (var i = 0; i < message.proof.length; ++i) {
                            var error = $root.exonum.proof.HashedEntry.verify(message.proof[i]);
                            if (error)
                                return "proof." + error;
                        }
                    }
                    if (message.entries != null && message.hasOwnProperty("entries")) {
                        if (!Array.isArray(message.entries))
                            return "entries: array expected";
                        for (var i = 0; i < message.entries.length; ++i) {
                            var error = $root.exonum.proof.ListProofEntry.verify(message.entries[i]);
                            if (error)
                                return "entries." + error;
                        }
                    }
                    if (message.length != null && message.hasOwnProperty("length"))
                        if (!$util.isInteger(message.length) && !(message.length && $util.isInteger(message.length.low) && $util.isInteger(message.length.high)))
                            return "length: integer|Long expected";
                    return null;
                };
    
                /**
                 * Creates a ListProof message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.ListProof} ListProof
                 */
                ListProof.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.ListProof)
                        return object;
                    var message = new $root.exonum.proof.ListProof();
                    if (object.proof) {
                        if (!Array.isArray(object.proof))
                            throw TypeError(".exonum.proof.ListProof.proof: array expected");
                        message.proof = [];
                        for (var i = 0; i < object.proof.length; ++i) {
                            if (typeof object.proof[i] !== "object")
                                throw TypeError(".exonum.proof.ListProof.proof: object expected");
                            message.proof[i] = $root.exonum.proof.HashedEntry.fromObject(object.proof[i]);
                        }
                    }
                    if (object.entries) {
                        if (!Array.isArray(object.entries))
                            throw TypeError(".exonum.proof.ListProof.entries: array expected");
                        message.entries = [];
                        for (var i = 0; i < object.entries.length; ++i) {
                            if (typeof object.entries[i] !== "object")
                                throw TypeError(".exonum.proof.ListProof.entries: object expected");
                            message.entries[i] = $root.exonum.proof.ListProofEntry.fromObject(object.entries[i]);
                        }
                    }
                    if (object.length != null)
                        if ($util.Long)
                            (message.length = $util.Long.fromValue(object.length)).unsigned = true;
                        else if (typeof object.length === "string")
                            message.length = parseInt(object.length, 10);
                        else if (typeof object.length === "number")
                            message.length = object.length;
                        else if (typeof object.length === "object")
                            message.length = new $util.LongBits(object.length.low >>> 0, object.length.high >>> 0).toNumber(true);
                    return message;
                };
    
                /**
                 * Creates a plain object from a ListProof message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.ListProof
                 * @static
                 * @param {exonum.proof.ListProof} message ListProof
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ListProof.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults) {
                        object.proof = [];
                        object.entries = [];
                    }
                    if (options.defaults)
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.length = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.length = options.longs === String ? "0" : 0;
                    if (message.proof && message.proof.length) {
                        object.proof = [];
                        for (var j = 0; j < message.proof.length; ++j)
                            object.proof[j] = $root.exonum.proof.HashedEntry.toObject(message.proof[j], options);
                    }
                    if (message.entries && message.entries.length) {
                        object.entries = [];
                        for (var j = 0; j < message.entries.length; ++j)
                            object.entries[j] = $root.exonum.proof.ListProofEntry.toObject(message.entries[j], options);
                    }
                    if (message.length != null && message.hasOwnProperty("length"))
                        if (typeof message.length === "number")
                            object.length = options.longs === String ? String(message.length) : message.length;
                        else
                            object.length = options.longs === String ? $util.Long.prototype.toString.call(message.length) : options.longs === Number ? new $util.LongBits(message.length.low >>> 0, message.length.high >>> 0).toNumber(true) : message.length;
                    return object;
                };
    
                /**
                 * Converts this ListProof to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.ListProof
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ListProof.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ListProof;
            })();
    
            proof.HashedEntry = (function() {
    
                /**
                 * Properties of a HashedEntry.
                 * @memberof exonum.proof
                 * @interface IHashedEntry
                 * @property {exonum.proof.IProofListKey|null} [key] HashedEntry key
                 * @property {exonum.crypto.IHash|null} [hash] HashedEntry hash
                 */
    
                /**
                 * Constructs a new HashedEntry.
                 * @memberof exonum.proof
                 * @classdesc Represents a HashedEntry.
                 * @implements IHashedEntry
                 * @constructor
                 * @param {exonum.proof.IHashedEntry=} [properties] Properties to set
                 */
                function HashedEntry(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * HashedEntry key.
                 * @member {exonum.proof.IProofListKey|null|undefined} key
                 * @memberof exonum.proof.HashedEntry
                 * @instance
                 */
                HashedEntry.prototype.key = null;
    
                /**
                 * HashedEntry hash.
                 * @member {exonum.crypto.IHash|null|undefined} hash
                 * @memberof exonum.proof.HashedEntry
                 * @instance
                 */
                HashedEntry.prototype.hash = null;
    
                /**
                 * Creates a new HashedEntry instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {exonum.proof.IHashedEntry=} [properties] Properties to set
                 * @returns {exonum.proof.HashedEntry} HashedEntry instance
                 */
                HashedEntry.create = function create(properties) {
                    return new HashedEntry(properties);
                };
    
                /**
                 * Encodes the specified HashedEntry message. Does not implicitly {@link exonum.proof.HashedEntry.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {exonum.proof.IHashedEntry} message HashedEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                HashedEntry.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.key != null && message.hasOwnProperty("key"))
                        $root.exonum.proof.ProofListKey.encode(message.key, writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.hash != null && message.hasOwnProperty("hash"))
                        $root.exonum.crypto.Hash.encode(message.hash, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified HashedEntry message, length delimited. Does not implicitly {@link exonum.proof.HashedEntry.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {exonum.proof.IHashedEntry} message HashedEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                HashedEntry.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a HashedEntry message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.HashedEntry} HashedEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                HashedEntry.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.HashedEntry();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.key = $root.exonum.proof.ProofListKey.decode(reader, reader.uint32());
                            break;
                        case 2:
                            message.hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a HashedEntry message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.HashedEntry} HashedEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                HashedEntry.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a HashedEntry message.
                 * @function verify
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                HashedEntry.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.key != null && message.hasOwnProperty("key")) {
                        var error = $root.exonum.proof.ProofListKey.verify(message.key);
                        if (error)
                            return "key." + error;
                    }
                    if (message.hash != null && message.hasOwnProperty("hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.hash);
                        if (error)
                            return "hash." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a HashedEntry message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.HashedEntry} HashedEntry
                 */
                HashedEntry.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.HashedEntry)
                        return object;
                    var message = new $root.exonum.proof.HashedEntry();
                    if (object.key != null) {
                        if (typeof object.key !== "object")
                            throw TypeError(".exonum.proof.HashedEntry.key: object expected");
                        message.key = $root.exonum.proof.ProofListKey.fromObject(object.key);
                    }
                    if (object.hash != null) {
                        if (typeof object.hash !== "object")
                            throw TypeError(".exonum.proof.HashedEntry.hash: object expected");
                        message.hash = $root.exonum.crypto.Hash.fromObject(object.hash);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a HashedEntry message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.HashedEntry
                 * @static
                 * @param {exonum.proof.HashedEntry} message HashedEntry
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                HashedEntry.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        object.key = null;
                        object.hash = null;
                    }
                    if (message.key != null && message.hasOwnProperty("key"))
                        object.key = $root.exonum.proof.ProofListKey.toObject(message.key, options);
                    if (message.hash != null && message.hasOwnProperty("hash"))
                        object.hash = $root.exonum.crypto.Hash.toObject(message.hash, options);
                    return object;
                };
    
                /**
                 * Converts this HashedEntry to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.HashedEntry
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                HashedEntry.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return HashedEntry;
            })();
    
            proof.ListProofEntry = (function() {
    
                /**
                 * Properties of a ListProofEntry.
                 * @memberof exonum.proof
                 * @interface IListProofEntry
                 * @property {number|Long|null} [index] ListProofEntry index
                 * @property {Uint8Array|null} [value] ListProofEntry value
                 */
    
                /**
                 * Constructs a new ListProofEntry.
                 * @memberof exonum.proof
                 * @classdesc Represents a ListProofEntry.
                 * @implements IListProofEntry
                 * @constructor
                 * @param {exonum.proof.IListProofEntry=} [properties] Properties to set
                 */
                function ListProofEntry(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ListProofEntry index.
                 * @member {number|Long} index
                 * @memberof exonum.proof.ListProofEntry
                 * @instance
                 */
                ListProofEntry.prototype.index = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * ListProofEntry value.
                 * @member {Uint8Array} value
                 * @memberof exonum.proof.ListProofEntry
                 * @instance
                 */
                ListProofEntry.prototype.value = $util.newBuffer([]);
    
                /**
                 * Creates a new ListProofEntry instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {exonum.proof.IListProofEntry=} [properties] Properties to set
                 * @returns {exonum.proof.ListProofEntry} ListProofEntry instance
                 */
                ListProofEntry.create = function create(properties) {
                    return new ListProofEntry(properties);
                };
    
                /**
                 * Encodes the specified ListProofEntry message. Does not implicitly {@link exonum.proof.ListProofEntry.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {exonum.proof.IListProofEntry} message ListProofEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ListProofEntry.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.index != null && message.hasOwnProperty("index"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint64(message.index);
                    if (message.value != null && message.hasOwnProperty("value"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.value);
                    return writer;
                };
    
                /**
                 * Encodes the specified ListProofEntry message, length delimited. Does not implicitly {@link exonum.proof.ListProofEntry.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {exonum.proof.IListProofEntry} message ListProofEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ListProofEntry.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a ListProofEntry message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.ListProofEntry} ListProofEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ListProofEntry.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.ListProofEntry();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.index = reader.uint64();
                            break;
                        case 2:
                            message.value = reader.bytes();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a ListProofEntry message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.ListProofEntry} ListProofEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ListProofEntry.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a ListProofEntry message.
                 * @function verify
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ListProofEntry.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.index != null && message.hasOwnProperty("index"))
                        if (!$util.isInteger(message.index) && !(message.index && $util.isInteger(message.index.low) && $util.isInteger(message.index.high)))
                            return "index: integer|Long expected";
                    if (message.value != null && message.hasOwnProperty("value"))
                        if (!(message.value && typeof message.value.length === "number" || $util.isString(message.value)))
                            return "value: buffer expected";
                    return null;
                };
    
                /**
                 * Creates a ListProofEntry message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.ListProofEntry} ListProofEntry
                 */
                ListProofEntry.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.ListProofEntry)
                        return object;
                    var message = new $root.exonum.proof.ListProofEntry();
                    if (object.index != null)
                        if ($util.Long)
                            (message.index = $util.Long.fromValue(object.index)).unsigned = true;
                        else if (typeof object.index === "string")
                            message.index = parseInt(object.index, 10);
                        else if (typeof object.index === "number")
                            message.index = object.index;
                        else if (typeof object.index === "object")
                            message.index = new $util.LongBits(object.index.low >>> 0, object.index.high >>> 0).toNumber(true);
                    if (object.value != null)
                        if (typeof object.value === "string")
                            $util.base64.decode(object.value, message.value = $util.newBuffer($util.base64.length(object.value)), 0);
                        else if (object.value.length)
                            message.value = object.value;
                    return message;
                };
    
                /**
                 * Creates a plain object from a ListProofEntry message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.ListProofEntry
                 * @static
                 * @param {exonum.proof.ListProofEntry} message ListProofEntry
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ListProofEntry.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.index = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.index = options.longs === String ? "0" : 0;
                        if (options.bytes === String)
                            object.value = "";
                        else {
                            object.value = [];
                            if (options.bytes !== Array)
                                object.value = $util.newBuffer(object.value);
                        }
                    }
                    if (message.index != null && message.hasOwnProperty("index"))
                        if (typeof message.index === "number")
                            object.index = options.longs === String ? String(message.index) : message.index;
                        else
                            object.index = options.longs === String ? $util.Long.prototype.toString.call(message.index) : options.longs === Number ? new $util.LongBits(message.index.low >>> 0, message.index.high >>> 0).toNumber(true) : message.index;
                    if (message.value != null && message.hasOwnProperty("value"))
                        object.value = options.bytes === String ? $util.base64.encode(message.value, 0, message.value.length) : options.bytes === Array ? Array.prototype.slice.call(message.value) : message.value;
                    return object;
                };
    
                /**
                 * Converts this ListProofEntry to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.ListProofEntry
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ListProofEntry.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ListProofEntry;
            })();
    
            proof.ProofListKey = (function() {
    
                /**
                 * Properties of a ProofListKey.
                 * @memberof exonum.proof
                 * @interface IProofListKey
                 * @property {number|Long|null} [index] ProofListKey index
                 * @property {number|null} [height] ProofListKey height
                 */
    
                /**
                 * Constructs a new ProofListKey.
                 * @memberof exonum.proof
                 * @classdesc Represents a ProofListKey.
                 * @implements IProofListKey
                 * @constructor
                 * @param {exonum.proof.IProofListKey=} [properties] Properties to set
                 */
                function ProofListKey(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * ProofListKey index.
                 * @member {number|Long} index
                 * @memberof exonum.proof.ProofListKey
                 * @instance
                 */
                ProofListKey.prototype.index = $util.Long ? $util.Long.fromBits(0,0,true) : 0;
    
                /**
                 * ProofListKey height.
                 * @member {number} height
                 * @memberof exonum.proof.ProofListKey
                 * @instance
                 */
                ProofListKey.prototype.height = 0;
    
                /**
                 * Creates a new ProofListKey instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {exonum.proof.IProofListKey=} [properties] Properties to set
                 * @returns {exonum.proof.ProofListKey} ProofListKey instance
                 */
                ProofListKey.create = function create(properties) {
                    return new ProofListKey(properties);
                };
    
                /**
                 * Encodes the specified ProofListKey message. Does not implicitly {@link exonum.proof.ProofListKey.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {exonum.proof.IProofListKey} message ProofListKey message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ProofListKey.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.index != null && message.hasOwnProperty("index"))
                        writer.uint32(/* id 1, wireType 0 =*/8).uint64(message.index);
                    if (message.height != null && message.hasOwnProperty("height"))
                        writer.uint32(/* id 2, wireType 0 =*/16).uint32(message.height);
                    return writer;
                };
    
                /**
                 * Encodes the specified ProofListKey message, length delimited. Does not implicitly {@link exonum.proof.ProofListKey.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {exonum.proof.IProofListKey} message ProofListKey message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                ProofListKey.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a ProofListKey message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.ProofListKey} ProofListKey
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ProofListKey.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.ProofListKey();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.index = reader.uint64();
                            break;
                        case 2:
                            message.height = reader.uint32();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a ProofListKey message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.ProofListKey} ProofListKey
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                ProofListKey.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a ProofListKey message.
                 * @function verify
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                ProofListKey.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.index != null && message.hasOwnProperty("index"))
                        if (!$util.isInteger(message.index) && !(message.index && $util.isInteger(message.index.low) && $util.isInteger(message.index.high)))
                            return "index: integer|Long expected";
                    if (message.height != null && message.hasOwnProperty("height"))
                        if (!$util.isInteger(message.height))
                            return "height: integer expected";
                    return null;
                };
    
                /**
                 * Creates a ProofListKey message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.ProofListKey} ProofListKey
                 */
                ProofListKey.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.ProofListKey)
                        return object;
                    var message = new $root.exonum.proof.ProofListKey();
                    if (object.index != null)
                        if ($util.Long)
                            (message.index = $util.Long.fromValue(object.index)).unsigned = true;
                        else if (typeof object.index === "string")
                            message.index = parseInt(object.index, 10);
                        else if (typeof object.index === "number")
                            message.index = object.index;
                        else if (typeof object.index === "object")
                            message.index = new $util.LongBits(object.index.low >>> 0, object.index.high >>> 0).toNumber(true);
                    if (object.height != null)
                        message.height = object.height >>> 0;
                    return message;
                };
    
                /**
                 * Creates a plain object from a ProofListKey message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.ProofListKey
                 * @static
                 * @param {exonum.proof.ProofListKey} message ProofListKey
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                ProofListKey.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, true);
                            object.index = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.index = options.longs === String ? "0" : 0;
                        object.height = 0;
                    }
                    if (message.index != null && message.hasOwnProperty("index"))
                        if (typeof message.index === "number")
                            object.index = options.longs === String ? String(message.index) : message.index;
                        else
                            object.index = options.longs === String ? $util.Long.prototype.toString.call(message.index) : options.longs === Number ? new $util.LongBits(message.index.low >>> 0, message.index.high >>> 0).toNumber(true) : message.index;
                    if (message.height != null && message.hasOwnProperty("height"))
                        object.height = message.height;
                    return object;
                };
    
                /**
                 * Converts this ProofListKey to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.ProofListKey
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                ProofListKey.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return ProofListKey;
            })();
    
            proof.MapProof = (function() {
    
                /**
                 * Properties of a MapProof.
                 * @memberof exonum.proof
                 * @interface IMapProof
                 * @property {Array.<exonum.proof.IOptionalEntry>|null} [entries] MapProof entries
                 * @property {Array.<exonum.proof.IMapProofEntry>|null} [proof] MapProof proof
                 */
    
                /**
                 * Constructs a new MapProof.
                 * @memberof exonum.proof
                 * @classdesc Represents a MapProof.
                 * @implements IMapProof
                 * @constructor
                 * @param {exonum.proof.IMapProof=} [properties] Properties to set
                 */
                function MapProof(properties) {
                    this.entries = [];
                    this.proof = [];
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * MapProof entries.
                 * @member {Array.<exonum.proof.IOptionalEntry>} entries
                 * @memberof exonum.proof.MapProof
                 * @instance
                 */
                MapProof.prototype.entries = $util.emptyArray;
    
                /**
                 * MapProof proof.
                 * @member {Array.<exonum.proof.IMapProofEntry>} proof
                 * @memberof exonum.proof.MapProof
                 * @instance
                 */
                MapProof.prototype.proof = $util.emptyArray;
    
                /**
                 * Creates a new MapProof instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {exonum.proof.IMapProof=} [properties] Properties to set
                 * @returns {exonum.proof.MapProof} MapProof instance
                 */
                MapProof.create = function create(properties) {
                    return new MapProof(properties);
                };
    
                /**
                 * Encodes the specified MapProof message. Does not implicitly {@link exonum.proof.MapProof.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {exonum.proof.IMapProof} message MapProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                MapProof.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.entries != null && message.entries.length)
                        for (var i = 0; i < message.entries.length; ++i)
                            $root.exonum.proof.OptionalEntry.encode(message.entries[i], writer.uint32(/* id 1, wireType 2 =*/10).fork()).ldelim();
                    if (message.proof != null && message.proof.length)
                        for (var i = 0; i < message.proof.length; ++i)
                            $root.exonum.proof.MapProofEntry.encode(message.proof[i], writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified MapProof message, length delimited. Does not implicitly {@link exonum.proof.MapProof.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {exonum.proof.IMapProof} message MapProof message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                MapProof.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a MapProof message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.MapProof} MapProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                MapProof.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.MapProof();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            if (!(message.entries && message.entries.length))
                                message.entries = [];
                            message.entries.push($root.exonum.proof.OptionalEntry.decode(reader, reader.uint32()));
                            break;
                        case 2:
                            if (!(message.proof && message.proof.length))
                                message.proof = [];
                            message.proof.push($root.exonum.proof.MapProofEntry.decode(reader, reader.uint32()));
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a MapProof message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.MapProof} MapProof
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                MapProof.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a MapProof message.
                 * @function verify
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                MapProof.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.entries != null && message.hasOwnProperty("entries")) {
                        if (!Array.isArray(message.entries))
                            return "entries: array expected";
                        for (var i = 0; i < message.entries.length; ++i) {
                            var error = $root.exonum.proof.OptionalEntry.verify(message.entries[i]);
                            if (error)
                                return "entries." + error;
                        }
                    }
                    if (message.proof != null && message.hasOwnProperty("proof")) {
                        if (!Array.isArray(message.proof))
                            return "proof: array expected";
                        for (var i = 0; i < message.proof.length; ++i) {
                            var error = $root.exonum.proof.MapProofEntry.verify(message.proof[i]);
                            if (error)
                                return "proof." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates a MapProof message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.MapProof} MapProof
                 */
                MapProof.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.MapProof)
                        return object;
                    var message = new $root.exonum.proof.MapProof();
                    if (object.entries) {
                        if (!Array.isArray(object.entries))
                            throw TypeError(".exonum.proof.MapProof.entries: array expected");
                        message.entries = [];
                        for (var i = 0; i < object.entries.length; ++i) {
                            if (typeof object.entries[i] !== "object")
                                throw TypeError(".exonum.proof.MapProof.entries: object expected");
                            message.entries[i] = $root.exonum.proof.OptionalEntry.fromObject(object.entries[i]);
                        }
                    }
                    if (object.proof) {
                        if (!Array.isArray(object.proof))
                            throw TypeError(".exonum.proof.MapProof.proof: array expected");
                        message.proof = [];
                        for (var i = 0; i < object.proof.length; ++i) {
                            if (typeof object.proof[i] !== "object")
                                throw TypeError(".exonum.proof.MapProof.proof: object expected");
                            message.proof[i] = $root.exonum.proof.MapProofEntry.fromObject(object.proof[i]);
                        }
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a MapProof message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.MapProof
                 * @static
                 * @param {exonum.proof.MapProof} message MapProof
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                MapProof.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.arrays || options.defaults) {
                        object.entries = [];
                        object.proof = [];
                    }
                    if (message.entries && message.entries.length) {
                        object.entries = [];
                        for (var j = 0; j < message.entries.length; ++j)
                            object.entries[j] = $root.exonum.proof.OptionalEntry.toObject(message.entries[j], options);
                    }
                    if (message.proof && message.proof.length) {
                        object.proof = [];
                        for (var j = 0; j < message.proof.length; ++j)
                            object.proof[j] = $root.exonum.proof.MapProofEntry.toObject(message.proof[j], options);
                    }
                    return object;
                };
    
                /**
                 * Converts this MapProof to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.MapProof
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                MapProof.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return MapProof;
            })();
    
            proof.OptionalEntry = (function() {
    
                /**
                 * Properties of an OptionalEntry.
                 * @memberof exonum.proof
                 * @interface IOptionalEntry
                 * @property {Uint8Array|null} [key] OptionalEntry key
                 * @property {Uint8Array|null} [value] OptionalEntry value
                 * @property {google.protobuf.IEmpty|null} [no_value] OptionalEntry no_value
                 */
    
                /**
                 * Constructs a new OptionalEntry.
                 * @memberof exonum.proof
                 * @classdesc Represents an OptionalEntry.
                 * @implements IOptionalEntry
                 * @constructor
                 * @param {exonum.proof.IOptionalEntry=} [properties] Properties to set
                 */
                function OptionalEntry(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * OptionalEntry key.
                 * @member {Uint8Array} key
                 * @memberof exonum.proof.OptionalEntry
                 * @instance
                 */
                OptionalEntry.prototype.key = $util.newBuffer([]);
    
                /**
                 * OptionalEntry value.
                 * @member {Uint8Array} value
                 * @memberof exonum.proof.OptionalEntry
                 * @instance
                 */
                OptionalEntry.prototype.value = $util.newBuffer([]);
    
                /**
                 * OptionalEntry no_value.
                 * @member {google.protobuf.IEmpty|null|undefined} no_value
                 * @memberof exonum.proof.OptionalEntry
                 * @instance
                 */
                OptionalEntry.prototype.no_value = null;
    
                // OneOf field names bound to virtual getters and setters
                var $oneOfFields;
    
                /**
                 * OptionalEntry maybe_value.
                 * @member {"value"|"no_value"|undefined} maybe_value
                 * @memberof exonum.proof.OptionalEntry
                 * @instance
                 */
                Object.defineProperty(OptionalEntry.prototype, "maybe_value", {
                    get: $util.oneOfGetter($oneOfFields = ["value", "no_value"]),
                    set: $util.oneOfSetter($oneOfFields)
                });
    
                /**
                 * Creates a new OptionalEntry instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {exonum.proof.IOptionalEntry=} [properties] Properties to set
                 * @returns {exonum.proof.OptionalEntry} OptionalEntry instance
                 */
                OptionalEntry.create = function create(properties) {
                    return new OptionalEntry(properties);
                };
    
                /**
                 * Encodes the specified OptionalEntry message. Does not implicitly {@link exonum.proof.OptionalEntry.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {exonum.proof.IOptionalEntry} message OptionalEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                OptionalEntry.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.key != null && message.hasOwnProperty("key"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.key);
                    if (message.value != null && message.hasOwnProperty("value"))
                        writer.uint32(/* id 2, wireType 2 =*/18).bytes(message.value);
                    if (message.no_value != null && message.hasOwnProperty("no_value"))
                        $root.google.protobuf.Empty.encode(message.no_value, writer.uint32(/* id 3, wireType 2 =*/26).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified OptionalEntry message, length delimited. Does not implicitly {@link exonum.proof.OptionalEntry.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {exonum.proof.IOptionalEntry} message OptionalEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                OptionalEntry.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an OptionalEntry message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.OptionalEntry} OptionalEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                OptionalEntry.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.OptionalEntry();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.key = reader.bytes();
                            break;
                        case 2:
                            message.value = reader.bytes();
                            break;
                        case 3:
                            message.no_value = $root.google.protobuf.Empty.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an OptionalEntry message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.OptionalEntry} OptionalEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                OptionalEntry.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an OptionalEntry message.
                 * @function verify
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                OptionalEntry.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    var properties = {};
                    if (message.key != null && message.hasOwnProperty("key"))
                        if (!(message.key && typeof message.key.length === "number" || $util.isString(message.key)))
                            return "key: buffer expected";
                    if (message.value != null && message.hasOwnProperty("value")) {
                        properties.maybe_value = 1;
                        if (!(message.value && typeof message.value.length === "number" || $util.isString(message.value)))
                            return "value: buffer expected";
                    }
                    if (message.no_value != null && message.hasOwnProperty("no_value")) {
                        if (properties.maybe_value === 1)
                            return "maybe_value: multiple values";
                        properties.maybe_value = 1;
                        {
                            var error = $root.google.protobuf.Empty.verify(message.no_value);
                            if (error)
                                return "no_value." + error;
                        }
                    }
                    return null;
                };
    
                /**
                 * Creates an OptionalEntry message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.OptionalEntry} OptionalEntry
                 */
                OptionalEntry.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.OptionalEntry)
                        return object;
                    var message = new $root.exonum.proof.OptionalEntry();
                    if (object.key != null)
                        if (typeof object.key === "string")
                            $util.base64.decode(object.key, message.key = $util.newBuffer($util.base64.length(object.key)), 0);
                        else if (object.key.length)
                            message.key = object.key;
                    if (object.value != null)
                        if (typeof object.value === "string")
                            $util.base64.decode(object.value, message.value = $util.newBuffer($util.base64.length(object.value)), 0);
                        else if (object.value.length)
                            message.value = object.value;
                    if (object.no_value != null) {
                        if (typeof object.no_value !== "object")
                            throw TypeError(".exonum.proof.OptionalEntry.no_value: object expected");
                        message.no_value = $root.google.protobuf.Empty.fromObject(object.no_value);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from an OptionalEntry message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.OptionalEntry
                 * @static
                 * @param {exonum.proof.OptionalEntry} message OptionalEntry
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                OptionalEntry.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults)
                        if (options.bytes === String)
                            object.key = "";
                        else {
                            object.key = [];
                            if (options.bytes !== Array)
                                object.key = $util.newBuffer(object.key);
                        }
                    if (message.key != null && message.hasOwnProperty("key"))
                        object.key = options.bytes === String ? $util.base64.encode(message.key, 0, message.key.length) : options.bytes === Array ? Array.prototype.slice.call(message.key) : message.key;
                    if (message.value != null && message.hasOwnProperty("value")) {
                        object.value = options.bytes === String ? $util.base64.encode(message.value, 0, message.value.length) : options.bytes === Array ? Array.prototype.slice.call(message.value) : message.value;
                        if (options.oneofs)
                            object.maybe_value = "value";
                    }
                    if (message.no_value != null && message.hasOwnProperty("no_value")) {
                        object.no_value = $root.google.protobuf.Empty.toObject(message.no_value, options);
                        if (options.oneofs)
                            object.maybe_value = "no_value";
                    }
                    return object;
                };
    
                /**
                 * Converts this OptionalEntry to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.OptionalEntry
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                OptionalEntry.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return OptionalEntry;
            })();
    
            proof.MapProofEntry = (function() {
    
                /**
                 * Properties of a MapProofEntry.
                 * @memberof exonum.proof
                 * @interface IMapProofEntry
                 * @property {Uint8Array|null} [proof_path] MapProofEntry proof_path
                 * @property {exonum.crypto.IHash|null} [hash] MapProofEntry hash
                 */
    
                /**
                 * Constructs a new MapProofEntry.
                 * @memberof exonum.proof
                 * @classdesc Represents a MapProofEntry.
                 * @implements IMapProofEntry
                 * @constructor
                 * @param {exonum.proof.IMapProofEntry=} [properties] Properties to set
                 */
                function MapProofEntry(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * MapProofEntry proof_path.
                 * @member {Uint8Array} proof_path
                 * @memberof exonum.proof.MapProofEntry
                 * @instance
                 */
                MapProofEntry.prototype.proof_path = $util.newBuffer([]);
    
                /**
                 * MapProofEntry hash.
                 * @member {exonum.crypto.IHash|null|undefined} hash
                 * @memberof exonum.proof.MapProofEntry
                 * @instance
                 */
                MapProofEntry.prototype.hash = null;
    
                /**
                 * Creates a new MapProofEntry instance using the specified properties.
                 * @function create
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {exonum.proof.IMapProofEntry=} [properties] Properties to set
                 * @returns {exonum.proof.MapProofEntry} MapProofEntry instance
                 */
                MapProofEntry.create = function create(properties) {
                    return new MapProofEntry(properties);
                };
    
                /**
                 * Encodes the specified MapProofEntry message. Does not implicitly {@link exonum.proof.MapProofEntry.verify|verify} messages.
                 * @function encode
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {exonum.proof.IMapProofEntry} message MapProofEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                MapProofEntry.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.proof_path != null && message.hasOwnProperty("proof_path"))
                        writer.uint32(/* id 1, wireType 2 =*/10).bytes(message.proof_path);
                    if (message.hash != null && message.hasOwnProperty("hash"))
                        $root.exonum.crypto.Hash.encode(message.hash, writer.uint32(/* id 2, wireType 2 =*/18).fork()).ldelim();
                    return writer;
                };
    
                /**
                 * Encodes the specified MapProofEntry message, length delimited. Does not implicitly {@link exonum.proof.MapProofEntry.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {exonum.proof.IMapProofEntry} message MapProofEntry message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                MapProofEntry.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a MapProofEntry message from the specified reader or buffer.
                 * @function decode
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {exonum.proof.MapProofEntry} MapProofEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                MapProofEntry.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.exonum.proof.MapProofEntry();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.proof_path = reader.bytes();
                            break;
                        case 2:
                            message.hash = $root.exonum.crypto.Hash.decode(reader, reader.uint32());
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a MapProofEntry message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {exonum.proof.MapProofEntry} MapProofEntry
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                MapProofEntry.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a MapProofEntry message.
                 * @function verify
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                MapProofEntry.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.proof_path != null && message.hasOwnProperty("proof_path"))
                        if (!(message.proof_path && typeof message.proof_path.length === "number" || $util.isString(message.proof_path)))
                            return "proof_path: buffer expected";
                    if (message.hash != null && message.hasOwnProperty("hash")) {
                        var error = $root.exonum.crypto.Hash.verify(message.hash);
                        if (error)
                            return "hash." + error;
                    }
                    return null;
                };
    
                /**
                 * Creates a MapProofEntry message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {exonum.proof.MapProofEntry} MapProofEntry
                 */
                MapProofEntry.fromObject = function fromObject(object) {
                    if (object instanceof $root.exonum.proof.MapProofEntry)
                        return object;
                    var message = new $root.exonum.proof.MapProofEntry();
                    if (object.proof_path != null)
                        if (typeof object.proof_path === "string")
                            $util.base64.decode(object.proof_path, message.proof_path = $util.newBuffer($util.base64.length(object.proof_path)), 0);
                        else if (object.proof_path.length)
                            message.proof_path = object.proof_path;
                    if (object.hash != null) {
                        if (typeof object.hash !== "object")
                            throw TypeError(".exonum.proof.MapProofEntry.hash: object expected");
                        message.hash = $root.exonum.crypto.Hash.fromObject(object.hash);
                    }
                    return message;
                };
    
                /**
                 * Creates a plain object from a MapProofEntry message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof exonum.proof.MapProofEntry
                 * @static
                 * @param {exonum.proof.MapProofEntry} message MapProofEntry
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                MapProofEntry.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if (options.bytes === String)
                            object.proof_path = "";
                        else {
                            object.proof_path = [];
                            if (options.bytes !== Array)
                                object.proof_path = $util.newBuffer(object.proof_path);
                        }
                        object.hash = null;
                    }
                    if (message.proof_path != null && message.hasOwnProperty("proof_path"))
                        object.proof_path = options.bytes === String ? $util.base64.encode(message.proof_path, 0, message.proof_path.length) : options.bytes === Array ? Array.prototype.slice.call(message.proof_path) : message.proof_path;
                    if (message.hash != null && message.hasOwnProperty("hash"))
                        object.hash = $root.exonum.crypto.Hash.toObject(message.hash, options);
                    return object;
                };
    
                /**
                 * Converts this MapProofEntry to JSON.
                 * @function toJSON
                 * @memberof exonum.proof.MapProofEntry
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                MapProofEntry.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return MapProofEntry;
            })();
    
            return proof;
        })();
    
        return exonum;
    })();
    
    $root.google = (function() {
    
        /**
         * Namespace google.
         * @exports google
         * @namespace
         */
        var google = {};
    
        google.protobuf = (function() {
    
            /**
             * Namespace protobuf.
             * @memberof google
             * @namespace
             */
            var protobuf = {};
    
            protobuf.Timestamp = (function() {
    
                /**
                 * Properties of a Timestamp.
                 * @memberof google.protobuf
                 * @interface ITimestamp
                 * @property {number|Long|null} [seconds] Timestamp seconds
                 * @property {number|null} [nanos] Timestamp nanos
                 */
    
                /**
                 * Constructs a new Timestamp.
                 * @memberof google.protobuf
                 * @classdesc Represents a Timestamp.
                 * @implements ITimestamp
                 * @constructor
                 * @param {google.protobuf.ITimestamp=} [properties] Properties to set
                 */
                function Timestamp(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Timestamp seconds.
                 * @member {number|Long} seconds
                 * @memberof google.protobuf.Timestamp
                 * @instance
                 */
                Timestamp.prototype.seconds = $util.Long ? $util.Long.fromBits(0,0,false) : 0;
    
                /**
                 * Timestamp nanos.
                 * @member {number} nanos
                 * @memberof google.protobuf.Timestamp
                 * @instance
                 */
                Timestamp.prototype.nanos = 0;
    
                /**
                 * Creates a new Timestamp instance using the specified properties.
                 * @function create
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {google.protobuf.ITimestamp=} [properties] Properties to set
                 * @returns {google.protobuf.Timestamp} Timestamp instance
                 */
                Timestamp.create = function create(properties) {
                    return new Timestamp(properties);
                };
    
                /**
                 * Encodes the specified Timestamp message. Does not implicitly {@link google.protobuf.Timestamp.verify|verify} messages.
                 * @function encode
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {google.protobuf.ITimestamp} message Timestamp message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Timestamp.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    if (message.seconds != null && message.hasOwnProperty("seconds"))
                        writer.uint32(/* id 1, wireType 0 =*/8).int64(message.seconds);
                    if (message.nanos != null && message.hasOwnProperty("nanos"))
                        writer.uint32(/* id 2, wireType 0 =*/16).int32(message.nanos);
                    return writer;
                };
    
                /**
                 * Encodes the specified Timestamp message, length delimited. Does not implicitly {@link google.protobuf.Timestamp.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {google.protobuf.ITimestamp} message Timestamp message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Timestamp.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes a Timestamp message from the specified reader or buffer.
                 * @function decode
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {google.protobuf.Timestamp} Timestamp
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Timestamp.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.google.protobuf.Timestamp();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        case 1:
                            message.seconds = reader.int64();
                            break;
                        case 2:
                            message.nanos = reader.int32();
                            break;
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes a Timestamp message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {google.protobuf.Timestamp} Timestamp
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Timestamp.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies a Timestamp message.
                 * @function verify
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Timestamp.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    if (message.seconds != null && message.hasOwnProperty("seconds"))
                        if (!$util.isInteger(message.seconds) && !(message.seconds && $util.isInteger(message.seconds.low) && $util.isInteger(message.seconds.high)))
                            return "seconds: integer|Long expected";
                    if (message.nanos != null && message.hasOwnProperty("nanos"))
                        if (!$util.isInteger(message.nanos))
                            return "nanos: integer expected";
                    return null;
                };
    
                /**
                 * Creates a Timestamp message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {google.protobuf.Timestamp} Timestamp
                 */
                Timestamp.fromObject = function fromObject(object) {
                    if (object instanceof $root.google.protobuf.Timestamp)
                        return object;
                    var message = new $root.google.protobuf.Timestamp();
                    if (object.seconds != null)
                        if ($util.Long)
                            (message.seconds = $util.Long.fromValue(object.seconds)).unsigned = false;
                        else if (typeof object.seconds === "string")
                            message.seconds = parseInt(object.seconds, 10);
                        else if (typeof object.seconds === "number")
                            message.seconds = object.seconds;
                        else if (typeof object.seconds === "object")
                            message.seconds = new $util.LongBits(object.seconds.low >>> 0, object.seconds.high >>> 0).toNumber();
                    if (object.nanos != null)
                        message.nanos = object.nanos | 0;
                    return message;
                };
    
                /**
                 * Creates a plain object from a Timestamp message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof google.protobuf.Timestamp
                 * @static
                 * @param {google.protobuf.Timestamp} message Timestamp
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Timestamp.toObject = function toObject(message, options) {
                    if (!options)
                        options = {};
                    var object = {};
                    if (options.defaults) {
                        if ($util.Long) {
                            var long = new $util.Long(0, 0, false);
                            object.seconds = options.longs === String ? long.toString() : options.longs === Number ? long.toNumber() : long;
                        } else
                            object.seconds = options.longs === String ? "0" : 0;
                        object.nanos = 0;
                    }
                    if (message.seconds != null && message.hasOwnProperty("seconds"))
                        if (typeof message.seconds === "number")
                            object.seconds = options.longs === String ? String(message.seconds) : message.seconds;
                        else
                            object.seconds = options.longs === String ? $util.Long.prototype.toString.call(message.seconds) : options.longs === Number ? new $util.LongBits(message.seconds.low >>> 0, message.seconds.high >>> 0).toNumber() : message.seconds;
                    if (message.nanos != null && message.hasOwnProperty("nanos"))
                        object.nanos = message.nanos;
                    return object;
                };
    
                /**
                 * Converts this Timestamp to JSON.
                 * @function toJSON
                 * @memberof google.protobuf.Timestamp
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Timestamp.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Timestamp;
            })();
    
            protobuf.Empty = (function() {
    
                /**
                 * Properties of an Empty.
                 * @memberof google.protobuf
                 * @interface IEmpty
                 */
    
                /**
                 * Constructs a new Empty.
                 * @memberof google.protobuf
                 * @classdesc Represents an Empty.
                 * @implements IEmpty
                 * @constructor
                 * @param {google.protobuf.IEmpty=} [properties] Properties to set
                 */
                function Empty(properties) {
                    if (properties)
                        for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i)
                            if (properties[keys[i]] != null)
                                this[keys[i]] = properties[keys[i]];
                }
    
                /**
                 * Creates a new Empty instance using the specified properties.
                 * @function create
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {google.protobuf.IEmpty=} [properties] Properties to set
                 * @returns {google.protobuf.Empty} Empty instance
                 */
                Empty.create = function create(properties) {
                    return new Empty(properties);
                };
    
                /**
                 * Encodes the specified Empty message. Does not implicitly {@link google.protobuf.Empty.verify|verify} messages.
                 * @function encode
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {google.protobuf.IEmpty} message Empty message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Empty.encode = function encode(message, writer) {
                    if (!writer)
                        writer = $Writer.create();
                    return writer;
                };
    
                /**
                 * Encodes the specified Empty message, length delimited. Does not implicitly {@link google.protobuf.Empty.verify|verify} messages.
                 * @function encodeDelimited
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {google.protobuf.IEmpty} message Empty message or plain object to encode
                 * @param {$protobuf.Writer} [writer] Writer to encode to
                 * @returns {$protobuf.Writer} Writer
                 */
                Empty.encodeDelimited = function encodeDelimited(message, writer) {
                    return this.encode(message, writer).ldelim();
                };
    
                /**
                 * Decodes an Empty message from the specified reader or buffer.
                 * @function decode
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @param {number} [length] Message length if known beforehand
                 * @returns {google.protobuf.Empty} Empty
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Empty.decode = function decode(reader, length) {
                    if (!(reader instanceof $Reader))
                        reader = $Reader.create(reader);
                    var end = length === undefined ? reader.len : reader.pos + length, message = new $root.google.protobuf.Empty();
                    while (reader.pos < end) {
                        var tag = reader.uint32();
                        switch (tag >>> 3) {
                        default:
                            reader.skipType(tag & 7);
                            break;
                        }
                    }
                    return message;
                };
    
                /**
                 * Decodes an Empty message from the specified reader or buffer, length delimited.
                 * @function decodeDelimited
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
                 * @returns {google.protobuf.Empty} Empty
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                Empty.decodeDelimited = function decodeDelimited(reader) {
                    if (!(reader instanceof $Reader))
                        reader = new $Reader(reader);
                    return this.decode(reader, reader.uint32());
                };
    
                /**
                 * Verifies an Empty message.
                 * @function verify
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {Object.<string,*>} message Plain object to verify
                 * @returns {string|null} `null` if valid, otherwise the reason why it is not
                 */
                Empty.verify = function verify(message) {
                    if (typeof message !== "object" || message === null)
                        return "object expected";
                    return null;
                };
    
                /**
                 * Creates an Empty message from a plain object. Also converts values to their respective internal types.
                 * @function fromObject
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {Object.<string,*>} object Plain object
                 * @returns {google.protobuf.Empty} Empty
                 */
                Empty.fromObject = function fromObject(object) {
                    if (object instanceof $root.google.protobuf.Empty)
                        return object;
                    return new $root.google.protobuf.Empty();
                };
    
                /**
                 * Creates a plain object from an Empty message. Also converts values to other types if specified.
                 * @function toObject
                 * @memberof google.protobuf.Empty
                 * @static
                 * @param {google.protobuf.Empty} message Empty
                 * @param {$protobuf.IConversionOptions} [options] Conversion options
                 * @returns {Object.<string,*>} Plain object
                 */
                Empty.toObject = function toObject() {
                    return {};
                };
    
                /**
                 * Converts this Empty to JSON.
                 * @function toJSON
                 * @memberof google.protobuf.Empty
                 * @instance
                 * @returns {Object.<string,*>} JSON object
                 */
                Empty.prototype.toJSON = function toJSON() {
                    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
                };
    
                return Empty;
            })();
    
            return protobuf;
        })();
    
        return google;
    })();

    return $root;
});
