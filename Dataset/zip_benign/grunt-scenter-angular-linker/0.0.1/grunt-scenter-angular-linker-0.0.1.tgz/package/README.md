# grunt-scenter-angular-linker

> Autoinsert scenter modules into main angular file

## Getting Started
This plugin requires Grunt `~0.4.x`

When the task is run the destination file is updated with the angular modules in scenter. The reason this plugin was built was to automate the process of inserting modules with the file structure of scenter which gets tedious.

```shell
npm install grunt-scenter-angular-linker
```

Once the plugin has been installed, it may be enabled inside your Gruntfile with this line of JavaScript:

```js
grunt.loadNpmTasks('grunt-scenter-angular-linker');
```

## The "angular-linker" task

### Overview
In your project's Gruntfile, add a section named `angular-linker` to the data object passed into `grunt.initConfig()`.

```js
grunt.initConfig({
  'angular-linker': {
    defaultOptions: {
      options: {
        startTag: '// INJECT APP MODULES',
        endTag: '// APP MODULES END',
        fileTmpl: "'%s',",
        appRoot: '.tmp/public/js/app',
        prefix: 'scenter.'
      },
      files: {
        // Target-specific file lists and/or options go here.
        'app/index.html': ['app/scripts/**/*.js']
      },
    },
  },
})
```

### Options

#### options.startTag
Type: `String`
Default value: `'// INJECT APP MODULES'`

Modules are places between the startTag and endTag

#### options.endTag
Type: `String`
Default value: `'// APP MODULES END'`

Modules are places between the startTag and endTag

#### options.fileTmpl
Type: `String`
Default value: `"'%s',"`

The template used to insert the reference to the modules.

#### options.appRoot
Type: `String`
Default value: `'.tmp/public/js/app'`

The root of the application. Script links are relative from this folder.

#### options.relative
Type: `String`
Default value: `'scenter.'`

Prefix to angular modules for namespacing.

