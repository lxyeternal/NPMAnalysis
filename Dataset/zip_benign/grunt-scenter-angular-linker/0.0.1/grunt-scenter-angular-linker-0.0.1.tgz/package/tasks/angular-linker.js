/*
 * grunt-scenter-angular-linker
 * https://github.com/jpopesculian/grunt-scenter-angular-linker
 *
 * Copyright (c) 2014 jpopesculian
 * Licensed under the MIT license.
 */

'use strict';

var util = require('util');

module.exports = function(grunt) {

  // Please see the Grunt documentation for more information regarding task
  // creation: http://gruntjs.com/creating-tasks

  grunt.registerMultiTask('angular-linker', 'Autoinsert scenter modules into main angular file', function() {
    // Merge task-specific and/or target-specific options with these defaults.
    var options = this.options({
      startTag: '// INJECT APP MODULES',
      endTag: '// APP MODULES END',
      fileTmpl: "'%s',",
      appRoot: '.tmp/public/js/app',
      prefix: 'scenter.'
    });


    // Iterate over all specified file groups.
    this.files.forEach(function (f) {
      var modules,
        page = '',
        newPage = '',
        start = -1,
        end = -1;

      // Create string tags
      modules = f.src.filter(function (filepath) {
          // Warn on and remove invalid source files (if nonull was set).
          if (!grunt.file.exists(filepath)) {
            grunt.log.warn('Source file "' + filepath + '" not found.');
            return false;
          } else {
            // ignore app.js
            if (filepath.split("/").length == options.appRoot.split("/").length + 1) {
              return false;
            }
            return true;
          }
        }).map(function (filepath) {

          filepath = filepath.replace(options.appRoot, '');
          filepath = filepath.replace(/^\//,'');

          // Create module structure
          var module = options.prefix + (function (file) {
            // get non-plural form
            file[0] = file[0].substr(0, file[0].length - 1);
            // get rid of extension
            file[file.length-1] = file[file.length-1].split(".")[0];
            return file.join(".");
          }(filepath.split("/")));

          return util.format(options.fileTmpl, module);
        });

      grunt.file.expand({}, f.dest).forEach(function(dest){
        page = grunt.file.read(dest);
        start = page.indexOf(options.startTag);
        end = page.indexOf(options.endTag, start);

        if (start === -1 || end === -1 || start >= end) {
          return;
        } else {
          var padding ='';
          var ind = start - 1;
          while(/[^\S\n]/.test(page.charAt(ind))){
            padding += page.charAt(ind);
            ind -= 1;
          }
          console.log('padding length', padding.length);
          newPage = page.substr(0, start + options.startTag.length) + grunt.util.linefeed + padding + modules.join(grunt.util.linefeed + padding) + grunt.util.linefeed + padding + page.substr(end);
          // Insert the modules
          grunt.file.write(dest, newPage);
          grunt.log.writeln('File "' + dest + '" updated.');
        }
      });
    });
  });

};
