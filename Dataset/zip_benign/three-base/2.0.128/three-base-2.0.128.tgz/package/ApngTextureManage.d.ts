import { Texture, TextureLoader } from "three";
/**
 * apng 纹理管理对象
 */
declare class apngTextureManage {
    constructor();
    static TextureLoader: TextureLoader;
    static isInit: boolean;
    static TimeTemp: number;
    playTimes: Map<any, any>;
    anpgTextList: {
        [key: string]: Texture[];
    };
    getTexture(path: string): Texture;
    loadApng(url: string): Promise<void>;
}
declare const ApngTextureManage: apngTextureManage;
export default ApngTextureManage;
