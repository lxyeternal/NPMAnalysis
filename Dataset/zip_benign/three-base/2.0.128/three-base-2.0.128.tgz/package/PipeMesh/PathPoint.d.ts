import { Vector3 } from 'three/src/math/Vector3';
/**
 * PathPoint
 */
declare class PathPoint {
    pos: Vector3;
    dir: Vector3;
    right: Vector3;
    up: Vector3;
    dist: number;
    widthScale: number;
    sharp: boolean;
    constructor();
    lerpPathPoints(p1: PathPoint, p2: PathPoint, alpha: number): void;
    copy(source: PathPoint): void;
}
export { PathPoint };
