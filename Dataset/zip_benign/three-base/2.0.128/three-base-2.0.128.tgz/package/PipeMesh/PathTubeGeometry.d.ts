import { Usage } from 'three/src/constants.js';
import { PathGeometry, type Options, type PathGeometryParam } from './PathGeometry.js';
import type { PathPointList } from './PathPointList.js';
/**
 * PathTubeGeometry
 */
declare class PathTubeGeometry extends PathGeometry {
    /**
     * @param {Object|Number} initData - If initData is number, geometry init by empty data and set it as the max vertex. If initData is Object, it contains pathPointList and options.
     * @param {Boolean} [generateUv2=false]
     */
    constructor(initData: PathGeometryParam, generateUv2?: boolean);
    _initByData(pathPointList: PathPointList, options: Options, usage: Usage, generateUv2: boolean): void;
    /**
     * Update geometry by PathPointList instance
     * @param {PathPointList} pathPointList
     * @param {Object} options
     * @param {Number} [options.radius=0.1]
     * @param {Number} [options.progress=1]
     * @param {Boolean} [options.radialSegments=8]
     * @param {String} [options.startRad=0]
     */
    update(pathPointList: PathPointList, options: Options): void;
}
export { PathTubeGeometry };
