import { Usage } from 'three/src/constants.js';
import type { PathPointList } from './PathPointList.js';
import { BufferGeometry } from 'three/src/core/BufferGeometry.js';
export interface Options {
    radius?: number;
    width?: number;
    progress?: number;
    radialSegments?: number;
    startRad?: number;
    arrow?: boolean;
    side?: 'both' | 'left' | 'right';
}
export interface PathGeometryParam {
    pathPointList: PathPointList;
    options: Options;
    usage: Usage;
    transparent: boolean;
}
/**
 * PathGeometry
 */
declare class PathGeometry extends BufferGeometry {
    /**
     * @param {Object|Number} initData - If initData is number, geometry init by empty data and set it as the max vertex. If initData is Object, it contains pathPointList and options.
     * @param {Boolean} [generateUv2=false]
     */
    constructor(initData: PathGeometryParam, generateUv2?: boolean);
    _initByMaxVertex(maxVertex: number, generateUv2: boolean): void;
    _initByData(pathPointList: PathPointList, options: Options, usage: Usage, generateUv2: boolean): void;
    /**
     * Update geometry by PathPointList instance
     * @param {PathPointList} pathPointList
     * @param {Object} options
     * @param {Number} [options.width=0.1]
     * @param {Number} [options.progress=1]
     * @param {Boolean} [options.arrow=true]
     * @param {String} [options.side='both'] - "left"/"right"/"both"
     */
    update(pathPointList: PathPointList, options: Options): void;
    _resizeAttribute(name: string, len: number): void;
    _resizeIndex(len: number): void;
    _updateAttributes(position: Array<number>, normal: Array<number>, uv: Array<number>, uv2: Array<number> | null, indices: Array<number>): void;
}
export { PathGeometry };
