import { Material, Mesh, Vector3 } from "three";
import { PathPointList } from "./PathPointList";
import { PathTubeGeometry } from "./PathTubeGeometry";
export type PipeMeshProps = {
    vector3s: Array<Vector3>;
    radius?: number;
    segments?: number;
};
/**
 * 创建基础的管道模型
 */
export default class PipeMesh extends Mesh<PathTubeGeometry, Material> {
    constructor(props: PipeMeshProps);
    type: string;
    vector3s: Array<Vector3>;
    radius: number;
    segments: number;
    pathPointList: PathPointList;
    material: Material;
    set(props: PipeMeshProps): void;
    setVector(i: number, vector: Vector3): void;
    getVector(i: number): Vector3;
    setLatestVector(vector: Vector3): void;
    getLatestVector(): Vector3;
}
