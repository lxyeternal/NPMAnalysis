export { default } from "./PipeMesh";
