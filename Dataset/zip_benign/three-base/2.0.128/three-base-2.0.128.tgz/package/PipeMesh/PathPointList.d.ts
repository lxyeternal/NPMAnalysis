import { Vector3 } from 'three/src/math/Vector3.js';
import { PathPoint } from './PathPoint.js';
/**
 * PathPointList
 * input points to generate a PathPoint list
 */
declare class PathPointList {
    array: Array<PathPoint>;
    count: number;
    constructor();
    /**
     * Set points
     * @param {Vector3[]} points key points array
     * @param {number} cornerRadius? the corner radius. set 0 to disable round corner. default is 0.1
     * @param {number} cornerSplit? the corner split. default is 10.
     * @param {number} up? force up. default is auto up (calculate by tangent).
     * @param {boolean} close? close path. default is false.
     */
    set(points: Array<Vector3>, cornerRadius?: number, cornerSplit?: number, up?: Vector3, close?: boolean): void;
    /**
     * Get distance of this path
     * @return {number}
     */
    distance(): number;
    _getByIndex(index: number): PathPoint;
    _start(current: Vector3, next: Vector3, up?: Vector3): void;
    _end(current: Vector3): void;
    _corner(current: Vector3, next: Vector3, cornerRadius: number, cornerSplit: number, up?: Vector3): void;
    _sharpCorner(current: Vector3, next: Vector3, up?: Vector3, dirType?: 0 | 1 | 2, sharp?: boolean): void;
}
export { PathPointList };
