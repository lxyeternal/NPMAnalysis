export declare const SPRITE_ROW_LENGTH = 4;
export declare const ONE_SPRITE_ROW_LENGTH: number;
import { BufferGeometry } from "three";
export default class FireGromtry extends BufferGeometry {
    radius: number;
    height: number;
    particleCount: number;
    constructor(radius?: number, height?: number, particleCount?: number);
}
