/*
 * @Author: xiaosihan
 * @Date: 2024-06-17 02:15:58
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2024-06-18 18:12:37
 */
export const SPRITE_ROW_LENGTH = 4; // 粒子图片中图片数量
export const ONE_SPRITE_ROW_LENGTH = 1 / SPRITE_ROW_LENGTH; // 每一行的宽度
import { BufferAttribute, BufferGeometry } from "three";
// 粒子火焰顶点对象
export default class FireGromtry extends BufferGeometry {
    radius = 0.5;
    height = 3;
    particleCount = 200;
    constructor(radius = 0.5, height = 3, particleCount = 200) {
        super();
        const halfHeight = height * 0.5;
        const position = new Float32Array(particleCount * 3);
        const random = new Float32Array(particleCount);
        const sprite = new Float32Array(particleCount);
        for (let i = 0; i < particleCount; i++) {
            const r = Math.sqrt(Math.random()) * radius;
            const angle = Math.random() * 2 * Math.PI;
            position[i * 3 + 0] = Math.cos(angle) * r;
            position[i * 3 + 1] = (radius - r) / radius * halfHeight + halfHeight;
            position[i * 3 + 2] = Math.sin(angle) * r;
            sprite[i] = ONE_SPRITE_ROW_LENGTH * ((Math.random() * 4) | 0);
            random[i] = Math.random();
            if (i === 0) {
                // to avoid going out of Frustum
                position[i * 3 + 0] = 0;
                position[i * 3 + 1] = 0;
                position[i * 3 + 2] = 0;
            }
        }
        this.setAttribute('position', new BufferAttribute(position, 3));
        this.setAttribute('random', new BufferAttribute(random, 1));
        this.setAttribute('sprite', new BufferAttribute(sprite, 1));
    }
}
