import { Color, ShaderMaterial } from "three";
export default class FireMaterial extends ShaderMaterial {
    constructor();
    uniforms: {
        color: {
            value: Color;
        };
        size: {
            value: number;
        };
        map: {
            value: import("three").Texture;
        };
        time: {
            value: number;
        };
        heightOfNearPlane: {
            value: number;
        };
    };
    vertexShader: string;
    fragmentShader: string;
    blending: 2;
    depthTest: boolean;
    depthWrite: boolean;
    transparent: boolean;
    fog: boolean;
}
