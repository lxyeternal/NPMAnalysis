import { BufferGeometry, Camera, Clock, Group, Material, NormalBufferAttributes, Object3DEventMap, Points, Scene, Vector2, WebGLRenderer } from "three";
import FireGromtry from "./FireGromtry";
import FireMaterial from "./FireMaterial";
export default class Fire extends Points {
    constructor();
    geometry: FireGromtry;
    material: FireMaterial;
    fireColor: string;
    fireScale: number;
    fireRadius: number;
    fireHeight: number;
    particleCount: number;
    isPerspectiveCamera: boolean;
    size: Vector2;
    cacheProps: {
        fireColor: string;
        fireScale: number;
        fireRadius: number;
        fireHeight: number;
        particleCount: number;
        width: number;
        height: number;
        isPerspectiveCamera: boolean;
    };
    updataFrame: number;
    clock: Clock;
    onBeforeRender(renderer: WebGLRenderer, scene: Scene, camera: Camera, geometry: BufferGeometry<NormalBufferAttributes>, material: Material, group: Group<Object3DEventMap>): void;
}
