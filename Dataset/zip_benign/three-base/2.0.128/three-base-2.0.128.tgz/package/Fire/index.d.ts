export { default } from "./Fire";
