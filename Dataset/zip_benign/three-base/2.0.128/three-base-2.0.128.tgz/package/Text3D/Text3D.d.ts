import { Mesh, MeshStandardMaterial } from "three";
export type Text3DProps = {
    text?: string;
    fontType?: string;
    size?: number | undefined;
    depth?: number | undefined;
    curveSegments?: number | undefined;
    bevelEnabled?: boolean | undefined;
    bevelThickness?: number | undefined;
    bevelSize?: number | undefined;
    bevelOffset?: number | undefined;
    bevelSegments?: number | undefined;
};
export default class Text3D extends Mesh {
    constructor(text?: string);
    static path: string;
    material: MeshStandardMaterial;
    _config: Text3DProps;
    setText(text3DProps: Text3DProps): void;
}
