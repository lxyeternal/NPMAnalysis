import Dexie, { Table } from "dexie";
import { Font } from "three/examples/jsm/loaders/FontLoader.js";
export type saveFontParam = {
    fontType?: string;
    fontName: string;
    fontJson: any;
};
export type addFontFamilyParam = {
    fontType?: string;
    fontFamilyJson: any;
};
export type getFontParam = {
    fontType?: string;
    fontName: string;
};
export type loadTextParam = {
    fontBasePath: string;
    fontType?: string;
    text?: string;
    callback?: (font: Font) => void;
};
declare class indexBD extends Dexie {
    constructor(dbName: string);
    threeFont: Table;
}
declare class fontContorl {
    constructor();
    THREEFontMap: Map<string, Font>;
    fontBD: indexBD;
    /**
     * 保存 字体json到本地数据库中
     * @param {saveFontParam} { fontType = "simhei", fontName, fontJson }
     * @memberof fontContorl
     */
    saveFont({ fontType, fontName, fontJson }: saveFontParam): Promise<void>;
    /**
     * 通过 fontType 和 fontName 查询 fontJson
     * @param {getFontParam} { fontType = "simhei", fontName }
     * @returns
     * @memberof fontContorl
     */
    getFont({ fontType, fontName }: getFontParam): Promise<any>;
    _loadTextCall: Map<string, Array<() => void>>;
    loadText({ fontType, text, fontBasePath, callback }: loadTextParam): Promise<void>;
    _loadFontIndexJson({ fontType, fontBasePath }: loadTextParam): Promise<void>;
    _loadFontJson({ fontType, fontName, fontBasePath }: {
        fontType: string;
        fontName: string;
        fontBasePath: string;
    }): Promise<void>;
    hasFont({ fontType, fontName }: {
        fontType: string;
        fontName: string;
    }): boolean;
    addFont({ fontType, fontName, fontJson }: saveFontParam): void;
    addFontFamily({ fontType, fontFamilyJson }: addFontFamilyParam): void;
}
declare const fontContorller: fontContorl;
export default fontContorller;
