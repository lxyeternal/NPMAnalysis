import { APNG } from "apng-js";
import Player from "apng-js/types/library/player";
import { CanvasTexture } from "three";
export default class ApngTexture extends CanvasTexture {
    constructor(url: string);
    static TimeTemp: number;
    preUpdate: number;
    player?: Player;
    apng?: APNG;
    onUpdate: () => void;
    getUuid(): number | "";
    loadApng(url: string): Promise<void>;
}
