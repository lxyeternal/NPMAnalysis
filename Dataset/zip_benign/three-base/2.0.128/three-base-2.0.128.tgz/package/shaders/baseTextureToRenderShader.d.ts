import { ShaderMaterial } from "three";
export declare const baseTextureToRenderShader: ShaderMaterial;
