import { ShaderChunk, ShaderMaterial } from "three";
// 拷贝着色器
const copyShader = new ShaderMaterial({
    uniforms: {
        map: { value: null },
        opacity: { value: 1 }, // 透明度
    },
    vertexShader: `
          ${ShaderChunk.common}
          ${ShaderChunk.logdepthbuf_pars_vertex}
          varying vec2 vUv;
          void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
              ${ShaderChunk.logdepthbuf_vertex}
          }
      `,
    fragmentShader: `
          ${ShaderChunk.logdepthbuf_pars_fragment}
          uniform float opacity;
          uniform sampler2D map;
          varying vec2 vUv;
          void main() {
              gl_FragColor = texture2D(map, vUv);
              gl_FragColor.a *= opacity;
              ${ShaderChunk.logdepthbuf_fragment}
          }
      `,
    depthTest: true,
    depthWrite: true,
    transparent: true,
});
export default copyShader;
