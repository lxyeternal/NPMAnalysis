import { ShaderMaterial } from "three";
declare const copyShader: ShaderMaterial;
export default copyShader;
