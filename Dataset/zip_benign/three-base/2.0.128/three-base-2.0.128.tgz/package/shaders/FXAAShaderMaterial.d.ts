import { ShaderMaterial } from "three";
declare const FXAAShaderMaterial: ShaderMaterial;
export default FXAAShaderMaterial;
