/*
 * @Author: xiaosihan
 * @Date: 2022-03-24 16:38:35
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2025-01-28 04:03:20
 */
import { NoBlending, OrthographicCamera, ShaderChunk, ShaderMaterial } from "three";
export const orthographicCamera = new OrthographicCamera(-1, 1, 1, -1, 0, 1);
// 清理着色器
export const clearShader = new ShaderMaterial({
    vertexShader: `
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = vec4(position, 1.0);
        }
    `,
    fragmentShader: `
        void main() {
            gl_FragColor = vec4(0.0);
        }
    `,
    blending: NoBlending,
    depthTest: false,
    depthWrite: false,
    transparent: true,
});
// 交集着色器提取相同的像素点
export const intersectionShader = new ShaderMaterial({
    uniforms: {
        map1: { value: null },
        map2: { value: null }, // 贴图纹理2
    },
    vertexShader: `
        ${ShaderChunk.common}
        ${ShaderChunk.logdepthbuf_pars_vertex}
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = vec4(position, 1.0);
            ${ShaderChunk.logdepthbuf_vertex}
        }
    `,
    fragmentShader: `
        ${ShaderChunk.logdepthbuf_pars_fragment}
        uniform sampler2D map1;
        uniform sampler2D map2;
        varying vec2 vUv;
        void main() {
            if(texture2D(map1, vUv) ==  texture2D(map2, vUv)){
                gl_FragColor = texture2D(map1, vUv);
            }else{
                discard;
            }
            ${ShaderChunk.logdepthbuf_fragment}
        }
    `,
    blending: NoBlending,
    depthTest: true,
    depthWrite: true,
    transparent: true,
});
// 拷贝着色器
export const copyShader = new ShaderMaterial({
    uniforms: {
        map: { value: null },
        opacity: { value: 1.0 }, // 透明度
    },
    vertexShader: `
        ${ShaderChunk.common}
        ${ShaderChunk.logdepthbuf_pars_vertex}
        varying vec2 vUv;
        void main() {
            vUv = uv;
            gl_Position = vec4(position, 1.0);
            ${ShaderChunk.logdepthbuf_vertex}
        }
    `,
    fragmentShader: `
        ${ShaderChunk.logdepthbuf_pars_fragment}
        uniform sampler2D map;
        uniform float opacity;
        varying vec2 vUv;
        void main() {
            vec4 diffuseColor = texture(map, vUv);
            gl_FragColor = diffuseColor * opacity;
            ${ShaderChunk.logdepthbuf_fragment}
        }
    `,
    depthTest: true,
    depthWrite: true,
    transparent: true,
});
