/*
 * @Author: xiaosihan
 * @Date: 2022-05-23 13:53:06
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2023-05-03 02:54:52
 */
import { DoubleSide, Mesh, MeshBasicMaterial, PlaneGeometry, Vector3 } from "three";
import SpriteText from "./SpriteText";
export default class PlaneText extends Mesh {
    constructor(text = "planeText") {
        super(PlaneText.geometry);
        this.set({ text });
    }
    type = "PlaneText";
    static geometry = new PlaneGeometry(1, 1, 1, 1);
    spriteText = new SpriteText("");
    material = new MeshBasicMaterial({ transparent: true, side: DoubleSide, map: this.spriteText.material.map });
    set(parame) {
        for (let key in parame) {
            //@ts-ignore
            this.spriteText[key] = parame[key];
        }
        this.scale.copy(this.spriteText.scale);
        this.scale.max(new Vector3(1, 1, 1));
        this.material.map = this.spriteText.material.map;
    }
    get(prop) {
        return this.spriteText[prop];
    }
}
