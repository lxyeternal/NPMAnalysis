import { AxesHelper, DepthTexture, EventDispatcher, GridHelper, Object3D, OrthographicCamera, PerspectiveCamera, Scene, Texture, Vector2, Vector3, WebGLRenderTarget, WebGLRenderer } from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import ThreeMouse from "./ThreeMouse";
import Transition from "./Transition";
export default class ThreeBase extends EventDispatcher {
    constructor();
    minDevicePixelRatio: number;
    baseDepthTexture: DepthTexture;
    baseRenderTarget: WebGLRenderTarget<Texture>;
    renderTarget: WebGLRenderTarget<Texture>;
    renderTarget2: WebGLRenderTarget<Texture>;
    tempVector2: Vector2;
    tempVector3: Vector3;
    size: Vector2;
    rendererLost: boolean;
    renderer: WebGLRenderer;
    perspectiveCamera: PerspectiveCamera;
    orthographicCamera: OrthographicCamera;
    cameraType: "perspectiveCamera" | "orthographicCamera";
    setCameraType(cameraType: "perspectiveCamera" | "orthographicCamera"): void;
    getCamera(): PerspectiveCamera | OrthographicCamera;
    scene: Scene;
    add(...object: Object3D[]): this;
    threeMouse: ThreeMouse;
    controls: OrbitControls;
    setContainer(div: HTMLDivElement | null): Promise<void>;
    setSize(width: number, height: number): void;
    controlsDistance: Transition<{
        distance: number;
    }, "distance">;
    controlsCenter: Transition<{
        x: number;
        y: number;
        z: number;
    }, "x" | "y" | "z">;
    controlsPosition: Transition<{
        x: number;
        y: number;
        z: number;
    }, "x" | "y" | "z">;
    gridHelper: GridHelper;
    axesHelper: AxesHelper;
    frame: number;
    init(): void;
    resetLookAt({ position, center, }: {
        position: Vector3;
        center: Vector3;
    }): void;
    setLookAt({ position, center, duration, }: {
        position: Vector3;
        center: Vector3;
        duration?: number;
    }): Promise<void>;
    getLookAt(): {
        center: Vector3;
        position: Vector3;
        centerPosition: string;
    };
    lookatObjects({ objects, duration, direction, offset, distance, }: {
        objects: Array<Object3D>;
        duration?: number;
        direction?: Vector3;
        offset?: Vector3;
        distance?: number;
    }): void;
    v3tov2(v3: Vector3): Vector2;
    controlType: "OrbitControls" | "MapControls";
    originScreenSpacePanning: boolean;
    setControlType(controlType: "OrbitControls" | "MapControls"): void;
    autoRender: boolean;
    needRender: boolean;
    stopRender(): void;
    render(): void;
    private renderBindThis;
    getThumbBlob(): Promise<Blob>;
    getThumbBase64(): string;
    getThumbFile(): Promise<File>;
    download(fileName?: string): Promise<void>;
    renderRendererTarget(renderTarget: WebGLRenderTarget): void;
    renderTexture(texture: Texture, alpha?: boolean): void;
}
