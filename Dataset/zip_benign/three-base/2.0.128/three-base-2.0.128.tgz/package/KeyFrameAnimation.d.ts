import { Euler, Line, LineBasicMaterial, Object3D, Vector3 } from "three";
export type Keyframe = {
    position: Vector3;
    scale: Vector3;
    rotation: Euler;
    timeTemp: number;
};
export type KeyframeAnimationProps = {
    speedScale?: number;
    object3d: Object3D;
    keyframes: Array<Keyframe>;
};
export default class KeyframeAnimation extends Object3D {
    constructor(props: KeyframeAnimationProps);
    speedScale: number;
    object3d: Object3D;
    halperLine: Line<any, LineBasicMaterial, import("three").Object3DEventMap>;
    keyframes: Array<Keyframe>;
    setObject3D(object3d: Object3D): void;
    getKeyframe(i: number): Keyframe;
    setKeyframe(i: number, keyframe: Keyframe): void;
    setKeyframes(keyframes: Array<Keyframe>): void;
    update(): void;
    updateMatrix(): void;
}
