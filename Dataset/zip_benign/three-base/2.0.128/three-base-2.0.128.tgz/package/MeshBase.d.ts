import { AnimationAction, AnimationMixer, Clock, Group, Mesh, Object3D, Vector3 } from "three";
export default class MeshBase extends Group {
    constructor(url?: string);
    url: string;
    static models: Map<string, Object3D>;
    static loadModeling: Map<string, boolean>;
    loaded: boolean;
    hasAnimation: boolean;
    mixer?: AnimationMixer;
    animationActions: {
        [key: string]: AnimationAction;
    };
    getSuffix(filename: string): string;
    reset(...object: Object3D[]): this;
    loadModel(url: string | File | Array<File>, filename?: string): Promise<void>;
    frustumCulled: boolean;
    castShadow: boolean;
    receiveShadow: boolean;
    resoles: Array<(value: void | PromiseLike<void>) => void>;
    awaitLoaded(): Promise<void>;
    traverseMesh(callback: (mesh: Mesh) => void): Promise<void>;
    clock: Clock;
    setClipActionWeight(weights?: {
        [key: string]: number;
    }): Promise<void>;
    getAnimas(): string[];
    setAnimas(anima?: string): void;
    stop(): void;
    updateMatrix(): void;
    getSize(): Promise<Vector3>;
    center(): Promise<void>;
    alignBottom(y?: number): Promise<void>;
    scaleTo(size?: number, key?: Array<"x" | "y" | "z">): Promise<void>;
    expandBynormal(length: number): void;
}
