import { OrthographicCamera, ShaderMaterial } from "three";
export declare const orthographicCamera: OrthographicCamera;
export declare const clearShader: ShaderMaterial;
export declare const intersectionShader: ShaderMaterial;
export declare const copyShader: ShaderMaterial;
