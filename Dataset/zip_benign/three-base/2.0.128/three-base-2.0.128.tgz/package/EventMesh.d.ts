import { BoxGeometry, BufferGeometry, CylinderGeometry, Material, Mesh, MeshNormalMaterial } from "three";
export declare enum CollisionShaere {
    cube = "cube",
    cylinder = "cylinder"
}
/**
 * 碰撞检测用的模型
 */
export default class EventMesh extends Mesh<BufferGeometry, Material> {
    constructor(type?: CollisionShaere);
    static type: typeof CollisionShaere;
    static material: MeshNormalMaterial;
    renderOrder: number;
    static cubeGeo: BoxGeometry;
    static cylinderGeo: CylinderGeometry;
    isEventMesh: boolean;
    setType(type: CollisionShaere): void;
}
