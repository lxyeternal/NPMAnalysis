import { Color, Euler, InstancedBufferAttribute, InstancedMesh, Matrix4, Mesh, Object3D, Quaternion, Vector3 } from "three";
import MeshBase from "./MeshBase";
export default class InstancedMeshBase extends MeshBase {
    constructor(url?: string);
    isInstancedGroupMesh: boolean;
    count: number;
    size: Vector3;
    meshCollect: Record<string, Mesh[]>;
    instanceCollect: Record<string, InstancedMesh>;
    colorMap: Map<String, Color>;
    children: InstancedMesh[];
    static _position: Vector3;
    static _scale: Vector3;
    static _rotation: Euler;
    static _Quaternion: Quaternion;
    static _matrix: Matrix4;
    instanceMatrix: InstancedBufferAttribute;
    instanceColor: InstancedBufferAttribute;
    reset(...object: Object3D[]): this;
    loadModel(url: string | File | Array<File>, filename?: string): Promise<void>;
    computeBoundingSphere: import("lodash").DebouncedFuncLeading<() => void>;
    setCount(count?: number): Promise<void>;
    setMatrixAt(index: number, matrix?: Matrix4): Promise<void>;
    setTRS(index: number, { position, rotation, scale, }: {
        position?: Vector3;
        rotation?: Euler;
        scale?: Vector3;
    }): Promise<void>;
    getTRS(index?: number): Promise<{
        position: Vector3;
        rotation: Euler;
        scale: Vector3;
    }>;
    setColorAt(index: number, color: (instancedMesh: InstancedMesh) => Color | undefined): Promise<void>;
    getColorAt(index?: number): Promise<Color>;
    updateMatrixWorld(force?: boolean): void;
    addEventListener(name: string, callback: (e: any) => void): Promise<void>;
    removeEventListener(name: string, callback: (e: any) => void): void;
}
