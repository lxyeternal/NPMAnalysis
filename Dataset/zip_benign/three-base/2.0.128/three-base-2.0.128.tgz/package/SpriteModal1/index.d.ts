export { default } from "./SpriteModal1";
