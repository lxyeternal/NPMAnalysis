import { Sprite, Raycaster, Intersection } from "three";
export type SpritModal1Config = {
    size?: number;
    title?: string;
    titleColor?: string;
    texts?: Array<{
        text?: string;
        color?: string;
        size?: number;
    }>;
};
export default class SpritModal1 extends Sprite {
    constructor(config?: SpritModal1Config);
    static img: HTMLImageElement;
    canvas: HTMLCanvasElement;
    context: CanvasRenderingContext2D;
    texture: import("three").Texture;
    _config: {
        size: number;
        title: string;
        titleColor: string;
        texts: Array<{
            text: string;
            color: string;
            size: number;
        }>;
    };
    updata(config: SpritModal1Config): Promise<void>;
    raycast(raycaster: Raycaster, intersects: Intersection[]): void;
}
