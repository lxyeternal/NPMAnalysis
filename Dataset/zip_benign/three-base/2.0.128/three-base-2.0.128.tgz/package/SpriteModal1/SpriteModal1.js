/*
 * @Author: xiaosihan
 * @Date: 2023-03-08 00:01:34
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2023-03-08 02:05:25
 */
import { Sprite, Vector2 } from "three";
import spriteModal1PNG from "./spriteModal1.png";
import threeLoader from "../threeLoader";
// sprit弹窗1
export default class SpritModal1 extends Sprite {
    constructor(config = {}) {
        super();
        this.updata(config);
        this.material.map = this.texture;
        this.material.transparent = true;
        this.material.alphaTest = 0.01;
    }
    // 背景图
    static img = (() => {
        const img = new Image();
        img.src = spriteModal1PNG;
        return img;
    })();
    canvas = (() => {
        const canvas = document.createElement("canvas");
        canvas.width = 1024;
        canvas.height = 1024;
        return canvas;
    })();
    context = this.canvas.getContext("2d");
    texture = threeLoader.getTexture(this.canvas);
    // 配置
    _config = {
        size: 10,
        title: "SpritModal1",
        titleColor: "#ffffff",
        texts: []
        // [
        //     {
        //         text: "1",
        //         color: "#ffff00",
        //         size: 40
        //     },
        //     {
        //         text: "2",
        //         color: "#ff00ff",
        //         size: 40
        //     },
        // ]
    };
    async updata(config) {
        Object.assign(this._config, config);
        //绘制背景
        this.context.clearRect(0, 0, 1024, 1024);
        while (!SpritModal1.img.complete) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        // 设置大小
        this.scale.set(this._config.size, this._config.size, this._config.size);
        // this.context.fillStyle = "#00000088";
        // this.context.fillRect(0, 0, 1024, 1024);
        //绘制背景
        this.context.drawImage(SpritModal1.img, 186, 0);
        // 绘制标题
        this.context.fillStyle = this._config.titleColor;
        this.context.font = '40px serif'; // 设置字体大小
        this.context.textAlign = "left";
        this.context.textBaseline = "top";
        this.context.fillText(this._config.title, 250, 72);
        let textPos = new Vector2(250, 150);
        let maxWidth = 530;
        // 绘制内容
        this._config.texts.map(({ text = "text", color = "#ffffff", size = 40 }) => {
            this.context.fillStyle = color;
            this.context.font = `${size}px serif`; // 设置字体大小
            this.context.textAlign = "left";
            this.context.textBaseline = "top";
            // 字符分隔为数组
            var arrText = text.split('');
            var line = '';
            // 文字自动换行计算
            for (var n = 0; n < arrText.length; n++) {
                var metrics = this.context.measureText(line + arrText[n]);
                var testWidth = metrics.width;
                if ((testWidth > maxWidth && n > 0) || arrText[n] === "\n") {
                    this.context.fillText(line, textPos.x, textPos.y);
                    line = "";
                    textPos.y += size;
                }
                else {
                    line += arrText[n];
                }
            }
            this.context.fillText(line, textPos.x, textPos.y);
            textPos.y += size;
        });
        this.texture.needsUpdate = true;
        this.dispatchEvent({ type: "loaded" });
    }
    //鼠标拾取计算
    raycast(raycaster, intersects) {
        let intersect = [];
        super.raycast(raycaster, intersect);
        let inte = intersect[0];
        if (inte && (inte.uv.x > 0.22 && inte.uv.x < 0.78) && (inte.uv.y > 0.54 && inte.uv.y < 0.94)) {
            intersects.push(inte);
        }
    }
}
