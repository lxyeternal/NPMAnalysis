export type TransitionParame = {
    [key: string]: number;
};
export default class Transition<T extends TransitionParame, K extends Extract<keyof T, string>> {
    /**
     *Creates an instance of transition.
     * @param {{ [key: string]: number }} // 初始值
     * @param {[0.8, 0, 0.2, 1]} // 贝塞尔曲线
     * @param {number} [duration=1000]  // 过渡时间
     * @memberof transition
     */
    constructor(param: T, bezier?: [number, number, number, number], duration?: number);
    _keys: Array<Extract<keyof T, string>>;
    _bezier: [number, number, number, number];
    _Xbezier: [number, number, number, number];
    _Ybezier: [number, number, number, number];
    setBezier(bezier?: [number, number, number, number]): this;
    timeTemp: number;
    _duration: number;
    _delay: number;
    setDuration(duration?: number): this;
    setDelay(delay?: number): this;
    _: {
        [key in `${K}_start` | `${K}_end` | `${K}_startTime`]: number;
    };
    private onChangeCall;
    private onDoneCall;
    run({ timeTemp }: any): this;
    runbindThis: any;
    onChange(onChangeCall: (josn: T) => void): this;
    onDone(onDoneCall: (josn: T) => void): this;
    get(key: Extract<keyof T, string>): T[K];
    set(param: Partial<T>): Promise<this>;
    reset(param: Partial<T>): this;
    getKeys(): Array<Extract<keyof T, string>>;
    hasKey(key: Extract<keyof T, string>): boolean;
    getJson(): T;
    _isDone: boolean;
    isDone(): boolean;
}
