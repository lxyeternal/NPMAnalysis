import { Mesh, MeshBasicMaterial, PlaneGeometry, Vector2 } from "three";
export default class PlaneWithHtml extends Mesh {
    constructor(html?: string, backgroundColor?: `#${string}`);
    visible: boolean;
    size: Vector2;
    geometry: PlaneGeometry;
    material: MeshBasicMaterial;
    div: HTMLDivElement;
    setGeoSize(width: number, height: number): void;
    setHtml(html?: string, backgroundColor?: `#${string}`): Promise<void>;
}
