/*
 * @Author: xiaosihan
 * @Date: 2022-03-20 12:55:37
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2023-02-07 11:19:56
 */
import { BoxGeometry, CylinderGeometry, DoubleSide, Mesh, MeshBasicMaterial, MeshNormalMaterial } from "three";
import threeUtils from "./threeUtils";
// 碰撞的形状
export var CollisionShaere;
(function (CollisionShaere) {
    CollisionShaere["cube"] = "cube";
    CollisionShaere["cylinder"] = "cylinder"; // 圆柱体
})(CollisionShaere || (CollisionShaere = {}));
/**
 * 碰撞检测用的模型
 */
export default class EventMesh extends Mesh {
    constructor(type = CollisionShaere.cube) {
        super();
        this.material = EventMesh.material;
        this.setType(type);
        // 生产环境 不用渲染
        if (threeUtils.isProd) {
            this.material = new MeshBasicMaterial({
                side: DoubleSide,
                transparent: true,
                opacity: 0.25,
                alphaTest: 1
            });
        }
    }
    static type = CollisionShaere;
    static material = new MeshNormalMaterial({
        side: DoubleSide,
        transparent: true,
        opacity: 0.3,
    });
    renderOrder = 99;
    // 正方体 网格模型
    static cubeGeo = new BoxGeometry(1, 1, 1, 1, 1, 1);
    // 圆柱体 网格模型
    static cylinderGeo = new CylinderGeometry(1, 1, 1, 50, 1, false, 0, Math.PI * 2);
    // 是否是碰撞检测专用的模型
    isEventMesh = true;
    setType(type) {
        switch (type) {
            case EventMesh.type.cube:
                this.geometry = EventMesh.cubeGeo;
                break;
            case EventMesh.type.cylinder:
                this.geometry = EventMesh.cylinderGeo;
                break;
            default:
                break;
        }
        this.geometry.computeVertexNormals();
    }
}
