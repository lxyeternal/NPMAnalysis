import { Camera, Clock, EventDispatcher, Object3D, Vector3 } from "three";
import { Capsule } from "three/examples/jsm/math/Capsule";
import { Octree } from "three/examples/jsm/math/Octree";
/**
 * 第一人称控制器
 *
 * @export
 * @class FPScontrol
 * @extends {EventDispatcher}
 */
export default class FPScontrol extends EventDispatcher {
    canvas: HTMLCanvasElement;
    constructor(camera: Camera, canvas: HTMLCanvasElement);
    enable: boolean;
    GRAVITY: number;
    STEPS_PER_FRAME: number;
    speed: number;
    camera: Camera;
    inertia: boolean;
    octreeMap: Map<number, Octree>;
    octree: Octree;
    addOctree(obj: Object3D): Octree;
    playerCollider: Capsule;
    clock: Clock;
    prePlayerVelocity: Vector3;
    playerVelocity: Vector3;
    jumping: boolean;
    playerDirection: Vector3;
    prePlayerOnFloor: boolean;
    playerOnFloor: boolean;
    mouseTime: number;
    isMousedown: boolean;
    keyStates: {
        [key: string]: boolean;
    };
    init(canvas: HTMLCanvasElement): void;
    keydown: (event: KeyboardEvent) => void;
    keyup: (event: KeyboardEvent) => void;
    mousedown: () => void;
    mouseup: () => void;
    mousemove: (event: MouseEvent) => void;
    getForwardVector: () => Vector3;
    getSideVector: () => Vector3;
    controls: (deltaTime: number) => void;
    updatePlayer: (deltaTime: number) => void;
    playerCollisions(): void;
    teleportPlayerIfOob: () => void;
    update(): void;
    disposer(): void;
}
