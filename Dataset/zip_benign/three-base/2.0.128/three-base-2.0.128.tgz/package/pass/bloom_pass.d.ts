import { WebGLRenderer, Camera, Object3D, DepthTexture, WebGLRenderTarget } from "three";
export default function bloom_pass(renderer: WebGLRenderer, camera: Camera, object3d: Object3D, baseRenderTarget: WebGLRenderTarget, baseDepthTexture: DepthTexture, devicePixelRatio: number): void;
