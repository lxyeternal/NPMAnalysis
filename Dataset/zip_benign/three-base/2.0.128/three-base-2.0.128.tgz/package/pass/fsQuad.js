/*
 * @Author: xiaosihan
 * @Date: 2023-05-09 01:36:35
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2025-01-28 04:04:33
 */
import { BufferGeometry, Float32BufferAttribute, Mesh, MeshBasicMaterial, OrthographicCamera, Scene } from "three";
class FullScreenQuad extends Scene {
    constructor() {
        super();
    }
    mesh = (() => {
        const geometry = new BufferGeometry();
        geometry.setAttribute("position", new Float32BufferAttribute([-1, 3, 0, -1, -1, 0, 3, -1, 0], 3));
        geometry.setAttribute("uv", new Float32BufferAttribute([0, 2, 0, 0, 2, 0], 2));
        const mesh = new Mesh(geometry, new MeshBasicMaterial());
        this.add(mesh);
        return mesh;
    })();
    orthographicCamera = new OrthographicCamera(-1, 1, 1, -1, 0, 1);
    render(renderer, material) {
        this.mesh.material = material;
        renderer.render(this, this.orthographicCamera);
    }
}
// 创建一个渲染工具 用于处理纹理
const fsQuad = new FullScreenQuad(); // 渲染辅助器
export default fsQuad;
