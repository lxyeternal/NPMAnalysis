import { BufferGeometry, Material, Mesh, OrthographicCamera, Scene, WebGLRenderer } from "three";
declare class FullScreenQuad extends Scene {
    constructor();
    mesh: Mesh<BufferGeometry<import("three").NormalBufferAttributes>, Material, import("three").Object3DEventMap>;
    orthographicCamera: OrthographicCamera;
    render(renderer: WebGLRenderer, material: Material): void;
}
declare const fsQuad: FullScreenQuad;
export default fsQuad;
