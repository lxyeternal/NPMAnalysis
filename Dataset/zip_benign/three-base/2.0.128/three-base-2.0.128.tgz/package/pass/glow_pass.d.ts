import { Camera, DepthTexture, Object3D, WebGLRenderer } from "three";
export default function glow_pass(renderer: WebGLRenderer, camera: Camera, object3d: Object3D, baseDepthTexture: DepthTexture, devicePixelRatio: number): void;
