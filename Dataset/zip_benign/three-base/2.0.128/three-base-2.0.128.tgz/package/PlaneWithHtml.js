/*
 * @Author: xiaosihan
 * @Date: 2023-04-15 11:26:32
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2023-04-15 12:38:09
 */
import html2canvas from "html2canvas";
import { CanvasTexture, DoubleSide, Mesh, MeshBasicMaterial, PlaneGeometry, Vector2 } from "three";
import { degToRad } from "three/src/math/MathUtils";
import threeLoader from "./threeLoader";
// html 文本面板
export default class PlaneWithHtml extends Mesh {
    constructor(html = "", backgroundColor = "#00000000") {
        super();
        this.setHtml(html, backgroundColor);
    }
    visible = false;
    size = new Vector2(10, 10);
    geometry = (() => {
        const geometry = new PlaneGeometry(10, 10, 1, 1);
        geometry.rotateX(degToRad(-90));
        return geometry;
    })();
    material = new MeshBasicMaterial({
        side: DoubleSide,
        transparent: true,
        alphaTest: 0.1
    });
    div = (() => {
        const div = document.createElement("div");
        div.style.position = "fixed";
        div.style.top = "100%";
        div.style.left = "100%";
        div.style.pointerEvents = "none";
        div.style.userSelect = "none";
        div.style.lineHeight = "1";
        div.style.whiteSpace = "nowrap";
        return div;
    })();
    // 设置网格尺寸
    setGeoSize(width, height) {
        this.size.set(width, height);
        this.geometry.dispose();
        const geometry = new PlaneGeometry(width, height, 1, 1);
        geometry.rotateX(degToRad(-90));
        this.geometry = geometry;
    }
    async setHtml(html = "", backgroundColor = "#00000000") {
        this.div.innerHTML = html;
        document.body.appendChild(this.div);
        await new Promise((resolve, reject) => {
            html2canvas(this.div, {
                backgroundColor,
                removeContainer: true
            }).then(async (canvas) => {
                this.setGeoSize(canvas.width, canvas.height);
                this.material.map = new CanvasTexture(canvas);
                this.material.map.anisotropy = threeLoader.anisotropy;
                this.material.needsUpdate = true;
                await new Promise(resolve => requestAnimationFrame(resolve));
                this.visible = true;
                this.div.remove();
                resolve();
            });
        });
        this.dispatchEvent({ type: "loaded" });
    }
}
