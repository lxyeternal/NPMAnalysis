import { Mesh, MeshLambertMaterial, PlaneGeometry } from "three";
export default class Grass extends Mesh {
    constructor();
    geometry: PlaneGeometry;
    map: import("three").Texture;
    material: MeshLambertMaterial;
    setSize(width: number, height: number): void;
}
