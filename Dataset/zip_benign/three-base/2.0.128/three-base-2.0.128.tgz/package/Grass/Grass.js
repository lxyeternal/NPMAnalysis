/*
 * @Author: xiaosihan
 * @Date: 2024-09-14 22:58:16
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2024-09-14 23:20:39
 */
import { DoubleSide, MathUtils, Mesh, MeshLambertMaterial, PlaneGeometry, RepeatWrapping, TextureLoader, } from "three";
import grassJPG from "./grass.jpg";
// 草地Mesh
export default class Grass extends Mesh {
    constructor() {
        super();
    }
    geometry = (() => {
        const geometry = new PlaneGeometry(1, 1, 1, 1);
        geometry.rotateX(MathUtils.degToRad(90));
        return geometry;
    })();
    map = (() => {
        const map = new TextureLoader().load(grassJPG);
        map.wrapS = map.wrapT = RepeatWrapping;
        map.repeat.set(1, 1);
        return map;
    })();
    material = (() => {
        const material = new MeshLambertMaterial({
            map: this.map,
            side: DoubleSide,
        });
        return material;
    })();
    // 设置尺寸
    setSize(width, height) {
        this.scale.set(width, 1, height);
        this.map.repeat.set(width, height);
        // this.material.uniforms.size.value.set(width * 0.001, height * 0.001);
    }
}
