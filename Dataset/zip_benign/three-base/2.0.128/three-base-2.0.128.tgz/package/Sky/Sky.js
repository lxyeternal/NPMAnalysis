/*
 * @Author: xiaosihan
 * @Date: 2022-05-20 18:03:58
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2022-12-27 09:54:23
 */
import { DoubleSide, Mesh, MeshBasicMaterial, SphereGeometry } from "three";
import threeLoader from "../threeLoader";
import skyMapPNG from "./skyMap.png";
/**
 * 天空球
 */
export default class Sky extends Mesh {
    constructor() {
        super(Sky.geometry);
    }
    static geometry = new SphereGeometry(5000, 100, 100);
    material = new MeshBasicMaterial({
        side: DoubleSide,
        map: threeLoader.getTexture(skyMapPNG),
    });
}
