import { Mesh, MeshBasicMaterial, SphereGeometry } from "three";
/**
 * 天空球
 */
export default class Sky extends Mesh {
    constructor();
    static geometry: SphereGeometry;
    material: MeshBasicMaterial;
}
