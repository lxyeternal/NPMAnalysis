import { Object3D, Raycaster, Scene, Vector2, WebGLRenderer } from "three";
import { Camera, Intersection, Renderer } from "three";
export interface ThreeMouseEvent extends Intersection {
    e: MouseEvent;
    renderer: Renderer;
    camera: Camera;
    type: string;
    offsetX: number;
    offsetY: number;
    x: number;
    y: number;
}
/**
 *  js 专用的鼠标拾取模型对象
 */
export default class ThreeMouse {
    constructor(renderer: WebGLRenderer, camera: Camera, scene: Scene);
    _renderer: WebGLRenderer;
    _camera: Camera;
    _scene: Scene;
    _mosePosition: Vector2;
    _mouseDownPosition: Vector2;
    _mesh_on?: Object3D;
    _mesh_Down?: Object3D;
    _raycaster: Raycaster;
    _frame: number;
    _mouseInRenderer: boolean;
    _mousemoveEvent?: MouseEvent;
    _mouseEvent?: MouseEvent;
    _object3ds: Object3D[];
    _click_num: number;
    _getSelected(object3ds: Object3D[]): Intersection | undefined;
    hasEvent(object?: Object3D, types?: Array<"leftclick" | "rightclick" | "click" | "dbclick" | "mouseenter" | "mouseleave" | "mousemove" | "mousedown" | "mouseup">): boolean;
    hasCursor(object?: Object3D): boolean;
    dispatchEvent(): void;
    _mouseleave: (e: MouseEvent) => void;
    _mousemove: (e: MouseEvent) => void;
    _mousedown: (e: MouseEvent) => void;
    _mouseup: import("lodash").DebouncedFunc<(e: PointerEvent) => Promise<void>>;
}
