import { EventDispatcher, EventListener, Vector3 } from "three";
/**
 * 键盘 使用 ↑↓←→ 控制 x z 方向, 小键盘 1 0 控制 y 方向
 *
 * @class KeyContorls
 * @extends {EventDispatcher}
 */
declare class KeyContorls extends EventDispatcher {
    constructor();
    uuid: string;
    direction: Vector3;
    add(e: any): void;
    delete(e: any): void;
    enter(e: any): void;
    keyDown: (e: any) => void;
    _listeners?: {
        [key: string]: Array<any>;
    };
    removeEvent: import("lodash").DebouncedFuncLeading<(type: string) => void>;
    addEventListener<T extends string>(type: T, listener: EventListener<{}, T, this>): void;
    addEvent(): void;
    dispose(): void;
}
declare const keyContorls: KeyContorls;
export default keyContorls;
