/*
 * @Author: xiaosihan
 * @Date: 2022-05-18 16:02:55
 * @Last Modified by: xiaosihan
 * @Last Modified time: 2023-05-03 02:55:28
 */
import { Sprite, PointLight as THREEPointLight } from "three";
import threeLoader from "../threeLoader";
import threeUtils from "../threeUtils";
import pointLight_mapPNG from "./pointLight_map.png";
import SpriteText from "../SpriteText";
/**
 * 点光源
 * @export
 * @class PointLight
 * @extends {THREEPointLight}
 */
export default class PointLight extends THREEPointLight {
    constructor(color = "#fff", intensity, distance, decay) {
        super(color, intensity, distance, decay);
    }
    // 灯光辅助器
    pointLinghtHelper = threeUtils.isDev && (() => {
        const pointLinghtHelper = new Sprite();
        pointLinghtHelper.scale.set(0.05, 0.05, 0.05);
        pointLinghtHelper.material.alphaTest = 0.1;
        pointLinghtHelper.material.color = this.color;
        pointLinghtHelper.material.map = threeLoader.getTexture(pointLight_mapPNG);
        pointLinghtHelper.material.sizeAttenuation = false;
        pointLinghtHelper.userData = {
            cursor: "pointer"
        };
        pointLinghtHelper.addEventListener("mouseenter", () => {
            if (this.label) {
                this.label.visible = true;
            }
        });
        pointLinghtHelper.addEventListener("mouseleave", () => {
            if (this.label) {
                this.label.visible = false;
            }
        });
        this.add(pointLinghtHelper);
        return pointLinghtHelper;
    })();
    label = threeUtils.isDev && (() => {
        const label = new SpriteText("点光源\n\n\n");
        label.renderOrder = Infinity;
        // label.backgroundColor = "rgba(0, 0, 0, 0.5)";
        label.padding = 4;
        label.strokeColor = "#333";
        label.strokeWidth = 2;
        // label.borderRadius = 4;
        // label.borderWidth = 1;
        label.position.set(0, 0, 0);
        label.visible = false;
        label.material.color = this.color;
        // label.material.depthTest = false;
        label.material.sizeAttenuation = false;
        label.scale.multiplyScalar(0.002);
        this.add(label);
        return label;
    })();
}
