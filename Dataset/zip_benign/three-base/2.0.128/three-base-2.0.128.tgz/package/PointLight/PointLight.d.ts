import { Sprite, PointLight as THREEPointLight } from "three";
import SpriteText from "../SpriteText";
/**
 * 点光源
 * @export
 * @class PointLight
 * @extends {THREEPointLight}
 */
export default class PointLight extends THREEPointLight {
    constructor(color?: string, intensity?: number, distance?: number, decay?: number);
    pointLinghtHelper: Sprite<import("three").Object3DEventMap>;
    label: SpriteText;
}
