export { default } from "./PointLight";
