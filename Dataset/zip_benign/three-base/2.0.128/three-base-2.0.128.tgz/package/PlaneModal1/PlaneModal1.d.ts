import { Mesh, MeshBasicMaterial, PlaneGeometry } from "three";
export type PlaneModal1Config = {
    size?: number;
    title?: string;
    titleColor?: string;
    texts?: Array<{
        text?: string;
        color?: string;
        size?: number;
    }>;
};
export default class PlaneModal1 extends Mesh {
    constructor(config?: PlaneModal1Config);
    geometry: PlaneGeometry;
    material: MeshBasicMaterial;
    static img: HTMLImageElement;
    canvas: HTMLCanvasElement;
    context: CanvasRenderingContext2D;
    texture: import("three").Texture;
    _config: {
        size: number;
        title: string;
        titleColor: string;
        texts: Array<{
            text: string;
            color: string;
            size: number;
        }>;
    };
    updata(config: PlaneModal1Config): Promise<void>;
}
