import { Box3, BufferGeometry, Clock, EventDispatcher, Material, Object3D, Vector3 } from "three";
declare class ThreeUtils extends EventDispatcher {
    constructor();
    isProd: boolean;
    isDev: boolean;
    _timeTemp: number;
    _accumulate: number;
    _box3: Box3;
    _size: Vector3;
    _center: Vector3;
    _clock: Clock;
    requestAnimationFrame(): void;
    private _keepZoomDoms;
    /**
     *计算需要保持比例的元素
     */
    private _computerDomZoom;
    /**
     * dom元素保持比例
     */
    keepZoom(dom: HTMLElement | null, width?: number, height?: number): void;
    workList: Array<() => void>;
    clock: Clock;
    /**
     * @param {() => void} [callback]
     * @param {boolean} [first=true] 需要优先执行
     */
    addWork(work?: () => void, first?: boolean): void;
    /**
     *判断一个元素是否在页面上
     */
    inDocument(dom: ParentNode | null): boolean;
    getCenter(object3d: Object3D | BufferGeometry): Vector3;
    getSize(object3d: Object3D | BufferGeometry): Vector3;
    alignBottom(object3d: Object3D | BufferGeometry, y?: number): void;
    centerObject3D(object3d: Object3D | BufferGeometry): void;
    center(object3d: Object3D | BufferGeometry): void;
    scaleTo(object3d: Object3D | BufferGeometry, size?: number, key?: Array<"x" | "y" | "z">): void;
    applyAllTranstion(object3d: Object3D): void;
    exportGLB(input: Object3D, fileName?: string, maxTextureSize?: number): void;
    exportUsdz(): void;
    getVolume(geometry: BufferGeometry): number;
    signedVolumeOfTriangle(p1: Vector3, p2: Vector3, p3: Vector3): number;
    dipose(object3d: Object3D): void;
    getSuffix(filename: string): string;
    getFilename(url: string): string;
    fileToBloburl(file: File): Promise<string>;
    toMeshBasicMaterial<P extends Material | Material[]>(material: P): P;
    toMeshLambertMaterial<P extends Material | Material[]>(material: P): P;
}
declare const threeUtils: ThreeUtils;
export default threeUtils;
