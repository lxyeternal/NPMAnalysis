import { BufferGeometry, Camera, Group, Material, Matrix4, Mesh, PerspectiveCamera, Plane, PlaneGeometry, Scene, ShaderMaterial, Vector3, Vector4, WebGLRenderTarget, WebGLRenderer } from "three";
export default class Mirror extends Mesh {
    constructor(geometry?: BufferGeometry);
    static geometry: PlaneGeometry;
    isReflector: boolean;
    type: string;
    camera: PerspectiveCamera;
    reflectorPlane: Plane;
    normal: Vector3;
    reflectorWorldPosition: Vector3;
    cameraWorldPosition: Vector3;
    rotationMatrix: Matrix4;
    lookAtPosition: Vector3;
    clipPlane: Vector4;
    view: Vector3;
    target: Vector3;
    q: Vector4;
    textureMatrix: Matrix4;
    virtualCamera: PerspectiveCamera;
    renderTarget: WebGLRenderTarget<import("three").Texture>;
    material: ShaderMaterial;
    onBeforeRender: (renderer: WebGLRenderer, scene: Scene, camera: Camera, geometry: BufferGeometry, material: Material, group: Group) => void;
    getRenderTarget(): WebGLRenderTarget<import("three").Texture>;
    dispose(): void;
}
