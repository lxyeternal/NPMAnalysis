import { BufferGeometry, Camera, Clock, Group, Material, Matrix4, Mesh, PlaneGeometry, Scene, ShaderMaterial, WebGLRenderer } from "three";
export default class Ground1 extends Mesh {
    tempMatrix: Matrix4;
    constructor();
    renderOrder: number;
    geometry: PlaneGeometry;
    setSize(width: number, height: number): void;
    clock: Clock;
    onBeforeRender: (renderer: WebGLRenderer, scene: Scene, camera: Camera, geometry: BufferGeometry, material: Material, group: Group) => void;
    material: ShaderMaterial;
}
