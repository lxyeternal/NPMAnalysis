import { Sprite } from "three";
export default class SpriteWithHtml extends Sprite {
    constructor(html?: string, backgroundColor?: `#${string}`);
    visible: boolean;
    div: HTMLDivElement;
    setHtml(html?: string, backgroundColor?: `#${string}`): Promise<void>;
}
