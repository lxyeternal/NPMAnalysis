import { EventDispatcher, Material, Texture, TextureLoader } from "three";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";
import { MTLLoader } from "three/examples/jsm/loaders/MTLLoader";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader";
import { STLLoader } from "three/examples/jsm/loaders/STLLoader";
import { USDZLoader } from "three/examples/jsm/loaders/USDZLoader";
import { PLYLoader } from "three/examples/jsm/Addons.js";
declare class ThreeLoader extends EventDispatcher {
    constructor();
    getFilename(url: string): string;
    uuid: string;
    anisotropy: number;
    setAnisotropy(v: number): void;
    textureMap: Map<string, Texture>;
    textureLoader: TextureLoader;
    getTexture(src: string | HTMLCanvasElement): Texture;
    _blobs: {
        [key: string]: string;
    };
    fbxLoader: FBXLoader;
    objLoader: OBJLoader;
    stlLoader: STLLoader;
    plyLoader: PLYLoader;
    mtlLoader: MTLLoader;
    gltfLoader: GLTFLoader;
    usdzLoader: USDZLoader;
    setFlipYIsFalse<T extends Material | Material[]>(material: T): void;
    /** 加载模型支持glb,gltf,fbx,stl,obj,usdz,dae,zip */
    loadModel(url: string | File | Array<File>, filename?: string): any;
    onload: boolean;
}
declare const threeLoader: ThreeLoader;
export default threeLoader;
