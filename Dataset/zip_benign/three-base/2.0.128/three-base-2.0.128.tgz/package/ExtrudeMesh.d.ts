import { BufferGeometry, Material, Matrix4, Mesh, Vector2, Vector3 } from "three";
export type ExtrudePath = {
    vector3: [number, number, number];
    radius: number;
    segments: number;
    scale: {
        x: number;
        y: number;
    };
    name: string;
};
export interface ExtrudeMeshProps {
    paths: Array<ExtrudePath>;
    shapePath: Array<[number, number]>;
    closed: boolean;
}
/**
 * 挤出模型
 * 此组件适合自动生成 公路 河流山川等 2d 平面上的模型
 *
 * @export
 * @class ExtrudeMesh
 * @extends {Mesh<BufferGeometry, Material>}
 */
export default class ExtrudeMesh extends Mesh<BufferGeometry, Material> {
    static temp1Vector2: Vector2;
    static temp2Vector2: Vector2;
    static temp3Vector2: Vector2;
    static tempVector3: Vector3;
    static temp1Vector3: Vector3;
    static temp2Vector3: Vector3;
    static temp3Vector3: Vector3;
    static temp1Matrix4: Matrix4;
    static temp2Matrix4: Matrix4;
    static temp3Matrix4: Matrix4;
    constructor(props: ExtrudeMeshProps, material?: Material);
    shapePathWidth: number;
    pointerWidthRadius: Array<{
        vector3: [number, number, number];
        matrix: [
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number
        ];
    }>;
    computerMatrix(vector1: [number, number, number], vector2: [number, number, number], scale: [number, number, number]): [number, number, number, number, number, number, number, number, number, number, number, number, number, number, number, number];
    /**
     * @计算渐变值 computerGradient([3,2,4], 0.3);
     * @渐变区间 values:number[]
     * @百分比 percentage:number
     */
    computerGradient(values: number[], percentage: number): number;
    computerPointerWidthRadius(paths: Array<ExtrudePath>, closed: boolean): void;
    computerPathLength(points: [number, number, number][]): number;
    setExtrudeMesh(startP: [number, number, number], // 起点位置
    startMatrix4: [
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number
    ], // 起点位置的矩阵
    endP: [number, number, number], // 终点位置
    endMatrix4: [
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number,
        number
    ], // 终点位置的矩阵
    uvx: number, // uv.x 的起始位置
    shapePath: Array<[number, number]>): {
        geometryPoint: number[];
        uvPoint: number[];
    };
    updateGeometry(props: ExtrudeMeshProps): void;
}
