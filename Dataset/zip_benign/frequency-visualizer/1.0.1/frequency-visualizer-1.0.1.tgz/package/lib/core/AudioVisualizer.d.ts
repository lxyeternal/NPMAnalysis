import { AudioVisualizerOptions } from '../types';
export declare class AudioVisualizer {
    private audioContext;
    private analyser;
    private source;
    private animationId;
    private canvas;
    private ctx;
    private audioElement;
    options: AudioVisualizerOptions;
    private hueOffset;
    private lastFrameTime;
    private static readonly DEFAULT_OPTIONS;
    constructor(canvas: HTMLCanvasElement, options?: Partial<AudioVisualizerOptions>, audioElement?: HTMLAudioElement);
    private initAudio;
    private setupEventListeners;
    start(): void;
    stop(): void;
    private draw;
    private getColor;
    private drawSmoothEqualizer;
    private drawBarsEqualizer;
    updateOptions(newOptions: Partial<AudioVisualizerOptions>): void;
    connectToMicrophone(): Promise<void>;
    connectToAudioNode(node: AudioNode): void;
}
