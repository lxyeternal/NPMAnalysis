import type { Adapter } from '@sveltejs/kit';
/**
 * Details about a page in the sitemap.
 *
 * Any of these can be left undefined to skip that property for this page in
 * the sitemap.
 *
 * @see {@link https://www.sitemaps.org | sitemaps.org} for further details.
 * Some of the documentation here is copied from there.
 */
export type PageDetails = {
    /**
     * When the page was last modified.
     *
     * Should be in {@link https://www.w3.org/TR/NOTE-datetime | W3C Datetime}
     * format, which is a subset of ISO8601.
     */
    lastmod?: string | undefined;
    /**
     * Priority of this page relative to others on the site.
     *
     * Valid values range from 0.0 to 1.0. This value does not affect how your
     * pages are compared to pages on other sites—it only lets the search
     * engines know which pages you deem most important for the crawlers.
     */
    priority?: number | undefined;
    /**
     * How frequently the page is likely to change.
     *
     * This value provides general information to search engines and may not
     * correlate exactly to how often they crawl the page.
     *
     * The value `'always'` should be used to describe documents that change
     * each time they are accessed. The value `'never'` should be used to
     * describe archived URLs.
     */
    changefreq?: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never' | undefined;
    /**
     * The hook will be called for each generating page URL.
     * It should return custom xml markup.
     */
    hook?(pageUrl: string): string;
};
/**
 * Configuration options for sitemap generation.
 */
export type Options = {
    /**
     * The origin (eg. `https://your.site`) to use to build urls.
     *
     * @defaultValue `kit.prerender.origin` from your SvelteKit config.
     * It will usually be better to configure the origin there instead of here.
     */
    origin: string;
    /**
     * The file to write the sitemap to.
     *
     * @defaultValue `sitemap.xml`.
     */
    sitemapFile: string;
    /**
     * Default options to use for all pages.
     *
     * @defaultValue
     * ```ts
     * {
     * 	lastmod: new Date().toISOString(),
     * 	changefreq: 'monthly',
     * 	priority: 0.5,
     * }
     * ```
     *
     * To remove a field from the sitemap, set the value to `undefined`. The
     * field can still be introduced for a specific page in `pages`.
     *
     * @see {@link PageDetails} for documentation of the available fields.
     */
    defaults: PageDetails;
    /**
     * Details for specific pages.
     *
     * Can be used to force extra pages to be included in the sitemap, or to
     * set specific properties on a page.
     *
     * The keys are the paths to the pages. For instance `/` or `/posts/1`.
     *
     * To remove a specific field for only this page, set the value to
     * `undefined`.
     *
     * @example
     * ```ts
     * {
     * 	pages: {
     * 		'/': {
     * 			priority: 1,
     * 			changefreq: 'daily'
     * 		},
     * 		// Explicitly included since it is not prerendered
     * 		'/dynamic': {}
     * 	}
     * }
     * ```
     *
     * @see {@link PageDetails} for documentation of the available fields.
     */
    pages: Record<string, Partial<PageDetails>>;
};
/**
 * This function is the entry point for sveltekit-static-sitemap. It takes a
 * SvelteKit adapter and returns a wrapped version which will retrieve a
 * sitemap together with the static assets.
 *
 * The sitemap is dynamically generated based on the prerendered pages from
 * SvelteKit. The `static` part in the name of this package comes from the
 * fact that the sitemap is only generated at compile-time.
 *
 * See the `options` argument for how to add more pages.
 *
 *
 * @param adapter - The SvelteKit adapter to wrap with sitemap generation.
 *
 * The sitemap will be provided to the adapter together with other static
 * assets and prerendered pages.
 *
 *
 * @param options - Configuration of the sitemap.
 *
 * The `defaults` key defines the default values for each url in the sitemap.
 *
 * The `pages` key defines values for specific pages, and can be used to
 * include extra urls in the sitemap. To include a new page with default values
 * it is sufficient to let the value be `{}`.
 *
 * See the documentation of {@link Options | the options object} for complete
 * details.
 *
 *
 * @returns An adapter which generates a sitemap and internally uses the
 * provided adapter from the first argument. This wrapped adapter will appear
 * as `<adapter> + sitemap` in SvelteKit, where `<adapter>` is the name of the
 * original adapter.
 *
 *
 *  * @example
 * ```ts
 * {
 *   kit: {
 *     adapter: sitemapWrapAdapter(adapter())
 *   }
 * }
 * ```
 */
export declare function sitemapWrapAdapter(adapter: Adapter, options?: Partial<Options>): Adapter;
