type UrlDefinition = {
    loc: string;
    lastmod?: string | undefined;
    priority?: number | undefined;
    changefreq?: string | undefined;
    hook?(pageUrl: string): string;
};
export declare function renderSitemap(pages: UrlDefinition[]): string;
export {};
