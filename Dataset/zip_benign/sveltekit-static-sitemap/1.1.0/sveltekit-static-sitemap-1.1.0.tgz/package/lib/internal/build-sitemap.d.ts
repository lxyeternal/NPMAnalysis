import type { Builder } from '@sveltejs/kit';
import type { Options } from '../index.js';
export declare function buildPageEntries(paths: Iterable<string>, options: Options): {
    lastmod?: string | undefined;
    priority?: number | undefined;
    changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never" | undefined;
    hook?: (pageUrl: string) => string;
    loc: string;
}[];
export declare function buildSitemap(builder: Builder, options: Options, dest: string): string[];
