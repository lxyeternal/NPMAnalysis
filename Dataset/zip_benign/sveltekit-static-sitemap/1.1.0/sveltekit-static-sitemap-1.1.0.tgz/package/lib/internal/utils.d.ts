type AnyFunction = (...args: any) => any;
type PrefixParameter<F extends (...args: any) => any, This, Parameter> = (this: This, original: Parameter, ...parameters: Parameters<F>) => ReturnType<F>;
export type OptionalFunctionsWithOriginal<T> = {
    [K in keyof T]?: T[K] extends AnyFunction ? PrefixParameter<T[K], T, T[K]> : never;
};
export declare function isFunction(func: unknown): func is (...args: unknown[]) => unknown;
type Truthy = <T>(object: T | false | undefined) => object is T;
export declare const truthy: Truthy;
export declare function truthyEntries<T extends Record<string, unknown>>(object: T): { [K in keyof T]-?: [K, T[K]]; }[keyof T][];
/**
 * Trim the size of the margin on the first line from every line.
 */
export declare function trimMargin(text: string): string;
export {};
