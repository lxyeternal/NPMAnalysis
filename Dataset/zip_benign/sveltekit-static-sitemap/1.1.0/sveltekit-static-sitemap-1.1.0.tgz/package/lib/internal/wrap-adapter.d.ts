import type { Adapter, Builder } from '@sveltejs/kit';
import { type OptionalFunctionsWithOriginal } from './utils.js';
type BuilderWrap = OptionalFunctionsWithOriginal<Builder> & {
    /**
     * Hook into the adapter's adapt function.
     *
     * This method is called right before the original adapt function is called.
     *
     * The Builder instance is available as `this`.
     */
    adapt?: (this: Builder) => void;
};
/**
 * Wrap an existing adapter and adapt the behaviour of the builder
 */
export declare function wrapAdapter(adapter: Adapter, nameTemplate: string, builderWrap: BuilderWrap): Adapter;
export {};
