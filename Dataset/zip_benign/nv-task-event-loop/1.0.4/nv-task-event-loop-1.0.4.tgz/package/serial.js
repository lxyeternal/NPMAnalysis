const {
   noexist,
   STATE_LABEL_DICT,
   ////
   sym_rs,
   sym_rj,
   sym_exec,
   sym_pause,
   sym_continue,
   sym_reset,
   sym_respawn,
   sym_rdy,
   sym_launch, 
   DFLT_CU_EXECUTOR,
   DFLT_EXEC_WRAP,
   DFLT_RECV,
   ERROR,
   ////
   Base
} = require("nv-task-event-basic");




class Sloop extends Base {
    #history = []
    #max_history_size = 1
    get max_history_size_() {return(this.#max_history_size)}
    set max_history_size_(v) {this.#max_history_size = Math.max(1,v)}
    get history_() {return(this.#history)}
    ////
    append(name,o,Cls=Base) {
        let chnd;
        if(o instanceof Function) {
            let forest = this.$forest_;
            chnd = forest.node(Cls);
            chnd.exec_ = o;
            this.$append_child(chnd)
        } else {
            chnd = this.$append_child(o)
        }
        chnd.name = name;
        if(this.is_pending()) {
            if(chnd.$is_lonely()) {
                chnd[sym_rdy]();
                chnd[sym_launch]();
            } else {}
        } else {}
    }
    ////
    start() {
        this[sym_rdy]();
        let fstch = this.$fstch_;
        if(fstch!==null) { 
            fstch[sym_rdy]()
        } else {}
        this[sym_launch]();
        if(fstch!==null) {
            fstch[sym_launch]()
        } else {}
    }
    get curr_pending_tsk_() {
        let children = this.$children_;
        for(let chnd of children) {
            if(chnd.is_pending()) {
                return(chnd)
            } else {}
        }
        return(null)
    }
    get curr_paused_tsk_() {
        if(this.is_paused()) {
            let children = this.$children_;
            for(let chnd of children) {
                if(chnd.is_paused()) {
                    return(chnd)
                } else {}
            }
            return(this)
        } else {
            return(null)
        }
    }    
    pause() {
        if(this.is_pending()) {
            let chnd = this.curr_pending_tsk_;
            if(chnd!==null) {
                chnd[sym_pause]();
                let nchnd = chnd[sym_respawn]();
                nchnd.name = chnd.name;
                nchnd[sym_rdy]();
                nchnd[sym_launch]();
                nchnd[sym_pause]();
            } else {
            }
            this[sym_pause]();
        } else {

        }
    }
    continue() {
        if(this.is_paused()) {
            let chnd = this.curr_paused_tsk_;
            if(chnd!==null) {
                if(chnd === this) {
                    let fstch = this.$fstch_;
                    if(fstch!==null) {
                        if(fstch.is_rejected()) {
                            src[sym_reset]();
                            src[sym_rdy]();
                            src[sym_launch]();
                        } else {
                            console.log('impossible')
                        }
                    } else {
                    }
                } else {
                    chnd[sym_continue]()
                }
                this[sym_continue]()
            } else {
                console.log('impossible')
            }
        } else {}
    }
    ////
    get lefted_() {return(this.$children_)}
}

const Forest = require("nv-data-tree-csp-forest");

function creat_sloop(max_history_size=10,forest,max_size=10000,rtrn_forest=true) {
    forest = forest??(new Forest(max_size));
    let sloop = forest.node(Sloop);
    sloop.max_history_size_ = max_history_size;
    sloop.regis_$recv$(
        (src,self)=> {
            ////
            if(src.is_resolved() || src.is_rejected()) {
                self.history_.push(src);
                if(self.history_.length>self.max_history_size_) {
                    self.history_.shift();
                } else {}
                let rsib = src.$rsib_;
                if(rsib!==null) {
                    if(rsib.is_rejected()) {
                        rsib[sym_reset]();
                        rsib[sym_rdy]();
                        rsib[sym_launch]();
                    } else if(rsib.is_resolved()) {
                        console.log('impossible:rsib.is_resolved')
                    } else {
                        rsib[sym_rdy]();
                        rsib[sym_launch]();
                    }
                } else {
                    //new round
                    let fstch = self.$fstch_;
                    if(fstch !==null) {
                        if(fstch.is_rejected()) {
                            fstch[sym_reset]();
                            fstch[sym_rdy]();
                            fstch[sym_launch]();
                        } else if(fstch.is_resolved()) {
                            if(fstch === src) {
                                //skip
                            } else {
                                console.log('impossible:fstch.is_resolved')
                            }
                        } else {
                            fstch[sym_rdy]();
                            fstch[sym_launch]();
                        }
                    } else {}
                }
                if(src.is_resolved()) {
                    src.$disconn();
                } else {}
            } else {
                console.log('impossible:not-settled')
            }
        }
    );
    if(rtrn_forest) {
        return([sloop,forest])
    } else {
        return(sloop)
    }
}


module.exports = creat_sloop;

