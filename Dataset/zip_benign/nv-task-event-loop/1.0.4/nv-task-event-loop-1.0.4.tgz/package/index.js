const {creat_serial_loop}   = require("./serial");
const {creat_parallel_loop} = require("./parallel");


const {
    creat_serial_loop,
    creat_parallel_loop,
}
