const {
   noexist,
   STATE_LABEL_DICT,
   ////
   sym_rs,
   sym_rj,
   sym_exec,
   sym_pause,
   sym_continue,
   sym_reset,
   sym_respawn,
   sym_rdy,
   sym_launch, 
   DFLT_CU_EXECUTOR,
   DFLT_EXEC_WRAP,
   DFLT_RECV,
   ERROR,
   ////
   Base
} = require("nv-task-event-basic");




class Ploop extends Base {
    ////
    add(name,o,Cls=Base) {
        let chnd;
        if(o instanceof Function) {
            let forest = this.$forest_;
            chnd = forest.node(Cls);
            chnd.exec_ = o;
            this.$append_child(chnd)
        } else {
            chnd = this.$append_child(o)
        }
        chnd.name = name;
        if(this.is_pending()) {
            chnd[sym_rdy]();
            chnd[sym_launch]();
        } else {}
    }
    ////
    start() {
        this[sym_rdy]();
        let children = this.$children_;
        children.forEach(chnd=>chnd[sym_rdy]());
        ////
        this[sym_launch]();
        children.forEach(chnd=>chnd[sym_launch]());
    }
    pause() {
        if(this.is_pending()) {
            let children = this.$children_;
            children = children.filter(chnd=>chnd.is_pending() || chnd.is_rejected());
            children.forEach(chnd=>{
                chnd[sym_pause]();
                let nchnd = chnd[sym_respawn]();
                nchnd.name = chnd.name;
                nchnd[sym_rdy]();
                nchnd[sym_launch]();
                nchnd[sym_pause]();
            });
            children = this.$children_;
            this[sym_pause]()
        } else {

        }
    }
    continue() {
        if(this.is_paused()) {
            let children = this.$children_;
            children = children.filter(chnd=>chnd.is_paused());
            children.forEach(chnd=>chnd[sym_continue]());
            this[sym_continue]()
        } else {}
    }
    ////
    get lefted_() {return(this.$children_)}
}

const Forest = require("nv-data-tree-csp-forest");

function creat_ploop(forest,max_size=10000,rtrn_forest=true) {
    forest = forest??(new Forest(max_size));
    let ploop = forest.node(Ploop);
    ploop.regis_$recv$(
        (src,self)=> {
            ////
            if(src.is_resolved()) {
                src.$disconn();
            } else if(src.is_rejected()) {
                src[sym_reset]();
                src[sym_rdy]();
                src[sym_launch]();
            } else {
                console.log('impossible')
            }
        }
    );
    if(rtrn_forest) {
        return([ploop,forest])
    } else {
        return(ploop)
    }
}


module.exports = creat_ploop;

