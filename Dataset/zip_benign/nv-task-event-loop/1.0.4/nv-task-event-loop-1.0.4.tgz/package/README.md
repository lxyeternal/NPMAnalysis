nv-task-event-loop
============
- nv-task-event-loop 
- simple-loop running until all tasks success


install
=======
- npm install nv-task-event-loop

usage
=====

example
-------

### parallel

     const {creat_ploop} = require("nv-task-event-loop")

    var [ploop,forest] = creat_ploop()
    
    
    
    function tsk(rs,rj,self) {
        console.log(self.name,"start:",new Date())
        setTimeout(
            () => {
                let cond =  (Math.random() >0.5)?true:false;
                if(cond) {
                     console.log(self.name,"succ:",new Date())
                    rs(Math.random())
                } else {
                    console.log(self.name,"fail:",new Date())
                    rj(Math.random())
                }
            },
            Math.random()*10000 + 2000
        )
    }
    
    
    ploop.add("t0",tsk)
    ploop.add("t1",tsk)
    ploop.add("t2",tsk)
    ploop.add("t3",tsk)
    
    
    > ploop.$sdfs_
    [
      Ploop [1 %d1d7c4ad:1% ] {},
      Base [2 %d1d7c4ad:2% ] {},
      Base [3 %d1d7c4ad:3% ] {},
      Base [4 %d1d7c4ad:4% ] {},
      Base [5 %d1d7c4ad:5% ] {}
    ]
    >
    
    ploop.start()
    >
    t0 start: 2021-11-28T10:43:23.418Z
    t1 start: 2021-11-28T10:43:23.418Z
    t2 start: 2021-11-28T10:43:23.419Z
    t3 start: 2021-11-28T10:43:23.419Z
    
    > t3 succ: 2021-11-28T10:43:26.360Z
    t2 fail: 2021-11-28T10:43:28.069Z
    Uncaught 0.9377473180908764
    > t2 start: 2021-11-28T10:43:28.077Z
    t2 fail: 2021-11-28T10:43:30.684Z
    Uncaught 0.6864665600383024
    > t2 start: 2021-11-28T10:43:30.690Z
    t1 succ: 2021-11-28T10:43:31.986Z
    t0 succ: 2021-11-28T10:43:33.250Z
    t2 succ: 2021-11-28T10:43:35.453Z
    
    > ploop.$sdfs_
    [ Ploop [1 %8a1501d4:1% ] {} ]
    >
    
    
    ploop.add("t4",tsk)
    t4 start: 2021-11-28T10:44:09.914Z
    > t4 succ: 2021-11-28T10:44:13.400Z


           ploop.add("t5",tsk)
           ploop.add("t6",tsk)
           ploop.add("t7",tsk)
           ploop.add("t8",tsk)
           
           > t8 succ: 2021-11-28T11:56:08.026Z
           t6 succ: 2021-11-28T11:56:09.034Z
           
           ploop.pause()
           
           > ploop.$sdfs_
           [
             Ploop [1 %33ad3d8f:1% ] {},
             Base [14 %33ad3d8f:14% ] { name: 't5'},
             Base [15 %33ad3d8f:15% ] { name: 't7'}
           ]
           >
           
           t5 start: 2021-11-28T11:57:10.168Z
           t7 start: 2021-11-28T11:57:10.168Z
           undefined
           > t7 fail: 2021-11-28T11:57:12.341Z
           Base [15 %33ad3d8f:15% ] { name: 't7'}
           t7 start: 2021-11-28T11:57:12.345Z
           Uncaught 0.8067136495847074
           > t5 fail: 2021-11-28T11:57:12.611Z
           Base [14 %33ad3d8f:14% ] { name: 't5'}
           t5 start: 2021-11-28T11:57:12.614Z
           Uncaught 0.9457326949590821
           > t7 succ: 2021-11-28T11:57:16.558Z
           Base [15 %33ad3d8f:15% ] { name: 't7'}
           t5 fail: 2021-11-28T11:57:18.550Z
           Base [14 %33ad3d8f:14% ] { name: 't5' }
           t5 start: 2021-11-28T11:57:18.551Z
           Uncaught 0.6334435325094092
           > t5 fail: 2021-11-28T11:57:24.162Z
           Base [14 %33ad3d8f:14% ] { name: 't5' }
           t5 start: 2021-11-28T11:57:24.163Z
           Uncaught 0.5462425557406225
           > t5 succ: 2021-11-28T11:57:29.638Z
           Base [14 %33ad3d8f:14% ] { name: 't5'}
           
           >
           > ploop.$sdfs_
           [ Ploop [1 %33ad3d8f:1% ] {} ]
           >





### serial

     const {creat_sloop} = require("nv-task-event-loop")

        var [sloop,forest] = creat_sloop()
        
        
        
        function tsk(rs,rj,self) {
            console.log(self.name,"start:",new Date())
            setTimeout(
                () => {
                    let cond =  (Math.random() >0.5)?true:false;
                    if(cond) {
                         console.log(self.name,"succ:",new Date())
                        rs(Math.random())
                    } else {
                        console.log(self.name,"fail:",new Date())
                        rj(Math.random())
                    }
                },
                Math.random()*10000 + 2000
            )
        }
        
        sloop.append('t0',tsk)
        sloop.append('t1',tsk)
        sloop.append('t2',tsk)
        sloop.append('t3',tsk)
        
        > sloop.$sdfs_
        [
          Sloop [1 %8a478ae0:1% ] {},
          Base [2 %8a478ae0:2% ] { name: 't0' },
          Base [3 %8a478ae0:3% ] { name: 't1' },
          Base [4 %8a478ae0:4% ] { name: 't2' },
          Base [5 %8a478ae0:5% ] { name: 't3' }
        ]

           > sloop.start()
           t0 start: 2021-11-28T12:47:04.080Z
           undefined
           > t0 succ: 2021-11-28T12:47:10.862Z
           t1 start: 2021-11-28T12:47:10.865Z
           
           > t1 fail: 2021-11-28T12:47:14.998Z
           t2 start: 2021-11-28T12:47:15.001Z
           Uncaught 0.03766741199616952
           > t2 succ: 2021-11-28T12:47:18.500Z
           t3 start: 2021-11-28T12:47:18.501Z
           
           > sloop.history_
           [
             Base [2 %134f4119:2% ] { name: 't0' },
             Base [3 %134f4119:3% ] { name: 't1' },
             Base [4 %134f4119:4% ] { name: 't2' }
           ]
           > t3 fail: 2021-11-28T12:47:28.235Z
           t1 start: 2021-11-28T12:47:28.237Z
           Uncaught 0.7733557460726412
           > sloop.t1 fail: 2021-11-28T12:47:37.725Z
           t3 start: 2021-11-28T12:47:37.727Z
           Uncaught 0.22587428091340156
           > sloop.$sdfs_
           [
             Sloop [1 %134f4119:1% ] {},
             Base [3 %134f4119:3% ] { name: 't1' },
             Base [5 %134f4119:5% ] { name: 't3' }
           ]
           > t3 succ: 2021-11-28T12:47:48.713Z
           t1 start: 2021-11-28T12:47:48.715Z
           
           > t1 succ: 2021-11-28T12:47:52.615Z
           undefined
           > sloop.$sdfs_
           [ Sloop [1 %134f4119:1% ] {} ]

         sloop.append('t4',tsk)
         t4 start: 2021-11-28T13:02:35.788Z
         > t4 fail: 2021-11-28T13:02:42.063Z
         t4 start: 2021-11-28T13:02:42.064Z
         Uncaught 0.967356516505113
         > t4 fail: 2021-11-28T13:02:51.727Z
         t4 start: 2021-11-28T13:02:51.728Z
         Uncaught 0.44575593589624285
         > t4 fail: 2021-11-28T13:02:59.898Z
         t4 start: 2021-11-28T13:02:59.899Z
         Uncaught 0.3339230914494107
         > t4 succ: 2021-11-28T13:03:11.244Z
         
         >
         
         sloop.append('t5',tsk)
         sloop.append('t6',tsk)
         sloop.append('t7',tsk)
         sloop.append('t8',tsk)
         
         t5 succ: 2021-11-28T13:04:24.811Z
         t6 start: 2021-11-28T13:04:24.813Z
         sloop.pause()
         > sloop.$sdfs_.map(r=>r.state_)
        [ Symbol(paused), Symbol(paused), Symbol(init), Symbol(init) ]
        >
        > sloop.$sdfs_
        [
          Sloop [1 %d17eb72e:1% ] {},
          Base [11 %d17eb72e:11% ] { name: 't6' },
          Base [9 %d17eb72e:9% ] { name: 't7' },
          Base [10 %d17eb72e:10% ] { name: 't8' }
        ]
        >
         > sloop.continue()
         t6 start: 2021-11-28T13:06:08.702Z
         undefined
         > t6 fail: 2021-11-28T13:06:11.066Z
         t7 start: 2021-11-28T13:06:11.068Z
         Uncaught 0.28002167582813486
         > t7 fail: 2021-11-28T13:06:19.158Z
         t8 start: 2021-11-28T13:06:19.159Z
         Uncaught 0.7690404739981405
         > t8 fail: 2021-11-28T13:06:30.440Z
         t6 start: 2021-11-28T13:06:30.441Z
         Uncaught 0.6015427168849683
         > t6 succ: 2021-11-28T13:06:39.316Z
         t7 start: 2021-11-28T13:06:39.317Z
         
         > sloop.$sdfs_
         [
           Sloop [1 %d17eb72e:1% ] {},
           Base [9 %d17eb72e:9% ] { name: 't7' },
           Base [10 %d17eb72e:10% ] { name: 't8' }
         ]
         > t7 fail: 2021-11-28T13:06:51.253Z
         t8 start: 2021-11-28T13:06:51.255Z
         Uncaught 0.34902555913841415
         > t8 succ: 2021-11-28T13:07:00.086Z
         t7 start: 2021-11-28T13:07:00.087Z
         
         > sloop.$sdfs_
         [ Sloop [1 %d17eb72e:1% ] {}, Base [9 %d17eb72e:9% ] { name: 't7' } ]
         > t7 fail: 2021-11-28T13:07:05.210Z
         t7 start: 2021-11-28T13:07:05.211Z
         Uncaught 0.8291153904570607
         > sloop.$sdfs_t7 succ: 2021-11-28T13:07:13.078Z
         
         [ Sloop [1 %d17eb72e:1% ] {} ]
         >
         
          sloop.append('t9',tsk)
         > sloop.append('t9',tsk)
         t9 start: 2021-11-28T13:07:51.439Z
         undefined
         > t9 fail: 2021-11-28T13:07:55.871Z
         t9 start: 2021-11-28T13:07:55.872Z
         Uncaught 0.4758705378679222
         > t9 succ: 2021-11-28T13:08:02.955Z
         
         >


        > sloop.history_
        [
          Base [11 %d17eb72e:11% ] { name: 't6' },
          Base [9 %d17eb72e:9% ] { name: 't7' },
          Base [10 %d17eb72e:10% ] { name: 't8' },
          Base [11 %d17eb72e:11% ] { name: 't6' },
          Base [9 %d17eb72e:9% ] { name: 't7' },
          Base [10 %d17eb72e:10% ] { name: 't8' },
          Base [9 %d17eb72e:9% ] { name: 't7' },
          Base [9 %d17eb72e:9% ] { name: 't7' },
          Base [12 %d17eb72e:12% ] { name: 't9' },
          Base [12 %d17eb72e:12% ] { name: 't9' }
        ]
        > sloop.max_history_size_
        10


APIS
====

- creat\_ploop(forest,max\_size,rtrn\_forest=true)
- creat\_ploop(max\_history\_size=10,forest,max\_size,rtrn\_forest=true)

LICENSE
=======
- ISC 
