// 判断是否为空，false：不为空
function isEmpty(sprite) {
  if (!!sprite && !!sprite.visible && !!sprite.imgObj && !!sprite.imgObj.src) {
    return false;
  }
  return true;
}

let util = {
  getSprite(sprites, row, col) {
    let sprite = sprites.filter(s => s.row == row && s.col == col)[0];
    if (!sprite) {
      // 没有精灵，返回一个默认空精灵
      sprite = this.root.renderEmpty(row, col);
    }
    return sprite;
  },
  getSpriteRows(sprites, row) {
    return sprites.filter(s => s.row == row);
  },
  getDir(point1, point2) {
    // "zuoshang"
    if (point1.row == point2.row) {
      // 同一行
      return "hengxian";
    } else if (point1.col == point2.col) {
      // 同一列
      return "shuxian";
    } else {
      // 转角
      if (point1.row > point2.row) {
        // point1 在 point2 下面
        if (point1.col > point2.col) {
          // point1 在 point2 右下面
          return "left_bottom";
        } else {
          // point1 在 point2 左下边
          return "right_bottom";
        }
      } else {
        // point1 在 point2 上面
        if (point1.col > point2.col) {
          // point1 在 point2 右上面
          return "left_top";
        } else {
          // point1 在 point2 左上边
          return "right_top";
        }
      }
    }
  },
  getBothDir(startOrEndPoint, point2) {
    if (startOrEndPoint.row == point2.row) {
      // 同一行
      if (startOrEndPoint.col < point2.col) {
        // 线条从右边出去
        return "to_right";
      } else {
        // 线条从左边出去
        return "to_left";
      }
    } else {
      // 同一列
      if (startOrEndPoint.row < point2.row) {
        // 线条从下面出去
        return "to_down";
      } else {
        // 线条从上面出去
        return "to_up";
      }
    }
  },
  getSpriteCols(sprites, col) {
    return sprites.filter(s => s.col == col);
  },
  MatchBolck(sprites, _beginPoint, _endPoint) {
    // 放一个空对象，代表转折点（空说明没有转折点，是一条直线）
    let points = [];
    // 如果不属于0折连接则返回false
    if (_beginPoint.col != _endPoint.col && _beginPoint.row != _endPoint.row) {
      return false;
    }
    let min, max;

    // 如果两点的row坐标相等，则在水平方向上扫描
    if (_beginPoint.row == _endPoint.row) {
      min = Math.min(_beginPoint.col, _endPoint.col);
      max = Math.max(_beginPoint.col, _endPoint.col);
      for (min++; min < max; min++) {
        if (!isEmpty(this.getSprite(sprites, _beginPoint.row, min))) {
          return false;
        } else {
          points.push({ row: _beginPoint.row, col: min, dir: "hengxian" });
        }
      }
    } else {
      // 如果两点的col坐标相等，则在竖直方向上扫描
      min = Math.min(_beginPoint.row, _endPoint.row);
      max = Math.max(_beginPoint.row, _endPoint.row);
      for (min++; min < max; min++) {
        if (!isEmpty(this.getSprite(sprites, min, _beginPoint.col))) {
          return false;
        } else {
          points.push({ row: min, col: _beginPoint.col, dir: "shuxian" });
        }
      }
    }
    return points;
  },
  MatchBolckOne(sprites, _beginPoint, _endPoint) {
    let points = [];//返回数组第一个为转角
    // 如果不属于1折连接则返回null
    if (_beginPoint.row == _endPoint.row || _beginPoint.col == _endPoint.col) { return null; }

    // 测试对角点1
    let pt1 = this.getSprite(sprites, _beginPoint.row, _endPoint.col);
    let pt2 = this.getSprite(sprites, _endPoint.row, _beginPoint.col);
    if (!isEmpty(pt1) && !isEmpty(pt2)) { return null; }

    if (isEmpty(pt1)) {
      let tArr1 = this.MatchBolck(sprites, pt1, _beginPoint);
      let tArr2 = this.MatchBolck(sprites, pt1, _endPoint);
      if (tArr1 && tArr2) {
        // pt1连接成功
        points.push(Object.assign({ dir: this.getDir(_beginPoint, _endPoint) }, pt1));
        tArr1.forEach(item => { points.push(item) })
        tArr2.forEach(item => { points.push(item) })
        return points;
      }
    }
    if (isEmpty(pt2)) {
      let tArr1 = this.MatchBolck(sprites, pt2, _beginPoint);
      let tArr2 = this.MatchBolck(sprites, pt2, _endPoint);
      if (tArr1 && tArr2) {
        // pt2连接成功
        points.push(Object.assign({ dir: this.getDir(_endPoint, _beginPoint) }, pt2));
        tArr1.forEach(item => { points.push(item) })
        tArr2.forEach(item => { points.push(item) })
        return points;
      }
    }

    return null;
  },
  MatchBolckTwo(sprites, _beginPoint, _endPoint) {
    let list = [];

    // 判断2折连接
    this.checkTwoCommon(list, sprites, _beginPoint, _endPoint, _beginPoint.col + 1, this.getSpriteRows(sprites, _beginPoint.row).length, true);
    // 右侧
    if (list.length > 0) { return list; }

    this.checkTwoCommon(list, sprites, _beginPoint, _endPoint, _beginPoint.col - 1, -1, true);
    // 左侧 --------
    if (list.length > 0) { return list; }

    this.checkTwoCommon(list, sprites, _beginPoint, _endPoint, _beginPoint.row + 1, this.getSpriteCols(sprites, _beginPoint.col).length);
    // 下
    if (list.length > 0) { return list; }

    this.checkTwoCommon(list, sprites, _beginPoint, _endPoint, _beginPoint.row - 1, -1);
    // 上 --------------
    if (list.length > 0) { return list; }

    return null;
  },
  checkTwoCommon(list, sprites, _beginPoint, _endPoint, start, end, isBl) {
    let min = start, max = end, step = 1;
    if (min < max) {
      step = 1;
    } else {
      step = -1;
    }
    for (let i = min; step > 0 ? i <= max : i >= max; i += step) {
      let tempSprite;
      if (isBl) {
        tempSprite = this.getSprite(sprites, _beginPoint.row, i);
      } else {
        tempSprite = this.getSprite(sprites, i, _beginPoint.col);
      }
      if (isEmpty(tempSprite)) {
        let dest = this.MatchBolckOne(sprites, tempSprite, _endPoint);
        let tt = this.MatchBolck(sprites, tempSprite, _beginPoint);
        if (!!dest && !!tt) {
          // 开始点转角
          if (isBl) {
            list.push(Object.assign({ dir: this.getDir(_beginPoint, dest[0]) }, tempSprite));
          } else {
            list.push(Object.assign({ dir: this.getDir(dest[0], _beginPoint) }, tempSprite));
          }
          // 开始点到转角的直接
          this.MatchBolck(sprites, tempSprite, _beginPoint).forEach(item => { list.push(item); })
          // 开始点转角到结束点转角的直线
          this.MatchBolck(sprites, tempSprite, dest[0]).forEach(item => { list.push(item); })
          // 结束点转角
          list.push(Object.assign({}, dest[0]));
          // 结束点转角到结束点直线
          this.MatchBolck(sprites, _endPoint, dest[0]).forEach(item => { list.push(item); })
          return list;
        }
      }
    }
  },
  isEqure(sprite1, sprite2) {
    if (!sprite1 || !sprite2) { return false; }
    if (!sprite1.visible || !sprite2.visible) { return false; }
    if (sprite1.imgObj.src == sprite2.imgObj.src) { return true; }
    return false;
  },
  getRoundPoint(points, point) {
    let tempPoint;
    points.forEach(item => {
      if (item.col == point.col) {
        if (Math.abs(item.row - point.row) == 1) {
          tempPoint = Object.assign({ dir: this.getBothDir(point, item) }, point);
        }
      } else if (item.row == point.row) {
        if (Math.abs(item.col - point.col) == 1) {
          tempPoint = Object.assign({ dir: this.getBothDir(point, item) }, point);
        }
      }
    })
    points.push(tempPoint);
  },
  checkPointFun(arr, _begin, _end, root) {
    this.root = root;
    let pointArr = null;
    if (!this.isEqure(_begin, _end)) { return false; }
    var islink = this.MatchBolck(arr, _begin, _end);
    if (!pointArr && islink) {
      pointArr = islink;
    }
    if (!pointArr) {
      islink = this.MatchBolckOne(arr, _begin, _end);
      if (islink) {
        pointArr = islink;
      } else {
        islink = this.MatchBolckOne(arr, _end, _begin);
        if (islink) {
          pointArr = islink;
        }
      }
    }
    if (!pointArr) {
      islink = this.MatchBolckTwo(arr, _begin, _end);
      if (islink) {
        pointArr = islink;
      } else {
        islink = this.MatchBolckTwo(arr, _end, _begin);
        if (islink) {
          pointArr = islink;
        }
      }
    }

    if (!pointArr) {
      return false;
    } else {
      if (pointArr.length > 0) {
        this.getRoundPoint(pointArr, _begin);
        this.getRoundPoint(pointArr, _end);
      } else {
        // 起点和终点挨着
        pointArr.push(Object.assign({ dir: this.getBothDir(_begin, _end) }, _begin))
        pointArr.push(Object.assign({ dir: this.getBothDir(_end, _begin) }, _end))
      }
      return pointArr;
    }
  },
}

export {
  util
}