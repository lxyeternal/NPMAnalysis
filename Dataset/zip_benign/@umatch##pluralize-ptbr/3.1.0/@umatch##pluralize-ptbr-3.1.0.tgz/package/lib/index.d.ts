import { ordinal } from './ordinal';
export { ordinal };
/**
 * Returns the plural form of the word.
 *
 * The word is only pluralized if quantity is undefined or not 1. Uses
 * the custom plural form if provided.
 *
 * *Warning*: expects single or compound words, not whole sentences.
 * @throws {Error} if splitting the string by spaces or dashes produces more than 3 words.
 */
export declare function plural(word: string, quantity?: number, customPlural?: string): string;
//# sourceMappingURL=index.d.ts.map