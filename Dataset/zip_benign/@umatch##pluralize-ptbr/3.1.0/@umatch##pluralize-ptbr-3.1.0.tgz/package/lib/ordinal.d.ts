export declare function ordinal(num: number): string;
//# sourceMappingURL=ordinal.d.ts.map