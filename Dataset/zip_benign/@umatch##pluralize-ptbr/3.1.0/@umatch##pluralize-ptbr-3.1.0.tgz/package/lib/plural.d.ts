/**
 * Returns the plural of a string, which can be a single or a
 * compound word.
 *
 * @throws {Error} if splitting the string by spaces or dashes produces more than 3 words.
 */
export declare function getPluralForm(string: string): string;
//# sourceMappingURL=plural.d.ts.map