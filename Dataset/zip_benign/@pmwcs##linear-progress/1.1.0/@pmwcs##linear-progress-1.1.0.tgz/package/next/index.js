function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

import { h, Fragment } from 'preact';
import { memo } from 'preact/compat';
import { useLinearProgressFoundation } from './foundation';
import { Tag, useClassNames, createComponent } from '@pmwcs/base';
/** A component to display linear progress. */

export const LinearProgress = createComponent(function LinearProgress(props, ref) {
  const {
    reversed,
    closed,
    progress,
    buffer,
    secondary,
    foundationRef,
    ...rest
  } = props;
  const className = useClassNames(props, ['mdc-linear-progress', {
    'mdc-linear-progress--reversed': reversed,
    'mdc-linear-progress--closed': closed,
    'mdc-linear-progress--secondary': secondary
  }]);
  const {
    rootEl
  } = useLinearProgressFoundation(props);
  return h(Tag, _extends({
    "aria-label": "Progress Bar"
  }, rest, {
    "aria-valuemin": 0,
    "aria-valuemax": 1,
    "aria-valuenow": progress,
    tag: "nav",
    role: "progressbar",
    element: rootEl,
    className: className,
    ref: ref
  }), h(LinearProgressBody, null));
});
const LinearProgressBody = memo(function LinearProgressBody() {
  return h(Fragment, null, h("div", {
    className: "mdc-linear-progress__buffer"
  }, h("div", {
    className: "mdc-linear-progress__buffer-bar"
  }), h("div", {
    className: "mdc-linear-progress__buffer-dots"
  })), h("div", {
    className: "mdc-linear-progress__bar mdc-linear-progress__primary-bar"
  }, h("span", {
    className: "mdc-linear-progress__bar-inner"
  })), h("div", {
    className: "mdc-linear-progress__bar mdc-linear-progress__secondary-bar"
  }, h("span", {
    className: "mdc-linear-progress__bar-inner"
  })));
});