import { useEffect, useState } from 'preact/hooks';
import { MDCLinearProgressFoundation } from '@material/linear-progress';
import { useFoundation } from '@pmwcs/base';
export const useLinearProgressFoundation = props => {
  const {
    foundation,
    ...elements
  } = useFoundation({
    props,
    elements: {
      rootEl: true
    },
    foundation: ({
      rootEl
    }) => {
      return new MDCLinearProgressFoundation({
        addClass: className => rootEl.addClass(className),
        forceLayout: () => {
          var _rootEl$ref;

          return (_rootEl$ref = rootEl.ref) === null || _rootEl$ref === void 0 ? void 0 : _rootEl$ref.offsetWidth;
        },
        hasClass: className => rootEl.hasClass(className),
        removeClass: className => rootEl.removeClass(className),
        setPrimaryBarStyle: (styleProperty, value) => {
          var _rootEl$ref2;

          const el = ((_rootEl$ref2 = rootEl.ref) === null || _rootEl$ref2 === void 0 ? void 0 : _rootEl$ref2.querySelector(MDCLinearProgressFoundation.strings.PRIMARY_BAR_SELECTOR)) || null;
          el && (el.style[styleProperty] = value);
        },
        setBufferBarStyle: (styleProperty, value) => {
          var _rootEl$ref3;

          const el = ((_rootEl$ref3 = rootEl.ref) === null || _rootEl$ref3 === void 0 ? void 0 : _rootEl$ref3.querySelector(MDCLinearProgressFoundation.strings.BUFFER_BAR_SELECTOR)) || null;
          el && (el.style[styleProperty] = value);
        }
      });
    }
  });
  const [determinate, setDeterminate] = useState(undefined); // progress and determinate

  useEffect(() => {
    foundation.setProgress(props.progress || 0);
    const isDeterminate = props.progress !== undefined;

    if (isDeterminate !== determinate) {
      foundation.setDeterminate(isDeterminate);
      setDeterminate(isDeterminate);
    }
  }, [props.progress, determinate, foundation]); // buffer

  useEffect(() => {
    foundation.setBuffer(props.buffer || 0);
  }, [props.buffer, foundation]); // reversed

  useEffect(() => {
    foundation.setReverse(!!props.reversed);
  }, [props.reversed, foundation]); // closed

  useEffect(() => {
    props.closed ? foundation.close() : foundation.open();
  }, [props.closed, foundation]);
  return {
    foundation,
    ...elements
  };
};