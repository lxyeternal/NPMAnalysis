import { Injectable, ɵɵdefineInjectable, EventEmitter, Component, ViewEncapsulation, ViewChild, Input, Output, Directive, HostListener, NgModule } from '@angular/core';
import { Subject } from 'rxjs';
import { faPowerOff } from '@fortawesome/free-solid-svg-icons';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

/**
 * @fileoverview added by tsickle
 * Generated from: lib/screen-res.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ScreenResService = /** @class */ (function () {
    function ScreenResService() {
        this.resizeSubject = new Subject();
    }
    /**
     * @param {?} window
     * @return {?}
     */
    ScreenResService.prototype.onResize = /**
     * @param {?} window
     * @return {?}
     */
    function (window) {
        this.resizeSubject.next(window);
    };
    ScreenResService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    /** @nocollapse */
    ScreenResService.ctorParameters = function () { return []; };
    /** @nocollapse */ ScreenResService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ScreenResService_Factory() { return new ScreenResService(); }, token: ScreenResService, providedIn: "root" });
    return ScreenResService;
}());
if (false) {
    /** @type {?} */
    ScreenResService.prototype.resizeSubject;
    /** @type {?} */
    ScreenResService.prototype.windowProperties;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/screen-res.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ScreenResComponent = /** @class */ (function () {
    function ScreenResComponent(screenRes) {
        this.screenRes = screenRes;
        this.chosen = 'fas fa-power-off';
        this.largeStyle = {};
        this.titleStyle = {};
        this.captionStyle = {};
        this.linkStyle = {};
        this.faCoffee = faPowerOff;
        this.linkColour = 'white';
        this.isTitle = false;
        this.isCaption = false;
        this.isButton = false;
        this.titleText = '';
        this.buttonSize = 'lg';
        this.height = 90;
        this.captionText = "You matter a lot";
        this.width = 90;
        this.fontFamilyCaption = '"Courier New", Courier, monospace';
        this.fontSizeCaption = 2;
        this.fontColourCaption = 'white';
        this.fontFamily = '"Courier New", Courier, monospace';
        this.fontSize = 4;
        this.fontColour = 'white';
        this.buttonClick = new EventEmitter();
    }
    /**
     * @return {?}
     */
    ScreenResComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var ratio = window.innerWidth / window.innerHeight;
        if (ratio >= 0.4 && ratio < 0.5) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image0 + '")';
        }
        else if (ratio >= 0.5 && ratio < 0.58) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image1 + '")';
            // Add to 0.7
        }
        else if (ratio >= 0.7 && ratio < 0.78) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image2 + '")';
            // Add to 1.3
        }
        else if (ratio >= 1.3 && ratio < 1.4) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image3 + '")';
            // Add to 1.7
        }
        else if (ratio >= 1.7 && ratio < 1.8) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image4 + '")';
        }
        else if (ratio >= 1.8 && ratio < 1.9) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image5 + '")';
        }
        else if (ratio >= 1.9) {
            this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image6 + '")';
        }
        this.largeStyle = { 'min-height': this.height + 'vh', 'min-width': this.width + 'vw',
            'background-repeat': 'no-repeat',
            'background-size': 100 + '%'
        };
        this.titleStyle = {
            'font-family': this.fontFamily,
            'font-size': this.fontSize + 'rem',
            'color': this.fontColour
        };
        this.captionStyle = {
            'font-family': this.fontFamilyCaption,
            'font-size': this.fontSizeCaption + 'rem',
            'color': this.fontColourCaption
        };
        this.linkStyle = {
            'color': this.linkColour
        };
        // this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image1 + '")';
        this.screenRes.resizeSubject.subscribe((/**
         * @param {?} result
         * @return {?}
         */
        function (result) {
            ratio = result.width / result.height;
            if (ratio >= 0.4 && ratio < 0.5) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image0 + '")';
            }
            else if (ratio >= 0.5 && ratio < 0.6) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image1 + '")';
            }
            else if (ratio >= 0.7 && ratio < 0.8) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image2 + '")';
            }
            else if (ratio >= 1.3 && ratio < 1.4) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image3 + '")';
            }
            else if (ratio >= 1.7 && ratio < 1.8) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image4 + '")';
            }
            else if (ratio >= 1.8 && ratio < 1.9) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image5 + '")';
            }
            else if (ratio >= 1.9) {
                _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image6 + '")';
            }
            console.log((result.width / result.height).toFixed(2));
            console.log(result);
        }));
        //  this.controlledContent = this.originalContent = this.content.nativeElement.textContent;
        console.log(this.name1);
        console.log(this.Image1);
    };
    /**
     * @param {?} value
     * @return {?}
     */
    ScreenResComponent.prototype.markText = /**
     * @param {?} value
     * @return {?}
     */
    function (value) {
        console.log(value);
    };
    ScreenResComponent.decorators = [
        { type: Component, args: [{
                    selector: 'nk-screen-res',
                    template: "<!-- <input type=\"text\" (keydown.enter)=\"markText($event.target.value)\">\r\n<div  [hidden]=\"true\">\r\n    <ng-content ></ng-content>\r\n</div>\r\n\r\n<div [innerHTML]=\"controlledContent\"></div>\r\n\r\n<p nkScreenRes >This is a message</p> -->\r\n<div  [ngStyle]=\"largeStyle\" #content nkScreenRes>\r\n    <div fxLayout=\"column\" style=\"width:100%; height: 100vh;\" fxLayoutAlign=\"center center\">\r\n        <section *ngIf=\"isTitle\">\r\n            <h1 style=\"margin-bottom:0px;\" [ngStyle]=\"titleStyle\" #title>\r\n                {{titleText}}\r\n            </h1>\r\n        </section>\r\n        <section  *ngIf=\"isCaption\">\r\n            <h4 style=\"margin-top:0; margin-bottom: 0; text-align: center;\" [ngStyle]=\"captionStyle\" #caption>\r\n                {{captionText}}</h4>\r\n        </section>\r\n        <section *ngIf=\"isButton\">\r\n            <a [ngStyle]=\"linkStyle\" (click)=\"buttonClick.emit()\">\r\n                <span></span>\r\n                <span></span>\r\n                <span></span>\r\n                <span></span>\r\n                <fa-icon [icon]=\"faCoffee\" [size]=\"buttonSize\"></fa-icon>\r\n            </a>\r\n        </section>\r\n    </div>\r\n</div>",
                    encapsulation: ViewEncapsulation.None,
                    styles: ["@import url(https://fonts.googleapis.com/css?family=Montserrat:900|Paytone+One|Raleway:900&display=swap);@import url(https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css);.main{font-family:'Courier New',Courier,monospace}.wallpaper{background-repeat:no-repeat;background-size:100%}.main-text{font-family:'Franklin Gothic Medium','Arial Narrow',Arial,sans-serif;font-size:4rem;color:#fff}a{position:relative;z-index:1000;display:inline-block;padding:15px 30px;color:#fff;text-transform:uppercase;letter-spacing:4px;text-decoration:none;font-size:24px;overflow:hidden;border-radius:50%;-webkit-transition:.2s;transition:.2s}a:hover{color:#255784;background:#2196f3;box-shadow:0 0 10px #2196f3,0 0 40px #2196f3,0 0 80px #2196f3}"]
                }] }
    ];
    /** @nocollapse */
    ScreenResComponent.ctorParameters = function () { return [
        { type: ScreenResService }
    ]; };
    ScreenResComponent.propDecorators = {
        content: [{ type: ViewChild, args: ['content', null,] }],
        title: [{ type: ViewChild, args: ['title', null,] }],
        captionReference: [{ type: ViewChild, args: ['caption', null,] }],
        name1: [{ type: Input }],
        chosen: [{ type: Input }],
        Image0: [{ type: Input }],
        Image1: [{ type: Input }],
        Image2: [{ type: Input }],
        Image3: [{ type: Input }],
        Image4: [{ type: Input }],
        Image5: [{ type: Input }],
        isTitle: [{ type: Input }],
        isCaption: [{ type: Input }],
        isButton: [{ type: Input }],
        titleText: [{ type: Input }],
        buttonSize: [{ type: Input }],
        Image6: [{ type: Input }],
        height: [{ type: Input }],
        captionText: [{ type: Input }],
        width: [{ type: Input }],
        fontFamilyCaption: [{ type: Input }],
        fontSizeCaption: [{ type: Input }],
        fontColourCaption: [{ type: Input }],
        fontFamily: [{ type: Input }],
        fontSize: [{ type: Input }],
        fontColour: [{ type: Input }],
        buttonClick: [{ type: Output }]
    };
    return ScreenResComponent;
}());
if (false) {
    /** @type {?} */
    ScreenResComponent.prototype.content;
    /** @type {?} */
    ScreenResComponent.prototype.title;
    /** @type {?} */
    ScreenResComponent.prototype.captionReference;
    /** @type {?} */
    ScreenResComponent.prototype.name1;
    /** @type {?} */
    ScreenResComponent.prototype.chosen;
    /** @type {?} */
    ScreenResComponent.prototype.largeStyle;
    /** @type {?} */
    ScreenResComponent.prototype.titleStyle;
    /** @type {?} */
    ScreenResComponent.prototype.captionStyle;
    /** @type {?} */
    ScreenResComponent.prototype.linkStyle;
    /** @type {?} */
    ScreenResComponent.prototype.originalContent;
    /** @type {?} */
    ScreenResComponent.prototype.controlledContent;
    /** @type {?} */
    ScreenResComponent.prototype.faCoffee;
    /** @type {?} */
    ScreenResComponent.prototype.linkColour;
    /** @type {?} */
    ScreenResComponent.prototype.Image0;
    /** @type {?} */
    ScreenResComponent.prototype.Image1;
    /** @type {?} */
    ScreenResComponent.prototype.Image2;
    /** @type {?} */
    ScreenResComponent.prototype.Image3;
    /** @type {?} */
    ScreenResComponent.prototype.Image4;
    /** @type {?} */
    ScreenResComponent.prototype.Image5;
    /** @type {?} */
    ScreenResComponent.prototype.isTitle;
    /** @type {?} */
    ScreenResComponent.prototype.isCaption;
    /** @type {?} */
    ScreenResComponent.prototype.isButton;
    /** @type {?} */
    ScreenResComponent.prototype.titleText;
    /** @type {?} */
    ScreenResComponent.prototype.buttonSize;
    /** @type {?} */
    ScreenResComponent.prototype.Image6;
    /** @type {?} */
    ScreenResComponent.prototype.height;
    /** @type {?} */
    ScreenResComponent.prototype.captionText;
    /** @type {?} */
    ScreenResComponent.prototype.width;
    /** @type {?} */
    ScreenResComponent.prototype.fontFamilyCaption;
    /** @type {?} */
    ScreenResComponent.prototype.fontSizeCaption;
    /** @type {?} */
    ScreenResComponent.prototype.fontColourCaption;
    /** @type {?} */
    ScreenResComponent.prototype.fontFamily;
    /** @type {?} */
    ScreenResComponent.prototype.fontSize;
    /** @type {?} */
    ScreenResComponent.prototype.fontColour;
    /** @type {?} */
    ScreenResComponent.prototype.buttonClick;
    /**
     * @type {?}
     * @private
     */
    ScreenResComponent.prototype.screenRes;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/screen-res.directive.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ScreenResDirective = /** @class */ (function () {
    function ScreenResDirective(screenRes) {
        this.screenRes = screenRes;
        this.windowSize = { height: 0, width: 0 };
    }
    /**
     * @param {?} event
     * @return {?}
     */
    ScreenResDirective.prototype.onResizing = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.windowSize = {
            height: window.innerHeight,
            width: window.innerWidth
        };
        this.screenRes.onResize(this.windowSize);
        // this.windowEvent.emit();
    };
    /**
     * @return {?}
     */
    ScreenResDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.windowSize = {
            height: window.innerHeight,
            width: window.innerWidth
        };
    };
    ScreenResDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[nkScreenRes]'
                },] }
    ];
    /** @nocollapse */
    ScreenResDirective.ctorParameters = function () { return [
        { type: ScreenResService }
    ]; };
    ScreenResDirective.propDecorators = {
        onResizing: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
    };
    return ScreenResDirective;
}());
if (false) {
    /** @type {?} */
    ScreenResDirective.prototype.innerwidth;
    /** @type {?} */
    ScreenResDirective.prototype.innerheight;
    /** @type {?} */
    ScreenResDirective.prototype.windowSize;
    /**
     * @type {?}
     * @private
     */
    ScreenResDirective.prototype.screenRes;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/screen-res.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ScreenResModule = /** @class */ (function () {
    function ScreenResModule() {
    }
    ScreenResModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [ScreenResComponent, ScreenResDirective],
                    imports: [
                        CommonModule,
                        FlexLayoutModule,
                        FontAwesomeModule
                    ],
                    exports: [ScreenResComponent]
                },] }
    ];
    return ScreenResModule;
}());

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: ck-screen-res.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { ScreenResComponent, ScreenResDirective, ScreenResModule, ScreenResService };
//# sourceMappingURL=ck-screen-res.js.map
