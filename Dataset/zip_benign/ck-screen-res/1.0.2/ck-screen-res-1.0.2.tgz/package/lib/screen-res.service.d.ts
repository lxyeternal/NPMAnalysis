import { WindowModel } from './Models/window.model';
import { Subject } from 'rxjs';
export declare class ScreenResService {
    resizeSubject: Subject<WindowModel>;
    windowProperties: WindowModel;
    constructor();
    onResize(window: WindowModel): void;
}
