export declare class ScreenResModule {
}
