import { WindowModel } from './Models/window.model';
import { ScreenResService } from './screen-res.service';
import { OnInit } from '@angular/core';
export declare class ScreenResDirective implements OnInit {
    private screenRes;
    innerwidth: any;
    innerheight: any;
    windowSize: WindowModel;
    constructor(screenRes: ScreenResService);
    onResizing(event: any): void;
    ngOnInit(): void;
}
