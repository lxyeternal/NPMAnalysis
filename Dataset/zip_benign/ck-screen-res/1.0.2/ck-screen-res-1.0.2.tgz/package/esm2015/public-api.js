/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of screen-res
 */
export { ScreenResService } from './lib/screen-res.service';
export { ScreenResComponent } from './lib/screen-res.component';
export { ScreenResDirective } from './lib/screen-res.directive';
export { ScreenResModule } from './lib/screen-res.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL2NrLXNjcmVlbi1yZXMvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBSUEsaUNBQWMsMEJBQTBCLENBQUM7QUFDekMsbUNBQWMsNEJBQTRCLENBQUM7QUFDM0MsbUNBQWMsNEJBQTRCLENBQUM7QUFDM0MsZ0NBQWMseUJBQXlCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogUHVibGljIEFQSSBTdXJmYWNlIG9mIHNjcmVlbi1yZXNcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9zY3JlZW4tcmVzLnNlcnZpY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc2NyZWVuLXJlcy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc2NyZWVuLXJlcy5kaXJlY3RpdmUnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc2NyZWVuLXJlcy5tb2R1bGUnO1xuIl19