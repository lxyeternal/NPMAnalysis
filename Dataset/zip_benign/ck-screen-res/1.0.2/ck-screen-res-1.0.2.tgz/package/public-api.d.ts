export * from './lib/screen-res.service';
export * from './lib/screen-res.component';
export * from './lib/screen-res.directive';
export * from './lib/screen-res.module';
