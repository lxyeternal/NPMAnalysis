(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('rxjs'), require('@fortawesome/free-solid-svg-icons'), require('@angular/common'), require('@angular/flex-layout'), require('@fortawesome/angular-fontawesome')) :
    typeof define === 'function' && define.amd ? define('ck-screen-res', ['exports', '@angular/core', 'rxjs', '@fortawesome/free-solid-svg-icons', '@angular/common', '@angular/flex-layout', '@fortawesome/angular-fontawesome'], factory) :
    (global = global || self, factory(global['ck-screen-res'] = {}, global.ng.core, global.rxjs, global.freeSolidSvgIcons, global.ng.common, global.ng['flex-layout'], global.angularFontawesome));
}(this, (function (exports, core, rxjs, freeSolidSvgIcons, common, flexLayout, angularFontawesome) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/screen-res.service.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ScreenResService = /** @class */ (function () {
        function ScreenResService() {
            this.resizeSubject = new rxjs.Subject();
        }
        /**
         * @param {?} window
         * @return {?}
         */
        ScreenResService.prototype.onResize = /**
         * @param {?} window
         * @return {?}
         */
        function (window) {
            this.resizeSubject.next(window);
        };
        ScreenResService.decorators = [
            { type: core.Injectable, args: [{
                        providedIn: 'root'
                    },] }
        ];
        /** @nocollapse */
        ScreenResService.ctorParameters = function () { return []; };
        /** @nocollapse */ ScreenResService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function ScreenResService_Factory() { return new ScreenResService(); }, token: ScreenResService, providedIn: "root" });
        return ScreenResService;
    }());
    if (false) {
        /** @type {?} */
        ScreenResService.prototype.resizeSubject;
        /** @type {?} */
        ScreenResService.prototype.windowProperties;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/screen-res.component.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ScreenResComponent = /** @class */ (function () {
        function ScreenResComponent(screenRes) {
            this.screenRes = screenRes;
            this.chosen = 'fas fa-power-off';
            this.largeStyle = {};
            this.titleStyle = {};
            this.captionStyle = {};
            this.linkStyle = {};
            this.faCoffee = freeSolidSvgIcons.faPowerOff;
            this.linkColour = 'white';
            this.isTitle = false;
            this.isCaption = false;
            this.isButton = false;
            this.titleText = '';
            this.buttonSize = 'lg';
            this.height = 90;
            this.captionText = "You matter a lot";
            this.width = 90;
            this.fontFamilyCaption = '"Courier New", Courier, monospace';
            this.fontSizeCaption = 2;
            this.fontColourCaption = 'white';
            this.fontFamily = '"Courier New", Courier, monospace';
            this.fontSize = 4;
            this.fontColour = 'white';
            this.buttonClick = new core.EventEmitter();
        }
        /**
         * @return {?}
         */
        ScreenResComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var ratio = window.innerWidth / window.innerHeight;
            if (ratio >= 0.4 && ratio < 0.5) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image0 + '")';
            }
            else if (ratio >= 0.5 && ratio < 0.58) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image1 + '")';
                // Add to 0.7
            }
            else if (ratio >= 0.7 && ratio < 0.78) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image2 + '")';
                // Add to 1.3
            }
            else if (ratio >= 1.3 && ratio < 1.4) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image3 + '")';
                // Add to 1.7
            }
            else if (ratio >= 1.7 && ratio < 1.8) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image4 + '")';
            }
            else if (ratio >= 1.8 && ratio < 1.9) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image5 + '")';
            }
            else if (ratio >= 1.9) {
                this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image6 + '")';
            }
            this.largeStyle = { 'min-height': this.height + 'vh', 'min-width': this.width + 'vw',
                'background-repeat': 'no-repeat',
                'background-size': 100 + '%'
            };
            this.titleStyle = {
                'font-family': this.fontFamily,
                'font-size': this.fontSize + 'rem',
                'color': this.fontColour
            };
            this.captionStyle = {
                'font-family': this.fontFamilyCaption,
                'font-size': this.fontSizeCaption + 'rem',
                'color': this.fontColourCaption
            };
            this.linkStyle = {
                'color': this.linkColour
            };
            // this.content.nativeElement.style.background = 'no-repeat center/100% url("' + this.Image1 + '")';
            this.screenRes.resizeSubject.subscribe((/**
             * @param {?} result
             * @return {?}
             */
            function (result) {
                ratio = result.width / result.height;
                if (ratio >= 0.4 && ratio < 0.5) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image0 + '")';
                }
                else if (ratio >= 0.5 && ratio < 0.6) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image1 + '")';
                }
                else if (ratio >= 0.7 && ratio < 0.8) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image2 + '")';
                }
                else if (ratio >= 1.3 && ratio < 1.4) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image3 + '")';
                }
                else if (ratio >= 1.7 && ratio < 1.8) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image4 + '")';
                }
                else if (ratio >= 1.8 && ratio < 1.9) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image5 + '")';
                }
                else if (ratio >= 1.9) {
                    _this.content.nativeElement.style.background = 'no-repeat center/100% url("' + _this.Image6 + '")';
                }
                console.log((result.width / result.height).toFixed(2));
                console.log(result);
            }));
            //  this.controlledContent = this.originalContent = this.content.nativeElement.textContent;
            console.log(this.name1);
            console.log(this.Image1);
        };
        /**
         * @param {?} value
         * @return {?}
         */
        ScreenResComponent.prototype.markText = /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            console.log(value);
        };
        ScreenResComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'nk-screen-res',
                        template: "<!-- <input type=\"text\" (keydown.enter)=\"markText($event.target.value)\">\r\n<div  [hidden]=\"true\">\r\n    <ng-content ></ng-content>\r\n</div>\r\n\r\n<div [innerHTML]=\"controlledContent\"></div>\r\n\r\n<p nkScreenRes >This is a message</p> -->\r\n<div  [ngStyle]=\"largeStyle\" #content nkScreenRes>\r\n    <div fxLayout=\"column\" style=\"width:100%; height: 100vh;\" fxLayoutAlign=\"center center\">\r\n        <section *ngIf=\"isTitle\">\r\n            <h1 style=\"margin-bottom:0px;\" [ngStyle]=\"titleStyle\" #title>\r\n                {{titleText}}\r\n            </h1>\r\n        </section>\r\n        <section  *ngIf=\"isCaption\">\r\n            <h4 style=\"margin-top:0; margin-bottom: 0; text-align: center;\" [ngStyle]=\"captionStyle\" #caption>\r\n                {{captionText}}</h4>\r\n        </section>\r\n        <section *ngIf=\"isButton\">\r\n            <a [ngStyle]=\"linkStyle\" (click)=\"buttonClick.emit()\">\r\n                <span></span>\r\n                <span></span>\r\n                <span></span>\r\n                <span></span>\r\n                <fa-icon [icon]=\"faCoffee\" [size]=\"buttonSize\"></fa-icon>\r\n            </a>\r\n        </section>\r\n    </div>\r\n</div>",
                        encapsulation: core.ViewEncapsulation.None,
                        styles: ["@import url(https://fonts.googleapis.com/css?family=Montserrat:900|Paytone+One|Raleway:900&display=swap);@import url(https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css);.main{font-family:'Courier New',Courier,monospace}.wallpaper{background-repeat:no-repeat;background-size:100%}.main-text{font-family:'Franklin Gothic Medium','Arial Narrow',Arial,sans-serif;font-size:4rem;color:#fff}a{position:relative;z-index:1000;display:inline-block;padding:15px 30px;color:#fff;text-transform:uppercase;letter-spacing:4px;text-decoration:none;font-size:24px;overflow:hidden;border-radius:50%;-webkit-transition:.2s;transition:.2s}a:hover{color:#255784;background:#2196f3;box-shadow:0 0 10px #2196f3,0 0 40px #2196f3,0 0 80px #2196f3}"]
                    }] }
        ];
        /** @nocollapse */
        ScreenResComponent.ctorParameters = function () { return [
            { type: ScreenResService }
        ]; };
        ScreenResComponent.propDecorators = {
            content: [{ type: core.ViewChild, args: ['content', null,] }],
            title: [{ type: core.ViewChild, args: ['title', null,] }],
            captionReference: [{ type: core.ViewChild, args: ['caption', null,] }],
            name1: [{ type: core.Input }],
            chosen: [{ type: core.Input }],
            Image0: [{ type: core.Input }],
            Image1: [{ type: core.Input }],
            Image2: [{ type: core.Input }],
            Image3: [{ type: core.Input }],
            Image4: [{ type: core.Input }],
            Image5: [{ type: core.Input }],
            isTitle: [{ type: core.Input }],
            isCaption: [{ type: core.Input }],
            isButton: [{ type: core.Input }],
            titleText: [{ type: core.Input }],
            buttonSize: [{ type: core.Input }],
            Image6: [{ type: core.Input }],
            height: [{ type: core.Input }],
            captionText: [{ type: core.Input }],
            width: [{ type: core.Input }],
            fontFamilyCaption: [{ type: core.Input }],
            fontSizeCaption: [{ type: core.Input }],
            fontColourCaption: [{ type: core.Input }],
            fontFamily: [{ type: core.Input }],
            fontSize: [{ type: core.Input }],
            fontColour: [{ type: core.Input }],
            buttonClick: [{ type: core.Output }]
        };
        return ScreenResComponent;
    }());
    if (false) {
        /** @type {?} */
        ScreenResComponent.prototype.content;
        /** @type {?} */
        ScreenResComponent.prototype.title;
        /** @type {?} */
        ScreenResComponent.prototype.captionReference;
        /** @type {?} */
        ScreenResComponent.prototype.name1;
        /** @type {?} */
        ScreenResComponent.prototype.chosen;
        /** @type {?} */
        ScreenResComponent.prototype.largeStyle;
        /** @type {?} */
        ScreenResComponent.prototype.titleStyle;
        /** @type {?} */
        ScreenResComponent.prototype.captionStyle;
        /** @type {?} */
        ScreenResComponent.prototype.linkStyle;
        /** @type {?} */
        ScreenResComponent.prototype.originalContent;
        /** @type {?} */
        ScreenResComponent.prototype.controlledContent;
        /** @type {?} */
        ScreenResComponent.prototype.faCoffee;
        /** @type {?} */
        ScreenResComponent.prototype.linkColour;
        /** @type {?} */
        ScreenResComponent.prototype.Image0;
        /** @type {?} */
        ScreenResComponent.prototype.Image1;
        /** @type {?} */
        ScreenResComponent.prototype.Image2;
        /** @type {?} */
        ScreenResComponent.prototype.Image3;
        /** @type {?} */
        ScreenResComponent.prototype.Image4;
        /** @type {?} */
        ScreenResComponent.prototype.Image5;
        /** @type {?} */
        ScreenResComponent.prototype.isTitle;
        /** @type {?} */
        ScreenResComponent.prototype.isCaption;
        /** @type {?} */
        ScreenResComponent.prototype.isButton;
        /** @type {?} */
        ScreenResComponent.prototype.titleText;
        /** @type {?} */
        ScreenResComponent.prototype.buttonSize;
        /** @type {?} */
        ScreenResComponent.prototype.Image6;
        /** @type {?} */
        ScreenResComponent.prototype.height;
        /** @type {?} */
        ScreenResComponent.prototype.captionText;
        /** @type {?} */
        ScreenResComponent.prototype.width;
        /** @type {?} */
        ScreenResComponent.prototype.fontFamilyCaption;
        /** @type {?} */
        ScreenResComponent.prototype.fontSizeCaption;
        /** @type {?} */
        ScreenResComponent.prototype.fontColourCaption;
        /** @type {?} */
        ScreenResComponent.prototype.fontFamily;
        /** @type {?} */
        ScreenResComponent.prototype.fontSize;
        /** @type {?} */
        ScreenResComponent.prototype.fontColour;
        /** @type {?} */
        ScreenResComponent.prototype.buttonClick;
        /**
         * @type {?}
         * @private
         */
        ScreenResComponent.prototype.screenRes;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/screen-res.directive.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ScreenResDirective = /** @class */ (function () {
        function ScreenResDirective(screenRes) {
            this.screenRes = screenRes;
            this.windowSize = { height: 0, width: 0 };
        }
        /**
         * @param {?} event
         * @return {?}
         */
        ScreenResDirective.prototype.onResizing = /**
         * @param {?} event
         * @return {?}
         */
        function (event) {
            this.windowSize = {
                height: window.innerHeight,
                width: window.innerWidth
            };
            this.screenRes.onResize(this.windowSize);
            // this.windowEvent.emit();
        };
        /**
         * @return {?}
         */
        ScreenResDirective.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.windowSize = {
                height: window.innerHeight,
                width: window.innerWidth
            };
        };
        ScreenResDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: '[nkScreenRes]'
                    },] }
        ];
        /** @nocollapse */
        ScreenResDirective.ctorParameters = function () { return [
            { type: ScreenResService }
        ]; };
        ScreenResDirective.propDecorators = {
            onResizing: [{ type: core.HostListener, args: ['window:resize', ['$event'],] }]
        };
        return ScreenResDirective;
    }());
    if (false) {
        /** @type {?} */
        ScreenResDirective.prototype.innerwidth;
        /** @type {?} */
        ScreenResDirective.prototype.innerheight;
        /** @type {?} */
        ScreenResDirective.prototype.windowSize;
        /**
         * @type {?}
         * @private
         */
        ScreenResDirective.prototype.screenRes;
    }

    /**
     * @fileoverview added by tsickle
     * Generated from: lib/screen-res.module.ts
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var ScreenResModule = /** @class */ (function () {
        function ScreenResModule() {
        }
        ScreenResModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [ScreenResComponent, ScreenResDirective],
                        imports: [
                            common.CommonModule,
                            flexLayout.FlexLayoutModule,
                            angularFontawesome.FontAwesomeModule
                        ],
                        exports: [ScreenResComponent]
                    },] }
        ];
        return ScreenResModule;
    }());

    exports.ScreenResComponent = ScreenResComponent;
    exports.ScreenResDirective = ScreenResDirective;
    exports.ScreenResModule = ScreenResModule;
    exports.ScreenResService = ScreenResService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ck-screen-res.umd.js.map
