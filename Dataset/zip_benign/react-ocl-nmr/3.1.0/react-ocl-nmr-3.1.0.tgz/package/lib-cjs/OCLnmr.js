"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = OCLnmr;
const jsx_runtime_1 = require("react/jsx-runtime");
const openchemlib_utils_1 = require("openchemlib-utils");
const react_1 = require("react");
const base_1 = require("react-ocl/base");
function OCLnmr(props) {
    const { OCL, molfile, setMolfile, setSelectedAtom, highlights, setHoverAtom, atomHighlightColor = 'yellow', internalAtomHighlightColor = 'red', atomHighlightOpacity = 0.3, internalAtomHighlightOpacity = 0.3, ...otherProps } = props;
    const [overHighlights, setOverHighlights] = (0, react_1.useState)([]);
    const cache = (0, react_1.useRef)({
        topicMolecule: new openchemlib_utils_1.TopicMolecule(new OCL.Molecule(0, 0)),
        normalizedMolfile: '',
        molecule: new OCL.Molecule(0, 0),
    });
    const { normalizedMolfile, molecule, topicMolecule } = (0, react_1.useMemo)(() => {
        const topicMolecule = cache.current.topicMolecule.fromMolecule(OCL.Molecule.fromMolfile(molfile));
        const normalizedMolfile = topicMolecule.toMolfile({ version: 3 });
        cache.current = {
            topicMolecule,
            normalizedMolfile,
            molecule: topicMolecule.getMolecule(),
        };
        return cache.current;
    }, [molfile, OCL]);
    const externalHighlights = (0, react_1.useMemo)(() => {
        // if the highlight is a proton and there is no proton we will highlight the carbon
        const allAtoms = [];
        const currentHighlights = [...highlights];
        // we receive an array of diaIDs to highlight
        for (const highlight of currentHighlights) {
            const atomIDs = getAtomIDsFromDiaID(topicMolecule, highlight);
            if (!atomIDs)
                continue;
            allAtoms.push(...atomIDs);
            for (const atomID of atomIDs) {
                if (atomID >= topicMolecule.molecule.getAllAtoms() &&
                    topicMolecule.diaIDsAndInfo[atomID].heavyAtom) {
                    // implicit hydrogen, we display the linked heavy atom
                    currentHighlights.push(topicMolecule.diaIDsAndInfo[atomID].heavyAtom);
                }
            }
        }
        return [...allAtoms];
    }, [highlights, topicMolecule]);
    const options = {
        OCL,
        molfile: normalizedMolfile,
        atomHighlight: overHighlights.length > 0 ? overHighlights : externalHighlights,
        atomHighlightOpacity: overHighlights.length > 0
            ? internalAtomHighlightOpacity
            : atomHighlightOpacity,
        atomHighlightColor: overHighlights.length > 0
            ? internalAtomHighlightColor
            : atomHighlightColor,
        onAtomEnter: (atomID) => {
            setHoverAtom(topicMolecule.diaIDsAndInfo[atomID]);
            const atomIDs = getAtomIDsFromDiaID(topicMolecule, topicMolecule.diaIDs[atomID]);
            setOverHighlights(atomIDs);
        },
        onAtomLeave: () => {
            setOverHighlights([]);
            setHoverAtom();
        },
        onAtomClick: (atomID, event) => {
            setSelectedAtom(topicMolecule.diaIDsAndInfo[atomID], event);
            if (event.shiftKey) {
                setOverHighlights([]);
                setHoverAtom();
                (0, openchemlib_utils_1.toggleHydrogens)(molecule, atomID);
                setMolfile(molecule.toMolfileV3());
            }
        },
    };
    return (0, jsx_runtime_1.jsx)(base_1.BaseMolfileSvgRenderer, { ...otherProps, ...options });
}
function getAtomIDsFromDiaID(topicMolecule, diaID) {
    const atomIDs = [];
    for (let i = 0; i < topicMolecule.diaIDs.length; i++) {
        if (topicMolecule.diaIDs[i] === diaID) {
            atomIDs.push(i);
        }
    }
    return atomIDs;
}
//# sourceMappingURL=OCLnmr.js.map