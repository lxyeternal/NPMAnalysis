import type { DiaIDAndInfo } from 'openchemlib-utils';
import { type MouseEvent } from 'react';
import { type BaseMolfileSvgRendererProps } from 'react-ocl/base';
export interface OCLnmrProps extends Omit<BaseMolfileSvgRendererProps, 'atomHighlight' | 'onAtomEnter' | 'onAtomLeave' | 'onAtomClick'> {
    setMolfile: (molfile: string) => void;
    setSelectedAtom: (atom: DiaIDAndInfo | undefined, event: MouseEvent) => void;
    highlights: any[];
    setHoverAtom: (atom?: DiaIDAndInfo) => void;
    internalAtomHighlightColor?: string;
    internalAtomHighlightOpacity?: number;
}
export default function OCLnmr(props: OCLnmrProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=OCLnmr.d.ts.map