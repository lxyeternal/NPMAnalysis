import { EasingGraph } from "./interfaces";
export declare const linear: EasingGraph;
export declare const circular: EasingGraph;
export declare const exponential: EasingGraph;
export declare const squared: EasingGraph;
export declare const cubed: EasingGraph;
export declare const quad: EasingGraph;
export declare const elastic: EasingGraph;
