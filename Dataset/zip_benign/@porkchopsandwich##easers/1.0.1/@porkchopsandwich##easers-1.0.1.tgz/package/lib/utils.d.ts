export declare const toRange: (x: number, min?: number, max?: number) => number;
export declare const arrayMean: (array: number[]) => number | undefined;
