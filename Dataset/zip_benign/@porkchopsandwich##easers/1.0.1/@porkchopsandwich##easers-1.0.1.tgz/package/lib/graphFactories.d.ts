import { EasingGraph } from "./interfaces";
export declare const sineWaveFactory: (amplitude?: number, ordinaryFrequency?: number, phase?: number) => EasingGraph;
export declare const fixedFactory: (y: number) => EasingGraph;
export declare const powerFactory: (power?: number) => EasingGraph;
export declare const bounceFactory: (baseline?: number) => EasingGraph;
export declare const doubleArcFactory: (max?: number) => EasingGraph;
