import { EasingGraph } from "./interfaces";
export declare const reverse: (graph: EasingGraph) => EasingGraph;
export declare const mirror: (graph: EasingGraph) => EasingGraph;
export declare const inverse: (graph: EasingGraph) => EasingGraph;
export declare const pair: (graphA: EasingGraph, graphB: EasingGraph) => EasingGraph;
export declare const inOut: (graph: EasingGraph) => EasingGraph;
export declare const mean: (...graphs: EasingGraph[]) => EasingGraph;
export declare const sequence: (...graphs: EasingGraph[]) => EasingGraph;
export declare const set: (...sets: [EasingGraph, number, number][]) => EasingGraph;
