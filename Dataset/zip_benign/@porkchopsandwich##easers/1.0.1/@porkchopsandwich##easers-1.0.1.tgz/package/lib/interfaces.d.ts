export declare type EasingGraph = (x: number) => number;
export declare type EasingGraphModifier = (graph: EasingGraph) => EasingGraph;
export declare type EasingStepper = (x: number, y: number, lastY?: number) => void;
export declare type EasingEase = (graph: EasingGraph, stepper: EasingStepper, duration: number, forceCaps?: boolean) => Promise<void>;
export declare type GraphApplicator = (y: number) => void;
export declare type GraphSet = [EasingGraph, number, number];
export declare type GraphRollingSet = [EasingGraph, number];
