import { EasingEase } from "./interfaces";
export declare const ease: EasingEase;
