# Easers

A set of composable easing functions.

## Installation

```
npm install --save @porkchopsandwich/easers
```

## Use

```typescript
import { linear, cubic, inverse } from "@porkchopsandwich/easers";

// Basic easers take an X value between 0 and 1, and return the matching Y value.
const y = linear(0.3); // => 0.3

// Other easers are higher order functions that operate on other easers
const invertedLinear = inverse(linear);
const y2 = invertedLinear(0.3);

```

## Available easers

### linear(x) => y
Returns the passed X as Y.

### fixedFactory(x) => () => y
Returns an easer that always returns the initial value.

### sineWaveFactory(amplitude = 1, ordinaryFrequency = 1, phase = 0) => (x) => y
Returns an easer that models a sine wave.

### circular(x) => y
Models a circular easing.

### exponential(x) => y
Models an exponential easing.

### powerFactory(power = 1) => (x) => y
Returns an easer that models the passed power easing.

### squared(x) => y
### cubed(x) => y
### quad(x) => y
Convenience easers for powers of 2, 3 and 4.

### bounceFactory(baseline = 2.75) => (x) => y
Returns a 'bounce' easer (based on Robert Penner's easing methods: http://robertpenner.com/easing/)

### elastic(x) => y
Models an elastic easer (based on Robert Penner's easing methods: http://robertpenner.com/easing/)

### doubleArcFactory(max = 1.1) => (x) => y
Returns an easer that models a double arc.

## Higher Order Easers

### reverse(easer) => (x) => y
Returns an easer that flips the X value passed to the `easer` (1 to 0 rather than 0 to 1)

### mirror(easer) => (x) => y
Returns an easer whose which produces a mirrored pair of the `easer`.

### inverse(easer) => (x) => y
Returns an easer that flips the X value passed to the `easer`, AND flips the returned Y value. Effectively mirrors the easer on a diagonal.

### pair(easer1, easer2) => (x) => y
Returns an easer that invokes `easer1` for the first half of the X range, and `easer2` for the second half.

### inOut(easer) => (x) => y
Returns an easer that invokes `easer` normally for the first half of the X range, and the inverse of `easer` for the second half.   

### mean(...easers) => (x) => y
Returns an easer that returns the mean value returned by all the input `easers`.

### sequence(...easers) => (x) => y
Returns an easer that breaks up the X value into a set matching the length of the input `easers`, and calls the appropriate one for the supplied X value.

### set(...easerSets) => (x) => y
Easer Sets are a 3-tuples consisting of an easer, a start x and an end x. Returns an easer that returns the mean of all easers whose set starts before the input X and ends after the input X.  

## Utilities

### toRange(x, min = 0, max = 1) => y
Converts a value between 0 and 1 to one on a range between min and max.

### arrayMean(arrayOfNumbers) => y
Returns the average of all numbers in an array.
