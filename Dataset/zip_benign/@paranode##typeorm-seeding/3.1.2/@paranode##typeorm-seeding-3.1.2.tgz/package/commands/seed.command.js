"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeedCommand = void 0;
const tslib_1 = require("tslib");
const seed_table_util_1 = require("./../utils/seed-table.util");
const ora_1 = tslib_1.__importDefault(require("ora"));
const chalk_1 = tslib_1.__importDefault(require("chalk"));
const importer_1 = require("../importer");
const file_util_1 = require("../utils/file.util");
const typeorm_seeding_1 = require("../typeorm-seeding");
const connection_1 = require("../connection");
const log_to_seed_table_util_1 = require("../utils/log-to-seed-table.util");
const read_pkg_1 = tslib_1.__importDefault(require("read-pkg"));
const path_1 = tslib_1.__importDefault(require("path"));
class SeedCommand {
    constructor() {
        this.command = 'seed';
        this.describe = 'Runs the seeds';
    }
    builder(args) {
        return args
            .option('d', {
            alias: 'datasource',
            default: '',
            describe: 'Name of the typeorm datasource file (json or js).',
        })
            .option('r', {
            alias: 'root',
            default: process.cwd(),
            describe: 'Path to your typeorm config file',
        })
            .option('seed', {
            alias: 's',
            describe: 'Specific seed class to run.',
        });
    }
    async handler(args) {
        const log = console.log;
        const pkg = await (0, read_pkg_1.default)({ cwd: path_1.default.join(process.cwd(), 'node_modules/@paranode/typeorm-seeding') });
        log('🌱  ' + chalk_1.default.bold(`TypeORM Seeding v${pkg.version}`));
        const spinner = (0, ora_1.default)('Loading ormconfig').start();
        const configureOption = {
            root: args.root,
            configName: args.datasource,
            connection: args.connection,
        };
        // Get TypeORM config file
        let option;
        try {
            (0, connection_1.configureConnection)(configureOption);
            option = await (0, connection_1.getConnectionOptions)();
            spinner.succeed('ORM Config loaded');
        }
        catch (error) {
            panic(spinner, error, 'Could not load the config file!');
            return;
        }
        // Find all factories and seed with help of the config
        spinner.start('Import Factories');
        const factoryFiles = (0, file_util_1.loadFiles)(option.factories);
        try {
            await (0, file_util_1.importFiles)(factoryFiles);
            spinner.succeed('Factories are imported');
        }
        catch (error) {
            panic(spinner, error, 'Could not import factories!');
        }
        // Show seeds in the console
        spinner.start('Importing Seeders');
        const seedFiles = (0, file_util_1.loadFiles)(option.seeds);
        let seedFileObjects = [];
        try {
            seedFileObjects = await Promise.all(seedFiles.map((seedFile) => (0, importer_1.importSeed)(seedFile)));
            spinner.succeed('Seeders are imported');
        }
        catch (error) {
            panic(spinner, error, 'Could not import seeders!');
        }
        // Get database connection and pass it to the seeder
        spinner.start('Connecting to the database');
        try {
            await (0, connection_1.createConnection)();
            spinner.succeed('Database connected');
        }
        catch (error) {
            panic(spinner, error, 'Database connection failed! Check your typeORM config file.');
        }
        // Create Seed table if not exists
        spinner.start('Get Executed Seeders & filter seed classes');
        let seedsAlreadyRan = [];
        try {
            await (0, seed_table_util_1.createSeedTable)(option);
            seedsAlreadyRan = await (0, seed_table_util_1.getExecutedSeeds)(option);
            const seedRanNames = seedsAlreadyRan.map(sar => sar.className);
            seedFileObjects = seedFileObjects.map(sfo => (sfo === null || sfo === void 0 ? void 0 : sfo.default) ? sfo.default : sfo);
            seedFileObjects = seedFileObjects.filter(sfo => !seedRanNames.includes(sfo.name) || (args.seed && args.seed === sfo.name));
            spinner.succeed(`Finish Getting Seeders. ${seedsAlreadyRan.length} seeders already ran, ${seedFileObjects.length} seeders are ready to be executed`);
        }
        catch (error) {
            panic(spinner, error, 'Error getting executed seeders');
        }
        // Run seeds
        for (const seedFileObject of seedFileObjects) {
            spinner.start(`Executing ${seedFileObject.name} Seeder`);
            try {
                await (0, typeorm_seeding_1.runSeeder)(seedFileObject);
                await (0, log_to_seed_table_util_1.logToSeedTable)(seedFileObject.name, option);
                spinner.succeed(`Seeder ${seedFileObject.name} executed`);
            }
            catch (error) {
                panic(spinner, error, `Could not run the seed ${seedFileObject.name}!`);
            }
        }
        log('👍 ', chalk_1.default.gray.underline(`Finished Seeding`));
        process.exit(0);
    }
}
exports.SeedCommand = SeedCommand;
function panic(spinner, error, message) {
    spinner.fail(message);
    console.error(error);
    process.exit(1);
}

//# sourceMappingURL=seed.command.js.map
