import * as yargs from 'yargs';
interface IArgs {
    datasource: string;
    root: string;
    connection: string;
}
export declare class ConfigCommand implements yargs.CommandModule {
    command: string;
    describe: string;
    builder(args: yargs.Argv): yargs.Argv<{
        d: string;
    } & {
        r: string;
    }>;
    handler(args: yargs.Arguments<IArgs>): Promise<void>;
}
export {};
