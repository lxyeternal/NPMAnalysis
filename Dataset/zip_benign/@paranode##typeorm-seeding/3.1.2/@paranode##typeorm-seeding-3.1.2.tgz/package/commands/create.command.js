"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCommand = void 0;
const tslib_1 = require("tslib");
const read_pkg_1 = tslib_1.__importDefault(require("read-pkg"));
const chalk_1 = tslib_1.__importDefault(require("chalk"));
const ora_1 = tslib_1.__importDefault(require("ora"));
const connection_js_1 = require("../connection.js");
const fs = tslib_1.__importStar(require("fs"));
const path_1 = tslib_1.__importDefault(require("path"));
const lodash_1 = tslib_1.__importDefault(require("lodash"));
const create_seeder_template_js_1 = tslib_1.__importDefault(require("../templates/create-seeder.template.js"));
class CreateCommand {
    constructor() {
        this.command = 'create';
        this.describe = 'Creates a new seeder file';
    }
    builder(args) {
        //
        return args
            .option('f', {
            alias: 'fileName',
            default: '',
            describe: 'the name of the seeder file to be created'
        })
            .option('d', {
            alias: 'datasource',
            default: '',
            describe: 'Name of the typeorm datasource file (json or js).',
        })
            .option('r', {
            alias: 'root',
            default: process.cwd(),
            describe: 'Path to your typeorm config file',
        });
    }
    async handler(args) {
        var _a;
        const log = console.log;
        const pkg = await (0, read_pkg_1.default)({ cwd: path_1.default.join(process.cwd(), 'node_modules/@paranode/typeorm-seeding') });
        log('🌱  ' + chalk_1.default.bold(`TypeORM Seeding v${pkg.version}`));
        const spinner = (0, ora_1.default)('Loading ormconfig').start();
        const configureOption = {
            root: args.root,
            configName: args.datasource,
            connection: args.connection,
        };
        // Get TypeORM config file
        let option;
        try {
            (0, connection_js_1.configureConnection)(configureOption);
            option = await (0, connection_js_1.getConnectionOptions)();
            spinner.succeed('ORM Config loaded');
        }
        catch (error) {
            panic(spinner, error, 'Could not load the config file!');
            return;
        }
        let seedsDir = 'src/database/seeds';
        if (!((_a = option === null || option === void 0 ? void 0 : option.cli) === null || _a === void 0 ? void 0 : _a.seedsDir)) {
            return panic(spinner, new Error('NO_CLI_SEEDS_DIR'), 'cli.seedsDir was not set in the ormconfig file');
        }
        else {
            seedsDir = option.cli.seedsDir;
        }
        if (!args.fileName) {
            return panic(spinner, new Error('NO_FILE_NAME'), 'no filename entered, please use -f or --fileName to specify the filename');
        }
        spinner.start('Creating file');
        const now = Date.now();
        const fileName = `${now}-${lodash_1.default.kebabCase(args.fileName)}`;
        const className = `${lodash_1.default.upperFirst(lodash_1.default.camelCase(args.fileName))}${now}`;
        try {
            if (!fs.existsSync(seedsDir)) {
                fs.mkdirSync(seedsDir, { recursive: true });
            }
            fs.writeFileSync(path_1.default.join(seedsDir, fileName + '.ts'), (0, create_seeder_template_js_1.default)({ className }));
            spinner.succeed(`File: ${fileName}.ts created successfully`);
        }
        catch (error) {
            panic(spinner, error, 'Error creating file');
        }
        process.exit(0);
    }
}
exports.CreateCommand = CreateCommand;
function panic(spinner, error, message) {
    spinner.fail(message);
    console.error(error);
    process.exit(1);
}

//# sourceMappingURL=create.command.js.map
