import * as yargs from 'yargs';
interface IArgs {
    datasource: string;
    root: string;
    seed: string;
    connection: string;
}
export declare class SeedCommand implements yargs.CommandModule {
    command: string;
    describe: string;
    builder(args: yargs.Argv): yargs.Argv<{
        d: string;
    } & {
        r: string;
    } & {
        seed: unknown;
    }>;
    handler(args: yargs.Arguments<IArgs>): Promise<void>;
}
export {};
