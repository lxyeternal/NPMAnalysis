"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigCommand = void 0;
const tslib_1 = require("tslib");
const read_pkg_1 = tslib_1.__importDefault(require("read-pkg"));
const chalk_1 = tslib_1.__importDefault(require("chalk"));
const log_util_1 = require("../utils/log.util");
const connection_1 = require("../connection");
const path_1 = tslib_1.__importDefault(require("path"));
class ConfigCommand {
    constructor() {
        this.command = 'config';
        this.describe = 'Show the TypeORM config';
    }
    builder(args) {
        return args
            .option('d', {
            alias: 'datasource',
            default: '',
            describe: 'Name of the typeorm datasource file (json or js).',
        })
            .option('r', {
            alias: 'root',
            default: process.cwd(),
            describe: 'Path to your typeorm datasource file',
        });
    }
    async handler(args) {
        const log = console.log;
        const pkg = await (0, read_pkg_1.default)({ cwd: path_1.default.join(process.cwd(), 'node_modules/@paranode/typeorm-seeding') });
        log('🌱  ' + chalk_1.default.bold(`TypeORM Seeding v${pkg.version}`));
        try {
            (0, connection_1.configureConnection)({
                root: args.root,
                configName: args.datasource,
                connection: args.connection,
            });
            const option = await (0, connection_1.getConnectionOptions)();
            log(option);
        }
        catch (error) {
            (0, log_util_1.printError)('Could not find the orm config file', error);
            process.exit(1);
        }
        process.exit(0);
    }
}
exports.ConfigCommand = ConfigCommand;

//# sourceMappingURL=config.command.js.map
