import * as yargs from "yargs";
interface IArgs {
    fileName: string;
    datasource: string;
    root: string;
    connection: string;
}
export declare class CreateCommand implements yargs.CommandModule {
    command: string;
    describe: string;
    builder(args: yargs.Argv): yargs.Argv<{
        f: string;
    } & {
        d: string;
    } & {
        r: string;
    }>;
    handler(args: yargs.Arguments<IArgs>): Promise<void>;
}
export {};
