"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createConnection = exports.getConnectionOptions = exports.setConnectionOptions = exports.configureConnection = exports.DataSource = void 0;
const typeorm_1 = require("typeorm");
const log_util_1 = require("./utils/log.util");
const createTypeOrmConnection = (options) => {
    const ds = new typeorm_1.DataSource(options);
    return ds.initialize();
};
class DataSource extends typeorm_1.DataSource {
}
exports.DataSource = DataSource;
const KEY = 'TypeORM_Seeding_Connection';
const defaultConfigureOption = {
    root: process.cwd(),
    configName: '',
    connection: '',
};
if (global[KEY] === undefined) {
    ;
    global[KEY] = {
        configureOption: defaultConfigureOption,
        ormConfig: undefined,
        connection: undefined,
        overrideConnectionOptions: {},
    };
}
const configureConnection = (option = {}) => {
    ;
    global[KEY].configureOption = {
        ...defaultConfigureOption,
        ...option,
    };
};
exports.configureConnection = configureConnection;
const setConnectionOptions = (options) => {
    ;
    global[KEY].overrideConnectionOptions = options;
};
exports.setConnectionOptions = setConnectionOptions;
const getConnectionOptions = async () => {
    var _a, _b;
    const ormConfig = global[KEY].ormConfig;
    const overrideConnectionOptions = global[KEY].overrideConnectionOptions;
    if (ormConfig === undefined) {
        const configureOption = global[KEY].configureOption;
        const connection = configureOption.connection;
        const reader = new typeorm_1.ConnectionOptionsReader({
            root: configureOption.root,
            configName: configureOption.configName,
        });
        let o = await reader.all();
        let options = o.map(option => option.dataSource || option);
        if (connection !== undefined && connection !== '') {
            const filteredOptions = options.filter((o) => o.name === connection);
            if (filteredOptions.length === 1) {
                options = filteredOptions;
            }
        }
        if (options.length > 1) {
            const filteredOptions = options.filter((o) => o.name === 'default');
            if (filteredOptions.length === 1) {
                options = filteredOptions;
            }
        }
        if (options.length === 1) {
            const option = (_b = (_a = options[0]) === null || _a === void 0 ? void 0 : _a.options) !== null && _b !== void 0 ? _b : options[0];
            if (!option.factories) {
                option.factories = [process.env.TYPEORM_SEEDING_FACTORIES || 'src/database/factories/**/*{.ts,.js}'];
            }
            if (!option.seeds) {
                option.seeds = [process.env.TYPEORM_SEEDING_SEEDS || 'src/database/seeds/**/*{.ts,.js}'];
            }
            ;
            global[KEY].ormConfig = {
                ...option,
                ...overrideConnectionOptions,
            };
            return global[KEY].ormConfig;
        }
        (0, log_util_1.printError)('There are multiple connections please provide a connection name');
    }
    return ormConfig;
};
exports.getConnectionOptions = getConnectionOptions;
const createConnection = async (option) => {
    const configureOption = global[KEY].configureOption;
    let connection = global[KEY].connection;
    let ormConfig = global[KEY].ormConfig;
    if (option !== undefined) {
        ormConfig = option;
    }
    if (connection === undefined) {
        connection = await createTypeOrmConnection(ormConfig);
        global[KEY].connection = connection;
    }
    return connection;
};
exports.createConnection = createConnection;

//# sourceMappingURL=connection.js.map
