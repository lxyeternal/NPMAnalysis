#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
require("reflect-metadata");
const yargs_1 = tslib_1.__importDefault(require("yargs/yargs"));
const seed_command_1 = require("./commands/seed.command");
const config_command_1 = require("./commands/config.command");
const create_command_1 = require("./commands/create.command");
(0, yargs_1.default)(process.argv.slice(2))
    .usage('Usage: $0 <command> [options]')
    .command(new config_command_1.ConfigCommand())
    .command(new seed_command_1.SeedCommand())
    .command(new create_command_1.CreateCommand())
    .recommendCommands()
    .demandCommand(1)
    .strict()
    .help('h')
    .alias('h', 'help').argv;

//# sourceMappingURL=cli.js.map
