import { DataSource as TODataSource, DataSourceOptions } from 'typeorm';
interface SeedingOptions {
    factories: string[];
    seeds: string[];
    seedsTableName: string;
    cli?: {
        seedsDir?: string;
    };
}
export declare type ConnectionOptions = DataSourceOptions & SeedingOptions;
export declare class DataSource extends TODataSource {
    options: ConnectionOptions;
}
export interface ConfigureOption {
    root?: string;
    configName?: string;
    connection?: string;
}
export declare const configureConnection: (option?: ConfigureOption) => void;
export declare const setConnectionOptions: (options: Partial<DataSourceOptions>) => void;
export declare const getConnectionOptions: () => Promise<ConnectionOptions>;
export declare const createConnection: (option?: DataSourceOptions) => Promise<DataSource>;
export {};
