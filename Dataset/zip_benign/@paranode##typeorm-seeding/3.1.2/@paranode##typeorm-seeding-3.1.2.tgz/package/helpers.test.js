"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const helpers_1 = require("./helpers");
describe('times', () => {
    test('Should call the func 2 times ', async () => {
        const result = await (0, helpers_1.times)(2, async () => 'a');
        expect(result.length).toBe(2);
        expect(result).toStrictEqual(['a', 'a']);
    });
});

//# sourceMappingURL=helpers.test.js.map
