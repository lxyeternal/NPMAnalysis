"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getExecutedSeeds = exports.createSeedTable = void 0;
const typeorm_1 = require("typeorm");
const connection_1 = require("./../connection");
const createSeedTable = async (options) => {
    const connection = await (0, connection_1.createConnection)(options);
    await connection.createQueryRunner().createTable(new typeorm_1.Table({
        name: options.seedsTableName || 'typeorm_seeds',
        columns: [
            {
                name: 'className',
                type: 'varchar',
                isUnique: true,
                isNullable: true,
            },
            {
                name: 'ran_at',
                type: 'timestamp',
                default: 'now()',
            },
        ],
    }), true);
};
exports.createSeedTable = createSeedTable;
const getExecutedSeeds = async (options) => {
    const connection = await (0, connection_1.createConnection)(options);
    return await connection.query(`select * from "${options.seedsTableName || 'typeorm_seeds'}"`);
};
exports.getExecutedSeeds = getExecutedSeeds;

//# sourceMappingURL=seed-table.util.js.map
