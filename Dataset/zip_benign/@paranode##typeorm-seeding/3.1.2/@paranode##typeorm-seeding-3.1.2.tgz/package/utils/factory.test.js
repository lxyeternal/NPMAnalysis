"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const factory_util_1 = require("./factory.util");
describe('getNameOfClass', () => {
    test('Passing UserEnity class should return the name of the class', () => {
        class UserEntity {
        }
        expect((0, factory_util_1.getNameOfEntity)(UserEntity)).toBe('UserEntity');
    });
    test('Passing UserEnity function should return the name of the function', () => {
        const UserEntity = () => void 0;
        expect((0, factory_util_1.getNameOfEntity)(UserEntity)).toBe('UserEntity');
    });
    test('Passing undefinde as a enity-class should throw an error', () => {
        try {
            (0, factory_util_1.getNameOfEntity)(undefined);
        }
        catch (error) {
            expect(error.message).toBe('Enity is not defined');
        }
    });
});
describe('isPromiseLike', () => {
    test('Passing a promise should return true', () => {
        const promise = new Promise(() => void 0);
        expect((0, factory_util_1.isPromiseLike)(promise)).toBeTruthy();
    });
    test('Passing no promise should return false', () => {
        expect((0, factory_util_1.isPromiseLike)(undefined)).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)(null)).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)('')).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)(42)).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)(true)).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)(false)).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)([])).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)({})).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)(() => void 0)).toBeFalsy();
        class UserEntity {
        }
        expect((0, factory_util_1.isPromiseLike)(new UserEntity())).toBeFalsy();
        expect((0, factory_util_1.isPromiseLike)(new Date())).toBeFalsy();
    });
});

//# sourceMappingURL=factory.test.js.map
