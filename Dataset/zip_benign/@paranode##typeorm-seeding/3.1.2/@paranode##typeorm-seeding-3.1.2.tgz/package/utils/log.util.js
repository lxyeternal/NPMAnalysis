"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.printWarning = exports.printError = void 0;
const tslib_1 = require("tslib");
const chalk_1 = tslib_1.__importDefault(require("chalk"));
/**
 * Prints the error to the console
 */
const printError = (message, error) => {
    console.log('\n❌ ', chalk_1.default.red(message));
    if (error) {
        console.error(error);
    }
};
exports.printError = printError;
/**
 * Prints the warning to the console
 */
const printWarning = (message, error) => {
    console.log('\n🚨 ', chalk_1.default.yellow(message));
    if (error) {
        console.error(error);
    }
};
exports.printWarning = printWarning;

//# sourceMappingURL=log.util.js.map
