"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadFiles = exports.importFiles = void 0;
const tslib_1 = require("tslib");
const glob_1 = tslib_1.__importDefault(require("glob"));
const path = tslib_1.__importStar(require("path"));
const importFiles = async (filePaths) => {
    await Promise.all(filePaths.map((filePath) => { var _a; return _a = filePath, Promise.resolve().then(() => tslib_1.__importStar(require(_a))); }));
};
exports.importFiles = importFiles;
const loadFiles = (filePattern) => {
    return filePattern
        .map((pattern) => glob_1.default.sync(path.resolve(process.cwd(), pattern)))
        .reduce((acc, filePath) => acc.concat(filePath), []);
};
exports.loadFiles = loadFiles;

//# sourceMappingURL=file.util.js.map
