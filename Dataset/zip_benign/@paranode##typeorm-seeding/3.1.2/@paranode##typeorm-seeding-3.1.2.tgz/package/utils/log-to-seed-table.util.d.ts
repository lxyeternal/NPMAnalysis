import { ConnectionOptions } from "../connection.js";
export declare const logToSeedTable: (seederName: string, options: ConnectionOptions) => Promise<any>;
