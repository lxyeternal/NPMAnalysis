"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logToSeedTable = void 0;
const connection_1 = require("./../connection");
const logToSeedTable = async (seederName, options) => {
    const connection = await (0, connection_1.createConnection)(options);
    return await connection.query(`insert into "${options.seedsTableName || 'typeorm_seeds'}" values ('${seederName}')`);
};
exports.logToSeedTable = logToSeedTable;

//# sourceMappingURL=log-to-seed-table.util.js.map
