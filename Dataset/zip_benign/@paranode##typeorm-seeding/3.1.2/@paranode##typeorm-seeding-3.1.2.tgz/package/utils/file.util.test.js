"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const file_util_1 = require("./file.util");
const path = tslib_1.__importStar(require("path"));
const glob = tslib_1.__importStar(require("glob"));
describe('loadFiles', () => {
    let syncMock;
    beforeEach(() => {
        syncMock = jest.fn();
        glob.sync = syncMock;
        syncMock.mockReturnValue(['fileA', 'fileB']);
    });
    test('Should return a flat array', () => {
        const results = (0, file_util_1.loadFiles)(['path/to/files', 'other/path/to/files']);
        expect(results.length).toBe(4);
        expect(results[0]).toBe('fileA');
        expect(results[1]).toBe('fileB');
    });
    test('Should call the sync method with the cwd path', () => {
        const results = (0, file_util_1.loadFiles)(['path/to/files']);
        expect(syncMock).toBeCalledWith(path.join(process.cwd(), 'path/to/files'));
    });
});

//# sourceMappingURL=file.util.test.js.map
