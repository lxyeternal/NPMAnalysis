"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const makeTemplate = ({ className }) => `/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable import/no-default-export */
import type { Factory, Seeder } from '@paranode/typeorm-seeding';
import type { DataSource } from 'typeorm';

export default class ${className} implements Seeder {
  public async run(_factory: Factory, _connection: DataSource): Promise<any> {
    // add your logic here
  }
}`;
exports.default = makeTemplate;

//# sourceMappingURL=create-seeder.template.js.map
