declare const makeTemplate: ({ className }: {
    className: string;
}) => string;
export default makeTemplate;
