import React from 'react';
import { ExpandableSideNavProps } from './types/ExpandableSideNav.interfaces';
export declare const ExpandableSideNav: React.FC<ExpandableSideNavProps>;
