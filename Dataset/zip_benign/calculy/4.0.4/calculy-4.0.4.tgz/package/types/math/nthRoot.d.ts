export default function nthRoot(num: number, n?: number): number;
