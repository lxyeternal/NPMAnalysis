export default function log(num: number, base?: number): number;
