export default function factorial(num: number): number;
