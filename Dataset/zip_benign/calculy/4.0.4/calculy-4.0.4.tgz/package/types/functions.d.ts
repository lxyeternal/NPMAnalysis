import { MathFuncs } from "./types";
export default function getFunctions(deg: boolean | undefined): MathFuncs;
