import { Expression, Options } from "./types";
export default function parse(tokens: string[], options?: Options): Expression;
