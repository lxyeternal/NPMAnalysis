import { Options } from "./types";
export default function calculate(code: string, options?: Options): number;
