import { MathFunc } from "./types";
export default function validate(func: MathFunc, min?: number, max?: number): MathFunc;
