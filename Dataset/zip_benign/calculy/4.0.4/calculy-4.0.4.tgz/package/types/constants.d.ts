import { Constants } from "./types";
export default function getConstants(custom: Constants | undefined): Constants;
