import { MathFunc } from "./types";
export default function degree(func: MathFunc): MathFunc;
