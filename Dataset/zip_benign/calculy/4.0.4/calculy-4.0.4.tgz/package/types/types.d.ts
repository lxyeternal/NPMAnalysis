export declare type MathFunc = (...args: number[]) => number;
export declare type Constants = Record<string, number>;
export declare type MathFuncs = Record<string, MathFunc>;
export declare type Options = {
    constants?: Constants;
    functions?: MathFuncs;
    deg?: boolean;
};
export declare enum ExpressionType {
    Add = "+",
    Subtract = "-",
    Multiply = "*",
    Divide = "/",
    Exponential = "^",
    Factorial = "!",
    Modulo = "%",
    Group = "group",
    Absolute = "absolute",
    Negative = "negative",
    Function = "function",
    Number = "number",
    Constant = "constant"
}
export declare type Expression = PrimaryExpression | ModifierExpression | ValueExpression | FunctionExpression | GroupExpression;
export declare type PrimaryExpression = {
    type: ExpressionType.Add | ExpressionType.Subtract | ExpressionType.Multiply | ExpressionType.Divide | ExpressionType.Exponential;
    left: Expression;
    right: Expression;
};
export declare type ModifierExpression = {
    type: ExpressionType.Negative | ExpressionType.Absolute | ExpressionType.Modulo | ExpressionType.Factorial;
    of: Expression;
};
export declare type ValueExpression = {
    type: ExpressionType.Number | ExpressionType.Constant;
    value: string;
};
export declare type FunctionExpression = {
    type: ExpressionType.Function;
    value: string;
    args: Expression[];
};
export declare type GroupExpression = {
    type: ExpressionType.Group;
    expression: Expression;
};
