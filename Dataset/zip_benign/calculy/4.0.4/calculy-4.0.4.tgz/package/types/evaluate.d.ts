import { Expression, Options } from "./types";
export default function evaluate(expression: Expression, options: Options): number;
