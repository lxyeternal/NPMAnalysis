import { convertTokensToCssVariables as cssVariables } from "./css/cssVariables/convertTokensToCssVariables.js";
import { convertTokensToScss as scss } from "./css/scss/convertTokensToScss.js";
import { convertTokensToJsObject as jsObject } from "./js/convertTokensToJsObject.js";
import { convertTokensToJson as json } from "./json/convertTokensToJson.js";
declare const builtInTransforms: {
    json: typeof json;
    cssVariables: typeof cssVariables;
    scss: typeof scss;
    jsObject: typeof jsObject;
};
export { builtInTransforms };
