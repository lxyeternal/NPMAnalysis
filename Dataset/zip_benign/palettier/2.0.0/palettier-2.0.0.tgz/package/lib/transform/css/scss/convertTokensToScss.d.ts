import type { Tokens } from "../../../tokens/isTokens.js";
declare function convertTokensToScss(tokens: Tokens): string;
export { convertTokensToScss };
