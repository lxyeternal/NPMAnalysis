type Entry = [string, string | number];
type Entries = Entry[];
declare function isEntry(unknown: unknown): unknown is Entry;
declare function isEntries(unknown: unknown): unknown is Entries;
export { isEntry, isEntries };
export type { Entry, Entries };
