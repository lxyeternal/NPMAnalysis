import type { Tokens } from "../../tokens/isTokens.js";
declare function convertTokensToJson(tokens: Tokens): string;
export { convertTokensToJson };
