import type { Tokens } from "../../tokens/isTokens.js";
declare function convertTokensToJsObject(tokens: Tokens, jsExportType?: string): string;
export { convertTokensToJsObject };
