import { type Tokens } from "../../tokens/isTokens.js";
import type { Entries } from "./isEntry.js";
declare const recursivelyGenerateEntries: (tokens: Tokens, parentKey?: string) => Entries;
export { recursivelyGenerateEntries };
