import type { Entries } from "./isEntry.js";
declare function generateCssFile(className?: string | null, entries?: Entries): string;
export { generateCssFile };
