import type { Entries } from "./isEntry.js";
declare function prefixWith(entries: Entries, prefix: string): Entries;
export { prefixWith };
