import { builtInTransforms } from "./builtInTransforms.js";
type BuiltInTransform = keyof typeof builtInTransforms;
declare function isBuiltInTransform(string: string): string is BuiltInTransform;
export { isBuiltInTransform };
