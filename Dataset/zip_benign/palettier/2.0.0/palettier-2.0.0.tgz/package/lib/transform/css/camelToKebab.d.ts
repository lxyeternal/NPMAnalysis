declare function camelToKebab(string: string): string;
export { camelToKebab };
