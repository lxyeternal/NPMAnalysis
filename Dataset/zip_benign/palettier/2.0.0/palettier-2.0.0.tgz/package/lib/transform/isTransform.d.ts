import type { TransformFunction } from "./getTransformFunction.js";
type Transform = [
    key: string | TransformFunction,
    fileName: string,
    ...options: string[]
];
declare function isTransform(transform: unknown): transform is Transform;
export type { Transform };
export { isTransform };
