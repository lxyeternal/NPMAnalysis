import type { Tokens } from "../tokens/isTokens.js";
type TransformFunction = (tokens: Tokens, ...options: string[]) => string;
declare function getTransformFunction(functionOrBuiltInTransform?: string | TransformFunction): null | TransformFunction;
export type { TransformFunction };
export { getTransformFunction };
