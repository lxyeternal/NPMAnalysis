declare const jsExportTypeMap: {
    readonly default: "export default palette";
    readonly named: "export { palette }";
    readonly commonjs: "module.exports = palette";
};
type JsExportType = keyof typeof jsExportTypeMap;
type JsExportTypeValue = (typeof jsExportTypeMap)[JsExportType];
declare function isJsExportType(string: string): string is JsExportType;
declare function isJsExportTypeValue(string: string): string is JsExportTypeValue;
export type { JsExportType, JsExportTypeValue };
export { isJsExportType, isJsExportTypeValue, jsExportTypeMap };
