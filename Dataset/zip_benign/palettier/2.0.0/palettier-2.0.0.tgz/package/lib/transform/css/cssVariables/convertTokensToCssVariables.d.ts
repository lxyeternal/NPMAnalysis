import type { Tokens } from "../../../tokens/isTokens.js";
declare function convertTokensToCssVariables(tokens: Tokens, className?: string): string;
export { convertTokensToCssVariables };
