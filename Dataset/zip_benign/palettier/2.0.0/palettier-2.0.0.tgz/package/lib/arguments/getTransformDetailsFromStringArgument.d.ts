import type { Transform } from "transform/isTransform.js";
declare function getTransformDetailsFromStringArgument(string: string): Transform;
export { getTransformDetailsFromStringArgument };
