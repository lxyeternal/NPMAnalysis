import type { Transform } from "transform/isTransform.js";
type ConfigArguments = {
    config: string;
};
type InlineArguments = {
    src: string;
    dist: string;
    transform?: Transform[];
    verbose?: boolean;
};
type Arguments = ConfigArguments | InlineArguments;
declare function isConfigArguments(object: object): object is ConfigArguments;
declare function isInlineArguments(object: object): object is InlineArguments;
declare function getCliArguments(): Partial<Arguments>;
export type { ConfigArguments, InlineArguments, Arguments };
export { getCliArguments, isConfigArguments, isInlineArguments };
