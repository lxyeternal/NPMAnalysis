declare function getAbsolutePath(string?: string): string;
export { getAbsolutePath };
