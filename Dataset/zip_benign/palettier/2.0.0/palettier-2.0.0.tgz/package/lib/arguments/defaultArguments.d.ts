import type { Arguments } from "./getCliArguments.js";
declare const defaultArguments: Omit<Arguments, "src">;
export { defaultArguments };
