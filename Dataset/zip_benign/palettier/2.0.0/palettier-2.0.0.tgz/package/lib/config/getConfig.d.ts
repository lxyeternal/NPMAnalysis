import { type Config } from "./isConfig.js";
declare function getConfig(): Promise<Config | Error>;
export { getConfig };
