import { type Transform } from "../transform/isTransform.js";
interface Config extends Record<string, unknown> {
    src: string;
    dist: string;
    transform: Transform[];
    verbose: boolean;
}
declare function isPartialConfig(config: unknown): config is Partial<Config>;
declare function isConfig(config: unknown): config is Config;
export type { Config };
export { isPartialConfig, isConfig };
