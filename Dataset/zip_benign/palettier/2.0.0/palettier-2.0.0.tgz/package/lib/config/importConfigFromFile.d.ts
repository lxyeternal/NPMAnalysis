import { type Config } from "./isConfig.js";
declare function importConfigFromFile(path: string): Promise<Partial<Config> | Error>;
export { importConfigFromFile };
