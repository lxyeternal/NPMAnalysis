interface Tokens {
    [key: string]: string | number | boolean | Tokens;
}
declare function isTokens(argument: unknown): argument is Tokens;
export type { Tokens };
export { isTokens };
