import { type Tokens } from "./isTokens.js";
declare function getTokens(path: string): Promise<Tokens>;
export { getTokens };
