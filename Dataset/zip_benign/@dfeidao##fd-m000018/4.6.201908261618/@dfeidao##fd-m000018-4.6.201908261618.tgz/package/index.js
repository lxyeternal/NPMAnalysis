"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const react_native_keyboard_aware_scroll_view_1 = require("react-native-keyboard-aware-scroll-view");
class M000018 extends react_1.Component {
    constructor(props) {
        super(props);
    }
    componentDidUpdate(_prevOption) {
        // scrollType为1的时候,调用scrollIntoView属性
        if (this.props.scrollType === 1) {
            this.scrollIntoView(this.props.scrollIntoView);
        }
        // scrollType为2的时候,调用scrollToEnd属性
        if (this.props.scrollType === 2) {
            this.scrollToEnd(this.props.scrollToEnd);
        }
        // scrollType为3的时候,调用scrollToPosition属性
        if (this.props.scrollType === 3) {
            this.scrollToPosition(this.props.scrollToPosition);
        }
    }
    render() {
        return (react_1.default.createElement(react_native_keyboard_aware_scroll_view_1.KeyboardAwareFlatList, Object.assign({ ref: (e) => {
                this.ref = e;
            }, extraData: new Date().getTime() }, this.props)));
    }
    /**
     * 跳转到指定节点
     * @param element 节点
     */
    scrollIntoView(ele) {
        if (ele) {
            return this.ref.scrollIntoView(ele);
        }
    }
    /**
     * Programatically scroll to any position
     * @param x 沿x轴滚动位置
     * @param y 沿y轴滚动位置
     * @param animated 滚动动画
     */
    scrollToPosition(option) {
        if (option) {
            return this.ref.scrollToPosition(option.x, option.y, option.animated);
        }
    }
    /**
     * 滚动到底部。如果不设置getItemLayout属性的话，可能会比较卡。
     * @param animated 滚动动画
     */
    scrollToEnd(animated) {
        return this.ref.scrollToEnd(animated);
    }
}
exports.default = M000018;
