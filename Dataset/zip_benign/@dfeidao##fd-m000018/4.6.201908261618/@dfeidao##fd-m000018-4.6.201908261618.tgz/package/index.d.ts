import React, { Component } from 'react';
import { KeyboardAwareFlatListProps } from 'react-native-keyboard-aware-scroll-view';
interface IProps extends KeyboardAwareFlatListProps<unknown> {
    scrollType?: 0 | 1 | 2 | 3;
    scrollIntoView?: React.ReactInstance;
    scrollToEnd?: boolean;
    scrollToPosition?: {
        x: number;
        y: number;
        animated?: boolean;
    };
}
export default class M000018 extends Component<IProps> {
    private ref;
    constructor(props: IProps);
    componentDidUpdate(_prevOption: IProps): void;
    render(): JSX.Element;
    /**
     * 跳转到指定节点
     * @param element 节点
     */
    private scrollIntoView;
    /**
     * Programatically scroll to any position
     * @param x 沿x轴滚动位置
     * @param y 沿y轴滚动位置
     * @param animated 滚动动画
     */
    private scrollToPosition;
    /**
     * 滚动到底部。如果不设置getItemLayout属性的话，可能会比较卡。
     * @param animated 滚动动画
     */
    private scrollToEnd;
}
export {};
