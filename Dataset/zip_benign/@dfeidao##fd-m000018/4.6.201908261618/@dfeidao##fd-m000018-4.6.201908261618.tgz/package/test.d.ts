import { Component } from 'react';
interface IState {
    scrollIntoView: string;
}
export default class App extends Component<{}, IState> {
    constructor(props: IState);
    click(): void;
    render(): JSX.Element;
}
export {};
