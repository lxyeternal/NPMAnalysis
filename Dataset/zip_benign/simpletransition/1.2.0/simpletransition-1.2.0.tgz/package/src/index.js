import React from 'react'
import ReactDOM from 'react-dom'

function addClass (elem, className) {
  elem.className += ' ' + className
}

function removeClass (elem, className) {
  let elemClassName = ` ${elem.className.trim()} `.replace(/[\n\t\r]/g, ' ')
  className = ` ${className.trim()} `

  while (elemClassName.indexOf(className) >= 0) {
    elemClassName = elemClassName.replace(className, ' ')
  }

  elem.className = elemClassName.trim()
}

const TICK = 17
const addClassOnNextTick = (element, className) => setTimeout(() => addClass(element, className), TICK)

class SimpleTransition extends React.Component {
  constructor (props) {
    super(props)
    const child = React.Children.only(props.children)
    this.state = { child }
  }

  componentDidMount () {
    this.transition('appear', this.state.child)
  }

  componentWillReceiveProps (nextProps) {    
    if (nextProps.children.type !== this.props.children.type) {
      this.transitionBetween(this.props.children, nextProps.children)
    } else {
      this.setState({ child: React.Children.only(nextProps.children)})
    }
  }

  shouldComponentUpdate (nextProps, nextState) {
    return nextState !== this.state
  }

  transition (type, element, callback) {
    const container = ReactDOM.findDOMNode(this)

    const options = element.type.transition
    const name = options.name || 'default'
    const timeout = options[type]

    const initialClassName = `${name}-${type}`
    const activeClassName = type === 'leave' ? `${name}-leaving` : `${name}-${type}ing`

    if (!timeout) return callback ? callback(type, element) : false

    addClass(container, initialClassName)
    addClassOnNextTick(container, activeClassName)

    setTimeout(() => {
      removeClass(container, `${initialClassName} ${activeClassName}`)
      if (callback) callback(type, element)
    }, timeout)
  }

  transitionBetween (current, next) {
    this.transition('leave', current, () => this.setState({ child: next }, () => {
      this.transition('enter', next)
    }))
  }

  render () {
    return <span>{this.state.child}</span>
  }
}

SimpleTransition.propTypes = { children: React.PropTypes.element }

export default SimpleTransition
