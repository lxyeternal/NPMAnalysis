# SimpleTransition

Dead simple transitions. Written very quickly for a simple use case.

```
npm install SimpleTransition
```

```html
<SimpleTransition>{children}</SimpleTransition>
```

```javascript
const ExampleChild = (props) => <h1>Hello there</h1>
ExampleChild.transition = { name: 'example-child', enter: 500, appear: 500 }
```

```css
.example-child-appear, .example-child-enter { opacity: 0; transition: opacity 0.5s; }
.example-child-appearing, .example-child-entering, .example-child-leave { opacity: 1; }
.example-child-leaving { transition: opacity 0.5s; opacity: 0; }
```
