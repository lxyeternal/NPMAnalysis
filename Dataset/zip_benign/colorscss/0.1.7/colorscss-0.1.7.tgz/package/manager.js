module.exports = {
    mixins: `
        @mixin themify($property, $item, $important: '') {
            @each $theme in $prefixes {
                .#{$theme} & {
                    #{$property}: map-get($item, $theme) #{$important};
                }
            }
        }

        @mixin themifyRGBA($property, $item, $alpha, $important: '') {
            @each $theme in $prefixes {
                .#{$theme} & {
                    #{$property}: rgba(map-get($item, $theme), $alpha) #{$important};
                }
            }
        }

        @mixin themifySVG($item, $important: '') {
            @each $theme in $prefixes {
                .#{$theme} & {
                    * { fill: #{map-get($item, $theme)} #{$important}; }
                }
            }
        }

        @mixin themifyGradient($direction, $item1, $opacity1, $value1, $item2, $opacity2, $value2) {
            @each $theme in $prefixes {
                .#{$theme} & {
                    background: linear-gradient(
                            to #{$direction},
                            rgba(map-get($item1, $theme), $opacity1) $value1,
                            rgba(map-get($item2, $theme), $opacity2) $value2
                    );
                }
            }
        }

        @mixin themifyDarken($property, $item, $value) {
            @each $theme in $prefixes {
                .#{$theme} & {
                    #{$property}: darken(map-get($item, $theme), $value);
                }
            }
        }

        @mixin themifyLighten($property, $item, $value) {
            @each $theme in $prefixes {
                .#{$theme} & {
                    #{$property}: lighten(map-get($item, $theme), $value);
                }
            }
        }

        @mixin themifyBoxShadow($settings, $item, $important: '') {
            @each $theme in $prefixes {
                .#{$theme} & {
                    box-shadow: #{$settings} map-get($item, $theme) #{$important};
                }
            }
        }
    `
};
