const fs = require('fs');
const read = require('read-file');
const mixins = require('./manager').mixins;

/* For debugging purposes */
// const util = require('util');

var colorscss = module.exports = {};

colorscss.generate = function(arg) {
    let names = [];
    let themescss = [];
    let content;

    const commentRegex = /(\/\*([\s\S]*?)\*\/)|(\/\/(.*)$)/gm;
    const newLineRegex = /\r?\n|\r/g;

    function chunkify(scss) {
        // Filter sass empty lines and comments, and split all properties into array of arrays.
        return scss
            .replace(commentRegex, "") // remove comments
            .replace(newLineRegex, "") // remove new lines
            .split(';')
            .filter((el) => {
                return (el.length > 0);
        }).map((el) => {
            return el
                .replace(" ", "")
                .split(':');
        });
    }

    function checkvar(property, context) {
        // Search for sass variable in given context and preprocess it
        // (for handle inner sass variables in theme file).
        let start = property.indexOf('$');
        if (start > -1) {
            let sassVar = property.substr(start).match(/((?=.)\W*(\w+(?:-\w+)*|$))/g)[0];
            for (i = 0; i < context.length; i++) {
                if (context[i][0] === sassVar) {
                    property = property.replace(sassVar, context[i][1]);
                    break;
                }
            }
        }
        return property;
    }

    // For every file entry object...
    arg.input.map((obj) => {
        // Loop through this object...
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                // Store key names and parsed files content in variables.
                names.push(key);
                themescss.push(chunkify(read.sync(obj[key], 'utf8')));
            }
        }
    });

    // Turn stored sass declarations into string and generate a final output.
    try {
        content = themescss[0].map((el, i) => {
            return el[0] + ':(' + names.map((elem, j) => {
                return elem + ':' + checkvar(themescss[j][i][1], themescss[j]) + ',';
            }).join('') + ');\n';
        }).join('')
        .concat('\n$prefixes: ' + names.join(' ') + ';\n')
        .concat(mixins);
    } catch (err) {
        console.log("\nERROR: Validation of *.scss themes files failed. \nPlease check if all variables matching.");
        content = '';
    }

    // Save output to a file.
    try {
        fs.writeFileSync(arg.output, content);
    } catch (err) {
        console.log("\nERROR: Can't save the output in the provided path.");
    }

}
