
/**
 * 加法
 */
 function add(...rest) {
    const npArr = rest.map((item) => {
      return (item.toString().split('.')[1] || '').length;
    })
    const baseNum = Math.pow(10, Math.max.apply(null, npArr));
    let i = 0;
    rest.forEach((element) => {
      i += element * baseNum
    });
    return i / baseNum;
  }
  
  /**
   * 减法
   */
  function sub(num1, num2) {
    const baseNum1 = (num1.toString().split('.')[1] || '').length;
    const baseNum2 = (num2.toString().split('.')[1] || '').length;
    const baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
    const precision = (baseNum1 >= baseNum2) ? baseNum1 : baseNum2;
    return ((num1 * baseNum - num2 * baseNum) / baseNum).toFixed(precision);
  }
  
  /**
   * 乘法
   */
  function multi(num1, num2) {
    const baseNum1 = (num1.toString().split('.')[1] || '').length;
    const baseNum2 = (num2.toString().split('.')[1] || '').length;
    const baseNum = baseNum1 + baseNum2;
    return Number(num1.toString().replace('.', '')) * Number(num2.toString().replace('.', '')) / Math.pow(10, baseNum);
  }
  
  /**
   * 除法
   */
  function divide(num1, num2) {
    const baseNum1 = (num1.toString().split('.')[1] || '').length;
    const baseNum2 = (num2.toString().split('.')[1] || '').length;
    const baseNum3 = Number(num1.toString().replace('.', ''));
    const baseNum4 = Number(num2.toString().replace('.', ''));
    return (baseNum3 / baseNum4) * Math.pow(10, baseNum2 - baseNum1);
  }
  
  export { add, sub, multi, divide };
  export default { add, sub, multi, divide };
  