### Install

```
npm install gy-number --save
```

### Usage

```js
import gn from "gy-number";
gn.add(0.2, 0.1, 1, 2); // =3.3
gn.sub(1.0, 0.5); // =0.5
gn.multi(3, 4); // =12
gn.divide(3, 1); // =3
```