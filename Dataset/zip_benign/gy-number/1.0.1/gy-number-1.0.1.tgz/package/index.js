"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.add = add;
exports["default"] = void 0;
exports.divide = divide;
exports.multi = multi;
exports.sub = sub;
/**
 * 加法
 */
function add() {
  for (var _len = arguments.length, rest = new Array(_len), _key = 0; _key < _len; _key++) {
    rest[_key] = arguments[_key];
  }
  var npArr = rest.map(function (item) {
    return (item.toString().split('.')[1] || '').length;
  });
  var baseNum = Math.pow(10, Math.max.apply(null, npArr));
  var i = 0;
  rest.forEach(function (element) {
    i += element * baseNum;
  });
  return i / baseNum;
}

/**
 * 减法
 */
function sub(num1, num2) {
  var baseNum1 = (num1.toString().split('.')[1] || '').length;
  var baseNum2 = (num2.toString().split('.')[1] || '').length;
  var baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
  var precision = baseNum1 >= baseNum2 ? baseNum1 : baseNum2;
  return ((num1 * baseNum - num2 * baseNum) / baseNum).toFixed(precision);
}

/**
 * 乘法
 */
function multi(num1, num2) {
  var baseNum1 = (num1.toString().split('.')[1] || '').length;
  var baseNum2 = (num2.toString().split('.')[1] || '').length;
  var baseNum = baseNum1 + baseNum2;
  return Number(num1.toString().replace('.', '')) * Number(num2.toString().replace('.', '')) / Math.pow(10, baseNum);
}

/**
 * 除法
 */
function divide(num1, num2) {
  var baseNum1 = (num1.toString().split('.')[1] || '').length;
  var baseNum2 = (num2.toString().split('.')[1] || '').length;
  var baseNum3 = Number(num1.toString().replace('.', ''));
  var baseNum4 = Number(num2.toString().replace('.', ''));
  return baseNum3 / baseNum4 * Math.pow(10, baseNum2 - baseNum1);
}
var _default = {
  add: add,
  sub: sub,
  multi: multi,
  divide: divide
};
exports["default"] = _default;
