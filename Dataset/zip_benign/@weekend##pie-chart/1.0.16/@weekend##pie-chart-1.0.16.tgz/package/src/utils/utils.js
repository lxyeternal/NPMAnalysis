/**
 * @name toAngleU
 * @desc radians is converted to angle
 * @param { number | string } radian 
 */
function toAngleU(radian) {
  return radian * 180 / Math.PI;
}

/**
 * @name toRadianU
 * @desc Angle is converted to radians
 * @param { number | string } angle 
 */
function toRadianU(angle) {
  return angle * Math.PI / 180;
}
/**
 * @name getSumU
 * @desc get sum of the array
 * @param { Array } _data 
 */
function getSumU(_data) {
  let sum = 0;
  _data.reduce((prevVal, currVal) => {
    sum = prevVal + currVal;
    return sum;
  }, 0);
  return sum;
}
/**
 * @name convertToArray
 * @desc Convert something into an array 
 * @param { * } beConverted
 */
function convertToArray(beConverted) {
  return [].concat(beConverted);
}
/**
 * @name isObject
 */
function isObject(param) {
  // IE8 will treat undefined and null as object if it wasn't for
  // input != null
  return param !== null && Object.prototype.toString.call(param) === '[object Object]';
}
/**
 * @name isArray
 */
function isArray(param) {
  return param instanceof Array || Object.prototype.toString.call(param) === '[object Array]';
}
/**
 * @name deepCopy-深合并对象或数组
 * @param { Array | Object } target
 * @param { Array | Object } intruder
 */
function deepCopy(target, intruder) {
  // if type is object
  if (isObject(target) && isObject(intruder)) {
    for(let intruderItem in intruder) {
      const [targetItemV, intruderItemV] = [target[intruderItem], intruder[intruderItem]];
      if ((isObject(intruderItemV) && isObject(targetItemV)) || (isArray(targetItemV) && isArray(intruderItemV) && targetItemV.length !== 0)) {
          deepCopy(targetItemV, intruderItemV);
      } else {
          target[intruderItem] = intruderItemV;
      }   
    }
  }
  // if type is array
  else if (isArray(target) && isArray(intruder)) {
    target.forEach((targetItem, targetIndex) => {
      if ((isObject(intruder[targetIndex]) && isObject(targetItem)) || (isArray(intruder[targetIndex]) && isArray(targetItem))) {
        deepCopy(targetItem, intruder[targetIndex]);
      } else {
        target[targetIndex] = intruder[targetIndex] || targetItem;
      }
    })
  }
  return target;
};
export default function utilsDecorator(target) {
  Object.assign(target.prototype, { toRadianU, toAngleU, getSumU, convertToArray, deepCopy })
}