import RootClass from './root';

export default class Ring extends RootClass {
  constructor(ele) {
    super(ele);
    this.draw = this.draw.bind(this);
    this.options = {
      radius: 60,
      percent: '0.3',
      lineWidth: 10,
      lineCap: 'round',
      color: ['#dedede', 'hotpink'],
      text: {
        show: false,
        value: '',
        font: '18px Airal',
        color: 'hotpink',
      },
    };
  }
  /**
   * @name draw
   * @param { object } [options = {}] configuration
   */
  draw(options = {}) {
    // init
    this.deepCopy(this.options, options);
    super.clear();
    // v
    const {
      ctx,
      x0,
      y0,
      // utils
      convertToArray,
    } = this;
    const {
      radius,
      lineWidth,
      lineCap,
      percent,
      color,
      text,
    } = this.options;
    // Draw the background circle
    ctx.lineWidth = lineWidth;
    ctx.beginPath();
    ctx.strokeStyle = color[0];
    ctx.arc(x0, y0, radius, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.closePath();
    // Draw the progress circle
    ctx.beginPath();
    ctx.strokeStyle = color[1];
    ctx.lineCap = lineCap;
    ctx.arc(x0, y0, radius, 0, 2 * percent * Math.PI);
    ctx.stroke();
    ctx.closePath();
    // ? Draw text(maxLength = 2)
    const textArray = convertToArray(text).slice(0, 2);
    textArray.forEach((item, index) => {
      const {
        show: textShow,
        font: textFont,
        value: textValue,
        color: textColor,
      } = item;
      if (textShow) {
        ctx.beginPath();
        ctx.fillStyle = textColor;
        ctx.font = textFont;
        // decision textBaseline
        if (textArray.length === 1) {
          ctx.textBaseline = 'middle';
        } else {
          if (index === 0) {
            ctx.textBaseline = 'bottom';
          } else {
            ctx.textBaseline = 'top';
          }
        }
        ctx.textAlign = 'center';
        ctx.fillText(textValue, x0, y0);
        ctx.closePath();
      }
    })
  }
}