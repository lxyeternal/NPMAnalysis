import RootClass from './root';

export default class Pie extends RootClass {
  constructor(ele) {
    super(ele);
    this.draw = this.draw.bind(this);
    this.options = {
      gradient: false,
      color: [ '#f29567', '#5976b9', '#72b3dd', '#72b3dd', '#87cdc5', '#b0d366', '#efed70', '#f6b167'],
      data: [],
      lable: [],
      innerCircle: {
        show: false,
        color: '#222228',
        radius: 30,
      },
      outerCircle: {
        radius: 100,
        stroke: {
          show: false,
          color: '#000',
          width: '3',
        }
      },
      text: {
        show: false,
        padding: 10,
        font: '13px Airal',
        gradient: false,
        color: [ '#f29567', '#5976b9', '#72b3dd', '#72b3dd', '#87cdc5', '#b0d366', '#efed70', '#f6b167'],
        shadow: {
          show: false,
          width: 20,
          color: [ '#f29567', '#5976b9', '#72b3dd', '#72b3dd', '#87cdc5', '#b0d366', '#efed70', '#f6b167'],
        },
        line: {
          padding: 20,
          width: '2',
          straightLineLength: 25,
          circleRadius: 4,
        },
      }
    };
  }
  /**
   * @name draw
   * @param { object } [options = {}] configuration
   */
  draw(options = {}) {
    // init
    this.deepCopy(this.options, options);
    super.clear();
  
    // v
    const {
      data,
      label,
      gradient: outerGradient,
      color,
      innerCircle: {
        show: innerShow,
        color: innerColor,
        radius: innerRadius,
      },
      outerCircle: {
        radius: outerRadius,
        stroke: {
          show: outerStrokeShow,
          color: outerStrokeColor,
          width: outerStrokeWidth,
        }
      },
      text: {
        show: textShow,
        font: textFont,
        padding: textPadding,
        gradient: textGradient,
        color: textColor,
        shadow: {
          show: shadowShow,
          width: shadowWidth,
          color: shadowColor,
        },
        line: {
          padding: textLinePadding,
          width: textLineWidth,
          straightLineLength,
          circleRadius: textCircleRadius,
        }
      }
    } = this.options;
    const {
      ctx,
      x0,
      y0,
    } = this;
    const sum = this.getSumU(data); // get sum
    let startRadian = 0,
        currindex = -1;

    const animation = () => {
      currindex += 1;
      // calc Radian
      const currRadian = this.toRadianU(data[currindex] / sum * 360);
      const endRadian = startRadian + currRadian;

      // draw fan
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      let fanStyle = '';
      if (outerGradient) {
        fanStyle = ctx.createRadialGradient(x0, y0, innerRadius, x0, y0, outerRadius);
        fanStyle.addColorStop(0, color[currindex][0]);
        fanStyle.addColorStop(1, color[currindex][1]);
      } else {
        fanStyle = color[currindex];
      }
      ctx.fillStyle = fanStyle;
      ctx.arc(x0, y0, outerRadius, startRadian, endRadian);   
      ctx.fill();

      // ? draw fan outline
      if (outerStrokeShow) {
        ctx.strokeStyle = outerStrokeColor;
        ctx.lineWidth = outerStrokeWidth;
        ctx.stroke();
      }
      ctx.closePath();

      // ? draw text
      if (textShow) {
        // draw diagonal
        ctx.save();
        ctx.beginPath();
        // const x0 = x0 + (outerRadius / 2) * Math.cos(endRadian - currRadian / 2);
        // const y0 = x0 + (outerRadius / 2) * Math.sin(endRadian - currRadian / 2);
        let endX = x0 + (outerRadius + textLinePadding) * Math.cos(endRadian - currRadian / 2);
        const endY = x0 + (outerRadius + textLinePadding) * Math.sin(endRadian - currRadian / 2);
        const currAngle = this.toAngleU(endRadian - currRadian / 2);
        let textStyle = '';
        const textColors = textColor || color;
        if (textGradient) {
          textStyle = ctx.createLinearGradient(x0, y0, endX, endY);
          textStyle.addColorStop(0, textColors[currindex][0]);
          textStyle.addColorStop(1, textColors[currindex][1]);
        } else {
          textStyle = textColors[currindex];
        }
        ctx.strokeStyle = textStyle;
        ctx.lineWidth = textLineWidth;
        ctx.moveTo(x0, y0);
        ctx.lineTo(endX, endY);
        
        // draw straight line
        if(currAngle > 90 && currAngle < 270){
          endX -= straightLineLength;
        }else{
          endX += straightLineLength;
        }
        ctx.lineTo(endX, endY);
        ctx.stroke();
        ctx.closePath();

        // draw small dots at the end of a straight line
        ctx.beginPath();
        ctx.arc(endX, endY, textCircleRadius, 0, 2 * Math.PI);
        if (shadowShow) {
          ctx.shadowColor = shadowColor[currindex];
          ctx.shadowBlur = shadowWidth;
        }
        ctx.fill();
        ctx.closePath();

        // draw text
        ctx.beginPath();
        ctx.fillStyle = textStyle;
        ctx.font = textFont;
        ctx.textBaseline = 'middle';
        let textX = endX,
            textY = endY;
        if (currAngle > 90 && currAngle < 270) {
            ctx.textAlign = 'right';
            textX = textX - textPadding;
        } else {
            ctx.textAlign = 'left';
            textX = textX + textPadding;
        }
        ctx.fillText(label[currindex], textX, textY);
        ctx.closePath();
        ctx.restore();
      }
     
      startRadian = endRadian;
      if (currindex < data.length - 1) {
        requestAnimationFrame(animation);
      } else {
        // draw inner radius
        if (innerShow) {
          ctx.beginPath();
          ctx.fillStyle = innerColor;
          ctx.arc(x0, y0, innerRadius, 0, 2 * Math.PI);
          ctx.fill();
          ctx.closePath();
        }
      }
    }
    requestAnimationFrame(animation);
  }
  }