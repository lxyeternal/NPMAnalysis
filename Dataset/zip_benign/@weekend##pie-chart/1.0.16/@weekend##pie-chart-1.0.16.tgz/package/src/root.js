import utilsDecorator from './utils/utils';
@utilsDecorator
export default class RootClass {
  constructor(ele) {
    this.ele = ele;
    this.x0 = this.ele.width / 2;
    this.y0 = this.ele.height / 2;
    this.ctx = this.ele.getContext("2d");
  }
  /**
   * @name clear
   */
  clear() {
    this.ctx.clearRect(0, 0, this.ele.width, this.ele.height);
  }
}