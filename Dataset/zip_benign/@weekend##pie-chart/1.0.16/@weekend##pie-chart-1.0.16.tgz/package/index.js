if (process.env.NODE_ENV === 'production') {
  module.exports = require('./dist/chart-pie.production.min');
} else {
  module.exports = require('./dist/chart-pie.development');
}
