Returns evenly spaced values within given interval.<br>
> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array<br>
> This is browserified, minified version of [@extra-array/linspace].<br>
> It is exported as global variable **array_linspace**.<br>
> CDN: [unpkg], [jsDelivr].

[@extra-array/linspace]: https://www.npmjs.com/package/@extra-array/linspace
[unpkg]: https://unpkg.com/@extra-array/linspace.min
[jsDelivr]: https://cdn.jsdelivr.net/npm/@extra-array/linspace.min

```javascript
array.linspace(v, V, [n]);
// v: start of interval
// V: end of interval
// n: no. of values in between (100)
```

```javascript
const array = require('extra-array');

array.linspace(0, 1, 3);
// [0, 0.5, 1]

array.linspace(0, -1, 5);
// [0, -0.25, -0.5, -0.75, -1]

array.linspace(0, 1);
// [0, ..., 1]  (100 values)
```

### references

- [linspace(): MATLAB](https://in.mathworks.com/help/matlab/ref/linspace.html)
