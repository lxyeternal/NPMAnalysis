# Thoron
FE simulator library.

## Usage

### Configuration object
See the [default config](src/config.js) for an example.
```
{
  unit: {
    strMagSplit, 
    inventory: {
      maxItems
    }
  },
  combat: {
    calcs: {
      hit,
      avd,
      crit,
      cev
    },
    useHit,
    useCrit,
    roll2RN,
    doubleThreshold
  },
  items: {
    limitedUses: true
  }
}
```

`unit`
  * `strMagSplit` **boolean** If true, units have Strength or Magic stats. If false, units have the Attack stat
  * `inventory`
    * `maxItems` **integer** Maximum number of items in a unit's inventory

`combat`
  * `calcs` These objects represent the formulae used to obtain a unit's combat stats (such as hit rate, crit rate) from its base stats (such as skl, luk). The calc output will be the sum of the stats named in the keys (or 'constant') multiplied by the coefficients in the values
    * Examples:
        * `{spd: 2, luk: 0.5}` = 2 * speed + 0.5 * luck
        * `{skl: 0.5, constant: 5}` = 0.5 * skill + 5
    * `hit` **Object** Hit 
    * `avd` **Object** Avoid
    * `crit` **Object** Crit
    * `ceva` **Object** Crit evasion
  * `useHit` **boolean** If false, attacks will never miss
  * `useCrit` **boolean** If false, attacks will never crit
  * `roll2RN` **boolean** If true, accuracy rolls will take the average of two randomly-generated numbers instead of one
  * `doubleThreshold` **integer** The amount of speed difference required for a unit to carry out a follow-up attack in combat

`items`
  * `limitedUses` **boolean** If true, items will break when they run out of uses

## Development
If using Visual Studio Code, install the Yarn SDK for PnP+TypeScript to work in the editor
- `yarn dlx @yarnpkg/sdks vscode`

### NPM Scripts
- `yarn build` Compile project. Optionally add `--sourcemap --watch` flags while testing (see [tsc CLI Options](https://www.typescriptlang.org/docs/handbook/compiler-options.html)).
- `yarn test` Run test suite.