
const fs = require('fs');
const Terser = require('terser');

//*****************************************************************************

fs.mkdirSync(`${__dirname}/dist`, { recursive: true });

const js = fs.readFileSync(`src/Qolor.js`).toString();

fs.writeFileSync(`dist/Qolor.debug.js`, js);
fs.writeFileSync(`dist/Qolor.js`, Terser.minify(js).code);

console.log('done');
