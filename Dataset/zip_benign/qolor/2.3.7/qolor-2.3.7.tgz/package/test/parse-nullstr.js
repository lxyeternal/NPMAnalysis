
const Qolor = require('../src/Qolor.js');

const color1 = Qolor.parse('null');
console.log(color1, color1.isValid());

const color2 = Qolor.parse();
console.log(color2, color2.isValid());

const color3 = Qolor.parse('');
console.log(color3, color3.isValid());

const color4 = Qolor.parse(null);
console.log(color4, color4.isValid());

