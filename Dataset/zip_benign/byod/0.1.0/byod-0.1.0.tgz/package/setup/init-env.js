var fs = require('fs')

fs.writeFileSync('.env', fs.readFileSync('.env-example', 'utf-8'))
