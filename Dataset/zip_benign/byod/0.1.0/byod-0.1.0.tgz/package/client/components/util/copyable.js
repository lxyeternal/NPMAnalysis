import m from 'mithril'

export default {
  oninit(vnode) {
    vnode.state.clicked = false
  },
  view({ state, attrs, children }) {
    var tt = state.clicked ? "Copied!" : attrs.tooltip

    return m('.tooltip.tooltip-bottom.c-hand', {
      'data-tooltip': tt,
      onclick: () => {
        copyToClipboard(attrs.value)
        state.clicked = true
      },
      onmouseenter: () => state.clicked = false,
    }, children)
  }
}

function copyToClipboard (value) {
  var dummy = document.createElement('input')
  document.body.appendChild(dummy)
  dummy.setAttribute('value', value)
  dummy.select()
  document.execCommand("copy")
  document.body.removeChild(dummy)
}