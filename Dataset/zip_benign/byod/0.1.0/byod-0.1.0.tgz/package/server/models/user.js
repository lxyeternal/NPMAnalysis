var utils = require('oauth2orize/lib/utils')


var store = [
  { id: utils.uid(16), name: 'Alice', username: 'alice', password: '123' }
]

exports.find = function (id) {
  var user = store.find(u => u.id === id)
  return user
    ? Promise.resolve(user)
    : Promise.reject(new Error('user_not_found'))
}

exports.findByUsername = function (username) {
  var user = store.find(u => u.username === username)
  return user
    ? Promise.resolve(user)
    : Promise.reject(new Error('user_not_found'))
}
