# Als-settings
**being tested**

- [Als-settings](#als-settings)
  - [About](#about)
    - [new in 0.4.0](#new-in-040)
    - [new in 0.3.1](#new-in-031)
    - [new in 0.3.1](#new-in-031-1)
    - [new in 0.3](#new-in-03)
    - [new in 0.2](#new-in-02)
  - [Basic usage](#basic-usage)
    - [Example](#example)
  - [global.sqlite usage](#globalsqlite-usage)


## About
Add dynamic settings to your project which saved in sqlite db and available for update. 

### new in 0.4.0
  * dependency als-sqlite update to 0.5
  * get method fixed
  * global.sqlite = {Model}


### new in 0.3.1
  * als-sqlite for saving updated to new version

### new in 0.3.1
  * save and get bollean type

### new in 0.3
  * not available as middleware
  * settings data has to be function that getting curent settings state
  * Now available ``process.get`` and ``process.set``
  * Unset by key ``set(key)``
  * Create new key ``set(key,value)`` - if not exsists, creating new setting

### new in 0.2
  * save json data

## Basic usage

Syntax for initialization:
```javascript
let getSettings = require('als-settings')
getSettings(settingsFn:function,restore:Boolean)
```
Parameters:
* **settingsFn** - is a function which get curent settings state and has to return new settings state as object
  * object can include objects and arrays
* **restore** - if true, restore settings with new state

After initialization, you can use the folowing:
```javascript
process.settings.keyForSetting // getting setting by key
process.settings.get(key) // deliting setting by key
process.settings.set(key,value) // adding new setting or updating existing
```

### Example
```javascript
let express = require('express')
let app = express()

let getSettings = require('als-settings')
let dev = true

//restore false by default
getSettings(function(settings) {
   let secret = settings.secret ? settings.secret : require('crypto').randomBytes(64).toString('hex')
   return {
      site_name:'test',
      roles: ['dev','admin','editor','user','subscriber','commentor'],
      secret,
   }
},dev)

app.get('/set/:site_name',(req,res) => {
   req.settings.set('site_name',req.params.site_name) // setting new value to key and update process.settings
})
app.get('/use',(req,res) => {
   // getting value
   return res.end(`<div>${process.settings.site_name}</div>`)
})
app.get('/refresh',(req,res) => {
   req.settings.get('key','value') // updating process.settings from db
   return res.end('done')
})

app.listen(3000)
```

## global.sqlite usage
You can use sqlite db with als-sqlite which available as ``global.sqlite.Model``.
The Model allready connected to db and has all existing models inside ``global.sqlite.Model.models``. 

Read more in https://www.npmjs.com/package/als-sqlite