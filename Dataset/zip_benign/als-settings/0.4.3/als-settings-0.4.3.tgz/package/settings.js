const {existsSync} = require('fs')
let {Schema,connect,Model} = require('als-sqlite')

module.exports = function(settings,restore=false) {
   let settingSchema = new Schema({
      key:{type:'text',default:'',unique:true},
      value:{type:'text',default:''},
      data:{type:'json',default:{}},
   })
   let dbPath = require('path').join(__dirname,'settings.sqlite')
   if(!existsSync(dbPath)) Model.migrate = true
   Model.db = connect(dbPath)
   // let Setting = new Model('settings',settingSchema)
   let Setting = Model.table('settings',settingSchema)
   if(Model.migrate || restore) {
      settings = settings(get())
      if(restore) {
         Setting.restore()
      }
      let newObj = Object.keys(settings).map(key => {
         value = settings[key]
         if(typeof value == 'object') 
            return {key,value:'json',data:value} 
         else return {key,value}
      })
      Setting.insertMany(newObj)
      console.log('Settings updated')
   }

   global.sqlite = {Model}

   function get() {
      let settings = Setting.find({})
      if(!process.settings) process.settings = {}
      if(settings) settings.forEach(obj => {
         let value = obj.value
         if(value == 'json') value = obj.data
         process.settings[obj.key] = value
      });
      process.settings.get = get
      process.settings.set = set
      return process.settings
   }
   
   function set(key,value) {
      let isExists = Setting.select().where({key}).get()
      if(isExists !== null && value == undefined) {
         Setting.delete({key})
      } else if(isExists !== null) {
         if(typeof value == 'object') Setting.update({key},{data:value})
         else Setting.update({key},{value})
      } else {
         let data = {}
         if(typeof value == 'object') {
            data = value
            value = 'json'
         }
         Setting.insert({key,value,data})
      }
      get()
   }
   get()

}