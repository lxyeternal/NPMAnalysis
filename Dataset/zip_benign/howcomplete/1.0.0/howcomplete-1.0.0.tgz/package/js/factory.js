module.exports = function(options){
  var options = options || {};
  this.sources = [];
  this.onchange = options.onchange;
  this.completionScore = 0;
  this.disabled = false;
  if(options.sources){
    this.addSources(options.sources);
  }

  this.disable = function(){
    this.disabled = true;
  };

  this.enable = function(){
    this.disabled = false;
    this.calculateCompleteness(true);
  };
  
  this.addSources = function(sources){
    var that = this;
    $.each(sources, function(index, source){
      that.addSource(source);
    });
  };

  this.addSource = function(options){
    options = options || {};
    options.calculator = this;
    var source = new Source(options);
    this.sources.push(source);
    return source;
  };

  this.completeness = function(){
    var score = 0;
    var that = this;
    $.each(this.sources, function(index, source){
      if(source.data){
        score += source.data*source.weight;
      }
    });
    return score;
  };

  this.calculateCompleteness = function(forceCalculate){
    var newScore = this.completeness();
    newScore = +newScore.toFixed(2);
    if(this.completionScore !== newScore || forceCalculate){
      this.completionScore = newScore;
      if(this.onchange && !this.disabled){
        this.onchange.call(this, this.completionScore);
      }
    }
  };

  var Source = function(options){
    this.weight = options.weight;
    this.calculator = options.calculator;
    this.data = options.data;

    this.update = function(data){
      this.data = data;
      this.calculator.calculateCompleteness.call(this.calculator);
    };
  };
}
