<template>
  <input
    ref="file"
    type="file"
    :accept="accept"
    :multiple="multiple"
    style="display: none;"
    @change="changeFile"
  />
</template>

<script>
export default {
  name: 'CompressImg',
  props: {
    accept: {
      type: String,
      default: () => 'image/*'
    },
    multiple: {
      type: Boolean,
      default: () => false
    },
    quality: { // 压缩质量0~1之间；【默认：0.2】；经过测验，quality=0.2~0.5之间的时候，图片保真率最高
      type: Number,
      default: () => 0.2
    },
    maxWidth: Number,
    maxHeight: Number,
    compressLimit: { // 图片超过限制之后才启用压缩；【默认：10KB】
      type: Number,
      default: () => 10
    }
  },
  data () {
    return {}
  },
  methods: {
    trigger () {
      this.$refs.file.click()
    },
    changeFile (e) {
      const files = e.target.files
      this.compressImg(files, this.quality, this.compressLimit).then(data => {
        this.$refs.file.value = null
        this.$emit('success', data)
      })
    },
    createFileReader (file) {
      return new Promise((resolve) => {
        const reader = new FileReader() // 创建 FileReader
        reader.onload = ({ target: { result: src } }) => {
          resolve(src)
        }
        reader.readAsDataURL(file)
      })
    },
    /**
     * 图片压缩
     * file：文件对象，支持多个图片
     * quality：压缩质量0~1之间；【默认：0.2】；经过测验，quality=0.2~0.5之间的时候，图片保真率最高
     * compressLimit：图片超过限制之后才启用压缩；【默认：10KB】
     * */
    compressImg (file, quality = 0.2, compressLimit = 10) {
      const dpi = Math.round(window.devicePixelRatio || 1)
      if (file[0]) { // 如果file是数组，则返回 Promise 数组
        return Promise.all(Array.from(file).map(e => this.compressImg(e, quality, compressLimit)))
      } else {
        return new Promise((resolve) => {
          if ((file.size / 1024).toFixed(2) < compressLimit) { // 小于10KB不压缩
            this.createFileReader(file).then(src => {
              resolve({
                file: file,
                origin: file,
                beforeSrc: src,
                afterSrc: src,
                beforeKB: Number((file.size / 1024).toFixed(2)),
                afterKB: Number((file.size / 1024).toFixed(2))
              })
            })
          } else {
            this.createFileReader(file).then(src => {
              const image = new Image() // 创建 img 元素
              image.onload = () => {
                const canvas = document.createElement('canvas') // 创建 canvas 元素
                const context = canvas.getContext('2d')
                let targetWidth = image.width
                let targetHeight = image.height
                const originWidth = image.width
                const originHeight = image.height
                let maxWidth = image.width
                let maxHeight = image.height
                if (this.maxWidth || this.maxHeight) {
                  maxWidth = this.maxWidth || image.width
                  maxHeight = this.maxHeight || image.height
                } else if (1 * 1024 <= parseInt((file.size / 1024).toFixed(2)) && parseInt((file.size / 1024).toFixed(2)) <= 10 * 1024) { // 1M~10M之间，控制最大宽高限制：1600x1600
                  maxWidth = 1600
                  maxHeight = 1600
                } else if (10 * 1024 <= parseInt((file.size / 1024).toFixed(2)) && parseInt((file.size / 1024).toFixed(2)) <= 20 * 1024) { // 10M~20M之间，控制最大宽高限制：1400x1400
                  maxWidth = 1400
                  maxHeight = 1400
                } else { // 大于20M，控制最大宽高限制：1024x1024
                  maxWidth = 1024
                  maxHeight = 1024
                }
                // 图片尺寸超过的限制
                if (originWidth > maxWidth || originHeight > maxHeight) {
                  if (originWidth / originHeight > maxWidth / maxHeight) {
                    // 更宽，按照宽度限定尺寸
                    targetWidth = maxWidth
                    targetHeight = Math.round(maxWidth * (originHeight / originWidth))
                  } else {
                    targetHeight = maxHeight
                    targetWidth = Math.round(maxHeight * (originWidth / originHeight))
                  }
                }
                canvas.width = targetWidth * dpi
                canvas.height = targetHeight * dpi
                canvas.style.width = `${targetWidth}px`
                canvas.style.height = `${targetHeight}px`
                context.scale(dpi, dpi)
                context.clearRect(0, 0, targetWidth, targetHeight)
                context.drawImage(image, 0, 0, targetWidth, targetHeight) // 绘制 canvas
                const canvasURL = canvas.toDataURL('image/jpeg', quality)
                const buffer = atob(canvasURL.split(',')[1])
                let length = buffer.length
                const bufferArray = new Uint8Array(new ArrayBuffer(length))
                while (length--) {
                  bufferArray[length] = buffer.charCodeAt(length)
                }
                const miniFile = new File([bufferArray], file.name, {
                  type: 'image/jpeg'
                })
                resolve({
                  file: miniFile,
                  origin: file,
                  beforeSrc: src,
                  afterSrc: canvasURL,
                  beforeKB: Number((file.size / 1024).toFixed(2)),
                  afterKB: Number((miniFile.size / 1024).toFixed(2))
                })
              }
              image.src = src
            })
          }
        })
      }
    }
  }
}
</script>
