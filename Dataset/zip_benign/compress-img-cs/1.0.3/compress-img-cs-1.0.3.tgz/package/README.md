# compress-img-cs

> 图片压缩

### Install

``` bash
npm install compress-img-cs --save
```

### Usage
``` bash
import CompressImg from 'compress-img-cs'

<compress-img
  ref="compress"
  accept="images/*"
  multiple
  :quality="0.2"
  :compressLimit="10"
  @success="compressSuccess"
/>

this.$refs.compress.trigger() // 触发上传
```

### Props
| 字段名称 | 类型 | 说明 | 默认值 |
| --- | --- | --- | --- |
| accept | String | 上传文件格式 | image/* |
| multiple | Boolean | 是否支持多选 | false |
| quality | Number | 压缩质量（0~1之间）经过测验，0.2~0.5之间的时候，图片保真率最高 | 0.2 |
| compressLimit | Number | 图片超过限制之后才启用压缩【默认：10KB】 | 10 |
| maxWidth | Number | 压缩最大宽度 | - |
| maxHeight | Number | 压缩最大高度 | - |
