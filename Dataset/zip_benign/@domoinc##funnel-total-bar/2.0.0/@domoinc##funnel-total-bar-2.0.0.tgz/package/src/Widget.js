//----------------------------------------------------------------------------------
//----------------------------------------------------------------------------------
// FunnelTotalBar:
//----------------------------------------------------------------------------------
//----------------------------------------------------------------------------------
var d3 = require('d3');
var d3Chart = require('d3.chart');
var BaseWidget = require('@domoinc/base-widget');
var da = require('@domoinc/utilities');
var daTheme2 = require('@domoinc/da-theme2');
var SummaryNumber = require('@domoinc/summary-number');

var _ = require('lodash');

module.exports = BaseWidget.extend('FunnelTotalBar', {
  initialize: function() {
    'use strict';

    var _Chart = this;

    //----------------------------------------------------------------------------------
    // Config
    // https://git.empdev.domo.com/AppTeam6/Domographics-shared/wiki/Config-Definition
    //----------------------------------------------------------------------------------
    this._newConfig = {
      chartName: {
        description: 'Name of chart for Reporting.',
        type: 'string',
        value: 'FunnelTotalBar'
      },

      prefix: {
        description: 'Text added before the value',
        value: '$',
        type: 'string',
      },
      formatFunction: {
        description: 'Function used to format value.',
        type: 'n/a',
        value: function(d) {
          return summaryNumberService.summaryNumber(d);
        }
      },

      transitionInTime: {
        value: 500,
        type: 'number',
        units: 'ms'
      },


      padding: {
        description: 'Range Band Padding [0,1].  0.5 means padding and bar width are equal.',
        value: 0.2,
        type: 'number',
        units: 'decimal'
      },
      outerPadding: {
        description: 'Range Band Outer Padding [0,1].  0.5 means padding and bar width are equal. Outer === on outer edges.',
        value: 0,
        type: 'number',
        units: 'decimal'
      },
      chartPrimarySeriesColors: daTheme2.themeElements.primaryColorSeries(),

      textFontFamily: daTheme2.themeElements.h5FontFamily(),
      textSize: daTheme2.themeElements.h5FontSize(),
      textColor: {
        name: 'Bars Text Color',
        description: 'Color of text inside bars',
        value: '#FFF'
      },

      generalWashoutColor: daTheme2.themeElements.washoutColor(),
    };
    this.mergeConfig(_Chart._newConfig);

    //----------------------------------------------------------------------------------
    // Data Definition:
    // Types : 'string', 'number', 'date'
    //----------------------------------------------------------------------------------
    _Chart._newDataDefinition = {
      'label': {
        type: 'string',
        validate: function(d) {
          return this.accessor(d) !== undefined;
        },
        accessor: function(line) {
          return line[0] === undefined ? undefined : String(line[0]);
        }
      },
      'value': {
        type: 'number',
        validate: function(d) {
          return !isNaN(this.accessor(d)) && this.accessor(d) >= 0;
        },
        accessor: function(line) {
          return Number(line[1]);
        }
      }
    };
    this.mergeDataDefinition(_Chart._newDataDefinition);

    //----------------------------------------------------------------------------------
    // Interface - This is where you document your events. The chart's .on()' and
    // '.trigger()' methods will go here.
    //----------------------------------------------------------------------------------
    _Chart.on('external:mouseenter', externalMouseEnter);
    _Chart.on('external:mouseleave', externalMouseLeave);

    //----------------------------------------------------------------------------------
    // Static - Anything that is defined here will never change
    //----------------------------------------------------------------------------------
    var summaryNumberService = new SummaryNumber();

    var barLayoutScale = d3.scale.ordinal();
    var colorScale = d3.scale.ordinal();
    var isManuelColorScale = false;
    var barHeightPercent = 0.65;

    _Chart._transitionLock = 0;
    _Chart.incTransitionLock = function() {
      _Chart._transitionLock++;
    };
    _Chart.decTransitionLock = function() {
      if (_Chart._transitionLock > 0) _Chart._transitionLock--;
    };
    _Chart.transitionLocked = function() {
      return _Chart._transitionLock !== 0;
    };

    _Chart._currentLabels = null;

    this.transform = function(data) {

      var validData = _.uniq(_Chart.validateData(data), _Chart.a('label'));

      _Chart._currentLabels = validData.map(_Chart.a('label'));

      setupScale(barLayoutScale, _Chart._currentLabels);

      if (!isManuelColorScale) {
        colorScale
          .domain(_Chart._currentLabels)
          .range(daTheme2.getPrimaryColorsForNumberOfSeries(_Chart._currentLabels.length, _Chart.c('chartPrimarySeriesColors')));
      }

      return validData;
    };

    //----------------------------------------------------------------------------------
    // Layers: This is where you'll place your layers.
    //----------------------------------------------------------------------------------
    _Chart.layer('layer', this._layerGroup, {
      dataBind: function(validData) {
        return this.selectAll('g.tLabels').data(validData);
      },
      insert: function() {
        var groups = this.append('g').attr('class', 'tLabels').style('opacity', 0);

        groups.append('rect')
          .attr('class', 'background')
          .style('opacity', 0);

        groups.append('rect').attr('class', 'colored');

        groups.append('text').attr('class', 'value');

        groups.append('text').attr('class', 'label');

        return groups;
      }
    })
    .on('enter', function() {
      this.selectAll('text').style('pointer-events', 'none');

      return this
        .on('mouseenter', mouseenter)
        .on('mouseleave', mouseleave);
    })
    .on('merge', function() {
      _Chart._transitionLock = 0;

      drawBackgroundRects(this);
      drawBars(this);
      drawValueLabels(this);
      drawLabels(this);

      this
        .style('fill', function(d, i) {
          return colorScale(_Chart.a('label')(d));
        })
        .transition().duration(_Chart.c('transitionInTime')).style('opacity', 1);

      return this;
    })
    .on('exit', function() {
      return this.transition().style('opacity', 0).remove();
    });

    function drawBackgroundRects(gSelection) {
      var barWidth = _Chart.c('width') / gSelection[0].length;

      gSelection.select('rect.background')
        .attr({
          'height': _Chart.c('height'),
          'width': barWidth,
          'x': function(d, i) {
            return i * barWidth;
          }
        })
    }

    function drawBars(gSelection) {
      _Chart.incTransitionLock();

      gSelection.select('rect.colored')
        .transition()
        .attr({
          'height': (barHeightPercent * _Chart.c('height')),
          'width': barLayoutScale.rangeBand(),
          'x': function(d, i) {
            return barLayoutScale(_Chart.a('label')(d));
          }
        })
        .call(d3.DomoTransitionEndAll, _Chart.decTransitionLock);
    }

    function drawValueLabels(gSelection) {
      _Chart.incTransitionLock();

      gSelection.select('text.value')
        .text(function(d, i) {
          return _Chart.c('prefix') + _Chart.c('formatFunction')(_Chart.a('value')(d));
        })
        .style({
          'font-size': _Chart.c('textSize') + 'px',
          'font-family': _Chart.c('textFontFamily'),
          'fill': _Chart.c('textColor'),
          'text-anchor': 'middle',
          'font-weight': 500
        })
        .transition()
        .attr({
          dy: _Chart.c('textSize') * 0.35,
          x: function(d, i) {
            return barLayoutScale(_Chart.a('label')(d)) + barLayoutScale.rangeBand() / 2.0;
          },
          y: ((barHeightPercent / 2.0) * _Chart.c('height'))
        })
        .call(d3.DomoTransitionEndAll, _Chart.decTransitionLock);
    }

    function drawLabels(gSelection) {
      _Chart.incTransitionLock();

      var labels = gSelection.select('text.label');

      labels
        .text(_Chart.a('label'))
        .attr({
          x: function(d, i) {
            return barLayoutScale(_Chart.a('label')(d)) + barLayoutScale.rangeBand() / 2.0;
          },
          y: (barHeightPercent * _Chart.c('height'))
        })
        .style({
          'opacity': 0,
          'font-size': (_Chart.c('textSize') - 2) + 'px',
          'font-family': _Chart.c('textFontFamily'),
          'text-anchor': 'middle',
          'letter-spacing': 1,
          'font-weight': 600
        });

      var s = null;
      var min = Number.MAX_VALUE;
      labels
        .each(function() {
          s = d3.select(this);
          d3.domoStrings.shrinkToTrunc(s, barLayoutScale.rangeBand() + 5, (_Chart.c('height') * (1 - barHeightPercent)) + 5, (_Chart.c('textSize') - 2));
          min = (parseInt(s.style('font-size')) < min ? parseInt(s.style('font-size')) : min);
        })
        .style('font-size', min + 'px');

      labels.transition()
        .delay(_Chart.c('transitionInTime') * 0.20)
        .transition()
        .style('opacity', 1)
        .attr({
          y: _Chart.c('height')
        })
        .call(d3.DomoTransitionEndAll, _Chart.decTransitionLock);
    }

    //----------------------------------------------------------------------------------
    // Helper Functions
    //----------------------------------------------------------------------------------
    function setupScale(scale, labels) {
      scale
        .domain(labels)
        .rangeBands([0, _Chart.c('width')], _Chart.c('padding'), _Chart.c('outerPadding'));
    }

    function highlightLabel(label) {
      if (_Chart.transitionLocked()) return;

      _Chart._layerGroup.selectAll('.tLabels')
        .style('fill', function(dd, ii) {
          return _Chart.a('label')(dd) === label ? colorScale(label) : _Chart.c('generalWashoutColor');
        })
    }

    function colorTLabels() {
      if (_Chart.transitionLocked()) return;

      _Chart._layerGroup.selectAll('.tLabels')
        .style('fill', function(d, i) {
          return colorScale(_Chart.a('label')(d));
        });
    }

    function mouseenter(d, i) {
      if (_Chart.transitionLocked()) return;

      var label = _Chart.a('label')(d);
      highlightLabel(label);

      _Chart.trigger('dispatch:mouseenter', {
        series: label,
        name: label,
        data: d
      })
    }

    function mouseleave() {
      if (_Chart.transitionLocked()) return;
      colorTLabels();

      _Chart.trigger('dispatch:mouseleave');
    }

    function externalMouseEnter(obj) {
      if (_Chart._currentLabels.indexOf(obj.name) > -1) {
        highlightLabel(obj.name);
      } else if (_Chart._currentLabels.indexOf(obj.series) > -1) {
        highlightLabel(obj.series);
      } else {
        colorTLabels();
      }
    }

    function externalMouseLeave() {
      colorTLabels();
    }

    _Chart.getBarHeightPercent = function() {
      return barHeightPercent;
    };
    _Chart.getColorScale = function() {
      return colorScale;
    };
    _Chart.setColorScale = function(newScale) {
      isManuelColorScale = true;
      colorScale = newScale;
    };

    _Chart.getBoxLayoutDataForNum = function(num) {
      var labels = d3.range(0, num);

      var tmpScale = d3.scale.ordinal();
      setupScale(tmpScale, labels);

      var tmp = [];
      for (var i = 0; i < num; i++) {
        tmp.push(tmpScale(labels[i]) + tmpScale.rangeBand() / 2.0);
      }

      return tmp;
    };
  }
});

