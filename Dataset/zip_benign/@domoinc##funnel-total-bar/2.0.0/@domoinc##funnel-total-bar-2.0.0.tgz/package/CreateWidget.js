var data = [
  ['SEM', 202398402938402394],
  ['DISPLAY', 1778.20123],
  ['SOCIAL', 100.0],
  ['FIELD', 10]
];

var data2 = [
  ['SEM', 2.10],
  ['DISPLAY', 1.20],
  ['SOCIAL', 1.05],
  ['FIELD', 0.95],
  ['SEM2', 2.10],
  ['DISPLAY2', 1.20],
  ['SOCIAL2', 1.05],
  ['FIELD2', 0.95]
];

var aHeight = 55;
var aWidth = 450;

//Initialze the widget
var chart = d3.select("#vis")
  .append("svg")
  .attr({
    height: '5000px',
    width: '5000px'
  })
  .append("g")
  .chart("FunnelTotalBar")
  .c({
    width: aWidth,
    height: aHeight
  });

//Render the chart with data
chart._notifier.showMessage(true);
chart.draw(data);

// setTimeout(function () {
//   chart.draw(data2)

//   chart.trigger('external:mouseenter', {series: 'SEM', name:'SEM', data: null});

// }, 1500);
// setTimeout(function () {
//   chart.draw(data)
// }, 4000);

// d3.select("svg").insert("rect", ":first-child")
//   .attr("height", aHeight)
//   .attr("width", aWidth)
//   .attr("stroke", "black")
//   .style("fill", "#2F3132")
//   .style("fill", "lightgrey")
//   .style("fill-opacity",0.5);

