# FunnelTotalBar





## Configuration Options


#### chartName
Type: `string`  
Default: `"FunnelTotalBar"`  

Name of chart for Reporting.

#### chartPrimarySeriesColors
Type: `colorArray`  
Default: `[["#D9EBFD","#B7DAF5","#90c4e4","#73B0D7","#4E8CBA","#31689B"],["#DDF4BA","#BBE491","#A0D771","#80C25D","#559E38","#387B26"],["#FDECAD","#FCCF84","#FBAD56","#FB8D34","#E45621","#A43724"],["#F3E4FE","#DDC8EF","#C5ACDE","#B391CA","#8F6DC0","#7940A1"],["#FCD7E6","#FBB6DD","#F395CD","#EE76BF","#CF51AC","#A62A92"],["#D8F4DE","#ABE4CA","#8DD5BE","#68BEA8","#46998A","#227872"],["#FDDDDD","#FCBCB7","#FD9A93","#FD7F76","#e45850","#c92e25"]]`  

The primary colors used to represent series data

#### formatFunction
Type: `n/a`  
Default: `"function (d) {\n\t          var numObj = i18n.summaryNumberToObject(d);\n\t          return i18n.toLocaleString(\n\t            numObj.prefix,\n\t            i18n.getLanguage(), {\n\t              style: 'currency',\n\t              currency: i18n.getCurrency(),\n\t              minimumFractionDigits: (numObj.magnitude === '' && Number(numObj.prefix) < 100 ? 2 : 0)\n\t            }\n\t          ) + numObj.magnitude;\n\t        }"`  

Function used to format value.

#### generalWashoutColor
Type: `color`  
Default: `"#E4E5E5"`  

Color used to indicate elements that are not being highlighted

#### height
Type: `number`  
Default: `250`  
Units: `px`



#### isOnMobile
Type: `boolean`  
Default: `false`  

If true, it signals to the widget that it is running on a mobile device. Should be called before draw and then NEVER changed.

#### outerPadding
Type: `number`  
Default: `0`  
Units: `decimal`

Range Band Outer Padding [0,1].  0.5 means padding and bar width are equal. Outer === on outer edges.

#### padding
Type: `number`  
Default: `0.2`  
Units: `decimal`

Range Band Padding [0,1].  0.5 means padding and bar width are equal.

#### shouldValidate
Type: `boolean`  
Default: `true`  

Flag for turning off data validation

#### textColor
Type: `undefined`  
Default: `"#FFF"`  

Color of text inside bars

#### textFontFamily
Type: `string`  
Default: `"Open Sans"`  



#### textSize
Type: `number`  
Default: `12`  
Units: `px`



#### transitionInTime
Type: `number`  
Default: `500`  
Units: `ms`

undefined

#### updateSizeableConfigs
Type: `boolean`  
Default: `true`  

Flag for turning off the mimic of illustrator's scale functionality

#### width
Type: `number`  
Default: `250`  
Units: `px`



## Data Definition


#### label
Type: `string`

Default validate:  
```js
function (d) {
	          return this.accessor(d) !== undefined;
	        }
```

Default accessor:  
```js
function (line) {
	          return line[0] === undefined ? undefined : String(line[0]);
	        }
```

#### value
Type: `number`

Default validate:  
```js
function (d) {
	          return !isNaN(this.accessor(d)) && this.accessor(d) >= 0;
	        }
```

Default accessor:  
```js
function (line) {
	          return Number(line[1]);
	        }
```

## Events


#### Dispatch Events

dispatch:mouseenter  
dispatch:mouseleave  
#### External Events

external:mouseenter  
external:mouseleave  

## Example

```js  
var data = [
  ['SEM', 202398402938402394],
  ['DISPLAY', 1778.20],
  ['SOCIAL', 100.05],
  ['FIELD', 10.95]
];

var data2 = [
  ['SEM', 2.10],
  ['DISPLAY', 1.20],
  ['SOCIAL', 1.05],
  ['FIELD', 0.95],
  ['SEM2', 2.10],
  ['DISPLAY2', 1.20],
  ['SOCIAL2', 1.05],
  ['FIELD2', 0.95]
];

var aHeight = 55;
var aWidth = 450;

//Initialze the widget
var chart = d3.select("#vis")
  .append("svg")
  .attr({
    height: '5000px',
    width: '5000px'
  })
  .append("g")
  .chart("FunnelTotalBar")
  .c({
    width: aWidth,
    height: aHeight
  });

//Render the chart with data
chart._notifier.showMessage(true);
chart.draw(data);

// setTimeout(function () {
//   chart.draw(data2)

//   chart.trigger('external:mouseenter', {series: 'SEM', name:'SEM', data: null});

// }, 1500);
// setTimeout(function () {
//   chart.draw(data)
// }, 4000);

// d3.select("svg").insert("rect", ":first-child")
//   .attr("height", aHeight)
//   .attr("width", aWidth)
//   .attr("stroke", "black")
//   .style("fill", "#2F3132")
//   .style("fill", "lightgrey")
//   .style("fill-opacity",0.5);


```

