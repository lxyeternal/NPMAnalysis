## Events


#### Dispatch Events

dispatch:mouseenter  
dispatch:mouseleave  
#### External Events

external:mouseenter  
external:mouseleave  

