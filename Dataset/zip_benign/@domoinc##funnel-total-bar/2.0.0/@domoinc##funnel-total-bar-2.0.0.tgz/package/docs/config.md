## Configuration Options


#### chartName
Type: `string`  
Default: `"FunnelTotalBar"`  

Name of chart for Reporting.

#### chartPrimarySeriesColors
Type: `colorArray`  
Default: `[["#D9EBFD","#B7DAF5","#90c4e4","#73B0D7","#4E8CBA","#31689B"],["#DDF4BA","#BBE491","#A0D771","#80C25D","#559E38","#387B26"],["#FDECAD","#FCCF84","#FBAD56","#FB8D34","#E45621","#A43724"],["#F3E4FE","#DDC8EF","#C5ACDE","#B391CA","#8F6DC0","#7940A1"],["#FCD7E6","#FBB6DD","#F395CD","#EE76BF","#CF51AC","#A62A92"],["#D8F4DE","#ABE4CA","#8DD5BE","#68BEA8","#46998A","#227872"],["#FDDDDD","#FCBCB7","#FD9A93","#FD7F76","#e45850","#c92e25"]]`  

The primary colors used to represent series data

#### formatFunction
Type: `n/a`  
Default: `"function (d) {\n\t          var numObj = i18n.summaryNumberToObject(d);\n\t          return i18n.toLocaleString(\n\t            numObj.prefix,\n\t            i18n.getLanguage(), {\n\t              style: 'currency',\n\t              currency: i18n.getCurrency(),\n\t              minimumFractionDigits: (numObj.magnitude === '' && Number(numObj.prefix) < 100 ? 2 : 0)\n\t            }\n\t          ) + numObj.magnitude;\n\t        }"`  

Function used to format value.

#### generalWashoutColor
Type: `color`  
Default: `"#E4E5E5"`  

Color used to indicate elements that are not being highlighted

#### height
Type: `number`  
Default: `250`  
Units: `px`



#### isOnMobile
Type: `boolean`  
Default: `false`  

If true, it signals to the widget that it is running on a mobile device. Should be called before draw and then NEVER changed.

#### outerPadding
Type: `number`  
Default: `0`  
Units: `decimal`

Range Band Outer Padding [0,1].  0.5 means padding and bar width are equal. Outer === on outer edges.

#### padding
Type: `number`  
Default: `0.2`  
Units: `decimal`

Range Band Padding [0,1].  0.5 means padding and bar width are equal.

#### shouldValidate
Type: `boolean`  
Default: `true`  

Flag for turning off data validation

#### textColor
Type: `undefined`  
Default: `"#FFF"`  

Color of text inside bars

#### textFontFamily
Type: `string`  
Default: `"Open Sans"`  



#### textSize
Type: `number`  
Default: `12`  
Units: `px`



#### transitionInTime
Type: `number`  
Default: `500`  
Units: `ms`

undefined

#### updateSizeableConfigs
Type: `boolean`  
Default: `true`  

Flag for turning off the mimic of illustrator's scale functionality

#### width
Type: `number`  
Default: `250`  
Units: `px`



