var webpack = require('webpack');
var config = {
  entry: './src/Widget',
  output: {
    path: __dirname + '/dist',
    publicPath: '/dist/',
    filename: 'bundle.js',
    libraryTarget: 'umd',
    library: 'FunnelTotalBar'
  },
  plugins: [
    new webpack.BannerPlugin('Copyright 2016 Domo Inc.')
  ],
  externals: {
    d3: 'd3',
    'd3.chart': 'd3.chart',
    'lodash': {
      root: '_',
      commonjs: 'lodash',
      commonjs2: 'lodash',
      amd: 'lodash'
    },
    '@domoinc/base-widget': {
      root: 'BaseWidget',
      commonjs: '@domoinc/base-widget',
      commonjs2: '@domoinc/base-widget',
      amd: 'base-widget'
    },
    '@domoinc/summary-number': {
      root: 'SummaryNumber',
      commonjs: '@domoinc/summary-number',
      commonjs2: '@domoinc/summary-number',
      amd: 'summary-number'
    },
    '@domoinc/utilities': {
      root: 'da',
      commonjs: '@domoinc/utilities',
      commonjs2: '@domoinc/utilities',
      amd: 'utilities'
    },
    '@domoinc/da-theme2': {
      root: ['da', 'theme2'],
      commonjs: '@domoinc/da-theme2',
      commonjs2: '@domoinc/da-theme2',
      amd: 'da-theme2'
    }
  }
};

config.setDev = function() {
  var externals = config.externals;
  delete config.externals;
  config.entry = {
    app: config.entry,
    vendor: Object.keys(externals)
  };
  config.plugins.push(new webpack.optimize.CommonsChunkPlugin(/* chunkName= */"vendor", /* filename= */"vendor.bundle.js"));
}
if (process.env.NODE_ENV === 'development') {
  config.setDev();
}

module.exports = config;
