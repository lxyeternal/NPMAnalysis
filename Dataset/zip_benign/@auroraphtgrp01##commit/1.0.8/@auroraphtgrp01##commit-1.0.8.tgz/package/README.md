# ✨ @auroraphtgrp01/commit ✨

[![Version](https://img.shields.io/badge/version-1.0.3-blue?style=for-the-badge)](https://github.com/auroraphtgrp01)
[![Powered by Gemini AI](https://img.shields.io/badge/powered%20by-Gemini%20AI-purple?style=for-the-badge)](https://makersuite.google.com/app/apikey)

## Elevate your git workflow with AI-crafted commit messages

---

## 🌟 Overview

A sophisticated CLI tool that harnesses the power of Google's Gemini AI to craft elegant, meaningful commit messages. Say goodbye to the tedium of formatting and wording—let AI handle the details while you focus on your code.

## 👨‍💻 Creator

[auroraphtgrp01](https://github.com/auroraphtgrp01)

**Crafting elegant developer experiences**

## ✨ Capabilities

- **AI-Powered Generation** — Creates contextually relevant commit messages based on your staged changes
- **Conventional Format** — Adheres to industry-standard commit conventions with appropriate emojis
- **Personalization** — Offers the flexibility to select from AI suggestions or craft your own message
- **Streamlined Workflow** — Features options to automatically stage changes and push commits
- **Elegant Interface** — Presents a beautiful, intuitive CLI experience

## 💎 Installation

```bash
# Global installation for regular use
npm install -g @auroraphtgrp01/commit

# Or use on demand without installation
npx @auroraphtgrp01/commit
```

## ⚙️ Configuration

Create an `auroraphtgrp01.json` configuration file in your project root:

```json
{
  "model": "gemini-pro",
  "temperature": 0.5,
  "maxTokens": 2048,
  "geminiToken": "YOUR_GEMINI_API_TOKEN"
}
```

*Obtain your Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)*

## 🚀 Usage

```bash
# Standard usage
npx @auroraphtgrp01/commit

# With workflow enhancements
npx @auroraphtgrp01/commit -a -p
```

### Elegant Options

| Option | Enhancement |
|:------:|-------------|
| `-a` | Gracefully stages all changes (`git add .`) before committing |
| `-p` | Seamlessly pushes your changes after committing |

Combine for a streamlined experience:
```bash
# Complete workflow: stage, commit, and push
npx @auroraphtgrp01/commit -a -p
```

## 🔄 Refined Workflow

1. **Prepare** — Stage your changes with `git add` (or use the elegant `-a` option)
2. **Generate** — Invoke the tool to create AI-powered commit messages
3. **Select** — Choose from thoughtfully crafted suggestions or compose your own
4. **Commit** — Your changes are committed with the selected message
5. **Share** — With the `-p` option, your work is automatically pushed to the remote repository

## 📝 Practical Example

```bash
# Stage specific files with precision
git add src/components/Button.js

# Generate an elegant commit message
npx @auroraphtgrp01/commit

# Or execute the entire workflow in one command
npx @auroraphtgrp01/commit -a -p
```

## 📜 License

This project is gracefully licensed under the MIT License.
