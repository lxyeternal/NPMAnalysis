<template>
<div class="w-auto inline-block">
    <div class="border-solid border shadow-lg rounded p-3">
        <!-- Palette menu -->
        
        <div v-if="!showModal">        
            <div class="flex flex-wrap">
                <template v-for="(item,i) in palette">
                    <div 
                        class="w-10 h-10 m-1 border border-gray-700 rounded-full cursor-pointer swatch"
                        v-bind:style="{backgroundColor: item['hex']}"
                        @click="makeActiveSwatch(i)"
                    >
                    </div>                
                </template>
                <div class="w-10 h-10 m-1  cursor-pointer rounded-full flex items-center justify-center font-bold text-4xl text-gray-700 hover:text-black" @click="addNewSwatch()">+</div>
            </div>      
        </div>
        <!-- Colorpicker Modal -->
        <div v-else>
            <div class="color-modal">
                <material-picker :value="palette[activeSwatch]['hex8']"  @input="storeCurrentColor" v-if="pickerType == 'Material'" />
                <compact-picker :value="palette[activeSwatch]['hex8']"  @input="storeCurrentColor" v-if="pickerType == 'Compact'" />
                <swatches-picker :value="palette[activeSwatch]['hex8']"  @input="storeCurrentColor" v-if="pickerType == 'Swatches'" />
                <slider-picker :value="palette[activeSwatch]['hex8']"  @input="storeCurrentColor" v-if="pickerType == 'Slider'" />
                <sketch-picker :value="palette[activeSwatch]['hex8']"  @input="storeCurrentColor" v-if="pickerType == 'Sketch'" />
                <chrome-picker :value="palette[activeSwatch]['hex8']"  @input="storeCurrentColor" v-if="pickerType == 'Chrome'" />
            </div>
            <div class="mt-2">
                <hr />
                <div class="inline-block w-full mt-2">
                    <button class="btn-grey float-left text-sm mr-2" @click="showModal = !showModal">Cancel</button>                     
                    <button class="btn-blue float-right text-sm" @click="selectColor">Select</button>                     
                    <button class="btn-red float-right text-sm mr-2" @click="removeSwatch(activeSwatch)">Remove</button>                    
                </div>
            </div>            
        </div>
    </div>
</div>
</template>



<script>

import {Material} from 'vue-color'
import {Compact} from 'vue-color'
import {Swatches} from 'vue-color'
import {Slider} from 'vue-color'
import {Sketch} from 'vue-color'
import {Chrome} from 'vue-color'

const tailwind = require('tailwindcss');


export default {
    getPalette() {
        return this.data().palette
    },
    components: {
        'material-picker': Material,
        'compact-picker': Compact,
        'swatches-picker': Swatches,
        'slider-picker': Slider,
        'sketch-picker': Sketch,
        'chrome-picker': Chrome
    },
    props: ['pickerType', 'initialPalette'],
    data() {
        return {            
            currentColor: '', // for temporary holding swatch value from color-picker
            showModal: false,
            activeSwatch: 0,
            palette:  [] , // the colors as they are created by the color pickers
            convertedColorArray: [], // the colors as they are sent to the ditherer ([0,0,0])
            originalInitialPalette: [], //this holds the first initial palette loaded
            presetPaletteSelection: 'original', 

        }
    },   
    created() {
        this.initialPalette.forEach((v, i) => {
            console.log(v)
            this.palette.push(v)
        })
        this.$emit('get-palette', this.palette)
    },
    methods: {   
        // This holds the selected color until user hits Select in the color modal
        storeCurrentColor(color) {
            this.currentColor = color
        },         
        // When the user selects the color from the modal
        selectColor() {
            var newSwatch = this.currentColor
            this.palette.splice(this.activeSwatch, 1, newSwatch)
            this.showModal = false
            this.$emit('get-palette', this.palette)
        },
        // Determine if a swatch is the active one, this controls which classes display on that swatch when selected
        isActiveSwatch(i) {
            if(this.activeSwatch === i) {
                return true
            } else {
                return false
            }
        } ,       
        // Make Active Swatch
        // When a swatch is clicked on, make it active and open the color picker
        makeActiveSwatch(i) {
            this.activeSwatch = i //tells the picker which swatch is being updated
            this.currentColor = this.palette[i]
            this.showModal = true
        },
        // Add New Swatch
        // This adds a new color to the colors        
        addNewSwatch(){
            this.palette.push({ "hsl": { "h": 0, "s": 0, "l": 1, "a": 1 }, "hex": "#FFFFFF", "hex8": "#FFFFFFFF", "rgba": { "r": 255, "g": 255, "b": 255, "a": 1 }, "hsv": { "h": 0, "s": 0, "v": 1, "a": 1 }, "oldHue": 0, "source": "hsva", "a": 1 } )
            this.activeSwatch = this.palette.length - 1
            this.makeActiveSwatch(this.palette.length - 1)
        },
        // Remove a swatch and update the palette      
        removeSwatch(i) {
            this.palette.splice(i,1)
            this.showModal = false
        },    
        //Convert Hex to RGB
        // Given a hex value, return the RGB tuple
        // hexToRgb(hex) {
        //     var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        //     return result ? [
        //         parseInt(result[1], 16),
        //         parseInt(result[2], 16),
        //         parseInt(result[3], 16)
        //     ] : null;
        // },
        // Convert RGB To Hex
        // this converts an array of tupes into hex values
        // rgbToHex() {
        //     this.palette = []
        //     var pal = this.initialPalette;
        //     for (let i=0; i<pal.length; i++) {
        //         var r = pal[i][0];
        //         var g = pal[i][1];
        //         var b = pal[i][2];
        //         var hex = '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
        //         this.palette.push({hex}); 

        //     }
        // },       
    
    }
}
</script>

<style scoped>

    @tailwind base;
    @tailwind components;
    @tailwind utilities;

    .color-modal > div {
        @apply shadow-none w-auto
    }

    .swatch:hover {
        @apply border-2 border-black
    }

    .btn-red {
        @apply bg-red-700 text-white font-bold py-2 px-2 rounded;
    }
    .btn-red:hover {
        @apply bg-red-800;
    }
    .btn-blue {
        @apply bg-blue-700 text-white font-bold py-2 px-2 rounded;
    }
    .btn-blue:hover {
        @apply bg-blue-800;
    }
    .btn-grey {
        @apply border-gray-400 border text-gray-700 font-bold py-2 px-2 rounded;
    }
    .btn-grey:hover {
        @apply bg-gray-900;
    }

</style>