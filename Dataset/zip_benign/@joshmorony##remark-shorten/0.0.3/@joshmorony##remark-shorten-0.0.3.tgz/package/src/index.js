export * from './lib/remark-shorten';
//# sourceMappingURL=index.js.map