export interface RemarkShortenOptions {
    percentage: number;
}
export declare const remarkShorten: (options?: RemarkShortenOptions) => (tree: any) => void;
