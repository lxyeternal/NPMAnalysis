# remark-shorten

This remark plugin will shorten a markdown file by (approximately) the percentage specified in the options, e.g:

```
{
  percentage: 0.5
}
```

This will remove approximately 50% of the content - it will delete all nodes after a certain line, but it will not break nodes apart (e.g. if you had a long paragraph the result may actually be longer than 50%).
