get-normal-distribution
=======================
[![Build Status](https://travis-ci.org/janjarfalk/get-normal-distribution.svg?branch=master)](https://travis-ci.org/janjarfalk/get-normal-distribution)

Returns the value of the normal distribution function for a specified value, mean, and standard deviation.

## Installation
```
npm install get-normal-distribution --save
```

## Syntax
```
getNormalDistribution(x, mean, standardDeviation)
```

## Usage
```
import getNormalDistribution from 'get-normal-distribution';
getNormalDistribution(2,0,1); // 0.97725
getNormalDistribution(0,0,1); // 0.5
```

## Tests
```
npm test
```

## Contributing

In lieu of a formal styleguide, take care to maintain the existing coding style.
Add unit tests for any new or changed functionality. Lint and test your code.

## Release History

* 1.0.0 Initial release