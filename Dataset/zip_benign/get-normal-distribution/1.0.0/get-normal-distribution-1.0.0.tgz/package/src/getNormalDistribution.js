function getNormalDistribution(x, mean, standardDeviation) {
  "use strict";

  function cdf(x, mean, stdev) {
    return 0.5 * (1 + erf((x - mean) / (Math.sqrt(2 * stdev))));
  }


  function erf(z) {

    const sign = (z >= 0) ? 1 : -1;
    z = Math.abs(z);

    const a1 =  0.254829592;
    const a2 = -0.284496736;
    const a3 =  1.421413741;
    const a4 = -1.453152027;
    const a5 =  1.061405429;
    const p  =  0.3275911;

    // A&S formula 7.1.26 with a slice of Horner's
    const t = 1.0/(1.0 + p*z);
    const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-z * z);
    return sign * y;
  }

  return Math.round(100000*cdf(x,mean,standardDeviation))/100000;

}

export default getNormalDistribution;