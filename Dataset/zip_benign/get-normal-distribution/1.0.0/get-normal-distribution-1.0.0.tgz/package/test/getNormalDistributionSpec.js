/*global describe it*/
import assert from 'assert';
import getNormalDistribution from '../src/getNormalDistribution.js';

const tests = [{
  values: [2, 0, 1],
  distribution: 0.97725
},{
  values: [0,0,1],
  distribution: 0.5
}];

describe('getStandardDeviation()', function () {
  tests.forEach(function (test) {
    it(test.values, function () {
      const v = test.values;
      assert.equal(getNormalDistribution(v[0],v[1],v[2]), test.distribution);
    });
  });
});