# react-material-type-scale

Visual typography based on [material design type scale](https://material.io/design/typography/the-type-system.html#type-scale).

## Install

```bash
$ yarn add react-material-type-scale
```

or

```bash
$ npm i react-material-type-scale
```

## Usage

All tags:

| Scale Category | Font    | Size | Letter spacing |
| -------------- | ------- | ---- | -------------- |
| H1             | Light   | 96   | -1.5           |
| H2             | Light   | 60   | -0.5           |
| H3             | Regular | 48   | 0              |
| H4             | Regular | 34   | 0.25           |
| H5             | Regular | 24   | 0              |
| H6             | Medium  | 20   | 0.15           |
| Subtile1       | Regular | 16   | 0.15           |
| Subtile2       | Medium  | 14   | 0.1            |
| Body1          | Regular | 16   | 0.5            |
| Body2          | Regular | 14   | 0.25           |
| Button         | Medium  | 14   | 1.25           |
| Caption        | Regular | 12   | 0.4            |
| Overline       | Regular | 10   | 1.5            |

This example is available in [CodeSandbox](https://codesandbox.io/s/using-the-reactmaterialtypescale-0pcmu).

```javascript
import React from 'react'
import { H1, Body1 } from 'react-material-type-scale'

function App() {
  return (
    <>
      <H1>Lorem ipsum dolor sit amet</H1>
      <Body1>
        Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.
        Nulla consequat massa quis enim. Donec pede justo, fringilla vel,
        aliquet nec, vulputate eget, arcu. <br />
        In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum
        felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum
        semper nisi. Aenean vulputate eleifend tellus. <br />
        Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim.
        Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.
        Phasellus viverra nulla ut metus varius laoreet. <br />
        Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur
        ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus,
        tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing
        sem neque sed ipsum.
        <br />
        Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas
        nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis
        faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt.
        Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna.
      </Body1>
    </>
  )
}

export default App
```

The `react-material-type-scale` can be used with React Native in the same way and with the same import. This example is available in [Snack by Expo](https://snack.expo.io/@pedrolobato/126edb).

```javascript
import React from 'react'
import { View, StyleSheet } from 'react-native'
import { Constants } from 'expo'
import { H1, Body1 } from 'react-material-type-scale/native'

function App() {
  return (
    <View styles={styles.container}>
      <H1>Lorem ipsum dolor sit amet</H1>
      <Body1>
      Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem.
      Nulla consequat massa quis enim. Donec pede justo, fringilla vel,
      aliquet nec, vulputate eget, arcu. '\n' In enim justo, rhoncus ut,
      imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis
      pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi.
      Aenean vulputate eleifend tellus.
      </Body1>
    </View>
  )
}

export default App

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
})
```
