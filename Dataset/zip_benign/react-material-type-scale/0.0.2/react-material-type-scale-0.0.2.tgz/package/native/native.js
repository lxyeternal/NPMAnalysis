import styled from 'styled-components/native'

export const H1 = styled.Text`
	font-size: 96;
	font-weight: 300;
	letter-spacing: -1.5;
`
export const H2 = styled.Text`
	font-size: 60;
	font-weight: 300;
	letter-spacing: -0.5;
`
export const H3 = styled.Text`
	font-size: 48;
	font-weight: 400;
	letter-spacing: 0;
`
export const H4 = styled.Text`
	font-size: 34;
	font-weight: 400;
	letter-spacing: 0.25;
`
export const H5 = styled.Text`
	font-size: 24;
	font-weight: 400;
	letter-spacing: 0;
`
export const H6 = styled.Text`
	font-size: 20;
	font-weight: 500;
	letter-spacing: 0.15;
`
export const Subtile1 = styled.Text`
	font-size: 16;
	font-weight: 400;
	letter-spacing: 0.15;
`
export const Subtile2 = styled.Text`
	font-size: 14;
	font-weight: 500;
	letter-spacing: 0.1;
`
export const Body1 = styled.Text`
	font-size: 16;
	font-weight: 400;
	letter-spacing: 0.5;
`
export const Body2 = styled.Text`
	font-size: 14;
	font-weight: 400;
	letter-spacing: 0.25;
`
export const Button = styled.Text`
	font-size: 14;
	font-weight: 500;
	letter-spacing: 1.25;
	text-transform: uppercase;
`
export const Caption = styled.Text`
	font-size: 12;
	font-weight: 400;
	letter-spacing: 0.4;
`
export const Oveline = styled.Text`
	font-size: 10;
	font-weight: 400;
	letter-spacing: 1.5;
	text-transform: uppercase;
`
