import styled from 'styled-components'

export const H1 = styled.h1`
	font-size: 6rem;
	font-weight: 300;
	letter-spacing: -1.5;
`
export const H2 = styled.h2`
	font-size: 3.75rem;
	font-weight: 300;
	letter-spacing: -0.5;
`
export const H3 = styled.h3`
	font-size: 3rem;
	font-weight: 400;
	letter-spacing: 0;
`
export const H4 = styled.h4`
	font-size: 2.125rem;
	font-weight: 400;
	letter-spacing: 0.25;
`
export const H5 = styled.h5`
	font-size: 1.5rem;
	font-weight: 400;
	letter-spacing: 0;
`
export const H6 = styled.h6`
	font-size: 1.25rem;
	font-weight: 500;
	letter-spacing: 0.15;
`
export const Subtile1 = styled.h6`
	font-size: 1rem;
	font-weight: 400;
	letter-spacing: 0.15;
`
export const Subtile2 = styled.h6`
	font-size: 0.875rem;
	font-weight: 500;
	letter-spacing: 0.1;
`
export const Body1 = styled.p`
	font-size: 1rem;
	font-weight: 400;
	letter-spacing: 0.5;
`
export const Body2 = styled.p`
	font-size: 0.875rem;
	font-weight: 400;
	letter-spacing: 0.25;
`
export const Button = styled.span`
	font-size: 0.875rem;
	font-weight: 500;
	letter-spacing: 1.25;
	text-transform: uppercase;
`
export const Caption = styled.span`
	font-size: 0.75rem;
	font-weight: 400;
	letter-spacing: 0.4;
`
export const Oveline = styled.span`
	font-size: 0.625rem;
	font-weight: 400;
	letter-spacing: 1.5;
	text-transform: uppercase;
`
