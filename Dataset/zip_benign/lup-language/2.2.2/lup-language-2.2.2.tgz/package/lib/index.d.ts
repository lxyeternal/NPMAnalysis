/**
 * Language detection methods.
 *  - uri: Detects language from URI e.g. '/en/about/' -> 'en'.
 *  - http-accept: Detects language from HTTP header 'accept-language'.
 *  - cookie: Detects language from cookie.
 */
type LanguageDetectionMethod = 'uri' | 'http-accept' | 'cookie';
/** Contains default settings that will be used if an option is not specified. */
export declare const DEFAULTS: {
    /** Default language code that will be used if no other method can detect the language. */
    LANGUAGE: string;
    /** Default list of language codes that will be accepted. */
    LANGUAGES: string[];
    /** Path to next.config.js file from which languages will be loaded from path i18n.locales (empty string to disable). */
    USE_NEXT_CONFIG_LANGUAGES: string;
    /** Default if language codes should be loaded from files in translations directory. */
    LANGUAGES_FROM_TRANSLATIONS_DIR: boolean;
    /** Default relative path from project root to a directory containing translation files.
     * Translation files are json files with the name of a language code e.g. 'en.json'.
     * Can also be an absolute path.
     */
    TRANSLATIONS_DIR: string;
    /** Default order of language detection methods. Entries can be removed if those methods should not be used. */
    LANGUAGE_DETECTION_METHODS: LanguageDetectionMethod[];
    /** Default setting if request to root document should be redirected to language prefixed root. */
    REDIRECT_ROOT: boolean;
    /** If root gets redirected to language prefixed root this HTTP response code will be sent. */
    REDIRECT_ROOT_RESPONSE_CODE: number;
    /** Default name of cookie to read/store user's language or null to disable cookie reading/storing. */
    COOKIE_NAME: string;
    /** Default expire seconds for cookie that gets set. */
    COOKIE_EXPIRE: number;
    /** Default path for which cookie will be set (can be null to not set property). */
    COOKIE_PATH: string;
    /** Default domain the cookie will be set for (can be null to not set property). */
    COOKIE_DOMAIN: string | null;
    /**
     * Default cookie setting if cookie should be set containing detected language.
     * (otherwise cookie just get read if 'DEFAULTS.COOKIE_NAME' is valid).
     */
    COOKIE_UPDATE: boolean;
    /** Name of the output attribute added to the request object that tells which language is requested. */
    REQUEST_ADD_LANGUAGE_ATTRIBUTE: string;
    /**
     * Name of the output attribute added to the request object that points to a key/value map with the translations in the requested language
     * (empty string to disable).
     */
    REQUEST_ADD_TRANSLATIONS_ATTRIBUTE: string;
    /** Name of the attribute added to the request object containing the path of the URI without the language prefix and without the query string. */
    REQUEST_ADD_PATH_ATTRIBUTE: string;
    /** Default behavior if the locale prefix should be remove from the req.url attribute. */
    REQUEST_URL_REMOVE_LANGUAGE_PREFIX: boolean;
};
type NextRequest = Request & {
    nextUrl: URL;
    get cookies(): {
        get(name: string): {
            value: string;
        } | undefined;
    };
};
type LanguageNextResponse = {
    /** URI to redirect to. */
    redirect?: string;
    /** HTTP response code to use when redirecting. */
    redirectResponseCode?: number;
    /** Cookie to set. */
    cookie?: {
        name: string;
        value: string;
        options: {
            expire: number;
            domain?: string;
            path?: string;
        };
    };
    /** Language code that was detected. */
    language: string;
    /** List of language codes that are supported. */
    languages: string[];
    /** Path of the URI without the language prefix and without the query string. */
    path: string;
    /** Object containing all translations in the detected language (only if requestAddTranslationsAttribute is set). */
    translations?: {
        [key: string]: string;
    };
};
type WithMethods = {
    /**
     * Optionally preload LanguageRouter so first request can be handled faster.
     * @return Promise<void> that resolves when preloading is done.
     */
    preload: () => Promise<void>;
    /**
     * Optionally preload LanguageRouter so first request can be handled faster.
     */
    preloadSync: () => void;
    /**
     * Can be called inside a Next.js middleware to handle language detection and translation loading.
     * @param req NextRequest object that should be handled.
     * @returns Object containing redirect and redirectResponseCode if a redirect should be done.
     */
    nextJsMiddlewareHandler: (req: NextRequest) => LanguageNextResponse;
};
type LanguageDetectionRequestHandler = ((req: any, res: any, next?: () => void) => Promise<void>) & WithMethods;
/**
 * Reloads translations from files inside given directory.
 * @param translationsDir Relative path to directory containing JSON files with translations.
 * @returns Promise that resolves with a list of language codes that where found after translations have been reloaded from files.
 */
export declare const reloadTranslations: (translationsDir?: string) => Promise<string[]>;
/**
 * Reloads translations from files inside given directory.
 * @param translationsDir Relative path to directory containing JSON files with translations.
 * @returns Promise that resolves with a list of language codes that where found after translations have been reloaded from files.
 */
export declare const reloadTranslationsSync: (translationsDir?: string) => string[];
/**
 * Returns a key/value array containing the translations in the given language.
 * @param lang Language code for which translations should be loaded.
 * @param defaultLang Default language code if given 'lang' is not supported.
 * @param translationKeys If not empty only translations with given keys will be included in output (if empty all translations will be included).
 * @param translationsDir Relative path to directory containing JSON files with translations (optional).
 * @returns Promise that resolves with the translations in the given language.
 */
export declare const getTranslations: (lang: string | null | undefined, defaultLang: string | null | undefined, translationKeys?: string[] | Set<string> | null | undefined, translationsDir?: string) => Promise<{
    [key: string]: string;
}>;
/**
 * Returns a translation for a given key in the given language.
 * @param lang Language code of language the translation should be in.
 * @param defaultLang Default language code if given 'lang' is not supported.
 * @param translationKey Key that should be looked up in the translations.
 * @param translationDir Relative path to directory containing JSON files with translations (optional).
 * @returns Promise that resolves with the translation or with the given key if no translation found.
 */
export declare const getTranslation: (lang: string | null | undefined, defaultLang: string | null | undefined, translationKey: string, translationDir?: string) => Promise<string>;
/**
 * Returns loaded language codes found in translations directory.
 * @param translationsDir Relative path to directory containing JSON files with translations.
 * @returns Promise that resolves to a list of language codes.
 */
export declare const getLanguages: (translationsDir?: string) => Promise<string[]>;
/**
 * Checks if a given language is supported and returns the supported language code.
 * If the given language is not supported the default language will be returned.
 *
 * @param lang Language code that should be checked.
 * @param defaultLang Default language code if given 'lang' is not supported.
 * @param translationsDir Relative path to directory containing JSON files with translations to lookup supported translations (optional).
 * @return Promise that resolves to the supported language code or undefined if no language is supported and also no default language is given.
 */
export declare const checkLanguage: (lang: string | null | undefined, defaultLang?: string, translationsDir?: string) => Promise<string | undefined>;
/**
 * Returns a map of all found languages and their native name.
 * Looksup following keys in the translations 'LANGUAGE_NAME_<lang>'.
 * @param translationsDir Relative path to directory containing JSON files with translations
 * @returns Promise that resolves to a map of language codes and their native names.
 */
export declare const getLanguageNames: (translationsDir?: string) => Promise<{
    [key: string]: string;
}>;
/**
 * Loads the contents of a file loaded inside the translations directory.
 * @param fileName Name of the file the contents should be loaded (relative path inside the translations directory).
 * @param translationsDir Relative path to directory containing JSON files with translations.
 * @returns Promise that resolves to the contents of the file.
 */
export declare const getTranslationFileContent: (fileName: string, translationsDir?: string) => Promise<string>;
/**
 * Loads the contents of a file loaded inside the translations directory.
 * @param fileName Name of the file the contents should be loaded (relative path inside the translations directory).
 * @param translationsDir Relative path to directory containing JSON files with translations.
 * @returns Contents of the file.
 */
export declare const getTranslationFileContentSync: (fileName: string, translationsDir?: string) => string;
/**
 * Splits a given locale string into language and country code.
 * @param locale Locale string that should be split.
 * @returns Language iso code and optionally country iso code if provided.
 */
export declare const splitLocale: (locale: string) => {
    languageIso: string;
    countryIso?: string;
};
type LanguageRouterOptions = {
    /** Fallback language code that will be used if no other method can detect the language (if not defined 'DEFAULTS.LANGUAGE' will be used). */
    defaultLanguage?: string;
    /** List of language codes that will be accepted (if not defined 'DEFAULTS.LANGUAGES' will be used). */
    languages?: string[];
    /**
     * Path to next.config.js file from which languages will be loaded from path i18n.locales
     * (empty string to disable, if not defined 'DEFAULTS.USE_NEXT_CONFIG_LANGUAGES' will be used).
     */
    useNextConfigLanguages?: string;
    /**
     * If supported languages should be automatically loaded from found files in translations directory
     * (if not defined 'DEFAULTS.LANGUAGES_FROM_TRANSLATIONS_DIR' will be used).
     */
    languagesFromTranslationsDir?: boolean;
    /**
     * Relative path from project root or absolute path to a directory containing translation files.
     * Translation files are json files with the name of a language code e.g. 'en.json'
     * (if not defined 'DEFAULTS.TRANSLATIONS_DIR' will be used, if null option is disabled).
     */
    translationsDir?: string;
    /**
     * Order of language detection methods. Entries can be removed if those methods should not be used.
     * (if not defined 'DEFAULTS.LANGUAGE_DETECTION_METHODS' will be used).
     */
    languageDetectionMethods?: LanguageDetectionMethod[];
    /** If root document should be redirected to language prefixed root (if not defined 'DEFAULTS.REDIRECT_ROOT' will be used). */
    redirectRoot?: boolean;
    /**
     * HTTP response code that will be sent if root document gets redirected to language prefixed root
     * (if not defined 'DEFAULTS.REDIRECT_ROOT_RESPONSE_CODE' will be used).
     */
    redirectRootResponseCode?: number;
    /** Name of cookie to read/store user's language or null to disable cookie reading/storing (if not defined 'DEFAULTS.COOKIE_NAME' will be used). */
    cookieName?: string;
    /** Expire seconds for cookie that gets set (if not defined 'DEFAULTS.COOKIE_EXPIRE' will be used). */
    cookieExpire?: number;
    /** Path for which cookie will be set (can be null to not set property, if not defined 'DEFAULTS.COOKIE_PATH' will be used). */
    cookiePath?: string;
    /** Domain the cookie will be set for (can be null to not set property, if not defined 'DEFAULTS.COOKIE_DOMAIN' will be used). */
    cookieDomain?: string;
    /**
     * If cookie should be set containing detected language (otherwise cookie just get read if 'DEFAULTS.COOKIE_NAME' is valid,
     * if not defined 'DEFAULTS.COOKIE_UPDATE' will be used).
     */
    cookieUpdate?: boolean;
    /**
     * Name of the attribute added to the req object that will contain to the detected language string
     * (if not defined 'DEFAULTS.REQUEST_ADD_LANGUAGE_ATTRIBUTE' will be used).
     */
    requestAddLanguageAttribute?: string;
    /**
     * Name of the attribute added to the req object that will point to a key/value map with all translations in the detected language
     * (empty string to disable, if not defined 'DEFAULTS.REQUEST_ADD_TRANSLATIONS_ATTRIBUTE' will be used).
     */
    requestAddTranslationsAttribute?: string;
    /**
     * Name of the attribute added to the req object containing the path of the URI without the language prefix and without the query string
     * (if not defined 'DEFAULTS.REQUEST_ADD_PATH_ATTRIBUTE' will be used).
     */
    requestAddPathAttribute?: string;
    /** If the locale prefix should be remove from the req.url attribute (if not defined 'DEFAULTS.REQUEST_URL_REMOVE_LANGUAGE_PREFIX' will be used). */
    requestUrlRemoveLanguagePrefix?: boolean;
};
/**
 * Returns a HTTP request/response middleware for detecting request language and loading translation variables.
 * @param options Object containing options for behavior of the middleware.
 * @returns function(req, res, next) that is designed for being set as middleware to pre-handle incoming requests.
 */
export declare const LanguageRouter: (options?: LanguageRouterOptions) => LanguageDetectionRequestHandler;
declare const _default: {
    DEFAULTS: {
        /** Default language code that will be used if no other method can detect the language. */
        LANGUAGE: string;
        /** Default list of language codes that will be accepted. */
        LANGUAGES: string[];
        /** Path to next.config.js file from which languages will be loaded from path i18n.locales (empty string to disable). */
        USE_NEXT_CONFIG_LANGUAGES: string;
        /** Default if language codes should be loaded from files in translations directory. */
        LANGUAGES_FROM_TRANSLATIONS_DIR: boolean;
        /** Default relative path from project root to a directory containing translation files.
         * Translation files are json files with the name of a language code e.g. 'en.json'.
         * Can also be an absolute path.
         */
        TRANSLATIONS_DIR: string;
        /** Default order of language detection methods. Entries can be removed if those methods should not be used. */
        LANGUAGE_DETECTION_METHODS: LanguageDetectionMethod[];
        /** Default setting if request to root document should be redirected to language prefixed root. */
        REDIRECT_ROOT: boolean;
        /** If root gets redirected to language prefixed root this HTTP response code will be sent. */
        REDIRECT_ROOT_RESPONSE_CODE: number;
        /** Default name of cookie to read/store user's language or null to disable cookie reading/storing. */
        COOKIE_NAME: string;
        /** Default expire seconds for cookie that gets set. */
        COOKIE_EXPIRE: number;
        /** Default path for which cookie will be set (can be null to not set property). */
        COOKIE_PATH: string;
        /** Default domain the cookie will be set for (can be null to not set property). */
        COOKIE_DOMAIN: string | null;
        /**
         * Default cookie setting if cookie should be set containing detected language.
         * (otherwise cookie just get read if 'DEFAULTS.COOKIE_NAME' is valid).
         */
        COOKIE_UPDATE: boolean;
        /** Name of the output attribute added to the request object that tells which language is requested. */
        REQUEST_ADD_LANGUAGE_ATTRIBUTE: string;
        /**
         * Name of the output attribute added to the request object that points to a key/value map with the translations in the requested language
         * (empty string to disable).
         */
        REQUEST_ADD_TRANSLATIONS_ATTRIBUTE: string;
        /** Name of the attribute added to the request object containing the path of the URI without the language prefix and without the query string. */
        REQUEST_ADD_PATH_ATTRIBUTE: string;
        /** Default behavior if the locale prefix should be remove from the req.url attribute. */
        REQUEST_URL_REMOVE_LANGUAGE_PREFIX: boolean;
    };
    reloadTranslations: (translationsDir?: string) => Promise<string[]>;
    getTranslation: (lang: string | null | undefined, defaultLang: string | null | undefined, translationKey: string, translationDir?: string) => Promise<string>;
    getTranslations: (lang: string | null | undefined, defaultLang: string | null | undefined, translationKeys?: string[] | Set<string> | null | undefined, translationsDir?: string) => Promise<{
        [key: string]: string;
    }>;
    getLanguageNames: (translationsDir?: string) => Promise<{
        [key: string]: string;
    }>;
    getLanguages: (translationsDir?: string) => Promise<string[]>;
    getTranslationFileContent: (fileName: string, translationsDir?: string) => Promise<string>;
    getTranslationFileContentSync: (fileName: string, translationsDir?: string) => string;
    LanguageRouter: (options?: LanguageRouterOptions) => LanguageDetectionRequestHandler;
};
export default _default;
