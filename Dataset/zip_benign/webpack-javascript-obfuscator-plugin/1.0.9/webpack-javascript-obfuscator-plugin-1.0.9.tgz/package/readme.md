webpack-javascript-obfuscator-plugin
----

本插件依赖[javascript-obfuscator](https://www.npmjs.com/package/javascript-obfuscator#controlflowflatteningthreshold)对前端代码进行AST混淆加密

### Install
With npm:
```bash
npm i webpack-javascript-obfuscator-plugin --save-dev
```

Or yarn:
```bash
yarn add webpack-javascript-obfuscator-plugin --dev
```

### Usage
首先引入
```javascript
// 引入
const WebpackJavascriptObfuscatorPlugin = require("webpack-javascript-obfuscator-plugin");
``` 

在webpack的插件选项中
```javascript
//在webpack的plugins中实例化此插件
plugins: [ new WebpackJavascriptObfuscatorPlugin(options) ]
``` 


```javascript
//如果你只想在打包时进行加密
plugins: process.env.NODE_ENV == "production" ? [ new WebpackJavascriptObfuscatorPlugin(options) ] : []
```


### Options(不添加默认中度混淆，最佳性能)
默认：
```javascript
{
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    debugProtection: false,
    debugProtectionInterval: false,
    disableConsoleOutput: true,
    identifierNamesGenerator: "hexadecimal",
    log: false,
    numbersToExpressions: true,
    renameGlobals: false,
    rotateStringArray: true,
    selfDefending: false,
    shuffleStringArray: true,
    simplify: true,
    splitStrings: true,
    splitStringsChunkLength: 10,
    stringArray: true,
    stringArrayEncoding: ["base64"],
    stringArrayIndexShift: true,
    stringArrayWrappersCount: 2,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 4,
    stringArrayWrappersType: "function",
    stringArrayThreshold: 0.75,
    transformObjectKeys: true,
    unicodeEscapeSequence: false
}
```

添加或修改配置项请移步[JavaScript Obfuscator Options](https://www.npmjs.com/package/javascript-obfuscator#controlflowflatteningthreshold)