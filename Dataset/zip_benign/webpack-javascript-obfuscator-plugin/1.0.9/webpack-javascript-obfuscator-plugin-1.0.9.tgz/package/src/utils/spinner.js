var chalk = require("chalk");
module.exports = function () {
	// this.spinner = ora({
	// 	// spinner: {
	// 	// interval: 80, // Optional
	// 	// frames: ['-', '+', '-']
	// 	// }
	// });

	this.log  = function(message, color = 'red') {
        console.log(chalk[color](message))
    }
};
