/*
 * @Author: spark
 * @Date: 2021-01-28 17:03:50
 * @LastEditTime: 2021-02-04 11:18:14
 * @LastEditors: spark
 * @Description: 趣看天下前端开发
 * @email: spark.xiaoyu@qq.com
 */

const JavaScriptObfuscator = require("javascript-obfuscator");
const Spinner = require("./utils/spinner");
const pluginName = "JavaScriptObfuscatorPlugin";

function JavaScriptObfuscatorPlugin(options) {
	this.options = Object.assign(
		{
			compact: true,
			controlFlowFlattening: true,
			controlFlowFlatteningThreshold: 0.75,
			deadCodeInjection: true,
			deadCodeInjectionThreshold: 0.4,
			debugProtection: false,
			debugProtectionInterval: false,
			disableConsoleOutput: true,
			identifierNamesGenerator: "hexadecimal",
			log: false,
			numbersToExpressions: true,
			renameGlobals: false,
			rotateStringArray: true,
			selfDefending: false,
			shuffleStringArray: true,
			simplify: true,
			splitStrings: true,
			splitStringsChunkLength: 10,
			stringArray: true,
			stringArrayEncoding: ["base64"],
			stringArrayIndexShift: true,
			stringArrayWrappersCount: 2,
			stringArrayWrappersChainedCalls: true,
			stringArrayWrappersParametersMaxCount: 4,
			stringArrayWrappersType: "function",
			stringArrayThreshold: 0.75,
			transformObjectKeys: true,
			unicodeEscapeSequence: false
		},
		options || {}
	);
}

JavaScriptObfuscatorPlugin.prototype.apply = function (compiler) {
	//注册事件回调有三个方法： tap、tapAsync 和 tapPromise，其中 tapAsync 和 tapPromise 不能用于 Sync 开头的钩子类，强行使用会报错
	// console.log(compiler.hooks);
	let _this = this;
	const progress = new Spinner();
	compiler.hooks.run.tap(pluginName, function () {
		progress.log("\nAST加密构建过程开始！", "blue");
	});

	compiler.hooks.emit.tapAsync(pluginName, function (compilation, callback) {
		for (let filename in compilation.assets) {
			// console.log(compilation.assets[filename].source())
			let _flag = compilation.assets[filename].source();
			if (/\.js$/gi.test(filename)) {
				let content = JavaScriptObfuscator.obfuscate(
					_flag,
					_this.options
				).getObfuscatedCode();
				if (content) {
					compilation.assets[filename] = {
						source() {
							return content;
						},
						size() {
							return content.length;
						}
					};
					progress.log("\n" + filename + ": AST加密完成", "green");
				}
			}
		}
        progress.log("\n加密进程结束", 'green');
		callback();
	});
};

module.exports = JavaScriptObfuscatorPlugin;
