/*
 * @Author: spark
 * @Date: 2021-02-02 17:14:44
 * @LastEditTime: 2021-02-03 11:58:41
 * @LastEditors: spark
 * @Description: 趣看天下前端开发
 * @email: spark.xiaoyu@qq.com
 */
module.exports = {
	presets: [
		[
			"@babel/preset-env",
			{
				useBuiltIns: false,
				targets: {
					browsers: ["iOS >= 7", "Android >= 4.1"]
				}
			}
		]
	],
	plugins: [
		// [
		// 	"@babel/plugin-transform-runtime",
		// 	{
		// 		absoluteRuntime: false,
		// 		corejs: false,
		// 		helpers: true,
		// 		regenerator: true,
		// 		useESModules: false
		// 	}
		// ],
		"@babel/plugin-transform-object-assign",
		[
			"@babel/plugin-proposal-decorators",
			{
				//装饰器
				legacy: true
			}
		],
		[
			"@babel/plugin-proposal-class-properties",
			{
				loose: true
			}
		]
	]
};
