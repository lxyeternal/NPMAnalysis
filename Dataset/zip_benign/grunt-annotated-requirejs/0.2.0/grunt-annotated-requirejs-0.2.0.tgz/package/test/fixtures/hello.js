define(function(){return "hello";});
