'use strict';

var ReactNativeFile = require('./ReactNativeFile');

module.exports = function isExtractableFile(value) {
  return (
    (typeof File !== 'undefined' && value instanceof File) ||
    value instanceof ReactNativeFile
  );
};
