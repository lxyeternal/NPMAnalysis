rm -rf ./build
tsc