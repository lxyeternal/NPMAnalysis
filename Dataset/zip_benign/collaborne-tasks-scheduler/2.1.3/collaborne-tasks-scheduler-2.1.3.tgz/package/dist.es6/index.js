import * as moment from 'moment';
import { businessAdd, businessDiff } from './business-days';
function businessAddWithBlocked(startMoment, daysToAdd, blockedPeriods) {
    // Function businessAdd() fails on non-integers
    // NB. Round up to express the next available business day
    const taskEnd = businessAdd(startMoment, Math.round(daysToAdd));
    // Check if task ends within one of the blocked periods provided
    const blockPeriod = blockedPeriods.find(block => taskEnd.isSame(block.start) || taskEnd.isAfter(block.start));
    if (blockPeriod) {
        // Move the deadline by the number of blocked days
        // NB. Add one to round up to the next available business day
        return businessAdd(taskEnd, blockPeriod.nrBlockDays + 1);
    }
    return taskEnd;
}
/**
 * Calculates the end date for the scheduled task.
 *
 * @param start - The starting date in date string format.
 * @param timeAllocation - The time allocation percentage.
 * @param nrNormDays - Number of normalized days required to complete all tasks.
 * @param blockedPeriods - Array of blocked periods.
 * @return the end date in date string format.
 */
function calcEnd(start, timeAllocation, nrNormDays, blockedPeriods) {
    const daysToAdd = nrNormDays / timeAllocation;
    return businessAddWithBlocked(start, daysToAdd, blockedPeriods);
}
/**
 * Checks if a provided string is a valid date
 *
 * @param date - The date to parse.
 * @return True if the input date is valid
 */
function isValidDate(date) {
    const timestamp = Date.parse(date);
    return !isNaN(timestamp);
}
function sumNrNormDays(tasks) {
    return tasks.reduce((acc, task) => acc + task.nrNormDays, 0);
}
function calcDeadlines(tasks, start, blockedPeriods, timeAllocation) {
    const totalNrNormDays = sumNrNormDays(tasks);
    let lastTaskNormDays = 0;
    return tasks.map(task => {
        lastTaskNormDays += task.nrNormDays;
        const realDays = lastTaskNormDays / timeAllocation;
        const taskDeadline = businessAddWithBlocked(start, realDays, blockedPeriods);
        return {
            deadline: taskDeadline.format('YYYY-MM-DD'),
            id: task.id,
            progress: lastTaskNormDays / totalNrNormDays,
        };
    });
}
/**
 * Calculates the scheduling of a set of tasks
 */
export function schedule(options) {
    // Input validation
    if (!isValidDate(options.start)) {
        throw new Error(`Invalid start date (${options.start}). Must be in format YYYY-MM-DD.`);
    }
    if (options.end && !isValidDate(options.end)) {
        throw new Error(`Invalid end date (${options.end}). Must be in format YYYY-MM-DD.`);
    }
    if (Boolean(options.end) && Boolean(options.timeAllocation)) {
        throw new Error('Only provide end date or time allocation percentage');
    }
    const startDate = moment.default(options.start);
    const nrNormDays = sumNrNormDays(options.tasks);
    const blockedPeriods = (options.blockedPeriods || []).map(period => ({
        nrBlockDays: businessDiff(startDate, moment.default(period.end)),
        start: period.start,
    }));
    let endDate;
    if (options.end) {
        // End date is given -> calculate time allocation
        endDate = moment.default(options.end);
    }
    else if (options.timeAllocation) {
        // Time allocation is given -> calculate end date
        endDate = calcEnd(startDate, options.timeAllocation, nrNormDays, blockedPeriods);
    }
    else {
        throw new Error('End or time allocation must be provided');
    }
    const nrRealDays = businessDiff(startDate, moment.default(endDate));
    let timeAllocation;
    if (options.end) {
        // End date is given -> calculate time allocation
        timeAllocation = nrNormDays / nrRealDays;
    }
    else {
        timeAllocation = options.timeAllocation;
    }
    const deadlines = calcDeadlines(options.tasks, startDate, blockedPeriods, timeAllocation);
    const deadlineById = deadlines.reduce((acc, task) => Object.assign(acc, {
        [task.id]: task.deadline,
    }), {});
    const progressById = deadlines.reduce((acc, task) => Object.assign(acc, {
        [task.id]: task.progress,
    }), {});
    return {
        deadlines: deadlineById,
        end: endDate.format('YYYY-MM-DD'),
        nrNormDays,
        nrRealDays,
        progress: progressById,
        start: startDate.format('YYYY-MM-DD'),
        timeAllocation: timeAllocation,
    };
}
//# sourceMappingURL=index.js.map