import * as moment from 'moment';
export declare function businessAdd(date: moment.Moment, nrDays: number): moment.Moment;
export declare function businessDiff(date1: moment.Moment, date2: moment.Moment): number;
