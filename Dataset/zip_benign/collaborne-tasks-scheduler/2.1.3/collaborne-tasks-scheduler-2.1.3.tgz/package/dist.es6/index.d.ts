/**
 * Task to be scheduled.
 */
interface Task {
    /**
     * ID of the task
     */
    id: string;
    /**
     * Number of normalized days required to complete the task (assuming 100% time allocation)
     */
    nrNormDays: number;
}
/**
 * Closed interval of time not available for tasks scheduling.
 * Eg. blocked period ['2018-03-07', '2018-03-08'] shifts scheduling of 2 days
 */
interface BlockedPeriod {
    /**
     * Start date of the period in ISO format (eg. '2018-03-19')
     */
    start: string;
    /**
     * End date of the period in ISO format (eg. '2018-03-19')
     */
    end: string;
}
/**
 * The computed scheduling.
 */
interface SchedulingResult {
    /**
     * Map of deadlines by task ID
     */
    deadlines: {
        [key: string]: string;
    };
    /**
     * List of progress objects
     */
    progress: {
        [key: string]: number;
    };
    /**
     * Start date in ISO format (eg. '2018-03-19')
     */
    start: string;
    /**
     * End date in ISO format (eg. '2018-03-19')
     */
    end: string;
    /**
     * Number of normalized days required to complete all tasks (e.g. if time allocation would be 100%)
     */
    nrNormDays: number;
    /**
     * The time allocation in percentage (0..1)
     */
    timeAllocation: number;
    /**
     * Number of business days required to complete all tasks (considering time allocation
     */
    nrRealDays: number;
}
interface ScheduleOptions {
    /**
     * An array of task
     */
    tasks: Task[];
    /**
     * Starting date in ISO format (eg. '2018-03-19')
     */
    start: string;
    /**
     * Ending date in ISO format (eg. '2018-03-19')
     */
    end?: string;
    /**
     * The time allocation percentage
     */
    timeAllocation?: number;
    /**
     * Array of blocked periods
     */
    blockedPeriods?: BlockedPeriod[];
}
/**
 * Calculates the scheduling of a set of tasks
 */
export declare function schedule(options: ScheduleOptions): SchedulingResult;
export {};
