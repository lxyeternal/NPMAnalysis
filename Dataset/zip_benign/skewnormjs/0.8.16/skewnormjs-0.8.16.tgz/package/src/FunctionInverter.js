"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FunctionInverter = /** @class */ (function () {
    function FunctionInverter() {
    }
    FunctionInverter.invertMonoton = function (f, start, end, y) {
        var epsilon = Math.pow(10, -10);
        var position = (end + start) / 2;
        var distance = end - position;
        var value = f(position);
        var i = 0;
        var lastDirUp = null;
        var lastValue = NaN;
        var isIncreasing = f(start) < f(end);
        while (Math.abs(value - y) > epsilon) {
            var isDirChanged = (value < y && lastDirUp === !isIncreasing) ||
                (value > y && lastDirUp === isIncreasing);
            var canDecrease = Math.abs(distance) > 0.0001;
            if (isDirChanged || canDecrease) {
                distance /= 2;
            }
            if ((value < y && isIncreasing) || (value > y && !isIncreasing)) {
                lastDirUp = true;
                position += distance;
            }
            else {
                lastDirUp = false;
                position -= distance;
            }
            value = f(position);
            if (lastValue === value) {
                return position;
            }
            lastValue = value;
            i++;
            if (i > 1000) {
                return NaN;
            }
        }
        return position;
    };
    return FunctionInverter;
}());
exports.FunctionInverter = FunctionInverter;
//# sourceMappingURL=FunctionInverter.js.map