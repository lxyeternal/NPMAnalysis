export declare class Integrator {
    static integrate(f: (x: number) => number, start: number, end: number, step: number): number;
}
