/**
 * Owen's T function
 * https://en.wikipedia.org/wiki/Owen%27s_T_function
 * "In mathematics, Owen's T function T(h, a), named after statistician Donald Bruce Owen, is defined by
 * {\displaystyle T(h,a)={\frac {1}{2\pi }}\int _{0}^{a}{\frac {e^{-{\frac {1}{2}}h^{2}(1+x^{2})}}
 *                                                             {1+x^{2}}}dx\quad \left(-\infty <h,a<+\infty \right).} ..."
 */
export declare class OwensTFunction {
    private static onePer2Pi;
    static T(h: number, a: number): number;
}
