"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Integrator_1 = require("./Integrator");
/**
 * Owen's T function
 * https://en.wikipedia.org/wiki/Owen%27s_T_function
 * "In mathematics, Owen's T function T(h, a), named after statistician Donald Bruce Owen, is defined by
 * {\displaystyle T(h,a)={\frac {1}{2\pi }}\int _{0}^{a}{\frac {e^{-{\frac {1}{2}}h^{2}(1+x^{2})}}
 *                                                             {1+x^{2}}}dx\quad \left(-\infty <h,a<+\infty \right).} ..."
 */
var OwensTFunction = /** @class */ (function () {
    function OwensTFunction() {
    }
    OwensTFunction.T = function (h, a) {
        var f = function (x) {
            var nominator = Math.exp(-1 / 2 * h * h * (1 + x * x));
            var denominator = (1 + x * x);
            return nominator / denominator;
        };
        var step = a / 1000;
        return OwensTFunction.onePer2Pi * Integrator_1.Integrator.integrate(f, 0, a, step);
    };
    OwensTFunction.onePer2Pi = 1 / (2 * Math.PI);
    return OwensTFunction;
}());
exports.OwensTFunction = OwensTFunction;
//# sourceMappingURL=OwensTFunction.js.map