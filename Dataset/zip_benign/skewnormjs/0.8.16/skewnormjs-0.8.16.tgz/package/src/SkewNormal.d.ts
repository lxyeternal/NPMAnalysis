export declare class SkewNormal {
    location: number;
    scale: number;
    shape: number;
    private static sqrtTwoPi;
    private static sqrtTwo;
    constructor(location?: number, scale?: number, shape?: number);
    static create(parameters: SkewNormal.Parameters): SkewNormal;
    static random(location?: number, scale?: number, shape?: number, min?: number, max?: number): number;
    /**
     * https://en.wikipedia.org/wiki/Skew_normal_distribution
     * http://reference.wolfram.com/language/ref/SkewNormalDistribution.html
     * http://www.boost.org/doc/libs/1_50_0/libs/math/doc/sf_and_dist/html/math_toolkit/dist/dist_ref/dists/skew_normal_dist.html
     * then the PDF of the skew normal distribution with shape parameter α, defined by O'Hagan and Leonhard (1976) is
     * @param location
     * @param scale
     * @param shape
     * @param x
     */
    static pdf(location?: number, scale?: number, shape?: number, x?: number): number;
    /**
     * cumulative distribution function
     * @param location
     * @param scale
     * @param shape
     * @param x
     * @returns {number}
     */
    static cdf(location: number, scale: number, shape: number, x: number): number;
    static invcdf(location: number, scale: number, shape: number, y: number): number;
    static expectedValue(location?: number, scale?: number, shape?: number): number;
    random(min?: number, max?: number): number;
    pdf(x: number): number;
    cdf(x: number): number;
    invcdf(x: number): number;
    expectedValue(): number;
}
export declare module SkewNormal {
    interface Parameters {
        shape: number;
        location: number;
        scale: number;
    }
}
