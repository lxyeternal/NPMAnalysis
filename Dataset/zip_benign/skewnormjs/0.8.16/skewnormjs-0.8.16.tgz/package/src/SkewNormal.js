"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var NormalDistribution_1 = require("./NormalDistribution");
var OwensTFunction_1 = require("./OwensTFunction");
var ErrorFunction_1 = require("./ErrorFunction");
var FunctionInverter_1 = require("./FunctionInverter");
var SkewNormal = /** @class */ (function () {
    function SkewNormal(location, scale, shape) {
        if (location === void 0) { location = 0; }
        if (scale === void 0) { scale = 1.0; }
        if (shape === void 0) { shape = 0; }
        this.location = location;
        this.scale = scale;
        this.shape = shape;
    }
    SkewNormal.create = function (parameters) {
        return new SkewNormal(parameters.location, parameters.scale, parameters.shape);
    };
    SkewNormal.random = function (location, scale, shape, min, max) {
        if (location === void 0) { location = 0; }
        if (scale === void 0) { scale = 1.0; }
        if (shape === void 0) { shape = 0; }
        if (min === void 0) { min = -Infinity; }
        if (max === void 0) { max = Infinity; }
        var sigma, u0, v, u1, ret;
        sigma = shape / Math.sqrt(1 + Math.pow(shape, 2));
        var generate = function () {
            u0 = NormalDistribution_1.NormalDistribution.random();
            v = NormalDistribution_1.NormalDistribution.random();
            u1 = (sigma * u0 + Math.sqrt(1 - Math.pow(sigma, 2)) * v);
            if (u0 >= 0) {
                return u1 * scale + location;
            }
            return (-u1) * scale + location;
        };
        do {
            ret = generate();
        } while (ret < min || ret > max);
        return ret;
    };
    /**
     * https://en.wikipedia.org/wiki/Skew_normal_distribution
     * http://reference.wolfram.com/language/ref/SkewNormalDistribution.html
     * http://www.boost.org/doc/libs/1_50_0/libs/math/doc/sf_and_dist/html/math_toolkit/dist/dist_ref/dists/skew_normal_dist.html
     * then the PDF of the skew normal distribution with shape parameter α, defined by O'Hagan and Leonhard (1976) is
     * @param location
     * @param scale
     * @param shape
     * @param x
     */
    SkewNormal.pdf = function (location, scale, shape, x) {
        if (location === void 0) { location = 0; }
        if (scale === void 0) { scale = 1.0; }
        if (shape === void 0) { shape = 0; }
        if (x === void 0) { x = 0; }
        var exp = Math.exp(-((x - location) * (x - location)) / (2 * scale * scale));
        var err = ErrorFunction_1.ErrorFunction.erfc(-(shape * (x - location)) / (SkewNormal.sqrtTwo * scale));
        return (exp * err) / (SkewNormal.sqrtTwoPi * scale);
    };
    /**
     * cumulative distribution function
     * @param location
     * @param scale
     * @param shape
     * @param x
     * @returns {number}
     */
    SkewNormal.cdf = function (location, scale, shape, x) {
        if (location === void 0) { location = 0; }
        if (scale === void 0) { scale = 1.0; }
        if (shape === void 0) { shape = 0; }
        return NormalDistribution_1.NormalDistribution.cdf(location, scale, x) - 2 * OwensTFunction_1.OwensTFunction.T((x - location) / scale, shape);
    };
    SkewNormal.invcdf = function (location, scale, shape, y) {
        if (location === void 0) { location = 0; }
        if (scale === void 0) { scale = 1.0; }
        if (shape === void 0) { shape = 0; }
        if (y < 0 || y > 1) {
            return NaN;
        }
        var f = function (x) {
            return SkewNormal.cdf(location, scale, shape, x);
        };
        return FunctionInverter_1.FunctionInverter.invertMonoton(f, -0.0, 10, y);
    };
    SkewNormal.expectedValue = function (location, scale, shape) {
        if (location === void 0) { location = 0; }
        if (scale === void 0) { scale = 1.0; }
        if (shape === void 0) { shape = 0; }
        var ro = shape / Math.sqrt(1 + shape * shape);
        return location + scale * ro * Math.sqrt(2 / Math.PI);
    };
    SkewNormal.prototype.random = function (min, max) {
        if (min === void 0) { min = -Infinity; }
        if (max === void 0) { max = Infinity; }
        return SkewNormal.random(this.location, this.scale, this.shape, min, max);
    };
    SkewNormal.prototype.pdf = function (x) {
        return SkewNormal.pdf(this.location, this.scale, this.shape, x);
    };
    SkewNormal.prototype.cdf = function (x) {
        return SkewNormal.cdf(this.location, this.scale, this.shape, x);
    };
    SkewNormal.prototype.invcdf = function (x) {
        return SkewNormal.invcdf(this.location, this.scale, this.shape, x);
    };
    SkewNormal.prototype.expectedValue = function () {
        return SkewNormal.expectedValue(this.location, this.scale, this.shape);
    };
    SkewNormal.sqrtTwoPi = Math.sqrt(2 * Math.PI);
    SkewNormal.sqrtTwo = Math.sqrt(2);
    return SkewNormal;
}());
exports.SkewNormal = SkewNormal;
//# sourceMappingURL=SkewNormal.js.map