/**
 * Error function
 * http://mathworld.wolfram.com/Erf.html
 * https://en.wikipedia.org/wiki/Error_function
 */
export declare class ErrorFunction {
    private static twoPerSqrPi;
    private static epsilon;
    /**
     * Erf defining as a Maclaurin series
     * has precision problem if abs(x) > 8
     * @param x
     */
    static erf2(x: number): number;
    /**
     * with approximation integration
     * @param x
     */
    static erf(x: number): number;
    static erfc(x: number): number;
}
