"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Integrator = /** @class */ (function () {
    function Integrator() {
    }
    Integrator.integrate = function (f, start, end, step) {
        var total = 0;
        if (start <= end) {
            step = Math.abs(step);
            var stepPer2 = step / 2;
            for (var x = start; x < end; x += step) {
                total += f(x + stepPer2) * step;
            }
        }
        else {
            step = -Math.abs(step);
            var stepPer2 = step / 2;
            for (var x = start; x > end; x += step) {
                total += f(x - stepPer2) * step;
            }
        }
        return total;
    };
    return Integrator;
}());
exports.Integrator = Integrator;
//# sourceMappingURL=Integrator.js.map