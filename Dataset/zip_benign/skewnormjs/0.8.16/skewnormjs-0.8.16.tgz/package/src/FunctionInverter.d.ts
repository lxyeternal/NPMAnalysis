export declare class FunctionInverter {
    static invertMonoton(f: Function, start: number, end: number, y: number): number;
}
