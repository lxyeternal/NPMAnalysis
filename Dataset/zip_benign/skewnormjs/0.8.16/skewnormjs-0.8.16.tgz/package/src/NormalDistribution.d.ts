/**
 * NormalDistribution Distribution
 * https://en.wikipedia.org/wiki/Normal_distribution
 */
export declare class NormalDistribution {
    private mean;
    private stdev;
    private static sqrtTwo;
    constructor(mean?: number, stdev?: number);
    static create(parameters: NormalDistribution.Parameters): NormalDistribution;
    /**
     *  from randgen
     */
    static random(mean?: number, stdev?: number): number;
    static expectedValue(mean: number, stdev: number): number;
    static pdf(mean: number, stdev: number, x: number): number;
    static cdf(mean: number, stdev: number, x: number): number;
    random(): number;
    pdf(x: number): number;
    cdf(x: number): number;
    expectedValue(): number;
}
export declare module NormalDistribution {
    interface Parameters {
        mean: number;
        stdev: number;
    }
}
