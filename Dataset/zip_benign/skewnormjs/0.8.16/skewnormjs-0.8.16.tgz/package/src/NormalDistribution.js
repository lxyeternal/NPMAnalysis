"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ErrorFunction_1 = require("./ErrorFunction");
/**
 * NormalDistribution Distribution
 * https://en.wikipedia.org/wiki/Normal_distribution
 */
var NormalDistribution = /** @class */ (function () {
    function NormalDistribution(mean, stdev) {
        if (mean === void 0) { mean = 0.0; }
        if (stdev === void 0) { stdev = 1.0; }
        this.mean = mean;
        this.stdev = stdev;
    }
    NormalDistribution.create = function (parameters) {
        return new NormalDistribution(parameters.mean, parameters.stdev);
    };
    /**
     *  from randgen
     */
    NormalDistribution.random = function (mean, stdev) {
        if (mean === void 0) { mean = 0.0; }
        if (stdev === void 0) { stdev = 1.0; }
        var u1, u2, v1, v2, s;
        do {
            u1 = Math.random();
            u2 = Math.random();
            v1 = 2 * u1 - 1;
            v2 = 2 * u2 - 1;
            s = v1 * v1 + v2 * v2;
        } while (s === 0 || s >= 1);
        return stdev * v1 * Math.sqrt(-2 * Math.log(s) / s) + mean;
    };
    NormalDistribution.expectedValue = function (mean, stdev) {
        return mean;
    };
    NormalDistribution.pdf = function (mean, stdev, x) {
        var first = 1 / Math.sqrt(2 * stdev * stdev * Math.PI);
        var exp = Math.exp(-((x - mean) * (x - mean)) / (2 * stdev * stdev));
        return first * exp;
    };
    NormalDistribution.cdf = function (mean, stdev, x) {
        return (1 / 2) * (1 + ErrorFunction_1.ErrorFunction.erf((x - mean) / (stdev * NormalDistribution.sqrtTwo)));
    };
    NormalDistribution.prototype.random = function () {
        return NormalDistribution.random(this.mean, this.stdev);
    };
    NormalDistribution.prototype.pdf = function (x) {
        return NormalDistribution.pdf(this.mean, this.stdev, x);
    };
    NormalDistribution.prototype.cdf = function (x) {
        return NormalDistribution.cdf(this.mean, this.stdev, x);
    };
    NormalDistribution.prototype.expectedValue = function () {
        return NormalDistribution.expectedValue(this.mean, this.stdev);
    };
    NormalDistribution.sqrtTwo = Math.sqrt(2);
    return NormalDistribution;
}());
exports.NormalDistribution = NormalDistribution;
//# sourceMappingURL=NormalDistribution.js.map