"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Integrator_1 = require("./Integrator");
/**
 * Error function
 * http://mathworld.wolfram.com/Erf.html
 * https://en.wikipedia.org/wiki/Error_function
 */
var ErrorFunction = /** @class */ (function () {
    function ErrorFunction() {
    }
    /**
     * Erf defining as a Maclaurin series
     * has precision problem if abs(x) > 8
     * @param x
     */
    ErrorFunction.erf2 = function (x) {
        var sum = 0;
        sum += x;
        var n = 1;
        var nFactorial = 1;
        var pow = x;
        var xSqr = x * x;
        while (true) {
            nFactorial *= n;
            var twoNplusOne = 2 * n + 1;
            var sign = n % 2 === 0 ? 1 : -1;
            pow *= xSqr;
            var nominator = sign * pow;
            var denominator = nFactorial * twoNplusOne;
            var result = nominator / denominator;
            if (isNaN(result)) {
                console.log(n, result, sum);
                break;
            }
            sum += result;
            if (Math.abs(result) < ErrorFunction.epsilon || n > 500) {
                console.log(n, result);
                break;
            }
            n++;
        }
        return ErrorFunction.twoPerSqrPi * sum;
    };
    /**
     * with approximation integration
     * @param x
     */
    ErrorFunction.erf = function (x) {
        var f = function (t) {
            return Math.exp(-(t * t));
        };
        return ErrorFunction.twoPerSqrPi * Integrator_1.Integrator.integrate(f, 0, x, 0.01);
    };
    ErrorFunction.erfc = function (x) {
        return 1 - this.erf(x);
    };
    ErrorFunction.twoPerSqrPi = 2 / Math.sqrt(Math.PI);
    ErrorFunction.epsilon = Math.pow(10, -30);
    return ErrorFunction;
}());
exports.ErrorFunction = ErrorFunction;
//# sourceMappingURL=ErrorFunction.js.map