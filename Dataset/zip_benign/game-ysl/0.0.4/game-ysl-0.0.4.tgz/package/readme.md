# YSL

# 游戏

##### 安装

```
npm install game-ysl
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-ysl/ysl"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: JSON.stringify({
      baseOps: {
        speed: { min: 10, max: 15, step: 0 },//移动速度
        firstY: 200,//首次加载游戏第一个元素的底部坐标位置
        intervalStep: 1,//两个物体之间的间隔递减值
        intervalStepH: 50,//移动指定距离递减一次
        minIntervalH: 420,//两个物体之间的最小间隔距离
        maxIntervalH: 600,//两个物体之间的间隔距离
        maxCols: 4,//一共有多少列
      },
      items: [
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ufMIKn1FJveU13QFv_!!1080040467.png", probability: 1, val: 0, time: 5 },//加5秒时长
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01K7qmO21FJveZ9aQgQ_!!1080040467.png", probability: 1, val: 10 },//只加分数
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ZKpfSt1FJveOLp9Fs_!!1080040467.png", probability: 1, val: 0, isDie: true },//碰撞结束游戏
      ],
      player: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01weapbd1FJveZstGn0_!!1080040467.png", bound: { left: 50, right: 50, bottom: 200, top: 150 }, moveY: false, bottom: -100, },

      timePos: {
        align: "left",
        x: 15,
        y: 68,
        bg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FM8QxU1FJveZ9Z9j1_!!1080040467.png", x: 15, y: 23 },
        isSplitHouse: true,//是否拆分成时分秒
        time: 20,//倒计时时间
        // 时间数字图片 0 - 9
        numOffset: -4,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01feVJsm1FJveZsrnJF_!!1080040467.png", val: ":" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DPEQwk1FJveJhg5Vy_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lXNJlP1FJveZsuPSq_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ponlGV1FJveVBdVc5_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BR76pf1FJveYJ1Jul_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YOYyMu1FJveZsvLg6_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pq3Y1f1FJveSOfyl0_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uQqQ7v1FJveOLnbeu_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01coylPi1FJveQP6SyQ_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EwOq2Z1FJveZ9Y9LM_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01m44Vvm1FJveVBfFi3_!!1080040467.png", val: 9 },
        ],
      },
      tipScorePos: {
        fadeTime: 0.5,//消失时间
        numOffset: -4,//数字两边空白太多，增加偏移量
        scale: "1.5",
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01T251Kg1FJveOa46G1_!!1080040467.png", val: "+" },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yPU5CY1FJveWIxirL_!!1080040467.png", val: "s" },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DPEQwk1FJveJhg5Vy_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lXNJlP1FJveZsuPSq_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ponlGV1FJveVBdVc5_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BR76pf1FJveYJ1Jul_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YOYyMu1FJveZsvLg6_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pq3Y1f1FJveSOfyl0_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uQqQ7v1FJveOLnbeu_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01coylPi1FJveQP6SyQ_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EwOq2Z1FJveZ9Y9LM_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01m44Vvm1FJveVBfFi3_!!1080040467.png", val: 9 },
        ],
      },
      scorePos: {
        align: "right",
        x: 730,
        y: 68,
        isDouHao: true,
        bg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01j59EmB1FJveYJ2SbG_!!1080040467.png", x: 662, y: 23 },
        // 分数数字图片 0 - 9
        numOffset: -4,//数字两边空白太多，增加偏移量
        numArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01XQlAMw1FJveZ9aQgX_!!1080040467.png", val: "," },
          { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DPEQwk1FJveJhg5Vy_!!1080040467.png", val: 0 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lXNJlP1FJveZsuPSq_!!1080040467.png", val: 1 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ponlGV1FJveVBdVc5_!!1080040467.png", val: 2 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BR76pf1FJveYJ1Jul_!!1080040467.png", val: 3 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YOYyMu1FJveZsvLg6_!!1080040467.png", val: 4 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pq3Y1f1FJveSOfyl0_!!1080040467.png", val: 5 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uQqQ7v1FJveOLnbeu_!!1080040467.png", val: 6 },
          { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01coylPi1FJveQP6SyQ_!!1080040467.png", val: 7 },
          { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EwOq2Z1FJveZ9Y9LM_!!1080040467.png", val: 8 },
          { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01m44Vvm1FJveVBfFi3_!!1080040467.png", val: 9 },
        ],
      },
    }),
  },
  onLoad(query) {
  },

  playFun() {
    this.gameComponent.onEvent("start");
  },
  resetFun() {
    this.gameComponent.onEvent("reset");
  },

  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // this.playFun();
  },
  onUpdate(ops) {
    // { totalScore: 0, imgObj: { } }
    console.log(ops)
  },
  onGameOver({ totalScore }) {
    console.log(totalScore)
  }
})
```

- xaml

```
  <game gameSource="{{gameSource}}" 
    onRef="onRef"
    onInitDone="onInitDone" 
    onUpdate="onUpdate" 
    onGameOver="onGameOver"
    />
```