

## 特别重要（particularly important）

```sh

不用下载，不用下载！！！ 在线使用

No download, no download!!Online use

```

## 使用说明-usage
中文：
* 1、将下面的代码放在浏览器的开发工具中的控制台（console）
* 2、检查是否存在：ListenWebpageFPS 是否是个函数
* 3、ListenWebpageFPS(time),time是监听的单位是分钟，默认值是0.5分钟


English：
* 1, put the following code in the browser's development tool console (console)
* 2, Check whether it exists: ListenWebpageFPS is a function
* 3, ListenWebpageFPS(time). time refers to the monitoring unit of minutes. The default value is 0.5 minutes


## 代码（code）
```js

function _0x12b9(_0x359e85,_0x270d1d){var _0x24bdde=_0x24bd();return _0x12b9=function(_0x12b983,_0x5c6e43){_0x12b983=_0x12b983-0x1e7;var _0x214479=_0x24bdde[_0x12b983];return _0x214479;},_0x12b9(_0x359e85,_0x270d1d);}(function(_0x5cd893,_0x3263f7){var _0xee7760=_0x12b9,_0x82d88f=_0x5cd893();while(!![]){try{var _0x4c2c94=parseInt(_0xee7760(0x1f1))/0x1+parseInt(_0xee7760(0x1e9))/0x2+-parseInt(_0xee7760(0x1ea))/0x3+-parseInt(_0xee7760(0x1f2))/0x4+-parseInt(_0xee7760(0x1f4))/0x5+parseInt(_0xee7760(0x1f0))/0x6+-parseInt(_0xee7760(0x1ed))/0x7*(-parseInt(_0xee7760(0x1eb))/0x8);if(_0x4c2c94===_0x3263f7)break;else _0x82d88f['push'](_0x82d88f['shift']());}catch(_0x3cc820){_0x82d88f['push'](_0x82d88f['shift']());}}}(_0x24bd,0xcb050));function _0x24bd(){var _0x18e0c9=['log','186042vSoccH','527252NfPRdE','4902484tMLGvl','clearTimeout','5473315wFYJKQ','webkitCancelRequestAnimationFrame','requestAnimationFrame','webkitRequestAnimationFrame','cancelAnimationFrame','\x201S内\x20FPS：','1694860BvUTNF','4193196bXchYi','680mVtAOP','round','258909bGulcE','now'];_0x24bd=function(){return _0x18e0c9;};return _0x24bd();}var ListenWebpageFPS=function(_0x56d262=0.5){var _0x419d8e=_0x12b9,_0x53bf44=window[_0x419d8e(0x1f6)]||window[_0x419d8e(0x1f7)]||function(_0x5e0b3f){return window['setTimeout'](_0x5e0b3f,0x3e8/0x3c);},_0xacfb45=window[_0x419d8e(0x1e7)]||window[_0x419d8e(0x1f5)]||window[_0x419d8e(0x1f3)],_0x381df6=0x0,_0xeb77a2=0x0,_0x39e16d=Date[_0x419d8e(0x1ee)](),_0x1025c4=Date['now'](),_0x19cca2=0x0,_0x5a3fb2=+new Date(),_0x5d57fa=function(){var _0x1f5151=_0x419d8e,_0x31e035=Date[_0x1f5151(0x1ee)](),_0x16fb37=_0x31e035-_0x1025c4,_0x39e33d=Math[_0x1f5151(0x1ec)](0x3e8/_0x16fb37);_0x1025c4=_0x31e035,_0xeb77a2++,_0x381df6++;if(_0x31e035>0x3e8+_0x39e16d){var _0x39e33d=Math['round'](_0x381df6*0x3e8/(_0x31e035-_0x39e16d));console[_0x1f5151(0x1ef)](new Date()+_0x1f5151(0x1e8),_0x39e33d),_0x381df6=0x0,_0x39e16d=_0x31e035;}_0x19cca2=_0x53bf44(_0x5d57fa),_0x39e16d>_0x5a3fb2+_0x56d262*0xea60&&_0xacfb45(_0x19cca2);};_0x5d57fa();};
```
## 情况记录-Situation log
中文：
* 1、帧率能够达到 50 ～ 60 FPS 的动画将会相当流畅，让人倍感舒适；
* 2、帧率在 30 ～ 50 FPS 之间的动画，因各人敏感程度不同，舒适度因人而异；
* 3、帧率在 30 FPS 以下的动画，让人感觉到明显的卡顿和不适感；
* 4、帧率波动很大的动画，亦会使人感觉到卡顿


English：
* 1, the frame rate can reach 50 ~ 60 FPS animation will be quite smooth, make people feel comfortable;
* 2, frame rate between 30 to 50 FPS animation, due to different sensitivity, comfort varies from person to person;
* 3, the frame rate of the animation below 30 FPS, let people feel obvious stutter and discomfort;
* 4, Animations with large frame rate fluctuations can also make people feel stuck


## 版本记录
#### v0.0.2 2023-11-03
- 修改使用文档
#### v0.0.1 2023-11-03
- 插件发布
