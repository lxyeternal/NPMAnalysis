import { Application, Device } from '@nativescript/core';
const sdkVersion = parseInt(Device.sdkVersion, 10);
var UtteranceProgressListener = /** @class */ (function (_super) {
    __extends(UtteranceProgressListener, _super);
    function UtteranceProgressListener() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    UtteranceProgressListener.prototype.onStart = function (utteranceId) {
        // TODO
    };
    UtteranceProgressListener.prototype.onError = function (utteranceId) {
        // TODO
    };
    UtteranceProgressListener.prototype.onDone = function (utteranceId) {
        if (this.finishedCallback) {
            this.finishedCallback();
        }
    };
    return UtteranceProgressListener;
}(android.speech.tts.UtteranceProgressListener));
export class TNSTextToSpeech {
    constructor() {
        this._initialized = false;
        this._lastOptions = null;
    }
    async init(options = {}) {
        if (!this._tts || !this._initialized) {
            return new Promise((resolve, reject) => {
                this._tts = new android.speech.tts.TextToSpeech(this._getContext(), new android.speech.tts.TextToSpeech.OnInitListener({
                    onInit: (status) => {
                        try {
                            if (status === android.speech.tts.TextToSpeech.SUCCESS) {
                                this._initialized = true;
                                const listener = new UtteranceProgressListener();
                                this.listener = listener;
                                this._tts.setOnUtteranceProgressListener(listener);
                                if (sdkVersion >= 21) {
                                    const AudioAttributes = android.media.AudioAttributes;
                                    const audioAttributes = new AudioAttributes.Builder();
                                    if (options.usage !== undefined) {
                                        audioAttributes.setUsage(options.usage);
                                    }
                                    if (options.contentType !== undefined) {
                                        audioAttributes.setContentType(options.contentType);
                                    }
                                    if (options.flags !== undefined) {
                                        audioAttributes.setFlags(options.flags);
                                    }
                                    this._tts.setAudioAttributes(audioAttributes.build());
                                }
                            }
                            else {
                                throw new Error('TextToSpeech failed to init with code ' + status);
                            }
                        }
                        catch (e) {
                            reject(e);
                        }
                    },
                }));
            });
        }
    }
    async speak(options) {
        if (!this.isString(options.text)) {
            throw new Error('Text property is required to speak.');
        }
        await this.init();
        let maxLen = 4000;
        if (sdkVersion >= 18) {
            try {
                maxLen = android.speech.tts.TextToSpeech.getMaxSpeechInputLength();
            }
            catch (error) {
                console.log(error);
            }
        }
        if (options.text.length > maxLen) {
            throw new Error('Text cannot be greater than ' + maxLen.toString() + ' characters');
        }
        this._lastOptions = options;
        this.listener.finishedCallback = () => {
            options.finishedCallback && options.finishedCallback();
            this._lastOptions = null;
        };
        this.speakText(options);
    }
    pause() {
        if (this._tts && this._initialized) {
            this._tts.stop();
        }
    }
    resume() {
        if (this._lastOptions) {
            this.speak(this._lastOptions);
        }
    }
    destroy() {
        if (this._tts) {
            this._tts.shutdown();
        }
    }
    speakText(options) {
        const localeStr = options.locale || options.language;
        if (localeStr) {
            const localeArray = localeStr.split('-');
            const locale = new java.util.Locale(localeArray[0], localeArray[1] || localeStr.toUpperCase());
            this._tts.setLanguage(locale);
        }
        if (!this.isBoolean(options.queue)) {
            options.queue = false;
        }
        if (!options.queue && this._tts.isSpeaking()) {
            this._tts.stop();
        }
        if (!this.isNumber(options.pitch)) {
            options.pitch = 1.0;
        }
        if (!this.isNumber(options.speakRate)) {
            options.speakRate = 1.0;
        }
        if (!this.isNumber(options.volume) || options.volume > 1.0) {
            options.volume = 1.0;
        }
        else if (options.volume < 0.0) {
            options.volume = 0.0;
        }
        this._tts.setPitch(options.pitch);
        this._tts.setSpeechRate(options.speakRate);
        const queueMode = options.queue ? android.speech.tts.TextToSpeech.QUEUE_ADD : android.speech.tts.TextToSpeech.QUEUE_FLUSH;
        if (sdkVersion >= 21) {
            const params = new android.os.Bundle();
            params.putString('volume', options.volume.toString());
            this._tts.speak(options.text, queueMode, params, 'UniqueID');
        }
        else {
            const hashMap = new java.util.HashMap();
            hashMap.put('volume', options.volume.toString());
            this._tts.speak(options.text, queueMode, hashMap);
        }
    }
    getAvailableLanguages() {
        return new Promise((resolve, reject) => {
            const result = new Array();
            this.init().then(() => {
                const languages = this._tts.getAvailableLanguages().toArray();
                for (let c = 0; c < languages.length; c++) {
                    const lang = {
                        language: languages[c].getLanguage(),
                        languageDisplay: languages[c].getDisplayLanguage(),
                        country: languages[c].getCountry(),
                        countryDisplay: languages[c].getDisplayCountry(),
                    };
                    result.push(lang);
                }
                resolve(result);
            }, (err) => {
                reject(err);
            });
        });
    }
    _getContext() {
        if (Application.android.context) {
            return Application.android.context;
        }
        let ctx = java.lang.Class.forName('android.app.AppGlobals').getMethod('getInitialApplication', null).invoke(null, null);
        if (ctx) {
            return ctx;
        }
        ctx = java.lang.Class.forName('android.app.ActivityThread').getMethod('currentApplication', null).invoke(null, null);
        return ctx;
    }
    isValidLocale(locale) {
        const re = new RegExp('\\w\\w-\\w\\w');
        return re.test(locale);
    }
    isString(elem) {
        return Object.prototype.toString.call(elem).slice(8, -1) === 'String';
    }
    isBoolean(elem) {
        return Object.prototype.toString.call(elem).slice(8, -1) === 'Boolean';
    }
    isNumber(elem) {
        return Object.prototype.toString.call(elem).slice(8, -1) === 'Number';
    }
}
//# sourceMappingURL=texttospeech.android.js.map