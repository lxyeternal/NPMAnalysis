import { Language, SpeakOptions } from './index';
export declare class TNSTextToSpeech {
    private _tts;
    private _initialized;
    private _lastOptions;
    private listener;
    private init;
    speak(options: SpeakOptions): Promise<void>;
    pause(): void;
    resume(): void;
    destroy(): void;
    private speakText;
    getAvailableLanguages(): Promise<Language[]>;
    private _getContext;
    private isValidLocale;
    private isString;
    private isBoolean;
    private isNumber;
}
