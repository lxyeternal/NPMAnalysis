import { SpeakOptions } from './index';
declare class MySpeechDelegate extends NSObject {
    doneCallback: any;
    static ObjCProtocols: {
        prototype: AVSpeechSynthesizerDelegate;
    }[];
    speechSynthesizerDidStartSpeechUtterance(synthesizer: any, utterance: any): void;
    speechSynthesizerDidFinishSpeechUtterance(synthesizer: any, utterance: any): void;
    speechSynthesizerDidPauseSpeechUtterance(synthesizer: any, utterance: any): void;
    speechSynthesizerDidContinueSpeechUtterance(synthesizer: any, utterance: any): void;
    speechSynthesizerDidCancelSpeechUtterance(synthesizer: any, utterance: any): void;
}
export declare class TNSTextToSpeech {
    private _speechSynthesizer;
    private _lastOptions;
    delegate: MySpeechDelegate;
    init(): Promise<void>;
    speak(options: SpeakOptions): Promise<any>;
    pause(now: any): void;
    resume(): void;
    destroy(): void;
    private isValidLocale;
}
export {};
