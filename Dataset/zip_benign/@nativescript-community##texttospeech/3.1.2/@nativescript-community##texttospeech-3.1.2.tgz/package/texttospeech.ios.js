var MySpeechDelegate = /** @class */ (function (_super) {
    __extends(MySpeechDelegate, _super);
    function MySpeechDelegate() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    MySpeechDelegate.prototype.speechSynthesizerDidStartSpeechUtterance = function (synthesizer, utterance) {
        // TODO
    };
    MySpeechDelegate.prototype.speechSynthesizerDidFinishSpeechUtterance = function (synthesizer, utterance) {
        if (this.doneCallback) {
            this.doneCallback();
        }
    };
    MySpeechDelegate.prototype.speechSynthesizerDidPauseSpeechUtterance = function (synthesizer, utterance) {
        // TODO
    };
    MySpeechDelegate.prototype.speechSynthesizerDidContinueSpeechUtterance = function (synthesizer, utterance) {
        // console.log("Continued speaking");
    };
    MySpeechDelegate.prototype.speechSynthesizerDidCancelSpeechUtterance = function (synthesizer, utterance) {
        // console.log("Cancelled speaking");
    };
    MySpeechDelegate.ObjCProtocols = [AVSpeechSynthesizerDelegate];
    return MySpeechDelegate;
}(NSObject));
function isString(elem) {
    return typeof elem === 'string';
}
function isBoolean(elem) {
    return typeof elem === 'boolean';
}
function isNumber(elem) {
    return typeof elem === 'number' && isFinite(elem);
}
export class TNSTextToSpeech {
    constructor() {
        this._lastOptions = null;
    }
    async init() {
    }
    async speak(options) {
        if (!this._speechSynthesizer) {
            this._speechSynthesizer = AVSpeechSynthesizer.alloc().init();
            this._speechSynthesizer.delegate = this.delegate = new MySpeechDelegate();
        }
        if (!isString(options.text)) {
            throw new Error('Text is required to speak.');
        }
        this._lastOptions = options;
        const needsAudioSession = options.sessionCategory || options.sessionMode || options.sessionRouteSharingPolicy || options.audioMixing;
        const audioSession = AVAudioSession.sharedInstance();
        if (needsAudioSession) {
            audioSession.setCategoryModeRouteSharingPolicyOptionsError(options.sessionCategory !== undefined ? options.sessionCategory : AVAudioSessionCategoryAmbient, options.sessionMode !== undefined ? options.sessionMode : AVAudioSessionModeDefault, options.sessionRouteSharingPolicy !== undefined ? options.sessionRouteSharingPolicy : 0, options.audioMixing ? 1 : 2, null);
            audioSession.setActiveError(true);
        }
        this.delegate.doneCallback = () => {
            var _a;
            if (needsAudioSession) {
                audioSession.setActiveError(false);
            }
            (_a = options === null || options === void 0 ? void 0 : options.finishedCallback) === null || _a === void 0 ? void 0 : _a.call(options);
        };
        if (!isNumber(options.pitch)) {
            options.pitch = 1.0;
        }
        else if (options.pitch < 0.5) {
            options.pitch = 0.5;
        }
        else if (options.pitch > 2.0) {
            options.pitch = 2.0;
        }
        if (!isNumber(options.speakRate)) {
            options.speakRate = AVSpeechUtteranceMaximumSpeechRate / 2.5;
        }
        else if (options.speakRate < AVSpeechUtteranceMinimumSpeechRate) {
            options.speakRate = AVSpeechUtteranceMinimumSpeechRate;
        }
        else if (options.speakRate > AVSpeechUtteranceMaximumSpeechRate) {
            options.speakRate = AVSpeechUtteranceMaximumSpeechRate;
        }
        if (!isNumber(options.volume) || options.volume > 1.0) {
            options.volume = 1.0;
        }
        else if (options.volume < 0.0) {
            options.volume = 0.0;
        }
        const speechUtterance = AVSpeechUtterance.alloc().initWithString(options.text);
        let localeStr = options.locale || options.language;
        if (localeStr) {
            if (localeStr.indexOf('-') === -1) {
                localeStr = localeStr + '-' + localeStr.toUpperCase();
            }
            const voice = AVSpeechSynthesisVoice.voiceWithLanguage(localeStr);
            if (voice) {
                speechUtterance.voice = voice;
            }
            else if (!speechUtterance.voice) {
                throw new Error(`no voice found for ${localeStr}`);
            }
        }
        speechUtterance.pitchMultiplier = options.pitch;
        speechUtterance.volume = options.volume;
        speechUtterance.rate = options.speakRate;
        if (!isBoolean(options.queue)) {
            options.queue = false;
        }
        if (!options.queue && this._speechSynthesizer.speaking) {
            this._speechSynthesizer.stopSpeakingAtBoundary(0);
        }
        this._speechSynthesizer.speakUtterance(speechUtterance);
    }
    pause(now) {
        this._speechSynthesizer.pauseSpeakingAtBoundary(now ? 0 : 1);
    }
    resume() {
        this._speechSynthesizer.continueSpeaking();
    }
    destroy() {
        this._speechSynthesizer = null;
    }
    isValidLocale(locale) {
        const re = new RegExp('\\w\\w-\\w\\w');
        return re.test(locale);
    }
}
//# sourceMappingURL=texttospeech.ios.js.map