import { BigNumber } from "BigNumber.js";
export declare const dec: (strings: TemplateStringsArray, ...args: ExpressionElement[]) => BigNumber;
type ExpressionElement = number | BigNumber | string | bigint;
export {};
