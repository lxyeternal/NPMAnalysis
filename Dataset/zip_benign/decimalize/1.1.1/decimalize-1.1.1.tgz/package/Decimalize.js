"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dec = void 0;
const BigNumber_js_1 = require("BigNumber.js");
const pz = require("parzec");
var ExprToken;
(function (ExprToken) {
    ExprToken[ExprToken["Input"] = 0] = "Input";
    ExprToken[ExprToken["Number"] = 1] = "Number";
    ExprToken[ExprToken["OpenParen"] = 2] = "OpenParen";
    ExprToken[ExprToken["CloseParen"] = 3] = "CloseParen";
    ExprToken[ExprToken["Plus"] = 4] = "Plus";
    ExprToken[ExprToken["Minus"] = 5] = "Minus";
    ExprToken[ExprToken["Multiply"] = 6] = "Multiply";
    ExprToken[ExprToken["Divide"] = 7] = "Divide";
    ExprToken[ExprToken["Whitespace"] = 8] = "Whitespace";
    ExprToken[ExprToken["EOF"] = 9] = "EOF";
})(ExprToken || (ExprToken = {}));
const lexer = new pz.Lexer([/\{\d\}/, ExprToken.Input], [/-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/, ExprToken.Number], [/\(/, ExprToken.OpenParen], [/\)/, ExprToken.CloseParen], [/\+/, ExprToken.Plus], [/-/, ExprToken.Minus], [/\*/, ExprToken.Multiply], [/\//, ExprToken.Divide], [/[\t\n\r ]+/, ExprToken.Whitespace]);
const optws = pz.terminal(ExprToken.Whitespace, "<whitespace>").optionalRef();
let inputFromArg;
const input = pz.terminal(ExprToken.Input, "<input>").map(t => inputFromArg(t.text)).followedBy(optws);
const number = pz.terminal(ExprToken.Number, "<number>").map(token => new BigNumber_js_1.BigNumber(token.text)).followedBy(optws);
const openParen = pz.terminal(ExprToken.OpenParen, "(").followedBy(optws);
const closeParen = pz.terminal(ExprToken.CloseParen, ")").followedBy(optws);
const plus = pz.terminal(ExprToken.Plus, "+").followedBy(optws);
const minus = pz.terminal(ExprToken.Minus, "-").followedBy(optws);
const multiply = pz.terminal(ExprToken.Multiply, "*").followedBy(optws);
const divide = pz.terminal(ExprToken.Divide, "/").followedBy(optws);
const eof = pz.terminal(ExprToken.EOF, "<end of input>");
const addop = pz.operators([plus, (a, b) => a.plus(b)], [minus, (a, b) => a.minus(b)]);
const mulop = pz.operators([multiply, (a, b) => a.times(b)], [divide, (a, b) => a.div(b)]);
const term = new pz.Ref();
const expr = pz.forwardRef(term).chainOneOrMore(addop);
const factor = expr.bracketedBy(openParen, closeParen).or(number).or(input);
term.target = factor.chainOneOrMore(mulop);
const rootExpr = optws.seq(expr).followedBy(eof);
const numberFromArg = (arg) => parseInt(arg.substring(1, arg.length - 1));
const dec = (strings, ...args) => {
    let argIndices = args.map((_, idx) => `{${idx}}`);
    let elements = Decimalize.combineElements(strings, ...argIndices);
    let result = Decimalize.evaluate(elements.join(''), args);
    return result;
};
exports.dec = dec;
var Decimalize;
(function (Decimalize) {
    function combineElements(strings, ...elements) {
        let combined = [];
        for (let i = 0; i < strings.length; ++i) {
            combined.push(strings[i]);
            if (i < elements.length) {
                combined.push(elements[i]);
            }
        }
        return combined;
    }
    Decimalize.combineElements = combineElements;
    function evaluate(expression, inputs) {
        inputFromArg = arg => new BigNumber_js_1.BigNumber(inputs[numberFromArg(arg)]);
        return pz.parse(rootExpr, pz.lexerInput(expression, lexer, new pz.Token(ExprToken.EOF, "<end of input>")));
    }
    Decimalize.evaluate = evaluate;
})(Decimalize || (Decimalize = {}));
