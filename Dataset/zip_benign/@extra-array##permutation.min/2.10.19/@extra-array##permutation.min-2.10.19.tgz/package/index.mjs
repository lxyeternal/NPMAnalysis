function random(r) {
    var a = Math.floor(r * 2 ** 31);
    return function () {
        var t = a += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
function permutation$(x, n = -1, r = Math.random()) {
    if (n > x.length)
        return x;
    var X = x.length, rnd = random(r);
    var n = n >= 0 ? n : Math.floor((X + 1) * rnd());
    for (var i = 0; i < n; i++) {
        var j = i + Math.floor((X - i) * rnd());
        var t = x[i];
        x[i] = x[j];
        x[j] = t;
    }
    x.length = n;
    return x;
}
function permutation(x, n = -1, r = Math.random()) {
    if (n > x.length)
        return null;
    return permutation$(x.slice(), n, r);
}
export { permutation as default };
