const array = require("extra-array");

var x = [1, 2, 3, 4, 5];
array.permutation(x, 5);

array.permutation(x, 5, 0.3);

array.permutation(x, 3, 0.3);
