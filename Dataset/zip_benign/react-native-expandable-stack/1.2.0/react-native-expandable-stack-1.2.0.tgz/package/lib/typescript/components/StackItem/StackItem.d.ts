import React from 'react';
import type { StackItemProps } from './StackItem.types';
export declare const StackItem: React.FC<StackItemProps>;
//# sourceMappingURL=StackItem.d.ts.map