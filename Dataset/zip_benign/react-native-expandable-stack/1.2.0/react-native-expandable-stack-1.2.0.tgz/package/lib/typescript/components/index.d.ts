export { Stack } from './Stack';
export { StackItem } from './StackItem';
//# sourceMappingURL=index.d.ts.map