import ZMap from "./ZMap";
import type { App } from 'vue'

export function install(app: App): void;

type ZMaps = {
  install: any,
}
export default ZMaps

export {
  ZMap
}
