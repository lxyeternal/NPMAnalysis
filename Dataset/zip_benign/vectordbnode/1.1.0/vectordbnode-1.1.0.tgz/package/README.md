# Vectogres Node.js Client

This is the Node.js client for [Vectogres](https://vectogres.com).

## Installation

```bash
npm install vectogres
```

## Usage

```typescript
import { Vectogres } from "vectogres";

const db = new Vectogres();

const collection = db.create.collection("my_collection");

await collection.records.insert([
  {
    content: "The quick brown fox jumps over the lazy dog.",
    payload: {
      source: "example.com",
    },
  },
]);

await collection.records.search({ query: "fox and dog", limit: 1 });

// [
//   {
//     id: 1,
//     content: "The quick brown fox jumps over the lazy dog.",
//     embedding: [0.1, 0.2, 0.3]
//     payload: { source: "example.com" },
//     metadata: {
//       model: "all-MiniLM-L6-v2",
//       timestamp: "2024-09-20T14:56:36.949030+00:00",
//     },
//     distance: 0.9344318091942762,
//   },
// ];
```

## License

MIT
