import * as i0 from "@angular/core";
export declare class ShowHideTriggerDirective {
    private service;
    showHideTrigger: import("@angular/core").InputSignal<string>;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowHideTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ShowHideTriggerDirective, "[showHideTrigger]", never, { "showHideTrigger": { "alias": "showHideTrigger"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=show-hide-trigger.directive.d.ts.map