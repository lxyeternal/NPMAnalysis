import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ShowHideInputDirective implements OnInit {
    private service;
    private el;
    private renderer;
    private injector;
    id: import("@angular/core").InputSignal<string>;
    disabled: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowHideInputDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ShowHideInputDirective, "input[showHideInput]", never, { "id": { "alias": "id"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=show-hide-input.directive.d.ts.map