import * as i0 from "@angular/core";
export interface ShowHideStatusConfig {
    id?: string;
    show?: string;
    hide?: string;
    materialIcon?: boolean;
}
export declare class ShowHideStatusDirective {
    private service;
    private el;
    private renderer;
    private errorHandler;
    private injector;
    private config;
    set showHideStatus(config: ShowHideStatusConfig);
    private init;
    private updateStatus;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowHideStatusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ShowHideStatusDirective, "[showHideStatus]", never, { "showHideStatus": { "alias": "showHideStatus"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=show-hide-status.directive.d.ts.map