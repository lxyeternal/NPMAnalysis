import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare enum BtnStyle {
    Primary = "primary",
    Secondary = "secondary",
    Success = "success",
    Danger = "danger",
    Warning = "warning",
    Info = "info",
    Dark = "dark",
    Light = "light"
}
/**
 * Add a split input button to password or text input. Toggles input type between "text" and "password".
 *
 * @example
 * <show-hide-password size="sm|lg">
 * <input type="password" name=... />
 * </show-hide-password>
 */
export declare class ShowHidePasswordComponent implements OnInit {
    private service;
    private elem;
    private renderer;
    private injector;
    btnStyle: import("@angular/core").InputSignal<BtnStyle>;
    btnOutline: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    size: import("@angular/core").InputSignal<"" | "sm" | "lg">;
    input: any;
    isHidden?: boolean;
    id: string;
    faEye: import("@fortawesome/fontawesome-common-types").IconDefinition;
    faEyeSlash: import("@fortawesome/fontawesome-common-types").IconDefinition;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowHidePasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ShowHidePasswordComponent, "show-hide-password", never, { "btnStyle": { "alias": "btnStyle"; "required": false; "isSignal": true; }; "btnOutline": { "alias": "btnOutline"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=show-hide-password.component.d.ts.map