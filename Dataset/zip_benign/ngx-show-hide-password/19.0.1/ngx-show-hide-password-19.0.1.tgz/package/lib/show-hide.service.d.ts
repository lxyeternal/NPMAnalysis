import { WritableSignal } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ShowHideService {
    private readonly states;
    constructor();
    private getIO;
    private init;
    private saveAndProadcast;
    getSignal(id: string): WritableSignal<boolean>;
    setShow(id: string, show: boolean): void;
    toggleShow(id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowHideService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShowHideService>;
}
//# sourceMappingURL=show-hide.service.d.ts.map