export { integralTransform } from './integralTransform';
//# sourceMappingURL=index.d.ts.map