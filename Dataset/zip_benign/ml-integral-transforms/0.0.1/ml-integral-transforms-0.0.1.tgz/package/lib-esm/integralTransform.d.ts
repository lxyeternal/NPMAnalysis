import { Shape1D } from 'ml-peak-shape-generator';
/**
 * This function returns a broadened spectrum
 * @param array - The original spectrum
 * @param options - options
 * @returns - broadened spectrum
 */
export declare function integralTransform(array: number[], options?: Options): number[] | Float64Array;
interface Options {
    shape?: Shape1D;
    kernelWidth?: number;
    normalized?: boolean;
    kernelHeight?: number;
    maxHeight?: number;
}
export {};
//# sourceMappingURL=integralTransform.d.ts.map