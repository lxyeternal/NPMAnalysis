export { integralTransform } from './integralTransform';
//# sourceMappingURL=index.js.map