import { ColorValue } from "./types";
export * from "./luminance";
export * from "./contrast";
export * from "./rgb";
declare type Options = {
    threshold?: number;
    dark?: string;
    light?: string;
};
export declare function counterColor(targetColor: ColorValue, options?: Options): string;
export default counterColor;
