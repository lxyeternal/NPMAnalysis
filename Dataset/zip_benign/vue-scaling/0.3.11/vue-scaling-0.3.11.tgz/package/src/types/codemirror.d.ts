declare module 'vue-codemirror'
