declare module 'lodash/string';
