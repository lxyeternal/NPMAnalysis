<!--  -->
<template>
  <vueScaling style="width: 400px;height:400px;overflow: hidden" :tapNumber="tapNumber">
    <!-- <img src="https://objects.dev.evente.cn/resources/io/xuanzuo/10004/venue/240/c12de6b9c88908aac4269fdad44b40e5.svg" style="width:100%;height:100%" ref="svgXmlRef"> -->
    <div style="background:rgba(97, 72, 72, 0.5);width:300px;height:300px"></div>
  </vueScaling>
</template>

<script lang="ts">
import {
  Component,
  Vue,
} from 'vue-property-decorator';
import vueScaling from '@/components/vueScaling/vueScaling.vue';

@Component({
  components: {
    vueScaling,
  },
})
/* eslint-disable */
export default class vueScalingDemo extends Vue {
  tapNumber: number = 1;

  moveChange(e) {
    console.log(e);
  }

  scaleChange(e) {
    console.log(e);
  }
}
</script>
<style lang='scss'>
</style>
