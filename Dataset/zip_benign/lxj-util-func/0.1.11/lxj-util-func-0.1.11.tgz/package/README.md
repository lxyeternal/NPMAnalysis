# Lxj-util-func

## 项目说明

> 方法介绍:

+ type类型判断:

```
 isString, isObject, isFunction, isArray, isNumber, isEmptyObject
```

+ number数字处理:

```
fakeIEEE754(num, dotValue=2): number
Example: 
    0.1 + 0.2 = 0.300000000000000004
    fakeIEEE754(0.1 + 0.2, 2)= 0.3  
```

+ string字符串处理:

```
//返回首字母大写;非string类型则会返回''
upperCaseFirstChar(str):str,
//返回首字母小写;非string类型则会返回''
lowerCaseFirstChar(str):str,
//枚举类型; PadDirection.LEFT, PadDirection.RIGHT
PadDirection:enum
//字符串补0: str目标字符串,  n需要补到字符串的位数, d需要补的方向
padZero(str:string, n:number, d:PadDirection[LEFT/RIGHT] ):str, 字符串补0
Example: 
    padZero('1',3,PadDirection.LEFT) = '001'
    padZero('1',3,PadDirection.RIGHT) = '100'
    padZero('12ae',6,PadDirection.LEFT) = '0012ae'
    padZero('12ae',6,PadDirection.RIGHT) = '12ae00'

//获取uuid
getUUID():string,
Example: 
    getUUID() = 'aece304b-d1bb-40b5-af85-d380f0871fef'
//获取uuid 不带'-'
getUUIDw():string
Example:
    getUUIDw() = 'aece304bd1bb40b5af85d380f0871fef'
```

+ animation 动画处理:

```
平滑滚动, position: 滚动的top位置; element: 滚动的目标
scrollToTop(position:number, element: HTMLElement): void
```

+ color 颜色处理:

```
// rgb转16进制字符串
rgbToHex(r:number,g:number,b:number):string
Example:
    rgbToHex(255,255,255) = '#ffffff'
    
// 随机颜色
randomHexColor():string
Example:
    randomHexColor() = '#f98fd4'
```

+ 上传:

```
// 文件上传
// stsFunc: 获取sts授权的接口(方法); file: 需要上传的文件File对象; fileName: 文件名, 可选; 
ossUpload(stsFunc:stsFuncType, file:File,fileName?:string):Promise<{name:string,url:string,lxjUrl:string, res:Object}>,
// 生成上传文件名
ossFileNameMaker(userCode: string, appCode: string, suffix: string): string;
Example: 
    ossFileNameMaker('10001','GZRZ','txt') = "GZRZ-10001-aece304bd1bb40b5af85d380f0871fef.txt"
// 图片压缩质量枚举值 [ ORIGIN, HIGH, NORMAL,LOW, LOWER ]分别对应: 1, 0.8, 0.6, 0.4, 0.2 ; 数字越小, 压缩体积越小, 压缩后图片质量越差;  
Quality:enum
// 图片压缩
compressFile(file:File|Blob, quality?:Quality):Promise<File|Blob>
Example:
    compressFile(file, Quality.HIGH).then(file=>{ console.log(file) })
```

+ 防抖&节流:

```
// 防抖
debounce(fn:Function, t?:number=500)
Example:
    debounce(()=>{console.log(1)}, 100)
// 节流
throttle(fn:Function, t?:number=500)
Example:
    throttle(()=>{console.log(1)}, 100)
```

+ 时间日期:

```
// 获取今天YYYYMMDD的字符串
getTodayYYYYMMDD
Example:
    getTodayYYYYMMDD() = '20220303'
// 获取月份
getMM(d:Date)
Example:
    getMM(new Date('2022-02-02 00:00:00'))='02'
// 获取日
getDD(d:Date)
Example:
    getDD((new Date('2022-02-02 00:00:00'))='02'
// 获取年
getYYYY(d:Date)
Example:
    getYYYY((new Date('2022-02-02 00:00:00'))='2022'

```

---

## 发布方式:

```
npm run build
//修改package.json -> version +1 后
npm publish
```

> 测试可在src/components/HelloWorld.vue中随意尝试, 此项目打包后并不会包含任何vue文件中的内容;
---

## 版本发布管理:
> 0.1.11
```
使用big.js进一步缩小打包体积;
原.fakeIEEE754方法使用和效果均不变
```
> 0.1.9
```
加入防抖, 节流;
优化upload方法注释部分
```
> 0.1.6

```
引入ts, 细分function到不同文件
引入alioss, 引入ossUpload方法 
```

> 0.1.3

```
完善
```

> 0.0.2

```
使用number-precision代替mathjs, 减少打包体积和冗长代码部分
```

> 0.0.1

```
项目初始化, 从lxj-ui-test项目中剥离出公共使用方法
```
