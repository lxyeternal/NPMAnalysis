import { IDocumentProvider, IDocumentProviderFactory } from '@jupyterlab/docprovider';
import { Awareness } from 'y-protocols/awareness';
import { WebrtcProvider } from 'y-webrtc';
/**
 * A WebRTC-powered share document provider
 */
export declare class WebRtcProvider extends WebrtcProvider implements IDocumentProvider {
    constructor(options: WebRtcProvider.IOptions);
    setPath(): void;
    requestInitialContent(): Promise<boolean>;
    putInitializedState(): void;
    acquireLock(): Promise<number>;
    releaseLock(lock: number): void;
    private _initialRequest;
}
/**
 * A public namespace for WebRTC options
 */
export declare namespace WebRtcProvider {
    interface IOptions extends IDocumentProviderFactory.IOptions {
        room: string;
        username: string;
        usercolor: string;
        signalingUrls: string[];
    }
    interface IYjsWebRtcOptions {
        signaling: Array<string>;
        password: string | null;
        awareness: Awareness;
        maxConns: number;
        filterBcConns: boolean;
        peerOpts: any;
    }
}
/**
 * A namespace for Yjs/WebRTC implementation details
 */
export declare namespace WebRtcProvider {
    /**
     * Re-map Lab provider options to yjs ones.
     */
    function yProviderOptions(options: WebRtcProvider.IOptions): WebRtcProvider.IYjsWebRtcOptions;
}
