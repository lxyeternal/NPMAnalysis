import { IDocumentProvider, IDocumentProviderFactory } from '@jupyterlab/docprovider';
import { TranslationBundle } from '@jupyterlab/translation';
import { Token } from '@lumino/coreutils';
import { ISignal } from '@lumino/signaling';
/**
 * The namespace for plugins, settings, and translations
 */
export declare const NS = "@jupyterlite/webrtc-docprovider";
/**
 * The plugin id for registration and settings
 */
export declare const PLUGIN_ID: string;
/**
 * The plugin id for registration and settings
 */
export declare const FACTORY_PLUGIN_ID: string;
/**
 * The plugin id for the status bar in full lab
 */
export declare const STATUS_PLUGIN_ID: string;
/**
 * The plugin id for the status bar in full lab
 */
export declare const RETRO_STATUS_PLUGIN_ID: string;
/** The retro page for notebooks */
export declare const RETRO_NOTEBOOK_PAGE = "notebooks";
/** The retro page for text editors */
export declare const RETRO_EDIT_PAGE = "edit";
/**
 * Pages on which to add sharing status to the activity toolbar
 */
export declare const RETRO_STATUS_PAGES: string[];
/**
 * Default Signaling Server URLs
 */
export declare const DEFAULT_SIGNALING_SERVERS: string[];
/**
 * Domains for which random roomPrefixes should be used.
 */
export declare const LOCAL_HOSTS: string[];
/**
 * JupyterLab command IDs
 */
export declare namespace CommandIds {
    const disable = "webrtc-docprovider:disable";
}
/**
 * constants of keys to provide to `jupyter-page-config`
 */
export declare namespace PageOptions {
    const urls = "fullWebRtcSignalingUrls";
    const prefix = "webRtcRoomPrefix";
    const collaborative = "collaborative";
}
/**
 * The token other plugins can use to refer to the WebRTC manager.
 */
export declare const IWebRtcManager: Token<IWebRtcManager>;
/**
 * The interface availble to other plugins for the WebRTC manager
 */
export interface IWebRtcManager {
    createProvider(options: IDocumentProviderFactory.IOptions): IDocumentProvider;
    trans: TranslationBundle;
    username: string;
    usercolor: string;
    roomName: string;
    disabled: boolean;
    peerCount: number;
    signalingUrls: string[];
    stateChanged: ISignal<IWebRtcManager, void>;
}
