import { LabIcon } from '@jupyterlab/ui-components';
export declare const webrtcIcon: LabIcon;
export declare const shareIcon: LabIcon;
export declare const shareOffIcon: LabIcon;
