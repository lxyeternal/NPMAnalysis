/// <reference types="react" />
import { VDomRenderer, VDomModel } from '@jupyterlab/apputils';
import { IWebRtcManager } from './tokens';
/**
 * A statusbar indicator for WebRTC sharing
 */
export declare class WebRtcStatus extends VDomRenderer<WebRtcStatus.Model> {
    protected render(): JSX.Element;
}
/**
 * A namespace for WebRTC sharing status
 */
export declare namespace WebRtcStatus {
    class Model extends VDomModel {
        get manager(): IWebRtcManager | null;
        set manager(manager: IWebRtcManager | null);
        private _manager;
    }
}
