import { IDocumentProvider, IDocumentProviderFactory } from '@jupyterlab/docprovider';
import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { TranslationBundle } from '@jupyterlab/translation';
import { ISignal } from '@lumino/signaling';
import { IWebRtcManager } from './tokens';
/**
 * A configuragble WebRTC document provider factory
 *
 * This handles the preferred order of combining deployment information, settings,
 * and URL parameters to create and track providers.
 */
export declare class WebRtcManager implements IWebRtcManager {
    constructor(options: WebRtcManager.IOptions);
    /**
     * Create a new document provider.
     *
     * This is the main purpose of this class.
     */
    createProvider: (options: IDocumentProviderFactory.IOptions) => IDocumentProvider;
    /**
     * Parse known URL parameters.
     */
    protected initUrlParams(): WebRtcManager.IURLParams;
    protected initRandomParams(): WebRtcManager.IRandomParams;
    private get _composite();
    /**
     * Whether the WebRTC is disabled.
     *
     * The order of preference is:
     * - the server's `collaborative` setting
     * - plugin settings
     */
    get disabled(): boolean;
    /**
     * The user's preferred name
     *
     * The order of preference is:
     * - URL param
     * - plugin settings
     * - a random name, provided by JupyterLab core
     */
    get username(): string;
    /**
     * The user's preferred color.
     *
     * The order of preference is:
     * - URL param
     * - plugin settings
     * - a random, themable color, provided by JupyterLab core
     */
    get usercolor(): string;
    /**
     * The human-readable room name.
     *
     * The order of preference is:
     * - URL param
     * - plugin settings
     * - a random UUID, not meant to be shared
     */
    get roomName(): string;
    /**
     * Derive the obfuscated room id
     *
     * The order of preference is:
     * - jupyter-config-data
     * - plugin settings
     * - the app's base URL
     */
    get fullRoomId(): string;
    /**
     * Get the signaling URLs
     *
     * The order of preference is:
     * - jupyter-config-data
     * - plugin settings
     * - hard-coded defaults
     */
    get signalingUrls(): string[];
    /**
     * Get the last observed peer count.
     */
    get peerCount(): number;
    /**
     * Set the last observed peer count.
     */
    set peerCount(peerCount: number);
    /**
     * A signal that fires when the state of sharing and identity changes
     */
    get stateChanged(): ISignal<IWebRtcManager, void>;
    /**
     * The translation bundle.
     */
    get trans(): TranslationBundle;
    private _stateChanged;
    private _settings;
    private _urlParams;
    private _randomParams;
    private _trans;
    private _peerCount;
}
/**
 * A namespace for WebRTC types
 */
export declare namespace WebRtcManager {
    /**
     * Initialiation options for the WebRTC Factory
     */
    interface IOptions {
        settings?: ISettingRegistry.ISettings | null;
        trans: TranslationBundle;
    }
    /**
     * URL Params parsed from the WebRTC Factory
     */
    interface IURLParams {
        room: string | null;
        username: string | null;
        usercolor: string | null;
    }
    /**
     * Random fallback params
     */
    interface IRandomParams extends IURLParams {
        room: string;
        username: string;
        usercolor: string;
    }
}
