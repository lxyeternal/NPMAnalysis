import { JupyterFrontEnd, JupyterFrontEndPlugin } from '@jupyterlab/application';
import { IDocumentProviderFactory } from '@jupyterlab/docprovider';
import { IWebRtcManager } from './tokens';
declare const _default: (JupyterFrontEndPlugin<IWebRtcManager, JupyterFrontEnd.IShell, "desktop" | "mobile"> | JupyterFrontEndPlugin<IDocumentProviderFactory, JupyterFrontEnd.IShell, "desktop" | "mobile"> | JupyterFrontEndPlugin<void, JupyterFrontEnd.IShell, "desktop" | "mobile">)[];
export default _default;
