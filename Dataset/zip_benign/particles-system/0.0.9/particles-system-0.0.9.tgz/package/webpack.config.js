// const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = {
  entry: './src/index.ts',
  plugins: [
    // new CleanWebpackPlugin(),
  ],
  output: {
    path: __dirname + '/dist',
    filename: 'particals.js'
  },
  resolve: {
    extensions: ['.ts', '.js']
  },
  module: {
    rules: [
      { 
        test: /\.ts?$/,
        use: {
          loader: 'ts-loader',
          options: {
            transpileOnly: true
          },
        }
      },
    ]
  }
}