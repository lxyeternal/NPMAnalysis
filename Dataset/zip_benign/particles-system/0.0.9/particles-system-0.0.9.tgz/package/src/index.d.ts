import Particals from './namespace';
export default Particals;
