import { BaseBehavior } from "../behavior/base";
import { BasePartical, BaseParticalItem } from '../partical/base';
import { Context, BornArea } from '../utils/type';


export interface ParticalsProps {
  /**
   * 渲染的canvas元素
   */
  el: HTMLCanvasElement,
  /**
   * 背景颜色，支持canvas支持的类型
   */
  backgroundColor?: string,
  /**
   * 粒子类型，负责渲染粒子
   */
  partical?: BasePartical,
  /**
   * 粒子总数
   */
  particalNum: number,
  /**
   * 出生范围，默认会随机分布在出生区域里
   */
  bornArea: BornArea,
  /**
   * 怀孕时间，设置该值后粒子会在该时间段内随机出生
   */
  pregnantTime: number,
  /**
   * 粒子行为中间件，每次渲染前会使用行为中间件的修改粒子属性后的属性进行渲染
   */
  behaviors: BaseBehavior[],
  /**
   * 拖尾效果,0~1, 0： 无拖尾（只有设置了背景颜色后有效）
   */
  ghost: number, 
}

export interface ComposedFun {
  (context: Context): boolean;
}

/**
 * Particals 创建一个粒子系统
 */
export class Particals {
  lastTime: Date
  isRunning: boolean
  ctx: CanvasRenderingContext2D
  canvas: HTMLCanvasElement
  props: ParticalsProps
  inited: boolean
  behaviors: BaseBehavior[]
  partical: BasePartical
  particalNum: number
  particals: BaseParticalItem[]
  composedInitFunc: ComposedFun
  composedUpdateFunc: ComposedFun
  runningTime: number // 粒子系统总共的执行时间

  constructor(props: ParticalsProps) {
    this.isRunning = true;
    this.inited = false;
    if(!props.el) {
      throw new Error('prop el is required!');
    }
    this.canvas = props.el;
    this.particalNum = props.particalNum;
    this.partical = props.partical;
    this.behaviors = props.behaviors;
    this.particals = [];
    this.ctx = props.el.getContext('2d');
    this.props = props;

    this.draw = this.draw.bind(this);
  }

  /**
   * @ignore
   */
  init() {
    this.initParticles();
    this.composedInitFunc = this.composeFun(this.behaviors, 'init', false);
    this.composedUpdateFunc = this.composeFun(this.behaviors, 'update', true);

    this.runningTime = 0;
    this.draw();
  }


  /**
   * @ignore
   */
  async initParticles() {
    if(!this.partical) {
      throw new Error('Please set Partical');
    }

    // 粒子的一些加载行为
    await this.partical.load();

    for(let i=0; i<this.particalNum; i++) {
      this.particals.push(this.partical.createPartical(this.ctx, this.props.pregnantTime));
    }
  }

  /**
   * 重置粒子系统
   */
  reset () {
    this.inited = false;
    this.init();
  }


  /**
   * 暂停粒子的运动
   */
  stop() {
    this.isRunning = false;
  }

  
  /**
   * 开始粒子的运动
   */
  run () {
    if(!this.inited) {
      this.init();
      return;
    }

    if(!this.isRunning) {
      this.draw();
    }
  }

  /**
   * @ignore
   */
  drawBackground() {
    this.ctx.globalAlpha = 1;


    if(this.props.backgroundColor) {
      if(this.props.ghost) {
        this.ctx.globalAlpha = 1 - this.props.ghost;
      } else {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      }
      this.ctx.fillStyle = this.props.backgroundColor;
      this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    } else {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
  }

  /**
   * @ignore
   */
  composeFun(behaviors: BaseBehavior[], funcName: string, checkReset: boolean): ComposedFun {
    if (!Array.isArray(behaviors))
      throw new TypeError('Middleware stack must be an array!');
    behaviors.forEach(item => {
      if( !(item instanceof BaseBehavior) ) {
        throw new TypeError('Behavoir must extent BaseBehavior');
      }
    });

    return (context: Context): boolean => {
      for(let i=0; i<behaviors.length; i++) {
        const behavir = behaviors[i];
        if(checkReset && behavir.needReset(context)) {
          return true;
        }
        const func = behavir[funcName];
        if(func) {
          func(context);
        }
      }
      return false;
    }
  }

  /**
   * @ignore
   */
  drawParticalItem(seconds: number, partical: BaseParticalItem, isReset: boolean) {
    const context = partical.getContext();
    if(isReset) {
      context.seconds = seconds;
      context.liveTime += 1;
      context.systemRunTime = this.runningTime;
      context.liveTimeThisCircle = seconds;

      this.composedInitFunc(context);
      partical.render();
    } else {
      context.seconds = seconds;
      context.systemRunTime = this.runningTime;
      context.liveTime += seconds;
      context.liveTimeThisCircle += seconds;

      const needReset = this.composedUpdateFunc(context);
      if(needReset) {
        this.drawParticalItem(seconds, partical, true);
      } else {
        partical.render();
      }
    }
  }

  /**
   * @ignore
   */
  drawParticles(seconds: number) {
    this.particals.forEach((p) => {

      const context = p.getContext();
      if(context.pregnantTime > this.runningTime) {
        return;
      }

      this.drawParticalItem(seconds, p, context.liveTime === 0);
    });
  }

  /**
   * @ignore
   */
  draw() {
    if(!this.isRunning) { return; }

    if(!this.lastTime) {
      this.lastTime = new Date();
      window.requestAnimationFrame(this.draw);
      return;
    }

    const now = new Date();
    let passedTime = (now.getTime() - this.lastTime.getTime())/1000;
    if(passedTime > 1) {
      // requestAnimationFrame 停止运行，自动补帧
      passedTime = 1/60;
    }
    this.lastTime = now;
    this.runningTime += passedTime;

    this.drawBackground();
    this.drawParticles(passedTime);
    window.requestAnimationFrame(this.draw);
  }
}