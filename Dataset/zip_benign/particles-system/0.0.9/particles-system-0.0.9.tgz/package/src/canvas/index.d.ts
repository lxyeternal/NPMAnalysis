import { BaseBehavior } from "../behavior/base";
import { BasePartical, BaseParticalItem } from '../partical/base';
import { Context, BornArea } from '../utils/type';
interface ParticalsProps {
    el: HTMLCanvasElement;
    backgroundColor?: string;
    partical?: BasePartical;
    particalNum: number;
    bornArea: BornArea;
    pregnantTime: number;
    behaviors: BaseBehavior[];
    showFps?: boolean;
}
interface ComposedFun {
    (context: Context): boolean;
}
export declare class Particals {
    lastTime: Date;
    isRunning: boolean;
    ctx: CanvasRenderingContext2D;
    canvas: HTMLCanvasElement;
    props: ParticalsProps;
    inited: boolean;
    behaviors: BaseBehavior[];
    partical: BasePartical;
    particalNum: number;
    particals: BaseParticalItem[];
    composedInitFunc: ComposedFun;
    composedUpdateFunc: ComposedFun;
    runningTime: number;
    constructor(props: ParticalsProps);
    init(): void;
    initParticles(): Promise<void>;
    reset(): void;
    stop(): void;
    run(): void;
    drawBackground(): void;
    composeFun(behaviors: BaseBehavior[], funcName: string, checkReset: boolean): ComposedFun;
    drawParticalItem(seconds: number, partical: BaseParticalItem, isReset: boolean): void;
    drawParticles(seconds: number): void;
    draw(): void;
}
export {};
