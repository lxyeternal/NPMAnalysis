
import { getRangeNumber } from '../utils';
import { Position, Context } from '../utils/type';

export interface BaseParticalProps {
  ctx: CanvasRenderingContext2D;
  pregnantTime: number;
}

/**
 * BasePartical为粒子渲染的基类
 */
export abstract class BasePartical {
  abstract createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number): BaseParticalItem

  // 开始运行前会执行该函数，默认为立即执行
  // 如果启动前有异步操作可以写在这里
  load() {
    return Promise.resolve();
  }
}

export abstract class BaseParticalItem {
  canvasCtx: CanvasRenderingContext2D;
  context: Context;

  constructor(props: BaseParticalProps) {
    this.canvasCtx = props.ctx;
    this.context = {
      size: 1,
      canvasCtx: this.canvasCtx,
      systemRunTime: 0,
      pregnantTime: props.pregnantTime ? getRangeNumber([0,props.pregnantTime]) : 0,
      visible: false,
      position: {
        x: 0,
        y: 0
      },
      w: 0,
      h: 0,
      initPosition: {
        x: 0,
        y: 0
      },
      liveTime: 0,
      runTime: 0,
      opacity: 1,
      isReset: true
    }
    this.render = this.render.bind(this);
  }

  getContext(): Context {
    return this.context;
  }

  abstract render():void;
}