import { BaseParticalItem, BaseParticalProps, BasePartical } from './base';
import { getRangeNumber, isEmpty, generateRandomInt } from '../utils/index';
import { Color, GradientColorItem } from '../utils/type';

export interface CircleParticalProps {
  color: Color;
  colors: Color[]; 
  radius: [number, number]|number;
  shadowBlur: [number, number]|number;
  shadowColor: string;
}
export interface CircleParticalItemProps extends CircleParticalProps, BaseParticalProps {
}

export class CirclePartical extends BasePartical {
  props: CircleParticalProps

  constructor(props: CircleParticalProps) {
    super();
    this.props = props;
  }

  createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number) {
    let { color, colors } = this.props;
    if(!color && colors) {
      color = colors[generateRandomInt(0, colors.length)];
    } 
    return new CircleParticalItem({...this.props, color, ctx, pregnantTime });
  }
}


export class CircleParticalItem extends BaseParticalItem {
  color: Color;
  radius: number;
  shadowBlur: number;
  shadowColor: string;

  constructor({color, radius, shadowBlur=0, shadowColor, pregnantTime, ctx}: CircleParticalItemProps) {
    super({ctx, pregnantTime});

    this.color = color;
    this.radius = getRangeNumber(radius);
    this.shadowBlur = getRangeNumber(shadowBlur);
    // console.log('this.shadowBlur: ', this.shadowBlur);
    this.shadowColor = shadowColor;
    this.render = this.render.bind(this);
  }

  createColor(x: number, y: number, radius: number, color: Color) {
    if(typeof color === 'string') {
      return color;
    }
    if(typeof Array.isArray(color)) {
      var gredientColor = this.canvasCtx.createRadialGradient(x, y, 0, x, y, radius);
      (color as GradientColorItem[]).forEach((item) => {
        gredientColor.addColorStop(item.offset, item.color);
      });
      return gredientColor;
    }

    throw new Error('Color not support');
  }

  render() {
    const { size, position, opacity } = this.context;
    const { x, y } = position;
    const radius = this.radius * size;
    this.canvasCtx.globalAlpha = isEmpty(opacity) ? 1 : opacity;
    this.canvasCtx.fillStyle = this.createColor(x, y, radius, this.color);
    this.canvasCtx.beginPath();
    this.canvasCtx.arc(x, y, radius, 0, Math.PI * 2);
    this.canvasCtx.closePath();
    this.canvasCtx.fill();
  }
}