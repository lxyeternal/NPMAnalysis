import { Context } from '../utils/type';
export interface BaseParticalProps {
    ctx: CanvasRenderingContext2D;
    pregnantTime: number;
}
export declare abstract class BasePartical {
    abstract createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number): BaseParticalItem;
    load(): Promise<void>;
}
export declare abstract class BaseParticalItem {
    canvasCtx: CanvasRenderingContext2D;
    context: Context;
    constructor(props: BaseParticalProps);
    getContext(): Context;
    abstract render(): void;
}
