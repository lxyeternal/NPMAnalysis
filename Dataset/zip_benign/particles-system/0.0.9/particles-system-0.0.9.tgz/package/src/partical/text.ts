import { BaseParticalItem, BaseParticalProps, BasePartical } from './base';
import { getRangeNumber, generateRandomInt, isEmpty } from '../utils/index';
import { Color, GradientColorItem } from '../utils/type';

enum TextDirection {
  vertical = 'vertical', 
  horizontal = 'horizontal'
}

type Text = string | string[]

export interface TextParticalProps {
  text: Text;
  color: string;
  font: string;
  fontSize: number;
  maxWidth?: number;
  direction: TextDirection;
  lineHeight?: number;
}

export interface TextParticalItemProps extends TextParticalProps, BaseParticalProps {
}

export class TextPartical extends BasePartical {
  props: TextParticalProps

  constructor(props: TextParticalProps) {
    super();
    this.props = props;
  }

  createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number) {
    return new TextParticalItem({...this.props, ctx, pregnantTime });
  }
}


export class TextParticalItem extends BaseParticalItem {
  props: TextParticalProps;
  text: string;
  font: string;
  fontSize: number;

  constructor(props: TextParticalItemProps) {
    super({ctx: props.ctx, pregnantTime: props.pregnantTime});

    this.props = props;
    this.text = this.getText(props.text, props.direction);
    this.fontSize = this.getFontSize(props.font, props.fontSize);
    this.font = this.getFont(props.font, this.fontSize);
    this.render = this.render.bind(this);
  }

  getText(text: Text, direction: TextDirection) {
    let resultText = '';
    if(typeof text === 'string') {
      resultText = text;
    } else if(Array.isArray(text)) {
      const randomIndex = generateRandomInt(0, text.length);
      resultText = text[randomIndex];
    } else {
      throw new Error('Text only support string or string[]');
    }
    return resultText;
  }

  getFontSize(font: string, fontSize: number|[number, number]) {
    if(fontSize) {
      return getRangeNumber(fontSize);
    }
    if(font) {
      const matchResult = font.match(/\d+px/);
      if(matchResult && matchResult[0]) {
        return parseInt(matchResult[0]);
      }
    }
    return 10;
  }

  getFont(font: string, fontSize: number|[number, number]) {
    let finalFont = font || '10px sans-serif';
    if(fontSize) {
      finalFont = finalFont.replace(/\d+px/,`${getRangeNumber(fontSize)}px`);
    }
    return finalFont;
  }

  render() {
    const { position, opacity } = this.context;
    const { x, y } = position;
    const { color, maxWidth } = this.props;

    this.canvasCtx.font = this.font;
    this.canvasCtx.fillStyle = color;

    this.canvasCtx.globalAlpha = isEmpty(opacity) ? 1 : opacity;
    const lineHeight: number = this.props.lineHeight || this.fontSize || 20;
    if(this.props.direction === TextDirection.vertical) {
      let currentY = y;
      let maxW = 0;
      this.text.split('').forEach(textItem => {
        const textW = this.canvasCtx.measureText(textItem).width;
        maxW = textW > maxW ? textW : maxW;
        this.canvasCtx.fillText(textItem, x, currentY);
        currentY += lineHeight;
      })
      this.context.h = currentY - y;
      this.context.w = maxW;
    } else {
      this.canvasCtx.fillText(this.text, x, y, maxWidth);
      const rect = this.canvasCtx.measureText(this.text);
      this.context.w = rect.width;
      this.context.h = lineHeight;
    }
  }
}