import { BaseParticalItem, BaseParticalProps, BasePartical } from './base';
import { isEmpty, generateRandomInt, getRangeNumber } from '../utils/index';
import { Color, GradientColorItem } from '../utils/type';

export interface ImageParticalProps {
  w: number|[number, number];
  h: number|[number, number];
  images: string[];
}

export interface ImageParticalItemProps extends ImageParticalProps, BaseParticalProps {
  imageEls: HTMLImageElement[]
}

export class ImagePartical extends BasePartical {
  props: ImageParticalProps
  imageEls: HTMLImageElement[]
  
  constructor(props: ImageParticalProps) {
    super();
    this.props = props;
  }

  generateImages(images: string[]) {
    return images.map((url) => {
      const image = new Image();
      image.src = url;
      return image;
    })
  }

  async load() {
    if(this.imageEls) return Promise.resolve();

    const promiseList = this.props.images.map((url) => {
      return new Promise<HTMLImageElement>((resolve, reject) => {
        const image = new Image();
        image.src = url;
        image.onload = () => {
          resolve(image);
        }
      })
    });
    this.imageEls = await Promise.all(promiseList);
  }

  createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number) {
    return new ImageParticalItem({...this.props, imageEls: this.imageEls, pregnantTime, ctx });
  }
}


export class ImageParticalItem extends BaseParticalItem {
  props: ImageParticalItemProps;
  image: HTMLImageElement;
  w: number;
  h: number;

  constructor(props: ImageParticalItemProps) {
    super({ctx: props.ctx, pregnantTime: props.pregnantTime});

    this.props = props;

    this.image = props.imageEls[generateRandomInt(0, props.imageEls.length)];
    this.getImageSize();
    this.render = this.render.bind(this);
  }

  getImageSize() {
    const { w, h } = this.props;

    if(!isEmpty(w) && !isEmpty(h)) {
      this.w = getRangeNumber(w);
      this.h = getRangeNumber(h);
      return;
    }
    if(isEmpty(w) && !isEmpty(h)) {
      this.w = getRangeNumber(w);
      this.h = this.image.height / this.image.width * this.w;
      return;
    }
    if(!isEmpty(w) && isEmpty(h)) {
      this.w = getRangeNumber(w);
      this.h = this.image.height / this.image.width * this.w;
      return;
    }

    this.w = this.image.width;
    this.h = this.image.height;
    return;
  }

  render() {
    const { position, size, opacity } = this.context;
    const { x, y } = position;

    const w = this.w * size;
    const h = this.h * size;
    this.canvasCtx.globalAlpha = isEmpty(opacity) ? 1 : opacity;
    this.canvasCtx.drawImage(this.image, x, y, w, h);
  }
}