import { BaseParticalItem, BaseParticalProps, BasePartical } from './base';
import { Color } from '../utils/type';
interface CircleParticalProps {
    color: string;
    radius: [number, number] | number;
    shadowBlur: [number, number] | number;
    shadowColor: string;
}
interface CircleParticalItemProps extends CircleParticalProps, BaseParticalProps {
}
export declare class CirclePartical extends BasePartical {
    props: CircleParticalProps;
    constructor(props: CircleParticalProps);
    createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number): CircleParticalItem;
}
export declare class CircleParticalItem extends BaseParticalItem {
    color: string;
    radius: number;
    shadowBlur: number;
    shadowColor: string;
    constructor({ color, radius, shadowBlur, shadowColor, pregnantTime, ctx }: CircleParticalItemProps);
    createColor(x: number, y: number, radius: number, color: Color): string | CanvasGradient;
    render(): void;
}
export {};
