import { BaseParticalItem, BaseParticalProps, BasePartical } from './base';
interface ImageParticalProps {
    w: number | [number, number];
    h: number | [number, number];
    images: string[];
}
interface ImageParticalItemProps extends ImageParticalProps, BaseParticalProps {
    imageEls: HTMLImageElement[];
}
export declare class ImagePartical extends BasePartical {
    props: ImageParticalProps;
    imageEls: HTMLImageElement[];
    constructor(props: ImageParticalProps);
    generateImages(images: string[]): HTMLImageElement[];
    load(): Promise<void>;
    createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number): ImageParticalItem;
}
export declare class ImageParticalItem extends BaseParticalItem {
    props: ImageParticalItemProps;
    image: HTMLImageElement;
    w: number;
    h: number;
    constructor(props: ImageParticalItemProps);
    getImageSize(): void;
    render(): void;
}
export {};
