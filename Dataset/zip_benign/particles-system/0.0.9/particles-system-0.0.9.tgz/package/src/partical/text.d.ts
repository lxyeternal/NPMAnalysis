import { BaseParticalItem, BaseParticalProps, BasePartical } from './base';
declare enum TextDirection {
    vertical = "vertical",
    horizontal = "horizontal"
}
declare type Text = string | string[];
interface TextParticalProps {
    text: Text;
    color: string;
    font: string;
    fontSize: number;
    maxWidth?: number;
    direction: TextDirection;
    lineHeight?: number;
}
interface TextParticalItemProps extends TextParticalProps, BaseParticalProps {
}
export declare class TextPartical extends BasePartical {
    props: TextParticalProps;
    constructor(props: TextParticalProps);
    createPartical(ctx: CanvasRenderingContext2D, pregnantTime: number): CircleParticalItem;
}
export declare class CircleParticalItem extends BaseParticalItem {
    props: TextParticalProps;
    text: string;
    font: string;
    fontSize: number;
    constructor(props: TextParticalItemProps);
    getText(text: Text, direction: TextDirection): string;
    getFontSize(font: string, fontSize: number | [number, number]): number;
    getFont(font: string, fontSize: number | [number, number]): string;
    render(): void;
}
export {};
