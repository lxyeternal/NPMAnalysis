// import { Particals } from './canvas/index';
// import * as BasePartical from './partical/base';
// import * as CirclePartical from './partical/circle';
// import * as TextPartical from './partical/text';
// import * as ImagePartical from './partical/image';
// import * as BaseBehavior from './behavior/base';
// import * as OpacityBehavior from './behavior/opacity-behavoior';
// import * as LinearPositionBehavior from './behavior/position/linear';
// import * as SinPositionBehavior from './behavior/position/sin';
// import * as SizeDieBehavior from './behavior/life/size';
// import * as BornBehaviorProps from './behavior/life/born';
// import * as BoundaryLifeBehavior from './behavior/life/boundary';
// import * as SizeBehavior from './behavior/size-behavior';

// const mods = {
//   Particals,
//   ...BasePartical,
//   ...CirclePartical,
//   ...TextPartical,
//   ...ImagePartical,
//   ...BaseBehavior,
//   ...OpacityBehavior,
//   ...LinearPositionBehavior,
//   ...SinPositionBehavior,
//   ...SizeDieBehavior,
//   ...BornBehaviorProps,
//   ...BoundaryLifeBehavior,
//   ...SizeBehavior
// }

// export default mods;

export { BaseParticalProps, BasePartical, BaseParticalItem } from './partical/base';

export { Particals, ParticalsProps, ComposedFun } from './canvas/index';

export { CirclePartical, CircleParticalProps, CircleParticalItemProps } from './partical/circle';

export { TextPartical, TextParticalItem, TextParticalProps, TextParticalItemProps }  from './partical/text';

export { ImagePartical, ImageParticalItem, ImageParticalProps, ImageParticalItemProps } from './partical/image';

export { BaseBehavior } from './behavior/base';

export { OpacityBehavior, OpacityBehavoirProps } from './behavior/opacity-behavoior';

export { LinearPositionBehavior, LinearPositionBehaviorProps }  from './behavior/position/linear';

export { SinPositionBehavior, SinPositionBehaviorProps } from './behavior/position/sin';

export { PositionBornBehavior, PositionBornBehaviorProps } from './behavior/life/born';

export { BoundaryLifeBehavior, BoundaryLifeBehaviorProps, BoundaryRange, BoundarySide } from './behavior/life/boundary';

export { LinearSizeBehavoir, LinearSizeBehavoirProps } from './behavior/size-behavior';

export { GradientColorItem, Color, Position, ParticalProperty, PositionProperty, SizeProperty, Context, BornArea } from './utils/type';