export const getRangeNumber = (n: [number, number]|number):number => {

  if(typeof n === 'number') {
    return n;
  }

  if((n as [number, number]).length !== 2) {
    throw new Error('范围类型必须长度为2');
  }
  if(n[0] === n[1]) return n[0];
  return Math.random()*(n[1]-n[0])+n[0];
}

export const generateRandomInt = (start, length) => {
  return Math.floor(Math.random() * length) + start;
}

export const getRangeNumberByCenger = (start: number, end: number, center: number): number => {
  const disLeft = Math.abs(start - center);
  const disRight = Math.abs(end - center);
  let width = 0;
  let left = 0;
  let right = 0;
  if(disRight > disLeft) {
    width = disRight*2;
    left = center - disRight;
    right = end;
  } else {
    width = disLeft*2;
    left = start;
    right = center + disLeft;
  }

  const rangeX = (start - left) / width;
  const rangeW = (end - start) / width;
  const x = Math.random()*rangeW + rangeX;
  const centerlizedX = Math.pow((x-0.5), 3) * 4 + 0.5;


  return centerlizedX*width + left ;
}

export const isEmpty = value => value === null || value === undefined;