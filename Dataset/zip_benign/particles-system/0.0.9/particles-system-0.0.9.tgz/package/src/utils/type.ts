export interface GradientColorItem {
  offset: number;
  color: string;
}

export type Color = GradientColorItem[] | String;
export interface Position {
  /**
   * x
   */
  x?: number;
  /**
   * y
   */
  y?: number;
}

export interface ParticalProperty {
  /**
   * 位置信息
   */
  position: Position;
  /**
   * 粒子缩放比例
   */
  size: number;
  /**
   * 粒子是否显示
   */
  visible: boolean;
}

export interface PositionProperty {

  /**
   * position改变的速度（/s）
   */
  positionSpeed?: number;
  /**
   * 移动方向，0代表向下
   */
  direction?: number;
}

export interface SizeProperty {
  /**
   * size改变的速度，1代表1s增加100%
   */
  sizeSpeed?: number;
}

/**
 * context 包含了粒子的核心上下文数据.
 * 包括生成时间、粒子宽高半径透明度等熟悉
 * 并且可以自由扩展，增加字段
 */
export interface Context extends ParticalProperty, PositionProperty, SizeProperty {
  /**
   * canvas元素的context
   */
  canvasCtx: CanvasRenderingContext2D,
  /**
   * 本次渲染周期距离上次的时间
   */
  seconds?: number,
  /**
   * 粒子系统的总执行时间
   */
  systemRunTime: number;
  /**
   * pregnantTime后粒子的总生存时间（s），粒子重生不会刷新该时间
   */
  liveTime: number;
  /**
   * 从reset起的生存时间
   */
  liveTimeThisCircle?: number;
  /**
   * 粒子出生准备时间，仅第一次有效
   */
  pregnantTime?: number;
  /**
   * 透明度
   */
  opacity?: number;
  /**
   * 粒子宽度
   */
  w?: number;
  /**
   * 粒子高度
   */
  h?: number;
  /**
   * 支持任意扩展
   */
  [key: string]: any;
}

export interface BornArea {
  x: number;
  y: number;
  w: number;
  h: number;
}