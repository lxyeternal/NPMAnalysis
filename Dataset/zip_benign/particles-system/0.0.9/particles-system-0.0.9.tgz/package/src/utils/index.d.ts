export declare const getRangeNumber: (n: [number, number] | number) => number;
export declare const generateRandomInt: (start: any, length: any) => any;
export declare const getRangeNumberByCenger: (start: number, end: number, center: number) => number;
export declare const isEmpty: (value: any) => boolean;
