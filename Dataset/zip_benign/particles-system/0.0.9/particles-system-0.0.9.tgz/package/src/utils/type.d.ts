export interface GradientColorItem {
    offset: number;
    color: string;
}
export declare type Color = GradientColorItem[] | String;
export interface Position {
    x?: number;
    y?: number;
}
export interface ParticalProperty {
    position: Position;
    size: number;
    visible: boolean;
}
export interface PositionProperty {
    positionSpeed?: number;
    direction?: number;
}
export interface SizeProperty {
    sizeSpeed?: number;
}
export interface Context extends ParticalProperty, PositionProperty, SizeProperty {
    seconds?: number;
    systemRunTime: number;
    liveTime: number;
    liveTimeThisCircle?: number;
    pregnantTime?: number;
    isReset?: boolean;
    opacity?: number;
    w?: number;
    h?: number;
    [key: string]: any;
}
export interface BornArea {
    x: number;
    y: number;
    w: number;
    h: number;
}
