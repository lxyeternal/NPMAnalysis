import * as Particals from './namespace';


// const f = () => {
//     // getRangeNumber(1);
//   console.log('hello world!!!!');
// }


window.Particals = Particals;
export default Particals;