import { Context, Position, BornArea } from '../../utils/type';
import { getRangeNumber, getRangeNumberByCenger, isEmpty } from '../../utils/index';
import { BaseBehavior } from '../base';



export interface PositionBornBehaviorProps {
  /**
   * 出生范围，默认会随机分布在出生区域里
   */
  bornArea: BornArea
  /**
   * 聚集中心，设置该值后越靠近该值出生概率越大，即越密集
   */
  denseCenter?: Position
}

/**
 * PositionBornBehavior通过设置参数可以实现出生位置的固定/随机分布
 */
export class PositionBornBehavior extends BaseBehavior {
  props: PositionBornBehaviorProps

  constructor(props: PositionBornBehaviorProps) {
    super();

    this.props = props;
    this.update = this.update.bind(this);
    this.init = this.init.bind(this);
    this.needReset = this.needReset.bind(this);
  }

  init(context: Context) {
    const newPosition = this.getInitPosition();
    context.position = newPosition;
    context.initPosition = { ...newPosition };
    context.size = 1;
  }

  getInitPosition() {
    const { bornArea, denseCenter } = this.props;
    const { x, y, w, h } = bornArea;
    let initX = getRangeNumber([x, x+w]);
    let initY = getRangeNumber([y, y+h]);

    if(denseCenter) {
      if(!isEmpty(denseCenter.x)) {
        initX = getRangeNumberByCenger(x, x+w, denseCenter.x);
      }
      if(!isEmpty(denseCenter.y)) {
        initX = getRangeNumberByCenger(y, y+h, denseCenter.y,)
      }
    }
    return { x: initX, y: initY };
  }

  update(context: Context) {
    return;
  }
}