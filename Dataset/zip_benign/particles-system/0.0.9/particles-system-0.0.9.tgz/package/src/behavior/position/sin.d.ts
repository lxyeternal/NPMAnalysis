import { BaseBehavior } from '../base';
import { Context } from '../../utils/type';
export interface SinPositionBehaviorProps {
    speed: [number, number] | number;
    speedRate: [number, number] | number;
    amplitude: [number, number] | number;
    frequency: [number, number] | number;
}
export declare class SinPositionBehavior extends BaseBehavior {
    props: SinPositionBehaviorProps;
    constructor(p: SinPositionBehaviorProps);
    init(context: Context): void;
    update(context: Context): void;
}
