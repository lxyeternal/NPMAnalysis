import { BaseBehavior } from '../base';
import { getRangeNumber } from '../../utils';
import { Position, Context } from '../../utils/type';

export interface LinearPositionBehaviorProps {
  /**
   * 每秒移动多少, 单位px/s, 传入数组代表范围
   */
  speed: [number, number]|number;
  /**
   * 移动方向多少, 单位degree, 传入数组代表范围
   */
  direction: [number, number]|number;
}

/**
 * LinearPositionBehavior通过设置参数可以实现线性的位置变化
 */
export class LinearPositionBehavior extends BaseBehavior {
  props: LinearPositionBehaviorProps;

  constructor(p: LinearPositionBehaviorProps) {
    super();

    this.props = p;
    this.update = this.update.bind(this);
    this.init = this.init.bind(this);
  }

  init(context: Context) {
    context.positionSpeed = getRangeNumber(this.props.speed);
    context.direction = getRangeNumber(this.props.direction);
  }

  update(context: Context) {
    const distance = context.positionSpeed * context.seconds;
    let { position: { x, y } } = context;
    x += distance * Math.sin(context.direction);
    y += distance * Math.cos(context.direction);
    context.position.x = x;
    context.position.y = y;
  }
}