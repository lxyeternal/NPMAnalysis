import { Context } from '../../utils/type';
import { BaseBehavior } from '../base';
export declare enum Side {
    left = "left",
    top = "top",
    right = "right",
    bottom = "bottom"
}
export interface BoundaryRange {
    min: number;
    max: number;
}
export declare type BoundaryLifeBehaviorProps = {
    [key in Side]: BoundaryRange;
};
export declare class BoundaryLifeBehavior extends BaseBehavior {
    props: BoundaryLifeBehaviorProps;
    constructor(props: BoundaryLifeBehaviorProps);
    isInRange(value: any, range: any): boolean;
    inBoundary(x: number, y: number, w: number, h: number): boolean;
    needReset(context: Context): boolean;
    update(context: Context): void;
}
