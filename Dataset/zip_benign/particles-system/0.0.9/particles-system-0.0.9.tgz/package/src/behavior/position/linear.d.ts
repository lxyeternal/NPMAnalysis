import { BaseBehavior } from '../base';
import { Context } from '../../utils/type';
export interface LinearPositionBehaviorProps {
    speed: [number, number] | number;
    direction: [number, number] | number;
}
export declare class LinearPositionBehavior extends BaseBehavior {
    props: LinearPositionBehaviorProps;
    constructor(p: LinearPositionBehaviorProps);
    init(context: Context): void;
    update(context: Context): void;
}
