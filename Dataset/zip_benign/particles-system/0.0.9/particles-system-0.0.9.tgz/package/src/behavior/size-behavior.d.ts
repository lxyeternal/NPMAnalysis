import { BaseBehavior } from './base';
import { Context } from '../utils/type';
export interface LinearSizeBehavoirProps {
    speed: [number, number] | number;
}
export declare class LinearSizeBehavoir extends BaseBehavior {
    propSpeed: number | [number, number];
    constructor({ speed }: LinearSizeBehavoirProps);
    init(context: Context): void;
    update(context: Context): void;
}
