import { Context, Position, BornArea } from '../../utils/type';
import { BaseBehavior } from '../base';
export interface PositionBornBehaviorProps {
    bornArea: BornArea;
    bornTimeRange: number;
    denseCenter?: Position;
}
export declare class PositionBornBehavior extends BaseBehavior {
    props: PositionBornBehaviorProps;
    constructor(props: PositionBornBehaviorProps);
    init(context: Context): void;
    getInitPosition(): {
        x: number;
        y: number;
    };
    update(context: Context): void;
}
