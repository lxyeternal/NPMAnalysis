import { Context, Position, BornArea } from '../../utils/type';
import { getRangeNumber, getRangeNumberByCenger, isEmpty } from '../../utils/index';
import { BaseBehavior } from '../base';

/**
 * 边界类型
 */
export enum BoundarySide {
  left='left',
  top='top',
  right='right',
  bottom='bottom'
}


/**
 * 边界值范围
 */
export interface BoundaryRange {
  min: number
  max: number
}

export type BoundaryLifeBehaviorProps = {
  [key in BoundarySide]: BoundaryRange
}

/**
 * BoundaryLifeBehavior通过设置参数可以实现边界检测，超出范围就会重生
 * 参数可设置某一/几条边的范围来限制，如 { left: { min: 0, max: 100 } } 代表粒子的左边超出0～100的范围就会重生
 */
export class BoundaryLifeBehavior extends BaseBehavior {
  props: BoundaryLifeBehaviorProps

  constructor(props: BoundaryLifeBehaviorProps) {
    super();

    this.props = props;
    this.update = this.update.bind(this);
    this.needReset = this.needReset.bind(this);

  }

  isInRange(value, range) {
    if(isEmpty(range) || isEmpty(value)) {
      return true;
    }
    if(!isEmpty(range.min) && value < range.min) {
      return false;
    }
    if(!isEmpty(range.max) && value > range.max) {
      return false;
    }
    return true;
  }

  inBoundary(x: number, y: number, w: number, h: number) {
    const { left, right, top, bottom } = this.props;
    
    return this.isInRange(x, left)
    && this.isInRange(x+w, right)
    && this.isInRange(y, top)
    && this.isInRange(y+h, bottom);
  }

  needReset(context: Context) {
    return !this.inBoundary(context.position.x, context.position.y, context.w, context.h);
  }

  update(context: Context) {
    return;
  }
}