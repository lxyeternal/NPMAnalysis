import { BaseBehavior } from './base';
import { getRangeNumber, isEmpty } from '../utils';
import { Context } from '../utils/type';

export interface LinearSizeBehavoirProps {
  /**
   * 每秒变化比例,  传入数组代表范围
   */
  speed: [number, number]|number;
  /**
   * 最小尺寸，size小于该值则会重生，只有设置该值后生效
   */
  minSize?: number
}

/**
 * LinearSizeBehavoir通过设置参数可以实现缩放大小的线性渐变
 * 在size为0时粒子会重生
 */
export class LinearSizeBehavoir extends BaseBehavior {
  propSpeed: number | [number, number]
  minSize: number

  constructor({ speed, minSize } : LinearSizeBehavoirProps) {
    super();

    this.propSpeed = speed;
    this.minSize = minSize;
    this.update = this.update.bind(this);
    this.needReset = this.needReset.bind(this);
    this.init = this.init.bind(this);
  }

  init(context: Context) {
    context.sizeSpeed = getRangeNumber(this.propSpeed);
  }

  needReset(context: Context) {
    if(isEmpty(this.minSize)) {
      return false;
    }
    return context.size <= this.minSize;
  }

  update(context: Context) {
    let { size } = context;
    if(size > 0) {
      size += context.sizeSpeed * context.seconds;
    }
    if(size < 0) {
      size = 0;
    }
    context.size = size;
  }
}