import { BaseBehavior } from '../base';
import { getRangeNumber } from '../../utils';
import { Position, Context } from '../../utils/type';

export interface SinPositionBehaviorProps {
  /**
   * 每秒移动多少, 单位px/s, 传入数组代表范围
   */
  speed: [number, number]|number; 
  /**
   * 加速度
   */
  speedRate: [number, number]|number; 
  /**
   * 振幅
   */
  amplitude: [number, number]|number;
  /**
   * 频率，圈/s
   */
  frequency: [number, number]|number;
}


/**
 * SinPositionBehavior通过设置参数可以实现sin函数形状的位置变化
 */
export class SinPositionBehavior extends BaseBehavior {
  props: SinPositionBehaviorProps;
  constructor(p: SinPositionBehaviorProps) {
    super();

    this.props = p;
    this.update = this.update.bind(this);
    this.init = this.init.bind(this);
  }

  init(context: Context) {
    context.positionSpeed = getRangeNumber(this.props.speed);
    context.positionSpeedRate = this.props.speedRate ? getRangeNumber(this.props.speedRate) : 0;
    context.amplitude = this.props.amplitude ? getRangeNumber(this.props.amplitude) : 0;
    context.frequency = this.props.frequency ? getRangeNumber(this.props.frequency) : 1;
    context.distance = 0;
  }
  
  update(context: Context) {
    context.positionSpeed += context.positionSpeedRate * context.seconds;
    const distance = context.positionSpeed * context.seconds;
    context.distance += distance;
    let { position: { x, y } } = context;
    x = context.initPosition.x + context.amplitude * Math.sin(context.frequency * context.liveTimeThisCircle * Math.PI * 2);
    y -= distance;
    context.position.x = x;
    context.position.y = y;
  }
}