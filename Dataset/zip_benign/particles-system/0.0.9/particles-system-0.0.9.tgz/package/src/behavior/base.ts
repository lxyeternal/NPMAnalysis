import { Position, Context } from "../utils/type";

/**
 * Behavior中间件的基础类，定义了一些基本的生命周期行为。
 * 如果需要自定义中间件可以继承该类，改写相应的方法以实现功能
 */
export class BaseBehavior {
  constructor() {
  }

  /**
   * 当粒子重生时会执行该函数，来进行一些初始化工作
   * 你也可以在这里面往context添加一些自定义属性
   */
  init(context: Context) {
    return;
  }
  /**
   * 是否需要重生
   * @returns 返回true阻断本次渲染循环，进行重生
   */
  needReset(context: Context) {
    return false;
  }

  /**
   * 更新context，
   * 每次更新循环会执行该函数，可以在该函数内执行更新属性
   */
  update(context: Context) {
    return;
  };
}