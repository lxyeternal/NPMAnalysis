import { Context } from "../utils/type";
export declare class BaseBehavior {
    constructor();
    init(context: Context): void;
    needReset(context: Context): boolean;
    update(context: Context): void;
}
