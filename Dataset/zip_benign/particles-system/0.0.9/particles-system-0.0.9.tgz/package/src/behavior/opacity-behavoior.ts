import { BaseBehavior } from './base';
import { getRangeNumber } from '../utils';
import { Context } from '../utils/type';

export interface OpacityBehavoirProps {
  /**
   * 每秒变化比例,  传入数组代表范围
   */
  speed: [number, number]|number;
  /**
   * 延迟几秒后开始透明度变化， 传入数组代表范围
   */
  delay?: [number, number]|number;
}

/**
 * OpacityBehavior通过设置参数可以实现透明度的线性渐变，在透明度为0时粒子会重生
 */
export class OpacityBehavior extends BaseBehavior {
  speed: number | [number, number];
  delay: [number, number]|number;

  constructor({ speed } : OpacityBehavoirProps) {
    super();

    this.speed = speed;

    this.update = this.update.bind(this);
    this.init = this.init.bind(this);
    this.needReset = this.needReset.bind(this);
  }

  init(context: Context) {
    context.opacity = 1;
    context.opacitySpeed = getRangeNumber(this.speed);
    context.opacityDelay = this.delay ? getRangeNumber(this.delay) : 0;
  }

  needReset(context: Context) {
    return context.opacity <= 0;
  }

  update(context: Context) {
    if(context.liveTimeThisCircle >= context.opacityDelay) {
      let { opacity } = context;
      if(opacity > 0) {
        opacity += context.opacitySpeed * context.seconds;
      }
      if(opacity < 0) {
        opacity = 0;
      }
      context.opacity = opacity;
    }
  }
}