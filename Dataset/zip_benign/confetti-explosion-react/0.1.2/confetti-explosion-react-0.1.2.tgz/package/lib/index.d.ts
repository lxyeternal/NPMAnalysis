/// <reference types="react" />
interface IConfetti {
    particleCount?: number;
    duration?: number;
    colors?: string[];
    particleSize?: number;
    force?: number;
    height?: number;
    width?: number;
    floorHeight?: number;
    floorWidth?: number;
}
declare function ConfettiExplosion({ particleCount, duration, colors, particleSize, force, height, width, floorHeight, floorWidth }: IConfetti): JSX.Element;
export default ConfettiExplosion;
