export interface IParticle {
    color: string;
    degree: number;
}
interface IParticlesProps {
    particles: IParticle[];
    duration: number;
    particleSize: number;
    force: number;
    height: number;
    width: number;
}
declare const useStyles: ({ particles, duration, height, width, force, particleSize }: IParticlesProps) => (params: void, styleOverrides?: {
    props: {
        classes?: Record<string, string> | undefined;
    } & Record<string, unknown>;
    ownerState?: Record<string, unknown> | undefined;
} | undefined) => {
    classes: Record<"container" | "particle", string>;
    theme: void;
    css: import("tss-react").Css;
    cx: import("tss-react").Cx;
};
export default useStyles;
