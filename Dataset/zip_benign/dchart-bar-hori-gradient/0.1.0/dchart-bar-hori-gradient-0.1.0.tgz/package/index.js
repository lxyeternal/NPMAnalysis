'use strict';
require('./default.css');
var Bar = require('dchart-bar-multi-hori-gradient');
var d3 = require('d3');
var _ = require('dchart-core/util');

function BarGradient(container, options) {
  var opt = {
    margin: {left: 14, top: 30, right: 16, bottom: 98},
    yaxis: {
      padding: [0.5, 0.6],
      groupPadding: [0, 0],
      dy: 2,
      labelOrient: 'horizontal'
    },
    gradientColors: {
      from: 'rgb(155,255,0)',
      to: 'rgb(255,0,155)',
      orient: 'horizontal',
    },
    background: {}
  };
  _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}

BarGradient = Bar.extend(BarGradient, {
  data: function (data) {
    if (!data) return this._data;
    var opt = this.options;
    var xkey = opt.xaxis.key;
    if (!data[0][xkey].length) {
      data.forEach(function (obj) {
        obj[xkey] = [obj[xkey]];
      });
      this._data = data;
    }
    if (!opt.gradientColors.length) {
      opt.gradientColors = [opt.gradientColors];
    }
  }
});

module.exports = BarGradient;
