dchart-bar-with-bg

符合dchart规范的柱状图

### 安装

```
npm install dchart-bar-with-bg
```

### 用法
```
var Bar = require('dchart-bar-with-bg');
var bar = new Bar(container, {
    margin: {left:14, top:30, right: 16, bottom: 98},
    yaxis : {
      padding: [0.5, 0.6],
      groupPadding: [0, 0],
      dy : 2
    },
    bg : {
      texture : {              //纹理默认是null，可以不配
        orient : "horizontal"  //纹理方向，默认是水平
        stroke : "rgb(245, 245, 245)" //纹理颜色
        size : 10,             //纹理重复大小
        strokeWidth : 5,       //纹理条形粗细
      }
    }
});
bar.render([
        {"x": "山东", "y": 100},
        {"x": "山西", "y": 52},
        {"x": "河北", "y": 49}
      ]);
```
