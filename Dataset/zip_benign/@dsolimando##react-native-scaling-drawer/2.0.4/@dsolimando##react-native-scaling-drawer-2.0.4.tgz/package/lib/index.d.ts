import { Component, ReactElement } from 'react';
import { Animated, ViewStyle } from 'react-native';
interface IProps {
    scalingFactor?: number;
    minimizeFactor?: number;
    swipeOffset?: number;
    contentWrapperStyle?: ViewStyle;
    frontStyle?: ViewStyle;
    containerStyle?: ViewStyle;
    content: ReactElement;
    onClose?: () => void;
    onOpen?: () => void;
    duration?: number;
}
interface IState {
    isOpen: boolean;
}
export default class SwipeAbleDrawer extends Component<IProps, IState> {
    static defaultProps: {
        scalingFactor: number;
        minimizeFactor: number;
        swipeOffset: number;
        duration: number;
    };
    private isBlockDrawer;
    private translateX;
    private scale;
    private maxTranslateXValue;
    private drawerAnimation;
    private panResponder;
    private frontRef;
    constructor(props: any);
    componentWillMount(): void;
    blockSwipeAbleDrawer: (isBlock: any) => void;
    _onStartShouldSetPanResponder: () => boolean;
    _onMoveShouldSetPanResponder: (e: any, { dx, dy, moveX }: {
        dx: any;
        dy: any;
        moveX: any;
    }) => boolean;
    _onPanResponderMove: (e: any, { dx }: {
        dx: any;
    }) => boolean;
    _onPanResponderRelease: (e: any, { dx }: {
        dx: any;
    }) => boolean;
    onDrawerAnimation(): void;
    animationInterpolate(): {
        translateX: Animated.AnimatedInterpolation;
        scale: Animated.AnimatedInterpolation;
    };
    close: () => void;
    open: () => void;
    render(): JSX.Element;
}
export {};
