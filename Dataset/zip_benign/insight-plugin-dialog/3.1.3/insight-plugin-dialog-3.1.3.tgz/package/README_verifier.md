# insight-plugin-dialog

> 表单验证插件

## Build Setup

``` bash
# 安装表单验证插件
npm install insight-plugin-verifier --save-dev
 
使用:
import * as ver from "insight-plugin-verifier";
 
var verifier = new ver.Verifier();
//非空验证
var  result = verifier.empty(value);
//邮箱验证
var  result = verifier.email(value);
 
方法： 
verifier.empty(value);
    非空验证； value：需要验证内容
verifier.email(value);
    邮箱格式验证； value：需要验证内容
 verifier.phone(value);
    手机格式验证； value：需要验证内容
verifier.credit(value);
    身份证格式验证； value：需要验证内容
 verifier.account(value,area);
    数字或字母验证； 
    value：需要验证内容
    area:  0:字母或者数字均可(默认);只能输入数字;2:只能输入字母;  （选传）
 verifier.length(value,leng);
    长度验证； 
    value：需要验证内容;
    leng:  长度区间数组（选传）; 如需限制长度为2-5个字符，则leng传入：[2,5];
 verifier.content(value,forbid,replace);
    内容验证； 
    value：需要验证内容;
    forbid:  违禁词数组;如["垃圾","sb"]。不传值则不验证违禁词;（选传）
    replace: 把违禁词替换的词语;（选传）
 
 
 
 返回信息(对象):
| 参数  | 内容  |   
| code  | 0:验证成功;10010：验证失败  |   
|  msg |  返回的验证结果信息  |   
|  content |  替换内容返回结果  |  


```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
