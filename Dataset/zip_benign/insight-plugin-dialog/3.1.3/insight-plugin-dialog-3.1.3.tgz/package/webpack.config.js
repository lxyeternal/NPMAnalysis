const path = require("path");
const uglify = require('uglifyjs-webpack-plugin');
const extractTextPlugin = require("extract-text-webpack-plugin");
const webpack = require('webpack');

module.exports = {
// mode: 'development',//开发模式development或发布模式production
mode: 'production',
// devtool: 'eval-source-map',
//入口文件的配置项
entry: {
  index: "./js/index.js",  //webpack主入口
  dialog:'./js/dialog.ts' //弹窗组件dialog.ts
  // verifier:'./js/verifier.ts' //弹窗组件verifier.ts
  
},
//出口文件的配置项
output: {
  // 组件名称，为空时即能直接调用类名
  library : '', 
  // 组件采用UMD格式打包
  libraryTarget: 'umd',
  //输出的路径，public为文件夹名
  path: path.resolve(__dirname, "dist/js"),
  //输出的文件名称[name]的意思是根据入口文件的名称，打包成相同的名称，有几个入口文件，就可以打包出几个文件。
  filename: "[name].js"
},
//模块：例如解读CSS,图片如何转换，压缩
module: {
rules:[
  {
    test: /\.(jsx|js)$/,
    exclude: /node_modules/, 
    loader: "babel-loader"
  },
  {
    test: /\.tsx?$/,
    use: {
      loader: 'ts-loader'
    }
  },
  {
    test: /\.css$/,
    use: extractTextPlugin.extract({
      fallback: "style-loader",
      use: [
        {loader: "css-loader",options:{importLoaders:1,minimize: true}},
        {loader:'postcss-loader'} 
      ]
    })
  },
  {
    test: /\.(sass|scss)$/,
    use: extractTextPlugin.extract({
      use: [{
          loader: "css-loader",options:{minimize: true}
        },
        {
          loader: "sass-loader",options:{minimize: true}
        },
        {loader:'postcss-loader'} 
      ],
      fallback: "style-loader"
    })
  },
  {
    test: /\.(png|jsp|gif)/,
    use: [
      {
        loader: "url-loader",
        options: {  
          limit: 20, 
          name:"../img/[hash:8].[ext]"
        }
      }
    ]
  }
]
},  
//插件，用于生产模版和各项功能
plugins: [
  new uglify(),
  new extractTextPlugin('../css/common.css'),
  new webpack.BannerPlugin({
    banner: '#Insight-plugin  @author:Rzcccccc @update:2019.01.28 @version:v2.17', 
  })
],
// optimization: {
//   splitChunks: {
//       cacheGroups: {
//           bb: {
//               name: "bb",
//               chunks: "all",
//               minChunks: 1
//           }
//       }
//   }
// },
//配置webpack开发服务功能
devServer: {
  // contentBase: path.resolve(__dirname,"dist"),//监听目录
  // host: "localhost",
  // compress: true,
  // historyApiFallback: true,//不跳转
  // inline: true,//实时刷新
  // port: 3030 //端口号
}
};