# insight-plugin-dialog

> 高灵活度弹窗插件

## Build Setup

``` bash
# 安装弹窗插件
npm install insight-plugin-dialog --save-dev

使用:
import * as dia from "insight-plugin-dialog";

new dia.Dialog({
  opacity:0.5, //蒙层透明度：0-1; 默认：1;
  width:598, //宽度，单位：px; 元素高宽度; 默认：500;
  height:338, //高度，单位：px; 元素高度; 默认：500;
  touchClose:true, //点击空白区域关闭弹窗; 默认：false;
  closeBtn:true, //开启关闭按钮; 默认：false;
});


# 属性： 
 el: string;
	弹窗id名称（唯一）；默认：dialog;
 width: number;
	宽度，单位：px; 元素高宽度;  默认：500;
 height: number;
	 高度，单位：px; 元素高度;  默认：500;
 opacity: number;
	 蒙层透明度：0-1;  默认：1;
 touchClose: boolean;
	 点击空白区域关闭弹窗;  默认：false;
 closeBtn: boolean;
	 开启关闭按钮;  默认：false;
 closeEle: string;
	 关闭按钮类名; 默认：dialog-close-btn; 


# 方法： 
 showDialog();
	显示弹窗
 hideDialog();
	关闭弹窗


```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
