"use strict";

function Watermark(setting) {
  //默认设置
  this.defaultSettings = Object.assign({
    el: document.body,
    //水印载体 默认Body
    marktype: 1,
    //水印类型 1-文字 2-图片 
    txt: "水印默认样式展示",
    //水印文字
    type: 'tile',
    //水印类型 单个-single 平铺-tile
    x: '50%',
    //单个水印x轴坐标
    y: "50%",
    //单个水印Y轴坐标
    start_x: 10,
    //水印起始位置x轴坐标
    start_y: 10,
    //水印起始位置Y轴坐标
    rows: 100,
    //水印行数
    cols: 100,
    //水印列数
    x_space: 70,
    //水印x轴间隔
    y_space: 70,
    //水印y轴间隔
    color: '#000',
    //水印字体颜色
    alpha: 0.1,
    //水印透明度
    fontsize: 20,
    //水印字体大小
    fontweight: 400,
    //水印字体字重
    fontstyle: 'nomal',
    //水印字体倾斜
    font: '微软雅黑',
    //水印字体
    angle: -17,
    //水印倾斜度数
    src: "",
    //图片水印src  
    scale: 1,
    //水印图片缩放  
    hidden: 1,
    //隐形水印 1开启 2关闭
    hidden_text: '版权所有 盗版必究',
    //隐形水印文字 
    monitor: false //是否开启监听

  }, setting);
  this.initOption();
} //初始化


Watermark.prototype.initOption = function () {
  this.parTemp = this.defaultSettings.el ? this.defaultSettings.el : document.body;
  var hard_shell = document.getElementById('watermark_hard_shell');
  hard_shell && hard_shell.parentNode && hard_shell.parentNode.removeChild(hard_shell);
  this.oDiv = document.createElement('div');
  this.oDiv.id = 'watermark_hard_shell';
  this.oDiv.setAttribute('style', 'pointer-events: none !important; display: block !important');
  this.parTemp.appendChild(this.oDiv); //是否开启隐形水印

  if (this.defaultSettings.hidden === 1) {
    this.InvisibleWatermark();
  }

  if (this.defaultSettings.hidden === 2) {
    this.defaultSettings.el.style.background = 'none';
  } //获取宽高


  this.getWidthHeight();
}; //文字水印


Watermark.prototype.TextWatermark = function () {
  var ol = this.defaultSettings; //单个水印

  if (ol.type === 'single') {
    var mask_div = document.createElement('div');
    var mask_span = document.createElement('span'); //设置div样式

    mask_div.className = 'mask_div00';
    mask_div.style.display = 'flex';
    mask_div.style.alignItems = 'center';
    mask_div.style.justifyContent = 'center';
    mask_div.style.position = "absolute";
    mask_div.style.width = ol.originW + 'px';
    mask_div.style.height = ol.originH + 'px';

    if (String(ol.x).includes('%')) {
      mask_div.style.left = ol.x;
    } else {
      mask_div.style.left = ol.x + 'px';
    }

    if (String(ol.y).includes('%')) {
      mask_div.style.top = ol.y;
    } else {
      mask_div.style.top = ol.y + 'px';
    }

    mask_div.style.opacity = ol.alpha;
    mask_div.style.webkitTransform = "translate(-50%, -50%)";
    mask_div.style.MozTransform = "translate(-50%, -50%)";
    mask_div.style.msTransform = "translate(-50%, -50%)";
    mask_div.style.OTransform = "translate(-50%, -50%)";
    mask_div.style.transform = "translate(-50%, -50%)";
    mask_div.style.zIndex = "999";
    mask_div.style.pointerEvents = 'none'; //pointer-events:none  让水印不遮挡页面的点击事件
    //设置span样式

    mask_span.appendChild(document.createTextNode(ol.txt));
    mask_span.style.visibility = "visible";
    mask_span.style.whiteSpace = "nowrap";
    mask_span.style.pointerEvents = 'none'; //pointer-events:none  让水印不遮挡页面的点击事件

    mask_span.style.fontSize = ol.fontsize + 'px';
    mask_span.style.lineHeight = ol.fontsize + 'px';
    mask_span.style.fontWeight = ol.fontweight;
    mask_span.style.fontStyle = ol.fontstyle;
    mask_span.style.fontFamily = ol.font;
    mask_span.style.color = ol.color;
    mask_span.style.textAlign = "center";
    mask_span.style.webkitTransform = "rotate(" + ol.angle + "deg)";
    mask_span.style.MozTransform = "rotate(" + ol.angle + "deg)";
    mask_span.style.msTransform = "rotate(" + ol.angle + "deg)";
    mask_span.style.OTransform = "rotate(" + ol.angle + "deg)";
    mask_span.style.transform = "rotate(" + ol.angle + "deg)";
    mask_span.style.display = "block";
    mask_div.appendChild(mask_span);
    this.oDiv.appendChild(mask_div);
  } //平铺水印


  if (ol.type === 'tile') {
    var x;
    var y;

    for (var i = 0; i < ol.rows; i++) {
      y = ol.start_y + (ol.y_space + ol.originH) * i;

      for (var j = 0; j < ol.cols; j++) {
        x = ol.start_x + (ol.originW + ol.x_space) * j;
        var mask_div = document.createElement('div');
        var mask_span = document.createElement('span');
        mask_div.id = 'mask_div' + i + j;
        mask_div.style.display = 'flex';
        mask_div.style.alignItems = 'center';
        mask_div.style.justifyContent = 'center';
        mask_span.appendChild(document.createTextNode(ol.txt)); //设置水印div倾斜显示

        mask_span.style.webkitTransform = "rotate(" + ol.angle + "deg)";
        mask_span.style.MozTransform = "rotate(" + ol.angle + "deg)";
        mask_span.style.msTransform = "rotate(" + ol.angle + "deg)";
        mask_span.style.OTransform = "rotate(" + ol.angle + "deg)";
        mask_span.style.transform = "rotate(" + ol.angle + "deg)";
        mask_span.style.transformOrigin = "center";
        mask_span.style.visibility = "visible";
        mask_span.style.whiteSpace = "nowrap";
        mask_div.style.position = "absolute";
        mask_div.style.width = ol.originW + 'px';
        mask_div.style.height = ol.originH + 'px';
        mask_div.style.left = x + 'px';
        mask_div.style.top = y + 'px';
        mask_div.style.zIndex = "999";
        mask_div.style.pointerEvents = 'none'; //pointer-events:none  让水印不遮挡页面的点击事件

        mask_span.style.opacity = ol.alpha;
        mask_span.style.fontSize = ol.fontsize + 'px';
        mask_span.style.lineHeight = ol.fontsize + 'px';
        mask_span.style.fontWeight = ol.fontweight;
        mask_span.style.fontStyle = ol.fontstyle;
        mask_span.style.fontFamily = ol.font;
        mask_span.style.color = ol.color;
        mask_span.style.textAlign = "center";
        mask_span.style.display = "inline-block";
        mask_div.appendChild(mask_span);
        this.oDiv.appendChild(mask_div);
      }
    }
  }

  if (ol.monitor) {
    this.DomMonitor(this.parTemp);
    this.DomMonitor(this.oDiv);
  }
}; //图片水印


Watermark.prototype.PictureWatermark = function () {
  var ol = this.defaultSettings; //单个水印

  if (ol.type === 'single') {
    var mask_div = document.createElement('div');
    var mask_img = document.createElement('img'); //设置div样式

    mask_div.className = 'mask_div00';
    mask_div.style.display = 'flex';
    mask_div.style.alignItems = 'center';
    mask_div.style.justifyContent = 'center';
    mask_div.style.position = "absolute";
    mask_div.style.width = ol.originW * ol.scale + 'px';
    mask_div.style.height = ol.originH * ol.scale + 'px';

    if (String(ol.x).includes('%')) {
      mask_div.style.left = ol.x;
    } else {
      mask_div.style.left = ol.x + 'px';
    }

    if (String(ol.y).includes('%')) {
      mask_div.style.top = ol.y;
    } else {
      mask_div.style.top = ol.y + 'px';
    }

    mask_div.style.zIndex = "999";
    mask_div.style.pointerEvents = 'none'; //pointer-events:none  让水印不遮挡页面的点击事件

    mask_div.style.opacity = ol.alpha;
    mask_div.style.webkitTransform = "translate(-50%, -50%)";
    mask_div.style.MozTransform = "translate(-50%, -50%)";
    mask_div.style.msTransform = "translate(-50%, -50%)";
    mask_div.style.OTransform = "translate(-50%, -50%)";
    mask_div.style.transform = "translate(-50%, -50%)"; //设置img样式

    mask_img.src = ol.src;
    mask_img.style.display = "block";
    mask_img.style.webkitTransform = "rotate(" + ol.angle + "deg)";
    mask_img.style.MozTransform = "rotate(" + ol.angle + "deg)";
    mask_img.style.msTransform = "rotate(" + ol.angle + "deg)";
    mask_img.style.OTransform = "rotate(" + ol.angle + "deg)";
    mask_img.style.transform = "rotate(" + ol.angle + "deg)";
    mask_img.style.transformOrigin = "center";
    mask_img.style.width = ol.width * ol.scale + 'px';
    mask_img.style.height = ol.height * ol.scale + 'px';
    mask_div.appendChild(mask_img);
    this.oDiv.appendChild(mask_div);
  } //平铺水印


  if (ol.type === 'tile') {
    var x;
    var y;

    for (var i = 0; i < ol.rows; i++) {
      y = ol.start_y + (ol.y_space + ol.originH * ol.scale) * i;

      for (var j = 0; j < ol.cols; j++) {
        x = ol.start_x + (ol.originW * ol.scale + ol.x_space) * j;
        var mask_div = document.createElement('div');
        var mask_img = document.createElement('img'); //设置div样式

        mask_div.className = 'mask_div' + i + j;
        mask_div.style.display = 'flex';
        mask_div.style.alignItems = 'center';
        mask_div.style.justifyContent = 'center';
        mask_div.style.position = "absolute";
        mask_div.style.width = ol.originW * ol.scale + 'px';
        mask_div.style.height = ol.originH * ol.scale + 'px';
        mask_div.style.left = x + 'px';
        mask_div.style.top = y + 'px';
        mask_div.style.zIndex = "999";
        mask_div.style.pointerEvents = 'none'; //pointer-events:none  让水印不遮挡页面的点击事件

        mask_div.style.opacity = ol.alpha; //设置img样式

        mask_img.src = ol.src;
        mask_img.style.display = "block";
        mask_img.style.webkitTransform = "rotate(" + ol.angle + "deg)";
        mask_img.style.MozTransform = "rotate(" + ol.angle + "deg)";
        mask_img.style.msTransform = "rotate(" + ol.angle + "deg)";
        mask_img.style.OTransform = "rotate(" + ol.angle + "deg)";
        mask_img.style.transform = "rotate(" + ol.angle + "deg)";
        mask_img.style.transformOrigin = "center";
        mask_img.style.width = ol.width * ol.scale + 'px';
        mask_img.style.height = ol.height * ol.scale + 'px';
        mask_div.appendChild(mask_img);
        this.oDiv.appendChild(mask_div);
      }
    }
  }

  if (ol.monitor) {
    this.DomMonitor(this.parTemp);
    this.DomMonitor(this.oDiv);
  }
}; //隐形水印


Watermark.prototype.InvisibleWatermark = function () {
  if (this.parTemp.style.background) {
    return false;
  }

  var mask_span = document.createElement('span');
  mask_span.appendChild(document.createTextNode(this.defaultSettings.hidden_text));
  mask_span.id = "text";
  mask_span.style.fontSize = 12 + 'px';
  mask_span.style.lineHeight = 12 + 'px';
  document.body.appendChild(mask_span);
  var width = document.getElementById('text').offsetWidth + 20;
  var height = document.getElementById('text').offsetHeight + 20;
  document.body.removeChild(mask_span);
  var svgStr = "<svg width=\"".concat(width, "\" height=\"").concat(height, "\" xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\"><text x=\"50%\" y=\"50%\" text-anchor=\"middle\" fill=\"rgba(127,127,127,.1)\" style=\"opacity:.1;font-family:-apple-system,system-ui,BlinkMacSystemFont,Helvetica Neue,PingFang SC,Hiragino Sans GB,Microsoft YaHei,Arial,sans-serif;font-size:12px;font-weight:400;\">").concat(this.defaultSettings.hidden_text, "</text></svg>");
  var base64Url = "data:image/svg+xml;base64,".concat(window.btoa(unescape(encodeURIComponent(svgStr))));
  this.parTemp.style.background = 'URL(' + base64Url + ')';
}; //获取宽高


Watermark.prototype.getWidthHeight = function () {
  var _this = this;

  var ol = this.defaultSettings; //文字

  if (ol.marktype === 1) {
    //创建文字demo 获取宽高
    var mask_span = document.createElement('span');
    mask_span.appendChild(document.createTextNode(ol.txt));
    mask_span.id = "mask_span_demo";
    mask_span.style.fontSize = ol.fontsize + 'px';
    mask_span.style.lineHeight = ol.fontsize + 'px';
    document.body.appendChild(mask_span);
    ol.width = document.getElementById('mask_span_demo').offsetWidth;
    ol.height = document.getElementById('mask_span_demo').offsetHeight;
    document.body.removeChild(mask_span);
    this.CalculateRC();
  } //图片


  if (ol.marktype === 2) {
    this._getImageOriginSize(ol.src).then(function (_ref) {
      var width = _ref.width,
          height = _ref.height;
      ol.width = width;
      ol.height = height;

      _this.CalculateRC();
    });
  }
}; //重新计算行列数


Watermark.prototype.CalculateRC = function () {
  var ol = this.defaultSettings;
  var parTemp = this.parTemp; //获取页面最大宽度

  var page_width = Math.max(parTemp.scrollWidth, parTemp.clientWidth); //获取页面最大高度

  var page_height = Math.max(parTemp.scrollHeight, parTemp.clientHeight);
  ol.originW = ol.width;
  ol.originH = ol.height;
  var angle = Math.abs(ol.angle);

  if (angle > 0) {
    ol.originW = ol.height * Math.sin(angle * Math.PI / 180.0) + ol.width * Math.cos(angle * Math.PI / 180.0);
    ol.originH = ol.height * Math.cos(angle * Math.PI / 180.0) + ol.width * Math.sin(angle * Math.PI / 180.0);
  } //计算水印列数


  if (ol.cols == 0 || parseInt((ol.originW + ol.x_space) * ol.cols) > page_width) {
    ol.cols = Math.ceil(page_width / (ol.originW + ol.x_space)) - 0;
  } //计算水印行数


  if (ol.rows == 0 || parseInt((ol.originH + ol.y_space) * ol.rows) > page_height) {
    ol.rows = Math.ceil(page_height / (ol.originH + ol.y_space)) - 0;
  } //文字


  if (this.defaultSettings.marktype === 1) {
    this.TextWatermark();
  } //图片


  if (this.defaultSettings.marktype === 2) {
    this.PictureWatermark();
  }
}; //获取图片宽高


Watermark.prototype._getImageOriginSize = function (src) {
  return new Promise(function (resolve) {
    var image = new Image();
    image.src = src;

    image.onload = function () {
      var width = image.width,
          height = image.height;
      resolve({
        width: width,
        height: height
      });
    };
  });
}; //dom监听


Watermark.prototype.DomMonitor = function (el) {
  var options = {
    'childList': true,
    'attributes': true,
    'subtree': true
  };
  var self = this;

  var callback = function callback(records) {
    //参考watermark-dom
    if (self.defaultSettings && records.length === 1 || records.length === 1 && records[0].removedNodes.length >= 1) {
      self.initOption();
    }
  };

  var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
  var observer = new MutationObserver(callback);
  observer.observe(el, options);
};

module.exports = Watermark;