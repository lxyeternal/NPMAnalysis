const path = require('path');
const TerserPlugin = require('terser-webpack-plugin');

module.exports = {
  mode:"production",
  entry:"./src/index.js",
  output:{
      path:path.resolve(__dirname,"dist"),
      filename:"index.js",
      library:"Watermark",// Watermark
      libraryTarget:"umd",
      umdNamedDefine: true
  },
  optimization: {
    minimize: true,
    minimizer: [new TerserPlugin()]
  }
};
