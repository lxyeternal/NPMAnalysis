/**
 * @name colorByName
 * @description List of commonly used color
 */
declare const _colorByName: {
    [key: string]: string;
};
export default _colorByName;
