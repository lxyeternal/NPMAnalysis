/**
 * @name colorToRGBA
 * @param color `string` The valid color to convert to rgba (e.g red or #ff0000)
 * @param alpha `Number` The opacity of the generated rgba (default 1)
 * @returns `String` Returns rgba with the alpha set to the specified value
 */
declare const colorToRGBA: (color: string, alpha: number) => string;
export default colorToRGBA;
