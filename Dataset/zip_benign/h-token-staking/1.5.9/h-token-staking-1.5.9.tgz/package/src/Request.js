let axios = require("axios")
let qs = require("qs")
class Request {

    constructor(url = "") {
        this.headers = {}
        this.url = url
    }
    setHead(headers) {
        this.headers = headers
    }

    get({ url,params,cancelToken }){
        return this.http({
            url,
            params: params ? params : {},
            method:'GET',
            headers:{
                "Accept-Version": "Latest",
            },
        },cancelToken)
    }

    post({ url,params }){
        return this.http({
            url,
            params: params ? params : {},
            method:'POST'
        })
    }

    put({ url,params }){
        return this.http({
            url,
            params: params ? params : {},
            method:'PUT'
        })
    }

    delete({ url,params }){
        return this.http({
            url,
            params: params ? params : {},
            method:'DELETE'
        })
    }

    postJson({ url,params }){
        return this.http({
            url,
            params: params ? params : {},
            method:'POST',
            headers:{
                "Content-Type": "application/json"
            },
            isJson:true
        })
    }

    http({ url, headers, params, method, isJson }) {
      const qsParams = method.toUpperCase() === "POST" ? isJson ? JSON.stringify(params) : qs.stringify(params) : params;
      
      headers = {
        ...headers,
        ...this.headers,
        "dex-source":"WEB",
      }
      
      return new Promise((resolve, reject) => {
        // 支持uni-app
        try{
            uni.request({
                url:this.url + url,
                method,
                sslVerify: false,
                data:params,
                header: {
                    ...headers,
                    "dex-source":"APP",
                    "Content-Type": isJson ? "application/json" : "application/x-www-form-urlencoded"
                },
                success: ({ data }) => {
                    resolve(data)
                },
                fail: (error) => {
                    console.log(error)
                    reject(error)
                }
            })
        }catch(err){
            axios(method.toUpperCase() === "POST" ? {
                    url:this.url + url,
                    headers,
                    data: qsParams,
                    method: method || "post"
                } : {
                    url:this.url + url,
                    headers,
                    params: qsParams,
                    method: method || "post"
                }
            ).then(({ data }) => { resolve(data); }).catch(err => {
                reject(err);
            });
        }
      });
    };
}

module.exports = Request