let Interact = require("./Interact")
let { abi,bytecode } = require("./abi/BatchV2.json")
let ERC20 = require("./ERC20")
let ERC721 = require("./ERC721")
let ERC1155 = require("./ERC1155")

class Batch extends Interact {

    constructor({ provider, account, rpcUrl, privateKey, contract }) {
        super({ provider, account, rpcUrl, privateKey, contract, abi })
        this.maxVal = "999000000000000000000000000000000000000000000000000"
        this.mainToken = "0x0000000000000000000000000000000000000000"
    }

    async deploy() {
        try {
            let from = this.web3.eth.defaultAccount
            let gasPrice = await this.GasPrice()
            let result = await this.SC.deploy({
                data: bytecode,
                arguments: []
            }).send({ from, gasPrice });
            return result
        } catch (err) {
            console.log(err)
        }
    }

    async balanceCheck(type,token,amount,tokenId = "") {
        try{
            let result = false
            let from  = this.web3.eth.defaultAccount
            let balance = 0
            let realAmount = amount
            switch(type) {
                case "ERC20":
                    let E20 = new ERC20({ ...this.network,contract:token })
                    balance = await E20.balanceOf(from)
                    realAmount = await E20.toAmount(amount)
                    result = parseInt(balance) >= parseInt(realAmount)
                break;
                case "ERC721":
                    let E721 = new ERC721({ ...this.network,contract:token })
                    result = await E721.isOwner(tokenId,from)
                break;
                case "ERC1155":
                    let E1155 = new ERC1155({ ...this.network,contract:token })
                    balance = await E1155.balanceOf(from,tokenId)
                    result = parseInt(balance) >= parseInt(amount)
                break;
            }
            return {
                type,token,amount,tokenId,
                balance,
                enough:result,
                realAmount
            }
        }catch(err){
            console.log(err)
            return false
        }
    }

    async approveCheck(type,token,target,amount) {
        try{
            let result = false
            let from  = this.web3.eth.defaultAccount
            switch(type) {
                case "ERC20":
                    let E20 = new ERC20({ ...this.network,contract:token })
                    result = await E20.isApprove(target,amount)
                break;
                case "ERC721":
                    let E721 = new ERC721({ ...this.network,contract:token })
                    result = await E721.isApprove(from,target)
                break;
                case "ERC1155":
                    let E1155 = new ERC1155({ ...this.network,contract:token })
                    result = await E1155.isApprove(from,target)
                break;
            }
            return {
                type,token,target,amount,approved:result
            }
        }catch(err){
            console.log(err)
            return false
        }
    }

    async tokenApprove(type,token,target) {
        try{
            let result = false
            switch(type) {
                case "ERC20":
                    let E20 = new ERC20({ ...this.network,contract:token })
                    result = await E20.approve(target,this.maxVal)
                break;
                case "ERC721":
                    let E721 = new ERC721({ ...this.network,contract:token })
                    result = await E721.approve(target,true)
                break;
                case "ERC1155":
                    let E1155 = new ERC1155({ ...this.network,contract:token })
                    result = await E1155.approve(target,true)
                break;
            }
            return result
        }catch(err){
            console.log(err)
            return false
        }
    }

    async paramCheck(list) {
        let result = []
        for(let i = 0; i < list.length; i++) {
            let { id,type,token,tokenId,amount,data,recipient } = list[i]
            let enough = await this.balanceCheck(type,token,amount,tokenId)
            let approved = await this.approveCheck(type,token,this.contract,amount)
            if(enough && approved) {
                result.push({ ...enough,...approved,id,data,recipient })
            }else if(enough && !approved) {
                result.push({ 
                    id,data,recipient,
                    ...enough,
                    approved:false,
                    target:this.contract
                })
            }else if(!enough && approved) {
                result.push({ 
                    id,data,recipient,tokenId,
                    balance:0,enough:false,realAmount:0,
                    ...approved
                })
            }else{
                result.push({ 
                    id,data,recipient,
                    type,token,amount,tokenId,balance:0,enough:false,realAmount:0,
                    approved:false,target:this.contract
                })
            }

            if(enough && !enough.enough) {
                console.error(`${type} ${token} 余额不足,请确保钱包中金额足够`)
            }else if(!enough) {
                console.error(`${type} ${token} 余额获取失败`)
            }
            if(approved && !approved.approved) {
                console.error(`${type} ${token} 未经授权,请调用tokenApprove(合约类型,合约地址,批量合约地址)`)
            }else if(!approved) {
                console.error(`${type} ${token} 授权查询失败`)
            }
        }
        return result
    }

    /**   
     * params: [
     *     {
     *         id:"标识",
     *         type:"代币类型",
     *         token:"代币数量",
     *         tokenId:"NFT tokenId",
     *         amount:"代币数量",
     *         data:"可选",
     *         recipient:"接收地址"
     *     }
     * ]
    */
    typeFormat(type) {
        let result = 20
        switch(type) {
            case "ERC20":
                result = 20
            break;
            case "ERC721":
                result = 721
            break;
            case "ERC1155":
                result = 1155
            break;
        }
        return result
    }

    async tokenBatch(list) {
        try{
            let resultCheck = await this.paramCheck(list)
            console.log(resultCheck)
            let pass = resultCheck.some(item => {
                return !item.approved || !item.enough
            })
            if(!pass){
                let param = [[],[],[],[],[],[],[]]
                for(let i = 0; i < resultCheck.length; i++) {
                    let { id,type,token,tokenId,data,recipient,realAmount } = resultCheck[i]
                    type = this.typeFormat(type)
                    param[0].push(id)
                    param[1].push(type)
                    param[2].push(token ? token : this.mainToken)
                    param[3].push(tokenId ? tokenId : 0)
                    param[4].push(realAmount)
                    param[5].push(data ? data : "0x0")
                    param[6].push(recipient)
                }
                console.log(param)
                let parmas = await this.buildTx("allToken", param)
                let result = parmas && await this.broadTx(parmas)
                return result
            }else {
                return false
            }
        }catch(err){
            console.log(err)
            return false
        }
    }

}


module.exports = Batch