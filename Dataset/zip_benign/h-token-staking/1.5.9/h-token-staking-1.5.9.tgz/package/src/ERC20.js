let Interact = require("./Interact")
let { abi } = require("./abi/ERC20.json")
let { longHandle,toSmall } = require("./utils")

class ERC20 extends Interact {
    constructor({ provider, account, rpcUrl, privateKey, contract }) {
        super({ provider, account, rpcUrl, privateKey, contract, abi })
        this.maxVal = "999000000000000000000000000000000000000000000000000"
        this.mainToken = "0x0000000000000000000000000000000000000000"
        if(!this.contract) {
            this.contract = this.mainToken
        }
    }

    async toAmount(amount) {
        try {
            let decimals = await this.decimals()
            let result = longHandle(amount, decimals)
            return result
        }catch(err){
            console.log(err)
            console.log("精度转换失败")
        }
    }

    async fromAmount(amount) {
        try {
            let decimals = await this.decimals()
            let result = toSmall(amount, decimals)
            return result
        }catch(err){
            console.log(err)
            console.log("精度转换失败")
        }
    }

    async isApprove(target,amount) {
        if (!this.isAddress(target)) {
            console.log("target 不是合法地址")
            return false
        }
        
        amount = await this.toAmount(amount)
        if(this.contract == this.mainToken) return true
        let approveAmount = await this.allowance(this.web3.eth.defaultAccount,target)

        return parseInt(approveAmount) >= parseInt(amount)
    }

    async tradeApprove(target,amount) {
        if (!this.isAddress(target)) {
            console.log("target 不是合法地址")
            return false
        }
        amount = await this.toAmount(amount)
        let balance = await this.balanceOf(this.web3.eth.defaultAccount)
        if(parseInt(balance) < parseInt(amount)){
            console.log("余额不足")
            return false
        }else {
            if(this.contract == this.mainToken) return true

            let approveAmount = await this.allowance(this.web3.eth.defaultAccount,target)
            if(parseInt(approveAmount) < parseInt(amount)) {
                let result = await this.approve(target,this.maxVal)
                return result
            }else{
                return true
            }
        }
    }

    async approve(spender, amount,broad = true) {
        if (!this.isAddress(spender)) {
            console.log("spender 不是合法地址")
            return false
        }
        amount = await this.toAmount(amount)

        
        let parmas = await this.buildTx("approve", [
            spender,
            amount
        ])

        let result
        if(broad) {
            result = parmas && await this.broadTx(parmas)
        }else {
            result = parmas && await this.readTx(parmas)
        }

        
        return result
    }

    async transfer(to, amount) {
        if (!this.isAddress(to)) {
            console.log("to 不是合法地址")
            return false
        }
        amount = await this.toAmount(amount)
        // 检查余额
        let balance = await this.balanceOf(this.web3.eth.defaultAccount)
        if(parseInt(balance) < parseInt(amount)) {
            console.log("账户余额不足")
            return false
        }

        let parmas;
        if(this.contract == this.mainToken) {
            parmas = await this.buildTx("", [],amount,{ to })
        }else {
            parmas = await this.buildTx("transfer", [
                to,
                amount
            ])
        }
        let result = parmas && await this.broadTx(parmas)
        return result
    }

    async transferFrom(from, to, amount) {
        if (!this.isAddress(from)) {
            console.log("from 不是合法地址")
            return false
        }
        if (!this.isAddress(to)) {
            console.log("to 不是合法地址")
            return false
        }
        amount = await this.toAmount(amount)
        // 检查余额
        let balance = await this.balanceOf(from)
        if(parseInt(balance) < parseInt(amount)) {
            console.log("账户余额不足")
            return false
        }
        // 检查授权数量
        let approveAmount = await this.allowance(from,this.web3.eth.defaultAccount)
        if(parseInt(approveAmount) < parseInt(amount)) {
            console.log("授权数量不足")
            return false
        }

        let parmas = await this.buildTx("transferFrom", [
            from,
            to,
            amount
        ])
        let result = parmas && await this.broadTx(parmas)
        return result
    }

    async balanceOf(wallet) {
        if (!this.isAddress(wallet)) {
            console.log("wallet 不是合法地址")
            return false
        }

        if(this.contract == this.mainToken) {
            let balance = await this.web3.eth.getBalance(wallet)
            return balance
        }else {
            let balance = await this.buildCall("balanceOf", [
                wallet
            ])
            return balance ? this.web3.utils.hexToNumberString(balance) : 0
        }
    }

    async decimals() {
        if(this.contract == this.mainToken) {
            return 18
        }else {
            let decimals = await this.buildCall("decimals")
            if(decimals === false) {
                console.log("精度获取失败",this.contract)
                return 0
            }else {
                return decimals ? this.web3.utils.hexToNumberString(decimals) : 0
            }
        }
        
    }

    async allowance(owner,spender) {
        if (!this.isAddress(owner)) {
            console.log("owner 不是合法地址")
            return false
        }
        if (!this.isAddress(spender)) {
            console.log("spender 不是合法地址")
            return false
        }
        let allowance = await this.buildCall("allowance", [
            owner,
            spender
        ])
        return allowance ? this.web3.utils.hexToNumberString(allowance) : 0
    }
}


module.exports = ERC20