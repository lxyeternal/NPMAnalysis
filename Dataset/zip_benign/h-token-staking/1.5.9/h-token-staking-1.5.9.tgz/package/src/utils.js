let BigNumber = require("bignumber.js")
let utils = require("web3-utils")

function byteGet(value, type = "address") {
    let result = ""
    switch (type) {
        case "address":
            result = `0x${value.slice(26)}`
            break;
    }
    return result
}

function charCompare(prev, next) {
    return prev.toLocaleLowerCase() == next.toLocaleLowerCase()
}


function toSmall(amount, precision) {
    return division(amount, Math.pow(10, precision))
}

function saveNum(n, l = 4) {
    n = BigNumber(n).toFixed()

    let isf = n.indexOf(".") != -1

    if (isf) {
        let int = n.split(".")[0]
        let float = n.split(".")[1]
        if (float.length > l) {
            float = float.slice(0, l)
        }
        return float ? `${int}.${float}` : int
    } else {
        return n
    }
}

function smallHandle(n, l = 18) {
    try {
        n = goodNumber(n)
        if (n) {
            n = '' + n
        } else {
            return '0'
        }
        l = parseInt(l)

        let e = n.length - l
        if (n.length >= l + 1) {
            let f = n.slice(0, e)
            let s = n.slice(e)
            n = `${f}.${s}`
        } else {
            let f
            f = new Array(Math.abs(e)).fill(0).join('')
            n = `0.${f}${n}`
        }
        return parseFloat(n)
    } catch (err) {
        console.log(err)
    }
}

function longHandle(n, l = 18) {
    n = goodNumber(n)
    if (n) {
        n = '' + n
    } else {
        return '0'
    }
    l = parseInt(l)

    if (n.indexOf('.') == -1) {
        n = n + new Array(l).fill(0).join('')
    } else {
        let h = n.split('.')[0]
        let e = n.split('.')[1]
        if (e.length >= l) {
            e = e.substr(0, l)
        } else {
            e = e + new Array(l - e.length).fill(0).join('')
        }
        if (parseInt(h)) {
            n = h + e
        } else {
            n = e
        }
    }
    return n
}

function goodNumber(n) {
    return BigNumber(n).toFixed()
}

function plus(x, y) {
    let base = BigNumber(x)
    return goodNumber(base.plus(y).toString())
}

function reduce(x, y) {
    let base = BigNumber(x)
    return goodNumber(base.minus(y).toString())
}

function multiplication(x, y) {
    let base = BigNumber(x)
    return goodNumber(base.multipliedBy(y).toString())
}

function division(x, y) {
    let base = BigNumber(x)
    let quote = BigNumber(y)
    return goodNumber(base.dividedBy(quote).toString())
}


module.exports = Object.assign(utils, {
    byteGet,
    charCompare,
    toSmall,
    division,
    multiplication,
    reduce,
    plus,
    goodNumber,
    longHandle,
    smallHandle,
    saveNum,

})