let Interact = require("./Interact")
let Request = require("./Request")
let ERC20 = require("./ERC20")
let { plus,reduce,multiplication,division,toSmall } = require("./utils")

class KySwap extends Interact {

    constructor({ provider, account, rpcUrl, privateKey, chain }) {
        super({ provider, account, rpcUrl, privateKey })
        this.maxVal = "999000000000000000000000000000000000000000000000000"
        this.mainToken = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE"
        this.EthToken = "0x0000000000000000000000000000000000000000"
        this.chain = chain

        this.isInBps = true
        this.chargeFeeBy = "currency_in"
        this.feeReceiver = "0x19cE99BDA3cc6e36855E5dc85A202e2be14F859F"
        this.feeAmount = 1
        this.saveGas = 0
        this.slippageTolerance = 50

        this.detail = {}
    }

    config({ isInBps,chargeFeeBy,feeReceiver,feeAmount,slippageTolerance }) {
        // 如果为true，则手续费以百分比 计算
        this.isInBps = isInBps !== undefined ? isInBps : this.isInBps
        // 手续费是由输入令牌currency_in还是输出令牌收取currency_out
        this.chargeFeeBy = chargeFeeBy ? chargeFeeBy : this.chargeFeeBy
        // 手续费接收地址 不能参与兑换
        this.feeReceiver = feeReceiver ? feeReceiver : this.feeReceiver
        // 手续费数量 
        // 如果isInBps=true是feeAmount我们将以基本单位 = 10000 收取的费用百分比，即feeAmount= 10 并且isInBps=true那么费用 = 0.1%
        // 如果isInBps=false是feeAmount我们将作为费用收取的代币数量，即feeAmount= 10 and isInBps= 'false' then fee = 10 token weis
        this.feeAmount = feeAmount ? feeAmount : this.feeAmount

        // false/ 0= 路由将基于返回的最大输出令牌 true/ 1= 路由将基于最低的 gas 成本（即最少的跳数）
        this.saveGas = saveGas == 1 ? 1 : 0
        // 这是用户可以接受的交易滑点量。取值范围为[0, 2000]，10表示0.1%。 默认值为 50/10000 ~ 0.5%。
        this.slippageTolerance = slippageTolerance ? slippageTolerance : 50
    }

    async encode_v2({ tokenIn,tokenOut,amountIn,to }) {
        let http = new Request();

        let InObj = new ERC20({
            ...this.network,
            contract:tokenIn ? tokenIn : this.EthToken
        })
        amountIn = await InObj.toAmount(amountIn)

        tokenIn = tokenIn ? tokenIn : this.mainToken
        tokenOut = tokenOut ? tokenOut : this.mainToken
        
        let params = {
            tokenIn,
            tokenOut,
            amountIn,
            saveGas: false,
            gasInclude: true,
            slippageTolerance:this.slippageTolerance,
            isInBps:this.isInBps,
            chargeFeeBy:this.chargeFeeBy,
            feeReceiver:this.feeReceiver,
            feeAmount:this.feeAmount
        }
        console.log(params)
        let { data } = await http.get({
            url:`https://aggregator-api.kyberswap.com/${this.chain}/api/v1/routes`,
            params
        })
        return data
    }

    async reEncode_v2({ routeSummary,sender,recipient }) {
        let http = new Request();
        let deadline = parseInt((new Date().getTime() + 1000 * 60 * 30) / 1000)
        let { data } = await http.postJson({
            url:`https://aggregator-api.kyberswap.com/${this.chain}/api/v1/route/build`,
            params:{
                deadline,
                routeSummary,
                recipient,
                sender,
                slippageTolerance:this.slippageTolerance,
                skipSimulateTx:false,
                source:"kyberswap"
            }
        })
        if(data) {
            let { tokenIn,tokenOut,amountIn,amountOut } = routeSummary
            let rateResult = await this.rateCompute({
                tokenIn,
                tokenOut,
                amountIn,
                amountOut
            })
            data = {
                ...data,
                ...rateResult
            }
            this.detail = data
        }
        
        return data
    }

    async encode({ tokenIn,tokenOut,amountIn,to }) {
        let http = new Request();

        let InObj = new ERC20({
            ...this.network,
            contract:tokenIn ? tokenIn : this.EthToken
        })
        amountIn = await InObj.toAmount(amountIn)

        tokenIn = tokenIn ? tokenIn : this.mainToken
        tokenOut = tokenOut ? tokenOut : this.mainToken
        
        let result = await http.get({
            url:`https://aggregator-api.kyberswap.com/${this.chain}/route/encode`,
            params:{
                tokenIn,
                tokenOut,
                amountIn,
                to,
                saveGas:this.saveGas,
                slippageTolerance:this.slippageTolerance,
                isInBps:this.isInBps,
                chargeFeeBy:this.chargeFeeBy,
                feeReceiver:this.feeReceiver,
                feeAmount:this.feeAmount,
                clientData:'{"source":"kyberswap"}'
            }
        })
        if(result) {
            let rateResult = await this.rateCompute({
                tokenIn,tokenOut,
                amountIn:result.inputAmount,
                amountOut:result.outputAmount
            })
            result = {
                ...result,
                ...rateResult
            }
            this.detail = result
        }
        
        return result
    }

    outCompute(amountIn) {
        let { priceRate } = this.detail
        if(!priceRate) {
            this.isDebug && console.log("请先执行encode({ tokenIn,tokenOut,amountIn,to })")
        }
        if(priceRate) {
            return multiplication(amountIn,this.detail.priceRate)
        }else {
            return 0
        }
    }

    async rateCompute({ tokenIn,tokenOut,amountIn,amountOut }) {
        
        if(tokenIn == this.mainToken || !tokenIn) {
            tokenIn = this.EthToken
        }
        if(tokenOut == this.mainToken || !tokenOut) {
            tokenOut = this.EthToken
        }
        let InObj = new ERC20({
            ...this.network,
            contract:tokenIn
        })
        let InAmount = await InObj.fromAmount(amountIn)
        let OutObj = new ERC20({
            ...this.network,
            contract:tokenOut
        })
        let OutAmount = await OutObj.fromAmount(amountOut)
        
        let priceRate = division(OutAmount,InAmount)
        return {
            priceRate,
            InAmount,
            OutAmount
        }
    }

    async swapTx_v2(tokenIn) {
        try{
            let { routerAddress,data,amountIn,gas } = this.detail
                let params = {
                    from: this.web3.eth.defaultAccount,
                    to: routerAddress,
                    data,
                    value: !tokenIn ? amountIn : 0,
                    gas:gas * 2
                }
                let gasPrice = await this.GasPrice()
                params.gasPrice = gasPrice
                let nonce = await this.web3.eth.getTransactionCount(params.from)
                params.nonce = nonce
                let realFee = multiplication(this.gas_price,gas)
                realFee = multiplication(realFee,2)
                let readFee = toSmall(realFee,18)
                params.realFee = realFee
                params.readFee = readFee

                this.isDebug && console.log(params)
                return params
        }catch(err){
            console.log(err)
            return false
        }
    }

    async swapTx({ tokenIn,tokenOut,amountIn,to }) {
        try{
            let result = await this.encode({ tokenIn,tokenOut,amountIn,to })
            if(result) {
                let { routerAddress,encodedSwapData,inputAmount,totalGas } = this.detail
                let params = {
                    from: this.web3.eth.defaultAccount,
                    to: routerAddress,
                    data: encodedSwapData,
                    value: !tokenIn ? inputAmount : 0,
                    gas:totalGas * 2
                }
                let gasPrice = await this.GasPrice()
                params.gasPrice = gasPrice
                let nonce = await this.web3.eth.getTransactionCount(params.from)
                params.nonce = nonce
                let realFee = multiplication(this.gas_price,totalGas)
                realFee = multiplication(realFee,2)
                let readFee = toSmall(realFee,18)
                params.realFee = realFee
                params.readFee = readFee

                this.isDebug && console.log(params)
                return params
            }else {
                return false
            }
        }catch(err){
            console.log(err)
            return false
        }
    }

    async isApprove(tokenIn,amountIn) {
        
        if(tokenIn == this.mainToken || !tokenIn) {
            tokenIn = this.EthToken
        }

        let { routerAddress } = this.detail
        if(!routerAddress) {
            this.isDebug && console.log("请先执行encode({ tokenIn,tokenOut,amountIn,to })")
        }

        let InObj = new ERC20({
            ...this.network,
            contract:tokenIn
        })
        let result = await InObj.isApprove(routerAddress,amountIn)
        return result
    }

    async approve(tokenIn) {
        let { routerAddress } = this.detail
        if(!routerAddress) {
            this.isDebug && console.log("请先执行encode({ tokenIn,tokenOut,amountIn,to })")
        }
        let InObj = new ERC20({
            ...this.network,
            contract:tokenIn
        })
        let result = await InObj.approve(routerAddress,this.maxVal)
        return result
    }
    


    

}


module.exports = KySwap