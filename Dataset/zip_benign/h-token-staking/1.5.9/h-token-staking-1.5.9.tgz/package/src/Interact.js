let Web3 = require("web3")
let ethSign = require("eth-sig-util")
let { plus, reduce, multiplication, division, toSmall, saveNum } = require("./utils")
class Interact {
    constructor({ provider, account, rpcUrl, privateKey, contract, abi }) {
        this.web3 = null
        this.SC = null
        this.privateKey = ""
        this.contract = ""
        this.provider = provider
        this.abi = abi
        this.speed = 0.25
        this.isDebug = true
        this.gas_price = 0
        this.gas_limit = 0

        this.network = {
            provider,
            account,
            rpcUrl,
            privateKey
        }

        if (provider) {
            this.web3 = new Web3(provider)
            this.web3.eth.defaultAccount = account
        } else if (rpcUrl) {
            this.web3 = new Web3(new Web3.providers.HttpProvider(rpcUrl))
            if (privateKey) {
                this.privateKey = privateKey.startsWith("0x") ? privateKey : `0x${privateKey}`
                let { address } = this.web3.eth.accounts.privateKeyToAccount(this.privateKey)
                this.web3.eth.defaultAccount = address
            } else if (account) {
                this.web3.eth.defaultAccount = account
            }
        }
        if (contract && this.abi && this.web3) {
            this.contract = contract
            this.SC = new this.web3.eth.Contract(this.abi, this.contract)
        } else if (this.web3 && this.abi) {
            this.SC = new this.web3.eth.Contract(this.abi)
        }
    }

    setSpeed(speed) {
        this.speed = speed ? speed : 0.25
    }

    openDebug(isDebug) {
        this.isDebug = isDebug
    }

    readTx(tx = {}) {
        let precision = 18
        let Gp = 9
        let { gas, value, gasPrice, from, to } = tx
        let total = multiplication(gas, gasPrice)
        total = plus(total, value)
        gas = plus(parseInt(gas), 0)
        value = plus(parseInt(value), 0)
        gasPrice = plus(parseInt(gasPrice), 0)
        return {
            gas,
            gasPrice,
            gasPrice: saveNum(toSmall(gasPrice, Gp)),
            value: saveNum(toSmall(value, precision)),
            total: saveNum(toSmall(total, precision)),
            from,
            to
        }
    }

    async GasPrice() {
        let result = await this.web3.eth.getGasPrice()

        let up = plus(1, this.speed)
        this.gas_price = parseInt(multiplication(up, result))
        result = '0x' + this.gas_price.toString(16)
        return result
    }
    async GasLimit(params) {
        let gas = await this.web3.eth.estimateGas(params)
        this.gas_limit = parseInt(multiplication(2, gas))
        gas = '0x' + this.gas_limit.toString(16)
        return gas
    }

    isAddress(address) {
        return this.web3.utils.isAddress(address)
    }
    buildData(method, param = []) {
        try {
            if (method) {
                let methodABI = this.abi.filter(item => {
                    return item.type == 'function' && item.name == method
                })[0]
                return this.web3.eth.abi.encodeFunctionCall(methodABI, param)
            }
        } catch (err) {
            console.log(err)
            throw err
        }
        return ""
    }
    async buildTx(method, param = [], value = 0, tx = {}) {
        try {
            let params = Object.assign({
                from: this.web3.eth.defaultAccount,
                to: this.contract,
                value,
            }, tx)
            params.data = this.buildData(method, param)
            let gas = await this.GasLimit(params)
            params.gas = gas
            let gasPrice = await this.GasPrice()
            params.gasPrice = gasPrice
            let nonce = await this.web3.eth.getTransactionCount(params.from)
            params.nonce = nonce
            this.isDebug && console.log(params)
            return params
        } catch (err) {
            console.log(err)
            throw err
        }
    }

    async buildTx_v1(tx = {}) {
        try {
            let params = {
                ...tx
            }
            let gas = await this.GasLimit(params)
            params.gas = gas
            let gasPrice = await this.GasPrice()
            params.gasPrice = gasPrice
            let nonce = await this.web3.eth.getTransactionCount(params.from)
            params.nonce = nonce
            this.isDebug && console.log(params)
            return params
        } catch (err) {
            console.log(err)
            throw err
        }
    }

    async buildCall(method, param = []) {
        try {
            if (!this.contract) return false
            let params = {
                from: this.web3.eth.defaultAccount,
                to: this.contract
            }
            params.data = this.buildData(method, param)
            let result = await this.web3.eth.call(params)
            return result
        } catch (err) {
            console.log(err)
            throw err
        }
    }

    txConfirm(tx) {
        return new Promise((resolve, reject) => {
            try {
                let time = setInterval(() => {
                    this.web3.eth.getTransaction(tx).then(result => {
                        console.log("Confirm Tx:", result)
                        if (result.blockHash) {
                            clearInterval(time)
                            resolve(true)
                        }
                    })
                }, 1000)
            } catch (err) {
                console.log(err)
                reject(err)
            }
        })
    }

    async broadTx(params) {
        try {
            let result;
            if (this.privateKey) {
                let { rawTransaction } = await this.web3.eth.accounts.signTransaction(params, this.privateKey)
                return new Promise((resolve, reject) => {
                    this.web3.eth.sendSignedTransaction(rawTransaction)
                        .on('error', (error) => {
                            console.log(error)
                            resolve(false)
                        }).on('receipt', (result) => {
                            this.isDebug && console.log(result)
                            if (result && result.transactionHash) {
                                this.txConfirm(result.transactionHash).then((confirm) => {
                                    if (confirm) {
                                        resolve(result)
                                    }
                                })
                            }

                        })
                })
            } else {
                result = await this.web3.eth.sendTransaction(params)
                this.isDebug && console.log(result)
                let confirm = await this.txConfirm(result.transactionHash)
                if (confirm) {
                    return result
                }
            }

        } catch (err) {
            console.log(err)
            throw err
        }
    }



    async msgSign(msg) {
        let signature;
        let r;
        let s;
        let v;
        let signer;
        if (this.privateKey) {
            let walletObj = this.web3.eth.accounts.privateKeyToAccount(this.privateKey)
            let result = walletObj.sign(msg)
            signature = result.signature
        } else {
            signature = await this.provider.request({
                method: "personal_sign",
                params: [msg, this.web3.eth.defaultAccount]
            })

        }
        if (signature) {
            r = signature.slice(0, 66)
            s = '0x' + signature.slice(66, 130)
            v = '0x' + signature.slice(130, 132)
            v = this.web3.utils.toDecimal(v).toString()
            signer = this.web3.eth.accounts.recover(msg, signature)
        }
        return { signature, r, s, v, signer }
    }


    async eth_signTypedData_v4(data) {
        let signature;
        let r;
        let s;
        let v;
        if (this.privateKey) {
            signature = ethSign.signTypedData_v4(Buffer.from(this.privateKey.slice(2), "hex"), { data });
        } else {
            signature = await this.provider.request({
                method: "eth_signTypedData_v4",
                params: [this.web3.eth.defaultAccount, JSON.stringify(data)]
            })
        }

        if (signature) {
            r = signature.slice(0, 66)
            s = '0x' + signature.slice(66, 130)
            v = '0x' + signature.slice(130, 132)
            v = this.web3.utils.toDecimal(v).toString()
        }
        return { signature, r, s, v }
    }
}

module.exports = Interact