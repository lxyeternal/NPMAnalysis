let HI = require("./Interact")
let HTS = require("./Staking")
let HERC20 = require("./ERC20")
let HERC721 = require("./ERC721")
let HERC1155 = require("./ERC1155")
let HBT = require("./Batch")
let HKYS = require("./KySwap")
let HDEX = require("./Dex")
let HWS = require("./InitSocket")
let utils = require("./utils")

try{
    if (window) {
        window.HI = HI
        window.HTS = HTS
        window.HBT = HBT
        window.HWS = HWS
        window.HKYS = HKYS
        window.HDEX = HDEX
        window.HERC20 = HERC20
        window.HERC721 = HERC721
        window.HERC1155 = HERC1155
        Object.keys(utils).forEach(item => {
            window[item] = utils[item]
        })
    }
    
}catch(err){}
module.exports = {
    HI,
    HTS,
    HBT,
    HWS,
    HKYS,
    HDEX,
    HERC20,
    HERC721,
    HERC1155
}