class InitSocket {
    constructor(url) {
        this.socketTask = null
        this.init(url)
        this.watch = null
    }

    chainup_trade(symbol,isCancel = false) {
        symbol = symbol.toLocaleLowerCase()
        let result = {
            "event": isCancel ? "unsub" : "sub",
            "params": {
                "channel": `market_${symbol}_trade_ticker`, // $symbol E.g. btcusdt 
            }
        }
        console.log(result)
        return JSON.stringify(result)
    }

    chainup_ticker(symbol,isCancel = false) {
        symbol = symbol.toLocaleLowerCase()
        let result = {
            "event": isCancel ? "unsub" : "sub",
            "params": {
                "channel": `market_${symbol}_ticker`, // $symbol E.g. btcusdt 
            }
        }
        return JSON.stringify(result)
    }

    chainup_kline(symbol, grap,endIdx = 0,isCancel = false) {
        //  grap [1min/5min/15min/30min/60min/1day/1week/1month]
        symbol = symbol.toLocaleLowerCase()
        let result = {
            "event": "req",
            "params": {
                "channel": `market_${symbol}_kline_${grap}`,
                "endIdx":endIdx ? endIdx : parseInt(new Date().getTime() / 1000),
                "pageSize": 300
            }
        }
        return JSON.stringify(result)
    }

    chainup_kline_ticker(symbol, grap,isCancel = false) {
        //  grap [1min/5min/15min/30min/60min/1day/1week/1month]
        symbol = symbol.toLocaleLowerCase()
        let result = {
            "event": isCancel ? "unsub" : "sub",
            "params": {
                "channel": `market_${symbol}_kline_${grap}`
            }
        }
        return JSON.stringify(result)
    }

    init(url) {
        if (window) {
            this.socketTask = new WebSocket(url);
        } else {
            this.socketTask = uni.connectSocket({
                url,
                success(data) { }
            });
        }
        return this.socketTask
    }

    check() {
        this.watch && clearTimeout(this.watch)
        this.watch = setTimeout(() => {
            this.socketTask && this.clear()
        }, 30000)
    }

    send(paramStr) {
        if (window) {
            this.socketTask.send(paramStr)
        } else {
            uni.sendSocketMessage({
                data: paramStr
            });
        }

    }

    message(fn = () => { }) {
        this.check()
        if (window) {
            this.socketTask.onmessage = (event) => {
                fn(event)
            }
        } else {
            uni.onSocketMessage((event) => {
                fn(event)
            });
        }
    }

    error(fn = () => { }) {
        if (window) {
            this.socketTask.onerror = (event) => {
                fn(event)
            }
        } else {
            uni.onSocketError((event) => {
                fn(event)
            });
        }
    }

    close(fn = () => { }) {
        if (window) {
            this.socketTask.onclose = (event) => {
                fn(event)
            }
        } else {
            uni.onSocketClose((event) => {
                fn(event)
            });
        }
    }

    clear() {
        if (window) {
            this.socketTask.close()
        } else {
            uni.closeSocket();
        }

    }

    open(fn = () => { }) {
        this.check()
        if (window) {
            this.socketTask.onopen = (event) => {
                fn(event)
            }
        } else {
            uni.onSocketOpen((event) => {
                fn(event)
            });
        }
    }
}

module.exports = InitSocket