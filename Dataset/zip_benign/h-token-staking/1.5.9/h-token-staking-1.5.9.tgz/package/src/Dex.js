let Interact = require("./Interact")
let Request = require("./Request")
let ERC20 = require("./ERC20")
let pako = require('pako')
let InitSocket = require("./InitSocket")
let { plus, reduce, multiplication, division, toSmall, longHandle, saveNum } = require("./utils")

class Dex extends Interact {

    constructor({ provider, account, rpcUrl, privateKey, chainId, url = "" }) {
        super({ provider, account, rpcUrl, privateKey })
        this.http = new Request(url)
        this.zero = "0x0000000000000000000000000000000000000000"
        this.chainId = chainId ? chainId : 137
        this.verfify = ""

        this.pool = "0x0000000000000000000000000000000000000000000000000000000000000000"
        this.taker = this.zero
        this.sender = this.zero
        this.gasFee = 0

        this.allPair = []
        this.socket = null
        this.ws_url = ""
    }

    initSocket(ws_url, callBack = () => { }) {
        return new Promise((resolve, reject) => {
            this.socket = new InitSocket(ws_url);
            this.socket.error((err) => {
                console.log(err);
                this.socket = null
                resolve(false)
            })
            this.socket.close(() => {
                this.isDebug && console.log("WebSocket 连接关闭!");
                this.socket = null
                resolve(false)
            })
            this.socket.open(() => {
                this.isDebug && console.log("WebSocket 连接成功!");
                resolve(true)
            })
            this.socket.message((event) => {
                try {
                    let { data } = event
                    if (window) {
                        if (data instanceof Blob) {
                            data.arrayBuffer().then(buffer => {
                                let result = JSON.parse(pako.inflate(buffer, { to: 'string' }))
                                if (result instanceof Object && result.channel) {
                                    callBack(result)
                                }
                            })
                        }
                    } else {
                        if (data instanceof ArrayBuffer) {
                            let result = JSON.parse(pako.inflate(event.data, { to: 'string' }))
                            if (result instanceof Object && result.channel) {
                                callBack(result)
                            }
                        }
                    }
                } catch (err) { }
            })
        })

    }

    async linkSocket(callBack = () => { }) {
        await this.public_info_market()
        let result = await this.initSocket(this.ws_url, callBack)
        return result
    }
    socket_trade(symbol, isCancel = false) {
        let msg = this.socket.chainup_trade(symbol, isCancel)
        return this.postSocket(msg)
    }

    socket_ticker(symbol, isCancel = false) {
        let msg = this.socket.chainup_ticker(symbol, isCancel)
        return this.postSocket(msg)
    }

    socket_tickers(isCancel = false) {
        let result = this.allPair.every(item => {
            let { symbol } = item
            let msg = this.socket.chainup_ticker(symbol, isCancel)
            return this.postSocket(msg)
        })
        return result
    }


    socket_kline(symbol, grap = "1day", endIdx = 0, isCancel = false) {
        let msg = this.socket.chainup_kline(symbol, grap, endIdx, isCancel)
        return this.postSocket(msg)
    }
    socket_kline_ticker(symbol, grap = "1day", endIdx = 0, isCancel = false) {
        let msg = this.socket.chainup_kline_ticker(symbol, grap, endIdx, isCancel)
        return this.postSocket(msg)
    }

    postSocket(msg) {
        if (this.socket) {
            this.socket.send(msg)
            return true
        } else {
            return false
        }
    }





    config({ url }) {
        this.url = url
    }

    result_handle(result) {
        if (result && result.code == 0) {
            return result.data
        } else {
            return result
        }
    }
    async sign_limit_one() {
        let param_one = "8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f"
        // 字符
        let ZeroEx = this.web3.utils.utf8ToHex("ZeroEx")
        ZeroEx = this.web3.utils.sha3(ZeroEx)
        ZeroEx = ZeroEx.substr(2)
        console.log("ZeroEx", ZeroEx)
        // 版本号
        let version = this.web3.utils.utf8ToHex("1.0.0")
        version = this.web3.utils.sha3(version)
        version = version.substr(2)
        console.log("version", version)
        // 主链ID
        let chainId = parseInt(this.chainId).toString(16)
        chainId = this.web3.utils.padLeft(chainId, 64)
        console.log("chainId", chainId)
        // 交易授权合约地址
        let verfifyingContract = this.web3.utils.padLeft(this.verfify, 64)
        verfifyingContract = verfifyingContract.substr(2)
        console.log("verfifyingContract", verfifyingContract)
        let mainOne = "0x" + param_one + ZeroEx + version + chainId + verfifyingContract
        console.log("mainOne", mainOne)
        mainOne = this.web3.utils.sha3(mainOne)
        console.log("mainOne_hash", mainOne)
        mainOne = mainOne.substr(2)
        return mainOne
    }

    // 下单
    async ex_order_v1(params = {}) {
        let { pair, price, amount, side, expiry, salt } = params
        let pool = this.pool
        let taker = this.taker
        let sender = this.sender
        let { v, r, s } = await this.sign_limit({ pair, price, amount, side, expiry, salt })
        let { takerTokenFeeAmount, quoteAmount, takerPrecision } = await this.param_format({ pair, price, amount, side })

        let {
            chainId, baseTokenAddress, quoteTokenAddress,
            feeAddress, isMain, baseContractPrecision, quoteContractPrecision
        } = pair

        quoteAmount = longHandle(quoteAmount, quoteContractPrecision)
        takerTokenFeeAmount = longHandle(takerTokenFeeAmount, takerPrecision)
        // 去零
        takerTokenFeeAmount = plus(takerTokenFeeAmount, 0)


        let result = await this.http.postJson({
            url: `/dex/ex/v1/order`,
            params: {
                chainId: chainId,
                _tokenContract: baseTokenAddress,
                _tokenAmount: longHandle(amount, baseContractPrecision),
                price,
                quoteToken: quoteTokenAddress,
                quoteAmount,
                maker: this.web3.eth.defaultAccount,
                taker,
                pool,
                expiry,
                salt,
                sender,
                isMainChain: isMain,
                signature: {
                    v, r, s,
                    signatureType: 2
                },
                side,
                gasFee: this.gasFee.toString(),
                takerTokenFeeAmount,
                feeRecipient: feeAddress
            }
        })
        return this.result_handle(result)
    }

    async param_format(params = {}) {
        let { pair, price, amount, side } = params

        let {
            baseTokenAddress, quoteTokenAddress, feeRate,
            feeAddress, baseContractPrecision, quoteContractPrecision
        } = pair
        let makerToken;
        let takerToken;
        let maketPrecision;
        let takerPrecision;
        let makerAmount;
        let takerAmount;
        let feeRecipient = feeAddress;
        let takerTokenFeeAmount;
        let quoteAmount;
        switch (side) {
            case "SELL":
                makerToken = baseTokenAddress
                takerToken = quoteTokenAddress
                maketPrecision = baseContractPrecision
                takerPrecision = quoteContractPrecision
                makerAmount = amount
                takerAmount = reduce(multiplication(price, amount), this.gasFee)
                quoteAmount = takerAmount
                break;
            case "BUY":
                makerToken = quoteTokenAddress
                takerToken = baseTokenAddress
                maketPrecision = quoteContractPrecision
                takerPrecision = baseContractPrecision
                makerAmount = plus(multiplication(price, amount), this.gasFee)
                takerAmount = amount
                quoteAmount = makerAmount
                break;
        }
        takerTokenFeeAmount = multiplication(feeRate, takerAmount)
        return {
            makerToken, takerToken, maketPrecision, takerPrecision,
            makerAmount, takerAmount, feeRecipient, takerTokenFeeAmount, quoteAmount
        }
    }

    async sign_limit(params = {}) {
        let { pair, price, amount, side, expiry, salt } = params
        let { chainId } = pair

        let {
            makerToken, takerToken, maketPrecision, takerPrecision,
            makerAmount, takerAmount, feeRecipient, takerTokenFeeAmount
        } = await this.param_format({ pair, price, amount, side })
        let { chainInfo } = await this.public_info()
        makerAmount = longHandle(makerAmount, maketPrecision)
        takerAmount = longHandle(takerAmount, takerPrecision)
        takerTokenFeeAmount = longHandle(takerTokenFeeAmount, takerPrecision)
        const typedData = {
            types: {
                EIP712Domain: [
                    { name: 'name', type: 'string' },
                    { name: 'version', type: 'string' },
                    { name: 'chainId', type: 'uint256' },
                    { name: 'verifyingContract', type: 'address' },
                ],
                LimitOrder: [
                    { type: 'address', name: 'makerToken' },
                    { type: 'address', name: 'takerToken' },
                    { type: 'uint128', name: 'makerAmount' },
                    { type: 'uint128', name: 'takerAmount' },
                    { type: 'uint128', name: 'takerTokenFeeAmount' },
                    { type: 'address', name: 'maker' },
                    { type: 'address', name: 'taker' },
                    { type: 'address', name: 'sender' },
                    { type: 'address', name: 'feeRecipient' },
                    { type: 'bytes32', name: 'pool' },
                    { type: 'uint64', name: 'expiry' },
                    { type: 'uint256', name: 'salt' },
                ],
            },
            domain: {
                name: 'ZeroEx',
                version: '1.0.0',
                chainId: this.chainId,
                verifyingContract: chainInfo.zeroExAddress,
            },
            primaryType: 'LimitOrder',
            message: {
                makerToken,
                takerToken,
                makerAmount,
                takerAmount,
                takerTokenFeeAmount,
                maker: this.web3.eth.defaultAccount,
                taker: this.taker,
                sender: this.sender,
                feeRecipient,
                pool: this.pool,
                expiry,
                salt
            },
        }

        console.log(typedData)
        let result = await this.eth_signTypedData_v4(typedData)
        return result

        let prefix = "0x1901"
        let mainOne = await this.sign_limit_one(chainId)
        console.log("mainOne_result", mainOne)
        let param_two = "ce918627cb55462ddbb85e73de69a8b322f2bc88f4507c52fcad6d4c33c29d49"
        // 支出币种
        makerToken = this.web3.utils.padLeft(makerToken, 64)
        makerToken = makerToken.substr(2)
        console.log("makerToken", makerToken)
        // 接收币种
        takerToken = this.web3.utils.padLeft(takerToken, 64)
        takerToken = takerToken.substr(2)
        console.log("takerToken", takerToken)
        // 支出数量
        console.log("makerAmount", makerAmount)
        makerAmount = longHandle(makerAmount, maketPrecision)
        makerAmount = parseInt(makerAmount).toString(16)
        makerAmount = this.web3.utils.padLeft(makerAmount, 64)

        // 手续费数量

        console.log("takerTokenFeeAmount", takerTokenFeeAmount)
        takerTokenFeeAmount = longHandle(takerTokenFeeAmount, takerPrecision)
        takerTokenFeeAmount = parseInt(takerTokenFeeAmount).toString(16)
        takerTokenFeeAmount = this.web3.utils.padLeft(takerTokenFeeAmount, 64)

        // 接收数量
        console.log("takerAmount", takerAmount)
        takerAmount = longHandle(takerAmount, takerPrecision)
        takerAmount = parseInt(takerAmount).toString(16)
        takerAmount = this.web3.utils.padLeft(takerAmount, 64)

        // 下单钱包地址
        let maker = this.web3.utils.padLeft(this.web3.eth.defaultAccount, 64)
        maker = maker.substr(2)
        console.log("maker", maker)
        // 接收钱包地址
        let taker = this.web3.utils.padLeft(this.taker, 64)
        taker = taker.substr(2)
        console.log("taker", taker)
        // 交易发送钱包地址
        let sender = this.web3.utils.padLeft(this.sender, 64)
        sender = sender.substr(2)
        console.log("sender", sender)
        // 手续费接收钱包地址
        feeRecipient = this.web3.utils.padLeft(feeRecipient, 64)
        feeRecipient = feeRecipient.substr(2)
        console.log("feeRecipient", feeRecipient)
        // pool
        let pool = this.pool.substr(2)
        console.log("pool", pool)
        // 订单到期时间
        expiry = parseInt(expiry).toString(16)
        expiry = this.web3.utils.padLeft(expiry, 64)
        console.log("expiry", expiry)
        // salt
        salt = parseInt(salt).toString(16)
        salt = this.web3.utils.padLeft(salt, 64)
        console.log("salt", salt)

        let mainTwo = "0x" + param_two + makerToken + takerToken + makerAmount + takerAmount
        mainTwo = mainTwo + takerTokenFeeAmount + maker + taker + sender + feeRecipient + pool
        mainTwo = mainTwo + expiry + salt
        console.log("mainTwo", mainTwo)
        mainTwo = this.web3.utils.sha3(mainTwo)
        console.log("mainTwo_hash", mainTwo)
        mainTwo = mainTwo.substr(2)
        console.log("mainTwo_result", mainTwo)

        let msg = prefix + mainOne + mainTwo
        console.log("msg", msg)
        msg = this.web3.utils.sha3(msg)
        console.log("msg_hash", msg)
        return this.msgSign(msg)
    }

    async signAuth({ companyId }) {
        let prefix = "0x1901"
        let param_one = "af3067cecdd428dab67b65fe3e0abb5ab731f2a7ad725daf7ca5791e0f693e32"
        // 主链ID
        let chainId = parseInt(this.chainId).toString(16)
        chainId = this.web3.utils.padLeft(chainId, 64)
        // 商户ID
        companyId = parseInt(companyId).toString(16)
        companyId = this.web3.utils.padLeft(companyId, 64)
        // 钱包地址
        let address = this.web3.utils.padLeft(this.web3.eth.defaultAccount, 64)
        address = address.substr(2)
        // 字符
        let allDex = this.web3.utils.utf8ToHex("AllDex")
        allDex = this.web3.utils.sha3(allDex)
        allDex = allDex.substr(2)

        let string = "0x" + param_one + chainId + companyId + address + allDex
        let msg = this.web3.utils.sha3(string)
        msg = msg.substr(2)
        msg = prefix + msg
        msg = this.web3.utils.sha3(msg)
        return this.msgSign(msg)
    }

    async signAuth_v2() {
        let { domain } = await this.public_info()
        const typedData = {
            types: {
                EIP712Domain: [
                    { name: 'name', type: 'string' },
                    { name: 'version', type: 'string' },
                    { name: 'chainId', type: 'uint256' },
                ],
                UserAuth: [
                    { type: 'string', name: 'action' },
                    { type: 'string', name: 'signDomain' },
                ],
            },
            domain: {
                name: 'Dex',
                version: '1.0.0',
                chainId: this.chainId,
            },
            primaryType: 'UserAuth',
            message: {
                action: 'Enable Trading',
                signDomain: domain,
            },
        }

        let result = await this.eth_signTypedData_v4(typedData)
        console.log(result)
        return result
    }
    // 用户登录
    async auth_info() {
        let { r, s, v } = await this.signAuth_v2()
        let result = await this.http.postJson({
            url: `/dex/v1/user/auth`,
            params: {
                chainId: this.chainId,
                userAddress: this.web3.eth.defaultAccount,
                signatureType: 2,
                r, s, v
            }
        })
        result = this.result_handle(result)
        this.http.setHead({
            "dex-token": result.token
        })
        return result
    }

    // 收藏币对list
    async collect_symbol() {
        let result = await this.http.postJson({
            url: `/dex/ex/list_symbol`,
            params: {}
        })
        return this.result_handle(result)
    }

    // 更新币对收藏 1,2,3
    async collect_update(symbols) {
        let result = await this.http.postJson({
            url: `/dex/ex/update_symbol`,
            params: {
                symbols
            }
        })
        return this.result_handle(result)
    }

    // 订单list
    async order_list_v1(params = {}) {
        let result = await this.http.postJson({
            url: `/dex/ex/v1/order/list`,
            params: {

                chainId: this.chainId,
                ...params
                // baseToken,
                // quoteToken,
                // current,
                // side,
                // page,
                // pageSize
            }
        })
        return this.result_handle(result)
    }


    // 取消主链币卖单
    async ex_cancel_mainsell({ orderId, txid }) {
        let result = await this.http.postJson({
            url: `/dex/ex/v1/cancel`,
            params: {
                chainId: this.chainId,
                orderId,
                account: this.web3.eth.defaultAccount,
                txid
            }
        })
        return this.result_handle(result)
    }
    // 取消代币以及主链币买单 第一步
    async ex_cancel_stepone({ orderId, account }) {
        let result = await this.http.postJson({
            url: `/dex/ex/v1/token/cancelStepOne`,
            params: {
                chainId: this.chainId,
                orderId,
                account
            }
        })
        return this.result_handle(result)
    }

    // 取消代币以及主链币买单 第二步
    async ex_cancel_steptwo({ orderId, account, txid }) {
        let result = await this.http.postJson({
            url: `/dex/ex/v1/token/cancelStepTwo`,
            params: {
                chainId: this.chainId,
                orderId,
                account,
                txid
            }
        })
        return this.result_handle(result)
    }

    // 同步主链币资产状态
    async sync_main_order({ orderId, txid }) {
        let result = await this.http.postJson({
            url: `/dex/ex/v1/order/syncMainOrder`,
            params: {
                chainId: this.chainId,
                orderId,
                txid
            }
        })
        return this.result_handle(result)
    }

    // 市场信息
    async public_info_market() {
        let result = await this.http.postJson({
            url: `/dex/public_info_market`,
            params: {
                chainId: this.chainId
            }
        })
        result = this.result_handle(result)
        let { market, ws_url } = result
        this.ws_url = ws_url
        // 所有币对
        this.allPair = []
        if (market && Object.keys(market)) {
            Object.keys(market).forEach(item => {
                this.allPair = this.allPair.concat(market[item])
            })
        }
        return {
            ...result,
            valuation: Object.keys(market)
        }
    }

    // 基础配置
    async public_info() {
        let result = await this.http.postJson({
            url: `/dex/public_info`,
            params: {
                chainId: this.chainId
            }
        })

        result = this.result_handle(result)
        if (result && result.chainInfo && result.chainInfo.zeroExAddress) {
            this.verfify = result.chainInfo.zeroExAddress
        }
        return result
    }

    // 汇率
    async dex_rate() {
        let result = await this.http.postJson({
            url: `/dex/rate`,
            params: { chainId: this.chainId }
        })
        return this.result_handle(result)
    }

    async estimate_trade_fee(pair) {
        let result = await this.http.postJson({
            url: `/dex/ex/v1/order/estimate_trade_fee`,
            params: {
                chainId: pair.chainId,
                baseToken: pair.baseTokenAddress,
                quoteToken: pair.quoteTokenAddress,
                isMain: pair.isMain,
            }
        })
        this.gasFee = this.result_handle(result)
        return this.gasFee
    }


    // 授权代币
    async approveToken({ pair, price, amount, side }) {
        let {
            baseTokenAddress, quoteTokenAddress, chainId,
            baseContractPrecision, quoteContractPrecision
        } = pair
        let token = ""
        let approveAmount = longHandle(amount, baseContractPrecision)
        if (side == "SELL") {
            token = baseTokenAddress
        } else {
            token = quoteTokenAddress
            approveAmount = multiplication(price, amount)
            approveAmount = longHandle(approveAmount, quoteContractPrecision)
        }
        let E20 = new ERC20({
            ...this.network,
            contract: token
        })
        let approved = await E20.allowance(this.web3.eth.defaultAccount, this.verfify)
        let sum = plus(approveAmount, approved)
        let result = await E20.buildTx("approve", [
            this.verfify,
            sum
        ])
        return result
    }

    // 主链币资产转换交易构建
    async main_assets_tx(params = {}) {
        let { pair, price, amount, side, expiry, salt } = params

        let {
            makerToken, takerToken, maketPrecision, takerPrecision,
            makerAmount, takerAmount, feeRecipient, takerTokenFeeAmount
        } = await this.param_format({ pair, price, amount, side })


        makerAmount = longHandle(makerAmount, maketPrecision)
        takerAmount = longHandle(takerAmount, takerPrecision)
        takerTokenFeeAmount = longHandle(takerTokenFeeAmount, takerPrecision)

        let maker = this.web3.eth.defaultAccount
        let pool = this.pool
        let taker = this.taker
        let sender = this.sender
        let data = this.web3.eth.abi.encodeFunctionCall({
            name: 'createLimitOrderForEthAsset',
            type: 'function',
            inputs: [{
                "components": [
                    {
                        "name": "makerToken",
                        "type": "address"
                    },
                    {
                        "name": "takerToken",
                        "type": "address"
                    },
                    {
                        "name": "makerAmount",
                        "type": "uint128"
                    },
                    {
                        "name": "takerAmount",
                        "type": "uint128"
                    },
                    {
                        "name": "takerTokenFeeAmount",
                        "type": "uint128"
                    },
                    {
                        "name": "maker",
                        "type": "address"
                    },
                    {
                        "name": "taker",
                        "type": "address"
                    },
                    {
                        "name": "sender",
                        "type": "address"
                    },
                    {
                        "name": "feeRecipient",
                        "type": "address"
                    },
                    {
                        "name": "pool",
                        "type": "bytes32"
                    },
                    {
                        "name": "expiry",
                        "type": "uint64"
                    },
                    {
                        "name": "salt",
                        "type": "uint256"
                    }
                ],
                "name": "order",
                "type": "tuple"
            }]
        }, [[
            makerToken,
            takerToken,
            makerAmount,
            takerAmount,
            takerTokenFeeAmount,
            maker,
            taker,
            sender,
            feeRecipient,
            pool,
            expiry,
            salt
        ]]);

        let param = await this.buildTx_v1({
            from: this.web3.eth.defaultAccount,
            to: this.verfify,
            data,
            value: makerAmount
        })
        return param
    }
    // 主链币资产转换交易广播
    async main_assets(params = {}) {

        let param = await this.main_assets_tx(params)
        let tx = param && await this.broadTx(param)
        return tx
    }

    // 主链币卖单撤单交易广播
    async cancel_sell_main(order) {
        let params = await this.cancel_sell_main_tx(order)
        let tx = params && await this.broadTx(params)
        return tx
    }

    // 主链币卖单撤单交易构建
    async cancel_sell_main_tx(order) {


        let {
            _tokenContract,
            _tokenAmount,
            quoteToken,
            quoteAmount,
            feeRecipientAddress,
            takerTokenFeeAmount,
            salt, expiry
        } = order


        let makerToken = _tokenContract
        let takerToken = quoteToken
        let makerAmount = plus(_tokenAmount, 0)
        let takerAmount = plus(quoteAmount, 0)
        takerTokenFeeAmount = plus(takerTokenFeeAmount, 0)
        let feeRecipient = feeRecipientAddress
        let maker = this.web3.eth.defaultAccount
        let pool = this.pool
        let taker = this.taker
        let sender = this.sender
        let data = this.web3.eth.abi.encodeFunctionCall({
            name: 'cancelLimitOrderForEth',
            type: 'function',
            inputs: [
                {
                    "components": [{
                        "name": "makerToken",
                        "type": "address"
                    }, {
                        "name": "takerToken",
                        "type": "address"
                    }, {
                        "name": "makerAmount",
                        "type": "uint128"
                    }, {
                        "name": "takerAmount",
                        "type": "uint128"
                    }, {
                        "name": "takerTokenFeeAmount",
                        "type": "uint128"
                    }, {
                        "name": "maker", "type": "address"
                    }, {
                        "name": "taker",
                        "type": "address"
                    }, {
                        "name": "sender",
                        "type": "address"
                    }, {
                        "name": "feeRecipient",
                        "type": "address"
                    }, {
                        "name": "pool",
                        "type": "bytes32"
                    }, {
                        "name": "expiry",
                        "type": "uint64"
                    }, {
                        "name": "salt",
                        "type": "uint256"
                    }],
                    "name": "order",
                    "type": "tuple"
                }]
        }, [[
            makerToken,
            takerToken,
            makerAmount,
            takerAmount,
            takerTokenFeeAmount,
            maker,
            taker,
            sender,
            feeRecipient,
            pool,
            expiry,
            salt]
        ]);

        let params = await this.buildTx_v1({
            from: this.web3.eth.defaultAccount,
            to: this.verfify,
            data,
            value: 0
        })
        return params
    }

    // token撤单以及主链币买单撤单交易构建
    async cancel_token_tx(order) {
        let {
            _tokenContract,
            _tokenAmount,
            quoteToken,
            quoteAmount,
            feeRecipientAddress,
            takerTokenFeeAmount,
            salt, expiry, side
        } = order

        let makerToken = _tokenContract
        let takerToken = quoteToken
        let makerAmount = plus(_tokenAmount, 0)
        let takerAmount = plus(quoteAmount, 0)

        if (side == "BUY") {
            makerToken = quoteToken
            takerToken = _tokenContract
            makerAmount = plus(quoteAmount, 0)
            takerAmount = plus(_tokenAmount, 0)
        }



        takerTokenFeeAmount = plus(takerTokenFeeAmount, 0)
        let feeRecipient = feeRecipientAddress
        let maker = this.web3.eth.defaultAccount
        let pool = this.pool
        let taker = this.taker
        let sender = this.sender

        let data = this.web3.eth.abi.encodeFunctionCall({
            name: 'cancelLimitOrder',
            type: 'function',
            inputs: [{
                "components": [{
                    "name": "makerToken",
                    "type": "address"
                }, {
                    "name": "takerToken",
                    "type": "address"
                }, {
                    "name": "makerAmount",
                    "type": "uint128"
                }, {
                    "name": "takerAmount",
                    "type": "uint128"
                }, {
                    "name": "takerTokenFeeAmount",
                    "type": "uint128"
                }, {
                    "name": "maker",
                    "type": "address"
                }, {
                    "name": "taker",
                    "type": "address"
                }, {
                    "name": "sender",
                    "type": "address"
                }, {
                    "name": "feeRecipient",
                    "type": "address"
                }, {
                    "name": "pool",
                    "type": "bytes32"
                }, {
                    "name": "expiry",
                    "type": "uint64"
                }, {
                    "name": "salt",
                    "type": "uint256"
                }],
                "name": "order",
                "type": "tuple"
            }]
        }, [
            [
                makerToken,
                takerToken,
                makerAmount,
                takerAmount,
                takerTokenFeeAmount,
                maker,
                taker,
                sender,
                feeRecipient,
                pool,
                expiry,
                salt
            ]
        ]);

        let params = await this.buildTx_v1({
            from: this.web3.eth.defaultAccount,
            to: this.verfify,
            data,
            value: 0
        })
        return params
    }
    // token撤单以及主链币买单撤单交易广播
    async cancel_token(order) {

        let params = await this.cancel_token_tx(order)
        let tx = params && await this.broadTx(params)
        return tx
    }

    async balanceOf(pair) {
        let {
            baseTokenAddress, quoteTokenAddress, isMain,
            baseContractPrecision, quoteContractPrecision
        } = pair
        baseTokenAddress = isMain == 1 ? this.zero : baseTokenAddress
        let base = new ERC20({
            ...this.network,
            contract: baseTokenAddress
        })
        let baseBalance = await base.balanceOf(this.web3.eth.defaultAccount)
        baseBalance = await base.fromAmount(baseBalance)
        let quote = new ERC20({
            ...this.network,
            contract: quoteTokenAddress
        })
        let quoteBalance = await quote.balanceOf(this.web3.eth.defaultAccount)
        quoteBalance = await quote.fromAmount(quoteBalance)
        return {
            baseContractPrecision,
            quoteContractPrecision,
            baseBalance: saveNum(baseBalance, 6),
            quoteBalance: saveNum(quoteBalance, 6),
        }
    }

    // 下单
    async place_order(params = {}) {
        let { pair, price, amount, side, salt, expiry } = params
        let { isMain } = pair
        let order;
        // 获取Gas手续费
        await this.estimate_trade_fee(pair)
        if (isMain == 1 && side == "SELL") {
            // 主链币资产转换
            let assets = await this.main_assets({ pair, price, amount, side, salt, expiry })
            // 下单
            order = await this.ex_order_v1({ pair, price, amount, side, salt, expiry })
            // 同步主链币资产
            await this.sync_main_order({
                orderId: order.orderId,
                txid: assets.transactionHash
            })
        } else {
            // 下单
            order = await this.ex_order_v1({ pair, price, amount, side, salt, expiry })
        }
        return order
    }

    // 取消订单
    async cancel_order(order) {

        let { isMain, side, makerAddress, id } = order
        if (isMain == 1 && side == "SELL") {
            let tx = await this.cancel_sell_main(order)
            if (tx.transactionHash) {
                await this.ex_cancel_mainsell({
                    orderId: id,
                    txid: tx.transactionHash
                })
                return true
            } else {
                return false
            }
        } else {
            await this.ex_cancel_stepone({
                orderId: id,
                account: makerAddress
            })
            let tx = await this.cancel_token(order)
            if (tx.transactionHash) {
                await this.ex_cancel_steptwo({
                    orderId: id,
                    account: makerAddress,
                    txid: tx.transactionHash
                })
                return true
            } else {
                return false
            }
        }


    }
}


module.exports = Dex