let Interact = require("./Interact")
let { abi } = require("./abi/ERC721.json")
let { byteGet,charCompare } = require("./utils")
class ERC721 extends Interact {
    constructor({ provider, account, rpcUrl, privateKey, contract }) {
        super({ provider, account, rpcUrl, privateKey, contract, abi })
        this.maxVal = "999000000000000000000000000000000000000000000000000"
        this.mainToken = "0x0000000000000000000000000000000000000000"
    }

    

    async isApprove(owner,spender) {
        if (!this.isAddress(owner)) {
            console.log("owner 不是合法地址")
            return false
        }
        if (!this.isAddress(spender)) {
            console.log("spender 不是合法地址")
            return false
        }

        let result = await this.buildCall("isApprovedForAll", [
            owner,
            spender
        ])
        return this.web3.utils.hexToNumberString(result) == 1 ? true : false
    }

    

    async approve(spender, power) {
        if (!this.isAddress(spender)) {
            console.log("spender 不是合法地址")
            return false
        }

        let parmas = await this.buildTx("setApprovalForAll", [
            spender,
            power
        ])
        let result = parmas && await this.broadTx(parmas)
        return result
    }

    

    async transferFrom(from, to, tokenId) {
        if (!this.isAddress(from)) {
            console.log("from 不是合法地址")
            return false
        }
        if (!this.isAddress(to)) {
            console.log("to 不是合法地址")
            return false
        }

        // 检查余额
        let isOwner = await this.isOwner(tokenId,this.web3.eth.defaultAccount)
        if(!isOwner) {
            console.log("账户余额不足")
            return false
        }

        let parmas = await this.buildTx("transferFrom", [
            from,
            to,
            tokenId
        ])
        let result = parmas && await this.broadTx(parmas)
        return result
    }

    async ownerOf(tokenId) {
        let owner = await this.buildCall("ownerOf", [
            tokenId
        ])
        return byteGet(owner)
    }

    async isOwner(tokenId,target) {
        let owner = await this.ownerOf(tokenId)
        if(charCompare(target,owner)) {
            return true
        }else {
            return false
        }
    }

    async balanceOf(wallet) {
        if (!this.isAddress(wallet)) {
            console.log("wallet 不是合法地址")
            return false
        }

        let balance = await this.buildCall("balanceOf", [
            wallet
        ])
        return balance ? this.web3.utils.hexToNumberString(balance) : 0
    }

    
}


module.exports = ERC721