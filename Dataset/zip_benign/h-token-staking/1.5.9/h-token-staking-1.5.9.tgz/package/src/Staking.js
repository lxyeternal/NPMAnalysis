let Interact = require("./Interact")
let { abi, bytecode } = require("./abi/tokenStaking.json")
let { byteGet, charCompare, multiplication, division,hexToNumberString } = require("./utils")
let ERC20 = require("./ERC20")
class Staking extends Interact {
    constructor({ provider, account, rpcUrl, privateKey, contract }) {
        super({ provider, account, rpcUrl, privateKey, contract, abi })
        this.mainToken = "0x0000000000000000000000000000000000000000"
    }
    async deploy(owner) {
        try {
            let from = this.web3.eth.defaultAccount
            let gasPrice = await this.GasPrice()
            let result = await this.SC.deploy({
                data: bytecode,
                arguments: [owner]
            }).send({ from, gasPrice });
            return result
        } catch (err) {
            console.log(err)
        }
    }

    async isOwner() {
        let owner = await this.buildCall("owner")
        owner = byteGet(owner)
        let isOwner = charCompare(owner, this.web3.eth.defaultAccount)
        return isOwner
    }

    async manage(method, param = []) {
        let isOwner = await this.isOwner()
        if (isOwner) {
            let parmas = await this.buildTx(method, param)
            let result = parmas && await this.broadTx(parmas)
            return result
        } else {
            console.log("非合约所有者调用")
        }
        return false
    }

    async buildProject({
        projectId, tokens, proportions, sumMin,
        profitToken, profit, pledgeDuration, punish, supply
    }) {
        let decimal = await this.decimals()
        sumMin = multiplication(sumMin,decimal)
        profit = multiplication(profit,decimal)
        punish = multiplication(punish,decimal)
        supply = multiplication(supply,decimal)

        let result = await this.manage("buildProject", [
            projectId, tokens, proportions, sumMin,
            profitToken, profit, pledgeDuration, punish, supply
        ])
        return result
    }

    async setProject({
        projectId, sumMin, profitToken, profit,
        pledgeDuration, punish, status, supply
    }) {
        let decimal = await this.decimals()
        sumMin = multiplication(sumMin,decimal)
        profit = multiplication(profit,decimal)
        punish = multiplication(punish,decimal)
        supply = multiplication(supply,decimal)

        let result = await this.manage("setProject", [
            projectId, sumMin, profitToken, profit,
            pledgeDuration, punish, status, supply
        ])
        return result
    }

    async runStandard(decimals, incomeGap) {
        let result = await this.manage("runStandard", [
            decimals, incomeGap
        ])
        return result
    }

    // 平台提取代币
    async externalToken(token, amount) {
        let tokenItem = new ERC20(Object.assign(this.network,{
            contract:token
        }))
        let realAmount = await tokenItem.toAmount(amount)

        let result = await this.manage("externalToken", [token, realAmount])
        return result
    }
    
    // 质押币种之前 授权币种
    /** 
        list:[
            {
                token:代币合约地址，
                amount:代币数量
            }
        ]
    */
    async beforeDeposit(list) {
        let realAmounts = []
        let result = true
        for(let i = 0; i < list.length; i++) {
            let tokenItem = new ERC20(Object.assign(this.network,{
                contract:list[i].token
            }))
            let realAmount = await tokenItem.toAmount(list[i].amount)
            realAmounts.push(realAmount)
            result = result && await tokenItem.tradeApprove(this.contract,list[i].amount)
        }
        return result
    }

    // 币种质押
    async tokenDeposit(projectId,list) {
        let { tokens,amounts,ethAmount } = await this.paramFormat(list)

        let parmas = await this.buildTx("tokenDeposit", [
            projectId,
            tokens,
            amounts
        ], ethAmount)
        let result = parmas && await this.broadTx(parmas)
        return result
    }

    async extractProfit(depositId,list) {
        let { tokens,amounts } = await this.paramFormat(list)

        let parmas = await this.buildTx("extractProfit", [
            depositId,tokens,amounts
        ])
        let result = parmas && await this.broadTx(parmas)
        return result
    }

    async profitCompute(depositId,list) {
        let { amounts } = await this.paramFormat(list)

        let profit = await this.buildCall("profitCompute", [
            depositId,amounts
        ])
        return profit
    }

    async soldOut(projectId) {
        let sold = await this.buildCall("projectSold", [projectId])
        let decimal = await this.decimals()
        return division(sold,decimal)
    }

    async decimals() {
        let decimal = await this.buildCall("decimals", [])
        return hexToNumberString(decimal)
    }

    async incomeGap() {
        let gap = await this.buildCall("incomeGap", [])
        return gap
    }

    async findProject(id) {
        let detail = await this.buildCall("findProject", [id])
        return detail
    }

    async findDeposit(id) {
        let detail = await this.buildCall("findDeposit", [id])
        return detail
    }
    
    async pledgeCompute(projectId,list) {

        let { tokens,amounts } = await this.paramFormat(list)

        let result = await this.buildCall("pledgeCompute", [
            projectId, tokens, amounts
        ])
        return result
    }

    async paramFormat(list) {
        let ethAmount = 0
        let realAmounts = []
        let tokens = []
        for(let i = 0; i < list.length; i++) {
            let tokenItem = new ERC20(Object.assign(this.network,{
                contract:list[i].token
            }))
            tokens.push(list[i].token)
            let realAmount = await tokenItem.toAmount(list[i].amount)
            realAmounts.push(realAmount)
            if(tokens[i] == this.mainToken) {
                ethAmount += realAmount
            }
        }
        return {
            ethAmount,
            amounts:realAmounts,
            tokens
        }
    }
}


module.exports = Staking