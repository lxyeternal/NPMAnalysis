```
dex功能

import { HDEX } from h-token-staking

this.dex = new HDEX({ 
	rpcUrl:"https://polygon-rpc.com", 
	privateKey,
    chainId:137
})

let { market,ws_url } = await this.dex.public_info_market()
// webSocket 推送文档 https://exchangedocsv2.gitbook.io/open-api-doc/websocket-tui-song

let pair = market["USDT"][2]
let price = 10;
let amount = 0.1;
let side ="BUY";
let expiry = parseInt(new Date().getTime() / 1000) + 60 * 60 * 12;
let salt = new Date().getTime();

<!-- 下单 -->
await this.dex.place_order({
    pair,price,amount,side,expiry,salt
})

let order_list = await this.dex.order_list_v1({
    current:0
})
let order = order_list.orderList[0]

<!-- 取消订单 -->
await this.dex.cancel_order(order)


主链币卖单下单
step1:授权代币给 0x54Ad075b4dFAA9bad2e129668aFdf435b0C676fb
step2:与0x54Ad075b4dFAA9bad2e129668aFdf435b0C676fb交互
step3:请求下单接口(/dex/ex/v1/order)
step4:请求同步主链币资产(/dex/ex/v1/order/syncMainOrder)

主链币买单 token币下单
step1:授权代币给 0x54Ad075b4dFAA9bad2e129668aFdf435b0C676fb
step3:请求下单接口(/dex/ex/v1/order)


主链币卖单取消订单 
step1:0x54Ad075b4dFAA9bad2e129668aFdf435b0C676fb交互
step2:请求取消订单接口(/dex/ex/v1/cancel)


主链币买单 token币取消订单
step1:请求取消订单第一步(/dex/ex/v1/token/cancelStepOne)
step2:0x54Ad075b4dFAA9bad2e129668aFdf435b0C676fb交互
step3:请求取消订单第二步(/dex/ex/v1/token/cancelStepTwo)
```













```
//初始化tokenStaking对象
方式1:
let ts = new HTS({ 
    // provider,
    // account,
    rpcUrl:"https://bsc-testnet.public.blastapi.io", 
    privateKey:"616d8aa*********************",
    contract:"0x069f8D83dc0c8b12C8205d79bCA5EB7a8401eA85"
})

方式2:
let accounts = await ethereum.enable()
let ts = new HTS({ 
    provider:ethereum,
    account:accounts[0],
    contract:"0x1D1BB56c27658841921C3d0f22238388434820f7"
})
```

```
//构建项目 执行角色:owner
let result = await ts.buildProject({
    projectId: 1,    //项目ID 自定义
    tokens: [
        "0x02ab81FdD5bc685228E0951B697Bd64512B9771E", 
        "0x9b436bD3d68cf855FAAD56B1730806b0f167Aa0e", 
        "0x0000000000000000000000000000000000000000", 
        "0xf2DC315D6591599701d4346c7A8E911C24d79740"
    ],    //[质押币种A合约地址,质押币种B合约地址]
    proportions: [24, 25, 1, 50],    //[币种A占比,币种B占比] 整数
    sumMin: 1,    //最小质押量
    profitToken: "0x9b436bD3d68cf855FAAD56B1730806b0f167Aa0e",    //收益币种合约地址
    profit: 0.3,    //收益率
    pledgeDuration: 10,    //收益周期 默认为天数,
    punish: 0.01,    //提前提取收益率
    supply: 100000    //项目发行量
})
```

```
//设置更新项目 执行角色:owner
let result = await ts.setProject({
    projectId: 1,   //项目ID
    sumMin: 1,      //最小质押量
    profitToken: "0x9b436bD3d68cf855FAAD56B1730806b0f167Aa0e",      //收益币种合约地址
    profit: 0.3,    //收益率
    pledgeDuration: 10,     //收益周期
    punish: 0.01,       //提取提取收益率
    status: true,       //项目开关
    supply: 100000      //项目发行量
})
```

```
// 质押代币 执行角色:every
let result = await ts.beforeDeposit({
    tokens:[质押币种A合约地址,质押币种B合约地址], 
    amounts:[币种A数量,币种B数量]
})
let result = await ts.tokenDeposit({ 
    projectId:项目ID, 
    tokens:[质押币种A合约地址,质押币种B合约地址], 
    amounts:[币种A数量,币种B数量] 
},主链币数量默认为0)
```

```
// 提取收益以及返还质押代币 执行角色: belong
let result = await ts.extractProfit({ 
    depositId:质押记录ID,
    tokens:[质押币种A合约地址,质押币种B合约地址], 
    amounts:[币种A数量,币种B数量]
})
```

```
// 部署一个tokenStaking合约 执行角色:every
let result = await ts.deploy(合约所有者钱包地址)
```





