import React from 'react';
import { FlatList, type FlatListProps } from 'react-native';
export interface VisibilityAwareFlatListProps<T = unknown> extends FlatListProps<T> {
    onViewportItemsChanged?: (items: VisibleItem[]) => void;
    viewportItemsChangePercentage?: number;
    triggerOnLayoutChange?: boolean;
    nestedViewportKey?: string;
    as?: any;
}
export type VisibleItem = {
    index: number;
    percentage: number;
    parents?: (string | undefined)[];
};
declare const VisibilityAwareFlatList: <T = unknown>(props: VisibilityAwareFlatListProps<T> & {
    ref?: any;
}, ref: React.ForwardedRef<FlatList<T>>) => React.ReactElement;
export type VisibilityAwareFlatListRef = FlatList & {
    getCurrentVisibleItems(): VisibleItem[];
};
export default VisibilityAwareFlatList;
//# sourceMappingURL=index.d.ts.map