var sinon = require('sinon');
var utils = require('./utils');
var expect = utils.expect

var apiCommands = require('../commands/apis');
var display = require('../lib/display');
var program = require('../programs/api');

describe('konga api', function () {
  var $api, $console, $display;
  beforeEach(() => $display = sinon.mock(display));
  afterEach(() => $display.restore());
  beforeEach(() => $console = sinon.mock(console));
  afterEach(() => $console.restore());
  beforeEach(() => $api = sinon.mock(apiCommands));
  afterEach(() => $api.restore());
  describe('list', function () {
    var args = ['exec', 'bin', 'list'];
    var a = {name: 1};
    var b = {name: 2};
    var apis = [a, b];
    it('should call apis.list and print the result', function () {
      $api.expects('list').callsArgWith(0, null, apis);
      $display.expects('api').withArgs(a).returns('api A')
      $display.expects('api').withArgs(b).returns('api B')
      $console.expects('log').withArgs('api A')
      $console.expects('log').withArgs('api B')

      program.parse(args);

      $api.verify();
      $display.verify()
      $console.verify()
    });
  })

  describe('api remove', function () {
  });
})
