/**
 * @license agx-typeahead
 * MIT license
 */
import { ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, NgModule, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JsonpModule } from '@angular/http';
import { HttpClient, HttpClientModule, HttpParams } from '@angular/common/http';
import { Subject, of } from 'rxjs';
import { concat, debounceTime, distinctUntilChanged, filter, map, switchMap, tap } from 'rxjs/operators';
import { __assign } from 'tslib';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/** @enum {number} */
var Key = {
    Backspace: 8,
    Tab: 9,
    Enter: 13,
    Shift: 16,
    Escape: 27,
    ArrowLeft: 37,
    ArrowRight: 39,
    ArrowUp: 38,
    ArrowDown: 40,
    // http://unixpapa.com/js/key.html
    MacCommandLeft: 91,
    MacCommandRight: 93,
    MacCommandFirefox: 224,
};
Key[Key.Backspace] = "Backspace";
Key[Key.Tab] = "Tab";
Key[Key.Enter] = "Enter";
Key[Key.Shift] = "Shift";
Key[Key.Escape] = "Escape";
Key[Key.ArrowLeft] = "ArrowLeft";
Key[Key.ArrowRight] = "ArrowRight";
Key[Key.ArrowUp] = "ArrowUp";
Key[Key.ArrowDown] = "ArrowDown";
Key[Key.MacCommandLeft] = "MacCommandLeft";
Key[Key.MacCommandRight] = "MacCommandRight";
Key[Key.MacCommandFirefox] = "MacCommandFirefox";

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} keyCode
 * @return {?}
 */
function validateNonCharKeyCode(keyCode) {
    return [
        Key.Enter,
        Key.Tab,
        Key.Shift,
        Key.ArrowLeft,
        Key.ArrowUp,
        Key.ArrowRight,
        Key.ArrowDown,
        Key.MacCommandLeft,
        Key.MacCommandRight,
        Key.MacCommandFirefox
    ].every(function (codeKey) { return codeKey !== keyCode; });
}
/**
 * @param {?} keyCode
 * @return {?}
 */
function validateArrowKeys(keyCode) {
    return keyCode === Key.ArrowDown || keyCode === Key.ArrowUp;
}
/**
 * @param {?} index
 * @param {?} currentIndex
 * @return {?}
 */
function isIndexActive(index, currentIndex) {
    return index === currentIndex;
}
/**
 * @param {?} event
 * @return {?}
 */
function isEnterKey(event) {
    return event.keyCode === Key.Enter;
}
/**
 * @param {?} event
 * @return {?}
 */
function isEscapeKey(event) {
    return event.keyCode === Key.Escape;
}
/**
 * @param {?} query
 * @param {?=} queryParamKey
 * @param {?=} customParams
 * @return {?}
 */
function createParamsForQuery(query, queryParamKey, customParams) {
    if (queryParamKey === void 0) { queryParamKey = 'q'; }
    if (customParams === void 0) { customParams = {}; }
    var /** @type {?} */ searchParams = __assign((_a = {}, _a[queryParamKey] = query, _a), customParams);
    // tslint:disable-next-line
    var /** @type {?} */ setParam = function (acc, param) {
        return acc.set(param, searchParams[param]);
    };
    var /** @type {?} */ params = Object.keys(searchParams).reduce(setParam, new HttpParams());
    return params;
    var _a;
}
/**
 * @param {?=} method
 * @return {?}
 */
function resolveApiMethod(method) {
    if (method === void 0) { method = ''; }
    var /** @type {?} */ isMethodValid = [
        'get',
        'post',
        'put',
        'delete',
        'patch',
        'request'
    ].some(function (methodName) { return method === methodName; });
    var /** @type {?} */ apiMethod = isMethodValid ? method : 'get';
    return apiMethod;
}
var NO_INDEX = -1;
/**
 * @param {?} currentIndex
 * @param {?} stepUp
 * @param {?=} listLength
 * @return {?}
 */
function resolveNextIndex(currentIndex, stepUp, listLength) {
    if (listLength === void 0) { listLength = 10; }
    var /** @type {?} */ step = stepUp ? 1 : -1;
    var /** @type {?} */ topLimit = listLength - 1;
    var /** @type {?} */ bottomLimit = NO_INDEX;
    var /** @type {?} */ currentResultIndex = currentIndex + step;
    var /** @type {?} */ resultIndex = currentResultIndex;
    if (currentResultIndex === topLimit + 1) {
        resultIndex = bottomLimit;
    }
    if (currentResultIndex === bottomLimit - 1) {
        resultIndex = topLimit;
    }
    return resultIndex;
}
/**
 * @param {?} response
 * @return {?}
 */
function toJsonpSingleResult(response) {
    return response[1];
}
/**
 * @param {?} results
 * @return {?}
 */
function toJsonpFinalResults(results) {
    return results.map(function (result) { return result[0]; });
}
/**
 * @param {?} query
 * @return {?}
 */
function hasCharacters(query) {
    return query.length > 0;
}
/**
 * @param {?} e
 * @return {?}
 */
function toFormControlValue(e) {
    return e.target.value;
}
/**
 * @param {?} item
 * @param {?} fieldsToExtract
 * @param {?=} caseSensitive
 * @return {?}
 */
function resolveItemValue(item, fieldsToExtract, caseSensitive) {
    if (caseSensitive === void 0) { caseSensitive = false; }
    var /** @type {?} */ newItem = item;
    if (!item.hasOwnProperty('length')) {
        var /** @type {?} */ fields = !fieldsToExtract.length
            ? Object.keys(item)
            : fieldsToExtract;
        newItem = fields.reduce(function (acc, cur) { return "" + acc + item[cur]; }, '');
    }
    return caseSensitive ? newItem : newItem.toLowerCase();
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var AgxTypeAheadComponent = (function () {
    function AgxTypeAheadComponent(element, viewContainer, http$$1, cdr) {
        this.element = element;
        this.viewContainer = viewContainer;
        this.http = http$$1;
        this.cdr = cdr;
        this.showSuggestions = false;
        this.results = [];
        this.taUrl = '';
        this.taParams = {};
        this.taQueryParam = 'q';
        this.taApi = 'jsonp';
        this.taApiMethod = 'get';
        this.taList = [];
        this.taListItemField = [];
        this.taListItemLabel = '';
        this.taDebounce = 300;
        this.taAllowEmpty = false;
        this.taCaseSensitive = false;
        this.taDisplayOnFocus = false;
        this.taSelected = new EventEmitter();
        this.suggestionIndex = 0;
        this.subscriptions = [];
        this.activeResult = '';
        this.searchQuery = '';
        this.selectedItem = {};
        this.resultsAsItems = [];
        this.keydown$ = new Subject();
        this.keyup$ = new Subject();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.handleEsc = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        if (isEscapeKey(event)) {
            this.hideSuggestions();
            event.preventDefault();
        }
        this.keydown$.next(event);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.onkeyup = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        event.preventDefault();
        event.stopPropagation();
        this.keyup$.next(event);
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.onClick = /**
     * @return {?}
     */
    function () {
        if (this.taDisplayOnFocus) {
            this.displaySuggestions();
        }
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.filterEnterEvent(this.keydown$);
        this.listenAndSuggest(this.keyup$);
        this.navigateWithArrows(this.keydown$);
        this.renderTemplate();
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        this.keydown$.complete();
        this.keyup$.complete();
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.renderTemplate = /**
     * @return {?}
     */
    function () {
        this.viewContainer.createEmbeddedView(this.suggestionsTplRef);
        this.cdr.markForCheck();
    };
    /**
     * @param {?} obs
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.listenAndSuggest = /**
     * @param {?} obs
     * @return {?}
     */
    function (obs) {
        var _this = this;
        obs
            .pipe(filter(function (e) { return validateNonCharKeyCode(e.keyCode); }), map(toFormControlValue), debounceTime(this.taDebounce), concat(), distinctUntilChanged(), filter(function (query) { return _this.taAllowEmpty || hasCharacters(query); }), tap(function (query) { return (_this.searchQuery = query); }), switchMap(function (query) { return _this.suggest(query); }))
            .subscribe(function (results) {
            _this.assignResults(results);
            // this.updateIndex(Key.ArrowDown);
            // this.updateIndex(Key.ArrowDown);
            _this.displaySuggestions();
        });
    };
    /**
     * @param {?} results
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.assignResults = /**
     * @param {?} results
     * @return {?}
     */
    function (results) {
        var /** @type {?} */ labelForDisplay = this.taListItemLabel;
        this.resultsAsItems = results;
        this.results = results.map(function (item) { return (labelForDisplay ? item[labelForDisplay] : item); });
        this.suggestionIndex = NO_INDEX;
        if (!results || !results.length) {
            this.activeResult = this.searchQuery;
        }
    };
    /**
     * @param {?} elementObs
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.filterEnterEvent = /**
     * @param {?} elementObs
     * @return {?}
     */
    function (elementObs) {
        var _this = this;
        elementObs.pipe(filter(isEnterKey)).subscribe(function (event) {
            _this.handleSelectSuggestion(_this.activeResult);
        });
    };
    /**
     * @param {?} elementObs
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.navigateWithArrows = /**
     * @param {?} elementObs
     * @return {?}
     */
    function (elementObs) {
        var _this = this;
        elementObs
            .pipe(filter(function (e) { return validateArrowKeys(e.keyCode); }), map(function (e) { return e.keyCode; }))
            .subscribe(function (keyCode) {
            _this.updateIndex(keyCode);
            _this.displaySuggestions();
        });
    };
    /**
     * @param {?} keyCode
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.updateIndex = /**
     * @param {?} keyCode
     * @return {?}
     */
    function (keyCode) {
        this.suggestionIndex = resolveNextIndex(this.suggestionIndex, keyCode === Key.ArrowDown, this.results.length);
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.displaySuggestions = /**
     * @return {?}
     */
    function () {
        this.showSuggestions = true;
        this.cdr.markForCheck();
    };
    /**
     * @param {?} query
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.suggest = /**
     * @param {?} query
     * @return {?}
     */
    function (query) {
        return this.taList.length
            ? this.createListSource(this.taList, query)
            : this.request(query);
    };
    /**
     * peforms a jsonp/http request to search with query and params
     * @param query the query to search from the remote source
     */
    /**
     * peforms a jsonp/http request to search with query and params
     * @param {?} query the query to search from the remote source
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.request = /**
     * peforms a jsonp/http request to search with query and params
     * @param {?} query the query to search from the remote source
     * @return {?}
     */
    function (query) {
        var /** @type {?} */ url = this.taUrl;
        var /** @type {?} */ searchConfig = createParamsForQuery(query, this.taQueryParam, this.taParams);
        var /** @type {?} */ options = {
            params: searchConfig
        };
        var /** @type {?} */ isJsonpApi = this.taApi === 'jsonp';
        return isJsonpApi
            ? this.requestJsonp(url, options, this.taCallbackParamValue)
            : this.requestHttp(url, options);
    };
    /**
     * @param {?} url
     * @param {?} options
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.requestHttp = /**
     * @param {?} url
     * @param {?} options
     * @return {?}
     */
    function (url, options) {
        var /** @type {?} */ apiMethod = resolveApiMethod(this.taApiMethod);
        return this.http[apiMethod](url, options);
    };
    /**
     * @param {?} url
     * @param {?} options
     * @param {?=} callback
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.requestJsonp = /**
     * @param {?} url
     * @param {?} options
     * @param {?=} callback
     * @return {?}
     */
    function (url, options, callback) {
        if (callback === void 0) { callback = 'callback'; }
        var /** @type {?} */ params = options.params.toString();
        return this.http.jsonp(url + "?" + params, callback).pipe(map(toJsonpSingleResult), map(toJsonpFinalResults));
    };
    /**
     * @param {?} index
     * @param {?} result
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.markIsActive = /**
     * @param {?} index
     * @param {?} result
     * @return {?}
     */
    function (index, result) {
        var /** @type {?} */ isActive = isIndexActive(index, this.suggestionIndex);
        if (isActive) {
            this.activeResult = result;
        }
        return isActive;
    };
    /**
     * @param {?} suggestion
     * @param {?} index
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.handleSelectionClick = /**
     * @param {?} suggestion
     * @param {?} index
     * @return {?}
     */
    function (suggestion, index) {
        this.suggestionIndex = index;
        this.handleSelectSuggestion(suggestion);
    };
    /**
     * @param {?} suggestion
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.handleSelectSuggestion = /**
     * @param {?} suggestion
     * @return {?}
     */
    function (suggestion) {
        var /** @type {?} */ result = this.resultsAsItems.length
            ? this.resultsAsItems[this.suggestionIndex]
            : suggestion;
        this.hideSuggestions();
        var /** @type {?} */ resolvedResult = this.suggestionIndex === NO_INDEX ? this.searchQuery : result;
        this.taSelected.emit(resolvedResult);
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.hideSuggestions = /**
     * @return {?}
     */
    function () {
        this.showSuggestions = false;
    };
    /**
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.hasItemTemplate = /**
     * @return {?}
     */
    function () {
        return this.taItemTpl !== undefined;
    };
    /**
     * @param {?} list
     * @param {?} query
     * @return {?}
     */
    AgxTypeAheadComponent.prototype.createListSource = /**
     * @param {?} list
     * @param {?} query
     * @return {?}
     */
    function (list, query) {
        var _this = this;
        var /** @type {?} */ sanitizedQuery = this.taCaseSensitive ? query : query.toLowerCase();
        var /** @type {?} */ fieldsToExtract = this.taListItemField;
        return of(list.filter(function (item) {
            return resolveItemValue(item, fieldsToExtract, _this.taCaseSensitive).includes(sanitizedQuery);
        }));
    };
    AgxTypeAheadComponent.decorators = [
        { type: Component, args: [{
                    selector: '[agxTypeahead]',
                    styles: [
                        "\n      .ta-results {\n        position: absolute;\n      }\n      .ta-backdrop {\n        bottom: 0;\n        left: 0;\n        position: fixed;\n        right: 0;\n        top: 0;\n        z-index: 1;\n      }\n      .ta-item {\n        position: relative;\n        z-index: 2;\n        display: block;\n      }\n    "
                    ],
                    template: "\n  <ng-template #suggestionsTplRef>\n  <section class=\"ta-results list-group\" *ngIf=\"showSuggestions\">\n    <div class=\"ta-backdrop\" (click)=\"hideSuggestions()\"></div>\n    <button type=\"button\" class=\"ta-item list-group-item\" style=\"width: 350px; padding: 5px; text-align: left;\"\n      *ngFor=\"let result of results; let i = index;\"\n      [class.active]=\"markIsActive(i, result)\"\n      (click)=\"handleSelectionClick(result, i)\">\n      <span *ngIf=\"!taItemTpl\"><i class=\"fa fa-search\"></i> {{ result }}</span>\n      <ng-template\n        [ngTemplateOutlet]=\"taItemTpl\"\n        [ngTemplateOutletContext]=\"{ $implicit: {result: result, index: i} }\"\n      ></ng-template>\n    </button>\n  </section>\n  </ng-template>\n  "
                },] },
    ];
    /** @nocollapse */
    AgxTypeAheadComponent.ctorParameters = function () { return [
        { type: ElementRef, },
        { type: ViewContainerRef, },
        { type: HttpClient, },
        { type: ChangeDetectorRef, },
    ]; };
    AgxTypeAheadComponent.propDecorators = {
        "taItemTpl": [{ type: Input },],
        "taUrl": [{ type: Input },],
        "taParams": [{ type: Input },],
        "taQueryParam": [{ type: Input },],
        "taCallbackParamValue": [{ type: Input },],
        "taApi": [{ type: Input },],
        "taApiMethod": [{ type: Input },],
        "taList": [{ type: Input },],
        "taListItemField": [{ type: Input },],
        "taListItemLabel": [{ type: Input },],
        "taDebounce": [{ type: Input },],
        "taAllowEmpty": [{ type: Input },],
        "taCaseSensitive": [{ type: Input },],
        "taDisplayOnFocus": [{ type: Input },],
        "taSelected": [{ type: Output },],
        "suggestionsTplRef": [{ type: ViewChild, args: ['suggestionsTplRef',] },],
        "handleEsc": [{ type: HostListener, args: ['keydown', ['$event'],] },],
        "onkeyup": [{ type: HostListener, args: ['keyup', ['$event'],] },],
        "onClick": [{ type: HostListener, args: ['click',] },],
    };
    return AgxTypeAheadComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var AgxTypeaheadModule = (function () {
    function AgxTypeaheadModule() {
    }
    AgxTypeaheadModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [AgxTypeAheadComponent],
                    exports: [AgxTypeAheadComponent, CommonModule],
                    imports: [CommonModule, HttpClientModule, JsonpModule],
                    providers: []
                },] },
    ];
    /** @nocollapse */
    AgxTypeaheadModule.ctorParameters = function () { return []; };
    return AgxTypeaheadModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Angular library starter.
 * Build an Angular library compatible with AoT compilation & Tree shaking
 * Copyright Roberto Simonetti.
 * MIT license.
 * https://github.com/robisim74/angular-library-starter
 */
/**
 * Entry point for all public APIs of the package.
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { AgxTypeaheadModule, AgxTypeAheadComponent as ɵa };
//# sourceMappingURL=agx-typeahead.js.map
