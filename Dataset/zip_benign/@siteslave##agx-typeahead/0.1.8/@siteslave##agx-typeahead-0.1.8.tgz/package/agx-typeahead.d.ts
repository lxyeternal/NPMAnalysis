/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { AgxTypeAheadComponent as ɵa } from './src/modules/agx-typeahead.component';
