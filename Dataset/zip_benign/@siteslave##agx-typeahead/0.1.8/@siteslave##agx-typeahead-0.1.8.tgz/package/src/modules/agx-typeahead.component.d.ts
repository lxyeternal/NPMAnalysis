import { HttpClient } from '@angular/common/http';
import { ChangeDetectorRef, ElementRef, EventEmitter, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Observable, Subject } from 'rxjs';
export declare class AgxTypeAheadComponent implements OnInit, OnDestroy {
    private element;
    private viewContainer;
    private http;
    private cdr;
    showSuggestions: boolean;
    results: string[];
    taItemTpl: TemplateRef<any>;
    taUrl: string;
    taParams: {};
    taQueryParam: string;
    taCallbackParamValue: any;
    taApi: string;
    taApiMethod: string;
    taList: never[];
    taListItemField: never[];
    taListItemLabel: string;
    taDebounce: number;
    taAllowEmpty: boolean;
    taCaseSensitive: boolean;
    taDisplayOnFocus: boolean;
    taSelected: EventEmitter<any>;
    suggestionsTplRef: TemplateRef<any>;
    private suggestionIndex;
    private subscriptions;
    private activeResult;
    private searchQuery;
    private selectedItem;
    private resultsAsItems;
    private keydown$;
    private keyup$;
    constructor(element: ElementRef, viewContainer: ViewContainerRef, http: HttpClient, cdr: ChangeDetectorRef);
    handleEsc(event: KeyboardEvent): void;
    onkeyup(event: KeyboardEvent): void;
    onClick(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    renderTemplate(): void;
    listenAndSuggest(obs: Subject<KeyboardEvent>): void;
    assignResults(results: any[]): void;
    filterEnterEvent(elementObs: Subject<KeyboardEvent>): void;
    navigateWithArrows(elementObs: Subject<KeyboardEvent>): void;
    updateIndex(keyCode: number): void;
    displaySuggestions(): void;
    suggest(query: string): any;
    /**
     * peforms a jsonp/http request to search with query and params
     * @param query the query to search from the remote source
     */
    request(query: string): any;
    requestHttp(url: string, options: any): any;
    requestJsonp(url: any, options: any, callback?: string): Observable<any[]>;
    markIsActive(index: number, result: string): boolean;
    handleSelectionClick(suggestion: string, index: number): void;
    handleSelectSuggestion(suggestion: string): void;
    hideSuggestions(): void;
    hasItemTemplate(): boolean;
    createListSource(list: any[], query: string): Observable<string[]>;
}
