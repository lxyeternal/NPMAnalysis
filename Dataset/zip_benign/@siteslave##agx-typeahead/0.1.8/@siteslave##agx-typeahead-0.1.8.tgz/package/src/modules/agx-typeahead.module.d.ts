export declare class AgxTypeaheadModule {
}
