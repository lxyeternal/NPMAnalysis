/**
 * @license agx-typeahead
 * MIT license
 */
import { ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, NgModule, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JsonpModule } from '@angular/http';
import { HttpClient, HttpClientModule, HttpParams } from '@angular/common/http';
import { Subject, of } from 'rxjs';
import { concat, debounceTime, distinctUntilChanged, filter, map, switchMap, tap } from 'rxjs/operators';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/** @enum {number} */
const Key = {
    Backspace: 8,
    Tab: 9,
    Enter: 13,
    Shift: 16,
    Escape: 27,
    ArrowLeft: 37,
    ArrowRight: 39,
    ArrowUp: 38,
    ArrowDown: 40,
    // http://unixpapa.com/js/key.html
    MacCommandLeft: 91,
    MacCommandRight: 93,
    MacCommandFirefox: 224,
};
Key[Key.Backspace] = "Backspace";
Key[Key.Tab] = "Tab";
Key[Key.Enter] = "Enter";
Key[Key.Shift] = "Shift";
Key[Key.Escape] = "Escape";
Key[Key.ArrowLeft] = "ArrowLeft";
Key[Key.ArrowRight] = "ArrowRight";
Key[Key.ArrowUp] = "ArrowUp";
Key[Key.ArrowDown] = "ArrowDown";
Key[Key.MacCommandLeft] = "MacCommandLeft";
Key[Key.MacCommandRight] = "MacCommandRight";
Key[Key.MacCommandFirefox] = "MacCommandFirefox";

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * @param {?} keyCode
 * @return {?}
 */
function validateNonCharKeyCode(keyCode) {
    return [
        Key.Enter,
        Key.Tab,
        Key.Shift,
        Key.ArrowLeft,
        Key.ArrowUp,
        Key.ArrowRight,
        Key.ArrowDown,
        Key.MacCommandLeft,
        Key.MacCommandRight,
        Key.MacCommandFirefox
    ].every(codeKey => codeKey !== keyCode);
}
/**
 * @param {?} keyCode
 * @return {?}
 */
function validateArrowKeys(keyCode) {
    return keyCode === Key.ArrowDown || keyCode === Key.ArrowUp;
}
/**
 * @param {?} index
 * @param {?} currentIndex
 * @return {?}
 */
function isIndexActive(index, currentIndex) {
    return index === currentIndex;
}
/**
 * @param {?} event
 * @return {?}
 */
function isEnterKey(event) {
    return event.keyCode === Key.Enter;
}
/**
 * @param {?} event
 * @return {?}
 */
function isEscapeKey(event) {
    return event.keyCode === Key.Escape;
}
/**
 * @param {?} query
 * @param {?=} queryParamKey
 * @param {?=} customParams
 * @return {?}
 */
function createParamsForQuery(query, queryParamKey = 'q', customParams = {}) {
    const /** @type {?} */ searchParams = Object.assign({ [queryParamKey]: query }, customParams);
    // tslint:disable-next-line
    const /** @type {?} */ setParam = (acc, param) => acc.set(param, searchParams[param]);
    const /** @type {?} */ params = Object.keys(searchParams).reduce(setParam, new HttpParams());
    return params;
}
/**
 * @param {?=} method
 * @return {?}
 */
function resolveApiMethod(method = '') {
    const /** @type {?} */ isMethodValid = [
        'get',
        'post',
        'put',
        'delete',
        'patch',
        'request'
    ].some(methodName => method === methodName);
    const /** @type {?} */ apiMethod = isMethodValid ? method : 'get';
    return apiMethod;
}
const NO_INDEX = -1;
/**
 * @param {?} currentIndex
 * @param {?} stepUp
 * @param {?=} listLength
 * @return {?}
 */
function resolveNextIndex(currentIndex, stepUp, listLength = 10) {
    const /** @type {?} */ step = stepUp ? 1 : -1;
    const /** @type {?} */ topLimit = listLength - 1;
    const /** @type {?} */ bottomLimit = NO_INDEX;
    const /** @type {?} */ currentResultIndex = currentIndex + step;
    let /** @type {?} */ resultIndex = currentResultIndex;
    if (currentResultIndex === topLimit + 1) {
        resultIndex = bottomLimit;
    }
    if (currentResultIndex === bottomLimit - 1) {
        resultIndex = topLimit;
    }
    return resultIndex;
}
/**
 * @param {?} response
 * @return {?}
 */
function toJsonpSingleResult(response) {
    return response[1];
}
/**
 * @param {?} results
 * @return {?}
 */
function toJsonpFinalResults(results) {
    return results.map((result) => result[0]);
}
/**
 * @param {?} query
 * @return {?}
 */
function hasCharacters(query) {
    return query.length > 0;
}
/**
 * @param {?} e
 * @return {?}
 */
function toFormControlValue(e) {
    return e.target.value;
}
/**
 * @param {?} item
 * @param {?} fieldsToExtract
 * @param {?=} caseSensitive
 * @return {?}
 */
function resolveItemValue(item, fieldsToExtract, caseSensitive = false) {
    let /** @type {?} */ newItem = item;
    if (!item.hasOwnProperty('length')) {
        const /** @type {?} */ fields = !fieldsToExtract.length
            ? Object.keys(item)
            : fieldsToExtract;
        newItem = fields.reduce((acc, cur) => `${acc}${item[cur]}`, '');
    }
    return caseSensitive ? newItem : newItem.toLowerCase();
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class AgxTypeAheadComponent {
    /**
     * @param {?} element
     * @param {?} viewContainer
     * @param {?} http
     * @param {?} cdr
     */
    constructor(element, viewContainer, http$$1, cdr) {
        this.element = element;
        this.viewContainer = viewContainer;
        this.http = http$$1;
        this.cdr = cdr;
        this.showSuggestions = false;
        this.results = [];
        this.taUrl = '';
        this.taParams = {};
        this.taQueryParam = 'q';
        this.taApi = 'jsonp';
        this.taApiMethod = 'get';
        this.taList = [];
        this.taListItemField = [];
        this.taListItemLabel = '';
        this.taDebounce = 300;
        this.taAllowEmpty = false;
        this.taCaseSensitive = false;
        this.taDisplayOnFocus = false;
        this.taSelected = new EventEmitter();
        this.suggestionIndex = 0;
        this.subscriptions = [];
        this.activeResult = '';
        this.searchQuery = '';
        this.selectedItem = {};
        this.resultsAsItems = [];
        this.keydown$ = new Subject();
        this.keyup$ = new Subject();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    handleEsc(event) {
        if (isEscapeKey(event)) {
            this.hideSuggestions();
            event.preventDefault();
        }
        this.keydown$.next(event);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onkeyup(event) {
        event.preventDefault();
        event.stopPropagation();
        this.keyup$.next(event);
    }
    /**
     * @return {?}
     */
    onClick() {
        if (this.taDisplayOnFocus) {
            this.displaySuggestions();
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.filterEnterEvent(this.keydown$);
        this.listenAndSuggest(this.keyup$);
        this.navigateWithArrows(this.keydown$);
        this.renderTemplate();
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.keydown$.complete();
        this.keyup$.complete();
    }
    /**
     * @return {?}
     */
    renderTemplate() {
        this.viewContainer.createEmbeddedView(this.suggestionsTplRef);
        this.cdr.markForCheck();
    }
    /**
     * @param {?} obs
     * @return {?}
     */
    listenAndSuggest(obs) {
        obs
            .pipe(filter((e) => validateNonCharKeyCode(e.keyCode)), map(toFormControlValue), debounceTime(this.taDebounce), concat(), distinctUntilChanged(), filter((query) => this.taAllowEmpty || hasCharacters(query)), tap((query) => (this.searchQuery = query)), switchMap((query) => this.suggest(query)))
            .subscribe((results) => {
            this.assignResults(results);
            // this.updateIndex(Key.ArrowDown);
            this.displaySuggestions();
        });
    }
    /**
     * @param {?} results
     * @return {?}
     */
    assignResults(results) {
        const /** @type {?} */ labelForDisplay = this.taListItemLabel;
        this.resultsAsItems = results;
        this.results = results.map((item) => (labelForDisplay ? item[labelForDisplay] : item));
        this.suggestionIndex = NO_INDEX;
        if (!results || !results.length) {
            this.activeResult = this.searchQuery;
        }
    }
    /**
     * @param {?} elementObs
     * @return {?}
     */
    filterEnterEvent(elementObs) {
        elementObs.pipe(filter(isEnterKey)).subscribe((event) => {
            this.handleSelectSuggestion(this.activeResult);
        });
    }
    /**
     * @param {?} elementObs
     * @return {?}
     */
    navigateWithArrows(elementObs) {
        elementObs
            .pipe(filter((e) => validateArrowKeys(e.keyCode)), map((e) => e.keyCode))
            .subscribe((keyCode) => {
            this.updateIndex(keyCode);
            this.displaySuggestions();
        });
    }
    /**
     * @param {?} keyCode
     * @return {?}
     */
    updateIndex(keyCode) {
        this.suggestionIndex = resolveNextIndex(this.suggestionIndex, keyCode === Key.ArrowDown, this.results.length);
    }
    /**
     * @return {?}
     */
    displaySuggestions() {
        this.showSuggestions = true;
        this.cdr.markForCheck();
    }
    /**
     * @param {?} query
     * @return {?}
     */
    suggest(query) {
        return this.taList.length
            ? this.createListSource(this.taList, query)
            : this.request(query);
    }
    /**
     * peforms a jsonp/http request to search with query and params
     * @param {?} query the query to search from the remote source
     * @return {?}
     */
    request(query) {
        const /** @type {?} */ url = this.taUrl;
        const /** @type {?} */ searchConfig = createParamsForQuery(query, this.taQueryParam, this.taParams);
        const /** @type {?} */ options = {
            params: searchConfig
        };
        const /** @type {?} */ isJsonpApi = this.taApi === 'jsonp';
        return isJsonpApi
            ? this.requestJsonp(url, options, this.taCallbackParamValue)
            : this.requestHttp(url, options);
    }
    /**
     * @param {?} url
     * @param {?} options
     * @return {?}
     */
    requestHttp(url, options) {
        const /** @type {?} */ apiMethod = resolveApiMethod(this.taApiMethod);
        return this.http[apiMethod](url, options);
    }
    /**
     * @param {?} url
     * @param {?} options
     * @param {?=} callback
     * @return {?}
     */
    requestJsonp(url, options, callback = 'callback') {
        const /** @type {?} */ params = options.params.toString();
        return this.http.jsonp(`${url}?${params}`, callback).pipe(map(toJsonpSingleResult), map(toJsonpFinalResults));
    }
    /**
     * @param {?} index
     * @param {?} result
     * @return {?}
     */
    markIsActive(index, result) {
        const /** @type {?} */ isActive = isIndexActive(index, this.suggestionIndex);
        if (isActive) {
            this.activeResult = result;
        }
        return isActive;
    }
    /**
     * @param {?} suggestion
     * @param {?} index
     * @return {?}
     */
    handleSelectionClick(suggestion, index) {
        this.suggestionIndex = index;
        this.handleSelectSuggestion(suggestion);
    }
    /**
     * @param {?} suggestion
     * @return {?}
     */
    handleSelectSuggestion(suggestion) {
        const /** @type {?} */ result = this.resultsAsItems.length
            ? this.resultsAsItems[this.suggestionIndex]
            : suggestion;
        this.hideSuggestions();
        const /** @type {?} */ resolvedResult = this.suggestionIndex === NO_INDEX ? this.searchQuery : result;
        this.taSelected.emit(resolvedResult);
    }
    /**
     * @return {?}
     */
    hideSuggestions() {
        this.showSuggestions = false;
    }
    /**
     * @return {?}
     */
    hasItemTemplate() {
        return this.taItemTpl !== undefined;
    }
    /**
     * @param {?} list
     * @param {?} query
     * @return {?}
     */
    createListSource(list, query) {
        const /** @type {?} */ sanitizedQuery = this.taCaseSensitive ? query : query.toLowerCase();
        const /** @type {?} */ fieldsToExtract = this.taListItemField;
        return of(list.filter((item) => {
            return resolveItemValue(item, fieldsToExtract, this.taCaseSensitive).includes(sanitizedQuery);
        }));
    }
}
AgxTypeAheadComponent.decorators = [
    { type: Component, args: [{
                selector: '[agxTypeahead]',
                styles: [
                    `
      .ta-results {
        position: absolute;
      }
      .ta-backdrop {
        bottom: 0;
        left: 0;
        position: fixed;
        right: 0;
        top: 0;
        z-index: 1;
      }
      .ta-item {
        position: relative;
        z-index: 2;
        display: block;
      }
    `
                ],
                template: `
  <ng-template #suggestionsTplRef>
  <section class="ta-results list-group" *ngIf="showSuggestions">
    <div class="ta-backdrop" (click)="hideSuggestions()"></div>
    <button type="button" class="ta-item list-group-item" style="width: 350px; padding: 5px; text-align: left;"
      *ngFor="let result of results; let i = index;"
      [class.active]="markIsActive(i, result)"
      (click)="handleSelectionClick(result, i)">
      <span *ngIf="!taItemTpl"><i class="fa fa-search"></i> {{ result }}</span>
      <ng-template
        [ngTemplateOutlet]="taItemTpl"
        [ngTemplateOutletContext]="{ $implicit: {result: result, index: i} }"
      ></ng-template>
    </button>
  </section>
  </ng-template>
  `
            },] },
];
/** @nocollapse */
AgxTypeAheadComponent.ctorParameters = () => [
    { type: ElementRef, },
    { type: ViewContainerRef, },
    { type: HttpClient, },
    { type: ChangeDetectorRef, },
];
AgxTypeAheadComponent.propDecorators = {
    "taItemTpl": [{ type: Input },],
    "taUrl": [{ type: Input },],
    "taParams": [{ type: Input },],
    "taQueryParam": [{ type: Input },],
    "taCallbackParamValue": [{ type: Input },],
    "taApi": [{ type: Input },],
    "taApiMethod": [{ type: Input },],
    "taList": [{ type: Input },],
    "taListItemField": [{ type: Input },],
    "taListItemLabel": [{ type: Input },],
    "taDebounce": [{ type: Input },],
    "taAllowEmpty": [{ type: Input },],
    "taCaseSensitive": [{ type: Input },],
    "taDisplayOnFocus": [{ type: Input },],
    "taSelected": [{ type: Output },],
    "suggestionsTplRef": [{ type: ViewChild, args: ['suggestionsTplRef',] },],
    "handleEsc": [{ type: HostListener, args: ['keydown', ['$event'],] },],
    "onkeyup": [{ type: HostListener, args: ['keyup', ['$event'],] },],
    "onClick": [{ type: HostListener, args: ['click',] },],
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class AgxTypeaheadModule {
}
AgxTypeaheadModule.decorators = [
    { type: NgModule, args: [{
                declarations: [AgxTypeAheadComponent],
                exports: [AgxTypeAheadComponent, CommonModule],
                imports: [CommonModule, HttpClientModule, JsonpModule],
                providers: []
            },] },
];
/** @nocollapse */
AgxTypeaheadModule.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Angular library starter.
 * Build an Angular library compatible with AoT compilation & Tree shaking
 * Copyright Roberto Simonetti.
 * MIT license.
 * https://github.com/robisim74/angular-library-starter
 */
/**
 * Entry point for all public APIs of the package.
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */

export { AgxTypeaheadModule, AgxTypeAheadComponent as ɵa };
//# sourceMappingURL=agx-typeahead.js.map
