declare const image: import("lit-html").TemplateResult<1>;
export default image;
