import { LitElement, CSSResult, TemplateResult, PropertyValues } from 'lit';
import QuickSearchEntry from './models/quick-search-entry';
import './quick-search';
/**
 * An element to render a search bar with an expandable quick search area
 *
 * @export
 * @class ExpandableSearchBar
 * @extends {LitElement}
 */
export default class ExpandableSearchBar extends LitElement {
    isOpen: boolean;
    showsDisclosure: boolean;
    searchTerm: string;
    quickSearches: QuickSearchEntry[];
    /**
     * LitElement lifecycle main render method
     *
     * @returns {TemplateResult}
     * @memberof ExpandableSearchBar
     */
    render(): TemplateResult;
    /**
     * Update the DOM element after the value of `this.searchTerm` changes
     *
     * @memberof ExpandableSearchBar
     */
    updated(props: PropertyValues): void;
    /**
     * Called when then user clicks the X button to clear the search
     *
     * @private
     * @memberof ExpandableSearchBar
     */
    private clearSearch;
    /**
     * Called when the user changes the input in the search bar.
     * Emits an `inputchange` event and, if needed, an
     * `enterKeyPressed` event.
     *
     * @private
     * @param {KeyboardEvent} e
     * @memberof ExpandableSearchBar
     */
    private inputChanged;
    /**
     * Emits an `inputchange` event.
     * ie: `e.detail.value = 'current search string'`
     *
     * @private
     * @memberof ExpandableSearchBar
     */
    private emitInputChangeEvent;
    /**
     * Emits an `enterKeyPressed` event that contains the current value.
     * ie: `e.detail.value = 'current search string'`
     *
     * @private
     * @memberof ExpandableSearchBar
     */
    private emitEnterKeyPressedEvent;
    /**
     * Emits a `searchCleared` event when the user clears the search
     *
     * @private
     * @memberof ExpandableSearchBar
     */
    private emitSearchClearedEvent;
    /**
     * Triggered when the user selects a quick search entry.
     * Emits a `quickSearchSelected` with the entry:
     * ie. `e.detail.quickSearchEntry = <QuickSearchEntry object>`
     *
     * @private
     * @param {CustomEvent} e
     * @memberof ExpandableSearchBar
     */
    private quickSearchSelected;
    /**
     * Triggered when the user clicks on the disclosure triangle to toggle the quick search.
     *
     * @private
     * @memberof ExpandableSearchBar
     */
    private toggleDisclosure;
    /**
     * Returns the search input form DOM element if it exists
     *
     * @readonly
     * @private
     * @type {(HTMLInputElement | null)}
     * @memberof ExpandableSearchBar
     */
    private get searchInput();
    /**
     * LitElement lifecycle styles
     *
     * @readonly
     * @static
     * @type {CSSResult}
     * @memberof ExpandableSearchBar
     */
    static get styles(): CSSResult;
}
