import { LitElement, CSSResult, TemplateResult } from 'lit';
import QuickSearchEntry from './models/quick-search-entry';
/**
 * An element used to render a list of QuickSearchEntry entries
 *
 * @export
 * @class QuickSearch
 * @extends {LitElement}
 */
export default class QuickSearch extends LitElement {
    quickSearches: QuickSearchEntry[];
    /**
     * LitElement lifecycle render method
     *
     * @returns {TemplateResult}
     * @memberof QuickSearch
     */
    render(): TemplateResult;
    /**
     * Triggered when the user selects one of the quick search entries.
     * It emits a `searchTermSelected` event.
     *
     * @private
     * @param {Event} e
     * @returns {void}
     * @memberof QuickSearch
     */
    private doQuickSearch;
    /**
     * LitElement lifecycle styles method
     *
     * @readonly
     * @static
     * @type {CSSResult}
     * @memberof QuickSearch
     */
    static get styles(): CSSResult;
}
