/*
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-15 19:44:48
 * @LastEditTime: 2020-08-16 15:49:02
 * @LastEditors: user
 * @Description:
 * @FilePath: \llgtfoo-conponents-boxs\src\plugins\iview.js
 */
// import Vue from 'vue'
// import ViewUI from 'view-design'

// Vue.use(ViewUI)

// import 'view-design/dist/styles/iview.css'
