/*
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-16 15:13:51
 * @LastEditTime: 2020-08-16 15:14:39
 * @LastEditors: user
 * @Description:
 * @FilePath: \llgtfoo-conponents-boxs\plugins\components\number-scroll\index.js
 */
import numberScroll from "./index.vue";

numberScroll.install = Vue => Vue.component(numberScroll.name, numberScroll); //注册组件

export default numberScroll;
