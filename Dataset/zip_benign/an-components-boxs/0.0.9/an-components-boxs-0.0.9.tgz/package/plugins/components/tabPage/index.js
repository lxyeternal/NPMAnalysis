/*
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-22 17:52:42
 * @LastEditTime: 2020-08-22 17:53:06
 * @LastEditors: user
 * @Description:
 * @FilePath: \llgtfoo-conponents-boxs\plugins\components\tabPage\index.js
 */
import tabPage from "./index.vue";

tabPage.install = Vue => Vue.component(tabPage.name, tabPage); //注册组件

export default tabPage;