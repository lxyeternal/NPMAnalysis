/*
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-09 20:14:11
 * @LastEditTime: 2020-08-09 21:15:55
 * @LastEditors: user
 * @Description:
 * @FilePath: \npm-test\npm-test\src\components\dateTime\index.js
 */

import dateTimes from "./date-time.vue";

dateTimes.install = Vue => Vue.component(dateTimes.name, dateTimes); //注册组件

export default dateTimes;
