import MediaPlayer from "@lin-media/player";
import "./style/index.scss";
declare class Contextmenu {
    static pluginName: string;
    private _playerInstance;
    private _options;
    private _eventManager;
    private _el;
    private _wrapperElement;
    constructor(playerInstance: MediaPlayer, el: HTMLElement);
    private _initListener;
    private _onMenuClick;
    private _handelMenuItemClick;
    private _onDocumentClick;
    private _createElement;
    private _onContextmenu;
    private _showMenu;
    private _hideMenu;
    private _adjustPosition;
    private _destroy;
}
export default Contextmenu;
