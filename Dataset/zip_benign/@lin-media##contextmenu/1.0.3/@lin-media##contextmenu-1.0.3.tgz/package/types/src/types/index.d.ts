export interface ContextmenuOptions {
    menuList: MenuList;
    menuItemWidth?: string;
    subMenuItemWidth?: string;
}
export declare type MenuList = Array<MenuItem> | Array<MenuItemLine> | Array<SubMenuItem>;
export declare type MenuItemType = "MenuItem" | "SubMenuItem" | "MenuLine";
export interface MenuItem {
    type: "MenuItem";
    label: string;
    callback?: (data: MenuItem) => void;
    eventName?: string;
    desc?: string;
    [key: string]: any;
}
export interface MenuItemLine {
    type: "MenuLine";
}
export declare type SubMenuList = Omit<MenuItem, "type">[];
export interface SubMenuItem {
    type: "SubMenuItem";
    label: string;
    subMenuList: SubMenuList;
}
