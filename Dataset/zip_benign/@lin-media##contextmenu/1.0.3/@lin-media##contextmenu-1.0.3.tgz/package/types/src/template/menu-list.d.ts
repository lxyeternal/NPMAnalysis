import { MenuList } from "../types";
interface Params {
    menuList: MenuList;
    subMenuItemWidth?: string;
}
export default function getMenuList({ menuList, subMenuItemWidth }: Params): string;
export {};
