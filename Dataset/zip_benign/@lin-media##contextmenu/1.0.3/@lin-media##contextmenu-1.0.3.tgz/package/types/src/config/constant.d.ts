export declare const pluginName = "Contextmenu";
export declare const MENUITEM = "MenuItem";
export declare const SUBMENUITEM = "SubMenuItem";
export declare const MENULINE = "MenuLine";
