function random(r) {
    var a = Math.floor(r * 2 ** 31);
    return function () {
        var t = a += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
function prefix(x, n = -1, r = Math.random()) {
    var X = x.length, rnd = random(r);
    var n = n >= 0 ? n : Math.floor((X + 1) * rnd());
    return n > X ? null : x.slice(0, n);
}
export { prefix as default };
