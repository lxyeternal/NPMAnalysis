Picks an arbitrary prefix.
[:package:](https://www.npmjs.com/package/@extra-array/prefix)
[:smiley_cat:](https://github.com/orgs/nodef/packages?repo_name=extra-array)
[:running:](https://npm.runkit.com/@extra-array/prefix)
[:vhs:](https://asciinema.org/a/332109)
[:moon:](https://www.npmjs.com/package/@extra-array/prefix.min)
[:scroll:](https://unpkg.com/@extra-array/prefix/)
[:newspaper:](https://nodef.github.io/extra-array/)
[:blue_book:](https://github.com/nodef/extra-array/wiki/)

> Similar: [prefix], [prefixes], [hasPrefix].

> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

<br>

```javascript
array.prefix(x, [n], [r]);
// x: an array
// n: number of values (-1 => any)
// r: random seed 0->1
```

```javascript
const array = require("extra-array");

var x = [1, 2, 3];
array.prefix(x);
// [ 1, 2 ]

array.prefix(x, 1);
// [ 1 ]

array.prefix(x, -1, 0.5);
// [ 1, 2 ]
```

[prefix]: https://github.com/nodef/extra-array/wiki/prefix
[prefixes]: https://github.com/nodef/extra-array/wiki/prefixes
[hasPrefix]: https://github.com/nodef/extra-array/wiki/hasPrefix
