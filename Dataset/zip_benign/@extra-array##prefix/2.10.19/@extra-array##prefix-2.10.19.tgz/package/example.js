const array = require("extra-array");

var x = [1, 2, 3];
array.prefix(x);

array.prefix(x, 1);

array.prefix(x, -1, 0.5);
