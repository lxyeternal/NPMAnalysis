const obj = {};
obj.ascsort = function(obj) {
    var arrKey = []
    var sortObj = {}
    for (item in obj) {
        arrKey.push(item)
    }
    arrKey = arrKey.sort()
    for (item in arrKey) {
        sortObj[arrKey[item]] = obj[arrKey[item]]
    }
    return sortObj

};
obj.getNowFormatDate = function() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    var minute = date.getMinutes();
    var second = date.getSeconds();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    if (minute >= 0 && minute <= 9) {
        minute = "0" + minute
    }
    if (second >= 0 && second <= 9) {
        second = "0" + second
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate +
        " " + date.getHours() + seperator2 + minute +
        seperator2 + second;
    return currentdate;
};
module.exports = obj;