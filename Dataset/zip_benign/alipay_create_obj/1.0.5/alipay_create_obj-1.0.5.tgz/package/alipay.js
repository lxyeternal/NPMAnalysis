const fuc = require('./function.js');
const conf = require('./config.js');
const fs = require('fs');
const deepcopy = require('deepcopy');

const crypto = require('crypto');
const randomstring = require('random-string');


//param:
//time(string): 当前时间，用来生成唯一的交易ID
//path(string):付款信息的文件存放路径
//callbackparam(obj) 回调的时候要传给回调链接的参数.
//ali_private_path(string)存放阿里私钥的路径。
function form(time, path, ali_private_path, callbackparam) {
    try {
        let signString = '';
        let buyLength = time;
        let price_info = fs.readFileSync(path, 'utf-8');
        price_info = JSON.parse(price_info);
        if (buyLength != 'year' && buyLength != 'month') {
            let returnObj = {
                code: '400',
                message: 'must be year or month'
            };
            return returnObj;

        }
        let total_amount = price_info['zh-CN'][buyLength]['price'];
        let randomString = randomstring({ length: 5 });
        let out_trade_number = new Date().getTime().toString() + randomString;
        let subject = price_info['zh-CN'][buyLength]['subject'];
        let publicParam = deepcopy(conf.alipay.param);
        publicParam.timestamp = fuc.getNowFormatDate();
        let biz_content = conf.biz_content;
        biz_content['out_trade_no'] = out_trade_number;
        biz_content['total_amount'] = total_amount;
        biz_content['subject'] = subject;
        let passback = JSON.stringify(callbackparam);
        biz_content['passback_params'] = encodeURIComponent(passback);
        publicParam['biz_content'] = JSON.stringify(biz_content);
        publicParam = fuc.ascsort(publicParam);
        //let orderObj = deepcopy(biz_content);
        for (let item in publicParam) {
            signString += (item + '=' + publicParam[item] + '&');

        }
        signString = signString.substring(0, signString.length - 1);
        let signer = crypto.createSign('RSA-SHA1');
        signer.update(signString);
        let privateKey = fs.readFileSync(ali_private_path);
        let signed = signer.sign(privateKey, 'base64');
        publicParam.sign = signed;
        let obj = {
            url: conf.trade_url,
            headers: {
                'content-type': 'application/x-www-form-urlencoded;charset=utf-8'
            },
            form: publicParam
        };
        return obj;
    } catch (e) {
        return 'generate alipay obj failed';
    }
}

module.exports = form;