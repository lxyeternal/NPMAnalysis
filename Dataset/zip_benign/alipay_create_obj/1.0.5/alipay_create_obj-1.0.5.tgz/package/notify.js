const crypto = require('crypto');
const request = require('request');
const deepcopy = require('deepcopy');
const fs = require('fs');
const func = require('./function.js');

function notification(ali_pubkey, body) {
    //设定好回调域名之后，在回调的路由里添加此方法用于验证是否支付宝官方回调和接收passback 参数。
    try {
        let sortedBody = func.ascsort(body);
        let sign = sortedBody['sign'];
        let sign_type = sortedBody['sign_type'];
        delete sortedBody['sign'];
        delete sortedBody['sign_type'];
        let paramString = "";
        for (let item in sortedBody) {
            let value = sortedBody[item];
            let key = item;
            paramString += (key + '=' + value + '&');
        }
        let pubKey = fs.readdirSync(ali_pubkey);
        paramString = paramString.substring(0, paramString.length - 1);
        let verify = crypto.createVerify('RSA-SHA1');
        verify.update(paramString);
        let aliRes = verify.verify(pubKey, sign, 'base64');
        let passback = JSON.parse(decodeURIComponent(sortedBody['passback_param']));
        //返回回调是否成功的状态和请求支付宝付款的时候带上的passback参数。
        //返回成功
        let return_obj = {
            isSuccess: aliRes,
            passbackParam: passback
        }
        return return_obj;
    } catch (e) {
        return e;
    }
}