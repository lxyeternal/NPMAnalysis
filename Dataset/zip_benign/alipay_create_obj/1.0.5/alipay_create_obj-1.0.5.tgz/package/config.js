//请将biz_content 和 alipay两个对象的属性填写完整。
const obj = {};
obj.mongo_address = '';
obj.trade_url = 'https://openapi.alipay.com/gateway.do';
obj.biz_content = {
    'out_trade_no': '', //自己生成的唯一订单号。
    'product_code': 'FAST_INSTANT_TRADE_PAY', //销售产品码,目前仅支持：FAST_INSTANT_TRADE_PAY
    'total_amount': '', //订单总金额，单位为元，精确到小数点后两位，取值范围[0.01,100000000]
    'subject': '', //订单标题
    'qr_pay_mode': '2', //具体意思请查阅支付宝官方文档
};
obj.alipay = {
    param: {
        'app_id': '', //商户的appid
        'biz_content': '', //业务请求参数的集合
        'charset': 'utf-8', //编码方式
        'format': 'JSON', //固定为JSON
        'method': 'alipay.trade.page.pay', //请求的接口名称
        'notify_url': '', //支付宝服务器主动通知商户服务器支付是否成功，以此为准
        'return_url': '', //支付宝同步跳转地址，扫码后悔跳转到这个地方
        'sign_type': 'RSA', //签名方式
        'timestamp': '', //发送请求的时间，格式"yyyy-MM-dd HH:mm:ss"
        'version': '1.0', //固定参数
    },
    seller_id: '', //收款支付宝账号对应的唯一的用户号，2088开头的16位数字.
};

obj.private_key = '';
obj.custom_filename = '';
module.exports = obj;