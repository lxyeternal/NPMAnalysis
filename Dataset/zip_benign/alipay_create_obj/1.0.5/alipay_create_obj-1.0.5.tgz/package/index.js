const alipay = require('./alipay.js');
module.exports = {
    create: alipay,
    config: require('./config.js')
};