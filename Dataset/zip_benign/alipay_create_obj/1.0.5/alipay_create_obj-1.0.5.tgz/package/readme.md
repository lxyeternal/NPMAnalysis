#### node版本支付宝的支付对象组装以及支付宝回调的验证  
* alipay.js 为组装请求对象的主程序。  
需要参数：  
time:  
(区分年费还是月费，期望参数：year（string）, month(string))  
path:
(产品的价格信息, json格式)  
期望格式：  
```{
	"default":{
		"price":10,
		"discount":0.85,
		"unit":"$",
		"period":"year"
	},
	"zh-CN":{
		"month":{
			"price":0.1,
			"subject":"your subject name",
			"discount":1,
			"unit":"￥",
			"period":"月"
		},
		"year":{
			"price":0.5,
			"subject":"your subject name",
			"discount":1,
			"unit":"￥",
			"period":"年"
		}
	}
}  
```
callbackparam:  回传给notify的参数。用于接下来处理自己的逻辑。
ali_private_path:  
阿里云提供的私钥的存储路径。用来加密传递给阿里云的数据。