export declare const table: Map<string, string>;
