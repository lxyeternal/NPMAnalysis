import { Vec4 } from "./shared";
declare class Hex {
    private hex2rgb6;
    private hex2rgba6;
    private hex3tohexArr;
    private hex6tohexArr;
    isHex: (hex: string) => boolean;
    hex2hexArr: (hex: string) => string[];
    hex2rgb: (color: string) => string;
    hex2rgba: (color: string) => string;
    hex2vec4: (str: string, alpha?: number) => Vec4;
}
declare const _default: Hex;
export default _default;
