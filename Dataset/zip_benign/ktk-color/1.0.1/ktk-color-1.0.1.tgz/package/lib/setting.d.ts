export declare const defaultColor = "#000000";
