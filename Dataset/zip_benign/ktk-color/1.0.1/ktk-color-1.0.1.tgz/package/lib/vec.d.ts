import { Vec4 } from "./shared";
declare class Vec {
    handleVec4: (vec4: Vec4) => number[];
    vec4torgb: (vec4: Vec4) => string;
    vec4torgba: (vec4: Vec4) => string;
    vec4tohex: (vec4: Vec4) => string;
    isVec4: (arg: any) => boolean;
    clampValue: (vec4: Vec4) => Vec4;
}
declare const _default: Vec;
export default _default;
