import { Vec4 } from './shared';
declare class RGB {
    private handleStr;
    isRGB: (str: string) => boolean;
    isRGBA: (str: string) => boolean;
    rgb2hex: (str: string) => string;
    rgb2vec4: (str: string) => Vec4;
    getAlpha: (str: string) => number;
    clampAlpha: (str: string) => string;
    addAlpha: (str: string) => string;
    removeAlpha: (str: string) => string;
}
declare const _default: RGB;
export default _default;
