import { Vec4 } from './shared';
declare class Color {
    private str2hex;
    private judgeType;
    tovec4: (color: any) => Vec4;
    tohex: (color: any) => string;
    torgb: (color: any) => string;
    torgba: (color: any) => string;
}
declare const _default: Color;
export default _default;
