export declare const clamp: (num: number, low: number, high: number) => number;
