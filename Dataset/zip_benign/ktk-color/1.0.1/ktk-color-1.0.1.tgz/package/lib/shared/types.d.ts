import { table } from "./data";
export declare type Vec4 = [number, number, number, number];
export declare enum CType {
    'ColorStr' = 0,
    'RGB' = 1,
    'RGBA' = 2,
    'Hex' = 3,
    'Other' = 4,
    'Vec4' = 5
}
export declare type ColorType = keyof typeof table;
