export { clamp } from './function';
export { defaultColor, table } from './data';
export * from './types';
