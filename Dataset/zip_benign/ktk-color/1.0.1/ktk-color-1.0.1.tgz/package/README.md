# ktk-color

ktk-color is used to transfer format of different kinds of color.

## Installing
```
npm install ktk-color
```

## Usage
```html
<script>
import Color from 'ktk-color';
const color = Color.tovec4('red'); // [1, 0, 0, 1]
</script>
```

## API Reference  

<a name="tovec4" href="#tovec4">#</a> Color.<b>tovec4</b>  
Returns value in vec4 format.  
The value will be clamped between 0 and 1 if exceeds limit.  
Returns default value([0, 0, 0, 1]) if not in normal color format.  

```js
Color.tovec4('red')                   // [1, 0, 0, 1]
Color.tovec4('rgb(100,75,50)')        // [0.39, 0.29, 0.19, 1]
Color.tovec4('rgba(100,75,50,0.5)')   // [0.39, 0.29, 0.19, 0.5]
Color.tovec4('#666666')               // [0.4, 0.4, 0.4, 1]
Color.tovec4([0, 0, 0, 1.5])          // [0, 0, 0, 1])
Color.tovec4([0, 0, 0, -0.5])         // [0, 0, 0, 0])
Color.tovec4([1, 100, 0, 0.5])        // [1, 1, 0, 0.5])
Color.tovec4('wrong')                 // [0, 0, 0, 1]
Color.tovec4(37374)                   // [0, 0, 0, 1]
```

<a name="tohex" href="#tohex">#</a> Color.<b>tohex</b>  
Returns value in hex format.  
Returns default value('#000000') if not in normal color format.  

```js
Color.tohex('red')                   // #ff0000
Color.tohex('rgb(100,100,100)')      // #646464
Color.tohex('rgba(100,100,100,0.5)') // #646464
Color.tohex('#666666')               // #666666
Color.tohex([1, 0, 0, 1])            // #ff0000
Color.tohex([1, 100, 0, 0.5])        // #ffff00
Color.tohex('wrong')                 // #000000
Color.tohex(37374)                   // #000000
```

<a name="torgb" href="#torgb">#</a> Color.<b>torgb</b>  
Returns value in rgb format.  
The value will be clamped between 0 and 1 if exceeds limit.  
Returns default value('rgb(0, 0, 0)') if not in normal color format.  

```js
Color.torgb('red')                   // rgb(255,0,0)
Color.torgb('rgb(100,75,50)')        // rgb(100,75,50)
Color.torgb('rgba(100,100,100,1)')   // rgb(100,100,100)
Color.torgb('#646464')               // rgb(100,100,100)
Color.torgb('#cde')                  // rgb(204,221,238)
Color.torgb([1, 100, 0, 0.5])        // rgb(255,255,0)
Color.torgb('wrong')                 // rgb(0,0,0)
Color.torgb(37374)                   // rgb(0,0,0)
```

<a name="torgba" href="#torgba">#</a> Color.<b>torgba</b>  
Returns value in rgba format.  
Returns default value('rgba(0, 0, 0, 1)') if not in normal color format.  

```js
Color.torgba('red')                   // rgba(255,0,0,1)
Color.torgba('rgb(100,75,50)')        // rgba(100,75,50,1)
Color.torgba('rgba(100,100,100,1)')   // rgba(100,100,100,1)
Color.torgba('#646464')               // rgba(100,100,100,1)
Color.torgba('#cde')                  // rgba(204,221,238,1)
Color.torgba([1, 100, 0, 0.5])        // rgba(255,255,0,0.5)
Color.torgba('wrong')                 // rgba(0,0,0,1)
Color.torgba(37374)                   // rgba(0,0,0,1)
```

## License
This project is licensed under [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Contact
* Email:[eric199002@icloud.com](eric199002@icloud.com)
* Twitter:[https://twitter.com/nikoniko600](https://twitter.com/nikoniko600)
* Repo:[https://github.com/Eric-Schecter/ktk-color](https://github.com/Eric-Schecter/ktk-color)