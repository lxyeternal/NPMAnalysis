/// <reference types="node" />
import type { NodeCanvasRenderingContext2D, Canvas } from "canvas";
export declare class CanvasUtil {
    canvas: Canvas;
    ctx: NodeCanvasRenderingContext2D;
    width: number;
    height: number;
    font: {
        name: string;
        size: number;
    };
    constructor(w?: number, h?: number);
    setBackground(type: string, value: string | Buffer): Promise<this>;
    setFont(name: string, size: number): this;
    setTransparancy(transparancy: number): this;
    addText(text: string, color: string, x: number, y: number): this;
    addImage(path: string, x: number, y: number, px: number, py: number): Promise<this>;
    addCircularImage(path: string, x: number, y: number, px: number, py: number): Promise<this>;
    build(): Buffer;
}
