import type { Canvas } from "canvas";
interface font {
    name: string;
    size: number;
}
export declare function applyText(canvas: Canvas, text: string, font: font): string;
export {};
