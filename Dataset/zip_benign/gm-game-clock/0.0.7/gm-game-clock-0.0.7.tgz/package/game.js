import { Box2D } from "./pixitool/box2d";
import { Dust } from "./pixitool/dust";
import { Charm } from "./pixitool/Charm";
import { Bump } from "./pixitool/bump";
import { Tink } from "./pixitool/tink";
import { SpriteUtilities } from "./pixitool/spriteUtilities"
let Application, PIXI;//pixi别名
/**粒子 */
let Tool_Dust;
/**精灵图 */
let Tool_Spr;
/**碰撞 */
let Tool_Bump;
/**交互 */
let Tool_Tink;
/**动画 */
let Tool_Charm;
//初始配置
let Game = function (options) {
  this.options = Object.assign({}, options);
  this.GameData = this.options.gameSource;
  this.scale = this.options.$game.fObj.scale;//宽高比
  this.width = this.options.$game.fObj.size.windowWidth;
  this.height = this.options.$game.fObj.size.windowHeight;
  // this.scale宽高比 0.524 this.width  393  this.height 733

  ////PIXI别名初始化//////
  PIXI = this.options.$game.fObj.PIXI;
  Application = this.options.$game.fObj.application;

  ////PIXI工具初始化//////
  Tool_Dust = new Dust(PIXI);
  Tool_Bump = new Bump(PIXI);
  Tool_Charm = new Charm(PIXI);
  Tool_Spr = new SpriteUtilities(PIXI);
  Tool_Tink = new Tink(PIXI, Application.renderer.view);
  // 创建pixi需要的对象 容器
  this.baseContainer = new PIXI.Container();// spriteArr
  Application.stage.addChild(this.baseContainer);
  this.GoodsContainer = new PIXI.Container();// spriteArr
  Application.stage.addChild(this.GoodsContainer);
  this.ClockBox = new PIXI.Container();//钟容器
  Application.stage.addChild(this.ClockBox);
  this.textContainer = new PIXI.Container();// 文本容器
  Application.stage.addChild(this.textContainer);
  this.animateContainer = new PIXI.Container();//动画容器
  Application.stage.addChild(this.animateContainer);

  // 绘制个屏幕大的矩形，解决触摸事件
  let rect1 = new PIXI.Graphics();
  rect1.beginFill(0xff0000, 0);
  rect1.drawRect(0, 0, this.width, this.height);
  rect1.endFill();
  this.baseContainer.addChild(rect1);
  this.baseContainer.setChildIndex(rect1, 0);//放在最底层

  let loaderList = [];
  // 资源属性名必须为"src"
  options.gameSource = JSON.parse(JSON.stringify(options.gameSource));
  this.traverse(options.gameSource, function (k, v) {
    //includes 确定数组是否包含特定元素，并根据需要返回true或false
    if (k == "src" && !!v && !loaderList.includes(v) && !PIXI.utils.TextureCache[v]) {
      loaderList.push(v);
    }
  })
  // console.log("预加载列表", loaderList)
  // 定时更新
  this.ticker = PIXI.ticker.shared;
  this.ticker.autoStart = false;//添加侦听器时，是否应自动调用方法 
  this.ticker.addOnce(() => { });//为tick事件添加一个处理程序，该处理程序仅执行一次
  // 加载图片资源
  if (loaderList.length > 0) {
    let loader = new PIXI.loaders.Loader();
    loaderList.forEach(item => {
      loader.add(this.uniId(), item);
    })
    this.pixiLoadFun(loader);
  } else {
    this.init({});
    this.ticker.start();
    this.options.initDone();
  }
  this.bindEvent();  //绑定事件
  this.ticker.add(() => this.onUpdate());  //帧刷新
};

//游戏绘制数据初始化 
Game.prototype.init = function (defaultData = {}) {
  this.hideSpriteArrFun(["animateSpriteArr", "BumpArr", "goodsArr"]);
  this.animateSpriteArr = defaultData.animateSpriteArr || [];// 存放动画精灵数组
  this.spriteArr = defaultData.spriteArr || [];// 存放精灵数组
  this.BumpArr = defaultData.bumpArr || [];//碰撞列表
  this.goodsArr = defaultData.goodsArr || [];//物品列表
  this.GoodsSpeed = this.GameData.goods.GoodsSpeed || 1.5;
  this.curAngle = defaultData.curAngle || 0;
  this.removeBox(this.GoodsContainer);
  this.GameTime = 0;
  this.totalScore = 0;
  this.LowerSpeed = 0;
  this.createType = 0;
  this.setBgShow();
  this.setTimeShow();
  this.setScoreShow();
  this.setClockShow();
  this.setBgMusic(this.GameData.Bgmusic.InitPlay);
};




//游戏逻辑
Game.prototype = Object.assign(Game.prototype, {


  removeBox(Box) {
    if (Box.children.length > 0) {
      for (let i = 0; i < Box.children.length; i++) {
        Box.children[i].destroy();
      }
    }
  },
  //资源加载检测
  pixiLoadFun: function (loader) {
    let time1 = new Date().getTime();
    loader.on("progress", e => {//资源加载进度
      this.options.progressFun(e.progress);
    })
    loader.on("error", e => {//资源加载错误
      this.options.errorFun(e);
    })
    loader.load(() => {  // 资源加载完成
      time1 = "";
      this.init({});
      this.ticker.start();
      this.options.initDone();
    });
    setTimeout(() => {
      // 5秒还没加载完，重新加载一遍
      if (!!time1) {
        console.log("重新加载资源...")
        this.pixiLoadFun(loader);
      }
    }, 5000)
  },
  //背景音乐按钮
  setBgMusic(isPlay) {
    if (isPlay) { this.audioFun(this.GameData.Bgmusic.audio, this.GameData.Bgmusic.loop); }
    if (!this.btn_BgMusic) {
      let btn_k = this.frame(this.GameData.Bgmusic.btn_img, 0, 0);
      let btn_g = this.frame(this.GameData.Bgmusic.btn_img1, 0, 0);
      let BgMusicImg = Object.assign({
        name: "btn_BgMusic",
      }, isPlay ? this.GameData.Bgmusic.btn_img1 : this.GameData.Bgmusic.btn_img)
      this.btn_BgMusic = this.renderSprite(BgMusicImg, this.textContainer);
      this.btn_BgMusic.position.set(this.GameData.Bgmusic.left * this.scale, this.GameData.Bgmusic.top * this.scale);
      this.btn_BgMusic.interactive = true;//触摸指针和鼠标事件是否开启 
      this.btn_BgMusic.on('pointerdown', (event) => {
        isPlay = !isPlay;
        this.options.VibrateFun(1);
        this.btn_BgMusic.texture = isPlay ? btn_g : btn_k;
        this.audioFun(isPlay ? this.GameData.Bgmusic.audio : null, this.GameData.Bgmusic.loop);
      })
    }
  },
  //绘制背景
  setBgShow: function (speed) {
    if (!this.GameData.rollBg) { return false; }
    if (!this.Bg) {
      let BgSpr = Object.assign({
        name: "Bg",
      }, this.GameData.bg);
      this.renderSprite(BgSpr);
    }
    if (!this.bg1Sprite) {
      // 底部背景
      return
      // 中间滚动背景
      let bgImg1 = Object.assign({
        name: "bg1Sprite"
      }, this.GameData.rollBg);
      bgImg1.x = 0;
      bgImg1.y = -(bgImg1.height * this.scale - this.height);
      this.renderSprite(bgImg1);

      // 上面滚动背景
      let bgImg2 = Object.assign({
        name: "bg2Sprite"
      }, this.GameData.rollBg);
      bgImg2.x = 0;
      bgImg2.y = bgImg1.y - bgImg1.height * this.scale;
      this.renderSprite(bgImg2);

      // 下面滚动背景
      let bgImg0 = Object.assign({
        name: "bg0Sprite"
      }, this.GameData.rollBg);
      bgImg0.x = 0;
      bgImg0.y = bgImg1.y + bgImg1.height * this.scale;
      this.renderSprite(bgImg0);
    } else {
      return
      let tempY = this.bg1Sprite.y - speed * 30;
      tempY = tempY % this.bg1Sprite.height;
      this.bg1Sprite.y = tempY;
      this.bg0Sprite.y = this.bg1Sprite.y + this.bg1Sprite.height;
      this.bg2Sprite.y = this.bg1Sprite.y - this.bg1Sprite.height;
    }
  },
  //时间显示
  setTimeShow() {
    if (this.gameStatus) {
      this.GameTime = parseInt(Math.max(0, (this.overTime - new Date().getTime()) / 1000));
      if (this.GameTime <= 0) {
        this.gameOver();
        this.LowerSpeed = 10;
        this.SwingSpr.step = 0;
        this.SwingSpr.rotation = 0;
        //飞出顶部
        let ClockAnim = Tool_Charm.slide(this.ClockBox, this.ClockBox.x, -this.height, this.GameData.clock.AnimTime, "linear");
        ClockAnim.onComplete = () => { }
      }
    } else {
      this.GameTime = 0;
    }
    if (!!this.TimeText) {
      this.TimeText = this.TextShow(this.TimeText, this.GameTime + "s");
    } else {
      if (!this.TimeText) {
        let TimeBox = new PIXI.Container();
        this.textContainer.addChild(TimeBox);
        TimeBox.position.set(this.width / 2, this.GameData.CountDown.top * this.scale);
        //时间动画
        let scale = { x: this.GameData.CountDown.TimeAinmscale, y: this.GameData.CountDown.TimeAinmscale };
        let AinmList = this.GameData.CountDown.AinmList;
        let speed = AinmList.length / this.GameData.CountDown.Time;
        this.AnimSpr = this.addAnim(AinmList, TimeBox, speed, "TimeAinm", false, scale);
        //时间数值
        this.TimeText = new PIXI.Text(this.GameTime + "s");
        TimeBox.addChild(this.TimeText);
        this.TimeText.anchor.set(0, 0);
        this.TimeText.style = { fill: "#EFDDA5", fontSize: this.GameData.CountDown.Size || 20, align: "center" };
        this.TimeText.position.set(-(this.TimeText.width / 2), -(this.TimeText.height / 2));
      }
    }
  },


  //得分显示
  setScoreShow(scorenum = 0) {
    if (!!this.scoreText) {
      this.scoreText = this.TextShow(this.scoreText, "得分:" + scorenum);
    } else {
      if (!this.scoreText) {
        let scoreBox = new PIXI.Container();
        this.textContainer.addChild(scoreBox);
        scoreBox.position.set(this.width / 2, this.GameData.Score.top * this.scale);
        this.scoreText = new PIXI.Text("得分:" + scorenum);
        scoreBox.addChild(this.scoreText);
        this.scoreText.anchor.set(0, 0);
        this.scoreText.style = { fill: this.GameData.Score.color || "#FFFFFF", fontSize: this.GameData.Score.Size || 18, align: "center" };
        this.scoreText.position.set(-(this.scoreText.width / 2), -(this.scoreText.height / 2));
      }
    }
  },


  setaddScoreShow(scorenum) {
    if (!!this.GameData.addScore.show) {
      let addScore = new PIXI.Text("+" + scorenum);
      this.textContainer.addChild(addScore);
      addScore.position.set(this.GameData.addScore.left * this.scale, this.GameData.addScore.top * this.scale);
      addScore.style = { fill: this.GameData.addScore.color || "#DF0101", fontSize: this.GameData.addScore.Size, align: "center" };
      let addScoreAnim = Tool_Charm.slide(addScore, addScore.x, this.GameData.addScore.pos_y, this.GameData.addScore.Speed, "linear");
      addScoreAnim.onComplete = () => { addScore.destroy() }
    }
  },
  //摆钟显示
  setClockShow() {
    //摆绳
    if (!this.SwingSpr) {
      let SwingImg = Object.assign({
        name: "SwingSpr",
        anchor: { x: 0.5, y: 0.165 },
      }, this.GameData.clock.srcArr[0]);
      this.renderSprite(SwingImg, this.ClockBox);

      this.curStep = SwingImg.step || 0.02;

      //钟盘
      this.renderSprite(Object.assign({ name: "DiscSpr", }, this.GameData.clock.srcArr[1]), this.ClockBox);
      this.ClockBox.position.set(this.width / 2, (this.height / 2) - this.DiscSpr.height / 2);
      //钟心
      this.renderSprite(Object.assign({}, this.GameData.clock.srcArr[2]), this.ClockBox);
      //撞针大
      let BigBulletimg = Object.assign({
        anchor: { x: 0.5, y: 1 },
      }, this.GameData.clock.srcArr[3])

      let BigBulletSpr = this.renderSprite(BigBulletimg, this.SwingSpr);
      BigBulletSpr.position.set(0, BigBulletimg.posy);

      //撞针小
      let SmallBulletimg = Object.assign({
        name: "SmallBulletSpr",
        anchor: { x: 0.5, y: 0.5 },
      }, this.GameData.clock.srcArr[4]);
      this.renderSprite(SmallBulletimg, this.SwingSpr);
      this.SmallBulletSpr.width = SmallBulletimg.width;
      this.SmallBulletSpr.height = SmallBulletimg.height;
      this.SmallBulletSpr.position.set(0, SmallBulletimg.posy);
      //绘制碰撞盒
      if (this.GameData.isBumpBox == true) {
        let rectangle = new PIXI.Graphics();
        rectangle.lineStyle(2, 0xFF3300, 1);
        rectangle.beginFill(0x66CCFF);
        rectangle.drawRect(
          this.SmallBulletSpr.x - this.SmallBulletSpr.width / 2,
          this.SmallBulletSpr.y - this.SmallBulletSpr.height / 2,
          this.SmallBulletSpr.width,
          this.SmallBulletSpr.height);
        rectangle.endFill();
        rectangle.x = this.SmallBulletSpr.x;
        rectangle.y = -(this.SmallBulletSpr.y);
        this.SmallBulletSpr.addChild(rectangle);
      }
    }
    //撞针数据
    this.clockLower = 0;
    this.SwingSpr.step = this.curStep;
    this.SwingSpr.rotation = this.curAngle;
    this.SwingSpr.maxX = this.GameData.clock.swingAngle * Math.PI / 180;
    this.SwingSpr.minX = -(this.GameData.clock.swingAngle) * Math.PI / 180;

    this.TopEdge = this.DiscSpr.height / 2;//上边距
    this.BottomEdge = this.height + this.DiscSpr.height;//下边距

    this.LowerSpeed = this.GameData.clock.LowerSpeed || 2;
    this.ClockisAnim = this.GameData.clock.isAnim || false;

    if (this.ClockisAnim) {
      this.ClockBox.position.set(this.width / 2, -(this.height / 2));
    } else {
      this.ClockBox.position.set(this.width / 2, this.height / 2 - this.DiscSpr.height);
    }
    this.setClockAnimShow(this.GameData.clock.isAnimType);

  },

  setClockAnimShow(type) {
    if (this.ClockisAnim && type) {
      this.setGoodsShow(0)
      this.setGoodsShow(1);
      this.ClockisAnim = this.ClockisAnim && type;
      let pos_y = this.height / 2 - this.DiscSpr.height;
      this.ClockAnim = Tool_Charm.slide(this.ClockBox, this.ClockBox.x, pos_y, this.GameData.clock.AnimTime, "linear");
      this.ClockAnim.onComplete = () => { this.ClockisAnim = false; }
    }
  },
  // 物品显示type 0 左 1 右
  setGoodsShow(type, isCreate = false, last_Y = 0) {
    // isCreate = false;
    // type = 1;
    //盒子
    this.createType = type == 1 ? 0 : 1;
    let GoodsBox = new PIXI.Container();//钟容器

    // this.GoodsSpeed = this.GoodsSpeed.toFixed(2);
    GoodsBox.type = type;
    GoodsBox.move = true;
    GoodsBox.vy = this.GoodsSpeed;
    GoodsBox.movex = type == 0 ? 1 : -1;
    this.GoodsSpeed += this.GameData.goods.AddSpeed;
    let Pos_Y = this.GameData.goods.Spacing + last_Y;
    GoodsBox.position.set(type == 0 ? 0 : this.width, Pos_Y);
    //云朵
    let typesrc = this.GameData.Cloud.type[type];
    let CloudImg = Object.assign({
      anchor: { x: type == 0 ? 0 : 1, y: 0.5 }
    }, typesrc[this.random({ max: typesrc.length })]);
    let CloudSpr = this.renderSprite(CloudImg, GoodsBox);
    this.GoodsContainer.addChild(GoodsBox);

    if (isCreate) {
      //物品
      let imgArr = this.GameData.goods.srcArr;
      let idx = this.random({ max: imgArr.length }); //idx = 1;
      let GoodsImg = Object.assign({ anchor: { x: type == 0 ? 0 : 1, y: 1 }, type: "GoodsSpr" }, imgArr[idx]);
      let GoodsSpr = this.renderSprite(GoodsImg, GoodsBox);
      // GoodsSpr.x = type == 0 ? this.GameData.goods.Left_X : this.GameData.goods.Right_X;

      GoodsSpr.x = type == 0 ? CloudSpr.width / 3 : -(CloudSpr.width / 3);
      GoodsSpr.y = -(CloudSpr.height / 2 - GoodsSpr.height / this.GameData.goods.DisplayArea);
      GoodsBox.setChildIndex(GoodsSpr, 0);

      let scale = { x: this.GameData.goods.BumpAinmscale, y: this.GameData.goods.BumpAinmscale };
      let BumpAinm = this.addAnim(this.GameData.goods.AinmList, GoodsBox, this.GameData.goods.BumpAinmSpeed, "BumpSpr", false, scale);
      let w2 = BumpAinm.width / 2;
      BumpAinm.x = (type == 0 ? GoodsSpr.x + GoodsSpr.width / 2 - w2 : GoodsSpr.x - (GoodsSpr.width / 2) - w2);
      BumpAinm.y = GoodsSpr.y - (GoodsSpr.height + BumpAinm.height / 2);
      BumpAinm.visible = false;
      let num = this.random({ max: 10 });
      // GoodsSpr.visible = num > 2;
      //绘制碰撞盒
      if (this.GameData.isBumpBox == true && GoodsSpr.visible == true) {
        let rectangle = new PIXI.Graphics();
        // rectangle.lineStyle(2, 0xFF3300, 1);
        rectangle.beginFill(0x66CCFF);
        let x = (type == 0) ? 0 : -(GoodsSpr.width)
        rectangle.drawRect(x, -(GoodsSpr.height), GoodsSpr.width, GoodsSpr.height);
        rectangle.endFill();
        rectangle.x = GoodsSpr.x;
        rectangle.y = GoodsSpr.y;
        GoodsBox.addChild(rectangle);
      }
    } else {
      GoodsBox.move = false;
      let top = this.height / 2 - CloudSpr.height / 2;
      let bottom = top + top / 2 + CloudSpr.height / 2;
      GoodsBox.y = this.random({ min: top, max: bottom, });
      GoodsBox.x = type == 0 ? -CloudSpr.width : this.width + CloudSpr.width;
      let GoodsBoxMove = Tool_Charm.slide(GoodsBox, type == 0 ? 0 : this.width, GoodsBox.y, this.GameData.Cloud.AnimTime, "linear");
      GoodsBoxMove.onComplete = () => { GoodsBox.move = true; }
    }
    GoodsBox.showWidth = CloudSpr.width;
    this.goodsArr.push(GoodsBox);
    this.BumpArr.push(GoodsBox);
  },




  //帧刷新
  onUpdate: function () {
    Tool_Charm.update();
    if (!this.gameStatus) return
    this.setGoodsMove();
    this.setTimeShow();
    this.setClockMove();
    this.setSprSwing(this.SwingSpr);
    this.setBgShow(this.GameData.rollBg.rollSpeed);
    this.onBump(this.SmallBulletSpr, this.BumpArr);
    return
    Tool_Dust.update();
    Tool_Tink.update();
  },



  //物品移动
  setGoodsMove() {
    var curNode = this.goodsArr[this.goodsArr.length - 1];
    if (!!curNode && curNode.move) {
      if (curNode.y <= this.height - this.GameData.goods.createPos && this.goodsArr.length < this.GameData.goods.maxcreateNum) {
        if (!!this.gameStatus) {
          this.setGoodsShow(this.createType, true, curNode.y);
        }

      }
    }

    for (let i = 0; i < this.goodsArr.length; i++) {
      let curNode = this.goodsArr[i];
      if (curNode.visible && curNode.move) {
        if (curNode.y <= 0) {
          curNode.parent.removeChild(curNode);
          this.goodsArr.splice(i, 1);
          break;
        }
        curNode.y -= this.GoodsSpeed;
        // let showWidth = curNode.showWidth;
        // if (curNode.type == 0) {
        //   if (curNode.movex == -1) {//向左
        //     if (curNode.x <= 0) {
        //       curNode.movex = 1
        //     }
        //   }
        //   else if (curNode.movex == 1) {
        //     if (curNode.x >= this.width - showWidth) {
        //       curNode.movex = -1
        //     }
        //   }
        // } else if (curNode.type == 1) {
        //   if (curNode.movex == -1) {//向左
        //     if (curNode.x <= showWidth) {
        //       curNode.movex = 1
        //     }

        //   }
        //   else if (curNode.movex == 1) {
        //     if (curNode.x >= this.width) {
        //       curNode.movex = -1
        //     }
        //   }
        // }
        // curNode.x += curNode.movex;
      }
    }

    for (let i = 0; i < this.BumpArr.length; i++) {
      let curNode = this.BumpArr[i];
      if ((curNode.y + curNode.height / 2) <= 0) {
        this.BumpArr.splice(i, 1);
      }
    }
  },

  //钟移动
  setClockMove() {
    if (this.ClockisAnim) return
    if (this.GameData.GameType == 0) {
      if (this.clockLower > 0) {//上移
        if (this.ClockBox.y > this.TopEdge) {
          this.ClockBox.y -= this.GameData.clock.UpperSpeed;
          this.clockLower -= 0.1;
        } else {
          this.clockLower = 0;
        }
      } else {
        if (this.SmallBulletSpr.y + this.ClockBox.y >= this.BottomEdge) {
          this.gameOver();
        }
        this.ClockBox.y += this.LowerSpeed;
      }
    } else if (this.GameData.GameType == 1) {

    }

  },

  // 两个不同方块之间的基本AABB检查
  testForAABB(object1, object2, type = 0) {
    const zj = object1.getBounds();
    const wp = object2.getBounds();
    let isblo = null;
    let zjzx_x = zj.x, zjzx_y = zj.y - zj.height;
    let wp_x, wp_y, wp_w = wp.width, wp_h = wp.height;
    // 中间 锚点为0.5,0.5 居中
    if (type == 0) {//左  锚点0,1 居左下角
      wp_x = wp.x + wp.width / 2;
      wp_y = wp.y - wp.height / 2;
    } else {//右  锚点1,1 居右下角
      wp_x = wp.x - wp.width / 2;
      wp_y = wp.y - wp.height / 2;
    }
    // isblo = Math.abs(wp_x - zjzx_x) <= (wp_w / 2 + zj.width / 2) && Math.abs(wp_y - zjzx_y) <= (wp_h / 2 + zj.height / 2);
    isblo = Math.abs(wp_x - zjzx_x) <= (wp_w / 2 + zj.width / 2) && Math.abs(wp_y - zjzx_y) <= (wp_h / 2 + zj.height / 2);
    return isblo;
    // return bounds1.x < bounds2.x + bounds2.width 
    // && bounds1.x + bounds2.width > bounds2.x
    // && bounds1.y < bounds2.y + bounds2.height
    // && bounds1.y + bounds2.height > bounds2.y;
  },

  onBump(bumpNode, checklist) {
    for (let x = 0; x < checklist.length; x++) {
      let GoodsBox = checklist[x];
      for (let y = 0; y < GoodsBox.children.length; y++) {
        if (GoodsBox.children[y]) {
          let CurNode = GoodsBox.children[y];
          if (CurNode.type == "GoodsSpr" && CurNode.visible == true) {
            if (this.testForAABB(bumpNode, CurNode, GoodsBox.type)) {
              this.setCurBumpNode(CurNode);
              this.BumpArr.splice(x, 1);
            };
          }
        }
      }
    }

    return
    //Bump.hit(监听对象,碰撞列表,是否重叠,是否反弹,使用精灵的全局坐标,回调);碰撞监听
    Tool_Bump.hit(this.SmallBulletSpr, this.BumpArr, true, false, true, function (BumpType, CurNode) {
      //BumpType 表示 sprite 的哪一边发生碰撞
      //CurNode 表示 sprite 正在碰撞的精灵组中的精灵
      // console.log("表示 sprite 的哪一边发生碰撞", BumpType);
      // console.log("表示 sprite 正在碰撞的精灵组中的精灵", CurNode);
      this.setCurBumpNode(CurNode)
    }.bind(this));
  },
  //处理当前碰撞节点
  setCurBumpNode(CurNode) {

    let Curparent = CurNode.parent;
    if (!!Curparent) {
      let addScore = CurNode.imgObj.val || 0;
      this.totalScore += addScore;
      this.setaddScoreShow(addScore);
      // Curparent.removeChild(CurNode);
      this.setScoreShow(this.totalScore);
      this.options.updateFun({ addScore: addScore, curScore: this.totalScore });
      for (let j = 0; j < Curparent.children.length; j++) {
        if (Curparent.children[j].type == "BumpSpr") {
          let BumpSpr = Curparent.children[j];
          this.options.VibrateFun();
          BumpSpr.visible = true;
          BumpSpr.play();
          BumpSpr.onComplete = function () {
            BumpSpr.visible = false;
            CurNode.visible = false;
          }
        }
      }
    }
  },

  //精灵渲染处理
  renderSprite: function (tImg, Parent = null) {
    let sprite;// 没有唯一标识，说明第一次生成
    if (tImg.type == "animate" || (!!tImg.srcArr && tImg.srcArr.length > 0)) {
      // 动画
      let textures = [];
      tImg.srcArr.forEach(img => {
        textures.push(this.frame(img, 0, 0));
      })

      sprite = new PIXI.extras.AnimatedSprite(textures);
      sprite.animationSpeed = tImg.boomSpeed || 0.1;
      sprite.loop = !!tImg.loop;
      sprite.onComplete = function () {
        console.log("动画播放完毕...");
        this.visible = false;
        if (!!tImg.callback) {
          try {
            tImg.callback();
          } catch (e) { }
        }
      }
    } else {
      //普通
      sprite = new PIXI.Sprite();
      sprite.texture = this.frame(tImg, 0, 0);
    }

    //数据初始赋值
    let uniId = tImg.uniId || this.uniId();
    //没设置锚点就默认中间
    if (!tImg.anchor) { tImg.anchor = { x: 0.5, y: 0.5 }; };

    tImg.uniId = uniId;
    sprite.imgObj = tImg;
    sprite.uniId = uniId;
    sprite.type = tImg.type || false;
    //有添加父节点放在父节点中心  没有位置默认放屏幕中间
    sprite.x = !!Parent ? 0 : (tImg.x || this.width / 2);
    sprite.y = !!Parent ? 0 : (tImg.y || this.height / 2);
    // 数据赋值
    sprite.anchor.set(tImg.anchor.x, tImg.anchor.y);
    sprite.width = tImg.spriteW || (tImg.width * this.scale);
    sprite.height = tImg.spriteH || (tImg.height * this.scale);

    if (!!tImg.name) { this[tImg.name] = sprite; };
    if (!!tImg.showWidth) { sprite.width = tImg.showWidth * this.scale; };
    if (!!tImg.showHeight) { sprite.height = tImg.showHeight * this.scale; };

    //分类存放
    if (Parent) {
      Parent.addChild(sprite);
    } else if (tImg.type == "animate") {
      sprite.stop();
      sprite.gotoAndPlay(0);
      this.animateSpriteArr.push(sprite);
      this.animateContainer.addChild(sprite);
    } else {
      this.spriteArr.push(sprite);
      this.baseContainer.addChild(sprite);
    }
    return sprite;
  },

  /**
   * 
   * @param {*} srcArr  资源数组
   * @param {*} addNode 添加节点
   * @param {*} speed   动画速度
   * @param {*} type    节点类型
   * @param {*} loop    循环类型
   * @param {*} scale   缩放大小
   */
  addAnim(srcArr, addNode, speed = 0.1, type = "", loop = false, scale = null) {
    if (!srcArr.length || !addNode) return
    let srcList = [];
    for (let i = 0; i < srcArr.length; i++) {
      srcList.push(this.frame(srcArr[i], 0, 0));
    }
    let AnimSpr = new PIXI.extras.AnimatedSprite(srcList);
    AnimSpr.loop = loop;
    AnimSpr.type = type;
    AnimSpr.anchor.set(0, 0);
    AnimSpr.animationSpeed = speed;
    if (!!scale) { AnimSpr.scale.set(scale.x, scale.y); }
    AnimSpr.position.set(-(AnimSpr.width / 2), -(AnimSpr.height / 2))
    addNode.addChild(AnimSpr);
    return AnimSpr
  },

  setSprSwing(CurNode) {
    if (this.ClockisAnim) return
    // 摇摆
    if (!!CurNode) {
      if (this.GameData.GameType == 0) {
        //钟上下移动自动左右摇摆
        let curRotate = CurNode.rotation + CurNode.step;
        if (curRotate < CurNode.minX) {
          CurNode.step = CurNode.step * -1;
          curRotate = CurNode.minX;
        }
        if (curRotate > CurNode.maxX) {
          CurNode.step = CurNode.step * -1;
          curRotate = CurNode.maxX;
        }
        CurNode.rotation = curRotate;
      } else if (this.GameData.GameType == 1) {
        //钟固定位置 滑动左右摇摆 自动回弹
        if (this.touchMotion) {
          this.curAngle += this.GameData.clock.swingSpeed * this.touchDirection;
          if (this.curAngle < - (this.GameData.clock.swingAngle)) {
            this.curAngle = -(this.GameData.clock.swingAngle);
          }
          if (this.curAngle > this.GameData.clock.swingAngle) {
            this.curAngle = this.GameData.clock.swingAngle;
          }
          CurNode.rotation = this.curAngle * (Math.PI / 180);
          if (this.reboundMotion) {
            if (Math.abs(this.curAngle) <= this.GameData.clock.swingSpeed) {
              this.reboundMotion = false;
              this.touchMotion = false;
              this.touchDirection = 0;
            }
          }
        } else {
          CurNode.rotation = 0;
        }
      } else if (this.GameData.GameType == 2) {
        //钟固定 滑动左右摇摆 衰弱回弹
        if (this.touchMotion) {
          if (!this.reboundMotion) {
            if (this.curAngle < - (this.GameData.clock.swingAngle)) {
              this.curAngle = -(this.GameData.clock.swingAngle);
            }
            if (this.curAngle > this.GameData.clock.swingAngle) {
              this.curAngle = this.GameData.clock.swingAngle;
            }
            CurNode.rotation = this.curAngle * (Math.PI / 180);
            this.weakAngle = this.curAngle * -1 * this.GameData.clock.swingWeak;
          } else {
            let fangxiang = this.weakAngle < this.curAngle ? -1 : 1;//左
            this.curAngle += this.GameData.clock.swingSpeed * fangxiang;
            if (Math.abs(this.curAngle - this.weakAngle) <= this.GameData.clock.swingSpeed) {
              if (Math.abs(this.curAngle) < this.GameData.clock.swingSpeed) {
                this.reboundMotion = false;
                this.touchMotion = false;
              } else {

                this.weakAngle = this.curAngle * -1 * this.GameData.clock.swingWeak;
              }
            } else {
              CurNode.rotation = this.curAngle * (Math.PI / 180);
            }
          }
        } else {
          CurNode.rotation = 0;
        }
      }
    }
  },

  // 绑定事件
  bindEvent: function () {
    let wcz = 5;
    this.startX = -1;
    this.startY = -1;
    this.moveX = -1;
    this.moveY = -1;
    this.weakAngle = 0;//回弹角度
    this.touchDirection = 0;//触摸方向
    this.touchMotion = false;//触摸运动
    this.reboundMotion = false;//反弹运动
    this.baseContainer.interactive = true;
    this.baseContainer.on('touchstart', (e) => {
      if (!this.gameStatus || this.GameTime <= 0) { return false; }
      let x = e.data.global.x, y = e.data.global.y;
      this.startX = x;
      this.startY = y;
      this.moveX = 0;
      this.moveY = 0;
      this.weakAngle = 0;
      this.touchDirection = 0;
      this.touchMotion = true;
      this.reboundMotion = false;
    })
    this.baseContainer.on('touchmove', (e) => {
      if (!this.gameStatus || this.GameTime <= 0) { return false; }
      let x = e.data.global.x, y = e.data.global.y;
      if (this.GameData.GameType == 0) {
        if (!!this.touchMotion) {
          this.moveX = Math.abs(this.startX - x);
          this.moveY = Math.abs(this.startY - y);
        }
      } else if (this.GameData.GameType == 1 || this.GameData.GameType == 2) {
        this.moveX = x - this.startX;
        this.moveY = y - this.startY;
        if (Math.abs(this.moveX) > wcz || !!this.touchDirection) {
          this.startX = x;
          this.startY = y;
          if (this.touchDirection == 0 && !this.reboundMotion) {
            if (this.moveX < 0) {//左
              this.touchDirection = 1;
            } else {
              this.touchDirection = -1;
            }
          }
        }
        if (this.GameData.GameType == 2) {
          this.curAngle += -1 * this.moveX / 2;
        }
      }
    })
    this.baseContainer.on('touchendoutside', (e) => {
      this.touchendFun(e);
    })

    this.baseContainer.on('touchend', (e) => {
      if (this.GameData.GameType == 0) {
        this.touchendFun(e);
      } else if (this.GameData.GameType == 1 || this.GameData.GameType == 2) {
        this.touchreboundFun(e);
      }
    })
  },


  touchreboundFun(e) {
    this.reboundMotion = true;
    this.touchDirection = 0;
    if (this.GameData.GameType == 1) {
      if (this.SwingSpr.rotation > 0) {//左  
        this.touchDirection = -1;
      } else if (this.SwingSpr.rotation < 0) {
        this.touchDirection = 1;
      }
    }
    this.startX = -1;
    this.startY = -1;
  },

  //触摸检测
  touchendFun: function (e) {
    if (!this.gameStatus || this.GameTime <= 0) { return false; }
    if (this.moveX == -1 || this.moveY == -1) { return false; }
    let wcz = 5;
    if (this.moveX < wcz && this.moveY < wcz) {
      // 此时移动在误差值范围内，判断为点击了
      this.clockLower = this.GameData.clock.UpperTime;
    } else {
    }
    this.startX = -1;
    this.startY = -1;
  },



  frame: function (img, x, y) {
    // 返回texture
    let source = img.src, width = img.fwidth || img.width, height = img.fheight || img.height;
    if (y > img.height) { y = img.height; }
    let texture, imageFrame;
    if (typeof source === "string") {
      if (PIXI.utils.TextureCache[source]) {
        //PIXI.Texture 纹理存储代表图像或图像一部分的信息。
        //无法将其直接添加到显示列表中。而是将其用作Sprite的纹理。如果未提供帧，则使用整个图像。
        texture = new PIXI.Texture(PIXI.utils.TextureCache[source]);
      }
    }
    if (!!texture) {//PIXI.Rectangle绘制矩形对象
      imageFrame = new PIXI.Rectangle(x, y, width, height);
      texture.frame = imageFrame;
      return texture;
    } else {
      console.log(`Please load the ${source} texture into the cache.`);
    }
  },



  /////////////////////////////////////////////////////////////////通用工具////////////////////////////////////////////////////////////////////////////////

  //随机ID
  uniId: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  },

  random: function (options) {
    let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
    let tempNum;
    do {
      let num = Math.random() * (opt.max - opt.min) + opt.min;
      tempNum = !!opt.isFloat ? num : parseInt(num);
    } while (opt.noNum.includes(tempNum));
    return tempNum;
  },

  //文本删除再赋值
  TextShow(CurText, str = "") {
    if (!!CurText) {
      let TextData = CurText;
      let Parent = CurText.parent;
      Parent.removeChild(CurText);
      CurText = new PIXI.Text(str.toString());
      CurText.style = TextData.style;
      CurText.anchor.set(0, 0);
      Parent.addChild(CurText);
      CurText.position.set(-(CurText.width / 2), -(CurText.height / 2));
      return CurText;
    } else {
      console.log("文本赋值失败CurText, str", CurText, str)
    }
  },


  // 清空所有精灵
  hideSpriteArrFun: function (names) {
    names.forEach(name => {
      if (!!this[name]) {
        this[name].forEach(sprite => {
          if (!!sprite.visible) {
            sprite.visible = false;
          }
        })
      }
    })
  },

  isArray: function (obj) {
    return obj instanceof Array;
  },
  isObject: function (obj) {
    // 判断数组对象
    if (!(obj instanceof Array) && (obj instanceof Object)) {
      return true;
    }
    return false;
  },

  // 遍历数据
  traverse: function (obj, callback) {
    // 遍历json
    for (let name in obj) {
      // 如果是json对象
      if (this.isObject(obj[name])) {
        this.traverse(obj[name], callback);
      } else if (this.isArray(obj[name])) {
        // 数组对象
        obj[name].forEach(item => {
          this.traverse(item, callback);
        })
      } else {
        callback(name, obj[name]);
      }
    }
  },
  /**
   * 
   * @param {*} src 音频路径 可是数据
   * @param {*} name 音频名称
   */
  audioFun: function (src = null, loop = false, name = null,) {
    if (!!this.fAudio) {
      this.fAudio.destroy();
    }
    let tempAudio;
    if (!src) return
    if (this.isArray(src)) {
      if (!name) return
      for (let audioName in src) {
        let audioObj = src[audioName];
        if (!!name && name == audioName) {
          tempAudio = audioObj;
        }
      }
    } else {
      tempAudio = src;
    }
    const innerAudioContext = my.createInnerAudioContext();
    this.fAudio = innerAudioContext;
    if (!!tempAudio) {
      let src = tempAudio.src || tempAudio.src1;
      if (!!src) {
        this.fAudio.src = src;
        this.fAudio.loop = loop;
        this.fAudio.play();
      }
    }
  },
  /////////////////////////////////////////////////////////////////通用工具--end////////////////////////////////////////////////////////////////////////////////

  // pixi开始机制
  tickerStart: function () {
    this.gameStatus = true;
    this.AnimSpr.play();
    if (!!this.GameData.CountDown) {
      // 开始游戏时就计算出游戏结束时间
      this.overTime = new Date().getTime() + (this.GameData.CountDown.Time) * 1000;
    }
    this.setClockAnimShow(!this.GameData.clock.isAnimType && this.gameStatus);
  },
  // pixi停止机制
  tickerStop: function () {
    this.ticker.stop();
  },

  //游戏重置
  reset: function () {
    this.init();
    this.tickerStart();
  },

  //游戏结束
  gameOver: function () {
    this.audioFun();
    this.AnimSpr.stop();
    this.clockLower = 0;
    this.gameStatus = false;
    this.SwingSpr.step = 0;
    this.SwingSpr.rotation = 0;
    this.options.overFun({ totalScore: this.totalScore });
    return
    if (!this.gameStatus) { return false; }
    try {
      if (!!this.clipSprite.step) {
        this.curStep = this.clipSprite.step;
      }
      this.clipSprite.step = 0;
    } catch (e) { }
  },
});
//开始游戏并记录开始时间
Game.prototype.startGame = function () {
  if (!!this.gameStatus) { return false; }
  this.tickerStart();
}
export { Game };