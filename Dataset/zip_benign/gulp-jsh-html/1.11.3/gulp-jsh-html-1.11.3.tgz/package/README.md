
## Information

<table>
<tr>
<td>Package</td><td>gulp-jsh-html</td>
</tr>
<tr>
<td>Description</td>
<td>Edited JSHint plugin for gulp made for my needs</td>
</tr>
<tr>
<td>Node Version</td>
<td>>= 0.4</td>
</tr>
</table>


## Reporters

### jsh-stlsh-html

The MIT License (MIT)

