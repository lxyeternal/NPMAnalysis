import React, { Component } from "react";
import { PropTypes } from "prop-types";
import raf from "raf";
import { any as isMobile } from "../util/isMobile";
import {
  getPostion,
  isPassiveEventSupported,
  getSwippedDirection
} from "../util/util";

const LONG_PRESS_DURATION = 50;
const PREVENT_CLICK_TIME = 500;
const PREVENT_CLICK_MAX_FORCE = 0.5;

const SWIPE_THRESOLD = 150;
const SWIPE_ALLOWED_TIME = 300;
const SWIPE_RESTRAINT_TIME = 100;

const TOUCH_EVENTS = {
  start: "touchstart",
  move: "touchmove",
  end: "touchend",
  cancel: "touchcancel"
};

class Pressure extends Component {
  constructor(props) {
    super(props);
    this.state = {
      force: 0,
      initial: null,
      current: null
    };

    this.maxForceFired = 0;
    this.touchStartedTime = null;

    this.bindEvents = this.bindEvents.bind(this);
    this.invokeSwipedPosition = this.invokeSwipedPosition.bind(this);
    this.updateRefElement = this.updateRefElement.bind(this);

    this._handleTouchStart = this._handleTouchStart.bind(this);
    this._handleTouchMove = this._handleTouchMove.bind(this);
    this._handleTouchEnd = this._handleTouchEnd.bind(this);
    this._handleTouchForceChange = this._handleTouchForceChange.bind(this);
    //polyfill for multi tocuh
    this.counter = 0;
    this._pressingDown = this._pressingDown.bind(this);
    this._notPressingDown = this._notPressingDown.bind(this);
    this._longPressTimer = this._longPressTimer.bind(this);
  }

  componentDidMount() {
    if (isMobile()) {
      this.bindEvents();
    }
  }

  _handleTouchStart(e) {
    if (!this.refElement) {
      return;
    }
    this.touchStartedTime = new Date().getTime();

    const current = getPostion(e);
    this.setState({
      initial: current,
      current: current
    });

    const { config = {}, handleTouchStart } = this.props;
    handleTouchStart && handleTouchStart(e, current);

    const { preventDefault } = config;
    if (preventDefault) {
      e.preventDefault();
    }
  }

  _handleTouchMove(e) {
    if (!this.refElement) {
      return;
    }

    const { initial } = this.state;
    const current = getPostion(e);
    this.setState({
      current: current
    });

    const { config = {}, handleTouchMove } = this.props;

    handleTouchMove && handleTouchMove(e, initial, current);

    const { preventDefault } = config;
    if (preventDefault) {
      e.preventDefault();
    }
  }

  _handleTouchEnd(e) {
    if (!this.refElement) {
      return;
    }
    const current = getPostion(e);
    const { initial } = this.state;
    this.invokeSwipedPosition(e);

    const { config = {}, handleTouchEnd } = this.props;
    handleTouchEnd && handleTouchEnd(e, current);

    const { maxForceFired, touchStartedTime } = this;
    const timeDiff = new Date().getTime() - touchStartedTime;
    const {
      preventClickTime = PREVENT_CLICK_TIME,
      preventClickMaxForce = PREVENT_CLICK_MAX_FORCE,
      preventDefault
    } = config;

    if (timeDiff > preventClickTime || maxForceFired > preventClickMaxForce) {
      e.stopPropagation();
      if (e.type != "touchcancel") {
        e.preventDefault();
      }
    } else if (preventDefault) {
      e.preventDefault();
    }
    this.maxForceFired = 0;
    this.touchStartedTime = null;

    this.setState({
      initial: null,
      current: null
    });
  }

  _handleTouchForceChange(e) {
    if (!this.refElement) {
      return;
    }

    const { force } = getPostion(e);
    const { handleTouchForceChange } = this.props;
    handleTouchForceChange && handleTouchForceChange(force);

    const { maxForceFired } = this;
    if (maxForceFired < force) {
      this.maxForceFired = force;
    }
  }

  _pressingDown(e) {
    this._timerID = raf(this._longPressTimer);
  }

  _notPressingDown(e) {
    this.counter = 0;
    raf.cancel(this._timerID);
  }

  _longPressTimer() {
    const { config = {} } = this.props;
    const { longPressDuration = LONG_PRESS_DURATION } = config;

    let counter = this.counter;

    if (counter < longPressDuration) {
      this._timerID = raf(this._longPressTimer);
      ++counter;
      this.counter = counter;

      const force = counter / longPressDuration;
      const { handleTouchForceChange } = this.props;
      handleTouchForceChange && handleTouchForceChange(force);

      const { maxForceFired } = this;
      if (maxForceFired < force) {
        this.maxForceFired = force;
      }
    }
  }

  bindEvents() {
    const container = this.refElement;
    if (!container) {
      return;
    }

    const { config = {} } = this.props;
    const { preventDefault, skipPassiveEvent = false } = config;

    let configObj = false;
    if (!preventDefault && !skipPassiveEvent) {
      configObj = isPassiveEventSupported() ? { passive: false } : false;
    }

    container.style["touch-action"] = "pan-y";
    container.style["-ms-touch-action"] = "pan-y";
    container.style["-webkit-tap-highlight-color"] = "rgba(0,0,0,0)";
    container.style.webkitTouchCallout = "none";
    container.style.webkitUserSelect = "none";
    container.style.khtmlUserSelect = "none";
    container.style.MozUserSelect = "none";
    container.style.msUserSelect = "none";
    container.style.userSelect = "none";
    container.style.outline = "none";

    const { start, move, end, cancel } = TOUCH_EVENTS;

    container.addEventListener(start, this._handleTouchStart, configObj);
    container.addEventListener(move, this._handleTouchMove, configObj);
    container.addEventListener(end, this._handleTouchEnd, false);
    container.addEventListener(cancel, this._handleTouchEnd, false);
    if ("ontouchforcechange" in window.document) {
      const evt = "touchforcechange";
      container.addEventListener(evt, this._handleTouchForceChange, configObj);
    } else {
      //run the polyfill by touch
      container.addEventListener(start, this._pressingDown, configObj);
      container.addEventListener(end, this._notPressingDown, configObj);
      container.addEventListener(cancel, this._notPressingDown, configObj);
    }
  }

  invokeSwipedPosition(e) {
    const current = getPostion(e);

    const { maxForceFired, touchStartedTime } = this;
    const elapsedTime = new Date().getTime() - touchStartedTime;

    const { initial } = this.state;
    const { config = {} } = this.props;
    const {
      swipeThresold = SWIPE_THRESOLD,
      swipeAllowedTime = SWIPE_ALLOWED_TIME,
      swipeRestraint = SWIPE_RESTRAINT_TIME
    } = config;

    let swipedir = getSwippedDirection(
      initial,
      current,
      swipeThresold,
      swipeRestraint,
      swipeAllowedTime,
      elapsedTime
    );

    if (swipedir !== "none") {
      const handler = this.props[`handleSwipe${swipedir}`];
      handler && handler(initial, current);
    }
  }

  updateRefElement(el) {
    this.refElement = el;
  }

  render() {
    let { props } = this;
    const { children } = props;
    return React.cloneElement(React.Children.only(children), {
      ref: ele => {
        this.updateRefElement(ele);
        const { ref } = children;
        if (typeof ref === "function") {
          ref(ele);
        }
      }
    });
  }
}

Pressure.propTypes = {
  children: PropTypes.element.isRequired,
  handleTouchStart: PropTypes.func,
  handleTouchMove: PropTypes.func,
  handleTouchForceChange: PropTypes.func,
  handleTouchEnd: PropTypes.func,
  handleSwipeLeft: PropTypes.func,
  handleSwipeRight: PropTypes.func,
  handleSwipeUp: PropTypes.func,
  handleSwipeDown: PropTypes.func,
  config: PropTypes.shape({
    longPressDuration: PropTypes.number,
    preventClickTime: PropTypes.number,
    preventClickMaxForce: PropTypes.number,
    preventDefault: PropTypes.bool,
    skipPassiveEvent: PropTypes.bool,
    swipeThresold: PropTypes.number,
    swipeRestraint: PropTypes.number,
    swipeAllowedTime: PropTypes.number
  })
};

export default Pressure;
