export function getPostion(e) {
  const touchobj = e.changedTouches[0];
  const { pageX, pageY, clientX, clientY, force } = touchobj;
  return { pageX, pageY, clientX, clientY, force };
}

export function isPassiveEventSupported() {
  let supportsPassive = false;
  try {
    var opts = Object.defineProperty({}, "passive", {
      get: function() {
        supportsPassive = true;
      }
    });
    window.addEventListener("testPassive", null, opts);
    window.removeEventListener("testPassive", null, opts);
  } catch (e) {}
  return supportsPassive;
}

export function getSwippedDirection(
  initial,
  current,
  threshold,
  restraint,
  allowedTime,
  elapsedTime
) {
  const { pageX, pageY } = initial;
  const distX = current.pageX - pageX;
  const distY = current.pageY - pageY;

  let swipedir = "none";
  if (elapsedTime <= allowedTime) {
    if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint) {
      swipedir = distX < 0 ? "Left" : "Right";
    } else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint) {
      swipedir = distY < 0 ? "Up" : "Down";
    }
  }
  return swipedir;
}

//un used util methods.
export function angelBetweenTwoPoints(startX, endX, startY, endY) {
  const deltaX = Math.abs(endX - startX);
  const deltaY = Math.abs(endY - startY);
  return (Math.atan2(deltaY, deltaX) * 180) / Math.PI;
}

export function distanceBetweenTwoPoints(startX, endX, startY, endY) {
  const deltaX = Math.abs(startX - endX);
  const deltaY = Math.abs(startY - endY);
  return Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
}

export function getVelocity(startX, startY, startTime, endX, endY, endTime) {
  let distance = distanceBetweenTwoPoints(startX, endX, startY, endY);
  return distance / (endTime - startTime);
}
