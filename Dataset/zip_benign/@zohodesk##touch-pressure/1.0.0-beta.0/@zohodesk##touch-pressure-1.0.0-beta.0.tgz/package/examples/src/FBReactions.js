import React, { Component } from "react";
import styles from "./css/FBReactions.css";
import Pressure from "@zohodesk/touch-pressure";

const EMOJIS = ["Like", "Love", "Haha", "Wow", "Sad", "Angry"];

class FBReactions extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpened: false,
      likeText: "Like",
      animateSelected: false
    };
    this.handleTouchForceChange = this.handleTouchForceChange.bind(this);
    this.updateReaction = this.updateReaction.bind(this);
    this.hideEmojiAnimation = this.hideEmojiAnimation.bind(this);
  }

  handleTouchForceChange(force) {
    const { onOpen, onClose } = this.props;
    if (force > 0.5) {
      this.setState({ isOpened: true, animateSelected: false });
      onOpen && onOpen();
    }
  }

  hideEmojiAnimation(reaction, e) {
    e.currentTarget.classList.remove(styles["reaction-selected"]);
    this.setState({
      likeText: reaction,
      isOpened: false,
      animateSelected: true
    });
    const { onChange } = this.props;
    onChange && onChange(reaction.toLowerCase());
  }

  updateReaction(reaction, e) {
    e.preventDefault();
    e.currentTarget.removeEventListener(
      "transitionend",
      this.hideEmojiAnimation
    );
    e.currentTarget.addEventListener(
      "transitionend",
      this.hideEmojiAnimation.bind(null, reaction)
    );
    e.currentTarget.classList.add(styles["reaction-selected"]);
  }

  componentDidMount() {
    const { selected } = this.props;
    if (EMOJIS.indexOf(selected) !== -1) {
      this.setState({ likeText: selected });
    }
  }

  render() {
    const { isOpened, likeText, animateSelected } = this.state;

    let emojis = [...EMOJIS].map((reaction, i) => {
      let emojiClass =
        styles.reaction + " " + styles["reaction-" + reaction.toLowerCase()];
      return (
        <li
          className={emojiClass}
          key={i}
          onClick={this.updateReaction.bind(null, reaction)}
        />
      );
    });

    let containerClass = isOpened
      ? styles["like-btn"] + " " + styles["like-btn-open"]
      : styles["like-btn"];

    let selectedClass = styles["like-btn-emo"];
    if (animateSelected) {
      selectedClass += " " + styles.emojiActive;
    }
    if (likeText === "Like") {
      selectedClass += " " + styles["like-btn-default"];
    } else {
      selectedClass += " " + styles["like-btn-" + likeText.toLowerCase()];
    }
    return (
      <div className={styles["facebook-reaction"]}>
        <span className={selectedClass} />
        <span className={containerClass}>
          <Pressure handleTouchForceChange={this.handleTouchForceChange}>
            <span className={styles["like-btn-text"]}>{likeText}</span>
          </Pressure>
          <ul className={styles["reactions-box"]}>{emojis}</ul>
        </span>
      </div>
    );
  }
}

export default FBReactions;
