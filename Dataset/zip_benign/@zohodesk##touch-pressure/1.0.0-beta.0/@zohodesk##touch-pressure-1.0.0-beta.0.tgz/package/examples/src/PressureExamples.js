import React, { Component } from "react";
import { Link } from "react-router-dom";

import AssistiveTouch from "./AssistiveTouch";
import Carousel from "./Carousel";
import ThreeDTouch from "./ThreeDTouch";
import styles from "./css/PressureExamples.css";

class PressureExamples extends Component {
  render() {
    return (
      <div>
        <div>
          <h1>Touch Examples</h1>
          <ul>
            <li>
              <Link to="/assistiveTouch">Assistive Touch</Link>
            </li>
            <li>
              <Link to="/carousel">Carousel</Link>
            </li>
            <li>
              <Link to="/3dTouch">3d Touch</Link>
            </li>
            <li>
              <Link to="/moon3DTouch">Moon 3D touch</Link>
            </li>
            <li>
              <Link to="/myApp">Swipable List App</Link>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}

export default PressureExamples;
