import React, { Component } from "react";
import { Link } from "react-router-dom";
import Pressure from "@zohodesk/touch-pressure";
import styles from "./css/Moon3DTouch.css";

export default class Moon3DTouch extends Component {
  constructor(props) {
    super(props);

    this.state = {
      force: 0
    };

    this.handleTouchStart = this.handleTouchStart.bind(this);
    this.handleTouchMove = this.handleTouchMove.bind(this);
    this.handleTouchForceChange = this.handleTouchForceChange.bind(this);
    this.handleTouchEnd = this.handleTouchEnd.bind(this);
    this.updateForce = this.updateForce.bind(this);
  }

  handleTouchStart(e, data) {
    this.updateForce(data);
  }

  handleTouchMove(e, initial, data) {
    this.updateForce(data);
  }

  handleTouchForceChange(force) {
    this.updateForce({ force });
  }

  handleTouchEnd(e, data) {
    this.updateForce(data);
  }

  updateForce(data) {
    let force = 0;
    if (data) {
      force = data.force;
    }
    this.setState({ force: force });
  }

  render() {
    const { force } = this.state;
    let forceTouchStyle = {};
    let bgStyle = {};

    if (force !== 0) {
      const transform =
        "translateX(-50%) translateY(-50%) scale(" + (1 + force * 1.5) + ")";
      const filter = "blur(" + force * 30 + "px)";
      forceTouchStyle = { webkitTransform: transform, transform };
      bgStyle = { filter, webkitFilter: filter };
    }

    return (
      <Pressure
        handleTouchStart={this.handleTouchStart}
        handleTouchMove={this.handleTouchMove}
        handleTouchForceChange={this.handleTouchForceChange}
        handleTouchEnd={this.handleTouchEnd}
      >
        <div className={styles.container}>
          <h1>3D Touch</h1>
          <p>Touch the sun on your 3D Touch enabled device.</p>
          <div id="background" style={bgStyle} className={styles.background} />
          <div
            id="forceMe"
            style={forceTouchStyle}
            className={styles.forceMe}
          />
          <div id="forceValue" className={styles.forceValue}>
            Force: {force}
          </div>

          <div id="footer" className={styles.footer}>
            <a href="https://github.com/freinbichler/3d-touch">
              Credits to @freinbichler
            </a>
          </div>
        </div>
      </Pressure>
    );
  }
}
