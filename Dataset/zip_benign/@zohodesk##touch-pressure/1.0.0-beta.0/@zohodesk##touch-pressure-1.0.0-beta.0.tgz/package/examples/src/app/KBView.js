import React, { Component } from "react";
import { Link } from "react-router-dom";
import Pressure from "@zohodesk/touch-pressure";
import { fetchAPI } from "../util/util";

const APIURL = "htt" + "ps://desk.zoho.com/portal/api/kbArticles";
const DEFAULT_PARAMS =
  "portalId=bf176ef04452afb226b71d032f1e8bd25fdf45fd13ed1e6d";

class KBView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      data: {}
    };
    this.handleSwipeRight = this.handleSwipeRight.bind(this);
  }

  handleSwipeRight() {
    const { router } = this.props;
    router.goBack();
  }

  componentDidMount() {
    const { id } = this.props.params;
    let data = JSON.parse(localStorage.getItem("articleInfo-v1")) || {};
    if (!data.hasOwnProperty(id)) {
      fetchAPI(`${APIURL}/${id}?${DEFAULT_PARAMS}`).then(res => {
        data[id] = res;
        localStorage.setItem("articleInfo-v1", JSON.stringify(data));
        this.setState({ loading: false, data: res });
      });
    } else {
      this.setState({ loading: false, data: data[id] });
    }
  }

  render() {
    const { loading, data } = this.props;
    if (loading) {
      return <div>Loading..</div>;
    }
    const { title, answer } = this.state.data;
    return (
      <Pressure
        handleSwipeRight={this.handleSwipeRight}
        config={{ swipeDistance: 75 }}
      >
        <div style={{ padding: "10px" }}>
          <div>
            <Link to="/myApp">Back</Link>
          </div>
          <div>
            <h3>{title}</h3>
          </div>
          <div>
            <p dangerouslySetInnerHTML={{ __html: answer }} />
          </div>
        </div>
      </Pressure>
    );
  }
}
export default KBView;
