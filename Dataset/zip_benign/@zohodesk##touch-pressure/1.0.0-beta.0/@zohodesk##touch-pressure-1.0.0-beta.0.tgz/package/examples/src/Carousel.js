import React, { Component } from "react";
import styles from "./css/Carousel.css";
import Pressure from "@zohodesk/touch-pressure";
import ImageContent from "./ImageContent";
import ImageWrapper from "./ImageWrapper";
import { Link } from "react-router-dom";

const DIRECTIONS = { left: "LEFT", right: "RIGHT", up: "UP", down: "DOWN" };

class Carousel extends Component {
  constructor(props) {
    super(props);

    this.state = {
      initial: null,
      current: null,
      selIndex: 1,
      totalLength: 11
    };

    this.handleTouchMove = this.handleTouchMove.bind(this);
    this.handleSwipeLeft = this.handleSwipeLeft.bind(this);
    this.handleSwipeRight = this.handleSwipeRight.bind(this);
  }

  handleSwipeLeft() {
    let { selIndex, totalLength } = this.state;
    selIndex = selIndex + 1;
    if (selIndex > totalLength) {
      selIndex = 1;
    }

    this.setState({
      selIndex
    });
  }

  handleSwipeRight() {
    let { selIndex, totalLength } = this.state;
    selIndex = selIndex - 1;
    if (selIndex === 0) {
      selIndex = totalLength;
    }

    this.setState({
      selIndex
    });
  }

  handleTouchMove(e, initial, current) {
    const { clientX, clientY } = initial;
    let deltaX = clientX - current.clientX;
    let deltaY = clientY - current.clientY;

    let direction = null;
    let distance = 0;
    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      if (deltaX > 0) {
        direction = DIRECTIONS.left;
      } else {
        direction = DIRECTIONS.right;
      }
    } else {
      if (deltaY > 0) {
        direction = DIRECTIONS.up;
      } else {
        direction = DIRECTIONS.down;
      }
    }

    if ([DIRECTIONS.left, DIRECTIONS.right].indexOf(direction) !== -1) {
      e.preventDefault();
    }
  }

  render() {
    let images = [];
    for (let i = 1; i <= 11; i++) {
      images.push(
        <ImageContent id={i} key={i}>
          <img
            src={"/images/wallpaper" + i + ".jpg"}
            className={styles.images}
          />
        </ImageContent>
      );
    }

    return (
      <Pressure
        handleTouchMove={this.handleTouchMove}
        handleSwipeLeft={this.handleSwipeLeft}
        handleSwipeRight={this.handleSwipeRight}
        config={{ swipeDistance: 50 }}
      >
        <div>
          <div>
            <Link to="/">Back</Link>
          </div>
          <ImageWrapper defaultIndex={this.state.selIndex}>
            {images}
          </ImageWrapper>
        </div>
      </Pressure>
    );
  }
}

export default Carousel;
