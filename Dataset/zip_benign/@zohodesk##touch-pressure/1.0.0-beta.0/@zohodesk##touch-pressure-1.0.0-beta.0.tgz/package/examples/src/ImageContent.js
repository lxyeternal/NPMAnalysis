import styles from "./css/ImageWrapper.css";
import React, { Component } from "react";

class ImageContent extends Component {
  render() {
    return (
      <div
        className={this.props.imgClass + " " + styles.item}
        style={this.props.style}
      >
        {this.props.children}
      </div>
    );
  }
}

export default ImageContent;
