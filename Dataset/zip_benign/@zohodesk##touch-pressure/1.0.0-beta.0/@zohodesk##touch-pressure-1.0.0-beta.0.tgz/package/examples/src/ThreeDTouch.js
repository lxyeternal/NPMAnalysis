import React, { Component } from "react";
import styles from "./css/ThreeDTouch.css";
import { Link } from "react-router-dom";
import Pressure from "@zohodesk/touch-pressure";
import { map } from "./util/util";

export default class ThreeDTouch extends Component {
  constructor(props) {
    super(props);

    this.state = {
      force: 0
    };

    this.handleTouchStart = this.handleTouchStart.bind(this);
    this.handleTouchMove = this.handleTouchMove.bind(this);
    this.handleTouchForceChange = this.handleTouchForceChange.bind(this);
    this.handleTouchEnd = this.handleTouchEnd.bind(this);
    this.updateForce = this.updateForce.bind(this);
  }

  handleTouchStart(e, data) {
    this.updateForce(data);
  }

  handleTouchMove(e, initial, data) {
    this.updateForce(data);
  }

  handleTouchForceChange(force) {
    this.updateForce({ force });
  }

  handleTouchEnd(e, data) {
    this.updateForce(data);
  }

  updateForce(data) {
    let force = 0;
    if (data) {
      force = data.force;
    }
    this.setState({ force: force });
  }

  render() {
    const { force } = this.state;
    let style = {
      width: "10em",
      height: "10em",
      marginTop: "-5em",
      marginLeft: "-5em" /*,
      backgroundColor: "#d9534f"*/
    };

    if (force !== 0) {
      const size = map(force, 0, 1, 10, 50);

      style = {
        width: size + "em",
        height: size + "em",
        marginTop: "-" + size / 2 + "em",
        marginLeft:
          "-" + size / 2 + "em" /*,
        backgroundColor: "#5bc0de"*/
      };
    }

    return (
      <Pressure
        handleTouchStart={this.handleTouchStart}
        handleTouchMove={this.handleTouchMove}
        handleTouchForceChange={this.handleTouchForceChange}
        handleTouchEnd={this.handleTouchEnd}
      >
        <div>
          <div>
            <Link to="/">Back</Link>
          </div>
          <div className={styles.circle} id="holder" style={style} />
        </div>
      </Pressure>
    );
  }
}
