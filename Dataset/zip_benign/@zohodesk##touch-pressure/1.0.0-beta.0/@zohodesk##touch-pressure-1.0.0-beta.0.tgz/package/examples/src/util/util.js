export function map(x, in_min, in_max, out_min, out_max) {
  return ((x - in_min) * (out_max - out_min)) / (in_max - in_min) + out_min;
}

export function fetchAPI(url) {
  return fetch(url).then(res => res.json());
}

export function isValidTouch(e) {
  return e.touches.length === 1;
}

export function getTransformStyleObj(distance) {
  return { transform: "translate3d(" + distance + "px,0, 0)" };
}

export function getDragSwipeStyleInfo(distance) {
  let left = {};
  let right = {};
  let center = getTransformStyleObj(distance);
  if (distance < 0) {
    right = center;
  } else {
    left = center;
  }

  return {
    left,
    center,
    right
  };
}

export function getRotateSwipeStyleInfo(
  distance,
  leftActionContainer,
  rightActionContainer
) {
  if (!leftActionContainer || !rightActionContainer) {
    return {};
  }

  let left = {};
  let right = {};
  let center = {};
  let centerDist = 0;

  if (distance > 0) {
    let leftFlip = 240;
    let persetenage = 1 - distance / leftFlip;
    centerDist = leftActionContainer.getBoundingClientRect().width.toFixed(2);
    left = { transform: "rotateY(" + 102 * persetenage + "deg)" };

    right = { transform: "rotateY(-102deg)" };
  } else {
    let rightFlip = -160;
    let persetenage = 1 - distance / rightFlip;
    centerDist = -rightActionContainer.getBoundingClientRect().width.toFixed(2);
    left = { transform: "rotateY(102deg)" };

    right = { transform: "rotateY(-" + 102 * persetenage + "deg)" };
  }

  center = getTransformStyleObj(centerDist);

  return {
    left,
    center,
    right
  };
}

export function getBorderSwipeStyleInfo(distance) {
  let leftItems = [];
  let rightItems = [];
  let center = getTransformStyleObj(distance);

  if (distance > 0) {
    leftItems.push(getTransformStyleObj(distance * (1 / 3)));
    leftItems.push(getTransformStyleObj(distance * (1 / 3) * 2));
    leftItems.push(getTransformStyleObj(distance * (1 / 3) * 3));
  } else {
    rightItems.push(getTransformStyleObj(distance * (1 / 2)));
    rightItems.push(getTransformStyleObj(distance));
  }

  return {
    leftItems,
    center,
    rightItems
  };
}

export function getStaticSwipeStyleInfo(distance) {
  let center = getTransformStyleObj(distance);
  return { center };
}
