import React, { Component } from "react";
import styles from "./css/AssistiveTouch.css";
import Pressure from "@zohodesk/touch-pressure";
import { Link } from "react-router-dom";

class AssistiveTouch extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isOpened: false
    };

    this.handleTouchForceChange = this.handleTouchForceChange.bind(this);
    this.bindCloseEvent = this.bindCloseEvent.bind(this);
    this.unbindCloseEvent = this.unbindCloseEvent.bind(this);
    this.handleCloseAssitiveTouch = this.handleCloseAssitiveTouch.bind(this);
    this.updateRef = this.updateRef.bind(this);
  }

  unbindCloseEvent() {
    document.removeEventListener("touchstart", this.handleCloseAssitiveTouch);
  }

  bindCloseEvent() {
    document.addEventListener("touchstart", this.handleCloseAssitiveTouch);
  }

  handleCloseAssitiveTouch(e) {
    const { isOpened } = this.state;
    if (!isOpened) {
      return;
    }
    this.setState({ isOpened: false });
  }

  componentDidMount() {
    this.bindCloseEvent();
  }

  componentWillUnmount() {
    this.unbindCloseEvent();
  }

  handleTouchForceChange(force) {
    if (force > 0.5) {
      this.setState({ isOpened: true });
    }
  }

  updateRef(ele) {
    this.refElement = ele;
  }

  render() {
    const { isOpened } = this.state;
    const parentClass = isOpened
      ? "fa " + styles.o + " fa-times"
      : "fa " + styles.o + " fa-circle-thin";
    const ballClass = isOpened ? styles.tog : "fa " + styles.display;
    const insideIconClass = isOpened ? "fa" : "fa " + styles.view;

    return (
      <div>
        <div>
          <Link to="/">Back</Link>
        </div>
        <Pressure handleTouchForceChange={this.handleTouchForceChange}>
          <div className={styles.stickyball} ref={this.updateRef}>
            <i className={parentClass} />
            <div className={ballClass + " " + styles.ball1}>
              <i className={insideIconClass + " fa-square-o"} />
            </div>
            <div className={ballClass + " " + styles.ball2}>
              <i className={insideIconClass + " fa-bars"} />
            </div>
            <div className={ballClass + " " + styles.ball3}>
              <i className={insideIconClass + " fa-lock"} />
            </div>
            <div className={ballClass + " " + styles.ball4}>
              <i className={insideIconClass + " fa-scissors"} />
            </div>
            <div className={ballClass + " " + styles.ball5}>
              <i className={insideIconClass + " fa-chevron-left"} />
            </div>
          </div>
        </Pressure>
      </div>
    );
  }
}

export default AssistiveTouch;
