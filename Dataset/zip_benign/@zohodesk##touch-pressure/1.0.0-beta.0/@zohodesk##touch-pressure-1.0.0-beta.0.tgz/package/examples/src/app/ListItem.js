import React, { Component } from "react";
import { Link } from "react-router-dom";
import ReactDOM from "react-dom";
import Pressure from "@zohodesk/touch-pressure";
import styles from "../css/ListItem.css";
import { CommonFontIcon } from "@zohodesk/components";
import {
  isValidTouch,
  getTransformStyleObj,
  getDragSwipeStyleInfo,
  getRotateSwipeStyleInfo,
  getBorderSwipeStyleInfo,
  getStaticSwipeStyleInfo
} from "../util/util";

import FBReactions from "../FBReactions";

const RIGHT_ACTIONS_WIDTH = -160;
const LEFT_ACTIONS_WIDTH = 240;

const DIRECTIONS = { left: "LEFT", right: "RIGHT", up: "UP", down: "DOWN" };

class ListItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isTouched: false,
      distance: 0,
      lastPostion: 0,
      scrollTop: null,
      popupId: null,
      isReactionsOpened: false
    };
    this.handleTouchStart = this.handleTouchStart.bind(this);
    this.handleTouchEnd = this.handleTouchEnd.bind(this);
    this.handleTouchMove = this.handleTouchMove.bind(this);
    this.getStyleInfo = this.getStyleInfo.bind(this);
    this.handleRectionOpen = this.handleRectionOpen.bind(this);
    this.handleRectionClose = this.handleRectionClose.bind(this);
    this.updateLeftActionRef = this.updateLeftActionRef.bind(this);
    this.updateRightActionRef = this.updateRightActionRef.bind(this);
  }

  updateLeftActionRef(ele) {
    this.leftActionContainer = ele;
  }

  updateRightActionRef(ele) {
    this.rightActionContainer = ele;
  }

  handleRectionOpen() {
    this.setState({ isReactionsOpened: true });
  }

  handleRectionClose(reaction) {
    this.setState({ isReactionsOpened: false });
  }

  handleTouchStart(e, data) {
    const { selectRecord, selectedId, id } = this.props;
    let { distance, isReactionsOpened } = this.state;
    if (isReactionsOpened) {
      return;
    }

    if (id !== selectedId) {
      selectRecord(id);
    }

    this.setState({
      isTouched: true,
      distance,
      lastPostion: distance,
      initial: data
    });
  }

  handleTouchEnd(e, current) {
    let { distance, lastPostion, isReactionsOpened, initial } = this.state;
    if (isReactionsOpened) {
      return;
    }

    if (distance !== 0) {
      let persetenage = 0;
      if (distance > 0) {
        persetenage = (distance / LEFT_ACTIONS_WIDTH) * 100;

        if (
          lastPostion === LEFT_ACTIONS_WIDTH &&
          lastPostion !== distance &&
          distance < LEFT_ACTIONS_WIDTH
        ) {
          distance = 0;
        } else if (persetenage >= 30) {
          distance = LEFT_ACTIONS_WIDTH;
        } else {
          distance = 0;
        }
      } else {
        persetenage = (distance / RIGHT_ACTIONS_WIDTH) * 100;

        persetenage = Math.abs(persetenage);
        if (
          lastPostion === RIGHT_ACTIONS_WIDTH &&
          lastPostion !== distance &&
          distance > RIGHT_ACTIONS_WIDTH
        ) {
          distance = 0;
        } else if (persetenage >= 30) {
          distance = RIGHT_ACTIONS_WIDTH;
        } else {
          distance = 0;
        }
      }
    }

    this.setState({
      isTouched: false,
      distance,
      lastPostion: distance
    });
  }

  handleTouchMove(e, initial, current) {
    const { closePopup } = this.props;
    let { isTouched, lastPostion, isReactionsOpened } = this.state;
    if (isReactionsOpened || !isValidTouch(e)) {
      return;
    }
    closePopup();

    if (!isTouched) {
      return;
    }

    const { clientX, clientY } = initial;
    let deltaX = clientX - current.clientX;
    let deltaY = clientY - current.clientY;

    let direction = null;
    let distance = 0;
    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      if (deltaX > 0) {
        direction = DIRECTIONS.left;
      } else {
        direction = DIRECTIONS.right;
      }
    } else {
      if (deltaY > 0) {
        direction = DIRECTIONS.up;
      } else {
        direction = DIRECTIONS.down;
      }
    }

    deltaX = current.clientX - clientX;

    if ([DIRECTIONS.left, DIRECTIONS.right].indexOf(direction) !== -1) {
      e.preventDefault();
      deltaX = lastPostion + deltaX;
      deltaX = Math.max(deltaX, RIGHT_ACTIONS_WIDTH);
      deltaX = Math.min(deltaX, LEFT_ACTIONS_WIDTH);
    } else {
      deltaX = 0;
    }

    this.setState({
      distance: deltaX
    });
  }

  getStyleInfo() {
    const { selectedId, id, swipeType = "Drag" } = this.props;
    const { distance } = this.state;
    if (selectedId !== id || distance === 0) {
      return {};
    }
    if (swipeType === "Drag") {
      return getDragSwipeStyleInfo(distance);
    }
    if (swipeType === "Static") {
      return getStaticSwipeStyleInfo(distance);
    }
    if (swipeType === "Rotate3D") {
      return getRotateSwipeStyleInfo(
        distance,
        this.leftActionContainer,
        this.rightActionContainer
      );
    }
    if (swipeType === "Border") {
      return getBorderSwipeStyleInfo(distance);
    }
    return null;
  }

  render() {
    const { popupId } = this.state;
    const { id, char, subject, info, reaction, swipeType } = this.props;
    const { left, leftItems = [], center, right, rightItems = [] } =
      this.getStyleInfo() || {};

    let containerClass = styles.item;
    containerClass += " " + styles[swipeType.toLowerCase() + "Trans"];

    return (
      <Pressure
        handleTouchStart={this.handleTouchStart}
        handleTouchEnd={this.handleTouchEnd}
        handleTouchMove={this.handleTouchMove}
        config={{ swipeDistance: 0, skipPassiveEvent: true }}
      >
        <div className={containerClass}>
          <div
            className={styles.slideListActLeft}
            style={left}
            ref={this.updateLeftActionRef}
          >
            <div
              className={styles.iconBox + " " + styles.blueBg}
              style={leftItems[0]}
            >
              <CommonFontIcon name="emailDft" size="large" />
            </div>
            <div
              className={styles.iconBox + " " + styles.greenBg}
              style={leftItems[1]}
            >
              <CommonFontIcon name="circlePlus" size="large" />
            </div>
            <div
              className={styles.iconBox + " " + styles.brownBg}
              style={leftItems[2]}
            >
              <CommonFontIcon name="information57" size="large" />
            </div>
          </div>

          <div className={styles.slideDiv} style={center}>
            <i>{char}</i>
            <div className={styles.slideListCont}>
              <b>
                <Link to={`/myApp/${id}`}>{subject}</Link>
              </b>
              <span>{info}</span>
              <div style={{ marginTop: "5px" }}>
                <FBReactions
                  selected={reaction}
                  onOpen={this.handleRectionOpen}
                  onChange={this.handleRectionClose}
                />

                <span>Type : {swipeType}</span>
              </div>
            </div>
          </div>

          <div
            className={styles.slideListActRgt}
            style={right}
            ref={this.updateRightActionRef}
          >
            <div
              className={styles.iconBox + " " + styles.greyBg}
              style={rightItems[0]}
            >
              <span>More</span>
            </div>
            <div
              className={styles.iconBox + " " + styles.redBg}
              style={rightItems[1]}
            >
              <span>Delete</span>
            </div>
          </div>
        </div>
      </Pressure>
    );
  }
}

export default ListItem;
