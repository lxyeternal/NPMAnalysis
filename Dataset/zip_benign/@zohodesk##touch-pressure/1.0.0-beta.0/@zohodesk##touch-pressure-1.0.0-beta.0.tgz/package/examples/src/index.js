import React, { Component } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { render } from "react-dom";

import PressureExamples from "./PressureExamples";
import MyApp from "./app/MyApp";
import KBView from "./app/KBView";
import AssistiveTouch from "./AssistiveTouch";
import Carousel from "./Carousel";
import ThreeDTouch from "./ThreeDTouch";
import Moon3DTouch from "./Moon3DTouch";

render(
  <BrowserRouter>
    <div>
      <Switch>
        <Route path="/" component={PressureExamples} exact />
        <Route path="/assistiveTouch" component={AssistiveTouch} />
        <Route path="/carousel" component={Carousel} />
        <Route path="/3dTouch" component={ThreeDTouch} />
        <Route path="/moon3DTouch" component={Moon3DTouch} />
        <Route path="/myApp" component={MyApp} />
        <Route path="/myApp/:id" component={KBView} />
      </Switch>
    </div>
  </BrowserRouter>,
  document.getElementById("root")
);
