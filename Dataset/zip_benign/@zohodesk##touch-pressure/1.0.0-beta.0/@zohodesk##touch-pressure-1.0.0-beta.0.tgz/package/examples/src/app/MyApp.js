import React, { Component } from "react";
import ListItem from "./ListItem";
import { Link } from "react-router-dom";
import styles from "../css/MyApp.css";
import { fetchAPI } from "../util/util";

const EMOJIS = ["Like", "Love", "Haha", "Wow", "Sad", "Angry"];
const SWIPABLE_TYPES = ["Border", "Rotate3D", "Static", "Drag"];

const APIURL = "htt" + "ps://desk.zoho.com/portal/api/kbArticles";
const DEFAULT_PARAMS =
  "portalId=bf176ef04452afb226b71d032f1e8bd25fdf45fd13ed1e6d";

class MyApp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      selectedId: null,
      isFetching: false,
      popupSelectedId: null,
      popupData: null
    };
    this.selectRecord = this.selectRecord.bind(this);
    this.goToDetailView = this.goToDetailView.bind(this);
    this.displayPopup = this.displayPopup.bind(this);
    this.getPopupComponent = this.getPopupComponent.bind(this);

    this.closePopup = this.closePopup.bind(this);
  }

  closePopup(e) {
    const { popupSelectedId } = this.state;
    if (popupSelectedId === null) {
      return;
    }
    this.setState({
      popupSelectedId: null,
      popupData: null,
      isFetching: false
    });
  }

  selectRecord(id) {
    this.setState({ selectedId: id });
  }

  displayPopup(id, title) {
    const { popupSelectedId } = this.state;
    if (popupSelectedId === id) {
      return;
    }

    let data = JSON.parse(localStorage.getItem("articleInfo-v1")) || {};
    if (!data.hasOwnProperty(id)) {
      this.setState({
        isFetching: true,
        popupSelectedId: id,
        popupData: { title, answer: "loading.." }
      });
      fetchAPI(`${APIURL}/${id}?${DEFAULT_PARAMS}`).then(res => {
        data[id] = res;
        localStorage.setItem("articleInfo-v1", JSON.stringify(data));
        this.setState({ popupData: res, isFetching: false });
      });
    } else {
      this.setState({
        popupData: data[id],
        popupSelectedId: id,
        isFetching: false
      });
    }
  }
  componentDidMount() {
    let data = localStorage.getItem("articles-v1");
    if (!data) {
      fetchAPI(`${APIURL}?${DEFAULT_PARAMS}&limit=100`).then(res => {
        res = res.data.map((item, i) => {
          const { id, title, summary } = item;
          return {
            id: id,
            char: title.charAt(0),
            subject: title,
            info: summary.length > 100 ? summary.substring(0, 100) : summary,
            reaction: EMOJIS[Math.round(Math.random() * 6)]
          };
        });
        localStorage.setItem("articles-v1", JSON.stringify(res));
        this.setState({ data: res });
      });
    } else {
      this.setState({ data: JSON.parse(data) });
    }
  }

  goToDetailView(id) {
    const { router } = this.props;
    router.push("/myApp/" + id);
  }

  getPopupComponent() {
    let { popupSelectedId, popupData } = this.state;
    const isPopOpened = popupSelectedId !== null;
    let popupComponent = null;
    if (isPopOpened) {
      const { title, answer } = popupData;

      popupComponent = (
        <div>
          <div className={styles.freezeLayer} onClick={this.closePopup} />
          <div className={styles.detailspopup}>
            <div>
              <h3>{title}</h3>
            </div>
            <div>
              <p dangerouslySetInnerHTML={{ __html: answer }} />
            </div>
          </div>
        </div>
      );
    }
    return popupComponent;
  }

  render() {
    let { data } = this.state;

    let popupComponent = this.getPopupComponent();
    let containerStyle = popupComponent !== null ? styles.blur : null;

    data = data.map((item, i) => {
      return (
        <ListItem
          {...item}
          selectedId={this.state.selectedId}
          selectRecord={this.selectRecord}
          goToDetailView={this.goToDetailView}
          displayPopup={this.displayPopup}
          closePopup={this.closePopup}
          swipeType={SWIPABLE_TYPES[i % SWIPABLE_TYPES.length]}
          key={i}
        />
      );
    });
    return (
      <div>
        <div className={containerStyle}>
          <div>
            <Link to="/">Back</Link>
          </div>
          <div>{data}</div>
        </div>
        <div>{popupComponent}</div>
      </div>
    );
  }
}

export default MyApp;
