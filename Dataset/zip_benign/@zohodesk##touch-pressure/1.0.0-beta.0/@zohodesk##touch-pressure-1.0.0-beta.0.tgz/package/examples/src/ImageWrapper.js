import React, { Component } from "react";
import styles from "./css/ImageWrapper.css";

class ImageWrapper extends Component {
  constructor(props) {
    super(props);
    this.state = {};

    this.getSelectedIndex = this.getSelectedIndex.bind(this);
  }

  getSelectedIndex() {
    const { defaultIndex } = this.props;

    const totalImg = this.props.children.length;
    let leftImg = defaultIndex - 2;
    if (leftImg < 0) {
      leftImg = totalImg - 1;
    }

    let centerImg = defaultIndex - 1;

    let rightImg = defaultIndex;
    if (rightImg >= totalImg) {
      rightImg = 0;
    }

    return [leftImg, centerImg, rightImg];
  }

  render() {
    const imgPositions = this.getSelectedIndex();
    const screenWidth = window.screen.width;

    let childrens = [
      React.cloneElement(this.props.children[imgPositions[0]], {
        style: { left: "0" }
      }),
      React.cloneElement(this.props.children[imgPositions[1]], {
        style: { left: screenWidth + 10 + "px" }
      }),
      React.cloneElement(this.props.children[imgPositions[2]], {
        style: { left: screenWidth * 2 + 20 + "px" }
      })
    ];
    return (
      <div className={styles.container} style={{ width: screenWidth + "px" }}>
        {childrens}
      </div>
    );
    /*

    return (
      <div className={styles.container} style={{ width: screenWidth + "px" }}>
        {React.Children.map(this.props.children, (child, i) => {
          return (
            <Motion
              key={i}
              style={{ left: spring(i * 100) }}
              defaultStyle={{ left: i - 1 * 100 }}
            >
              {style =>
                React.cloneElement(child, {
                  style: { left: style.left + "px" }
                })
              }
            </Motion>
          );
        })}
        <Motion>{({ x }) => <div>{x}</div>}</Motion>
      </div>
    );

    */
  }
}

export default ImageWrapper;
