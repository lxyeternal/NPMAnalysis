# React Pressure

Run the app server

```
npm run start  -server:port=2524 -server:context=public  -disable:contexturl=true
```

