import { isAnyArray } from 'is-any-array';
import max from 'ml-array-max';
import sum from 'ml-array-sum';

function norm(input) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var _options$algorithm = options.algorithm,
      algorithm = _options$algorithm === void 0 ? 'absolute' : _options$algorithm,
      _options$sumValue = options.sumValue,
      sumValue = _options$sumValue === void 0 ? 1 : _options$sumValue,
      _options$maxValue = options.maxValue,
      maxValue = _options$maxValue === void 0 ? 1 : _options$maxValue;

  if (!isAnyArray(input)) {
    throw new Error('input must be an array');
  }

  var output;

  if (options.output !== undefined) {
    if (!isAnyArray(options.output)) {
      throw new TypeError('output option must be an array if specified');
    }

    output = options.output;
  } else {
    output = new Array(input.length);
  }

  if (input.length === 0) {
    throw new Error('input must not be empty');
  }

  switch (algorithm.toLowerCase()) {
    case 'absolute':
      {
        var absoluteSumValue = absoluteSum(input) / sumValue;
        if (absoluteSumValue === 0) return input.slice(0);

        for (var i = 0; i < input.length; i++) {
          output[i] = input[i] / absoluteSumValue;
        }

        return output;
      }

    case 'max':
      {
        var currentMaxValue = max(input);
        if (currentMaxValue === 0) return input.slice(0);
        var factor = maxValue / currentMaxValue;

        for (var _i = 0; _i < input.length; _i++) {
          output[_i] = input[_i] * factor;
        }

        return output;
      }

    case 'sum':
      {
        var sumFactor = sum(input) / sumValue;
        if (sumFactor === 0) return input.slice(0);

        for (var _i2 = 0; _i2 < input.length; _i2++) {
          output[_i2] = input[_i2] / sumFactor;
        }

        return output;
      }

    default:
      throw new Error("norm: unknown algorithm: ".concat(algorithm));
  }
}

function absoluteSum(input) {
  var sumValue = 0;

  for (var i = 0; i < input.length; i++) {
    sumValue += Math.abs(input[i]);
  }

  return sumValue;
}

export { norm as default };
