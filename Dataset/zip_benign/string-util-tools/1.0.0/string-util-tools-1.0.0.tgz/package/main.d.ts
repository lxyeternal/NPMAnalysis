declare module 'string-util-tools';

export function between(string: string, char?: string, spaces?: boolean): string;

export function derpify(string: string, chance?: number): string;

export function fill(sequence: string, amount: number): string;

export function pad(string: string, char?: string, left?: number, right?: number): string;

export function random(len?: number): string;

export function shortify(string: string, len?: number): string;

export function shuffle(string: string): string;

export function splitByArray(string: string, array: object): string;
