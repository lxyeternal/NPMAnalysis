function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function escapeRegex(string) { return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function shortify(string, len = 7) {
  if (len > string.length) throw new Error('StringUtilsError: The length specifies is longer than string name')

  sa = String(string).split('')
  out = ''

  for (var i = 0; i < len; i++) {
    out += sa[i]
  }

  return out + '...'
}

function derpify(string, chance = 0.5) {
  sa = String(string).split('')
  out = ''

  sa.forEach((i) => {
    r = Math.random()

    if (r > chance) {
      out += i.toUpperCase()
    } else {
      out += i.toLowerCase()
    }
  })

  return out
}

function fill(sequence, amount) {
  out = ''

  for (var i = 0; i < amount; i++) {
    out += sequence
  }

  return String(out)
}

function random(len = 1) {
  out = ''

  for (var i = 0; i < len; i++) {
    out += String.fromCharCode(rand(33, 127))
  }
  return out
}

function splitByArray(string, array) {
  regexString = '('
  array.forEach((i, n) => {
    regexString += escapeRegex(i)

    if (array[(n + 1)]) regexString += '|'
  })
  regexString += ')'

  split = string.split(new RegExp(regexString))
  out = []

  split.forEach((i) => {
    if (!RegExp(regexString).test(i)) {
      out.push(i)
    }
  })

  return out
}

function shuffle(string) {
  arr = string.split('')
  used = []
  out = ''

  while (arr.length != used.length) {
    r = rand(0, arr.length) - 1
    if (used.includes(r)) continue

    out += arr[r]
    used.push(r)
  }

  return out
}

function pad(string, char = '-', left = 1, right = 1) {
  out = ''
  for (var i = 0; i < left; i++) {
    out += char
  }

  out += string
  for (var i = 0; i < right; i++) {
    out += char
  }

  return out
}

function between(string, char = '-', spaces = false) {
  out = ''
  arr = String(string).split('')

  arr.forEach((i, n) => {
    out += i

    if (!spaces && arr[(n + 1)] && arr[(n + 1)] != ' ' && i != ' ') out += char
    if (spaces && arr[(n + 1)]) out += char
  })

  return out
}

exports.shortify = shortify
exports.derpify = derpify
exports.fill = fill
exports.random = random
exports.splitByArray = splitByArray
exports.shuffle = shuffle
exports.pad = pad
exports.between = between
