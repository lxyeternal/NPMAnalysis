# string-util-tools

A simple minimalistic 0 dependecies package used for string manipulation.



### Instalation

Install the package from the terminal

```bash
$ npm install string-util-tools
```

Requiere the package

```js
const StringUtils = require('string-util-tools')
```



### Usage

```js
StringUtils.function(...args[]): string
```

Here is a list of all the funtions:

1. **Shortify**
   This will shorten the string (`string`) to the selected lenght (`len = 7`) and add '...' to the end of it.

   ```js
   StringUtility.shortify(string, len?)
   ```

   Examples:

   ```js
   StringUtility.shortify('abcdefghijklmnopqrstuvwxyz', 11)
   // => abcdefghijk...

   StringUtility.shortify('abcdefghijklmnopqrstuvwxyz')
   // => abcdefg...
   ```

2. **Derpify**
   This will randomly capitalize the string (`string`) based in a border value (`chance = 0.5`). Note that this is random every time you run it.

   ```js
   StringUtility.derpify(string, chance?)
   ```

   Examples:

   ```js
   StringUtils.derpify('abcdefghijklmnopqrstuvwxyz')
   // => AbCDEfGHiJKLMNoPqRstuvwXYZ

   StringUtils.derpify('abcdefghijklmnopqrstuvwxyz', 0.8) /* Make 80% lowercase */
   // => abcdefghijkLmnopqrstUvwXYz
   ```

3. **Fill**
   This will make a string of the selected length (`amount`) of a selected sequence (`sequence`)

   ```js
   StringUtility.fill(sequence, amount)
   ```

   Examples:

   ```js
   StringUtils.fill('a', 10)
   // => aaaaaaaaaa

   StringUtils.fill('\\/', 10) /* Note, that '\\' is just an escaped '\' */
   // => \/\/\/\/\/\/\/\/\/\/
   ```

4.  **Random**

   This will make a random ascii string of selected length (`len = 1`). Note that this results into different string every time you run this.

   ```js
   StringUtility.random(len?)
   ```

   Examples:

   ```js
   StringUtils.random(100)
   // => }8n/8)&K>9EA132tPt12"ts`)k8nu;/fQ6c/"+LCKZRUKaTXIDPE_o)r}ih7?|k'IY$&J2nd1(`Xb;?u]Bs?,,?v|e`IQ]QGoUO

   StringUtils.random(50)
   // => z=hdLshN4#k%V})Pi>dv%i%DIA6KQ-'w';m"[D+~_CN}f_m=vM
   ```

5. **splitByArray**

   This will split the inputed string (`string`) based on an array (`array`) of separators. To explain: splitting by an array `[';', '\n']` will split the string by both `;` AND *`newline`* into one array.

   ```js
   StringUtils.splitByArray(string, array[])
   ```

   Examples:

   ```js
   StringUtils.splitByArray('a,b|c-d/e', [',', '|', '-', '/'])
   // => [ 'a', 'b', 'c', 'd', 'e' ]

   StringUtils.splitByArray('ab(bc$cd[de}ef', ['(', '$', '[', '}'])
   // => [ 'ab', 'bc', 'cd', 'de', 'ef' ]
   ```

6. ~~**Shuffle**~~ **DEPRACATED DUE TO AN ERROR!**

7. **pad**

   This will pad the string (`string`) with a selected character (`char = '-'`). You can select how many do you want on left side (`left = 1`) and right side (`right = 1`).

   ```js
   StringUtils.pad(string, char?, left?, right?)
   ```

   Examples:

   ```js
   StringUtils.pad('abcde', '§')
   // => §abcde§

   StringUtils.pad('Hello world!', '-', 5, 5)
   // => -----Hello world!-----
   ```

8. **between**

   This will put a selected character (`char = '-'`) in between of each character in your string (`string`). You can also select if you want to do this to spaces (`spaces = false`)

   ```js
   StringUtils.between(string, char?, spaces?)
   ```

   Examples:

   ```js
   StringUtils.between('Hello world!')
   // => H-e-l-l-o w-o-r-l-d-!

   StringUtils.between('Hello world!', '#', true)
   // => H#e#l#l#o# #w#o#r#l#d#!
   ```



**If you find any bugs, please DM me on discord (My tag is `danik#4985`)**
