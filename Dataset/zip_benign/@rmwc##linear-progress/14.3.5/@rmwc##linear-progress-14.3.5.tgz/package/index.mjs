import { jsx as t, jsxs as g, Fragment as _ } from "react/jsx-runtime";
import b, { useState as y, useEffect as u } from "react";
import { MDCLinearProgressFoundation as f } from "@material/linear-progress";
import { useFoundation as P, createComponent as R, useClassNames as C, Tag as h } from "@rmwc/base";
const B = (n) => {
  const i = (r, e, s, o) => {
    const c = (r == null ? void 0 : r.querySelector(e)) ?? null;
    c && (c.style[s] = o);
  }, { foundation: a, ...m } = P({
    props: n,
    elements: { rootEl: !0 },
    foundation: ({ rootEl: r }) => new f({
      addClass: (e) => r.addClass(e),
      forceLayout: () => {
        var e;
        return (e = r.ref) == null ? void 0 : e.getBoundingClientRect();
      },
      hasClass: (e) => r.hasClass(e),
      removeClass: (e) => r.removeClass(e),
      setBufferBarStyle: (e, s) => {
        i(
          r.ref,
          f.strings.BUFFER_BAR_SELECTOR,
          e,
          s
        );
      },
      setPrimaryBarStyle: (e, s) => {
        i(
          r.ref,
          f.strings.PRIMARY_BAR_SELECTOR,
          e,
          s
        );
      },
      setAttribute: (e, s) => {
        r.setProp(e, s);
      },
      removeAttribute: (e) => r.removeProp(e),
      setStyle: (e, s) => {
        r.ref.style.setProperty(e, s);
      },
      attachResizeObserver: (e) => {
        const s = window.ResizeObserver;
        if (s) {
          const o = new s(
            (c, v) => r.ref && e(c, v)
          );
          return o.observe(r.ref), o;
        }
        return null;
      },
      getWidth: () => r.ref.offsetWidth
    })
  }), [d, l] = y(
    void 0
  );
  return u(() => {
    a.setProgress(n.progress || 0);
    const r = n.progress !== void 0;
    r !== d && (a.setDeterminate(r), l(r));
  }, [n.progress, d, a]), u(() => {
    a.setBuffer(n.buffer || 0);
  }, [n.buffer, a]), u(() => {
    n.closed ? a.close() : a.open();
  }, [n.closed, a]), { foundation: a, ...m };
}, w = R(
  function(i, a) {
    const { reversed: m, closed: d, progress: l, buffer: r, foundationRef: e, ...s } = i, o = C(i, [
      "mdc-linear-progress",
      {
        "mdc-linear-progress--indeterminate": l === void 0,
        "mdc-linear-progress--closed": d
      }
    ]), { rootEl: c } = B(i);
    return /* @__PURE__ */ t(
      h,
      {
        "aria-label": "Progress Bar",
        ...s,
        "aria-valuemin": 0,
        "aria-valuemax": 1,
        "aria-valuenow": l,
        tag: "div",
        role: "progressbar",
        element: c,
        className: o,
        ref: a,
        dir: m && "rtl",
        children: /* @__PURE__ */ t(p, {})
      }
    );
  }
), p = b.memo(function() {
  return /* @__PURE__ */ g(_, { children: [
    /* @__PURE__ */ g("div", { className: "mdc-linear-progress__buffer", children: [
      /* @__PURE__ */ t("div", { className: "mdc-linear-progress__buffer-bar" }),
      /* @__PURE__ */ t("div", { className: "mdc-linear-progress__buffer-dots" })
    ] }),
    /* @__PURE__ */ t("div", { className: "mdc-linear-progress__bar mdc-linear-progress__primary-bar", children: /* @__PURE__ */ t("div", { className: "mdc-linear-progress__bar-inner" }) }),
    /* @__PURE__ */ t("div", { className: "mdc-linear-progress__bar mdc-linear-progress__secondary-bar", children: /* @__PURE__ */ t("div", { className: "mdc-linear-progress__bar-inner" }) })
  ] });
});
export {
  w as LinearProgress
};
