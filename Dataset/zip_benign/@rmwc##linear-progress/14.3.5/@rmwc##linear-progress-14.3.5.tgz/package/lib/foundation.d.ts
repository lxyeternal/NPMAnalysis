import { MDCLinearProgressFoundation } from '@material/linear-progress';
import { LinearProgressProps } from './linear-progress';
export declare const useLinearProgressFoundation: (props: LinearProgressProps) => {
    rootEl: import("@rmwc/base").FoundationElement<any, HTMLElement>;
    foundation: MDCLinearProgressFoundation;
};
