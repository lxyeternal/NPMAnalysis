import ThMap from './map'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import * as esri from 'esri-leaflet'
import proj from 'proj4leaflet'
import utils from './utils/mapUtils'
// 组件列表
const components = [ThMap]

const install = function (Vue) {
  // 判断是否安装
  if (install.installed) return;
	// 遍历注册全局组件
	components.map((component) => Vue.component(component.name, component))
}

// 判断是否是直接引入文件
if (typeof window !== 'undefined' && window.Vue) {
	install(window.Vue)
}

// 获取版本信息
const version = import('../package.json').version

// 全部加载
export default {
	version: version,
	install,
	ThMap,
}

// 按需加载
export { version, install, ThMap, L, esri, proj, utils }
