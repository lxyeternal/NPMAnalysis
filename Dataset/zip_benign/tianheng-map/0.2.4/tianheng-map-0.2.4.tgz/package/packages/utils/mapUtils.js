import proj from 'proj4leaflet'
import * as L from 'leaflet'
import * as esri from 'esri-leaflet'

const utils = {}

utils.queryByArcgis = (serverUrl, geometry) => {
	return new Promise((resolve, reject) => {
		const query = esri.Query({
			url: serverUrl,
		})
		query.intersects(geometry)
		query.run((error, featureCollection, response) => {
			if (error) {
				reject(error)
			} else {
				resolve({
					featureCollection,
					response,
				})
			}
		})
	})
}

utils.getTileLayer = (url, options) => {
	return new L.tileLayer(url, options)
}
utils.getWMSLayer = (url, options) => {
	return new L.tileLayer.wms(url, options)
}

utils.getWMTSLayer = (url, options) => {
	return new L.TileLayer.WMTS(url, options)
}

utils.getArcgisLayer = (url, tileSize = 256, maxZoom = 18, minZoom = 6) => {
	return esri.tiledMapLayer({
		url: url,
		tileSize: tileSize,
		maxZoom: maxZoom,
		minZoom: minZoom,
	})
}

utils.getArcgisDynamicLayer = (url, options = { opacity: 0.8 }) => {
	return esri.dynamicMapLayer({
		url: url,
		...options,
	})
}

utils.getCrs = (code, proj4def, options) => {
	return new proj.CRS(code, proj4def, options)
}
utils.getCrs4490 = (
	options = {
		origin: [-180, 90],
		resolutions: [
			1.4062499999938884, 0.7031249999990244, 0.35156250000003225,
			0.17578125000001613, 0.08789062500000806, 0.04394531250000403,
			0.021972656249969514, 0.01098632812499999, 0.005493164062499995,
			0.0027465820312499974, 0.0013732910156249987, 0.0006866455078124993,
			0.00034332275390625076, 0.00017166137695312497,
			0.00008583068847656249, 0.000042915344238281236,
			0.000021457672119140618, 0.000010728836059570309,
			0.000005364418029785167, 0.0000026822090148925836,
			0.0000013411045074462918,
		],
	}
) => {
	return new proj.CRS(
		'EPSG:4490',
		'+proj=longlat +ellps=GRS80 +no_defs',
		options
	)
}

utils.initLeafletWMTS = (L) => {
	L.TileLayer.WMTS = L.TileLayer.extend({
		options: {
			version: '1.0.0',
			style: '',
			tilematrixSet: '',
			format: 'image/png',
			tileSize: 256,
			matrixIds: null,
			layer: '',
			requestEncoding: 'KVP',
			attribution: '',
			noWrap: true,
		},

		// todo 自动获取Capabilities
		initialize: function (url, options) {
			// (String, Object)
			this._url = url
			L.setOptions(this, options)

			var opt = this.options
			if (opt.requestEncoding === 'REST') {
				var formatSuffixMap = {
					'image/png': 'png',
					'image/png8': 'png',
					'image/png24': 'png',
					'image/png32': 'png',
					png: 'png',
					'image/jpeg': 'jpg',
					'image/jpg': 'jpg',
					jpeg: 'jpg',
					jpg: 'jpg',
				}
				this.formatSuffix =
					'.' +
					(formatSuffixMap[opt.format] ||
						opt.format.split('/').pop() ||
						'png')
			} else {
				opt.requestEncoding = 'KVP'
			}
		},

		/**
		 * @function WMTSLayer.prototype.getTileUrl
		 * @description 获取切片地址。
		 * @param {Object} coords - 行列号。
		 * @returns {string} 切片地址。
		 */
		getTileUrl: function (coords) {
			// (Point, Number) -> String
			var zoom = this._getZoomForUrl()
			var ident = this.options.matrixIds
				? this.options.matrixIds[zoom].identifier
				: zoom
			var index = this._url.indexOf('?')
			var url =
				index > -1
					? this._url.substring(0, this._url.indexOf('?'))
					: this._url
			var urlParams =
				index > -1 ? this._url.substring(this._url.indexOf('?')) : ''

			url = L.Util.template(url, { s: this._getSubdomain(coords) })

			var obj = {
				service: 'WMTS',
				request: 'GetTile',
				version: this.options.version,
				style: this.options.style,
				tilematrixSet: this.options.tilematrixSet,
				format: this.options.format,
				width: this.options.tileSize,
				height: this.options.tileSize,
				layer: this.options.layer,
				tilematrix: ident,
				tilerow: coords.y,
				tilecol: coords.x,
			}

			if (this.options.tileProxy) {
				url = this.options.tileProxy + url
			}

			if (this.options.requestEncoding === 'KVP') {
				url += L.Util.getParamString(obj, url)
			} else if (this.options.requestEncoding === 'REST') {
				var params =
					'/' +
					obj.layer +
					'/' +
					obj.style +
					'/' +
					obj.tilematrixSet +
					'/' +
					obj.tilematrix +
					'/' +
					obj.tilerow +
					'/' +
					obj.tilecol +
					this.formatSuffix
				url += params
			}
			url = urlAppend(url, urlParams)
			// url = appendCredential(url);
			return url
		},
	})

	L.tileLayer.wmts = function (url, options) {
		return new L.TileLayer.WMTS(url, options)
	}
}
/**
 * @memberOf CommonUtil
 * @description 给 URL 追加查询参数。
 * @param {string} url - 待追加参数的 URL 字符串。
 * @param {string} paramStr - 待追加的查询参数。
 * @returns {string} 新的 URL。
 */
function urlAppend(url, paramStr) {
	var newUrl = url
	if (paramStr) {
		if (paramStr.indexOf('?') === 0) {
			paramStr = paramStr.substring(1)
		}
		var parts = (url + ' ').split(/[?&]/)
		newUrl +=
			parts.pop() === ' '
				? paramStr
				: parts.length
				? '&' + paramStr
				: '?' + paramStr
	}
	return newUrl
}

export default utils
