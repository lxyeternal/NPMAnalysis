import ThMap from './index.vue'

ThMap.install = (App) => {
	App.component(ThMap.__name, ThMap)
}

export default ThMap
