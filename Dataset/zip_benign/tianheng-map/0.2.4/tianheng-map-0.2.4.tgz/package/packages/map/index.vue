<template>
	<div class="th-map-view" ref="mainBox">
		<div ref="mapEl" class="th-map-content" />
		<slot />
	</div>
</template>
<script setup name="ThMap">
import { onMounted, onUnmounted, ref, reactive, toRaw } from 'vue'
import * as L from 'leaflet'
import utils from '../utils/mapUtils'
import '@geoman-io/leaflet-geoman-free'
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css'
import '../utils/leaflet-side-by-side.js'
import LeafletMeasureSimplify from '../utils/leaflet-measure-simplify.js'
import ElementResizeDetectorMaker from 'element-resize-detector'
utils.initLeafletWMTS(L) // 载入wmts加载方式

//界面变化监听
const erd = ElementResizeDetectorMaker()
const mapEl = ref()
const mainBox = ref()
const state = reactive({
	map: null,
	timer: null,
	drawing: false,
	drawType: '',
	drawLayer: null,
	drawLayerGroup: null,
	sideControl: null, // 卷帘组件
	sideLeft: null,
	sideRight: null,
	measureTools: null, //测量工具
})

const emit = defineEmits(['mapReady', 'drawResult', 'measureResult'])
const props = defineProps({
	crs: {
		type: Object,
		default: null,
	},
	zoom: {
		type: Number,
		default: 8,
	},
	center: {
		type: Array,
		default: () => [30.987527, 112.271301],
	},
	zoomConfig: {
		type: Object,
		default: () => {
			return {
				control: true,
				doubleClickZoom: false,
				position: 'bottomright', // 'topleft', 'topright', 'bottomleft' or 'bottomright'
			}
		},
	},
	drawConfig: {
		type: Object,
		default: () => {
			return {
				color: '#409EFF',
				fillColor: '#409EFF',
				fillOpacity: 0.5,
			}
		},
	},
	measureConfig: {
		type: Object,
		default: () => {
			return {
				weight: 3, // 线条宽度
				color: '#039bec', // 主题色
				showTip: true, //	是否显示操作提示
				showResult: true, // 是否显示测量结果
				unitDistance: 'kilometer', // 距离测量单位（kilometer：千米/metre：米）
				unitArea: 'kilometer', // 面积测量单位（kilometer：平方千米/metre：平方米）
				precisionDistance: 2, // 	距离测量精度
				precisionArea: 2, // 面积测量精度
				precisionCoord: 6, // 经纬度测量精度
				customTip: {
					step1: '单击开始绘制',
					step2: '单机继续绘制',
					step3: '右键单击结束绘制',
				}, // 自定义操作提示 例如：{"step1":"单击开始绘制","step2":"单机继续绘制","step3":"右键单击结束绘制"}
			}
		},
	},
})
// 初始化地图
function initMap() {
	const mapOption = {
		center: props.center, // 地图中心 宜都市
		zoom: props.zoom, // 缩放比列
		zoomControl: false, // 缩放组件手动添加，方便控制方向
		doubleClickZoom: props.zoomConfig && props.zoomConfig.doubleClickZoom, // 禁用双击放大
		attributionControl: false, // 移除右下角leaflet标识
	}
	if (props.crs) {
		mapOption.crs = props.crs
	}
	state.map = L.map(mapEl.value, mapOption)
	if (props.zoomConfig && props.zoomConfig.control) {
		//添加缩放控件
		const zoomControl = L.control.zoom({
			position: props.zoomConfig.position,
		})
		toRaw(state.map).addControl(zoomControl)
	}
	// 设置绘制配置
	toRaw(state.map).pm.setLang('zh') // 控件提示设置中文
	state.drawLayerGroup = L.layerGroup()
	toRaw(state.map).addLayer(state.drawLayerGroup)
	toRaw(state.map).pm.setGlobalOptions({
		snapable: false,
		layerGroup: state.drawLayerGroup,
	})
	// 绘制样式设定
	if (props.drawConfig && props.drawConfig.color) {
		toRaw(state.map).pm.setPathOptions({
			color: props.drawConfig.color,
			fillColor: props.drawConfig.fillColor
				? props.drawConfig.fillColor
				: props.drawConfig.color,
			fillOpacity: props.drawConfig.fillOpacity
				? props.drawConfig.fillOpacity
				: 0.5,
		})
	} else {
		toRaw(state.map).pm.setPathOptions({
			color: '#409EFF',
			fillColor: '#409EFF',
			fillOpacity: 0.5,
		})
	}
	// toRaw(state.map).pm.addControls({
	// 	position: 'topright', // 控件菜单位置
	// 	drawPolygon: true, //绘制多边形
	// 	drawMarker: false, //绘制标记点
	// 	drawCircleMarker: false, //绘制圆形标记
	// 	drawPolyline: true, //绘制线条
	// 	drawRectangle: true, //绘制矩形
	// 	drawCircle: true, //绘制圆圈
	// 	editMode: false, //编辑多边形
	// 	dragMode: false, //拖动多边形
	// 	cutPolygon: false, //添加⼀个按钮以删除多边形⾥⾯的部分内容
	// 	removalMode: true, //清除多边形
	// })
	// 绘制事件监听
	toRaw(state.map).on('pm:create', (e) => {
		console.log(e, '绘制完成时调用')
		state.drawLayer = e.layer
		state.drawing = false
		emit('drawResult', {
			type: e.shape,
			data: e,
		})
	})

	if (props.measureConfig) {
		state.measureTools = new LeafletMeasureSimplify(
			toRaw(state.map),
			props.measureConfig
		)
	}

	emit('mapReady', toRaw(state.map))
}
// 启动测量
function enableMeasure(method = 'distance') {
	if (!state.measureTools) {
		return
	}
	if (!['distance', 'area', 'coord'].includes(method)) {
		console.error('Measure method参数错误')
		return
	}
	state.measureTools[method]().then((path) => {
		console.log(path) //绘制完成后将返回路径
		emit('measureResult', {
			type: method,
			data: path,
		})
	})
}
// 关闭测量
function disableMeasure() {
	if (!state.measureTools) {
		return
	}
	state.measureTools.close()
	state.measureTools.clear()
}
// 添加图层
function addLayer(layer) {
	if (!state.map) {
		return
	}
	if (!layer) {
		return
	}
	const layers = asArray(layer)
	layers.forEach((e) => {
		if (!toRaw(state.map).hasLayer(e)) {
			toRaw(state.map).addLayer(e)
		}
	})
}
// 移除图层
function removeLayer(layer) {
	if (!state.map) {
		return
	}
	if (!layer) {
		return
	}
	const layers = asArray(layer)
	layers.forEach((e) => {
		if (toRaw(state.map).hasLayer(e)) {
			toRaw(state.map).removeLayer(e)
		}
	})
}
// 重置地图
function resetMap() {
	if (!state.map) {
		return
	}
	L.Util.requestAnimFrame(
		toRaw(state.map).invalidateSize,
		toRaw(state.map),
		!1,
		toRaw(state.map)._container
	)
}
// 创建层级设置zindex
function createPane(name, zIndex = 450) {
	if (!state.map) {
		return
	}
	toRaw(state.map).createPane(name)
	toRaw(state.map).getPane(name).style.zIndex = zIndex
}
// 启动pm绘制
function enableDraw(drawType = 'Polygon', clear = true) {
	if (!['Marker','Line', 'Polygon', 'Rectangle', 'Circle'].includes(drawType)) {
		console.error('drawType参数错误')
		return
	}
	if (!state.drawing) {
		if(clear){
			clearDraw()
		}
		state.drawing = true
		state.drawType = drawType
		toRaw(state.map).pm.enableDraw(drawType, {
			snappable: true,
			finishOn: 'contextmenu',
			allowSelfIntersection: false,
			tooltips: true,
		})
	} else {
		if(clear){
			clearDraw()
		}
		emit('drawResult', {
			type: state.drawType,
			data: [],
		})
	}
}
// 清空绘制图层
function clearDraw() {
	state.drawing = false
	toRaw(state.map).pm.disableDraw(state.drawType)
	if (state.drawLayer) {
		toRaw(state.map).removeLayer(state.drawLayer)
		state.drawLayer = null
	}
	state.drawLayerGroup.clearLayers()
}
// 启动卷帘模式
function enableSideBySide(leftLayers, rightLayers) {
	if (!state.map) {
		return
	}
	if (this.sideControl) {
		this.disableSideBySide()
	}
	state.sideLeft = leftLayers
	state.sideRight = rightLayers
	addLayer(state.sideLeft)
	addLayer(state.sideRight)
	state.sideControl = L.control.sideBySide(state.sideLeft, state.sideRight)
	toRaw(state.map).addControl(state.sideControl)
}
function asArray(arg) {
	return arg === 'undefined' ? [] : Array.isArray(arg) ? arg : [arg]
}
// 设置左侧图层
function setSideLeftLayer(layer) {
	if (!state.map) {
		return
	}
	removeLayer(state.sideLeft)
	state.sideLeft = layer
	addLayer(state.sideLeft)
	state.sideControl.setLeftLayers(state.sideLeft)
}
// 设置右侧图层
function setSideRightLayer(layer) {
	if (!state.map) {
		return
	}
	removeLayer(state.sideRight)
	state.sideRight = layer
	addLayer(state.sideRight)
	state.sideControl.setRightLayers(state.sideRight)
}
// 关闭卷帘模式
function disableSideBySide() {
	if (!state.map) {
		return
	}
	toRaw(state.map).removeControl(state.sideControl)
	removeLayer(state.sideLeft)
	removeLayer(state.sideRight)
}

// 事件防抖
function debounce(fn, time) {
	if (state.timer !== null) {
		clearTimeout(state.timer)
	}
	state.timer = setTimeout(fn, time)
}
onMounted(() => {
	erd.listenTo(mainBox.value, () => {
		debounce(() => {
			// 界面变化后 对地图进行重置
			resetMap()
		}, 50)
	})
	initMap()
})
onUnmounted(() => {
	erd.uninstall(mainBox.value)
})

// 设置天地图为基础
function setTiandituMap(tk) {
	const baseLayer = L.layerGroup([
		L.tileLayer(
			`http://{s}.tianditu.gov.cn/DataServer?T=img_w&X={x}&Y={y}&L={z}&tk=${tk}`,
			{
				subdomains: ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7'],
				maxZoom: 18,
				minZoom: 6,
			}
		),
		L.tileLayer(
			`http://{s}.tianditu.gov.cn/DataServer?T=cia_w&X={x}&Y={y}&L={z}&tk=${tk}`,
			{
				subdomains: ['t0', 't1', 't2', 't3', 't4', 't5', 't6', 't7'],
				maxZoom: 18,
				minZoom: 6,
			}
		),
	])
	toRaw(state.map).addLayer(baseLayer)
}

// 图形设置到中心点
const fitBounds = (bounds, option) => {
	if (!state.map) {
		return
	}
	toRaw(state.map).fitBounds(bounds, option)
}

// 图形设置到中心点
const setView = (point, option) => {
	if (!state.map) {
		return
	}
	toRaw(state.map).setView(point, option)
}
// 获取map对象
const getMap = () => {
	return toRaw(state.map)
}
defineExpose({
	addLayer,
	removeLayer,
	createPane,
	enableDraw,
	clearDraw,
	setTiandituMap,
	enableSideBySide,
	setSideLeftLayer,
	setSideRightLayer,
	disableSideBySide,
	enableMeasure,
	disableMeasure,
	resetMap,
	fitBounds,
	setView,
	getMap,
})
</script>
<style lang="less" scoped>
.th-map-view {
	width: 100%;
	height: 100%;
	position: relative;
	overflow: hidden;
	.th-map-content {
		width: 100%;
		height: 100%;
		position: relative;
	}
}
</style>
