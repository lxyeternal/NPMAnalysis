# Requestivle — A simple request wrapper and variable compiler for making HTTP(s) based API calls.
[![NPM](https://nodei.co/npm/requestivle.png)](https://nodei.co/npm/requestivle/)

## NOTICE:
restivle has been MOVED and RENAMED to [requestivle](https://www.npmjs.com/package/requestivle). The methods will remain the same but all future development will happen there. The same owner and developers are there.

Admittedly, the sudden popularity was surprising, but we assure you that development will continue unabated over on [requestivle](https://www.npmjs.com/package/requestivle) package.