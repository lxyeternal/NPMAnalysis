exports.Conf = {
	host: "192.168.1.142",
	port: 5280,
	uid: "victor.goya@af83.com",
	credential: "pwd"
};