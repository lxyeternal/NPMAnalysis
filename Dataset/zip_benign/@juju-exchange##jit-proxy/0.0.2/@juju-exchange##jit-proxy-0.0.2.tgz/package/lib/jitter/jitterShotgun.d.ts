/// <reference types="@pythnetwork/client/node_modules/@solana/web3.js" />
import { JitProxyClient } from '../jitProxyClient';
import { PublicKey } from '@solana/web3.js';
import { AuctionSubscriber, DriftClient, Order, UserAccount, UserStatsMap } from '@juju-exchange/sdk';
import { BaseJitter } from './baseJitter';
export declare class JitterShotgun extends BaseJitter {
    constructor({ auctionSubscriber, jitProxyClient, driftClient, userStatsMap, }: {
        driftClient: DriftClient;
        auctionSubscriber: AuctionSubscriber;
        jitProxyClient: JitProxyClient;
        userStatsMap?: UserStatsMap;
    });
    createTryFill(taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string): () => Promise<void>;
}
