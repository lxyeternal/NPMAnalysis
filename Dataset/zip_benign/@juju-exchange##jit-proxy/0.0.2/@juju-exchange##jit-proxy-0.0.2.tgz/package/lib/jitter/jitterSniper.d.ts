/// <reference types="@pythnetwork/client/node_modules/@solana/web3.js" />
import { JitProxyClient } from '../jitProxyClient';
import { PublicKey } from '@solana/web3.js';
import { AuctionSubscriber, DriftClient, OraclePriceData, Order, SlotSubscriber, UserAccount, UserStatsMap } from '@juju-exchange/sdk';
import { BaseJitter } from './baseJitter';
type AuctionAndOrderDetails = {
    slotsTilCross: number;
    willCross: boolean;
    bid: number;
    ask: number;
    auctionStartPrice: number;
    auctionEndPrice: number;
    stepSize: number;
    oraclePrice: OraclePriceData;
};
export declare class JitterSniper extends BaseJitter {
    slotSubscriber: SlotSubscriber;
    userStatsMap: UserStatsMap;
    constructor({ auctionSubscriber, slotSubscriber, jitProxyClient, driftClient, userStatsMap, }: {
        driftClient: DriftClient;
        slotSubscriber: SlotSubscriber;
        auctionSubscriber: AuctionSubscriber;
        jitProxyClient: JitProxyClient;
        userStatsMap?: UserStatsMap;
    });
    createTryFill(taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string): () => Promise<void>;
    getAuctionAndOrderDetails(order: Order): AuctionAndOrderDetails;
    waitForSlotOrCrossOrExpiry(targetSlot: number, order: Order, initialDetails: AuctionAndOrderDetails): Promise<{
        slot: number;
        updatedDetails: AuctionAndOrderDetails;
    }>;
}
export {};
