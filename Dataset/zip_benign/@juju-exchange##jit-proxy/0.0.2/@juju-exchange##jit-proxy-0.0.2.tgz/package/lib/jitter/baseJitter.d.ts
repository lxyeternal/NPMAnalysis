/// <reference types="@pythnetwork/client/node_modules/@solana/web3.js" />
import { JitProxyClient, PriceType } from '../jitProxyClient';
import { PublicKey } from '@solana/web3.js';
import { AuctionSubscriber, BN, DriftClient, Order, PostOnlyParams, UserAccount, UserStatsMap } from '@juju-exchange/sdk';
export type UserFilter = (userAccount: UserAccount, userKey: string, order: Order) => boolean;
export type JitParams = {
    bid: BN;
    ask: BN;
    minPosition: BN;
    maxPosition: any;
    priceType: PriceType;
    subAccountId?: number;
    postOnlyParams?: PostOnlyParams;
};
export declare abstract class BaseJitter {
    auctionSubscriber: AuctionSubscriber;
    driftClient: DriftClient;
    jitProxyClient: JitProxyClient;
    userStatsMap: UserStatsMap;
    perpParams: Map<number, JitParams>;
    spotParams: Map<number, JitParams>;
    seenOrders: Set<string>;
    onGoingAuctions: Map<string, Promise<void>>;
    userFilter: UserFilter;
    computeUnits: number;
    computeUnitsPrice: number;
    constructor({ auctionSubscriber, jitProxyClient, driftClient, userStatsMap, }: {
        driftClient: DriftClient;
        auctionSubscriber: AuctionSubscriber;
        jitProxyClient: JitProxyClient;
        userStatsMap: UserStatsMap;
    });
    subscribe(): Promise<void>;
    createTryFill(taker: UserAccount, takerKey: PublicKey, takerStatsKey: PublicKey, order: Order, orderSignature: string): () => Promise<void>;
    deleteOnGoingAuction(orderSignature: string): void;
    getOrderSignatures(takerKey: string, orderId: number): string;
    updatePerpParams(marketIndex: number, params: JitParams): void;
    updateSpotParams(marketIndex: number, params: JitParams): void;
    setUserFilter(userFilter: UserFilter | undefined): void;
    setComputeUnits(computeUnits: number): void;
    setComputeUnitsPrice(computeUnitsPrice: number): void;
}
