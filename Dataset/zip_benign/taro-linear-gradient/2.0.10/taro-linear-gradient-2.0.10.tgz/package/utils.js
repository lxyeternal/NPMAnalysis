export const getColors = ({ startColor, startOpacity, endColor, endOpacity, colors = [] }) => {
  if (colors.length === 0) {
    return [
      { color: startColor, opacity: startOpacity },
      { color: endColor, opacity: endOpacity }
    ]
  }
  return colors.filter(({ color }) => color)
}

const defaultOpacity = (opacity, index) => {
  if (opacity === undefined && index === 0) return 0
  if (opacity === undefined) return 1
  return opacity
}

const buildWithDefault =
  (stopCount) =>
  ({ color = '#ffffff', offset, opacity }, index) => ({
    color,
    opacity: defaultOpacity(opacity, index),
    offset: offset === undefined ? `${(index * 100) / (stopCount - 1)}%` : offset
  })

export const buildSvgStops = (colors = []) => colors.map(buildWithDefault(colors.length))

export const getXY = (rotate) => {
  const anglePI = rotate * (Math.PI / 180)
  return {
    'x2': `${Math.round(50 + Math.sin(anglePI) * 50)}%`,
    'y2': `${Math.round(50 + Math.cos(anglePI) * 50)}%`,
    'x1': `${Math.round(50 + Math.sin(anglePI + Math.PI) * 50)}%`,
    'y1': `${Math.round(50 + Math.cos(anglePI + Math.PI) * 50)}%`
  }
}
