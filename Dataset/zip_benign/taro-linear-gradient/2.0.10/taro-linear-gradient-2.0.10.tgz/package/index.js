/**
 * @ Author: moses.zhou
 * @ Create Time: 2021-11-26 10:20:56
 * @ Modified by: moses.zhou
 * @ Modified time: 2022-07-05 18:12:49
 * @ Description: 在weapp/tt/alipay都不支持svg标签，但是支持svg图片，所以将svg做成图片显示
 */

import Taro, { PureComponent } from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import { Base64 } from './base64'
import { getColors, buildSvgStops, getXY } from './utils'
import './index.scss'

let _base64 = null
function getBase64() {
  if (!_base64) {
    _base64 = new Base64()
  }
  return _base64
}

const buildSvgSource = ({ randomId, colors = [], angleCoords }) => {
  const stops = buildSvgStops(colors)
    .map(({ color, opacity, offset }) => `<stop offset='${offset}' stop-color='${color}' stop-opacity='${opacity}' />`)
    .join('')
  return `<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <defs>
                    <linearGradient id='${randomId}' x1='${angleCoords.x1}' y1='${angleCoords.y1}' x2='${angleCoords.x2}' y2='${angleCoords.y2}'>
		    ${stops}
                    </linearGradient>
                    </defs>
                    <rect x='0' y='0' width='100%' height='100%' fill='url(#${randomId})' />
                    </svg>`
}

/*
 * colors, 元素的定义如
 * {color: '#fff', opacity: 1}
 */
export default class BgLinearGradient extends PureComponent {
  static options = { virtualHost: true }

  constructor(props) {
    super(props)
    this.randomId = `grad_${parseInt(Math.random() * 10000000)}`
  }

  render() {
    const {
      startColor = '#ffffff',
      startOpacity = 0,
      endColor = '#ffffff',
      endOpacity = 1,
      style = {},
      rotate: _rotate = 0,
      colors = []
    } = this.props
    let rotate = _rotate
    if (typeof _rotate === 'string') {
      rotate = Number(rotate)
    }
    const angleCoords = getXY(rotate)

    const temp = buildSvgSource({
      randomId: this.randomId,
      colors: getColors({ startColor, startOpacity, endColor, endOpacity, colors }),
      angleCoords
    })

    const base64 = getBase64()
    const source = `data:image/svg+xml;base64,${base64.encode(temp)}`
    return (
      <View className='bg-linear-gradient' style={style}>
        <Image src={source} className='bg-linear-gradient-img' />
      </View>
    )
  }
}
