/* eslint-disable taro/props-reserve-keyword */
/**
 * @ Author: moses.zhou
 * @ Create Time: 2021-11-26 10:20:56
 * @ Modified by: moses.zhou
 * @ Modified time: 2022-07-05 18:15:41
 * @ Description: 由于h5中同时存在多个svg会出现第二个svg表现和第一个一样，设置参数无效。故使用和weapp一样的模式
 */

import Taro, { PureComponent } from '@tarojs/taro'
import { View } from '@tarojs/components'
import { getColors, buildSvgStops, getXY } from './utils'
import './index.scss'

/*
 * colors, 元素的定义如
 * {color: '#fff', opacity: 1}
 */
export default class BgLinearGradient extends PureComponent {
  constructor(props) {
    super(props)
    this.randomId = `grad_${parseInt(Math.random() * 10000000)}`
  }

  render() {
    const {
      startColor = '#ffffff',
      startOpacity = 0,
      endColor = '#ffffff',
      endOpacity = 1,
      colors = [],
      style = {},
      rotate: _rotate = 0
    } = this.props
    let rotate = _rotate
    if (typeof _rotate === 'string') {
      rotate = Number(rotate)
    }
    const angleCoords = getXY(rotate)
    return (
      <View className='bg-linear-gradient' style={style}>
        <svg width='100%' height='100%'>
          <defs>
            <linearGradient id={this.randomId} x1={angleCoords.x1} x2={angleCoords.x2} y1={angleCoords.y1} y2={angleCoords.y2}>
              {buildSvgStops(getColors({ startColor, startOpacity, endColor, endOpacity, colors })).map(({ color, opacity, offset }, index) => (
                <stop key={`stop-${index}`} offset={offset} stopColor={color} stopOpacity={opacity} />
              ))}
            </linearGradient>
          </defs>
          <rect x='0' y='0' width='100%' height='100%' fill={`url(#${this.randomId})`} />
        </svg>
      </View>
    )
  }
}
