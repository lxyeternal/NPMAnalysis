/**
 * @ Author: moses.zhou
 * @ Create Time: 2021-11-26 10:20:56
 * @ Modified by: moses.zhou
 * @ Modified time: 2022-07-05 18:13:48
 * @ Description:
 */

/* eslint-disable taro/props-reserve-keyword */
import Taro, { PureComponent } from '@tarojs/taro'
import { View } from '@tarojs/components'
import Svg, { LinearGradient, Stop, Defs, Rect } from 'react-native-svg'
import { getColors, buildSvgStops, getXY } from './utils'
import './index.scss'

/*
 * colors, 元素的定义如
 * {color: '#fff', opacity: 1}
 */

export default class BgLinearGradient extends PureComponent {
  constructor(props) {
    super(props)
    this.randomId = `grad_${parseInt(Math.random() * 10000000)}`
  }

  render() {
    const {
      startColor = '#ffffff',
      startOpacity = 0,
      endColor = '#ffffff',
      endOpacity = 1,
      colors = [],
      style = {},
      rotate: _rotate = 0
    } = this.props
    let rotate = _rotate
    if (typeof _rotate === 'string') {
      rotate = Number(rotate)
    }
    const angleCoords = getXY(rotate)

    return (
      <View pointerEvents={this.props.pointerEvents || 'auto'} className='bg-linear-gradient' style={style}>
        <Svg height='100%' width='100%'>
          <Defs>
            <LinearGradient id={this.randomId} x1={angleCoords.x1} y1={angleCoords.y1} x2={angleCoords.x2} y2={angleCoords.y2}>
              {buildSvgStops(getColors({ startColor, startOpacity, endColor, endOpacity, colors })).map(({ color, opacity, offset }, index) => (
                <Stop key={`stop-${index}`} offset={offset} stopColor={color} stopOpacity={opacity} />
              ))}
            </LinearGradient>
          </Defs>
          <Rect fill={`url(#${this.randomId})`} x={0} y={0} width='100%' height='100%' />
        </Svg>
      </View>
    )
  }
}
