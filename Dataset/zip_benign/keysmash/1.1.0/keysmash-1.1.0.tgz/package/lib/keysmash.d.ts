declare const keysmash: (length: number, options?: {
    /**
     * the chance that the keysmash starts with 'a'
     * @default 0.4
     */
    startsWithAChance: number;
    /**
     * the chance that a character gets rerolled if it is the same as the previous character
     * @default 0.9
     */
    rerollChance: number;
}) => string;
export default keysmash;
