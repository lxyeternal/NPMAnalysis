# Laravel Mix Sitemap

`laravel-mix-sitemap` は、Laravel Mix を使ったビルドプロセスにおいて、サイトマップを自動生成するための拡張機能です。また、単体のユーティリティクラスとしても利用できます。

## インストール

### 1. npm でパッケージをインストール

```bash
npm install laravel-mix-sitemap --save-dev
```

## 使い方
webpack.mix.js に以下の設定を追加して、サイトマップを生成します。

```javascript
let mix = require('laravel-mix');
require('laravel-mix-sitemap'); // 拡張機能を読み込む

const BASE_URL = 'https://example.com'; // あなたのベースURLを設定
const distPath = 'dist'; // サイトマップの出力先ディレクトリ

mix.sitemap({
  baseUrl: BASE_URL, // サイトのベースURL
  distDir: distPath, // サイトマップを生成するディレクトリ
  defaultChangefreq: 'daily', // 各ページの更新頻度
  defaultPriority: 0.5, // 各ページの優先度
});
```

これにより、ビルド後に指定したディレクトリ（例：dist）に sitemap.xml が生成されます。


## 単体利用 での使い方
laravel-mix-sitemap は、Laravel Mix に依存せず、単体でもサイトマップを生成することが可能です。
他の処理でHTMLの生成タイミングの問題で sitemap.xml が生成できない場合などに活用してください。

### ▼ 例: 独立したスクリプトでサイトマップを生成する

#### ① generate-sitemap.js を作成して以下のコードを記述します。

```
const SitemapGenerator = require('laravel-mix-sitemap'); // ユーティリティクラスを読み込む

const generator = new SitemapGenerator();
generator.register({
  baseUrl: 'https://example.com', // サイトのベースURL
  distDir: 'dist', // サイトマップを生成するディレクトリ
  defaultChangefreq: 'daily', // 各ページの更新頻度
  defaultPriority: 0.5, // 各ページの優先度
});
generator.generate();

console.log('Sitemap has been generated successfully!');
```

#### ② 以下のコマンドでスクリプトを実行します。
```
{
  "scripts": {
    "sitemap": "node generate-sitemap.js", // サイトマップを単独で生成
    "prod": "mix --production && npm run sitemap" // ビルド後にサイトマップを生成
  }
}
```

実行コマンド：
```
npm run sitemap
```

または、ビルドと同時に生成したい場合：
```
npm run prod
```


## オプション
register() メソッドに渡すオプションは以下の通りです。

- baseUrl (string): サイトマップのベースとなるURL。必須項目です。
- distDir (string): サイトマップの出力先ディレクトリ。デフォルトは dist です。
- defaultChangefreq (string): 各ページの更新頻度。デフォルトは weekly です。
- defaultPriority (number): 各ページの優先度。デフォルトは 0.8 です。


## 注意点
- Laravel Mixの拡張機能として利用する場合は、必ず`require('laravel-mix-sitemap')`を`webpack.mix.js`内で読み込んでください。
- 単体利用する場合は、`SitemapGenerator`クラスを直接利用してください。