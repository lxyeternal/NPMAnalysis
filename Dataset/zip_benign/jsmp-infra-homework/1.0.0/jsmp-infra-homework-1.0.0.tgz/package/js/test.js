import {sortArray} from './sortArray';
import {modifyString} from './modifyString';
import * as assert from 'assert';

const sortedArr = sortArray([1, 3], 2);

assert.ok(modifyString('HeLlo', 'upper') === 'HELLO');
assert.ok(modifyString('HellO', 'lower') ==='hello');
assert.equal(typeof modifyString('Somestr'),  'string');


assert.deepEqual(sortArray([300, 100, 230, 124], 220), [100, 124, 220, 230, 300]);
assert.ok(sortArray([10, 20, 30], 12).length === 4);
assert.ok(sortedArr instanceof Array);