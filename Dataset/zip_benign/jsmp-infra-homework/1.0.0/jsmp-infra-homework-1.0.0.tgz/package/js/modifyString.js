export const modifyString = (str, action = 'capitalize') => {
  let newStr = '';
  switch (action) {
    case 'upper': newStr = str.toUpperCase();
      break;
    case 'lower': newStr = str.toLowerCase();
      break;
    default: newStr = str[0].toUpperCase() + str.slice(1,);
      break;
  }
  return newStr;
};