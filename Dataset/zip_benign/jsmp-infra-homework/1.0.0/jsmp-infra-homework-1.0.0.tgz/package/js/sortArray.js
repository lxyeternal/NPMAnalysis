import { sortedIndex } from 'lodash';

export const sortArray = (arr, newValue) => {
  const newArr = [...arr];
  let indexInsertedElement;

  newArr.sort((a, b) => a - b);
  indexInsertedElement = sortedIndex(newArr, newValue);
  newArr.splice(indexInsertedElement, 0, newValue);

  return newArr;
};