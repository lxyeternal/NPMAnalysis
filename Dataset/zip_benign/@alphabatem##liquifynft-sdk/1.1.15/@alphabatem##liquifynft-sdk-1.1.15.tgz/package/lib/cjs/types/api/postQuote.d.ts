import { QuoteRequest, QuoteResponse } from "../entities";
export declare function postQuote(req: QuoteRequest): Promise<QuoteResponse>;
//# sourceMappingURL=postQuote.d.ts.map