export declare function getApi(uri: string): Promise<any>;
export declare function postApi(uri: string, data: any): Promise<any>;
export declare function fullUri(path: string): string;
export declare function baseURI(): string;
export declare function setBaseURI(base: string): void;
//# sourceMappingURL=core.d.ts.map