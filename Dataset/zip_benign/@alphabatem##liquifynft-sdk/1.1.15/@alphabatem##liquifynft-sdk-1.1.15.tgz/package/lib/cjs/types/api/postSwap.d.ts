import { SwapRequest, SwapResponse } from "../entities";
export declare function postSwap(req: SwapRequest): Promise<SwapResponse>;
//# sourceMappingURL=postSwap.d.ts.map