export declare class Route {
    readonly inputMint: string;
    readonly outputMint: string;
    readonly slippage: number;
    readonly swapMode: number;
    readonly marketRoute: MarketRoute;
    readonly token: TokenRoute;
    readonly platformFee: Fee;
    constructor(props: any);
}
export declare class MarketRoute {
    readonly id: string;
    readonly marketId: string;
    readonly label: string;
    readonly inAmount: string;
    readonly outAmount: string;
    readonly lPFee: Fee;
    constructor(props: any);
}
export declare class TokenRoute {
    readonly id: string;
    readonly label: string;
    readonly inAmount: number;
    readonly OutAmount: number;
    readonly lPFee: number;
    constructor(props: any);
}
export declare class Fee {
    readonly amount: number;
    readonly mint: string;
    readonly percent: number;
    constructor(props: any);
}
//# sourceMappingURL=route.d.ts.map