export declare class StatOverviewResponse {
    readonly users_connected: number;
    readonly volume_all: number;
    readonly segment: StatSegment;
    constructor(props: any);
}
export declare class StatSegment {
    readonly quote_count: number;
    readonly swap_count: number;
    readonly volume: number;
    constructor(props: any);
}
//# sourceMappingURL=stats.d.ts.map