import { Route } from "./route";
import { VersionedTransaction } from "@solana/web3.js";
export declare class SwapRequest {
    route: Route;
    userPublicKey: string;
    priorityFee: number;
    constructor(route: Route, userPublicKey: string, priorityFee: number);
}
export declare class SwapResponse {
    readonly setupTransactions: string[];
    readonly cleanupTransactions: string[];
    readonly swapTransactions: string[];
    constructor(txns: string[]);
    toSetupTransactions(): VersionedTransaction[];
    toSwapTransactions(): VersionedTransaction[];
    toCleanupTransactions(): VersionedTransaction[];
    _toTransactions(tx: string[]): VersionedTransaction[];
}
//# sourceMappingURL=swap.d.ts.map