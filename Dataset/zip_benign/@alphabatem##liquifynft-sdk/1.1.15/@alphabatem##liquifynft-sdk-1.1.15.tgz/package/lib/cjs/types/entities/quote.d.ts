import { Route } from "./route";
export declare class QuoteRequest {
    readonly id: string;
    readonly inputMint: string;
    readonly outputMint: string;
    readonly swapMode: number;
    readonly slippage: number;
    readonly referralFee: number;
    readonly referralFeeTarget?: string;
    readonly userPublicKey: string;
    constructor(id: string, inputMint: string, outputMint: string, swapMode: number, slippage: number, userPublicKey: string, referralFee?: number, referralFeeTarget?: string);
}
export declare class QuoteResponse {
    readonly routes: Route[];
    readonly slot: number;
    constructor(routes: Route[], slot: number);
}
//# sourceMappingURL=quote.d.ts.map