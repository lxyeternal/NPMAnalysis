export declare function getCollectionPricing(): Promise<any>;
//# sourceMappingURL=getCollectionPricing.d.ts.map