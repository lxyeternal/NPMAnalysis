import { StatOverviewResponse } from "../entities/stats";
export declare function getStatsOverview(): Promise<StatOverviewResponse>;
//# sourceMappingURL=getStatsOverview.d.ts.map