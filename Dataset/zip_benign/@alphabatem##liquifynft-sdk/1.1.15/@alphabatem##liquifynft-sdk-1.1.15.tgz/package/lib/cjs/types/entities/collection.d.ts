export declare class CollectionResponse {
    readonly id: string;
    readonly name: string;
    readonly imageSrc: string;
    readonly markets: CollectionMarket[];
    readonly firstCreator: string;
    readonly addedBy: string;
    constructor(props: any);
}
export declare class CollectionMarket {
    readonly hadeswap: string;
    readonly hyperspace: string;
    readonly elixir: string;
    readonly tensor: string;
    readonly coralCube: string;
    readonly magicEden: string;
    constructor(props: any);
}
//# sourceMappingURL=collection.d.ts.map