import { CollectionResponse } from "../entities";
export declare function getCollection(collectionAddr: string): Promise<CollectionResponse>;
//# sourceMappingURL=getCollection.d.ts.map