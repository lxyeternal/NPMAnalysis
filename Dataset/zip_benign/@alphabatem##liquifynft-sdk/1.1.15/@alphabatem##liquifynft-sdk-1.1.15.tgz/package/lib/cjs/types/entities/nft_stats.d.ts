import { CollectionResponse } from "./collection";
export declare class NftStatResponse {
    readonly lastSaleTxn: number;
    readonly lastSalePrice: number;
    readonly purchaseDate: number;
    readonly collection: CollectionResponse;
    constructor(props: any);
}
//# sourceMappingURL=nft_stats.d.ts.map