import { NftStatResponse } from "../entities/nft_stats";
export declare function getNftStats(id: string): Promise<NftStatResponse>;
//# sourceMappingURL=getNftStats.d.ts.map