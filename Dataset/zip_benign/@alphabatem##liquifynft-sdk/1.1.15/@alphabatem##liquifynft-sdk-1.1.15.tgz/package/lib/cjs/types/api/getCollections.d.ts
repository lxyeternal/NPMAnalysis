import { CollectionResponse } from "../entities";
export declare function getCollections(page?: number, limit?: number, search?: string, onChainOnly?: boolean): Promise<CollectionResponse>;
//# sourceMappingURL=getCollections.d.ts.map