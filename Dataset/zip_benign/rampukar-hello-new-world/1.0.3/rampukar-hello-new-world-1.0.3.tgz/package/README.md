# This is just an example package 

# Example:
const { area, perimeter} = require('rampukar-hello-new-world');
console.log(area(1));
console.log(perimeter(0.5));