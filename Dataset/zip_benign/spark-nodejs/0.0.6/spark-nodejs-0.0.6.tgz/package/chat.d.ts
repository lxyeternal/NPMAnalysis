interface ISparkSocketBaseOptions {
    appid?: string;
    uid?: string;
    temperature?: number;
    maxTokens?: number;
    topK?: number;
    chatId?: string;
    useHistory?: boolean;
}
interface ISparkSocketOptions extends ISparkSocketBaseOptions {
    url?: string;
    urlGetter?: () => Promise<string>;
}
interface IQuestionOptions {
    content: string;
    onData?(options: {
        content: string;
        start: boolean;
        end: boolean;
        seq: number;
    }): void;
    onEnd?(options: {
        content: string;
        tokens: number;
        questionTokens: number;
    }): void;
}
declare class SparkChat {
    static Socket: typeof WebSocket;
    temperature: number;
    maxTokens: number;
    topK: number;
    chatId?: string;
    appid: string;
    uid: string;
    isInRequest: boolean;
    useHistory: boolean;
    url: string;
    urlGetter?: () => Promise<string>;
    private history;
    private historyTokens;
    private historyTokensSum;
    private maxHistoryTokens;
    constructor({ url, appid, uid, temperature, maxTokens, topK, chatId, useHistory, urlGetter, }: ISparkSocketOptions);
    private _addIntoHistory;
    private _getUrl;
    chat({ content, onData, onEnd, }: IQuestionOptions): Promise<string>;
}

export { IQuestionOptions, ISparkSocketBaseOptions, ISparkSocketOptions, SparkChat };
