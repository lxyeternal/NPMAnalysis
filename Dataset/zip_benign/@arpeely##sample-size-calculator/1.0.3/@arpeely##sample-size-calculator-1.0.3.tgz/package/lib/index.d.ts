declare const sampleSizeEstimate: (relativeMDE: number, baselineConversionRate: number, significance?: number) => number;
export default sampleSizeEstimate;
