export * from './lib/totop.component';
