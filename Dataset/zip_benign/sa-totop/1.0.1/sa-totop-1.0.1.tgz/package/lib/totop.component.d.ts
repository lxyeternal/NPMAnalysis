import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TotopComponent {
    private platformId;
    constructor(platformId: object);
    width: number;
    bottom: number;
    end: number;
    color: string;
    scrollBehavior: ScrollBehavior;
    background: string;
    duration: number;
    visibilityHeight: number;
    alwaysVisible: boolean;
    customeBtn: boolean;
    scrollComplete: EventEmitter<any>;
    toTopClicked: EventEmitter<any>;
    documentHieght: number;
    scrollHeight: number;
    divisionConst: number;
    dashOffset: number;
    screenHieght: number;
    toTop(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TotopComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TotopComponent, "sa-totop", never, { "width": { "alias": "width"; "required": false; }; "bottom": { "alias": "bottom"; "required": false; }; "end": { "alias": "end"; "required": false; }; "color": { "alias": "color"; "required": false; }; "scrollBehavior": { "alias": "scrollBehavior"; "required": false; }; "background": { "alias": "background"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "visibilityHeight": { "alias": "visibilityHeight"; "required": false; }; "alwaysVisible": { "alias": "alwaysVisible"; "required": false; }; "customeBtn": { "alias": "customeBtn"; "required": false; }; }, { "scrollComplete": "scrollComplete"; "toTopClicked": "toTopClicked"; }, never, ["*"], true, never>;
}
