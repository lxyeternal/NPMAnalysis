# youkuohao apps service


## Docker Service Example

```sh
docker service create --name youkuohao-apps \
  --mount type=bind,src=$PWD/,dst=/data/db \
  --env 'PORT=8080' \
  --env 'MAIN_URL=https://cdn.jsdelivr.net/npm/youkuohao-apps' \
  --network cms \
  --limit-cpu 0.5 \
  --publish 10002:8080 \
  docker.pkg.github.com/heineiuo/node-universal-runtime/node-universal-runtime:0.4.0
```


