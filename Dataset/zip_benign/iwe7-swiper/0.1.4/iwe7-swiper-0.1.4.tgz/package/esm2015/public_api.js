/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
export { SwiperComponents, SwiperDevices, Iwe7SwiperModule } from './lib/iwe7-swiper.module';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL2l3ZTctc3dpcGVyLyIsInNvdXJjZXMiOlsicHVibGljX2FwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsa0VBQWMsMEJBQTBCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgKiBmcm9tICcuL2xpYi9pd2U3LXN3aXBlci5tb2R1bGUnO1xuIl19