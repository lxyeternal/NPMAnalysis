(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('iwe7-core'), require('rxjs'), require('rxjs/operators'), require('iwe7-better-scroll'), require('iwe7-icss'), require('@angular/cdk/coercion'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('iwe7-swiper', ['exports', '@angular/core', 'iwe7-core', 'rxjs', 'rxjs/operators', 'iwe7-better-scroll', 'iwe7-icss', '@angular/cdk/coercion', '@angular/common'], factory) :
    (factory((global['iwe7-swiper'] = {}),global.ng.core,null,global.rxjs,global.rxjs.operators,null,null,global.ng.cdk.coercion,global.ng.common));
}(this, (function (exports,core,iwe7Core,rxjs,operators,iwe7BetterScroll,iwe7Icss,coercion,common) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b)
            if (b.hasOwnProperty(p))
                d[p] = b[p]; };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SwiperImageDirective = (function (_super) {
        __extends(SwiperImageDirective, _super);
        function SwiperImageDirective(render, ele, injector) {
            var _this = _super.call(this, injector) || this;
            _this.render = render;
            _this.ele = ele;
            _this.injector = injector;
            _this.getCyc('ngOnChanges').subscribe(function (res) {
                _this.render.setStyle(_this.image.nativeElement, 'background-image', "url(" + _this.swiperImage + ")");
            });
            return _this;
        }
        SwiperImageDirective.decorators = [
            { type: core.Component, args: [{
                        selector: '[swiperImage]',
                        template: "\n        <div class=\"swiper-image\" #image>\n            <ng-content></ng-content>\n        </div>\n    "
                    },] },
        ];
        /** @nocollapse */
        SwiperImageDirective.ctorParameters = function () {
            return [
                { type: core.Renderer2 },
                { type: core.ElementRef },
                { type: core.Injector }
            ];
        };
        SwiperImageDirective.propDecorators = {
            swiperImage: [{ type: core.Input }],
            image: [{ type: core.ViewChild, args: ['image',] }]
        };
        return SwiperImageDirective;
    }(iwe7Core.Iwe7CoreComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SwiperDotsDirective = (function () {
        function SwiperDotsDirective(cd, ngZone) {
            this.cd = cd;
            this.ngZone = ngZone;
            this._dots = true;
            this.currentIndex = new rxjs.BehaviorSubject(0);
        }
        Object.defineProperty(SwiperDotsDirective.prototype, "outlet", {
            set: /**
             * @param {?} val
             * @return {?}
             */ function (val) {
                var _this = this;
                val.ngSlide.subscribe(this.currentIndex);
                this.currentIndex.subscribe(function (res) {
                    _this.cd.markForCheck();
                });
                this.dots = val.getCyc('ngAfterContentInit').pipe(operators.map(function () {
                    var /** @type {?} */ items = [];
                    for (var /** @type {?} */ key = 0; key < val.children.length; key++) {
                        items.push(key);
                    }
                    return items;
                }));
            },
            enumerable: true,
            configurable: true
        });
        SwiperDotsDirective.decorators = [
            { type: core.Component, args: [{
                        selector: '[swiperDots]',
                        template: "\n    <ng-container *ngFor=\"let item of dots|async;index as i;\">\n        <span [swiperDot]=\"i\"></span>\n    </ng-container>\n    ",
                        changeDetection: core.ChangeDetectionStrategy.OnPush
                    },] },
        ];
        /** @nocollapse */
        SwiperDotsDirective.ctorParameters = function () {
            return [
                { type: core.ChangeDetectorRef },
                { type: core.NgZone }
            ];
        };
        SwiperDotsDirective.propDecorators = {
            _dots: [{ type: core.HostBinding, args: ['class.dots',] }],
            dots: [{ type: core.Input }],
            outlet: [{ type: core.Input }]
        };
        return SwiperDotsDirective;
    }());
    var SwiperDotDirective = (function () {
        function SwiperDotDirective(dots, render, ele) {
            this.dots = dots;
            this.render = render;
            this.ele = ele;
            this.dot = true;
        }
        /**
         * @return {?}
         */
        SwiperDotDirective.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.dots.currentIndex.subscribe(function (res) {
                    if (res === _this.swiperDot) {
                        _this.render.addClass(_this.ele.nativeElement, 'active');
                    }
                    else {
                        _this.render.removeClass(_this.ele.nativeElement, 'active');
                    }
                });
            };
        SwiperDotDirective.decorators = [
            { type: core.Directive, args: [{ selector: '[swiperDot]' },] },
        ];
        /** @nocollapse */
        SwiperDotDirective.ctorParameters = function () {
            return [
                { type: SwiperDotsDirective },
                { type: core.Renderer2 },
                { type: core.ElementRef }
            ];
        };
        SwiperDotDirective.propDecorators = {
            dot: [{ type: core.HostBinding, args: ['class.dot',] }],
            swiperDot: [{ type: core.Input }]
        };
        return SwiperDotDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SwiperItemDirective = (function () {
        function SwiperItemDirective() {
            this.item = true;
        }
        SwiperItemDirective.decorators = [
            { type: core.Directive, args: [{ selector: '[swiperItem]' },] },
        ];
        SwiperItemDirective.propDecorators = {
            item: [{ type: core.HostBinding, args: ['class.swiper-item',] }]
        };
        return SwiperItemDirective;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SwiperOutletComponent = (function (_super) {
        __extends(SwiperOutletComponent, _super);
        function SwiperOutletComponent(injector, ele, render, better) {
            var _this = _super.call(this, ele, injector, better) || this;
            _this.ele = ele;
            _this.render = render;
            _this.better = better;
            _this.height = '100%';
            _this._hasDot = true;
            // 自动轮播
            _this._autoPlay = true;
            _this._interval = 4000;
            _this.ngSlide = new core.EventEmitter();
            _this.currentPageIndex = 0;
            _this.options.scrollX = true;
            _this.options.scrollY = false;
            _this.snap = /** @type {?} */ ({});
            _this.click = true;
            _this.autoPlay = true;
            _this.setStyleInputs(['height']);
            _this.getCyc('betterScrollInited').subscribe(function (res) {
                _this._scroll.autoPlay({
                    interval: _this._interval,
                    autoPlay: _this._autoPlay
                });
                _this.styleObj = {
                    height: _this.height
                };
                var /** @type {?} */ scrollEnd = function () {
                    _this.onScrollEnd();
                };
                _this._scroll.on('scrollEnd', scrollEnd);
                _this.updateStyle(_this.ele.nativeElement);
            });
            return _this;
        }
        Object.defineProperty(SwiperOutletComponent.prototype, "hasDot", {
            set: /**
             * @param {?} val
             * @return {?}
             */ function (val) {
                this._hasDot = coercion.coerceBooleanProperty(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SwiperOutletComponent.prototype, "loop", {
            set: /**
             * @param {?} val
             * @return {?}
             */ function (val) {
                ((this.options.snap)).loop = coercion.coerceBooleanProperty(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SwiperOutletComponent.prototype, "speed", {
            set: /**
             * @param {?} val
             * @return {?}
             */ function (val) {
                ((this.options.snap)).speed = coercion.coerceNumberProperty(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SwiperOutletComponent.prototype, "autoPlay", {
            set: /**
             * @param {?} val
             * @return {?}
             */ function (val) {
                this._autoPlay = coercion.coerceBooleanProperty(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(SwiperOutletComponent.prototype, "interval", {
            set: /**
             * @param {?} val
             * @return {?}
             */ function (val) {
                this._interval = coercion.coerceNumberProperty(val);
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @return {?}
         */
        SwiperOutletComponent.prototype.onScrollEnd = /**
         * @return {?}
         */
            function () {
                if (this.options.scrollX) {
                    this.currentPageIndex = this._scroll.getPageX();
                }
                else {
                    this.currentPageIndex = this._scroll.getPageY();
                }
                this.ngSlide.emit(this.currentPageIndex);
                if (this._autoPlay) {
                    this._scroll.play();
                }
            };
        SwiperOutletComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'swiper-outlet',
                        template: "<ng-content></ng-content>\n",
                        styles: ["swiper-outlet{--height:100%;min-height:1px;display:block;position:relative;height:var(--height)}swiper-outlet .slide-item{display:block;float:left;box-sizing:border-box;overflow:hidden;text-align:center;width:100%;height:var(--height);position:relative}swiper-outlet .slide-item .swiper-image{position:absolute;top:0;left:0;right:0;bottom:0;background-size:100% var(--height);background-repeat:no-repeat;zoom:1;background-position:center 0}swiper-outlet .slide-item a{display:block;width:100%;overflow:hidden;text-decoration:none}.dots{position:absolute;justify-content:center;align-items:center}.dots .dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#ccc}.dots .dot.active{border-radius:5px;background:#fff}.scroll-x .slide-item{height:100%}.scroll-x img{display:block;width:100%}.scroll-x .dots{right:0;left:0;bottom:12px;-webkit-transform:translateZ(1px);transform:translateZ(1px);text-align:center;font-size:0;display:flex;flex-direction:row}.scroll-x .dots .dot{margin:0 4px}.scroll-x .dots .dot.active{width:20px}.scroll-y img{display:block;width:100%}.scroll-y .dots{top:0;bottom:0;right:12px;-webkit-transform:translateZ(1px);transform:translateZ(1px);text-align:center;font-size:0;display:flex;flex-direction:column}.scroll-y .dots .dot{margin:4px 0}.scroll-y .dots .dot.active{height:20px}"],
                        changeDetection: core.ChangeDetectionStrategy.OnPush,
                        encapsulation: core.ViewEncapsulation.None,
                        host: {
                            '[class.scroll-x]': 'scrollX',
                            '[class.scroll-y]': 'scrollY',
                            '[style.height]': 'height'
                        },
                        inputs: ['interval', 'threshold', 'speed', 'list'],
                        providers: [iwe7Icss.Iwe7IcssService],
                        exportAs: 'swiperOutlet'
                    },] },
        ];
        /** @nocollapse */
        SwiperOutletComponent.ctorParameters = function () {
            return [
                { type: core.Injector },
                { type: core.ElementRef },
                { type: core.Renderer2 },
                { type: iwe7BetterScroll.BetterManagerService }
            ];
        };
        SwiperOutletComponent.propDecorators = {
            height: [{ type: core.Input }],
            hasDot: [{ type: core.Input }],
            loop: [{ type: core.Input }],
            speed: [{ type: core.Input }],
            autoPlay: [{ type: core.Input }],
            interval: [{ type: core.Input }],
            ngSlide: [{ type: core.Output }]
        };
        return SwiperOutletComponent;
    }(iwe7BetterScroll.BetterScrollDirective));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ SwiperComponents = [
        SwiperOutletComponent
    ];
    var /** @type {?} */ SwiperDevices = [
        SwiperItemDirective,
        SwiperImageDirective,
        SwiperDotsDirective,
        SwiperDotDirective
    ];
    var Iwe7SwiperModule = (function () {
        function Iwe7SwiperModule() {
        }
        Iwe7SwiperModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [
                            common.CommonModule,
                            iwe7BetterScroll.BetterCoreModule
                        ],
                        declarations: __spread(SwiperComponents, SwiperDevices),
                        exports: __spread(SwiperComponents, SwiperDevices)
                    },] },
        ];
        return Iwe7SwiperModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    exports.SwiperComponents = SwiperComponents;
    exports.SwiperDevices = SwiperDevices;
    exports.Iwe7SwiperModule = Iwe7SwiperModule;
    exports.ɵe = SwiperDotDirective;
    exports.ɵd = SwiperDotsDirective;
    exports.ɵc = SwiperImageDirective;
    exports.ɵb = SwiperItemDirective;
    exports.ɵa = SwiperOutletComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXdlNy1zd2lwZXIudW1kLmpzLm1hcCIsInNvdXJjZXMiOltudWxsLCJuZzovL2l3ZTctc3dpcGVyL2xpYi9zd2lwZXItZGlyZWN0aXZlL3N3aXBlci1pbWFnZS50cyIsIm5nOi8vaXdlNy1zd2lwZXIvbGliL3N3aXBlci1kaXJlY3RpdmUvc3dpcGVyLWRvdHMudHMiLCJuZzovL2l3ZTctc3dpcGVyL2xpYi9zd2lwZXItZGlyZWN0aXZlL3N3aXBlci1pdGVtLnRzIiwibmc6Ly9pd2U3LXN3aXBlci9saWIvc3dpcGVyLW91dGxldC9zd2lwZXItb3V0bGV0LnRzIiwibmc6Ly9pd2U3LXN3aXBlci9saWIvaXdlNy1zd2lwZXIubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qISAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG5Db3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cclxuTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTsgeW91IG1heSBub3QgdXNlXHJcbnRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlXHJcbkxpY2Vuc2UgYXQgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXHJcblxyXG5USElTIENPREUgSVMgUFJPVklERUQgT04gQU4gKkFTIElTKiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZXHJcbktJTkQsIEVJVEhFUiBFWFBSRVNTIE9SIElNUExJRUQsIElOQ0xVRElORyBXSVRIT1VUIExJTUlUQVRJT04gQU5ZIElNUExJRURcclxuV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIFRJVExFLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSxcclxuTUVSQ0hBTlRBQkxJVFkgT1IgTk9OLUlORlJJTkdFTUVOVC5cclxuXHJcblNlZSB0aGUgQXBhY2hlIFZlcnNpb24gMi4wIExpY2Vuc2UgZm9yIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9uc1xyXG5hbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXHJcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXHJcbi8qIGdsb2JhbCBSZWZsZWN0LCBQcm9taXNlICovXHJcblxyXG52YXIgZXh0ZW5kU3RhdGljcyA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiB8fFxyXG4gICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoYi5oYXNPd25Qcm9wZXJ0eShwKSkgZFtwXSA9IGJbcF07IH07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHRlbmRzKGQsIGIpIHtcclxuICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxufVxyXG5cclxuZXhwb3J0IHZhciBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gX19hc3NpZ24odCkge1xyXG4gICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcclxuICAgICAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkpIHRbcF0gPSBzW3BdO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIGlmIChlLmluZGV4T2YocFtpXSkgPCAwKVxyXG4gICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgIHJldHVybiB0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYykge1xyXG4gICAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5kZWNvcmF0ZSA9PT0gXCJmdW5jdGlvblwiKSByID0gUmVmbGVjdC5kZWNvcmF0ZShkZWNvcmF0b3JzLCB0YXJnZXQsIGtleSwgZGVzYyk7XHJcbiAgICBlbHNlIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSBpZiAoZCA9IGRlY29yYXRvcnNbaV0pIHIgPSAoYyA8IDMgPyBkKHIpIDogYyA+IDMgPyBkKHRhcmdldCwga2V5LCByKSA6IGQodGFyZ2V0LCBrZXkpKSB8fCByO1xyXG4gICAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XHJcbiAgICByZXR1cm4gZnVuY3Rpb24gKHRhcmdldCwga2V5KSB7IGRlY29yYXRvcih0YXJnZXQsIGtleSwgcGFyYW1JbmRleCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcclxuICAgIGlmICh0eXBlb2YgUmVmbGVjdCA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgUmVmbGVjdC5tZXRhZGF0YSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gUmVmbGVjdC5tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0ZXIodGhpc0FyZywgX2FyZ3VtZW50cywgUCwgZ2VuZXJhdG9yKSB7XHJcbiAgICByZXR1cm4gbmV3IChQIHx8IChQID0gUHJvbWlzZSkpKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcclxuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XHJcbiAgICAgICAgZnVuY3Rpb24gc3RlcChyZXN1bHQpIHsgcmVzdWx0LmRvbmUgPyByZXNvbHZlKHJlc3VsdC52YWx1ZSkgOiBuZXcgUChmdW5jdGlvbiAocmVzb2x2ZSkgeyByZXNvbHZlKHJlc3VsdC52YWx1ZSk7IH0pLnRoZW4oZnVsZmlsbGVkLCByZWplY3RlZCk7IH1cclxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XHJcbiAgICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcclxuICAgIHZhciBfID0geyBsYWJlbDogMCwgc2VudDogZnVuY3Rpb24oKSB7IGlmICh0WzBdICYgMSkgdGhyb3cgdFsxXTsgcmV0dXJuIHRbMV07IH0sIHRyeXM6IFtdLCBvcHM6IFtdIH0sIGYsIHksIHQsIGc7XHJcbiAgICByZXR1cm4gZyA9IHsgbmV4dDogdmVyYigwKSwgXCJ0aHJvd1wiOiB2ZXJiKDEpLCBcInJldHVyblwiOiB2ZXJiKDIpIH0sIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiAoZ1tTeW1ib2wuaXRlcmF0b3JdID0gZnVuY3Rpb24oKSB7IHJldHVybiB0aGlzOyB9KSwgZztcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyByZXR1cm4gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIHN0ZXAoW24sIHZdKTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc3RlcChvcCkge1xyXG4gICAgICAgIGlmIChmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiR2VuZXJhdG9yIGlzIGFscmVhZHkgZXhlY3V0aW5nLlwiKTtcclxuICAgICAgICB3aGlsZSAoXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIGV4cG9ydHMpIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKCFleHBvcnRzLmhhc093blByb3BlcnR5KHApKSBleHBvcnRzW3BdID0gbVtwXTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgaW4gbW9kKSBpZiAoT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobW9kLCBrKSkgcmVzdWx0W2tdID0gbW9kW2tdO1xyXG4gICAgcmVzdWx0LmRlZmF1bHQgPSBtb2Q7XHJcbiAgICByZXR1cm4gcmVzdWx0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19pbXBvcnREZWZhdWx0KG1vZCkge1xyXG4gICAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcclxufVxyXG4iLCJpbXBvcnQgeyBEb21TYW5pdGl6ZXIgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7IEhvc3RCaW5kaW5nLCBSZW5kZXJlcjIsIEVsZW1lbnRSZWYsIEluamVjdG9yLCBDb21wb25lbnQsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRGlyZWN0aXZlLCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSXdlN0NvcmVDb21wb25lbnQgfSBmcm9tICdpd2U3LWNvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ1tzd2lwZXJJbWFnZV0nLFxuICAgIHRlbXBsYXRlOiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzd2lwZXItaW1hZ2VcIiAjaW1hZ2U+XG4gICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgICAgIDwvZGl2PlxuICAgIGBcbn0pXG5leHBvcnQgY2xhc3MgU3dpcGVySW1hZ2VEaXJlY3RpdmUgZXh0ZW5kcyBJd2U3Q29yZUNvbXBvbmVudCB7XG4gICAgQElucHV0KCkgc3dpcGVySW1hZ2U6IHN0cmluZztcbiAgICBAVmlld0NoaWxkKCdpbWFnZScpIGltYWdlOiBFbGVtZW50UmVmO1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgcmVuZGVyOiBSZW5kZXJlcjIsXG4gICAgICAgIHB1YmxpYyBlbGU6IEVsZW1lbnRSZWYsXG4gICAgICAgIHB1YmxpYyBpbmplY3RvcjogSW5qZWN0b3JcbiAgICApIHtcbiAgICAgICAgc3VwZXIoaW5qZWN0b3IpO1xuICAgICAgICB0aGlzLmdldEN5YygnbmdPbkNoYW5nZXMnKS5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyLnNldFN0eWxlKHRoaXMuaW1hZ2UubmF0aXZlRWxlbWVudCwgJ2JhY2tncm91bmQtaW1hZ2UnLCBgdXJsKCR7dGhpcy5zd2lwZXJJbWFnZX0pYCk7XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEVsZW1lbnRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUsIEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgQ29tcG9uZW50LCBIb3N0QmluZGluZywgSW5wdXQsIENoYW5nZURldGVjdG9yUmVmLCBOZ1pvbmUsIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN3aXBlck91dGxldENvbXBvbmVudCB9IGZyb20gJy4uL3N3aXBlci1vdXRsZXQvc3dpcGVyLW91dGxldCc7XG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogJ1tzd2lwZXJEb3RzXScsXG4gICAgdGVtcGxhdGU6IGBcbiAgICA8bmctY29udGFpbmVyICpuZ0Zvcj1cImxldCBpdGVtIG9mIGRvdHN8YXN5bmM7aW5kZXggYXMgaTtcIj5cbiAgICAgICAgPHNwYW4gW3N3aXBlckRvdF09XCJpXCI+PC9zcGFuPlxuICAgIDwvbmctY29udGFpbmVyPlxuICAgIGAsXG4gICAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2hcbn0pXG5leHBvcnQgY2xhc3MgU3dpcGVyRG90c0RpcmVjdGl2ZSB7XG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5kb3RzJykgX2RvdHM6IGJvb2xlYW4gPSB0cnVlO1xuICAgIGN1cnJlbnRJbmRleDogQmVoYXZpb3JTdWJqZWN0PG51bWJlcj4gPSBuZXcgQmVoYXZpb3JTdWJqZWN0KDApO1xuICAgIEBJbnB1dCgpIGRvdHM6IE9ic2VydmFibGU8YW55W10+O1xuICAgIEBJbnB1dCgpXG4gICAgc2V0IG91dGxldCh2YWw6IFN3aXBlck91dGxldENvbXBvbmVudCkge1xuICAgICAgICB2YWwubmdTbGlkZS5zdWJzY3JpYmUodGhpcy5jdXJyZW50SW5kZXgpO1xuICAgICAgICB0aGlzLmN1cnJlbnRJbmRleC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgICAgIHRoaXMuY2QubWFya0ZvckNoZWNrKCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmRvdHMgPSB2YWwuZ2V0Q3ljKCduZ0FmdGVyQ29udGVudEluaXQnKS5waXBlKFxuICAgICAgICAgICAgbWFwKCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpdGVtcyA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGtleSA9IDA7IGtleSA8IHZhbC5jaGlsZHJlbi5sZW5ndGg7IGtleSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zLnB1c2goa2V5KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIGl0ZW1zO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgY2Q6IENoYW5nZURldGVjdG9yUmVmLCBwdWJsaWMgbmdab25lOiBOZ1pvbmUpIHsgfVxufVxuXG5cbmltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuQERpcmVjdGl2ZSh7IHNlbGVjdG9yOiAnW3N3aXBlckRvdF0nIH0pXG5leHBvcnQgY2xhc3MgU3dpcGVyRG90RGlyZWN0aXZlIHtcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmRvdCcpIGRvdDogYm9vbGVhbiA9IHRydWU7XG4gICAgQElucHV0KCkgc3dpcGVyRG90OiBudW1iZXI7XG4gICAgY29uc3RydWN0b3IocHVibGljIGRvdHM6IFN3aXBlckRvdHNEaXJlY3RpdmUsIHB1YmxpYyByZW5kZXI6IFJlbmRlcmVyMiwgcHVibGljIGVsZTogRWxlbWVudFJlZikge31cblxuICAgIG5nT25Jbml0KCkge1xuICAgICAgICB0aGlzLmRvdHMuY3VycmVudEluZGV4LnN1YnNjcmliZShyZXMgPT4ge1xuICAgICAgICAgICAgaWYgKHJlcyA9PT0gdGhpcy5zd2lwZXJEb3QpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbmRlci5hZGRDbGFzcyh0aGlzLmVsZS5uYXRpdmVFbGVtZW50LCAnYWN0aXZlJyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucmVuZGVyLnJlbW92ZUNsYXNzKHRoaXMuZWxlLm5hdGl2ZUVsZW1lbnQsICdhY3RpdmUnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgSG9zdEJpbmRpbmcgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERpcmVjdGl2ZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuQERpcmVjdGl2ZSh7IHNlbGVjdG9yOiAnW3N3aXBlckl0ZW1dJyB9KVxuZXhwb3J0IGNsYXNzIFN3aXBlckl0ZW1EaXJlY3RpdmUge1xuICAgIEBIb3N0QmluZGluZygnY2xhc3Muc3dpcGVyLWl0ZW0nKSBpdGVtOiBib29sZWFuID0gdHJ1ZTtcbn1cbiIsImltcG9ydCB7IEJldHRlck1hbmFnZXJTZXJ2aWNlLCBCZXR0ZXJTY3JvbGxEaXJlY3RpdmUgfSBmcm9tICdpd2U3LWJldHRlci1zY3JvbGwnO1xuaW1wb3J0IHsgSXdlN0ljc3NTZXJ2aWNlIH0gZnJvbSAnaXdlNy1pY3NzJztcbmltcG9ydCB7IEVsZW1lbnRSZWYsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgICBDb21wb25lbnQsIEluamVjdG9yLFxuICAgIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBWaWV3RW5jYXBzdWxhdGlvbixcbiAgICBJbnB1dCwgT3V0cHV0LCBFdmVudEVtaXR0ZXJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBjb2VyY2VCb29sZWFuUHJvcGVydHksIGNvZXJjZU51bWJlclByb3BlcnR5IH0gZnJvbSAnQGFuZ3VsYXIvY2RrL2NvZXJjaW9uJztcbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnc3dpcGVyLW91dGxldCcsXG4gICAgdGVtcGxhdGU6IGA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG5gLFxuICAgIHN0eWxlczogW2Bzd2lwZXItb3V0bGV0ey0taGVpZ2h0OjEwMCU7bWluLWhlaWdodDoxcHg7ZGlzcGxheTpibG9jaztwb3NpdGlvbjpyZWxhdGl2ZTtoZWlnaHQ6dmFyKC0taGVpZ2h0KX1zd2lwZXItb3V0bGV0IC5zbGlkZS1pdGVte2Rpc3BsYXk6YmxvY2s7ZmxvYXQ6bGVmdDtib3gtc2l6aW5nOmJvcmRlci1ib3g7b3ZlcmZsb3c6aGlkZGVuO3RleHQtYWxpZ246Y2VudGVyO3dpZHRoOjEwMCU7aGVpZ2h0OnZhcigtLWhlaWdodCk7cG9zaXRpb246cmVsYXRpdmV9c3dpcGVyLW91dGxldCAuc2xpZGUtaXRlbSAuc3dpcGVyLWltYWdle3Bvc2l0aW9uOmFic29sdXRlO3RvcDowO2xlZnQ6MDtyaWdodDowO2JvdHRvbTowO2JhY2tncm91bmQtc2l6ZToxMDAlIHZhcigtLWhlaWdodCk7YmFja2dyb3VuZC1yZXBlYXQ6bm8tcmVwZWF0O3pvb206MTtiYWNrZ3JvdW5kLXBvc2l0aW9uOmNlbnRlciAwfXN3aXBlci1vdXRsZXQgLnNsaWRlLWl0ZW0gYXtkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCU7b3ZlcmZsb3c6aGlkZGVuO3RleHQtZGVjb3JhdGlvbjpub25lfS5kb3Rze3Bvc2l0aW9uOmFic29sdXRlO2p1c3RpZnktY29udGVudDpjZW50ZXI7YWxpZ24taXRlbXM6Y2VudGVyfS5kb3RzIC5kb3R7ZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6OHB4O2hlaWdodDo4cHg7Ym9yZGVyLXJhZGl1czo1MCU7YmFja2dyb3VuZDojY2NjfS5kb3RzIC5kb3QuYWN0aXZle2JvcmRlci1yYWRpdXM6NXB4O2JhY2tncm91bmQ6I2ZmZn0uc2Nyb2xsLXggLnNsaWRlLWl0ZW17aGVpZ2h0OjEwMCV9LnNjcm9sbC14IGltZ3tkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCV9LnNjcm9sbC14IC5kb3Rze3JpZ2h0OjA7bGVmdDowO2JvdHRvbToxMnB4Oy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVooMXB4KTt0cmFuc2Zvcm06dHJhbnNsYXRlWigxcHgpO3RleHQtYWxpZ246Y2VudGVyO2ZvbnQtc2l6ZTowO2Rpc3BsYXk6ZmxleDtmbGV4LWRpcmVjdGlvbjpyb3d9LnNjcm9sbC14IC5kb3RzIC5kb3R7bWFyZ2luOjAgNHB4fS5zY3JvbGwteCAuZG90cyAuZG90LmFjdGl2ZXt3aWR0aDoyMHB4fS5zY3JvbGwteSBpbWd7ZGlzcGxheTpibG9jazt3aWR0aDoxMDAlfS5zY3JvbGwteSAuZG90c3t0b3A6MDtib3R0b206MDtyaWdodDoxMnB4Oy13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVooMXB4KTt0cmFuc2Zvcm06dHJhbnNsYXRlWigxcHgpO3RleHQtYWxpZ246Y2VudGVyO2ZvbnQtc2l6ZTowO2Rpc3BsYXk6ZmxleDtmbGV4LWRpcmVjdGlvbjpjb2x1bW59LnNjcm9sbC15IC5kb3RzIC5kb3R7bWFyZ2luOjRweCAwfS5zY3JvbGwteSAuZG90cyAuZG90LmFjdGl2ZXtoZWlnaHQ6MjBweH1gXSxcbiAgICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxuICAgIGhvc3Q6IHtcbiAgICAgICAgJ1tjbGFzcy5zY3JvbGwteF0nOiAnc2Nyb2xsWCcsXG4gICAgICAgICdbY2xhc3Muc2Nyb2xsLXldJzogJ3Njcm9sbFknLFxuICAgICAgICAnW3N0eWxlLmhlaWdodF0nOiAnaGVpZ2h0J1xuICAgIH0sXG4gICAgaW5wdXRzOiBbJ2ludGVydmFsJywgJ3RocmVzaG9sZCcsICdzcGVlZCcsICdsaXN0J10sXG4gICAgcHJvdmlkZXJzOiBbSXdlN0ljc3NTZXJ2aWNlXSxcbiAgICBleHBvcnRBczogJ3N3aXBlck91dGxldCdcbn0pXG5leHBvcnQgY2xhc3MgU3dpcGVyT3V0bGV0Q29tcG9uZW50IGV4dGVuZHMgQmV0dGVyU2Nyb2xsRGlyZWN0aXZlIHtcbiAgICBASW5wdXQoKSBoZWlnaHQgPSAnMTAwJSc7XG4gICAgX2hhc0RvdDogYm9vbGVhbiA9IHRydWU7XG4gICAgQElucHV0KClcbiAgICBzZXQgaGFzRG90KHZhbDogYW55KSB7XG4gICAgICAgIHRoaXMuX2hhc0RvdCA9IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSh2YWwpO1xuICAgIH1cbiAgICBASW5wdXQoKVxuICAgIHNldCBsb29wKHZhbDogYW55KSB7XG4gICAgICAgICg8YW55PnRoaXMub3B0aW9ucy5zbmFwKS5sb29wID0gY29lcmNlQm9vbGVhblByb3BlcnR5KHZhbCk7XG4gICAgfVxuICAgIEBJbnB1dCgpXG4gICAgc2V0IHNwZWVkKHZhbDogYW55KSB7XG4gICAgICAgICg8YW55PnRoaXMub3B0aW9ucy5zbmFwKS5zcGVlZCA9IGNvZXJjZU51bWJlclByb3BlcnR5KHZhbCk7XG4gICAgfVxuICAgIC8vIMOowofCqsOlworCqMOowr3CrsOmwpLCrVxuICAgIF9hdXRvUGxheTogYm9vbGVhbiA9IHRydWU7XG4gICAgQElucHV0KClcbiAgICBzZXQgYXV0b1BsYXkodmFsOiBhbnkpIHtcbiAgICAgICAgdGhpcy5fYXV0b1BsYXkgPSBjb2VyY2VCb29sZWFuUHJvcGVydHkodmFsKTtcbiAgICB9XG5cbiAgICBfaW50ZXJ2YWw6IG51bWJlciA9IDQwMDA7XG4gICAgQElucHV0KClcbiAgICBzZXQgaW50ZXJ2YWwodmFsOiBhbnkpIHtcbiAgICAgICAgdGhpcy5faW50ZXJ2YWwgPSBjb2VyY2VOdW1iZXJQcm9wZXJ0eSh2YWwpO1xuICAgIH1cblxuICAgIEBPdXRwdXQoKVxuICAgIG5nU2xpZGU6IEV2ZW50RW1pdHRlcjxudW1iZXI+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBpbmplY3RvcjogSW5qZWN0b3IsXG4gICAgICAgIHB1YmxpYyBlbGU6IEVsZW1lbnRSZWYsXG4gICAgICAgIHB1YmxpYyByZW5kZXI6IFJlbmRlcmVyMixcbiAgICAgICAgcHVibGljIGJldHRlcjogQmV0dGVyTWFuYWdlclNlcnZpY2VcbiAgICApIHtcbiAgICAgICAgc3VwZXIoZWxlLCBpbmplY3RvciwgYmV0dGVyKTtcbiAgICAgICAgdGhpcy5vcHRpb25zLnNjcm9sbFggPSB0cnVlO1xuICAgICAgICB0aGlzLm9wdGlvbnMuc2Nyb2xsWSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnNuYXAgPSB7fSBhcyBhbnk7XG4gICAgICAgIHRoaXMuY2xpY2sgPSB0cnVlO1xuICAgICAgICB0aGlzLmF1dG9QbGF5ID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zZXRTdHlsZUlucHV0cyhbJ2hlaWdodCddKTtcbiAgICAgICAgdGhpcy5nZXRDeWMoJ2JldHRlclNjcm9sbEluaXRlZCcpLnN1YnNjcmliZShyZXMgPT4ge1xuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsLmF1dG9QbGF5KHtcbiAgICAgICAgICAgICAgICBpbnRlcnZhbDogdGhpcy5faW50ZXJ2YWwsXG4gICAgICAgICAgICAgICAgYXV0b1BsYXk6IHRoaXMuX2F1dG9QbGF5XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHRoaXMuc3R5bGVPYmogPSB7XG4gICAgICAgICAgICAgICAgaGVpZ2h0OiB0aGlzLmhlaWdodFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGNvbnN0IHNjcm9sbEVuZDogYW55ID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMub25TY3JvbGxFbmQoKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLl9zY3JvbGwub24oJ3Njcm9sbEVuZCcsIHNjcm9sbEVuZCk7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVN0eWxlKHRoaXMuZWxlLm5hdGl2ZUVsZW1lbnQpO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBjdXJyZW50UGFnZUluZGV4OiBudW1iZXIgPSAwO1xuXG4gICAgb25TY3JvbGxFbmQoKSB7XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuc2Nyb2xsWCkge1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50UGFnZUluZGV4ID0gdGhpcy5fc2Nyb2xsLmdldFBhZ2VYKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRQYWdlSW5kZXggPSB0aGlzLl9zY3JvbGwuZ2V0UGFnZVkoKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5nU2xpZGUuZW1pdCh0aGlzLmN1cnJlbnRQYWdlSW5kZXgpO1xuICAgICAgICBpZiAodGhpcy5fYXV0b1BsYXkpIHtcbiAgICAgICAgICAgIHRoaXMuX3Njcm9sbC5wbGF5KCk7XG4gICAgICAgIH1cbiAgICB9XG5cbn1cblxuIiwiaW1wb3J0IHsgQmV0dGVyQ29yZU1vZHVsZSB9IGZyb20gJ2l3ZTctYmV0dGVyLXNjcm9sbCc7XG5pbXBvcnQgeyBTd2lwZXJJbWFnZURpcmVjdGl2ZSB9IGZyb20gJy4vc3dpcGVyLWRpcmVjdGl2ZS9zd2lwZXItaW1hZ2UnO1xuaW1wb3J0IHsgU3dpcGVyRG90c0RpcmVjdGl2ZSwgU3dpcGVyRG90RGlyZWN0aXZlIH0gZnJvbSAnLi9zd2lwZXItZGlyZWN0aXZlL3N3aXBlci1kb3RzJztcbmltcG9ydCB7IFN3aXBlckl0ZW1EaXJlY3RpdmUgfSBmcm9tICcuL3N3aXBlci1kaXJlY3RpdmUvc3dpcGVyLWl0ZW0nO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTd2lwZXJPdXRsZXRDb21wb25lbnQgfSBmcm9tICcuL3N3aXBlci1vdXRsZXQvc3dpcGVyLW91dGxldCc7XG5leHBvcnQgY29uc3QgU3dpcGVyQ29tcG9uZW50cyA9IFtcbiAgU3dpcGVyT3V0bGV0Q29tcG9uZW50XG5dO1xuXG5leHBvcnQgY29uc3QgU3dpcGVyRGV2aWNlcyA9IFtcbiAgU3dpcGVySXRlbURpcmVjdGl2ZSxcbiAgU3dpcGVySW1hZ2VEaXJlY3RpdmUsXG4gIFN3aXBlckRvdHNEaXJlY3RpdmUsXG4gIFN3aXBlckRvdERpcmVjdGl2ZVxuXTtcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW1xuICAgIENvbW1vbk1vZHVsZSxcbiAgICBCZXR0ZXJDb3JlTW9kdWxlXG4gIF0sXG4gIGRlY2xhcmF0aW9uczogW1xuICAgIC4uLlN3aXBlckNvbXBvbmVudHMsXG4gICAgLi4uU3dpcGVyRGV2aWNlc1xuICBdLFxuICBleHBvcnRzOiBbXG4gICAgLi4uU3dpcGVyQ29tcG9uZW50cyxcbiAgICAuLi5Td2lwZXJEZXZpY2VzXG4gIF1cbn0pXG5leHBvcnQgY2xhc3MgSXdlN1N3aXBlck1vZHVsZSB7IH1cbiJdLCJuYW1lcyI6WyJ0c2xpYl8xLl9fZXh0ZW5kcyIsIkNvbXBvbmVudCIsIlJlbmRlcmVyMiIsIkVsZW1lbnRSZWYiLCJJbmplY3RvciIsIklucHV0IiwiVmlld0NoaWxkIiwiSXdlN0NvcmVDb21wb25lbnQiLCJCZWhhdmlvclN1YmplY3QiLCJtYXAiLCJDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSIsIkNoYW5nZURldGVjdG9yUmVmIiwiTmdab25lIiwiSG9zdEJpbmRpbmciLCJEaXJlY3RpdmUiLCJFdmVudEVtaXR0ZXIiLCJjb2VyY2VCb29sZWFuUHJvcGVydHkiLCJjb2VyY2VOdW1iZXJQcm9wZXJ0eSIsIlZpZXdFbmNhcHN1bGF0aW9uIiwiSXdlN0ljc3NTZXJ2aWNlIiwiQmV0dGVyTWFuYWdlclNlcnZpY2UiLCJPdXRwdXQiLCJCZXR0ZXJTY3JvbGxEaXJlY3RpdmUiLCJOZ01vZHVsZSIsIkNvbW1vbk1vZHVsZSIsIkJldHRlckNvcmVNb2R1bGUiXSwibWFwcGluZ3MiOiI7Ozs7OztJQUFBOzs7Ozs7Ozs7Ozs7OztJQWNBO0lBRUEsSUFBSSxhQUFhLEdBQUcsTUFBTSxDQUFDLGNBQWM7U0FDcEMsRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFlBQVksS0FBSyxJQUFJLFVBQVUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDNUUsVUFBVSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQztZQUFFLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7Z0JBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFFL0UsdUJBQTBCLENBQUMsRUFBRSxDQUFDO1FBQzFCLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDcEIsZ0JBQWdCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEVBQUU7UUFDdkMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLEtBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztJQUN6RixDQUFDO0FBRUQsb0JBcUZ1QixDQUFDLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsR0FBRyxPQUFPLE1BQU0sS0FBSyxVQUFVLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsQ0FBQztZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ2pDLElBQUk7WUFDQSxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJO2dCQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzlFO1FBQ0QsT0FBTyxLQUFLLEVBQUU7WUFBRSxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUM7U0FBRTtnQkFDL0I7WUFDSixJQUFJO2dCQUNBLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDcEQ7b0JBQ087Z0JBQUUsSUFBSSxDQUFDO29CQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQzthQUFFO1NBQ3BDO1FBQ0QsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0FBRUQ7UUFDSSxLQUFLLElBQUksRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtZQUM5QyxFQUFFLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN6QyxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7Ozs7Ozs7UUN2SHlDQSx3Q0FBaUI7UUFHdkQsOEJBQ1csUUFDQSxLQUNBO1lBSFgsWUFLSSxrQkFBTSxRQUFRLENBQUMsU0FJbEI7WUFSVSxZQUFNLEdBQU4sTUFBTTtZQUNOLFNBQUcsR0FBSCxHQUFHO1lBQ0gsY0FBUSxHQUFSLFFBQVE7WUFHZixLQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLEdBQUc7Z0JBQ3BDLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLGtCQUFrQixFQUFFLFNBQU8sS0FBSSxDQUFDLFdBQVcsTUFBRyxDQUFDLENBQUM7YUFDbEcsQ0FBQyxDQUFDOztTQUNOOztvQkFwQkpDLGNBQVMsU0FBQzt3QkFDUCxRQUFRLEVBQUUsZUFBZTt3QkFDekIsUUFBUSxFQUFFLDRHQUlUO3FCQUNKOzs7Ozt3QkFYcUJDLGNBQVM7d0JBQUVDLGVBQVU7d0JBQUVDLGFBQVE7Ozs7a0NBYWhEQyxVQUFLOzRCQUNMQyxjQUFTLFNBQUMsT0FBTzs7bUNBZnRCO01BYTBDQywwQkFBaUI7Ozs7OztBQ2IzRDtRQW1DSSw2QkFBbUIsRUFBcUIsRUFBUyxNQUFjO1lBQTVDLE9BQUUsR0FBRixFQUFFLENBQW1CO1lBQVMsV0FBTSxHQUFOLE1BQU0sQ0FBUTt5QkFwQm5CLElBQUk7Z0NBQ1IsSUFBSUMsb0JBQWUsQ0FBQyxDQUFDLENBQUM7U0FtQk07UUFqQnBFLHNCQUNJLHVDQUFNOzs7O2dCQURWLFVBQ1csR0FBMEI7Z0JBRHJDLGlCQWVDO2dCQWJHLEdBQUcsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDekMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsVUFBQSxHQUFHO29CQUMzQixLQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDO2lCQUMxQixDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUM3Q0MsYUFBRyxDQUFDO29CQUNBLHFCQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2pCLEtBQUsscUJBQUksR0FBRyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLEVBQUU7d0JBQ2hELEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ25CO29CQUNELE9BQU8sS0FBSyxDQUFDO2lCQUNoQixDQUFDLENBQ0wsQ0FBQzthQUNMOzs7V0FBQTs7b0JBNUJKUixjQUFTLFNBQUM7d0JBQ1AsUUFBUSxFQUFFLGNBQWM7d0JBQ3hCLFFBQVEsRUFBRSx3SUFJVDt3QkFDRCxlQUFlLEVBQUVTLDRCQUF1QixDQUFDLE1BQU07cUJBQ2xEOzs7Ozt3QkFWdUNDLHNCQUFpQjt3QkFBRUMsV0FBTTs7Ozs0QkFZNURDLGdCQUFXLFNBQUMsWUFBWTsyQkFFeEJSLFVBQUs7NkJBQ0xBLFVBQUs7O2tDQWxCVjs7O1FBNENJLDRCQUFtQixJQUF5QixFQUFTLE1BQWlCLEVBQVMsR0FBZTtZQUEzRSxTQUFJLEdBQUosSUFBSSxDQUFxQjtZQUFTLFdBQU0sR0FBTixNQUFNLENBQVc7WUFBUyxRQUFHLEdBQUgsR0FBRyxDQUFZO3VCQUZyRCxJQUFJO1NBRXFEOzs7O1FBRWxHLHFDQUFROzs7WUFBUjtnQkFBQSxpQkFRQztnQkFQRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsVUFBQSxHQUFHO29CQUNoQyxJQUFJLEdBQUcsS0FBSyxLQUFJLENBQUMsU0FBUyxFQUFFO3dCQUN4QixLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQztxQkFDMUQ7eUJBQU07d0JBQ0gsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7cUJBQzdEO2lCQUNKLENBQUMsQ0FBQzthQUNOOztvQkFkSlMsY0FBUyxTQUFDLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRTs7Ozs7d0JBSVQsbUJBQW1CO3dCQXpDNENaLGNBQVM7d0JBSDVGQyxlQUFVOzs7OzBCQTBDZFUsZ0JBQVcsU0FBQyxXQUFXO2dDQUN2QlIsVUFBSzs7aUNBM0NWOzs7Ozs7O0FDQUE7O3dCQUlzRCxJQUFJOzs7b0JBRnpEUyxjQUFTLFNBQUMsRUFBRSxRQUFRLEVBQUUsY0FBYyxFQUFFOzs7MkJBRWxDRCxnQkFBVyxTQUFDLG1CQUFtQjs7a0NBSnBDOzs7Ozs7OztRQ3lCMkNiLHlDQUFxQjtRQThCNUQsK0JBQ0ksUUFBa0IsRUFDWCxLQUNBLFFBQ0E7WUFKWCxZQU1JLGtCQUFNLEdBQUcsRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLFNBcUIvQjtZQXpCVSxTQUFHLEdBQUgsR0FBRztZQUNILFlBQU0sR0FBTixNQUFNO1lBQ04sWUFBTSxHQUFOLE1BQU07MkJBakNDLE1BQU07NEJBQ0wsSUFBSTs7OEJBY0YsSUFBSTs4QkFNTCxJQUFJOzRCQU9RLElBQUllLGlCQUFZLEVBQUU7cUNBOEJ2QixDQUFDO1lBdEJ4QixLQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDNUIsS0FBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQzdCLEtBQUksQ0FBQyxJQUFJLHFCQUFHLEVBQVMsQ0FBQSxDQUFDO1lBQ3RCLEtBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1lBQ2xCLEtBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ3JCLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLEtBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxHQUFHO2dCQUMzQyxLQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztvQkFDbEIsUUFBUSxFQUFFLEtBQUksQ0FBQyxTQUFTO29CQUN4QixRQUFRLEVBQUUsS0FBSSxDQUFDLFNBQVM7aUJBQzNCLENBQUMsQ0FBQztnQkFDSCxLQUFJLENBQUMsUUFBUSxHQUFHO29CQUNaLE1BQU0sRUFBRSxLQUFJLENBQUMsTUFBTTtpQkFDdEIsQ0FBQztnQkFDRixxQkFBTSxTQUFTLEdBQVE7b0JBQ25CLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztpQkFDdEIsQ0FBQztnQkFDRixLQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3hDLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQzthQUM1QyxDQUFDLENBQUM7O1NBQ047UUF0REQsc0JBQ0kseUNBQU07Ozs7Z0JBRFYsVUFDVyxHQUFRO2dCQUNmLElBQUksQ0FBQyxPQUFPLEdBQUdDLDhCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzdDOzs7V0FBQTtRQUNELHNCQUNJLHVDQUFJOzs7O2dCQURSLFVBQ1MsR0FBUTtnQkFDYixFQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFFLElBQUksR0FBR0EsOEJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDOUQ7OztXQUFBO1FBQ0Qsc0JBQ0ksd0NBQUs7Ozs7Z0JBRFQsVUFDVSxHQUFRO2dCQUNkLEVBQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUUsS0FBSyxHQUFHQyw2QkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM5RDs7O1dBQUE7UUFHRCxzQkFDSSwyQ0FBUTs7OztnQkFEWixVQUNhLEdBQVE7Z0JBQ2pCLElBQUksQ0FBQyxTQUFTLEdBQUdELDhCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9DOzs7V0FBQTtRQUdELHNCQUNJLDJDQUFROzs7O2dCQURaLFVBQ2EsR0FBUTtnQkFDakIsSUFBSSxDQUFDLFNBQVMsR0FBR0MsNkJBQW9CLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDOUM7OztXQUFBOzs7O1FBbUNELDJDQUFXOzs7WUFBWDtnQkFDSSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFO29CQUN0QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztpQkFDbkQ7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7aUJBQ25EO2dCQUNELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUN6QyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7b0JBQ2hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7aUJBQ3ZCO2FBQ0o7O29CQXZGSmhCLGNBQVMsU0FBQzt3QkFDUCxRQUFRLEVBQUUsZUFBZTt3QkFDekIsUUFBUSxFQUFFLDZCQUNiO3dCQUNHLE1BQU0sRUFBRSxDQUFDLGd6Q0FBZ3pDLENBQUM7d0JBQzF6QyxlQUFlLEVBQUVTLDRCQUF1QixDQUFDLE1BQU07d0JBQy9DLGFBQWEsRUFBRVEsc0JBQWlCLENBQUMsSUFBSTt3QkFDckMsSUFBSSxFQUFFOzRCQUNGLGtCQUFrQixFQUFFLFNBQVM7NEJBQzdCLGtCQUFrQixFQUFFLFNBQVM7NEJBQzdCLGdCQUFnQixFQUFFLFFBQVE7eUJBQzdCO3dCQUNELE1BQU0sRUFBRSxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQzt3QkFDbEQsU0FBUyxFQUFFLENBQUNDLHdCQUFlLENBQUM7d0JBQzVCLFFBQVEsRUFBRSxjQUFjO3FCQUMzQjs7Ozs7d0JBcEJjZixhQUFRO3dCQUZkRCxlQUFVO3dCQUFFRCxjQUFTO3dCQUZyQmtCLHFDQUFvQjs7Ozs2QkEwQnhCZixVQUFLOzZCQUVMQSxVQUFLOzJCQUlMQSxVQUFLOzRCQUlMQSxVQUFLOytCQU1MQSxVQUFLOytCQU1MQSxVQUFLOzhCQUtMZ0IsV0FBTTs7b0NBckRYO01BeUIyQ0Msc0NBQXFCOzs7Ozs7eUJDbEJuRCxnQkFBZ0IsR0FBRztRQUM5QixxQkFBcUI7S0FDdEIsQ0FBQztBQUVGLHlCQUFhLGFBQWEsR0FBRztRQUMzQixtQkFBbUI7UUFDbkIsb0JBQW9CO1FBQ3BCLG1CQUFtQjtRQUNuQixrQkFBa0I7S0FDbkIsQ0FBQzs7Ozs7b0JBRURDLGFBQVEsU0FBQzt3QkFDUixPQUFPLEVBQUU7NEJBQ1BDLG1CQUFZOzRCQUNaQyxpQ0FBZ0I7eUJBQ2pCO3dCQUNELFlBQVksV0FDUCxnQkFBZ0IsRUFDaEIsYUFBYSxDQUNqQjt3QkFDRCxPQUFPLFdBQ0YsZ0JBQWdCLEVBQ2hCLGFBQWEsQ0FDakI7cUJBQ0Y7OytCQS9CRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OyJ9