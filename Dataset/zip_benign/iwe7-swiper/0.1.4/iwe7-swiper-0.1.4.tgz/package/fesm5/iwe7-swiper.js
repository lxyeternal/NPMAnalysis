import { __extends, __spread } from 'tslib';
import { Renderer2, ElementRef, Injector, Component, ViewChild, Input, ChangeDetectionStrategy, ViewEncapsulation, Output, EventEmitter, HostBinding, ChangeDetectorRef, NgZone, Directive, NgModule } from '@angular/core';
import { Iwe7CoreComponent } from 'iwe7-core';
import { BetterManagerService, BetterScrollDirective, BetterCoreModule } from 'iwe7-better-scroll';
import { Iwe7IcssService } from 'iwe7-icss';
import { coerceBooleanProperty, coerceNumberProperty } from '@angular/cdk/coercion';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SwiperImageDirective = /** @class */ (function (_super) {
    __extends(SwiperImageDirective, _super);
    function SwiperImageDirective(render, ele, injector) {
        var _this = _super.call(this, injector) || this;
        _this.render = render;
        _this.ele = ele;
        _this.injector = injector;
        _this.getCyc('ngOnChanges').subscribe(function (res) {
            _this.render.setStyle(_this.image.nativeElement, 'background-image', "url(" + _this.swiperImage + ")");
        });
        return _this;
    }
    SwiperImageDirective.decorators = [
        { type: Component, args: [{
                    selector: '[swiperImage]',
                    template: "\n        <div class=\"swiper-image\" #image>\n            <ng-content></ng-content>\n        </div>\n    "
                },] },
    ];
    /** @nocollapse */
    SwiperImageDirective.ctorParameters = function () { return [
        { type: Renderer2 },
        { type: ElementRef },
        { type: Injector }
    ]; };
    SwiperImageDirective.propDecorators = {
        swiperImage: [{ type: Input }],
        image: [{ type: ViewChild, args: ['image',] }]
    };
    return SwiperImageDirective;
}(Iwe7CoreComponent));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SwiperOutletComponent = /** @class */ (function (_super) {
    __extends(SwiperOutletComponent, _super);
    function SwiperOutletComponent(injector, ele, render, better) {
        var _this = _super.call(this, ele, injector, better) || this;
        _this.ele = ele;
        _this.render = render;
        _this.better = better;
        _this.height = '100%';
        _this._hasDot = true;
        // 自动轮播
        _this._autoPlay = true;
        _this._interval = 4000;
        _this.ngSlide = new EventEmitter();
        _this.currentPageIndex = 0;
        _this.options.scrollX = true;
        _this.options.scrollY = false;
        _this.snap = /** @type {?} */ ({});
        _this.click = true;
        _this.autoPlay = true;
        _this.setStyleInputs(['height']);
        _this.getCyc('betterScrollInited').subscribe(function (res) {
            _this._scroll.autoPlay({
                interval: _this._interval,
                autoPlay: _this._autoPlay
            });
            _this.styleObj = {
                height: _this.height
            };
            var /** @type {?} */ scrollEnd = function () {
                _this.onScrollEnd();
            };
            _this._scroll.on('scrollEnd', scrollEnd);
            _this.updateStyle(_this.ele.nativeElement);
        });
        return _this;
    }
    Object.defineProperty(SwiperOutletComponent.prototype, "hasDot", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            this._hasDot = coerceBooleanProperty(val);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SwiperOutletComponent.prototype, "loop", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            (/** @type {?} */ (this.options.snap)).loop = coerceBooleanProperty(val);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SwiperOutletComponent.prototype, "speed", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            (/** @type {?} */ (this.options.snap)).speed = coerceNumberProperty(val);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SwiperOutletComponent.prototype, "autoPlay", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            this._autoPlay = coerceBooleanProperty(val);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SwiperOutletComponent.prototype, "interval", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            this._interval = coerceNumberProperty(val);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    SwiperOutletComponent.prototype.onScrollEnd = /**
     * @return {?}
     */
    function () {
        if (this.options.scrollX) {
            this.currentPageIndex = this._scroll.getPageX();
        }
        else {
            this.currentPageIndex = this._scroll.getPageY();
        }
        this.ngSlide.emit(this.currentPageIndex);
        if (this._autoPlay) {
            this._scroll.play();
        }
    };
    SwiperOutletComponent.decorators = [
        { type: Component, args: [{
                    selector: 'swiper-outlet',
                    template: "<ng-content></ng-content>\n",
                    styles: ["swiper-outlet{--height:100%;min-height:1px;display:block;position:relative;height:var(--height)}swiper-outlet .slide-item{display:block;float:left;box-sizing:border-box;overflow:hidden;text-align:center;width:100%;height:var(--height);position:relative}swiper-outlet .slide-item .swiper-image{position:absolute;top:0;left:0;right:0;bottom:0;background-size:100% var(--height);background-repeat:no-repeat;zoom:1;background-position:center 0}swiper-outlet .slide-item a{display:block;width:100%;overflow:hidden;text-decoration:none}.dots{position:absolute;justify-content:center;align-items:center}.dots .dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#ccc}.dots .dot.active{border-radius:5px;background:#fff}.scroll-x .slide-item{height:100%}.scroll-x img{display:block;width:100%}.scroll-x .dots{right:0;left:0;bottom:12px;-webkit-transform:translateZ(1px);transform:translateZ(1px);text-align:center;font-size:0;display:flex;flex-direction:row}.scroll-x .dots .dot{margin:0 4px}.scroll-x .dots .dot.active{width:20px}.scroll-y img{display:block;width:100%}.scroll-y .dots{top:0;bottom:0;right:12px;-webkit-transform:translateZ(1px);transform:translateZ(1px);text-align:center;font-size:0;display:flex;flex-direction:column}.scroll-y .dots .dot{margin:4px 0}.scroll-y .dots .dot.active{height:20px}"],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class.scroll-x]': 'scrollX',
                        '[class.scroll-y]': 'scrollY',
                        '[style.height]': 'height'
                    },
                    inputs: ['interval', 'threshold', 'speed', 'list'],
                    providers: [Iwe7IcssService],
                    exportAs: 'swiperOutlet'
                },] },
    ];
    /** @nocollapse */
    SwiperOutletComponent.ctorParameters = function () { return [
        { type: Injector },
        { type: ElementRef },
        { type: Renderer2 },
        { type: BetterManagerService }
    ]; };
    SwiperOutletComponent.propDecorators = {
        height: [{ type: Input }],
        hasDot: [{ type: Input }],
        loop: [{ type: Input }],
        speed: [{ type: Input }],
        autoPlay: [{ type: Input }],
        interval: [{ type: Input }],
        ngSlide: [{ type: Output }]
    };
    return SwiperOutletComponent;
}(BetterScrollDirective));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SwiperDotsDirective = /** @class */ (function () {
    function SwiperDotsDirective(cd, ngZone) {
        this.cd = cd;
        this.ngZone = ngZone;
        this._dots = true;
        this.currentIndex = new BehaviorSubject(0);
    }
    Object.defineProperty(SwiperDotsDirective.prototype, "outlet", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            var _this = this;
            val.ngSlide.subscribe(this.currentIndex);
            this.currentIndex.subscribe(function (res) {
                _this.cd.markForCheck();
            });
            this.dots = val.getCyc('ngAfterContentInit').pipe(map(function () {
                var /** @type {?} */ items = [];
                for (var /** @type {?} */ key = 0; key < val.children.length; key++) {
                    items.push(key);
                }
                return items;
            }));
        },
        enumerable: true,
        configurable: true
    });
    SwiperDotsDirective.decorators = [
        { type: Component, args: [{
                    selector: '[swiperDots]',
                    template: "\n    <ng-container *ngFor=\"let item of dots|async;index as i;\">\n        <span [swiperDot]=\"i\"></span>\n    </ng-container>\n    ",
                    changeDetection: ChangeDetectionStrategy.OnPush
                },] },
    ];
    /** @nocollapse */
    SwiperDotsDirective.ctorParameters = function () { return [
        { type: ChangeDetectorRef },
        { type: NgZone }
    ]; };
    SwiperDotsDirective.propDecorators = {
        _dots: [{ type: HostBinding, args: ['class.dots',] }],
        dots: [{ type: Input }],
        outlet: [{ type: Input }]
    };
    return SwiperDotsDirective;
}());
var SwiperDotDirective = /** @class */ (function () {
    function SwiperDotDirective(dots, render, ele) {
        this.dots = dots;
        this.render = render;
        this.ele = ele;
        this.dot = true;
    }
    /**
     * @return {?}
     */
    SwiperDotDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.dots.currentIndex.subscribe(function (res) {
            if (res === _this.swiperDot) {
                _this.render.addClass(_this.ele.nativeElement, 'active');
            }
            else {
                _this.render.removeClass(_this.ele.nativeElement, 'active');
            }
        });
    };
    SwiperDotDirective.decorators = [
        { type: Directive, args: [{ selector: '[swiperDot]' },] },
    ];
    /** @nocollapse */
    SwiperDotDirective.ctorParameters = function () { return [
        { type: SwiperDotsDirective },
        { type: Renderer2 },
        { type: ElementRef }
    ]; };
    SwiperDotDirective.propDecorators = {
        dot: [{ type: HostBinding, args: ['class.dot',] }],
        swiperDot: [{ type: Input }]
    };
    return SwiperDotDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SwiperItemDirective = /** @class */ (function () {
    function SwiperItemDirective() {
        this.item = true;
    }
    SwiperItemDirective.decorators = [
        { type: Directive, args: [{ selector: '[swiperItem]' },] },
    ];
    SwiperItemDirective.propDecorators = {
        item: [{ type: HostBinding, args: ['class.swiper-item',] }]
    };
    return SwiperItemDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var /** @type {?} */ SwiperComponents = [
    SwiperOutletComponent
];
var /** @type {?} */ SwiperDevices = [
    SwiperItemDirective,
    SwiperImageDirective,
    SwiperDotsDirective,
    SwiperDotDirective
];
var Iwe7SwiperModule = /** @class */ (function () {
    function Iwe7SwiperModule() {
    }
    Iwe7SwiperModule.decorators = [
        { type: NgModule, args: [{
                    imports: [
                        CommonModule,
                        BetterCoreModule
                    ],
                    declarations: __spread(SwiperComponents, SwiperDevices),
                    exports: __spread(SwiperComponents, SwiperDevices)
                },] },
    ];
    return Iwe7SwiperModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

export { SwiperComponents, SwiperDevices, Iwe7SwiperModule, SwiperDotDirective as ɵe, SwiperDotsDirective as ɵd, SwiperImageDirective as ɵc, SwiperItemDirective as ɵb, SwiperOutletComponent as ɵa };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXdlNy1zd2lwZXIuanMubWFwIiwic291cmNlcyI6WyJuZzovL2l3ZTctc3dpcGVyL2xpYi9zd2lwZXItZGlyZWN0aXZlL3N3aXBlci1pbWFnZS50cyIsIm5nOi8vaXdlNy1zd2lwZXIvbGliL3N3aXBlci1vdXRsZXQvc3dpcGVyLW91dGxldC50cyIsIm5nOi8vaXdlNy1zd2lwZXIvbGliL3N3aXBlci1kaXJlY3RpdmUvc3dpcGVyLWRvdHMudHMiLCJuZzovL2l3ZTctc3dpcGVyL2xpYi9zd2lwZXItZGlyZWN0aXZlL3N3aXBlci1pdGVtLnRzIiwibmc6Ly9pd2U3LXN3aXBlci9saWIvaXdlNy1zd2lwZXIubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERvbVNhbml0aXplciB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgSG9zdEJpbmRpbmcsIFJlbmRlcmVyMiwgRWxlbWVudFJlZiwgSW5qZWN0b3IsIENvbXBvbmVudCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEaXJlY3RpdmUsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJd2U3Q29yZUNvbXBvbmVudCB9IGZyb20gJ2l3ZTctY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICAgIHNlbGVjdG9yOiAnW3N3aXBlckltYWdlXScsXG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInN3aXBlci1pbWFnZVwiICNpbWFnZT5cbiAgICAgICAgICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbiAgICAgICAgPC9kaXY+XG4gICAgYFxufSlcbmV4cG9ydCBjbGFzcyBTd2lwZXJJbWFnZURpcmVjdGl2ZSBleHRlbmRzIEl3ZTdDb3JlQ29tcG9uZW50IHtcbiAgICBASW5wdXQoKSBzd2lwZXJJbWFnZTogc3RyaW5nO1xuICAgIEBWaWV3Q2hpbGQoJ2ltYWdlJykgaW1hZ2U6IEVsZW1lbnRSZWY7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIHB1YmxpYyByZW5kZXI6IFJlbmRlcmVyMixcbiAgICAgICAgcHVibGljIGVsZTogRWxlbWVudFJlZixcbiAgICAgICAgcHVibGljIGluamVjdG9yOiBJbmplY3RvclxuICAgICkge1xuICAgICAgICBzdXBlcihpbmplY3Rvcik7XG4gICAgICAgIHRoaXMuZ2V0Q3ljKCduZ09uQ2hhbmdlcycpLnN1YnNjcmliZShyZXMgPT4ge1xuICAgICAgICAgICAgdGhpcy5yZW5kZXIuc2V0U3R5bGUodGhpcy5pbWFnZS5uYXRpdmVFbGVtZW50LCAnYmFja2dyb3VuZC1pbWFnZScsIGB1cmwoJHt0aGlzLnN3aXBlckltYWdlfSlgKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQmV0dGVyTWFuYWdlclNlcnZpY2UsIEJldHRlclNjcm9sbERpcmVjdGl2ZSB9IGZyb20gJ2l3ZTctYmV0dGVyLXNjcm9sbCc7XG5pbXBvcnQgeyBJd2U3SWNzc1NlcnZpY2UgfSBmcm9tICdpd2U3LWljc3MnO1xuaW1wb3J0IHsgRWxlbWVudFJlZiwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICAgIENvbXBvbmVudCwgSW5qZWN0b3IsXG4gICAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIFZpZXdFbmNhcHN1bGF0aW9uLFxuICAgIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSwgY29lcmNlTnVtYmVyUHJvcGVydHkgfSBmcm9tICdAYW5ndWxhci9jZGsvY29lcmNpb24nO1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdzd2lwZXItb3V0bGV0JyxcbiAgICB0ZW1wbGF0ZTogYDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbmAsXG4gICAgc3R5bGVzOiBbYHN3aXBlci1vdXRsZXR7LS1oZWlnaHQ6MTAwJTttaW4taGVpZ2h0OjFweDtkaXNwbGF5OmJsb2NrO3Bvc2l0aW9uOnJlbGF0aXZlO2hlaWdodDp2YXIoLS1oZWlnaHQpfXN3aXBlci1vdXRsZXQgLnNsaWRlLWl0ZW17ZGlzcGxheTpibG9jaztmbG9hdDpsZWZ0O2JveC1zaXppbmc6Ym9yZGVyLWJveDtvdmVyZmxvdzpoaWRkZW47dGV4dC1hbGlnbjpjZW50ZXI7d2lkdGg6MTAwJTtoZWlnaHQ6dmFyKC0taGVpZ2h0KTtwb3NpdGlvbjpyZWxhdGl2ZX1zd2lwZXItb3V0bGV0IC5zbGlkZS1pdGVtIC5zd2lwZXItaW1hZ2V7cG9zaXRpb246YWJzb2x1dGU7dG9wOjA7bGVmdDowO3JpZ2h0OjA7Ym90dG9tOjA7YmFja2dyb3VuZC1zaXplOjEwMCUgdmFyKC0taGVpZ2h0KTtiYWNrZ3JvdW5kLXJlcGVhdDpuby1yZXBlYXQ7em9vbToxO2JhY2tncm91bmQtcG9zaXRpb246Y2VudGVyIDB9c3dpcGVyLW91dGxldCAuc2xpZGUtaXRlbSBhe2Rpc3BsYXk6YmxvY2s7d2lkdGg6MTAwJTtvdmVyZmxvdzpoaWRkZW47dGV4dC1kZWNvcmF0aW9uOm5vbmV9LmRvdHN7cG9zaXRpb246YWJzb2x1dGU7anVzdGlmeS1jb250ZW50OmNlbnRlcjthbGlnbi1pdGVtczpjZW50ZXJ9LmRvdHMgLmRvdHtkaXNwbGF5OmlubGluZS1ibG9jazt3aWR0aDo4cHg7aGVpZ2h0OjhweDtib3JkZXItcmFkaXVzOjUwJTtiYWNrZ3JvdW5kOiNjY2N9LmRvdHMgLmRvdC5hY3RpdmV7Ym9yZGVyLXJhZGl1czo1cHg7YmFja2dyb3VuZDojZmZmfS5zY3JvbGwteCAuc2xpZGUtaXRlbXtoZWlnaHQ6MTAwJX0uc2Nyb2xsLXggaW1ne2Rpc3BsYXk6YmxvY2s7d2lkdGg6MTAwJX0uc2Nyb2xsLXggLmRvdHN7cmlnaHQ6MDtsZWZ0OjA7Ym90dG9tOjEycHg7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWigxcHgpO3RyYW5zZm9ybTp0cmFuc2xhdGVaKDFweCk7dGV4dC1hbGlnbjpjZW50ZXI7Zm9udC1zaXplOjA7ZGlzcGxheTpmbGV4O2ZsZXgtZGlyZWN0aW9uOnJvd30uc2Nyb2xsLXggLmRvdHMgLmRvdHttYXJnaW46MCA0cHh9LnNjcm9sbC14IC5kb3RzIC5kb3QuYWN0aXZle3dpZHRoOjIwcHh9LnNjcm9sbC15IGltZ3tkaXNwbGF5OmJsb2NrO3dpZHRoOjEwMCV9LnNjcm9sbC15IC5kb3Rze3RvcDowO2JvdHRvbTowO3JpZ2h0OjEycHg7LXdlYmtpdC10cmFuc2Zvcm06dHJhbnNsYXRlWigxcHgpO3RyYW5zZm9ybTp0cmFuc2xhdGVaKDFweCk7dGV4dC1hbGlnbjpjZW50ZXI7Zm9udC1zaXplOjA7ZGlzcGxheTpmbGV4O2ZsZXgtZGlyZWN0aW9uOmNvbHVtbn0uc2Nyb2xsLXkgLmRvdHMgLmRvdHttYXJnaW46NHB4IDB9LnNjcm9sbC15IC5kb3RzIC5kb3QuYWN0aXZle2hlaWdodDoyMHB4fWBdLFxuICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG4gICAgaG9zdDoge1xuICAgICAgICAnW2NsYXNzLnNjcm9sbC14XSc6ICdzY3JvbGxYJyxcbiAgICAgICAgJ1tjbGFzcy5zY3JvbGwteV0nOiAnc2Nyb2xsWScsXG4gICAgICAgICdbc3R5bGUuaGVpZ2h0XSc6ICdoZWlnaHQnXG4gICAgfSxcbiAgICBpbnB1dHM6IFsnaW50ZXJ2YWwnLCAndGhyZXNob2xkJywgJ3NwZWVkJywgJ2xpc3QnXSxcbiAgICBwcm92aWRlcnM6IFtJd2U3SWNzc1NlcnZpY2VdLFxuICAgIGV4cG9ydEFzOiAnc3dpcGVyT3V0bGV0J1xufSlcbmV4cG9ydCBjbGFzcyBTd2lwZXJPdXRsZXRDb21wb25lbnQgZXh0ZW5kcyBCZXR0ZXJTY3JvbGxEaXJlY3RpdmUge1xuICAgIEBJbnB1dCgpIGhlaWdodCA9ICcxMDAlJztcbiAgICBfaGFzRG90OiBib29sZWFuID0gdHJ1ZTtcbiAgICBASW5wdXQoKVxuICAgIHNldCBoYXNEb3QodmFsOiBhbnkpIHtcbiAgICAgICAgdGhpcy5faGFzRG90ID0gY29lcmNlQm9vbGVhblByb3BlcnR5KHZhbCk7XG4gICAgfVxuICAgIEBJbnB1dCgpXG4gICAgc2V0IGxvb3AodmFsOiBhbnkpIHtcbiAgICAgICAgKDxhbnk+dGhpcy5vcHRpb25zLnNuYXApLmxvb3AgPSBjb2VyY2VCb29sZWFuUHJvcGVydHkodmFsKTtcbiAgICB9XG4gICAgQElucHV0KClcbiAgICBzZXQgc3BlZWQodmFsOiBhbnkpIHtcbiAgICAgICAgKDxhbnk+dGhpcy5vcHRpb25zLnNuYXApLnNwZWVkID0gY29lcmNlTnVtYmVyUHJvcGVydHkodmFsKTtcbiAgICB9XG4gICAgLy8gw6jCh8Kqw6XCisKow6jCvcKuw6bCksKtXG4gICAgX2F1dG9QbGF5OiBib29sZWFuID0gdHJ1ZTtcbiAgICBASW5wdXQoKVxuICAgIHNldCBhdXRvUGxheSh2YWw6IGFueSkge1xuICAgICAgICB0aGlzLl9hdXRvUGxheSA9IGNvZXJjZUJvb2xlYW5Qcm9wZXJ0eSh2YWwpO1xuICAgIH1cblxuICAgIF9pbnRlcnZhbDogbnVtYmVyID0gNDAwMDtcbiAgICBASW5wdXQoKVxuICAgIHNldCBpbnRlcnZhbCh2YWw6IGFueSkge1xuICAgICAgICB0aGlzLl9pbnRlcnZhbCA9IGNvZXJjZU51bWJlclByb3BlcnR5KHZhbCk7XG4gICAgfVxuXG4gICAgQE91dHB1dCgpXG4gICAgbmdTbGlkZTogRXZlbnRFbWl0dGVyPG51bWJlcj4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgY29uc3RydWN0b3IoXG4gICAgICAgIGluamVjdG9yOiBJbmplY3RvcixcbiAgICAgICAgcHVibGljIGVsZTogRWxlbWVudFJlZixcbiAgICAgICAgcHVibGljIHJlbmRlcjogUmVuZGVyZXIyLFxuICAgICAgICBwdWJsaWMgYmV0dGVyOiBCZXR0ZXJNYW5hZ2VyU2VydmljZVxuICAgICkge1xuICAgICAgICBzdXBlcihlbGUsIGluamVjdG9yLCBiZXR0ZXIpO1xuICAgICAgICB0aGlzLm9wdGlvbnMuc2Nyb2xsWCA9IHRydWU7XG4gICAgICAgIHRoaXMub3B0aW9ucy5zY3JvbGxZID0gZmFsc2U7XG4gICAgICAgIHRoaXMuc25hcCA9IHt9IGFzIGFueTtcbiAgICAgICAgdGhpcy5jbGljayA9IHRydWU7XG4gICAgICAgIHRoaXMuYXV0b1BsYXkgPSB0cnVlO1xuICAgICAgICB0aGlzLnNldFN0eWxlSW5wdXRzKFsnaGVpZ2h0J10pO1xuICAgICAgICB0aGlzLmdldEN5YygnYmV0dGVyU2Nyb2xsSW5pdGVkJykuc3Vic2NyaWJlKHJlcyA9PiB7XG4gICAgICAgICAgICB0aGlzLl9zY3JvbGwuYXV0b1BsYXkoe1xuICAgICAgICAgICAgICAgIGludGVydmFsOiB0aGlzLl9pbnRlcnZhbCxcbiAgICAgICAgICAgICAgICBhdXRvUGxheTogdGhpcy5fYXV0b1BsYXlcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5zdHlsZU9iaiA9IHtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IHRoaXMuaGVpZ2h0XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgY29uc3Qgc2Nyb2xsRW5kOiBhbnkgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5vblNjcm9sbEVuZCgpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuX3Njcm9sbC5vbignc2Nyb2xsRW5kJywgc2Nyb2xsRW5kKTtcbiAgICAgICAgICAgIHRoaXMudXBkYXRlU3R5bGUodGhpcy5lbGUubmF0aXZlRWxlbWVudCk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGN1cnJlbnRQYWdlSW5kZXg6IG51bWJlciA9IDA7XG5cbiAgICBvblNjcm9sbEVuZCgpIHtcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5zY3JvbGxYKSB7XG4gICAgICAgICAgICB0aGlzLmN1cnJlbnRQYWdlSW5kZXggPSB0aGlzLl9zY3JvbGwuZ2V0UGFnZVgoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuY3VycmVudFBhZ2VJbmRleCA9IHRoaXMuX3Njcm9sbC5nZXRQYWdlWSgpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubmdTbGlkZS5lbWl0KHRoaXMuY3VycmVudFBhZ2VJbmRleCk7XG4gICAgICAgIGlmICh0aGlzLl9hdXRvUGxheSkge1xuICAgICAgICAgICAgdGhpcy5fc2Nyb2xsLnBsYXkoKTtcbiAgICAgICAgfVxuICAgIH1cblxufVxuXG4iLCJpbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBCZWhhdmlvclN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IENvbXBvbmVudCwgSG9zdEJpbmRpbmcsIElucHV0LCBDaGFuZ2VEZXRlY3RvclJlZiwgTmdab25lLCBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTd2lwZXJPdXRsZXRDb21wb25lbnQgfSBmcm9tICcuLi9zd2lwZXItb3V0bGV0L3N3aXBlci1vdXRsZXQnO1xuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdbc3dpcGVyRG90c10nLFxuICAgIHRlbXBsYXRlOiBgXG4gICAgPG5nLWNvbnRhaW5lciAqbmdGb3I9XCJsZXQgaXRlbSBvZiBkb3RzfGFzeW5jO2luZGV4IGFzIGk7XCI+XG4gICAgICAgIDxzcGFuIFtzd2lwZXJEb3RdPVwiaVwiPjwvc3Bhbj5cbiAgICA8L25nLWNvbnRhaW5lcj5cbiAgICBgLFxuICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoXG59KVxuZXhwb3J0IGNsYXNzIFN3aXBlckRvdHNEaXJlY3RpdmUge1xuICAgIEBIb3N0QmluZGluZygnY2xhc3MuZG90cycpIF9kb3RzOiBib29sZWFuID0gdHJ1ZTtcbiAgICBjdXJyZW50SW5kZXg6IEJlaGF2aW9yU3ViamVjdDxudW1iZXI+ID0gbmV3IEJlaGF2aW9yU3ViamVjdCgwKTtcbiAgICBASW5wdXQoKSBkb3RzOiBPYnNlcnZhYmxlPGFueVtdPjtcbiAgICBASW5wdXQoKVxuICAgIHNldCBvdXRsZXQodmFsOiBTd2lwZXJPdXRsZXRDb21wb25lbnQpIHtcbiAgICAgICAgdmFsLm5nU2xpZGUuc3Vic2NyaWJlKHRoaXMuY3VycmVudEluZGV4KTtcbiAgICAgICAgdGhpcy5jdXJyZW50SW5kZXguc3Vic2NyaWJlKHJlcyA9PiB7XG4gICAgICAgICAgICB0aGlzLmNkLm1hcmtGb3JDaGVjaygpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5kb3RzID0gdmFsLmdldEN5YygnbmdBZnRlckNvbnRlbnRJbml0JykucGlwZShcbiAgICAgICAgICAgIG1hcCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXRlbXMgPSBbXTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXkgPSAwOyBrZXkgPCB2YWwuY2hpbGRyZW4ubGVuZ3RoOyBrZXkrKykge1xuICAgICAgICAgICAgICAgICAgICBpdGVtcy5wdXNoKGtleSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBpdGVtcztcbiAgICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3RydWN0b3IocHVibGljIGNkOiBDaGFuZ2VEZXRlY3RvclJlZiwgcHVibGljIG5nWm9uZTogTmdab25lKSB7IH1cbn1cblxuXG5pbXBvcnQgeyBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbkBEaXJlY3RpdmUoeyBzZWxlY3RvcjogJ1tzd2lwZXJEb3RdJyB9KVxuZXhwb3J0IGNsYXNzIFN3aXBlckRvdERpcmVjdGl2ZSB7XG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5kb3QnKSBkb3Q6IGJvb2xlYW4gPSB0cnVlO1xuICAgIEBJbnB1dCgpIHN3aXBlckRvdDogbnVtYmVyO1xuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBkb3RzOiBTd2lwZXJEb3RzRGlyZWN0aXZlLCBwdWJsaWMgcmVuZGVyOiBSZW5kZXJlcjIsIHB1YmxpYyBlbGU6IEVsZW1lbnRSZWYpIHt9XG5cbiAgICBuZ09uSW5pdCgpIHtcbiAgICAgICAgdGhpcy5kb3RzLmN1cnJlbnRJbmRleC5zdWJzY3JpYmUocmVzID0+IHtcbiAgICAgICAgICAgIGlmIChyZXMgPT09IHRoaXMuc3dpcGVyRG90KSB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW5kZXIuYWRkQ2xhc3ModGhpcy5lbGUubmF0aXZlRWxlbWVudCwgJ2FjdGl2ZScpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbmRlci5yZW1vdmVDbGFzcyh0aGlzLmVsZS5uYXRpdmVFbGVtZW50LCAnYWN0aXZlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEhvc3RCaW5kaW5nIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbkBEaXJlY3RpdmUoeyBzZWxlY3RvcjogJ1tzd2lwZXJJdGVtXScgfSlcbmV4cG9ydCBjbGFzcyBTd2lwZXJJdGVtRGlyZWN0aXZlIHtcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLnN3aXBlci1pdGVtJykgaXRlbTogYm9vbGVhbiA9IHRydWU7XG59XG4iLCJpbXBvcnQgeyBCZXR0ZXJDb3JlTW9kdWxlIH0gZnJvbSAnaXdlNy1iZXR0ZXItc2Nyb2xsJztcbmltcG9ydCB7IFN3aXBlckltYWdlRGlyZWN0aXZlIH0gZnJvbSAnLi9zd2lwZXItZGlyZWN0aXZlL3N3aXBlci1pbWFnZSc7XG5pbXBvcnQgeyBTd2lwZXJEb3RzRGlyZWN0aXZlLCBTd2lwZXJEb3REaXJlY3RpdmUgfSBmcm9tICcuL3N3aXBlci1kaXJlY3RpdmUvc3dpcGVyLWRvdHMnO1xuaW1wb3J0IHsgU3dpcGVySXRlbURpcmVjdGl2ZSB9IGZyb20gJy4vc3dpcGVyLWRpcmVjdGl2ZS9zd2lwZXItaXRlbSc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFN3aXBlck91dGxldENvbXBvbmVudCB9IGZyb20gJy4vc3dpcGVyLW91dGxldC9zd2lwZXItb3V0bGV0JztcbmV4cG9ydCBjb25zdCBTd2lwZXJDb21wb25lbnRzID0gW1xuICBTd2lwZXJPdXRsZXRDb21wb25lbnRcbl07XG5cbmV4cG9ydCBjb25zdCBTd2lwZXJEZXZpY2VzID0gW1xuICBTd2lwZXJJdGVtRGlyZWN0aXZlLFxuICBTd2lwZXJJbWFnZURpcmVjdGl2ZSxcbiAgU3dpcGVyRG90c0RpcmVjdGl2ZSxcbiAgU3dpcGVyRG90RGlyZWN0aXZlXG5dO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIEJldHRlckNvcmVNb2R1bGVcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgLi4uU3dpcGVyQ29tcG9uZW50cyxcbiAgICAuLi5Td2lwZXJEZXZpY2VzXG4gIF0sXG4gIGV4cG9ydHM6IFtcbiAgICAuLi5Td2lwZXJDb21wb25lbnRzLFxuICAgIC4uLlN3aXBlckRldmljZXNcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBJd2U3U3dpcGVyTW9kdWxlIHsgfVxuIl0sIm5hbWVzIjpbInRzbGliXzEuX19leHRlbmRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7SUFhMENBLHdDQUFpQjtJQUd2RCw4QkFDVyxRQUNBLEtBQ0E7UUFIWCxZQUtJLGtCQUFNLFFBQVEsQ0FBQyxTQUlsQjtRQVJVLFlBQU0sR0FBTixNQUFNO1FBQ04sU0FBRyxHQUFILEdBQUc7UUFDSCxjQUFRLEdBQVIsUUFBUTtRQUdmLEtBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNwQyxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxrQkFBa0IsRUFBRSxTQUFPLEtBQUksQ0FBQyxXQUFXLE1BQUcsQ0FBQyxDQUFDO1NBQ2xHLENBQUMsQ0FBQzs7S0FDTjs7Z0JBcEJKLFNBQVMsU0FBQztvQkFDUCxRQUFRLEVBQUUsZUFBZTtvQkFDekIsUUFBUSxFQUFFLDRHQUlUO2lCQUNKOzs7O2dCQVhxQixTQUFTO2dCQUFFLFVBQVU7Z0JBQUUsUUFBUTs7OzhCQWFoRCxLQUFLO3dCQUNMLFNBQVMsU0FBQyxPQUFPOzsrQkFmdEI7RUFhMEMsaUJBQWlCOzs7Ozs7O0lDWWhCQSx5Q0FBcUI7SUE4QjVELCtCQUNJLFFBQWtCLEVBQ1gsS0FDQSxRQUNBO1FBSlgsWUFNSSxrQkFBTSxHQUFHLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxTQXFCL0I7UUF6QlUsU0FBRyxHQUFILEdBQUc7UUFDSCxZQUFNLEdBQU4sTUFBTTtRQUNOLFlBQU0sR0FBTixNQUFNO3VCQWpDQyxNQUFNO3dCQUNMLElBQUk7OzBCQWNGLElBQUk7MEJBTUwsSUFBSTt3QkFPUSxJQUFJLFlBQVksRUFBRTtpQ0E4QnZCLENBQUM7UUF0QnhCLEtBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUM1QixLQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDN0IsS0FBSSxDQUFDLElBQUkscUJBQUcsRUFBUyxDQUFBLENBQUM7UUFDdEIsS0FBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7UUFDbEIsS0FBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDckIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDaEMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFBLEdBQUc7WUFDM0MsS0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7Z0JBQ2xCLFFBQVEsRUFBRSxLQUFJLENBQUMsU0FBUztnQkFDeEIsUUFBUSxFQUFFLEtBQUksQ0FBQyxTQUFTO2FBQzNCLENBQUMsQ0FBQztZQUNILEtBQUksQ0FBQyxRQUFRLEdBQUc7Z0JBQ1osTUFBTSxFQUFFLEtBQUksQ0FBQyxNQUFNO2FBQ3RCLENBQUM7WUFDRixxQkFBTSxTQUFTLEdBQVE7Z0JBQ25CLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUN0QixDQUFDO1lBQ0YsS0FBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3hDLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUM1QyxDQUFDLENBQUM7O0tBQ047SUF0REQsc0JBQ0kseUNBQU07Ozs7O1FBRFYsVUFDVyxHQUFRO1lBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM3Qzs7O09BQUE7SUFDRCxzQkFDSSx1Q0FBSTs7Ozs7UUFEUixVQUNTLEdBQVE7WUFDYixtQkFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRSxJQUFJLEdBQUcscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDOUQ7OztPQUFBO0lBQ0Qsc0JBQ0ksd0NBQUs7Ozs7O1FBRFQsVUFDVSxHQUFRO1lBQ2QsbUJBQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUUsS0FBSyxHQUFHLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzlEOzs7T0FBQTtJQUdELHNCQUNJLDJDQUFROzs7OztRQURaLFVBQ2EsR0FBUTtZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQy9DOzs7T0FBQTtJQUdELHNCQUNJLDJDQUFROzs7OztRQURaLFVBQ2EsR0FBUTtZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzlDOzs7T0FBQTs7OztJQW1DRCwyQ0FBVzs7O0lBQVg7UUFDSSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFO1lBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25EO2FBQU07WUFDSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNuRDtRQUNELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3pDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1NBQ3ZCO0tBQ0o7O2dCQXZGSixTQUFTLFNBQUM7b0JBQ1AsUUFBUSxFQUFFLGVBQWU7b0JBQ3pCLFFBQVEsRUFBRSw2QkFDYjtvQkFDRyxNQUFNLEVBQUUsQ0FBQyxnekNBQWd6QyxDQUFDO29CQUMxekMsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07b0JBQy9DLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO29CQUNyQyxJQUFJLEVBQUU7d0JBQ0Ysa0JBQWtCLEVBQUUsU0FBUzt3QkFDN0Isa0JBQWtCLEVBQUUsU0FBUzt3QkFDN0IsZ0JBQWdCLEVBQUUsUUFBUTtxQkFDN0I7b0JBQ0QsTUFBTSxFQUFFLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDO29CQUNsRCxTQUFTLEVBQUUsQ0FBQyxlQUFlLENBQUM7b0JBQzVCLFFBQVEsRUFBRSxjQUFjO2lCQUMzQjs7OztnQkFwQmMsUUFBUTtnQkFGZCxVQUFVO2dCQUFFLFNBQVM7Z0JBRnJCLG9CQUFvQjs7O3lCQTBCeEIsS0FBSzt5QkFFTCxLQUFLO3VCQUlMLEtBQUs7d0JBSUwsS0FBSzsyQkFNTCxLQUFLOzJCQU1MLEtBQUs7MEJBS0wsTUFBTTs7Z0NBckRYO0VBeUIyQyxxQkFBcUI7Ozs7OztBQ3pCaEU7SUFtQ0ksNkJBQW1CLEVBQXFCLEVBQVMsTUFBYztRQUE1QyxPQUFFLEdBQUYsRUFBRSxDQUFtQjtRQUFTLFdBQU0sR0FBTixNQUFNLENBQVE7cUJBcEJuQixJQUFJOzRCQUNSLElBQUksZUFBZSxDQUFDLENBQUMsQ0FBQztLQW1CTTtJQWpCcEUsc0JBQ0ksdUNBQU07Ozs7O1FBRFYsVUFDVyxHQUEwQjtZQURyQyxpQkFlQztZQWJHLEdBQUcsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEdBQUc7Z0JBQzNCLEtBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDMUIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUM3QyxHQUFHLENBQUM7Z0JBQ0EscUJBQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztnQkFDakIsS0FBSyxxQkFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsRUFBRTtvQkFDaEQsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDbkI7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7YUFDaEIsQ0FBQyxDQUNMLENBQUM7U0FDTDs7O09BQUE7O2dCQTVCSixTQUFTLFNBQUM7b0JBQ1AsUUFBUSxFQUFFLGNBQWM7b0JBQ3hCLFFBQVEsRUFBRSx3SUFJVDtvQkFDRCxlQUFlLEVBQUUsdUJBQXVCLENBQUMsTUFBTTtpQkFDbEQ7Ozs7Z0JBVnVDLGlCQUFpQjtnQkFBRSxNQUFNOzs7d0JBWTVELFdBQVcsU0FBQyxZQUFZO3VCQUV4QixLQUFLO3lCQUNMLEtBQUs7OzhCQWxCVjs7O0lBNENJLDRCQUFtQixJQUF5QixFQUFTLE1BQWlCLEVBQVMsR0FBZTtRQUEzRSxTQUFJLEdBQUosSUFBSSxDQUFxQjtRQUFTLFdBQU0sR0FBTixNQUFNLENBQVc7UUFBUyxRQUFHLEdBQUgsR0FBRyxDQUFZO21CQUZyRCxJQUFJO0tBRXFEOzs7O0lBRWxHLHFDQUFROzs7SUFBUjtRQUFBLGlCQVFDO1FBUEcsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNoQyxJQUFJLEdBQUcsS0FBSyxLQUFJLENBQUMsU0FBUyxFQUFFO2dCQUN4QixLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUMxRDtpQkFBTTtnQkFDSCxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUM3RDtTQUNKLENBQUMsQ0FBQztLQUNOOztnQkFkSixTQUFTLFNBQUMsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFOzs7O2dCQUlULG1CQUFtQjtnQkF6QzRDLFNBQVM7Z0JBSDVGLFVBQVU7OztzQkEwQ2QsV0FBVyxTQUFDLFdBQVc7NEJBQ3ZCLEtBQUs7OzZCQTNDVjs7Ozs7OztBQ0FBOztvQkFJc0QsSUFBSTs7O2dCQUZ6RCxTQUFTLFNBQUMsRUFBRSxRQUFRLEVBQUUsY0FBYyxFQUFFOzs7dUJBRWxDLFdBQVcsU0FBQyxtQkFBbUI7OzhCQUpwQzs7Ozs7OztxQkNPYSxnQkFBZ0IsR0FBRztJQUM5QixxQkFBcUI7Q0FDdEIsQ0FBQztBQUVGLHFCQUFhLGFBQWEsR0FBRztJQUMzQixtQkFBbUI7SUFDbkIsb0JBQW9CO0lBQ3BCLG1CQUFtQjtJQUNuQixrQkFBa0I7Q0FDbkIsQ0FBQzs7Ozs7Z0JBRUQsUUFBUSxTQUFDO29CQUNSLE9BQU8sRUFBRTt3QkFDUCxZQUFZO3dCQUNaLGdCQUFnQjtxQkFDakI7b0JBQ0QsWUFBWSxXQUNQLGdCQUFnQixFQUNoQixhQUFhLENBQ2pCO29CQUNELE9BQU8sV0FDRixnQkFBZ0IsRUFDaEIsYUFBYSxDQUNqQjtpQkFDRjs7MkJBL0JEOzs7Ozs7Ozs7Ozs7Ozs7In0=