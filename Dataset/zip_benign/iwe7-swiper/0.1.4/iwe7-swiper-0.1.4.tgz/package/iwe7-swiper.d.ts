/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { SwiperDotDirective as ɵe, SwiperDotsDirective as ɵd } from './lib/swiper-directive/swiper-dots';
export { SwiperImageDirective as ɵc } from './lib/swiper-directive/swiper-image';
export { SwiperItemDirective as ɵb } from './lib/swiper-directive/swiper-item';
export { SwiperOutletComponent as ɵa } from './lib/swiper-outlet/swiper-outlet';
