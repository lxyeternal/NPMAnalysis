import { BetterManagerService, BetterScrollDirective } from 'iwe7-better-scroll';
import { ElementRef, Renderer2 } from '@angular/core';
import { Injector, EventEmitter } from '@angular/core';
export declare class SwiperOutletComponent extends BetterScrollDirective {
    ele: ElementRef;
    render: Renderer2;
    better: BetterManagerService;
    height: string;
    _hasDot: boolean;
    hasDot: any;
    loop: any;
    speed: any;
    _autoPlay: boolean;
    autoPlay: any;
    _interval: number;
    interval: any;
    ngSlide: EventEmitter<number>;
    constructor(injector: Injector, ele: ElementRef, render: Renderer2, better: BetterManagerService);
    currentPageIndex: number;
    onScrollEnd(): void;
}
