export declare class SwiperItemDirective {
    item: boolean;
}
