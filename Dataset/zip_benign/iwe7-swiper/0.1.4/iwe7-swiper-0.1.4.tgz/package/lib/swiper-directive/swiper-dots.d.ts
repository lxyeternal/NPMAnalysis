import { ElementRef } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { ChangeDetectorRef, NgZone, Renderer2 } from '@angular/core';
import { SwiperOutletComponent } from '../swiper-outlet/swiper-outlet';
export declare class SwiperDotsDirective {
    cd: ChangeDetectorRef;
    ngZone: NgZone;
    _dots: boolean;
    currentIndex: BehaviorSubject<number>;
    dots: Observable<any[]>;
    outlet: SwiperOutletComponent;
    constructor(cd: ChangeDetectorRef, ngZone: NgZone);
}
export declare class SwiperDotDirective {
    dots: SwiperDotsDirective;
    render: Renderer2;
    ele: ElementRef;
    dot: boolean;
    swiperDot: number;
    constructor(dots: SwiperDotsDirective, render: Renderer2, ele: ElementRef);
    ngOnInit(): void;
}
