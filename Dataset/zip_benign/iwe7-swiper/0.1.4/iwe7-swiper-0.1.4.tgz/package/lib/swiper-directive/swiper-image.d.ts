import { Renderer2, ElementRef, Injector } from '@angular/core';
import { Iwe7CoreComponent } from 'iwe7-core';
export declare class SwiperImageDirective extends Iwe7CoreComponent {
    render: Renderer2;
    ele: ElementRef;
    injector: Injector;
    swiperImage: string;
    image: ElementRef;
    constructor(render: Renderer2, ele: ElementRef, injector: Injector);
}
