import { SwiperImageDirective } from './swiper-directive/swiper-image';
import { SwiperDotsDirective, SwiperDotDirective } from './swiper-directive/swiper-dots';
import { SwiperItemDirective } from './swiper-directive/swiper-item';
import { SwiperOutletComponent } from './swiper-outlet/swiper-outlet';
export declare const SwiperComponents: (typeof SwiperOutletComponent)[];
export declare const SwiperDevices: (typeof SwiperItemDirective | typeof SwiperImageDirective | typeof SwiperDotsDirective | typeof SwiperDotDirective)[];
export declare class Iwe7SwiperModule {
}
