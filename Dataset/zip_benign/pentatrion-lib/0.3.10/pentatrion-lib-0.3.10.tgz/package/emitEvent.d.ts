export default function emitEvent(type: string, detail?: {}, elem?: Document): boolean | undefined;
