export declare function toIsoString(datetime: Date, complete?: boolean): string;
export declare function ago(ptime: Date, ctime?: Date): string;
declare const _default: {
    toIsoString: typeof toIsoString;
    ago: typeof ago;
};
export default _default;
