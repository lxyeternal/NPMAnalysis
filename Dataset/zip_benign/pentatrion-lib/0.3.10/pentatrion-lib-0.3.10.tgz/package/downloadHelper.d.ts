export declare function downloadFromBlob(b: Blob, filename: string): void;
export declare function downloadFromUrl(url: string, filename: string): Promise<string>;
export declare function stringToSlug(str: string): string;
