export declare function jsonFetchOrNotify(url: string, params?: RequestInit, xRequestedWith?: boolean): Promise<any>;
export declare function formFetchOrNotify(url: string, params?: RequestInit, xRequestedWith?: boolean): Promise<any>;
export declare function fetchOrNotify(url: string, params?: RequestInit, xRequestedWith?: boolean): Promise<any>;
export declare function jsonFetch(url: string, params?: RequestInit, xRequestedWith?: boolean): Promise<any>;
export declare function formFetch(url: string, params?: RequestInit, xRequestedWith?: boolean): Promise<any>;
export declare class ApiError {
    title: string;
    status: number;
    constructor(title: string, status?: number);
}
