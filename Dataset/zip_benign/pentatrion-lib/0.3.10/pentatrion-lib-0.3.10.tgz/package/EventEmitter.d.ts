/**
 * EvEmitter v1.1.0
 * Lil' event emitter
 * MIT License
 */
declare type Listener = (...args: any[]) => void;
declare class EventEmitter {
    private events;
    private onceEvents;
    on(eventName: string, listener: Listener): this;
    once(eventName: string, listener: Listener): this | undefined;
    off(eventName: string, listener: Listener): this | undefined;
    emitEvent(eventName: string, args: any[]): this | undefined;
    allOff(): void;
}
export default EventEmitter;
