export default class Animator {
    static defaultOptions: {
        inactiveClass: string;
        transitionName: string;
    };
    private animation;
    private options;
    constructor(options?: {});
    beforeAnimation(item: HTMLElement): boolean;
    animEnter(item: HTMLElement): void;
    animLeave(item: HTMLElement): void;
}
