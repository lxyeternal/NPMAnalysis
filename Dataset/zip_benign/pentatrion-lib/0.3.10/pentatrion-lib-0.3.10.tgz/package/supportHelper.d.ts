export declare function supportsCssVars(): boolean;
