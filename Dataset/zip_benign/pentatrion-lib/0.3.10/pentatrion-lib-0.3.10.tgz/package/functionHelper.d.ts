export declare type Newable<T> = {
    new (...args: any[]): T;
};
export declare function debounceMethod(_class: Newable<{
    prototype: {
        [k: string]: any;
    };
}>, methodName: string, threshold: number): void;
export declare function throttleMethod(_class: Newable<{
    prototype: {
        [k: string]: any;
    };
}>, methodName: string, threshold: number): void;
