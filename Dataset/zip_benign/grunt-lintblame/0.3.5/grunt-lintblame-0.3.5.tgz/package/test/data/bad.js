if (fun)
{
  party hard"";
}