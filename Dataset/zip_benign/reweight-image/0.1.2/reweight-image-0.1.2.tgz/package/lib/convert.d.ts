import { Observable } from "rxjs";
import Blob = require('cross-blob');
declare type Base64data = string;
export declare class Convert {
    readonly BYTES_SLICE_SIZE = 1024;
    getBase64FromBlob(image: Blob): Observable<Base64data>;
    getBlobFromBase64(base64data: Base64data): Blob;
    private getByteArrays;
    private getbyteArraysLength;
    private getActualData;
}
export {};
