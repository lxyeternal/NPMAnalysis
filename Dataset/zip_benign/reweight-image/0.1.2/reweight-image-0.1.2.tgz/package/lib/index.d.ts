import { Observable } from 'rxjs';
import { Convert } from './convert';
export { Convert };
export interface ReweightLimits {
    fileSizeMb?: number;
    imageSizePx?: number;
    jpegQuality?: number;
}
export interface ReweightImageOptions {
    coverMaxImageSize?: boolean;
    imageSizeRatio?: number;
    jpegQualityRatio?: number;
}
export declare class ReweightImage {
    readonly BYTES_IN_ONEMB = 1000000;
    readonly DEFAULT_REDUCE_RATIO = 0.99;
    readonly CONVERT: Convert;
    limits: {
        fileSizeMb: number;
        imageSize: number;
        jpegQuality: number;
    };
    options: {
        coverMaxImageSize: boolean;
        imageSizeRatio: number;
        jpegQualityRatio: number;
    };
    constructor(limits: ReweightLimits, options?: ReweightImageOptions);
    compressImageFile(fileImage: File): Observable<File>;
    private reweightBase64Image;
    private getCompleteInputLimits;
    private getCompleteInputOptions;
    private compressBase64Image;
    private compressImageElement;
    private createCanvasWithFinalDimensions;
    private fillCanvasWithImage;
    private getScale;
}
