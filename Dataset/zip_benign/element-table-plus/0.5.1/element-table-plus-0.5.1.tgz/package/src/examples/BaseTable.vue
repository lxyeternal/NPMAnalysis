<template>
  <MyTable
    :table-attrs="tableAttrs"
    :columns="columns"
    :pagination-attrs="pagination"
  />
</template>

<script>
import MyTable from '../CommonTable';
export default {
  components: { MyTable },
  data() {
    return {
      tableAttrs: {
        style: 'width: 100%',
        spanMethod: this.m111,
        border: true,
        data: [
          {
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄'
          },
          {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄'
          },
          {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          },
          {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }
        ],
      },
      columns: [
        { label: '日期', prop: 'date', width: 180 },
        { label: '姓名', prop: 'name', width: 180 },
        { label: '地址', prop: 'address' }
      ],
      pagination: {
        total: 40
      }
    };
  },
  methods: {
    m111({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex % 2 === 0) {
          return {
            rowspan: 2,
            colspan: 1
          };
        } else {
          return {
            rowspan: 0,
            colspan: 0
          };
        }
      }
    }
  }
};
</script>