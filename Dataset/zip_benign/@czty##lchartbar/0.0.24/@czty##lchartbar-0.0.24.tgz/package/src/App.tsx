import React, { FC } from 'react'
import 'antd/dist/antd.css'
// 文件夹命名得全小写的
import Lchartbar from '@/component'

const App: FC = () => {
  return (
    <div className="app">
      <Lchartbar /> 
    </div>
  )
}

export default App