import * as echarts from 'echarts/lib/echarts'
import 'echarts/lib/chart/bar'
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/title'
import 'echarts/lib/component/legend'
import 'echarts/lib/component/grid'
import 'echarts/lib/chart/graph'
import 'echarts/lib/component/graphic'
import 'echarts/lib/chart/pictorialBar'

import React, { FC, useEffect, useState } from 'react'
import { merge } from 'lodash'
import './index.scss'
import configers from '../../configer'
import request from '@/utils/request'

const noDataOption = {
  text: '暂无数据',
  color: 'rgba(255, 255, 255, 0)',
  textColor: '#8a8e91',
  maskColor: 'rgba(255, 255, 255, 0)'
}
const loadingDataOption = {
  text: '正在加载中...',
  color: 'rgba(255, 255, 255, 0)',
  textColor: '#8a8e91',
  maskColor: 'rgba(255, 255, 255, 0)'
}


Date.prototype.format = function (format) {
  var o = {
    "M+": this.getMonth() + 1, //month
    "d+": this.getDate(),    //day
    "h+": this.getHours(),   //hour
    "m+": this.getMinutes(), //minute
    "s+": this.getSeconds(), //second
    "q+": Math.floor((this.getMonth() + 3) / 3),  //quarter
    "S": this.getMilliseconds() //millisecond
  }
  if (/(y+)/.test(format)) format = format.replace(RegExp.$1,
    (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o) if (new RegExp("(" + k + ")").test(format))
    format = format.replace(RegExp.$1,
      RegExp.$1.length == 1 ? o[k] :
        ("00" + o[k]).substr(("" + o[k]).length));
  return format;
}
// mode是模式， false代表接口模式，true代表外部填写静态值的模式, mode=false 
const Lchartbar: FC = ({
  draggable=true,
  configer=configers
}) => {
  const {
    ydata,
    xdata,
    legendData,
    width,
    height,
    axisTextColor,
    barWidth,
    barbackground,
    barItemColor,
    pictorialBar,
    options
  } = configer
  const [barItemColor0, barItemColor1] = barItemColor
  const chartData = {
    // color: ['rgb(22, 56, 92)' , 'rgb(36, 225, 254)'],
    backgroundColor: 'transparent',
    grid: {
      right: '5',
      left: '5',
      bottom: '15',
      top: '20',
      containLabel: true
    },
    legend: {
      show: false,
      data: legendData
    },
    tooltip: {
      show: false,
      trigger: 'axis',
    },
    xAxis: {
      type: 'category',
      data: [],
      axisLine: {
        lineStyle: {
          color: 'rgba(32, 82, 131, 1)',
          width: 1
        }
      },
      axisLabel: {
        color: axisTextColor
      },
      splitLine: {
        show: false,
        lineStyle: {
          color: 'rgba(32, 82, 131, 0.5)',
          width: 1
        }
      }
    },
    yAxis: {
      type: 'value',
      axisLine: {
        lineStyle: {
          color: 'rgba(32, 82, 131, 0.5)',
          width: 2
        }
      },
      axisLabel: {
        color: axisTextColor
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: 'rgba(32, 82, 131, 0.5)',
          width: 1,
          type: 'dashed'
        }
      }
    },
    series: [
      {
        data: [],
        type: 'bar',
        barWidth: barWidth,
        showBackground: true,
        backgroundStyle: {
          color: barbackground
        },
        z: 10,
        zlevel: 0,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            {
              offset: 0,
              color: barItemColor0 ? barItemColor0 : 'none' // "rgba(36, 226, 254, 1)", 
            },
            {
              offset: 1,
              color: barItemColor1 ? barItemColor1 : barItemColor0 ? barItemColor0 : 'none' //  "rgba(21, 52, 86, 1)",
            }
          ])
        },
      },
      {
        // 分隔
        type: "pictorialBar",
        itemStyle: {
          color: 'rgba(0, 0, 0, 0.5)'
        },
        symbolRepeat: "fixed",
        symbolMargin: 4,
        symbol: "rect",
        symbolClip: true,
        symbolSize: [10, 2],
        symbolPosition: "start",
        symbolOffset: [0,1],
        data: [],
        width: 2,
        zlevel: pictorialBar ? 1 : 0
      }
    ]
  };
  const [myChart, setChart] = useState(null)
  const [od, setOd] = useState(chartData)
  const [dots] = useState(Math.floor(Math.random() * 10000))
  const handleDrag = (e) => {
    /*
    * 这里还可以传输一个字段，来标明是什么类型的组件
    * 比如button是需要传string的prop, echarts是传数组对象类的prop
    * 不同的类型，左侧的属性编辑栏里编辑的项不同
    */
    const data = JSON.stringify({ type: 'other', id: 'Lchartbar', relate: 'in' })
    e.dataTransfer.setData('Text', data)
  }

  const updateData = () => {
    const item = merge(chartData, options)
    item.xAxis.data = xdata
    item.series[0].data = ydata[0]?ydata[0]:[]
    item.series[1].data = ydata[0]?ydata[0]:[]
    item.legend.data = legendData
    setOd({...item})
  }
  
  useEffect(() => {
    const chartDom = document.querySelector(`.dccp-charts-${dots}`)
    setChart(echarts.init(chartDom))
  }, [])

  useEffect(() => {
    updateData()
    // 对于第二个参数是对象的问题，可以是string化，也可以是md5化
  }, [JSON.stringify(configer)])

  useEffect(() => {
    try {
      myChart?.setOption(od, true)
    } catch(e) {
      console.log(e)
    }
    if(od.series[0].data?.length) {
      myChart?.hideLoading()
    }else {
      myChart?.showLoading(noDataOption);
    }
  }, [JSON.stringify(od), myChart])

  const handleResize = () => {
    myChart?.resize()
  }
  useEffect(()=>{
    if(myChart) {
      window.addEventListener('resize', handleResize);
    }
    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [myChart])
  
  return (
    <>
      <div
        draggable={draggable}
        onDragStart={(e) => { handleDrag(e) } }
        style={{ width: width, height: height }}
        className={`dragor dccp-charts dccp-charts-${dots}`}
      >
        
      </div>
    </>
  )
}

export default Lchartbar