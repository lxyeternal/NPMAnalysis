export const cfgItem = [{
  label: 'x',
  name: 'x',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'y',
  name: 'y',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'clazz',
  name: 'clazz',
  value: '',
  placeholder: '例如：cz-title',
  type: []
},{
  label: '请求参数',
  name: 'params',
  value: '',
  placeholder: '例如：{id: 2}',
  type: []
},{
  label: '请求方式',
  name: 'method',
  value: 'get',
  placeholder: '例如：get',
  type: [{
    id: 'get',
    name: 'get'
  }, {
    id: 'post',
    name: 'post'
  }, {
    id: 'put',
    name: 'put'
  }, {
    id: 'delete',
    name: 'delete'
  }]
},{
  label: '请求地址',
  name: 'url',
  value: '',
  placeholder: '例如：',
  type: []
},{
  label: '数据',
  name: 'ydata',
  value: [[3, 4, 6, 10, 30]],
  placeholder: '例如：[]',
  type: []
}, {
  label: 'x轴字段',
  name: 'xdata',
  value: ['04-02', '04-01', '03-30', '03-29', '03-28'],
  placeholder: "例如：['2022-04-02', '2022-04-01', '2022-03-30', '2022-03-29', '2022-03-28']",
  type: []
}, {
  label: '图例数据',
  name: 'legendData',
  value: [],
  placeholder: '例如：["2022"]',
  type: []
}, {
  label: '宽度',
  name: 'width',
  value: '400px',
  placeholder: '例如：400px',
  type: []
}, {
  label: '高度',
  name: 'height',
  value: '202px',
  placeholder: '例如：704px',
  type: []
},{
  label: '轴字颜色',
  name: 'axisTextColor',
  value: 'rgb(137, 171, 205)',
  placeholder: '例如：rgb(137, 171, 205)',
  type: ['color']
},{
  label: '柱子宽度',
  name: 'barWidth',
  value: 10,
  placeholder: '例如：10',
  type: []
},{
  label: '柱子背景',
  name: 'barbackground',
  value: 'rgba(55, 95, 144, 0.5)',
  placeholder: '例如：rgba(55, 95, 144, 0.5)',
  type: []
},{
  label: '柱子颜色',
  name: 'barItemColor',
  value: ['rgba(36, 226, 254, 1)', 'rgba(21, 52, 86, 1)'],
  placeholder: '例如：[rgba(36, 226, 254, 1), rgba(21, 52, 86, 1)]',
  type: []
},{
  label: '象形柱图',
  name: 'pictorialBar',
  value: true,
  placeholder: '例如：false',
  type: []
}, {
  label: 'options',
  name: 'options',
  value: {},
  placeholder: '例如：{}',
  type: []
}]

export default  {
  x: 0,
  y: 0,
  clazz : '',
  params : {},
  url: '',
  method: 'get',
  ydata: [[3, 4, 6, 10, 30]],
  xdata: ['04-02', '04-01', '03-30', '03-29', '03-28'],
  legendData: [],

  width: '400px',
  height: '200px',

  axisTextColor: 'rgb(137, 171, 205)',
  barWidth: 10,
  barbackground: 'rgba(55, 95, 144, 0.5)',
  barItemColor: ['rgba(36, 226, 254, 1)', 'rgba(21, 52, 86, 1)'],
  pictorialBar: true,

  options: {}
}