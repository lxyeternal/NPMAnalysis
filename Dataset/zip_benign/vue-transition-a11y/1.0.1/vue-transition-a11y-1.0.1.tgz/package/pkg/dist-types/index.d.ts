import Vue from 'vue';
interface IVueTransitiona11yProps {
    reduceMotion: boolean;
}
declare const _default: import("vue/types/vue").ExtendedVue<Vue, {}, {}, {}, IVueTransitiona11yProps>;
export default _default;
