import Vue from 'vue';

const MEDIA_QUERY_REDUCE_MOTION = 'screen and (prefers-reduced-motion: reduce)';
var index = Vue.component('transition-a11y', {
    functional: true,
    props: {
        reduceMotion: {
            default: true,
        },
    },
    render: (h, { data, props: { reduceMotion }, children }) => {
        if (typeof window === 'undefined')
            return children;
        const { matches = false } = window.matchMedia(MEDIA_QUERY_REDUCE_MOTION);
        return reduceMotion && matches ? children : h('transition', data, children);
    },
});

export default index;
//# sourceMappingURL=index.js.map
