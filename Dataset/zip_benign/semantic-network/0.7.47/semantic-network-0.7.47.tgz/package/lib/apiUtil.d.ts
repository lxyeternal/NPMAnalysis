import { get } from './representation/get';
import { create } from './representation/create';
import { update } from './representation/update';
import { del } from './representation/delete';
export declare class ApiUtil {
    static get: typeof get;
    static create: typeof create;
    static update: typeof update;
    static delete: typeof del;
}
