export declare function instanceOfSimpleValue(obj: unknown): obj is string | number;
