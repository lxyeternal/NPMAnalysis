import { RelationshipType } from 'semantic-link';
export declare class RelationshipTypeUtil {
    /**
     * Takes a string or a Regexp and makes camel cased strings.
     *
     * @example
     *
     *      test -> test
     *      /test/ -> test
     *      /test/g -> test
     *      /create-form/ -> createForm
     *
     * @param {RelationshipType} rel
     * @returns {string}
     */
    static toCamel(rel: RelationshipType): string | undefined | never;
}
