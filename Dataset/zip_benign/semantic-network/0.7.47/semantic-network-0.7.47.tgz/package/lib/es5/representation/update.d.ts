import { LinkedRepresentation } from 'semantic-link';
import { ResourceUpdateOptions } from '../interfaces/resourceUpdateOptions';
import { Tracked } from '../types/types';
import { DocumentRepresentation } from '../interfaces/document';
import { ResourceLinkOptions } from '../interfaces/resourceLinkOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { ResourceMergeOptions } from '../interfaces/resourceAssignOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
/**
 * A subset of the {@link ApiOptions} that are appropriate for a HTTP PUT.
 *
 * @see ApiOptions
 */
export type ApiUpdateOptions = ResourceUpdateOptions & ResourceLinkOptions & HttpRequestOptions & ResourceMergeOptions & ResourceFetchOptions;
/**
 * Update on existing resource
 *      TODO: accept but don't require TrackedRepresentation interface
 *      TODO: always returns resource but hard to know if error. Either throw or return undefined
 *            Note: underlying TrackedRepresentationFactory.update has this strategy
 */
export declare function update<T extends LinkedRepresentation>(resource: T | Tracked<T>, document: T | DocumentRepresentation<T>, options?: ApiUpdateOptions): Promise<T>;
