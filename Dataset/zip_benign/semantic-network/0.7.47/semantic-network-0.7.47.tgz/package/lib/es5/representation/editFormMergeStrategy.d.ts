import { EditFormMergeStrategy } from '../interfaces/editFormMergeStrategy';
export declare const defaultEditFormStrategy: EditFormMergeStrategy;
