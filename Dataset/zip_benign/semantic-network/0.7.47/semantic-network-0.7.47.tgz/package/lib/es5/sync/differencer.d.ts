import { CollectionRepresentation } from 'semantic-link';
import { Comparator } from '../interfaces/comparator';
import { SyncOptions } from '../interfaces/sync/syncOptions';
import { SyncResultItem } from '../interfaces/sync/types';
import { ComparableRepresentation } from '../interfaces/comparableRepresentation';
export declare class Differencer {
    /**
     * A default set of comparisons made to check if two resource
     * representation refer to the same resource in a collection.
     *
     * The most specific and robust equality check is first, with the most vague and
     * optimistic last.
     */
    static get defaultEqualityOperators(): Comparator<ComparableRepresentation>[];
    /**
     *  Processes difference sets (create, update, delete) for between two client-side collections {@Link CollectionRepresentation}
     *
     * WARNING: this is a differencing set and update can be misleading. What is means is that we have 'matched' these
     * two resource as both 'existing' and thus may or may not require some form of update on them. The decision on
     * whether there is an actual difference is up to some other decision that know about the internals of the resource
     * (such as an edit form merger).
     *
     *     set one - current collection
     *     set two - new collection

     *     add/create    - not in set one but in set two
     *     match/update  - intersection of both sets (may or may not require a change)
     *     remove/delete - in set one and not in set two
     *
     *                       set one: current
     *                 +-----------------------------+
     *     +-----------------------------------------+
     *     |           |              |              |
     *     |   add     |    match     |   remove     |
     *     |           |              |              |
     *     +-----------------------------------------+
     *     +--------------------------+
     *           set two: new
     *
     *
     * @param  resource an existing resource collection that is
     * synchronised with the server (network of data).
     *
     * @param document a document with a collection CollectionRepresentation
     * format that describes the state of the resources.
     *
     * @param options a document with a collection CollectionRepresentation
     * format that describes the state of the resources.
     */
    static difference(resource: CollectionRepresentation, document: CollectionRepresentation, options?: SyncOptions): Promise<SyncResultItem>;
}
