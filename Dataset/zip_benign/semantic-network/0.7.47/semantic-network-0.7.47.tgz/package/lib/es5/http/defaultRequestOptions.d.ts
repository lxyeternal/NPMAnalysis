import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
export declare const defaultRequestOptions: Required<HttpRequestOptions>;
