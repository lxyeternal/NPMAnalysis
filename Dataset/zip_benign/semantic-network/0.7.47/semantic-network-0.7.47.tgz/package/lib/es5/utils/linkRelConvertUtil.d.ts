import { RelationshipType } from 'semantic-link';
export declare class LinkRelConvertUtil {
    private static NameRegex;
    private static EMPTY;
    private static DASH;
    /**
     * Takes an array of potentially camel-cased strings and only returns those that have a dash in
     * the form
     *
     * @example
     *   [questionType, type] --> [question-type]
     *
     * @param {string[]} array
     * @return {string[]}
     */
    static filterCamelToDash(array: string[]): string[];
    /**
     * Takes an array of potentially camel-cased strings and returns all in dash form
     *
     * @example
     *   [questionType, type] --> [question-type, type]
     *
     * @param {string[]} array
     * @return {string[]}
     */
    static camelToDash(array: string[] | string): string | string[];
    /**
     * Takes a string and returns any dash string as camel-cased string
     *
     * @example
     *   question-type --> questionType
     *   type          --> type
     */
    static dashToCamel(str: string): string;
    /**
     * Takes a string or a Regexp and makes camel cased strings.
     *
     * @example
     *
     *      test -> test
     *      /test/ -> test
     *      /test/g -> test
     *      /create-form/ -> createForm
     *      'create-form' -> createForm
     *
     * @param rel relationship that will become the field name
     * @returns field name
     */
    static relTypeToCamel(rel: RelationshipType | undefined): string;
    private static replaceToDash;
}
