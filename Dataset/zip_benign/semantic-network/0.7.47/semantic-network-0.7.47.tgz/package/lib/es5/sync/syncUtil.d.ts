import { CollectionRepresentation, LinkedRepresentation } from 'semantic-link';
import { StrategyType, SyncResultItem } from '../interfaces/sync/types';
import { SyncOptions } from '../interfaces/sync/syncOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { SyncInfo } from '../interfaces/sync/syncInfo';
import { DocumentRepresentation } from '../interfaces/document';
import { Document, Representation } from '../types/types';
import { RepresentationUtil } from '../utils/representationUtil';
export declare class SyncUtil {
    static defaultFindResourceInCollectionStrategy: typeof RepresentationUtil.findInCollection;
    static synchroniseCollection: <T extends LinkedRepresentation>(collectionResource: CollectionRepresentation<T>, collectionDocument: CollectionRepresentation<T>, options?: SyncOptions & ResourceFetchOptions & HttpRequestOptions) => Promise<SyncResultItem>;
    static syncResources<T extends Representation, U extends Document>(resource: T, document: U, strategies?: StrategyType[], options?: SyncOptions & ResourceFetchOptions & HttpRequestOptions): Promise<() => Promise<void[]>>;
    static tailRecursionThroughStrategies(strategies: StrategyType[], syncInfos: SyncInfo[], options?: SyncOptions & ResourceFetchOptions & HttpRequestOptions): Promise<void>;
    static syncResourceInCollection<T extends LinkedRepresentation>(resource: CollectionRepresentation<T>, document: T | DocumentRepresentation<T>, options?: SyncOptions & ResourceFetchOptions & HttpRequestOptions): Promise<SyncInfo | undefined>;
    static syncInfos(strategies: StrategyType[], options?: SyncOptions & ResourceFetchOptions & HttpRequestOptions): (syncInfo: SyncInfo) => Promise<LinkedRepresentation>;
}
