import { LinkType, RelationshipType } from 'semantic-link';
import { AxiosRequestConfig, AxiosResponse } from 'axios';
import { DocumentRepresentation } from '../interfaces/document';
export declare function defaultPostFactory<T>(link: LinkType, rel: RelationshipType, document: T | DocumentRepresentation<T>, options?: AxiosRequestConfig): Promise<AxiosResponse<T>>;
