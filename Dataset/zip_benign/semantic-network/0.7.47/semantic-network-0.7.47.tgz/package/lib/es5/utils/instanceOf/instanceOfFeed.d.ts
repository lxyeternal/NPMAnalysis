import { FeedRepresentation, LinkedRepresentation } from 'semantic-link';
export declare function instanceOfFeed(object: unknown | LinkedRepresentation): object is FeedRepresentation;
