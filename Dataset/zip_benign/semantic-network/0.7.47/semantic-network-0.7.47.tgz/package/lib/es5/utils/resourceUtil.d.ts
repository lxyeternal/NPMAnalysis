import { ApiOptions } from '../interfaces/apiOptions';
export declare class ResourceUtil {
    /**
     * Given a set of {@link ApiOptions}, use the {@link ApiOptions.name} and {@ApiOptions.rel}
     * properties to determine a name.
     *
     * Note: a valid name is always returns or throw error
     */
    static makeName(options?: ApiOptions): string;
}
