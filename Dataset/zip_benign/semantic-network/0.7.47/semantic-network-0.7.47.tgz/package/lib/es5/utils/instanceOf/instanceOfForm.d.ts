import { LinkedRepresentation } from 'semantic-link';
import { FormRepresentation } from '../../interfaces/formRepresentation';
/**
 * This is a known hack to determine if a URL refers to a form. This is used
 * to match a path element from URLs of the form:
 *     - https://schema.example.com/my/form/create
 *     - https://schema.example.com/my/create-form
 */
export declare const knownFormPathElements: string[];
/**
 * A guard to detect whether the object is a form {@link FormRepresentation}
 *
 * @see https://stackoverflow.com/questions/14425568/interface-type-check-with-typescript
 * @param object
 * @returns whether the object is an instance on the interface
 */
export declare function instanceOfForm(object: unknown | LinkedRepresentation): object is FormRepresentation;
