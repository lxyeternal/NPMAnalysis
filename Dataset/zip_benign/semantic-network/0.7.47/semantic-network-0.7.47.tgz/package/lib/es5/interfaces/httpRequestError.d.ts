import { AxiosError } from 'axios';
export type HttpRequestError = AxiosError;
/**
 * Supports detecting {@link axios} {@link AxiosError}
 */
export declare const isHttpRequestError: (e: unknown) => e is HttpRequestError;
