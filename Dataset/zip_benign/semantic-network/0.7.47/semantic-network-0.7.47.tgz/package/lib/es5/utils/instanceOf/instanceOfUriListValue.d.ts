import { Uri } from 'semantic-link';
export declare function instanceOfUriListValue(obj: unknown): obj is Uri[];
