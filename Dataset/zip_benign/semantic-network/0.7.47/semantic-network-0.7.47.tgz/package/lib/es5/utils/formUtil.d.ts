import { FormRepresentation } from '../interfaces/formRepresentation';
import { LinkedRepresentation } from 'semantic-link';
import { FormItem } from '../interfaces/formItem';
import { DocumentRepresentation } from '../interfaces/document';
import { MergeOptions } from '../interfaces/mergeOptions';
export declare class FormUtil {
    /**
     * Returns the fields that the server is willing to accept. Current it defaults to finding
     * value of the key of the field {@link FormItem.name}.
     *
     * Note: the form is of the format - the `items` list the fields that the server will accept
     * <pre>
     * {
     *  links: [],
     *  items:
     *    [
     *      {
     *          type: "",
     *          name: "",
     *          description: ""
     *      }
     *    ]
     * }
     * </pre>
     */
    static fieldsToAccept<T extends LinkedRepresentation | Partial<T> = LinkedRepresentation, TForm extends FormRepresentation = FormRepresentation, TField extends Omit<Extract<keyof T, string>, 'links'> = Omit<Extract<keyof T, string>, 'links'>>(form: TForm, defaultFields: TField[]): TField[];
    /**
     * Pick all the fields to resolve in the document at that (a) exist in the form AND (b) exist on the document itself
     * or are defaults
     * @param document
     * @param form
     * @param defaultFields
     */
    static fieldsToResolve<T extends LinkedRepresentation | Partial<T>, TForm extends FormRepresentation, TField extends Extract<keyof Omit<T, 'links'>, string> = Extract<keyof Omit<T, 'links'>, string>>(document: T, form: TForm, defaultFields?: TField[]): Omit<Extract<keyof T, string>, 'links'>[];
    /**
     * Pick all the fields to resolve in the document at that (a) exist in the form AND (b) exist on the document itself
     * or are defaults
     * @param document
     * @param form
     * @param defaultFields
     * @returns
     *
     */
    static linksToResolve<T extends LinkedRepresentation | Partial<T>, TForm extends FormRepresentation, TField extends Extract<keyof Omit<T, 'links'>, string> = Extract<keyof Omit<T, 'links'>, string>>(document: T, form: TForm, defaultFields?: TField[]): TField[];
    /**
     * Find a {@link FormItem} by matching its {@link FormItem.name} against a field name. A fieldname strategy
     * is camel cased
     *
     * @see LinkRelConvertUtil.dashToCamel
     *
     * TODO: field could accept RelationshipType {@see LinkRelConvertUtil.relTypeToCamel}
     *
     * @param form
     * @param field
     */
    static findByField(form: FormRepresentation, field: string): FormItem | undefined;
    /**
     * A basic dirty check type function comparing an original resource with a new document.
     * @param resource original document
     * @param document updates to be made
     * @param form
     * @param defaultFields that require update
     * @returns fields to merge that actually requiring updating based on being a different value
     *
     * // TODO; return Omit<P, "links">
     */
    static fieldsRequiringUpdate<T extends LinkedRepresentation | Partial<T>, TForm extends FormRepresentation, TField extends Extract<keyof Omit<T, 'links'>, string> = Extract<keyof Omit<T, 'links'>, string>>(resource: T, document: T | DocumentRepresentation<T>, form: TForm, defaultFields?: TField[]): TField[];
    /**
     * Returns a new object with only fields explicitly set in the form or default values
     * @param document
     * @param form
     * @param options
     */
    static fieldsToReturnFromForm<T extends LinkedRepresentation | Partial<T>, TField extends Extract<keyof Omit<T, 'links'>, string>>(document: T, form: FormRepresentation, options?: MergeOptions): DocumentRepresentation;
    /**
     * A {@link FormItem} can have a lazy loaded {@link FieldType.Collection} on a {@link FieldType.Select} where the
     * {@link FormItem.id} is set to the uri of the collection that is resolved via an optional {@link MergeOptions.resourceResolver}.
     * This collection may or may not be resolved at the same time via an optional {@link MergeOptions.resolver}.
     *
     * Note: there is a current implicit polymorphism to be resolved. The {@link FormItem.items} can be both a {@link FormItem[]}
     *       and a {@link CollectionRepresentation} where the code looks through to the Collection items.
     *
     * @param item form item that may optionally have a lazy loaded items collection
     * @param options contains the optional resolvers
     */
    static resolveItemsFromCollection(item: FormItem, options?: MergeOptions): Promise<void>;
    /**
     * Take a form representation and return back a document based on the keys in the form representation.
     *
     * TODO: values are currently null but could include any defaults from the form
     */
    static toEmptyDocument(form: FormRepresentation): DocumentRepresentation;
}
