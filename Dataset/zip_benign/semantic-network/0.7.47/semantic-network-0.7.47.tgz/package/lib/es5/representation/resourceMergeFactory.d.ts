import { LinkedRepresentation } from 'semantic-link';
import { FormRepresentation } from '../interfaces/formRepresentation';
import { MergeOptions } from '../interfaces/mergeOptions';
import { ResourceResolver } from '../interfaces/resourceResolver';
import { DocumentRepresentation } from '../interfaces/document';
import { Tracked } from '../types/types';
import { Resolver } from '../interfaces/resolver';
export declare const noop: () => void;
export declare const noopResolver: Resolver;
export declare const noopResourceResolver: ResourceResolver;
/**
 * Processes difference sets (created, update, delete) for between two client-side collections {@Link CollectionRepresentation}
 *
 */
export declare class ResourceMergeFactory {
    static createMerge<T extends DocumentRepresentation>(resource: T, form: FormRepresentation, options?: MergeOptions): Promise<DocumentRepresentation>;
    /**
     * A three-way merge between a form resource and existing {@link LinkedRepresentation}
     * client-side representation within the api network of data and a new {@Link LinkedRepresentation} document.
     *
     * Use option {@link EditMergeOptions.undefinedWhenNoUpdateRequired} to return undefined
     * when no update is required
     *
     * The basic merge is:
     *      1. remove any fields document representation that are not field items in the form
     *      2. merge the document into the client-side representation
     * @param resource a clean over-the-wire version
     * @param document any updates
     * @param form required to specify the merge fields
     * @param options
     */
    static editMerge<T extends Tracked | LinkedRepresentation, TForm extends FormRepresentation, TField extends Extract<keyof Omit<T, 'links'>, string>>(resource: T, document: T | DocumentRepresentation<T>, form: TForm, options?: MergeOptions): Promise<T | undefined>;
    /**
     * Makes the new document with all links and fields resolved.
     * @param document
     * @param form
     * @param {MergeOptions} options?
     * @return {Promise.<*>|Promise} containing the document updates to be merged
     * @private
     */
    private static resolveLinksAndFields;
    /**
     * A merge between the a form resource and an existing resource. It merges based on
     * both attributes and link relations in a resource
     *
     * Example One:
     *
     * form fields:
     *   'name', 'job', 'relates'
     *
     * resource:
     * {
     *    links: [
     *      { rel: 'Self', href: 'http://example.com/item/1' },
     *      { rel: 'relates', href: 'http://example.com/job/1' },
     *    ],
     *    name: 'this',
     *    job: 'that'
     *    type: '1'
     *  }
     *
     *  result:
     *  {
     *      relates: 'http://example.com/job/1',
     *      name: 'this',
     *      job: 'that'
     *  }
     *
     *
     * The resolver will match against fields and return a value. This is used
     * for example with the 'relates' attribute to return a href reference to the parent resource
     *
     * Example Two: '//types/form/collection'
     *
     * form fields:
     *   {
     *
     *    "links": [
     *        {
     *            "rel": "Self",
     *            "href": "http://localhost:1080/page/form/edit"
     *        }
     *    ],
     *    "items": [
     *        {
     *            "type": "//types/form/text",
     *            "name": "title",
     *            "description": "The title of the survey"
     *        },
     *        {
     *            "type": "//types/form/collection",
     *            "name": "role",
     *            "description": "An optional list of roles to be granted access to the page"
     *        }
     *    ]
     *}
     *
     * resource:
     * {
     *    links: [
     *      { rel: 'Self', href: 'http://example.com/item/1' },
     *      { rel: 'role', href: 'http://example.com/role/1' },
     *      { rel: 'role', href: 'http://example.com/role/2' },
     *    ],
     *    title: 'this',
     *  }
     *
     *  result:
     *  {
     *      role: ['http://example.com/role/1', 'http://example.com/role2']
     *      name: 'this',
     *  }
     * Example Three: '//types/form/group'
     *
     * form fields:
     *   {
     *
     *    "links": [
     *        {
     *            "rel": "Self",
     *            "href": "http://localhost:1080/page/form/edit"
     *        }
     *    ],
     *    "items": [
     *        {
     *            "type": "//types/form/text",
     *            "name": "title",
     *            "description": "The title of the survey"
     *        },
     *        {
     *
     *           "type": "//types/form/group",
     *           "name": "textBox",
     *           "items": [
     *               {
     *                   "type": "//types/form/text",
     *                   "name": "height",
     *                   "description": "The height of the text box in lines"
     *               },
     *               {
     *                   "type": "//types/form/text",
     *                   "name": "width",
     *                   "description": "The width of the text box in characters"
     *               }
     *           ],
     *           "description": "Dimensions for a text box"
     *        }
     *    ]
     *}
     * resource:
     * {
     *    links: [
     *      { rel: 'Self', href: 'http://example.com/item/1' },
     *    ],
     *    textBox: {
     *      height: 5,
     *      width: 20
     *    }
     *  }
     *
     *  result:
     *  {
     *    textBox: {
     *      height: 5,
     *      width: 20
     *    }
     *  }
     * @param resource
     * @param form
     * @param options
     * @return the resource to be created
     */
    private static merge;
}
