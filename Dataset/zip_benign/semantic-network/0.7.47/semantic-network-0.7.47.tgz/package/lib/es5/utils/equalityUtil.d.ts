import { LinkedRepresentation, RelationshipType } from 'semantic-link';
import { EqualityMatcher } from '../interfaces/collectionMergerOptions';
export declare class EqualityUtil {
    /**
     * Checks if two resource identities are the same.
     *
     * @default {@link CanonicalOrSelf}
     */
    static matches(lvalue: LinkedRepresentation, rvalue: LinkedRepresentation, relationshipType?: RelationshipType): boolean;
    /**
     * Checks if the identity and the version both match
     */
    static matchesIdAndETag(lvalue: LinkedRepresentation, rvalue: LinkedRepresentation, relationshipType: RelationshipType): boolean;
    /**
     * Checks if there is no difference in eTags (both empty also equals same)
     */
    static matchesETag(lvalue: LinkedRepresentation, rvalue: LinkedRepresentation): boolean;
}
export declare const defaultEqualityMatcher: EqualityMatcher;
