import { LinkedRepresentation, RelationshipType } from 'semantic-link';
import { ResourceQueryOptions } from '../interfaces/resourceQueryOptions';
import { ResourceAssignOptions } from '../interfaces/resourceAssignOptions';
import { Document, Nullable, Representation, Tracked } from '../types/types';
import { LoaderJobOptions } from '../interfaces/loader';
/**
 *
 */
type NameStrategy = (rel: RelationshipType | undefined, representation?: Representation | Document | undefined) => string;
export declare class NamedRepresentationFactory {
    static defaultNameStrategy: NameStrategy;
    /**
     * Manages the loading (returning) of a named resource (sub-resource collection or singleton) on a context based on
     * the {@link ResourceQueryOptions.rel}.
     *
     * Note: the naming strategy is currently not injectable but the value can be overridden {@link ResourceQueryOptions.name}
     * @see LinkRelConvertUtil.relTypeToCamel
     *
     * @see TrackedRepresentationFactory
     * @param resource context resource that has the sub-resource added (and is tracked {@link State.collection} and {@link State.singleton})
     * @param options specify the {@link ResourceQueryOptions.rel} to pick the name resource
     */
    static load<TReturn extends LinkedRepresentation, T extends LinkedRepresentation | TReturn = LinkedRepresentation, TResult extends TReturn = T extends TReturn ? T : TReturn>(resource: T, options?: ResourceQueryOptions & ResourceAssignOptions & LoaderJobOptions): Promise<Nullable<Tracked<TResult>>>;
}
export {};
