import { UriList } from '../../types/mediaTypes';
import { Uri } from 'semantic-link';
/**
 * A guard to detect whether the object is a {@link UriList}
 *
 * @param object
 * @returns whether the object is an instance on the interface
 */
export declare function instanceOfUriList(object: unknown): object is UriList;
/**
 * A guard to detect whether the object is a {@link Uri}
 *
 * @param object
 * @returns whether the object is an instance on the interface
 */
export declare function instanceOfUri(object: unknown): object is Uri;
