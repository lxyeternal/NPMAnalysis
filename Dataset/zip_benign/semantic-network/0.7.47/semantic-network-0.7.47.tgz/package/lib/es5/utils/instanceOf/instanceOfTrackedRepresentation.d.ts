import { LinkedRepresentation } from 'semantic-link';
import { Tracked } from '../../types/types';
/**
 * A guard to detect whether the object has {@link State} and is a {@link LinkedRepresentation}
 *
 * @param object
 * @returns whether the object is an instance on the interface
 */
export declare function instanceOfTrackedRepresentation<T extends LinkedRepresentation>(object: unknown | LinkedRepresentation): object is Tracked<T>;
