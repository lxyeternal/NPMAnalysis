import { AddRequestHeaderStrategy } from '../interfaces/addRequestHeaderStrategy';
import { AxiosHeaders, RawAxiosRequestHeaders } from 'axios';
import { Tracked } from '../types/types';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
/**
 * The goal is to leave all heavy lifting to the browser (ie implement caching rules). The key issue
 * here is whether to return the in-memory resource or push through to the browser request (ie xhr).
 */
export declare class RequestHeaders {
    /**
     * WARNING: if this is a CORS request that both pragma and cache-control must be registered as exposed
     *          Access-Control-Allow-Headers (otherwise failed CORS request in browser)
     *
     *          @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Request-Headers
     */
    static noCacheHeader: Partial<RawAxiosRequestHeaders | AxiosHeaders>;
    static emptyHeaders: Partial<RawAxiosRequestHeaders | AxiosHeaders>;
    static defaultStrategies: AddRequestHeaderStrategy[];
    static conditionalGetHeaders: (documentResource: Tracked) => Partial<RawAxiosRequestHeaders | AxiosHeaders>;
    /**
     * Add eTag detection for when feed items had the eTag included. Provides the request with a no-cache directive for http 1.0/1.1/2.
     *
     * Note: this directive used when a new resource based on eTag is detected the client requires the origin
     * server to provide a new resource. This is most likely to occur because of an out-of-band mechanism (ie another
     * process outside the direct context of the resource)
     *
     * In effect, this strategy mimics the "disable cache" mechanism if performing a manual intervention
     */
    static noCacheOnStaleEtagStatusHeaderStrategy(resource: Tracked, options?: ResourceFetchOptions): Partial<RawAxiosRequestHeaders | AxiosHeaders>;
    static ifNoneMatchesOnStaleEtagStatusHeaderStrategy(resource: Tracked, options?: ResourceFetchOptions): Partial<RawAxiosRequestHeaders | AxiosHeaders>;
    /**
     *  Detect that the resource has a stale 'expires' header
     */
    static noCacheOnStaleExpiresHeaderStrategy(resource: Tracked): Partial<RawAxiosRequestHeaders | AxiosHeaders>;
}
