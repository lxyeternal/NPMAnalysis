import { Resolver } from '../interfaces/resolver';
export declare class UriFieldResolver {
    /**
     * Match urls within a text field
     *
     * @example
     *  http://example.com/2
     *  https://example.com/2
     *  https://example.com/resource/2
     */
    static regExp: RegExp;
    /**
     * Look through a string and tokenise for all urls and replace using a resolver
     * @param value text string containing an urls
     * @param resolver has a map of key/values to make the replacements in the string
     */
    static resolve<T>(value: (T & string) | T, resolver: Resolver): (T & string) | T;
}
