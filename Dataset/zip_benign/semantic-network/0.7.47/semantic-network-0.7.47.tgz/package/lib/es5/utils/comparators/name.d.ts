import { Comparator } from '../../interfaces/comparator';
import { ComparableRepresentation } from '../../interfaces/comparableRepresentation';
/**
 * Simple match on the name attribute on the resources
 */
export declare const name: Comparator<ComparableRepresentation>;
