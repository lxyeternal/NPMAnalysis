import { CreateFormMergeStrategy } from '../interfaces/createFormMergeStrategy';
export declare const defaultCreateFormStrategy: CreateFormMergeStrategy;
