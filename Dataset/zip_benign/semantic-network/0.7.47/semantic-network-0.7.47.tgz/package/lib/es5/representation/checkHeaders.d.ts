import { CheckHeaderStrategy } from '../interfaces/checkHeaderStrategy';
/**
 * The goal is to leave all heavy lifting to the browser (ie implement caching rules). The key issue
 * here is whether to return the in-memory resource or push through to the browser request (ie xhr).
 */
export declare class CheckHeaders {
    static defaultStrategies: CheckHeaderStrategy[];
    /**
     * The main issue is whether "time" is up and a potential refresh is required. This calculation is the
     * last-modified + max-age. The server provides this as an absolute date in the expires header.
     */
    static checkExpiresHeaderStrategy(headers: Record<string, string>, now: Date): boolean;
    /**
     * Caters for the non-sensical situation where the Expires header is BEHIND the Date header.
     * @param headers
     */
    static checkExpiresBeforeDateHeaderStrategy(headers: Record<string, string>): boolean;
    /**
     * Looks through the 'cache-control' headers and checks for max-age and no-cache.
     */
    static checkNoCacheHeaderStrategy(headers: Record<string, string>): boolean;
    /**
     * Looks through the 'cache-control' headers and checks for expiry as the last served ('date') plus max-age being reached
     */
    static checkMaxAgeHeaderStrategy(headers: Record<string, string>, now: Date): boolean;
}
