import { CollectionRepresentation, LinkedRepresentation, Uri } from 'semantic-link';
import { Tracked } from '../types/types';
import { ResourceFactoryOptions } from '../interfaces/resourceFactoryOptions';
/**
 * A factory for performing the initial construction of tracked resources.
 *
 * This factory is responsible for performing a logical 'new' of the in memory object
 * used to represent resources. These objects have a 'state' object of type {@link State}
 * that is used to track and manage the resources.
 *
 * If the across the wire representation is available it can be provided via
 * the {@link ResourceFactoryOptions.addStateOn} property to provide an initial values
 * for the resource. If the values are not provided then the resource is marked
 * as being in the {@link Status.locationOnly} state (i.e. sparely populated).
 *
 * This factory is a pluggable strategy via the {@link ResourceFactoryOptions.makeSparseStrategy}. By
 * default, the strategy is to create new instances for every instance of a resource. Implementations
 * are provided to allowed pooled instances.
 */
export declare class SparseRepresentationFactory {
    static defaultMappedTitleAttributeName: "name";
    static defaultMappedFromFeedItemFieldName: "title";
    static defaultMappedUpdatedAttributeName: "updatedAt";
    static defaultMappedFromFeedItemUpdatedFieldName: "updated";
    static defaultMappedFromFeedItemETagFieldName: "eTag";
    /**
     * A simple facade to allow the make() method to be provided by an alternative strategy.
     *
     * @see {defaultMakeStrategy}
     */
    static make<T extends LinkedRepresentation | CollectionRepresentation>(options?: ResourceFactoryOptions): Tracked<T>;
    /**
     * Returns a {@link LinkedRepresentation} with {@link State} initialised. An initialised representation will
     * be at worst sparse with a state ({@link Status.locationOnly}, {@link Status.virtual}). At best, the representation
     * is {@link Status.hydrated} when a resource is presented that has been retrieved across the wire.
     */
    static defaultMakeStrategy<T extends LinkedRepresentation | CollectionRepresentation>(options?: ResourceFactoryOptions): Tracked<T>;
    /**
     * Create sparse items from a 'pool'. The pool is a single collection resource, which is used
     * as both a source of items and a location to store new (sparse) items.
     *
     * This strategy allows the caching of resources in a memory conservative way so that the same
     * resource is not loaded twice. More importantly this also means that if the application/user
     * has a view of those resources then the view will be the same.
     *
     * It is assumed that the pooled collection is logically backed/represented by the set of all
     * possible items, whereas the specific collection is a subset of those items.
     */
    static pooledCollectionMakeStrategy<T extends LinkedRepresentation | CollectionRepresentation>(pool: CollectionRepresentation, options?: ResourceFactoryOptions): Tracked<T>;
    /**
     * Find the first matching item in a collection. Match by URI.
     *
     * At this stage, it is really unlikely that this will ever match on eTag for identity at this point. ETag
     * checking is later on in the pipeline (ie versioning is later)
     */
    static firstMatchingFeedItem<T extends LinkedRepresentation>(collection: CollectionRepresentation<T>, id: Uri): T | undefined;
    /**
     * Create sparse item from a 'pool'. The pool is a single collection resource, which is used
     * as both a source of items and a location to store new (sparse) items.
     *
     * This strategy allows the caching of resources in a memory conservative way so that the same
     * resource is not loaded twice. More importantly this also means that if the application/user
     * has a view of those resources then the view will be the same.
     *
     * It is assumed that the pooled collection is logically backed/represented by the set of all
     * possible items, whereas the specific collection is a subset of those items.
     */
    static pooledSingletonMakeStrategy<T extends LinkedRepresentation | CollectionRepresentation>(pool: CollectionRepresentation, options?: ResourceFactoryOptions): Tracked<T>;
    private static makeHydrated;
    /**
     *  The resource is to be made as a sparse resource as there is no data provided via
     *  the {@link ResourceFactoryOptions.addStateOn} property.
     */
    private static makeSparse;
    /**
     * Make a collection (that is not pools) from members that are pools.
     */
    private static makeHydratedPoolCollection;
    /**
     * Make an item for a collection using a pool as the source for items.
     */
    private static makePooledFeedItemResource;
    /**
     * if an incoming feed item is already in the collection AND the incoming has the eTag as part of the feed
     * then check if the existing item is stale (ie stale if eTags don't match and requires fetch across the wire)
     *
     * note: combined with {@link includeItems} items with eTag changes should be refreshed
     */
    private static mergeFeedItemETag;
    /**
     *  The resource is to be made as a sparse resource as there is no data provided via
     *  the {@link ResourceFactoryOptions.addStateOn} property. Iff a link has been provided
     *  can the item be fetched from or stored into the pool.
     */
    private static makeSparsePooled;
    /**
     * Make a collection (that is not pools) from members that are pools.
     */
    private static makeHydratedPoolSingleton;
    private static mergeFeedItem;
    /**
     * Any resource requires incoming sparse representation options to be merged into existing resources. This method
     * will follow any options override mappings
     *
     * Note: in practice, this means that incoming feed will be mapped back onto the UI with new feed titles/updatedAt
     */
    private static mergeFeedItemFields;
    /**
     * Get the {@link ResourceFactoryOptions.addStateOn} data as a {@link FeedRepresentation}.
     */
    private static onAsFeedRepresentation;
}
export declare const defaultMakeStrategy: typeof SparseRepresentationFactory.defaultMakeStrategy;
export declare const pooledCollectionMakeStrategy: typeof SparseRepresentationFactory.pooledCollectionMakeStrategy;
export declare const pooledSingletonMakeStrategy: typeof SparseRepresentationFactory.pooledSingletonMakeStrategy;
