/**
 * Header dates across HTTP must be GMT formatted.
 * @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Last-Modified
 */
export declare const dateToGMTHeader: (date?: string) => string | undefined;
