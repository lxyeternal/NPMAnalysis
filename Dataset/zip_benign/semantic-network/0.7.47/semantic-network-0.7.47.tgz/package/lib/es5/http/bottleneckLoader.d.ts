import Bottleneck from 'bottleneck';
import { Loader, LoaderJobOptions, LoaderOptions } from '../interfaces/loader';
import { LoaderRequest } from '../interfaces/loaderRequest';
/**
 * Loading service to allow for rate limiting and prioritising concurrent requests and
 * being able to cancel some or all requests.
 *
 * Wraps bottleneck and axios cancellable in the background using es6 promises.
 *
 */
export declare class BottleneckLoader implements Loader {
    readonly requests: Map<string, LoaderRequest>;
    private readonly _currentOptions;
    constructor(options?: LoaderOptions);
    /**
     */
    static get defaultOptions(): LoaderOptions;
    /**
     * @see {@link Bottleneck.on}
     * @return {{EMPTY: string, IDLE: string, DROPPED: string, DEPLETED: string, DEBUG: string, ERROR: string}}
     */
    static get event(): LoaderOptions;
    private _limiter;
    /**
     * Access to the limiter. Chain the methods of this instance if you require it
     *
     * @example loader.limiter.on(loader.event.DEBUG, () => {});
     * @example itemsInQueue = loader.limiter.queued();
     * @example loader.limiter.schedule( ...
     */
    get limiter(): Bottleneck;
    /**
     * Current options in the limiter
     */
    get currentOptions(): Bottleneck.ConstructorOptions;
    /**
     * Make a new limiter with the options
     */
    static limiterFactory(options: Bottleneck.ConstructorOptions): Bottleneck;
    /**
     * This method wraps the limiter scheduler because it cannot deal with multiple requests at the same time on
     * the same 'id'. This queues up subsequent requests and then resolves them upon the original request.
     *
     * This is primarily used for GET requests.
     *
     * Note: this is a naive implementation of queue clearing.
     *
     * TODO: cancelled promises need to be cleared out of this queue too
     *
     * @see https://github.com/SGrondin/bottleneck/issues/68
     *
     */
    schedule<T>(id: string, action: () => Promise<T>, options?: LoaderJobOptions | undefined): Promise<T>;
    /**
     * This method wraps the limiter scheduler.
     *
     * This is primarily used for POST, PUT, PATCH, DELETE requests
     */
    submit<T>(action: () => PromiseLike<T>, options?: LoaderJobOptions | undefined): Promise<T>;
    /**
     * Stop all current and pending requests and reset all queues.
     */
    clearAll(): Promise<void>;
    getRequest(id: string): LoaderRequest | undefined;
}
declare const bottleneckLoader: BottleneckLoader;
export { bottleneckLoader };
