import { CollectionRepresentation, LinkedRepresentation } from 'semantic-link';
import { ResourceQueryOptions } from '../interfaces/resourceQueryOptions';
import { Nullable, Tracked } from '../types/types';
export declare class RepresentationUtil {
    /**
     * Return the list of keys as a typed array from a representation.
     *
     *  see https://fettblog.eu/typescript-better-object-keys/
     *  see https://stackoverflow.com/questions/52856496/typescript-object-keys-return-string
     *
     * @param representation representation object
     * @returns array of all the field property keys
     */
    static properties<T extends LinkedRepresentation | Partial<T>, TField extends Omit<Extract<keyof T, string>, 'links'>>(representation: T): TField[];
    static getProperty<T, K extends Extract<keyof T, string>>(o: T, propertyName: K | string): T[K];
    /**
     * Finds (by OR) a resource item in a collection identified through a found link relation or resource attribute
     * that matches an item in the collection items.
     *
     * It looks for items:
     *
     *   1. matching link relation (default: Self) by uri
     *   2. field attribute (default: name ({@link TrackedRepresentationFactory.mappedTitleAttributeName}) on a resource by string
     *   3. link selector
     *
     */
    static findInCollection<T extends LinkedRepresentation>(collection: CollectionRepresentation<T>, options?: ResourceQueryOptions): Nullable<T>;
    static fields<T extends LinkedRepresentation | Partial<T>, TField extends Omit<Extract<keyof T, string>, 'links'>>(representation: T): TField[];
    /**
     * Removes the item from the collection by matching its Self link. If not found, it returns undefined.
     */
    static removeItemFromCollection<T extends LinkedRepresentation>(collection: CollectionRepresentation<T> | Tracked<CollectionRepresentation<T>>, item: T): T | undefined;
    /**
     * Removes the item from the collection by matching its Self link. If not found, returns undefined.
     */
    static addItemToCollection<T extends LinkedRepresentation>(collection: CollectionRepresentation<T>, item: T): CollectionRepresentation<T>;
    /**
     * Returns the first item from a collection
     *
     * @obsolete this should never be used but rather look for the 'current' on links and return resource
     */
    static current<T extends LinkedRepresentation>(collection: Nullable<CollectionRepresentation<T>>): T | undefined;
}
