import { Document, Representation, Tracked } from '../types/types';
import { DocumentRepresentation } from '../interfaces/document';
import { StrategyType } from '../interfaces/sync/types';
import { SyncOptions } from '../interfaces/sync/syncOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
/**
 * Sync resources between two networks of data
 *
 * There six scenarios:
 *
 *  key:  x - undefined
 *        + - specified
 *  [empty] - not required
 *
 *                         options                    resource                 document
 *                     rel    relOnDocument     singleton  collection   singleton  collection
 *  1.                  x        x                 +                        +
 *  2.                  +        +
 *  3.                  x        x                 +                        +
 *  4.                  +        x                                          +
 *  5.                  x        x                             +                      +
 *  6.                  +        x                                                    +
 *
 *
 * Strategy One
 * ============
 *
 * Retrieves a resource and synchronises (its attributes) from the document
 *
 * Note: this is used for syncing two documents through their parents
 *
 *
 * @example
 *
 *     Resource               Document
 *
 *                  sync
 *     +-----+                +-----+
 *     |     |  <-----------+ |     |
 *     |     |                |     |
 *     +-----+                +-----+
 *
 *
 * Strategy Two
 * ============
 *
 * Retrieves a singleton resource on a parent resource and updates (its
 * attributes) based on a singleton of the same name in the given parent document.
 *
 * The parent maybe either a collection resource or a singleton resource
 *
 * Note: this is used for syncing two documents through their parents
 *
 * @example
 *
 *
 *     parent     singleton           singleton   parent
 *     Resource    Resource            Document   Document
 *
 *     +----------+                            +---------+
 *     |          |            sync            |         |
 *     |          +-----+                +-----+         |
 *     |     Named|     |  <-----------+ |     |Named    |
 *     |          |     |                |     |         |
 *     |          +-----+                +-----+         |
 *     |          |                            |         |
 *     |          |                       ^    |         |
 *     +----------+                       |    +---------+
 *                                        |
 *                                        +
 *                                        looks for
 *
 * Strategy Three
 * ==============
 *
 *
 * Retrieves a resource item from a resource collection and synchronises (its attributes) from the document.
 *
 * @example
 *
 *     resource
 *     Collection         Document
 *
 *     +-----+
 *     |     |
 *     |     |
 *     +-----+    sync
 *         X                +---+
 *         X  <-----------+ | x |
 *         X                +---+
 *           items
 *
 * Strategy Four
 * =============
 *
 *
 * Retrieves a parent resource and its named collection with items (sparsely populated), finds the item in that
 * collection and then synchronises (its attributes) with the document.
 *
 *  @example
 *
 *      parent      resource
 *      Resource    Collection        Document
 *
 *      +----------+
 *      |          |
 *      |          +-----+
 *      |     Named|     |
 *      |          |     |
 *      |          +-----+    sync
 *      |          |   X                +---+
 *      |          |   X  <-----------+ | x |
 *      +----------+   X                +---+
 *                       items
 *
 * Strategy Five
 * =============
 *
 *
 * Retrieves a collection resource with items (sparsely populated), then synchronises the
 * collection items where each item may be updated (its attributes), a new item created or an item removed.
 *
 *  @example
 *
 *     resource              document
 *     Collection            Collection
 *
 *
 *                  sync
 *     +-----+                +-----+
 *     |     |  <-----------+ |     |
 *     |     |                |     |
 *     +-----+                +-----+
 *         X                     X
 *         X items               X items
 *         X                     X
 *
 *
 * Strategy Six
 * ============
 *
 * Retrieves a parent resource and its named collection with items (sparsely populated), then synchronises the
 * collection items where each item may be updated (its attributes), a new item created or an item removed.
 *
 * This method is used when you have context of one parent and the document collection
 *
 *  @example
 *
 *      parent     resource              document
 *      Resource   Collection            Collection
 *
 *     +----------+
 *     |          |            sync
 *     |          +-----+                +-----+
 *     |     Named|     |  <-----------+ |     |
 *     |          |     |                |     |
 *     |          +-----+                +-----+
 *     |          |   X                     X
 *     |          |   X items               X items
 *     +----------+   X                     X
 *
 *
 *
 * @param resource
 * @param document
 * @param strategies
 * @param options
 */
export declare function syncResource<T extends Representation, U extends Document>(resource: Tracked<T> | T, document: DocumentRepresentation<U> | U, strategies?: StrategyType[], options?: SyncOptions & ResourceFetchOptions & HttpRequestOptions): Promise<T>;
