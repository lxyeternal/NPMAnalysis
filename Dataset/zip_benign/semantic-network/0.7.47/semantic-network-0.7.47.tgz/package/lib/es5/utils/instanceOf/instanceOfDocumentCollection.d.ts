import { DocumentRepresentation } from '../../interfaces/document';
export declare function instanceOfDocumentCollection(obj: unknown): obj is DocumentRepresentation;
