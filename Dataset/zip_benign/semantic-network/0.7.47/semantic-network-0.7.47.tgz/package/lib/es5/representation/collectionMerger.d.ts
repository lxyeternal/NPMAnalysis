import { CollectionRepresentation } from 'semantic-link';
import { ResourceAssignOptions } from '../interfaces/resourceAssignOptions';
import { CollectionMergerOptions } from '../interfaces/collectionMergerOptions';
/**
 * A helper class for manipulating items in a {@link CollectionRepresentation.items}.
 */
export declare class CollectionMerger {
    /**
     * Update existing items in the lvalue that are in the rvalue.
     * Returns the lvalue (mutated).
     *
     * The equality operator is {@link CanonicalOrSelf}.
     */
    static updateItems<T extends CollectionRepresentation>(lvalue: T, rvalue: T, options?: ResourceAssignOptions & CollectionMergerOptions): T;
    /**
     * Omit items in the lvalue that are not in the rvalue.
     * Returns the lvalue (mutated).
     *
     * This method splices (mutates) the {@link CollectionRepresentation.items} in order to retain bindings if they exist.
     *
     * The equality operator is {@link CanonicalOrSelf}.
     */
    static omitItems<T extends CollectionRepresentation>(lvalue: T, rvalue: T, options?: ResourceAssignOptions & CollectionMergerOptions): T;
    /**
     * Extract items in the rvalue that are not in the lvalue to extend the lvalue.
     * Returns the lvalue (mutated).
     *
     * This method splices (mutates) the {@link CollectionRepresentation.items} in order to retain bindings if they exist.
     *
     * The equality operator is {@link canonicalOrSelf}.
     */
    static extractItems<T extends CollectionRepresentation>(lvalue: T, rvalue: T, options?: ResourceAssignOptions & CollectionMergerOptions): T;
    /**
     * Return a lvalue
     *  1. items that
     *   - only has items found in rvalue
     *   - where the lvalue already had a value leave the original lvalue item in place.
     *  2. links in the lvalue with any new rvalue links [optional]
     *
     *  The equality operator is {@link canonicalOrSelf}.
     *
     * Note: the identity operator does not need to know about state
     */
    static merge<T extends CollectionRepresentation>(lvalue: T, rvalue: T, options?: ResourceAssignOptions & CollectionMergerOptions): T;
}
