import { LinkType, RelationshipType } from 'semantic-link';
import { AxiosRequestConfig, AxiosResponse } from 'axios';
export declare function defaultGetFactory<T>(link: LinkType, rel: RelationshipType, options?: AxiosRequestConfig): Promise<AxiosResponse<T>>;
