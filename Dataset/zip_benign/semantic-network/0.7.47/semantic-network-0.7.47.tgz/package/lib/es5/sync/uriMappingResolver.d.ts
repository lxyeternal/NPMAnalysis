import { Uri } from 'semantic-link';
import { Resolver } from '../interfaces/resolver';
/**
 * A resolving cache of key/value mapping to/from a network of data URI to/from a document URI.
 *
 * We use this to resolve transitive references in a network of data when creating, updating and deleting.
 * For example, we are cloning a resource that is linked to another resource. In the new resource, it is not
 * linked to the original other resource but to the equivalent other. We need to be to map these going forward.
 *
 * @example
 *
 * Document: A exists, B references A
 * NOD: Create A` (hold reference A` through A), Create B` (but now B` references A, replace A with A`)
 *
 */
declare class UriMappingResolver implements Resolver {
    private readonly resolutions;
    constructor();
    /**
     * Update a mapping to/from a network of data (NOD) URI to/from a document URI.
     */
    update(documentUri: Uri, resolvedUri: Uri): void;
    /**
     * Add a mapping to/from a network of data (NOD) URI to/from a document URI.
     */
    add(documentUri: Uri, resolvedUri: Uri): void;
    /**
     * Signal to the resolver that a mapping is no longer relevant.
     * Remove based on the document URI a mapping to/from a network of data (NOD) URI to/from a document URI.
     */
    remove(documentUri: Uri): void;
    /**
     * Returns the network of data (NOD) URI based on a document URI or if not found itself
     */
    resolve(documentUri: Uri): Uri;
    /**
     * Helper to print out the resolutions map
     * @returns stringified JSON version of the resolutions map
     */
    out(): string;
}
export declare const uriMappingResolver: UriMappingResolver;
export {};
