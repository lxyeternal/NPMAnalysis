import { CollectionRepresentation, LinkedRepresentation, RelationshipType } from 'semantic-link';
import { ApiOptions } from '../interfaces/apiOptions';
import { DocumentRepresentation } from '../interfaces/document';
export declare class SearchUtil {
    /**
     * Create or get a tracked resource that is a collection to store search collections. It
     * is likely (but not required) that the resource is backed by a 'real' resource.
     *
     * This can be used to store search results in an ad-hoc manner where the search
     * result doesn't have to have a name. The 'self' link of the search result can be used
     * to identify what the search was (and should be unique).
     */
    static makePooledCollection<T extends LinkedRepresentation, TKey extends keyof T & string, TResult extends LinkedRepresentation>(context: T, options?: ApiOptions): CollectionRepresentation<TResult>;
    /**
     *
     * Return a search result collection that is a tracked resource collection on the context collection.
     *
     * Each time this is called the new search result is merged into the search result collection that can
     * be bound to the view.
     *
     * With each call, the pooled search collection will use existing items or fetch new ones to minimise the
     * across the wire calls.
     *
     * The default implementation will create a '.pooled-search' sub-collection that can be view in devtool
     *
     * @param context resource that has the search collection as a link relation
     * @param document the search fields that will be used for the search (and is merged into the create/search form)
     * @param options
     */
    static search<T extends LinkedRepresentation = LinkedRepresentation>(context: CollectionRepresentation<T>, document: DocumentRepresentation, options?: ApiOptions): Promise<CollectionRepresentation<T>>;
    /**
     * In-place add to a (search) collection a new item. This is used where the current list is being added to independently
     * of a newly added collection without returning the entire search collection
     *
     * @default equalityMatch {@link CanonicalOrSelf}
     */
    static update<T extends LinkedRepresentation = LinkedRepresentation>(collection: CollectionRepresentation<T>, item: T, equalityMatch?: RelationshipType): void;
}
