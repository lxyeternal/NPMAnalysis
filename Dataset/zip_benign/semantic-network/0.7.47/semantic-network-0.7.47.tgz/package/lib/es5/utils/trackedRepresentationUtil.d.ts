import { LinkedRepresentation } from 'semantic-link';
import { StandardResponseHeader, Tracked } from '../types/types';
import { State } from '../representation/state';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { ResourceAssignOptions } from '../interfaces/resourceAssignOptions';
export declare class TrackedRepresentationUtil {
    /**
     * Return back the internal {@link State} object for tracking and introspection
     * @param resource
     */
    static getState<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): State;
    /**
     * Set the headers inside the internal {@link State} object for tracking and introspection
     */
    static setHeaders<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U, headers: Record<StandardResponseHeader | string, string>): State;
    /**
     * Helper to set resource to {@link Status.stale}  so that the cache forces need fetch
     */
    static setStateStale<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): void;
    /**
     * Helper to set resource to {@link Status.staleFromETag} so that the cache forces need fetch
     */
    static setStateStaleFromETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): void;
    /**
     * Looks through into the {@link State} headers for the ETag
     */
    static getETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): string | undefined;
    /**
     * Looks through into the {@link State} headers for the ETag
     */
    static getFeedETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): string | undefined;
    /**
     * Looks through into the {@link State} headers for the 'last-modified'
     */
    static getFeedLastModified<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): string | undefined;
    /**
     * Sets the value of the feed eTag and if null is provided, it is cleared
     */
    static setFeedETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U, eTag?: string, lastModified?: string): void;
    /**
     * Checks if an eTag exists based on looking through into the {@link State} headers for the ETag
     */
    static hasETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): boolean;
    /**
     * Checks if an eTag exists based on looking through into the {@link State} headers for the ETag
     */
    static hasFeedETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): boolean;
    /**
     * Checks if the header eTag matches the feed eTag. It is deemed stale when both eTags are present and different
     * suggesting that the latest is not present
     */
    static hasStaleFeedETag<T extends LinkedRepresentation, U extends Tracked<T>>(resource: U): boolean;
    /**
     * Checks the named child object is tracked on the resource.
     *
     * A resource keeps a set of child singletons and a set of child collections. This utility
     * provides a logical 'in' operator on those sets.
     *
     * Note: field name ideally comes in as K only, but in practice it also needs to be dealt with as arbitrary string
     *       as soon as it is known to be a tracked representation then it can cast string to K (rather than deal with
     *       string in the subsequent methods
     */
    static isTracked<T extends Tracked<LinkedRepresentation> | LinkedRepresentation | Partial<LinkedRepresentation>, K extends keyof T = keyof T>(resource: T, name: K | string): boolean;
    /**
     * Checks the resource is currently tracked in either as a singleton or a collection
     */
    static getTrackedFields<T extends Tracked<LinkedRepresentation> | LinkedRepresentation, K extends keyof T>(resource: T): K[];
    /**
     * Checks whether the resource requires an across-the-wire fetch based on the state flags.
     *
     * We can only do a fetch when we actually have a potentially valid uri and that we haven't already
     * got the resource. Currently, the forceLoad allows an override which is an initial cache busting
     * strategy that will need improvement
     *
     * Simple cache bust strategy which is an override switch. To be expanded as needed. Currently, only
     * cache bust on {@link Status.hydrated} resources. There is no time-based, refresh strategy at this point.
     *
     */
    static needsFetchFromState<T extends Tracked<LinkedRepresentation>>(resource: T, options?: ResourceFetchOptions): boolean;
    /**
     * Respects conditional headers from the server on whether to push back through the application cache. Without it,
     * client developers use {@link ResourceFetchOptions.forceLoad} option too often because requests do not respect the server cache-control
     * headers.
     *
     * Note: this code will not attempt to reimplement request headers (that is what browsers already do). However, what
     *       you may find is inconsistent behaviours between browsers on request cache control headers
     *
     *       @see https://gertjans.home.xs4all.nl/javascript/cache-control.html
     */
    static needsFetchFromHeaders<T extends Tracked<LinkedRepresentation>>(resource: T, options?: ResourceFetchOptions): boolean;
    /**
     *
     * Returns target.
     *
     * @param target
     * @param prop
     * @param resource
     * @param options
     */
    static add<T extends LinkedRepresentation, U extends LinkedRepresentation>(target: T, prop: keyof T | string, resource: U, options?: ResourceAssignOptions): T;
    private static setState;
    /**
     * Checks the resource is currently tracked as a singleton
     */
    private static isSingletonTracked;
    /**
     * Checks the resource is currently tracked as a collection
     */
    private static isCollectionTracked;
}
