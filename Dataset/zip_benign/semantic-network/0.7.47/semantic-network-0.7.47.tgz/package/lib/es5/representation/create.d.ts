import { LinkedRepresentation, LinkType } from 'semantic-link';
import { Tracked } from '../types/types';
import { ResourceQueryOptions } from '../interfaces/resourceQueryOptions';
import { ResourceLinkOptions } from '../interfaces/resourceLinkOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { ResourceFactoryOptions } from '../interfaces/resourceFactoryOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { DocumentRepresentation } from '../interfaces/document';
import { ResourceCreateOptions } from '../interfaces/resourceCreateOptions';
/**
 * A subset of the {@link ApiOptions} that are appropriate for a HTTP POST.
 *
 * @see ApiOptions
 */
export type ApiCreateOptions = ResourceCreateOptions & ResourceFactoryOptions & ResourceQueryOptions & ResourceLinkOptions & HttpRequestOptions & ResourceFetchOptions;
/**
 *
 * TODO: accept but don't require TrackedRepresentation interface
 *
 * @throws HttpRequestError
 */
export declare function create<T extends LinkedRepresentation, TResult extends LinkedRepresentation = T>(document: DocumentRepresentation<T> | Tracked<T> | LinkType, options?: ApiCreateOptions): Promise<TResult | undefined>;
