import { LinkedRepresentation, RelationshipType } from 'semantic-link';
import { Nullable, Tracked } from '../types/types';
import { PooledCollectionOptions } from '../interfaces/pooledCollectionOptions';
export declare class PooledResourceUtil {
    /**
     * Used for provisioning a pooled resource. Based on
     * the differences it will resolve a resource and may create one in the process.
     *
     * A pooled collection lives outside of the current context that needs to be resolved. Examples similar to this
     * in other contexts are called meta-data or static collections. The main point is that resources from the pooled collection
     * are used by reference in the current collection.
     *
     * When pooled collection is read-only then no resources may be added from other contexts.
     *
     */
    static sync<T extends LinkedRepresentation>(context: T, aDocument: T, options?: PooledCollectionOptions): Promise<Nullable<T>>;
    /**
     * Retrieves a resource from a named resource from the context of a given resource.
     *
     * @return {Promise<string>} containing the uri resource {@link LinkedRepresentation}
     */
    static get<T extends LinkedRepresentation, TResult extends LinkedRepresentation>(resource: T | Tracked<T>, collectionName: string, collectionRel: RelationshipType, resourceDocument: TResult, options?: PooledCollectionOptions): Promise<TResult | undefined>;
}
