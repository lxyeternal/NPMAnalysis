import { LinkedRepresentation } from 'semantic-link';
import { DocumentRepresentation } from '../interfaces/document';
import { FormItem } from '../interfaces/formItem';
import { MergeOptions } from '../interfaces/mergeOptions';
import { FormRepresentation } from '../interfaces/formRepresentation';
import { FieldValue, ResourceValue } from '../interfaces/fieldResolver';
export declare class FieldResolverUtil {
    /**
     * Recursive, resolving merger that adds fields to a document based on a (create or edit) form
     * and the allowed fields with their type.
     *
     * Note: field names are converted to tracked names
     */
    static resolveFields<T extends DocumentRepresentation, TForm extends FormRepresentation, TField extends Extract<keyof T, string>>(document: DocumentRepresentation, form: TForm, options?: MergeOptions): Promise<DocumentRepresentation>;
    /**
     * Takes an incoming polymorphic field ({@link SimpleValue}, {@link UriListValue} or {@link ResourceValue}) and
     * checks if its value is valid against the form. To do this, it will also resolve fields if necessary.
     *
     * Resolutions are performed via injected {@link MergeOptions.resolver} and {@link MergeOptions.resourceResolver}
     *
     * @param fieldValue
     * @param item
     * @param options?
     */
    static resolve<T extends FieldValue>(fieldValue: T, item: FormItem, options?: MergeOptions): Promise<T | undefined>;
    /**
     * Resolves any {@link FormItem.id} as a {@link LinkedRepresentation} when there is a {@link MergeOptions.resourceResolver}.
     *
     * Note:
     *  - current strategy to resolve on the title of the Canonical on the field value.
     *  - there is no placement of the resolution onto the item
     *
     * @param formItem form item to process for resolution
     * @param fieldValue
     * @param options
     */
    static resolveResource<T extends ResourceValue>(fieldValue: T, formItem: FormItem, options?: MergeOptions): Promise<T>;
    /**
     *
     * Strategy is to resolve the lookup key as the title from the Canonical link relation
     * @param resource field resource being resolved
     */
    static resourceResolverRelNameStrategy(resource: LinkedRepresentation): string | undefined;
    /**
     * If a {@link MergeOptions.resolver} has been provided then there is potentially a pooled resource available
     * requiring resolution
     *
     * @param fieldValue
     * @param item
     * @param options contains the resolver to be used
     */
    static resolveByPooled<T extends FieldValue>(fieldValue: T, item: FormItem, options?: MergeOptions): Promise<FieldValue>;
    /**
     *
     * @param fieldValue
     * @param formItem
     * @param options
     */
    static resolveByType<T extends FieldValue>(fieldValue: T, formItem: FormItem, options?: MergeOptions): Promise<T | undefined>;
    /**
     * Matches a field value against the form items switching across {@link FieldValue} type.
     *
     *  - {@link SimpleValue} - look through the list by value
     *  - {@link UriListValue} - look across the list by value
     *  - {@link ResourceValue} - look into the resource's {@link LinkRelation.Canonical} to locate the 'title'
     *
     * @param formItem a form item (with items eager loaded)
     * @param fieldValue
     * @param options
     */
    private static findValueInItems;
}
