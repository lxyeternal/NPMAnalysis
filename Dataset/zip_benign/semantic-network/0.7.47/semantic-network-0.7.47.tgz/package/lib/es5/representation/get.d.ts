import { LinkedRepresentation } from 'semantic-link';
import { ResourceQueryOptions } from '../interfaces/resourceQueryOptions';
import { ResourceLinkOptions } from '../interfaces/resourceLinkOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { ResourceMergeOptions } from '../interfaces/resourceAssignOptions';
import { ResourceFactoryOptions } from '../interfaces/resourceFactoryOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { ResourceUpdateOptions } from '../interfaces/resourceUpdateOptions';
import { Nullable, Tracked } from '../types/types';
import { LoaderJobOptions } from '../interfaces/loader';
/**
 * A subset of the {@link ApiOptions} that are appropriate for a HTTP GET.
 *
 * @see ApiOptions
 */
export type ApiGetOptions = ResourceFactoryOptions & ResourceQueryOptions & ResourceLinkOptions & HttpRequestOptions & ResourceMergeOptions & ResourceFetchOptions & ResourceUpdateOptions & LoaderJobOptions;
/**
 * Retrieve a resource based on its context and options, and its current state (ie hydrated or not)
 *
 * Note: a returned resource will not always be the same (ie self) but rather a different linked resource.
 *
 * TODO: where 'named' resources are known, return that type based on the 'rel' in options.
 */
export declare function get<TReturn extends LinkedRepresentation, T extends LinkedRepresentation | TReturn = LinkedRepresentation, TResult extends TReturn = T extends TReturn ? T : TReturn>(resource: T | Tracked<T>, options?: ApiGetOptions): Promise<Nullable<TResult | Tracked<TResult>>>;
