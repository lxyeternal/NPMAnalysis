import { FormRepresentation } from '../interfaces/formRepresentation';
import { ApiOptions } from '../interfaces/apiOptions';
export declare class FormRepresentationUtil {
    /**
     *  Walks a form (items) and loads any collections
     *
     *  @example
     *
     *   {
     *     "links": [
     *       {
     *         "rel": "self",
     *         "href": "http://localhost:5000/field/o/a656927b0f/form/create"
     *       }
     *     ],
     *     "items": [
     *       {
     *         "type": "//types/form/select",
     *         "name": "field",
     *         "label": "Template Field",
     *         "required": true,
     *         "items": [
     *           {
     *             id: "http://localhost:5000/organisation/4ed8e42224/information/listing/template"
     *             label: "Listing"
     *             type: "//types/form/collection"
     *             items: null -->
     *                [
     *                    "links": [{
     *                      ...
     *                    }],
     *                    "name": "GivenName",
     *                    "label": Given name (Listing),
     *                    "order": 1,
     *                    categories: ['listing']
     *                  },
     *                ]
     *       },
     *     ]
     *   }
     */
    static getFieldCollection(form: FormRepresentation, options?: ApiOptions): Promise<FormRepresentation>;
}
