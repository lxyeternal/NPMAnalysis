import { DocumentRepresentation } from '../../interfaces/document';
export declare function instanceOfDocumentRepresentation(obj: unknown): obj is DocumentRepresentation;
