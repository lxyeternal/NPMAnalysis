import { LinkedRepresentation } from 'semantic-link';
import { MergeOptions } from '../interfaces/mergeOptions';
import { FormRepresentation } from '../interfaces/formRepresentation';
export declare class FieldLinksResolverUtil {
    /**
     * On a resource, iterate through all the link relations that match the form items and resolve the reference
     * to a value and attach onto the original resource.
     *
     * Note: while this treats a link rel as a uri-list, it doesn't current support multiple resolutions
     */
    static resolveLinks<T extends LinkedRepresentation | Partial<T>, TForm extends FormRepresentation, TField extends Extract<keyof Omit<T, 'links'>, string>>(resource: T, form: TForm, options?: MergeOptions): Promise<T | undefined>;
    /**
     * Filters all the links on the document based on the link relations and makes into a uri-list. However, based on the
     * {@link FormItem.multiple} the uri-list may be a single (text) or multiple (array) return type.
     *
     * All uris are also resolved via optional {@link MergeOptions.resolver}
     *
     * Note: the {@link FormItem.multiple} overrides the single versus multiple and will pick the head of the array to
     * return a single uri
     *
     * @param document
     * @param formItem
     * @param rel
     * @param options?
     * @returns the resolved {@link UriListValue}
     */
    private static resolveFormItemToUri;
}
