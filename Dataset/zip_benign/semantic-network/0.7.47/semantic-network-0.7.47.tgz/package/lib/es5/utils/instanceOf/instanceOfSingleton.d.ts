import { LinkedRepresentation } from 'semantic-link';
import { SingletonRepresentation } from '../../types/types';
export declare function instanceOfSingleton(object: unknown | LinkedRepresentation): object is SingletonRepresentation;
