import { Comparator } from '../../interfaces/comparator';
import { ComparableRepresentation } from '../../interfaces/comparableRepresentation';
/**
 * Simple match on the 'id' attribute on the resources
 */
export declare const id: Comparator<ComparableRepresentation>;
