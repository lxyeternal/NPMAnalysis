import { CollectionRepresentation, LinkedRepresentation } from 'semantic-link';
/**
 * Resolution of promises across a collection. Returns when all resolutions have occurred.
 *
 * @param resource collection to iterate through all the items
 * @param iterator promise-based iterator
 */
export type PromiseWaitAll = <T extends CollectionRepresentation<U>, U extends LinkedRepresentation>(resource: T, iterator: (item: U) => Promise<void>) => Promise<void>;
/**
 * Resolution of promises across a map. Returns when all resolutions have occurred.
 *
 * @param resource collection to iterate through all the items
 * @param iterator promise-based iterator
 * @returns the array of mapped representations that have been iterated across
 */
export type PromiseMapWaitAll = <T extends CollectionRepresentation<U>, U extends LinkedRepresentation, TMap>(resource: T, iterator: (item: U) => Promise<TMap>) => Promise<TMap[]>;
/**
 * Sequential resolution of promises across a collection. Returns when all resolutions have occurred.
 *
 * @param resource collection to iterate through all the items
 * @param iterator promise-based iterator
 * @returns the array of mapped representations that have been iterated across
 * @see parallelMapWaitAll
 */
export declare const sequentialMapWaitAll: PromiseMapWaitAll;
/**
 * Parallel resolution of promises across a collection. Returns when all resolutions have occurred.
 *
 * @param resource collection to iterate through all the items
 * @param iterator promise-based iterator
 * @returns the array of mapped representations that have been iterated across
 * @see sequentialMapWaitAll
 */
export declare const parallelMapWaitAll: PromiseMapWaitAll;
/**
 * Sequential resolution of promises across a collection. Returns when all resolutions have occurred.
 *
 * @param resource collection to iterate through all the items
 * @param iterator promise-based iterator
 * @see parallelWaitAll
 */
export declare const sequentialWaitAll: PromiseWaitAll;
/**
 * Parallel resolution of promises across a collection. Returns when all resolutions have occurred.
 *
 * @param resource collection to iterate through all the items
 * @param iterator promise-based iterator
 * @see sequentialWaitAll
 */
export declare const parallelWaitAll: PromiseWaitAll;
