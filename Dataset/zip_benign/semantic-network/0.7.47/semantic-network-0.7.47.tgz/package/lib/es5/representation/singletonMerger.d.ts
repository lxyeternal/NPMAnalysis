import { ResourceAssignOptions, ResourceMergeOptions } from '../interfaces/resourceAssignOptions';
export declare const defaultOptions: ResourceMergeOptions;
export declare const createInstance: (options?: ResourceMergeOptions) => ResourceMergeOptions;
export declare const options: {
    set?<T>(object: unknown, key: string | number, value: T): T;
    set?<T_1>(array: T_1[], key: number, value: T_1): T_1;
    set?<T_2, U>(object: T_2, key: keyof T_2, value: U): T_2;
};
/**
 * A helper class for manipulating items in a {@link SingletonRepresentation}.
 */
export declare class SingletonMerger {
    /**
     * Copy the values of all the enumerable own properties from one or more source objects to a target object.
     * Returns the target object.
     *
     * @param target The target object to copy to
     * @param source The source object from which to copy properties
     * @param options
     */
    static merge<T extends object, U>(target: T, source: U, options?: ResourceMergeOptions): Extract<U, T>;
    /**
     * Adds a resource object to the target object on the named property.
     * Returns the target object
     *
     * @param target The target object to add a resource to
     * @param prop The property name to be added to the target
     * @param resource The resource object that is added to the target
     * @param options
     */
    static add<T extends object, U>(target: T, prop: keyof T | string, resource: U, options?: ResourceAssignOptions): T;
}
