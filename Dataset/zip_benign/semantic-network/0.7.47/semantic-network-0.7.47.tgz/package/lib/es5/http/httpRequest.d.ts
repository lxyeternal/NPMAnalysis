import { LinkedRepresentation, LinkType, RelationshipType } from 'semantic-link';
import { AxiosRequestConfig, AxiosResponse } from 'axios';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { DocumentRepresentation } from '../interfaces/document';
import { LoaderJobOptions } from '../interfaces/loader';
export declare class HttpRequest {
    private options;
    private readonly loader;
    constructor(options: Required<HttpRequestOptions>);
    /**
     * TODO: should probably return T | undefined
     */
    load<T extends LinkedRepresentation>(link: LinkType, rel: RelationshipType, options?: HttpRequestOptions & AxiosRequestConfig & LoaderJobOptions): Promise<AxiosResponse<T>>;
    update<T extends LinkedRepresentation>(resource: T, document: T | DocumentRepresentation<T>, options?: HttpRequestOptions & AxiosRequestConfig & LoaderJobOptions): Promise<AxiosResponse<void>>;
    create<T extends LinkedRepresentation>(resource: T, document: T | DocumentRepresentation<T>, options?: HttpRequestOptions & AxiosRequestConfig & LoaderJobOptions): Promise<AxiosResponse<T | undefined>>;
    del<T extends LinkedRepresentation>(resource: T, options?: HttpRequestOptions & AxiosRequestConfig & LoaderJobOptions): Promise<AxiosResponse<void>>;
}
