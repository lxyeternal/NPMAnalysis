import { DocumentRepresentation } from '../../interfaces/document';
export declare function instanceOfDocumentRepresentationGroup(obj: unknown): obj is DocumentRepresentation[];
