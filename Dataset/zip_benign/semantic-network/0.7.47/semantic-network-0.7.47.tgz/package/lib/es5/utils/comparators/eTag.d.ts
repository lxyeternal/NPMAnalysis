import { Comparator } from '../../interfaces/comparator';
import { Tracked } from '../../types/types';
/**
 * Simple match on the eTag in the header of a {@link Tracked}
 */
export declare const eTag: Comparator<Tracked>;
