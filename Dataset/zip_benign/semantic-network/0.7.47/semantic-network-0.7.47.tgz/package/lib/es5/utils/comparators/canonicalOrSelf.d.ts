import { RelationshipType } from 'semantic-link';
import { Comparator } from '../../interfaces/comparator';
import { ComparableRepresentation } from '../../interfaces/comparableRepresentation';
export declare const CanonicalOrSelf: RelationshipType;
/**
 * Matches on the Canonical or Self link relation on the resources
 */
export declare const canonicalOrSelf: Comparator<ComparableRepresentation>;
