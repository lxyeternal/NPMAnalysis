import { LinkType, RelationshipType } from 'semantic-link';
import { AxiosResponse } from 'axios';
export declare function defaultDeleteFactory(link: LinkType, rel: RelationshipType): Promise<AxiosResponse<void>>;
