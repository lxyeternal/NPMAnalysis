import { ResourceSync } from '../../interfaces/sync/resourceSync';
import { LinkedRepresentation } from 'semantic-link';
export declare function instanceOfResourceSync<T extends LinkedRepresentation>(obj: unknown): obj is ResourceSync<T>;
