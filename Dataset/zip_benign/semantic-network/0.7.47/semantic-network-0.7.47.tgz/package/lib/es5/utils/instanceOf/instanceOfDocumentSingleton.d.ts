import { DocumentRepresentation } from '../../interfaces/document';
export declare function instanceOfDocumentSingleton(obj: unknown): obj is DocumentRepresentation;
