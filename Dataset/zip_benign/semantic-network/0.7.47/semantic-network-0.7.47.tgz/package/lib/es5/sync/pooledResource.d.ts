import { LinkedRepresentation, RelationshipType } from 'semantic-link';
import { PooledCollectionOptions } from '../interfaces/pooledCollectionOptions';
import { ResourceResolver } from '../interfaces/resourceResolver';
import { Nullable } from '../types/types';
/**
 * On locating a sub resource, a select on a form provides the 'name' with a value which is the key of the sub resource
 * that is used to resolve the resource itself via a known link relation
 */
export type RelName = string;
export type PooledResourceResolver = <T extends LinkedRepresentation>(resource: T, options?: PooledCollectionOptions) => Promise<Nullable<T>>;
export declare abstract class PooledResource<T extends LinkedRepresentation> {
    /**
     * the home resource (or starting point) of the sub collections
     */
    protected contextResource: T | undefined;
    /**
     * A set of resolvers that map between the originating resource (eg a singleton item) to its containing resource
     * (eg a collection) in order to sync inside its containing resource on the pooled collection.
     *
     * Note: these resolvers are set in the implementing class via {@link makeResolvers}
     */
    protected resolvers: Record<RelName, PooledResourceResolver>;
    constructor(resource: T);
    get resourceResolver(): ResourceResolver;
    /**
     *
     * @param rel known link relation of the resource resolved on the pooled resource context
     * @param options
     */
    protected resolve(rel: RelationshipType, options?: PooledCollectionOptions): PooledResourceResolver;
    /**
     * Set of resolvers returning the sub collections
     */
    protected abstract makeResolvers(): Record<string, PooledResourceResolver>;
    /**
     * Default resolves returns a noop undefined
     */
    protected defaultPooledResolver: (type: string) => PooledResourceResolver;
    /**
     * Access back to the keyed resolver
     */
    private pooledResource;
}
