import { LinkedRepresentation } from 'semantic-link';
import { ResourceQueryOptions } from '../interfaces/resourceQueryOptions';
import { ResourceLinkOptions } from '../interfaces/resourceLinkOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { ResourceFactoryOptions } from '../interfaces/resourceFactoryOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { Tracked } from '../types/types';
import { ResourceDeleteOptions } from '../interfaces/resourceDeleteOptions';
/**
 * A subset of the {@link ApiOptions} that are appropriate for a HTTP DELETE.
 *
 * @see ApiOptions
 */
export type ApiDeleteOptions = ResourceDeleteOptions & ResourceFactoryOptions & ResourceQueryOptions & ResourceLinkOptions & HttpRequestOptions & ResourceFetchOptions;
/**
 *
 * TODO: accept but don't require TrackedRepresentation interface
 * @param resource
 * @param options
 * @returns removed representation or default
 */
export declare function del<T extends LinkedRepresentation>(resource: T | Tracked<T>, options?: ApiDeleteOptions): Promise<T | undefined>;
