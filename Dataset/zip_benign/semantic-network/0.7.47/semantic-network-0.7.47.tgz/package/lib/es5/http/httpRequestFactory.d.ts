import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { HttpRequest } from './httpRequest';
export declare class HttpRequestFactory {
    private static instance;
    /**
     * Factory up a version of the http request.
     *
     * If requiring a specific version, call this method to instantiate the specific singleton
     * @param options
     * @param forceNewOptions
     * @constructor
     */
    static Instance(options?: HttpRequestOptions, forceNewOptions?: boolean): HttpRequest;
}
