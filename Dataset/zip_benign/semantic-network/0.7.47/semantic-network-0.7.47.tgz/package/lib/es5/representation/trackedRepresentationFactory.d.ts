import { CollectionRepresentation, LinkedRepresentation } from 'semantic-link';
import { Tracked } from '../types/types';
import { ResourceLinkOptions } from '../interfaces/resourceLinkOptions';
import { HttpRequestOptions } from '../interfaces/httpRequestOptions';
import { ResourceQueryOptions } from '../interfaces/resourceQueryOptions';
import { ResourceMergeOptions } from '../interfaces/resourceAssignOptions';
import { ResourceFetchOptions } from '../interfaces/resourceFetchOptions';
import { DocumentRepresentation } from '../interfaces/document';
import { ResourceFactoryOptions } from '../interfaces/resourceFactoryOptions';
import { FormRepresentation } from '../interfaces/formRepresentation';
import { LoaderJobOptions } from '../interfaces/loader';
export declare class TrackedRepresentationFactory {
    /**
     * Creates (POST) a representation in the context of a resource. The resulting representation from the Location header
     * is hydrated and returned.
     *
     * Note: a 201 returns a location whereas the 200 and 202 do not and undef
     *
     * @param resource context in which a resource is created
     * @param document content of the representation
     * @param options
     * @returns a 201 returns a representation whereas the 200 and 202 return undefined
     * @throws AxiosError
     */
    static create<T extends LinkedRepresentation, TResult extends LinkedRepresentation>(resource: T | Tracked<T> | FormRepresentation, document: DocumentRepresentation, options?: ResourceFactoryOptions & ResourceQueryOptions & ResourceLinkOptions & HttpRequestOptions & ResourceFetchOptions & LoaderJobOptions): Promise<TResult | Tracked<TResult> | undefined>;
    static del<T extends LinkedRepresentation>(resource: T | Tracked<T>, options?: ResourceLinkOptions & HttpRequestOptions & ResourceMergeOptions & ResourceQueryOptions & LoaderJobOptions): Promise<T | Tracked<T>>;
    /**
     *
     * @throws
     */
    static update<T extends LinkedRepresentation>(resource: T | Tracked<T>, document: T | DocumentRepresentation<T>, options?: ResourceLinkOptions & HttpRequestOptions & ResourceMergeOptions & ResourceFetchOptions & LoaderJobOptions): Promise<T | void>;
    /**
     * Processes all the hydration rules of the {@link LinkedRepresentation} of whether or not a resource a should
     * be fetched based on its state and http headers.
     *
     * Its responsibility is to deal with the tracking of the representation.
     *
     * TODO: load would ideally NOT come in on a TrackedRepresentation but rather a LinkedRepresentation only
     *
     * @param resource existing resource
     * @param options
     */
    static load<T extends LinkedRepresentation>(resource: T | Tracked<T>, options?: ResourceLinkOptions & HttpRequestOptions & ResourceMergeOptions & ResourceQueryOptions & ResourceFetchOptions & LoaderJobOptions): Promise<T | Tracked<T>>;
    /**
     * Removes the item from the collection by matching its Self link. If not found, it returns undefined.
     * If an items is removed from a collection, it is marked as 'stale'
     */
    static removeCollectionItem<T extends LinkedRepresentation>(collection: CollectionRepresentation<T> | Tracked<CollectionRepresentation<T>>, item: T): T | undefined;
    private static mergeHeaders;
    /**
     * Updates the state object based on the error
     *
     * TODO: add client status errors to state for surfacing field validations errors
     *          - this will require an error processing factory given most system
     *            present these errors differently
     *
     * TODO: add onErrorHandling strategy (eg throw or quiet)
     */
    private static processError;
    private static processResource;
    /**
     * Ensures the in-memory collection resource and its items are up-to-date with the server with
     * the number of items matching and all items at least sparsely populated. Use 'includeItems' flag
     * to fully hydrate each item.
     */
    private static processCollection;
    private static processStaleCollectionItems;
    private static processCollectionItems;
    /**
     * Ensures the in-memory resource is up-to-date with the server. Synchronising needs to
     * occur within the context of this {@link State} object so that {@link State.status} flag of
     * the to-be-retrieved resource is in context.
     *
     * Note: singleton also processes a form and may need to be separated for deep merge of items
     */
    private static processSingleton;
}
