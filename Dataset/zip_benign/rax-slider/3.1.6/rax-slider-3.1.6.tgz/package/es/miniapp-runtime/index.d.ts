import { SliderType } from '../types';
import '../index.css';
declare const _default: SliderType;
export default _default;
