import { Component } from 'rax';
import * as PropTypes from 'prop-types';
import { SliderProps } from '../types';
import '../index.css';
declare class Slider extends Component<SliderProps, any> {
    static defaultProps: {
        horizontal: boolean;
        showsPagination: boolean;
        loop: boolean;
        autoPlay: boolean;
        autoPlayInterval: number;
        speed: number;
        cssEase: string;
        index: number;
        paginationStyle: {};
        initialVelocityThreshold: number;
        verticalThreshold: number;
        horizontalThreshold: number;
        vertical: boolean;
    };
    static propTypes: {
        onChange: PropTypes.Requireable<(...args: any[]) => any>;
        paginationStyle: PropTypes.Requireable<object>;
    };
    static Item: import("rax").ExoticComponent<{
        children?: import("rax").RaxNode;
    }>;
    static displayName: string;
    private index;
    private height;
    private width;
    private loopIdx;
    private offsetX;
    private isSwiping;
    private total;
    private swipeView;
    private childRefs;
    private isAutoPlay;
    private autoPlayTimer;
    private isInTransition;
    constructor(props: SliderProps);
    componentDidMount(): void;
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    private autoPlay;
    slideTo(index: number): void;
    private onSwipeBegin;
    private isLoopEnd;
    private onSwipe;
    private onSwipeEnd;
    private loopedIndex;
    private renderPagination;
    private getPages;
    private renderSwipeView;
    private handleTransitionEnd;
    private resetSliderIndex;
    render(): JSX.Element;
}
export default Slider;
