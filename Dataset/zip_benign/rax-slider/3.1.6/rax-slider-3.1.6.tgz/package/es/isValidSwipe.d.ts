declare const _default: (velocity: number, directionalChange: number, velocityThreshold: number, changeThreshold: number) => boolean;
export default _default;
