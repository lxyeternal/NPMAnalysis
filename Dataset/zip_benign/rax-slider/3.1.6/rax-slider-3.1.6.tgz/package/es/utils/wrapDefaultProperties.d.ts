import { SliderType } from '../types';
export default function wrapDefaultProperties(Slider: SliderType): SliderType;
