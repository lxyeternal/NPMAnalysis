import { Component } from 'rax';
import * as PropTypes from 'prop-types';
import { SwipeEventProps } from './types';
declare class SwipeEvent extends Component<SwipeEventProps, {
    swipe: any;
}> {
    static propTypes: {
        onSwipeBegin: PropTypes.Requireable<(...args: any[]) => any>;
        onSwipe: PropTypes.Requireable<(...args: any[]) => any>;
        onSwipeEnd: PropTypes.Requireable<(...args: any[]) => any>;
        swipeDecoratorStyle: PropTypes.Requireable<object>;
    };
    static defaultProps: {
        horizontal: boolean;
        vertical: boolean;
        left: boolean;
        right: boolean;
        up: boolean;
        down: boolean;
        continuous: boolean;
        initialVelocityThreshold: number;
        verticalThreshold: number;
        horizontalThreshold: number;
        setGestureState: boolean;
        handlerStyle: {};
    };
    private swipeDetected;
    private velocityProp;
    private distanceProp;
    private swipeDirection;
    private panResponder;
    constructor(props: any);
    private handleTerminationAndRelease;
    render(): JSX.Element;
}
export default SwipeEvent;
