declare let Slider: any;
export default Slider;
