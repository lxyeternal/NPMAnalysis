/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng-docx" />
export * from './public-api';
