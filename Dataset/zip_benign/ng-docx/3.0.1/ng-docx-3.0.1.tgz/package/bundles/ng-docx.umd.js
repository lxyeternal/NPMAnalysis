(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@angular/router'), require('@angular/forms'), require('@angular/material/sidenav'), require('@angular/material/icon'), require('@angular/material/button'), require('@angular/material/input'), require('@angular/material/form-field'), require('@angular/material/select'), require('@angular/material/snack-bar'), require('@angular/common/http'), require('ngx-markdown/'), require('rxjs'), require('rxjs/operators'), require('@angular/material/core'), require('mark.js')) :
    typeof define === 'function' && define.amd ? define('ng-docx', ['exports', '@angular/core', '@angular/common', '@angular/router', '@angular/forms', '@angular/material/sidenav', '@angular/material/icon', '@angular/material/button', '@angular/material/input', '@angular/material/form-field', '@angular/material/select', '@angular/material/snack-bar', '@angular/common/http', 'ngx-markdown/', 'rxjs', 'rxjs/operators', '@angular/material/core', 'mark.js'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["ng-docx"] = {}, global.ng.core, global.ng.common, global.ng.router, global.ng.forms, global.ng.material.sidenav, global.ng.material.icon, global.ng.material.button, global.ng.material.input, global.ng.material.formField, global.ng.material.select, global.ng.material.snackBar, global.ng.common.http, global.i12, global.rxjs, global.rxjs.operators, global.ng.material.core, global.Mark));
})(this, (function (exports, i0, i3, i1$1, i7, i6, i2, i2$1, i8, i4, i2$2, i5, i1, i12, rxjs, operators, i3$1, Mark) { 'use strict';

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var i3__namespace = /*#__PURE__*/_interopNamespace(i3);
    var i1__namespace$1 = /*#__PURE__*/_interopNamespace(i1$1);
    var i7__namespace = /*#__PURE__*/_interopNamespace(i7);
    var i6__namespace = /*#__PURE__*/_interopNamespace(i6);
    var i2__namespace = /*#__PURE__*/_interopNamespace(i2);
    var i2__namespace$1 = /*#__PURE__*/_interopNamespace(i2$1);
    var i8__namespace = /*#__PURE__*/_interopNamespace(i8);
    var i4__namespace = /*#__PURE__*/_interopNamespace(i4);
    var i2__namespace$2 = /*#__PURE__*/_interopNamespace(i2$2);
    var i5__namespace = /*#__PURE__*/_interopNamespace(i5);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
    var i12__namespace = /*#__PURE__*/_interopNamespace(i12);
    var i3__namespace$1 = /*#__PURE__*/_interopNamespace(i3$1);
    var Mark__default = /*#__PURE__*/_interopDefaultLegacy(Mark);

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2)
            for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                    if (!ar)
                        ar = Array.prototype.slice.call(from, 0, i);
                    ar[i] = from[i];
                }
            }
        return to.concat(ar || from);
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }

    var UtilsService = /** @class */ (function () {
        function UtilsService() {
        }
        UtilsService.prototype.copyOnClipboard = function (textToCopy) {
            var elSelected = document.createElement('textarea');
            elSelected.value = textToCopy;
            document.body.appendChild(elSelected);
            elSelected.select();
            document.execCommand('copy');
            document.body.removeChild(elSelected);
        };
        UtilsService.prototype.getHashURL = function () {
            return parseInt(window.location.hash.replace('#', ''), 10);
        };
        UtilsService.prototype.getURLWithoutHash = function () {
            var url = new URL(window.location.toString());
            url.hash = '';
            return url.toString();
        };
        UtilsService.prototype.nextUntil = function (elem, selector, filter) {
            if (filter === void 0) { filter = null; }
            var siblings = [];
            elem = elem.nextElementSibling;
            while (elem) {
                if (elem.matches(selector)) {
                    break;
                }
                if (filter && !elem.matches(filter)) {
                    elem = elem.nextElementSibling;
                    continue;
                }
                siblings.push(elem);
                elem = elem.nextElementSibling;
            }
            return siblings;
        };
        UtilsService.prototype.groupBy = function (collection, key) {
            return collection.reduce(function (rv, x) {
                if (x) {
                    (rv[x[key]] = rv[x[key]] || []).push(x);
                }
                return rv;
            }, {});
        };
        return UtilsService;
    }());
    UtilsService.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: UtilsService, deps: [], target: i0__namespace.ɵɵFactoryTarget.Injectable });
    UtilsService.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: UtilsService, providedIn: 'root' });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: UtilsService, decorators: [{
                type: i0.Injectable,
                args: [{
                        providedIn: 'root'
                    }]
            }], ctorParameters: function () { return []; } });

    var FileSystemService = /** @class */ (function () {
        function FileSystemService(http, utils) {
            this.http = http;
            this.utils = utils;
            this.docsSubject = new rxjs.BehaviorSubject(null);
            this.navigationMenuSubject = new rxjs.BehaviorSubject(null);
            this.docs$ = this.docsSubject.asObservable();
            this.navigationMenu$ = this.navigationMenuSubject.asObservable();
        }
        FileSystemService.prototype.loadDocs = function (docsDir, docNames) {
            var _this = this;
            rxjs.forkJoin(this.getDocs(docsDir, docNames)).subscribe(function (docs) {
                _this.navigationMenuSubject.next(_this.createNavigationMenu(docs));
                _this.docsSubject.next(_this.utils.groupBy(docs, 'folder'));
            });
        };
        FileSystemService.prototype.getDocs = function (docsDir, docNames) {
            var _this = this;
            var docs$ = [];
            docNames.map(function (docName) { return __awaiter(_this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    if (typeof docName === 'string') {
                        docs$.push(this.readFile(docsDir, docName));
                    }
                    else {
                        Object.keys(docName).forEach(function (folderName) { return __awaiter(_this, void 0, void 0, function () {
                            var _this = this;
                            return __generator(this, function (_a) {
                                docName[folderName].map(function (title) {
                                    docs$.push(_this.readFile("" + docsDir + folderName + "/", title, folderName));
                                });
                                return [2 /*return*/];
                            });
                        }); });
                    }
                    return [2 /*return*/];
                });
            }); });
            return docs$;
        };
        FileSystemService.prototype.readFile = function (docsDir, docName, folderName) {
            if (folderName === void 0) { folderName = null; }
            return this.http.get("" + docsDir + docName + ".md", { responseType: 'text' }).pipe(operators.map(function (docContent) {
                return {
                    title: docName,
                    content: docContent,
                    folder: folderName
                };
            }), operators.catchError(function () {
                return rxjs.of(null);
            }));
        };
        FileSystemService.prototype.createNavigationMenu = function (docs) {
            var navigationMenu = [];
            var folderAlreadyPushed = [];
            var groupedDocs = this.utils.groupBy(docs, 'folder');
            docs.forEach(function (doc) {
                if (doc) {
                    if (doc.folder && !folderAlreadyPushed.some(function (folder) { return folder === (doc === null || doc === void 0 ? void 0 : doc.folder); })) {
                        var folder = {};
                        folder[doc.folder] = groupedDocs[doc.folder];
                        navigationMenu.push(folder);
                        folderAlreadyPushed.push(doc.folder);
                    }
                    else if (!doc.folder) {
                        navigationMenu.push(doc);
                    }
                }
            });
            return navigationMenu;
        };
        return FileSystemService;
    }());
    FileSystemService.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: FileSystemService, deps: [{ token: i1__namespace.HttpClient }, { token: UtilsService }], target: i0__namespace.ɵɵFactoryTarget.Injectable });
    FileSystemService.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: FileSystemService });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: FileSystemService, decorators: [{
                type: i0.Injectable
            }], ctorParameters: function () { return [{ type: i1__namespace.HttpClient }, { type: UtilsService }]; } });

    /**
     * Internal service.
     */
    var DocsService = /** @class */ (function () {
        function DocsService() {
            this.markdownChangeSubject = new rxjs.BehaviorSubject(false);
            this.markdownChange$ = this.markdownChangeSubject.asObservable();
        }
        DocsService.prototype.notifyMarkdownChanges = function () {
            this.markdownChangeSubject.next(true);
        };
        return DocsService;
    }());
    DocsService.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: DocsService, deps: [], target: i0__namespace.ɵɵFactoryTarget.Injectable });
    DocsService.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: DocsService, providedIn: 'root' });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: DocsService, decorators: [{
                type: i0.Injectable,
                args: [{
                        providedIn: 'root'
                    }]
            }], ctorParameters: function () { return []; } });

    var NavigationTreeComponent = /** @class */ (function () {
        function NavigationTreeComponent(utils, docsService) {
            this.utils = utils;
            this.docsService = docsService;
            this.sectionsLoaded = new i0.EventEmitter();
            this.classNavigationMenu = 'navigationMenu';
        }
        NavigationTreeComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.loadObservables();
            this.markdownChange$.subscribe(function (isChanged) {
                if (isChanged) {
                    _this.cleanTree();
                    _this.loadSections();
                    _this.sectionsLoaded.emit(true);
                }
            });
        };
        NavigationTreeComponent.prototype.loadObservables = function () {
            this.markdownChange$ = this.docsService.markdownChange$;
        };
        NavigationTreeComponent.prototype.cleanTree = function () {
            var navigationMenu = document.getElementsByClassName(this.classNavigationMenu)[0];
            navigationMenu.innerHTML = '';
        };
        NavigationTreeComponent.prototype.loadSections = function () {
            this.createSectionTitle();
            this.createSectionSubTitles();
        };
        NavigationTreeComponent.prototype.createSectionTitle = function () {
            var titleH1 = document.getElementsByTagName('h1')[0];
            if (titleH1) {
                this.wrapElementWithSection(titleH1, '0');
                this.createTreeItem(titleH1.textContent, 0);
            }
        };
        NavigationTreeComponent.prototype.createSectionSubTitles = function () {
            var _this = this;
            var elementsH2 = document.getElementsByTagName('h2');
            var arrElementsH2 = __spreadArray([], __read(elementsH2));
            var lastIndex = 0;
            arrElementsH2.forEach(function (elementH2, index) {
                index = lastIndex + 1;
                var arrElementsH3 = _this.utils.nextUntil(elementH2, 'h2', 'h3');
                _this.loadSectionsH3(arrElementsH3, index);
                _this.wrapElementWithSection(elementH2, index.toString());
                _this.createTreeItem(elementH2.textContent, index, arrElementsH3);
                lastIndex = index + arrElementsH3.length;
            });
        };
        NavigationTreeComponent.prototype.loadSectionsH3 = function (arrElementsH3, index) {
            var _this = this;
            arrElementsH3.forEach(function (elementH3, subIndex) {
                _this.wrapElementWithSection(elementH3, (index + subIndex + 1).toString());
            });
        };
        NavigationTreeComponent.prototype.wrapElementWithSection = function (element, id) {
            var parent = element.parentNode;
            var wrapperSection = document.createElement('section');
            wrapperSection.id = id;
            parent.replaceChild(wrapperSection, element);
            wrapperSection.appendChild(element);
        };
        NavigationTreeComponent.prototype.createTreeItem = function (text, index, subItems) {
            var _this = this;
            if (subItems === void 0) { subItems = []; }
            var navigationMenu = document.getElementsByClassName(this.classNavigationMenu)[0];
            var div = document.createElement('div');
            var aItem = document.createElement('a');
            var aText = document.createTextNode(text);
            aItem.appendChild(aText);
            aItem.title = text;
            aItem.id = "navItem" + index;
            aItem.href = window.location.pathname + window.location.search + "#" + index;
            div.appendChild(aItem);
            navigationMenu.appendChild(div);
            subItems.forEach(function (subItem, subIndex) {
                _this.createTreeSubItem(navigationMenu, subItem.textContent, index + subIndex + 1);
            });
        };
        NavigationTreeComponent.prototype.createTreeSubItem = function (parent, text, id) {
            var div = document.createElement('div');
            var aSubItem = document.createElement('a');
            var aText = document.createTextNode(text);
            aSubItem.appendChild(aText);
            aSubItem.title = text;
            aSubItem.id = "navItem" + id;
            aSubItem.href = window.location.pathname + window.location.search + "#" + id;
            aSubItem.classList.add('sub-item-navigation');
            div.appendChild(aSubItem);
            parent.insertAdjacentElement('beforeend', div);
        };
        return NavigationTreeComponent;
    }());
    NavigationTreeComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NavigationTreeComponent, deps: [{ token: UtilsService }, { token: DocsService }], target: i0__namespace.ɵɵFactoryTarget.Component });
    NavigationTreeComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: NavigationTreeComponent, selector: "lib-navigation-tree", outputs: { sectionsLoaded: "sectionsLoaded" }, ngImport: i0__namespace, template: "<div [ngClass]=\"classNavigationMenu\"></div>\n", styles: [".navigationMenu{margin-top:20px;position:relative}.navigationMenu div{position:relative;padding:3px}.navigationMenu div:before{position:absolute;border-left:1px solid #dbdbdb;content:\"\";left:20px;top:0;bottom:-4px}.navigationMenu div:first-child:after{content:\"\";display:block;height:1px;width:40%;background:#dbdbdb;clear:both;margin:7px 0 4px 37px}.navigationMenu a{color:#444;text-decoration:none;text-transform:initial;display:block;font-size:13px;padding-left:40px;padding-bottom:3px;padding-top:3px}.navigationMenu a.navigation-item-selected{font-weight:500}.navigationMenu a.navigation-item-selected:after{content:\"\";border-radius:50%;left:18px;top:11px;background-color:#444;position:absolute;width:6px;height:6px}.navigationMenu a.sub-item-navigation{margin-left:10px}\n"], directives: [{ type: i3__namespace.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], encapsulation: i0__namespace.ViewEncapsulation.None });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NavigationTreeComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'lib-navigation-tree',
                        templateUrl: './navigation-tree.component.html',
                        styleUrls: ['./navigation-tree.component.scss'],
                        encapsulation: i0.ViewEncapsulation.None
                    }]
            }], ctorParameters: function () { return [{ type: UtilsService }, { type: DocsService }]; }, propDecorators: { sectionsLoaded: [{
                    type: i0.Output
                }] } });

    var NavigationMenuComponent = /** @class */ (function () {
        function NavigationMenuComponent(fileSystem) {
            this.fileSystem = fileSystem;
            this.markdownChange = new i0.EventEmitter();
            this.openedFolders = [];
        }
        NavigationMenuComponent.prototype.ngOnInit = function () {
            this.docs$ = this.fileSystem.docs$;
            this.navigationMenu$ = this.fileSystem.navigationMenu$;
            this.fillOpenedFolders();
        };
        NavigationMenuComponent.prototype.ngOnChanges = function (changes) {
            var _a, _b;
            if (changes.currentFile.currentValue) {
                var folder = ((_a = this.currentFile) === null || _a === void 0 ? void 0 : _a.indexOf('/')) !== -1 ? (_b = this.currentFile) === null || _b === void 0 ? void 0 : _b.split('/')[0] : null;
                if (folder) {
                    this.openedFolders[folder] = true;
                }
            }
        };
        NavigationMenuComponent.prototype.fillOpenedFolders = function () {
            var _this = this;
            this.docs$.subscribe(function (docs) {
                if (docs) {
                    Object.keys(docs).forEach(function (folderName) {
                        _this.openedFolders[folderName] = false;
                    });
                }
            });
        };
        NavigationMenuComponent.prototype.getFolderName = function (folder) {
            return Object.keys(folder)[0];
        };
        NavigationMenuComponent.prototype.getDocsFromFolder = function (folder) {
            return folder[Object.keys(folder)[0]];
        };
        NavigationMenuComponent.prototype.switchOpenFolder = function (folderName) {
            this.openedFolders[folderName] = !this.openedFolders[folderName];
        };
        NavigationMenuComponent.prototype.isItemActived = function (item) {
            return item.title ? this.currentFile === item.title : false;
        };
        NavigationMenuComponent.prototype.isFolderItemActived = function (folder, title) {
            return this.currentFile === folder + "/" + title;
        };
        NavigationMenuComponent.prototype.loadMarkdown = function (name) {
            this.markdownChange.emit(name);
        };
        return NavigationMenuComponent;
    }());
    NavigationMenuComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NavigationMenuComponent, deps: [{ token: FileSystemService }], target: i0__namespace.ɵɵFactoryTarget.Component });
    NavigationMenuComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: NavigationMenuComponent, selector: "lib-navigation-menu", inputs: { currentFile: "currentFile" }, outputs: { markdownChange: "markdownChange" }, usesOnChanges: true, ngImport: i0__namespace, template: "<div class=\"item-navigation\">\n    <div *ngFor=\"let item of navigationMenu$ | async\" class=\"files\" [class.item-actived]=\"isItemActived(item)\">\n        <ng-template [ngIf]=\"item.title\" [ngIfElse]=\"folderTemplate\">\n            <div class=\"text\" (click)=\"loadMarkdown(item.title)\">\n                {{ item.title }}\n            </div>\n        </ng-template>\n\n        <ng-template #folderTemplate>\n            <div class=\"text\" (click)=\"switchOpenFolder(getFolderName(item))\">\n                {{ getFolderName(item) }}\n                <mat-icon class=\"arrow-icon\">\n                    {{ openedFolders[getFolderName(item)] ? 'keyboard_arrow_down' : 'keyboard_arrow_right' }}\n                </mat-icon>\n            </div>\n            <ng-container *ngIf=\"openedFolders[getFolderName(item)]\">\n                <div\n                    *ngFor=\"let doc of getDocsFromFolder(item)\"\n                    (click)=\"loadMarkdown(doc.folder + '/' + doc.title)\"\n                    class=\"text sub-text\"\n                    [class.item-actived]=\"isFolderItemActived(getFolderName(item), doc.title)\"\n                >\n                    {{ doc.title }}\n                </div>\n            </ng-container>\n        </ng-template>\n    </div>\n</div>\n", styles: [".item-navigation{font-size:16px;box-sizing:border-box;color:#444;cursor:pointer;align-items:center;justify-content:space-between;overflow-wrap:break-word;text-decoration:none;text-align:left;width:100%;word-wrap:break-word;text-transform:uppercase}.item-navigation .files:first-child{margin-top:20px}.item-navigation .files .text{position:relative;padding:8px}.item-navigation .files .text:hover{background-color:#dbdbdb}.item-navigation .files .sub-text{padding-left:20px;font-size:14px;text-transform:capitalize}.item-navigation .files .arrow-icon{position:absolute;right:0;top:50%;transform:translateY(-50%)}.item-navigation .item-actived{color:#0082bb}\n"], components: [{ type: i2__namespace.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], directives: [{ type: i3__namespace.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i3__namespace.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "async": i3__namespace.AsyncPipe } });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NavigationMenuComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'lib-navigation-menu',
                        templateUrl: './navigation-menu.component.html',
                        styleUrls: ['./navigation-menu.component.scss']
                    }]
            }], ctorParameters: function () { return [{ type: FileSystemService }]; }, propDecorators: { currentFile: [{
                    type: i0.Input
                }], markdownChange: [{
                    type: i0.Output
                }] } });

    var ClickOutsideDirective = /** @class */ (function () {
        function ClickOutsideDirective(elementRef) {
            this.elementRef = elementRef;
            this.clickOutside = new i0.EventEmitter();
        }
        ClickOutsideDirective.prototype.onMouseEnter = function (targetElement) {
            var clickedInside = this.elementRef.nativeElement.contains(targetElement);
            if (!clickedInside) {
                this.clickOutside.emit(null);
            }
        };
        return ClickOutsideDirective;
    }());
    ClickOutsideDirective.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: ClickOutsideDirective, deps: [{ token: i0__namespace.ElementRef }], target: i0__namespace.ɵɵFactoryTarget.Directive });
    ClickOutsideDirective.ɵdir = i0__namespace.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "12.2.15", type: ClickOutsideDirective, selector: "[clickOutside]", outputs: { clickOutside: "clickOutside" }, host: { listeners: { "document:click": "onMouseEnter($event.target)" } }, ngImport: i0__namespace });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: ClickOutsideDirective, decorators: [{
                type: i0.Directive,
                args: [{
                        selector: '[clickOutside]'
                    }]
            }], ctorParameters: function () { return [{ type: i0__namespace.ElementRef }]; }, propDecorators: { clickOutside: [{
                    type: i0.Output
                }], onMouseEnter: [{
                    type: i0.HostListener,
                    args: ['document:click', ['$event.target']]
                }] } });

    var SearchComponent = /** @class */ (function () {
        function SearchComponent(fileSystem) {
            this.fileSystem = fileSystem;
            this.navigateToMarkdown = new i0.EventEmitter();
            this.panelVisible = false;
            this.results = [];
            this.indexSearch = [];
        }
        SearchComponent.prototype.onKeydownHandler = function (event) {
            this.closePanel();
        };
        SearchComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.fileSystem.docs$.subscribe(function (docs) {
                if (docs) {
                    _this.buildIndexSearch(docs);
                }
            });
        };
        SearchComponent.prototype.buildIndexSearch = function (docs) {
            var _this = this;
            this.indexSearch = [];
            Object.keys(docs).forEach(function (folderName) {
                docs[folderName].forEach(function (doc) {
                    _this.indexSearch.push({
                        title: doc.title,
                        content: doc.content,
                        folder: doc.folder
                    });
                });
            });
        };
        SearchComponent.prototype.search = function () {
            if (this.searchValue) {
                this.results = this.searchEngine(this.searchValue, ['content']);
            }
            else {
                this.cleanResults();
            }
        };
        SearchComponent.prototype.searchEngine = function (query, keys) {
            var results = [];
            this.indexSearch.forEach(function (item) {
                keys.forEach(function (key) {
                    var index = item[key].toLocaleLowerCase().indexOf(query.toLocaleLowerCase());
                    if (index >= 0) {
                        results.push(item);
                    }
                });
            });
            return results.length ? results : null;
        };
        SearchComponent.prototype.openPanel = function () {
            var _this = this;
            this.panelVisible = true;
            setTimeout(function () {
                _this.inputSearch.nativeElement.focus();
            });
        };
        SearchComponent.prototype.closePanel = function () {
            if (this.panelVisible) {
                this.panelVisible = false;
                this.searchValue = null;
                this.cleanResults();
            }
        };
        SearchComponent.prototype.cleanResults = function () {
            this.results = [];
        };
        SearchComponent.prototype.navigateTo = function (result) {
            this.navigateToMarkdown.emit({
                title: result.folder ? result.folder + "/" + result.title : result.title,
                search: this.searchValue
            });
            this.closePanel();
        };
        return SearchComponent;
    }());
    SearchComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: SearchComponent, deps: [{ token: FileSystemService }], target: i0__namespace.ɵɵFactoryTarget.Component });
    SearchComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: SearchComponent, selector: "lib-search", outputs: { navigateToMarkdown: "navigateToMarkdown" }, host: { listeners: { "document:keydown.escape": "onKeydownHandler($event)" } }, viewQueries: [{ propertyName: "inputSearch", first: true, predicate: ["inputSearch"], descendants: true }], ngImport: i0__namespace, template: "<div clickOutside (clickOutside)=\"closePanel()\">\n    <button mat-fab color=\"primary\" (click)=\"openPanel()\" class=\"button-search\">\n        <mat-icon>search</mat-icon>\n    </button>\n    <div *ngIf=\"panelVisible\" class=\"panel-search\">\n        <div class=\"panel-results\">\n            <div *ngFor=\"let result of results\" (click)=\"navigateTo(result)\" class=\"item-result\">\n                {{ result.title | uppercase }}\n            </div>\n        </div>\n        <form class=\"panel-form\">\n            <mat-form-field>\n                <input\n                    #inputSearch\n                    matInput\n                    name=\"value\"\n                    [(ngModel)]=\"searchValue\"\n                    (ngModelChange)=\"search()\"\n                    autofocus\n                    autocomplete=\"off\"\n                />\n                <mat-icon *ngIf=\"!searchValue\" (click)=\"closePanel()\" class=\"icon-cross\" matSuffix>\n                    close\n                </mat-icon>\n                <mat-icon *ngIf=\"searchValue\" matSuffix>\n                    search\n                </mat-icon>\n            </mat-form-field>\n        </form>\n    </div>\n</div>\n", styles: [".button-search{position:absolute!important;right:20px;bottom:20px}.panel-search{position:absolute;display:flex;bottom:0;height:200px;width:100%;background-color:#444;box-shadow:0 0 5px 2px #0000004d}.panel-search .panel-results{color:#fff;padding:20px;display:flex;flex:100%;flex-direction:column;flex-wrap:wrap}.panel-search .panel-results .item-result{padding:10px;color:#dbdbdb;cursor:pointer;flex:1 0 5%}.panel-search .panel-results .item-result:hover{color:#fff}.panel-search .panel-form{align-self:flex-end;color:#fff;flex:1;text-align:right;margin-right:20px}.panel-search .panel-form ::ng-deep .mat-form-field-underline{background-color:#fff}.panel-search .icon-cross{cursor:pointer}\n"], components: [{ type: i2__namespace$1.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i2__namespace.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i4__namespace.MatFormField, selector: "mat-form-field", inputs: ["color", "floatLabel", "appearance", "hideRequiredMarker", "hintLabel"], exportAs: ["matFormField"] }], directives: [{ type: ClickOutsideDirective, selector: "[clickOutside]", outputs: ["clickOutside"] }, { type: i3__namespace.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i3__namespace.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i7__namespace.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { type: i7__namespace.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { type: i7__namespace.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { type: i8__namespace.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["id", "disabled", "required", "type", "value", "readonly", "placeholder", "errorStateMatcher", "aria-describedby"], exportAs: ["matInput"] }, { type: i7__namespace.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i7__namespace.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i7__namespace.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { type: i4__namespace.MatSuffix, selector: "[matSuffix]" }], pipes: { "uppercase": i3__namespace.UpperCasePipe } });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: SearchComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'lib-search',
                        templateUrl: './search.component.html',
                        styleUrls: ['./search.component.scss']
                    }]
            }], ctorParameters: function () { return [{ type: FileSystemService }]; }, propDecorators: { navigateToMarkdown: [{
                    type: i0.Output
                }], inputSearch: [{
                    type: i0.ViewChild,
                    args: ['inputSearch', { static: false }]
                }], onKeydownHandler: [{
                    type: i0.HostListener,
                    args: ['document:keydown.escape', ['$event']]
                }] } });

    var VersioningComponent = /** @class */ (function () {
        function VersioningComponent() {
            this.versionChange = new i0.EventEmitter();
        }
        VersioningComponent.prototype.selectionChange = function () {
            this.versionChange.emit(this.currentVersion);
        };
        return VersioningComponent;
    }());
    VersioningComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: VersioningComponent, deps: [], target: i0__namespace.ɵɵFactoryTarget.Component });
    VersioningComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: VersioningComponent, selector: "lib-versioning", inputs: { versions: "versions", currentVersion: "currentVersion" }, outputs: { versionChange: "versionChange" }, ngImport: i0__namespace, template: "<mat-form-field>\n    <mat-label>Versions</mat-label>\n    <mat-select [(value)]=\"currentVersion\" (selectionChange)=\"selectionChange()\">\n        <mat-option *ngFor=\"let version of versions\" [value]=\"version\">\n            {{ version }}\n        </mat-option>\n    </mat-select>\n</mat-form-field>\n", styles: [""], components: [{ type: i4__namespace.MatFormField, selector: "mat-form-field", inputs: ["color", "floatLabel", "appearance", "hideRequiredMarker", "hintLabel"], exportAs: ["matFormField"] }, { type: i2__namespace$2.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex"], exportAs: ["matSelect"] }, { type: i3__namespace$1.MatOption, selector: "mat-option", exportAs: ["matOption"] }], directives: [{ type: i4__namespace.MatLabel, selector: "mat-label" }, { type: i3__namespace.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: VersioningComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'lib-versioning',
                        templateUrl: './versioning.component.html',
                        styleUrls: ['./versioning.component.scss']
                    }]
            }], ctorParameters: function () { return []; }, propDecorators: { versions: [{
                    type: i0.Input
                }], currentVersion: [{
                    type: i0.Input
                }], versionChange: [{
                    type: i0.Output
                }] } });

    var EditButtonComponent = /** @class */ (function () {
        function EditButtonComponent() {
        }
        EditButtonComponent.prototype.goToEdit = function () {
            window.open(this.path, '_blank');
        };
        return EditButtonComponent;
    }());
    EditButtonComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: EditButtonComponent, deps: [], target: i0__namespace.ɵɵFactoryTarget.Component });
    EditButtonComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: EditButtonComponent, selector: "edit-button", inputs: { path: "path" }, ngImport: i0__namespace, template: "<button mat-icon-button aria-label=\"suggest edit\" (click)=\"goToEdit()\" class=\"edit-icon\" color=\"primary\">\n    <mat-icon>edit</mat-icon>\n</button>\n", styles: [".edit-icon{position:absolute!important;right:20px;top:0px}.edit-icon:hover{background-color:#eceff1}\n"], components: [{ type: i2__namespace$1.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i2__namespace.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: EditButtonComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'edit-button',
                        templateUrl: './edit-button.component.html',
                        styleUrls: ['./edit-button.component.scss']
                    }]
            }], ctorParameters: function () { return []; }, propDecorators: { path: [{
                    type: i0.Input
                }] } });

    var SnackBarCopyComponent = /** @class */ (function () {
        function SnackBarCopyComponent() {
        }
        return SnackBarCopyComponent;
    }());
    SnackBarCopyComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: SnackBarCopyComponent, deps: [], target: i0__namespace.ɵɵFactoryTarget.Component });
    SnackBarCopyComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: SnackBarCopyComponent, selector: "lib-snack-bar-copy", ngImport: i0__namespace, template: "<div class=\"snack-container\">\n    <mat-icon color=\"primary\">content_copy</mat-icon>\n    <mat-icon class=\"check-icon\">check</mat-icon>\n</div>\n", styles: [".snack-container .check-icon{float:right}\n"], components: [{ type: i2__namespace.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: SnackBarCopyComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'lib-snack-bar-copy',
                        templateUrl: './snack-bar-copy.component.html',
                        styleUrls: ['./snack-bar-copy.component.scss']
                    }]
            }], ctorParameters: function () { return []; } });

    /**
     * Public service to manage the library
     */
    var NgDocxService = /** @class */ (function () {
        function NgDocxService() {
            this.editEnableSubject = new rxjs.BehaviorSubject(true);
            /**
             * Observable to know if you can edit the documents.
             */
            this.editEnable$ = this.editEnableSubject.asObservable();
        }
        /**
         * Set the edit button visibility.
         * @param enable boolean True if the edit button should be visible.
         */
        NgDocxService.prototype.setEdit = function (enable) {
            this.editEnableSubject.next(enable);
        };
        return NgDocxService;
    }());
    NgDocxService.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxService, deps: [], target: i0__namespace.ɵɵFactoryTarget.Injectable });
    NgDocxService.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxService, providedIn: 'root' });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxService, decorators: [{
                type: i0.Injectable,
                args: [{
                        providedIn: 'root'
                    }]
            }], ctorParameters: function () { return []; } });

    var DOCS_FOLDER = 'assets/docs/';
    var NgDocxComponent = /** @class */ (function () {
        function NgDocxComponent(config, ngDocxService, docsService, utils, fileSystem, snackBar) {
            this.config = config;
            this.ngDocxService = ngDocxService;
            this.docsService = docsService;
            this.utils = utils;
            this.fileSystem = fileSystem;
            this.snackBar = snackBar;
            this.currentVersion = null;
            this.docsDir = DOCS_FOLDER;
            this.markdownBefore = null;
            this.searchValue = null;
            this.section = null;
            this.sidenavOpened = true;
        }
        NgDocxComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.docs$ = this.fileSystem.docs$;
            this.docs$.subscribe(function (docs) {
                if (docs) {
                    var markdownName = _this.getQueryParamTitle();
                    var folder = markdownName.indexOf('/') !== -1 ? markdownName.split('/')[0] : null;
                    var title = folder ? markdownName.split('/')[1] : markdownName;
                    _this.section = _this.utils.getHashURL();
                    _this.markdownName = _this.docExists(docs, folder, title) ? markdownName : _this.getFirstTitle(docs);
                    _this.loadMarkdown(_this.markdownName);
                }
            });
            this.checkVersioning();
            this.fileSystem.loadDocs(this.docsDir, this.config.files);
        };
        NgDocxComponent.prototype.docExists = function (docs, folder, title) {
            return docs[folder] ? docs[folder].some(function (doc) { return doc.title === title; }) : false;
        };
        NgDocxComponent.prototype.getFirstTitle = function (docs) {
            return docs[Object.keys(docs)[0]][0].title;
        };
        NgDocxComponent.prototype.getQueryParamTitle = function () {
            var urlParams = new URLSearchParams(window.location.search);
            return decodeURIComponent(urlParams.get('title'));
        };
        NgDocxComponent.prototype.checkVersioning = function () {
            if (this.config.versions) {
                this.currentVersion = this.config.versions[this.config.versions.length - 1];
                this.docsDir = "" + DOCS_FOLDER + this.currentVersion + "/";
            }
        };
        NgDocxComponent.prototype.markdownChangeFromMenu = function (markdownName) {
            this.section = null;
            this.loadMarkdown(markdownName);
        };
        NgDocxComponent.prototype.loadMarkdown = function (markdownName, searchValue) {
            if (searchValue === void 0) { searchValue = null; }
            this.markdownName = markdownName;
            this.markdownBefore = this.markdown;
            this.markdown = "" + this.docsDir + this.markdownName + ".md";
            this.writeQueryParam(this.markdownName);
            this.searchValue = searchValue;
            if (this.searchValue && this.markdownBefore === this.markdown) {
                this.unmarkSearch();
                this.markSearchAndNavigate(this.searchValue);
                this.searchValue = null;
            }
        };
        NgDocxComponent.prototype.writeQueryParam = function (markdownName) {
            var hash = this.section ? window.location.hash : '';
            window.history.replaceState(null, null, window.location.pathname + "?title=" + encodeURIComponent(markdownName) + hash);
        };
        NgDocxComponent.prototype.notifyMarkdownChanges = function () {
            if (this.markdownBefore !== this.markdown) {
                this.docsService.notifyMarkdownChanges();
                document.querySelector('.mat-sidenav-content').scrollTop = 0;
            }
            if (this.searchValue) {
                this.markSearchAndNavigate(this.searchValue);
                this.searchValue = null;
            }
        };
        NgDocxComponent.prototype.sectionsLoaded = function () {
            var _this = this;
            this.highlightHeader();
            if (this.section && !Number.isNaN(this.section)) {
                setTimeout(function () {
                    var _a;
                    var positionSection = (_a = document.getElementById(_this.section.toString())) === null || _a === void 0 ? void 0 : _a.getBoundingClientRect().top;
                    _this.navigateToPosition(positionSection);
                });
            }
            this.addSectionLinks();
        };
        NgDocxComponent.prototype.navigateToPosition = function (position) {
            var matSidenavContent = document.querySelector('.mat-sidenav-content');
            var toolbar = document.getElementsByTagName('mat-toolbar')[0];
            var someSpace = 10;
            if (matSidenavContent) {
                matSidenavContent.scrollTop =
                    matSidenavContent.scrollTop +
                        position -
                        (toolbar ? toolbar.getBoundingClientRect().height : 0) -
                        someSpace;
            }
        };
        NgDocxComponent.prototype.onScroll = function () {
            this.highlightHeader();
        };
        NgDocxComponent.prototype.highlightHeader = function () {
            var _this = this;
            var sections = document.getElementsByTagName('section');
            var arrSections = __spreadArray([], __read(sections));
            arrSections.some(function (section, index) {
                var positionSection = section.getBoundingClientRect();
                if (positionSection.top >= 0 && positionSection.bottom <= window.innerHeight) {
                    _this.hightlightItem(index);
                    return true;
                }
            });
        };
        NgDocxComponent.prototype.hightlightItem = function (index) {
            var className = 'navigation-item-selected';
            var currentSelected = document.getElementsByClassName("navigation-item-selected")[0];
            var item = document.getElementById("navItem" + index);
            if (currentSelected !== item) {
                if (currentSelected) {
                    currentSelected.classList.remove(className);
                }
                if (item) {
                    item.classList.add(className);
                }
            }
        };
        NgDocxComponent.prototype.addSectionLinks = function () {
            var _this = this;
            var sections = document.getElementsByTagName('section');
            var arrSections = __spreadArray([], __read(sections));
            arrSections.some(function (section, index) {
                _this.addSectionLink(section, index);
            });
        };
        NgDocxComponent.prototype.addSectionLink = function (section, index) {
            var _this = this;
            var newSectionLink = document.createElement('i');
            newSectionLink.setAttribute('index', index.toString());
            newSectionLink.className = 'material-icons ng-docx-section-link';
            newSectionLink.innerText = 'link';
            newSectionLink.addEventListener('click', function (event) {
                var currentURL = _this.utils.getURLWithoutHash();
                _this.utils.copyOnClipboard(currentURL + "#" + event.target.getAttribute('index'));
                _this.openSnackBarCopied();
            });
            section.childNodes[0].appendChild(newSectionLink);
        };
        NgDocxComponent.prototype.openSnackBarCopied = function () {
            this.snackBar.openFromComponent(SnackBarCopyComponent, {
                duration: 1000
            });
        };
        NgDocxComponent.prototype.switchSidenav = function () {
            this.sidenavOpened = !this.sidenavOpened;
        };
        NgDocxComponent.prototype.unmarkSearch = function () {
            var context = document.querySelector('markdown');
            var instance = new Mark__default["default"](context);
            instance.unmark();
        };
        NgDocxComponent.prototype.markSearchAndNavigate = function (text) {
            var context = document.querySelector('markdown');
            var instance = new Mark__default["default"](context);
            instance.mark(text);
            var markElement = document.querySelector('mark');
            if (markElement) {
                this.navigateToPosition(markElement.getBoundingClientRect().top);
            }
        };
        NgDocxComponent.prototype.versionChange = function (newVersion) {
            this.currentVersion = newVersion;
            this.docsDir = "" + DOCS_FOLDER + this.currentVersion + "/";
            this.fileSystem.loadDocs(this.docsDir, this.config.files);
        };
        return NgDocxComponent;
    }());
    NgDocxComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxComponent, deps: [{ token: 'config' }, { token: NgDocxService }, { token: DocsService }, { token: UtilsService }, { token: FileSystemService }, { token: i5__namespace.MatSnackBar }], target: i0__namespace.ɵɵFactoryTarget.Component });
    NgDocxComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: NgDocxComponent, selector: "ng-docx", ngImport: i0__namespace, template: "<mat-sidenav-container class=\"sidenav-container\">\n    <mat-sidenav [opened]=\"sidenavOpened\" mode=\"side\" opened class=\"sidenav-left\">\n        <lib-navigation-menu\n            [currentFile]=\"markdownName\"\n            (markdownChange)=\"markdownChangeFromMenu($event)\"\n        ></lib-navigation-menu>\n        <hr *ngIf=\"currentVersion\" class=\"versioning-separator\" />\n        <lib-versioning\n            *ngIf=\"currentVersion\"\n            [versions]=\"config.versions\"\n            [currentVersion]=\"currentVersion\"\n            (versionChange)=\"versionChange($event)\"\n            class=\"versioning\"\n        ></lib-versioning>\n    </mat-sidenav>\n    <mat-sidenav-content (scroll)=\"onScroll()\">\n        <div>\n            <button mat-icon-button aria-label=\"menu icon\" (click)=\"switchSidenav()\" class=\"menu-icon\">\n                <mat-icon>{{ sidenavOpened ? 'menu_open' : 'menu' }}</mat-icon>\n            </button>\n            <edit-button\n                *ngIf=\"config.editAssetsPath && ngDocxService.editEnable$ | async\"\n                [path]=\"config.editAssetsPath + '/' + docsDir + markdownName + '.md'\"\n            >\n            </edit-button>\n            <markdown [src]=\"markdown\" (ready)=\"notifyMarkdownChanges()\" lineNumbers></markdown>\n        </div>\n    </mat-sidenav-content>\n    <mat-sidenav class=\"sidenav-right\" opened mode=\"side\" position=\"end\">\n        <lib-navigation-tree (sectionsLoaded)=\"sectionsLoaded()\"></lib-navigation-tree>\n    </mat-sidenav>\n</mat-sidenav-container>\n<lib-search (navigateToMarkdown)=\"loadMarkdown($event.title, $event.search)\"></lib-search>\n", styles: ["::-webkit-scrollbar{width:5px;color:0}::-webkit-scrollbar-track{background:#f1f1f1}::-webkit-scrollbar-thumb{background:#888}::-webkit-scrollbar-thumb:hover{background:#555}mat-sidenav-content{background-color:#fff}mat-sidenav-content>div{padding:30px}lib-search{position:absolute;bottom:0;width:100%;z-index:1}section:hover .ng-docx-section-link{display:initial}.ng-docx-section-link{color:#6e6e6e;cursor:pointer;display:none;position:absolute}.sidenav-container{position:relative;height:100%;background:#eee}.sidenav-container mat-sidenav{width:200px}.sidenav-container mat-sidenav.sidenav-right{width:240px}.sidenav-container .sidenav-left{box-shadow:6px 0 6px #0000001a}.sidenav-container .mat-drawer-side.mat-drawer-end{border-left:none}.menu-icon{position:absolute!important;left:-3px;top:-5px}.highlight-search{background-color:#ff0}.versioning-separator{margin-right:8px;margin-left:8px;border-top:1px solid #dbdbdb}.versioning{padding:8px}.versioning .mat-form-field{width:90%}\n"], components: [{ type: i6__namespace.MatSidenavContainer, selector: "mat-sidenav-container", exportAs: ["matSidenavContainer"] }, { type: i6__namespace.MatSidenav, selector: "mat-sidenav", inputs: ["fixedInViewport", "fixedTopGap", "fixedBottomGap"], exportAs: ["matSidenav"] }, { type: NavigationMenuComponent, selector: "lib-navigation-menu", inputs: ["currentFile"], outputs: ["markdownChange"] }, { type: VersioningComponent, selector: "lib-versioning", inputs: ["versions", "currentVersion"], outputs: ["versionChange"] }, { type: i6__namespace.MatSidenavContent, selector: "mat-sidenav-content" }, { type: i2__namespace$1.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i2__namespace.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: EditButtonComponent, selector: "edit-button", inputs: ["path"] }, { type: i12__namespace.MarkdownComponent, selector: "markdown, [markdown]", inputs: ["emoji", "katex", "lineHighlight", "lineNumbers", "data", "src", "katexOptions", "line", "lineOffset", "start"], outputs: ["error", "load", "ready"] }, { type: NavigationTreeComponent, selector: "lib-navigation-tree", outputs: ["sectionsLoaded"] }, { type: SearchComponent, selector: "lib-search", outputs: ["navigateToMarkdown"] }], directives: [{ type: i3__namespace.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "async": i3__namespace.AsyncPipe }, encapsulation: i0__namespace.ViewEncapsulation.None });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'ng-docx',
                        templateUrl: './docs.component.html',
                        styleUrls: ['./docs.component.scss'],
                        encapsulation: i0.ViewEncapsulation.None
                    }]
            }], ctorParameters: function () {
            return [{ type: undefined, decorators: [{
                            type: i0.Inject,
                            args: ['config']
                        }] }, { type: NgDocxService }, { type: DocsService }, { type: UtilsService }, { type: FileSystemService }, { type: i5__namespace.MatSnackBar }];
        } });

    var childRoutes = [{ path: '', component: NgDocxComponent }];
    var NgDocxModule = /** @class */ (function () {
        function NgDocxModule() {
        }
        NgDocxModule.forRoot = function (configuration) {
            return {
                ngModule: NgDocxModule,
                providers: [{ provide: 'config', useValue: configuration }]
            };
        };
        return NgDocxModule;
    }());
    NgDocxModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
    NgDocxModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxModule, declarations: [NgDocxComponent,
            NavigationTreeComponent,
            NavigationMenuComponent,
            SearchComponent,
            ClickOutsideDirective,
            VersioningComponent,
            EditButtonComponent,
            SnackBarCopyComponent], imports: [i3.CommonModule, i1__namespace$1.RouterModule, i2$1.MatButtonModule,
            i2.MatIconModule,
            i6.MatSidenavModule,
            i8.MatInputModule,
            i4.MatFormFieldModule,
            i2$2.MatSelectModule,
            i5.MatSnackBarModule,
            i7.FormsModule,
            i1.HttpClientModule, i12__namespace.MarkdownModule] });
    NgDocxModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxModule, providers: [FileSystemService], imports: [[
                i3.CommonModule,
                i1$1.RouterModule.forChild(childRoutes),
                i2$1.MatButtonModule,
                i2.MatIconModule,
                i6.MatSidenavModule,
                i8.MatInputModule,
                i4.MatFormFieldModule,
                i2$2.MatSelectModule,
                i5.MatSnackBarModule,
                i7.FormsModule,
                i1.HttpClientModule,
                i12.MarkdownModule.forRoot({ loader: i1.HttpClient })
            ]] });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0__namespace, type: NgDocxModule, decorators: [{
                type: i0.NgModule,
                args: [{
                        declarations: [
                            NgDocxComponent,
                            NavigationTreeComponent,
                            NavigationMenuComponent,
                            SearchComponent,
                            ClickOutsideDirective,
                            VersioningComponent,
                            EditButtonComponent,
                            SnackBarCopyComponent
                        ],
                        imports: [
                            i3.CommonModule,
                            i1$1.RouterModule.forChild(childRoutes),
                            i2$1.MatButtonModule,
                            i2.MatIconModule,
                            i6.MatSidenavModule,
                            i8.MatInputModule,
                            i4.MatFormFieldModule,
                            i2$2.MatSelectModule,
                            i5.MatSnackBarModule,
                            i7.FormsModule,
                            i1.HttpClientModule,
                            i12.MarkdownModule.forRoot({ loader: i1.HttpClient })
                        ],
                        providers: [FileSystemService],
                        entryComponents: [SnackBarCopyComponent]
                    }]
            }] });

    /*
     * Public API Surface of ng-docx
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.NgDocxComponent = NgDocxComponent;
    exports.NgDocxModule = NgDocxModule;
    exports.NgDocxService = NgDocxService;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=ng-docx.umd.js.map
