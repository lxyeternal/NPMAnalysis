import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Internal service.
 */
export declare class DocsService {
    private markdownChangeSubject;
    readonly markdownChange$: Observable<boolean>;
    constructor();
    notifyMarkdownChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocsService>;
}
