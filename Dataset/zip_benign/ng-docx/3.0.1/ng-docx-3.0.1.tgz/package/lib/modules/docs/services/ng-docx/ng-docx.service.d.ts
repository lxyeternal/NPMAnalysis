import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Public service to manage the library
 */
export declare class NgDocxService {
    private editEnableSubject;
    /**
     * Observable to know if you can edit the documents.
     */
    readonly editEnable$: Observable<boolean>;
    constructor();
    /**
     * Set the edit button visibility.
     * @param enable boolean True if the edit button should be visible.
     */
    setEdit(enable: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgDocxService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgDocxService>;
}
