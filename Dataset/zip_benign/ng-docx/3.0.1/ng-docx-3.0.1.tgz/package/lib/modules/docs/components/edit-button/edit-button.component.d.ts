import * as i0 from "@angular/core";
export declare class EditButtonComponent {
    path: string;
    constructor();
    goToEdit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditButtonComponent, "edit-button", never, { "path": "path"; }, {}, never, never>;
}
