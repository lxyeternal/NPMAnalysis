import { HttpClient } from '@angular/common/http';
import { UtilsService } from './../utils/utils.service';
import { DocumentInterface, DocCollectionInterface, FolderInterface } from '../../models';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class FileSystemService {
    http: HttpClient;
    private utils;
    private docsSubject;
    private navigationMenuSubject;
    readonly docs$: Observable<DocCollectionInterface>;
    readonly navigationMenu$: Observable<DocumentInterface[]>;
    constructor(http: HttpClient, utils: UtilsService);
    loadDocs(docsDir: string, docNames: (string | FolderInterface)[]): void;
    getDocs(docsDir: string, docNames: (string | FolderInterface)[]): Observable<DocumentInterface>[];
    readFile(docsDir: string, docName: string, folderName?: string): Observable<DocumentInterface>;
    createNavigationMenu(docs: DocumentInterface[]): DocumentInterface[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSystemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileSystemService>;
}
