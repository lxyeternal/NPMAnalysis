import { OnInit, EventEmitter } from '@angular/core';
import { UtilsService } from '../../services/utils/utils.service';
import { DocsService } from '../../services/docs/docs.service';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class NavigationTreeComponent implements OnInit {
    private utils;
    private docsService;
    sectionsLoaded: EventEmitter<boolean>;
    classNavigationMenu: string;
    markdownChange$: Observable<boolean>;
    constructor(utils: UtilsService, docsService: DocsService);
    ngOnInit(): void;
    loadObservables(): void;
    cleanTree(): void;
    loadSections(): void;
    createSectionTitle(): void;
    createSectionSubTitles(): void;
    loadSectionsH3(arrElementsH3: any[], index: number): void;
    wrapElementWithSection(element: any, id: string): void;
    createTreeItem(text: string, index: number, subItems?: any[]): void;
    createTreeSubItem(parent: Element, text: string, id: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationTreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationTreeComponent, "lib-navigation-tree", never, {}, { "sectionsLoaded": "sectionsLoaded"; }, never, never>;
}
