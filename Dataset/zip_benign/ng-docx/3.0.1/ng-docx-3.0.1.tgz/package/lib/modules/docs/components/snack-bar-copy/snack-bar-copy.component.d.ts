import * as i0 from "@angular/core";
export declare class SnackBarCopyComponent {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackBarCopyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SnackBarCopyComponent, "lib-snack-bar-copy", never, {}, {}, never, never>;
}
