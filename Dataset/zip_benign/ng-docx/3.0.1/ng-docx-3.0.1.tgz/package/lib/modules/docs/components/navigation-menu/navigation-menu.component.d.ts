import { EventEmitter, OnInit, SimpleChanges, OnChanges } from '@angular/core';
import { FileSystemService } from './../../services/file-system/file-system.service';
import { DocCollectionInterface, DocumentInterface } from '../../models';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class NavigationMenuComponent implements OnInit, OnChanges {
    private fileSystem;
    currentFile: string;
    markdownChange: EventEmitter<string>;
    navigationMenu$: Observable<DocumentInterface[]>;
    docs$: Observable<DocCollectionInterface>;
    openedFolders: {
        [folder: string]: boolean;
    }[];
    constructor(fileSystem: FileSystemService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private fillOpenedFolders;
    getFolderName(folder: {
        [folderName: string]: DocumentInterface[];
    }): string;
    getDocsFromFolder(folder: {
        [folderName: string]: DocumentInterface[];
    }): DocumentInterface[];
    switchOpenFolder(folderName: string): void;
    isItemActived(item: any): boolean;
    isFolderItemActived(folder: string, title: string): boolean;
    loadMarkdown(name: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationMenuComponent, "lib-navigation-menu", never, { "currentFile": "currentFile"; }, { "markdownChange": "markdownChange"; }, never, never>;
}
