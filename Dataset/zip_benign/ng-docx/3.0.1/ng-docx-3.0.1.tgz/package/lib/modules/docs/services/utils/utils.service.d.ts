import * as i0 from "@angular/core";
export declare class UtilsService {
    constructor();
    copyOnClipboard(textToCopy: string): void;
    getHashURL(): number;
    getURLWithoutHash(): string;
    nextUntil(elem: Element, selector: string, filter?: string): Element[];
    groupBy(collection: any, key: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UtilsService>;
}
