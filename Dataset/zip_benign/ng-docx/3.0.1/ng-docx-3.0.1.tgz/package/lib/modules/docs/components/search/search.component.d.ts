import { OnInit, EventEmitter } from '@angular/core';
import { DocumentInterface } from '../../models';
import { FileSystemService } from '../../services/file-system/file-system.service';
import * as i0 from "@angular/core";
export declare class SearchComponent implements OnInit {
    private fileSystem;
    navigateToMarkdown: EventEmitter<{
        title: string;
        search: string;
    }>;
    panelVisible: boolean;
    searchValue: string;
    results: any;
    indexSearch: any[];
    private inputSearch;
    onKeydownHandler(event: KeyboardEvent): void;
    constructor(fileSystem: FileSystemService);
    ngOnInit(): void;
    private buildIndexSearch;
    search(): void;
    private searchEngine;
    openPanel(): void;
    closePanel(): void;
    private cleanResults;
    navigateTo(result: DocumentInterface): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchComponent, "lib-search", never, {}, { "navigateToMarkdown": "navigateToMarkdown"; }, never, never>;
}
