import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class VersioningComponent {
    versions: string[];
    currentVersion: string;
    versionChange: EventEmitter<string>;
    constructor();
    selectionChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersioningComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersioningComponent, "lib-versioning", never, { "versions": "versions"; "currentVersion": "currentVersion"; }, { "versionChange": "versionChange"; }, never, never>;
}
