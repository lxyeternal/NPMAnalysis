import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Component, ViewEncapsulation, Output, Input, Directive, HostListener, ViewChild, Inject, NgModule } from '@angular/core';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i7 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i6 from '@angular/material/sidenav';
import { MatSidenavModule } from '@angular/material/sidenav';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i2$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i8 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i4 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i2$2 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i5 from '@angular/material/snack-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import * as i1 from '@angular/common/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import * as i12 from 'ngx-markdown/';
import { MarkdownModule } from 'ngx-markdown/';
import { __awaiter } from 'tslib';
import { BehaviorSubject, forkJoin, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import * as i3$1 from '@angular/material/core';
import Mark from 'mark.js';

class UtilsService {
    constructor() { }
    copyOnClipboard(textToCopy) {
        const elSelected = document.createElement('textarea');
        elSelected.value = textToCopy;
        document.body.appendChild(elSelected);
        elSelected.select();
        document.execCommand('copy');
        document.body.removeChild(elSelected);
    }
    getHashURL() {
        return parseInt(window.location.hash.replace('#', ''), 10);
    }
    getURLWithoutHash() {
        const url = new URL(window.location.toString());
        url.hash = '';
        return url.toString();
    }
    nextUntil(elem, selector, filter = null) {
        const siblings = [];
        elem = elem.nextElementSibling;
        while (elem) {
            if (elem.matches(selector)) {
                break;
            }
            if (filter && !elem.matches(filter)) {
                elem = elem.nextElementSibling;
                continue;
            }
            siblings.push(elem);
            elem = elem.nextElementSibling;
        }
        return siblings;
    }
    groupBy(collection, key) {
        return collection.reduce((rv, x) => {
            if (x) {
                (rv[x[key]] = rv[x[key]] || []).push(x);
            }
            return rv;
        }, {});
    }
}
UtilsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: UtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
UtilsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: UtilsService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: UtilsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class FileSystemService {
    constructor(http, utils) {
        this.http = http;
        this.utils = utils;
        this.docsSubject = new BehaviorSubject(null);
        this.navigationMenuSubject = new BehaviorSubject(null);
        this.docs$ = this.docsSubject.asObservable();
        this.navigationMenu$ = this.navigationMenuSubject.asObservable();
    }
    loadDocs(docsDir, docNames) {
        forkJoin(this.getDocs(docsDir, docNames)).subscribe((docs) => {
            this.navigationMenuSubject.next(this.createNavigationMenu(docs));
            this.docsSubject.next(this.utils.groupBy(docs, 'folder'));
        });
    }
    getDocs(docsDir, docNames) {
        const docs$ = [];
        docNames.map((docName) => __awaiter(this, void 0, void 0, function* () {
            if (typeof docName === 'string') {
                docs$.push(this.readFile(docsDir, docName));
            }
            else {
                Object.keys(docName).forEach((folderName) => __awaiter(this, void 0, void 0, function* () {
                    docName[folderName].map((title) => {
                        docs$.push(this.readFile(`${docsDir}${folderName}/`, title, folderName));
                    });
                }));
            }
        }));
        return docs$;
    }
    readFile(docsDir, docName, folderName = null) {
        return this.http.get(`${docsDir}${docName}.md`, { responseType: 'text' }).pipe(map((docContent) => {
            return {
                title: docName,
                content: docContent,
                folder: folderName
            };
        }), catchError(() => {
            return of(null);
        }));
    }
    createNavigationMenu(docs) {
        const navigationMenu = [];
        const folderAlreadyPushed = [];
        const groupedDocs = this.utils.groupBy(docs, 'folder');
        docs.forEach((doc) => {
            if (doc) {
                if (doc.folder && !folderAlreadyPushed.some((folder) => folder === (doc === null || doc === void 0 ? void 0 : doc.folder))) {
                    const folder = {};
                    folder[doc.folder] = groupedDocs[doc.folder];
                    navigationMenu.push(folder);
                    folderAlreadyPushed.push(doc.folder);
                }
                else if (!doc.folder) {
                    navigationMenu.push(doc);
                }
            }
        });
        return navigationMenu;
    }
}
FileSystemService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: FileSystemService, deps: [{ token: i1.HttpClient }, { token: UtilsService }], target: i0.ɵɵFactoryTarget.Injectable });
FileSystemService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: FileSystemService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: FileSystemService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: UtilsService }]; } });

/**
 * Internal service.
 */
class DocsService {
    constructor() {
        this.markdownChangeSubject = new BehaviorSubject(false);
        this.markdownChange$ = this.markdownChangeSubject.asObservable();
    }
    notifyMarkdownChanges() {
        this.markdownChangeSubject.next(true);
    }
}
DocsService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: DocsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
DocsService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: DocsService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: DocsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class NavigationTreeComponent {
    constructor(utils, docsService) {
        this.utils = utils;
        this.docsService = docsService;
        this.sectionsLoaded = new EventEmitter();
        this.classNavigationMenu = 'navigationMenu';
    }
    ngOnInit() {
        this.loadObservables();
        this.markdownChange$.subscribe((isChanged) => {
            if (isChanged) {
                this.cleanTree();
                this.loadSections();
                this.sectionsLoaded.emit(true);
            }
        });
    }
    loadObservables() {
        this.markdownChange$ = this.docsService.markdownChange$;
    }
    cleanTree() {
        const navigationMenu = document.getElementsByClassName(this.classNavigationMenu)[0];
        navigationMenu.innerHTML = '';
    }
    loadSections() {
        this.createSectionTitle();
        this.createSectionSubTitles();
    }
    createSectionTitle() {
        const titleH1 = document.getElementsByTagName('h1')[0];
        if (titleH1) {
            this.wrapElementWithSection(titleH1, '0');
            this.createTreeItem(titleH1.textContent, 0);
        }
    }
    createSectionSubTitles() {
        const elementsH2 = document.getElementsByTagName('h2');
        const arrElementsH2 = [...elementsH2];
        let lastIndex = 0;
        arrElementsH2.forEach((elementH2, index) => {
            index = lastIndex + 1;
            const arrElementsH3 = this.utils.nextUntil(elementH2, 'h2', 'h3');
            this.loadSectionsH3(arrElementsH3, index);
            this.wrapElementWithSection(elementH2, index.toString());
            this.createTreeItem(elementH2.textContent, index, arrElementsH3);
            lastIndex = index + arrElementsH3.length;
        });
    }
    loadSectionsH3(arrElementsH3, index) {
        arrElementsH3.forEach((elementH3, subIndex) => {
            this.wrapElementWithSection(elementH3, (index + subIndex + 1).toString());
        });
    }
    wrapElementWithSection(element, id) {
        const parent = element.parentNode;
        const wrapperSection = document.createElement('section');
        wrapperSection.id = id;
        parent.replaceChild(wrapperSection, element);
        wrapperSection.appendChild(element);
    }
    createTreeItem(text, index, subItems = []) {
        const navigationMenu = document.getElementsByClassName(this.classNavigationMenu)[0];
        const div = document.createElement('div');
        const aItem = document.createElement('a');
        const aText = document.createTextNode(text);
        aItem.appendChild(aText);
        aItem.title = text;
        aItem.id = `navItem${index}`;
        aItem.href = `${window.location.pathname + window.location.search}#${index}`;
        div.appendChild(aItem);
        navigationMenu.appendChild(div);
        subItems.forEach((subItem, subIndex) => {
            this.createTreeSubItem(navigationMenu, subItem.textContent, index + subIndex + 1);
        });
    }
    createTreeSubItem(parent, text, id) {
        const div = document.createElement('div');
        const aSubItem = document.createElement('a');
        const aText = document.createTextNode(text);
        aSubItem.appendChild(aText);
        aSubItem.title = text;
        aSubItem.id = `navItem${id}`;
        aSubItem.href = `${window.location.pathname + window.location.search}#${id}`;
        aSubItem.classList.add('sub-item-navigation');
        div.appendChild(aSubItem);
        parent.insertAdjacentElement('beforeend', div);
    }
}
NavigationTreeComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NavigationTreeComponent, deps: [{ token: UtilsService }, { token: DocsService }], target: i0.ɵɵFactoryTarget.Component });
NavigationTreeComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: NavigationTreeComponent, selector: "lib-navigation-tree", outputs: { sectionsLoaded: "sectionsLoaded" }, ngImport: i0, template: "<div [ngClass]=\"classNavigationMenu\"></div>\n", styles: [".navigationMenu{margin-top:20px;position:relative}.navigationMenu div{position:relative;padding:3px}.navigationMenu div:before{position:absolute;border-left:1px solid #dbdbdb;content:\"\";left:20px;top:0;bottom:-4px}.navigationMenu div:first-child:after{content:\"\";display:block;height:1px;width:40%;background:#dbdbdb;clear:both;margin:7px 0 4px 37px}.navigationMenu a{color:#444;text-decoration:none;text-transform:initial;display:block;font-size:13px;padding-left:40px;padding-bottom:3px;padding-top:3px}.navigationMenu a.navigation-item-selected{font-weight:500}.navigationMenu a.navigation-item-selected:after{content:\"\";border-radius:50%;left:18px;top:11px;background-color:#444;position:absolute;width:6px;height:6px}.navigationMenu a.sub-item-navigation{margin-left:10px}\n"], directives: [{ type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NavigationTreeComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'lib-navigation-tree',
                    templateUrl: './navigation-tree.component.html',
                    styleUrls: ['./navigation-tree.component.scss'],
                    encapsulation: ViewEncapsulation.None
                }]
        }], ctorParameters: function () { return [{ type: UtilsService }, { type: DocsService }]; }, propDecorators: { sectionsLoaded: [{
                type: Output
            }] } });

class NavigationMenuComponent {
    constructor(fileSystem) {
        this.fileSystem = fileSystem;
        this.markdownChange = new EventEmitter();
        this.openedFolders = [];
    }
    ngOnInit() {
        this.docs$ = this.fileSystem.docs$;
        this.navigationMenu$ = this.fileSystem.navigationMenu$;
        this.fillOpenedFolders();
    }
    ngOnChanges(changes) {
        var _a, _b;
        if (changes.currentFile.currentValue) {
            const folder = ((_a = this.currentFile) === null || _a === void 0 ? void 0 : _a.indexOf('/')) !== -1 ? (_b = this.currentFile) === null || _b === void 0 ? void 0 : _b.split('/')[0] : null;
            if (folder) {
                this.openedFolders[folder] = true;
            }
        }
    }
    fillOpenedFolders() {
        this.docs$.subscribe((docs) => {
            if (docs) {
                Object.keys(docs).forEach((folderName) => {
                    this.openedFolders[folderName] = false;
                });
            }
        });
    }
    getFolderName(folder) {
        return Object.keys(folder)[0];
    }
    getDocsFromFolder(folder) {
        return folder[Object.keys(folder)[0]];
    }
    switchOpenFolder(folderName) {
        this.openedFolders[folderName] = !this.openedFolders[folderName];
    }
    isItemActived(item) {
        return item.title ? this.currentFile === item.title : false;
    }
    isFolderItemActived(folder, title) {
        return this.currentFile === `${folder}/${title}`;
    }
    loadMarkdown(name) {
        this.markdownChange.emit(name);
    }
}
NavigationMenuComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NavigationMenuComponent, deps: [{ token: FileSystemService }], target: i0.ɵɵFactoryTarget.Component });
NavigationMenuComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: NavigationMenuComponent, selector: "lib-navigation-menu", inputs: { currentFile: "currentFile" }, outputs: { markdownChange: "markdownChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"item-navigation\">\n    <div *ngFor=\"let item of navigationMenu$ | async\" class=\"files\" [class.item-actived]=\"isItemActived(item)\">\n        <ng-template [ngIf]=\"item.title\" [ngIfElse]=\"folderTemplate\">\n            <div class=\"text\" (click)=\"loadMarkdown(item.title)\">\n                {{ item.title }}\n            </div>\n        </ng-template>\n\n        <ng-template #folderTemplate>\n            <div class=\"text\" (click)=\"switchOpenFolder(getFolderName(item))\">\n                {{ getFolderName(item) }}\n                <mat-icon class=\"arrow-icon\">\n                    {{ openedFolders[getFolderName(item)] ? 'keyboard_arrow_down' : 'keyboard_arrow_right' }}\n                </mat-icon>\n            </div>\n            <ng-container *ngIf=\"openedFolders[getFolderName(item)]\">\n                <div\n                    *ngFor=\"let doc of getDocsFromFolder(item)\"\n                    (click)=\"loadMarkdown(doc.folder + '/' + doc.title)\"\n                    class=\"text sub-text\"\n                    [class.item-actived]=\"isFolderItemActived(getFolderName(item), doc.title)\"\n                >\n                    {{ doc.title }}\n                </div>\n            </ng-container>\n        </ng-template>\n    </div>\n</div>\n", styles: [".item-navigation{font-size:16px;box-sizing:border-box;color:#444;cursor:pointer;align-items:center;justify-content:space-between;overflow-wrap:break-word;text-decoration:none;text-align:left;width:100%;word-wrap:break-word;text-transform:uppercase}.item-navigation .files:first-child{margin-top:20px}.item-navigation .files .text{position:relative;padding:8px}.item-navigation .files .text:hover{background-color:#dbdbdb}.item-navigation .files .sub-text{padding-left:20px;font-size:14px;text-transform:capitalize}.item-navigation .files .arrow-icon{position:absolute;right:0;top:50%;transform:translateY(-50%)}.item-navigation .item-actived{color:#0082bb}\n"], components: [{ type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], directives: [{ type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "async": i3.AsyncPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NavigationMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'lib-navigation-menu',
                    templateUrl: './navigation-menu.component.html',
                    styleUrls: ['./navigation-menu.component.scss']
                }]
        }], ctorParameters: function () { return [{ type: FileSystemService }]; }, propDecorators: { currentFile: [{
                type: Input
            }], markdownChange: [{
                type: Output
            }] } });

class ClickOutsideDirective {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.clickOutside = new EventEmitter();
    }
    onMouseEnter(targetElement) {
        const clickedInside = this.elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.clickOutside.emit(null);
        }
    }
}
ClickOutsideDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: ClickOutsideDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
ClickOutsideDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "12.2.15", type: ClickOutsideDirective, selector: "[clickOutside]", outputs: { clickOutside: "clickOutside" }, host: { listeners: { "document:click": "onMouseEnter($event.target)" } }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: ClickOutsideDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[clickOutside]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { clickOutside: [{
                type: Output
            }], onMouseEnter: [{
                type: HostListener,
                args: ['document:click', ['$event.target']]
            }] } });

class SearchComponent {
    constructor(fileSystem) {
        this.fileSystem = fileSystem;
        this.navigateToMarkdown = new EventEmitter();
        this.panelVisible = false;
        this.results = [];
        this.indexSearch = [];
    }
    onKeydownHandler(event) {
        this.closePanel();
    }
    ngOnInit() {
        this.fileSystem.docs$.subscribe((docs) => {
            if (docs) {
                this.buildIndexSearch(docs);
            }
        });
    }
    buildIndexSearch(docs) {
        this.indexSearch = [];
        Object.keys(docs).forEach((folderName) => {
            docs[folderName].forEach((doc) => {
                this.indexSearch.push({
                    title: doc.title,
                    content: doc.content,
                    folder: doc.folder
                });
            });
        });
    }
    search() {
        if (this.searchValue) {
            this.results = this.searchEngine(this.searchValue, ['content']);
        }
        else {
            this.cleanResults();
        }
    }
    searchEngine(query, keys) {
        const results = [];
        this.indexSearch.forEach((item) => {
            keys.forEach((key) => {
                const index = item[key].toLocaleLowerCase().indexOf(query.toLocaleLowerCase());
                if (index >= 0) {
                    results.push(item);
                }
            });
        });
        return results.length ? results : null;
    }
    openPanel() {
        this.panelVisible = true;
        setTimeout(() => {
            this.inputSearch.nativeElement.focus();
        });
    }
    closePanel() {
        if (this.panelVisible) {
            this.panelVisible = false;
            this.searchValue = null;
            this.cleanResults();
        }
    }
    cleanResults() {
        this.results = [];
    }
    navigateTo(result) {
        this.navigateToMarkdown.emit({
            title: result.folder ? `${result.folder}/${result.title}` : result.title,
            search: this.searchValue
        });
        this.closePanel();
    }
}
SearchComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: SearchComponent, deps: [{ token: FileSystemService }], target: i0.ɵɵFactoryTarget.Component });
SearchComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: SearchComponent, selector: "lib-search", outputs: { navigateToMarkdown: "navigateToMarkdown" }, host: { listeners: { "document:keydown.escape": "onKeydownHandler($event)" } }, viewQueries: [{ propertyName: "inputSearch", first: true, predicate: ["inputSearch"], descendants: true }], ngImport: i0, template: "<div clickOutside (clickOutside)=\"closePanel()\">\n    <button mat-fab color=\"primary\" (click)=\"openPanel()\" class=\"button-search\">\n        <mat-icon>search</mat-icon>\n    </button>\n    <div *ngIf=\"panelVisible\" class=\"panel-search\">\n        <div class=\"panel-results\">\n            <div *ngFor=\"let result of results\" (click)=\"navigateTo(result)\" class=\"item-result\">\n                {{ result.title | uppercase }}\n            </div>\n        </div>\n        <form class=\"panel-form\">\n            <mat-form-field>\n                <input\n                    #inputSearch\n                    matInput\n                    name=\"value\"\n                    [(ngModel)]=\"searchValue\"\n                    (ngModelChange)=\"search()\"\n                    autofocus\n                    autocomplete=\"off\"\n                />\n                <mat-icon *ngIf=\"!searchValue\" (click)=\"closePanel()\" class=\"icon-cross\" matSuffix>\n                    close\n                </mat-icon>\n                <mat-icon *ngIf=\"searchValue\" matSuffix>\n                    search\n                </mat-icon>\n            </mat-form-field>\n        </form>\n    </div>\n</div>\n", styles: [".button-search{position:absolute!important;right:20px;bottom:20px}.panel-search{position:absolute;display:flex;bottom:0;height:200px;width:100%;background-color:#444;box-shadow:0 0 5px 2px #0000004d}.panel-search .panel-results{color:#fff;padding:20px;display:flex;flex:100%;flex-direction:column;flex-wrap:wrap}.panel-search .panel-results .item-result{padding:10px;color:#dbdbdb;cursor:pointer;flex:1 0 5%}.panel-search .panel-results .item-result:hover{color:#fff}.panel-search .panel-form{align-self:flex-end;color:#fff;flex:1;text-align:right;margin-right:20px}.panel-search .panel-form ::ng-deep .mat-form-field-underline{background-color:#fff}.panel-search .icon-cross{cursor:pointer}\n"], components: [{ type: i2$1.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i4.MatFormField, selector: "mat-form-field", inputs: ["color", "floatLabel", "appearance", "hideRequiredMarker", "hintLabel"], exportAs: ["matFormField"] }], directives: [{ type: ClickOutsideDirective, selector: "[clickOutside]", outputs: ["clickOutside"] }, { type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i7.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { type: i7.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { type: i7.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { type: i8.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["id", "disabled", "required", "type", "value", "readonly", "placeholder", "errorStateMatcher", "aria-describedby"], exportAs: ["matInput"] }, { type: i7.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i7.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i7.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { type: i4.MatSuffix, selector: "[matSuffix]" }], pipes: { "uppercase": i3.UpperCasePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: SearchComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'lib-search',
                    templateUrl: './search.component.html',
                    styleUrls: ['./search.component.scss']
                }]
        }], ctorParameters: function () { return [{ type: FileSystemService }]; }, propDecorators: { navigateToMarkdown: [{
                type: Output
            }], inputSearch: [{
                type: ViewChild,
                args: ['inputSearch', { static: false }]
            }], onKeydownHandler: [{
                type: HostListener,
                args: ['document:keydown.escape', ['$event']]
            }] } });

class VersioningComponent {
    constructor() {
        this.versionChange = new EventEmitter();
    }
    selectionChange() {
        this.versionChange.emit(this.currentVersion);
    }
}
VersioningComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: VersioningComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
VersioningComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: VersioningComponent, selector: "lib-versioning", inputs: { versions: "versions", currentVersion: "currentVersion" }, outputs: { versionChange: "versionChange" }, ngImport: i0, template: "<mat-form-field>\n    <mat-label>Versions</mat-label>\n    <mat-select [(value)]=\"currentVersion\" (selectionChange)=\"selectionChange()\">\n        <mat-option *ngFor=\"let version of versions\" [value]=\"version\">\n            {{ version }}\n        </mat-option>\n    </mat-select>\n</mat-form-field>\n", styles: [""], components: [{ type: i4.MatFormField, selector: "mat-form-field", inputs: ["color", "floatLabel", "appearance", "hideRequiredMarker", "hintLabel"], exportAs: ["matFormField"] }, { type: i2$2.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex"], exportAs: ["matSelect"] }, { type: i3$1.MatOption, selector: "mat-option", exportAs: ["matOption"] }], directives: [{ type: i4.MatLabel, selector: "mat-label" }, { type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: VersioningComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'lib-versioning',
                    templateUrl: './versioning.component.html',
                    styleUrls: ['./versioning.component.scss']
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { versions: [{
                type: Input
            }], currentVersion: [{
                type: Input
            }], versionChange: [{
                type: Output
            }] } });

class EditButtonComponent {
    constructor() { }
    goToEdit() {
        window.open(this.path, '_blank');
    }
}
EditButtonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: EditButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
EditButtonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: EditButtonComponent, selector: "edit-button", inputs: { path: "path" }, ngImport: i0, template: "<button mat-icon-button aria-label=\"suggest edit\" (click)=\"goToEdit()\" class=\"edit-icon\" color=\"primary\">\n    <mat-icon>edit</mat-icon>\n</button>\n", styles: [".edit-icon{position:absolute!important;right:20px;top:0px}.edit-icon:hover{background-color:#eceff1}\n"], components: [{ type: i2$1.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: EditButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'edit-button',
                    templateUrl: './edit-button.component.html',
                    styleUrls: ['./edit-button.component.scss']
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { path: [{
                type: Input
            }] } });

class SnackBarCopyComponent {
    constructor() { }
}
SnackBarCopyComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: SnackBarCopyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
SnackBarCopyComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: SnackBarCopyComponent, selector: "lib-snack-bar-copy", ngImport: i0, template: "<div class=\"snack-container\">\n    <mat-icon color=\"primary\">content_copy</mat-icon>\n    <mat-icon class=\"check-icon\">check</mat-icon>\n</div>\n", styles: [".snack-container .check-icon{float:right}\n"], components: [{ type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: SnackBarCopyComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'lib-snack-bar-copy',
                    templateUrl: './snack-bar-copy.component.html',
                    styleUrls: ['./snack-bar-copy.component.scss']
                }]
        }], ctorParameters: function () { return []; } });

/**
 * Public service to manage the library
 */
class NgDocxService {
    constructor() {
        this.editEnableSubject = new BehaviorSubject(true);
        /**
         * Observable to know if you can edit the documents.
         */
        this.editEnable$ = this.editEnableSubject.asObservable();
    }
    /**
     * Set the edit button visibility.
     * @param enable boolean True if the edit button should be visible.
     */
    setEdit(enable) {
        this.editEnableSubject.next(enable);
    }
}
NgDocxService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
NgDocxService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

const DOCS_FOLDER = 'assets/docs/';
class NgDocxComponent {
    constructor(config, ngDocxService, docsService, utils, fileSystem, snackBar) {
        this.config = config;
        this.ngDocxService = ngDocxService;
        this.docsService = docsService;
        this.utils = utils;
        this.fileSystem = fileSystem;
        this.snackBar = snackBar;
        this.currentVersion = null;
        this.docsDir = DOCS_FOLDER;
        this.markdownBefore = null;
        this.searchValue = null;
        this.section = null;
        this.sidenavOpened = true;
    }
    ngOnInit() {
        this.docs$ = this.fileSystem.docs$;
        this.docs$.subscribe((docs) => {
            if (docs) {
                const markdownName = this.getQueryParamTitle();
                const folder = markdownName.indexOf('/') !== -1 ? markdownName.split('/')[0] : null;
                const title = folder ? markdownName.split('/')[1] : markdownName;
                this.section = this.utils.getHashURL();
                this.markdownName = this.docExists(docs, folder, title) ? markdownName : this.getFirstTitle(docs);
                this.loadMarkdown(this.markdownName);
            }
        });
        this.checkVersioning();
        this.fileSystem.loadDocs(this.docsDir, this.config.files);
    }
    docExists(docs, folder, title) {
        return docs[folder] ? docs[folder].some((doc) => doc.title === title) : false;
    }
    getFirstTitle(docs) {
        return docs[Object.keys(docs)[0]][0].title;
    }
    getQueryParamTitle() {
        const urlParams = new URLSearchParams(window.location.search);
        return decodeURIComponent(urlParams.get('title'));
    }
    checkVersioning() {
        if (this.config.versions) {
            this.currentVersion = this.config.versions[this.config.versions.length - 1];
            this.docsDir = `${DOCS_FOLDER}${this.currentVersion}/`;
        }
    }
    markdownChangeFromMenu(markdownName) {
        this.section = null;
        this.loadMarkdown(markdownName);
    }
    loadMarkdown(markdownName, searchValue = null) {
        this.markdownName = markdownName;
        this.markdownBefore = this.markdown;
        this.markdown = `${this.docsDir}${this.markdownName}.md`;
        this.writeQueryParam(this.markdownName);
        this.searchValue = searchValue;
        if (this.searchValue && this.markdownBefore === this.markdown) {
            this.unmarkSearch();
            this.markSearchAndNavigate(this.searchValue);
            this.searchValue = null;
        }
    }
    writeQueryParam(markdownName) {
        const hash = this.section ? window.location.hash : '';
        window.history.replaceState(null, null, `${window.location.pathname}?title=${encodeURIComponent(markdownName)}${hash}`);
    }
    notifyMarkdownChanges() {
        if (this.markdownBefore !== this.markdown) {
            this.docsService.notifyMarkdownChanges();
            document.querySelector('.mat-sidenav-content').scrollTop = 0;
        }
        if (this.searchValue) {
            this.markSearchAndNavigate(this.searchValue);
            this.searchValue = null;
        }
    }
    sectionsLoaded() {
        this.highlightHeader();
        if (this.section && !Number.isNaN(this.section)) {
            setTimeout(() => {
                var _a;
                const positionSection = (_a = document.getElementById(this.section.toString())) === null || _a === void 0 ? void 0 : _a.getBoundingClientRect().top;
                this.navigateToPosition(positionSection);
            });
        }
        this.addSectionLinks();
    }
    navigateToPosition(position) {
        const matSidenavContent = document.querySelector('.mat-sidenav-content');
        const toolbar = document.getElementsByTagName('mat-toolbar')[0];
        const someSpace = 10;
        if (matSidenavContent) {
            matSidenavContent.scrollTop =
                matSidenavContent.scrollTop +
                    position -
                    (toolbar ? toolbar.getBoundingClientRect().height : 0) -
                    someSpace;
        }
    }
    onScroll() {
        this.highlightHeader();
    }
    highlightHeader() {
        const sections = document.getElementsByTagName('section');
        const arrSections = [...sections];
        arrSections.some((section, index) => {
            const positionSection = section.getBoundingClientRect();
            if (positionSection.top >= 0 && positionSection.bottom <= window.innerHeight) {
                this.hightlightItem(index);
                return true;
            }
        });
    }
    hightlightItem(index) {
        const className = 'navigation-item-selected';
        const currentSelected = document.getElementsByClassName(`navigation-item-selected`)[0];
        const item = document.getElementById(`navItem${index}`);
        if (currentSelected !== item) {
            if (currentSelected) {
                currentSelected.classList.remove(className);
            }
            if (item) {
                item.classList.add(className);
            }
        }
    }
    addSectionLinks() {
        const sections = document.getElementsByTagName('section');
        const arrSections = [...sections];
        arrSections.some((section, index) => {
            this.addSectionLink(section, index);
        });
    }
    addSectionLink(section, index) {
        const newSectionLink = document.createElement('i');
        newSectionLink.setAttribute('index', index.toString());
        newSectionLink.className = 'material-icons ng-docx-section-link';
        newSectionLink.innerText = 'link';
        newSectionLink.addEventListener('click', (event) => {
            const currentURL = this.utils.getURLWithoutHash();
            this.utils.copyOnClipboard(`${currentURL}#${event.target.getAttribute('index')}`);
            this.openSnackBarCopied();
        });
        section.childNodes[0].appendChild(newSectionLink);
    }
    openSnackBarCopied() {
        this.snackBar.openFromComponent(SnackBarCopyComponent, {
            duration: 1000
        });
    }
    switchSidenav() {
        this.sidenavOpened = !this.sidenavOpened;
    }
    unmarkSearch() {
        const context = document.querySelector('markdown');
        const instance = new Mark(context);
        instance.unmark();
    }
    markSearchAndNavigate(text) {
        const context = document.querySelector('markdown');
        const instance = new Mark(context);
        instance.mark(text);
        const markElement = document.querySelector('mark');
        if (markElement) {
            this.navigateToPosition(markElement.getBoundingClientRect().top);
        }
    }
    versionChange(newVersion) {
        this.currentVersion = newVersion;
        this.docsDir = `${DOCS_FOLDER}${this.currentVersion}/`;
        this.fileSystem.loadDocs(this.docsDir, this.config.files);
    }
}
NgDocxComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxComponent, deps: [{ token: 'config' }, { token: NgDocxService }, { token: DocsService }, { token: UtilsService }, { token: FileSystemService }, { token: i5.MatSnackBar }], target: i0.ɵɵFactoryTarget.Component });
NgDocxComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.2.15", type: NgDocxComponent, selector: "ng-docx", ngImport: i0, template: "<mat-sidenav-container class=\"sidenav-container\">\n    <mat-sidenav [opened]=\"sidenavOpened\" mode=\"side\" opened class=\"sidenav-left\">\n        <lib-navigation-menu\n            [currentFile]=\"markdownName\"\n            (markdownChange)=\"markdownChangeFromMenu($event)\"\n        ></lib-navigation-menu>\n        <hr *ngIf=\"currentVersion\" class=\"versioning-separator\" />\n        <lib-versioning\n            *ngIf=\"currentVersion\"\n            [versions]=\"config.versions\"\n            [currentVersion]=\"currentVersion\"\n            (versionChange)=\"versionChange($event)\"\n            class=\"versioning\"\n        ></lib-versioning>\n    </mat-sidenav>\n    <mat-sidenav-content (scroll)=\"onScroll()\">\n        <div>\n            <button mat-icon-button aria-label=\"menu icon\" (click)=\"switchSidenav()\" class=\"menu-icon\">\n                <mat-icon>{{ sidenavOpened ? 'menu_open' : 'menu' }}</mat-icon>\n            </button>\n            <edit-button\n                *ngIf=\"config.editAssetsPath && ngDocxService.editEnable$ | async\"\n                [path]=\"config.editAssetsPath + '/' + docsDir + markdownName + '.md'\"\n            >\n            </edit-button>\n            <markdown [src]=\"markdown\" (ready)=\"notifyMarkdownChanges()\" lineNumbers></markdown>\n        </div>\n    </mat-sidenav-content>\n    <mat-sidenav class=\"sidenav-right\" opened mode=\"side\" position=\"end\">\n        <lib-navigation-tree (sectionsLoaded)=\"sectionsLoaded()\"></lib-navigation-tree>\n    </mat-sidenav>\n</mat-sidenav-container>\n<lib-search (navigateToMarkdown)=\"loadMarkdown($event.title, $event.search)\"></lib-search>\n", styles: ["::-webkit-scrollbar{width:5px;color:0}::-webkit-scrollbar-track{background:#f1f1f1}::-webkit-scrollbar-thumb{background:#888}::-webkit-scrollbar-thumb:hover{background:#555}mat-sidenav-content{background-color:#fff}mat-sidenav-content>div{padding:30px}lib-search{position:absolute;bottom:0;width:100%;z-index:1}section:hover .ng-docx-section-link{display:initial}.ng-docx-section-link{color:#6e6e6e;cursor:pointer;display:none;position:absolute}.sidenav-container{position:relative;height:100%;background:#eee}.sidenav-container mat-sidenav{width:200px}.sidenav-container mat-sidenav.sidenav-right{width:240px}.sidenav-container .sidenav-left{box-shadow:6px 0 6px #0000001a}.sidenav-container .mat-drawer-side.mat-drawer-end{border-left:none}.menu-icon{position:absolute!important;left:-3px;top:-5px}.highlight-search{background-color:#ff0}.versioning-separator{margin-right:8px;margin-left:8px;border-top:1px solid #dbdbdb}.versioning{padding:8px}.versioning .mat-form-field{width:90%}\n"], components: [{ type: i6.MatSidenavContainer, selector: "mat-sidenav-container", exportAs: ["matSidenavContainer"] }, { type: i6.MatSidenav, selector: "mat-sidenav", inputs: ["fixedInViewport", "fixedTopGap", "fixedBottomGap"], exportAs: ["matSidenav"] }, { type: NavigationMenuComponent, selector: "lib-navigation-menu", inputs: ["currentFile"], outputs: ["markdownChange"] }, { type: VersioningComponent, selector: "lib-versioning", inputs: ["versions", "currentVersion"], outputs: ["versionChange"] }, { type: i6.MatSidenavContent, selector: "mat-sidenav-content" }, { type: i2$1.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: EditButtonComponent, selector: "edit-button", inputs: ["path"] }, { type: i12.MarkdownComponent, selector: "markdown, [markdown]", inputs: ["emoji", "katex", "lineHighlight", "lineNumbers", "data", "src", "katexOptions", "line", "lineOffset", "start"], outputs: ["error", "load", "ready"] }, { type: NavigationTreeComponent, selector: "lib-navigation-tree", outputs: ["sectionsLoaded"] }, { type: SearchComponent, selector: "lib-search", outputs: ["navigateToMarkdown"] }], directives: [{ type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "async": i3.AsyncPipe }, encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ng-docx',
                    templateUrl: './docs.component.html',
                    styleUrls: ['./docs.component.scss'],
                    encapsulation: ViewEncapsulation.None
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: ['config']
                }] }, { type: NgDocxService }, { type: DocsService }, { type: UtilsService }, { type: FileSystemService }, { type: i5.MatSnackBar }]; } });

const childRoutes = [{ path: '', component: NgDocxComponent }];
class NgDocxModule {
    static forRoot(configuration) {
        return {
            ngModule: NgDocxModule,
            providers: [{ provide: 'config', useValue: configuration }]
        };
    }
}
NgDocxModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
NgDocxModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxModule, declarations: [NgDocxComponent,
        NavigationTreeComponent,
        NavigationMenuComponent,
        SearchComponent,
        ClickOutsideDirective,
        VersioningComponent,
        EditButtonComponent,
        SnackBarCopyComponent], imports: [CommonModule, i1$1.RouterModule, MatButtonModule,
        MatIconModule,
        MatSidenavModule,
        MatInputModule,
        MatFormFieldModule,
        MatSelectModule,
        MatSnackBarModule,
        FormsModule,
        HttpClientModule, i12.MarkdownModule] });
NgDocxModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxModule, providers: [FileSystemService], imports: [[
            CommonModule,
            RouterModule.forChild(childRoutes),
            MatButtonModule,
            MatIconModule,
            MatSidenavModule,
            MatInputModule,
            MatFormFieldModule,
            MatSelectModule,
            MatSnackBarModule,
            FormsModule,
            HttpClientModule,
            MarkdownModule.forRoot({ loader: HttpClient })
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.15", ngImport: i0, type: NgDocxModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        NgDocxComponent,
                        NavigationTreeComponent,
                        NavigationMenuComponent,
                        SearchComponent,
                        ClickOutsideDirective,
                        VersioningComponent,
                        EditButtonComponent,
                        SnackBarCopyComponent
                    ],
                    imports: [
                        CommonModule,
                        RouterModule.forChild(childRoutes),
                        MatButtonModule,
                        MatIconModule,
                        MatSidenavModule,
                        MatInputModule,
                        MatFormFieldModule,
                        MatSelectModule,
                        MatSnackBarModule,
                        FormsModule,
                        HttpClientModule,
                        MarkdownModule.forRoot({ loader: HttpClient })
                    ],
                    providers: [FileSystemService],
                    entryComponents: [SnackBarCopyComponent]
                }]
        }] });

/*
 * Public API Surface of ng-docx
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgDocxComponent, NgDocxModule, NgDocxService };
//# sourceMappingURL=ng-docx.js.map
