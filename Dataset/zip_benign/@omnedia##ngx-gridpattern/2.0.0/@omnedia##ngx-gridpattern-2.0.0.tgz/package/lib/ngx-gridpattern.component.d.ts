import { ElementRef } from "@angular/core";
import * as i0 from "@angular/core";
export declare class NgxGridpatternComponent {
    elementRef: ElementRef<HTMLElement>;
    styleClass?: string;
    set smallGridValue(smallGrid: boolean);
    smallGrid: boolean;
    set gridColorValue(color: string);
    gridColor: string;
    set gradientColorValue(color: string);
    gradientColor: string;
    gridStyle: any;
    setGridStyle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxGridpatternComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxGridpatternComponent, "om-gridpattern", never, { "styleClass": { "alias": "styleClass"; "required": false; }; "smallGridValue": { "alias": "smallGrid"; "required": false; }; "gridColorValue": { "alias": "gridColor"; "required": false; }; "gradientColorValue": { "alias": "gradientColor"; "required": false; }; }, {}, never, ["*"], true, never>;
}
