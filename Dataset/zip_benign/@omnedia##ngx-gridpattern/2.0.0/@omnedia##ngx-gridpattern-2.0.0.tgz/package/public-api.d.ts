export * from './lib/ngx-gridpattern.component';
