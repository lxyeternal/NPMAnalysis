import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, ViewChild, Input } from '@angular/core';

class NgxGridpatternComponent {
    constructor() {
        this.smallGrid = false;
        this.gridColor = "rgba(255, 255, 255, 0.2)";
        this.gradientColor = "rgb(0, 0, 0)";
        this.gridStyle = {};
    }
    set smallGridValue(smallGrid) {
        this.smallGrid = smallGrid;
        this.setGridStyle();
    }
    set gridColorValue(color) {
        this.gridColor = color;
        this.setGridStyle();
    }
    set gradientColorValue(color) {
        this.gradientColor = color;
        this.setGridStyle();
    }
    setGridStyle() {
        let dataUri = "";
        if (this.smallGrid) {
            dataUri = `data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='16' height='16' fill='none' stroke='${this.gridColor}' %3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e`;
        }
        else {
            dataUri = `data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='32' height='32' fill='none' stroke='${this.gridColor}' %3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e`;
        }
        this.gridStyle["background-image"] = `url("${dataUri}")`;
        this.gridStyle["--om-gridpattern-gradient-color"] = this.gradientColor;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.3", ngImport: i0, type: NgxGridpatternComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.0.3", type: NgxGridpatternComponent, isStandalone: true, selector: "om-gridpattern", inputs: { styleClass: "styleClass", smallGridValue: ["smallGrid", "smallGridValue"], gridColorValue: ["gridColor", "gridColorValue"], gradientColorValue: ["gradientColor", "gradientColorValue"] }, viewQueries: [{ propertyName: "elementRef", first: true, predicate: ["OmGridPatternBackground"], descendants: true }], ngImport: i0, template: "<div class=\"om-gridpattern\" [ngClass]=\"styleClass\">\n    <div class=\"om-gridpattern-background\" [ngStyle]=\"gridStyle\" [class.om-gridpattern-background-small]=\"smallGrid\">\n        <div class=\"om-gridpattern-gradient\"></div>\n    </div>\n    <ng-content></ng-content>\n</div>", styles: [".om-gridpattern{position:relative;overflow:hidden;width:100%;height:100%}.om-gridpattern .om-gridpattern-background{--om-gridpattern-gradient-color: rgb(0, 0, 0);position:absolute;pointer-events:none;height:100%;width:100%;background-image:url(\"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='32' height='32' fill='none' stroke='rgba(255, 255, 255, 0.2)'%3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e\")}.om-gridpattern .om-gridpattern-background.om-gridpattern-background-small{background-image:url(\"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='16' height='16' fill='none' stroke='rgba(255, 255, 255, 0.2)'%3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e\")}.om-gridpattern .om-gridpattern-background .om-gridpattern-gradient{position:absolute;inset:0;-webkit-mask-image:radial-gradient(ellipse at center,transparent 10%,#000);mask-image:radial-gradient(ellipse at center,transparent 10%,#000);background-color:var(--om-gridpattern-gradient-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.3", ngImport: i0, type: NgxGridpatternComponent, decorators: [{
            type: Component,
            args: [{ selector: "om-gridpattern", standalone: true, imports: [CommonModule], template: "<div class=\"om-gridpattern\" [ngClass]=\"styleClass\">\n    <div class=\"om-gridpattern-background\" [ngStyle]=\"gridStyle\" [class.om-gridpattern-background-small]=\"smallGrid\">\n        <div class=\"om-gridpattern-gradient\"></div>\n    </div>\n    <ng-content></ng-content>\n</div>", styles: [".om-gridpattern{position:relative;overflow:hidden;width:100%;height:100%}.om-gridpattern .om-gridpattern-background{--om-gridpattern-gradient-color: rgb(0, 0, 0);position:absolute;pointer-events:none;height:100%;width:100%;background-image:url(\"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='32' height='32' fill='none' stroke='rgba(255, 255, 255, 0.2)'%3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e\")}.om-gridpattern .om-gridpattern-background.om-gridpattern-background-small{background-image:url(\"data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='16' height='16' fill='none' stroke='rgba(255, 255, 255, 0.2)'%3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e\")}.om-gridpattern .om-gridpattern-background .om-gridpattern-gradient{position:absolute;inset:0;-webkit-mask-image:radial-gradient(ellipse at center,transparent 10%,#000);mask-image:radial-gradient(ellipse at center,transparent 10%,#000);background-color:var(--om-gridpattern-gradient-color)}\n"] }]
        }], propDecorators: { elementRef: [{
                type: ViewChild,
                args: ["OmGridPatternBackground"]
            }], styleClass: [{
                type: Input,
                args: ["styleClass"]
            }], smallGridValue: [{
                type: Input,
                args: ["smallGrid"]
            }], gridColorValue: [{
                type: Input,
                args: ["gridColor"]
            }], gradientColorValue: [{
                type: Input,
                args: ["gradientColor"]
            }] } });

/*
 * Public API Surface of ngx-gridpattern
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxGridpatternComponent };
//# sourceMappingURL=omnedia-ngx-gridpattern.mjs.map
