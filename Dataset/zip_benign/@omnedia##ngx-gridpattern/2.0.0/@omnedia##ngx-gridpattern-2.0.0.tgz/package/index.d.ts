/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@omnedia/ngx-gridpattern" />
export * from './public-api';
