var should = require('should')
var mongoose = require('mongoose')
var models = require('./helpers')
var Async = require('../lib/Async')

mongoose.connect('mongodb://localhost:27017/atticue_test')

describe('denormalize', function() {

  var foo = new models.Foo()
  var bar = new models.Bar()
  var baz = new models.Baz()
  var async = new Async()

  beforeEach(function(done) {
    bar.faux = baz.faux = 'faux'
    bar.quas = 'bar.quas'
    baz.quas = 'baz.quas'
    done()
  })

  after(function(done) {
    models.Foo.remove({}, function() {})
    models.Bar.remove({}, function() {})
    models.Baz.remove({}, function() {
      done()
    })
  })

  describe('pull', function() {

    beforeEach(function(done) {
      bar.save(function() {})
      baz.save(function(err) {

        foo.bar = bar._id
        done()
      })

    })

    it('should fetch data from refs', function(done) {
      foo.save(function(err, foo) {
        foo.bar.faux
          .should
          .equal('faux')
        done()
      })
    })

    it('should fetch data from objects inside objects', function(done) {

      foo.ref.baz = baz._id
      foo.save(function(err, foo) {
        foo.ref.baz.quas
          .should
          .equal('baz.quas')
        done()
      })
    })

  })

  describe('push', function() {

    it('should push out changes', function(done) {
      bar.faux = 'new faux'
      bar.save(function() {

        models.Foo.findOne({ 'bar._id': bar._id }, function(err, foo) {

          foo.bar.faux
            .should
            .equal('new faux')
          done()
        })
      })
    })

    it('should push out changes to objects inside objects', function(done) {
      baz.faux = 'new faux'
      baz.save(function() {

        models.Foo.findOne({ 'ref.baz._id': baz._id }, function(err, foo) {

          foo.ref.baz.faux
            .should
            .equal('new faux')
          done()
        })
      })

    });

  })

})
