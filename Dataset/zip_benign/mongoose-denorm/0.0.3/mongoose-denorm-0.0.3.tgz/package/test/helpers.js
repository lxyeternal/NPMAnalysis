var mongoose = require('mongoose');
var denormalize = require('../lib/denormalize');

var Mixed = mongoose.Schema.Types.Mixed;
var FooSchema = new mongoose.Schema({
    bar: { type: Mixed, ref: 'bars', fields: ['faux', 'quas'] },
    ref: {
      baz: { type: Mixed, ref: 'bazs', fields: ['quas'] }
    }
});

var BarSchema = new mongoose.Schema({
    faux: { type: String, maps: ['foos'] },
    quas: { type: String, maps: ['foos'] }
});

var BazSchema = new mongoose.Schema({
    faux: { type: String, maps: ['foos'] },
    quas: { type: String, maps: ['foos'] }
})

FooSchema.plugin(denormalize);
BarSchema.plugin(denormalize);
BazSchema.plugin(denormalize);

exports.Foo = mongoose.model('foos', FooSchema);
exports.Bar = mongoose.model('bars', BarSchema);
exports.Baz = mongoose.model('bazs', BazSchema);
