module.exports = require('./lib/denormalize');
