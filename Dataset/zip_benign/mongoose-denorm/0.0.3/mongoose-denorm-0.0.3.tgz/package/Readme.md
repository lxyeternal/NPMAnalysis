# Mongoose-elastic

Simple two-way denormalization for mongoose schemas.

## Version
0.3

## Tech
* Mongoose

## Directory Structure
```sh
|---mongoose-elastic
   |-lib
   |-test
```
## Install
```sh
npm install mongoose-elastic --save
```

## Setup

Add a mapping and prefix.
```sh
activitySchema.plugin(elastic, { prefix: 'dev',
  mapping: {

    message: String,
    event: {
      title: String
    }
  }
})
```
=======
## Examples
```sh
var mongoose = require('mongoose');

var denormalize = require('./lib/denormalize');
var Mixed = mongoose.Schema.Types.Mixed;

```sh
var activitySchema = new mongoose.Schema({
  message           :   String,
  event           : { type: Mixed, ref: 'events', fields: ['title', 'uName', 'address'] },
  user            : { type: Mixed, ref: 'users', fields: ['uName'] },
});

var eventSchema = new mongoose.Schema({
  uName    : { type: String, maps: ['activities'] },
  title: { type: String, maps: ['activities'] },
  address: String,
  location: [0, 3]
})

var userSchema = new mongoose.Schema({
  uName: String,
  fullName: String
})

// automatically all data on save, not just 'changed' fields
activitySchema.plugin(denormalize, { sync: true });
userSchema.plugin(denormalize);
eventSchema.plugin(denormalize);
```

var Activity = mongoose.model('activities', activitySchema)
var User = mongoose.model('users', userSchema)
var Event = mongoose.model('events', eventSchema)

mongoose.connect('mongodb://localhost:27017/test')

// create models
var event = new Event({
  uName: 'eventUName',
  title: 'Smashboxx',
  address: 'Scottsdale, AZ',
  location: [0, 3]
 })

var user = new User({
  uName: 'username',
  fullName: 'John Doe'
})

/*
  Now just save docs and activity will
  be denormalized.
 */
var activity = new Activity({
  message: 'Im denormalized! Yay!',
  user: user.id,
  event: event.id
})
```

## Tests
-----------
```sh
make test
```

