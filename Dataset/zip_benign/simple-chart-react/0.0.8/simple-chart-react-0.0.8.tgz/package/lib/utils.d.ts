import { AxisParams, AxisValue, ChartSize } from "./interfaces";
export declare const lineChartSize: ChartSize;
export declare const chartVerticalPadding = 20;
export declare const mergeStyles: (...styles: (string | boolean | undefined)[]) => string;
export declare const getAxisValues: (totalLength: number, values: (string | number)[]) => {
    values: AxisValue[];
    params: AxisParams;
};
export declare const trimValue: (value: number | string, length?: number) => string | number;
