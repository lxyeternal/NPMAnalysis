export declare const colors: {
    blacks: string[];
};
