/// <reference types="react" />
import { AxisT, AxisValue } from "../interfaces";
import "../styles/axis.css";
interface Props {
    axes: AxisT[];
    values: AxisValue[];
    valuesHorizontal: AxisValue[];
    width: number;
    height: number;
}
export declare const Axes: ({ axes, values, valuesHorizontal, height, width }: Props) => JSX.Element;
export {};
