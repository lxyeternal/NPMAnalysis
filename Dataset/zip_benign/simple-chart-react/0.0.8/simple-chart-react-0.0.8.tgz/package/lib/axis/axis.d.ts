/// <reference types="react" />
import { AxisValue } from "../interfaces";
interface Props {
    name: string;
    values: AxisValue[];
    isHorizontal?: boolean;
    length: number;
}
export declare const Axis: ({ name, values, isHorizontal, length }: Props) => JSX.Element;
export {};
