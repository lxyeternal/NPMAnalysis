/// <reference types="react" />
import { AxisParams, ChartValue } from "../../interfaces";
interface Props {
    points: ChartValue[];
    keys: string[];
    axisParams: AxisParams;
    axisHorizontalParams: AxisParams;
    height: number;
    color?: string;
}
export declare const PointsLines: ({ points, keys, axisParams, axisHorizontalParams, height, color }: Props) => JSX.Element;
export {};
