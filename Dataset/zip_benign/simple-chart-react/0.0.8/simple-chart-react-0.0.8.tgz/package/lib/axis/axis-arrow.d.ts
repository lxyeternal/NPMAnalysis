/// <reference types="react" />
interface Props {
    isBottom?: boolean;
}
export declare const AxisArrow: ({ isBottom }: Props) => JSX.Element;
export {};
