/// <reference types="react" />
import { AxisT, ChartValue } from "./interfaces";
import "./styles/styles.css";
interface Props {
    data: ChartValue[];
    axes: AxisT[];
    width?: number;
    height?: number;
    lineColor?: string;
}
export declare const LineChart: ({ data, axes, width, height, lineColor }: Props) => JSX.Element;
export {};
