export default parse;
/**
 * 构建样式
 * @param {Object} settings 配置 { text, stroke, circle, fill, icon, image}
 * @param {Object} [StyleModel]
 * @return {Style}
 */
declare function parse(settings: Object, StyleModel?: Object | undefined): Style;
import { Style } from "ol/style";
