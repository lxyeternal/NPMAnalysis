/**
 * 构造箭头样式
 * @param {number[]} start 起点经纬度
 * @param {number[]} end 终点经纬度
 * @param {Object|Boolean|String} opts 箭头Icon配置项
 * @param {Object} [defaultValue] 默认配置项
 * @return {Style}
 */
export default function _default(start: number[], end: number[], opts?: Object | boolean | string, defaultValue?: Object | undefined): Style;
