import type { ExtractPropTypes } from 'vue';
/**
 * @member props
 * @property {number[]} [coordinates] 地图坐标
 */
export declare const polygonProps: {
    readonly coordinates: import("../utils/props/types").EpPropFinalized<(new (...args: any[]) => number[][]) | (() => number[][]) | ((new (...args: any[]) => number[][]) | (() => number[][]))[], unknown, unknown, () => never[], boolean>;
    readonly zIndex: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props/types").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props/types").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
};
export declare type PolygonProps = ExtractPropTypes<typeof polygonProps>;
