export function getWMTSGrid(proj?: string): WMTSGrid;
/**
 * 创建 WMTS 资源瓦片图层
 * @param settings
 * @returns {*|TileLayer}
 */
export function createWMTSLayer(settings: any): any | TileLayer<any>;
/**
 * 适配图层加载
 * @param {string|object|function} adapter 适配器 object: {id, type, url, layers}
 * @param {object} opts
 * @return {LayerGroup|TileLayer|*}
 */
export function createLayer(adapter: string | object | Function, opts?: object): LayerGroup | TileLayer<any> | any;
import WMTSGrid from "ol/tilegrid/WMTS";
import TileLayer from "ol/layer/Tile";
import LayerGroup from "ol/layer/Group";
