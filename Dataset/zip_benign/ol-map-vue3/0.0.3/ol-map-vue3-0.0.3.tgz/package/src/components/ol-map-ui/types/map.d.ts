import type { ExtractPropTypes } from 'vue';
export declare const mapProps: {
    readonly zoom: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly minZoom: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly maxZoom: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 20, boolean>;
    readonly center: import("../utils/props/types").EpPropFinalized<(new (...args: any[]) => number[]) | (() => number[]) | ((new (...args: any[]) => number[]) | (() => number[]))[], unknown, unknown, () => number[], boolean>;
    readonly adapter: import("../utils/props/types").EpPropFinalized<readonly [StringConstructor, ObjectConstructor, FunctionConstructor], unknown, unknown, "Baidu", boolean>;
    readonly projection: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "EPSG:4326", boolean>;
    readonly width: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly height: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "400px", boolean>;
    readonly dragPan: import("../utils/props/types").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly mouseWheelZoom: import("../utils/props/types").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly mapOptions: ObjectConstructor;
    readonly viewOptions: ObjectConstructor;
    readonly invert: BooleanConstructor;
    readonly filter: ObjectConstructor;
};
export declare type MapProps = ExtractPropTypes<typeof mapProps>;
