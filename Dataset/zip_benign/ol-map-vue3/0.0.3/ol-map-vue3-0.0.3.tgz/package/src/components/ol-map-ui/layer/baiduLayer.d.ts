export default function _default(settings: any): Tile<XYZ>;
import XYZ from "ol/source/XYZ";
import Tile from "ol/layer/Tile";
