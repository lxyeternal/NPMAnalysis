import Overlay from 'ol/Overlay';
declare const _sfc_main: import("vue").DefineComponent<{
    readonly id: import("../utils/props").EpPropFinalized<(new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, 0, boolean>;
    readonly offset: import("../utils/props").EpPropFinalized<(new (...args: any[]) => [number, number]) | (() => [number, number]) | ((new (...args: any[]) => [number, number]) | (() => [number, number]))[], unknown, unknown, () => number[], boolean>;
    readonly position: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly positioning: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "center-center", boolean>;
    readonly stopEvent: import("../utils/props").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly insertFirst: BooleanConstructor;
    readonly autoPan: import("../utils/props").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly autoPanAnimation: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
    readonly autoPanMargin: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 20, boolean>;
    readonly visible: import("../utils/props").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}, {
    props: any;
    myMap: any;
    show: import("vue/macros").ReactiveVariable<false> | import("vue/macros").ReactiveVariable<true>;
    olMapHtml: import("vue/macros").ReactiveVariable<HTMLElement> | undefined;
    overlay: import("vue/macros").ReactiveVariable<Overlay> | undefined;
    init: () => void;
    setPosition: (position: any) => void;
    dispose: () => void;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly id: import("../utils/props").EpPropFinalized<(new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, 0, boolean>;
    readonly offset: import("../utils/props").EpPropFinalized<(new (...args: any[]) => [number, number]) | (() => [number, number]) | ((new (...args: any[]) => [number, number]) | (() => [number, number]))[], unknown, unknown, () => number[], boolean>;
    readonly position: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly positioning: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "center-center", boolean>;
    readonly stopEvent: import("../utils/props").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly insertFirst: BooleanConstructor;
    readonly autoPan: import("../utils/props").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly autoPanAnimation: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
    readonly autoPanMargin: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 20, boolean>;
    readonly visible: import("../utils/props").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}>>, {
    readonly id: any;
    readonly offset: [number, number];
    readonly positioning: string;
    readonly stopEvent: import("../utils/props").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoPan: import("../utils/props").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoPanAnimation: Record<string, any>;
    readonly autoPanMargin: number;
    readonly visible: import("../utils/props").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly insertFirst: boolean;
}>;
export default _sfc_main;
