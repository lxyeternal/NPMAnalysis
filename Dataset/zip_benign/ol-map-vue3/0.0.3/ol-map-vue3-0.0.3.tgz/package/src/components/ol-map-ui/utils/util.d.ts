/**
 * 从Vue实例提取参数构造参数集合
 * @param vm
 * @param keys
 * @return {null}
 */
export function mergeProps(vm: any, keys?: any[]): null;
/**
 * 阶乘
 * @param num
 * @return {number}
 */
export function factorial(num: any): number;
/**
 * 生成贝塞尔曲线
 * @param points
 * @param space 必须要大于0
 * @return {Array}
 */
export function createBezierCurvePoints(points?: any[], space?: number): any[];
/**
 * 创建曲线的点
 * @param {number[]} from 起点
 * @param {number[]} to 终点
 * @param {number} radius 半径
 * @param {number} angle 角度
 * @param {number} space
 * @return {Array}
 */
export function createCurvePoints(from: number[], to: number[], radius?: number, angle?: number, space?: number): any[];
/**
 * 对线条增加间隔点
 * @param {Array[]} coordinates 线条坐标数组，支持曲线
 * @param {number} space 点的间隔距离，经纬度单位，值越小，增加的点越多
 * @return {Array[]}
 */
export function createLinePathPoints(coordinates?: any[][], space?: number): any[][];
/**
 * 格式化数字，修复精度问题
 * @param number
 * @return {number}
 */
export function parseDecimal(number: any): number;
/**
 * 检测两个经纬度是否相同
 * @param coordinate1
 * @param coordinate2
 * @return {boolean|boolean}
 */
export function coordinateEqual(coordinate1: any, coordinate2: any): boolean | boolean;
/**
 * 针对ECharts提供的GeoJSON进行解码
 * @param json
 * @return {{features}|*}
 */
export function geoJsonDecode(json: any): any;
/**
 * 计算两经纬度坐标点距离，
 * @param {Array} coordinate1 标准经纬度坐标数组,如：[113.38585096783513, 22.96213834599851]；
 * @param {Array} coordinate2 标准经纬度坐标数组,如：[113.38585096783513, 22.96213834599851]；
 * @return {Number} 返回距离，单位为米；
 */
export function getDistance(coordinate1: any[], coordinate2: any[]): number;
export function getScale(map: any, mapComp: any): number;
/**
 * Icon 字体转 图片 方法（用于大批量icon在地图中实现）
 * @param {String} fontClass icon 的名称
 * @param {Number} size icon 大小
 * @param {String} color icon 颜色
 * @param {String} fontFamily icon 字体的类型 （IconFont / 'element-icons'）
 * @return {Promise} Promise(img)
 */
export function svgToImg(fontClass: string, size: number, color: string, fontFamily?: string): Promise<any>;
/**
 * 墨卡托坐标转换成WGS84坐标，即 EPSG:4326 转换成  EPSG:3857
 * @param {number[]|Array[]} coordinate
 * @returns {Array}
 */
export function fromLonLat(coordinate: number[] | any[][]): any[];
/**
 * WGS84坐标转换成墨卡托坐标，即 EPSG:3857 转换成  EPSG:4326
 * @param {number[]|Array[]} coordinate
 * @returns {Array}
 */
export function toLonLat(coordinate: number[] | any[][]): any[];
export function decodePolygon(coordinate: any, encodeOffsets: any): number[][];
