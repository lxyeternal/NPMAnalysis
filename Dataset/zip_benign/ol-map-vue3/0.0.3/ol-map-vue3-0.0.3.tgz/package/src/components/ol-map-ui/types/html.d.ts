import type { ExtractPropTypes } from 'vue';
/**
   * 属性参数
   * @member props
   * @property {string} [id] html 元素 id
   * @property {number[]} [offset] html 相对 position 的 xy偏移值 单位px
   * @property {number[]} [position] 地图坐标
   * @property {String} [positioning] html 相对 position的 定位原点， 可选值： 'bottom-left', 'bottom-center', 'bottom-right', 'center-left', 'center-center', 'center-right', 'top-left', 'top-center', and 'top-right'
   * @property {Boolean} [stopEvent] 是否阻隔鼠标对地图的作用事件。默认 true
   * @property {Boolean} [insertFirst] 是否预先添加进地图
   * @property {Boolean} [autoPan] 控制地图在 html元素通过 setPosition 展示在地图上时，地图视口自动定位到html 可以显示的范围
   * @property {Object} [autoPanAnimation] autoPan为true时地图视口移动的动画配置 {duration: 2000,  easing: easeIn}
   * @property {Number} [autoPanMargin] autoPan为true时地图视口移动到出现html元素显示位置的距离
   * @property {Boolean} [visible=true] 是否可见
   */
export declare const htmlProps: {
    readonly id: import("../utils/props/types").EpPropFinalized<(new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    } | ((new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    })[], unknown, unknown, 0, boolean>;
    readonly offset: import("../utils/props/types").EpPropFinalized<(new (...args: any[]) => [number, number]) | (() => [number, number]) | ((new (...args: any[]) => [number, number]) | (() => [number, number]))[], unknown, unknown, () => number[], boolean>;
    readonly position: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly positioning: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "center-center", boolean>;
    readonly stopEvent: import("../utils/props/types").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly insertFirst: BooleanConstructor;
    readonly autoPan: import("../utils/props/types").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly autoPanAnimation: import("../utils/props/types").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
    readonly autoPanMargin: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 20, boolean>;
    readonly visible: import("../utils/props/types").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
};
export declare type HtmlProps = ExtractPropTypes<typeof htmlProps>;
