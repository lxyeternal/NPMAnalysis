import OlMap from './components/OlMap.vue';
import OlMapCircle from './components/OlMapCircle.vue';
import OlMapLine from './components/OlMapLine.vue';
import OlMapPolygon from './components/OlMapPolygon.vue';
import OlMapText from './components/OlMapText.vue';
import OlMapHtml from './components/OlMapHtml.vue';
export { OlMap, OlMapCircle, OlMapLine, OlMapPolygon, OlMapText, OlMapHtml };
declare const OlMapUI: {
    install(App: any): void;
};
export default OlMapUI;
