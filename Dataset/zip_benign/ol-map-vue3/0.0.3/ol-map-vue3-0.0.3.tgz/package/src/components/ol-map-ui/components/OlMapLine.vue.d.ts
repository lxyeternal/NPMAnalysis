import LineString from 'ol/geom/LineString';
import Feature from 'ol/Feature';
import { watch, inject } from 'vue';
import parseStyle from '../utils/style';
import createArrow from '../utils/arrow';
import { createBezierCurvePoints } from '../utils/util';
declare const _sfc_main: import("vue").DefineComponent<{
    readonly coordinates: import("../utils/props").EpPropFinalized<(new (...args: any[]) => number[][]) | (() => number[][]) | ((new (...args: any[]) => number[][]) | (() => number[][]))[], unknown, unknown, () => never[], boolean>;
    readonly arrow: import("../utils/props").EpPropFinalized<readonly [BooleanConstructor, StringConstructor, ObjectConstructor], unknown, unknown, false, boolean>;
    readonly arrowEach: BooleanConstructor;
    readonly bezier: BooleanConstructor;
    readonly color: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "#409eff", boolean>;
    readonly width: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 3, boolean>;
    readonly lineCap: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
    readonly lineJoin: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
    readonly lineDash: {
        readonly type: import("vue").PropType<unknown[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly lineDashOffset: NumberConstructor;
    readonly miterLimit: NumberConstructor;
    readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
}, {
    emit: (event: "feature-draw", ...args: any[]) => void;
    props: any;
    myMap: any;
    feature: import("vue/macros").ReactiveVariable<Feature<import("ol/geom/Geometry").default>> | undefined;
    lastSegmentStyle: () => any;
    createLineStyle: () => any[];
    setStyle: () => void;
    createLine: () => any[];
    drawHandler: () => LineString | null;
    modifyHandler: (geometry: LineString) => void;
    draw: () => void;
    styleText: import("vue/macros").ComputedVariable<Record<string, any>>;
    modify: () => void;
    readonly LineString: typeof LineString;
    readonly Feature: typeof Feature;
    onMounted: (hook: () => any, target?: import("vue").ComponentInternalInstance | null | undefined) => false | Function | undefined;
    onUnmounted: (hook: () => any, target?: import("vue").ComponentInternalInstance | null | undefined) => false | Function | undefined;
    watch: typeof watch;
    inject: typeof inject;
    readonly lineProps: {
        readonly coordinates: import("../utils/props").EpPropFinalized<(new (...args: any[]) => number[][]) | (() => number[][]) | ((new (...args: any[]) => number[][]) | (() => number[][]))[], unknown, unknown, () => never[], boolean>;
        readonly arrow: import("../utils/props").EpPropFinalized<readonly [BooleanConstructor, StringConstructor, ObjectConstructor], unknown, unknown, false, boolean>;
        readonly arrowEach: BooleanConstructor;
        readonly bezier: BooleanConstructor;
        readonly color: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "#409eff", boolean>;
        readonly width: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 3, boolean>;
        readonly lineCap: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
        readonly lineJoin: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
        readonly lineDash: {
            readonly type: import("vue").PropType<unknown[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly lineDashOffset: NumberConstructor;
        readonly miterLimit: NumberConstructor;
        readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
        readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
            width: number;
            color: string;
        }, boolean>;
        readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
        readonly styleFunction: FunctionConstructor;
    };
    readonly parseStyle: typeof parseStyle;
    readonly createArrow: typeof createArrow;
    readonly createBezierCurvePoints: typeof createBezierCurvePoints;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "feature-draw"[], "feature-draw", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly coordinates: import("../utils/props").EpPropFinalized<(new (...args: any[]) => number[][]) | (() => number[][]) | ((new (...args: any[]) => number[][]) | (() => number[][]))[], unknown, unknown, () => never[], boolean>;
    readonly arrow: import("../utils/props").EpPropFinalized<readonly [BooleanConstructor, StringConstructor, ObjectConstructor], unknown, unknown, false, boolean>;
    readonly arrowEach: BooleanConstructor;
    readonly bezier: BooleanConstructor;
    readonly color: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "#409eff", boolean>;
    readonly width: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 3, boolean>;
    readonly lineCap: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
    readonly lineJoin: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
    readonly lineDash: {
        readonly type: import("vue").PropType<unknown[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly lineDashOffset: NumberConstructor;
    readonly miterLimit: NumberConstructor;
    readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
}>> & {
    "onFeature-draw"?: ((...args: any[]) => any) | undefined;
}, {
    readonly width: number;
    readonly fill: string;
    readonly zIndex: number;
    readonly stroke: Record<string, any>;
    readonly text: import("../utils/props").EpPropMergeType<readonly [ObjectConstructor, StringConstructor], unknown, unknown>;
    readonly coordinates: number[][];
    readonly arrow: import("../utils/props").EpPropMergeType<readonly [BooleanConstructor, StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly color: string;
    readonly lineCap: string;
    readonly lineJoin: string;
    readonly arrowEach: boolean;
    readonly bezier: boolean;
}>;
export default _sfc_main;
