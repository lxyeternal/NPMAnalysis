import Circle from 'ol/geom/Circle';
import Feature from 'ol/Feature';
import { watch, inject } from 'vue';
import parseStyle from '../utils/style';
declare const _sfc_main: import("vue").DefineComponent<{
    readonly center: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly radius: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
}, {
    emit: (event: "feature-draw", ...args: any[]) => void;
    props: any;
    myMap: any;
    feature: import("vue/macros").ReactiveVariable<Feature<import("ol/geom/Geometry").default>> | undefined;
    getRadius: () => number;
    drawHandler: () => Circle;
    modifyHandler: (geometry: Circle) => void;
    draw: () => void;
    styleText: import("vue/macros").ComputedVariable<Record<string, any>>;
    setStyle: () => void;
    modify: () => void;
    readonly Circle: typeof Circle;
    readonly Feature: typeof Feature;
    onMounted: (hook: () => any, target?: import("vue").ComponentInternalInstance | null | undefined) => false | Function | undefined;
    onUnmounted: (hook: () => any, target?: import("vue").ComponentInternalInstance | null | undefined) => false | Function | undefined;
    watch: typeof watch;
    inject: typeof inject;
    readonly circleProps: {
        readonly center: {
            readonly type: import("vue").PropType<number[]>;
            readonly required: true;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly radius: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
        readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
            width: number;
            color: string;
        }, boolean>;
        readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
        readonly styleFunction: FunctionConstructor;
    };
    readonly parseStyle: typeof parseStyle;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "feature-draw"[], "feature-draw", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly center: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly radius: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
}>> & {
    "onFeature-draw"?: ((...args: any[]) => any) | undefined;
}, {
    readonly fill: string;
    readonly radius: number;
    readonly zIndex: number;
    readonly stroke: Record<string, any>;
    readonly text: import("../utils/props").EpPropMergeType<readonly [ObjectConstructor, StringConstructor], unknown, unknown>;
}>;
export default _sfc_main;
