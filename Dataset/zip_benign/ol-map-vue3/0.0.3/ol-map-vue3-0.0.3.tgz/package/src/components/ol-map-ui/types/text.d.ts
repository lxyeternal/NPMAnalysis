import type { ExtractPropTypes } from 'vue';
/**
 * 属性参数
 * @member props
 * @property {string} [font] 文字样式
 * @property {number} [maxAngle] 偏移角度
 * @property {number} [offsetX] X方向偏移
 * @property {number} [offsetY] Y方向偏移
 * @property {boolean} [overflow]
 * @property {string} [placement] 定位方式 'point' 'line'
 * @property {number} [scale] 放大缩小比例
 * @property {boolean} [rotateWithView] 是否根据地图视口旋转
 * @property {string} [text] 显示文字
 * @property {string} [textAlign] 文字横向对齐
 * @property {string} [textBaseline] 文字对齐基线
 * @property {string} [backgroundFill] 文字背景色
 * @property {string} [backgroundStroke] 文字背景边框
 * @property {number[]} [padding] 文字背景填充距离 默认[0,0,0,0]
 * @property {number[]} [coordinate] 地图坐标
 */
export declare const textProps: {
    readonly font: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "12px", boolean>;
    readonly maxAngle: NumberConstructor;
    readonly offsetX: NumberConstructor;
    readonly offsetY: NumberConstructor;
    readonly overflow: BooleanConstructor;
    readonly placement: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "point", boolean>;
    readonly scale: NumberConstructor;
    readonly rotateWithView: BooleanConstructor;
    readonly rotation: NumberConstructor;
    readonly textAlign: StringConstructor;
    readonly textBaseline: StringConstructor;
    readonly backgroundFill: StringConstructor;
    readonly backgroundStroke: ObjectConstructor;
    readonly padding: ArrayConstructor;
    readonly coordinate: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly zIndex: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props/types").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props/types").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
};
export declare type TextProps = ExtractPropTypes<typeof textProps>;
