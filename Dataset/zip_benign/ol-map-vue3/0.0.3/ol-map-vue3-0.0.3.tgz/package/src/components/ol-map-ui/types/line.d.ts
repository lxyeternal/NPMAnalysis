import type { ExtractPropTypes } from 'vue';
/**
 * @member props
 * @property {number[]} [coordinates] 地图坐标
 * @property {string} [color] 颜色
 * @property {number} [width] 线条宽度
 * @property {string} [lineCap]
 * @property {string} [lineJoin]
 * @property {number[]} [lineDash]
 * @property {number} [lineDashOffset]
 * @property {boolean|object} [arrow] 显示箭头
 * @property {boolean} [arrowEach] 每段线都带箭头
 * @property {boolean} [bezier] 显示曲线
 */
export declare const lineProps: {
    readonly coordinates: import("../utils/props/types").EpPropFinalized<(new (...args: any[]) => number[][]) | (() => number[][]) | ((new (...args: any[]) => number[][]) | (() => number[][]))[], unknown, unknown, () => never[], boolean>;
    readonly arrow: import("../utils/props/types").EpPropFinalized<readonly [BooleanConstructor, StringConstructor, ObjectConstructor], unknown, unknown, false, boolean>;
    readonly arrowEach: BooleanConstructor;
    readonly bezier: BooleanConstructor;
    readonly color: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "#409eff", boolean>;
    readonly width: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 3, boolean>;
    readonly lineCap: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
    readonly lineJoin: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "round", boolean>;
    readonly lineDash: {
        readonly type: import("vue").PropType<unknown[]>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly lineDashOffset: NumberConstructor;
    readonly miterLimit: NumberConstructor;
    readonly zIndex: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props/types").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props/types").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
};
export declare type LineProps = ExtractPropTypes<typeof lineProps>;
