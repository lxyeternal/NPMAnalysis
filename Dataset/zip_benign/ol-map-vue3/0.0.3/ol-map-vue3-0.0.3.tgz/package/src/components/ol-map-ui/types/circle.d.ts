import type { ExtractPropTypes } from 'vue';
/**
 * 属性参数
 * @member props
 * @property {Number} [zIndex] 显示层级
 * @property {String} [fill] 填充颜色
 * @property {Object} [stroke] 描边 {color,lineCap, lineJoin, lineDash, lineDashOffset, miterLimit, width}
 * @property {Object} [text] 文本， {font,maxAngle,offsetX,offsetY,overflow,placement,scale,rotateWithView,rotation,text,textAlign,textBaseline,fill,stroke,backgroundFill,backgroundStroke,padding}
 * @property {Function} [styleFunction] 渲染Style函数，必须返回Style实例
 */
export declare const circleProps: {
    readonly center: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly radius: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly zIndex: import("../utils/props/types").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props/types").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props/types").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props/types").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
};
export declare type CircleProps = ExtractPropTypes<typeof circleProps>;
