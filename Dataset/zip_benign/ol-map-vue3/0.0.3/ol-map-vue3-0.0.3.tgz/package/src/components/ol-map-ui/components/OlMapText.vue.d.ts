import Point from 'ol/geom/Point';
import Feature from 'ol/Feature';
import { watch, inject } from 'vue';
import parseStyle from '../utils/style';
declare const _sfc_main: import("vue").DefineComponent<{
    readonly font: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "12px", boolean>;
    readonly maxAngle: NumberConstructor;
    readonly offsetX: NumberConstructor;
    readonly offsetY: NumberConstructor;
    readonly overflow: BooleanConstructor;
    readonly placement: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "point", boolean>;
    readonly scale: NumberConstructor;
    readonly rotateWithView: BooleanConstructor;
    readonly rotation: NumberConstructor;
    readonly textAlign: StringConstructor;
    readonly textBaseline: StringConstructor;
    readonly backgroundFill: StringConstructor;
    readonly backgroundStroke: ObjectConstructor;
    readonly padding: ArrayConstructor;
    readonly coordinate: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
}, {
    emit: (event: "feature-draw", ...args: any[]) => void;
    props: any;
    myMap: any;
    feature: import("vue/macros").ReactiveVariable<Feature<import("ol/geom/Geometry").default>> | undefined;
    drawHandler: () => Point;
    setStyle: () => void;
    modifyHandler: (geometry: Point) => void;
    draw: () => void;
    modify: () => void;
    readonly Point: typeof Point;
    readonly Feature: typeof Feature;
    onMounted: (hook: () => any, target?: import("vue").ComponentInternalInstance | null | undefined) => false | Function | undefined;
    onUnmounted: (hook: () => any, target?: import("vue").ComponentInternalInstance | null | undefined) => false | Function | undefined;
    watch: typeof watch;
    inject: typeof inject;
    readonly textProps: {
        readonly font: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "12px", boolean>;
        readonly maxAngle: NumberConstructor;
        readonly offsetX: NumberConstructor;
        readonly offsetY: NumberConstructor;
        readonly overflow: BooleanConstructor;
        readonly placement: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "point", boolean>;
        readonly scale: NumberConstructor;
        readonly rotateWithView: BooleanConstructor;
        readonly rotation: NumberConstructor;
        readonly textAlign: StringConstructor;
        readonly textBaseline: StringConstructor;
        readonly backgroundFill: StringConstructor;
        readonly backgroundStroke: ObjectConstructor;
        readonly padding: ArrayConstructor;
        readonly coordinate: {
            readonly type: import("vue").PropType<number[]>;
            readonly required: true;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
        readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
            width: number;
            color: string;
        }, boolean>;
        readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
        readonly styleFunction: FunctionConstructor;
    };
    readonly parseStyle: typeof parseStyle;
}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "feature-draw"[], "feature-draw", import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    readonly font: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "12px", boolean>;
    readonly maxAngle: NumberConstructor;
    readonly offsetX: NumberConstructor;
    readonly offsetY: NumberConstructor;
    readonly overflow: BooleanConstructor;
    readonly placement: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "point", boolean>;
    readonly scale: NumberConstructor;
    readonly rotateWithView: BooleanConstructor;
    readonly rotation: NumberConstructor;
    readonly textAlign: StringConstructor;
    readonly textBaseline: StringConstructor;
    readonly backgroundFill: StringConstructor;
    readonly backgroundStroke: ObjectConstructor;
    readonly padding: ArrayConstructor;
    readonly coordinate: {
        readonly type: import("vue").PropType<number[]>;
        readonly required: true;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly zIndex: import("../utils/props").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly fill: import("../utils/props").EpPropFinalized<StringConstructor, unknown, unknown, "rgba(255, 255,255, 0.5)", boolean>;
    readonly stroke: import("../utils/props").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {
        width: number;
        color: string;
    }, boolean>;
    readonly text: import("../utils/props").EpPropFinalized<readonly [ObjectConstructor, StringConstructor], unknown, unknown, null, boolean>;
    readonly styleFunction: FunctionConstructor;
}>> & {
    "onFeature-draw"?: ((...args: any[]) => any) | undefined;
}, {
    readonly fill: string;
    readonly zIndex: number;
    readonly stroke: Record<string, any>;
    readonly text: import("../utils/props").EpPropMergeType<readonly [ObjectConstructor, StringConstructor], unknown, unknown>;
    readonly font: string;
    readonly placement: string;
    readonly overflow: boolean;
    readonly rotateWithView: boolean;
}>;
export default _sfc_main;
