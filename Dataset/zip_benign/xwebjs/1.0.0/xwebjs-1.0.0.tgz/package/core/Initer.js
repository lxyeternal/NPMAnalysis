/*
 * Initializing the system
 */
(function(){
	
	var $w = {
		global : getRoot(),
		customConfig : getCustomConfig(),
		init: function(){
		  this.loadClassModule();
		}
	}
	
	function getRoot(){
		return window;
	}

	function getCustomConfig(){
	}
	
	function loadClassModule(){
	  
	}
	
}());

