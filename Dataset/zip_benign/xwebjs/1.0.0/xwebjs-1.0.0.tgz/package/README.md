# xwebjs-class-system
Javascript class system

Release 0.5 beta will implement OO features
