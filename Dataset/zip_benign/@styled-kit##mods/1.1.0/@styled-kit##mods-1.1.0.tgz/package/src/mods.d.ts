import { InitMods, ModsConfigStructure, ModifierValue, InitModsOptions } from './types';
import { FnMode } from './types/function-mode';
import { ObjModeFn } from './types/object-mode';
/**
 * A method for object mode to get styles by modifiers
 * @param not
 * @param options
 */
export declare const getObjMode: (not: boolean, options: InitModsOptions) => <ModName extends string | number | symbol, ModValue extends ModifierValue | undefined>(name: ModName, value?: ModValue | undefined) => ObjModeFn<ModName, ModValue>;
/**
 * A method for function mode to get styles by modifiers
 * @param not
 * @param options
 */
export declare const getFnMode: (not: boolean, options: InitModsOptions) => FnMode<false>;
/**
 * Creates a complete structure of modifiers for object mode and for function mode
 * @param mods
 * @param options
 */
export declare const initMods: <Mods extends ModsConfigStructure>(mods: Mods, options?: InitModsOptions) => InitMods<Mods>;
