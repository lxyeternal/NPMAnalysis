"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initMods = exports.getFnMode = exports.getObjMode = void 0;
const styled_components_1 = require("styled-components");
/**
 * It tries to return the value of mod from props, checking its presence with and without the prefix `$`
 * @param name
 * @param value
 * @param props
 * @param options
 */
const getValueFromProps = (name, value, props, options) => {
    const stringName = String(name);
    const searchResultWithPrefix = props[`$${stringName}`];
    const valueFromPropsByName = searchResultWithPrefix === undefined
        ? props[stringName]
        : searchResultWithPrefix;
    const isTrueFalse = (target) => {
        return (typeof target === 'boolean' ||
            target === 'true' ||
            target === 'false');
    };
    const hasBooleanValue = Array.isArray(value)
        ? value.some(isTrueFalse)
        : isTrueFalse(value);
    return options.onlyFalseValues || !hasBooleanValue
        ? valueFromPropsByName
        : valueFromPropsByName !== null && valueFromPropsByName !== void 0 ? valueFromPropsByName : false;
};
/**
 * Checks if two values are equal
 * @param value
 * @param valueProps
 */
const isValueEqualValueProps = (value, valueProps) => {
    return String(value) === String(valueProps !== null && valueProps !== void 0 ? valueProps : false);
};
/**
 * Returns styles in css from styled components
 * @param literals
 * @param interpolations
 */
const returnStyles = (literals, interpolations) => {
    if (Array.isArray(interpolations) && interpolations.length) {
        return (0, styled_components_1.css)(literals, ...interpolations);
    }
    return (0, styled_components_1.css) `
        ${literals};
    `;
};
/**
 * A method for object mode to get styles by modifiers
 * @param not
 * @param options
 */
const getObjMode = (not, options) => (name, value) => {
    return (literalsAndFnLiterals, ...interpolations) => {
        return (props) => {
            const modValueFromProps = getValueFromProps(name, value, props, options);
            const isModUndefined = modValueFromProps === undefined;
            /**
             * For `mods.color.blue`
             * For `mods.not.color.blue`
             * For `mods.color`
             * For `mods.not.color`
             */
            if (value !== undefined || !not
                ? isModUndefined
                : !isModUndefined) {
                return (0, styled_components_1.css) ``;
            }
            if (value !== undefined) {
                /**
                 * For `mods.color.blue`
                 * For `mods.not.color.blue`
                 */
                const isValuesEqual = isValueEqualValueProps(value, modValueFromProps);
                if (not ? isValuesEqual : !isValuesEqual) {
                    return (0, styled_components_1.css) ``;
                }
            }
            const literals = typeof literalsAndFnLiterals === 'function'
                ? literalsAndFnLiterals(modValueFromProps, props)
                : literalsAndFnLiterals;
            return returnStyles(literals, interpolations);
        };
    };
};
exports.getObjMode = getObjMode;
/**
 * A method for function mode to get styles by modifiers
 * @param not
 * @param options
 */
const getFnMode = (not, options) => (name, value) => {
    return (literalsAndFnLiterals, ...interpolations) => {
        return (props) => {
            const names = Array.isArray(name) ? name : [name];
            const values = Array.isArray(value)
                ? value
                : value === undefined
                    ? []
                    : [value];
            const modValueFromProps = names.reduce((acc, targetName) => {
                acc[targetName] = getValueFromProps(targetName, value, props, options);
                return acc;
            }, {});
            /**
             * If some mod is not defined in the props
             */
            const isSomeModUndefined = Object.values(modValueFromProps).some((targetModValue) => targetModValue === undefined);
            if (not && names.length > 1 && values.length === 1) {
                /*
                 * For mods.not(['color', 'bg'], 'blue')
                 */
                const isSomeValueEqualSomePropsValue = values.some((targetValue) => {
                    return Object.values(modValueFromProps).some((targetValueProps) => isValueEqualValueProps(targetValue, targetValueProps));
                });
                if (isSomeValueEqualSomePropsValue)
                    return (0, styled_components_1.css) ``;
            }
            else if (values.length) {
                /**
                 * For mods('color', 'bg')
                 * For mods('color', ['blue', 'black'])
                 * For mods(['color', 'bg'], 'blue')
                 * For mods(['color', 'bg'], ['blue', 'black'])
                 * and
                 * For mods.not('color', 'bg')
                 * For mods.not('color', ['blue', 'black'])
                 * For mods.not(['color', 'bg'], ['blue', 'black'])
                 */
                const isSomeValueEqualEveryPropsValue = values.some((targetValue) => {
                    return Object.values(modValueFromProps).every((targetValueProps) => isValueEqualValueProps(targetValue, targetValueProps));
                });
                if (not
                    ? isSomeValueEqualEveryPropsValue
                    : !isSomeValueEqualEveryPropsValue) {
                    return (0, styled_components_1.css) ``;
                }
            }
            /**
             * For mods.not(['color', 'bg'])
             */
            if (not && name.length > 1 && !values.length) {
                const isEveryModUndefined = Object.values(modValueFromProps).every((targetModValue) => targetModValue === undefined);
                if (!isEveryModUndefined)
                    return (0, styled_components_1.css) ``;
            }
            /**
             * For mods('color', 'bg')
             * For mods('color', ['blue', 'black'])
             * For mods(['color', 'bg'], 'blue')
             * For mods(['color', 'bg'], ['blue', 'black'])
             * For mods('color')
             * For mods(['color', 'bg'])
             * and
             * For mods.not('color', 'bg')
             * For mods.not('color', ['blue', 'black'])
             * For mods.not(['color', 'bg'], 'blue')
             * For mods.not(['color', 'bg'], ['blue', 'black'])
             */
            if (values.length || !not
                ? isSomeModUndefined
                : !isSomeModUndefined) {
                return (0, styled_components_1.css) ``;
            }
            const literals = typeof literalsAndFnLiterals === 'function'
                ? literalsAndFnLiterals(names.length > 1 && (not || values.length !== 1)
                    ? modValueFromProps
                    : modValueFromProps[names[0]], props)
                : literalsAndFnLiterals;
            return returnStyles(literals, interpolations);
        };
    };
};
exports.getFnMode = getFnMode;
/**
 * Creating a modifier structure for an object mode
 * @param name
 * @param values
 * @param not
 * @param options
 */
const createModsObject = (name, values, not, options) => {
    const valuesObject = values.reduce((acc, value) => {
        const preparedValue = typeof value === 'number' ? value : String(value);
        return Object.assign(Object.assign({}, acc), { [preparedValue]: (0, exports.getObjMode)(not, options)(name, value) });
    }, {});
    return Object.assign((0, exports.getObjMode)(not, options)(name), valuesObject);
};
/**
 * Creates a complete structure of modifiers for object mode and for function mode
 * @param mods
 * @param options
 */
const initMods = (mods, options = {
    onlyFalseValues: false,
}) => {
    const structureForObjMode = Object.entries(mods).map(([name, values]) => {
        return [name, createModsObject(name, values, false, options)];
    });
    const objMode = Object.fromEntries(structureForObjMode);
    const structureForObjModeWithNo = Object.entries(mods).map(([name, values]) => {
        return [name, createModsObject(name, values, true, options)];
    });
    const objModeNo = Object.fromEntries(structureForObjModeWithNo);
    return Object.assign((0, exports.getFnMode)(false, options), objMode, {
        not: Object.assign((0, exports.getFnMode)(true, options), objModeNo),
    });
};
exports.initMods = initMods;
