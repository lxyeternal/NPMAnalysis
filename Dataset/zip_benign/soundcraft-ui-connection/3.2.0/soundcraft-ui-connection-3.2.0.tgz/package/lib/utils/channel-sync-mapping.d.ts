import { FadeableChannel } from '../facade';
import { SoundcraftUI } from '../soundcraft-ui';
import { ChannelType, MixerModel } from '../types';
/**
 * Convert channel index to FadeableChannel on the master bus.
 * @param sui Soundcraft UI instance
 * @param model Mixer model
 * @param index Channel index
 */
export declare function indexToChannel(sui: SoundcraftUI, model: MixerModel, index: number): FadeableChannel | null;
export declare function channelToIndex(model: MixerModel, type: 'master'): number | null;
export declare function channelToIndex(model: MixerModel, type: ChannelType, num: number): number | null;
