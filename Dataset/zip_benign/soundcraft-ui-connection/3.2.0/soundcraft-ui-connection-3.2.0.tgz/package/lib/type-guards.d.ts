import { DelayableMasterChannel, MasterBus, MasterChannel } from './facade';
import { Channel } from './facade/channel';
/** Asserts that the given object is an instance of `Channel` */
export declare function isChannel(ch: unknown): ch is Channel;
/** Asserts that the given object is an instance of `MasterChannel` */
export declare function isMasterChannel(ch: unknown): ch is MasterChannel;
/** Asserts that the given object is an instance of `DelayableMasterChannel` */
export declare function isDelayableMasterChannel(ch: unknown): ch is DelayableMasterChannel;
/** Asserts that the given object is an instance of `MasterBus` */
export declare function isMaster(ch: unknown): ch is MasterBus;
