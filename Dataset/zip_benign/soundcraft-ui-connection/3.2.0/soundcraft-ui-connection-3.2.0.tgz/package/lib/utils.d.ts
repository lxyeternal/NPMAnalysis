import { MixerStore } from './state/mixer-store';
import { ChannelType, FxType, VolumeBusType } from './types';
/** Clamp numeric value to min and max */
export declare function clamp(value: number, min: number, max: number): number;
/**
 * Transform a given value to int, float or string
 * @param value
 */
export declare function transformStringValue(value: string): string | number;
/**
 * Transform player time in seconds to human-readable format M:SS
 * @param value player time in seconds
 */
export declare function playerTimeToString(value: number): string;
export declare function getLinkedChannelNumber(channel: number, stereoIndex: number): number;
/** Helper function to convert FX type into readable name (Reverb, Chorus, ...) */
export declare function fxTypeToString(type: FxType): keyof typeof FxType;
/**
 * Construct a human-readable name for a channel
 * based on the default labels from the web interface
 * @param type
 * @param channel
 * @returns
 */
export declare function constructReadableChannelName(type: ChannelType | VolumeBusType, channel: number): string;
/**
 * Returns a Promise that fires when the mixer state hasn't changed for 25 ms OR when 250 ms timeout are over.
 * This makes sure that all initial params can be received by the mixer after connection init.
 * In case the state never stands still for 50 ms, the 250 ms timeout will emit finally.
 */
export declare function waitForInitParams(store: MixerStore): Promise<void>;
