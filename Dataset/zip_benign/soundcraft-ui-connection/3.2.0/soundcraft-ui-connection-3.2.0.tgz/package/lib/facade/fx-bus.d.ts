import { Observable } from 'rxjs';
import { MixerConnection } from '../mixer-connection';
import { MixerStore } from '../state/mixer-store';
import { FxChannel } from './fx-channel';
/**
 * Represents an FX bus
 */
export declare class FxBus {
    private conn;
    private store;
    private bus;
    /**
     * Selected FX type (Reverb, Delay, Chorus, Room).
     * The numeric value can be matched using the `FxType` enum.
     */
    fxType$: Observable<import("../types").FxType>;
    /**
     * BPM value of this FX.
     * This setting is always present but might not be actually used if the selected FX does not have a BPM setting.
     */
    bpm$: Observable<number>;
    constructor(conn: MixerConnection, store: MixerStore, bus: number);
    /**
     * Get input channel on the FX bus
     * @param channel Channel number
     */
    input(channel: number): FxChannel;
    /**
     * Get line channel on the FX bus
     * @param channel Channel number
     */
    line(channel: number): FxChannel;
    /**
     * Get player channel on the FX bus
     * @param channel Channel number
     */
    player(channel: number): FxChannel;
    /**
     * Get sub group channel on the FX bus
     * @param channel Channel number
     */
    sub(channel: number): FxChannel;
    /**
     * Set BPM value of this FX (between `20` and `400`)
     * This setting is always present but might not be actually used if the selected FX does not have a BPM setting.
     */
    setBpm(value: number): void;
    private assertFxParamInRange;
    private makeFxParamPath;
    /**
     * Get linear values (between `0` and `1`) of one FX parameter as an Observable stream
     * @param param FX Parameter, between `1` and `6`
     * @returns Observable<number>
     */
    getParam(param: number): Observable<number>;
    /**
     * Set linear value for one FX parameter
     * @param param FX Parameter, between `1` and `6`
     * @param value value to set, between `0` and `1`
     * @returns Observable<number>
     */
    setParam(param: number, value: number): void;
}
