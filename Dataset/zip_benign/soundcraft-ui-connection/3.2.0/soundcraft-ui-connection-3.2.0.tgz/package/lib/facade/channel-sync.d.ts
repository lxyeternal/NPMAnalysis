import { Observable } from 'rxjs';
import { FadeableChannel } from './interfaces';
import { SoundcraftUI } from '../soundcraft-ui';
import { ChannelType } from '../types';
export declare class ChannelSync {
    private sui;
    private readonly defaultSyncId;
    constructor(sui: SoundcraftUI);
    /**
     * Get index of the currently selected channel as an Observable stream, from left to right on the master bus.
     * @param syncId SYNC ID to use (default: 'SYNC_ID')
     * @returns
     */
    getSelectedChannelIndex(syncId?: string): Observable<number>;
    /**
     * Get the currently selected channel object on the master bus as an Observable stream.
     * It emits `FadeableChannel` objects. Note that this interface does not contain all fields of a channel but only the subset that all fadeable objects share.
     * @param syncId SYNC ID to use (default: 'SYNC_ID')
     * @returns
     */
    getSelectedChannel(syncId?: string): Observable<FadeableChannel | null>;
    /**
     * Select a channel by index. All clients with the same SYNC ID will select the same channel.
     * @param index Zero-based index of the channel to select, from left to right on the master bus
     * @param syncId SYNC ID to use (default: 'SYNC_ID')
     */
    selectChannelIndex(index: number, syncId?: string): void;
    /**
     * Select a channel by type and number. All clients with the same SYNC ID will select the same channel.
     * @param type Channel type (`i`, `l`, `p`, `f`, `s`, `a`, `v`, `master`)
     * @param num Channel number
     * @param syncId SYNC ID to use (default: 'SYNC_ID')
     *
     * @example
     * ```ts
     * // Select input 1
     * selectChannel('i', 1)
     *
     * // Select input 1 with SYNC ID 'mySyncId'
     * selectChannel('i', 1, 'mySyncId')
     *
     * // Select master
     * selectChannel('master')
     *
     * // Select master with SYNC ID 'mySyncId'
     * selectChannel('master', 'mySyncId')
     * ```
     */
    selectChannel(type: 'master', syncId?: string): void;
    selectChannel(type: ChannelType, num: number, syncId?: string): void;
}
