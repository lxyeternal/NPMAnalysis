import { MixerConnection } from '../mixer-connection';
import { ObjectStore } from './object-store';
export declare class MixerStore {
    private conn;
    /** Internal filtered stream of matched SETD and SETS messages */
    private setdSetsMessageMatches$;
    /** Stream of raw SETD and SETS messages */
    readonly messages$: import("rxjs").Observable<string>;
    /** The full mixer state as a flat object. Updates whenever the state changes. */
    readonly state$: import("rxjs").Connectable<any>;
    /**
     * Stream of channel sync states.
     * Each value is an object with syncId keys and index values.
     */
    readonly syncState$: import("rxjs").Connectable<Record<string, number>>;
    readonly objectStore: ObjectStore;
    constructor(conn: MixerConnection);
}
