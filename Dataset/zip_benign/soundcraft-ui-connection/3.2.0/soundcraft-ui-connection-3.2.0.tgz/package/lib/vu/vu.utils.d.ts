import { VuData } from './vu.types';
/** convert linear VU value (between `0`..`1`) to dB (between `-80`..`0`)
 *
 * ```ts
 * // Example
 * conn.vuProcessor.master().pipe(
 *   map(data => vuValueToDB(data.vuPostFaderL))
 * );
 * ```
 */
export declare function vuValueToDB(linearValue: number): number;
/** convert base64 VU data to array */
export declare function vuMessageToArray(vuMessage: string): Uint8Array;
/** convert VU message array to actual VU information represented as an object of type `VuData` */
export declare function parseVuMessageArray(rawVuData: Uint8Array): VuData;
