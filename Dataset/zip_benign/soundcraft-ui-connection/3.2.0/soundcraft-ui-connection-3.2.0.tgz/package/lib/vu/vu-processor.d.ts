import { Observable } from 'rxjs';
import { MixerConnection } from '../mixer-connection';
import { AuxChannelVuData, FxVuData, InputChannelVuData, StereoMasterVuData, SubGroupVuData, VuData } from './vu.types';
export declare class VuProcessor {
    private conn;
    /** VU data for all master channels */
    vuData$: Observable<VuData>;
    constructor(conn: MixerConnection);
    /**
     * Get VU info for input channel on the master bus
     * @param channel Channel number
     */
    input(channel: number): Observable<InputChannelVuData>;
    /**
     * Get VU info for line channel on the master bus
     * @param channel Channel number
     */
    line(channel: number): Observable<InputChannelVuData>;
    /**
     * Get VU info for player channel on the master bus
     * @param channel Channel number
     */
    player(channel: number): Observable<InputChannelVuData>;
    /**
     * Get VU info for AUX output channel on the master bus
     * @param channel Channel number
     */
    aux(channel: number): Observable<AuxChannelVuData>;
    /**
     * Get VU info for FX channel on the master bus
     * @param channel Channel number
     */
    fx(channel: number): Observable<FxVuData>;
    /**
     * Get VU info for sub group channel on the master bus
     * @param channel Channel number
     */
    sub(channel: number): Observable<SubGroupVuData>;
    /**
     * Get VU info for the stereo grand master
     */
    master(): Observable<StereoMasterVuData>;
}
