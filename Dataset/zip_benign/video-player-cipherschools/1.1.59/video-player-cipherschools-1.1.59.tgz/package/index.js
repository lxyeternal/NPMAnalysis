"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.VideoScreen = VideoScreen;
exports["default"] = exports.VideoAttributes = exports.VideoJS = void 0;

require("videojs-hls-quality-selector/dist/videojs-hls-quality-selector.css");

var _videojsHlsQualitySelector2 = _interopRequireDefault(require("videojs-hls-quality-selector"));

var _react = _interopRequireWildcard(require("react"));

require("videojs-watermark/dist/videojs-watermark.css");

var _videojsWatermark2 = _interopRequireDefault(require("videojs-watermark"));

var _videojsPlaylist = _interopRequireDefault(require("videojs-playlist"));

require("videojs-contrib-quality-levels");

require("videojs-landscape-fullscreen");

require("video.js/dist/video-js.css");

var _video = _interopRequireDefault(require("video.js"));

require("videojs-hotkeys");

require("videojs-youtube");

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]; if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

var player;
var currentQuality;
var currentPlaybackRate = 1;

var VideoJS = function VideoJS(props) {
  var videoRef = (0, _react.useRef)(null);
  var options = props.options,
      className = props.className,
      hoverControls = props.hoverControls;

  var _useState = (0, _react.useState)(""),
      _useState2 = _slicedToArray(_useState, 2),
      status = _useState2[0],
      setStatus = _useState2[1];

  function changeStatus(e) {
    e.stopPropagation();

    if (player) {
      if (status === "paused") player.play();else player.pause();
    }
  }

  function setCurrentTime(time) {
    return function (e) {
      e.stopPropagation();

      if (player) {
        var now = player.currentTime();
        player.currentTime(now + time);
      }
    };
  }

  function doubleClickHandler() {
    if (player.isFullscreen()) player.exitFullscreen();else player.requestFullscreen();
  } // This seperate functional component fixes the removal of the videoelement
  // from the DOM when calling the dispose() method on a player
  // const VideoHtml = (props) =>


  (0, _react.useEffect)(function () {
    var videoElement = videoRef.current;

    if (videoElement) {
      //for quality selector
      _video["default"].registerPlugin("hlsQualitySelector", _videojsHlsQualitySelector2["default"]); //for watermark


      _video["default"].registerPlugin("watermark", _videojsWatermark2["default"]); // for playlist


      _video["default"].registerPlugin("playlist", _videojsPlaylist["default"]); // creating videojs player DOM


      player = (0, _video["default"])(videoElement, options, function () {// console.log("player is ready", { player });
        // parentCallback(state);
      });
      player.landscapeFullscreen({
        fullscreen: {
          enterOnRotate: true,
          exitOnRotate: true,
          alwaysInLandscapeMode: true,
          iOS: true
        }
      });
      player.on("pause", function () {
        setStatus("paused");
      });
      player.on("play", function () {
        setStatus("playing");
      });
      player.on("ended", function () {
        setStatus("ended");
      }); // player.on("touchstart", function (e) {
      //   if (e.target.nodeName === "VIDEO") {
      //     if (player.paused()) {
      //       this.play();
      //     } else {
      //       this.pause();
      //     }
      //   }
      // });
      //play next video of playlist after the end of one.

      player.playlist.autoadvance(0);
    }

    return function () {
      if (player) {
        //removing created videojs player from dom by dispose.
        player.dispose();
      }
    };
  }, [videoRef]);
  (0, _react.useEffect)(function () {
    props === null || props === void 0 ? void 0 : props.handleIsPlay(status);
  }, [status]);
  (0, _react.useEffect)(function () {
    var _player2;

    player.on("ratechange", function () {
      var _player;

      currentPlaybackRate = (_player = player) === null || _player === void 0 ? void 0 : _player.playbackRate();
      props === null || props === void 0 ? void 0 : props.handlePlayrate(currentPlaybackRate);
    });
    var qualityLevels = (_player2 = player) === null || _player2 === void 0 ? void 0 : _player2.qualityLevels();
    qualityLevels.on("change", function () {
      currentQuality = qualityLevels[qualityLevels.selectedIndex].height;
      props === null || props === void 0 ? void 0 : props.handleQuality(currentQuality);
    });
  }, []);
  return /*#__PURE__*/_react["default"].createElement("div", {
    "data-vjs-player": true
  }, /*#__PURE__*/_react["default"].createElement("video", {
    ref: videoRef,
    crossOrigin: "use-credentials",
    "data-setup": "{ \"playbackRates\": [0.5, 0.75, 1, 1.25, 1.5, 2] }",
    className: "".concat(className, " video-js")
  }), hoverControls.enabled ? /*#__PURE__*/_react["default"].createElement("div", {
    className: "seekButtons",
    onDoubleClick: doubleClickHandler
  }, /*#__PURE__*/_react["default"].createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    preserveAspectRatio: "xMidYMid meet",
    viewBox: "0 0 24 24",
    onClick: setCurrentTime(-hoverControls.seekTime),
    onDoubleClick: function onDoubleClick(e) {
      return e.stopPropagation();
    }
  }, /*#__PURE__*/_react["default"].createElement("path", {
    fill: "currentColor",
    "fill-rule": "evenodd",
    d: "M12 12c0-.107.023-.216.072-.316a.617.617 0 0 1 .221-.253l6.86-4.35c.276-.174.623-.06.775.254a.725.725 0 0 1 .072.316v8.698c0 .36-.255.651-.57.651a.516.516 0 0 1-.277-.082l-6.86-4.349A.671.671 0 0 1 12 12v4.35c0 .36-.255.651-.57.651a.516.516 0 0 1-.277-.082l-6.86-4.349c-.275-.174-.374-.57-.221-.885a.617.617 0 0 1 .221-.253l6.86-4.35c.276-.174.623-.06.775.254a.725.725 0 0 1 .072.316V12Z"
  })), status === "playing" ? /*#__PURE__*/_react["default"].createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    preserveAspectRatio: "xMidYMid meet",
    viewBox: "0 0 24 24",
    onClick: changeStatus,
    onDoubleClick: function onDoubleClick(e) {
      return e.stopPropagation();
    }
  }, /*#__PURE__*/_react["default"].createElement("path", {
    fill: "currentColor",
    "fill-rule": "evenodd",
    d: "M10 18a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v12Zm7 0a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v12Z"
  })) : /*#__PURE__*/_react["default"].createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    preserveAspectRatio: "xMidYMid meet",
    viewBox: "0 0 24 24",
    onClick: changeStatus,
    onDoubleClick: function onDoubleClick(e) {
      return e.stopPropagation();
    }
  }, /*#__PURE__*/_react["default"].createElement("path", {
    fill: "currentColor",
    d: "M6 5.912c0-.155.037-.307.107-.443c.23-.44.75-.599 1.163-.354l10.29 6.088c.14.083.255.206.332.355c.23.44.08.995-.332 1.239L7.27 18.885a.814.814 0 0 1-.415.115C6.383 19 6 18.592 6 18.089V5.912Z"
  })), /*#__PURE__*/_react["default"].createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    preserveAspectRatio: "xMidYMid meet",
    viewBox: "0 0 24 24",
    onClick: setCurrentTime(hoverControls.seekTime),
    onDoubleClick: function onDoubleClick(e) {
      return e.stopPropagation();
    }
  }, /*#__PURE__*/_react["default"].createElement("path", {
    fill: "currentColor",
    d: "M12 12V7.65c0-.11.025-.22.072-.316c.152-.314.5-.428.775-.253l6.86 4.349c.093.059.17.147.221.253c.153.314.054.71-.221.885l-6.86 4.35a.516.516 0 0 1-.277.081c-.315 0-.57-.291-.57-.651v-4.35c0 .23-.106.451-.293.57l-6.86 4.35A.516.516 0 0 1 4.57 17c-.315 0-.57-.291-.57-.651V7.651c0-.11.025-.22.072-.316c.152-.314.5-.428.775-.253l6.86 4.349c.093.059.17.147.221.253c.049.1.072.209.072.315Z"
  }))) : null);
};

exports.VideoJS = VideoJS;

function VideoScreen(_ref) {
  var _ref$autoplay = _ref.autoplay,
      autoplay = _ref$autoplay === void 0 ? true : _ref$autoplay,
      _ref$responsive = _ref.responsive,
      responsive = _ref$responsive === void 0 ? false : _ref$responsive,
      _ref$fluid = _ref.fluid,
      fluid = _ref$fluid === void 0 ? false : _ref$fluid,
      _ref$controls = _ref.controls,
      controls = _ref$controls === void 0 ? true : _ref$controls,
      _ref$aspectRatio = _ref.aspectRatio,
      aspectRatio = _ref$aspectRatio === void 0 ? "16:9" : _ref$aspectRatio,
      videoList = _ref.videoList,
      className = _ref.className,
      _ref$hoverControls = _ref.hoverControls,
      hoverControls = _ref$hoverControls === void 0 ? {
    enabled: true,
    seekTime: 10
  } : _ref$hoverControls,
      _ref$hotKeys = _ref.hotKeys,
      hotKeys = _ref$hotKeys === void 0 ? {
    seekStep: 30
  } : _ref$hotKeys,
      _ref$watermark = _ref.watermark,
      watermark = _ref$watermark === void 0 ? {
    "default": false
  } : _ref$watermark,
      _ref$qualitySelector = _ref.qualitySelector,
      qualitySelector = _ref$qualitySelector === void 0 ? {
    "default": true,
    qualityText: undefined
  } : _ref$qualitySelector,
      checkStatus = _ref.checkStatus,
      checkQuality = _ref.checkQuality,
      checkPlayrate = _ref.checkPlayrate;
  var videoOptions = {
    autoplay: autoplay,
    // playbackRates,
    responsive: responsive,
    aspectRatio: aspectRatio,
    fluid: fluid,
    controls: controls,
    controlBar: {
      audioTrackButton: false
    },
    plugins: {
      hotkeys: {
        enableModifiersForNumbers: false,
        seekStep: hotKeys.seekStep || 30
      },
      // fullscreen: {
      //   enterOnRotate: true,
      //   exitOnRotate: true,
      //   alwaysInLandscapeMode: true,
      //   iOS: true,
      // },
      watermark: watermark["default"] ? {
        image: watermark.image,
        fadeTime: watermark.fadeTime || 3,
        position: watermark.position || "top-right",
        url: watermark.url || ""
      } : {},
      hlsQualitySelector: qualitySelector["default"] ? {
        displayCurrentQuality: qualitySelector.qualityText === undefined ? false : true,
        vjsIconClass: qualitySelector.qualityText === undefined ? qualitySelector.icon || "vjs-icon-cog" : ""
      } : {},
      playlist: videoList
    }
  };
  return /*#__PURE__*/_react["default"].createElement("div", {
    className: "player-container"
  }, /*#__PURE__*/_react["default"].createElement(VideoJS, {
    options: videoOptions,
    className: className,
    hoverControls: hoverControls,
    handleIsPlay: checkStatus,
    handleQuality: checkQuality,
    handlePlayrate: checkPlayrate
  }));
}

var VideoAttributes = function VideoAttributes() {
  var state = {};

  state.getCurrentPlayer = function () {
    return player;
  };

  state.getCurrentQuality = function () {
    return currentQuality;
  };

  state.getCurrentPlayRate = function () {
    return currentPlaybackRate;
  };

  return state;
};

exports.VideoAttributes = VideoAttributes;
var _default = {
  VideoScreen: VideoScreen,
  VideoAttributes: VideoAttributes
};
exports["default"] = _default;
