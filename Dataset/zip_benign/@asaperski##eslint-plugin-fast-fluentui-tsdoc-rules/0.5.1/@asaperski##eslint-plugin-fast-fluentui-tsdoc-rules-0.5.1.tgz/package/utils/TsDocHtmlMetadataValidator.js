"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsDocHtmlMetadataValidator = void 0;
const types_1 = require("../eslint-redirect/5.x/types");
const utils_1 = require("./utils");
const TsDocCommentsSet_1 = require("./TsDocCommentsSet");
class TsDocHtmlMetadataValidator {
    validate(node, nodeComments, validationSettings, context) {
        const tagName = validationSettings.tsDocTagName;
        const expectedTagDescriptionPrefix = validationSettings.expectedDescriptionPrefix;
        const expectedValue = validationSettings.expectedValue;
        const expectedTagDescription = `${expectedTagDescriptionPrefix}${expectedValue}`;
        if (!nodeComments || !nodeComments.length) {
            const fix = this.fixCreatingTsDocBlock(tagName, expectedTagDescription, node);
            context.report({
                messageId: "missingTsDocComment",
                node: node,
                fix: fix,
            });
            return;
        }
        const tsDocCommentsSet = new TsDocCommentsSet_1.TsDocCommentsSet(node, nodeComments);
        const tagExcerpts = tsDocCommentsSet.findTag(tagName);
        if (!tagExcerpts.length) {
            const fix = this.fixAddingTagWithDescription(tagName, expectedTagDescription, tsDocCommentsSet);
            context.report({
                messageId: "missingTagWithDescription",
                node: node,
                fix: fix,
            });
            return;
        }
        const linesWithExpectedTagDescription = TsDocCommentsSet_1.TsDocExcerpt.findLines(expectedTagDescription, tagExcerpts);
        if (linesWithExpectedTagDescription.length === 1) {
            return;
        }
        else if (linesWithExpectedTagDescription.length > 1) {
            const fix = this.fixRemovingDuplicateDescriptions(linesWithExpectedTagDescription, tsDocCommentsSet);
            context.report({
                messageId: "duplicateDescriptions",
                node: node,
                fix: fix,
            });
            return;
        }
        // prefix is valid, but value is invalid
        const linesWithInvalidValue = TsDocCommentsSet_1.TsDocExcerpt.findLines((line) => line.startsWith(expectedTagDescriptionPrefix), tagExcerpts);
        if (linesWithInvalidValue.length) {
            const fix = this.fixInvalidDescriptions(tagName, expectedTagDescription, linesWithInvalidValue, tsDocCommentsSet);
            context.report({
                messageId: "wrongValue",
                data: {
                    expectedValue: expectedValue,
                },
                node: node,
                fix: fix,
            });
            return;
        }
        if (validationSettings.invalidDescriptionPrefixRegexpPattern) {
            // invalid prefix, but valid value
            const invalidPrefixValidValueRegex = this.getInvalidTagDescriptionPrefixAndValidValueRegex(validationSettings.invalidDescriptionPrefixRegexpPattern, expectedValue);
            const linesWithInvalidPrefix = TsDocCommentsSet_1.TsDocExcerpt.findLines(invalidPrefixValidValueRegex, tagExcerpts);
            if (linesWithInvalidPrefix.length) {
                const fix = this.fixInvalidDescriptions(tagName, expectedTagDescription, linesWithInvalidPrefix, tsDocCommentsSet);
                context.report({
                    messageId: "invalidDescription",
                    data: {
                        expectedValue: expectedValue,
                        expectedDescriptionPrefix: expectedTagDescriptionPrefix,
                    },
                    node: node,
                    fix: fix,
                });
                return;
            }
            // invalid prefix and invalid value
            const invalidPrefixAndValueRegex = this.getInvalidTagDescriptionPrefixAndInvalidValueRegex(validationSettings.invalidDescriptionPrefixRegexpPattern);
            const linesWithInvalidPrefixesAndValue = TsDocCommentsSet_1.TsDocExcerpt.findLines(invalidPrefixAndValueRegex, tagExcerpts);
            if (linesWithInvalidPrefixesAndValue.length) {
                const fix = this.fixInvalidDescriptions(tagName, expectedTagDescription, linesWithInvalidPrefixesAndValue, tsDocCommentsSet);
                context.report({
                    messageId: "invalidDescription",
                    data: {
                        expectedValue: expectedValue,
                        expectedDescriptionPrefix: expectedTagDescriptionPrefix,
                    },
                    node: node,
                    fix: fix,
                });
                return;
            }
        }
        // description is missing
        const lastTagExcerpt = tagExcerpts[tagExcerpts.length - 1];
        const missingDescriptionFix = this.fixAddingDescription(expectedTagDescription, lastTagExcerpt, tsDocCommentsSet);
        context.report({
            messageId: "missingDescription",
            data: {
                expectedValue: expectedValue,
                expectedDescriptionPrefix: expectedTagDescriptionPrefix,
            },
            node: node,
            fix: missingDescriptionFix,
        });
    }
    fixCreatingTsDocBlock(tagName, tagDescription, node) {
        var _a;
        const indent = (0, utils_1.getNodeIndent)(node);
        let nodeToInserBefore = node;
        if (node.type === types_1.AST_NODE_TYPES.PropertyDefinition &&
            ((_a = node.decorators) === null || _a === void 0 ? void 0 : _a.length)) {
            nodeToInserBefore = node.decorators[0];
        }
        const tsDocCommentText = `/**` +
            `\n${indent} * @${tagName}` +
            `\n${indent} * ${tagDescription}` +
            `\n${indent} */` +
            `\n${indent}`;
        return (fixer) => fixer.insertTextBefore(nodeToInserBefore, tsDocCommentText);
    }
    fixAddingTagWithDescription(tagName, tagDescription, tsDocCommentsSet) {
        const tagLines = [`@${tagName}`, tagDescription];
        tsDocCommentsSet.addLines(tagLines);
        return tsDocCommentsSet.createFixer();
    }
    fixRemovingDuplicateDescriptions(duplicateDescriptions, tsDocCommentsSet) {
        for (let i = 1; i < duplicateDescriptions.length; i++) {
            tsDocCommentsSet.removeLine(duplicateDescriptions[i]);
        }
        return tsDocCommentsSet.createFixer();
    }
    fixInvalidDescriptions(tagName, tagDescription, invalidDescriptions, tsDocCommentsSet) {
        const updatedLine = invalidDescriptions[0];
        if (updatedLine.value.startsWith(`@${tagName}`)) {
            tsDocCommentsSet.setLineValue(updatedLine, `@${tagName}`);
            tsDocCommentsSet.addLineAfter(updatedLine, tagDescription);
        }
        else {
            tsDocCommentsSet.setLineValue(updatedLine, tagDescription);
        }
        for (let i = 1; i < invalidDescriptions.length; i++) {
            tsDocCommentsSet.removeLine(invalidDescriptions[i]);
        }
        return tsDocCommentsSet.createFixer();
    }
    fixAddingDescription(tagDescription, tagExcerpt, tsDocCommentsSet) {
        const lastLine = tagExcerpt.lines[tagExcerpt.lines.length - 1];
        tsDocCommentsSet.addLineAfter(lastLine, tagDescription);
        return tsDocCommentsSet.createFixer();
    }
    getInvalidTagDescriptionPrefixAndValidValueRegex(invalidTagDescriptionRegexPattern, expectedValue) {
        const pattern = invalidTagDescriptionRegexPattern + "\\s*" + expectedValue;
        return new RegExp(`^.*${pattern}.*$`, "i");
    }
    getInvalidTagDescriptionPrefixAndInvalidValueRegex(invalidTagDescriptionRegexPattern) {
        const pattern = invalidTagDescriptionRegexPattern + ".*";
        return new RegExp(`^.*${pattern}.*$`, "i");
    }
}
exports.TsDocHtmlMetadataValidator = TsDocHtmlMetadataValidator;
