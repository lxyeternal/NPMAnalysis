"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TsDocCommentsSet = exports.TsDocExcerpt = void 0;
const utils_1 = require("./utils");
const tsDocTagRegExp = /^[ \t]*(\*|\/{3})*[ \t]*@(?<tag>\w+).*$/;
class TsDocExcerpt {
    constructor(lines) {
        this.lines = lines;
    }
    static findLines(criteria, excerpts) {
        const foundLines = [];
        excerpts.forEach((excerpt) => {
            excerpt.lines.forEach((line) => {
                if (isMatch(line.value)) {
                    foundLines.push(line);
                }
            });
        });
        function isMatch(line) {
            if (typeof criteria === "function") {
                return criteria(line);
            }
            if (criteria instanceof RegExp) {
                return criteria.test(line);
            }
            return criteria === line;
        }
        return foundLines;
    }
}
exports.TsDocExcerpt = TsDocExcerpt;
var TsDocNodeState;
(function (TsDocNodeState) {
    TsDocNodeState[TsDocNodeState["Unmodified"] = 1] = "Unmodified";
    TsDocNodeState[TsDocNodeState["Updated"] = 2] = "Updated";
    TsDocNodeState[TsDocNodeState["Added"] = 3] = "Added";
    TsDocNodeState[TsDocNodeState["Deleted"] = 4] = "Deleted";
})(TsDocNodeState || (TsDocNodeState = {}));
class TsDocNode {
    constructor(id, _state, parent) {
        this.id = id;
        this._state = _state;
        this.parent = parent;
        this._idSequence = 0;
    }
    get state() {
        return this._state;
    }
    set state(newState) {
        this._state = newState;
    }
    getNextId() {
        return this._idSequence++;
    }
}
class TsDocLine extends TsDocNode {
    constructor(value, id, state, parent) {
        super(id, state, parent);
        this._value = value;
    }
    get value() {
        return this._value;
    }
    set value(newValue) {
        if (newValue !== this.value) {
            this._value = newValue;
            this.onValueUpdated();
        }
    }
    onValueUpdated() {
        if (this.state === TsDocNodeState.Unmodified) {
            this.state = TsDocNodeState.Updated;
        }
    }
}
class TsDocBlock extends TsDocNode {
    constructor(lines, id, state, parent, commentNode) {
        super(id, state, parent);
        this.commentNode = commentNode;
        this._lines = [];
        const lastLineIndex = lines.length - 1;
        lines.forEach((line, index) => {
            if ((index === 0 || index === lastLineIndex) && !line) {
                return;
            }
            this._lines.push(new TsDocLine(line, this.getNextId(), state, this));
        });
    }
    findTag(searchedTagName) {
        if (!this._lines.length) {
            return;
        }
        const docExcerpts = [];
        let currentExcerptLines = [];
        let currentTagName = null;
        this._lines.forEach((line) => {
            const match = tsDocTagRegExp.exec(line.value);
            if (!match) {
                if (currentTagName === searchedTagName) {
                    currentExcerptLines.push(line);
                }
                return;
            }
            if (currentExcerptLines.length) {
                docExcerpts.push(new TsDocExcerpt(currentExcerptLines));
                currentExcerptLines = [];
            }
            const { tag: commentTagName } = match.groups;
            currentTagName = commentTagName;
            if (currentTagName === searchedTagName) {
                currentExcerptLines.push(line);
            }
        });
        if (currentExcerptLines.length) {
            docExcerpts.push(new TsDocExcerpt(currentExcerptLines));
        }
        return docExcerpts;
    }
    setLineValue(line, newValue) {
        const lineIndex = this.getLineIndexById(line.id);
        if (lineIndex === -1) {
            return;
        }
        this._lines[lineIndex].value = newValue;
        this.updateState();
    }
    removeLine(line) {
        const lineIndex = this.getLineIndexById(line.id);
        if (lineIndex === -1) {
            return;
        }
        if (this._lines[lineIndex].state === TsDocNodeState.Added) {
            this._lines.splice(lineIndex, 1);
        }
        else {
            this._lines[lineIndex].state = TsDocNodeState.Deleted;
        }
        this.updateState();
    }
    addLines(lineValues) {
        const lineIndex = this._lines.length;
        this._addLines(lineIndex, lineValues);
    }
    addLinesBefore(line, lineValues) {
        const lineIndex = this.getLineIndexById(line.id);
        if (lineIndex === -1) {
            return;
        }
        this._addLines(lineIndex, lineValues);
    }
    addLinesAfter(line, lineValues) {
        const lineIndex = this.getLineIndexById(line.id);
        if (lineIndex === -1) {
            return;
        }
        this._addLines(lineIndex + 1, lineValues);
    }
    getContent(indent) {
        let content = "";
        let linesCount = 0;
        this._lines
            .filter((line) => line.state !== TsDocNodeState.Deleted)
            .forEach((line) => {
            content += `${indent} * ${line.value}\n`;
            linesCount++;
        });
        if (content) {
            const startIndent = this.state === TsDocNodeState.Added ? indent : "";
            content = `${startIndent}/**\n${content}${indent} */`;
        }
        return content;
    }
    _addLines(index, lineValues) {
        let newLines = [];
        lineValues.forEach((lineValue) => {
            newLines.push(new TsDocLine(lineValue, this.getNextId(), TsDocNodeState.Added, this));
        });
        this._lines.splice(index, 0, ...newLines);
        this.updateState();
    }
    getLineIndexById(id) {
        let lineIndex = -1;
        this._lines.forEach((line, index) => {
            if (line.id === id) {
                lineIndex = index;
            }
        });
        return lineIndex;
    }
    updateState() {
        const totalLinesCount = this._lines.length;
        const deletedLinesCount = this.getLinesInState(TsDocNodeState.Deleted).length;
        if (totalLinesCount === deletedLinesCount) {
            this.state = TsDocNodeState.Deleted;
            return;
        }
        if (deletedLinesCount > 0) {
            this.state = this.commentNode
                ? TsDocNodeState.Updated
                : TsDocNodeState.Added;
        }
        const updateLinesCount = this.getLinesInState(TsDocNodeState.Updated).length;
        const addedLinesCount = this.getLinesInState(TsDocNodeState.Added).length;
        if (deletedLinesCount > 0 || updateLinesCount > 0 || addedLinesCount > 0) {
            this.state = this.commentNode
                ? TsDocNodeState.Updated
                : TsDocNodeState.Added;
        }
        else {
            this.state = TsDocNodeState.Unmodified;
        }
    }
    getLinesInState(state) {
        return this._lines.filter((line) => line.state === state);
    }
}
class TsDocCommentsSet extends TsDocNode {
    constructor(parentNode, commentNodes) {
        super(0, TsDocNodeState.Unmodified, null);
        this.parentNode = parentNode;
        this.blocks = [];
        this.indent = (0, utils_1.getNodeIndent)(parentNode);
        commentNodes.forEach((commentNode) => {
            const commentLines = this.splitAndNormalizeLines(commentNode.value);
            this.blocks.push(new TsDocBlock(commentLines, this.getNextId(), TsDocNodeState.Unmodified, this, commentNode));
        });
    }
    splitAndNormalizeLines(comment) {
        const lines = [];
        comment.split(/\r?\n|\r|\n/g).forEach((commentLine) => {
            const normalizedLine = (0, utils_1.trimStart)(commentLine, "/* \t").trimEnd();
            lines.push(normalizedLine);
        });
        return lines;
    }
    findTag(tagName) {
        if (!this.blocks.length) {
            return;
        }
        let docExcerpts = [];
        this.blocks.forEach((block) => {
            const blockExcerpts = block.findTag(tagName);
            if (blockExcerpts) {
                docExcerpts = docExcerpts.concat(blockExcerpts);
            }
        });
        return docExcerpts;
    }
    setLineValue(line, newValue) {
        this.findBlockAndExec(line, (block) => {
            block.setLineValue(line, newValue);
        });
    }
    removeLine(line) {
        this.findBlockAndExec(line, (block) => {
            block.removeLine(line);
        });
    }
    addLines(lineValues) {
        let block;
        for (let i = this.blocks.length - 1; i >= 0; i--) {
            if (this.blocks[i].commentNode) {
                block = this.blocks[i];
                break;
            }
        }
        if (block) {
            block.addLines(lineValues);
        }
    }
    addLineBefore(line, lineValue) {
        this.findBlockAndExec(line, (block) => {
            block.addLinesBefore(line, [lineValue]);
        });
    }
    addLinesBefore(line, lineValues) {
        this.findBlockAndExec(line, (block) => {
            block.addLinesBefore(line, lineValues);
        });
    }
    addLineAfter(line, lineValue) {
        this.findBlockAndExec(line, (block) => {
            block.addLinesAfter(line, [lineValue]);
        });
    }
    addLinesAfter(line, lineValues) {
        this.findBlockAndExec(line, (block) => {
            block.addLinesAfter(line, lineValues);
        });
    }
    createFixer() {
        const docCommentsSet = this;
        return (fixer) => {
            const fixes = [];
            docCommentsSet.blocks
                .filter((block) => block.commentNode && block.state === TsDocNodeState.Deleted)
                .forEach((block) => {
                fixes.push(fixer.remove(block.commentNode));
            });
            let previousBlockNode = null;
            docCommentsSet.blocks
                .filter((block) => block.state === TsDocNodeState.Updated)
                .forEach((block) => {
                const blockContent = block.getContent(this.indent);
                if (!blockContent) {
                    if (block.commentNode) {
                        fixes.push(fixer.remove(block.commentNode));
                    }
                }
                else {
                    previousBlockNode = block;
                    fixes.push(fixer.replaceText(block.commentNode, block.getContent(this.indent)));
                }
            });
            docCommentsSet.blocks
                .filter((block) => block.state === TsDocNodeState.Added)
                .forEach((block) => {
                const blockContent = block.getContent(this.indent);
                if (!blockContent) {
                    return;
                }
                if (previousBlockNode) {
                    fixes.push(fixer.insertTextAfter(previousBlockNode.commentNode, blockContent));
                }
                else {
                    fixes.push(fixer.insertTextBefore(this.parentNode, blockContent));
                }
            });
            return fixes;
        };
    }
    findBlockAndExec(line, action) {
        const tsDocLine = line;
        const block = tsDocLine === null || tsDocLine === void 0 ? void 0 : tsDocLine.parent;
        if (block) {
            action(block);
        }
    }
}
exports.TsDocCommentsSet = TsDocCommentsSet;
