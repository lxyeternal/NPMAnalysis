"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEslintRule = void 0;
const types_1 = require("../eslint-redirect/5.x/types");
exports.createEslintRule = types_1.ESLintUtils.RuleCreator((ruleName) => ruleName);
