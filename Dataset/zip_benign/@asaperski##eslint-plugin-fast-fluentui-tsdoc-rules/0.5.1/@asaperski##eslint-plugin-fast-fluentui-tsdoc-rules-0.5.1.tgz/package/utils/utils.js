"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.trimEnd = exports.trimStart = exports.getNodeIndent = exports.camelToKebabCase = exports.getHtmlAttributeName = exports.getHtmlElementName = exports.getPropertyValue = exports.getPropertyName = exports.getDecoratorByName = exports.getAttributeDecorator = exports.isPublicProperty = void 0;
const types_1 = require("../eslint-redirect/5.x/types");
function isPublicProperty(node) {
    return node.accessibility !== "private" && node.accessibility !== "protected";
}
exports.isPublicProperty = isPublicProperty;
function getAttributeDecorator(node) {
    return getDecoratorByName(node, "attr");
}
exports.getAttributeDecorator = getAttributeDecorator;
function getDecoratorByName(node, decoratorName) {
    if (!node.decorators) {
        return;
    }
    const matchingDecorator = node.decorators.find((decorator) => {
        const decoratorExpression = decorator.expression;
        if (decoratorExpression.type === types_1.AST_NODE_TYPES.Identifier &&
            decoratorExpression.name === decoratorName) {
            return true;
        }
        if (decoratorExpression.type === types_1.AST_NODE_TYPES.CallExpression &&
            decoratorExpression.callee.type === types_1.AST_NODE_TYPES.Identifier &&
            decoratorExpression.callee.name === decoratorName) {
            return true;
        }
        return false;
    });
    return matchingDecorator;
}
exports.getDecoratorByName = getDecoratorByName;
function getPropertyName(node) {
    if (node.key.type === types_1.AST_NODE_TYPES.Identifier) {
        return node.key.name;
    }
    if (node.key.type === types_1.AST_NODE_TYPES.Literal &&
        typeof node.key.value === "string") {
        return node.key.value;
    }
    return;
}
exports.getPropertyName = getPropertyName;
function getPropertyValue(node) {
    if (node.value.type === types_1.AST_NODE_TYPES.Literal &&
        typeof node.value.value === "string") {
        return node.value.value;
    }
    else if (node.value.type === types_1.AST_NODE_TYPES.TemplateLiteral) {
        const parts = [];
        node.value.quasis.forEach((item) => {
            if (item.value.raw) {
                parts.push(item.value.raw);
            }
        });
        return parts.join();
    }
    return;
}
exports.getPropertyValue = getPropertyValue;
function getHtmlElementName(node, namePrefix) {
    if (!node.declarations || node.declarations.length != 1) {
        return;
    }
    const variableDeclaratorNode = node
        .declarations[0];
    if (!variableDeclaratorNode) {
        return;
    }
    const initCallExpressionNode = variableDeclaratorNode.init;
    if (!initCallExpressionNode ||
        !initCallExpressionNode.arguments ||
        initCallExpressionNode.arguments.length != 1) {
        return;
    }
    const argument = initCallExpressionNode.arguments[0];
    if (argument.type != types_1.AST_NODE_TYPES.ObjectExpression ||
        !argument.properties) {
        return;
    }
    const nameProperty = argument.properties.find((property) => {
        if (property.type === types_1.AST_NODE_TYPES.Property &&
            getPropertyName(property) === "name") {
            return true;
        }
    });
    if (!nameProperty) {
        return;
    }
    const name = getPropertyValue(nameProperty);
    if (!name) {
        return;
    }
    if (!namePrefix) {
        return name;
    }
    return `${namePrefix}${name}`;
}
exports.getHtmlElementName = getHtmlElementName;
function getHtmlAttributeName(attrDecorator) {
    const expression = attrDecorator.expression;
    if (expression.type != types_1.AST_NODE_TYPES.CallExpression ||
        !expression.arguments ||
        expression.arguments.length != 1) {
        return;
    }
    const argument = expression.arguments[0];
    if (argument.type != types_1.AST_NODE_TYPES.ObjectExpression ||
        !argument.properties) {
        return;
    }
    const attributeNameProperty = argument.properties.find((property) => {
        if (property.type === types_1.AST_NODE_TYPES.Property &&
            getPropertyName(property) === "attribute") {
            return true;
        }
    });
    if (!attributeNameProperty) {
        return;
    }
    return getPropertyValue(attributeNameProperty);
}
exports.getHtmlAttributeName = getHtmlAttributeName;
function camelToKebabCase(camelCaseString) {
    return camelCaseString
        .replace(/[A-Z]+(?![a-z])|[A-Z]/g, ($, ofs) => (ofs ? "-" : "") + $.toLowerCase())
        .replace(/-{2,}/g, "-");
}
exports.camelToKebabCase = camelToKebabCase;
function getNodeIndent(node) {
    const indentSize = node.loc.start.column;
    const indent = " ".repeat(indentSize);
    return indent;
}
exports.getNodeIndent = getNodeIndent;
function trimStart(inputString, trimmedChars) {
    let start = 0;
    const end = inputString.length;
    while (start < end && trimmedChars.indexOf(inputString[start]) >= 0)
        ++start;
    return start > 0 ? inputString.substring(start) : inputString;
}
exports.trimStart = trimStart;
function trimEnd(inputString, trimmedChars) {
    let end = inputString.length;
    while (end > 0 && trimmedChars.indexOf(inputString[end - 1]) >= 0)
        --end;
    return end < inputString.length ? inputString.substring(0, end) : inputString;
}
exports.trimEnd = trimEnd;
