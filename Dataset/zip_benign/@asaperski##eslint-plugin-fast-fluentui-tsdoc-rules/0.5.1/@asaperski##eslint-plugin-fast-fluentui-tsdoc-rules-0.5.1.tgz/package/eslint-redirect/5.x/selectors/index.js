"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMPONENT_DEFINITION_VARIABLE_DECLARATION = exports.PROPERTY_DEFINITION_WITH_ATTR_DECORATOR = void 0;
exports.PROPERTY_DEFINITION_WITH_ATTR_DECORATOR = "ClassBody > PropertyDefinition:has(" +
    "Decorator:matches(" +
    "[expression.type='Identifier'][expression.name='attr']," +
    "[expression.type='CallExpression'][expression.callee.name='attr']" +
    "))";
exports.COMPONENT_DEFINITION_VARIABLE_DECLARATION = "ExportNamedDeclaration:has(VariableDeclaration:has(" +
    "VariableDeclarator:matches(" +
    "[id.name='definition'][init.callee.property.name='compose']" +
    ")))";
