"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tsdoc_html_attribute_1 = __importDefault(require("./tsdoc-html-attribute"));
const tsdoc_html_element_1 = __importDefault(require("./tsdoc-html-element"));
exports.default = {
    "tsdoc-html-attribute": tsdoc_html_attribute_1.default,
    "tsdoc-html-element": tsdoc_html_element_1.default,
};
