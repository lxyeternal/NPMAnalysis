"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rule = exports.defaultDescriptionPrefix = exports.RULE_NAME = void 0;
const create_eslint_rule_1 = require("../utils/create-eslint-rule");
const selectors_1 = require("../eslint-redirect/5.x/selectors");
const utils = __importStar(require("../utils"));
exports.RULE_NAME = "tsdoc-html-attribute";
exports.defaultDescriptionPrefix = "HTML Attribute: ";
const defaultInvalidDescriptionRegexpPattern = ".*html\\s*attr[a-z]*\\s*:.*";
exports.rule = (0, create_eslint_rule_1.createEslintRule)({
    name: exports.RULE_NAME,
    meta: {
        docs: {
            description: "TSDoc comment should specify HTML Attribute name in description of @remarks tag.",
            recommended: "warn",
            // category: "Stylistic Issues",
        },
        messages: {
            missingTsDocComment: "TSDoc comment is missing. Should specify HTML attribute name in description of @remarks tag",
            missingTagWithDescription: "@remarks tag with HTML attribute name description is missing",
            wrongValue: "Wrong HTML attribute name is specified in @remarks tag, expected: {{ expectedValue }}",
            invalidDescription: "Invalid HTML attribute name descripion, expected: {{ expectedDescriptionPrefix }}{{ expectedValue }}",
            missingDescription: "HTML attribute description is missing, expected: {{ expectedDescriptionPrefix }}{{ expectedValue }}",
            duplicateDescriptions: "TSDoc comment contains duplicate HTML attribute descriptions",
        },
        type: "suggestion",
        schema: [],
        fixable: "code",
    },
    defaultOptions: [
        {
            descriptionPrefix: exports.defaultDescriptionPrefix,
        },
    ],
    create: (context, [options]) => {
        const sourceCode = context.getSourceCode();
        return {
            [selectors_1.PROPERTY_DEFINITION_WITH_ATTR_DECORATOR](node) {
                if (!isEligibleNode(node)) {
                    return;
                }
                const attrDecorator = utils.getAttributeDecorator(node);
                const expectedDescriptionPrefix = options.descriptionPrefix || exports.defaultDescriptionPrefix;
                const invalidDescriptionPrefixRegexpPattern = getInvalidDescriptionPrefixRegexpPattern(expectedDescriptionPrefix, options.invalidDescriptionRegexp);
                const expectedValue = getExpectedValue(node, attrDecorator);
                const nodeComments = sourceCode.getCommentsBefore(node);
                var validationSettings = {
                    tsDocTagName: "remarks",
                    expectedDescriptionPrefix: expectedDescriptionPrefix,
                    invalidDescriptionPrefixRegexpPattern: invalidDescriptionPrefixRegexpPattern,
                    expectedValue: expectedValue,
                };
                const validator = new utils.TsDocHtmlMetadataValidator();
                validator.validate(node, nodeComments, validationSettings, context);
            },
        };
    },
});
function isEligibleNode(node) {
    if (!utils.isPublicProperty(node)) {
        return false;
    }
    const attrDecorator = utils.getAttributeDecorator(node);
    if (!attrDecorator) {
        return false;
    }
    const expectedAttributeName = getExpectedValue(node, attrDecorator);
    if (!expectedAttributeName) {
        return false;
    }
    return true;
}
function getExpectedValue(node, attrDecorator) {
    let attributeName = utils.getHtmlAttributeName(attrDecorator);
    if (!attributeName) {
        const propertyName = utils.getPropertyName(node);
        if (!propertyName) {
            return;
        }
        attributeName = utils.camelToKebabCase(propertyName);
    }
    return attributeName;
}
function getInvalidDescriptionPrefixRegexpPattern(htmlAttributePrefixText, configuredInvalidHtmlAttributePrefixRegexp) {
    if (configuredInvalidHtmlAttributePrefixRegexp) {
        return utils.trimStart(utils.trimEnd(configuredInvalidHtmlAttributePrefixRegexp, "$"), "^");
    }
    if (htmlAttributePrefixText === exports.defaultDescriptionPrefix) {
        return defaultInvalidDescriptionRegexpPattern;
    }
}
exports.default = exports.rule;
