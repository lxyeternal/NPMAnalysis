"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.rule = exports.defaultHtmlElementNamePrefix = exports.defaultDescriptionPrefix = exports.RULE_NAME = void 0;
const create_eslint_rule_1 = require("../utils/create-eslint-rule");
const selectors_1 = require("../eslint-redirect/5.x/selectors");
const utils = __importStar(require("../utils"));
exports.RULE_NAME = "tsdoc-html-element";
exports.defaultDescriptionPrefix = "HTML Element: ";
const defaultInvalidDescriptionRegexpPattern = ".*html\\s*elem[a-z]*\\s*:.*";
exports.defaultHtmlElementNamePrefix = "fluent";
exports.rule = (0, create_eslint_rule_1.createEslintRule)({
    name: exports.RULE_NAME,
    meta: {
        docs: {
            description: "TSDoc comment should specify HTML Element name in description of @remarks tag.",
            recommended: "warn",
            // category: "Stylistic Issues",
        },
        messages: {
            missingTsDocComment: "TSDoc comment is missing. Should specify HTML element name in description of @remarks tag",
            missingTagWithDescription: "@remarks tag with HTML element name description is missing",
            wrongValue: "Wrong HTML element name is specified in @remarks tag, expected: {{ expectedValue }}",
            invalidDescription: "Invalid HTML element name descripion, expected: {{ expectedDescriptionPrefix }}{{ expectedValue }}",
            missingDescription: "HTML element description is missing, expected: {{ expectedDescriptionPrefix }}{{ expectedValue }}",
            duplicateDescriptions: "TSDoc comment contains duplicate HTML element descriptions",
        },
        type: "suggestion",
        schema: [],
        fixable: "code",
    },
    defaultOptions: [
        {
            descriptionPrefix: exports.defaultDescriptionPrefix,
            htmlElementNamePrefix: exports.defaultHtmlElementNamePrefix,
        },
    ],
    create: (context, [options]) => {
        const sourceCode = context.getSourceCode();
        return {
            [selectors_1.COMPONENT_DEFINITION_VARIABLE_DECLARATION](node) {
                if (!isEligibleNode(node)) {
                    return;
                }
                const expectedDescriptionPrefix = options.descriptionPrefix || exports.defaultDescriptionPrefix;
                const invalidDescriptionPrefixRegexpPattern = getInvalidDescriptionPrefixRegexpPattern(expectedDescriptionPrefix, options.invalidDescriptionRegexp);
                const expectedValuePrefix = options.htmlElementNamePrefix || exports.defaultHtmlElementNamePrefix;
                const expectedValue = getExpectedValue(node, expectedValuePrefix);
                const nodeComments = sourceCode.getCommentsBefore(node);
                var validationSettings = {
                    tsDocTagName: "remarks",
                    expectedDescriptionPrefix: expectedDescriptionPrefix,
                    invalidDescriptionPrefixRegexpPattern: invalidDescriptionPrefixRegexpPattern,
                    expectedValue: expectedValue,
                };
                const validator = new utils.TsDocHtmlMetadataValidator();
                validator.validate(node, nodeComments, validationSettings, context);
            },
        };
    },
});
function isEligibleNode(node) {
    const variableDeclarationNode = node.declaration;
    if (!variableDeclarationNode) {
        return false;
    }
    if (!utils.getHtmlElementName(variableDeclarationNode, "p")) {
        return false;
    }
    return true;
}
function getExpectedValue(node, namePrefix) {
    const variableDeclarationNode = node.declaration;
    if (!variableDeclarationNode) {
        return;
    }
    const elementName = utils.getHtmlElementName(variableDeclarationNode, namePrefix);
    return `\\<${elementName}\\>`;
}
function getInvalidDescriptionPrefixRegexpPattern(descriptionPrefix, configuredInvalidDescriptionPrefixRegexpPattern) {
    if (configuredInvalidDescriptionPrefixRegexpPattern) {
        return utils.trimStart(utils.trimEnd(configuredInvalidDescriptionPrefixRegexpPattern, "$"), "^");
    }
    if (descriptionPrefix === exports.defaultDescriptionPrefix) {
        return defaultInvalidDescriptionRegexpPattern;
    }
}
exports.default = exports.rule;
