/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@omnedia/ngx-globe" />
export * from './public-api';
