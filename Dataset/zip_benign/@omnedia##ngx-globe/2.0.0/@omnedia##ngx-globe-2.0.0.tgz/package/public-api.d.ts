export * from './lib/ngx-globe.component';
export * from './lib/ngx-globe.types';
