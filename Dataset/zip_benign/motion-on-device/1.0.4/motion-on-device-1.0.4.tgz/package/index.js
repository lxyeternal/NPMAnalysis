import React from 'react';
import './mod.css';
import './mod-data.css';


const init = ()=>{
  window.addEventListener("deviceorientation", handleOrientation, true);
  window.addEventListener("devicemotion", handleMotion, true);


  if(!window.rotation){
    window.rotation={
      dampening:0.01,
      smoothing:0.5,
      gamma:0,
      beta:0,
      alpha:0,
    }
  }
  if(!window.rotationRate){
    window.rotationRate={
      dampening:0.0005,
      smoothing:0.2,
      gamma:0,
      beta:0,
      alpha:0,
    }
  }
  if(!window.acceleration){
    window.acceleration={
      sensitivity:0.1,
      dampening:1,
      smoothing:0.3,
      x:0,
      y:0,
      z:0,
    }
  }
}

function setCSSVariable(variable, value){
  document.documentElement.style
  .setProperty('--moa-'+variable, value);
}
function average(arr){
  var total = 0;
  for(var i = 0; i < arr.length; i++) {
      total += arr[i];
  }
  var avg = total / arr.length;
  return(avg);
}
function percentage(partialValue, totalValue) {
   return (100 * partialValue) / totalValue;
}
function lerp (start, end, amt){
  return (1-amt)*start+amt*end
}

const handleOrientation = (event)=>{
  window.rotation.gamma = lerp(window.rotation.gamma, event.gamma*window.rotation.dampening, window.rotation.smoothing)
  window.rotation.beta = lerp(window.rotation.beta, event.beta*window.rotation.dampening, window.rotation.smoothing)
  window.rotation.alpha = lerp(window.rotation.alpha, event.alpha*window.rotation.dampening, window.rotation.smoothing)
  setCSSVariable('rotation-x',(percentage(window.rotation.beta,360)+'turn'));
  setCSSVariable('rotation-y',(percentage(-window.rotation.gamma,360)+'turn'));
  setCSSVariable('rotation-z',(percentage(window.rotation.alpha, 360)+'turn'));
}
const handleMotion = (event)=>{


  window.acceleration.x = lerp(window.acceleration.x, event.acceleration.x*window.acceleration.dampening*window.acceleration.sensitivity, window.acceleration.smoothing)
  window.acceleration.y = lerp(window.acceleration.y, event.acceleration.y*window.acceleration.dampening*window.acceleration.sensitivity, window.acceleration.smoothing)
  window.acceleration.z = lerp(window.acceleration.z, event.acceleration.z*window.acceleration.dampening*window.acceleration.sensitivity, window.acceleration.smoothing)

  window.rotationRate.gamma = lerp(window.rotationRate.gamma, event.rotationRate.gamma*window.rotationRate.dampening, window.rotationRate.smoothing)
  window.rotationRate.beta = lerp(window.rotationRate.beta, event.rotationRate.beta*window.rotationRate.dampening, window.rotationRate.smoothing)
  window.rotationRate.alpha = lerp(window.rotationRate.alpha, event.rotationRate.alpha*window.rotationRate.dampening, window.rotationRate.smoothing)

  setCSSVariable('translate-x',-window.acceleration.x+'cm');
  setCSSVariable('translate-y',window.acceleration.y+'cm');
  setCSSVariable('translate-z',window.acceleration.z+'cm');

  setCSSVariable('rotationRate-x',((window.rotationRate.alpha)+'turn'));
  setCSSVariable('rotationRate-y',((-window.rotationRate.beta)+'turn'));
  setCSSVariable('rotationRate-z',((window.rotationRate.gamma)+'turn'));

  setCSSVariable('scale-x',((window.acceleration.x*0.5)+1));
  setCSSVariable('scale-y',((window.acceleration.y*0.5)+1));
  setCSSVariable('scale-z',((window.acceleration.z*0.5)+1));

}
export default {
init,
}
