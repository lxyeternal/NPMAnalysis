import React from 'react';
import './mod.css';
import './mod-data.css';


const init = (parameters)=>{
  window.addEventListener("deviceorientation", handleOrientation, true);
  window.addEventListener("devicemotion", handleMotion, true);
}

function setCSSVariable(variable, value){
  document.documentElement.style
  .setProperty('--moa-'+variable, value);
}
function average(arr){
  var total = 0;
  for(var i = 0; i < arr.length; i++) {
      total += arr[i];
  }
  var avg = total / arr.length;
  return(avg);
}
function percentage(partialValue, totalValue) {
   return (100 * partialValue) / totalValue;
}
function lerp (start, end, amt){
  return (1-amt)*start+amt*end
}

const handleOrientation = (event)=>{
  setCSSVariable('rotation-x',(percentage(event.beta*0.01,360)+'turn'));
  setCSSVariable('rotation-y',(percentage((-event.gamma )*0.01,360)+'turn'));
  setCSSVariable('rotation-z',(percentage(event.alpha*0.01,360)+'turn'));
}
const handleMotion = (event)=>{

  if(!window.acceleration){
    window.acceleration={
      sensitivity:1,
      dampening:5,
      smoothing:0.3,
      x:0,
      y:0,
      z:0,
    }
  }
  window.acceleration.x = lerp(window.acceleration.x, event.acceleration.x*window.acceleration.dampening*window.acceleration.sensitivity, window.acceleration.smoothing)
  window.acceleration.y = lerp(window.acceleration.y, event.acceleration.y*window.acceleration.dampening*window.acceleration.sensitivity, window.acceleration.smoothing)
  window.acceleration.z = lerp(window.acceleration.z, event.acceleration.z*window.acceleration.dampening*window.acceleration.sensitivity, window.acceleration.smoothing)

  if(!window.rotationRate){
    window.rotationRate={
      dampening:0.0005,
      smoothing:0.2,
      gamma:0,
      beta:0,
      alpha:0,
    }
  }
  window.rotationRate.gamma = lerp(window.rotationRate.gamma, event.rotationRate.gamma*window.rotationRate.dampening, window.rotationRate.smoothing)
  window.rotationRate.beta = lerp(window.rotationRate.beta, event.rotationRate.beta*window.rotationRate.dampening, window.rotationRate.smoothing)
  window.rotationRate.alpha = lerp(window.rotationRate.alpha, event.rotationRate.alpha*window.rotationRate.dampening, window.rotationRate.smoothing)

  setCSSVariable('translate-x',-window.acceleration.x+'px');
  setCSSVariable('translate-y',window.acceleration.y+'px');
  setCSSVariable('translate-z',window.acceleration.z+'px');

  setCSSVariable('rotationRate-x',((window.rotationRate.alpha)+'turn'));
  setCSSVariable('rotationRate-y',((window.rotationRate.beta)+'turn'));
  setCSSVariable('rotationRate-z',((window.rotationRate.gamma)+'turn'));

  setCSSVariable('scale-x',((window.acceleration.x*0.5)+1));
  setCSSVariable('scale-y',((window.acceleration.y*0.5)+1));
  setCSSVariable('scale-z',((window.acceleration.z*0.5)+1));

}
export default {
init,
}
