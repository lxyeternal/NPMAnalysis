<h3> Download & Installation </h3>

```shell
$ npm i motion-on-device
```

<h3> Code Demo </h3>

```html

import MOD from 'mod';
MOD.init();

```

<h3> With parameters </h3>
```html
MOD.init()

// Optional - Default Values 

window.rotation.dampening = 0.01;
window.rotation.smoothing = 0.5;

window.rotationRate.dampening = 0.0005;
window.rotationRate.smoothing = 0.2;

window.acceleration.sensitivity = 0.1;
window.acceleration.dampening = 1;
window.acceleration.smoothing = 0.3;
```

<h3> Tags </h3>

```html

<div data-moa='jellyX' > </div>
<div data-moa='jellyY' > </div>
<div data-moa='jellyZ' > </div>
<div data-moa='jellyXY' > </div>
<div data-moa='jelly3D' > </div>

<div data-moa='giggleX' > </div>
<div data-moa='giggleY' > </div>
<div data-moa='giggleZ' > </div>
<div data-moa='giggleXY' > </div>
<div data-moa='giggle3D' > </div>

<div data-moa='rotateX' > </div>
<div data-moa='rotateY' > </div>
<div data-moa='rotateZ' > </div>
<div data-moa='rotateXY' > </div>
<div data-moa='rotate3D' > </div>

<div data-moa='wobbleX' > </div>
<div data-moa='wobbleY' > </div>
<div data-moa='wobbleZ' > </div>
<div data-moa='wobbleXY' > </div>
<div data-moa='wobble3D' > </div>

```

<h3>Authors or Acknowledgments</h3>
<ul>
<li>James Edward Burdge</li>
</ul>

<h3>License</h3>

This project is licensed under the MIT License
