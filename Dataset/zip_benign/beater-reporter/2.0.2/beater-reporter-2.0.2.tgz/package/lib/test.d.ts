declare type Test = Function;
export { Test };
