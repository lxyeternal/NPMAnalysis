import CistercianNumber from './component/CistercianNumber.svelte';
import { cistercianNumberPaths } from './component/numberPath.js';
export { cistercianNumberPaths };
export default CistercianNumber;
