import { SvelteComponentTyped } from "svelte";
declare const __propDef: {
    props: {
        value?: number | undefined;
    };
    events: {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export type CistercianNumberProps = typeof __propDef.props;
export type CistercianNumberEvents = typeof __propDef.events;
export type CistercianNumberSlots = typeof __propDef.slots;
export default class CistercianNumber extends SvelteComponentTyped<CistercianNumberProps, CistercianNumberEvents, CistercianNumberSlots> {
}
export {};
