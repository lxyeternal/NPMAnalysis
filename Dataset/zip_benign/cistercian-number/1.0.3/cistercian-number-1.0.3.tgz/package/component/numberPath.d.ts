export declare function cistercianNumberPaths(val: number): string[];
