 
# aai osp SDK

The official Javascript client library for the AAI one-stop flow.


## Table of Contents

- AAI OSP SDK
  - [Install](#install)
  - [Documentation](#documentation)
  - [Getting Started](#getting-started)
  - [Contributing](#contributing)
  - [Demo](#demo)
  - [License](#license)

## Install

```bash
npm install aai-osp-websdk
```


## Documentation

The module provides a sdk for the AAI OSP flow. For complete information about the API, head to
the [docs](https://one-stop-documentation.readme.io/docs/embedded-flow-integration).

## Getting Started

To open the flow you must create a `osp` object.

```javascript
import OSP from 'aai-osp-websdk'
const container = document.querySelector('#app')
const osp = OSP.init(container!, {
    token: 'XXXXX-XXXX-XXXX-XXXX-XXXXXXXXXX', // Obtain the token according to the integration doc
    environment: 'sandbox',
    language: 'en',
    captureConfig: {
        type: !!window.MediaRecorder ? 'video' : 'image',
        videoConfig: {
            videoBitsPerSecond: 200000,
        },
        imageConfig: {
            mimeType: 'image/jpeg',
            quality: 0.4,
            loopTime: 1000
        }
    },
    onReady() {
        console.log('onReady')
        osp.open()
    },
    onLoad() {
        console.log('onload')
    },
    onError() {
        console.error('onerror')
    },
    onEvent(data) {
        console.log(`onEvent:${JSON.stringify(data)}`)
    },
    onComplete(){
        console.log('workflow complete!')
    }
})
```

## DEMO

[npm integration OSP Demo](https://d9wl3c.csb.app/)

## License

[MIT](LICENSE)

[0]: https://one-stop-documentation.readme.io