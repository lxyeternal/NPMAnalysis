"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationTokens = void 0;
exports.ApplicationTokens = {
    LoggerToken: 'LoggerToken',
    RedisStoreToken: 'RedisStoreToken',
    RedisClientToken: 'RedisClientToken'
};
