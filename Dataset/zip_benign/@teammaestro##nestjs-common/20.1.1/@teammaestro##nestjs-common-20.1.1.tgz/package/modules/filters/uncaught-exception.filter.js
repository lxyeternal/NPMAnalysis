"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UncaughtExceptionFilter = void 0;
const common_1 = require("@nestjs/common");
const base_http_exception_filter_1 = require("./base-http-exception.filter");
const ignoredHttpStatuses = [
    common_1.HttpStatus.NOT_FOUND,
    common_1.HttpStatus.FORBIDDEN,
    common_1.HttpStatus.METHOD_NOT_ALLOWED,
    common_1.HttpStatus.PAYLOAD_TOO_LARGE
];
let UncaughtExceptionFilter = class UncaughtExceptionFilter extends base_http_exception_filter_1.BaseHttpExceptionFilter {
    catch(exception, host) {
        var _a;
        exception = this.getInitialException(exception);
        const contextType = this.getHostContextType(host);
        if (contextType === 'http') {
            if (ignoredHttpStatuses.indexOf(exception.status) === -1) {
                this.errorHandler.captureException(exception);
            }
            const res = host.switchToHttp().getResponse();
            const statusCode = exception.status || 500;
            let message;
            if (exception.message) {
                message = exception.message.error || exception.message;
            }
            else {
                message = 'There was an internal server error';
            }
            const exceptionResponse = Object.assign({ statusCode, appCode: (_a = exception.appCode) !== null && _a !== void 0 ? _a : common_1.HttpStatus[statusCode], message }, exception.customResponse);
            res.status(statusCode).json(exceptionResponse);
        }
        else {
            return this.handleRpcException(exception, host, true);
        }
    }
};
UncaughtExceptionFilter = __decorate([
    (0, common_1.Catch)()
], UncaughtExceptionFilter);
exports.UncaughtExceptionFilter = UncaughtExceptionFilter;
