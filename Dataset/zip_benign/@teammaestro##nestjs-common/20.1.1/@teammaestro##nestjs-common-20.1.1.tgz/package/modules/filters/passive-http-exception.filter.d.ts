import { ArgumentsHost, ExceptionFilter } from '@nestjs/common';
import { BaseHttpExceptionFilter } from './base-http-exception.filter';
import { PassiveException } from '../exceptions/passive.exception';
export declare class PassiveHttpExceptionFilter extends BaseHttpExceptionFilter implements ExceptionFilter {
    catch(exception: PassiveException, host: ArgumentsHost): import("rxjs").Observable<never>;
}
