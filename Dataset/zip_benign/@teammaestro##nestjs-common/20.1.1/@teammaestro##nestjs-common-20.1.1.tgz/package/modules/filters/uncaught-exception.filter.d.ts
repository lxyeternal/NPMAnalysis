import { ArgumentsHost, ExceptionFilter } from '@nestjs/common';
import { BaseHttpExceptionFilter } from './base-http-exception.filter';
export declare class UncaughtExceptionFilter extends BaseHttpExceptionFilter implements ExceptionFilter {
    catch(exception: any, host: ArgumentsHost): import("rxjs").Observable<never>;
}
