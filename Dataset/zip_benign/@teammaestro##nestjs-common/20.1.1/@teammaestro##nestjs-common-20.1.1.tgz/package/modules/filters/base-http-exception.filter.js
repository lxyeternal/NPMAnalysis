"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseHttpExceptionFilter = void 0;
const common_1 = require("@nestjs/common");
const rxjs_1 = require("rxjs");
const error_handler_service_1 = require("../services/error-handler/error-handler.service");
let BaseHttpExceptionFilter = class BaseHttpExceptionFilter {
    constructor(errorHandler) {
        this.errorHandler = errorHandler;
    }
    getInitialException(exception) {
        if (exception.status === common_1.HttpStatus.FORBIDDEN) {
            exception.status = common_1.HttpStatus.METHOD_NOT_ALLOWED;
        }
        return exception;
    }
    getHostContextType(host) {
        const res = host.switchToHttp().getResponse();
        if (res.req && res.status && typeof res.status === 'function') {
            return 'http';
        }
        return 'rpc';
    }
    handleRpcException(exception, host, logException) {
        const context = host.switchToRpc().getContext();
        if (context.rpcType === 'ACTIVE_MQ') {
            if (logException) {
                this.errorHandler.captureException(exception);
            }
            return (0, rxjs_1.throwError)(exception);
        }
        else {
            return rxjs_1.EMPTY;
        }
    }
};
BaseHttpExceptionFilter = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [error_handler_service_1.ErrorHandler])
], BaseHttpExceptionFilter);
exports.BaseHttpExceptionFilter = BaseHttpExceptionFilter;
