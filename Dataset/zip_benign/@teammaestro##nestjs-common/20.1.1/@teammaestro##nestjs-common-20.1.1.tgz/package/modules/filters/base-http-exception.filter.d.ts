import { ArgumentsHost, ContextType } from '@nestjs/common';
import { ErrorHandler } from '../services/error-handler/error-handler.service';
export declare class BaseHttpExceptionFilter {
    protected readonly errorHandler: ErrorHandler;
    constructor(errorHandler: ErrorHandler);
    getInitialException(exception: any): any;
    getHostContextType(host: ArgumentsHost): ContextType;
    handleRpcException(exception: any, host: ArgumentsHost, logException: boolean): import("rxjs").Observable<never>;
}
