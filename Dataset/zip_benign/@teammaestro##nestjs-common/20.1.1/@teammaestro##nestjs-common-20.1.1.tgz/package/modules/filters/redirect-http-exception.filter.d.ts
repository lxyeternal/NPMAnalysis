import { ArgumentsHost, ExceptionFilter } from '@nestjs/common';
import { BaseHttpExceptionFilter } from './base-http-exception.filter';
import { RedirectException } from '../exceptions';
export declare class RedirectHttpExceptionFilter extends BaseHttpExceptionFilter implements ExceptionFilter {
    catch(exception: RedirectException, host: ArgumentsHost): void;
}
