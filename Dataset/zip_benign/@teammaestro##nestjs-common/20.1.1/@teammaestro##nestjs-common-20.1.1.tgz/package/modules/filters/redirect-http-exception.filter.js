"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedirectHttpExceptionFilter = void 0;
const common_1 = require("@nestjs/common");
const base_http_exception_filter_1 = require("./base-http-exception.filter");
const exceptions_1 = require("../exceptions");
let RedirectHttpExceptionFilter = class RedirectHttpExceptionFilter extends base_http_exception_filter_1.BaseHttpExceptionFilter {
    catch(exception, host) {
        const res = host.switchToHttp().getResponse();
        const req = host.switchToHttp().getRequest();
        exception = this.getInitialException(exception);
        let scheme = '';
        if (req['customUrlScheme']) {
            scheme = req['customUrlScheme'];
        }
        res.redirect(`${scheme}${exception.redirectPath}`);
    }
};
RedirectHttpExceptionFilter = __decorate([
    (0, common_1.Catch)(exceptions_1.RedirectException)
], RedirectHttpExceptionFilter);
exports.RedirectHttpExceptionFilter = RedirectHttpExceptionFilter;
