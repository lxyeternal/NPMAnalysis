import { ArgumentsHost, ExceptionFilter } from '@nestjs/common';
import { BaseHttpExceptionFilter } from './base-http-exception.filter';
import { LoggedException } from '../exceptions/logged.exception';
export declare class LoggedHttpExceptionFilter extends BaseHttpExceptionFilter implements ExceptionFilter {
    catch(exception: LoggedException, host: ArgumentsHost): import("rxjs").Observable<never>;
}
