"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.throwValidationErrors = void 0;
const exceptions_1 = require("../exceptions");
const throwValidationErrors = (errors, markedCritical = false) => {
    const constraints = errors[0].constraints;
    const children = errors[0].children;
    if (constraints) {
        const message = constraints[Object.keys(constraints)[0]];
        throw new exceptions_1.ValidationException(message, { critical: markedCritical });
    }
    else if (children) {
        (0, exports.throwValidationErrors)(children, markedCritical);
    }
    else {
        throw new exceptions_1.ValidationException('Validation Failed', { critical: markedCritical });
    }
};
exports.throwValidationErrors = throwValidationErrors;
