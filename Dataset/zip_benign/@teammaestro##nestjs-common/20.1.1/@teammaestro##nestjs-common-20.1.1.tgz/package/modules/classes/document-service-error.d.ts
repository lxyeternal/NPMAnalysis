export declare class DocumentServiceExceptionError extends Error {
    message: string;
    stack: string;
    original: any;
    constructor(error: any);
}
