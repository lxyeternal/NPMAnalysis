"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AxiosExceptionError = void 0;
class AxiosExceptionError extends Error {
    constructor(error) {
        super();
        if (error) {
            if (error.response) {
                this.message = `${error.response.status} - ${error.response.statusText}`;
                this.original = {
                    config: error.config,
                    response: {
                        status: error.response.status,
                        statusText: error.response.statusText,
                        headers: error.response.headers,
                        data: error.response.data
                    }
                };
            }
            else {
                this.message = error.message;
            }
            this.stack = error.stack;
        }
    }
}
exports.AxiosExceptionError = AxiosExceptionError;
