"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentServiceExceptionError = void 0;
class DocumentServiceExceptionError extends Error {
    constructor(error) {
        super();
        if (error) {
            this.message = error.message;
            this.stack = error.stack;
            this.original = error.original;
        }
    }
}
exports.DocumentServiceExceptionError = DocumentServiceExceptionError;
