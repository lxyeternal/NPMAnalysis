"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqlExceptionError = void 0;
class SqlExceptionError extends Error {
    constructor(error) {
        super();
        if (error) {
            this.message = error.message;
            this.stack = error.stack;
            this.original = error.original;
        }
    }
}
exports.SqlExceptionError = SqlExceptionError;
