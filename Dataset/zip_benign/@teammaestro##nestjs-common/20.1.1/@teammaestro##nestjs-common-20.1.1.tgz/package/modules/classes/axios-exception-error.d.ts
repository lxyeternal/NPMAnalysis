import { AxiosError } from 'axios';
export declare class AxiosExceptionError extends Error {
    message: string;
    stack: string;
    original: any;
    constructor(error: AxiosError);
}
