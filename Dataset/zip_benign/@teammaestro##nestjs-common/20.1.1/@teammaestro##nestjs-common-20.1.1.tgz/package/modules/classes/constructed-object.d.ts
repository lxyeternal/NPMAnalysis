export declare class ConstructedObject {
    readonly object: any;
    constructor(object: any);
}
