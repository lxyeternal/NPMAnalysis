import { SequelizeError } from '../interfaces';
export declare class SqlExceptionError extends Error {
    message: string;
    stack: string;
    original: any;
    constructor(error: SequelizeError);
}
