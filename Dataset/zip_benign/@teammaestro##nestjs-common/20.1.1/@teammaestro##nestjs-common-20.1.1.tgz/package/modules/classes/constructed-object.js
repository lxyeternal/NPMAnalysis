"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConstructedObject = void 0;
class ConstructedObject {
    constructor(object) {
        this.object = object;
    }
}
exports.ConstructedObject = ConstructedObject;
