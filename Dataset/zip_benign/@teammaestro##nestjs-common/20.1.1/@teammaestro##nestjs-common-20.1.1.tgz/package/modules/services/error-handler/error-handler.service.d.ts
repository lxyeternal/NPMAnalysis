import { StaticErrorHandlerConfiguration } from '@teammaestro/node-common';
import { Logger } from 'log4js';
import { Breadcrum } from '../../interfaces/breadcrum.interface';
export declare class ErrorHandler {
    private readonly logger;
    private readonly errorHandlerConfiguration?;
    constructor(logger: Logger, errorHandlerConfiguration?: StaticErrorHandlerConfiguration);
    captureBreadcrumb(breadcrumb: Breadcrum): void;
    captureException(error: Error): string;
    captureMessage(message: string, tags?: {
        [key: string]: string;
    }): void;
}
