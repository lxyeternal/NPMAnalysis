"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorHandler = void 0;
const common_1 = require("@nestjs/common");
const node_common_1 = require("@teammaestro/node-common");
const log4js_1 = require("log4js");
const application_tokens_const_1 = require("../../application-tokens.const");
const error_handler_configuration_provider_1 = require("../../providers/error-handler-configuration/error-handler-configuration.provider");
let ErrorHandler = class ErrorHandler {
    constructor(logger, errorHandlerConfiguration) {
        this.logger = logger;
        this.errorHandlerConfiguration = errorHandlerConfiguration;
        this.errorHandlerConfiguration = Object.assign({}, {
            useSentry: true
        }, errorHandlerConfiguration !== null && errorHandlerConfiguration !== void 0 ? errorHandlerConfiguration : {});
    }
    captureBreadcrumb(breadcrumb) {
        node_common_1.StaticErrorHandlerService.captureBreadcrumb(breadcrumb, this.logger, this.errorHandlerConfiguration);
    }
    captureException(error) {
        return node_common_1.StaticErrorHandlerService.captureException(error, this.logger, this.errorHandlerConfiguration);
    }
    captureMessage(message, tags) {
        node_common_1.StaticErrorHandlerService.captureMessage(message, this.logger, this.errorHandlerConfiguration, tags);
    }
};
ErrorHandler = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(application_tokens_const_1.ApplicationTokens.LoggerToken)),
    __param(1, (0, common_1.Inject)(error_handler_configuration_provider_1.ErrorHandlerConfigurationToken)),
    __param(1, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [log4js_1.Logger, Object])
], ErrorHandler);
exports.ErrorHandler = ErrorHandler;
