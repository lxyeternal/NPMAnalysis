"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisService = void 0;
const common_1 = require("@nestjs/common");
const application_tokens_const_1 = require("../../application-tokens.const");
const redis_exception_1 = require("../../exceptions/redis.exception");
const providers_1 = require("../../providers");
const redis_configuration_provider_1 = require("../../providers/redis-configuration/redis-configuration.provider");
const error_handler_1 = require("../error-handler");
let RedisService = class RedisService {
    constructor(client, redisConfiguration, errorHandler) {
        var _a, _b;
        this.client = client;
        this.redisConfiguration = redisConfiguration;
        this.errorHandler = errorHandler;
        this.client.on('error', error => this.errorHandler.captureException(new redis_exception_1.RedisException(error)));
        this.client.on('ready', () => this.errorHandler.captureBreadcrumb({ message: 'Connected to Redis' }));
        this.client.on('reconnecting', () => this.errorHandler.captureBreadcrumb({ message: 'Attempting to reconnect to Redis...' }));
        this.client.on('end', () => this.errorHandler.captureException(new redis_exception_1.RedisException(new Error('Redis Connection Fatal'))));
        this.defaultExpiration = (_a = this.redisConfiguration.expiration) !== null && _a !== void 0 ? _a : 86400;
        this.keyPrefix = (_b = this.redisConfiguration.keyPrefix) !== null && _b !== void 0 ? _b : '';
    }
    getValue(key, ignorePrefix) {
        return new Promise((resolve, reject) => {
            this.client.connection.get(`${ignorePrefix ? '' : this.keyPrefix}${key}`, async (error, response) => {
                if (error) {
                    return reject(error);
                }
                let parsedResponse;
                try {
                    parsedResponse = JSON.parse(response);
                }
                catch (error) {
                    reject(error);
                }
                return resolve(parsedResponse);
            });
        });
    }
    setValue(key, value, duration = this.defaultExpiration, ignorePrefix) {
        return new Promise((resolve, reject) => {
            if (duration > 0) {
                this.client.connection.set(`${ignorePrefix ? '' : this.keyPrefix}${key}`, JSON.stringify(value), 'EX', duration, (err, response) => {
                    if (err) {
                        return reject(err);
                    }
                    return resolve(response);
                });
            }
            else {
                this.client.connection.set(`${ignorePrefix ? '' : this.keyPrefix}${key}`, JSON.stringify(value), (err, response) => {
                    if (err) {
                        return reject(err);
                    }
                    return resolve(response);
                });
            }
        });
    }
    async delete(key, ignorePrefix) {
        if (Array.isArray(key)) {
            key = key.map(individualKey => ignorePrefix ? '' : this.keyPrefix + individualKey);
        }
        else {
            key = `${ignorePrefix ? '' : this.keyPrefix}${key}`;
        }
        try {
            await this.client.connection.del(key);
        }
        catch (error) {
            throw new redis_exception_1.RedisException(error);
        }
    }
    async getKeys(pattern, ignorePrefix) {
        return new Promise((resolve, reject) => {
            this.client.connection.keys(`${ignorePrefix ? '' : this.keyPrefix}${pattern}`, (err, keys) => {
                if (err) {
                    reject(err);
                }
                else {
                    resolve(keys);
                }
            });
        });
    }
};
RedisService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(application_tokens_const_1.ApplicationTokens.RedisClientToken)),
    __param(1, (0, common_1.Inject)(redis_configuration_provider_1.RedisConfigurationToken)),
    __metadata("design:paramtypes", [providers_1.RedisClient, Object, error_handler_1.ErrorHandler])
], RedisService);
exports.RedisService = RedisService;
