import { RedisClient } from '../../providers';
import { RedisConfigurationOptions } from '../../providers/redis-configuration/redis-configuration.provider';
import { ErrorHandler } from '../error-handler';
export declare class RedisService {
    readonly client: RedisClient;
    private readonly redisConfiguration;
    private readonly errorHandler;
    private keyPrefix;
    private defaultExpiration;
    constructor(client: RedisClient, redisConfiguration: RedisConfigurationOptions, errorHandler: ErrorHandler);
    getValue(key: string, ignorePrefix?: boolean): Promise<any>;
    setValue(key: string, value: any, duration?: number, ignorePrefix?: boolean): Promise<any>;
    delete(key: string | string[], ignorePrefix?: boolean): Promise<void>;
    getKeys(pattern: string, ignorePrefix?: boolean): Promise<string[]>;
}
