import { PassportWhitelistedErrors } from '../enums';
export declare function PassportAuthGuard(strategyToken: string): {
    new (): {
        whitelistedErrors: Set<string>;
        handleRequest(error: any, user: any, passportError: any): any;
        isWhitelisted(error?: Error): boolean;
        handleErrors(error: Error): void;
        throwException(): void;
        addToWhitelist(messages: string[]): void;
        removeFromWhitelist(messages: PassportWhitelistedErrors[]): void;
        canActivate(context: import("@nestjs/common").ExecutionContext): boolean | Promise<boolean> | import("rxjs").Observable<boolean>;
        logIn<TRequest extends {
            logIn: Function;
        } = any>(request: TRequest): Promise<void>;
        getAuthenticateOptions(context: any): import("@nestjs/passport").IAuthModuleOptions<any>;
    };
    apply(this: Function, thisArg: any, argArray?: any): any;
    call(this: Function, thisArg: any, ...argArray: any[]): any;
    bind(this: Function, thisArg: any, ...argArray: any[]): any;
    toString(): string;
    readonly length: number;
    arguments: any;
    caller: Function;
    readonly name: string;
    [Symbol.hasInstance](value: any): boolean;
};
