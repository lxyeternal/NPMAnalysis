export declare const ApplicationTokens: {
    LoggerToken: string;
    RedisStoreToken: string;
    RedisClientToken: string;
};
