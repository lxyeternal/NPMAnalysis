import { PaginationOptions } from '../interfaces';
import { SortDirection } from '../types';
export declare class Pagination {
    page: number;
    size: number;
    shift: number;
    sortBy: string;
    sortDir: SortDirection;
    offset: number;
    sortByModel: any;
    defaultSort: string;
    secondarySort?: any;
    static defaultSortDir: SortDirection;
    constructor(options: PaginationOptions, defaultSortBy: string);
    getOrderBy(options?: OrderByOptions): any[];
}
export interface OrderByOptions {
    sortById?: boolean;
    sortBy?: string;
}
