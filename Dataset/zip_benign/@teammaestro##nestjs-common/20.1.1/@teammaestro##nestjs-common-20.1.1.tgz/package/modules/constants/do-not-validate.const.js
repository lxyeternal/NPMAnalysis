"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DO_NOT_VALIDATE = void 0;
exports.DO_NOT_VALIDATE = 'teamhive:do-no-validate';
