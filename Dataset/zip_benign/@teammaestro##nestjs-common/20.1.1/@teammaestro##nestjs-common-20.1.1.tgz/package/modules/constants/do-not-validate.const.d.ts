export declare const DO_NOT_VALIDATE = "teamhive:do-no-validate";
