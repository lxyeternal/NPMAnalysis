"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PassportWhitelistedErrors = void 0;
var PassportWhitelistedErrors;
(function (PassportWhitelistedErrors) {
    PassportWhitelistedErrors["NoAuthToken"] = "No auth token";
    PassportWhitelistedErrors["JwtExpired"] = "jwt expired";
    PassportWhitelistedErrors["JwtNotActive"] = "jwt not active";
    PassportWhitelistedErrors["InvalidSignature"] = "invalid signature";
    PassportWhitelistedErrors["MaxAgeExceeded"] = "maxAge exceeded";
    PassportWhitelistedErrors["JwtMalformed"] = "jwt malformed";
    PassportWhitelistedErrors["UnexpectedToken"] = "Unexpected token";
    PassportWhitelistedErrors["InvalidToken"] = "invalid token";
})(PassportWhitelistedErrors = exports.PassportWhitelistedErrors || (exports.PassportWhitelistedErrors = {}));
