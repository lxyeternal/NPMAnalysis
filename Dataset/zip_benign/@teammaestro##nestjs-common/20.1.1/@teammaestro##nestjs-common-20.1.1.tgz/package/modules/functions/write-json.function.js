"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeJson = void 0;
const fs_1 = require("fs");
async function writeJson(path, object) {
    const { writeFile } = fs_1.promises;
    await writeFile(path, object);
}
exports.writeJson = writeJson;
