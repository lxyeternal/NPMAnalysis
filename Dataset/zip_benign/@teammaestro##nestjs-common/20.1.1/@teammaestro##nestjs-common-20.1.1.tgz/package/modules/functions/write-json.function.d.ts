export declare function writeJson(path: string, object: any): Promise<void>;
