import { ValidationTypes } from 'class-validator';
export declare function getValidation(targetConstructor: Function, propertyKey: string): ValidationTypes[];
