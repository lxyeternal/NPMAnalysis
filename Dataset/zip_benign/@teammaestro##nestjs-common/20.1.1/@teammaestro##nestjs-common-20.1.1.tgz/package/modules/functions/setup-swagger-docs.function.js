"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSwaggerDocs = void 0;
const swagger_1 = require("@nestjs/swagger");
const path_1 = require("path");
const write_json_function_1 = require("./write-json.function");
async function setupSwaggerDocs(app, outputDirectory = process.cwd(), applicationName = 'API') {
    const options = new swagger_1.DocumentBuilder()
        .setTitle(applicationName)
        .setDescription(`Documentation for ${applicationName}`)
        .addBearerAuth()
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, options);
    processDocument(document);
    await (0, write_json_function_1.writeJson)((0, path_1.join)(outputDirectory, 'openApi.json'), JSON.stringify(document));
}
exports.setupSwaggerDocs = setupSwaggerDocs;
function processDocument(document) {
    const methods = ['get', 'put', 'post', 'delete'];
    const tags = new Set();
    if (document && document.paths) {
        const paths = Object.keys(document.paths);
        for (const path of paths) {
            for (const method of methods) {
                if (document.paths[path][method] && document.paths[path][method].operationId) {
                    const operationId = document.paths[path][method].operationId;
                    if (document.paths[path][method].tags && document.paths[path][method].tags.length > 0) {
                        let tag = document.paths[path][method].tags[0];
                        tags.add(tag);
                        if (tag && tag.length > 0) {
                            tag = tag.replace(/\s/g, '');
                        }
                        document.paths[path][method].operationId = `${encodeURI(tag)}/${operationId}`;
                    }
                }
            }
        }
    }
    const sortedTags = Array.from(tags)
        .sort((strA, strB) => {
        const strANoAdmin = strA.replace('Admin - ', '');
        const strBNoAdmin = strB.replace('Admin - ', '');
        return strANoAdmin.localeCompare(strBNoAdmin, 'en');
    })
        .map((tagName) => ({
        name: tagName
    }));
    document.tags = sortedTags;
    return document;
}
