import { INestApplication } from '@nestjs/common';
export declare function setupSwaggerDocs(app: INestApplication, outputDirectory?: string, applicationName?: string): Promise<void>;
