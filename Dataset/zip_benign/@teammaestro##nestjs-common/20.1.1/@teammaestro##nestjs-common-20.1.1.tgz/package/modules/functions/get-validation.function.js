"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getValidation = void 0;
const class_validator_1 = require("class-validator");
function getValidation(targetConstructor, propertyKey) {
    const validatorStorage = (0, class_validator_1.getFromContainer)(class_validator_1.MetadataStorage);
    const targetValidationMetadata = validatorStorage.getTargetValidationMetadatas(targetConstructor, null, null);
    const validationMetadata = validatorStorage.groupByPropertyName(targetValidationMetadata);
    if (validationMetadata) {
        const propertyValidation = validationMetadata[propertyKey];
        if (propertyValidation && propertyValidation.length > 0) {
            return propertyValidation.map(validation => validation.type);
        }
    }
    return [];
}
exports.getValidation = getValidation;
