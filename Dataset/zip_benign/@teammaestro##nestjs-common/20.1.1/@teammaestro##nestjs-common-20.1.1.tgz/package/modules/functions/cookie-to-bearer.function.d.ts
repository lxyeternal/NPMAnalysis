import * as express from 'express';
export declare function CookieToBearer(cookieName?: string): (req: express.Request, res: express.Response, next: express.NextFunction) => void;
