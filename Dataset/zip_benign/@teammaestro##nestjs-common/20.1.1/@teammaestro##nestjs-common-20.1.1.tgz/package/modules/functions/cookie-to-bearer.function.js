"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CookieToBearer = void 0;
function CookieToBearer(cookieName = 'access_token') {
    return (req, res, next) => {
        if (req.cookies && req.cookies[cookieName]) {
            req.headers['authorization'] = `bearer ${req.cookies[cookieName]}`;
        }
        next();
    };
}
exports.CookieToBearer = CookieToBearer;
