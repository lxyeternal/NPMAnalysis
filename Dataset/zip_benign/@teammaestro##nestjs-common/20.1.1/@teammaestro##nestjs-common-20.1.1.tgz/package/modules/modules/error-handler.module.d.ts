import { DynamicModule } from '@nestjs/common';
import { ErrorHandlerConfigurationOptions } from '../providers';
export declare class ErrorHandlerModule {
    static register(optionsFactory?: () => ErrorHandlerConfigurationOptions): DynamicModule;
}
