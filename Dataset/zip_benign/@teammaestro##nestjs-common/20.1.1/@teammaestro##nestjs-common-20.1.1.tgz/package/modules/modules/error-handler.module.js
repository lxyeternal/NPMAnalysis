"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ErrorHandlerModule_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorHandlerModule = void 0;
const common_1 = require("@nestjs/common");
const providers_1 = require("../providers");
const services_1 = require("../services");
let ErrorHandlerModule = ErrorHandlerModule_1 = class ErrorHandlerModule {
    static register(optionsFactory) {
        return {
            module: ErrorHandlerModule_1,
            providers: [
                services_1.ErrorHandler,
                (0, providers_1.getErrorHandlerConfigurationProvider)(optionsFactory)
            ],
            exports: [services_1.ErrorHandler]
        };
    }
};
ErrorHandlerModule = ErrorHandlerModule_1 = __decorate([
    (0, common_1.Module)({
        providers: [
            services_1.ErrorHandler,
            (0, providers_1.getErrorHandlerConfigurationProvider)()
        ],
        exports: [
            services_1.ErrorHandler
        ]
    })
], ErrorHandlerModule);
exports.ErrorHandlerModule = ErrorHandlerModule;
