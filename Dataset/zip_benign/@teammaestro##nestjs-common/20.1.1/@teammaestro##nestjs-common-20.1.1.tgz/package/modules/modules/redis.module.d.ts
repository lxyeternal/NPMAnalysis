import { DynamicModule } from '@nestjs/common';
import { ClientOpts } from 'redis';
export declare class RedisModule {
    static register(optionsFactory?: () => ClientOpts): DynamicModule;
}
