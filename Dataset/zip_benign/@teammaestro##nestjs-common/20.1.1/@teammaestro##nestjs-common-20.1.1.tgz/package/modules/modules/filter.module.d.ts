export declare class FilterModule {
}
