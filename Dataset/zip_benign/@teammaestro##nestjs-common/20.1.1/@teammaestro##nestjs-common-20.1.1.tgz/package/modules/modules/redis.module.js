"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var RedisModule_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisModule = void 0;
const common_1 = require("@nestjs/common");
const providers_1 = require("../providers");
const redis_configuration_provider_1 = require("../providers/redis-configuration/redis-configuration.provider");
const services_1 = require("../services");
let RedisModule = RedisModule_1 = class RedisModule {
    static register(optionsFactory) {
        return {
            module: RedisModule_1,
            providers: [
                providers_1.RedisProvider,
                services_1.RedisService,
                (0, redis_configuration_provider_1.getRedisConfigurationProvider)(optionsFactory)
            ],
            exports: [
                services_1.RedisService
            ]
        };
    }
};
RedisModule = RedisModule_1 = __decorate([
    (0, common_1.Module)({
        providers: [
            providers_1.RedisProvider,
            services_1.RedisService,
            (0, redis_configuration_provider_1.getRedisConfigurationProvider)()
        ],
        exports: [
            services_1.RedisService
        ]
    })
], RedisModule);
exports.RedisModule = RedisModule;
