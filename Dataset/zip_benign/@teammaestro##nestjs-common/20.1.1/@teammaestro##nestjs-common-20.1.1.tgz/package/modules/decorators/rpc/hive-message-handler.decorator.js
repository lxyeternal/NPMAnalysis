"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HiveMessageHandler = void 0;
const microservices_1 = require("@nestjs/microservices");
const get_message_options_1 = require("./get-message-options");
const get_message_pattern_1 = require("./get-message-pattern");
function HiveMessageHandler(messageClass) {
    return (target, property, descriptor) => {
        const messagePattern = (0, get_message_pattern_1.getMessagePattern)(messageClass);
        const messageOptions = (0, get_message_options_1.getMessageOptions)(messageClass);
        if (messageOptions.isRpc) {
            (0, microservices_1.MessagePattern)(messagePattern)(target, property, descriptor);
        }
        else {
            (0, microservices_1.EventPattern)(messagePattern)(target, property, descriptor);
        }
    };
}
exports.HiveMessageHandler = HiveMessageHandler;
