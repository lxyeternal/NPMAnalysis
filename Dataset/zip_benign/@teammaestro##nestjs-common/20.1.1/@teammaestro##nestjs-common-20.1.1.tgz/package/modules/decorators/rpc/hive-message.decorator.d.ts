export declare const RPC_PATTERN_KEY = "loop:rpc-pattern-key";
export declare const RPC_OPTIONS_KEY = "teamhive:rpc-message-options";
export interface HiveMessageOptions {
    isRpc?: boolean;
}
export declare function HiveMessage(messagePattern: string, options?: HiveMessageOptions): ClassDecorator;
