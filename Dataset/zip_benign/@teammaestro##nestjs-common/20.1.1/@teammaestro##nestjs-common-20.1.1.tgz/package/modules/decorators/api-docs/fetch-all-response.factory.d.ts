export declare const fetchAllResponseFactory: (contentClass: any) => any;
