"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Critical = void 0;
const common_1 = require("@nestjs/common");
const Critical = (critical = true) => (0, common_1.SetMetadata)('markedCritical', critical);
exports.Critical = Critical;
