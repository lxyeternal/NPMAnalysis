"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InjectMetadata = exports.INJECTED_METADATA_KEY = void 0;
const common_1 = require("@nestjs/common");
const constants_1 = require("../../constants");
exports.INJECTED_METADATA_KEY = Symbol('INJECTED METADATA KEY');
const InjectMetadata = (reqProperty, ...injectFunctions) => {
    return (target, property, index) => {
        if (reqProperty === 'body') {
            (0, common_1.Body)(constants_1.DO_NOT_VALIDATE)(target, property, index);
        }
        else if (reqProperty === 'query') {
            (0, common_1.Query)(constants_1.DO_NOT_VALIDATE)(target, property, index);
        }
        (0, common_1.createParamDecorator)((data, ctx) => {
            const req = ctx.switchToHttp().getRequest();
            if (!reqProperty || typeof req[reqProperty] !== 'object') {
                return req[reqProperty];
            }
            const reqValue = req[reqProperty];
            const [paramTarget, paramProperty, paramIndex] = data;
            let injectedMetadata = {};
            injectFunctions.forEach((fn) => {
                injectedMetadata = Object.assign(injectedMetadata, fn(ctx, paramTarget, paramProperty, paramIndex));
            });
            return Object.assign(Object.assign({}, reqValue), { [exports.INJECTED_METADATA_KEY]: injectedMetadata });
        })([target, property, index])(target, property, index);
    };
};
exports.InjectMetadata = InjectMetadata;
