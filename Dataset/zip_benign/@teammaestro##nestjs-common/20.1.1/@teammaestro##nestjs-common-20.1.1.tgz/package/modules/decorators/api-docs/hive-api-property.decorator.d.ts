import { ApiPropertyOptions } from '@nestjs/swagger';
export declare function HiveApiModelProperty(description: string, metadata?: ApiPropertyOptions): PropertyDecorator;
