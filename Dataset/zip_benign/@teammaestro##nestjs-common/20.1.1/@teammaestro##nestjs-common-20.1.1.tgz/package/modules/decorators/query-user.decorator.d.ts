export declare const QueryUser: (...dataOrPipes: any[]) => ParameterDecorator;
