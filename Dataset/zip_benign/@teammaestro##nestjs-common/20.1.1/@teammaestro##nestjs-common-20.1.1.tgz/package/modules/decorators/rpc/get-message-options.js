"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMessageOptions = void 0;
const hive_message_decorator_1 = require("./hive-message.decorator");
function getMessageOptions(target) {
    var _a;
    return (_a = Reflect.getMetadata(hive_message_decorator_1.RPC_OPTIONS_KEY, target)) !== null && _a !== void 0 ? _a : {};
}
exports.getMessageOptions = getMessageOptions;
