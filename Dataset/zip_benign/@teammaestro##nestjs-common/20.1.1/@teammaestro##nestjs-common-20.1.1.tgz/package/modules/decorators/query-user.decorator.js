"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryUser = void 0;
const common_1 = require("@nestjs/common");
exports.QueryUser = (0, common_1.createParamDecorator)((_data, ctx) => {
    const req = ctx.switchToHttp().getRequest();
    return Object.assign({ user: req.user || {} }, req.query);
});
