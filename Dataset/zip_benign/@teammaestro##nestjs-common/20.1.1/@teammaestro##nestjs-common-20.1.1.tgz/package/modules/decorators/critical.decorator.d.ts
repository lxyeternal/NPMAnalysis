export declare const Critical: (critical?: boolean) => import("@nestjs/common").CustomDecorator<string>;
