"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HiveMessage = exports.RPC_OPTIONS_KEY = exports.RPC_PATTERN_KEY = void 0;
const critical_decorator_1 = require("../critical.decorator");
exports.RPC_PATTERN_KEY = 'loop:rpc-pattern-key';
exports.RPC_OPTIONS_KEY = 'teamhive:rpc-message-options';
function HiveMessage(messagePattern, options = {}) {
    return (target) => {
        (0, critical_decorator_1.Critical)()(target);
        Reflect.defineMetadata(exports.RPC_PATTERN_KEY, messagePattern, target);
        Reflect.defineMetadata(exports.RPC_OPTIONS_KEY, options, target);
    };
}
exports.HiveMessage = HiveMessage;
