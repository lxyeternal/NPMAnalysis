export declare const Permissions: <T>(...permissions: T[]) => import("@nestjs/common").CustomDecorator<string>;
