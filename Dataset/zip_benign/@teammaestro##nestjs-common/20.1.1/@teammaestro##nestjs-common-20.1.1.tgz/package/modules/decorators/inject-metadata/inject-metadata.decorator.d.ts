export declare const INJECTED_METADATA_KEY: unique symbol;
export declare const InjectMetadata: (reqProperty?: string, ...injectFunctions: ((req: any, paramTarget: any, paramProperty: any, paramIndex: any) => object)[]) => (target: any, property: any, index: any) => void;
