"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HiveApiModelProperty = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const get_validation_function_1 = require("../../functions/get-validation.function");
function HiveApiModelProperty(description, metadata = {}) {
    return (target, propertyKey) => {
        const validations = (0, get_validation_function_1.getValidation)(target.constructor, propertyKey);
        metadata.required =
            metadata.required !== undefined
                ? metadata.required
                : !validations.includes(class_validator_1.ValidationTypes.CONDITIONAL_VALIDATION);
        (0, swagger_1.ApiProperty)(Object.assign({ description }, metadata))(target, propertyKey);
    };
}
exports.HiveApiModelProperty = HiveApiModelProperty;
