"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMessagePattern = void 0;
const hive_message_decorator_1 = require("./hive-message.decorator");
function getMessagePattern(target) {
    return Reflect.getMetadata(hive_message_decorator_1.RPC_PATTERN_KEY, target);
}
exports.getMessagePattern = getMessagePattern;
