import { HiveApiDocConfig } from '../../interfaces';
export declare function HiveApiDocs(options: HiveApiDocConfig): MethodDecorator;
