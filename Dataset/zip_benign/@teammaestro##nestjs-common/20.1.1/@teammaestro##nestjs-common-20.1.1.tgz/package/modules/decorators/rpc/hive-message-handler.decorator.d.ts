export declare function HiveMessageHandler(messageClass: any): MethodDecorator;
