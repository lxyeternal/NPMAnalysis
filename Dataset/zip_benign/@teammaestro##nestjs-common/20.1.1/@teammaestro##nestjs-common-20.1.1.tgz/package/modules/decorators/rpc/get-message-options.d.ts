import { HiveMessageOptions } from './hive-message.decorator';
export declare function getMessageOptions(target: any): HiveMessageOptions;
