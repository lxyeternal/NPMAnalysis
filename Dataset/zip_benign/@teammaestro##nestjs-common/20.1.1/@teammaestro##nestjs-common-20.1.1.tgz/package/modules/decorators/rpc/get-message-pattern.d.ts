export declare function getMessagePattern(target: any): any;
