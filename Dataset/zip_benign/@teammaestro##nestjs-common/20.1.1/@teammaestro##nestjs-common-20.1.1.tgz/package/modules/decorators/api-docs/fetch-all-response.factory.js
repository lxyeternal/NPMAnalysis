"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchAllResponseFactory = void 0;
const hive_api_property_decorator_1 = require("./hive-api-property.decorator");
const fetchAllResponseFactory = (contentClass) => {
    class FetchAllResponseClass {
        constructor(findAndCountAll) {
            this.totalElements = findAndCountAll.count;
            this.content = findAndCountAll.rows;
        }
    }
    __decorate([
        (0, hive_api_property_decorator_1.HiveApiModelProperty)(`The count of total elements.`),
        __metadata("design:type", Number)
    ], FetchAllResponseClass.prototype, "totalElements", void 0);
    __decorate([
        (0, hive_api_property_decorator_1.HiveApiModelProperty)('The content', {
            type: contentClass
        }),
        __metadata("design:type", Array)
    ], FetchAllResponseClass.prototype, "content", void 0);
    return FetchAllResponseClass;
};
exports.fetchAllResponseFactory = fetchAllResponseFactory;
