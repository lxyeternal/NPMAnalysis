export declare type SortDirection = 'ASC' | 'DESC';
