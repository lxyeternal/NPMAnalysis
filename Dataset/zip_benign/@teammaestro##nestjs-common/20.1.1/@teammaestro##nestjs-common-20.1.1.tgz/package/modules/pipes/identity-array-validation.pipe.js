"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IdentityArrayValidationPipe = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const exceptions_1 = require("../exceptions");
let IdentityArrayValidationPipe = class IdentityArrayValidationPipe {
    async transform(values = []) {
        if (!values) {
            throw new exceptions_1.ValidationException('array of identities is not defined');
        }
        if (!(0, class_validator_1.isArray)(values)) {
            throw new exceptions_1.ValidationException('invalid array');
        }
        values.forEach((value) => {
            if (!(0, class_validator_1.isUUID)(value)) {
                throw new exceptions_1.ValidationException('invalid uuid list of identities');
            }
        });
        return values;
    }
};
IdentityArrayValidationPipe = __decorate([
    (0, common_1.Injectable)()
], IdentityArrayValidationPipe);
exports.IdentityArrayValidationPipe = IdentityArrayValidationPipe;
