import { PipeTransform } from '@nestjs/common';
export declare class IdentityArrayValidationPipe implements PipeTransform<string[]> {
    transform(values?: string[]): Promise<string[]>;
}
