import { ValidationArguments, ValidationOptions, ValidatorConstraintInterface } from 'class-validator';
export declare class IsNumberConstraint implements ValidatorConstraintInterface {
    validate(number: any): boolean;
    defaultMessage(args: ValidationArguments): string;
}
export declare function IsNumber(validationOptions?: ValidationOptions): (object: Object, propertyName: string) => void;
