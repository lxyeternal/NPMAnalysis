"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessingException = void 0;
const common_1 = require("@nestjs/common");
const passive_exception_1 = require("./passive.exception");
class ProcessingException extends passive_exception_1.PassiveException {
    constructor(message) {
        super('ProcessingException', message || 'Processing', common_1.HttpStatus.ACCEPTED);
    }
}
exports.ProcessingException = ProcessingException;
