"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConflictException = void 0;
const common_1 = require("@nestjs/common");
const passive_exception_1 = require("./passive.exception");
class ConflictException extends passive_exception_1.PassiveException {
    constructor(error, conflictDescription) {
        super('ConflictException', conflictDescription, common_1.HttpStatus.CONFLICT, error);
    }
}
exports.ConflictException = ConflictException;
