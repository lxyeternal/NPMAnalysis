import { PassiveException } from './passive.exception';
export declare class ProcessingException extends PassiveException {
    constructor(message?: string);
}
