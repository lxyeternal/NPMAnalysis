import { LoggedException } from './logged.exception';
export declare class SsoException extends LoggedException {
    constructor(error?: Error, customMessage?: string);
}
