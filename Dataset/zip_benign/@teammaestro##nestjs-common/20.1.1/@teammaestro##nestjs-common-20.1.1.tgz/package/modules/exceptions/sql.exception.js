"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqlException = void 0;
const common_1 = require("@nestjs/common");
const logged_exception_1 = require("./logged.exception");
const classes_1 = require("../classes");
class SqlException extends logged_exception_1.LoggedException {
    constructor(error, customMessage) {
        super('SqlException', customMessage || 'Internal server error with database', common_1.HttpStatus.INTERNAL_SERVER_ERROR, new classes_1.SqlExceptionError(error));
        this.loggedMetadata = {
            sql: error.sql
        };
        if (error.original) {
            this.loggedMetadata.original = {
                message: error.original.message,
                detail: error.original.detail
            };
        }
    }
}
exports.SqlException = SqlException;
