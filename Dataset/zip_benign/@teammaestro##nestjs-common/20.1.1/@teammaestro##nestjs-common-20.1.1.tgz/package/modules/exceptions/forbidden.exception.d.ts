import { PassiveException } from './passive.exception';
export declare class ForbiddenException extends PassiveException {
    constructor(message?: string, options?: {
        appCode?: string;
    });
}
