"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseException = void 0;
const common_1 = require("@nestjs/common");
class BaseException extends common_1.HttpException {
    constructor(name, response, status, error) {
        super(response, status);
        this.name = name;
        this.error = error;
        this.tags = {};
        this.loggedMetadata = {};
    }
}
exports.BaseException = BaseException;
