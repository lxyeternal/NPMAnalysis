"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentServiceException = void 0;
const common_1 = require("@nestjs/common");
const logged_exception_1 = require("./logged.exception");
const document_service_error_1 = require("../classes/document-service-error");
class DocumentServiceException extends logged_exception_1.LoggedException {
    constructor(error) {
        super('DocumentServiceException', 'Internal Server Error - DMS', common_1.HttpStatus.INTERNAL_SERVER_ERROR, new document_service_error_1.DocumentServiceExceptionError(error));
    }
}
exports.DocumentServiceException = DocumentServiceException;
