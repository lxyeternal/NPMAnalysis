"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotFoundException = void 0;
const common_1 = require("@nestjs/common");
const passive_exception_1 = require("./passive.exception");
class NotFoundException extends passive_exception_1.PassiveException {
    constructor(message, options) {
        super('NotFoundException', message || 'Item not found', common_1.HttpStatus.NOT_FOUND);
        if (options === null || options === void 0 ? void 0 : options.appCode) {
            this.appCode = options.appCode;
        }
    }
}
exports.NotFoundException = NotFoundException;
