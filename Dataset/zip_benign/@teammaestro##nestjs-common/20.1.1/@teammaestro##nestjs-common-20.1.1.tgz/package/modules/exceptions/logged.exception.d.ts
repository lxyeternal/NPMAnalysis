import { BaseException } from './base.exception';
export declare class LoggedException extends BaseException {
    tags: {
        [key: string]: string;
    };
    constructor(name: string, response: string | object, status: number, error?: Error);
}
