import { LoggedException } from './logged.exception';
export declare class ValidationException extends LoggedException {
    constructor(message?: string, options?: {
        appCode?: string;
        critical?: boolean;
    });
}
