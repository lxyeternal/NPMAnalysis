"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForbiddenException = void 0;
const common_1 = require("@nestjs/common");
const passive_exception_1 = require("./passive.exception");
class ForbiddenException extends passive_exception_1.PassiveException {
    constructor(message = 'Forbidden Action', options) {
        super('ForbiddenException', message, common_1.HttpStatus.FORBIDDEN);
        if (options === null || options === void 0 ? void 0 : options.appCode) {
            this.appCode = options.appCode;
        }
    }
}
exports.ForbiddenException = ForbiddenException;
