import { BaseException } from './base.exception';
export declare class PassiveException extends BaseException {
    constructor(name: string, response: string | object, status: number, error?: Error);
}
