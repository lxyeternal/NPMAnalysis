import { HttpException } from "@nestjs/common";
export declare class BaseException extends HttpException {
    customResponse: {
        [key: string]: any;
    };
    tags: {
        [key: string]: number | string | boolean | bigint | symbol | null | undefined;
    };
    error: Error;
    loggedMetadata: any;
    appCode?: string;
    constructor(name: string, response: string | object, status: number, error?: Error);
}
