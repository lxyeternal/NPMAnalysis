import { LoggedException } from './logged.exception';
export declare class RedisException extends LoggedException {
    constructor(error?: any);
}
