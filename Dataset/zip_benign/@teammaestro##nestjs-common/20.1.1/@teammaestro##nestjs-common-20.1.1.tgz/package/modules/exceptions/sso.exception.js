"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SsoException = void 0;
const common_1 = require("@nestjs/common");
const logged_exception_1 = require("./logged.exception");
class SsoException extends logged_exception_1.LoggedException {
    constructor(error, customMessage) {
        super('SsoException', customMessage || 'Internal server error with SSO', common_1.HttpStatus.INTERNAL_SERVER_ERROR, error);
    }
}
exports.SsoException = SsoException;
