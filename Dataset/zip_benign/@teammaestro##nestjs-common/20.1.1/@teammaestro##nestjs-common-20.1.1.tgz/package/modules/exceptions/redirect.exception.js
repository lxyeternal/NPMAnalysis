"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedirectException = void 0;
const common_1 = require("@nestjs/common");
const base_exception_1 = require("./base.exception");
class RedirectException extends base_exception_1.BaseException {
    constructor(redirectPath) {
        super('RedirectException', 'Redirect', common_1.HttpStatus.TEMPORARY_REDIRECT);
        this.redirectPath = redirectPath;
    }
}
exports.RedirectException = RedirectException;
