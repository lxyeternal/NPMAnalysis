import { PassiveException } from './passive.exception';
export declare class ConflictException extends PassiveException {
    constructor(error: any, conflictDescription: string);
}
