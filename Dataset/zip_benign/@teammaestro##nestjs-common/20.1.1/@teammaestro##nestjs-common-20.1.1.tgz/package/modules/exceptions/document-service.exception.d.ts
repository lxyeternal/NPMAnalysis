import { LoggedException } from './logged.exception';
export declare class DocumentServiceException extends LoggedException {
    constructor(error: any);
}
