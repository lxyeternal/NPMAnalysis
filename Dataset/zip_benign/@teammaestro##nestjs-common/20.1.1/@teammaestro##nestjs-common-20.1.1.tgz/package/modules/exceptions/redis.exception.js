"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisException = void 0;
const common_1 = require("@nestjs/common");
const logged_exception_1 = require("./logged.exception");
class RedisException extends logged_exception_1.LoggedException {
    constructor(error) {
        super('RedisException', 'Internal server error with redis', common_1.HttpStatus.INTERNAL_SERVER_ERROR, error);
    }
}
exports.RedisException = RedisException;
