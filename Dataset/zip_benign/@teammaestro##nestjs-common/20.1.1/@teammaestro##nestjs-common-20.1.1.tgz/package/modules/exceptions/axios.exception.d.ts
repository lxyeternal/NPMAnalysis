import { AxiosError } from 'axios';
import { LoggedException } from './logged.exception';
export declare class AxiosException extends LoggedException {
    constructor(error: AxiosError, customMessage?: string);
}
