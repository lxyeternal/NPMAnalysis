"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BadRequestException = void 0;
const common_1 = require("@nestjs/common");
const passive_exception_1 = require("./passive.exception");
class BadRequestException extends passive_exception_1.PassiveException {
    constructor(message, options) {
        super('BadRequestException', message || 'Bad Request', common_1.HttpStatus.BAD_REQUEST);
        if (options === null || options === void 0 ? void 0 : options.appCode) {
            this.appCode = options.appCode;
        }
    }
}
exports.BadRequestException = BadRequestException;
