import { LoggedException } from './logged.exception';
import { SequelizeError } from '../interfaces';
export declare class SqlException extends LoggedException {
    constructor(error: SequelizeError, customMessage?: string);
}
