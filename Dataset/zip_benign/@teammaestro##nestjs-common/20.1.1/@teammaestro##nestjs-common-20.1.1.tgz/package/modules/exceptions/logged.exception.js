"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggedException = void 0;
const base_exception_1 = require("./base.exception");
class LoggedException extends base_exception_1.BaseException {
    constructor(name, response, status, error) {
        super(name, response, status, error);
        this.tags = {
            critical: 'true'
        };
    }
}
exports.LoggedException = LoggedException;
