"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnauthorizedException = void 0;
const common_1 = require("@nestjs/common");
const passive_exception_1 = require("./passive.exception");
class UnauthorizedException extends passive_exception_1.PassiveException {
    constructor(message, options) {
        super('UnauthorizedException', message || 'Unauthorized', common_1.HttpStatus.UNAUTHORIZED);
        if (options === null || options === void 0 ? void 0 : options.appCode) {
            this.appCode = options.appCode;
        }
    }
}
exports.UnauthorizedException = UnauthorizedException;
