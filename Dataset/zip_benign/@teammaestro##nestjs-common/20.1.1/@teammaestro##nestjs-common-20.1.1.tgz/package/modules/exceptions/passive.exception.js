"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PassiveException = void 0;
const base_exception_1 = require("./base.exception");
class PassiveException extends base_exception_1.BaseException {
    constructor(name, response, status, error) {
        super(name, response, status, error);
    }
}
exports.PassiveException = PassiveException;
