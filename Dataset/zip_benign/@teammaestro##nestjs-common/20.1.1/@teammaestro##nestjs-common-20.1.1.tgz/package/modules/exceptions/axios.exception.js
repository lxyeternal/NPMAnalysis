"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AxiosException = void 0;
const common_1 = require("@nestjs/common");
const logged_exception_1 = require("./logged.exception");
const classes_1 = require("../classes");
class AxiosException extends logged_exception_1.LoggedException {
    constructor(error, customMessage) {
        super('AxiosException', customMessage || 'Internal server error with request', common_1.HttpStatus.INTERNAL_SERVER_ERROR, new classes_1.AxiosExceptionError(error));
    }
}
exports.AxiosException = AxiosException;
