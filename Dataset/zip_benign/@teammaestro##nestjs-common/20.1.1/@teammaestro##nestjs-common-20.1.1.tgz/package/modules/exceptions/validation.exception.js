"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidationException = void 0;
const common_1 = require("@nestjs/common");
const logged_exception_1 = require("./logged.exception");
class ValidationException extends logged_exception_1.LoggedException {
    constructor(message, options) {
        super('ValidationException', message || 'Request format is invalid', common_1.HttpStatus.BAD_REQUEST);
        this.tags.critical = !!(options === null || options === void 0 ? void 0 : options.critical) ? 'true' : 'false';
        if (options === null || options === void 0 ? void 0 : options.appCode) {
            this.appCode = options.appCode;
        }
    }
}
exports.ValidationException = ValidationException;
