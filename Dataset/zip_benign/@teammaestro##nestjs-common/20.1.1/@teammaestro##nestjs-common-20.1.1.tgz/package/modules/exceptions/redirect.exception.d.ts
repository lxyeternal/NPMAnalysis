import { BaseException } from './base.exception';
export declare class RedirectException extends BaseException {
    redirectPath: string;
    constructor(redirectPath: string);
}
