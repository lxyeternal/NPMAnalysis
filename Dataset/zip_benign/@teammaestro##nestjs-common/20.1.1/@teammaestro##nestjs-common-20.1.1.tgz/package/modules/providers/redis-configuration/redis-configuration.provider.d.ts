import { FactoryProvider } from '@nestjs/common';
import { ClientOpts } from 'redis';
export declare const RedisConfigurationToken = "teamhive:nestjs:RedisConfigurationToken";
export declare type RedisConfigurationOptions = ClientOpts & {
    expiration?: number;
    keyPrefix?: string;
};
export declare function getRedisConfigurationProvider(optionsFactory?: () => RedisConfigurationOptions): FactoryProvider;
