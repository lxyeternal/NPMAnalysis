/// <reference types="node" />
import * as EventEmitter from 'events';
import * as redis from 'redis';
import { RedisConfigurationOptions } from '../redis-configuration/redis-configuration.provider';
export declare class RedisClient extends EventEmitter {
    private readonly redisConfiguration;
    connection: redis.RedisClient;
    private pingRate;
    private maxTotalRetryTime;
    constructor(redisConfiguration: RedisConfigurationOptions);
    setupClient(): redis.RedisClient;
    private emitClientEvents;
    private pingRedis;
}
export declare const RedisProvider: {
    provide: string;
    useClass: typeof RedisClient;
};
