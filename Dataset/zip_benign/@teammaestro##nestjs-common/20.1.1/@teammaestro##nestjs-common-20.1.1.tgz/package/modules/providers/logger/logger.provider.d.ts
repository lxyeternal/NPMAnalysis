import * as log from 'log4js';
export declare const LoggerProvider: {
    provide: string;
    useFactory: () => log.Logger;
};
