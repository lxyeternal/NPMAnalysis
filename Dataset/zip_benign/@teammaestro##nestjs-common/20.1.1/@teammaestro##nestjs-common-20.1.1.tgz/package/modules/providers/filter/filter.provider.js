"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilterProviders = void 0;
const core_1 = require("@nestjs/core");
const filters_1 = require("../../filters");
exports.FilterProviders = [
    {
        provide: core_1.APP_FILTER,
        useClass: filters_1.UncaughtExceptionFilter
    },
    {
        provide: core_1.APP_FILTER,
        useClass: filters_1.PassiveHttpExceptionFilter
    },
    {
        provide: core_1.APP_FILTER,
        useClass: filters_1.RedirectHttpExceptionFilter
    },
    {
        provide: core_1.APP_FILTER,
        useClass: filters_1.LoggedHttpExceptionFilter
    }
];
