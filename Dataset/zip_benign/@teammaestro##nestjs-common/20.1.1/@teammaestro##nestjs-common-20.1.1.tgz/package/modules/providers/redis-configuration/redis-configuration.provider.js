"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRedisConfigurationProvider = exports.RedisConfigurationToken = void 0;
exports.RedisConfigurationToken = 'teamhive:nestjs:RedisConfigurationToken';
function getRedisConfigurationProvider(optionsFactory = () => ({
    host: 'localhost'
})) {
    return {
        provide: exports.RedisConfigurationToken,
        useFactory: optionsFactory
    };
}
exports.getRedisConfigurationProvider = getRedisConfigurationProvider;
