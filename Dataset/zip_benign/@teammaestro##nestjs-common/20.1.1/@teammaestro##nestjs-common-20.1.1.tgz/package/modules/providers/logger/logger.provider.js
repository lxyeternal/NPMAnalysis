"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggerProvider = void 0;
const log = require("log4js");
const application_tokens_const_1 = require("../../application-tokens.const");
exports.LoggerProvider = {
    provide: application_tokens_const_1.ApplicationTokens.LoggerToken,
    useFactory: () => {
        const logger = log.getLogger();
        return logger;
    },
};
