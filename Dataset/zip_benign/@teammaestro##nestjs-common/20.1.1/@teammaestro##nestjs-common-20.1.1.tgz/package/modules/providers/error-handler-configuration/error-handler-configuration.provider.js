"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getErrorHandlerConfigurationProvider = exports.ErrorHandlerConfigurationToken = void 0;
exports.ErrorHandlerConfigurationToken = 'teamhive:nestjs:ErrorHandlerConfigurationToken';
function getErrorHandlerConfigurationProvider(optionsFactory = () => ({
    useSentry: true
})) {
    return {
        provide: exports.ErrorHandlerConfigurationToken,
        useFactory: optionsFactory
    };
}
exports.getErrorHandlerConfigurationProvider = getErrorHandlerConfigurationProvider;
