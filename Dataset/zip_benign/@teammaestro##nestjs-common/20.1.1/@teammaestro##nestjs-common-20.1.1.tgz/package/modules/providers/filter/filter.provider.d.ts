import { ClassProvider } from '@nestjs/common/interfaces';
export declare const FilterProviders: ClassProvider[];
