"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisProvider = exports.RedisClient = void 0;
const common_1 = require("@nestjs/common");
const EventEmitter = require("events");
const redis = require("redis");
const application_tokens_const_1 = require("../../application-tokens.const");
const redis_configuration_provider_1 = require("../redis-configuration/redis-configuration.provider");
let RedisClient = class RedisClient extends EventEmitter {
    constructor(redisConfiguration) {
        super();
        this.redisConfiguration = redisConfiguration;
        this.pingRate = 60000;
        this.maxTotalRetryTime = 10000;
        this.connection = this.setupClient();
        this.pingRedis();
    }
    setupClient() {
        const self = this;
        const client = redis.createClient(Object.assign({ retry_strategy(options) {
                if (options.totalRetryTime > self.maxTotalRetryTime) {
                    self.emit('error', new Error('Retry time exhausted, creating new client connection...'));
                    client.quit();
                    self.connection = self.setupClient();
                    return;
                }
                return Math.min(options.attempt * 100, 3000);
            }, enable_offline_queue: false }, this.redisConfiguration));
        this.emitClientEvents(client);
        return client;
    }
    emitClientEvents(client) {
        client.on('error', error => this.emit('error', error));
        client.on('ready', () => this.emit('ready'));
        client.on('reconnecting', () => this.emit('reconnecting'));
        client.on('end', () => this.emit('end'));
    }
    pingRedis() {
        setInterval(() => {
            if (this.connection && this.connection.ping) {
                this.connection.ping();
            }
        }, this.pingRate);
    }
};
RedisClient = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(redis_configuration_provider_1.RedisConfigurationToken)),
    __metadata("design:paramtypes", [Object])
], RedisClient);
exports.RedisClient = RedisClient;
exports.RedisProvider = {
    provide: application_tokens_const_1.ApplicationTokens.RedisClientToken,
    useClass: RedisClient
};
