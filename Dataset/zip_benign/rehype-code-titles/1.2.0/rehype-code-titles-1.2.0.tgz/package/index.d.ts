import type * as H from 'hast';
declare type Options = {
    customClassName?: string;
    titleSeparator?: string;
};
declare function rehypeCodeTitles({ customClassName, titleSeparator }?: Options): (tree: H.Root) => void;
export default rehypeCodeTitles;
