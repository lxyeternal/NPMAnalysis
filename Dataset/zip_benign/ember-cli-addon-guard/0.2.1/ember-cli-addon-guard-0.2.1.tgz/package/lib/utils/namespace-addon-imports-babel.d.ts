export default function NamespaceAddonImports(): {
    name: string;
    visitor: {
        ImportDeclaration(path: any, state: any): void;
    };
};
