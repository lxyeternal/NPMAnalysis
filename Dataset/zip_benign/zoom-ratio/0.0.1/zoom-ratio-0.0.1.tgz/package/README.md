## introduction

获取页面缩放比例，获取是否高分屏

## question

- Q: 为什么不能用 devicePixelRatio 来获取是否高分屏
- A: 高分屏为 2，普通屏为 1，但如果页面缩放 (cmd +/-) 后，这个值会变

---

- Q: 为什么不能用 devicePixelRatio 直接获取缩放比例
- A: 两者都能缩放到 0.5，但 0.5 对高分屏代表缩到 1/4，而对普通屏代表缩到 1/2

## usage

```js
import {isRetina, getRatio, addZoomListener, removeZoomListener} from 'zoom-ratio'

isRetina() // 返回是否高分屏

getRatio() // 返回页面缩放比例，如 1.5 0.75

addZoomListener((ratio) => {
    // 绑定监听，当页面缩放比例变化时候，触发
})
```