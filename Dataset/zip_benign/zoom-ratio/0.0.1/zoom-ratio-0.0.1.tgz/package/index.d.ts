export function isRetina(): boolean;
export function getRatio(): number;
export function addZoomListener(fn: (ratio: number) => any): void
export function removeZoomListener(fn: Function): void
