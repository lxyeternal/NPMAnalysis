 // 正常缩放比例，12px 可渲染的最小尺寸
 function getSize(fontsize) {
    var div = document.createElement("div");
    var span = document.createElement("span");
    div.appendChild(span);
    span.innerHTML = "A";
    span.setAttribute(
      "style",
      "font-size: " +
        fontsize +
        "px; font-family: Arial; top: -60000px; left: -60000px; position: fixed; z-index: -60000; opacity: 0;"
    );
    document.documentElement.appendChild(div);
    var width = span.getBoundingClientRect().width;
    setTimeout(function () {
      document.documentElement.removeChild(div);
    }, 10);
    return width;
  }

  function isSame(a, b) {
    return Math.abs(a - b) < 0.001;
  }

  // 判断是否是 retina 屏幕
  function isRetina() {
    if (!window.devicePixelRatio) return false;
    var curRatio = window.devicePixelRatio;
    if (curRatio < 1) {
      // 高分屏低分屏幕都有可能
      // 低分屏支持的最大尺寸：
      var thres1 = Math.floor(12 / curRatio) - 1;
      // 高分屏支持的最大尺寸：
      var thres2 = Math.floor(24 / curRatio) - 1;
      // 选择一个介于之间的判断一下
      return isSame(getSize(thres1), getSize(thres2));
    } else if (curRatio < 2) {
      return isSame(getSize(12), getSize(13));
    } else if (curRatio < 9) {
      // 低分屏放大的最小尺寸
      var thres1 = Math.ceil(12 / curRatio) + 1;
      // 高分屏放大的最小尺寸
      var thres2 = Math.ceil(24 / curRatio) + 1;
      var refer = Math.floor(12 / curRatio) - 1;
      if (refer < 1) refer = 1;
      return isSame(getSize(thres1), getSize(refer));
    } else {
      return true;
    }
  }

  // 获取缩放比例
  function getRatio() {
    if (!window.devicePixelRatio) return 1;
    return +(window.devicePixelRatio / (isRetina() ? 2 : 1)).toFixed(2);
  }

  var isResizeBound = false;
  var evList = [];
  var lastRatio = 1;
  var cb = function () {
    var currentRatio = getRatio()
    var isNotChange = isSame(currentRatio, lastRatio)
    lastRatio = currentRatio
    if (isNotChange) return;
    for (var i = 0; i < evList.length; i++) {
      if (typeof evList[i] === "function") evList[i](currentRatio);
    }
  };
  function addZoomListener(callback) {
    lastRatio = getRatio();
    if (!isResizeBound) {
      window.addEventListener("resize", cb);
      isResizeBound = true;
    }
    if (evList.indexOf(callback) === -1) evList.push(callback);
  }

  function removeZoomListener(callback) {
    var index = evList.indexOf(callback);
    if (index === -1) return;
    evList.splice(index, 1);
  }

  export {isRetina, getRatio, addZoomListener, removeZoomListener}