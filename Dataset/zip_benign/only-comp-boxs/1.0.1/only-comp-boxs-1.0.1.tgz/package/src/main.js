/*
 * @Descripttion: ''
 * @Author: lilong(lilong@hztianque.com)
 * @Date: 2020-08-14 14:44:10
 * @LastEditTime: 2020-11-09 09:02:36
 */
import Vue from 'vue'
import './plugins/axios'
import App from './App.vue'
import router from './router'
import store from './store'
import './plugins/iview.js'
import './assets/css/reset.css'
Vue.config.productionTip = false

import llgtfooComponentsBoxTest from "../plugins/index.js";
Vue.use(llgtfooComponentsBoxTest);

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
