/*
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-09 21:22:56
 * @LastEditTime: 2020-11-09 09:00:42
 * @LastEditors: Please set LastEditors
 * @Description:
 * @FilePath: \llgtfoo-conponents-boxs\plugins\index.js
 */
//组件
import DateTime from "./components/dateTime/date-time.vue";
import selectDate from "./components/selectDate/index.vue";
import numberScroll from "./components/number-scroll/index.vue";
import tabPage from "./components/tabPage/index.vue";
import listScroll from "./components/list-scroll/index.vue";
import CMap from "../node_modules/@ektx/cmap/src/index.js";

//指令
// import * as directives from "./directives/*/index.js";
import autoScale from './directives/auto-scale/index.js'
import waterMarker from './directives/water-marker/index.js'
import drag from './directives/drag/index.js'


//过滤器
import numberFormat from './Filters/number-format/index.js'

//所有组件列表
const components = [DateTime, selectDate, numberScroll, tabPage, listScroll];
//所以指令
const directives = [autoScale, waterMarker, drag];
//过滤器
const filters = [numberFormat]

//定义install方法，Vue作为参数
const install = Vue => {


  //判断是否安装，安装过就不用继续执行
  if (install.installed) return;
  install.installed = true;
  //遍历注册所有组件
  components.map(component => Vue.component(component.name, component));

  //遍历注册所有指令
  directives.map(directives => Vue.use(directives));

  //遍历过滤器
  filters.map(filters => Vue.use(filters));
  //注册全局CMap方法
  Vue.prototype.$CMap = CMap
};

//检测到Vue再执行
if (typeof window !== "undefined" && window.Vue) {
  install(window.Vue);
}
export default {
  install,
  //所有组件，必须具有install方法才能使用Vue.use()
  ...components,
  ...directives,
  ...filters
};
