/*
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-15 20:25:01
 * @LastEditTime: 2020-09-09 18:12:36
 * @LastEditors: Please set LastEditors
 * @Description:
 * @FilePath: \llgtfoo-conponents-boxs\plugins\Filters\number-format\index.js
 */
export default (Vue) => {
    Vue.filter('numberFormat', function (value, obj) {
        if (Number(value) !== 0) {
            const intPart = Number(value).toFixed()
            let regExp = new RegExp((`(\\d)(?=(?:\\d{${obj.step}})+$)`), 'g')
            const intPartFormat = intPart.toString().replace(regExp, `$1${obj.separator}`)
            // const intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, `$1${obj.separator}`)
            return intPartFormat
        }
        else {
            return value
        }
    })

}