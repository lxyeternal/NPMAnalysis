<!--
 * @Author: llgtfoo@163.com
 * @Date: 2020-08-16 15:13:37
 * @LastEditTime: 2020-10-14 19:16:20
 * @LastEditors: Please set LastEditors
 * @Description: 
 * @FilePath: \llgtfoo-conponents-boxs\plugins\components\number-scroll\index.vue
 -->

 <template>
  <count-to
    :start-val="0"
    :end-val="maxValue"
    :duration="duration"
    :separator="separator"
    :decimals="toFixed"
    :prefix="prefix"
    :suffix="suffix"
    :useEasing="true"
    :autoplay="true"
  ></count-to>
</template>
 
 <script>
import countTo from "vue-count-to";
export default {
  name: "numberScroll",
  data() {
    return {};
  },
  components: { countTo },
  props: {
    maxValue: {
      type: [String,Number],
      default: 2020
    },
     duration: {
      type: [String,Number],
      default: ''
    },
     separator: {
      type: [String,Number],
      default: ''
    },
     toFixed: {
      type: [String,Number],
      default: 0
    },
     prefix: {
      type: [String,Number],
      default: ''
    },
    suffix: {
      type: [String,Number],
      default: ''
    },
  },
};
</script>
 
 <style>
</style>
