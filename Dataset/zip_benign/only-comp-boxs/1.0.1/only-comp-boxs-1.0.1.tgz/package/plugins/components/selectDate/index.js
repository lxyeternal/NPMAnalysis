/*
 * @Descripttion: ''
 * @Author: lilong(lilong@hztianque.com)
 * @Date: 2020-08-11 08:56:57
 * @LastEditTime: 2020-08-11 10:11:49
 */
import selectDate from "./index.vue";

selectDate.install = Vue => Vue.component(selectDate.name, selectDate); //注册组件

export default selectDate;
