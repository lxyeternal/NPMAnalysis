import { Coord } from './vector';
interface StrokeWidth {
    breakpoint: number;
    strokeWidth: number;
}
export interface Curve {
    points: Coord[];
    bezierPoints: Coord[];
    strokeWidths?: StrokeWidth[];
}
/**
 * Calculates the outside curves that define the width of the inkbrush
 * @param middleCurve - the middle curve to calculate the edge curves for
 * @returns the outside curves
 */
export declare const calculateEdgeCurves: (middleCurve: Curve, bend: number) => [Curve, Curve];
export {};
