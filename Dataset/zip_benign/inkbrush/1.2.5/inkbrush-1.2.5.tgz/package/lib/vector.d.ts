export interface Coord {
    x: number;
    y: number;
}
/**
 * @param p1 - the first point
 * @param p2 - the second point
 * @returns the sum of the two points
 */
export declare const add: (p1: Coord, p2: Coord) => Coord;
/**
 * @param p1 - the first point
 * @param p2 - the second point
 * @returns the difference between the two points
 */
export declare const subtract: (p1: Coord, p2: Coord) => Coord;
/**
 * @param p - the point to scale
 * @param scalar - the scalar to scale the point by
 * @returns the scaled point
 */
export declare const scale: (p: Coord, scalar: number) => Coord;
/**
 * @param p - the point to reflect
 * @returns the reflected point around the 45 degree line
 */
export declare const reflect: (p: Coord) => Coord;
/**
 * @param vector - the vector to normalize
 * @returns the normalized vector
 */
export declare const normalize: (vector: Coord) => Coord;
/**
 * @param p1 - the first point
 * @param p2 - the second point
 * @returns the distance between the two points
 */
export declare const distance: (p1: Coord, p2: Coord) => number;
/**
 * @param vector - the vector to calculate the magnitude of
 * @returns the magnitude of the vector
 */
export declare const magnitude: (vector: Coord) => number;
/**
 * @param A - the first point of the first line
 * @param B - the second point of the first line
 * @param C - the first point of the second line
 * @param D - the second point of the second line
 * @returns the intersection point of the two lines, or undefined if the lines are parallel
 */
export declare const locateIntersection: (A: Coord, B: Coord, C: Coord, D: Coord) => Coord | undefined;
/**
 * @param A - The first point
 * @param B - The second point
 * @returns The midpoint of the two points
 */
export declare const locateMidpoint: (A: Coord, B: Coord) => Coord;
