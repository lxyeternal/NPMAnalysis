import { Curve } from './width';
/**
 * Encodes the given points into an SVG path
 * @param edge1 - the first edge curve
 * @param edge2 - the second edge curve
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string
 */
export declare const toPath: (edge1: Curve, edge2: Curve, precision: number) => string;
