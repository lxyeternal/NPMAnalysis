import { Coord } from './vector';
/**
 * @param destination - the coordinate to move to
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a move
 */
export declare const move: (destination: Coord, precision: number) => string;
/**
 * @param destination - the coordinate to draw a line to
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a line
 */
export declare const line: (destination: Coord, precision: number) => string;
/**
 * @param destination - the coordinate to draw a vertical line to
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a vertical line
 */
export declare const verticalLine: (destination: number, precision: number) => string;
/**
 * @param destination - the coordinate to draw a horizontal line to
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a horizontal line
 */
export declare const horizontalLine: (destination: number, precision: number) => string;
/**
 * @param control1 - the first control point
 * @param control2 - the second control point
 * @param destination - the destination point
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a curve
 */
export declare const curve: (control1: Coord, control2: Coord, destination: Coord, precision: number) => string;
/**
 * @param control - the control point
 * @param destination - the destination point
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a shorthand curve
 */
export declare const shorthandCurve: (control: Coord, destination: Coord, precision: number) => string;
/**
 * @param control - the control point
 * @param destination - the destination point
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a bezier curve
 */
export declare const bezier: (control: Coord, destination: Coord, precision: number) => string;
/**
 * @param destination - the destination point
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a shorthand bezier
 */
export declare const shorthandBezier: (destination: Coord, precision: number) => string;
/**
 * @param rx - the x radius
 * @param ry - the y radius
 * @param xAxisRotation - the x axis rotation
 * @param largeArcFlag - the large arc flag
 * @param sweepFlag - the sweep flag
 * @param destination - the destination point
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for an arc
 */
export declare const arc: (rx: number, ry: number, xAxisRotation: number, largeArcFlag: number, sweepFlag: number, destination: Coord, precision: number) => string;
/**
 * @param destination - the destination point
 * @param precision - the precision of the numbers in the SVG path
 * @returns the SVG path string for a half circle
 */
export declare const halfCircle: (from: Coord, destination: Coord, precision: number) => string;
/**
 * @returns the SVG path string for a direct line to the start
 */
export declare const close: () => string;
