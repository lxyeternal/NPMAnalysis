import { Coord } from './vector';
import { Curve } from './width';
/**
 * Calculates the bezier points for the given points and bend
 * @param points - the points to calculate the bezier points for
 * @param bend - the amount of bend in the curve
 * @returns the bezier points (n - 1)
 */
export declare const calculateBezierPoints: (points: Coord[], bend: number) => Coord[];
/**
 * Using the default bezier point algorithm does not work perfectly for the inkbrush.
 * So we need to alter the bezier points to make the inkbrush look better.
 * @param middle - the middle curve
 * @param edge - the edge curve
 * @returns the new bezier points
 */
export declare const alterBezierPoints: (middle: Curve, edge: Curve) => Coord[];
