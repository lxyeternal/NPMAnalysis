var str = "console.log('tomaszek');";

console.log('test');