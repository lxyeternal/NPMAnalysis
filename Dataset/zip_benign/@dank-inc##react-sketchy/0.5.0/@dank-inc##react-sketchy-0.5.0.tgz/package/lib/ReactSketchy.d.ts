import { MutableRefObject } from "react";
import Sketchy, { SketchConfig } from "@dank-inc/sketchy";
declare type Props = Partial<SketchConfig> & {
    sketch?: Sketchy.Sketch;
    className?: string;
    elRef?: MutableRefObject<HTMLElement | null>;
};
export declare const ReactSketchy: ({ sketch, dimensions, className, animate, timeOffset, elRef, }: Props) => JSX.Element | null;
export {};
