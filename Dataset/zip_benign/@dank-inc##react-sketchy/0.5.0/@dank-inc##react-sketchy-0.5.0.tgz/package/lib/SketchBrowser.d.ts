import { Sketch } from "@dank-inc/sketchy";
import React from "react";
declare type Props = {
    sketches: Sketch[];
    children: React.ReactElement;
    controls?: boolean;
    dimensions?: [number, number];
    animate?: boolean;
    wrap?: boolean;
};
export declare const SketchBrowser: ({ controls, sketches, children, dimensions, animate, wrap, }: Props) => JSX.Element;
export {};
