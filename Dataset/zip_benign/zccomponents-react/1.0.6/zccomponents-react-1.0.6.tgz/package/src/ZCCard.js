import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Icon from "@material-ui/core/Icon";


import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import Danger from "components/Typography/Danger.js";
import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";


const useStyles = makeStyles(styles);

//https://material.io/resources/icons/?search=phone&style=baseline
//headerIconColor = ["info", "success", "warning", "danger"]
//PROPS
//{headerIconColor, headerIconName, title, text, footerIconName, footerText, footerOnClickHandler}


const ZCCard = (props) => {
    const classes = useStyles();
    const {headerIconColor, headerIconName, title, text, footerIconName, footerText, footerOnClickHandler, bodyComponent, 'data-testid':testID} = props


    return (
        <Card data-testid={testID}>
        <CardHeader stats icon>
          <CardIcon color={headerIconColor?headerIconColor:"warning"}>
            <Icon>{headerIconName?headerIconName:"content_copy"}</Icon>
          </CardIcon>
          <p className={classes.cardCategory}>{title}</p>
          <h1 className={classes.cardTitle}>
            {text}
          </h1>
        </CardHeader>
        {(bodyComponent) &&
            <CardBody>{bodyComponent}</CardBody>
        }        
        <CardFooter stats>
            {(footerText) &&
                <div className={classes.stats}>
                <Danger>
                    <Icon>{footerIconName?footerIconName:"info"}</Icon>    
                </Danger>
                <a href="#pablo" onClick={footerOnClickHandler}>
                    {footerText}
                </a>
                </div>
            }
        </CardFooter>   
      </Card>
    )
}

export default ZCCard