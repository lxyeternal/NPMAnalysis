import React from 'react'

export default function ZCDummy() {
    return (
        <div>
            DUMMY
        </div>
    )
}
