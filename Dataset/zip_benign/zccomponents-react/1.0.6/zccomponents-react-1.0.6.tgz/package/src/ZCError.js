import React from 'react'

import { makeStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    backgroundColor: 'red'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular
  },
}));



export default function ZCError(props) {
    const classes = useStyles();

    if (props.error){
        const error = props.error
        const msg = (error.MESSAGE?error.MESSAGE:JSON.stringify(error))
        const detailMsg = JSON.stringify(error);
        return (
            <ExpansionPanel data-testid={props.data-testid} className={classes.root}>
            <ExpansionPanelSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1a-content"
              id="panel1a-header"
            >
              <Typography className={classes.heading}>ERROR:{msg}</Typography>
            </ExpansionPanelSummary>
            <ExpansionPanelDetails>
              <Typography>
                  {detailMsg}
              </Typography>
            </ExpansionPanelDetails>
          </ExpansionPanel>            
        )    
    }
    else return("")
}
