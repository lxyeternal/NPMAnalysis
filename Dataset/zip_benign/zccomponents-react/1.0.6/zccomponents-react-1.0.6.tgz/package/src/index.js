//
// Follow this post
//https://medium.com/recraftrelic/building-a-react-component-as-a-npm-module-18308d4ccde9

import ZCDummy from './ZCDummy'
import ZCCard from './ZCCard'
import ZCChart from './ZCChart'
import ZCError from './ZCError'
import ZCTable from './ZCTable'
import ZCRecordTable from './ZCRecordTable'

import ZCPdfTable from './ZCPdfTable'

export {
    ZCDummy,
    ZCError,
    ZCCard,
    ZCChart,
    ZCTable,
    ZCRecordTable,
    ZCPdfTable
}