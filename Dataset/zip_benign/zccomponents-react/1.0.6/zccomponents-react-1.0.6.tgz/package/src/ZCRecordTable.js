import React, {useState, useEffect} from 'react'

import useGlobalState from 'globalStateContext.js';
import {IformRequest} from 'iformauth-react'
import ZCTable from './ZCTable.js'


const dataToBody = (data, skipFields=[]) => {
    skipFields.push('id')
    const fields = Object.keys(data).filter(key => !skipFields.includes(key)).map((key) => {
      return {
        'element_name': key,
        'value':data[key]
      }
    })
    const body = {
        'fields': fields
    }
  
    return body
}

const iform_fields = (columns) => {
    let str = ""
    columns.forEach(c => str += (c.filter?","+c.field+"("+c.filter+")":","+c.field))
    return 'id'+str;
}





const ZCRecordTable = (props) => {
    const [{ profile_id }] = useGlobalState();
    const {page_id, editable, columns, isEditable,  ...rest} = props
    const [records, setRecords] = useState([])
    const [error, setError] = useState(null)

    const fetchRecords = () => {
        if (profile_id){
            const fields = iform_fields(columns)
            const apiPath = `/v60/profiles/${profile_id}/pages/${page_id}/records?fields=${fields}`
            console.log(apiPath)
            IformRequest.get(apiPath).then (response => {
                console.log(response)
                setRecords(response.data)
            }).catch(error => {
                console.log(error)
                setError(error)
            })
        }
    }
    

    useEffect(() => {
        fetchRecords()
    },[profile_id])


    //////////////////////////////////////////////
    //   Update a Single Row                //
    //////////////////////////////////////////////
    const updateRecord = (newData, oldData) =>{
        return new Promise( (resolve, reject) => {

            const apiPath = `/v60/profiles/${profile_id}/pages/${page_id}/records/${newData.id}`
            const skipFields = ['image']
            const body = dataToBody(newData, skipFields)
            IformRequest.put(apiPath, body).then (response => {
                console.log(response)
                //Update Local
                //Need to create a new array. Otherwise useState will not update underlaying state
                let data = Array.from(records)
                const index = data.indexOf(oldData);
                data[index] = newData;
                setRecords(data)
                resolve()      
            }).catch(error => {
                console.log(error)
                setError(error)
                resolve()
            })    
        })
    }



    return (
        <ZCTable 
            {...rest}
            error={error}
            editable={isEditable && {
                onRowUpdate: (newData, oldData) => updateRecord(newData, oldData),
                ...editable
              }}
            columns = {columns}
            data = {records}
        />
    )
}

export default ZCRecordTable