import React from 'react'
import MaterialTable from 'material-table'
import Container from '@material-ui/core/Container'
import {ZCError} from 'zccomponents-react';


import { primaryColor } from 'assets/jss/material-dashboard-pro-react';

const ZCTable = (props) => {

    const {options, error, 'data-testid':testID, ...rest} = props

    return (
        <Container data-testid={testID} maxWidth={false}>
        <ZCError error={error}/>    
        <MaterialTable 
            {...rest}
            options={
                {
                exportButton: true,
                actionsColumnIndex: -1,
                headerStyle: {
                    backgroundColor: primaryColor[0],
                    fontSize:16,
                    color: '#FFF'
                },
                rowStyle: {
                    backgroundColor: '#FFF'
                },
                pageSize:20,
                ...options
            }}
            />
        </Container>    
    )
}

export default ZCTable