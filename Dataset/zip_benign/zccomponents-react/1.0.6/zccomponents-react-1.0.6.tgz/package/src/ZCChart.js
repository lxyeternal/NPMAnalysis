import React from "react";

import { makeStyles } from "@material-ui/core/styles";
import Icon from "@material-ui/core/Icon";


import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import styles from "assets/jss/material-dashboard-pro-react/views/chartsStyle.js";

import ChartistGraph from "react-chartist";
import GaugeChart from 'react-gauge-chart'


const useStyles = makeStyles(styles);

//https://material.io/resources/icons/?search=phone&style=baseline
//headerIconColor = ["info", "success", "warning", "danger"]
//PROPS
//{headerIconColor, headerIconName, title, text, footerIconName, footerText, footerOnClickHandler}



const ZCChart = (props) => {
    const classes = useStyles();
    const {headerIconColor, 
            headerIconName, 
            title, 
            data,
            type,
            options, 
            listener,
            footerIconName, 
            footerText, 
            footerOnClickHandler, 
            bodyComponent,
            gaugeProps,
            'data-testid':testID
            } = props



    var series = [
        classes.info,
        classes.danger,
        classes.warning,
        classes.parimary,
        classes.success,
        classes.gray,
        classes.rose
    ]


    let i = 0

    return (
        <Card data-testid={testID}>
        <CardHeader icon>
          <CardIcon color={headerIconColor?headerIconColor:"warning"}>
            <Icon>{headerIconName?headerIconName:"content_copy"}</Icon>
          </CardIcon>
          <h4 className={classes.cardIconTitle}>{title}</h4>
        </CardHeader>
        <CardBody>
            {
                bodyComponent ||
                ((data) && (type=="Gauge") &&
                     <GaugeChart 
                        nrOfLevels={20} 
                        percent={data} 
                        textColor={styles.info.color}
                        {...gaugeProps}
                    />
                    ) ||
                ((data) &&
                    <ChartistGraph
                        data={data}
                        type={type}
                        options={options}
                        listener={listener}
                    />
                )
            }   
        </CardBody>
        { (type=="Pie") &&
        <CardFooter stats className={classes.cardFooter}>
            <h6 className={classes.legendTitle}>Legend</h6>
            <div className={classes.legendContent}>
            {data && data.label.map((label) => 
                <div key={label} className={classes.legendItem}><i className={"fas fa-circle " + series[i++]} /> {label}</div>
                
            )}
            </div>
        </CardFooter>
        }
      </Card>
    )
}

export default ZCChart