import React from 'react'
import {Table, TableHeader, TableCell, TableBody, DataTableCell} from '@david.kucsai/react-pdf-table'

export default function ZCPdfTable(props) {
    const {columns, data} = props

    return (
        <Table data-testid={props.data-testid} data={data}>
        <TableHeader>
          {columns.map((c) =>
            <TableCell weighting={c.weighting}>{c.title}</TableCell>
          )}
      </TableHeader>
        <TableBody>
          {columns.map((c) =>
            <DataTableCell 
              weighting={c.weighting} 
              getContent={
                (r) => (c.type=='image'?<Image src='{r[c.field]}'/>:r[c.field])
              }
            />
          )}
        </TableBody>
        </Table>
      )
}
