import path from 'path';
import { configureToMatchRulesSnapshot } from '@morgs32/firebase-rules-snapshot';

jest.mock('@stackshirts/firebase', () => {
  return {
    firebaseDb: {
      doc: jest.fn(),
      collection: jest.fn()
    },
    makeTimestamp: () => {
      return {
        nanoseconds: 1,
        seconds: 1,
      };
    }
  };
});

const toMatchRulesSnapshot = configureToMatchRulesSnapshot({
  customRulesDir: path.resolve(__dirname, '../../../firestore.rules'),
  before: ({ firestore }) => {
    firebaseDb.doc.mockImplementation((...args) => firestore.doc(...args));
    firebaseDb.collection.mockImplementation((...args) => firestore.collection(...args));
    /* ^^^ The reason we do jest.mock('@stackshirts/firebase') above ^^^ */
  },
});

expect.extend({
  toMatchRulesSnapshot,
});
