const cheerio = require('cheerio')
const JsDiff = require('diff')
const {
  rulesCSS,
  bsTooltipCSS,
  scripts,
  scriptDiffTooltips,
  scriptAutoTooltip,
} = require('./helpers.js')

module.exports = function diffRulesCoverage({ receivedHtml, baselineHtml, isSeries = false }) {


  const received$ = cheerio.load(receivedHtml)
  const baseline$ = cheerio.load(baselineHtml)

  const sameRules = received$('body').innerText === baseline$('body').innerText;

  /**
   * If the rules are the same (body.innerText) then
   * when you trigger tooltip on one, trigger the other.
   */

  const diffHTML = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Diff Report</title>
    <link
            rel="stylesheet"
            href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap-grid.min.css"
    >
    <style>
        html {
            height: 100%;
            width: 100%;
        }
        body {
            margin-top: 0;
            margin-bottom: 0;
        }
        .col-6 {
            overflow: scroll;
            padding-top: 15px;
            padding-bottom: 15px;
        }
        .col-6:first-child {
            border-right: 1px solid #aaa;
            padding-left: 30px;
        }
        pre {
            margin: 0;
        }  
        ${rulesCSS}
        ${bsTooltipCSS}
    </style>
    
    
    ${scripts}
    
    ${sameRules ? scriptDiffTooltips : scriptAutoTooltip}
        
</head>
<body class="row">

    <div id="${isSeries ? 'before' : 'expected'}" class="col-6">
        ${baseline$('body').html()}
    </div>
    <div id="${isSeries ? 'after' : 'received'}" class="col-6">
        ${received$('body').html()}
    </div>
</body>
</html>
`


  return diffHTML;


}