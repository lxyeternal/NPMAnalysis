const rimraf = require('rimraf');
const path = require('path');
const mkdirp = require('mkdirp');
const fs = require('fs');
const makeDiffHTML = require('./makeDiffHTML');
const cheerio = require('cheerio')
const JsDiff = require('diff')

const isFailure = ({ pass, updateSnapshot }) => !pass && !updateSnapshot;

const shouldUpdate = ({ pass, updateSnapshot }) => !pass && updateSnapshot;

module.exports = function diffSnapshot(options) {
  const {
    receivedHtml,
    currentCountOfSnapshotsInTest,
    snapshotsDir,
    diffDir,
    seriesDir,
    snapshotIdentifier,
    previousSnapshotIdentifier,
    updateSnapshot = false,
  } = options;


  const baselineSnapshotPath = path.join(snapshotsDir, `${snapshotIdentifier}-snap.html`);

  const result = {
    pass: true,
    baselineSnapshotPath,
  };

  const diffWithPrevious = () => {
    if (previousSnapshotIdentifier) {
      mkdirp.sync(seriesDir);
      const previousSnapshotPath = path.join(snapshotsDir, `${previousSnapshotIdentifier}-snap.html`);
      const previousHtml = fs.readFileSync(previousSnapshotPath, 'utf8');

      const seriesSnapshotPath = path.join(seriesDir, `${previousSnapshotIdentifier}-${currentCountOfSnapshotsInTest + 1}-snap.html`);
      rimraf.sync(seriesSnapshotPath);

      const diffHtml = makeDiffHTML({ receivedHtml, baselineHtml: previousHtml, isSeries: true });
      fs.writeFileSync(seriesSnapshotPath, diffHtml);
    }
  }

  diffWithPrevious()

  if (!fs.existsSync(baselineSnapshotPath)) {
    /**
     * This is first time...
     * So just write the snapshot ex. '/__firebase_rules_snapshots__/testFile-testName-1-snap.html'
     */
    mkdirp.sync(snapshotsDir);
    fs.writeFileSync(baselineSnapshotPath, receivedHtml);
    Object.assign(result, {
      added: true,
    });

  }
  else {


    const baselineHtml = fs.readFileSync(baselineSnapshotPath, 'utf8');

    const pass = receivedHtml === baselineHtml;

    if (isFailure({ pass, updateSnapshot })) {
      /**
       * Now, if we have a diff...
       * Write the diff snapshot to ex.
       * '/__firebase_rules_snapshots__/__diff_output__/testFile-testName-1-diff.html'
       */

      const diffOutputPath = path.join(diffDir, `${snapshotIdentifier}-diff.html`);
      rimraf.sync(diffOutputPath);

      mkdirp.sync(diffDir);

      const diffHtml = makeDiffHTML({ receivedHtml, baselineHtml });
      fs.writeFileSync(diffOutputPath, diffHtml);

      Object.assign(result, {
        pass: false,
        diffOutputPath,
      });
    }


    if (shouldUpdate({ pass, updateSnapshot })) {
      mkdirp.sync(snapshotsDir);
      fs.writeFileSync(baselineSnapshotPath, receivedHtml);
      Object.assign(result, {
        updated: true,
      });

    }
  }

  return result;
};
