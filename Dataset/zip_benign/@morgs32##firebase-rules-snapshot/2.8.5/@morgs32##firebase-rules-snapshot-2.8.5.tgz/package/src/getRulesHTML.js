const { JSDOM } = require('jsdom');
const {
  rulesCSS,
  bsTooltipCSS,
  scripts,
  scriptAutoTooltip,
} = require('./helpers.js')

module.exports = function getRulesCoverage(url) {
  return JSDOM.fromURL(url, {
    runScripts: 'dangerously',
  })
    .then((dom) => {
      dom.window.onload();
      dom.window.eval(`

        Array.prototype.slice.call(document.getElementsByClassName('coverage-expr'))
          .map((span, i) => {
            if (span.title !== 'Expression never evaluated') {
              span.classList.add('coverage-expr__evaluated');
              var valueSpan = document.createElement('span');
              valueSpan.classList.add('coverage-expr__value');
              valueSpan.title = span.title;
              valueSpan.classList.add('value-of-coverage-expr-' + i)

              if (span.title.match(/(null|error|false)/i)) {
                span.classList.add('coverage-expr__falsy');
              }
              
              span.appendChild(valueSpan)
            }
          });
  
  
        document.getElementsByTagName('style')[0].innerHTML = \`
          ${rulesCSS}
          
          ${bsTooltipCSS}
          
        \`;
  
        document.getElementsByTagName('script')[0].remove();

        document.head.insertAdjacentHTML('beforeend', \`${scripts}${scriptAutoTooltip}\`)

      `);


      return dom.serialize();

    });
};
