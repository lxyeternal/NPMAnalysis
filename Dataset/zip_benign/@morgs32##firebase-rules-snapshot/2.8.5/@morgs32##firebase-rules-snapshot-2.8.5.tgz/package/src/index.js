const fs = require('fs');
const path = require('path');
const Chalk = require('chalk').constructor;
const kebabCase = require('lodash/kebabCase');
const merge = require('lodash/merge');
const firebase = require('@firebase/testing');
const axios = require('axios');
const P = require('bluebird');
const _each = require('lodash/each');

const diffSnapshot = require('./checkSnapshot');
const getRulesHTML = require('./getRulesHTML');

const timesCalled = new Map();

const firestoreApps = {};

const SNAPSHOTS_DIR = '__firebase_rules_snapshots__';

/**
 * This is to aggregate # of failing snapshots (unmatched)
 * or added snapshots,
 * or updated snapshots,
 * TODO: And removed snapshots?
 */
function updateSnapshotState(originalSnapshotState, partialSnapshotState) {
  if (global.UNSTABLE_SKIP_REPORTING) {
    return originalSnapshotState;
  }
  return merge(originalSnapshotState, partialSnapshotState);
}

function checkResult({
  result,
  reflectedAssertion,
  snapshotState,
  retryTimes,
  snapshotIdentifier,
  chalk,
}) {

  if (!result.pass) {
    const currentRun = timesCalled.get(snapshotIdentifier);
    if (!retryTimes || (currentRun > retryTimes)) {
      updateSnapshotState(snapshotState, { unmatched: snapshotState.unmatched + 1 });
    }
  }

  if (reflectedAssertion.isRejected()) {
    console.error(reflectedAssertion.reason());

    if (!result.pass) {
      return {
        message: () => {
          return [
            'Your assertion was rejected.',
            'And, the rules output from the firebase emulator did not match the baseline snapshot.',
            `${chalk.bold.red('See diff for details:')} ${chalk.red(result.diffOutputPath)}`]
            .join('\n');
        },
        pass: false,
      };
    }
    else {
      return {
        message: () => [
          'Your assertion was rejected.',
          'The rules output from the firebase emulator is in the baseline snapshot.',
          `${chalk.bold.red('See snapshot for details:')} ${chalk.red(result.baselineSnapshotPath)}`]
          .join('\n'),
        pass: false,
      };
    }
  }

  if (!result.pass) {
    return {
      message: () => [
        'The rules output from the firebase emulator did not match the baseline snapshot',
        `${chalk.bold.red('See diff for details:')} ${chalk.red(result.diffOutputPath)}`]
        .join('\n'),
      pass: false,
    };
  }


  if (result.updated) {
    // once transition away from jasmine is done this will be a lot more elegant and pure
    // https://github.com/facebook/jest/pull/3668
    updateSnapshotState(snapshotState, { updated: snapshotState.updated + 1 });
  }
  else if (result.added) {
    updateSnapshotState(snapshotState, { added: snapshotState.added + 1 });
  }
  return {
    message: () => '',
    pass: true,
  };

}

function createTestNameIdentifier({
  testPath,
  currentTestName,
}) {
  return kebabCase(`${path.basename(testPath)}-${currentTestName}`);
}

function createSnapshotIdentifier({
  retryTimes,
  testIdentifier,
  currentTestName,
  customSnapshotIdentifier,
  snapshotState,
}) {

  const snapshotIdentifier = customSnapshotIdentifier || `${testIdentifier}-${snapshotState._counters.get(currentTestName)}`;
  if (retryTimes) {
    if (!customSnapshotIdentifier) throw new Error('A unique customSnapshotIdentifier must be set when jest.retryTimes() is used');

    timesCalled.set(snapshotIdentifier, (timesCalled.get(snapshotIdentifier) || 0) + 1);
  }
  return snapshotIdentifier;
}

function configureToMatchRulesSnapshot(customOptions = {}) {

  const {
    port = 8080,
    replace = [],
    customSnapshotsDir: configuredCustomSnapshotsDir = '',
    customDiffDir: configuredCustomDiffDir,
    customSeriesDir: configuredCustomSeriesDir,
    customRulesDir: configuredCustomRulesDir = process.cwd(),
    before: configuredBefore = () => '',
    auth: configuredAuth = {
      uid: 'default',
    },
  } = customOptions;

  return async function toMatchRulesSnapshot(receivedAssertion, snapshotArgs = {}) {

    const {
      customSnapshotIdentifier = '',
      customSnapshotsDir = configuredCustomSnapshotsDir,
      customDiffDir = configuredCustomDiffDir,
      customSeriesDir = configuredCustomSeriesDir,
      customRulesDir = configuredCustomRulesDir,
      before = configuredBefore,
      auth = configuredAuth,
    } = snapshotArgs;

    const {
      testPath,
      currentTestName,
      isNot,
      snapshotState,
    } = this;

    const chalk = new Chalk();

    const retryTimes = parseInt(global[Symbol.for('RETRY_TIMES')], 10) || 0;

    if (isNot) {
      throw new Error('Jest: `.not` cannot be used with `.toMatchImageSnapshot()`.');
    }

    const currentCountOfSnapshotsInTest = snapshotState._counters.get(currentTestName) || 0;

    const testIdentifier = createTestNameIdentifier({
      testPath,
      currentTestName,
    });

    let previousSnapshotIdentifier;
    if (currentCountOfSnapshotsInTest > 0 && !retryTimes) {
      previousSnapshotIdentifier = createSnapshotIdentifier({
        retryTimes,
        testIdentifier,
        currentTestName,
        customSnapshotIdentifier,
        snapshotState,
      });
    }

    updateSnapshotState(snapshotState, {
      _counters: snapshotState._counters.set(currentTestName, currentCountOfSnapshotsInTest + 1),
    });

    const snapshotIdentifier = createSnapshotIdentifier({
      retryTimes,
      testIdentifier,
      currentTestName,
      customSnapshotIdentifier,
      snapshotState,
    });

    const snapshotsDir = customSnapshotsDir || path.join(path.dirname(testPath), SNAPSHOTS_DIR);
    const diffDir = customDiffDir || path.join(snapshotsDir, '__diff_output__');
    const seriesDir = customSeriesDir || path.join(snapshotsDir, '__series__');

    const baselineSnapshotPath = path.join(snapshotsDir, `${snapshotIdentifier}-snap.html`);

    if (snapshotState._updateSnapshot === 'none' && !fs.existsSync(baselineSnapshotPath)) {
      return {
        pass: false,
        message: () => `New snapshot was ${chalk.bold.red('not written')}. The update flag must be explicitly ` +
                       'passed to write a new snapshot.\n\n + This is likely because this test is run in a continuous ' +
                       'integration (CI) environment in which snapshots are not written by default.\n\n',
      };
    }

    /**
     * Create the app.
     * Run any commands in args.
     */

    const projectId = testIdentifier;

    if (!firestoreApps[projectId]) {
      firestoreApps[projectId] = {};
    }

    let app = firestoreApps[projectId][auth.uid];
    if (!app) {
      app = firebase.initializeTestApp({
        projectId,
        auth,
      });
      firestoreApps[projectId][auth.uid] = app;
      await firebase.loadFirestoreRules({
        projectId,
        rules: fs.readFileSync(customRulesDir || path.resolve(process.cwd(), './firestore.rules'), 'utf8'),
      });
    }

    const firestore = app.firestore();

    const admin = firebase.initializeAdminApp({
      projectId,
    });

    await axios.get(`http://localhost:${port}`)
      .then(res => res.data)
      .catch(() => {
        throw Error(`Issue connecting to firestore server on localhost:${port}`);
      })
      .then((message) => {
        if (!message.includes('Ok')) {
          throw Error(`Did not receive message "Ok" from localhost:${port}`);
        }
      });

    if (!currentCountOfSnapshotsInTest) {
      if (typeof before !== 'function') {
        throw Error('The "before" option must be a function when using "toMatchRulesSnapshot"');
      }
      if (receivedAssertion && typeof receivedAssertion !== 'function') {
        throw Error('The assertion in "expect(assertion).toMatchRulesSnapshot()" must be a function');
      }
      before({
        firestore,
        admin,
        serverTimestamp: firebase.firestore.FieldValue.serverTimestamp,
      });
    }

    const reflectedAssertion = receivedAssertion ? await P.try(receivedAssertion).reflect() : P.resolve().reflect();

    /**
     * Ok, just hold on to the settled promise...
     * Still do the snapshot...
     * But the message should say "Your test failed.
     * See your snapshot here... Or see the diff here..."
     */

    const rulesUrl = `http://localhost:${port}/emulator/v1/projects/${projectId}:ruleCoverage.html`
    let receivedHtml = await getRulesHTML(rulesUrl)
    _each(replace, ([regex, replaceWith]) => {
      receivedHtml = receivedHtml.replace(regex, replaceWith);
    });


    const result =
      diffSnapshot({
        receivedHtml,
        currentCountOfSnapshotsInTest,
        snapshotsDir,
        diffDir,
        seriesDir,
        snapshotIdentifier,
        previousSnapshotIdentifier,
        updateSnapshot: snapshotState._updateSnapshot === 'all',
      });

    return checkResult({
      result,
      reflectedAssertion,
      snapshotState,
      retryTimes,
      snapshotIdentifier,
      chalk,
    });
  };
}

module.exports = {
  toMatchRulesSnapshot: configureToMatchRulesSnapshot(),
  configureToMatchRulesSnapshot,
  updateSnapshotState,
};
