/**
 * Ranks currencies based on current value in ascending order
 * @param currencies [] of format ['100 INR', '1.2 SGD']
 * @returns [] in sorted order
 */
export declare const rankCurrencies: (currencies: string[]) => Promise<(string | number)[]>;
export declare const convertCurrency: (value: number, fromCurrency: string, toCurrency: string) => Promise<number>;
