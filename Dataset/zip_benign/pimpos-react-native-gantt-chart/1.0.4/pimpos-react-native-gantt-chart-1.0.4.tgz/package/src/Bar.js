import React from 'react'
import { Rect, Text, G, Circle } from 'react-native-svg'

const Bar = props => {
  const {
    index,
    startVal,
    endVal,
    barHeight,
    task,
    onPress,
    primaryColor,
    secondaryColor,
    textColor,
    ticks,
    width
  } = props

  const padding = 4

  const y = barHeight * index + padding * (index + 1)
  const size = Math.floor(width / (ticks * 2))
  return (
    <G onPress={() => onPress(task)}>
      
      <Rect
        x={(size * startVal) * 2}
        y={y}
        height={barHeight}
        width={((size  * 2 ) * ( endVal - startVal))}
        strokeWidth={2}
        fill={primaryColor}
      />
      
      {task.state != '' && <>
        <Circle 
          fill={task.state}
          stroke={'#b8a3f3'}
          r="8"
          height={barHeight}
          width={barHeight}
          textAnchor="start"
          x={(size * startVal) * 2 + 20}
          y={y + (barHeight) / 2}
        />
        
      </>}
      <Text
        fill={textColor}
        stroke={textColor}
        fontSize={15}
        textAnchor="start"
        x={(size * startVal) * 2 + 35}
        y={y + (barHeight + 10) / 2}
      >
        {task.name}
      </Text>
      
    </G>
  )
}

export default Bar
