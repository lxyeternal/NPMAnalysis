import React from 'react'
import { G, Line, Text } from 'react-native-svg'

const Axis = props => {
  const { x, y, width, ticks, textColor, nameTicks } = props
  const endX = x + width
  const endY = y


  // Calculate tick points
  let tickPoints = []
  let TICKS_EVERY = Math.floor(width / ticks)

  let iterator = x
  while (iterator < endX) {
    if((iterator + TICKS_EVERY) >= endX){
      iterator = endX
    }else{
      tickPoints.push(iterator)
      iterator += TICKS_EVERY
    }
  }

  return (
    <G>
      <Line
        stroke={textColor}
        strokeWidth="1"
        x1={x}
        x2={endX}
        y1={y}
        y2={endY}
      />

      {tickPoints.map(pos => {
        return [
          <Line
            key={`h1-${pos}`}
            stroke={textColor}
            strokeWidth="1"
            x1={pos}
            y1={y}
            x2={pos}
            y2={20}
          />
        ]
      })}

      {tickPoints.map((pos, index) => {
        return (
          <Text
            key={`t-${pos}`}
            fill={"#C5c5c5"}
            stroke={"#C5c5c5"}
            fontSize={14}
            x={pos + 20 }
            y={y / 2 + 10 }
          >
            {nameTicks ? (String(index + 1) + 'º ' + nameTicks) : ''}
          </Text>
        )
      })}
    </G>
  )
}

export default Axis
