import React, { PureComponent } from 'react'
import { Dimensions, View, PanResponder, ScrollView } from 'react-native'
import Svg, { G } from 'react-native-svg'
import PropTypes from 'prop-types'
import Axis from './Axis'
import Bar from './Bar'

class GanttChart extends PureComponent {
  window = Dimensions.get('window')
  barHeight = 44

  state = {
    height: this.window.height,
    width: this.window.width
  }

  _isMoving = false
  _top = 0
  _initialY = 0
  _initialTop = 0
  chartRef = null

  processTouch(y) {
    if (!this._isMoving) {
      this._isMoving = true
      this._initialTop = this._top
      this._initialY = y
    } else {
      const dy = y - this._initialY
      this._top = Math.min(this._initialTop + dy, 0)

      // react-native-svg - setNativeProps({ matrix: [scaleX, skewY, skewX, scaleY, translateX, translateY] })
      this.chartRef.setNativeProps({ matrix: [1, 0, 0, 1, 0, this._top] })
    }
  }
  
  componentWillMount() {
    this.panResponder = PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: event => {
        const { touches } = event.nativeEvent
        if (touches.length === 1) {
          const [{ locationY }] = touches
          this.processTouch(locationY)
        }
      },
      onPanResponderRelease: () => (this._isMoving = false)
    })
  }

  _onLayout(event) {
    const {
      nativeEvent: {
        layout: { height, width }
      }
    } = event

    this.setState({ height, width })
  }


  render() {
    const { data, numberOfTicks, onPressTask, colors,nameTicks } = this.props
    const {
      barColorPrimary,
      barColorSecondary,
      backgroundColor,
      textColor,
      barColor
    } = colors
    const ticks = numberOfTicks

    const { height, width } = this.state
    const timeAxisHeight = height / 10

    if (!data || data.length === 0) return null

    const maxWidth = width + ( 96 * numberOfTicks)

    return (
      <ScrollView
        horizontal
        contentContainerStyle={{backgroundColor }}
        style={{paddingHorizontal: 20}}
        {...this.panResponder.panHandlers}
      >
        <Svg height={height} width={maxWidth + 40}>
          <Axis
            nameTicks={nameTicks}
            height={height}
            width={maxWidth}
            x={0}
            y={40}
            ticks={ticks}
            textColor={textColor}
          />
        </Svg>

        <Svg
          height={height - timeAxisHeight}
          width={maxWidth}
          style={{
            backgroundColor: 'transparent',
            position: 'absolute',
            top: timeAxisHeight + 1.5,
            left: 0
          }}
        >
          <G x={0} y={this._top} ref={ref => (this.chartRef = ref)}>
            {data.map((task, index) => {
              return (
                <Bar
                  onPress={onPressTask}
                  key={task._id}
                  index={index}
                  startVal={ task.start - 1}
                  endVal={task.end == task.start ? task.end + 1 : task.end}
                  barHeight={this.barHeight}
                  task={task}
                  width={maxWidth}
                  ticks={ticks}
                  primaryColor={barColor[task.type]}
                  secondaryColor={barColorSecondary}
                  textColor={textColor}
                />
              )
            })}
          </G>
        </Svg>
      </ScrollView>
    )
  }
}

GanttChart.propTypes = {
  data: PropTypes.arrayOf({
    _id: PropTypes.string.isRequired,
    name: PropTypes.string,
    progress: PropTypes.number,
    start: PropTypes.instanceOf(Date).isRequired,
    end: PropTypes.instanceOf(Date).isRequired
  }).isRequired,

  gridMax: PropTypes.number,
  gridMin: PropTypes.number,

  numberOfTicks: PropTypes.number,
  onPressTask: PropTypes.func,
  nameTicks: PropTypes.string,
  colors: PropTypes.objectOf({
    barColorPrimary: PropTypes.string,
    barColorSecondary: PropTypes.string,
    textColor: PropTypes.string,
    backgroundColor: PropTypes.string
  })
}

GanttChart.defaultProps = {
  numberOfTicks: 4,
  colors: {
    barColorPrimary: '#0c2461',
    barColorSecondary: '#4a69bd',
    textColor: '#fff',
    backgroundColor: '#82ccdd'
  },
  onPressTask: () => {}
}

export default GanttChart
