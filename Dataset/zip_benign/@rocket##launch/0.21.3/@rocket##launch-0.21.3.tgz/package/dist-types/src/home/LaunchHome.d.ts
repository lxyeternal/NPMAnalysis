export class LaunchHome extends LitElement {
    static properties: {
        reasons: {
            type: ArrayConstructor;
        };
        backgroundImage: {
            type: BooleanConstructor;
            reflect: boolean;
            attribute: string;
        };
    };
    static styles: import("lit").CSSResult[];
    /** @type {{ header: string, text: string }[]} */
    reasons: {
        header: string;
        text: string;
    }[];
    backgroundImage: boolean;
    render(): import("lit-html").TemplateResult<1>;
}
import { LitElement } from "lit-element/lit-element";
//# sourceMappingURL=LaunchHome.d.ts.map