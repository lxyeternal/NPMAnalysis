export class LayoutBlogPost extends LayoutMain {
}
import { LayoutMain } from "./LayoutMain.js";
//# sourceMappingURL=LayoutBlogPost.d.ts.map