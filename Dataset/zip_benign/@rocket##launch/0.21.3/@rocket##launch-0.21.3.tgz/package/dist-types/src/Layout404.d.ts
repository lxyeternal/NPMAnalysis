export class Layout404 {
    render(): import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Layout404.d.ts.map