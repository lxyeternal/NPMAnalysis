export class LayoutMain extends Layout {
    /**
     * @param {Partial<import('../types/layout.js').LayoutSidebarOptions>} options
     */
    constructor(options: Partial<import('../types/layout.js').LayoutSidebarOptions>);
    /**
     * Options for this layout.
     *
     * ⚠️ changes effect all following pages using this layout
     * => mostly useful in recursive.data.js and local.data.js files
     *
     * If you want to change only the current page, use `setPageOptions`
     *
     * Example: append html to sidebar only for this page
     * @example
     * layout.setPageOptions(sourceRelativeFilePath,
     *   {
     *     sidebar__70: html`
     *       <p>appended only on this page</p>
     *     `
     *   }
     * );
     *
     * @type {import('../types/layout.js').LayoutSidebarOptions}
     */
    options: import('../types/layout.js').LayoutSidebarOptions;
    /**
     * @param {string} sourceRelativeFilePath
     * @param {Partial<import('../types/layout.js').LayoutSidebarOptions>} options
     */
    setPageOptions(sourceRelativeFilePath: string, options: Partial<import('../types/layout.js').LayoutSidebarOptions>): void;
}
import { Layout } from "@rocket/engine";
//# sourceMappingURL=LayoutMain.d.ts.map