export class LayoutHome extends LayoutMain {
    /**
     * @param {import('../types/layout.js').LayoutHomeOptions} options
     */
    constructor(options: import('../types/layout.js').LayoutHomeOptions);
    /** @type {import('../types/layout.js').LayoutHomeOptions} */
    options: import('../types/layout.js').LayoutHomeOptions;
}
import { LayoutMain } from "./LayoutMain.js";
//# sourceMappingURL=LayoutHome.d.ts.map