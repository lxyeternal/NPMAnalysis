export function rocketLaunch(): Partial<import("@rocket/cli/dist-types/types/preset").FullRocketPreset>;
//# sourceMappingURL=rocketLaunch.d.ts.map