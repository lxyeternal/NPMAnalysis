export class LaunchBlogDetails extends LitElement {
    static properties: {
        data: {
            type: ObjectConstructor;
        };
    };
    static styles: import("lit").CSSResult[];
    /** @type {{ firstName: string; lastName: string; twitter: string; image: string; publishDate: Date; authors: [{ firstName: string; lastName: string; twitter: string; }], tags: string[] } | undefined} */
    data: {
        firstName: string;
        lastName: string;
        twitter: string;
        image: string;
        publishDate: Date;
        authors: [{
            firstName: string;
            lastName: string;
            twitter: string;
        }];
        tags: string[];
    } | undefined;
    dateFormatter: Intl.DateTimeFormat;
    render(): import("lit-html").TemplateResult<1> | typeof nothing;
}
import { LitElement } from "lit-element/lit-element";
import { nothing } from "lit-html";
//# sourceMappingURL=LaunchBlogDetails.d.ts.map