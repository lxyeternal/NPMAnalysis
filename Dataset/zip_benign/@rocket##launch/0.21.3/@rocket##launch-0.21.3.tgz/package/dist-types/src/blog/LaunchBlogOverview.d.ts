export class LaunchBlogOverview extends LitElement {
    /** @type {import('@rocket/engine').PageTree | undefined} */
    pageTree: import('@rocket/engine').PageTree | undefined;
    sourceRelativeFilePath: string;
    render(): import("lit-html").TemplateResult<1> | typeof nothing;
}
export type NodeOfPage = import('@rocket/engine').NodeOfPage;
import { LitElement } from "lit-element/lit-element.js";
import { nothing } from "lit-html";
//# sourceMappingURL=LaunchBlogOverview.d.ts.map