export class LaunchBlogPreview extends LitElement {
    static properties: {
        post: {
            type: ObjectConstructor;
        };
    };
    static styles: import("lit").CSSResult[];
    /** @type {{ publishDate: Date; title: string; description: string; url: string; name: string; } | undefined} */
    post: {
        publishDate: Date;
        title: string;
        description: string;
        url: string;
        name: string;
    } | undefined;
    dateFormatter: Intl.DateTimeFormat;
    render(): import("lit-html").TemplateResult<1> | typeof nothing;
}
import { LitElement } from "lit-element/lit-element";
import { nothing } from "lit-html";
//# sourceMappingURL=LaunchBlogPreview.d.ts.map