export class LayoutSidebar extends LayoutMain {
}
import { LayoutMain } from "./LayoutMain.js";
//# sourceMappingURL=LayoutSidebar.d.ts.map