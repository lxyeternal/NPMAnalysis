export namespace defaultGlobalOptions {
    const siteName: string;
    const logoSrc: string;
    const logoAlt: string;
    const gitSiteUrl: string;
    const gitBranch: string;
    const description: string;
}
//# sourceMappingURL=_shared.d.ts.map