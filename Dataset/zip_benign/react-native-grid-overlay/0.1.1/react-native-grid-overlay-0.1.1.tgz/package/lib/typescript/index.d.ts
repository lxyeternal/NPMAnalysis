import React from 'react';
import { ColorValue } from 'react-native';
export declare const GridOverlay: ({ color, opacity, stepSize, highlightGroupSize, height, width, children, }: IGridOverlayProps) => JSX.Element;
interface IGridOverlayProps {
    color?: ColorValue;
    opacity?: number;
    stepSize?: number;
    highlightGroupSize?: number;
    height?: number;
    width?: number;
    children?: React.ReactNode;
}
export {};
//# sourceMappingURL=index.d.ts.map