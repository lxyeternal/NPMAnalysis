interface IWebappBoxConfig {
    clickMaskClose?: boolean;
    width?: number;
    height?: number;
}
declare function configBox({ clickMaskClose, width, height }: IWebappBoxConfig): void;
declare function back(): void;
declare function close(): void;

declare const WebappBox: {
    version: string;
    config: typeof configBox;
    add(dom?: HTMLElement, title?: string): void;
    close: typeof close;
    back: typeof back;
};

export { WebappBox as default };
