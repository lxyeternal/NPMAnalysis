import * as React from 'react';
import { Box, Typography } from '@mui/material';

interface ColorSwatchProps {
  title: string;
  colorKey: string;
  hex: string;
  hasBorder?: boolean;
}

const ColorSwatch: React.FC<ColorSwatchProps> = ({ title, colorKey, hex, hasBorder }) => (
  <Box>
    <Box bgcolor={hex} height={64} border="1px solid" borderColor={hasBorder ? 'grey.300' : 'transparent'} />
    <Box display="flex" flexDirection="row" justifyContent="space-between" mt={1}>
      <Box>
        <Typography variant="subtitle1" component="h4" m={0}>
          {title}
        </Typography>
        <Typography variant="caption" m={0}>
          {colorKey}
        </Typography>
      </Box>
      <Box>
        <Typography variant="subtitle2" component="span" sx={{ color: 'grey' }} m={0}>
          {hex.toUpperCase()}
        </Typography>
      </Box>
    </Box>
  </Box>
);

ColorSwatch.displayName = 'ColorSwatch';

export default ColorSwatch;
