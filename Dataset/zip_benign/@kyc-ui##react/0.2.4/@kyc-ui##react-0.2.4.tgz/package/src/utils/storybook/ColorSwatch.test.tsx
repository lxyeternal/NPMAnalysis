import * as React from 'react';
import { render } from '@testing-library/react';

import { theme } from '../../theme';
import ColorSwatch from './ColorSwatch';

describe('utils/storybook', () => {
  describe('ColorSwatch', () => {
    test('renders correctly', () => {
      const { container } = render(<ColorSwatch title="primary" colorKey="" hex={theme.palette.primary.main} />);

      expect(container.firstChild).toBeInTheDocument();
    });
  });
});
