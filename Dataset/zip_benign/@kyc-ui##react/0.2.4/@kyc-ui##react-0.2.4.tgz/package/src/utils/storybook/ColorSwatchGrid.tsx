import * as React from 'react';
import { Box } from '@mui/material';

const ColorSwatchGrid: React.FC = ({ children }) => {
  return (
    <Box
      mt={4}
      mb={8}
      display="grid"
      gridTemplateColumns="repeat(auto-fill, minmax(calc(1116px / 4 - 24px), 1fr))"
      gap={6}
    >
      {children}
    </Box>
  );
};

export default ColorSwatchGrid;
