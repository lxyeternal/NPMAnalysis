# Kyc Provider

> Provides necessary resets to use kyc-ui.

## Usage

Wrap your entire app with `KycProvider`. This will apply the theme provider as well as the default global styles.

```jsx
import { KycProvider } from '@kyc-ui/react';
export default function MyApp({ children }) {
  return <KycProvider>{children}</KycProvider>;
}
```

If you would like to use additional styles for `KycProvider`, add the `disableInjection` prop to `KycProvider` and add your custom styles as follows.

```jsx
import { css } from '@emotion/css';
import { KycProvider, injectGlobalStyles } from '@kyc-ui/react';
const styles = css`
  [data-reach-tooltip] {
    z-index: 1;
    pointer-events: none;
    position: absolute;
    padding: 0.25em 0.5em;
    box-shadow: 2px 2px 10px hsla(0, 0%, 0%, 0.1);
    white-space: nowrap;
    font-size: 85%;
    background: #f0f0f0;
    color: #444;
    border: solid 1px #ccc;
  }
`;
const { inputGlobalStyles } = injectGlobalStyles(styles);
export default function MyApp({ children }) {
  return (
    <KycProvider disableInjection>
      {inputGlobalStyles}
      {children}
    </KycProvider>
  );
}
```

Once you've applied the provider, you can use KYC UI components in your app.
