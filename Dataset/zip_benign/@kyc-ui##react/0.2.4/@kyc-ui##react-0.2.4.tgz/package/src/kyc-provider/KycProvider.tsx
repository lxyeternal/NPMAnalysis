import * as React from 'react';
import { CssBaseline } from '@mui/material';
import { ThemeProvider, Theme } from '@mui/material/styles';

import { SnackbarProvider } from '../components/snackbar/internals';
import { theme as defaultTheme } from '../theme';
import injectGlobalStyles from './injectGlobalStyles';

import '../assets/fonts';

export interface KycProviderProps {
  /**
   * If you want to extend the global styles set to `true` and inject them
   * manually via `injectGlobalStyles`.
   */
  disableInjection?: boolean;
  /** Custom theme object. */
  theme?: Theme;
}

const { inputGlobalStyles } = injectGlobalStyles();

const KycProvider: React.FC<KycProviderProps> = ({ children, disableInjection, theme = defaultTheme }) => {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {!disableInjection && inputGlobalStyles}
      <SnackbarProvider>{children}</SnackbarProvider>
    </ThemeProvider>
  );
};

KycProvider.displayName = 'KycProvider';

export default KycProvider;
