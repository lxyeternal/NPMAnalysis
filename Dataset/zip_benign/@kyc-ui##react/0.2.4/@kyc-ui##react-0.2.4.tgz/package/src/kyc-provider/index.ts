export { default as KycProvider } from './KycProvider';
export * from './KycProvider';

export { default as injectGlobalStyles } from './injectGlobalStyles';
