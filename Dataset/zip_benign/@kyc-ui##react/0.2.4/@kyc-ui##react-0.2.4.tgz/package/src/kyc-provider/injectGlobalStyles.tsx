import * as React from 'react';
import { GlobalStyles } from '@mui/material';
import { css } from '@emotion/css';

const injectGlobalStyles = (additionalStyles?: string | ReturnType<typeof css>) => {
  const inputGlobalStyles = <GlobalStyles styles={additionalStyles} />;
  return { inputGlobalStyles };
};

export default injectGlobalStyles;
