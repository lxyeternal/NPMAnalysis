import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import { Meta } from '@storybook/react/types-6-0';

import { ColorSwatch, ColorSwatchGrid } from '../../utils/storybook';

export default {
  title: 'Core/Foundations/Colors',
  parameters: {
    controls: {
      disabled: true,
    },
  },
} as Meta;

export const Primary = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Main" colorKey="" hex={theme.palette.primary.main} />
      <ColorSwatch title="Light" colorKey="" hex={theme.palette.primary.light} />
      <ColorSwatch title="Dark" colorKey="" hex={theme.palette.primary.dark} />
      <ColorSwatch title="Contrast" colorKey="" hex={theme.palette.primary.contrastText} hasBorder />
    </ColorSwatchGrid>
  );
};

export const Secondary = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Main" colorKey="" hex={theme.palette.secondary.main} />
      <ColorSwatch title="Light" colorKey="" hex={theme.palette.secondary.light} />
      <ColorSwatch title="Dark" colorKey="" hex={theme.palette.secondary.dark} />
      <ColorSwatch title="Contrast" colorKey="" hex={theme.palette.secondary.contrastText} />
    </ColorSwatchGrid>
  );
};

export const Error = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Main" colorKey="" hex={theme.palette.error.main} />
      <ColorSwatch title="Light" colorKey="" hex={theme.palette.error.light} />
      <ColorSwatch title="Dark" colorKey="" hex={theme.palette.error.dark} />
      <ColorSwatch title="Contrast" colorKey="" hex={theme.palette.error.contrastText} hasBorder />
    </ColorSwatchGrid>
  );
};

export const Warning = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Main" colorKey="" hex={theme.palette.warning.main} />
      <ColorSwatch title="Light" colorKey="" hex={theme.palette.warning.light} />
      <ColorSwatch title="Dark" colorKey="" hex={theme.palette.warning.dark} />
      <ColorSwatch title="Contrast" colorKey="" hex={theme.palette.warning.contrastText} />
    </ColorSwatchGrid>
  );
};

export const Info = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Main" colorKey="" hex={theme.palette.info.main} />
      <ColorSwatch title="Light" colorKey="" hex={theme.palette.info.light} />
      <ColorSwatch title="Dark" colorKey="" hex={theme.palette.info.dark} />
      <ColorSwatch title="Contrast" colorKey="" hex={theme.palette.info.contrastText} hasBorder />
    </ColorSwatchGrid>
  );
};

export const Success = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Main" colorKey="" hex={theme.palette.success.main} />
      <ColorSwatch title="Light" colorKey="" hex={theme.palette.success.light} />
      <ColorSwatch title="Dark" colorKey="" hex={theme.palette.success.dark} />
      <ColorSwatch title="Contrast" colorKey="" hex={theme.palette.success.contrastText} />
    </ColorSwatchGrid>
  );
};

export const Text = () => {
  const theme = useTheme();
  return (
    <ColorSwatchGrid>
      <ColorSwatch title="Primary" colorKey="" hex={theme.palette.text.primary} />
      <ColorSwatch title="Secondary" colorKey="" hex={theme.palette.text.secondary} />
      <ColorSwatch title="Disabled" colorKey="" hex={theme.palette.text.disabled} />
    </ColorSwatchGrid>
  );
};
