import { createTheme } from '@mui/material/styles';

import colors from './colors';

const systemFonts =
  "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'";

const fonts = {
  system: systemFonts,
  body: `'Poppins', ${systemFonts}`,
};

const themeBase = createTheme({
  typography: {
    fontFamily: fonts.body,
  },
  palette: {
    primary: {
      main: colors.blue[500],
      dark: colors.blue[700],
      light: colors.blue[300],
      contrastText: colors.white,
    },
    secondary: {
      main: colors.purple[500],
      dark: colors.purple[700],
      light: colors.purple[300],
      contrastText: colors.white,
    },
    info: {
      main: colors.violet[500],
      dark: colors.violet[700],
      light: colors.violet[300],
      contrastText: colors.white,
    },
    warning: {
      main: colors.orange[500],
      dark: colors.orange[700],
      light: colors.orange[300],
      contrastText: colors.white,
    },
    success: {
      main: colors.green[500],
      dark: colors.green[700],
      light: colors.green[300],
      contrastText: colors.black,
    },
    error: {
      main: colors.red[500],
      dark: colors.red[700],
      light: colors.red[300],
      contrastText: colors.white,
    },
    text: {
      primary: colors.black,
      secondary: '#737491',
      disabled: '#B7B7C1',
    },
    background: {
      paper: colors.white,
      default: '#F5F6FA',
    },
    action: {
      active: 'rgba(74, 75, 101, 0.6)',
      hover: 'rgba(74, 75, 101, 0.04)',
      selected: 'rgba(74, 75, 101, 0.08)',
      disabled: 'rgba(74, 75, 101, 0.26)',
      disabledBackground: 'rgba(74, 75, 101, 0.12)',
      focus: 'rgba(74, 75, 101, 0.12)',
    },
  },
  breakpoints: {
    values: {
      xs: 0,
      sm: 360,
      md: 768,
      lg: 1280,
      xl: 1920,
    },
  },
  spacing: 4,
});

const theme = createTheme(themeBase, {
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          fontFamily: fonts.body,
          backgroundColor: '#F5F6FA',
        },
        a: {
          textDecoration: 'none',
          color: 'inherit',
        },

        '[aria-label="cancel"]': {
          display: 'inline-flex !important',
        },

        '[aria-label="tnc link"]': {
          color: '-webkit-link',
        },

        [themeBase.breakpoints.up('lg')]: {
          '[aria-label="cancel"]': {
            display: 'none !important',
          },
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: themeBase.spacing(4),
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        rounded: {
          borderRadius: themeBase.spacing(4),
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          width: '100%',
          height: 'auto',
          borderRadius: themeBase.spacing(4),
        },
      },
    },
    MuiCardContent: {
      styleOverrides: {
        root: {
          padding: themeBase.spacing(6),
        },
      },
    },
    MuiList: {
      styleOverrides: {
        padding: {
          paddingTop: 0,
          paddingBottom: 0,
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: themeBase.spacing(4),
        },
      },
    },
  },
});

export default theme;
