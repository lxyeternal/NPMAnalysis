export const SNACKBAR_WIDTH = 366;
export const ANIMATION_DURATION = 400;
