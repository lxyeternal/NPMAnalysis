import * as React from 'react';
import { SnackbarSettings } from '../types';
import SnackbarContainer from './SnackbarContainer';
import SnackbarContext from './SnackbarContext';

let snackbarCount = 0;

const SnackbarProvider: React.FC = ({ children }) => {
  const [snackbars, setSnackbars] = React.useState<SnackbarSettings[]>([]);

  const createSnackbarInstance = (settings: SnackbarSettings): SnackbarSettings => {
    const { id, ...rest } = settings;

    const uniqueId = ++snackbarCount;
    const generatedId = `${id ?? 'snackbar'}-${uniqueId}`;

    return {
      id: generatedId,
      ...rest,
    };
  };

  const addSnackbar = React.useCallback(
    (settings: SnackbarSettings) => {
      const snackbar = createSnackbarInstance(settings);
      setSnackbars(snackbarItems => [snackbar, ...snackbarItems]);
      return snackbar;
    },
    [setSnackbars]
  );

  const removeSnackbar = React.useCallback(
    (id?: string) => {
      setSnackbars(snackbarItems => snackbarItems.filter(t => t.id !== id));
    },
    [setSnackbars]
  );

  return (
    <SnackbarContext.Provider value={{ addSnackbar, removeSnackbar }}>
      {children}
      <SnackbarContainer snackbars={snackbars} />
    </SnackbarContext.Provider>
  );
};

export default SnackbarProvider;
