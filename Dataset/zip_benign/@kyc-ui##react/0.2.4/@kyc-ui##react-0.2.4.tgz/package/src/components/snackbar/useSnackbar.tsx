import * as React from 'react';
import { SnackbarContext } from './internals';

const useSnackbar = () => React.useContext(SnackbarContext);

export default useSnackbar;
