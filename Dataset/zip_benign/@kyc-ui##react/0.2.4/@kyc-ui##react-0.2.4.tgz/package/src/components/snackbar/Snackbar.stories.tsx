import { action } from '@storybook/addon-actions';
import * as React from 'react';
import { Box, AlertTitle } from '@mui/material';

import useSnackbar from './useSnackbar';
import Snackbar from './Snackbar';

export default {
  title: 'Core/Components/Snackbar',
  component: Snackbar,
};

export const Example = () => {
  const { addSnackbar } = useSnackbar();
  return (
    <Box sx={{ '> :not([hidden]) ~ :not([hidden])': { marginLeft: 'md' } }}>
      <button type="button" onClick={() => addSnackbar({ message: 'Single line' })}>
        Single line
      </button>
      <button
        type="button"
        onClick={() =>
          addSnackbar({ message: 'Single line with action', actionText: 'Action', onAction: () => action('click') })
        }
      >
        Single line with action
      </button>
      <button
        type="button"
        onClick={() =>
          addSnackbar({
            message: 'Single line',
          })
        }
      >
        Single line dismissable
      </button>
      <button
        type="button"
        onClick={() =>
          addSnackbar({
            message:
              'Multiple line. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras morbi enim, nisl in.',
          })
        }
      >
        Multiple line
      </button>
      <button
        type="button"
        onClick={() =>
          addSnackbar({
            message:
              'Multiple line. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras morbi enim, nisl in.',
            actionText: 'Action',
            onAction: () => action('click'),
          })
        }
      >
        Multiple line with action
      </button>

      <button
        type="button"
        onClick={() =>
          addSnackbar({
            message: 'Error',
            status: 'error',
            dismissAfter: 5000,
          })
        }
      >
        Error alert with action
      </button>

      <button
        type="button"
        onClick={() =>
          addSnackbar({
            message: (
              <>
                <AlertTitle>Info</AlertTitle>
                This is an info alert — <strong>check it out!</strong>
              </>
            ),
            status: 'info',
            actionText: 'Action',
            onAction: () => action('click'),
          })
        }
      >
        Info alert with title and action
      </button>
    </Box>
  );
};
