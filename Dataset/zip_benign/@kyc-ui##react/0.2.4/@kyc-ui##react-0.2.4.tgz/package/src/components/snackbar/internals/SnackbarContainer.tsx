import * as React from 'react';
import { Stack, Portal } from '@mui/material';

import Snackbar from '../Snackbar';
import { SnackbarSettings } from '../types';
import SnackbarContext from './SnackbarContext';

interface SnackbarContainerProps {
  snackbars?: SnackbarSettings[];
}

const SnackbarContainer: React.FC<SnackbarContainerProps> = ({ snackbars }) => {
  const { removeSnackbar } = React.useContext(SnackbarContext);

  return (
    <Portal>
      <Stack spacing={2} sx={{ width: '100%', position: 'fixed', bottom: 0, left: 0, right: 0 }}>
        {snackbars?.map(({ id, message, onRemove: _onRemove, status, ...rest }) => {
          return (
            <Snackbar
              key={id}
              id={id}
              message={message}
              variant={status}
              onRemove={() => removeSnackbar(id)}
              {...rest}
            />
          );
        })}
      </Stack>
    </Portal>
  );
};

export default SnackbarContainer;
