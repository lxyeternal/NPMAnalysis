export type SnackbarVariants = 'default' | 'error' | 'info' | 'success' | 'warning';

export interface SnackbarSettings {
  id?: string;
  /**
   * The message to display in the snackbar.
   * @type {string | React.ReactNode}
   * */
  message: string | React.ReactNode;
  status?: SnackbarVariants;
  /**
   * The number of milliseconds to wait before automatically calling the `onClose` function.
   * @default 5000
   * @type number
   * */
  dismissAfter?: number;
  /**
   * The text to display in the snackbar's action button.
   * */
  actionText?: string;
  /**
   * The callback function to call when the close button is clicked.
   * */
  onAction?: () => void;
  /**
   * The callback function to call when the snackbar is closed.
   * */
  onRemove?: () => void;
}

export interface SnackbarContextType {
  snackbars?: SnackbarSettings[];
  addSnackbar: (settings: SnackbarSettings) => SnackbarSettings;
  removeSnackbar: (id?: string) => void;
}
