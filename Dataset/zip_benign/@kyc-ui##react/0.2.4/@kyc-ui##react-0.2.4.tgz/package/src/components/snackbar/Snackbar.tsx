import * as React from 'react';
import {
  Snackbar as SnackbarMui,
  SnackbarOrigin,
  Button,
  IconButton,
  Alert,
  useMediaQuery,
  Theme,
  BoxProps,
} from '@mui/material';
import { Close } from '@mui/icons-material';

import { ANIMATION_DURATION, SNACKBAR_WIDTH } from './internals/constants';
import { SnackbarSettings, SnackbarVariants } from './types';

export interface SnackbarProps extends Omit<SnackbarSettings, 'status'>, BoxProps {
  /** The variant of the snackbar
   * @type { "default" | "success" | "info" | "error" | "warning" }
   * @default 'default'
   */
  variant?: SnackbarVariants;
}

export default function Snackbar({
  id,
  message,
  dismissAfter = 5000,
  variant = 'default',
  onAction,
  onRemove,
  actionText = 'Action',
}: SnackbarProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const onMobile = useMediaQuery((theme: Theme) => theme.breakpoints.down('md'));
  const [snackBarPosition, setSnackBarPosition] = React.useState<SnackbarOrigin>({
    vertical: 'bottom',
    horizontal: 'left',
  });
  const { vertical, horizontal } = snackBarPosition;

  React.useEffect(() => {
    if (onMobile) {
      setSnackBarPosition({ vertical: 'bottom', horizontal: 'center' });
    }
  }, [onMobile]);

  const close = React.useCallback(() => {
    setIsOpen(false);
  }, [setIsOpen]);

  React.useEffect(() => {
    let currentTimer: NodeJS.Timeout | null = null;
    setIsOpen(true);

    currentTimer = setTimeout(() => {
      close();
    }, dismissAfter);

    return () => {
      if (currentTimer) {
        clearTimeout(currentTimer);
      }
    };
  }, [close, dismissAfter]);

  const handleSnackBarClose = (onClose: () => void = () => {}, reason?: string) => {
    if (reason === 'timeout' || reason === 'clickaway') {
      onClose();
      close();
    }
  };

  return (
    <SnackbarMui
      id={id}
      action={
        <React.Fragment>
          {onAction && (
            <Button color="secondary" onClick={() => close()} size="small">
              {actionText}
            </Button>
          )}
          <IconButton
            aria-label="close"
            color="inherit"
            onClick={() => handleSnackBarClose(onAction, 'clickaway')}
            size="small"
          >
            <Close fontSize="small" />
          </IconButton>
        </React.Fragment>
      }
      anchorOrigin={{ vertical, horizontal }}
      autoHideDuration={dismissAfter}
      message={message}
      onClose={() => handleSnackBarClose(onAction, 'timeout')}
      open={isOpen}
      sx={{
        position: 'relative',
        width: `${SNACKBAR_WIDTH}px`,
      }}
      transitionDuration={{
        enter: ANIMATION_DURATION + 100,
        exit: ANIMATION_DURATION + 400,
      }}
      TransitionProps={{
        in: isOpen,
        onExited: onRemove,
      }}
    >
      {variant === 'default' ? undefined : (
        <Alert onClose={() => handleSnackBarClose(onAction, 'clickaway')} severity={variant} variant="filled">
          {message}
        </Alert>
      )}
    </SnackbarMui>
  );
}
