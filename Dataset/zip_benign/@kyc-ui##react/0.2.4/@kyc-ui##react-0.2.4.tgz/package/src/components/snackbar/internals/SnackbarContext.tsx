import * as React from 'react';
import { SnackbarContextType } from '../types';

const SnackbarContext = React.createContext<SnackbarContextType>({} as SnackbarContextType);

export default SnackbarContext;
