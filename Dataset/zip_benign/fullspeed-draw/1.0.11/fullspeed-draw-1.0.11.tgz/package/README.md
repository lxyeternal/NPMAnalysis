<!--
 * @Author: your name
 * @Date: 2021-03-15 18:16:54
 * @LastEditTime: 2021-03-15 18:46:27
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /npmDraw/README.md
-->
##### 使用步骤
①引入
```
  import drawCom from 'fullspeed-draw'
```
②使用
```
1.创建构造函数
  drawCom(); //执行函数
2.生成一个新的转盘
  const aa=new window.turnTable({  
    conId: "mycircle",     //父容器id
    num: 6,                //扇形个数
    max: 3,                //一次能抽奖的最大次数
    imgList: specList,     //图片列表

    drawWidth: 600,        //转盘宽度，以750设计稿为准
    drawStyle: {           //转盘样式
      singleColor: "#faa", //单数颜色 
      oldColor: "#aff",    //双数颜色
    },
    noPrizeTitle: "谢谢参与",  //无奖文案 
    fontStyle: {              //文字样式
      titleFontColor: "#333", //标题文字颜色
      titleFontSize: 20,      //标题字体大小
      titleSet: 0.4,          //标题离中心位置 0～1
      specFontColor: "#999",  //描述文字颜色
      specFontSize: 30,       //描述字体大小
      specSet: 0.5,           //描述离中心位置 0～1
      noPrizeFontColor: "#fee55d", //无奖字体颜色
      noPrizeFontSize: 35,         //无奖文案字体大小
      noPrizeSet: 0.4,             //无奖文案离中心位置 0～1
      imgWidth: 40,                //图片宽度
      imgHeight: 40,               //图片高度
      imgSet: 0.9,                 //图片离中心位置 0~1 越大离中心越远
    },
    hasRightArrow: true,           //是否有右侧的箭头
    arrowStyle: {                  //右侧箭头样式
      arrowColor: '#99f',          //箭头颜色
      arrowWidth: "",              //箭头宽度
      arrowHeight: "",             //箭头高度
    },

    callback: function () {        //抽奖结束回调
      console.log("结束抽奖回调");
    },
  });
3.使用函数
  aa._turnDraw(num); //num抽奖结果，以正东为原点

```