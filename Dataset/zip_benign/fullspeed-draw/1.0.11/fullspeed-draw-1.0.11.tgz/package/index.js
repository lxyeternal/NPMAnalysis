/*
 * @Author: your name
 * @Date: 2021-03-15 14:46:56
 * @LastEditTime: 2021-03-15 17:39:49
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /npmDraw/index.js
 */

import './index.css'

export default function drawCom() {

  var turnTable = function (option) {
    var _self = this;
    // _self.option = $.extend({}, turnTable.option, option);
    _self.option = Object.assign({}, turnTable.option, option)
    _self._init(option.num, option.imgList);
    window.onresize = function () {
      location.reload();
    }
  }

  turnTable.option = {
    con: '', canOut: '', circle: '',// 节点
    canClick: true,
    degList: [],//角度列表
    textDeg: [],//累计角度
    chaDegList: [],//中心累计角度
    initDeg: 0,
    initRes: 0,
    isEnd: false,
    res: 0,
    times: 0,
    max: 0, //最大抽奖次数

    drawWidth: 0, //转盘宽度
    drawStyle: { //转盘样式
      singleColor: '', //颜色1
      oldColor: '', //颜色2
    },
    noPrizeTitle: '', //无奖文案
    fontStyle: {  //文字样式
      titleFontColor: '', //名称字体颜色
      titleFontSize: '', //名称字体大小
      titleSet: 0, //名称位置
      specFontColor: '',
      specFontSize: '', //描述字体大小
      specSet: '', //描述位置
      noPrizeFontColor: '',
      noPrizeFontSize: '', //无奖文案字体大小
      noPrizeSet: 0, //无奖位置
      imgWidth: 0, //图片宽度
      imgHeight: 0, //图片高度
      imgSet: 0, //图片距离 
    },
    hasRightArrow: '', //是否有右侧小箭头
    arrowStyle: { //箭头样式
      arrowColor: '',
      arrowWidth: '',
      arrowHeight: '',
    }

    // num: 0,
    //max:2,
    // callback:''
    // conId: ''
  }

  turnTable.prototype = {
    _init: function (num, imgList) {
      var _self = this;
      // _self._num = num;//传入的个数参数
      let width = _self.option.drawWidth;
      let { hasRightArrow, drawWidth, arrowStyle } = _self.option;
      let conWidth = drawWidth / 100;
      let { arrowColor } = arrowStyle;
      let rightStyle = "position:absolute;left:5.6rem;top:2.8rem;z-index:10;border-width:0.2rem;border-style:solid;border-color:rgba(0,0,0,0);";
      let rightAddStyle = "border-right-color:" + (arrowColor ? arrowColor : '');
      rightStyle += rightAddStyle;
      // 最终生成的HTML
      let html = `
        <div id="con" style="width:${conWidth}rem;height:${conWidth}rem;position:relative">
        ${hasRightArrow ? `<div class="right" style=${rightStyle}></div>` : null}
          <div id="canvasout" class="canvasout" style="width:${conWidth}rem;height:${conWidth}rem;border-radius:50%;position:absolute;transition:transform 2s ease-in-out;transform:rotate(0)">
            <canvas id="canvas" width="${width}" height="${width}" style="display:block;border-radius:50%;touch-action:none"></canvas>
          </div>
        </div>
       
      `;
      // 添加到节点 #mycircle
      document.getElementById(_self.option.conId) && (document.getElementById(_self.option.conId).innerHTML += html);
      // 获取所需要的节点
      _self._getNeedElement();
      //绘制转盘
      _self.option.conId = document.getElementById(_self.option.conId)
      _self.option.conId && _self._drawText(num, imgList);
      // document.getElementById(_self.option.id).addEventListener('click', e => {
      // _self._turnDraw();
      // });
    },
    //获取元素节点
    _getNeedElement: function () {
      var _self = this;
      _self.option.con = document.getElementById('con');
      _self.option.canOut = document.getElementById('canvasout');
      _self.option.circle = document.getElementById('canvas');
    },

    //绘制转盘和文字
    _drawText: function (number, specList) {
      var _self = this;
      let deg = 360 / number;
      for (let i = 0; i < number; i++) {
        _self.option.degList.push(deg);
      }
      let degT = 0;
      for (let i = 0; i <= _self.option.degList.length; i++) {
        _self.option.textDeg.push(degT);
        degT += _self.option.degList[i];
      }
      let chaDeg;
      for (let i = 0; i < _self.option.textDeg.length - 1; i++) {
        chaDeg = (_self.option.textDeg[i + 1] + _self.option.textDeg[i]) / 2;
        _self.option.chaDegList.push(chaDeg);
      }
      // console.log(degList, textDeg, chaDegList)
      //绘制圆盘及文字
      let c3 = document.getElementById("canvas");
      let ctx = c3.getContext("2d");
      let clientWidth = document.documentElement.clientWidth;
      let mywidth = c3.width;
      let canvasWidth = (mywidth * clientWidth) / 750;
      let canvas = document.getElementsByTagName("canvas")[0];
      canvas.setAttribute("width", canvasWidth + "px");
      canvas.setAttribute("height", canvasWidth + "px");
      let width = ctx.canvas.width;
      console.log(width)
      let r = width / 2; //半径为画布的一半
      let { titleFontSize, specFontSize, noPrizeFontSize, titleSet, specSet, noPrizeSet,
        titleFontColor, specFontColor, noPrizeFontColor
      } = _self.option.fontStyle;
      // let fontStyle = _self.option.fontStyle;
      let fontWidth = (clientWidth * (titleFontSize ? titleFontSize : 40)) / 750;
      let fontWidth2 = (clientWidth * (specFontSize ? specFontSize : 46)) / 750;
      let fontWidth3 = (clientWidth * (noPrizeFontSize ? noPrizeFontSize : 52)) / 750;
      ctx.translate(r, r);
      // 将圆盘0的位置 转到箭头指向的地方
      if (specList && specList.length) {
        ctx.rotate(2.5 * (Math.PI / 180) * -(360 / specList.length));
        //绘制扇形和文字
        let thankImg = '';
        let emptyImg = '';
        let imgArray = [];
        //图片数组
        specList.forEach((elem) => {
          let obj = {};

          if (elem.imgurl) {
            obj = { src: elem.imgurl, isload: false };
          } else {
            if (elem.isPrize == true) {
              obj = { src: emptyImg, isload: false };
            } else {
              obj = { src: thankImg, isload: false };
            }
          }
          //isload是否可以加载图片
          imgArray.push(obj);
        });
        ctx.clearRect(0, 0, width, width);
        imgArray[0].isload = true;
        for (let i = 0; i < specList.length; i++) {
          let img = new Image();
          img.src = imgArray[i].src;
          img.onload = function () {
            let timer = setInterval(() => {
              if (imgArray[i].isload) {
                ctx.rotate((Math.PI / 180) * _self.option.degList[number - i]);
                ctx.beginPath();
                ctx.arc(0, 0, r, 0, (Math.PI / 180) * _self.option.degList[number - 1 - i]);
                ctx.lineTo(0, 0);
                let { oldColor, singleColor } = _self.option.drawStyle;
                if (i % 2 == 0) {
                  ctx.fillStyle = oldColor ? oldColor : "#fff4c3";
                } else {
                  ctx.fillStyle = singleColor ? singleColor : '#fff';
                }

                ctx.fill();
                let title = specList[i].title ? specList[i].title : "";
                let spec = specList[i].desc
                  ? specList[i].desc
                  : "";
                let isPrize = specList[i].isPrize;

                ctx.rotate(((Math.PI / 180) * _self.option.degList[number - 1 - i]) / 2);
                ctx.rotate(Math.PI / 2);
                if (isPrize == true) {
                  ctx.fillStyle = titleFontColor ? titleFontColor : "#666";
                  ctx.textAlign = "center";
                  ctx.font = fontWidth + "px 黑体";
                  // ctx.fillText(title, 0, -width / 2.5); //-width/10
                  ctx.fillText(title, 0, -r * titleSet); //-width/10
                  ctx.fillStyle = specFontColor ? specFontColor : "#333";
                  ctx.font = fontWidth2 + "px 黑体";
                  ctx.fillText(spec, 0, -r * specSet); //-width/10
                } else {
                  if (title) {
                    ctx.fillStyle = titleFontColor ? titleFontColor : "#666";
                    ctx.textAlign = "center";
                    ctx.font = fontWidth + "px 黑体";
                    ctx.fillText(title, 0, -r * titleSet); //-width/10
                    ctx.fillStyle = specFontColor ? specFontColor : "#333";
                    ctx.font = fontWidth2 + "px 黑体";
                    ctx.fillText(spec, 0, -r * specSet); //-width/10
                  } else {
                    ctx.fillStyle = noPrizeFontColor ? noPrizeFontColor : "#333";
                    ctx.textAlign = "center";
                    ctx.font = fontWidth3 + "px 黑体";
                    // console.log(ctx.font)
                    ctx.fillText(_self.option.noPrizeTitle, 0, -r * noPrizeSet); //-width/10
                  }
                }

                let { imgWidth, imgHeight, imgSet } = _self.option.fontStyle;
                // ctx.drawImage(img, -r / 8, -0.96 * r, (8 * r) / 31, (8 * r) / 31); //绘制图片
                ctx.drawImage(img, -imgWidth / 2, imgSet ? (-imgSet * r) : (-0.96 * r), imgWidth, imgHeight); //绘制图片
                // console.log(2222)
                ctx.rotate(-Math.PI / 2);
                ctx.rotate(-((Math.PI / 180) * _self.option.degList[number - 1 - i]) / 2);
                if (i < specList.length - 1) {
                  imgArray[i + 1].isload = true;
                }
                clearInterval(timer);
              }
            }, 10);
          };
        }
      }

      // _self.state.initDeg = (360 / number);
    },


    //点击开始
    _turnDraw: function (res) {
      const _self = this;
      if (_self.option.canClick) {
        _self.option.times++;
        _self.option.canClick = false;
        let randomDeg = (_self.option.num - res) * (360 / _self.option.num)
        let turnDeg;
        if (_self.option.times === 1) {
          turnDeg = _self.option.initDeg + randomDeg + 1440;
        } else {
          turnDeg = _self.option.initDeg + 1440 + (_self.option.initRes - res) * (360 / _self.option.num);
        }
        _self.option.canOut.style.transform = `rotate(${turnDeg}deg)`;
        _self.option.initDeg = turnDeg;
        setTimeout(() => {
          _self.option.initRes = res;
          console.log('res:', res)
          _self.option.isEnd = true;
          if (_self.option.times < _self.option.max) {
            _self.option.canClick = true;
          }
        }, 2000);
      }
      _self._endCallback();
    },
    //结束时回调
    _endCallback: function () {
      const _self = this;
      let timer;
      timer = setInterval(() => {
        if (_self.option.isEnd) {
          _self.option.callback();
          _self.option.isEnd = false;
          clearInterval(timer);
        }
      }, 2000)
    }
  }

  window.turnTable = turnTable;
};