import { SpawnOptions } from "child_process";

export interface Recorder {
  cmd: string;
  args?: (string | number)[];
  spawnOptions?: SpawnOptions;
}
