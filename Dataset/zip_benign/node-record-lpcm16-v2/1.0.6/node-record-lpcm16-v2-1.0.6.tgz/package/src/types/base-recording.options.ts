export interface BaseRecordingOptions {
  cmd?: string;
  compress?: boolean;
}
