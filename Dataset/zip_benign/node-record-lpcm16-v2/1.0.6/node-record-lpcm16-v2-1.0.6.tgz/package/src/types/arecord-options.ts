import { BaseRecordingOptions } from "./base-recording.options";

export interface ArecordOptions extends BaseRecordingOptions {
  recorder: "arecord";
  sampleRate: number;
  channels: number;
  audioType: string;
  device?: string;
}
