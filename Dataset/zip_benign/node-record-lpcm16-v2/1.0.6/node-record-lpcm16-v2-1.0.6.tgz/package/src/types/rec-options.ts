import { BaseRecordingOptions } from "./base-recording.options";
export interface RecOptions extends BaseRecordingOptions {
  sampleRate: number;
  channels: number;
  audioType: string;
  endOnSilence?: boolean;
  threshold?: number;
  thresholdStart?: string | null;
  thresholdEnd?: string | null;
  silence?: string;
  recorder: "rec";
}
