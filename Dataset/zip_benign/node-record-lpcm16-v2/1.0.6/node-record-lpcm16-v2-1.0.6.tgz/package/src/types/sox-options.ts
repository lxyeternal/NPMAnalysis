import { BaseRecordingOptions } from './base-recording.options';
export interface SoxOptions extends BaseRecordingOptions {
  sampleRate: number;
  channels: number;
  audioType: string;
  endOnSilence?: boolean;
  threshold?: number;
  thresholdStart?: string | null;
  thresholdEnd?: string | null;
  silence?: string;
  device?: string;
  recorder:"sox";
}