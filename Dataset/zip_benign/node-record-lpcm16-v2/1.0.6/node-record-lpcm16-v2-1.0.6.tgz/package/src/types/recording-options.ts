import { ArecordOptions } from "./arecord-options";
import { RecOptions } from "./rec-options";
import { SoxOptions } from "./sox-options";

export type RecorderOptions = (ArecordOptions | SoxOptions | RecOptions);
