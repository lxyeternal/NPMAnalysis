import { FootprintSettings } from './settings';
export interface Footprint {
    name: string;
    description: string;
    keywords: string[];
    housing: Housing;
}
export interface Housing {
    pattern: string;
    bodyLength: string;
    bodyWidth: string;
    height: string;
    leadLength: string;
}
export declare class Library {
    readonly name: string;
    readonly settings?: FootprintSettings | undefined;
    readonly footprints: Footprint[];
    constructor(name: string, settings?: FootprintSettings | undefined);
    addFootprint(fp: Footprint): void;
    generate(dir?: string): void;
}
