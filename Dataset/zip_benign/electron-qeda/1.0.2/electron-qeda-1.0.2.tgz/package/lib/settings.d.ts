export interface FootprintSettings {
    style: 'default';
    densityLevel: 'N';
    decimals: number;
    polarityMark: 'dot';
    preferManufacturer: boolean;
    smoothPadCorners: boolean;
    tolerance: {
        default: number;
        fabrication: number;
        placement: number;
    };
    clearance: {
        padToSilk: number;
        padToPad: number;
        padToMask: number;
        leadToHole: number;
    };
    ratio: {
        padToHole: number;
        cornerToWidth: number;
    };
    minimum: {
        ringWidth: number;
        holeDiameter: number;
        maskWidth: number;
        spaceForIron: number;
    };
    maximum: {
        cornerRadius: number;
    };
    lineWidth: {
        default: number;
        silkscreen: number;
        assembly: number;
        courtyard: number;
    };
    fontSize: {
        default: number;
        refDes: number;
        value: number;
    };
    ball: {
        collapsible: boolean;
    };
}
export declare const DefaultFootprintSettings: FootprintSettings;
