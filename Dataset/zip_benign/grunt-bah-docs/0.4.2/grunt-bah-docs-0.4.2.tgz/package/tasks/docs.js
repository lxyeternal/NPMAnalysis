/*
 * grunt-bah-docs
 * https://github.com/StefanKandlbinder/grunt-bah-docs
 *
 * Copyright (c) 2015 Stefan Kandlbinder
 * Licensed under the MIT license.
 */

'use strict';

module.exports = function(grunt) {
  var path = require('path');

  // Please see the Grunt documentation for more information regarding task
  // creation: http://gruntjs.com/creating-tasks

  grunt.registerMultiTask('docs', 'bet-at-home doc generator', function() {
    var kindOf = grunt.util.kindOf;

    var options = this.options({
      processContent: false,
      processContentExclude: []
    });

    var copyOptions = {
      process: options.processContent,
      noProcess: options.processContentExclude
    };

    grunt.verbose.writeflags(options, 'Options');

    var dest;
    var isExpandedPair;
    var tally = {
      dirs: 0,
      files: 0
    };

    // get the body of the single doc element
    var docBody = grunt.file.read('bah/html/includes/head.html');
    var after = '';
    var splitDocBody = docBody.split('<div class="bah-sg-content">');

    // get the body of the single page doc element
    var docFullBody = grunt.file.read('bah/html/includes/head-full-doc.html');
    var splitDocFullBody = docFullBody.split('<div class="bah-sg-content">');

    // all the objects combined in one variable
    var doc = '';
    doc += splitDocFullBody[0] + '<div class="bah-sg-content">';

    // the affix Object -> call by reference
    var affix = new Object();
    affix.val = '';
    var folder = [];

    this.files.forEach(function(filePair) {
      isExpandedPair = filePair.orig.expand || false;

      filePair.src.forEach(function(src) {
        if (detectDestType(filePair.dest) === 'directory') {
          dest = (isExpandedPair) ? filePair.dest : unixifyPath(path.join(filePair.dest, src));
        } 
        else {
          dest = filePair.dest;
          // grunt.log.writeln(dest);
          // grunt.log.writeln('####### OIDA ########');
          folder.push(dest.substring(dest.lastIndexOf('/')  + 1, dest.lastIndexOf('__')));
          // grunt.log.writeln(actualFolder);
        }

        if (grunt.file.isDir(src)) {
          grunt.verbose.writeln('Creating ' + dest.cyan);
          grunt.file.mkdir(dest);
          tally.dirs++;
        }
        else {
          grunt.verbose.writeln('Copying ' + src.cyan + ' -> ' + dest.cyan);
          grunt.file.copy(src, dest, copyOptions);

          docBody = splitDocBody[0] + '<div class="bah-sg-content">';
          after = splitDocBody[1];

          var content = grunt.file.read(dest);
          content = createSourceCode(content, affix);
          var contents = docBody + content + after;

          // add content to the single page doc
          doc += content;

          createAffix(content, affix, folder);

          grunt.file.write(dest, contents); 

          tally.files++;
        }
      });
    });

    // generate the whole doc
    doc += splitDocFullBody[1];
    
    // createAffix(doc, affix);
    var docSplitted = '';
    docSplitted = doc.split('<div class="bah-sg-affix">');
    // grunt.log.writeln(docSplitted[1]);
    docSplitted = docSplitted[0] + '<div class="bah-sg-affix">'  + affix.val + docSplitted[1];


    grunt.file.write("bah/html/doc.html", docSplitted);

    if (tally.dirs) {
      grunt.log.write('Created ' + tally.dirs.toString().cyan + ' directories');
    }

    if (tally.files) {
      grunt.log.write((tally.dirs ? ', copied ' : 'Copied ') + tally.files.toString().cyan + ' files');
    }
  });

  var createSourceCode = function(content, affix) {
    var splittedContent = '';
    splittedContent = content.split("<seperator></seperator>");
    var tmp = '';
    var begin = "<!-- doc-begin-->";  // starting point of documentation
    var end = "<!-- doc-end-->";  // end point of documentation
    var beginIndex = -1;  // the start index of the documentation
    var endIndex = -1;  // the end index of the documentation
    var before = '';  // the documentation before the raw source code
    var after = '';  // the documentation after the raw source code
    var xmp = '';  // the raw source code without documentation

    // are there more than one source code chunks
    if  (splittedContent.length >= 1) {
      for (var i=0; i<splittedContent.length; i++) {
        xmp = splittedContent[i].trim();

        // get the doc before the source code
        beginIndex = xmp.indexOf(begin);
        endIndex = xmp.indexOf(end);
        before = '';

        if (beginIndex >= 0) {
          before = xmp.substring(beginIndex, endIndex + end.length);
          xmp = xmp.replace(before, '');
          beginIndex = -1;
        }

        // get the doc after the source code
        beginIndex = xmp.lastIndexOf(begin);
        endIndex = xmp.lastIndexOf(end);
        after = '';

        if (beginIndex >= 0) {
          after = xmp.substring(beginIndex, endIndex + end.length)
          xmp = xmp.replace(after, '');
          beginIndex = -1;
        }

        if (xmp.trim() == '') {
          tmp = tmp + '<article>' + before + xmp + after + '</article>' + '<seperator></seperator><hr>';          
        }
        else {
          // tmp = tmp + before + xmp + '<xmp class="bah-sg-source">' + xmp.trim() + '</xmp>' + after + '<seperator></seperator>';  
          
          // prepare for the prism highlighter
          tmp = tmp + '<article>' + before + xmp + '<pre class="rB h-bG-FFFFF"><code class="language-markup">' + escapeHtml(xmp.trim()) + '</code></pre>' + after + '</article>' + '<seperator></seperator>';  
        }
      }
    }
    else {
      xmp = content.trim();

      // get the doc before the source code
      beginIndex = xmp.indexOf(begin);
      endIndex = xmp.indexOf(end);
      before = xmp.substring(beginIndex, endIndex + end.length);

      if (beginIndex >= 0) {
        xmp = xmp.replace(before, '');
      }

      // get the doc after the source code
      beginIndex = xmp.lastIndexOf(begin);
      endIndex = xmp.lastIndexOf(end);
      after = xmp.substring(beginIndex, endIndex + end.length)

      if (beginIndex >= 0) {
        xmp = xmp.replace(after, '');
      }

      if (xmp.trim() == '') {
          tmp = tmp + '<article>' + before + xmp + after + '</article>' + '<seperator></seperator>';            
        }
      else {
        // tmp = tmp + before + xmp + '<xmp class="bah-sg-source">' + xmp.trim() + '</xmp>' + after + '<seperator></seperator>';  
        
        // prepare for the prism highlighter
        tmp = tmp + '<article>' + before + xmp + '<pre class="rB"><code class="language-markup">' + escapeHtml(xmp.trim()) + '</code></pre>' + after + '</article>' + '<seperator></seperator>';  
      }
    }

    return tmp;
  }

  function escapeHtml(string) {
    var entityMap = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': '&quot;',
      "'": '&#39;',
      "/": '&#x2F;'
    };

    return String(string).replace(/[&<>"'\/]/g, function (s) {
      return entityMap[s];
    });
  }

  var createAffix = function(content, affix, folder) {
    // grunt.log.writeln(content);
    // var myRegExp__h1 =  /[^"<h1 id="]\w*[^">]/g;
    // var myRegExp__h1 =  /(<h1\sid=")\w+/g;
    // var myRegExp__h2 =  /(<h2\sid=")\w+/g;
    var myRegExp__h1 = /<(h1 id=).*?>(.*?)<\/h1>/g;
    var myRegExp__h2 = /<(h2 id=).*?>(.*?)<\/h2>/g;
    
    // var affix = "";
    var affix__content = '';
    var result__h1 = '';
    var result__h2 = '';
    var value = '';
    var folderBefore = '';
    var folderAfter = '';
    var folderLength = 0;
    var header = '';

    folderLength = folder.length;
    folderBefore = folder[folderLength - 2];
    folderAfter = folder[folderLength - 1];

    // if the folder changes add the header
    if (folderAfter != folderBefore) {
      // grunt.log.writeln(folderAfter);
      affix.val += affix__content + '\n</ul>\n<!-- end of ftl-nestedList -->\n</li>\n<!-- end of ftl-item -->\n</ul>\n<!-- end of ftl -->\n</div>\n<!-- end of rB -->';
      header = '\n\n<div class="rB S22G h-bG-E4E8EA h-bgTo-ffffff clearfix l-mb6">\n<!-- begin of ftl -->\n<ul class="ftl ftl-simple">\n<!-- begin of ftl-item -->\n<li class="ftl-item">\n<a class="ftl-item-link" onclick="$(this).parent().toggleClass(\'s-expanded\');"><i class="i-sprite ftl-item-i i-arrowDownBlue8x8"></i><i class="i-sprite ftl-item-i i-arrowRightBlue8x8"></i><span class="ftl-item-title">' + folderAfter + '</span></a>\n<!-- begin of ftl-nestedList -->\n<ul class="ftl-nestedList">';
    }
    else {
      affix.val += affix__content + '\n</li>\n<!-- end of ftl-item -->';
      header = '';
    }

    result__h1 = content.match(myRegExp__h1);
    // value = content.match(myRegExp__value);
    // grunt.log.writeln(value[0].substring(value[0].indexOf('">') + 2, value[0].indexOf('</')));

    if (result__h1) {
      for (var i=0; i<result__h1.length; i++) {
        // result__h1[i] = result__h1[i].replace("<h1 id=\"", "");
        value = result__h1[i].substring(result__h1[i].indexOf('">') + 2, result__h1[i].lastIndexOf('</'));
        result__h1[i] = result__h1[i].substring(result__h1[i].indexOf('<h1 id="') + 8, result__h1[i].indexOf('">'));
        affix__content += header + '\n<!-- begin of ftl-nestedItem -->\n<li class="ftl-nestedItem">\n<a class="ftl-nestedItem-link" style="position: relative;" href="#' + result__h1[i] + '" onclick="$(this).parent().toggleClass(\'s-expanded\');"><span class="ftl-nestedItem-title">' + value + '</span></a>';
      }
    }

    result__h2 = content.match(myRegExp__h2);

    // add the subitems if there are any
    if (result__h2) {
      affix__content += '\n<!-- begin of ftl-nestedSubList -->\n<ul class="ftl-nestedSubList">';
      for (var j=0; j<result__h2.length; j++) {
        value = result__h2[j].substring(result__h2[j].indexOf('">') + 2, result__h2[j].lastIndexOf('</'));
        result__h2[j] = result__h2[j].substring(result__h2[j].indexOf('<h2 id="') + 8, result__h2[j].indexOf('">'));
        affix__content += '\n<li class="ftl-nestedSubItem">\n<a class="ftl-nestedSubItem-link" href="#' + result__h2[j] + '"><span class="ftl-nestedSubItem-title">' + value + '</span></a>\n</li>';
      }
      affix__content += '\n</ul>\n<!-- end of ftl-nestedSubList -->';
      /* if (result__h2.length > 1)
        affix__content += '</div></div>';
      else {
        affix__content += '</div>';
      } */
    }
    
    // close the h1 if there is one
    if(result__h1) {
      affix__content += '\n</li>\n<!-- end of ftl-nestedItem -->';
    }

    affix.val += affix__content;

    
    /* if (folderAfter != folderBefore)
      affix.val += affix__content + '\n</ul>\n<!-- end of ftl -->\n</div>\n<!-- end of rB -->';
    else
      affix.val += affix__content + '\n</li>\n<!-- end of ftl-item -->'; */
  }

  var detectDestType = function(dest) {
    if (grunt.util._.endsWith(dest, '/')) {
      return 'directory';
    } else {
      return 'file';
    }
  };

  var unixifyPath = function(filepath) {
    if (process.platform === 'win32') {
      return filepath.replace(/\\/g, '/');
    } else {
      return filepath;
    }
  };
};