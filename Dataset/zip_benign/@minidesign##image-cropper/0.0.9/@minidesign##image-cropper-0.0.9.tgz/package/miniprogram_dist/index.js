module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var time = void 0;

Component({
  properties: {
    /**
     * 图片路径
     */
    imgSrc: {
      type: String
    },
    /**
     * 剪裁框高度
     */
    height: {
      type: Number,
      value: 200
    },
    /**
     * 剪裁框宽度
     */
    width: {
      type: Number,
      value: 200
    },
    /**
     * 生成的图片质量0-1
     */
    quality: {
      type: Number,
      value: 1
    },
    cut_top: {
      type: Number,
      value: null
    },
    cut_left: {
      type: Number,
      value: null
    },
    /**
     * canvas上边距（不设置默认不显示）
     */
    canvas_top: {
      type: Number,
      value: null
    },
    /**
     * canvas左边距（不设置默认不显示）
     */
    canvas_left: {
      type: Number,
      value: null
    },
    /**
     * 图片宽度
     */
    imgWidth: {
      type: null,
      value: null
    },
    /**
     * 图片高度
     */
    imgHeight: {
      type: null,
      value: null
    },
    /**
     * 图片缩放比
     */
    scale: {
      type: Number,
      value: 1
    },
    /**
     * 图片旋转角度
     */
    rotate: {
      type: Number,
      value: 0
    },
    /**
     * 最小缩放比
     */
    min_scale: {
      type: Number,
      value: 0.5
    },
    /**
     * 最大缩放比
     */
    max_scale: {
      type: Number,
      value: 2
    },
    /**
     * 是否禁用旋转
     */
    disable_rotate: {
      type: Boolean,
      value: false
    }
  },
  data: {
    el: 'image-cropper', // 暂时无用
    info: wx.getSystemInfoSync(),
    init_imgWidth: 0, // 图片设置尺寸,此值不变（记录最初设定的尺寸）
    init_imgHeight: 0, // 图片设置尺寸,此值不变（记录最初设定的尺寸）
    origin_x: 0.5, // 图片旋转中心
    origin_y: 0.5, // 图片旋转中心
    imgTop: wx.getSystemInfoSync().windowHeight / 2, // 图片上边距
    imgLeft: wx.getSystemInfoSync().windowWidth / 2, // 图片左边距
    touch_img_relative: [{
      x: 0,
      y: 0
    }], // 鼠标和图片中心的相对位置
    first_Hypotenuse: 0, // 双指触摸时斜边长度
    flag: false, // 是否结束触摸
    flag_bright: true, // 背景是否亮
    canvas_overflow: true, // canvas缩略图是否在屏幕外面
    watch: {
      // 监听截取框宽高变化
      width: function width(value, that) {
        that._changeWindowSize();
      },
      height: function height(value, that) {
        that._changeWindowSize();
      },
      canvas_top: function canvas_top(value, that) {
        if (that.data.canvas_top < -that.data.height || that.data.canvas_top > that.data.info.windowHeight) {
          that.data.canvas_overflow = true;
        } else {
          that.data.canvas_overflow = false;
        }
      },
      canvas_left: function canvas_left(value, that) {
        if (that.data.canvas_left < -that.data.width || that.data.canvas_left > that.data.info.windowWidth) {
          that.data.canvas_overflow = true;
        } else {
          that.data.canvas_overflow = false;
        }
      },
      imgSrc: function imgSrc(value, that) {
        that._changeWindowSize(true);
      },
      cut_top: function cut_top(value, that) {
        if (that.data.cut_top < 0) {
          that.setData({
            cut_top: 0
          });
        }
        if (that.data.cut_top > that.data.info.windowHeight - that.data.height) {
          that.setData({
            cut_top: that.data.info.windowHeight - that.data.height
          });
        }
        that._changeWindowSize();
      },
      cut_left: function cut_left(value, that) {
        if (that.data.cut_left < 0) {
          that.setData({
            cut_left: 0
          });
        }
        if (that.data.cut_left > that.data.info.windowWidth - that.data.width) {
          that.setData({
            cut_left: that.data.info.windowWidth - that.data.width
          });
        }
        that._changeWindowSize();
      }
    }
  },
  attached: function attached() {
    this._watcher(); //启用数据监听
    this._changeWindowSize(true); //设置截取框大小、绘制canvas
    this.data.init_imgWidth = this.data.imgWidth;
    this.data.init_imgHeight = this.data.imgHeight;
    //处理宽高特殊单位
    if (this.data.imgWidth && this.data.imgWidth.indexOf('%') != -1) {
      var width = this.data.imgWidth.replace('%', '');
      this.setData({
        imgWidth: this.data.info.windowWidth / 100 * width,
        init_imgWidth: this.data.info.windowWidth / 100 * width
      });
    }
    if (this.data.imgHeight && this.data.imgHeight.indexOf('%') != -1) {
      var height = this.data.imgHeight.replace('%', '');
      this.setData({
        imgHeight: this.data.info.windowHeight / 100 * height,
        init_imgHeight: this.data.info.windowHeight / 100 * height
      });
    }
    // 裁剪框坐标处理（如果只写一个参数则另一个默认为0，都不写默认居中）
    if (this.data.cut_top == null && this.data.cut_left == null) {
      this.cutCenter();
    } else if (this.data.cut_top != null && this.data.cut_left == null) {
      this.setData({
        cut_left: 0 // 截取的框左边距
      });
    } else if (this.data.cut_top == null && this.data.cut_left != null) {
      this.setData({
        cut_top: 0 // 截取的框左边距
      });
    }
    // canvas坐标处理（如果只写一个参数则另一个默认为0，都不写默认超出屏幕外）
    if (this.data.canvas_top != null && this.data.canvas_left == null) {
      this.setData({
        canvas_left: 0
      });
    } else if (this.data.canvas_top == null && this.data.canvas_left != null) {
      this.setData({
        canvas_top: 0
      });
    } else if (this.data.canvas_top == null && this.data.canvas_left == null) {
      this.setData({
        canvas_top: -3000
      });
    }
    // 校验canvas是否超出屏幕外
    this.data.watch.canvas_top(null, this);
    this.data.watch.canvas_left(null, this);
    //校验裁剪框是否超出屏幕外
    this.data.watch.cut_top(null, this);
    this.data.watch.cut_left(null, this);
  },

  methods: {
    /**
     * 返回图片路径
     */
    getImg: function getImg(getCallback) {
      this._draw();
      var triggerEvent = this.triggerEvent;
      wx.canvasToTempFilePath({
        width: this.data.width,
        height: this.data.height,
        destWidth: this.data.width * 3,
        destHeight: this.data.height * 3,
        fileType: 'png',
        quality: this.data.quality,
        canvasId: this.data.el,
        success: function success(res) {
          getCallback && getCallback(res.tempFilePath);
          triggerEvent('cropper', res.tempFilePath);
        }
      }, this);
    },

    /**
     * 点击中间剪裁框的回调
     */
    clickCallback: function clickCallback(callback) {
      this._clickCallback = callback;
    },

    /**
     * 设置图片动画
     * {
     *    x:10,//图片在原有基础上向下移动10px
     *    y:10,//图片在原有基础上向右移动10px
     *    rotate:10,//图片在原有基础上旋转10deg
     *    scale:0.5,//图片在原有基础上增加0.5倍
     * }
     */
    setTransform: function setTransform(transform) {
      if (!transform) return;
      var scale = this.data.scale;
      if (transform.scale) {
        scale = this.data.scale + transform.scale;
        scale = scale <= this.data.min_scale ? this.data.min_scale : scale;
        scale = scale >= this.data.max_scale ? this.data.max_scale : scale;
      }
      var cutX = this.data.cut_left;
      var cutY = this.data.cut_top;
      if (transform.cutX) {
        this.setData({
          cut_left: cutX + transform.cutX
        });
        this.data.watch.cut_left(null, this);
      }
      if (transform.cutY) {
        this.setData({
          cut_top: cutY + transform.cutY
        });
        this.data.watch.cut_top(null, this);
      }
      this.setData({
        imgTop: transform.y ? this.data.imgTop + transform.y : this.data.imgTop,
        imgLeft: transform.x ? this.data.imgLeft + transform.x : this.data.imgLeft,
        rotate: transform.rotate ? this.data.rotate + transform.rotate : this.data.rotate,
        scale: scale
      });

      if (!this.data.canvas_overflow) {
        this._draw();
      }
    },

    /**
     * 上传图片
     */
    upload: function upload() {
      var that = this;
      wx.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success: function success(res) {
          var tempFilePaths = res.tempFilePaths[0];
          that.pushImg(tempFilePaths);
        }
      });
    },
    cutCenter: function cutCenter() {
      this.setData({
        cut_top: (this.data.info.windowHeight - this.data.height) * 0.5, // 截取的框上边距
        cut_left: (this.data.info.windowWidth - this.data.width) * 0.5 // 截取的框左边距
      });
    },

    /**
     * 设置剪裁框宽度
     */
    setWidth: function setWidth(width) {
      this.setData({
        width: width
      });
      this._changeWindowSize();
    },

    /**
     * 设置剪裁框高度
     */
    setHeight: function setHeight(height) {
      this.setData({
        height: height
      });
      this._changeWindowSize();
    },
    setDisableRotate: function setDisableRotate(value) {
      this.data.disable_rotate = value;
    },

    /**
     * 加载（更换）图片
     */
    pushImg: function pushImg(src) {
      var _this = this;

      if (src) {
        this.setData({
          imgSrc: src
        });
      }
      wx.getImageInfo({
        src: this.data.imgSrc,
        success: function success(res) {
          var imgWidth = _this.data.imgWidth;

          var imgHeight = _this.data.imgHeight;
          if (_this.data.init_imgWidth && _this.data.init_imgHeight) {} else if (!_this.data.init_imgHeight && !_this.data.init_imgWidth) {
            imgWidth = res.width;
            imgHeight = res.height;
          } else if (_this.data.init_imgHeight) {
            imgWidth = res.width / res.height * _this.data.init_imgHeight;
          } else if (_this.data.init_imgWidth) {
            imgHeight = res.height / res.width * _this.data.init_imgWidth;
          }
          // 图片非本地路径需要换成本地路径
          if (_this.data.imgSrc.search(/tmp/) == -1) {
            _this.setData({
              imgSrc: res.path,
              imgWidth: imgWidth,
              imgHeight: imgHeight
            });
          } else {
            _this.setData({
              imgWidth: imgWidth,
              imgHeight: imgHeight
            });
          }
          _this._draw();
        },
        fail: function fail(err) {
          _this.setData({
            imgSrc: ''
          });
        }
      });
    },

    /**
     * 设置图片放大缩小
     */
    setScale: function setScale(scale) {
      if (!scale) return;
      // scale = scale <= this.data.min_scale ? this.data.min_scale : scale;
      // scale = scale >= this.data.max_scale ? this.data.max_scale : scale;
      this.setData({
        scale: scale.toFixed(3)
      });
      if (!this.data.canvas_overflow) {
        this._draw();
      }
    },

    /**
     * 设置图片旋转角度
     */
    setRotate: function setRotate(rotate) {
      if (!rotate) return;
      this.setData({
        rotate: rotate.toFixed(2)
      });
      if (!this.data.canvas_overflow) {
        this._draw();
      }
    },
    _init: function _init(flag) {
      // flag-是否需要重新处理图片
      // 初始化canvas
      if (!this.data.ctx) {
        this.data.ctx = wx.createCanvasContext(this.data.el, this);
      }
      this.data.ctx.width = this.data.width;
      this.data.ctx.height = this.data.height;
      if (this.data.imgSrc) {
        if (flag) {
          this.pushImg();
        } else {
          this._draw();
        }
      }
    },

    // 改变截取框大小
    _changeWindowSize: function _changeWindowSize(flag) {
      // flag-是否需要重新处理图片
      if (this.data.width > this.data.info.windowWidth) {
        this.setData({
          width: this.data.info.windowWidth
        });
      }
      if (this.data.height > this.data.info.windowHeight) {
        this.setData({
          height: this.data.info.windowHeight
        });
      }
      this._init(flag); //不需要重新添加图片
    },

    // 开始触摸
    _start: function _start(event) {
      this.data.flag = false;
      if (event.touches.length == 1) {
        // 单指拖动
        this.setData({
          'touch_img_relative[0]': {
            x: event.touches[0].clientX - this.data.imgLeft,
            y: event.touches[0].clientY - this.data.imgTop
          }
        });
      } else {
        // 双指放大
        var width = Math.abs(event.touches[0].clientX - event.touches[1].clientX);
        var height = Math.abs(event.touches[0].clientY - event.touches[1].clientY);
        var touch_img_relative = [{
          x: this.data.imgWidth - (this.data.imgLeft + this.data.imgWidth - event.touches[0].clientX),
          y: this.data.imgHeight - (this.data.imgTop + this.data.imgHeight - event.touches[0].clientY)
        }, {
          x: this.data.imgWidth - (this.data.imgLeft + this.data.imgWidth - event.touches[1].clientX),
          y: this.data.imgHeight - (this.data.imgTop + this.data.imgHeight - event.touches[1].clientY)
        }];
        this.setData({
          first_Hypotenuse: Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2)),
          touch_img_relative: touch_img_relative
        });
      }
      if (!this.data.canvas_overflow) {
        this._draw(); //实时渲染canvas
      }
    },
    _move: function _move(event) {
      if (this.data.flag) return;
      if (!this.data.flag_bright) {
        clearTimeout(time);
        this.setData({
          flag_bright: true
        });
      }
      if (event.touches.length == 1) {
        // 单指拖动
        var left = event.touches[0].clientX - this.data.touch_img_relative[0].x;

        var top = event.touches[0].clientY - this.data.touch_img_relative[0].y;
        // left = left < 0 ? 0 : left;
        // top = top < 0 ? 0 : top;
        this.setData({
          imgLeft: left,
          imgTop: top
        });
      } else {
        // 双指放大
        var width = Math.abs(event.touches[0].clientX - event.touches[1].clientX);

        var height = Math.abs(event.touches[0].clientY - event.touches[1].clientY);

        var hypotenuse = Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2));

        var scale = this.data.scale * (hypotenuse / this.data.first_Hypotenuse);

        var current_deg = 0;
        scale = scale <= this.data.min_scale ? this.data.min_scale : scale;
        scale = scale >= this.data.max_scale ? this.data.max_scale : scale;
        //双指旋转(如果没禁用旋转)
        var touch_img_relative = [{
          x: this.data.imgWidth - (this.data.imgLeft + this.data.imgWidth - event.touches[0].clientX),
          y: this.data.imgHeight - (this.data.imgTop + this.data.imgHeight - event.touches[0].clientY)
        }, {
          x: this.data.imgWidth - (this.data.imgLeft + this.data.imgWidth - event.touches[1].clientX),
          y: this.data.imgHeight - (this.data.imgTop + this.data.imgHeight - event.touches[1].clientY)
        }];
        if (!this.data.disable_rotate) {
          var first_atan = 180 / Math.PI * Math.atan2(touch_img_relative[0].y, touch_img_relative[0].x);
          var first_atan_old = 180 / Math.PI * Math.atan2(this.data.touch_img_relative[0].y, this.data.touch_img_relative[0].x);
          var second_atan = 180 / Math.PI * Math.atan2(touch_img_relative[1].y, touch_img_relative[1].x);
          var second_atan_old = 180 / Math.PI * Math.atan2(this.data.touch_img_relative[1].y, this.data.touch_img_relative[1].x);
          //当前旋转的角度
          var first_deg = first_atan - first_atan_old;

          var second_deg = second_atan - second_atan_old;
          if (first_deg != 0) {
            current_deg = first_deg;
          } else if (second_deg != 0) {
            current_deg = second_deg;
          }
        }
        this.setData({
          rotate: this.data.rotate + current_deg,
          scale: scale,
          first_Hypotenuse: Math.sqrt(Math.pow(width, 2) + Math.pow(height, 2)),
          touch_img_relative: touch_img_relative
        });
      }
      if (!this.data.canvas_overflow) {
        this._draw();
      }
    },

    // 结束操作
    _end: function _end(event) {
      var _this2 = this;

      this.data.flag = true;
      clearTimeout(time);
      time = setTimeout(function () {
        _this2.setData({
          flag_bright: false
        });
        _this2.getImg();
      }, 1000);
    },

    // 点击中间剪裁框处理
    _click: function _click(event) {
      var _this3 = this;

      if (!this.data.imgSrc) {
        this.upload();
        return;
      }
      this._draw();
      var triggerEvent = this.triggerEvent;
      var x = event.detail.x;
      var y = event.detail.y;
      if (x >= this.data.cut_left && x <= this.data.cut_left + this.data.width && y >= this.data.cut_top && y <= this.data.cut_top + this.data.height) {
        wx.canvasToTempFilePath({
          width: this.data.width,
          height: this.data.height,
          destWidth: this.data.width * 3,
          destHeight: this.data.height * 3,
          fileType: 'png',
          quality: this.data.quality,
          canvasId: this.data.el,
          success: function success(res) {
            triggerEvent('cropper', res.tempFilePath);
            _this3._clickCallback && _this3._clickCallback(res.tempFilePath);
          }
        }, this);
      }
    },

    // 渲染
    _draw: function _draw() {
      if (!this.data.imgSrc) return;
      //图片实际大小
      var imgWidth = this.data.imgWidth * this.data.scale;
      var imgHeight = this.data.imgHeight * this.data.scale;
      //canvas和图片的相对距离
      var xpos = this.data.imgLeft - this.data.cut_left;
      var ypos = this.data.imgTop - this.data.cut_top;
      //旋转画布
      this.data.ctx.translate(xpos, ypos);
      this.data.ctx.rotate(this.data.rotate * Math.PI / 180);
      this.data.ctx.drawImage(this.data.imgSrc, -imgWidth / 2, -imgHeight / 2, imgWidth, imgHeight);
      this.data.ctx.draw();
    },

    // 监听器
    _watcher: function _watcher() {
      var _this4 = this;

      Object.keys(this.data.watch).forEach(function (v) {
        _this4._observe(_this4.data, v, _this4.data.watch[v]);
      });
    },
    _observe: function _observe(obj, key, watchFun) {
      var _this5 = this;

      var val = obj[key]; // 给该属性设默认值
      Object.defineProperty(obj, key, {
        configurable: true,
        enumerable: true,
        set: function set(value) {
          val = value;
          watchFun(val, _this5);
        },
        get: function get() {
          return val;
        }
      });
    }
  },
  _preventTouchMove: function _preventTouchMove() {},
  ready: function ready(options) {}
});

/***/ })
/******/ ]);