## @ailjc/react-particle-line

基于 react 的线性粒子背景

![](https://img.shields.io/npm/v/@ailjc/react-particle-line)
![](https://img.shields.io/npm/types/@ailjc/react-particle-line)
[![NPM downloads](http://img.shields.io/npm/dm/@ailjc/react-particle-line.svg?style=flat)](https://npmjs.org/package/@ailjc/react-particle-line)

### Examples

```js
import React from 'react';
import ReactParticleLine from '@ailjc/react-particle-line';

const Example = () => (
  <ReactParticleLine
    lineWidth={0.3}
    dotsNumber={100}
    dotsDistance={100}
    hoverEffect={true}
  >
    {/* ... */}
  </ReactParticleLine>
);

export default Example;
```

### Props

| Prop         | Type    | Default | Description              |
| ------------ | ------- | :-----: | ------------------------ |
| lineWidth    | Number  |   0.3   | connect line width       |
| dotsNumber   | Number  |   100   | dot number               |
| dotsDistance | Number  |   100   | far as points to connect |
| hoverEffect  | Boolean |  true   | mouse hover events       |
