<template>
  <nav class="navbar" @click="toggleMenu">
      <div class="nav-icon" v-bind:class="{open: openedSidebar}" v-if="showIcon">
        <div></div>
      </div>
      <ul class="navbar-nav" v-else>
        <li>
          <p class="username">Username</p>
          <small class="role">RoleName</small>
        </li>
      </ul>
  </nav>
</template>

<script>
export default {
  name: 'NavBar',
  data() {
    return {
      openedSidebar: false,
      showIcon: false,
      windowWidth: window.innerWidth || 0,
    };
  },
  mounted() {
    if (this.windowWidth < 1024) {
      this.showIcon = true;
    }
    this.$nextTick(() => {
      window.addEventListener('resize', this.onResize);
    })
  },
  computed: {
    
  },
  methods: {
    toggleMenu() {
      this.openedSidebar = !this.openedSidebar;
      this.$emit('toggle-sidebar');
    },
    onResize() {
      this.windowWidth = window.innerWidth;
    }
  },
  watch: {
    windowWidth(newWidth) {
      if (newWidth < 1024) {
        this.showIcon = true;
      } else {
        this.showIcon = false;
      }
    }
  }
}
</script>
