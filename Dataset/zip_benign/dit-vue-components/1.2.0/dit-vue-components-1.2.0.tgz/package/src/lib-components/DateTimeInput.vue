<template>
  <div>
    <label>{{label}}</label>
    <div class="input-group">
      <input type="text" class="input-group-field" :data-input="true" @input="onInput" ref="timepicker">
      <label class="input-group-label" v-if="icon">
        <Icon :source="icon" />
      </label>
    </div>
  </div>
</template>

<script>
import Flatpickr from 'flatpickr';
import { Spanish } from 'flatpickr/dist/l10n/es.js';
import Icon from './Icon.vue';

const defaultEvents = [
  'onChange',
  'onClose',
  'onDestroy',
  'onMonthChange',
  'onOpen',
  'onYearChange',
];

const excludedEvents = [
  'onValueUpdate',
  'onDayCreate',
  'onParseConfig',
  'onReady',
  'onPreCalendarPosition',
  'onKeyDown',
]

export default {
  name: 'DateTimeInput',
  components: {Icon},
  props: {
    label: {
      default: null,
      required: false,
    },
    value: {
      default: '',
      required: true,
    },
    disabled: {
      default: () => false,
      required: false,
    },
    mode: {
      default: 'date',
      required: false,
      validator(value) {
        return ['date', 'dateTime', 'time'].includes(value);
      },
    },
    events: {
      type: Array,
      default: () => defaultEvents,
    },
    config: {
      type: Object,
      default: () => ({
        wrap: true,
        defaultDate: null,
        locale: Spanish,
      })
    },
    icon: {
      default: null,
    },
  },
  data() {
    return {
      picker: null,
    };
  },
  mounted() {
    if (this.picker) return;
    let safeConfig = {...this.config};
    if (this.mode !== 'date') {
      safeConfig = {...safeConfig, enableTime: true}
    }

    this.events.forEach((hook) => {
      const globalCallbacks = Flatpickr.defaultConfig[hook] || [];

      const localCallback = (...args) => {
        this.$emit(this.camelToKebab(hook), ...args);
      };

      // Overwrite with merged array
      safeConfig[hook] = this.arrayify(safeConfig[hook] || []).concat(
        globalCallbacks,
        localCallback
      );
    });

    const onCloseCb = (...args) => {
      this.onClose(...args)
    };
    safeConfig['onClose'] = this.arrayify(safeConfig['onClose'] || []).concat(onCloseCb)
    safeConfig.defaultDate = this.value || safeConfig.defaultDate;

    this.picker = new Flatpickr(this.element, safeConfig);
    this.fpInput.addEventListener('blur', this.onBlur);
  },
  computed: {
    element() {
      return this.config.wrap ? this.$refs.timepicker.parentNode : this.$refs.timepicker;
    },
    fpInput() {
      return this.picker.altInput || this.picker.input;
    },
  },
  methods: {
    onInput(event) {
      const input = event.target;
      this.$nextTick().then(() => {
        this.$emit('input', input.value);
      });
    },
    onClose(selectedDates, dateStr) {
      this.$emit('input', dateStr);
    },
    onBlur(event) {
      this.$emit('blur', event.target.value);
    },
    camelToKebab(string) {
      return string.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    },
    arrayify(obj) {
      return obj instanceof Array ? obj : [obj];
    },
  },
  watch: {
    disabled(newState) {
      if (!this.picker) return;

      if (newState) {
        this.fpInput.setAttribute('disabled', newState);
      } else {
        this.fpInput.removeAttribute('disabled');
      }
    },
    config: {
      deep: true,
      handler(newConfig) {
        let safeConfig = {...newConfig};
        const allEvents = defaultEvents.concat(excludedEvents);
        allEvents.forEach((hook) => {
          delete safeConfig[hook];
        });
        this.picker.set(safeConfig);

        ['locale', 'showMonths'].forEach((name) => {
          if (typeof safeConfig[name] !== 'undefined') {
            this.picker.set(name, safeConfig[name]);
          }
        });
      },
    },
    value(newValue) {
      if (newValue === this.$refs.timepicker.value) return;
      this.picker && this.picker.setDate(newValue, true);
    },
  },
  beforeUnmount() {
    if (this.picker) {
      this.fpInput.removeEventListener('blur', this.onBlur);
      this.picker.destroy();
      this.picker = null;
    }
  },
}
</script>
