<template>
  <router-link v-if="to" :to="{ name: to, params }" v-slot="{ href, navigate, isExactActive }">
    <li :class="[hastSlot && 'sub-menu']">
      <a :href="href" @click="navigate" :class="[isExactActive && 'active']">
        <Icon :source="icon || image" />
        {{name}}
      </a>
      <slot></slot>
    </li>
  </router-link>
  <li v-else-if="hastSlot" :class="[hastSlot && 'sub-menu']">
    <a href="">
      <Icon :source="icon || image" />
      {{name}}
    </a>
    <slot></slot>
  </li>
  <li v-else>
    <a href="" @click.stop.prevent="$emit('click')">
      <Icon :source="icon || image" />
      {{name}}
    </a>
  </li>
</template>

<script>
  import Icon from './Icon.vue';
  export default {
    name: 'MenuItem',
    props: {
      name: {
        default: null,
        required: true,
      },
      to: null,
      icon: null,
      image: null,
      params: null
    },
    components: { Icon },
    computed: {
      hastSlot() {
        return !!this.$slots.default;
      }
    }
  }
</script>
