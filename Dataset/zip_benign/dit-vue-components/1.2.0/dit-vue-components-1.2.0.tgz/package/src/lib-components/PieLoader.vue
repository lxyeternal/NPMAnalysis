<template>
  <div class="pie-loader__loader-container">
    <div class="pie-loader__loader-container__circle">
      <div class="pie-loader__loader-container__animated-background">
        <div class="pie-loader__loader-container__animated-background__circle-sm"></div>
      </div>
      <div class="pie-loader__loader-container__line"></div>
      <div class="pie-loader__loader-container__line"></div>
      <div class="pie-loader__loader-container__line"></div>
      <div class="pie-loader__loader-container__line"></div>
      <div class="pie-loader__loader-container__line"></div>
      <div class="pie-loader__loader-container__line"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PieLoader',
}
</script>
