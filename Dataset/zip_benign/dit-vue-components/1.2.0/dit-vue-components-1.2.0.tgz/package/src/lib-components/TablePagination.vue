<template>
  <div class="content-table">
    <div class="table-scroll">
      <table>
        <thead>
          <tr>
            <slot name="head"></slot>
          </tr>
        </thead>
        <tbody>
          <slot></slot>
        </tbody>
      </table>
    </div>
    <nav v-if="pages.length > 1">
      <ul class="pagination">
        <li class="pagination__previous" v-bind:class="{'pagination-disabled': !showPrevButton}">
          <a href="#" @click.stop.prevent="$emit('page-selected', currentPage - 1)" v-if="showPrevButton">Anterior</a>
          <template v-else>Anterior</template>
        </li>
        <li v-bind:class="classesPage(page)" v-for="page in pages" :key="page">
          <a v-if="page !== '...'" href="#" @click.stop.prevent="$emit('page-selected', page)" :aria-label="`Page ${page}`">{{page}}</a>
        </li>
				<li class="pagination__next" v-bind:class="{'pagination-disabled': !showNextButton}">
          <a href="#" @click.stop.prevent="$emit('page-selected', currentPage + 1)" v-if="showNextButton">Siguiente</a>
          <template v-else>Siguiente</template>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
export default {
  name: 'TablePagination',
  props: {
    params: {},
  },
  computed: {
    totalPages() {
      return this.params.last_page || 0;
    },
    currentPage() {
      return this.params.current_page || 0;
    },
    totalPages() {
      return this.params.last_page || 0;
    },
    pages() {
      const delta = 2;
      const left = this.currentPage - delta;
      const right = this.currentPage + delta + 1;
      const range = [];
      const rangeWithDots = [];
      let l;
      for (let page = 1; page <= this.totalPages; page++) {
        if (page === 1 || page === this.totalPages || (page >= left && page < right)) {
          range.push(page);
        }
      }

      for (let page of range) {
        if (l) {
          if (page - l === 2) {
            rangeWithDots.push(l + 1);
          } else if (page - l !== 1) {
            rangeWithDots.push('...');
          }
        }
        rangeWithDots.push(page);
        l = page;
      }

      return rangeWithDots;
    },
    showNextButton() {
      return this.currentPage < this.totalPages;
    },
    showPrevButton() {
      return this.currentPage > 1;
    },
  },
  methods: {
    classesPage(page) {
      return {
        'pagination-current': this.currentPage === page,
        'pagination__ellipsis': page === '...'
      };
    },
  },
}
</script>
