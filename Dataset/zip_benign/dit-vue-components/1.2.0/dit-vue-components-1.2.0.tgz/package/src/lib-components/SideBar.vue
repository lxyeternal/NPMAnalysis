<template>
  <div class="sidebar">
    <div class="logo" v-if="logo">
      <img :src="logo" alt="">
    </div>
    <div class="nav">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SideBar',
  props: {
    logo: {
      default: null,
      required: false,
    },
  },
}
</script>
