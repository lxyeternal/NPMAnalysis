<template>
  <div class="card">
    <div class="content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'Card',
  }
</script>
