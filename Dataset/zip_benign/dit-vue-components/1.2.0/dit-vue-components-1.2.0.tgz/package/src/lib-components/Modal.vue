<template>
  <div class="modal__container">
    <button v-if="label || hasButtonSlot" @click="show = !show" :class="buttonClass">
      <slot name="button"></slot>
      {{label}}
    </button>
    <div class="modal" v-bind:class="classes" v-if="show">
      <div class="modal__backdrop" @click="closeModal"></div>
      <div class="modal__content" :style="styles">
        <div class="modal__content__title">
          <slot name="title"></slot>
          <button class="modal__content__close" @click="closeModal"></button>
        </div>

        <div class="modal__content__body">
          <slot name="content"></slot>
          <slot></slot>
        </div>

        <div class="modal__content__footer">
          <slot name="footer"></slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Modal',
  props: {
    label: {
      default: null,
      required: false,
    },
    width: {
      default: 0.5,
      required: false,
    },
    buttonClass: {
      type: [Array, Object],
      default: () => [],
      required: false,
    },
  },
  data() {
    return {
      show: false,
    };
  },
  computed: {
    classes() {
      return {
        'modal--show': this.show,
      };
    },
    styles() {
      if (this.width < 1) {
        return {
          width: `${100 * this.width}%`,
        };
      } else if (this.width > 200) {
        return {
          width: `${this.width / 16}rem`,
        };
      }

      return {};
    },
    hasButtonSlot() {
      return !!this.$slots.button;
    },
  },
  methods: {
    closeModal() {
      this.$emit('close-modal');
      this.show = false;
    }
  }
}
</script>
