<template>
  <div>
    <div class="table-loader__row" v-for="i in rows" :key="i">
      <div class="table-loader__placeholder" v-for="j in cols" :key="j">
        <div class="table-loader__animated-background"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TableLoader',
  props: {
    cols: {
      default: 1,
    },
    rows: {
      default: 1
    }
  }
}
</script>
