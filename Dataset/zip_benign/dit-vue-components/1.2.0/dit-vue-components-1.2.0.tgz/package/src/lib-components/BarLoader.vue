<template>
  <div class="bar-loader__loader-container">
    <div class="bar-loader__row">
      <div class="bar-loader__placeholder" v-for="bar in bars" :key="bar" v-bind:style="{height: calcHeight() + 'px', width: width}">
        <div class="bar-loader__animated-background"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BarLoader',
  props: {
    bars: {
      default: 3,
    },
  },
  methods: {
    calcHeight() {
      return Math.floor((Math.random() * 300) + 50);
    }
  },
  computed: {
    width() {
      return 50 / this.bars + '%';
    }
  }
}
</script>
