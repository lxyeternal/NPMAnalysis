<template>
  <i :class="[prefix, iconClass, 'icon']" v-if="isWebFont"></i>
  <img class="icon" :src="source" v-else-if="isImage" />
</template>

<script>
export default {
  name: 'Icon',
  props: {
    source: {
      default: '',
      required: true,
    },
    prefix: {
      default: 'mdi',
      required: false,
    },
  },
  computed: {
    iconClass() {
      return `${this.prefix}-${this.source}`;
    },
    isWebFont() {
      if (this.isImage) {
        return false;
      }
      return true;
    },
    isImage() {
      return /^data:image/gi.test(this.source);
    },
  },
}
</script>
