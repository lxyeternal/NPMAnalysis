<template>
  <label>{{label}}
    <div class="input-group">
      <span class="input-group-label">{{currency}}</span>
      <CurrencyInput
        type="text"
        class="input-group-field money-input"
        :currency="null"
        :value="value"
        :readonly="readonly"
        v-on:change="$emit('input', $event)"
      />
    </div>
  </label>
</template>

<script>
import { CurrencyInput } from 'vue-currency-input';

export default {
  name: 'MoneyInput',
  props: {
    currency: {
      default: '$',
      required: false,
    },
    label: {
      default: null,
      required: false,
    },
    value: {
      default: 0,
      required: true,
    },
    readonly: {
      default: false,
      required: false,
    },
  },
  components: { CurrencyInput },
}
</script>
