'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var detectEthereumProvider = require('@metamask/detect-provider');
var ethers = require('ethers');
var nearAPI = require('near-api-js');
var nearSeedPhrase = require('near-seed-phrase');
var BN = require('bn.js');
var isMobile = require('is-mobile');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n["default"] = e;
    return Object.freeze(n);
}

var detectEthereumProvider__default = /*#__PURE__*/_interopDefaultLegacy(detectEthereumProvider);
var nearAPI__namespace = /*#__PURE__*/_interopNamespace(nearAPI);
var BN__default = /*#__PURE__*/_interopDefaultLegacy(BN);
var isMobile__default = /*#__PURE__*/_interopDefaultLegacy(isMobile);

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

const nethIcon = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABiCAYAAACmu3ZJAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAEqVJREFUeJztnHtUVXWbx797n/uBIxcvwNG4CGqCikZKpIFKr5TayItm5qsD1Vuu0bIsXSOrSJmVjk6OC8fpNisTWWW6alLGZLQy31ReFRIjSxAvIAYCcr+c+9nP/MFIL3I4Z1/O4eb7WWv/wTl7P8+zn+/ev9/zuxwYIiLcQ1VVFT799FMcPXoU169fR21tLex2O2QyGQICAhAaGor58+dj2bJlCA8Pv/fyIU1paSlycnLw/fff4+rVq2hpacGoUaMwduxYLFiwAMuXL0dISIh4B/Q3mM1mSk9PJ41GQwBcHnK5nNatW0etra001Kmvr6fU1FRiWdZpTpRKJa1bt446OjpE+ekSpKGhgeLj43kJce8xbdo0qq+vd9vNDzRKSkooLCxMUE5iYmKoqqpKsC8QEVksFkpISBAlxt0jOjqaWlpa3J6M/qa6uprGjBkjKidTp06l9vZ2Qf5ARJSRkSFJjLvH/PnzyWazeSQx/QHHcZSUlCQpJ6tWrRLkE9XV1eTl5eUWQQDQunXrPJSevueDDz6QnA+5XE6XL1/m7RPvvvuu28S4e3z44YceTFPfUF5eTjqdzi352LBhA2+/mDNnjtsFUSgUdPLkSc9ly8PY7XaaPXu22/IxceJE3r6h1+vdLggA8vf3p7KyMg+mzXPs2rXLrbmQy+Vkt9t5+YZCofCIIHefjObmZg+nz72UlZWRVqt1ey7q6up4+YenxLh7zJs3j6xWq4fT6B7sdrvosZirg++YxOOCAKC1a9d6OJXuwRMFzoAUBAC9//77Hk6nNEpKSnhPGQ0JQeRyOX333XceTqs4bDYbxcbGevT+B5wgAMjPz4+uXLni4fQKZ+vWrR6/9wEpCACaMGECNTY2ejjF/Ll8+TKp1er7VxAAFB8fT2az2cOpdo3VaqXp06f3yT0PaEEA0AsvvODhdLtm8+bNfXa/A14QALR7924Pp7x3Ll68SEIHxUFBQQNTEJZlafv27fTggw9KEkQul9Px48c9nPqemM1mio6O5h2nSqWizz77jKxWK/n4+Aw8QYKCgoiI6MaNGzRy5EhJovj6+lJJSYkn89+Dt956i3d8/v7+9MMPP3RdK3buz6OC6PX6LgNnzpwhlUolSZSwsDC6c+eO2xPviAsXLvBuqsLCwnqsZQx4QYiIsrOzJQkCgB577DGPV14mk4kmTZrEK54ZM2ZQTU1NDxuDQhAiog0bNkgW5fnnn5ecdGfwjTE5ObnXXSODRhC73U6LFi2SLEpWVpakpPfG2bNnSSaTufS/du1ap/sCBo0gRERtbW00ZcoUSYLIZDI6cuSIqKT3htFopMjISKd+GYahTZs2ubQ1qAQhIqqoqKCAgABJouh0Orp06RLffLvktddec+pPrVbTgQMHeNkadIIQEeXn50uuvEJDQ3mvsjnjzJkzTpuq4cOH0+nTp3nbG5SCEBHl5ORIEgQAzZo1i0wmE+9k3UtHRwdFRET0aj88PFzw7POgFYSIKD09XbIoaWlpghL2t6xevbpXu3FxcaLewEEtCMdxtHTpUsmi7NixQ3DiTpw4QQzDOLS3ZMkSMhgMgm0SDXJBiIgMBoPkKW6WZSk3N5e3z/b2dgoPD3doa+3atby35Dhi0AtCRFRZWUmBgYGSRBFSeb3yyis9rpfL5W7ZUTkkBCEiOnfunOSVudDQUKqtrXXp694JT29vb8rLyxMcsyOGjCBERPv37++1Xed7zJw502XllZyc3C3WoqIiUfE6YkgJQuSenz6kpqY69dHS0kKZmZmUnp5Ot2/fFh2rI4acIBzH0bJlyySLsm3bNtExSGHICULUWXnNmDFDkiAsy9Lhw4clxSEGTwvCoh/QaDQ4fPgwxowZI9oGx3FYsWIFiouL3RhZ/9MvggBAUFAQcnNzodVqRdtob2/H/PnzUV1d7cbI+pd+EwQAHnroIeTk5IBhGNE2qqursWjRIhiNRjdG1n/0qyAAsHjxYrz99tuSbPz4449IS0sD9fwfCIOSPu/U74XjOFq+fLnkymvLli1ujcsRQ7LKcoTRaJS8A51hGN4LTWIZklWWI9RqNQ4fPowHHnhAtA0iwnPPPYfCwkI3Rta3DBhBACAwMBC5ubnw8vISbcNoNCI5ORlVVVVujKzvGFCCAMC0adOQk5MDlhUf2t3Ky2AwuDGyvmHACQIAKSkpyMzMlGTjwoULSE1NHZSV14Do1O+F4zhasWKF5MorMzPTrXF5ulNn/v8CQej1+j5po00mE+bMmYNz586JtsEwDA4ePIinn37aLTH9/PPPaG1tRWNjI5qamnD79m2cP38eBQUFTmcMqqqqoNfrefkYkG/IXWpqaig4OFjSW6LVaqmwsNDjsVZWVlJWVhbFxMQMzTfkLsXFxZg1axba29tF29Dr9SgoKMDo0aMFXWe2EGoa7GhotqPdQPj+5GmolDL4DtNghL8KD0aMxOTInqX65cuXsWvXLnzyySew2Wy835BBIQgA5ObmIiUlBRzHibYRExODU6dOOZ3Q5Djg8g0LisssKC23orrO5tKuzdIG1noTYXobVi6eirCQkV3flZWVISMjA1lZWQgKCnJpa9AIAgDbtm1Denq6JBspKSn44osvepTV7QYO354z4kyRCc1t4kXnOBu4jhIkzdRi+eJHBF8/IASpqanBzp07odFo8Prrr8PHx6fXc9PS0rBv3z7Rvvz8/FBQUICIiAgAgMVK+PqUAd+dM8JscW+JbG4txYtLg5AQF8H7mn4XpKioCE899VRXhZKcnIxDhw71er7ZbEZiYiLy8/MF+woNDUVeXh4mTpwIoLNpys5tR0OzXVzwPCCyQ8sV49/enAOtRuny/H4V5Ouvv8azzz7brbMOCAhATU2N0+vq6uoQGxuLiooK3r6io6Nx/PhxBAQEgAjY8M43aLZPQ1+NG4OGE9auGI5R/jKn5/XbSP29995DcnJyj8rpmWeecXntqFGjcOTIEeh0Ol6+goODkZeXh4CAABhNVrz4zyfQZBMvRvgYheBrbjcweOe/mnDtltXpeX0uCMdxeOONN/Dyyy/Dbu/eVISGhuKdd97hZWfSpEnYv38/ZDLnT5yvry/y8vKg1+s7xdh4CqSZIjr+SRFKJDyshr+P8NR1GAk7c1pwrbJ3UfpUEIPBgCVLlmDnzp09vmMYBnv27OH91APAwoULsX37dqfnZGdnIyoqCkTAK5tOQeUjXgylgsGfFniDYYG4aDXErDybLYT/2N/SazndZ4I0NDRg3rx5vXbYa9aswdy5cwXbfeONN/DSSy85/G7lypVYtGgRACD9X78BqcWLAQALHtN29QEjfGUYFyy86QI635Tdn7fCaOrZZvaJICUlJZg+fXqvlVF4eDi2bdsm2v7u3bsRHx/f7bOgoCBkZWUBAI58cwm1xsmi7QNAwHAZkmZqun320EQV1CpxGzTqGu3Yd6Stx+ceFyQ/Px/x8fEoLy93+D3LstizZ4+kRSmlUomvvvqqa2wBAJs2bYK/vz/MFjsOHLeAZeWi7QPAyoXeUMi7J1+lZBATqRJts/AXM4qvWLp95lFBcnJyMHfuXNTX1/d6zquvvoqEhATJvoYPH47c3Fz4+Phg9OjRSEtLAwD8y84TUHsHS7IdO0WFiWMdjyHCxygQOMJ5YeGM/XntsNl+b7o8IggRYfPmzUhLS4PFYun1vAkTJmDLli1u8xsZGYmDBw8iPT0dKpUKrW0mVDaFSrKpUTFYOs+71+8ZBoidrIbYBc76ZjvyfzJ3/e12QSwWC9LS0pCZmel0tU4mk2Hv3r3QaDS9niOGpKQkrFmzBgDwn3vPQ6n2k2Qv5XEv+Oqcp8lXxyKylzeID3lnDF1jIrcK0tTUhCeeeAI5OTkuz12/fj3i4uLc6b4Hv1aI36YKACF6OWY/zO+BiZ6ghLdWXDrrm+woLe9sSdwmSHl5OWbOnImTJ0+6PDcqKkrymrkrKqotUOtCRV/PMMCKBd68myK5jMH0SeI7+L8WdzZbbhGkoKAAcXFxKCkpcXmuXC7H3r17oVKJD54Pv15zvY7hjDnTNRgrcIokOFCOBwLFVXO/XLWAyA2CHDp0CHPmzEFtbS2v8zdu3Ijp06dLdeuS0grnc0bOGObN4o+J4srw2MkqyOXCxyatHRyq79jECdLW1oaOjg7s3LkTS5Ys4b3/KTo6GhkZGWJcCuZmtXhBliV5Q6vumdR2A4eCS2aUVdhwo8oKm71n0eKlYTFlnLgO/ma1DaLer7a2Nvj5+cFq5X/TCoUC2dnZUCrFVyN8aevg0GEUN5U7IVSBGZO7N6f1zXaUVVhhtXX2LWYrh9oGO6pq7RjhJ0NIoAxaze/P9qQIJcqrrGhqFbbyeLveLk4QAILEAICMjAxMnTpVrDtBNLSIW4KVy4CVC3Vdk4Y3q22ouN3ZFzFAj8lEO0eobbChrtEGH28WwYEK+PuwXWOT4381CJrib2iRIIgQpk2bho0bN/aFKwCAySzu7XhilhYj/WW4fMOC2no7ZDIGfHoDIqC5jUNzmxlaNQv9KBlGj5Rj7BgFrrtY/+gWt4k8L4hKpcK+ffugUIibGRWDxSpcEF8di8DhMpwuMkLGMpDJxE0aGkwcrlVy+O22DSP9WNysBmw8V4hNFvL85GJmZiYmT5Y20yoUuYjHrKWdw8lCEyzia4FudJgIv1yz8hYDAFQKxrNvSGxsLNavX+9JFw7RqMQ9Z9dvWXGrxoZJEUpEhisgY4W/JUSdRUVzGweizn6Hbz+iVjGee0NUKhX27NnjconVE7iae3KEUsHgqQQt1EoGRSVm/M9fDPitVtjg0mgiVNfZ0NTKQaNiMHGsUtCqot8w1nOCbN26FVFRUZ4y7xRfHSt44chsIfxyzYLMNX54cpYWBiOHE+eN+OasweXGOYuVUFNvR12jHYTOsndhgheq62wQstEycIQcMgCbBUXOg0cffRQfffSRpB/dSIFhgJ+vWNAocBzQ3MZBIWOw+HEvzJikxp1GO67fsuFqpRVmCzDKXwYZy6C+2Y4OI4HjgOZWDo0tHGx24IFAORJjNQjVK3D+khm364Xt91oYr4VMoVBslrJf9l60Wi2OHTuGESNGuM2mGOqb7Ci7KbyHvlppxbgQJUL1cjwyRY1xIQqUV9lQXmXDtVtWKOQMOA6oqbfjTpMdJgvBR8ciPkaNKeNVUCoYVFRbcbG093UgR6hVDJY/qQMbEBAgOGhnbN++HePGjXOrTTFERYibESAC9nzVinZD50MaOVaJzH/yx7NPegMEnC02oajEjMYWDgo5gxmTVVg02wv6kZ31UbuBw9liszMXDokcqwTLAqw7kzd79mysXr3abfakMC5YgRF+4gqKplYO2bm/b+CTyYDHH9Fgyyv+SHhYDSJgfIgCyXO9MDHs946bCDh1wSRqHPTIlM7pGnbhwoWigr4XLy8vfPzxx/3Wb9wLwwCPRouf4r9YasZfCrv/uw4fHYt/fEqHFQt1iItWQ63sXjj8VGrGnSbh+4S9tSyix3e+0ezy5cvh7d37mjFfduzYgfDwcMl23ElirAYqpbgRNwAcONbhsPRVOBi91TbYcemasH7jLn94RNM1Zc8GBgZKHrwlJSVh1apVkmx4Am8ti4SH1aKvt9oIH33Z5rIJslgJp4uMovYKe2kYzI39fZmYBYA333wTiYmJwq0BCAkJQXZ2tqT/6ONJ/mG2600Kzqius+HLbzucnpN/0SR6un/x493XXligc1n1yy+/FCxKeHg4vv32WwQGBooKpi/QqJjOCkkC3xcY8dMVx83RlQoLKmvELRdHBCsQH9P9De56dHx9fXHs2DFkZma67FNYlkVaWhoKCwsHRInrioejVD1uXAhEwN7DbT1G7M1tHH78VXiJCwBaDYMXF+t6TK0w5GDzVG1tLT7//HMcPXoUpaWlqK2thbe3N8aPH4/ExESkpqZi/PjxogLpLyxWwr/va3H5+wxnTAhVYH2qL85dMsFsIRw9ZRC8Kgh0LoS9+icfRIb3HCs5FGSo0mEkbPukmdcva3tjyR+84KNjkX/RhNJy4eIyDPDnlGFd444e399PggCdouz6rEXQSt7fIpMBM6JUOHfJLLiqksuA5/84DLGTex8f3XeCAJ0zux9/1YaiEnHtvxiGebFY9fQwPBjmfOX0vhQE6OyoT5w34r+/6xA11SGEyLFK/DlFBx8e5fd9K8hd6pvtOPC/HbhY6v63xVfHYuk8b8T20l844r4X5C7lVTYcPWVAcZlZ0KKSI0b4yZD0qAaPPaTu8SMfV/xdkHtoaeNw/pIZxWVmXL9lg9XGLz2j/GWIDFcidrIK44IVon4QCvxdEKdYrITfam1dy7NmC8FsJbAMA7WK6dw6NEKG0aPk8Bvmnlnu/wNWcf8As19BPQAAAABJRU5ErkJggg==`;

// @ts-nocheck
const {
  Near,
  Account,
  KeyPair,
  keyStores: {
    BrowserLocalStorageKeyStore
  },
  transactions: {
    addKey,
    deleteKey,
    functionCallAccessKey
  },
  utils: {
    PublicKey,
    format: {
      parseNearAmount
    }
  }
} = nearAPI__namespace;
const NETH_SITE_URL = "https://neth.app";
const PREV_NETH_SITE_URL = "neardefi.github.io/neth";
const NETWORK = {
  testnet: {
    FUNDING_ACCOUNT_ID: "neth.testnet",
    MAP_ACCOUNT_ID: "map.neth.testnet",
    ROOT_ACCOUNT_ID: "testnet"
  },
  mainnet: {
    MAP_ACCOUNT_ID: "nethmap.near",
    ROOT_ACCOUNT_ID: "near"
  }
};
const WS_STORAGE_NAMESPACE = "near-wallet-selector:neth:";
const REFRESH_MSG = `Please refresh the page and try again.`;
const TX_ARGS_ATTEMPT = "__TX_ARGS_ATTEMPT";
const ATTEMPT_SECRET_KEY = "__ATTEMPT_SECRET_KEY";
const ATTEMPT_ACCOUNT_ID = "__ATTEMPT_ACCOUNT_ID";
const ATTEMPT_ETH_ADDRESS = "__ATTEMPT_ETH_ADDRESS";
const APP_KEY_SECRET = "__APP_KEY_SECRET";
const APP_KEY_ACCOUNT_ID = "__APP_KEY_ACCOUNT_ID";
const defaultGas = "200000000000000";
const halfGas = "50000000000000"; /// this is the new account amount 0.21 for account name, keys, contract and 0.01 for mapping contract storage cost

const MIN_NEW_ACCOUNT = parseNearAmount("0.4");
const MIN_NEW_ACCOUNT_THRESH = parseNearAmount("0.49");
const MIN_NEW_ACCOUNT_ASK = parseNearAmount("0.5");
const FUNDING_CHECK_TIMEOUT = 5000; /// lkmfawl

const attachedDepositMapping = parseNearAmount("0.05"); /// Helpers

const defaultStorage = (prefix = "") => ({
  getItem: k => {
    const v = localStorage.getItem(prefix + k);

    if ((v === null || v === void 0 ? void 0 : v.charAt(0)) !== "{") {
      return v;
    }

    try {
      return JSON.parse(v);
    } catch (e) {//   logger.log(e);
    }
  },
  setItem: (k, v) => localStorage.setItem(prefix + k, typeof v === "string" ? v : JSON.stringify(v)),
  removeItem: k => localStorage.removeItem(prefix + k)
});

const defaultLogger = () => ({
  // eslint-disable-next-line
  log: args => console.log(...args)
}); /// NEAR setup


let near, gas, keyStore, logger, storage, connection, networkId, contractAccount, accountSuffix;
const initConnection = ({
  network,
  gas: _gas = defaultGas,
  logger: _logger = defaultLogger(),
  storage: _storage = defaultStorage()
}) => {
  gas = _gas;
  logger = _logger;
  storage = _storage;
  keyStore = new BrowserLocalStorageKeyStore();
  near = new Near(Object.assign(Object.assign({}, network), {
    keyStore
  }));
  connection = near.connection;
  networkId = network.networkId;
  contractAccount = new Account(connection, networkId === "mainnet" ? "near" : networkId);
  accountSuffix = networkId === "mainnet" ? ".near" : "." + networkId;
  const cover = document.createElement("div");
  cover.style.display = "none";
  cover.style.width = "100%";
  cover.style.height = "100vh";
  cover.style.zIndex = "999999";
  cover.style.position = "fixed";
  cover.style.top = "0";
  cover.style.background = "rgba(0, 0, 0, 0.5)";
  document.body.appendChild(cover); /// recovery from unbundled TXs that haven't been broadcast yet

  broadcastTXs();
  return cover;
};
const getConnection = () => {
  return {
    near,
    connection,
    keyStore,
    networkId,
    contractAccount,
    accountSuffix
  };
}; /// helpers

const accountExists = (accountId, ethAddress = null) => __awaiter(void 0, void 0, void 0, function* () {
  try {
    const account = new nearAPI__namespace.Account(connection, accountId);
    yield account.state();

    if (ethAddress) {
      const mapAccountId = yield getNearMap(ethAddress);

      if (mapAccountId) {
        return true;
      }
    }

    return true;
  } catch (e) {
    if (!/no such file|does not exist/.test(e.toString())) {
      throw e;
    }

    return false;
  }
});

const buf2hex = buf => ethers.ethers.utils.hexlify(buf).substring(2);

const pub2hex = publicKey => ethers.ethers.utils.hexlify(PublicKey.fromString(publicKey).data).substring(2); /// account creation and connection flow


const handleCreate = (signer, ethAddress, newAccountId, fundingAccountCB, fundingErrorCB, postFundingCB) => __awaiter(void 0, void 0, void 0, function* () {
  if (networkId === "testnet" && newAccountId.indexOf(".near") > -1 || networkId === "mainnet" && newAccountId.indexOf(".testnet") > -1) {
    return alert("Invalid account name. You do not need to add any .near or .testnet. Please try again.");
  } /// get keypair from eth sig entropy for the near-eth account


  const {
    publicKey: fundingAccountPubKey,
    secretKey: new_secret_key
  } = yield keyPairFromEthSig(signer, fundingKeyPayload()); /// store attempt in localStorage so we can recover and retry / resume contract deployment

  yield storage.setItem(ATTEMPT_ACCOUNT_ID, newAccountId);
  yield storage.setItem(ATTEMPT_SECRET_KEY, new_secret_key);
  yield storage.setItem(ATTEMPT_ETH_ADDRESS, ethAddress);
  return yield createAccount({
    signer,
    newAccountId,
    fundingAccountPubKey,
    fundingAccountCB,
    fundingErrorCB,
    postFundingCB
  });
});

const createAccount = ({
  signer,
  newAccountId,
  fundingAccountPubKey,
  fundingAccountCB,
  fundingErrorCB,
  postFundingCB
}) => __awaiter(void 0, void 0, void 0, function* () {
  // const { publicKey, secretKey } = parseSeedPhrase(process.env.REACT_APP_FUNDING_SEED_PHRASE);
  /// assumes implicit is funded, otherwise will warn and cycle here
  const implicitAccountId = Buffer.from(PublicKey.from(fundingAccountPubKey).data).toString("hex");

  if (fundingAccountCB) {
    fundingAccountCB(implicitAccountId);
  } /// wait for implicit funding here and then continue to createAccount


  const checkImplicitFunded = () => __awaiter(void 0, void 0, void 0, function* () {
    logger.log("checking for funding of implicit account", implicitAccountId);
    const account = new Account(connection, implicitAccountId);

    try {
      const balance = yield account.getAccountBalance();
      const {
        available
      } = balance;
      const diff = new BN__default["default"](available).sub(new BN__default["default"](MIN_NEW_ACCOUNT_THRESH));

      if (diff.lt(new BN__default["default"]("0"))) {
        // alert(`There is not enough NEAR (${formatNearAmount(MIN_NEW_ACCOUNT_ASK, 4)} minimum) to create a new account and deploy NETH contract. Please deposit more and try again.`)
        if (fundingErrorCB) {
          fundingErrorCB(implicitAccountId, diff.abs().toString());
        }

        yield new Promise(r => setTimeout(r, FUNDING_CHECK_TIMEOUT));
        return yield checkImplicitFunded();
      }
    } catch (e) {
      if (!/does not exist/gi.test(e.toString())) {
        throw e;
      }

      logger.log("not funded, checking again");
      yield new Promise(r => setTimeout(r, FUNDING_CHECK_TIMEOUT));
      return yield checkImplicitFunded();
    }

    return true;
  }); /// if not funded properly, return and reload


  if (!(yield checkImplicitFunded())) {
    return window.location.reload();
  }

  logger.log("implicit account funded", implicitAccountId);

  if (postFundingCB) {
    postFundingCB();
  }

  const {
    account,
    ethAddress
  } = yield setupFromStorage(implicitAccountId); /// final checks, last chance to cancel funding if they fail

  if (yield accountExists(newAccountId, ethAddress)) {
    alert(`${newAccountId} already exists. Please try another.`);
    return yield handleCancelFunding(implicitAccountId);
  } /// create account now
  /// get keypair from eth sig entropy for the near-eth account


  const {
    publicKey: new_public_key,
    secretKey: new_secret_key
  } = yield keyPairFromEthSig(signer, unlimitedKeyPayload(newAccountId, ethAddress));
  yield storage.setItem(ATTEMPT_SECRET_KEY, new_secret_key); // remove any existing app key

  yield storage.removeItem(APP_KEY_ACCOUNT_ID);
  yield storage.removeItem(APP_KEY_SECRET);

  try {
    yield account.functionCall({
      contractId: NETWORK[networkId].ROOT_ACCOUNT_ID,
      methodName: "create_account",
      args: {
        new_account_id: newAccountId,
        new_public_key
      },
      gas,
      attachedDeposit: new BN__default["default"](MIN_NEW_ACCOUNT)
    });
  } catch (e) {
    if (!/be created by/.test(JSON.stringify(e))) {
      throw e;
    }

    return handleCancelFunding(implicitAccountId);
  } /// check


  if (!(yield accountExists(newAccountId))) {
    return logger.log(`Account ${newAccountId} could NOT be created. Please refresh the page and try again.`);
  }

  logger.log(`Account ${newAccountId} created successfully.`); /// drain implicit

  yield account.deleteAccount(newAccountId);
  return yield handleMapping();
});

const handleCancelFunding = fundingAccountId => __awaiter(void 0, void 0, void 0, function* () {
  const {
    account
  } = yield setupFromStorage(fundingAccountId);
  const refundAccountId = window.prompt(`There was an error creating the account. You need to refund and try again. Please enter the account you funded from. MAKE SURE IT IS CORRECT. THIS CANNOT BE UNDONE.`); /// drain implicit

  try {
    yield account.deleteAccount(refundAccountId);
  } catch (e) {
    logger.log("Cannot delete implicit");
  } finally {
    /// delete attempt
    yield storage.removeItem(ATTEMPT_ACCOUNT_ID);
    yield storage.removeItem(ATTEMPT_SECRET_KEY);
    yield storage.removeItem(ATTEMPT_ETH_ADDRESS);
  }
});
const handleMapping = () => __awaiter(void 0, void 0, void 0, function* () {
  const {
    account,
    ethAddress
  } = yield setupFromStorage();

  try {
    yield account.functionCall({
      contractId: NETWORK[networkId].MAP_ACCOUNT_ID,
      methodName: "set",
      args: {
        eth_address: ethAddress
      },
      gas,
      attachedDeposit: new BN__default["default"](attachedDepositMapping)
    });
    logger.log(`Account mapping successful`);
  } catch (e) {
    logger.log(e);
    return logger.log(`Account mapping failed`);
  }

  return yield handleDeployContract();
});
const handleDeployContract = () => __awaiter(void 0, void 0, void 0, function* () {
  const {
    account
  } = yield setupFromStorage();
  const contractPath = window === null || window === void 0 ? void 0 : window.contractPath; // logger.log(contractPath)

  const ab = yield fetch(contractPath).then(res => res.arrayBuffer());
  const contractBytes = new Uint8Array(ab); // logger.log("contractBytes.length", contractBytes.length);

  try {
    yield account.deployContract(contractBytes);
    logger.log(`Contract deployed successfully.`);
  } catch (e) {
    logger.log(e);
    return logger.log(`Contract deployment failed. ${REFRESH_MSG}`);
  }

  return yield handleSetupContract();
});
const handleSetupContract = () => __awaiter(void 0, void 0, void 0, function* () {
  const {
    account,
    ethAddress
  } = yield setupFromStorage();

  try {
    yield account.functionCall({
      contractId: account.accountId,
      methodName: "setup",
      args: {
        eth_address: ethAddress
      },
      gas
    });
    logger.log(`Contract setup successfully.`);
  } catch (e) {
    logger.log(e);
    return logger.log(`Contract setup failed. ${REFRESH_MSG}`);
  }

  return yield handleKeys();
});
const handleKeys = () => __awaiter(void 0, void 0, void 0, function* () {
  var _a, _b, _c;

  const {
    account,
    newAccountId,
    ethAddress
  } = yield setupFromStorage();
  const accessKeys = yield account.getAccessKeys(); // keys are done

  if (accessKeys.length !== 1 || ((_b = (_a = accessKeys[0]) === null || _a === void 0 ? void 0 : _a.access_key) === null || _b === void 0 ? void 0 : _b.permission) !== "FullAccess") {
    return;
  }

  const publicKey = PublicKey.from(accessKeys[0].public_key);
  const actions = [// delete the full access key
  deleteKey(publicKey), // limited to execute, unlimited allowance
  addKey(publicKey, functionCallAccessKey(newAccountId, ["execute"]))];

  try {
    const res = yield account.signAndSendTransaction({
      receiverId: newAccountId,
      actions
    });

    if (((_c = res === null || res === void 0 ? void 0 : res.status) === null || _c === void 0 ? void 0 : _c.SuccessValue) !== "") {
      return logger.log(`Key rotation failed. ${REFRESH_MSG}`);
    }

    logger.log(`Key rotation successful.`);
  } catch (e) {
    logger.log(e);
    return logger.log(`Key rotation failed. ${REFRESH_MSG}`);
  }

  return yield handleCheckAccount({
    ethAddress
  });
}); /// waterfall check everything about account and fill in missing pieces

const handleCheckAccount = ({
  signer = null,
  ethAddress = null,
  fundingAccountCB = null,
  fundingErrorCB = null,
  postFundingCB = null
}) => __awaiter(void 0, void 0, void 0, function* () {
  var _d, _e;

  const setup = yield setupFromStorage();
  let {
    newAccountId
  } = setup;
  const {
    newSecretKey
  } = setup;
  const mapAccountId = yield getNearMap(ethAddress);

  if (!mapAccountId) {
    // alert("create account first");
    logger.log("No account mapping exists.");
  } else {
    newAccountId = mapAccountId;
  }

  logger.log("Checking account created.");

  if (!(yield accountExists(newAccountId))) {
    const keyPair = KeyPair.fromString(newSecretKey);
    return createAccount({
      signer,
      newAccountId,
      fundingAccountPubKey: keyPair.getPublicKey().toString(),
      fundingAccountCB,
      fundingErrorCB,
      postFundingCB
    });
  }

  const account = new Account(connection, newAccountId);
  logger.log("Checking account address mapping.");
  const mapRes = yield account.viewFunction({
    contractId: NETWORK[networkId].MAP_ACCOUNT_ID,
    methodName: "get_eth",
    args: {
      account_id: newAccountId
    }
  });

  if (mapRes === null) {
    return handleMapping();
  }

  logger.log("Checking contract deployed.");
  const state = yield account.state();

  if (state.code_hash === "11111111111111111111111111111111") {
    return handleDeployContract();
  }

  logger.log("Checking contract setup.");

  try {
    const ethRes = yield account.viewFunction({
      contractId: newAccountId,
      methodName: "get_address"
    }); // any reason the address wasn't set properly

    if (!ethRes || !ethRes.length) {
      return handleSetupContract();
    }
  } catch (e) {
    // not set at all (wasm error unreachable storage value)
    logger.log(e);
    return handleSetupContract();
  }

  logger.log("Checking access keys.");
  const accessKeys = yield account.getAccessKeys();

  if (accessKeys.length === 1 && ((_e = (_d = accessKeys[0]) === null || _d === void 0 ? void 0 : _d.access_key) === null || _e === void 0 ? void 0 : _e.permission) === "FullAccess") {
    return handleKeys();
  }

  logger.log("Account created.");
  logger.log("Contract deployed and setup.");
  logger.log("Mapping added.");
  logger.log("Keys rotated.");
  yield storage.removeItem(ATTEMPT_ACCOUNT_ID);
  yield storage.removeItem(ATTEMPT_SECRET_KEY);
  yield storage.removeItem(ATTEMPT_ETH_ADDRESS);
  return {
    account
  };
}); /// on same domain as setup

const hasAppKey = accessKeys => accessKeys.some(k => {
  var _a, _b;

  const functionCallPermission = (_b = (_a = k === null || k === void 0 ? void 0 : k.access_key) === null || _a === void 0 ? void 0 : _a.permission) === null || _b === void 0 ? void 0 : _b.FunctionCall;
  return functionCallPermission.allowance !== null && functionCallPermission.method_names[0] === "execute";
});
const handleRefreshAppKey = (signer, ethAddress) => __awaiter(void 0, void 0, void 0, function* () {
  var _f;

  const {
    account,
    accountId
  } = yield getUnlimitedKeyAccount(signer, ethAddress); // now refresh app key

  const nonce = parseInt(yield account.viewFunction({
    contractId: accountId,
    methodName: "get_nonce"
  }), 16).toString(); // new public key based on current nonce which will become the app_key_nonce in contract after this TX

  const {
    publicKey,
    secretKey
  } = yield keyPairFromEthSig(signer, appKeyPayload(accountId, nonce)); // logger.log(publicKey);

  const public_key = pub2hex(publicKey);
  const actions = [{
    type: "AddKey",
    public_key,
    allowance: parseNearAmount("1"),
    receiver_id: accountId,
    method_names: "execute"
  }]; /// check keys, find old app key, delete that first

  const accessKeys = yield account.getAccessKeys();

  if (hasAppKey(accessKeys)) {
    // old public key based on current app_key_nonce
    const appKeyNonce = parseInt(yield account.viewFunction({
      contractId: accountId,
      methodName: "get_app_key_nonce"
    }), 16).toString();
    const {
      publicKey: oldPublicKey
    } = yield keyPairFromEthSig(signer, appKeyPayload(accountId, appKeyNonce));
    const oldPublicKeyHex = pub2hex(oldPublicKey);
    actions.unshift({
      type: "DeleteKey",
      public_key: oldPublicKeyHex
    });
  } /// get args for execute call


  const args = yield ethSignJson(signer, {
    nonce,
    receivers: [accountId],
    transactions: [{
      actions
    }]
  });
  const res = yield account.functionCall({
    contractId: accountId,
    methodName: "execute",
    args,
    gas
  });

  if (((_f = res === null || res === void 0 ? void 0 : res.status) === null || _f === void 0 ? void 0 : _f.SuccessValue) !== "") {
    return logger.log(`App key rotation unsuccessful. ${REFRESH_MSG}`);
  }

  yield storage.removeItem(APP_KEY_SECRET);
  yield storage.removeItem(APP_KEY_ACCOUNT_ID);
  return {
    publicKey: public_key,
    secretKey
  };
});
const handleUpdateContract = (signer, ethAddress) => __awaiter(void 0, void 0, void 0, function* () {
  var _g;

  const {
    account,
    accountId
  } = yield getUnlimitedKeyAccount(signer, ethAddress);
  const contractPath = window === null || window === void 0 ? void 0 : window.contractPath;
  const ab = yield fetch(contractPath).then(res => res.arrayBuffer());
  const contractBytes = new Uint8Array(ab);
  const actions = [{
    type: "DeployContract",
    code: buf2hex(contractBytes)
  }];
  const nonce = parseInt(yield account.viewFunction({
    contractId: accountId,
    methodName: "get_nonce"
  }), 16).toString();
  const args = yield ethSignJson(signer, {
    nonce,
    receivers: [accountId],
    transactions: [{
      actions
    }]
  });
  const res = yield account.functionCall({
    contractId: accountId,
    methodName: "execute",
    args,
    gas
  });

  if (((_g = res === null || res === void 0 ? void 0 : res.status) === null || _g === void 0 ? void 0 : _g.SuccessValue) !== "") {
    return logger.log(`Redeply contract unsuccessful. ${REFRESH_MSG}`);
  }
}); /// account disconnecting flow

const handleDisconnect = (signer, ethAddress) => __awaiter(void 0, void 0, void 0, function* () {
  var _h, _j;

  const {
    account,
    accountId,
    secretKey
  } = yield getUnlimitedKeyAccount(signer, ethAddress);
  const {
    seedPhrase,
    publicKey,
    secretKey: newSecretKey
  } = nearSeedPhrase.generateSeedPhrase();

  const _seedPhrase = window.prompt("Copy this down and keep it safe!!! This is your new seed phrase!!!", seedPhrase);

  if (seedPhrase !== _seedPhrase) {
    return alert("There was an error copying seed phrase. Nothing has been done. Please try again.");
  }

  const oldUnlimitedKey = KeyPair.fromString(secretKey);
  const actions = [{
    type: "DeleteKey",
    public_key: pub2hex(oldUnlimitedKey.getPublicKey().toString())
  }, {
    type: "AddKey",
    public_key: pub2hex(publicKey),
    // special case will add full access key
    allowance: "0"
  }, {
    type: "FunctionCall",
    method_name: "remove_storage",
    args: "",
    amount: "0",
    gas: halfGas
  }, {
    type: "DeployContract",
    code: ""
  }]; /// check keys, find old app key, delete that first

  const accessKeys = yield account.getAccessKeys();

  if (accessKeys.some(k => {
    var _a, _b;

    const functionCallPermission = (_b = (_a = k === null || k === void 0 ? void 0 : k.access_key) === null || _a === void 0 ? void 0 : _a.permission) === null || _b === void 0 ? void 0 : _b.FunctionCall;
    return (functionCallPermission === null || functionCallPermission === void 0 ? void 0 : functionCallPermission.allowance) !== null && (functionCallPermission === null || functionCallPermission === void 0 ? void 0 : functionCallPermission.method_names[0]) === "execute";
  })) {
    const appKeyNonce = parseInt(yield account.viewFunction({
      contractId: accountId,
      methodName: "get_app_key_nonce"
    }), 16).toString();
    const {
      publicKey: oldPublicKey
    } = yield keyPairFromEthSig(signer, appKeyPayload(accountId, appKeyNonce));
    const oldPublicKeyHex = pub2hex(oldPublicKey);
    actions.unshift({
      type: "DeleteKey",
      public_key: oldPublicKeyHex
    });
  } /// get args for execute call


  const nonce = parseInt(yield account.viewFunction({
    contractId: accountId,
    methodName: "get_nonce"
  }), 16).toString();
  const args = yield ethSignJson(signer, {
    nonce,
    receivers: [accountId],
    transactions: [{
      actions
    }]
  });
  const res = yield account.functionCall({
    contractId: accountId,
    methodName: "execute",
    args,
    gas
  });

  if (((_h = res === null || res === void 0 ? void 0 : res.status) === null || _h === void 0 ? void 0 : _h.SuccessValue) !== "") {
    return logger.log("app key rotation unsuccessful");
  } // remove the mapping (can do this later if user has FAK)


  keyStore.setKey(networkId, accountId, newSecretKey);

  try {
    const mapRes = yield account.functionCall({
      contractId: NETWORK[networkId].MAP_ACCOUNT_ID,
      methodName: "del",
      args: {},
      gas
    });
    logger.log(mapRes);

    if (((_j = mapRes === null || mapRes === void 0 ? void 0 : mapRes.status) === null || _j === void 0 ? void 0 : _j.SuccessValue) !== "") {
      logger.log("account mapping removal failed");
    }
  } catch (e) {
    logger.log(e);
  }

  return {
    account
  };
}); /// helpers for account creation and connection domain

const setupFromStorage = (accountId = "") => __awaiter(void 0, void 0, void 0, function* () {
  const newAccountId = accountId.length > 0 ? accountId : yield storage.getItem(ATTEMPT_ACCOUNT_ID);
  const newSecretKey = yield storage.getItem(ATTEMPT_SECRET_KEY);
  const ethAddress = yield storage.getItem(ATTEMPT_ETH_ADDRESS);
  const account = new Account(connection, newAccountId);
  let keyPair;

  if (newSecretKey) {
    keyPair = KeyPair.fromString(newSecretKey);
    keyStore.setKey(networkId, newAccountId, keyPair);
  }

  return {
    newAccountId,
    newSecretKey,
    ethAddress,
    account,
    keyPair
  };
});

const getUnlimitedKeyAccount = (signer, ethAddress, tryPrevUrl = false) => __awaiter(void 0, void 0, void 0, function* () {
  let accountId,
      secretKey = yield storage.getItem(ATTEMPT_SECRET_KEY); // if unlimited allowance access key is not in localStorage user will have to sign to generate it

  if (!secretKey) {
    // TODO remove dep on near-utils
    // use any random near account to check mapping
    accountId = yield getNearMap(ethAddress);
    const {
      secretKey: _secretKey
    } = yield keyPairFromEthSig(signer, unlimitedKeyPayload(accountId, tryPrevUrl));
    secretKey = _secretKey;
  } else {
    accountId = yield storage.getItem(ATTEMPT_ACCOUNT_ID);
  }

  const account = new Account(connection, accountId);
  const keyPair = KeyPair.fromString(secretKey);
  const publicKey = keyPair.getPublicKey().toString(); /// check if access key matches

  const accessKeys = yield account.getAccessKeys();

  if (!accessKeys.some(({
    public_key
  }) => publicKey === public_key)) {
    return yield getUnlimitedKeyAccount(signer, ethAddress, true);
  }

  keyStore.setKey(networkId, accountId, keyPair);
  return {
    account,
    accountId,
    secretKey
  };
});
/**
 * The access key payloads, unlimited and limited
 */


const appKeyPayload = (accountId, appKeyNonce) => ({
  WARNING: `Creating key for: ${accountId}`,
  nonce: appKeyNonce,
  description: `ONLY sign this on apps you trust! This key CAN use up to 1 N for transactions.`
});

const unlimitedKeyPayload = (accountId, tryPrevUrl) => ({
  WARNING: `Creates a key with access to your (new) paired NEAR Account: ${accountId}`,
  description: `ONLY sign this message on this website: ${tryPrevUrl ? PREV_NETH_SITE_URL : NETH_SITE_URL}`
});

const fundingKeyPayload = () => ({
  WARNING: `This creates a full access key in your localStorage to a funding account you will be sending NEAR to.`,
  description: `ONLY sign this message on this website: ${NETH_SITE_URL}`
});
/**
 * main domain, types and eth signTypedData method
 */


const domain = {
  name: "NETH",
  version: "1",
  // chainId: 1, // aurora
  chainId: 1313161554 // aurora

};
const HEADER_OFFSET = "NETH";
const HEADER_PAD = 8;
const RECEIVER_MARKER = "|~-_NETH~-_-~RECEIVER_-~|";
const PREFIX = "|NETH_";
const SUFFIX = "_NETH|";

const pack = elements => elements.map(el => {
  const str = typeof el === "string" ? el : Object.entries(el).map(([k, v]) => `${PREFIX}${k}:${typeof v === "string" ? v : JSON.stringify(v)}${SUFFIX}`).join("");
  const len = str.length.toString().padStart(HEADER_PAD, "0");
  return HEADER_OFFSET + len + "__" + str;
}).join("");

const ethSignJson = (signer, json) => __awaiter(void 0, void 0, void 0, function* () {
  const Transaction = [];
  const types = {
    Transaction
  };
  Object.entries(json).forEach(([k]) => {
    types.Transaction.push({
      type: "string",
      name: k
    });
  }); /// convenience for devs so they can pass in JSON
  /// hoist any functionCall args containing receiver|account in their key to top level receivers
  /// replaces value with marker, contract fills in marker

  if (json.transactions) {
    Object.values(json.transactions).forEach((tx, i) => {
      tx.actions.forEach(action => {
        if (!action.args) {
          return;
        }

        if (Buffer.isBuffer(action.args)) {
          action.args = "0x" + action.args.toString("hex");
          return;
        }

        Object.entries(action.args).forEach(([key, value]) => {
          /// TODO include check on value to determine valid account_id to be replaced
          if (/receiver_id|account_id/g.test(key)) {
            action.args[key] = RECEIVER_MARKER;
            json.receivers.splice(i + 1, 0, value);
          }
        });
      });
    });
    json.transactions = pack(json.transactions.map(({
      actions
    }) => pack(actions)));
  }

  if (json.receivers) {
    const numReceivers = json.receivers.length.toString();
    json.receivers = HEADER_OFFSET + json.receivers.join(",").length.toString().padStart(HEADER_PAD, "0") + "__" + json.receivers.join(",");
    json.receivers = json.receivers.substring(0, 4) + numReceivers.padStart(3, "0") + json.receivers.substring(7);
  }

  const sig = yield signer._signTypedData(domain, types, json);
  const args = {
    sig,
    msg: json
  }; // logger.log('\nargs\n', JSON.stringify(args, null, 4), '\n');

  return args;
});

const keyPairFromEthSig = (signer, json) => __awaiter(void 0, void 0, void 0, function* () {
  const {
    sig
  } = yield ethSignJson(signer, json);
  const sigHash = ethers.ethers.utils.id(sig); /// use 32 bytes of entropy from hash of signature to create NEAR keyPair

  return nearSeedPhrase.generateSeedPhrase(sigHash.substring(2, 34));
});
/**
 * Used by apps to signIn and signAndSendTransactions
 */
/// ethereum


const getEthereum = () => __awaiter(void 0, void 0, void 0, function* () {
  var _k, _l;

  const provider = yield detectEthereumProvider__default["default"]();

  if (!provider) {
    return alert("Please install/activate MetaMask and try again.");
  }

  try {
    yield window.ethereum.request({
      method: "wallet_switchEthereumChain",
      params: [{
        chainId: "0x" + domain.chainId.toString(16)
      }]
    });
  } catch (e) {
    logger.log(e);
    const code = (e === null || e === void 0 ? void 0 : e.code) || ((_l = (_k = e === null || e === void 0 ? void 0 : e.data) === null || _k === void 0 ? void 0 : _k.originalError) === null || _l === void 0 ? void 0 : _l.code);

    if (code !== 4902) {
      throw e;
    }

    try {
      yield window.ethereum.request({
        method: "wallet_addEthereumChain",
        params: [{
          chainId: "0x" + domain.chainId.toString(16),
          chainName: "Aurora Mainnet",
          nativeCurrency: {
            name: "Ethereum",
            symbol: "ETH",
            decimals: 18
          },
          blockExplorerUrls: ["https://explorer.mainnet.aurora.dev/"],
          rpcUrls: ["https://mainnet.aurora.dev"]
        }]
      });
    } catch (e2) {
      alert('Error adding chain. Please click "Choose Ethereum Account" and add the Aurora Network to continue.');
      throw e2;
    }
  }

  const ethersProvider = new ethers.ethers.providers.Web3Provider(window.ethereum);
  const accounts = yield ethersProvider.listAccounts();

  if (accounts.length === 0) {
    yield ethersProvider.send("eth_requestAccounts", []);
  }

  const signer = ethersProvider.getSigner();
  return {
    signer,
    ethAddress: yield signer.getAddress()
  };
});
const switchEthereum = () => __awaiter(void 0, void 0, void 0, function* () {
  const provider = yield detectEthereumProvider__default["default"]();
  yield provider.send("wallet_requestPermissions", [{
    eth_accounts: {}
  }]);
  const ethersProvider = new ethers.ethers.providers.Web3Provider(window.ethereum);
  const signer = ethersProvider.getSigner();
  return {
    signer,
    ethAddress: yield signer.getAddress()
  };
}); /// near

const getNearMap = eth_address => __awaiter(void 0, void 0, void 0, function* () {
  return contractAccount.viewFunction({
    contractId: NETWORK[networkId].MAP_ACCOUNT_ID,
    methodName: "get_near",
    args: {
      eth_address
    }
  });
});
const getNear = () => __awaiter(void 0, void 0, void 0, function* () {
  const secretKey = yield storage.getItem(APP_KEY_SECRET);
  const accountId = yield storage.getItem(APP_KEY_ACCOUNT_ID);

  if (!secretKey || !accountId) {
    const ethRes = yield getEthereum();
    const res = yield getAppKey(ethRes);

    if (!res) {
      return false;
    }

    return yield getNear();
  }

  const account = new Account(connection, accountId);
  const keyPair = KeyPair.fromString(secretKey);
  keyStore.setKey(networkId, accountId, keyPair);
  return {
    account,
    accountId,
    keyPair,
    secretKey
  };
});
const signIn = getNear;
const signOut = () => __awaiter(void 0, void 0, void 0, function* () {
  const accountId = yield storage.getItem(APP_KEY_ACCOUNT_ID);

  if (!accountId) {
    return logger.log("already signed out");
  }

  yield storage.removeItem(APP_KEY_SECRET);
  yield storage.removeItem(APP_KEY_ACCOUNT_ID);
  return {
    accountId
  };
});
const verifyOwner = ({
  message,
  provider,
  account
}) => __awaiter(void 0, void 0, void 0, function* () {
  let accountId;

  if (!account) {
    const nearAccount = yield getNear();

    if (nearAccount) {
      ({
        account,
        accountId
      } = nearAccount);
    }
  } else {
    ({
      accountId
    } = account);
  }

  if (!account) {
    throw new Error("Wallet not signed in");
  }

  const pubKey = yield account.connection.signer.getPublicKey(accountId, networkId);
  const publicKey = Buffer.from(pubKey.data).toString("base64");
  const block = yield provider.block({
    finality: "final"
  });
  const blockId = block.header.hash;
  const data = {
    accountId,
    message,
    blockId,
    publicKey,
    keyType: pubKey.keyType
  };
  const encoded = JSON.stringify(data);
  const signed = yield account.connection.signer.signMessage(new Uint8Array(Buffer.from(encoded)), accountId, networkId);
  return Object.assign(Object.assign({}, data), {
    signature: Buffer.from(signed.signature).toString("base64")
  });
});
const isSignedIn = () => __awaiter(void 0, void 0, void 0, function* () {
  /// init defaultStorage here because it's not initialized until initConnection
  const tempStorage = defaultStorage(WS_STORAGE_NAMESPACE);
  return !!(yield tempStorage.getItem(APP_KEY_SECRET)) || !!(yield tempStorage.getItem(APP_KEY_ACCOUNT_ID));
}); // const promptValidAccountId = async (msg) => {
//   const newAccountId = window.prompt(msg);
//   if (!newAccountId) {
//     throw new Error("NETH Error: failed to pick valid NEAR account name");
//   }
//   if (
//     newAccountId.length < 2 ||
//     newAccountId.indexOf(".") > -1 ||
//     !ACCOUNT_REGEX.test(newAccountId) ||
//     newAccountId.length > 64
//   ) {
//     return promptValidAccountId(
//       `account is invalid (a-z, 0-9 and -,_ only; min 2; max 64; ${accountSuffix} applied automatically)`
//     );
//   }
//   if (await accountExists(newAccountId)) {
//     return promptValidAccountId(`account already exists`);
//   }
//   return newAccountId;
// };

const getAppKey = ({
  signer,
  ethAddress: eth_address
}) => __awaiter(void 0, void 0, void 0, function* () {
  const accountId = yield getNearMap(eth_address);

  if (!accountId) {
    const tryAgain = window.confirm(`Ethereum account ${eth_address} is not connected to a NETH account. Would you like to try another Ethereum account?`);

    if (tryAgain) {
      try {
        const {
          signer: _signer,
          ethAddress
        } = yield switchEthereum();
        return yield getAppKey({
          signer: _signer,
          ethAddress
        });
      } catch (e) {
        logger.log(e);
      }

      return;
    }

    const nethURL = `${NETH_SITE_URL}/${networkId === "testnet" ? "?network=testnet" : ""}`;
    window.prompt(`We couldn't find a NETH account. To set up a NETH account visit`, nethURL); // throw new Error(`Ethereum account is not connected to a NETH account. To set up a NETH account visit: ${nethURL}`)
    // /// prompt for near account name and auto deploy
    // const newAccountId = await promptValidAccountId(
    // 	`The Ethereum address ${eth_address} is not connected to a NEAR account yet. Select a NEAR account name and we'll create and connect one for you.`,
    // );
    // const { account } = await handleCreate(signer, eth_address, newAccountId + accountSuffix);
    // accountId = account.accountId;
  }

  const appKeyNonce = parseInt(yield contractAccount.viewFunction({
    contractId: accountId,
    methodName: "get_app_key_nonce"
  }), 16).toString();
  const {
    publicKey,
    secretKey
  } = yield keyPairFromEthSig(signer, appKeyPayload(accountId, appKeyNonce));
  const account = new Account(connection, accountId); // check that app key exists on account

  const accessKeys = yield account.getAccessKeys();

  if (!hasAppKey(accessKeys)) {
    yield handleRefreshAppKey(signer, eth_address);
  }

  const keyPair = KeyPair.fromString(secretKey);
  keyStore.setKey(networkId, accountId, keyPair);
  yield storage.setItem(APP_KEY_SECRET, secretKey);
  yield storage.setItem(APP_KEY_ACCOUNT_ID, account.accountId);
  return {
    publicKey,
    secretKey,
    account
  };
});

const broadcastTXs = () => __awaiter(void 0, void 0, void 0, function* () {
  const nearAccount = yield getNear();

  if (!nearAccount) {
    logger.log("NETH: ERROR broadcasting tx. No account found.");
    return;
  }

  const {
    account,
    accountId
  } = nearAccount;
  const args = yield storage.getItem(TX_ARGS_ATTEMPT);

  if (!args || args.length === 0) {
    return;
  }

  const res = [];

  while (args.length > 0) {
    const currentArgs = args.shift();
    logger.log("NETH: broadcasting tx", currentArgs);

    try {
      const tx = yield account.functionCall({
        contractId: accountId,
        methodName: "execute",
        args: currentArgs,
        gas
      });
      yield storage.setItem(TX_ARGS_ATTEMPT, args);
      res.push(tx);
    } catch (e) {
      logger.log("NETH: ERROR broadcasting tx", e);
    }
  }

  yield storage.removeItem(TX_ARGS_ATTEMPT);
  return res;
});

const signAndSendTransactions = ({
  transactions,
  bundle
}) => __awaiter(void 0, void 0, void 0, function* () {
  const ethRes = yield getEthereum();
  const {
    signer
  } = ethRes;
  const nearAccount = yield getNear();

  if (!nearAccount) {
    logger.log("NETH: ERROR signing and sending transactions. No account found.");
    return;
  }

  const {
    account,
    accountId
  } = nearAccount;
  const receivers = transactions.map(({
    receiverId
  }) => receiverId);
  const transformedTxs = transactions.map(({
    receiverId,
    actions
  }) => ({
    actions: convertActions(actions, accountId, receiverId)
  }));
  const nonce = parseInt(yield account.viewFunction({
    contractId: accountId,
    methodName: "get_nonce"
  }), 16);
  const args = [];

  if (!bundle) {
    for (let i = 0; i < transformedTxs.length; i++) {
      args.push(yield ethSignJson(signer, {
        nonce: (nonce + i).toString(),
        receivers: [receivers[i]],
        transactions: [transformedTxs[i]]
      }));
    }
  } else {
    args.push(yield ethSignJson(signer, {
      nonce: nonce.toString(),
      receivers,
      transactions: transformedTxs
    }));
  }

  yield storage.setItem(TX_ARGS_ATTEMPT, args);
  const res = yield broadcastTXs();
  return res;
}); /// helpers

const convertActions = (actions, accountId, receiverId) => actions.map(_action => {
  const {
    enum: type
  } = _action;
  const {
    gas: _gas,
    publicKey,
    methodName,
    args,
    deposit,
    accessKey,
    code
  } = _action[type] || _action;
  const action = {
    type: type && type[0].toUpperCase() + type.substr(1) || "FunctionCall",
    gas: _gas && _gas.toString() || undefined,
    public_key: publicKey && pub2hex(publicKey) || undefined,
    method_name: methodName,
    args: args || undefined,
    code: code || undefined,
    amount: deposit && deposit.toString() || undefined,
    permission: undefined
  };
  Object.keys(action).forEach(k => {
    if (action[k] === undefined) {
      delete action[k];
    }
  });

  if (accessKey) {
    if (receiverId === accountId) {
      action.allowance = parseNearAmount("1");
      action.method_names = "execute";
      action.receiver_id = accountId;
    } else if (accessKey.permission.enum === "functionCall") {
      const {
        receiverId: _receiverId,
        methodNames,
        allowance
      } = accessKey.permission.functionCall;
      action.receiver_id = _receiverId;
      action.allowance = allowance && allowance.toString() || parseNearAmount("0.25");
      action.method_names = methodNames.join(",");
    }
  }

  return action;
});

const isInstalled = () => __awaiter(void 0, void 0, void 0, function* () {
  yield detectEthereumProvider__default["default"]({
    timeout: 100
  });
  return !!window.ethereum;
});

let bundle = true;
let useCover = false;
let customGas;

const Neth = ({
  metadata,
  logger,
  store,
  storage,
  options,
  provider
}) => __awaiter(void 0, void 0, void 0, function* () {
  const cover = initConnection({
    network: options.network,
    gas: customGas,
    logger,
    storage
  });

  const isValidActions = actions => {
    return actions.every(x => x.type === "FunctionCall");
  };

  const transformActions = actions => {
    const validActions = isValidActions(actions);

    if (!validActions) {
      throw new Error(`Only 'FunctionCall' actions types are supported by ${metadata.name}`);
    }

    return actions.map(x => x.params);
  };

  const signTransactions = transactions => __awaiter(void 0, void 0, void 0, function* () {
    logger.log("NETH:signAndSendTransactions", {
      transactions
    });
    const {
      contract
    } = store.getState();

    if (!(yield isSignedIn()) || !contract) {
      throw new Error("Wallet not signed in");
    }

    if (useCover) {
      cover.style.display = "block";
    }

    const transformedTxs = transactions.map(({
      receiverId,
      actions
    }) => ({
      receiverId: receiverId || contract.contractId,
      actions: transformActions(actions)
    }));
    let res;

    try {
      res = yield signAndSendTransactions({
        transactions: transformedTxs,
        bundle
      });
    } catch (e) {
      /// "user rejected signing" or near network error
      logger.log("NETH:signAndSendTransactions Error", e);
      throw e;
    }

    if (useCover) {
      cover.style.display = "none";
    }

    return res;
  }); // return the wallet interface for wallet-selector


  return {
    signIn() {
      return __awaiter(this, void 0, void 0, function* () {
        let account;

        try {
          account = yield signIn();

          if (!account) {
            return [];
          }
        } catch (e) {
          if (!/not connected/.test(e.toString())) {
            throw e;
          } // console.log(e);

        }

        return [account];
      });
    },

    signOut() {
      return __awaiter(this, void 0, void 0, function* () {
        yield signOut();
      });
    },

    verifyOwner({
      message
    }) {
      return __awaiter(this, void 0, void 0, function* () {
        logger.log("NETH:verifyOwner", {
          message
        });
        return verifyOwner({
          message,
          provider,
          account: null
        });
      });
    },

    getAccounts() {
      return __awaiter(this, void 0, void 0, function* () {
        const near = yield getNear();

        if (!near) {
          logger.log("NETH:getAccounts");
          return [];
        }

        const {
          account,
          accountId
        } = near;
        return [{
          accountId,
          publicKey: (yield account.connection.signer.getPublicKey(account.accountId, options.network.networkId)).toString()
        }];
      });
    },

    signAndSendTransaction: ({
      receiverId,
      actions
    }) => __awaiter(void 0, void 0, void 0, function* () {
      return signTransactions([{
        receiverId,
        actions
      }]);
    }),
    signAndSendTransactions: ({
      transactions
    }) => __awaiter(void 0, void 0, void 0, function* () {
      return signTransactions(transactions);
    })
  };
});

function setupNeth({
  iconUrl = nethIcon,
  gas,
  useModalCover = false,
  bundle: _bundle = true,
  deprecated = false
} = {}) {
  return () => __awaiter(this, void 0, void 0, function* () {
    useCover = useModalCover;
    customGas = gas;
    bundle = _bundle;
    const mobile = isMobile__default["default"]();

    if (mobile) {
      return null;
    }

    const installed = yield isInstalled();
    return {
      id: "neth",
      type: "injected",
      metadata: {
        name: "NETH Account",
        description: null,
        iconUrl,
        downloadUrl: NETH_SITE_URL,
        deprecated: false,
        available: installed
      },
      deprecated,
      init: Neth
    };
  });
}

exports.MIN_NEW_ACCOUNT_ASK = MIN_NEW_ACCOUNT_ASK;
exports.accountExists = accountExists;
exports.getConnection = getConnection;
exports.getEthereum = getEthereum;
exports.getNear = getNear;
exports.getNearMap = getNearMap;
exports.handleCancelFunding = handleCancelFunding;
exports.handleCheckAccount = handleCheckAccount;
exports.handleCreate = handleCreate;
exports.handleDisconnect = handleDisconnect;
exports.handleRefreshAppKey = handleRefreshAppKey;
exports.handleUpdateContract = handleUpdateContract;
exports.hasAppKey = hasAppKey;
exports.initConnection = initConnection;
exports.isSignedIn = isSignedIn;
exports.setupNeth = setupNeth;
exports.signAndSendTransactions = signAndSendTransactions;
exports.signIn = signIn;
exports.signOut = signOut;
exports.switchEthereum = switchEthereum;
exports.verifyOwner = verifyOwner;
