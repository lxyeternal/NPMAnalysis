# NPM Package Validator
## Installation
To use this tool, install the package globally. E.g:
```
npm i -g @dinopereira/package-validator
```

## Usage
Seeing as this tool is still in its infancy we are providing only three commands to start off with

#### Config

Creates a config file in the root of your current project called `npv-config.json`.
When using `npv` for the first time you will be asked if you want to create a default config file or provide a path to an existing config file (think monorepo, where you want to have parent base configurations). You can later edit this file:
  - add or remove package form White List / Black List
  - add or remove license typres from the allowed license list.
  - define a base value to evaluate package health, this is the value that will be returned from [npms.io](https://npms.io), its a calculation that factors in code coverage, popularity, maintenance (open issues vs closed issues), etc.

```
npv config
```

#### Health: 

This command will analise the current package with data that comes from [npms.io](https://npms.io), and validate against predefined conditions

```
npv health [package]
```

#### Install:

This command will have two distinct behaviours, when we don't provide a package, all packages will run through a license validator, that will tell us which packages aren't compliant based on our current License whitelist, each will be audited and only then installed.

```
npv install
```

And if we provide a package name, that package will pass thorough the license validator and health check, audited and only installed if the package passes all stages.
We can provide a `dev` flag to install the package as a dev dependency.

```
npv install [package] dev
```

