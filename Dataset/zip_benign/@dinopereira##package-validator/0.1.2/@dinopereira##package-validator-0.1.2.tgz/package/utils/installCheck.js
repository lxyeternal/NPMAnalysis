const packageChecker = require('license-checker');
const axios = require('axios');
const dedent = require('dedent');
const execa = require('execa');
const chalk = require('chalk');
const fs = require('fs');
const process = require('process');

/**
 * Receives a package and dev flag, checks if the package has the correct license, 
 * then checks health... (better description)
 * @param {string} pkg 
 * @param {boolean} dev 
 */

async function installCheck (dev, force) {
  packageChecker.init({
      start: process.cwd(),
      out: '../',
      production: !dev,
      development: dev,
      summary: true,
      direct: true,
  }, async (err, json) => {
    if (!fs.existsSync(`${process.cwd()}/npv-config.json`)) {
      await execa(
        'npv',
        ['config'],
        { stdio: 'inherit' },
      ).then((result) => {
          if (result.code !== 0) {
              throw new Error(dedent`
                  Failed to create config file ${pkg}.
              `);
          }
      }).catch(err => {
          console.log("this caught fire!!!", err);
      });
    }

    const rawConfig = fs.readFileSync(`${process.cwd()}/npv-config.json`);
    const config = JSON.parse(rawConfig);

      const rawPackageJson = fs.readFileSync(`${process.cwd()}/package.json`, 'utf8');
      const packageJson = JSON.parse(rawPackageJson);
      let buildStatus = true;

      Object.keys(packageJson.dependencies).forEach((element) => {
          if (config.blacklist.some((blacklisted) => blacklisted === element)) {
              console.log(dedent(chalk`
                  __________________________________________________________________________________________
                  
                  {red.bold ${element} has been blacklisted, do not install this package! }
                  __________________________________________________________________________________________
                  
              `));

              return;
          }

          axios.get(`https://api.npms.io/v2/package/${element}`)
              .then(res => {
                  const data = res.data;
                  const coverage = data.collected.source.coverage ? `${Math.round(data.collected.source.coverage) * 100}%` : "0% or that information is not available";
                  if (Math.round(data.score.final * 100) < config.healthThreshold) {
                      console.log(dedent(chalk`
                      ---------------------------------------------------------------
  
                      {red.bold Dependency: } {bold ${element}} {red.bold | License: } {bold ${data.collected.metadata.license}} {red.bold | Stars: } {bold ${data.collected.npm.starsCount}}
                      
                      {red.bold Coverage: } {bold ${coverage}}
              
                      {red.bold Final Score: } {bold ${Math.round(data.score.final * 100)}%}
                      {red.bold Quality: } {bold ${Math.round(data.score.detail.quality * 100)}%}
                      {red.bold Maintenance: } {bold ${Math.round(data.score.detail.maintenance * 100)}%}
                      {red.bold Popularity: } {bold ${Math.round(data.score.detail.popularity * 100)}%}
                      {red.bold ${element}} is not Valid
                      
                      ---------------------------------------------------------------
                      `));

                      buildStatus = false;
                  }
              })
              .catch(err => {
                  throw new Error(dedent(chalk`
                      Couldn't get {red.bold ${element}} package information.
                      {red.bold Error code:}
                      ${err}
                  `));
              })
      });

      Object.keys(json).forEach((element) => {

          if (!config.allowedLicenses.includes(json[element].licenses)) {
              console.log(dedent(chalk`
                  -------------
                  Check License
                  -------------
                  {red.bold ${element}} does not have a valid license: {red.bold ${json[element].licenses}}

              `));
          }
      });

      setTimeout(() => {
        if (buildStatus || force) {
          execa(
            'npm',
            ['install'],
            { stdio: "inherit" },
          ).then((result) => {
            if (result.code !== 0) {
                throw new Error(dedent`
                    Failed to audit.
                `);
            }
          })
        } else {
            console.log(dedent(chalk`
                ____________________________________________________________________________________________________________________
                
                {red.bold Something went wrong, licenses may be invalid, or a recently installed package failed our quality check! }
                ____________________________________________________________________________________________________________________
                
            `));
        }
      }, 500);
  });
}

module.exports = installCheck;