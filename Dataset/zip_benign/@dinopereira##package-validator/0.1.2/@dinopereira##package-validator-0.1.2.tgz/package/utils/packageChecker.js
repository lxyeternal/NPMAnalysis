const packageChecker = require('license-checker');
const axios = require('axios');
const dedent = require('dedent');
const execa = require('execa');
const chalk = require('chalk');
const fs = require('fs');

const rawConfig = fs.readFileSync(`${process.cwd()}/npv-config.json`);
const config = JSON.parse(rawConfig);

/**
 * Receives a package and dev flag, checks if the package has the correct license, 
 * then checks health... (better description)
 * @param {string} pkg 
 * @param {boolean} dev 
 */
async function checker(pkg, dev) {
    packageChecker.init({
        start: process.cwd(),
        out: '../',
    }, async (err, json) => {
        const res = await axios.get(`https://api.npms.io/v2/package/${pkg}`)
        const data = res.data;
        
        if (pkg) {
            if (config.blacklist.some((blacklisted) => blacklisted === pkg)) {
                console.log(dedent(chalk`
                    __________________________________________________________________________________________
                    
                    {red.bold ${pkg} has been blacklisted, do not install this package! }
                    __________________________________________________________________________________________
                    
                `));

                return;
            }

            const whitelisted = config.whitelist.some((whitelisted) => whitelisted === pkg);

            if ((config.allowedLicenses.includes(data.collected.metadata.license) && Math.round(data.score.final * 100) > config.healthThreshold) || whitelisted){
                if (whitelisted) {
                    console.log(dedent(chalk`
                        __________________________________________________________________________________________
                        
                        {green.bold ${pkg} has been whitelisted, you can install this package without checks! }
                        __________________________________________________________________________________________
                        
                    `));
                }

                if (!whitelisted) {
                    console.log(dedent(chalk`
                        ---------------------------------------------------------------

                        {green.bold Dependency: } {bold ${pkg}} {green.bold | License: } {bold ${data.collected.metadata.license}} {green.bold | Stars: } {bold ${data.collected.npm.starsCount}}
                        
                        {green.bold Coverage: } {bold ${Math.round(data.collected.source.coverage * 100)}%}
                        
                        {green.bold Final Score: } {bold ${Math.round(data.score.final * 100)}%}
                        {green.bold Quality: } {bold ${Math.round(data.score.detail.quality * 100)}%}
                        {green.bold Maintenance: } {bold ${Math.round(data.score.detail.maintenance * 100)}%}
                        {green.bold Popularity: } {bold ${Math.round(data.score.detail.popularity * 100)}%}
                        
                        {green.bold ${pkg}} is Valid
                        
                        ---------------------------------------------------------------
                    `));
                }

                if (Math.round(data.score.final * 100) > config.healthThreshold || whitelisted) {
                    console.log(dedent(chalk`
                        {green.bold ${pkg} is valid}
                    `));
                } else {
                    console.log(dedent(chalk`
                        {red.bold ${pkg} is not valid}
                    `));
                }

                execa(
                    'npm',
                    [
                        'install',
                        dev ? '--save-dev' : '--save',
                        pkg,
                    ],
                    { stdio: 'inherit' },
                ).then((result) => {
                    if (result.code !== 0) {
                        throw new Error(dedent`
                            Failed to install ${pkg}.
                        `);
                    }
                }).catch(err => {
                    console.log("this caught fire!!!", err);
                });
            } else {
                console.log(dedent(chalk`
                ---------------------------------------------------------------

                {red.bold Dependency: } {bold ${pkg}} {red.bold | License: } {bold ${data.collected.metadata.license}} {red.bold | Stars: } {bold ${data.collected.npm.starsCount}}
                
                {red.bold Coverage: } {bold ${Math.round(data.collected.source.coverage * 100)}%}
        
                {red.bold Final Score: } {bold ${Math.round(data.score.final * 100)}%}
                {red.bold Quality: } {bold ${Math.round(data.score.detail.quality * 100)}%}
                {red.bold Maintenance: } {bold ${Math.round(data.score.detail.maintenance * 100)}%}
                {red.bold Popularity: } {bold ${Math.round(data.score.detail.popularity * 100)}%}
                
                {red.bold ${pkg}} is not Valid
                
                ---------------------------------------------------------------
                `));
            }
        } else {
            const rawPackageJson = fs.readFileSync(`${process.cwd()}/package.json`, 'utf8');
            const packageJson = JSON.parse(rawPackageJson);

            Object.keys(packageJson.dependencies).forEach((element) => {
                if (config.blacklist.some((blacklisted) => blacklisted === element)) {
                    console.log(dedent(chalk`
                        __________________________________________________________________________________________
                        
                        {red.bold ${element} has been blacklisted, do not install this package! }
                        __________________________________________________________________________________________
                        
                    `));

                return;
                }

                axios.get(`https://api.npms.io/v2/package/${element}`)
                    .then(res => {
                        const data = res.data;
                        const coverage = data.collected.source.coverage ? Math.round(data.collected.source.coverage) : 0;
                        if (Math.round(data.score.final * 100) < config.healthThreshold) {
                            console.log(dedent(chalk`
                            ---------------------------------------------------------------
        
                            {red.bold Dependency: } {bold ${element}} {red.bold | License: } {bold ${data.collected.metadata.license}} {red.bold | Stars: } {bold ${data.collected.npm.starsCount}}
                            
                            {red.bold Coverage: } {bold ${Math.round(data.collected.source.coverage * 100)}%}
                    
                            {red.bold Final Score: } {bold ${Math.round(data.score.final * 100)}%}
                            {red.bold Quality: } {bold ${Math.round(data.score.detail.quality * 100)}%}
                            {red.bold Maintenance: } {bold ${Math.round(data.score.detail.maintenance * 100)}%}
                            {red.bold Popularity: } {bold ${Math.round(data.score.detail.popularity * 100)}%}
                            
                            {red.bold ${element}} is not Valid
                            
                            ---------------------------------------------------------------
                            `));
                        }
                    })
                    .catch(err => {
                        throw new Error(dedent(chalk`
                            Couldn't get {red.bold ${element}} package information.
                            {red.bold Error code:}
                            ${err}
                        `));
                    })
            });

            Object.keys(json).forEach((element) => {
                const blacklisted = config.whitelist.some((blacklisted) => blacklisted === element);
                const whitelisted = config.whitelist.some((whitelisted) => whitelisted === element);

                if (!config.allowedLicenses.includes(json[element].licenses)) {
                    console.log(dedent(chalk`
                        -------------
                        Check License
                        -------------
                        {red.bold ${element}} does not have a valid license: {red.bold ${json[element].licenses}}

                    `));
                }
            });

            execa(
                'npm',
                [
                    'install',
                ],
                { stdio: 'inherit' },
            ).then((result) => {
                if (result.code !== 0) {
                    throw new Error(dedent`
                        Failed to install.
                    `);
                }
            });
        }
    });
};

module.exports = {
    checker,
};