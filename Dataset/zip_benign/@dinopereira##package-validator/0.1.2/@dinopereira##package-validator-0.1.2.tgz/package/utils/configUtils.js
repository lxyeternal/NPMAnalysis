const fs = require('fs');
const process = require('process');
const defaultConfig = require('../bin/config.json')

async function createConfigFile(path) {
  const rawConfig = path ? fs.readFileSync(path) : defaultConfig;
  const config = path ? JSON.parse(rawConfig) : rawConfig;
  await fs.writeFileSync(`${process.cwd()}/npv-config.json`, JSON.stringify(config), () => {});
}

module.exports = {
  createConfigFile
};