const dedent = require('dedent');
const chalk = require('chalk');
const fs = require('fs');
const execa = require('execa');

/**
 * Add a description ...
 * @param {string} packageName 
 * @param {object} data 
 */
async function health(packageName, data) {
    if (!fs.existsSync(`${process.cwd()}/npv-config.json`)) {
        await execa(
            'npv',
            ['config'],
            { stdio: 'inherit' },
        ).then((result) => {
            if (result.code !== 0) {
                throw new Error(dedent`
                    Failed to create config file ${pkg}.
                `);
            }
        }).catch(err => {
            console.log("this caught fire!!!", err);
        });
    }
  
    const rawConfig = fs.readFileSync(`${process.cwd()}/npv-config.json`);
    const config = JSON.parse(rawConfig);

    if (config.blacklist.some((blacklisted) => blacklisted === packageName)) {
        console.log(dedent(chalk`
            __________________________________________________________________________________________
            
            {red.bold ${packageName} has been blacklisted, do not install this package! }
            __________________________________________________________________________________________
            
        `));
        return;
    }

    if (config.whitelist.some((whitelisted) => whitelisted === packageName)) {
        console.log(dedent(chalk`
            __________________________________________________________________________________________
            
            {green.bold ${packageName} has been whitelisted, you can install this package without audit checks! }
            __________________________________________________________________________________________
            
        `));
        return;
    }

    console.log(dedent(chalk`
        --------------------------------------------------------------
    
        {magenta.bold Dependency: } {bold ${packageName}} {magenta.bold | License: } {bold ${data.collected.metadata.license}} {magenta.bold | Stars: } {bold ${data.collected.npm.starsCount}}
        
        {magenta.bold Coverage: } {bold ${Math.round(data.collected.source.coverage * 100)}%}
    
        {magenta.bold Final Score: } {bold ${Math.round(data.score.final * 100)}%}
        {magenta.bold Quality: } {bold ${Math.round(data.score.detail.quality * 100)}%}
        {magenta.bold Maintenance: } {bold ${Math.round(data.score.detail.maintenance * 100)}%}
        {magenta.bold Popularity: } {bold ${Math.round(data.score.detail.popularity * 100)}%}
        
        ---------------------------------------------------------------
    `));

    if (Math.round(data.score.final * 100) < config.healthThreshold) {
        console.log(dedent(chalk`
            {red.bold ${packageName} is not valid}
        `));
    } else {
        console.log(dedent(chalk`
            {green.bold ${packageName} is valid}
        `));
    }
}

module.exports = health;