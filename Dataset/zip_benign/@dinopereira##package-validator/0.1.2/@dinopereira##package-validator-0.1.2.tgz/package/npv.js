#!/usr/bin/env node

const ace = require('@adonisjs/ace');
const fs = require('fs');
const config = require('./bin/config.json');
// register commands
ace.addCommand(require('./commands/Install.js'));
ace.addCommand(require('./commands/Config.js'));
ace.addCommand(require('./commands/HealthCheck.js'));

// Boot ace to execute commands
ace.wireUpWithCommander();
ace.invoke();