const { Command } = require('@adonisjs/ace');
const packageCheck = require('../utils/packageCheck');
const installCheck = require('../utils/installCheck');

class Install extends Command {

    static get signature () {
        return `install
            {packageName?: name of package to install}
            {--dev?: saves package as dev}
            {--force?: bypasses security check}`
    }
    
    static get description () {
        return 'Install Package'
    }
    
    async handle ({ packageName }, { dev, force }) {
        if (packageName) {
            packageCheck(packageName, dev, force);
        } else {
            installCheck(dev, force);
        }
    }
}

module.exports = Install;