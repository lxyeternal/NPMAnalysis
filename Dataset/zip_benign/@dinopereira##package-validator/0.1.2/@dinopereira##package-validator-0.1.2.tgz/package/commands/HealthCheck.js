const { Command } = require('@adonisjs/ace');
const axios = require('axios');
const packageHealth = require('../utils/packageHealth.js');

class HealthCheck extends Command {

    static get signature () {
        return `health
            {packageName: name of package to check}`
    }
    
    static get description () {
        return 'Check Package'
    }
    
    async handle ({ packageName }) {
        try {
            const response = await axios.get(`https://api.npms.io/v2/package/${packageName}`);

            packageHealth(packageName, response.data);
        } catch (error) {
            console.log(error);
        }
    }
}

module.exports = HealthCheck;