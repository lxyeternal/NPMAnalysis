const { Command } = require('@adonisjs/ace');
const configUtils = require('../utils/configUtils');

class Config extends Command {

    static get signature () {
        return `config`
    }
    
    static get description () {
        return 'Change config parameters'
    }
    
    async handle () {
        const useDefault = await this
          .choice('Use default config or provide path to another file?', [
            'default', 'path'
          ]);
        const path = useDefault === 'path' ? await this
          .ask('Enter relative path to config file...')
          : null;

        configUtils.createConfigFile(path);
    }
}

module.exports = Config;