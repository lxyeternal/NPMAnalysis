const TerserPlugin = require("terser-webpack-plugin");


function createVariants(config, configCallback) {
  const keys = Object.keys(config);
  const values = Object.values(config);

  const configs = values.reduce((acc, curr) => {
    const variants = [];

    curr.forEach(val => {
      if (acc.length === 0) {
        variants.push({[keys[0]]: val});
      } else {
        acc.forEach(item => {
          variants.push({...item, [keys[acc[0] ? Object.keys(item).length : 0]]: val});
        });
      }
    });

    return variants;
  }, []);

  return configCallback ? configs.map(configCallback) : configs;
}

function createConfig(options) {
  const config = {
    entry: __dirname + "/src/app.js",
    output: {
      path: __dirname + "/build",
      filename:
        "waveform-playlist." +
        options.target +
        (options.minified ? ".min" : "") +
        ".js",
      library: {
        name: "WaveformPlaylist",
        type: options.target,
      },
    },
    optimization: {
      minimize: options.minified,
      minimizer: [new TerserPlugin()],
    },
    mode: "production",
    module: {
      rules: [
        {
          test: /\.m?js$/,
          exclude: /(node_modules|bower_components)/,
          use: {
            loader: "babel-loader",
            options: {
              presets: ["@babel/preset-env"],
              plugins: [["@babel/plugin-transform-runtime"]],
            },
          },
        },
      ],
    },
  };

  if (options.target === "umd") {
    config.output.umdNamedDefine = true;
    config.output.globalObject = "this";
  }

  return config;
}

module.exports = createVariants(
  {
    minified: [false, true],
    target: ["var", "commonjs2", "umd", "amd"],
  },
  createConfig
);
