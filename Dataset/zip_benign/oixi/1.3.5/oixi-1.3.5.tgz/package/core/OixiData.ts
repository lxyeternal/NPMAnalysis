import { AbstractComponent } from "./AbstractComponent"
import { Container } from "pixi.js"

export class OixiData {
  /**绑定上下文为组件的事件 */
  events: string[] = []
  /**从组件层获得的属性集 */
  props: string[] = []
  /**从组件层获得的子显示对象 */
  slots: (AbstractComponent | Container)[] = null
  /**从组件层获得的子显示对象 */
  template: (AbstractComponent | Container)[] = null
}