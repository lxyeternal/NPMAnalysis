import { Container, Sprite, Text, Graphics, AnimatedSprite, TilingSprite } from "pixi.js";

type S = { new(): Sprite }
type T = { new(): Text }
type G = { new(): Graphics }
type L = { new(): TilingSprite }
type A = { new(): AnimatedSprite }

type ViewType = S | T | G | L | A

/**
 * 抽象组件基类，被自定义组件继承
 */
abstract class AbstractComponent {
  $?: { [a in string]: string }
  private _view: Container

  /**
   * 构建组件
   * @param ViewClass 可以传入Sprite等Container的子类作为视图
   */
  constructor(ViewClass: ViewType = null) {
    this._view = ViewClass ? new ViewClass : new Container
  }

  get view(): Container {
    return this._view
  }

  created() { }

  /**
   * 监听事件，代理view的监听方法，可以接收到view的交互事件
   * @param event 事件名
   * @param fn 处理事件的函数
   * @param context 函数里的this
   */
  on(event: string | symbol, fn: (...args: any[]) => void, context?: any) {
    this._view.on(event, fn, context)
  }

  /**
   * 发送事件，避免与原生交互事件冲突，例如不要使用click
   * @param event 事件名
   * @param args 附带的参数列表
   */
  emit(event: string | symbol, ...args: any[]): boolean {
    return this._view.emit(event, ...args)
  }

  /**
   * 关闭监听
   * @param event 事件名
   * @param fn 处理事件的函数
   * @param context 函数里的this
   */
  off(event: string | symbol, fn?: (...args: any[]) => void, context?: any) {
    this._view.off(event, fn, context)
  }

  set interactive(v: boolean) {
    this._view.interactive = v
  }

  get interactive(): boolean {
    return this._view.interactive
  }
}

export { AbstractComponent }