import { Container, ObservablePoint } from "pixi.js"
import { AbstractComponent } from "./AbstractComponent"
import { OixiData } from "./OixiData"

const _oixi_ = '_oixi_'

const TOUCH_EVENTS = ['tap', 'touchstart', 'touchend', 'touchmove']

/**
 * 创建根组件，创建完成后自动释放临时数据
 * 模板中的组件在父组件创建完成后才会释放临时数据
 * 参数解释请参考buildComponent
 * @param component 
 * @param attributes 
 * @param template 
 */
export function buildRootComponent(
  component: AbstractComponent | Container,
  attributes?: string,
  template?: () => (AbstractComponent | Container)[]
): AbstractComponent | Container {
  let root = buildComponent(component, attributes, null, template)
  releaseOixiData(getView(root))
  return root
}

/*
 * 模板参数：#child1 @click=onClick $prop1=string x=number
 * # 组件id，对应同名成员变量，同时将id赋值到组件显示对象的name属性上
 * @ 事件，事件处理函数的this绑定组件实例
 * $ 传给子组件的属性，子组件通过this.$.a获取，传入的值解析为字符串
 * 不带前缀的表示直接设置显示对象的属性，自定义组件将设置view的属性，值类型是数字，一般用于设置x,y
 * ObservablePoint类型属性可直接赋值，例如anchor=0.5设置anchor.x和anchor.y均为0.5
 * 也可以单独设置anchor.x=0.5
 * 注意所有属性值都不能带空格
*/
/**
 * 通过传入的参数初始化自定以组件
 * 自定义组件均继承AbstractComponent,通过view属性引用显示对象
 * 内部组件返回pixi原生对象，例如OSprite返回Sprite对象
 * @param component 组件实例
 * @param attributes 从父组件传入的模板参数
 * @param slots 从父组件传入的子显示对象
 * @param template 定义组件显示对象列表的模板，如果设置了模板且需要传入slots，则模板中必须有#slot的对象作为slots的容器
 */
export function buildComponent(
  component: AbstractComponent | Container,
  attributes?: string,
  slots?: (AbstractComponent | Container)[],
  template?: () => (AbstractComponent | Container)[]
): AbstractComponent | Container {

  let view: Container = component instanceof AbstractComponent ? component.view : component
  let oxd = new OixiData()
  view[_oixi_] = oxd

  if (template) {
    oxd.template = template()
    addChildren(view, oxd.template)

    if (slots) {
      oxd.slots = slots
      addChildren2TemplateSlot(slots, oxd.template)
    }

    bindAttributes2Component(oxd.template, component as AbstractComponent)

  } else if (slots) {
    oxd.slots = slots
    addChildren(view, slots)
  }

  if (attributes) {
    parseAttributes(attributes, view)
  }

  if (component instanceof AbstractComponent) {
    applyProps(component)
    component.created()
  }

  return component
}

function getOixiData(view: Container): OixiData {
  return view[_oixi_] ? view[_oixi_] : null
}

function getView(object: AbstractComponent | Container): Container {
  return (object instanceof AbstractComponent) ? object.view : object
}

function releaseOixiData(view: Container) {
  delete view[_oixi_]
}

function addChildren(view: Container, children: (AbstractComponent | Container)[]) {
  children.forEach(c => {
    view.addChild(getView(c))
  })
}

function parseAttributes(arg: string, view: Container) {
  function getValue(str: String) {
    return str.substring(1)
  }

  let oxd = getOixiData(view)
  arg.split(' ').forEach(attribute => {
    if (attribute) {
      switch (attribute.charAt(0)) {
        case '#':
          view.name = getValue(attribute)
          break
        case '@':
          oxd.events.push(getValue(attribute))
          break
        case '$':
          oxd.props.push(getValue(attribute))
          break
        default:
          let a = attribute.split('=')
          let keys: string[] = a[0].split('.')
          let value: number = Number(a[1])
          let n = keys.length
          let o = view
          for (let i = 0; i < n; i++) {
            let k = keys[i]
            if (o && (k in o)) {
              if (i == n - 1) {
                if (o[k] instanceof ObservablePoint) {
                  o[k].set(value)
                } else {
                  o[k] = value
                }
              } else {
                o = o[k]
              }
            } else {
              throw Error(`oixi: Property ${a[0]} is not in ${view['constructor'].name}`)
            }
          }
          break
      }
    }
  })
}

function findSlotContainer(children: (AbstractComponent | Container)[]): Container {
  for (var i = 0, n = children.length; i < n; i++) {
    let c = children[i]
    let view = getView(c)
    if (view.name === 'slot') {
      return view
    } else {
      let oxd = getOixiData(view)
      if (oxd && oxd.slots) {
        let s = findSlotContainer(oxd.slots)
        if (s) {
          return s
        }
      }
    }
  }

  return null
}

function addChildren2TemplateSlot(slots: (AbstractComponent | Container)[], template: (AbstractComponent | Container)[]) {
  //从模板中查找#slot，不存在则抛出错误
  let slotContainer = findSlotContainer(template)
  if (slotContainer) {
    addChildren(slotContainer, slots)
  } else {
    throw Error('oixi: no #slot in template')
  }
}

function bindAttributes2Component(children: (AbstractComponent | Container)[], component: AbstractComponent) {
  for (let i = 0, n = children.length; i < n; i++) {
    let child = children[i]
    let view = getView(child)
    let oxd = getOixiData(view)
    if (oxd) {
      //将子显示对象赋值给组件
      let name = view.name
      if (name) {
        if (name in component) {
          if (Array.isArray(component[name])) {
            component[name].push(child)
          } else {
            component[name] = child
          }
        } else if (name != 'slot') {
          console.warn('oixi: no member match ' + name)
        }
      }

      if (oxd.events.length) {
        applyEvents(child, oxd.events, component)
      }

      if (oxd.slots) {
        bindAttributes2Component(oxd.slots, component)
      }

      //子显示对象的OixiData使命完成，释放内存
      releaseOixiData(view)
    }
  }
}

function applyProps(component: AbstractComponent) {
  let oxd = getOixiData(getView(component))
  if (oxd.props.length) {
    component.$ = {}
    oxd.props.forEach(p => {
      let a = p.split('=')
      let k = a[0]
      component.$[k] = a[1]
    })
  }
}

function applyEvents(child: AbstractComponent | Container, events: string[], component: AbstractComponent) {
  events.forEach(e => {
    let a = e.split('=')
    let eventName = a[0]
    let handleName = a[1]
    let handle = component[handleName]
    if (handle) {
      if (TOUCH_EVENTS.includes(eventName)) {
        child.interactive = true
      }
      child.on(eventName, handle, component)
    } else {
      throw Error(`oixi: Function ${handleName} is undefined`)
    }
  })
}