import { Container, TilingSprite, Texture } from "pixi.js";
import { AbstractComponent } from "../core/AbstractComponent";
import { buildComponent } from "../core/buildComponent";

function OTilingSprite(texture: string, attribute: string): TilingSprite
function OTilingSprite(texture: string, attribute: string, slots: (AbstractComponent | Container)[]): TilingSprite

/**
 * 平铺精灵，可以平铺纹理，需要在attribute设置宽高eg.'#tile width=10 height=10'
 */
function OTilingSprite(a: string, b: string, c?: (AbstractComponent | Container)[]): TilingSprite {
  let t: TilingSprite
  t = new TilingSprite(Texture.from(a))
  if (c) {
    buildComponent(t, b, c)
  } else {
    buildComponent(t, b)
  }
  return t
}

export { OTilingSprite }