import { Container, Sprite, Texture } from "pixi.js";
import { AbstractComponent } from "../core/AbstractComponent";
import { buildComponent } from "../core/buildComponent";

function OSprite(texture: string): Sprite
function OSprite(texture: string, attribute: string): Sprite
function OSprite(texture: string, slots: (AbstractComponent | Container)[]): Sprite
function OSprite(texture: string, attribute: string, slots: (AbstractComponent | Container)[]): Sprite

/**
 * 精灵，可以渲染纹理的容器
 */
function OSprite(a: string, b?: any, c?: (AbstractComponent | Container)[]): Sprite {
  let s: Sprite
  s = a ? new Sprite(Texture.from(a)) : new Sprite
  if (c) {
    buildComponent(s, b, c)
  } else if (b) {
    if (typeof b === 'string') {
      buildComponent(s, b)
    } else {
      buildComponent(s, null, b)
    }
  }
  return s
}

export { OSprite }