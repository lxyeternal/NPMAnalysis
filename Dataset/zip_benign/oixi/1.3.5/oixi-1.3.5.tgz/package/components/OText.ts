import { ITextStyle, Text } from "pixi.js";
import { buildComponent } from "../core/buildComponent";

let textDefaultStyle: Object = {}

/**
 * 设置全局默认样式
 * @param style 样式对象
 */
export function setTextDefaultStyle(style: Partial<ITextStyle>) {
  textDefaultStyle = style
}

function OText(text: string): Text
function OText(text: string, attribute: string): Text
function OText(text: string, style: Partial<ITextStyle>): Text
function OText(text: string, attribute: string, style: Partial<ITextStyle>): Text

function OText(a: string, b?: any, c?: Partial<ITextStyle>): Text {
  let t: Text
  if (c) {
    let style = Object.assign({}, textDefaultStyle, c)
    t = new Text(a, style)
    buildComponent(t, b)
  } else if (b) {
    if (typeof b === 'string') {
      t = new Text(a, textDefaultStyle)
      buildComponent(t, b)
    } else {
      let style = Object.assign({}, textDefaultStyle, b)
      t = new Text(a, style)
    }
  } else {
    t = new Text(a, textDefaultStyle)
  }

  return t
}

export { OText }