import { AnimatedSprite, Texture } from "pixi.js";
import { buildComponent } from "../core/buildComponent";

function OAnimatedSprite(textures: string[]): AnimatedSprite
function OAnimatedSprite(textures: string[], attribute: string): AnimatedSprite

function OAnimatedSprite(a: string[], b?: string): AnimatedSprite {
  let txrs = a.map(t => Texture.from(t))
  let ants = new AnimatedSprite(txrs)
  if (b) {
    buildComponent(ants, b)
  }

  return ants
}

export { OAnimatedSprite }