import { Container } from "pixi.js";
import { AbstractComponent } from "../core/AbstractComponent";
import { buildComponent } from "../core/buildComponent";

function OContainer(attribute: string): Container
function OContainer(slots: (AbstractComponent | Container)[]): Container
function OContainer(attribute: string, slots: (AbstractComponent | Container)[]): Container

function OContainer(a: any, b?: any): Container {
  let c = new Container()
  if (b) {
    buildComponent(c, a, b)
  } else {
    if (typeof a === 'string') {
      buildComponent(c, a)
    } else {
      buildComponent(c, null, a)
    }
  }

  return c
}

export { OContainer }