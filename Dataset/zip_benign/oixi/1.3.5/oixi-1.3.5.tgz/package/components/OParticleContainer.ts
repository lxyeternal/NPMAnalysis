import { ParticleContainer } from "pixi.js";
import { buildComponent } from "../core/buildComponent";

export function OParticleContainer(maxSize: number, attributes: string) {
  return buildComponent(new ParticleContainer(maxSize, { position: true }), attributes)
}