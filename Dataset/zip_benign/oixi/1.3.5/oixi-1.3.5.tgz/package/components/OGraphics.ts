import { Graphics } from "pixi.js";
import { buildComponent } from "../core/buildComponent";

export function OGraphics(attribute?: string): Graphics {
  let g = new Graphics()
  buildComponent(g, attribute)
  return g
}