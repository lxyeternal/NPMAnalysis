# React Custom Particles

React Custom Particles is a lightweight and customizable particle animation library for React.js. This library allows you to create stunning particle effects without relying on third-party particle libraries. You can customize particle colors, sizes, speed, and more.

## Installation

You can install the library via npm:

```bash
npm install react-fire-particles-kkduniya

## Example

# import React from 'react';
# import ParticlesComponent from 'react-custom-particles';

# const options = {
#   particleCount: 100,  // Number of particles
#   size: { min: 1, max: 5 },  // Size range of particles
#   speed: { min: 0.5, max: 2 },  // Speed range of particles
#   colors: ['#1E00FF', '#FF0061', '#E1FF00', '#00FF9E']  // Array of colors for particles
# };

# const App = () => (
#   <div style={{ height: 100vh, width: "100%" }}>
#     <ParticlesComponent options={options} />
#   </div>
# );

# export default App;



