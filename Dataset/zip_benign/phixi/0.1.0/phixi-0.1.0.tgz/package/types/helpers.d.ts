/**
 * pixi.js関係のアセットをロード
 * pixiのloaderは並列ロードができないため、アセットごとにloaderを生成する
 * TODO: エラーハンドリング
 * TODO: ローダーはキャッシュする？
 *
 * @param key
 * @param path
 */
export declare function loadPixiAsset(key: string, path: string): Promise<PIXI.LoaderResource>;
