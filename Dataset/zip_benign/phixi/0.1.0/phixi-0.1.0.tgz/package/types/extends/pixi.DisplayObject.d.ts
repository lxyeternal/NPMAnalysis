import phina from 'phina.js';
interface PhinaAccessoryOverride extends phina.accessory.Accessory {
    update?: (app?: any) => any;
}
declare module 'pixi.js' {
    interface DisplayObject {
        /**
         * Attach phina.accessory
         * @param accessory - phina.accessory.Accessory instance to attach
         */
        attach(accessory: phina.accessory.Accessory): this;
        /**
         * Remove attached phina.accessory
         * @param accessory - phina.accessory.Accessory instance to detach
         */
        detach(accessory: phina.accessory.Accessory): this;
        /**
         * Private tweener
         */
        _tweener?: phina.accessory.Tweener;
        /**
         * Getter for phina.accessory.Tweener
         */
        tweener: phina.accessory.Tweener;
        /**
         * Array of phina.accessory.Accessory
         */
        accessories?: PhinaAccessoryOverride[];
        /**
         * App-class driven update function.
         * Run by Updater if defined
         */
        onUpdate?(app?: any): any;
        /**
         * Chainable object position setting method
         */
        setPosition(x?: number, y?: number): this;
        /**
         * Chainable object scale setting method
         */
        setScale(x: number, y?: number): this;
        /**
         * Chainable object alpha setting method
         */
        setAlpha(alpha: number): this;
        /**
         * Chainable object visibility setting method
         */
        setVisible(flag: boolean): this;
        /**
         * Chainable object interactivity setting method
         */
        setInteractive(flag: boolean): this;
        /**
         * Accessor for scale.x
         */
        scaleX: number;
        /**
         * Accessor for scale.y
         */
        scaleY: number;
    }
}
export {};
