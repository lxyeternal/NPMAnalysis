declare module 'pixi.js' {
    namespace utils {
        interface EventEmitter {
            /**
             * Calls each of the listeners registered for a given event.
             * Alias method for `emit`
             * @alias emit
             */
            flare(event: string | symbol, ...args: any[]): boolean;
        }
    }
}
export {};
