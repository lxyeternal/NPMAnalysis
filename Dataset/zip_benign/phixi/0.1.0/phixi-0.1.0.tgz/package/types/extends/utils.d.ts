/**
 * 任意のオブジェクトにgetterを追加する
 */
export declare function addGetter<T>(obj: T, prop: string, getter: (this: T) => any): void;
/**
 * 任意のオブジェクトにgetter及びsetterを追加する
 */
export declare function addAccessor<T>(obj: T, prop: string, accessor: {
    get: (this: T) => any;
    set: (this: T, v: any) => any;
}): void;
/**
 * 任意のオブジェクトにメソッドを追加する
 * REVIEW: メソッドを遠回しに生やすため、obj.prototype.fooのように
 *
 * @param obj target object
 * @param prop property name
 * @param methodFunc
 */
export declare function addMethod<T>(obj: T, prop: string, methodFunc: (this: T, ...args: any) => any): void;
