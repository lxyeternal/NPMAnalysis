import { Text } from 'pixi.js';
import { Scene } from './Scene';
/**
 * Built-in result scene
 * WIP
 */
export declare class ResultScene extends Scene {
    label: Text;
    scoreLabel: Text;
    retryButton: Text;
    constructor(options?: {
        score: number | string;
    });
    _onEnter(): void;
}
