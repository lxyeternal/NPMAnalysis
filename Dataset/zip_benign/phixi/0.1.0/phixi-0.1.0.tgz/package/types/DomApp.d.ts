import phina from 'phina.js';
import { BaseApp, BaseAppOptions } from './BaseApp';
/**
 * phina.app.DomAppクラスに相当
 * domElement(renderer.view)に各種Inputクラスを付与する
 * ただしaccelerometerはない
 */
export declare class DomApp extends BaseApp {
    mouse: phina.input.Mouse;
    touch: phina.input.Touch;
    touchList: phina.input.TouchList;
    keyboard: phina.input.Keyboard;
    pointer: phina.input.Touch | phina.input.Mouse;
    pointers: (phina.input.Touch | phina.input.Mouse)[];
    constructor(params?: BaseAppOptions);
    mount(element: Element): this;
}
