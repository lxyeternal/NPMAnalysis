import { Graphics } from 'pixi.js';
export interface GaugeOptions {
    width?: number;
    height?: number;
    value?: number;
    max?: number;
    min?: number;
    visualMax?: number;
    visualMin?: number;
    color?: string | number;
    bgColor?: string | number;
}
/**
 * Gauge drawing class with PIXI.Graphics
 *
 * ### TODO
 * - Add stroke drawing feature
 * - Add cornerRadius feature
 * - Add value change animation feature
 */
export declare class Gauge extends Graphics {
    /**
     * The ratio which shows the gauge visible value.
     * The actual drawing uses this value.
     */
    private _visualRatio;
    protected _value: number;
    protected _gaugeWidth: number;
    protected _gaugeHeight: number;
    protected _maxValue: number;
    protected _minValue: number;
    protected _visualMaxValue: number;
    protected _visualMinValue: number;
    protected _mainColor: number;
    protected _bgColor: number;
    private _gaugeAlpha;
    /**
     * @params params
     */
    constructor(params?: GaugeOptions);
    /**
     * update gauge image
     */
    private _drawGauge;
    /**
     * 見かけ上のゲージ率値を再セット=>再描画
     */
    private _updateVisualRatio;
    /**
     * set value
     *
     * @param v 指定値。未指定で内部値の再計算・再描画のみを行うことも可能
     * @param clampWithinRange 値がminValue ~ maxValueの範囲に収まるよう制限する。デフォルトはtrue
     */
    setValue(v?: number, clampWithinRange?: boolean): this;
    /**
     * 最大値をセット
     * @param v 実際の最大値
     * @param updateVisualValueToo 見かけ上の値も更新するかどうか（デフォルト: true）。数字を指定した場合、その数字を代入。
     */
    setMax(v: number, updateVisualValueToo?: number | boolean): this;
    /**
     * 最小値セット
     * @param v 実際値セット
     * @param updateVisualValueToo 見かけ上の値も更新するかどうか（デフォルト: true）。数字を指定した場合、その数字を代入。
     */
    setMin(v: number, updateVisualValueToo?: number | boolean): this;
    /**
     * set the value to max
     */
    refill(): this;
    /**
     * set gauge and background color
     *
     * @param mainColor hex
     * @param bgColor hex
     */
    setColor(mainColor?: number | string, bgColor?: number | string): this;
    /**
     * @property
     * @readonly
     * 見かけ上のゲージ率。0 ~ 1.0の値を返す
     */
    get visualRatio(): number;
    /**
     * @property
     * 実際値。setの際はmin~max間にclampされることを留意。
     */
    get value(): number;
    set value(v: number);
    /**
     * @property
     * @readonly
     * ゲージの最大値（実際値）
     * 見かけの最大値（visualMaxValue）とは区別される
     * setの際は {@link Gauge#setMax} を使用
     */
    get maxValue(): number;
    /**
     * @property
     * @readonly
     * ゲージの最小値（実際値）
     * 見かけの最小値（visualMinValue）とは区別される
     * setの際は {@link Gauge#setMin} を使用
     */
    get minValue(): number;
    /**
     * ゲージの透明度
     */
    get gaugeAlpha(): number;
    set gaugeAlpha(v: number);
    /**
     * @readonly
     * valueが最大値以上かどうか
     */
    get isMax(): boolean;
    /**
     * @readonly
     * valueが負数かどうか
     */
    get isNeg(): boolean;
}
