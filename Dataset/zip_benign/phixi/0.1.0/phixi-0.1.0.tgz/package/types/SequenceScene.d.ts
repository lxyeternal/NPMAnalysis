import { Scene } from './Scene';
declare type Constructable = new (...args: any) => any;
declare type SceneLabel = string | number;
export interface SceneData {
    className: string | Constructable;
    label: SceneLabel;
    arguments?: any;
}
export interface SceneScequenceParam {
    startLabel: SceneLabel;
    scenes: SceneData[];
}
/**
 * phina.game.ManagerScene相当のクラス
 * Sceneクラスを継承するが、自身はSceneとしての機能を持たず、
 * app本体のpushScene, popSceneを操作することで子Sceneを入れ替え管理を行う
 */
export declare class SequenceManageScene extends Scene {
    protected _sceneDataList: SceneData[];
    protected _sceneIndex: number;
    /**
     * @constructor
     * @param params
     */
    constructor(params: SceneScequenceParam);
    /**
     * sceneリストセットアップ
     * @param scenes
     */
    setScenes(scenes: SceneData[]): this;
    /**
     * Sceneクラスをインスタンス化
     * @param data
     * @param args
     */
    private _instantiateScene;
    /**
     * index(or label) のシーンへ飛ぶ
     * @param label
     * @param args
     */
    gotoScene(label: SceneLabel, args?: any): this | undefined;
    /**
     * 次のシーンへ飛ぶ
     * @param args
     */
    gotoNext(args: any): this;
    /**
     * シーンインデックスを取得
     */
    getCurrentIndex(): number;
    /**
     * シーンラベルを取得
     */
    getCurrentLabel(): SceneLabel;
    /**
     * ラベルからインデックスに変換
     */
    labelToIndex(label: SceneLabel): number;
    /**
     * インデックスからラベルに変換
     * @param index
     * @returns label
     */
    indexToLabel(index: number): SceneLabel;
}
export {};
