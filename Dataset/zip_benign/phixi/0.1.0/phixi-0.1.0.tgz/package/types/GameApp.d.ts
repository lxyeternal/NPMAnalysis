import { BaseAppOptions } from './BaseApp';
import { DomApp } from './DomApp';
import { ManagerSceneParam } from './Scene';
import { PhinaAssetLoaderLoadParam } from './types';
export interface GameAppOption extends ManagerSceneParam, BaseAppOptions {
    assets?: PhinaAssetLoaderLoadParam;
    append?: boolean;
    fit?: boolean;
}
/**
 * phina.js GameApp相当のクラス
 * ただしCanvasAppが無い分、append等の一部オプションはこちらで管理
 */
export declare class GameApp extends DomApp {
    /**
     * @param options
     */
    constructor(options: GameAppOption);
    /**
     * アセットロードを試す
     * @param assets 無指定の時はすぐに切り替え
     */
    private _tryAssetLoad;
    /**
     * 画面（ウィンドウ）に合わせてcanvas要素をリサイズ
     * phina.graphics.Canvas.fitScreenを流用
     * @param isEver windowリサイズ時に合わせてサイズをリセットするかどうか
     */
    fitScreen(isEver?: boolean): void;
}
