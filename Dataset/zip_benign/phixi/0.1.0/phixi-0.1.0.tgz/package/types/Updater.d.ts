import { Container } from 'pixi.js';
import { BaseApp } from './BaseApp';
export declare class Updater {
    app: BaseApp;
    constructor(app: BaseApp);
    updateElement(obj: Container): void;
}
