import { Container } from 'pixi.js';
import { BaseApp } from './BaseApp';
declare type Constructable = new (...args: any) => any;
declare type SceneLabel = string | number;
interface NextSceneOption {
    nextLabel: SceneLabel;
    [key: string]: any;
}
/**
 * Phixi.Sceneクラス
 */
export declare class Scene<A extends BaseApp = BaseApp> extends Container {
    protected _app?: A | null;
    constructor();
    /**
     * @virtual
     * @param app
     */
    onUpdate(_app?: A): void;
    setApp(app: A | null): void;
    exit(nextLabelOrOption?: string | NextSceneOption, nextArguments?: any): this | undefined;
    /**
     * @property app
     * TODO: _appが存在しないときはエラー吐く？
     */
    get app(): A | null | undefined;
    /**
     * 表示canvas要素領域の幅
     * scene enter後でないとアクセス不可
     */
    get viewportWidth(): number;
    /**
     * 表示canvas要素領域の高さ
     * scene enter後でないとアクセス不可
     */
    get viewportHeight(): number;
    get screenWidth(): number;
    get screenHeight(): number;
}
export interface SceneData {
    className: string | Constructable;
    label: SceneLabel;
    arguments?: any;
}
export interface ManagerSceneParam {
    startLabel: SceneLabel;
    scenes: SceneData[];
}
/**
 * phina.game.ManagerScene相当のクラス
 * Sceneクラスを継承するが、自身はSceneとしての機能を持たず、
 * app本体のpushScene, popSceneを操作することで子Sceneを入れ替え管理を行う
 */
export declare class SequenceManagerScene extends Scene {
    protected _sceneDataList: SceneData[];
    protected _sceneIndex: number;
    /**
     * @constructor
     * @param params
     */
    constructor(params: ManagerSceneParam);
    /**
     * sceneリストセットアップ
     * @param scenes
     */
    setScenes(scenes: SceneData[]): this;
    /**
     * Sceneクラスをインスタンス化
     * @param data
     * @param args
     */
    private _instantiateScene;
    /**
     * index(or label) のシーンへ飛ぶ
     * @param label
     * @param args
     */
    gotoScene(label: SceneLabel, args?: any): this | undefined;
    /**
     * 次のシーンへ飛ぶ
     * @param args
     */
    gotoNext(args: any): this;
    /**
     * シーンインデックスを取得
     */
    getCurrentIndex(): number;
    /**
     * シーンラベルを取得
     */
    getCurrentLabel(): SceneLabel;
    /**
     * ラベルからインデックスに変換
     */
    labelToIndex(label: SceneLabel): number;
    /**
     * インデックスからラベルに変換
     * @param index
     * @returns label
     */
    indexToLabel(index: number): SceneLabel;
}
export {};
