import { Text } from 'pixi.js';
import { Scene } from './Scene';
/**
 * Built-in title scene
 * WIP
 */
export declare class TitleScene extends Scene {
    titleLabel: Text;
    constructor(options?: any);
    _onEnter(): void;
}
