export declare type RendererOptions = {
    width?: number;
    height?: number;
    view?: HTMLCanvasElement;
    transparent?: boolean;
    autoDensity?: boolean;
    antialias?: boolean;
    resolution?: number;
    clearBeforeRender?: boolean;
    preserveDrawingBuffer?: boolean;
    backgroundColor?: number;
    powerPreference?: string;
    context?: any;
};
export declare enum PhinaEvent {
    Enterframe = "enterframe",
    AccessoryAttached = "attached",
    AccessoryDetached = "detached",
    Removed = "removed",
    EnterScene = "enter",
    ExitScene = "exit",
    ScenePaused = "pause",
    LoadingSceneLoaded = "loaded",
    AppChangeScene = "changescene",
    AppPushScene = "push",
    AppScenePushed = "pushed",
    AppPopScene = "pop",
    AppScenePoped = "poped",
    AppResume = "resume"
}
export interface PhinaKeyBoardEvent {
    keyCode: KeyboardEvent['keyCode'];
}
export declare enum TweenerUpdateType {
    Normal = "normal",
    Delta = "delta",
    FPS = "fps"
}
export declare enum AssetType {
    Pixi = "pixi"
}
export interface PhinaAssetLoaderLoadParam {
    [assetType: string]: {
        [assetKey: string]: string;
    };
}
