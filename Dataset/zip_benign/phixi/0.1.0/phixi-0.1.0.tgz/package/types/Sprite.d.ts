/// <reference types="types/extends/pixi.displayobject" />
/// <reference types="types/extends/pixi.container" />
/// <reference types="types/extends/pixi.eventemitter" />
import { Sprite as PixiSprite } from 'pixi.js';
declare type TextureOrKey = PIXI.Texture | string;
/**
 * PIXI.Sprite拡張クラス
 * 文字列keyでの指定ができるなど、phina.js Spriteクラスの特徴を追加
 */
export declare class Sprite extends PixiSprite {
    constructor(texture: TextureOrKey);
    setTexture(texture: TextureOrKey): this;
    setFrameIndex(): void;
    static getTextureByKey(key: string): import("pixi.js").Texture;
    static from(source: string | PIXI.Texture | HTMLCanvasElement | HTMLVideoElement): PixiSprite;
}
export {};
