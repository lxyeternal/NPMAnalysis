import { Gauge } from './Gauge';
import { Scene } from './Scene';
import { PhinaAssetLoaderLoadParam } from './types';
interface LoadingSceneInterface {
    load: (assets: PhinaAssetLoaderLoadParam) => any;
}
/**
 * Built-in LoadingSceen
 * WIP
 */
export declare class LoadingScene extends Scene implements LoadingSceneInterface {
    gauge: Gauge;
    constructor();
    /**
     * ロード後は
     * @param assets
     */
    load(assets: PhinaAssetLoaderLoadParam): void;
}
export {};
