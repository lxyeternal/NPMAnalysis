/**
 * The result of comparing two comparable instances.
 */
export type Ordering = GT | EQ | LT;
/**
 * An {@link Ordering} to represent that one is _greater than_ the other.
 */
export type GT = 1;
/**
 * An {@link Ordering} to represent that one is _equal to_ the other.
 */
export type EQ = 0;
/**
 * An {@link Ordering} to represent that one is _less than_ the other.
 */
export type LT = -1;

/**
 * Digit type.
 */
export type Digit = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
/**
 * String representation of {@link Digit}.
 */
export type SDigit = `${Digit}`;

/**
 * Alias for `number` to represent natural numbers.
 */
export type Nat = number;
/**
 * Alias for `number` to represent integers.
 */
export type Int = number;
