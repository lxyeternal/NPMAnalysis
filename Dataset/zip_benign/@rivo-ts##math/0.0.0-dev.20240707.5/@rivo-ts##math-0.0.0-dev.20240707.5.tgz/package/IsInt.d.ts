export type { IsInt } from "./Int/IsInt";
