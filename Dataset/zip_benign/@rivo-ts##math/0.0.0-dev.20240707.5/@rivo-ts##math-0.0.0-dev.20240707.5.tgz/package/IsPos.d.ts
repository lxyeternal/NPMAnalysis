/**
 * Check if a number is positive.
 *
 * Sig: `(n: number | bigint) => boolean`
 */
export type IsPos<N extends number | bigint> =
  N extends N ?
    number extends N ? boolean
    : bigint extends N ? boolean
    : `${N}` extends `-${string}` ? false
    : true
  : never;
