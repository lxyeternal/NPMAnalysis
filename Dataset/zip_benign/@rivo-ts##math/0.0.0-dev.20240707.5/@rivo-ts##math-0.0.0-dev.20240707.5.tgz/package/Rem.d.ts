import type { SDivRem } from "./DivRem";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Get the remainder of dividing two `number`s.
 *
 * Sig: `(n: number, m: number) => number`
 */
export type Rem<N extends number, M extends number> =
  N extends N ?
    M extends M ?
      number extends N | M ?
        number
      : _StrToNum<SRem<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Get the remainder of dividing two string representations of `number`s.
 * @private
 */
export type SRem<N extends string, M extends string> = SDivRem<N, M>[1];
