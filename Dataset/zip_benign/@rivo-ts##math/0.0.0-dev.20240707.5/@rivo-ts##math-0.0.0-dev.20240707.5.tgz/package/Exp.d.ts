import type { SAdd } from "./Add";
import type { SDiv } from "./Div";
import type { SMul } from "./Mul";
import type { SAdd as SAddNat } from "./Nat/Add";
import type { SCompare as SCompareNat } from "./Nat/Compare";
import type { LT } from "./aliases";
import type { _CanStrToLiteralNum } from "./internals/_CanStrToLiteralNum";
import type { _Div10 } from "./internals/_Div10";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Calculate the exponentiation of a `number`.
 *
 * Uses Taylor series to calculate the exponentiation, and the default iteration precision is `10`.
 *
 * Sig: `(n: number, precision?: number) => number`
 *
 * @example
 * ```typescript
 * type R1 = Exp<2>;
 * //   ^?: 7.388712522045852
 * type R2 = Exp<3>;
 * //   ^?: 20.063392857142855
 * ```
 */
export type Exp<N extends number, Precision extends number = 10> =
  N extends N ?
    number extends N ?
      number
    : _StrToNum<SExp<`${N}`, `${Precision}`>>
  : never;

/**
 * Calculate the exponentiation of the string representation of a `number`.
 *
 * Uses Taylor series to calculate the exponentiation, and the default iteration precision is `10`.
 * @private
 */
export type SExp<N extends string, Precision extends string = "10"> =
  (
    N extends `-${infer N}` ?
      SDiv<"1", _SExp<N, Precision, "1", "1", "1">>
    : _SExp<N, Precision, "1", "1", "1">
  ) extends infer R extends string ?
    R
  : never;
type _SExp<
  N extends string,
  Precision extends string,
  I extends string,
  Term extends string,
  Result extends string,
> =
  SCompareNat<I, Precision> extends LT ?
    SMul<Term, SDiv<N, I>> extends infer NextTerm extends string ?
      _SExp<N, Precision, SAddNat<I, "1">, NextTerm, SAdd<Result, NextTerm>>
    : never
  : Result;
