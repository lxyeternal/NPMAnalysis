import type { SAdd } from "./Add";
import type { SDiv } from "./Div";
import type { SMul } from "./Mul";
import type { SAdd as SAddNat } from "./Nat/Add";
import type { SCompare as SCompareNat } from "./Nat/Compare";
import type { SSub } from "./Sub";
import type { LT } from "./aliases";
import type { _CanStrToLiteralNum } from "./internals/_CanStrToLiteralNum";
import type { _Div10 } from "./internals/_Div10";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Calculate the natural logarithm of a `number`.
 *
 * Uses Taylor series to calculate the exponentiation, and the default iteration precision is `10`.
 *
 * Sig: `(n: number, precision?: number) => number`
 *
 * @example
 * ```typescript
 * type R1 = Ln<2>;
 * //   ^?: 0.6931460473908266
 * type R2 = Ln<3>;
 * //   ^?: 1.04509781125992
 * ```
 */
export type Ln<N extends number, Precision extends number = 10> =
  N extends N ?
    number extends N ?
      number
    : _StrToNum<SLn<`${N}`, `${Precision}`>>
  : never;

/**
 * Calculate the natural logarithm of the string representation of a `number`.
 *
 * Uses Taylor series to calculate the exponentiation, and the default iteration precision is `10`.
 * @private
 */
export type SLn<N extends string, Precision extends string = "10"> =
  _SExp<N, Precision, "1", SDiv<SSub<N, "1">, SAdd<N, "1">>, "0"> extends infer R extends string ? R
  : never;
type _SExp<
  N extends string,
  Precision extends string,
  I extends string,
  Term extends string,
  Result extends string,
> =
  SCompareNat<I, Precision> extends LT ?
    SMul<Term, SDiv<SSub<N, "1">, SMul<SAdd<N, "1">, SAdd<N, "1">>>> extends (
      infer NextTerm extends string
    ) ?
      _SExp<N, Precision, SAddNat<I, "2">, NextTerm, SAdd<Result, SDiv<Term, I>>>
    : never
  : SMul<Result, "2">;
