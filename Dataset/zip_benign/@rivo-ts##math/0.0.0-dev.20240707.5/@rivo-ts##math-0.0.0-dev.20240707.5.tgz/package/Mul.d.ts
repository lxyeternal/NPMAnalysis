import type { SMul as SMulInt } from "./Int/Mul";
import type { _RemoveStrPaddingZeroes } from "./Nat/internals/_RemoveStrPaddingZeroes";
import type { _AddTrailingZeroesToSameLength } from "./internals/_AddTrailingZeroesToSameLength";
import type { _Div10 } from "./internals/_Div10";
import type { _ReplaceAllCharsWithZero } from "./internals/_ReplaceAllCharsWithZero";
import type { _StrToNum } from "./internals/_StrToNum";
import type { _TruncateTooLongFractionalPart } from "./internals/_TruncateTooLongFractionalPart";

/**
 * Multiply two numbers.
 *
 * Sig: `(n: number, m: number) => number`
 */
export type Mul<N extends number, M extends number> =
  N extends N ?
    M extends M ?
      _StrToNum<SMul<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Multiply two string representations of `number`s.
 * @private
 */
export type SMul<N extends string, M extends string> = _TruncateTooLongFractionalPart<
  N extends `${infer NIntPart}.${infer NFracPart}` ?
    M extends `${infer MIntPart}.${infer MFracPart}` ?
      _Div10<
        SMulInt<
          _RemoveStrPaddingZeroes<`${NIntPart extends "0" ? "" : NIntPart}${_AddTrailingZeroesToSameLength<NFracPart, MFracPart>}`>,
          _RemoveStrPaddingZeroes<`${MIntPart extends "0" ? "" : MIntPart}${_AddTrailingZeroesToSameLength<MFracPart, NFracPart>}`>
        >,
        `${_AddTrailingZeroesToSameLength<NFracPart, MFracPart>}${_AddTrailingZeroesToSameLength<NFracPart, MFracPart>}`
      >
    : _Div10<
        SMulInt<
          _RemoveStrPaddingZeroes<`${NIntPart extends "0" ? "" : NIntPart}${NFracPart}`>,
          _RemoveStrPaddingZeroes<`${M}${_ReplaceAllCharsWithZero<NFracPart>}`>
        >,
        `${NFracPart}${NFracPart}`
      >
  : M extends `${infer MIntPart}.${infer MFracPart}` ?
    _Div10<
      SMulInt<
        _RemoveStrPaddingZeroes<`${N}${_ReplaceAllCharsWithZero<MFracPart>}`>,
        _RemoveStrPaddingZeroes<`${MIntPart extends "0" ? "" : MIntPart}${MFracPart}`>
      >,
      `${MFracPart}${MFracPart}`
    >
  : SMulInt<N, M>
>;
