import type { SDivRem as SDivRemNat } from "./Nat/DivRem";
import type { _AddTrailingZeroesToSameLength } from "./internals/_AddTrailingZeroesToSameLength";
import type { _CanStrToLiteralNum } from "./internals/_CanStrToLiteralNum";
import type { _Div10 } from "./internals/_Div10";
import type { _HandleNegativeZero } from "./internals/_HandleNegativeZero";
import type { _RemoveTrailingFractionalZeroes } from "./internals/_RemoveTrailingFractionalZeroes";
import type { _ReplaceAllCharsWithZero } from "./internals/_ReplaceAllCharsWithZero";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Get the quotient and remainder of dividing two `number`s.
 *
 * Sign of the remainder is the same as the sign of the dividend.
 *
 * Sig: `(n: number, m: number) => number`
 */
export type DivRem<N extends number, M extends number> =
  N extends N ?
    M extends M ?
      SDivRem<`${N}`, `${M}`> extends [infer Div extends string, infer Rem extends string] ?
        [_StrToNum<Div>, _StrToNum<Rem>]
      : never
    : never
  : never;

/**
 * Get the quotient and remainder of dividing two string representations of `number`s.
 *
 * Sign of the remainder is the same as the sign of the dividend.
 * @private
 */
export type SDivRem<N extends string, M extends string> =
  N extends `-${infer N}` ?
    M extends `-${infer M}` ?
      [_SDivRem<N, M>[0], _HandleNegativeZero<`-${_SDivRem<N, M>[1]}`>]
    : [_HandleNegativeZero<`-${_SDivRem<N, M>[0]}`>, _HandleNegativeZero<`-${_SDivRem<N, M>[1]}`>]
  : M extends `-${infer M}` ? [_HandleNegativeZero<`-${_SDivRem<N, M>[0]}`>, _SDivRem<N, M>[1]]
  : _SDivRem<N, M>;
/**
 * `N`, `M` must be positive numbers.
 * @private
 */
type _SDivRem<N extends string, M extends string> =
  N extends `${infer NIntPart}.${infer NFracPart}` ?
    M extends `${infer MIntPart}.${infer MFracPart}` ?
      SDivRemNat<
        `${NIntPart extends "0" ? "" : NIntPart}${_AddTrailingZeroesToSameLength<NFracPart, MFracPart>}`,
        `${MIntPart extends "0" ? "" : MIntPart}${_AddTrailingZeroesToSameLength<MFracPart, NFracPart>}`
      > extends [infer Div extends string, infer Rem extends string] ?
        [Div, _Div10<Rem, _AddTrailingZeroesToSameLength<MFracPart, NFracPart>>]
      : never
    : SDivRemNat<
      `${NIntPart extends "0" ? "" : NIntPart}${NFracPart}`,
      `${M}${_ReplaceAllCharsWithZero<NFracPart>}`
    > extends [infer Div extends string, infer Rem extends string] ?
      [Div, _Div10<Rem, NFracPart>]
    : never
  : M extends `${infer MIntPart}.${infer MFracPart}` ?
    SDivRemNat<
      `${N}${_ReplaceAllCharsWithZero<MFracPart>}`,
      `${MIntPart extends "0" ? "" : MIntPart}${MFracPart}`
    > extends [infer Div extends string, infer Rem extends string] ?
      [Div, _Div10<Rem, MFracPart>]
    : never
  : SDivRemNat<N, M>;
