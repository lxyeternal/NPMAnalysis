import type { SDivMod as SDivModNat } from "./Nat/DivMod";
import type { _RemoveStrPaddingZeroes } from "./Nat/internals/_RemoveStrPaddingZeroes";
import type { _AddTrailingZeroesToSameLength } from "./internals/_AddTrailingZeroesToSameLength";
import type { _CanStrToLiteralNum } from "./internals/_CanStrToLiteralNum";
import type { _Div10 } from "./internals/_Div10";
import type { _HandleNegativeZero } from "./internals/_HandleNegativeZero";
import type { _RemoveTrailingFractionalZeroes } from "./internals/_RemoveTrailingFractionalZeroes";
import type { _ReplaceAllCharsWithZero } from "./internals/_ReplaceAllCharsWithZero";
import type { _StrToNum } from "./internals/_StrToNum";
import type { _TruncateTooLongFractionalPart } from "./internals/_TruncateTooLongFractionalPart";

/**
 * Divide two `number`s.
 *
 * Sig: `(n: number, m: number) => number`
 */
export type Div<N extends number, M extends number> =
  N extends N ?
    M extends M ?
      _StrToNum<SDiv<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Divide two string representations of `number`s.
 * @private
 */
export type SDiv<N extends string, M extends string> = _HandleNegativeZero<
  N extends `-${infer N}` ?
    M extends `-${infer M}` ?
      _SDiv<N, M>
    : `-${_SDiv<N, M>}`
  : M extends `-${infer M}` ? `-${_SDiv<N, M>}`
  : _SDiv<N, M>
>;
/**
 * `N`, `M` must be positive numbers.
 * @private
 */
type _SDiv<N extends string, M extends string> = _TruncateTooLongFractionalPart<
  N extends `${infer NIntPart}.${infer NFracPart}` ?
    M extends `${infer MIntPart}.${infer MFracPart}` ?
      __SDiv<
        _RemoveStrPaddingZeroes<`${NIntPart extends "0" ? "" : NIntPart}${_AddTrailingZeroesToSameLength<NFracPart, MFracPart>}`>,
        _RemoveStrPaddingZeroes<`${MIntPart extends "0" ? "" : MIntPart}${_AddTrailingZeroesToSameLength<MFracPart, NFracPart>}`>
      >
    : __SDiv<
        _RemoveStrPaddingZeroes<`${NIntPart extends "0" ? "" : NIntPart}${NFracPart}`>,
        _RemoveStrPaddingZeroes<`${M}${_ReplaceAllCharsWithZero<NFracPart>}`>
      >
  : M extends `${infer MIntPart}.${infer MFracPart}` ?
    __SDiv<
      _RemoveStrPaddingZeroes<`${N}${_ReplaceAllCharsWithZero<MFracPart>}`>,
      _RemoveStrPaddingZeroes<`${MIntPart extends "0" ? "" : MIntPart}${MFracPart}`>
    >
  : __SDiv<N, M>
>;
/**
 * `N`, `M` must be natural numbers.
 * @private
 */
type __SDiv<
  N extends string,
  M extends string,
  IntPart extends string = "",
  FracPart extends string = "",
> =
  SDivModNat<N, M> extends [infer Div extends string, infer Mod extends string] ?
    Mod extends "0" ?
      IntPart extends "" ?
        Div
      : `${IntPart}.${FracPart}${Div}`
    : IntPart extends "" ? __SDiv<`${Mod}0`, M, Div, "">
    : _CanStrToLiteralNum<_RemoveTrailingFractionalZeroes<`${IntPart}.${FracPart}${Div}`>> extends (
      true
    ) ?
      __SDiv<`${Mod}0`, M, IntPart, `${FracPart}${Div}`>
    : _RemoveTrailingFractionalZeroes<`${IntPart}.${FracPart}${Div}`>
  : never;
