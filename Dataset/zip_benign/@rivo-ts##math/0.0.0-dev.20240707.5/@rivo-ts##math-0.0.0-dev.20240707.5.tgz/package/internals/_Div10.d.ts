import type { _RemoveTrailingFractionalZeroes } from "./_RemoveTrailingFractionalZeroes";
import type { _ReplaceAllCharsWithZero } from "./_ReplaceAllCharsWithZero";
import type { _ReverseString } from "./_ReverseString";
import type { _StrToNum } from "./_StrToNum";

/**
 * Divide integer `N` by 10^`Length<By>`.
 *
 * **⚠️ Warning:** length of `By` must be less than or equal to the number of digits in `N`.
 * @private
 *
 * @example
 * ```typescript
 * type R1 = _Div10<"125", "_">;
 * //   ^?: "12.5"
 * type R2 = _Div10<"-12300", "__">;
 * //   ^?: "-123"
 * type R3 = _Div10<"-12300", "___">;
 * //   ^?: "-12.3"
 * ```
 */
export type _Div10<N extends string, By extends string> =
  N extends `-${infer N}` ? `-${__Div10<N, By>}` : __Div10<N, By>;
type __Div10<N extends string, By extends string> =
  ___Div10<_ReverseString<`${N}`>, By, ""> extends infer R extends string ?
    R extends `.${infer R}` ?
      `0.${R}`
    : R
  : never;
type ___Div10<A extends string, By extends string, B extends string> =
  By extends `${string}${infer RestBy}` ?
    A extends `${infer F}${infer R}` ?
      ___Div10<R, RestBy, `${F}${B}`>
    : `0.${_ReplaceAllCharsWithZero<By>}${B}`
  : _RemoveTrailingFractionalZeroes<`${_ReverseString<A>}.${B}`>;
