import type { _ReplaceAllCharsWithZero } from "./_ReplaceAllCharsWithZero";

/**
 * Add trailing zeroes to `S` until it has the same length as `By`.
 * @private
 *
 * @example
 * ```typescript
 * type R1 = _AddTrailingZeroesToSameLength<"123", "12">;
 * //   ^?: "123"
 * type R2 = _AddTrailingZeroesToSameLength<"123", "123">;
 * //   ^?: "123"
 * type R3 = _AddTrailingZeroesToSameLength<"123", "1234">;
 * //   ^?: "1230"
 * type R4 = _AddTrailingZeroesToSameLength<"123", "12345">;
 * //   ^?: "12300"
 * ````
 */
export type _AddTrailingZeroesToSameLength<S extends string, By extends string> =
  S extends `${infer F}${infer R}` ?
    By extends `${string}${infer RestBy}` ?
      `${F}${_AddTrailingZeroesToSameLength<R, RestBy>}`
    : S
  : _ReplaceAllCharsWithZero<By>;
