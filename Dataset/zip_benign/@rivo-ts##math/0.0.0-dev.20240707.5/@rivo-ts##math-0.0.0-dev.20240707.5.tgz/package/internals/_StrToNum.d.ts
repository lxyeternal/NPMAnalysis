import type { Digit } from "../aliases";

/**
 * Convert a `string` to `number`.
 *
 * Sig: `(s: string) => number`
 *
 * Type safety is **not guaranteed** if the input string is not a valid number.
 * @private
 */
export type _StrToNum<S extends string> =
  S extends `${infer R extends number}` ?
    [number, S] extends [R, `${infer SInt}.${infer SFrac}${Digit}`] ?
      _StrToNum<`${SInt}${SFrac extends "" ? "" : `.${SFrac}`}`>
    : R
  : never;
