import type { _CanStrToLiteralNum } from "./_CanStrToLiteralNum";
import type { _StrToNum } from "./_StrToNum";

/**
 * Truncate the fractional part of a number if it's too long.
 */
export type _TruncateTooLongFractionalPart<N extends string> =
  N extends `${string}.${string}` ?
    _CanStrToLiteralNum<N> extends true ?
      N
    : `${_StrToNum<N>}`
  : N;
