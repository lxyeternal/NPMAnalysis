/**
 * Check if a string can be converted to a literal number.
 * @private
 */
export type _CanStrToLiteralNum<S extends string> =
  S extends `${infer R extends number}` ?
    number extends R ?
      false
    : true
  : false;
