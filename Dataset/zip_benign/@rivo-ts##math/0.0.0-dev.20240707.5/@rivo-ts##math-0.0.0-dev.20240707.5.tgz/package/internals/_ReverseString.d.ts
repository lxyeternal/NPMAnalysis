/**
 * Reverse a string.
 *
 * Sig: `(s: string) => string`
 * @private
 */
export type _ReverseString<S extends string> =
  S extends `${infer F}${infer R}` ? `${_ReverseString<R>}${F}` : "";
