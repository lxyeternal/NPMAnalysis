/**
 * Convert a `string` to `bigint`.
 *
 * Sig: `(s: string) => bigint`
 *
 * Type safety is **not guaranteed** if the input string is not a valid number.
 * @private
 */
export type _StrToBigInt<S extends string> = S extends `${infer R extends bigint}` ? R : never;
