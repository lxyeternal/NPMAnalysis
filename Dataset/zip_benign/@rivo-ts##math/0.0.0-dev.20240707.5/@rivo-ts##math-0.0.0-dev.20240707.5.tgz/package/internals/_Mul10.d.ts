import type { _RemoveTrailingFractionalZeroes } from "./_RemoveTrailingFractionalZeroes";
import type { _ReverseString } from "./_ReverseString";
import type { _StrToNum } from "./_StrToNum";

/**
 * Multiply factional number `N` by 10^`Length<By>`.
 *
 * **⚠️ Warning:** `N` must be a fractional number.
 * @private
 *
 * @example
 * ```typescript
 * type R1 = _Mul10<"12.5", "_">;
 * //   ^?: "125"
 * type R2 = _Mul10<"-12.3", "__">;
 * //   ^?: "-1230"
 * type R3 = _Div10<"-1.234", "__">;
 * //   ^?: "-123.4"
 * ```
 */
export type _Mul10<N extends string, By extends string> =
  N extends `${infer IntPart}.${infer FracPart}` ? `${IntPart}${__Mul10<"", By, FracPart>}` : never;
type __Mul10<A extends string, By extends string, B extends string> =
  By extends `${string}${infer RestBy}` ?
    B extends `${infer F}${infer R}` ?
      __Mul10<`${A}${F}`, RestBy, R>
    : __Mul10<`${A}0`, RestBy, B>
  : `${A}${B extends "" ? "" : `.${B}`}`;
