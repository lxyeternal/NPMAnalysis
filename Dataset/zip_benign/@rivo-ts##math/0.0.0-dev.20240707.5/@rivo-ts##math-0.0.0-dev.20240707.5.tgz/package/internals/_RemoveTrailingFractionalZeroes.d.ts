/**
 * Remove trailing fractional zeroes from a string (remove `.` if no fractional part).
 * @private
 */
export type _RemoveTrailingFractionalZeroes<S extends string> =
  S extends `${infer F}0` ? _RemoveTrailingFractionalZeroes<F>
  : S extends `${infer F}.` ? F
  : S;
