/**
 * Converts negative zero to zero.
 * @private
 */
export type _HandleNegativeZero<N extends string> = N extends "-0" ? "0" : N;
