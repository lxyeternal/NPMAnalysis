/**
 * Replace all characters in `S` with `0`.
 * @private
 */
export type _ReplaceAllCharsWithZero<S extends string> =
  S extends `${string}${infer R}` ? `0${_ReplaceAllCharsWithZero<R>}` : "";
