import type { SDivMod } from "./DivMod";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Get the modulo of dividing two `number`s.
 *
 * Sig: `(n: number, m: number) => number`
 */
export type Mod<N extends number, M extends number> =
  N extends N ?
    M extends M ?
      number extends N | M ?
        number
      : _StrToNum<SMod<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Get the modulo of dividing two string representations of `number`s.
 * @private
 */
export type SMod<N extends string, M extends string> = SDivMod<N, M>[1];
