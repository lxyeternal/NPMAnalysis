/**
 * Get the absolute value of a number.
 *
 * Sig: `(n: number | bigint) => number | bigint`
 */
export type Abs<N extends number | bigint> =
  0 extends 1 & N ? number | bigint
  : N extends N ?
    number extends N ? number
    : bigint extends N ? bigint
    : N extends number ?
      `${N}` extends `-${infer N extends number}` ?
        N
      : N
    : N extends bigint ?
      `${N}` extends `-${infer N extends bigint}` ?
        N
      : N
    : N
  : never;
