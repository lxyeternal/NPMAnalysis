import type { _StrToBigInt } from "./internals/_StrToBigInt";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Negate a number.
 *
 * Sig: `(n: number | bigint) => number | bigint`
 *
 * @example
 * ```typescript
 * type R1 = Negate<5>;
 * //   ^?: -5
 * type R2 = Negate<-5n>;
 * //   ^?: 5n
 * type R3 = Negate<0>;
 * //   ^?: 0
 * ```
 */
export type Negate<N extends number | bigint> =
  0 extends 1 & N ? number | bigint
  : N extends N ?
    number extends N ? number
    : bigint extends N ? bigint
    : N extends 0 ? 0
    : N extends 0n ? 0n
    : N extends number ?
      `${N}` extends `-${infer R extends number}` ?
        R
      : _StrToNum<`-${N}`>
    : N extends bigint ?
      `${N}` extends `-${infer R extends bigint}` ?
        R
      : _StrToBigInt<`-${N}`>
    : never
  : never;
