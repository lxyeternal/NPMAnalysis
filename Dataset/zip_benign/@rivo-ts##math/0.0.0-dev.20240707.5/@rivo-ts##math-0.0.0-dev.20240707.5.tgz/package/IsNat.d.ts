export type { IsNat } from "./Nat/IsNat";
