/**
 * Get the absolute value of a `bigint` (not `number`).
 *
 * Sig: `(n: bigint) => bigint`
 * @private
 */
export type _AbsNum<N extends bigint> =
  0 extends 1 & N ? bigint
  : N extends N ?
    bigint extends N ? bigint
    : `${N}` extends `-${infer N extends bigint}` ? N
    : N
  : never;
