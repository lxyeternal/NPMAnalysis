# @rivo-ts/math

Type-level math operations for TypeScript.

This package is essentially an independent part of the [Rivo](https://github.com/Snowflyt/rivo) project which does not rely on [@rivo-ts/core](https://github.com/Snowflyt/rivo/tree/main/core). Many other packages in the Rivo project depend on this package.

You can use it with any TypeScript project that needs type-level math operations, not just Rivo.

## Usage

```typescript
import type { Add, Div, Exp, Pow } from "@rivo-ts/math";

type R1 = Add<1339642.329553, -2775689265.941>;
//   ^?: -2774349623.611447
type R2 = Div<388.6, 15>;
//   ^?: 25.906666666666666
type R3 = Exp<3>;
//   ^?: 20.063392857142855
type R4 = Pow<2, 3>;
//   ^?: 8
type R5 = Pow<2, 0.5>;
//   ^?: 1.414212636572998
```
