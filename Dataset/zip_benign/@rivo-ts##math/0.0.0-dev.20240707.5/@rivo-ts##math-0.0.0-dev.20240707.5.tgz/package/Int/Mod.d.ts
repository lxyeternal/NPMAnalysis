import type { SDivMod } from "./DivMod";
import type { Int } from "../aliases";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Get the modulo of dividing two {@link Int}s.
 *
 * Sig: `(n: Int, m: Int) => Int`
 */
export type Mod<N extends Int, M extends Int> =
  N extends N ?
    M extends M ?
      Int extends N | M ?
        Int
      : _StrToNum<SMod<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Get the modulo of dividing two string representations of {@link Int}s.
 * @private
 */
export type SMod<N extends string, M extends string> = SDivMod<N, M>[1];
