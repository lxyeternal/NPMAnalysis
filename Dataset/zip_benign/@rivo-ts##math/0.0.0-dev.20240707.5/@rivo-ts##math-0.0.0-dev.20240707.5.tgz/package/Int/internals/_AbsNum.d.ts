/**
 * Get the absolute value of a `number` (not `bigint`).
 *
 * Sig: `(n: number) => number`
 * @private
 */
export type _AbsNum<N extends number> =
  0 extends 1 & N ? number
  : N extends N ?
    number extends N ? number
    : `${N}` extends `-${infer N extends number}` ? N
    : N
  : never;
