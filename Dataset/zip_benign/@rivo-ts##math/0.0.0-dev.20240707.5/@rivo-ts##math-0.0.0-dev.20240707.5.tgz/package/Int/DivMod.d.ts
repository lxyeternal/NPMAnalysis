import type { SAdd } from "./Add";
import type { SDivRem } from "./DivRem";
import type { SDivRem as SDivRemNat } from "../Nat/DivRem";
import type { Int } from "../aliases";
import type { _HandleNegativeZero } from "../internals/_HandleNegativeZero";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Get the quotient and modulo of two {@link Int}s.
 *
 * Sign of the modulo is always non-negative.
 *
 * Sig: `(n: Int, m: Int) => [Int, Int]`
 * @private
 */
export type DivMod<N extends Int, M extends Int> =
  Int extends N | M ? [Int, Int]
  : [_StrToNum<SDivMod<`${N}`, `${M}`>[0]>, _StrToNum<SDivMod<`${N}`, `${M}`>[1]>];

/**
 * Get the quotient and modulo of two string representations of {@link Int}s.
 *
 * Sign of the modulo is always non-negative.
 * @private
 */
export type SDivMod<N extends string, M extends string> =
  N extends `-${infer PosN}` ?
    M extends `-${infer PosM}` ?
      [SDivRemNat<PosN, PosM>[0], SDivRem<SAdd<SDivRem<N, PosM>[1], PosM>, PosM>[1]]
    : [_HandleNegativeZero<`-${SDivRemNat<PosN, M>[0]}`>, SDivRem<SAdd<SDivRem<N, M>[1], M>, M>[1]]
  : M extends `-${infer PosM}` ?
    [
      _HandleNegativeZero<`-${SDivRemNat<N, PosM>[0]}`>,
      SDivRem<SAdd<SDivRem<N, PosM>[1], PosM>, PosM>[1],
    ]
  : [SDivRemNat<N, N>[0], SDivRem<SAdd<SDivRem<N, M>[1], M>, M>[1]];
