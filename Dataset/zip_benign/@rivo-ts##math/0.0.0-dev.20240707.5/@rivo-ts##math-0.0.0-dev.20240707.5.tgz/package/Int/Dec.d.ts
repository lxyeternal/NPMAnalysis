import type { Sub } from "./Sub";
import type { Int } from "../aliases";

/**
 * Subtract 1 from an {@link Int}.
 *
 * Sig: `(n: Int) => Int`
 */
export type Dec<N extends Int> = Sub<N, 1>;
