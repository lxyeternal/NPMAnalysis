import type { _AbsNum } from "./internals/_AbsNum";
import type { SMul as SMulNat } from "../Nat/Mul";
import type { Int } from "../aliases";
import type { _HandleNegativeZero } from "../internals/_HandleNegativeZero";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Multiply two {@link Int}s.
 *
 * Sig: `(n: Int, m: Int) => Int`
 */
export type Mul<N extends Int, M extends Int> =
  Int extends N | M ? Int : _StrToNum<SMul<`${N}`, `${M}`>>;

/**
 * Multiply two string representations of {@link Int}s.
 * @private
 */
export type SMul<N extends string, M extends string> = _HandleNegativeZero<
  N extends `-${infer N}` ?
    M extends `-${infer M}` ?
      SMulNat<N, M>
    : `-${SMulNat<N, M>}`
  : M extends `-${infer M}` ? `-${SMulNat<N, M>}`
  : SMulNat<N, M>
>;
