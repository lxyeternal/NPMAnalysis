import type { Add } from "./Add";
import type { Int } from "../aliases";

/**
 * Add 1 to an {@link Int}.
 *
 * Sig: `(n: Int) => Int`
 */
export type Inc<N extends Int> = Add<N, 1>;
