import type { SDivRem } from "./DivRem";
import type { Int } from "../aliases";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Get the remainder of dividing two {@link Int}s.
 *
 * Sig: `(n: Int, m: Int) => Int`
 */
export type Rem<N extends Int, M extends Int> =
  N extends N ?
    M extends M ?
      Int extends N | M ?
        Int
      : _StrToNum<SRem<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Get the remainder of dividing two string representations of {@link Int}s.
 * @private
 */
export type SRem<N extends string, M extends string> = SDivRem<N, M>[1];
