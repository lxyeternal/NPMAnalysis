import type { _AbsNum } from "./internals/_AbsNum";
import type { SAdd as SAddNat } from "../Nat/Add";
import type { SCompare as SCompareNat } from "../Nat/Compare";
import type { SSub as SSubNat } from "../Nat/Sub";
import type { Int, LT } from "../aliases";
import type { _HandleNegativeZero } from "../internals/_HandleNegativeZero";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Subtract two {@link Int}s.
 *
 * Sig: `(n: Int, m: Int) => Int`
 */
export type Sub<N extends Int, M extends Int> =
  Int extends N | M ? Int : _StrToNum<SSub<`${N}`, `${M}`>>;

/**
 * Subtract two string representations of {@link Int}s.
 * @private
 */
export type SSub<N extends string, M extends string> = _HandleNegativeZero<
  N extends `-${infer N}` ?
    M extends `-${infer M}` ?
      SCompareNat<N, M> extends LT ?
        SSubNat<M, N>
      : `-${SSubNat<N, M>}`
    : `-${SAddNat<N, M>}`
  : M extends `-${infer M}` ? SAddNat<N, M>
  : SCompareNat<N, M> extends LT ? `-${SSubNat<M, N>}`
  : SSubNat<N, M>
>;
