import type { SDivRem as SDivRemNat } from "../Nat/DivRem";
import type { Int } from "../aliases";
import type { _HandleNegativeZero } from "../internals/_HandleNegativeZero";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Get the quotient and remainder of two {@link Int}s.
 *
 * Sign of the remainder is the same as the sign of the dividend.
 *
 * Sig: `(n: Int, m: Int) => [Int, Int]`
 * @private
 */
export type DivRem<N extends Int, M extends Int> =
  Int extends N | M ? [Int, Int]
  : [_StrToNum<SDivRem<`${N}`, `${M}`>[0]>, _StrToNum<SDivRem<`${N}`, `${M}`>[1]>];

/**
 * Get the quotient and remainder of two string representations of {@link Int}s.
 *
 * Sign of the remainder is the same as the sign of the dividend.
 * @private
 */
export type SDivRem<N extends string, M extends string> =
  N extends `-${infer N}` ?
    M extends `-${infer M}` ?
      [SDivRemNat<N, M>[0], _HandleNegativeZero<`-${SDivRemNat<N, M>[1]}`>]
    : [
        _HandleNegativeZero<`-${SDivRemNat<N, M>[0]}`>,
        _HandleNegativeZero<`-${SDivRemNat<N, M>[1]}`>,
      ]
  : M extends `-${infer M}` ? [_HandleNegativeZero<`-${SDivRemNat<N, M>[0]}`>, SDivRemNat<N, M>[1]]
  : SDivRemNat<N, M>;
