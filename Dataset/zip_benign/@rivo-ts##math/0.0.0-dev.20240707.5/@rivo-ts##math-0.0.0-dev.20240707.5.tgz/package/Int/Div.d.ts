import type { SDivRem } from "./DivRem";
import type { Int } from "../aliases";

/**
 * Divide two {@link Int}s.
 *
 * Sig: `(n: Int, m: Int) => Int`
 */
export type Div<N extends Int, M extends Int> =
  N extends N ?
    M extends M ?
      Int extends N | M ?
        Int
      : SDiv<`${N}`, `${M}`>
    : never
  : never;

/**
 * Divide two string representations of {@link Int}s.
 * @private
 */
export type SDiv<N extends string, M extends string> = SDivRem<N, M>[0];
