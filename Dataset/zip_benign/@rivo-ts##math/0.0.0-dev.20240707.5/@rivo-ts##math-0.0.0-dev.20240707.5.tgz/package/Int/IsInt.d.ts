// @ts-ignore - Only used in doc comments
import type { Int } from "../aliases";

/**
 * Check if a value is {@link Int}.
 *
 * Sig: `(x: unknown) => boolean`
 */
export type IsInt<T> =
  T extends string | number | bigint ?
    number extends T ? boolean
    : bigint extends T ? boolean
    : `${T}` extends `${bigint}` ? true
    : false
  : false;
