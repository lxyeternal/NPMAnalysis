/**
 * Check if a number is negative.
 *
 * Sig: `(n: number | bigint) => boolean`
 */
export type IsNeg<N extends number | bigint> =
  N extends N ?
    number extends N ? boolean
    : bigint extends N ? boolean
    : `${N}` extends `-${string}` ? true
    : false
  : never;
