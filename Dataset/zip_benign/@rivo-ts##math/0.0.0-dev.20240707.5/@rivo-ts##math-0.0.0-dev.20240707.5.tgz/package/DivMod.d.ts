import type { SAdd } from "./Add";
import type { SDivRem } from "./DivRem";
import type { SDivRem as SDivRemNat } from "./Nat/DivRem";
import type { _AddTrailingZeroesToSameLength } from "./internals/_AddTrailingZeroesToSameLength";
import type { _CanStrToLiteralNum } from "./internals/_CanStrToLiteralNum";
import type { _Div10 } from "./internals/_Div10";
import type { _HandleNegativeZero } from "./internals/_HandleNegativeZero";
import type { _RemoveTrailingFractionalZeroes } from "./internals/_RemoveTrailingFractionalZeroes";
import type { _ReplaceAllCharsWithZero } from "./internals/_ReplaceAllCharsWithZero";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Get the quotient and modulo of dividing two `number`s.
 *
 * Sign of the modulo is always non-negative.
 *
 * Sig: `(n: number, m: number) => number`
 */
export type DivMod<N extends number, M extends number> =
  N extends N ?
    M extends M ?
      SDivMod<`${N}`, `${M}`> extends [infer Div extends string, infer Rem extends string] ?
        [_StrToNum<Div>, _StrToNum<Rem>]
      : never
    : never
  : never;

/**
 * Get the quotient and modulo of dividing two string representations of `number`s.
 *
 * Sign of the modulo is always non-negative.
 * @private
 */
export type SDivMod<N extends string, M extends string> =
  N extends `-${infer PosN}` ?
    M extends `-${infer PosM}` ?
      [SDivRemNat<PosN, PosM>[0], SDivRem<SAdd<SDivRem<N, PosM>[1], PosM>, PosM>[1]]
    : [_HandleNegativeZero<`-${SDivRemNat<PosN, M>[0]}`>, SDivRem<SAdd<SDivRem<N, M>[1], M>, M>[1]]
  : M extends `-${infer PosM}` ?
    [
      _HandleNegativeZero<`-${SDivRemNat<N, PosM>[0]}`>,
      SDivRem<SAdd<SDivRem<N, PosM>[1], PosM>, PosM>[1],
    ]
  : [SDivRemNat<N, N>[0], SDivRem<SAdd<SDivRem<N, M>[1], M>, M>[1]];
