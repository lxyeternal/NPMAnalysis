import type { SDiv } from "./Div";
import type { SExp } from "./Exp";
import type { SLn } from "./Ln";
import type { SMul } from "./Mul";
import type { SSub as SSubNat } from "./Nat/Sub";
import type { _StrToNum } from "./internals/_StrToNum";

/**
 * Calculate the power of a `number`.
 *
 * Sig: `(base: number, exponent: number) => number`
 *
 * @example
 * ```typescript
 * type R1 = Pow<2, 3>;
 * //   ^?: 8
 * type R2 = Pow<2, 0.5>;
 * //   ^?: 1.414212636572998
 * ```
 */
export type Pow<Base extends number, Exponent extends number> =
  Base extends Base ?
    number extends Base ?
      number
    : _StrToNum<SPow<`${Base}`, `${Exponent}`>>
  : never;

/**
 * Calculate the power of the string representation of a `number`.
 *
 * Sig: `(base: string, exponent: string) => string`
 * @private
 */
export type SPow<Base extends string, Exponent extends string> =
  (
    Exponent extends "0" ? "1"
    : Exponent extends `-${string}` ? SDiv<"1", SPow<Base, `-${Exponent}`>>
    : Exponent extends `${string}.${string}` ?
      SLn<Base> extends infer R extends string ?
        SExp<SMul<Exponent, R>>
      : never
    : _SIntPow<Base, Exponent, "1">
  ) extends infer R extends string ?
    R
  : never;

type _SIntPow<Base extends string, Exponent extends string, Result extends string> =
  Exponent extends "0" ? Result : _SIntPow<Base, SSubNat<Exponent, "1">, SMul<Result, Base>>;
