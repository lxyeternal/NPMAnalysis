import type { SAdd } from "./Add";
import type { SCompare } from "./Compare";
import type { SMul } from "./Mul";
import type { SSub } from "./Sub";
import type { LT, Nat } from "../aliases";
import type { _ReplaceAllCharsWithZero } from "../internals/_ReplaceAllCharsWithZero";
import type { _StrToNum } from "../internals/_StrToNum";
import type { _RemoveStrPaddingZeroes } from "./internals/_RemoveStrPaddingZeroes";

/**
 * Get the quotient and remainder of dividing two {@link Nat}s.
 *
 * Sig: `(n: Nat, m: Nat) => [Nat, Nat]`
 */
export type DivMod<N extends Nat, M extends Nat> =
  N extends N ?
    M extends M ?
      Nat extends N | M ? [Nat, Nat]
      : M extends 0 ? never
      : SDivMod<`${N}`, `${M}`> extends [infer Q extends string, infer R extends string] ?
        [_StrToNum<Q>, _StrToNum<R>]
      : never
    : never
  : never;

/**
 * Get the quotient and remainder of dividing two string representations of {@link Nat}s.
 * @private
 */
export type SDivMod<N extends string, M extends string> =
  _TakeSameLength<N, M> extends [infer Left extends string, infer Right extends string] ?
    _SDivMod<Left, Right, M, "">
  : never;
export type _SDivMod<
  Left extends string,
  Right extends string,
  M extends string,
  Q extends string,
> =
  __SDivMod<Left, M> extends [infer Div extends string, infer Mod extends string] ?
    Right extends "" ? [SAdd<Q, Div>, Mod]
    : Div extends "0" ?
      Right extends `${infer F}${infer R}` ?
        _SDivMod<`${Left}${F}`, R, M, `${Q}0`>
      : never
    : Right extends `${infer F}${infer R}` ?
      _SDivMod<_RemoveStrPaddingZeroes<`${Mod}${F}`>, R, M, `${SAdd<Q, Div>}0`>
    : never
  : never;
type __SDivMod<N extends string, M extends string, Try extends string = "9"> =
  SMul<M, Try> extends infer R extends string ?
    SCompare<N, R> extends LT ?
      __SDivMod<N, M, SSub<Try, "1">>
    : [Try, SSub<N, R>]
  : never;
/**
 * @private
 *
 * @example
 * ```typescript
 * type R = _DivModSameLength<"4567", "12">;
 * //	^ = type R = ["45", "67"]
 * ```
 */
type _TakeSameLength<N extends string, M extends string, Result extends string = ""> =
  N extends `${infer F}${infer R}` ?
    M extends `${string}${infer S}` ?
      _TakeSameLength<R, S, `${Result}${F}`>
    : [Result, N]
  : [Result, ""];
