import type { _CompareDigit } from "./internals/_CompareDigit";
import type { _CompareSDigit } from "./internals/_CompareSDigit";
import type { _CompareStrLength } from "./internals/_CompareStrLength";
import type { EQ, Nat, Ordering, SDigit } from "../aliases";

/**
 * Compare two {@link Nat}s.
 *
 * Sig: `(n: Nat, m: Nat) => Ordering`
 */
export type Compare<N extends Nat, M extends Nat> =
  N extends N ?
    M extends M ?
      Nat extends N | M ?
        Ordering
      : SCompare<`${N}`, `${M}`>
    : never
  : never;

/**
 * Compare two string representations of {@link Nat}s.
 * @private
 */
export type SCompare<N extends string, M extends string> =
  N extends M ? EQ
  : _CompareStrLength<N, M> extends infer O extends Ordering ?
    O extends EQ ?
      _CompareSNatRec<N, M>
    : O
  : never;

/**
 * Compare two string representations of {@link Nat}s.
 *
 * **⚠️ Warning:** `N` must be of the same length as `M`.
 * @private
 */
type _CompareSNatRec<N extends string, M extends string> =
  N extends `${infer F extends SDigit}${infer R}` ?
    M extends `${infer G extends SDigit}${infer S}` ?
      _CompareSDigit<F, G> extends EQ ?
        _CompareSNatRec<R, S>
      : _CompareSDigit<F, G>
    : never
  : EQ;
