import type { SAdd } from "./Add";
import type { Nat } from "../aliases";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Add 1 to a {@link Nat}.
 *
 * Sig: `(n: Nat) => Nat`
 */
export type Inc<N extends Nat> = N extends N ? _StrToNum<SAdd<`${N}`, "1">> : never;
