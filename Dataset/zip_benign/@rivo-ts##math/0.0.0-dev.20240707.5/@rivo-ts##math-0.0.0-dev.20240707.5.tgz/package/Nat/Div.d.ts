import type { SDivMod } from "./DivMod";
import type { Nat } from "../aliases";

/**
 * Divide two {@link Nat}s.
 *
 * Sig: `(n: Nat, m: Nat) => Nat`
 */
export type Div<N extends Nat, M extends Nat> =
  N extends N ?
    M extends M ?
      Nat extends N | M ?
        Nat
      : SDiv<`${N}`, `${M}`>
    : never
  : never;

/**
 * Divide two string representations of {@link Nat}s.
 * @private
 */
export type SDiv<N extends string, M extends string> = SDivMod<N, M>[0];
