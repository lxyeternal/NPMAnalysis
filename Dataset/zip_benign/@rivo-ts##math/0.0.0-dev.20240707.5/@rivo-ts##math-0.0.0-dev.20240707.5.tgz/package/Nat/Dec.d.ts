import type { SSub } from "./Sub";
import type { Nat } from "../aliases";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Subtract 1 from a {@link Nat}.
 *
 * Sig: `(n: Nat) => Nat`
 *
 * **⚠️ Warning:** `N` must be greater than or equal to 1.
 */
export type Dec<N extends Nat> = N extends N ? _StrToNum<SSub<`${N}`, "1">> : never;
