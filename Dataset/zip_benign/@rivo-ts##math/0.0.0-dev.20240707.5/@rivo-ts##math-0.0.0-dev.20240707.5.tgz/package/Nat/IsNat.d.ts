// @ts-ignore - Only used in doc comments
import type { Nat } from "../aliases";

/**
 * Check if a value is {@link Nat}.
 *
 * Sig: `(x: unknown) => boolean`
 */
export type IsNat<T> =
  T extends string | number | bigint ?
    number extends T ? boolean
    : bigint extends T ? boolean
    : `${T}` extends `-${bigint}` ? false
    : `${T}` extends `${bigint}` ? true
    : false
  : false;
