import type { Digit } from "../../aliases";

/**
 * Subtract two {@link Digit}s.
 *
 * Sig: `(n: Digit, m: Digit) => Digit`
 *
 * **⚠️ Warning:** `N` must be greater than or equal to `M`.
 * @private
 */
export type _SubDigit<N extends Digit, M extends Digit> =
  M extends 0 ? N
  : N extends 0 ? 0
  : N extends 1 ? 0
  : N extends 2 ?
    // prettier-ignore
    M extends 1 ? 1 : 0
  : N extends 3 ?
    // prettier-ignore
    M extends 1 ? 2 : M extends 2 ? 1 : 0
  : N extends 4 ?
    // prettier-ignore
    M extends 1 ? 3 : M extends 2 ? 2 : M extends 3 ? 1 : 0
  : N extends 5 ?
    // prettier-ignore
    M extends 1 ? 4 : M extends 2 ? 3 : M extends 3 ? 2 : M extends 4 ? 1 : 0
  : N extends 6 ?
    // prettier-ignore
    M extends 1 ? 5 : M extends 2 ? 4 : M extends 3 ? 3 : M extends 4 ? 2 : M extends 5 ? 1 : 0
  : N extends 7 ?
    // prettier-ignore
    M extends 1 ? 6 : M extends 2 ? 5 : M extends 3 ? 4 : M extends 4 ? 3 : M extends 5 ? 2 : M extends 6 ? 1 : 0
  : N extends 8 ?
    // prettier-ignore
    M extends 1 ? 7 : M extends 2 ? 6 : M extends 3 ? 5 : M extends 4 ? 4 : M extends 5 ? 3 : M extends 6 ? 2 : M extends 7 ? 1 : 0
  : // prettier-ignore
  M extends 1 ? 8 : M extends 2 ? 7 : M extends 3 ? 6 : M extends 4 ? 5 : M extends 5 ? 4 : M extends 6 ? 3 : M extends 7 ? 2 : M extends 8 ? 1 : 0;
