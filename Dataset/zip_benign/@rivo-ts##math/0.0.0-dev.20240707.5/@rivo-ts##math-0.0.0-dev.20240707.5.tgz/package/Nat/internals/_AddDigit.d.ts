import type { Digit } from "../../aliases";

/**
 * Add two {@link Digit}s.
 *
 * Sig: `(n: Digit, m: Digit) => Digit`
 * @private
 */
export type _AddDigit<N extends Digit, M extends Digit> =
  N extends 0 ? M
  : M extends 0 ? N
  : N extends 1 ?
    // prettier-ignore
    M extends 1 ? 2 : M extends 2 ? 3 : M extends 3 ? 4 : M extends 4 ? 5 : M extends 5 ? 6 : M extends 6 ? 7 : M extends 7 ? 8 : M extends 8 ? 9 : 10
  : N extends 2 ?
    // prettier-ignore
    M extends 1 ? 3 : M extends 2 ? 4 : M extends 3 ? 5 : M extends 4 ? 6 : M extends 5 ? 7 : M extends 6 ? 8 : M extends 7 ? 9 : M extends 8 ? 10 : 11
  : N extends 3 ?
    // prettier-ignore
    M extends 1 ? 4 : M extends 2 ? 5 : M extends 3 ? 6 : M extends 4 ? 7 : M extends 5 ? 8 : M extends 6 ? 9 : M extends 7 ? 10 : M extends 8 ? 11 : 12
  : N extends 4 ?
    // prettier-ignore
    M extends 1 ? 5 : M extends 2 ? 6 : M extends 3 ? 7 : M extends 4 ? 8 : M extends 5 ? 9 : M extends 6 ? 10 : M extends 7 ? 11 : M extends 8 ? 12 : 13
  : N extends 5 ?
    // prettier-ignore
    M extends 1 ? 6 : M extends 2 ? 7 : M extends 3 ? 8 : M extends 4 ? 9 : M extends 5 ? 10 : M extends 6 ? 11 : M extends 7 ? 12 : M extends 8 ? 13 : 14
  : N extends 6 ?
    // prettier-ignore
    M extends 1 ? 7 : M extends 2 ? 8 : M extends 3 ? 9 : M extends 4 ? 10 : M extends 5 ? 11 : M extends 6 ? 12 : M extends 7 ? 13 : M extends 8 ? 14 : 15
  : N extends 7 ?
    // prettier-ignore
    M extends 1 ? 8 : M extends 2 ? 9 : M extends 3 ? 10 : M extends 4 ? 11 : M extends 5 ? 12 : M extends 6 ? 13 : M extends 7 ? 14 : M extends 8 ? 15 : 16
  : N extends 8 ?
    // prettier-ignore
    M extends 1 ? 9 : M extends 2 ? 10 : M extends 3 ? 11 : M extends 4 ? 12 : M extends 5 ? 13 : M extends 6 ? 14 : M extends 7 ? 15 : M extends 8 ? 16 : 17
  : // prettier-ignore
  M extends 1 ? 10 : M extends 2 ? 11 : M extends 3 ? 12 : M extends 4 ? 13 : M extends 5 ? 14 : M extends 6 ? 15 : M extends 7 ? 16 : M extends 8 ? 17 : 18;
