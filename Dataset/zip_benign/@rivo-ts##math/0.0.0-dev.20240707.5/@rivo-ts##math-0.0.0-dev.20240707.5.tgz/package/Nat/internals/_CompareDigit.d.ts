import type { Digit, EQ, GT, LT } from "../../aliases";

/**
 * Compare two {@link Digit}s.
 *
 * Sig: `(n: Digit, m: Digit) => Ordering`
 * @private
 */
export type _CompareDigit<N extends Digit, M extends Digit> =
  N extends M ? EQ
  : N extends 0 ? LT
  : N extends 1 ?
    // prettier-ignore
    M extends 0 ? GT : LT
  : N extends 2 ?
    // prettier-ignore
    M extends 0 | 1 ? GT : LT
  : N extends 3 ?
    // prettier-ignore
    M extends 0 | 1 | 2 ? GT : LT
  : N extends 4 ?
    // prettier-ignore
    M extends 0 | 1 | 2 | 3 ? GT : LT
  : N extends 5 ?
    // prettier-ignore
    M extends 0 | 1 | 2 | 3 | 4 ? GT : LT
  : N extends 6 ?
    // prettier-ignore
    M extends 0 | 1 | 2 | 3 | 4 | 5 ? GT : LT
  : N extends 7 ?
    // prettier-ignore
    M extends 0 | 1 | 2 | 3 | 4 | 5 | 6 ? GT : LT
  : N extends 8 ?
    // prettier-ignore
    M extends 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 ? GT : LT
  : // prettier-ignore
  M extends 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 ? GT : LT;
