/**
 * Remove padding `0`s from the start of a string (automatically skips the first `-` if present).
 *
 * Sig: `(s: string) => string`
 * @private
 */
export type _RemoveStrPaddingZeroes<S extends string> =
  S extends `-${infer S}` ? `-${__RemoveStrPaddingZeroes<S>}` : __RemoveStrPaddingZeroes<S>;
type __RemoveStrPaddingZeroes<S extends string> =
  S extends "0" ? S
  : S extends `0${infer R}` ? __RemoveStrPaddingZeroes<R>
  : S;
