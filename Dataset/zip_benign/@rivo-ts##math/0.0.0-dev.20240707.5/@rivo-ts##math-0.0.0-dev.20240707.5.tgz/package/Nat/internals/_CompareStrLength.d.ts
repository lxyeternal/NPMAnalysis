import type { EQ, GT, LT } from "../../aliases";

/**
 * Compare the length of two strings.
 *
 * Sig: `(s1: string, s2: string) => Ordering`
 * @private
 */
export type _CompareStrLength<S1 extends string, S2 extends string> =
  S1 extends `${string}${infer R}` ?
    S2 extends `${string}${infer S}` ?
      _CompareStrLength<R, S>
    : GT
  : S2 extends "" ? EQ
  : LT;
