import type { _AddDigit } from "./internals/_AddDigit";
import type { _CompareDigit } from "./internals/_CompareDigit";
import type { _RemoveStrPaddingZeroes } from "./internals/_RemoveStrPaddingZeroes";
import type { _SubDigit } from "./internals/_SubDigit";
import type { Digit, EQ, GT, Nat } from "../aliases";
import type { _ReverseString } from "../internals/_ReverseString";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Subtract two {@link Nat}s.
 *
 * Sig: `(n: Nat, m: Nat) => Nat`
 *
 * **⚠️ Warning:** `N` must be greater than or equal to `M`.
 */
export type Sub<N extends Nat, M extends Nat> =
  N extends N ?
    M extends M ?
      Nat extends N | M ?
        Nat
      : _StrToNum<SSub<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Subtract two string representations of {@link Nat}s.
 *
 * **⚠️ Warning:** `N` must be greater than or equal to `M`.
 * @private
 */
export type SSub<N extends string, M extends string> = _RemoveStrPaddingZeroes<
  _ReverseString<_SSub<_ReverseString<N>, _ReverseString<M>>>
>;
type _SSub<
  N extends string,
  M extends string,
  Borrow extends 0 | 1 = 0,
  Result extends string = "",
> =
  N extends `${infer F extends Digit}${infer R}` ?
    M extends `${infer G extends Digit}${infer S}` ?
      Borrow extends 0 ?
        _CompareDigit<F, G> extends EQ | GT ?
          _SSub<R, S, 0, `${Result}${_SubDigit<F, G>}`>
        : // prettier-ignore
          _SSub<R, S, 1, `${Result}${_AddDigit<_AddDigit<_SubDigit<9, G>, 1> extends infer U extends Digit ? U : never, F>}`>
      : F extends 0 ? _SSub<R, S, 1, `${Result}${_SubDigit<9, G>}`>
      : _CompareDigit<_SubDigit<F, 1>, G> extends EQ | GT ?
        _SSub<R, S, 0, `${Result}${_SubDigit<_SubDigit<F, 1>, G>}`>
      : // prettier-ignore
        _SSub<R, S, 1, `${Result}${_AddDigit<_SubDigit<9, G>, F>}`>
    : Borrow extends 1 ? `${Result}${_SSub<N, "1">}`
    : `${Result}${N}`
  : Borrow extends 1 ? `${Result}1`
  : Result;
