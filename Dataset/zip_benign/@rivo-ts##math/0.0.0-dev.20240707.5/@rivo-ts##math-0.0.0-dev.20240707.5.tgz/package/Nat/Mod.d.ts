import type { SDivMod } from "./DivMod";
import type { Nat } from "../aliases";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Get the remainder of dividing two {@link Nat}s.
 *
 * Sig: `(n: Nat, m: Nat) => Nat`
 */
export type Mod<N extends Nat, M extends Nat> =
  N extends N ?
    M extends M ?
      Nat extends N | M ?
        Nat
      : _StrToNum<SMod<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Get the remainder of dividing two string representations of {@link Nat}s.
 * @private
 */
export type SMod<N extends string, M extends string> = SDivMod<N, M>[1];
