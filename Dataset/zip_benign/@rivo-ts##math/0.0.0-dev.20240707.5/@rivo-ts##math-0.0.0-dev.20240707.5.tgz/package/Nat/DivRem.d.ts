export type { DivMod as DivRem, SDivMod as SDivRem } from "./DivMod";
