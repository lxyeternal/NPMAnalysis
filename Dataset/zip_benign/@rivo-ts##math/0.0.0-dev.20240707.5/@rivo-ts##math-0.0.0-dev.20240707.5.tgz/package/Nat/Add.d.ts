import type { _AddDigit } from "./internals/_AddDigit";
import type { _CompareStrLength } from "./internals/_CompareStrLength";
import type { Digit, GT, Nat } from "../aliases";
import type { _ReverseString } from "../internals/_ReverseString";
import type { _StrToNum } from "../internals/_StrToNum";

/**
 * Add two {@link Nat}s.
 *
 * Sig: `(n: Nat, m: Nat) => Nat`
 */
export type Add<N extends Nat, M extends Nat> =
  N extends N ?
    M extends M ?
      Nat extends N | M ?
        Nat
      : _StrToNum<SAdd<`${N}`, `${M}`>>
    : never
  : never;

/**
 * Add two string representations of {@link Nat}s.
 * @private
 */
export type SAdd<N extends string, M extends string> =
  _CompareStrLength<N, M> extends GT ? _ReverseString<_SAdd<_ReverseString<N>, _ReverseString<M>>>
  : _ReverseString<_SAdd<_ReverseString<M>, _ReverseString<N>>>;
type _SAdd<
  N extends string,
  M extends string,
  Carry extends 0 | 1 = 0,
  Result extends string = "",
> =
  N extends `${infer F extends Digit}${infer R}` ?
    M extends `${infer G extends Digit}${infer S}` ?
      _AddDigit<F, G> extends infer D extends Nat ?
        `${D}` extends `1${infer D extends Digit}` ?
          _SAdd<R, S, 1, `${Result}${Carry extends 1 ? _AddDigit<D, 1> : D}`>
        : D extends Digit ?
          [D, Carry] extends [9, 1] ?
            _SAdd<R, S, 1, `${Result}0`>
          : _SAdd<R, S, 0, `${Result}${Carry extends 1 ? _AddDigit<D, 1> : D}`>
        : never
      : never
    : Carry extends 1 ? `${Result}${_SAdd<N, "1">}`
    : `${Result}${N}`
  : Carry extends 1 ? `${Result}1`
  : Result;
