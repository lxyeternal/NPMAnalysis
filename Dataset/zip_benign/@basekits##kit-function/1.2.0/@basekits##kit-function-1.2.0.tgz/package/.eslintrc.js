module.exports = {
  env: {
    es6: true
  },
  parserOptions: {
    ecmaVersion: 2017
  }
}
