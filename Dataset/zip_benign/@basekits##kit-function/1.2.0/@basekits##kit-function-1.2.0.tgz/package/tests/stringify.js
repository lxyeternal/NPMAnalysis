const assert = require('assert')
const kit = require('@basekits/core')
const kitType = require('@basekits/kit-type')
const kitError = require('@basekits/kit-error')
kit.addKit(kitType)
kit.addKit(kitError)
kit.addKit(require('../source'))

assert.strictEqual( kit.stringify(null), 'null' )

const obj = {a: {b: 1}, c: undefined}
assert.strictEqual( kit.stringify(obj), JSON.stringify(obj) )

const arr = ['hey', obj, 8999, undefined, false]
assert.strictEqual( kit.stringify(arr), JSON.stringify(arr) )
