const assert = require('assert')
const kit = require('@basekits/core')
const kitType = require('@basekits/kit-type')
const kitError = require('@basekits/kit-error')
kit.addKit(kitType)
kit.addKit(kitError)
kit.addKit(require('../source'))

assert.strictEqual( kit.destringify('true'), 'true' )
assert.strictEqual( kit.destringify('true', 'boolean'), true )

const obj = {hey: 'you'}
assert.strictEqual( kit.destringify(JSON.stringify(obj)), JSON.stringify(obj) )
assert.strictEqual(
  JSON.stringify(kit.destringify(JSON.stringify(obj), 'object')),
  JSON.stringify(obj)
)

assert.strictEqual( kit.destringify('9.99'), '9.99' )
assert.strictEqual( kit.destringify('9.99', 'number'), 9.99 )
