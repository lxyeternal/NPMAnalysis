# @basekits/kit-function
Helper functions kit for [basekits](https://github.com/basekits/core).

## Install
```sh
npm i @basekits/kit-type @basekits/kit-error @basekits/kit-function
```

## Usage
```js
const kit = require('@basekits/core')
const type = require('@basekits/kit-type')
const error = require('@basekits/kit-error')
const fn = require('@basekits/kit-function')
kit.addKit(type)
kit.addKit(error)
kit.addKit(fn)
```

## Available Items
The following methods will be available after adding this kit:

**.waitForIt(condition, callback, interval = 300, timeout = 10000)**

Runs `condition` function every `interval` miliseconds and runs `callback` if condition function returns true. The `callback` will also be run if `condition` doesn't return true after `timeout` miliseconds.

```js
// wait for library to be available
function checkLib() {
  return 'someLibrary' in window
}

function useLibrary() {
  window.someLibrary.someMethod.call()
}

kit.waitForIt(checkLib, useLibrary)
// interval is 0.3 and timeout is 10 seconds by default
```

---

**.debounce(func, wait, options)**

[An article](https://css-tricks.com/the-difference-between-throttling-and-debouncing/) that explains what debounce and throttle does. Implementation of `debounce` and `throttle` taken from [lodash](https://github.com/lodash/lodash/blob/4.17.11/lodash.js#L10306).

---

**.throttle(func, wait, options)**

[An article](https://css-tricks.com/the-difference-between-throttling-and-debouncing/) that explains what debounce and throttle does. Implementation of `debounce` and `throttle` taken from [lodash](https://github.com/lodash/lodash/blob/4.17.11/lodash.js#L10898).

---

**.stringify(value)**

Stringifies the input. Input can be one of basekits types: `error`, `object`, `array`, `string`, `number`, `boolean`, `null`, `undefined`, `nan`, `date`, `function`, `bigint` or `domelement`. It will give you the `innerText` property in the case of a `domElement`. Returns an empty string in the case of unrecognized types.

---

**.destringify(value, type = null)**

Destringifies the input according to `type`. Returns value as it is if `type` left empty. `type` is one of basekits type.

---
