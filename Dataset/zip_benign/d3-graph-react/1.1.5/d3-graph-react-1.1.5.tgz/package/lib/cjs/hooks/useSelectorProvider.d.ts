import { BaseType, Selection } from 'd3-selection';
import { FC, ReactNode } from 'react';
export type ISelectorsContext = {
    containerSelector: () => Selection<BaseType, unknown, HTMLElement, any>;
    svgSelector: () => Selection<SVGElement, unknown, HTMLElement, any>;
    gSelector: () => Selection<SVGGraphicsElement, unknown, HTMLElement, any>;
};
export declare const SelectorsContext: import("react").Context<ISelectorsContext | null>;
export declare const useSelectorsContext: () => ISelectorsContext;
export declare const SelectorsProvider: FC<{
    children: ReactNode;
    containerId?: string;
}>;
