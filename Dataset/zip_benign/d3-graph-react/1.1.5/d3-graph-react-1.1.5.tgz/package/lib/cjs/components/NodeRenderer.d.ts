import { Node, NodeComponentType, NodeType } from '../Graph';
export declare const NodeRenderer: <N extends Node>({ nodes, simNodes, nodeRefs, NodeComponent, }: {
    nodes: N[];
    simNodes: NodeType[];
    nodeRefs: React.RefObject<HTMLDivElement>[];
    NodeComponent?: NodeComponentType<N>;
}) => import("react/jsx-runtime").JSX.Element;
