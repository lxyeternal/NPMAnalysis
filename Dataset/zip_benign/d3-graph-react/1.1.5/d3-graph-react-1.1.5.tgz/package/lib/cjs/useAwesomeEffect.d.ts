import { DependencyList, EffectCallback } from 'react';
export declare function useAwesomeEffect(effect: EffectCallback, deps?: DependencyList): void;
