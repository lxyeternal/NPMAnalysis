export declare function constantHash(arg: any): string;
