import { D3ZoomEvent } from 'd3-zoom';
import React, { RefObject } from 'react';
import './index.css';
export type Node = {
    id: string | number;
};
export type Link = {
    source: number;
    target: number;
};
export type NodeType = {
    index: number;
    id: string | number;
    x: number;
    y: number;
    vx: number;
    vy: number;
    fx?: number | null;
    fy?: number | null;
};
export declare const DEFAULT_LINK_LENGTH = 200;
export type NodeComponentType<N> = React.FC<{
    node: N;
}>;
export type LinkComponentType<L> = React.FC<{
    link: L;
    sourceNode: NodeType;
    sourceNodeRef: RefObject<HTMLDivElement>;
    targetNode: NodeType;
    targetNodeRef: RefObject<HTMLDivElement>;
}>;
export type GraphType<N extends Node = Node, L extends Link = Link> = {
    graph: {
        nodes: N[];
        links: L[];
    };
    NodeComponent?: NodeComponentType<N>;
    LinkComponent?: LinkComponentType<L>;
    zoomScale?: [number, number];
    onZoom?: (d3zoomEven: D3ZoomEvent<SVGElement, unknown>) => any;
    linkForce?: {
        strength: number;
        length: number;
    };
    gravityForce?: {
        strength: number;
        center_x: number;
        center_y: number;
    };
    chargeForce?: {
        strength: number;
    };
    isNodeDraggable?: boolean;
    containerId?: string;
    containerClassName?: string;
    svgClassName?: string;
};
export declare function Graph<N extends Node, L extends Link>(props: GraphType<N, L>): import("react/jsx-runtime").JSX.Element;
export default Graph;
