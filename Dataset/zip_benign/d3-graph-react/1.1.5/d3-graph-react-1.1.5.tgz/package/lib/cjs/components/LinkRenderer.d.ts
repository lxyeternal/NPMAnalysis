import { SimulationLinkDatum } from 'd3-force';
import { Link, LinkComponentType, NodeType } from '../Graph';
export declare const LinkRenderer: <L extends Link>({ simLinks, links, nodeRefs, LinkComponent, }: {
    simLinks: SimulationLinkDatum<NodeType>[];
    links: L[];
    nodeRefs: React.RefObject<HTMLDivElement>[];
    LinkComponent?: LinkComponentType<L>;
}) => import("react/jsx-runtime").JSX.Element;
export declare const DefaultLinkComponent: LinkComponentType<any>;
