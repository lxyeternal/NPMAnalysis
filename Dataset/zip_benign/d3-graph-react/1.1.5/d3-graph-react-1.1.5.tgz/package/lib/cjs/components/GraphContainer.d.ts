import { ReactNode } from 'react';
export declare const GraphContainer: ({ children, containerClassName, containerId, svgClassName, }: {
    children: ReactNode;
    containerId?: string;
    containerClassName?: string;
    svgClassName?: string;
}) => import("react/jsx-runtime").JSX.Element;
