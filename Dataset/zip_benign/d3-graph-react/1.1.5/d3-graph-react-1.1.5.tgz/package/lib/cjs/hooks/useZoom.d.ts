import { D3ZoomEvent } from 'd3-zoom';
export declare function useZoom(zoomScale: [number, number], onZoom?: (event: D3ZoomEvent<SVGElement, unknown>) => void): void;
