import { SimulationLinkDatum } from 'd3-force';
import { GraphType, Link, Node, NodeType } from '../Graph';
export declare function useSimulation<N extends Node, L extends Link>({ graph, linkForce, gravityForce, chargeForce, isNodeDraggable, }: {
    graph: GraphType<N, L>['graph'];
    linkForce?: {
        strength: number;
        length: number;
    };
    gravityForce?: {
        strength: number;
        center_x: number;
        center_y: number;
    };
    chargeForce?: {
        strength: number;
    };
    isNodeDraggable?: boolean;
}): {
    simulationNodes: NodeType[];
    simulationLinks: SimulationLinkDatum<NodeType>[];
    nodeRefs: import("react").RefObject<HTMLDivElement>[];
};
