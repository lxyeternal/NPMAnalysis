<template>
  <div class="home">
    <h2>video example</h2>
    <div>
      <div id="livePlayer"></div>
      <div id="playbackPlayer"></div>
    </div>
  </div>
</template>

<script>
import * as ccVideo from 'aiwen-cc-video'

export default {
  name: "Home",
  data() {
    return {};
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      ccVideo.login({
        userid: "", // 必须参数
        roomid: "", // 必须参数
        success: (data) => {
          console.log("loginSuccess::", data)
        },
        fail: (data) => {

        }
      });
      ccVideo.watchEvent("onLiveStart", (data) => {
        console.log("onLiveStart::", data)
      })
      ccVideo.watchEvent("onLiveStarting", (data) => {
        console.log("onLiveStarting::", data)
      })
    },
  },
  beforeDestroy() {
    ccVideo.destroy()
  },
};
</script>
