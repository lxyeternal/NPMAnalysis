const path = require("path");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const TerserPlugin = require("terser-webpack-plugin");
const outputPath = path.resolve(__dirname, "./dist/");
let packageObj = require("./package.json");
module.exports = {
  entry: { vue: "./lib/index.js" },
  output: {
    path: outputPath,
    filename: `cc-video.js`,
    library: "$cc-video",
    libraryTarget: "umd",
    libraryExport: "default",
    umdNamedDefine: true,
  },
  resolve: {
    extensions: [".js"],
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /(node_modules|bower_components)/,
        use: {
          loader: "babel-loader",
        },
      },
    ],
  },
  mode: "production",
  plugins: [new CleanWebpackPlugin()],
  optimization: {
    minimize: true,
    minimizer: [
      new TerserPlugin({
        extractComments: false,
        terserOptions: {
          mangle: true,
          ecma: 5,
          format: {
            comments: false,
          },
        },
      }),
    ],
  },
};
