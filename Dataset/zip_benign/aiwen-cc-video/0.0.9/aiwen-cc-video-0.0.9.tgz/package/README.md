## 简介
本项目为对cc直播sdk的简单封装，对部分需要使用的事件做了代理。
> [cc直播sdk文档](https://doc.bokecc.com/live/developer/web_sdk.html)


## 使用
### 直播：
```vue
<template>
  <div>
    <div id="livePlayer"></div>
  </div>
</template>

<script>
// nuxt 项目中需要判断 process.client 再 require
import ccVideo from "aiwen-cc-video";

export default {
  data() {
    return {};
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // 初始化
      ccVideo.login({
        userid: "", // 必须参数
        roomid: "", // 必须参数
        success: (data) => {
          console.log("loginSuccess::", data)
        },
        fail: (data) => {

        }
      });
      // 事件监听
      ccVideo.watchEvent("onLiveStart", (data) => {
        console.log("onLiveStart::", data)
      })
      // 调用api
      ccVideo.callMethod("setSound", 0.5)
    },
  },
  beforeDestroy() {
    ccVideo.destroy()
  },
};
</script>

```

### 回放：
```vue
<template>
  <div>
    <div id="playbackPlayer"></div>
  </div>
</template>

<script>
// nuxt 项目中需要判断 process.client 再 require
import ccVideo from "aiwen-cc-video";

export default {
  data() {
    return {};
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // 初始化
      window.$.DW.config({
        userId: "", // 必须参数
        roomId: "", // 必须参数
        recordId: "", // 必须参数
        isH5play: true,
        fastMode: true,
      });
    },
  },
  beforeDestroy() {
    ccVideo.destroy()
  },
};
</script>

```


### 注意
- 升级引用的cc直播sdk文件时，不能简单的进行替换，目前还需将其修改为ESM的形式。
- 直播页面禁止直接使用全局的DWLive对象，会造成事件被重复执行的问题。
- 目前使用了该sdk的项目有 ncme-app-h5