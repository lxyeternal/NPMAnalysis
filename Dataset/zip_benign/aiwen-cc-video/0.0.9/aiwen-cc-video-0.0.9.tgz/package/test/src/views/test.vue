<template>
  <div>test</div>
</template>
<script>
export default {
  name: "test",
  created() {
    console.log("test");
  },
};
</script>
