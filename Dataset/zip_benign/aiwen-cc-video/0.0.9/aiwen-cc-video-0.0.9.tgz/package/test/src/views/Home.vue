<template>
  <div class="home">
    <h2>video test</h2>
    <div>
      <div id="livePlayer"></div>
      <div id="playbackPlayer"></div>
    </div>
  </div>
</template>

<script>
import ccVideo from "../../../lib/index";

export default {
  name: "Home",
  data() {
    return {};
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      ccVideo.login({
        userid: "", // 必须参数
        roomid: "", // 必须参数
        success: (data) => {
          console.log("loginSuccess::", data)
        },
        fail: (data) => {

        }
      });
    },
  },
  beforeDestroy() {
    ccVideo.destroy()
  },
};
</script>
