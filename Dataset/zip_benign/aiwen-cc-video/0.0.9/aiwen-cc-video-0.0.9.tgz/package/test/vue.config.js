"use strict";
const path = require("path");
function resolve(dir) {
  return path.join(__dirname, dir);
}
let customConfig = {
  publicPath: "/",
  outputDir: "dist",
  assetsDir: "static",
};
module.exports = {
  publicPath: customConfig.publicPath,
  outputDir: customConfig.outputDir,
  assetsDir: customConfig.assetsDir,
  lintOnSave: process.env.NODE_ENV === "development",
  productionSourceMap: false,
  devServer: {
    port: 3001,
    open: true,
    overlay: {
      warnings: false,
      errors: true,
    },
  },
  configureWebpack: {
    resolve: {
      alias: {
        "@": resolve("src"),
      },
    },
  },
  chainWebpack(config) {
    config.devtool("inline-source-map");
  },
};
