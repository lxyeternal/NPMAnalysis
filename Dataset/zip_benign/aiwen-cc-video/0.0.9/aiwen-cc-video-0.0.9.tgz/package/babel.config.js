module.exports = {
  presets: ["babel-preset-es2015"],
  plugins: ["transform-runtime"],
};
