module.exports = {
  root: true,
  parser: "babel-eslint",
  env: {
    node: true,
    browser: true,
    es6: true,
  },
  parserOptions: {
    ecmaVersion: 6,
    sourceType: "module",
    ecmaFeatures: {
      jsx: true,
    },
  },
  extends: ["prettier", "eslint:recommended"],
  plugins: ["prettier", "html"],
  settings: {
    "html/html-extensions": [".html", ".vue"],
    "html/indent": "+2",
  },
  rules: {
    "prettier/prettier": "error",
    "comma-spacing": 0,
    // 强制在关键字前后使用一致的空格 (前后腰需要)
    "keyword-spacing": 0,
    // 禁止条件表达式中出现赋值操作符
    "no-cond-assign": 2,
    "no-constant-condition": 2,
    // 禁止 function 定义中出现重名参数
    "no-dupe-args": 2,
    // 禁止对象字面量中出现重复的 key
    "no-dupe-keys": 2,
    // 禁止重复的 case 标签
    "no-duplicate-case": 2,
    // 禁止空语句块
    "computed-property-spacing": [2, "never"],
    //"SwitchCase" (默认：0) 强制 switch 语句中的 case 子句的缩进水平
    // 以方括号取对象属性时，[ 后面和 ] 前面是否需要空格, 可选参数 never, always
    "no-empty": 2,
    indent: [
      "error",
      2,
      {
        SwitchCase: 1,
      },
    ],
    "linebreak-style": [0, "unix"],
    quotes: ["error", "double"],
    semi: ["error", "always"],
    "no-unused-vars": [
      2,
      {
        // 允许声明未使用变量
        // "vars": "local",
        // 参数不检查
        args: "none",
      },
    ],
  },
};
