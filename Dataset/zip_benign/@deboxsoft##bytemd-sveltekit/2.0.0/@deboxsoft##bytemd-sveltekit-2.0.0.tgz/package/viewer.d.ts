import type { Processor } from 'unified';
import type { ViewerProps } from './types';
/**
 * Get unified processor with ByteMD plugins
 */
export declare function getProcessor({ sanitize, plugins, }: Omit<ViewerProps, 'value'>): Processor<import("hast").Root, import("hast").Root, import("hast").Root, string>;
