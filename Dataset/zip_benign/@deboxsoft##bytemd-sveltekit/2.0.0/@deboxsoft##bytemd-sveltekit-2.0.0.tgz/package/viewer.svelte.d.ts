import { SvelteComponentTyped } from "svelte";
import type { ViewerProps } from './helpers';
declare const __propDef: {
    props: {
        value?: ViewerProps['value'];
        plugins?: NonNullable<ViewerProps['plugins']>;
        sanitize: ViewerProps['sanitize'];
    };
    events: {
        hast: CustomEvent<any>;
    } & {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export declare type ViewerProps = typeof __propDef.props;
export declare type ViewerEvents = typeof __propDef.events;
export declare type ViewerSlots = typeof __propDef.slots;
export default class Viewer extends SvelteComponentTyped<ViewerProps, ViewerEvents, ViewerSlots> {
}
export {};
