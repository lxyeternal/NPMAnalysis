import { SvelteComponentTyped } from "svelte";
import type { EditorProps } from './helpers';
declare const __propDef: {
    props: {
        value?: EditorProps['value'];
        plugins?: NonNullable<EditorProps['plugins']>;
        sanitize: EditorProps['sanitize'];
        mode?: NonNullable<EditorProps['mode']>;
        previewDebounce?: NonNullable<EditorProps['previewDebounce']>;
        placeholder: EditorProps['placeholder'];
        editorConfig: EditorProps['editorConfig'];
        locale: EditorProps['locale'];
        uploadImages: EditorProps['uploadImages'];
        overridePreview: EditorProps['overridePreview'];
        maxLength?: NonNullable<EditorProps['maxLength']>;
    };
    events: {
        change: CustomEvent<any>;
    } & {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export declare type EditorProps = typeof __propDef.props;
export declare type EditorEvents = typeof __propDef.events;
export declare type EditorSlots = typeof __propDef.slots;
export default class Editor extends SvelteComponentTyped<EditorProps, EditorEvents, EditorSlots> {
}
export {};
