export declare const icons: {
    strikethrough: string;
    task: string;
    table: string;
};
