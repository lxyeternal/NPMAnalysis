import type { BytemdPlugin } from '$lib';
export default function breaks(): BytemdPlugin;
