import remarkBreaks from 'remark-breaks';
export default function breaks() {
    return {
        remark: (u) => u.use(remarkBreaks),
    };
}
