import type { BytemdPlugin } from '$lib';
import type * as K from 'katex';
import { MathLocale } from '../math-common';
export interface BytemdPluginMathOptions {
    locale?: Partial<MathLocale>;
    katexOptions?: Omit<K.KatexOptions, 'displayMode'>;
}
export default function math({ locale: _locale, katexOptions, }?: BytemdPluginMathOptions): BytemdPlugin;
