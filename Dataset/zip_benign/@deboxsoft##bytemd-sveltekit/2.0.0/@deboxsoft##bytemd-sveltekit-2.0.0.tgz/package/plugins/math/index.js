import remarkMath from 'remark-math';
import { getMathActions } from '../math-common';
import en from './locales/en.json';
export default function math({ locale: _locale, katexOptions, } = {}) {
    const locale = { ...en, ..._locale };
    let katex;
    return {
        remark: (p) => p.use(remarkMath),
        viewerEffect({ markdownBody }) {
            const renderMath = async (selector, displayMode) => {
                const els = markdownBody.querySelectorAll(selector);
                if (els.length === 0)
                    return;
                if (!katex) {
                    katex = await import('katex').then((m) => m.default);
                }
                els.forEach((el) => {
                    katex.render(el.innerText, el, {
                        ...katexOptions,
                        throwOnError: false,
                        displayMode,
                    });
                });
            };
            renderMath('.math.math-inline', false);
            renderMath('.math.math-display', true);
        },
        actions: getMathActions(locale),
    };
}
