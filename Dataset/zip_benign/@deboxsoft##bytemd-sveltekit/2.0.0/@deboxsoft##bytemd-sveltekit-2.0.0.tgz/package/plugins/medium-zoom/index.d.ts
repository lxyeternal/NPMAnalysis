import type { BytemdPlugin } from '$lib';
import type * as M from 'medium-zoom';
export interface BytemdPluginMediumZoomOptions extends M.ZoomOptions {
    filter?: (img: HTMLDivElement) => boolean;
}
export default function mediumZoom(options?: BytemdPluginMediumZoomOptions): BytemdPlugin;
