import remarkFrontmatter from 'remark-frontmatter';
import { load } from 'js-yaml';
export default function frontmatter({ onError, } = {}) {
    return {
        remark: (p) => p.use(remarkFrontmatter).use(() => (tree, file) => {
            // TODO: arg types
            // console.log(tree);
            const fisrtNode = tree.children[0];
            if (fisrtNode?.type !== 'yaml')
                return;
            try {
                file.frontmatter = load(fisrtNode.value);
            }
            catch (err) {
                onError?.(err);
            }
        }),
    };
}
