import type { BytemdPlugin } from '$lib';
import { load } from 'js-yaml';
export interface BytemdPluginFrontmatterOptions {
    onError?(err: any): void;
}
declare module 'vfile' {
    interface VFile {
        frontmatter: ReturnType<typeof load>;
    }
}
export default function frontmatter({ onError, }?: BytemdPluginFrontmatterOptions): BytemdPlugin;
