export declare const icons: {
    mermaid: string;
};
