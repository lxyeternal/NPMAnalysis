import type { BytemdPlugin } from '$lib';
import type mermaidAPI from 'mermaid/mermaidAPI';
declare type Locale = {
    mermaid: string;
    flowchart: string;
    sequence: string;
    class: string;
    state: string;
    er: string;
    uj: string;
    gantt: string;
    pie: string;
};
export interface BytemdPluginMermaidOptions extends mermaidAPI.Config {
    locale?: Partial<Locale>;
}
export default function mermaid({ locale: _locale, ...mermaidConfig }?: BytemdPluginMermaidOptions): BytemdPlugin;
export {};
