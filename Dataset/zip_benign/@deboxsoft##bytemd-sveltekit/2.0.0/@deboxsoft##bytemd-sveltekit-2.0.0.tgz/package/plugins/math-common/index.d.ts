import type { BytemdAction } from '$lib';
export declare type MathLocale = {
    inline: string;
    inlineText: string;
    block: string;
    blockText: string;
};
export declare function getMathActions(locale: MathLocale): BytemdAction[];
