export declare const icons: {
    math: string;
    inline: string;
    block: string;
};
