import remarkFootnotes from 'remark-footnotes';
export default function footnotes(options) {
    return {
        remark: (u) => u.use(remarkFootnotes, options),
    };
}
