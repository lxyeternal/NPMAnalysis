import type { BytemdPlugin } from '$lib';
import { Options } from 'remark-footnotes';
export default function footnotes(options?: Options): BytemdPlugin;
