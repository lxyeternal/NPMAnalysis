import type { BytemdPlugin } from '$lib';
import type H from 'highlight.js';
export interface BytemdPluginHighlightOptions {
    init?(hljs: typeof H): void | Promise<void>;
}
export default function highlight({ init, }?: BytemdPluginHighlightOptions): BytemdPlugin;
