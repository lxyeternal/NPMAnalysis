import type { BytemdPlugin } from '$lib';
export default function gemoji(): BytemdPlugin;
