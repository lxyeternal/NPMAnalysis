# @rohan-stha/hextorgba

A simple package to convert hex color codes to rgba color format.

## Installation

You can install the package via npm:

```bash
npm install @rohan-stha/hextorgba
```

## Usage
```bash
const hexToRgba = require('@rohan-stha/hextorgba');

// Convert hex color code to rgba
const rgbaColor = hexToRgba("#ff0000", 0.5);
console.log(rgbaColor); // Output: rgba(255,0,0,0.5)
```


## API
```bash
hexToRgba(hex, alpha) 
```
Converts a hexadecimal color code to its corresponding RGBA format.

hex (string): The hexadecimal color code (e.g., "#ff0000").
alpha (number, optional): The alpha value (opacity) of the RGBA color. Defaults to 1.
Returns the RGBA color in the format "rgba(r,g,b,a)".


Author
Created by Rohan Shrestha.