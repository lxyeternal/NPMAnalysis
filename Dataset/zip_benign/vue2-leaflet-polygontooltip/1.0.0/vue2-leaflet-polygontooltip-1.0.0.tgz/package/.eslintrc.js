module.exports = {
  root: true,

  env: {
    node: true,
    es6: true,
    browser: true
  },

  extends: [
    "plugin:vue/essential",
    "plugin:prettier/recommended",
    "prettier",
    "prettier/vue"
  ],

  plugins: ["prettier"],

  rules: {
    "no-console": "off",
    "no-debugger": "off"
  },

  parserOptions: {
    parser: "babel-eslint"
  }
};
