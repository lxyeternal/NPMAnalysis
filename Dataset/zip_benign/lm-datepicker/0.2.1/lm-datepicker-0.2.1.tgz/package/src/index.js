/**
 * Created by caoxuewei<caoxuewei@58ganji.com>.
 * ComponentName Datepicker
 * Desc 日期选择
 * GroupName lm-component
 */

import React, { Component } from 'react'
import PropTypes from 'prop-types'

import Popup from 'lm-popup';
import { Picker } from 'lm-picker';

import './index.scss'

import { timeHandler, getItems, getDayItems, setInitItems} from './utils';

let nowObj = new Date();
let now = {
    year: nowObj.getFullYear(),
    month: nowObj.getMonth() + 1,
    day: nowObj.getDate(),
    hour: nowObj.getHours(),
    minute: nowObj.getMinutes(),
    sconds: nowObj.getSeconds()
};

let allMonthItems = getItems(1, 12, '月');
let allHourItems = getItems(0, 23, '时');
let allMinuteItems = getItems(0, 59, '分');

/**
 * @class Datepicker
 * @extends React.Component
 * @desc Datepicker Component for mobile
 */
const DATETIME = "datetime";
const DATE = "date";
const TIME = "time";
const YEAR = "年";
const MONTH = "月";
const DAY = "日";
const HOUR = "时";
const MINUTE = "分";
let startyear, startmonth, startday;
let endyear, endmonth, endday;

export default class Datepicker extends Component {

    static propTypes = {
        showState: PropTypes.bool.isRequired,
        passeddays: PropTypes.number, // 单位天，开始时间为，当前时间 - passedDuration
        futuredays: PropTypes.number, // 单位天，结束时间为，当前时间 + futureDuration
        startTime: PropTypes.string, //开始时间 '2012-10-30 11:30:00' ,优先级高于passedDuration
        endTime: PropTypes.string, // 结束时间 '2018-10-30 12:30:00' ,优先级高于futureDuration

        selected: PropTypes.object, // 默认选中的年份，月份，日期，小时，分钟

        type: PropTypes.oneOf([DATETIME, DATE, TIME]), // 选择类型  datetime日期时间选择,date日期选择,time时间选择
        opacity: PropTypes.number, // 蒙层透明度

        onOk: PropTypes.func, // 确定按钮的回调函数
        onDismiss: PropTypes.func, // 取消按钮的回调函数
    };

    static defaultProps = {
        passeddays: 30,
        futuredays: 30,
        selected: now,
        type: DATETIME,
        onOk: args => args,
        onDismiss: args => args,
        opacity: 0.5

    };

    /**
     * @constructor
     */
    constructor(props) {
        super(props);

        let {
            startTime,
            endTime,
            passeddays,
            futuredays,
            selected,
            type
        } = this.props;
        let opt = {
            startTime,
            endTime,
            passeddays,
            futuredays,
            now
        }
        let startend = timeHandler(opt);
        
        startyear = startend.startyear;
        startmonth = startend.startmonth;
        startday = startend.startday;
        endyear = startend.endyear;
        endmonth = startend.endmonth;
        endday = startend.endday;
       
        
        let params = Object.assign({}, startend, this.props, {
            allMonthItems
        })
        let initResult = setInitItems(params)
        let initYearItems = this.setInitYearItems(startyear, endyear, type)
        
        

        this.state = {
            year: selected.year, // 显示的年份
            month: selected.month, // 显示的月份
            day: selected.day, // 显示的天
            hour: selected.hour, // 显示的小时
            minute: selected.minute, // 显示的分钟
            
            yearItems: initYearItems,
            monthItems: initResult.computeMonthItem,
            dayItems: initResult.computeDayItem,
            hourItems: allHourItems, 
            minuteItems: allMinuteItems,

            tmpyear: selected.year, // 暂存，取消的时候赋值给year
            tmpmonth: selected.month, // 暂存，取消的时候赋值给month
            tmpday: selected.day, // 暂存，取消的时候赋值给day
            tmphour: selected.hour, // 暂存，取消的时候赋值给hour
            tmpminute: selected.minute, // 暂存，取消的时候赋值给minute
            
            tmpMonthItems: initResult.computeMonthItem, // 暂存，取消的时候赋值给monthItems
            tmpDayItems: initResult.computeDayItem, // 暂存，取消的时候赋值给dayItems
            tmpHourItems: allHourItems, // 暂存，取消的时候赋值给hourItems
            tmpMinuteItems: allMinuteItems, // 暂存，取消的时候赋值给minuteItems

        }
        this.onYearChange = this.onYearChange.bind(this);
        this.onMonthChange = this.onMonthChange.bind(this);
        this.onDayChange = this.onDayChange.bind(this);
        this.onHourChange = this.onHourChange.bind(this);
        this.onMinuteChange = this.onMinuteChange.bind(this);
        this.onOk = this.onOk.bind(this);
        this.onDismiss = this.onDismiss.bind(this);
    }
   
    setInitYearItems(startyear, endyear, type) {
        // 初始化年份Items
        if (type === TIME) {
            return null
        } else {
            return getItems(startyear, endyear, YEAR)
        }
    }

    setMonth() {
        // 当改变年份的时候，重置月份及月份Items
        let { year, month } = this.state;
        let computeMonth = month;
        let computeMonthItem = allMonthItems;

        if (startyear === endyear) {
            computeMonth = month;
            computeMonthItem = allMonthItems.slice(startmonth -1 , endmonth);
        } else if (year === startyear) {
            computeMonth = Math.max(month, startmonth);
            computeMonthItem = allMonthItems.slice(startmonth - 1);
        } else if (year === endyear) {
            computeMonth = Math.min(month, endmonth);
            computeMonthItem = allMonthItems.slice(0, endmonth);
        }
        this.setState({
            month: computeMonth,
            monthItems: computeMonthItem
        })
    }
    setDay() {
        // 当改变年份或月份的时候，重置日期及日期Items
        let { year, month, day} = this.state;
        let computeDayItems = getDayItems(year, month).dayItems;
        let computeDay = Math.min(getDayItems(year, month).days, day);

        
        if (year === startyear && month === startmonth) {
            computeDayItems = getDayItems(year, month, startday).dayItems;
            computeDay = Math.max(day, startday);
            computeDay = Math.min(computeDay, getDayItems(year, month, startday).days);
            
        } else if (year === endyear && month === endmonth) {
            computeDay = Math.min(day, endday);
            computeDayItems = getDayItems(year, month, 1, endday).dayItems;
        }
        this.setState({
            day: computeDay,
            dayItems: computeDayItems
        })
    }
    onYearChange (value) {
        value = parseInt(value.replace(YEAR, ''), 10);
        if (value !== this.state.year) {
            this.setState({
                year: value
            })
            this.setMonth();
            this.setDay();
        }
    }
    onMonthChange (value) {
        if (value !== this.state.month) {
            this.setState({
                month: parseInt(value.replace(MONTH, ''), 10)
            })
            this.setMonth();
            this.setDay();
        }
    }
    onDayChange (value) {
        if (value !== this.state.day) {
            this.setState({
                day: parseInt(value.replace(DAY, ''), 10)
            })
        }
    }
    onHourChange (value) {
        if (value !== this.state.hour) {
            this.setState({
                hour: parseInt(value.replace(HOUR, ''), 10)
            })
        }
        
    }
    onMinuteChange (value) {
        if (value !== this.state.minute) {
            this.setState({
                minute: parseInt(value.replace(MINUTE, ''), 10)
            })
        }
    }
 
    onOk() {
        let {year, month, day, hour, minute, monthItems, dayItems} = this.state
        let { onOk, type } = this.props
        this.setState({
            tmpyear: year,
            tmpmonth: month,
            tmpday: day,
            tmphour: hour,
            tmpminute: minute,
            tmpDayItems: dayItems,
            tmpMonthItems: monthItems
        })
        
        
        let dateRes = {
                year, month, day
            };
        let timeRes = {
            hour, minute
        }
        let result = Object.assign({}, dateRes, timeRes);
        
        if (type === DATE) {
            result = dateRes;
        } else if (type === TIME) {
            result = timeRes;
        }
        onOk && onOk(result);
    }

    onDismiss() {
        let {
            tmpyear,
            tmpmonth,
            tmpday,
            tmphour,
            tmpminute,

            tmpDayItems,
            tmpMonthItems,
            tmpHourItems,
            tmpMinuteItems
        } = this.state
        this.setState({
            year: tmpyear,
            month: tmpmonth,
            day: tmpday,
            hour: tmphour,
            minute: tmpminute,
            dayItems: tmpDayItems,
            monthItems: tmpMonthItems,
            hourItems: tmpHourItems,
            minuteItems: tmpMinuteItems
        })
        this.props.onDismiss && this.props.onDismiss();
    }

    render () {
        let { year, month, day, hour, minute, yearItems, monthItems, dayItems, hourItems, minuteItems } = this.state
        let { type } = this.props;
        let showDate = [DATETIME, DATE].indexOf(type) > -1;
        let showTime = [DATETIME, TIME].indexOf(type) > -1;
        let arr = []
        if (showDate) {
            arr.push({
                date: month,
                func: this.onMonthChange,
                items: monthItems,
                flag: MONTH
            });
            arr.push({
                date: day,
                func: this.onDayChange,
                items: dayItems,
                flag: DAY
            })
        }
        if (showTime) {
            arr.push({
                date: hour,
                func: this.onHourChange,
                items: hourItems,
                flag: HOUR
            });
            arr.push({
                date: minute,
                func: this.onMinuteChange,
                items: minuteItems,
                flag: MINUTE
            })
        }

        const picker = (
            <div className="picker-container">
                {
                    showDate ? (
                        <div className="picker-item-container">
                            <Picker
                                selectedValue={ `${year}${YEAR}` }
                                onValueChange={ this.onYearChange }>
                                { yearItems }
                            </Picker>
                        </div>
                        ) : null
                }
                {
                    arr && arr.map(value => {
                        let keystr = year + '-' +  month + '-' + value.date + value.flag;
                        return (
                            <div className="picker-item-container" key={keystr}>
                                <Picker
                                    selectedValue={ `${value.date < 10 ? '0':''}${value.date}${value.flag}` }
                                    onValueChange={ value.func }>
                                    { value.items }
                                </Picker>
                            </div>)
                    })
                }
                
            </div>
            
        );
        
        return (
            <div>
                <Popup
                    title="请选择"
                    okText="确定"
                    dismissText="取消"
                    content={ picker }
                    visible={ this.props.showState }
                    onDismiss = { this.onDismiss }
                    onOk={ this.onOk }
                    opacity={ this.props.opacity }
                    onMaskClick={ this.onDismiss }
                />
            </div>
            
        )
    }

}
