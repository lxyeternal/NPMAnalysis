import React from 'react';

let nowObj = new Date();
let now = {
	year: nowObj.getFullYear(),
	month: nowObj.getMonth() + 1,
	day: nowObj.getDate(),
	hour: nowObj.getHours(),
	minute: nowObj.getMinutes(),
	sconds: nowObj.getSeconds()
};

function parseTime (timestr, flag) {
	// let year, month, day, hour, minute, second;
	let timeobj = {};
	let arr = timestr.split(' ');
	let dateArr = arr[0];
	let ymd = dateArr.split('-');
	let yearobj = {}
	yearobj[`${flag}year`] = parseInt(ymd[0], 10);
	yearobj[`${flag}month`] = parseInt(ymd[1], 10);
	yearobj[`${flag}day`] = parseInt(ymd[2], 10);
	if (arr[1]) {
		let timeArr = arr[1];
		let hms = timeArr.split(':');
		timeobj[`${flag}hour`] = parseInt(hms[0], 10);
		timeobj[`${flag}minute`] = parseInt(hms[1], 10);
		timeobj[`${flag}second`] = hms[2] ? parseInt(hms[2], 10) : 0;
	}
	
	return Object.assign({}, yearobj, timeobj)
}

function parseDuration (duration, now, flag, minus) {
	let newdate = new Date();
	let timegap = duration * 24 * 60 * 60 * 1000;
	let newtimes;
	if (minus) {
		newtimes = newdate.getTime() - timegap;
	} else {
		newtimes = newdate.getTime() + timegap;
	}
	newdate.setTime(newtimes);
	let year = newdate.getFullYear();
	let month = newdate.getMonth() + 1;
	let day = newdate.getDate();
	let hour = newdate.getHours();
	let minute = newdate.getMinutes();

	let result = {}
	result[`${flag}year`] = year;
	result[`${flag}month`] = month;
	result[`${flag}day`] = day;
	result[`${flag}hour`] = hour;
	result[`${flag}minute`] = minute;
	return result
}
export function getItems (start, end, flag) {
	let items = [];
	for (let i = start; i <= end; i++) {
		if (i < 10) {
			i = `0${i}`
		}
		items.push(<div value={`${i}${flag}`} key={i}>{`${i}${flag}`}</div>);
	}
	return items
}
export function getDayItems (year, month, startday, endday) {
	year = year || now.year
	month = month || now.month

	let day30 = [4, 6, 9, 11]
	let dayTempl = getItems(1, 31, '日');
	let isLeap = isLeapYear(year);
	let days = 31;
	if (day30.indexOf(month) > -1) {
		days = 30;
	} else if (isLeap && month === 2) {
		days = 29;
	} else if (!isLeap && month === 2) {
		days = 28;
	}
	
	let dayItems = []
	if (startday < 1 || startday > 31 || !startday) {
		startday = 1
	}
	if (endday < 1 || endday > days) {
		endday = null
	}

	if (!endday) {
		dayItems = days === 31 ? dayTempl.slice(startday-1) : dayTempl.slice(startday-1, days-31);
	} else {
		dayItems = dayTempl.slice(startday-1, endday-31);
	}
	return {dayItems, days}

}
export function isLeapYear(year) {
  return ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);
}


export function timeHandler (options) {
	let {
		startTime,
		endTime,
		passeddays,
		futuredays,
		now
		} = options;
	let startObj = {};
	let endObj = {};
	if (startTime) {
		startObj = parseTime(startTime, 'start');
	} else if (passeddays) {
		startObj = parseDuration(passeddays, now, 'start', true)
	} else {
		startObj = {
			startyear: now.year,
			startmonth: now.month,
			startday: now.day,
			starthour: now.hour,
			startminute: now.minute,
			startsecond: now.second
		}
	}
	
	if (endTime) {
		endObj = parseTime(endTime, 'end')
	} else {
		endObj = parseDuration(futuredays, now, 'end')
	}
	
	return Object.assign({}, startObj, endObj)
}


export function setInitItems (options) {
	// 初始化 月份items、日期items
	let {
		allMonthItems, startyear,
		startmonth, startday,
		endyear,
		endmonth,
		endday,
		selected,
	} = options

	let computeMonthItem = allMonthItems;
    let computeDayItem = getDayItems(selected.year, selected.month).dayItems;
    if (startyear === endyear) {
    	computeMonthItem = allMonthItems.slice(startmonth -1, endmonth);
    	if (endmonth === startmonth) {
    		computeDayItem = getDayItems(startyear, startmonth, startday, endday).dayItems;
    	} else if (selected.month === startmonth) {
    		computeDayItem = getDayItems(startyear, startmonth, startday).dayItems;
    	} else if (selected.month === endmonth) {
    		computeDayItem = getDayItems(startyear, startmonth, 1, endday).dayItems;
    	}
    } else if (startyear === selected.year) {
        computeMonthItem = allMonthItems.slice(startmonth - 1);
        if (startmonth === selected.month) {
            computeDayItem = getDayItems(selected.year, selected.month, startday).dayItems;
        }
        
    } else if (endyear === selected.year) {
        computeMonthItem = allMonthItems.slice(0, endmonth);
        if (endmonth === selected.month) {
            computeDayItem = getDayItems(selected.year, selected.month, 1, endday).dayItems;
        }
    }
    return {
    	computeMonthItem,
    	computeDayItem
    }

}