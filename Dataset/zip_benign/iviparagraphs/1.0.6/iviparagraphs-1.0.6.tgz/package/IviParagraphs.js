import IviHorImage from './IviHorImage';
import IviText from './IviText';
import IviFullSizeImage from './IviFullSizeImage';
import IviFullSizeImageSmallTitle from './IviFullSizeImageSmallTitle';
import IviVideo from './IviVideo';
import IviGallery from './IviGallery';
import IviTextAndImage from './IviTextAndImage';
import IviTwoTexts from './IviTwoTexts';
import IviThreeParts from './IviThreeParts';
import IviVertImg from './IviVertImg';
import IviHorSingleImg from './IviHorSingleImg';
import IviTextAndBooking from './IviTextAndBooking';

export default class IviParagraphs {

    constructor(settings) {
        IviParagraphs.settings = settings;
        IviParagraphs.default = IviParagraphs.defaultSettings();
        this.iviList = {
            iviparagraphs__text: {
                title: IviText,
                settings: 'text'
            },
            iviparagraphs__fsimage: {
                title: IviFullSizeImage,
                settings: 'fsImage'
            },
            iviparagraphs__fsimagesm: {
                title: IviFullSizeImageSmallTitle,
                settings: 'fsImageSmallTitle'
            },
            iviparagraphs__horimage: {
                title: IviHorImage,
                settings: 'horImage'
            },
            iviparagraphs__video: {
                title: IviVideo,
                settings: 'videoPar'
            },
            iviparagraphs__gallery: {
                title: IviGallery,
                settings: 'gallery'
            },
            iviparagraphs__textandimage: {
                title: IviTextAndImage,
                settings: 'textAndImage'
            },
            iviparagraphs__twotexts: {
                title: IviTwoTexts,
                settings: 'twotexts'
            },
            iviparagraphs__threeparts: {
                title: IviThreeParts,
                settings: 'threeparts'
            },
            iviparagraphs__vertimg: {
                title: IviVertImg,
                settings: 'vertimg'
            },
            iviparagraphs__horsingleimg: {
                title: IviHorSingleImg,
                settings: 'horsingleimg'
            },
            iviparagraphs__textandbooking: {
                title: IviTextAndBooking,
                settings: 'textandbooking'
            }
        };

    }

    init() {
        this.paragraphs = document.getElementsByClassName('iviparagraphs');
        if (this.paragraphs.length > 0) {
            let allParagraphs = [];
            let ind = -1;
            for (let parElement of this.paragraphs) {

                if (parElement.childNodes.length > 0) {

                    for (let paragraphItem of parElement.childNodes) {
                        ind++;
                        allParagraphs[ind] = paragraphItem;
                    }

                }
            }


            let index = 0;
            let classesList = [];
            let count = allParagraphs.length;
           /* let addClassNum = 0;
            if (count > 1) {
                addClassNum = 1;
            }*/

            for (let parElement of allParagraphs) {

                if (parElement.childNodes.length > 0) {
                    /*if (index === addClassNum) {
                        IviParagraphs.addClassToElement(parElement, 'cancelplaceholder');
                    }*/
                    index++;
                    let classes = parElement.className;
                    let classesArray = classes.split(' ');
                    classesList[index] = classesArray[0];

                }
            }
            let list = classesList.filter((x, i, a) => a.indexOf(x) == i);
            this._arrangeParagraphs(list);

            let elementsWithImages = [];
            let n = -1;
            for (let parElement of allParagraphs) {
                if (parElement.className.indexOf('iviparagraphs__twotexts') > -1 || parElement.className.indexOf('iviparagraphs__horimage') > -1 || parElement.className.indexOf('iviparagraphs__vertimg') > -1 || parElement.className.indexOf('iviparagraphs__text_and_image') > -1 || parElement.className.indexOf('iviparagraphs__gallery') > -1 || parElement.className.indexOf('iviparagraphs__fsimagesm') > -1 || parElement.className.indexOf('iviparagraphs__fsimage') > -1 || parElement.className.indexOf('iviparagraphs__horsingleimg') > -1) {
                    n++;
                    elementsWithImages[n] = parElement;
                }
            }

            if (elementsWithImages.length > 0) {
                IviParagraphs.addClassToElement(elementsWithImages[0], 'cancelplaceholder');
            }
            else {
                if (document.getElementsByClassName('iviplaceholder').length > 0) {
                    for (let item of document.getElementsByClassName('iviplaceholder')) {
                        if (item.className.indexOf('iviplaceholder-none') < 1) {
                            IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                        }
                    }
                }
            }


        }
        this.setTitle();
    }

    setTitle() {
        let h1s = document.getElementsByTagName('h1');
        if (h1s.length < 1) {
            let titles = document.getElementsByClassName('mbtitle');
            if (titles.length > 0) {
                var h = document.createElement('H1');
                var titleContent = titles[0].textContent;
                titles[0].textContent = '';
                titles[0].appendChild(h);
                h.textContent = titleContent;
            }
        }

    }

    _arrangeParagraphs(parClassList) {

        for (let parClass of parClassList) {

            if (this.iviList.hasOwnProperty(parClass)) {
                this.iviList[parClass]['title'].set(parClass, IviParagraphs.defaultSettings()[this.iviList[parClass]['settings']]);
            }
        }

    }

    static defaultSettings() {
        let self = this;

        let defaultSettings = {
            horImage: {
                height: 0.4,
                marginBottom: 20,
                marginTop: 20
            },
            text: {
                span: false,
                spanstyle1: '',
                spanstyle2: '',
                spanstyle3: '',
                defaultStyle: false,
                marginBottom: 20,
                marginTop: 20,
                imageWrapperDefault: false,
            },
            fsImage: {
                arrowClass: 'iviparagraphs__fsimage-elementarrow-default',
                span: false,
                spanClass: '',
                marginBottom: 20,
                marginTop: 20,
                bottomOffset: 0,
                imageLayer: false,
                defaultTitle: false,
                titleClass: 'h2',
                style: {}
            },
            fsImageSmallTitle: {
                arrowClass: 'iviparagraphs__fsimagesm-elementarrow-default',
                span: false,
                spanClass: '',
                marginBottom: 20,
                marginTop: 20,
                bottomOffset: 0,
                imageLayer: false,
                defaultTitle: false,
                titleClass: 'h2',
                style: {}
            },
            videoPar: {
                marginBottom: 20,
                marginTop: 20,
            },
            gallery: {
                marginBottom: 20,
                marginTop: 20,
                firstDefaultArrows: true,
                firstMousedrag: true,
                firstTouchdrag: true,
                firstButtonsToMove: true,
                firstControlKeys: true,
                style1: {
                    horizontalPadding: 5,
                    height: {
                        responsive: {
                            0: 250,
                            767: 300,
                            1023: 450,
                            1200: 550
                        }
                    },
                    cloneBackground: '#fff',
                    placeholderBackground: '#faf2eb',
                    arrowsPosition: 'right',
                    placeholderSrc: '/sites/all/themes/tgtheme/misc/dist/images/iviparagraphs/placeholder.png',
                }
            },
            textAndImage: {
                marginBottom: 20,
                marginTop: 20,
                span: false,
                spanstyle1: '',
                spanstyle2: '',
                spanstyle3: '',
                spanstyle4: '',
                defaultStyle: false,
                defaultImgWidth: {
                    responsive: {
                        0: 100,
                        767: 50
                    }
                },
                zeroElementsPadding: 20,
                largeElementsPadding: 40,
                imageWrapperDefault: false,
            },
            twotexts: {
                marginBottom: 20,
                marginTop: 20,
                span: false,
                spanstyle1: '',
                spanstyle2: '',
                spanstyle3: '',
                spanstyle4: '',
                defaultStyle: false,
                zeroElementsPadding: 20,
                largeElementsPadding: 40,
                imageWrapperDefault: false,
                narrowWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '50%',
                        }
                    }
                },
                wideWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '50%',
                        }
                    }
                },
            },
            textandbooking: {
                marginBottom: 20,
                marginTop: 20,
                span: false,
                spanstyle1: '',
                spanstyle2: '',
                spanstyle3: '',
                spanstyle4: '',
                defaultStyle: false,
                zeroElementsPadding: 20,
                largeElementsPadding: 40,
                imageWrapperDefault: false,
                narrowWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '50%',
                        }
                    }
                },
                wideWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '50%',
                        }
                    }
                },
            },
            threeparts: {
                marginBottom: 20,
                marginTop: 20,
                defaultStyle: false,
                imgWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '33.3333%',
                        }
                    }
                },
                textWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '33.3333%',
                        }
                    }
                },
                titleWidth: {
                    width: {
                        responsive: {
                            0: '100%',
                            767: '33.3333%',
                        }
                    }
                },
            },
            vertimg: {
                marginBottom: 20,
                marginTop: 20,
            },
            horsingleimg: {
                marginBottom: 20,
                marginTop: 20,
            }
        };

        if (self.settings !== undefined) {
            for (var key in defaultSettings) {
                if (defaultSettings.hasOwnProperty(key)) {

                    if (self.settings.hasOwnProperty(key)) {

                        if (self.settings[key] instanceof Object) {

                            for (var secondKey in self.settings[key]) {

                                // if (defaultSettings[key].hasOwnProperty(secondKey)) {
                                if (self.settings[key].hasOwnProperty(secondKey)) {
                                    if (self.settings[key][secondKey] != defaultSettings[key][secondKey]) {
                                        defaultSettings[key][secondKey] = self.settings[key][secondKey];
                                    }
                                }
                                //  }


                            }
                        }
                        else {
                            if (self.settings[key] != defaultSettings[key]) {
                                defaultSettings[key] = self.settings[key];
                            }
                        }
                    }
                }
            }
        }
        return defaultSettings;
    }

    // Get single image and set it as a background of element "image"
    static getJSONforSingleImageFromFid(fid, image) {
        let langPrefix = document.documentElement.lang == 'ru' ? '' : '/' + document.documentElement.lang;
        var topDist;
        topDist = window.pageXOffset;
        image.fetched = 0;
        let loadBefore = 400 + window.innerHeight;

        if (topDist > (image.getBoundingClientRect().top - loadBefore) && image.fetched !== 1) {
            fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                .then(function (response) {
                    return response.json();
                }).then(function (json) {
                IviParagraphs.addBgToElementFromFid(json, image);
                image.fetched = 1;
            }).catch(function (ex) {
                console.log('parsing failed', ex);
            })
        }

        window.addEventListener("scroll", function (event) {
            topDist = this.scrollY;

            if ((topDist > (image.getBoundingClientRect().top - loadBefore) && image.fetched !== 1) || (topDist === undefined && image.fetched !== 1)) {
                image.fetched = 1;

                fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                    .then(function (response) {
                        return response.json();
                    }).then(function (json) {
                    IviParagraphs.addBgToElementFromFid(json, image);

                }).catch(function (ex) {
                    console.log('parsing failed', ex);
                })
            }
        }, false);

    }

    static addBgToElementFromFid(json, image) {
        image.style.backgroundImage = 'url(' + json[0] + ')';
        image.style.backgroundSize = 'cover';
        image.style.backgroundPosition = 'center';

    }

    /**
     *
     * Divide style settings into responsive and not responsive. If not responsive - send to style-setter, if responsive - send first to the function that will define what size to use
     */

    static defineCss(element, styleSettings) {

        for (let key in styleSettings) {
            if (styleSettings[key] instanceof Object) {

                if (styleSettings[key].hasOwnProperty('responsive')) {
                    IviParagraphs.checkResponsive(element, key, styleSettings[key]);

                }

            }
            else {
                IviParagraphs.setCss(element, key, styleSettings[key]);
            }
        }
    }

    static checkResponsive(element, key, styleSetting) {
        if (Object.keys(styleSetting.responsive).length > 0) {
            let screenSize;
            screenSize = IviParagraphs.applySize(styleSetting.responsive);
            IviParagraphs.setCss(element, key, styleSetting.responsive[screenSize]);

            window.addEventListener('resize', function () {
                screenSize = IviParagraphs.applySize(styleSetting.responsive);
                IviParagraphs.setCss(element, key, styleSetting.responsive[screenSize]);
            });
        }
    }

    static setCss(element, cssName, cssValue) {
        element.style[cssName] = cssValue;
    }

    static applySize(styleSetting) {
        let resultScreenSize = 0;
        for (let screenSize in styleSetting) {
            if (!isNaN(Math.floor(screenSize))) {
                if (Math.floor(screenSize) < window.innerWidth) {
                    resultScreenSize = Math.floor(screenSize);
                }
            }
        }
        return resultScreenSize;
    }

    /**
     * Add class to element
     */
    static addClassToElement(element, classTitle) {

        if (element && (typeof classTitle === 'string' || classTitle instanceof String)) {
            element.className += ' ' + classTitle;
        }
    }

    static getHeaderHeight() {
        var header = document.getElementById('header');

        if (header != null) {
            return header.clientHeight;
        }
        else {
            return 0;
        }
    }

    static elementHasClass(element, className) {
        return element.className.indexOf(className) >= 0;
    }

    static getStyleNumber(element) {
        let classes = element.className;
        let classesParts = classes.split(' ');

        let classesArray = classesParts[1].split('-');
        let styleNumber;

        for (let elClass of classesArray) {
            if (elClass.indexOf('style') >= 0) {
                styleNumber = elClass;
            }
        }

        return styleNumber;
    }

    static getElementNumber(element) {
        let classes = element.className;
        let classesParts = classes.split(' ');
        let styleNumber;

        for (let elClass of classesParts) {
            if (elClass.indexOf('number') >= 0) {
                styleNumber = elClass;
            }
        }
        let numberArray = styleNumber.split('-');
        return numberArray[1];
    }

    static getItemNumber(element) {
        let classes = element.className;
        let classesParts = classes.split('__');

        let styleNumber;

        for (let elClass of classesParts) {
            if (elClass.indexOf('item') >= 0) {
                styleNumber = elClass;
            }
        }
        let classesArray = styleNumber.split('-');
        return classesArray[1];
    }

    static getFid(element) {
        let classes = element.className;
        let classesParts = classes.split(' ');
        let classPartWithFid;

        for (let elClass of classesParts) {
            if (elClass.indexOf('-img-') >= 0 && elClass.indexOf('-img-default') < 0) {
                classPartWithFid = elClass;
            }
        }


        if (classPartWithFid !== undefined) {
            let classPartWithFidParts = classPartWithFid.split('-');
            for (let imgPart of classPartWithFidParts) {
                if (!isNaN(Math.floor(imgPart))) {
                    return imgPart;
                }
            }

        }
        else {
            return false;
        }

    }

    static setDefaultSettings(child, paragraphClass) {

        let classes = child.className;
        let classesParts = classes.split(' ');
        let classesArray = classesParts[0].split('-');
        let childName = classesArray[1];
        child.classList.add(paragraphClass + '-' + childName + '-default');
    }

    static addSpan(element, styleNumber, settings, elementClass, titleClass, subtitleClass, textClass, linkClass, wrapperClass) {

        let title = element.getElementsByClassName(titleClass);
        let subtitle = element.getElementsByClassName(subtitleClass);
        let text = element.getElementsByClassName(textClass);
        let link = element.getElementsByClassName(linkClass);

        let spanClass = settings['span' + styleNumber];

        if (spanClass.length > 0) {
            let spanWrap = document.createElement('div');
            let span = document.createElement('span');
            span.classList.add(spanClass);
            spanWrap.appendChild(span);

            if (element.className.indexOf('img') >= 0) {

                console.log(element);

                let textWithImageWrap;
                textWithImageWrap = document.createElement('div');
                textWithImageWrap.classList.add(wrapperClass);
                if (settings.imageWrapperDefault == true) {
                    IviParagraphs.setDefaultSettings(textWithImageWrap, elementClass);
                }
                if (title.length == 0 && subtitle.length == 0 && text.length > 0) {

                    if (link.length == 0) {

                        textWithImageWrap.appendChild(text[0]);
                        textWithImageWrap.appendChild(spanWrap);

                    }
                    else {
                        textWithImageWrap.appendChild(text[0]);
                        textWithImageWrap.appendChild(spanWrap);
                        textWithImageWrap.appendChild(link[0]);
                    }
                }

                else if (spanClass.length > 0 && text.length > 0 && (title.length !== 0 || subtitle.length !== 0)) {

                    if (title.length !== 0) {
                        textWithImageWrap.appendChild(title[0]);
                    }
                    if (subtitle.length !== 0) {
                        textWithImageWrap.appendChild(subtitle[0]);
                    }
                    textWithImageWrap.appendChild(text[0]);
                    textWithImageWrap.appendChild(spanWrap);
                    if (link.length !== 0) {
                        textWithImageWrap.appendChild(link[0]);
                    }
                }

                else if (spanClass.length > 0 && text.length === 0 && title.length !== 0 && subtitle.length !== 0 && link.length !== 0) {
                    if (title.length !== 0) {
                        textWithImageWrap.appendChild(title[0]);
                    }
                    if (subtitle.length !== 0) {
                        textWithImageWrap.appendChild(subtitle[0]);
                    }
                    // textWithImageWrap.appendChild(link[0]);
                    textWithImageWrap.appendChild(spanWrap);
                    if (link.length !== 0) {
                        textWithImageWrap.appendChild(link[0]);
                    }
                }

                else if (spanClass.length > 0 && text.length === 0 && title.length !== 0 && subtitle.length !== 0 && link.length === 0) {
                    if (title.length !== 0) {
                        textWithImageWrap.appendChild(title[0]);
                    }
                    if (subtitle.length !== 0) {
                        textWithImageWrap.appendChild(subtitle[0]);
                    }
                    // textWithImageWrap.appendChild(link[0]);
                   // textWithImageWrap.appendChild(spanWrap);

                }

                else if (spanClass.length > 0 && text.length === 0 && title.length !== 0 && subtitle.length === 0 && link.length !== 0) {
                    if (title.length !== 0) {
                        textWithImageWrap.appendChild(title[0]);
                    }
                    if (link.length !== 0) {
                        textWithImageWrap.appendChild(link[0]);
                    }
                  //  textWithImageWrap.appendChild(spanWrap);

                }

                else if (spanClass.length > 0 && text.length === 0 && title.length !== 0 && subtitle.length === 0 && link.length === 0) {
                    if (title.length !== 0) {
                        textWithImageWrap.appendChild(title[0]);
                    }

                    //  textWithImageWrap.appendChild(spanWrap);

                }

                else if (spanClass.length > 0 && text.length === 0 && title.length === 0 && subtitle.length !== 0 && link.length === 0) {
                    if (subtitle.length !== 0) {
                        textWithImageWrap.appendChild(subtitle[0]);
                    }

                    //  textWithImageWrap.appendChild(spanWrap);

                }

                element.appendChild(textWithImageWrap);

            }
            else {

                let textWithImageWrap;
                textWithImageWrap = document.createElement('div');
                textWithImageWrap.classList.add(wrapperClass);

                if (title.length == 0 && subtitle.length == 0 && text.length > 0) {

                    if (link.length == 0) {

                        element.appendChild(spanWrap);

                    }
                    else {
                        element.insertBefore(spanWrap, link[0]);
                    }
                }

                else if (spanClass.length > 0 && text.length > 0 && (title.length !== 0 || subtitle.length !== 0)) {

                    element.insertBefore(spanWrap, text[0]);
                    /* textWithImageWrap.appendChild(title[0]);
                     textWithImageWrap.appendChild(subtitle[0]);
                     textWithImageWrap.appendChild(link[0]);*/
                }

               else if (spanClass.length > 0 && text.length === 0 && (title.length !== 0 || subtitle.length !== 0) && link.length !== 0) {
                  //  element.insertBefore(spanWrap, link[0]);
                }



            }
        }



        else {
            if (element.className.indexOf('img') >= 0) {
                let textWithImageWrap;
                /* if (element.className.indexOf('wrapper') >= 0) {
                 textWithImageWrap = element;
                 }
                 else {
                 textWithImageWrap = document.createElement('div');
                 textWithImageWrap.classList.add(wrapperClass);
                 }*/
                textWithImageWrap = document.createElement('div');
                textWithImageWrap.classList.add(wrapperClass);
                if (settings.imageWrapperDefault == true) {
                    //  IviText._setDefaultSettings(textWithImageWrap);
                    IviParagraphs.setDefaultSettings(textWithImageWrap, elementClass);
                }
                if (title.length !== 0) {
                    textWithImageWrap.appendChild(title[0]);
                }
                if (subtitle.length !== 0) {
                    textWithImageWrap.appendChild(subtitle[0]);
                }
                if (text.length !== 0) {
                    textWithImageWrap.appendChild(text[0]);
                }
                if (link.length !== 0) {
                    textWithImageWrap.appendChild(link[0]);
                }
                /* if (element.className.indexOf('wrapper') < 0) {
                 element.appendChild(textWithImageWrap);
                 }*/
                element.appendChild(textWithImageWrap);
            }
        }

    }

    static leftOrRight(element) {
        let classes = element.className;
        if (classes.indexOf('leftimg') >= 0) {
            return 'left';
        }
        else {
            return 'right';
        }
    }


    static addMap(element) {
     //   element.innerHTML = '<iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A1beb59c06c03f372806e7d4617f82a7bdad29a4e27b74b59ce460e7923f462b7&amp;source=constructor" width="600" height="450" frameborder="0"></iframe>';

    }
}