import IviParagraphs from './IviParagraphs';
export default class IviGallery {

    constructor(galleryClass, settings) {
        IviGallery.settings = settings;
    }

    static set(galleryClass, settings) {
        var galleries = document.getElementsByClassName(galleryClass);

        if (galleries.length > 0) {
            IviGallery._run(galleries, settings);
        }

    }


    static _run(galleries, settings) {
        let index = 0;
        for (var gallery of galleries) {
            if (gallery.children.length > 2) {
                index++;
                IviParagraphs.setCss(gallery, 'marginTop', settings.marginTop + 'px');
                IviParagraphs.setCss(gallery, 'marginBottom', settings.marginBottom + 'px');

                let styleNumber = IviParagraphs.getStyleNumber(gallery);

                if (styleNumber == 'style1') {
                    IviParagraphs.addClassToElement(gallery, 'iviparagraphs__gallery__number-' + index);
                    IviGallery._startFirstGallery(gallery, settings[styleNumber], index);
                }

                if (styleNumber == 'style2') {

                }

                if (styleNumber == 'style3') {

                }

                if (styleNumber == 'style4') {

                }
            }


        }
        if (document.getElementsByClassName('iviplaceholder').length > 0) {
            for (let item of document.getElementsByClassName('iviplaceholder')) {
                if (item.className.indexOf('iviplaceholder-none') < 1) {
                    IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                }
            }
        }
    }

    static _startFirstGallery(gallery, settings, index) {

        let screenHeight = IviParagraphs.applySize(settings.height.responsive);
        IviGallery.buildArea(gallery, settings.height.responsive[screenHeight], index);
        IviGallery._buildFirstGallery(gallery, settings.height.responsive[screenHeight]);
        IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(gallery.firstChild), gallery.firstChild, settings.height.responsive[screenHeight], settings, 1);
        window.addEventListener('resize', function () {
            screenHeight = IviParagraphs.applySize(settings.height.responsive);
            // IviGallery._buildFirstGallery(gallery, settings, settings.height.responsive[screenHeight]);
            IviGallery.correctHeight(gallery, settings.height.responsive[screenHeight]);
            IviGallery.correctLeft(gallery, settings);
        });
    }

    static _buildFirstGallery(gallery, height) {
        let wrapper = gallery.getElementsByClassName('iviparagraphs__gallery-wrapper')[0];
        wrapper.style.height = height + 'px';
    }


    static getJSONforGalleryImageFromFid(fid, image, height, settings, num) {

        let langPrefix = document.documentElement.lang == 'ru' ? '' : '/' + document.documentElement.lang;
        var topDist;
        topDist = window.pageXOffset;
        let loadBefore = 1500 + window.innerHeight;

        if (topDist > (image.getBoundingClientRect().top - loadBefore)) {
            if (image.className.indexOf('iviparagraphs__gallery-loaded') < 0) {
                let items = image.parentNode.getElementsByClassName('iviparagraphs__gallery-img');
                IviParagraphs.addClassToElement(image, 'iviparagraphs__gallery-loaded');
                fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                    .then(function (response) {
                        return response.json();
                    }).then(function (json) {
                    IviGallery.getImageDimensions(json, image, height, settings, num);
                    if (num === items.length) {
                        IviParagraphs.addClassToElement(image.parentNode, 'iviparagraphs__gallery-finished');
                    }

                }).catch(function (ex) {
                    console.log('parsing failed', ex);
                })
            }

        }

        window.addEventListener("scroll", function (event) {
            topDist = this.scrollY;
            if (topDist > (image.getBoundingClientRect().top - loadBefore) || topDist === undefined) {
                if (image.className.indexOf('iviparagraphs__gallery-loaded') < 0) {
                    let items = image.parentNode.getElementsByClassName('iviparagraphs__gallery-img');
                    IviParagraphs.addClassToElement(image, 'iviparagraphs__gallery-loaded');
                    fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                        .then(function (response) {
                            return response.json();
                        }).then(function (json) {
                        IviGallery.getImageDimensions(json, image, height, settings, num);
                        if (num === items.length) {
                            IviParagraphs.addClassToElement(image.parentNode, 'iviparagraphs__gallery-finished');
                        }
                    }).catch(function (ex) {
                        console.log('parsing failed', ex);
                    })
                }

            }
        }, false);
    }

    static getImageDimensions(json, image, height, settings, num) {

        let img = new Image();
        img.src = json[0];
        let move = image.parentNode.nextSibling.getElementsByClassName('iviparagraphs__gallery-progressmove');

    //    img.onload = function () {
            //   let ratio = img.naturalWidth / img.naturalHeight;
            // let width = height * ratio;
            move[0].style.width = image.parentNode.clientWidth / (image.parentNode.childElementCount - 2) * num + 'px';
            if (IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor1') && IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor2') && IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor3') && IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor4')) {
              //  progressMove.style.background = IviParagraphs.settings.gallery.style1.progressColor1;
                if (num < (image.parentNode.childElementCount - 2) / 4) {
                    move[0].style.background = IviParagraphs.settings.gallery.style1.progressColor1;
                }
                if (num > (image.parentNode.childElementCount - 2) / 4 && num < (image.parentNode.childElementCount - 2) / 2) {
                    move[0].style.background = IviParagraphs.settings.gallery.style1.progressColor2;
                }
                if (num > (image.parentNode.childElementCount - 2) / 2 && num < (image.parentNode.childElementCount - 2) * 0.75) {
                    move[0].style.background = IviParagraphs.settings.gallery.style1.progressColor3;
                }
                else {
                    move[0].style.background = IviParagraphs.settings.gallery.style1.progressColor4;
                }
            }
            IviGallery.setFirstSlides(json, image, height, settings, num);
      //  };
    }

    static buildArea(gallery, height, index) {
        let galleryWrap = document.createElement('div');
        galleryWrap.classList.add('iviparagraphs__gallery-wrapper');
        galleryWrap.id = 'iviparagraphs__gallery-wrapper-' + index;
        galleryWrap.style.height = height + 'px';
        gallery.appendChild(galleryWrap);
        let img = new Image();
        img.src = IviParagraphs.default.gallery.style1.placeholderSrc;

        img.onload = function () {
            let imgWidth = img.width;
            let imgHeight = img.height;
            let left = (gallery.clientWidth - imgWidth) / 2;
            let top = (gallery.clientHeight - imgHeight) / 3;
            IviGallery.addRule(
                ".iviparagraphs__gallery::before", {
                    background: IviParagraphs.default.gallery.style1.placeholderBackground,
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                }
            );
            IviGallery.addRule(
                ".iviparagraphs__gallery::after", {
                    top: top + 'px',
                    left: left + 'px',
                    //  right: 0,
                    content: 'url("' + IviParagraphs.default.gallery.style1.placeholderSrc + '")',
                    // transform: 'rotateX(130deg)',
                    //   -webkit-transform: 'rotateY(130deg)',
                }
            );
        };

        let progressWrap = document.createElement('div');
        progressWrap.classList.add('iviparagraphs__gallery-progress');
        gallery.parentNode.insertBefore(progressWrap, gallery.nextSibling);

        let progressBar = document.createElement('div');
        progressBar.classList.add('iviparagraphs__gallery-bar');
        progressWrap.appendChild(progressBar);
        progressBar.style.top = - gallery.clientHeight / 2 + 'px';

        let progressMove = document.createElement('div');
        progressMove.classList.add('iviparagraphs__gallery-progressmove');
        progressBar.appendChild(progressMove);
        progressMove.style.width = gallery.clientWidth / (gallery.childElementCount - 2) + 'px';
        if (IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor1') && IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor2') && IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor3') && IviParagraphs.settings.gallery.style1.hasOwnProperty('progressColor4')) {
            progressMove.style.background = IviParagraphs.settings.gallery.style1.progressColor1;
        }
    }

    static addRule(selector, css) {
        let s = document.createElement('style');
        var sheet = document.head.appendChild(s).sheet;
        var propText = Object.keys(css).map(function (p) {
            return p + ":" + css[p]
        }).join(";");
        sheet.insertRule(selector + "{" + propText + "}", sheet.cssRules.length);
    }


    static setFirstSlides(json, image, height, settings, num) {

        let firstSlide = document.createElement('img');
        firstSlide.classList.add('iviparagraphs__gallery__it');
        firstSlide.classList.add('iviparagraphs__gallery__item-' + num);
        firstSlide.src = json[0];
        let wrapper = image.parentNode.lastChild;
        firstSlide.style.height = height + 'px';
        IviGallery.addFirstSlide(height, settings, num, wrapper, firstSlide);
    }

    static addFirstSlide(height, settings, num, wrapper, firstSlide) {
        let length = wrapper.parentNode.childElementCount;

        if (num === 1) {
            wrapper.appendChild(firstSlide);
            IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(wrapper.parentNode.children[num]), wrapper.parentNode.children[num], height, settings, (num + 1));
        }
        if ((num % 2 == 0) && num !== 1) {
            if (num < length - 1) {
                wrapper.appendChild(firstSlide);
                IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(wrapper.parentNode.children[length - num / 2 - 1]), wrapper.parentNode.children[length - num / 2 - 1], height, settings, (num + 1));
            }
            if (num === length - 1) {
                wrapper.appendChild(firstSlide);
              //  IviGallery.setWidthAndStartPosition(wrapper, settings, height);
                IviGallery.startingApplyDimensions(wrapper, settings, height);
            }

        }
        if ((num % 2 !== 0) && num !== 1) {
            if (num < length - 1) {
                wrapper.insertBefore(firstSlide, wrapper.firstChild);
                IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(wrapper.parentNode.children[(num + 1) / 2]), wrapper.parentNode.children[(num + 1) / 2], height, settings, (num + 1));
            }
            if (num === length - 1) {
                wrapper.insertBefore(firstSlide, wrapper.firstChild);
              //  IviGallery.setWidthAndStartPosition(wrapper, settings, height);
                IviGallery.startingApplyDimensions(wrapper, settings, height);
            }
        }

    }

    static startingApplyDimensions(wrapper, settings, height) {

        var x = setInterval(function () {

            var loaded = IviGallery.checkCheckFinishedClass(wrapper);
            console.log(111, loaded);
            if (loaded) {
                console.log(2222);
                IviGallery.setWidthAndStartPosition(wrapper, settings, height);
                clearInterval(x);
            }

        }, 200);

    }

    static checkCheckFinishedClass(wrapper) {
        return wrapper.parentNode.className.indexOf('iviparagraphs__gallery-finished') >= 0;
    }

    static setWidthAndStartPosition(wrapper, settings, height) {



        let length = wrapper.childElementCount;
        let wrapperWidth = 0;
        let galleryWidth = wrapper.parentNode.clientWidth;

        let maxImageWidth = 0;
        let ratio = 0;
        for (let image of wrapper.children) {

            if (image.clientWidth > maxImageWidth) {
                maxImageWidth = image.clientWidth;
                ratio = image.clientHeight / image.clientWidth;
            }
        }

        if (maxImageWidth > galleryWidth) {
            let imagesToReduce = wrapper.getElementsByTagName('img');
            for (let imageToReduce of imagesToReduce) {
                imageToReduce.style.height = galleryWidth * ratio + 'px';
            }
            wrapper.style.height = galleryWidth * ratio + 'px';
        }

        let ind = 0;
        for (let image of wrapper.children) {
            ind++;
            wrapperWidth += image.clientWidth;

            if (ind === 1) {
                image.style.paddingRight = settings.horizontalPadding / 2 + 'px';
            }
            if (ind > 1 && ind < (length)) {
                image.style.paddingRight = settings.horizontalPadding / 2 + 'px';
                image.style.paddingLeft = settings.horizontalPadding / 2 + 'px';
            }
            if (ind === length) {
                image.style.paddingLeft = settings.horizontalPadding / 2 + 'px';
            }
        }

        wrapper.style.width = wrapperWidth + settings.horizontalPadding * (length) + 'px';
        let firstImagesWidth = 0;

        let centre;
        if ((wrapperWidth + settings.horizontalPadding * length) < galleryWidth) {
            wrapper.style.left = (galleryWidth - wrapperWidth) / 2 + 'px';
        }
        else {
            if (length % 2 == 0) {
                let i;
                for (i = 0; i < (length / 2 - 1); i++) {
                    firstImagesWidth += wrapper.children[i].clientWidth;
                }
                centre = firstImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2;
            }
            else {
                let i;
                for (i = 0; i < (length / 2 - 1); i++) {
                    firstImagesWidth += wrapper.children[i].clientWidth;
                }
                centre = firstImagesWidth + wrapper.children[length / 2 - 0.5].clientWidth / 2;
            }

            let rightCentre;

            let rightImagesWidth = 0;
            if (length % 2 == 0) {
                let i;
                for (i = length; i > (length / 2); i--) {

                    rightImagesWidth += wrapper.children[i - 1].clientWidth;
                }
                rightCentre = rightImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2;

            }
            else {
                let i;
                for (i = length; i > (length / 2 + 1); i--) {

                    rightImagesWidth += wrapper.children[i - 1].clientWidth;
                }
                rightCentre = rightImagesWidth + wrapper.children[length / 2 - 0.5].clientWidth / 2;
            }

            let centreOffset = wrapper.clientWidth / 2 - centre;
            // let simpleLeft = (galleryWidth - wrapperWidth) / 2 - settings.horizontalPadding;
            let simpleLeft = (galleryWidth - wrapper.clientWidth) / 2;
            let resultLeft = simpleLeft + centreOffset;

            if (galleryWidth / 2 > centre) {
                wrapper.style.left = -settings.horizontalPadding + 'px';
            }
            if (galleryWidth / 2 > rightCentre) {
                wrapper.style.left = resultLeft + galleryWidth / 2 - rightCentre + 'px';
            }
            if (galleryWidth / 2 < centre && galleryWidth / 2 < rightCentre) {
                wrapper.style.left = resultLeft - settings.horizontalPadding / 2 + 'px';
            }
        }


        if (wrapperWidth > galleryWidth) {
            if (IviParagraphs.default.gallery.firstButtonsToMove === true) {
                IviGallery.buildButtons(wrapper, settings);
            }
            if (IviParagraphs.default.gallery.firstMoveOnMouseClick === true) {
                IviGallery._moveGalleryOnMouseClick(wrapper, settings);
            }
            if (IviParagraphs.default.gallery.firstMousedrag === true) {
                IviGallery._makeGalleryDrag(wrapper, settings);
            }
            if (IviParagraphs.default.gallery.firstTouchdrag === true) {
                IviGallery._makeGalleryTouchDraggable(wrapper, settings);
            }
            if (IviParagraphs.default.gallery.firstControlKeys === true) {
                IviGallery._navigateWithArrowKeys(wrapper, settings);
            }
        }

        IviGallery.addRule(
            ".iviparagraphs__gallery__number-" + IviParagraphs.getElementNumber(wrapper.parentNode) + "::before", {
                display: 'none'
            }
        );
        IviGallery.addRule(
            ".iviparagraphs__gallery__number-" + IviParagraphs.getElementNumber(wrapper.parentNode) + "::after", {
                display: 'none'
            }
        );

        let move = wrapper.parentNode.nextSibling.getElementsByClassName('iviparagraphs__gallery-progressmove');
        move[0].parentNode.removeChild(move[0]);
    }


    /**
     * Corrects the left Offset, height of gallery depenfint of the widest img and wrapper width depending of height
     * @param gallery
     * @param settings
     */
    static correctLeft(gallery, settings) {
        let wrapper = gallery.getElementsByClassName('iviparagraphs__gallery-wrapper')[0];
        let length = wrapper.childElementCount;

        let galleryWidth = wrapper.parentNode.clientWidth;

        let maxImageWidth = 0;
        let ratio = 0;
        for (let image of wrapper.children) {
            if (image.clientWidth > maxImageWidth) {
                maxImageWidth = image.clientWidth;
                ratio = image.clientHeight / image.clientWidth;
            }
        }

        if (maxImageWidth > galleryWidth) {
            let imagesToReduce = wrapper.getElementsByTagName('img');
            for (let imageToReduce of imagesToReduce) {
                imageToReduce.style.height = galleryWidth * ratio + 'px';
            }
            wrapper.style.height = galleryWidth * ratio + 'px';
        }

        let wrapperWidth;

        wrapperWidth = 0;
        for (let image of wrapper.children) {
            wrapperWidth += image.clientWidth;
        }
        if (wrapper.className.indexOf('iviparagraphs__gallery-wrapper-start') > 0) {
            wrapper.style.width = wrapperWidth + settings.horizontalPadding * (1) + 'px';
        }
        else {
            wrapper.style.width = wrapperWidth + settings.horizontalPadding * (1) + 'px';
        }

        let firstImagesWidth = 0;
        /**
         * First - in case of moving
         */

        // if (wrapper.className.indexOf('iviparagraphs__gallery-wrapper-start') > 0) {
        if (wrapperWidth < galleryWidth) {
            wrapper.style.left = (galleryWidth - wrapperWidth) / 2 + 'px';
        }
        else {
            if (wrapper.children.length > 2) {
                let centre;
                if (length % 2 == 0) {
                    let i;
                    for (i = 0; i < (length / 2 - 1); i++) {
                        firstImagesWidth += wrapper.children[i].clientWidth;
                    }
                    centre = firstImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2;

                }
                else {
                    let i;
                    for (i = 0; i < (length / 2 - 1); i++) {
                        firstImagesWidth += wrapper.children[i].clientWidth;
                    }
                    centre = firstImagesWidth + wrapper.children[length / 2 - 0.5].clientWidth / 2/* + settings.horizontalPadding * 0.5*/;
                }

                let rightCentre;

                let rightImagesWidth = 0;
                if (length % 2 == 0) {
                    let i;

                    for (i = length; i > (length / 2); i--) {
                        rightImagesWidth += wrapper.children[i - 1].clientWidth;
                    }
                    rightCentre = rightImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2;

                }
                else {
                    let i;
                    for (i = length; i > (length / 2 + 1); i--) {

                        rightImagesWidth += wrapper.children[i - 1].clientWidth;
                    }
                    rightCentre = rightImagesWidth + wrapper.children[length / 2 - 0.5].clientWidth / 2;
                }

                let centreOffset = wrapperWidth / 2 - centre;
                let simpleLeft = (galleryWidth - wrapperWidth) / 2;
                let resultLeft = simpleLeft + centreOffset;
                if (galleryWidth / 2 > centre) {
                    wrapper.style.left = -settings.horizontalPadding + 'px';
                }

                if (galleryWidth / 2 > rightCentre) {
                    wrapper.style.left = resultLeft + galleryWidth / 2 - rightCentre + 'px';
                }
                if (galleryWidth / 2 < centre && galleryWidth / 2 < rightCentre) {
                    wrapper.style.left = resultLeft - settings.horizontalPadding / 2 + 'px';
                }

            }
        }

        /**
         * Add Buttons depending on width of wrapper and gallery itself if setting is true
         */
        if (IviParagraphs.default.gallery.firstButtonsToMove === true) {
            if (wrapperWidth > galleryWidth) {
                IviGallery.buildButtons(wrapper, settings);
            }
            else {
                let btns = wrapper.parentNode.getElementsByClassName('iviparagraphs__gallery-btns');
                if (btns.length > 0) {
                    wrapper.parentNode.removeChild(btns[0]);
                }
            }
        }

        if (IviParagraphs.default.gallery.firstMousedrag === true) {

            if (wrapperWidth > galleryWidth) {

                IviGallery._makeGalleryDrag(wrapper, settings);
            }

        }

        if (IviParagraphs.default.gallery.firstTouchdrag === true) {

            if (wrapperWidth > galleryWidth) {

                IviGallery._makeGalleryTouchDraggable(wrapper, settings);
            }

        }

        if (IviParagraphs.default.gallery.firstControlKeys === true) {

            if (wrapperWidth > galleryWidth) {

                IviGallery._navigateWithArrowKeys(wrapper, settings);
            }

        }

    }

    /**
     * Correct height of gallery and Image on resize
     * @param gallery
     * @param height
     */
    static correctHeight(gallery, height) {
        let wrapper = gallery.getElementsByClassName('iviparagraphs__gallery-wrapper')[0];
        wrapper.style.height = height + 'px';
        for (let image of wrapper.children) {
            image.style.height = height + 'px';
        }
    }

    /**
     * Start building buttons
     * @param wrapper
     * @param settings
     */
    static buildButtons(wrapper, settings) {

        let btnsTest = wrapper.parentNode.getElementsByClassName('iviparagraphs__gallery-btns');
        if (btnsTest.length < 1) {
            let leftBtn = document.createElement('div');
            leftBtn.classList.add('iviparagraphs__gallery-leftbtn');

            let rightBtn = document.createElement('div');
            rightBtn.classList.add('iviparagraphs__gallery-rightbtn');

            let btns = document.createElement('div');
            btns.classList.add('iviparagraphs__gallery-btns');

            wrapper.parentNode.appendChild(btns);
            btns.appendChild(leftBtn);
            btns.appendChild(rightBtn);

            IviGallery.addStyleToButtons(wrapper, settings, leftBtn, rightBtn, btns);
        }
    }

    /**
     * Add style to buttons May be default or own
     * @param wrapper
     * @param settings
     * @param leftBtn
     * @param rightBtn
     * @param btns
     */

    static addStyleToButtons(wrapper, settings, leftBtn, rightBtn, btns) {

        if (IviParagraphs.default.gallery.firstDefaultArrows === true) {
            rightBtn.classList.add('iviparagraphs__gallery-rightbtn-default');
            leftBtn.classList.add('iviparagraphs__gallery-leftbtn-default');
        }
        if (IviParagraphs.default.gallery.firstDefaultArrows === false) {
            if (settings.rightArrowClass !== undefined && settings.rightArrowClass.length > 0) {
                IviParagraphs.addClassToElement(rightBtn, settings.rightArrowClass);
            }
            if (settings.leftArrowClass !== undefined && settings.leftArrowClass.length > 0) {
                IviParagraphs.addClassToElement(leftBtn, settings.leftArrowClass);
            }
        }

        let position = settings.arrowsPosition;

        if (position === 'centre') {
            btns.style.left = wrapper.parentNode.clientWidth / 2 - btns.clientWidth / 2 + 'px';
            btns.style.top = 0;
        }
        if (position === 'left') {
            btns.style.left = 0;
            btns.style.top = 0;
        }
        if (position === 'right' || position === undefined) {
            btns.style.right = 0;
            btns.style.top = 0;
        }
        if (position === 'justify') {
            btns.style.top = 0;
            btns.style.right = 0;
            btns.style.left = 0;
            leftBtn.style.left = 0;
            rightBtn.style.right = 0;
            leftBtn.style.position = 'absolute';
            rightBtn.style.position = 'absolute';
        }
        if (position === 'bottom') {
            btns.style.left = wrapper.parentNode.clientWidth / 2 - btns.clientWidth / 2 + 'px';
            btns.style.bottom = 0;
        }
        IviGallery._runButtons(wrapper, settings, leftBtn, rightBtn);

    }

    /**
     * Start ,mving with buttons depending on which button is clicked
     * @param wrapper
     * @param settings
     * @param leftBtn
     * @param rightBtn
     * @private
     */
    static _runButtons(wrapper, settings, leftBtn, rightBtn) {
        leftBtn.addEventListener('click', (e) => {
            IviGallery._moveSliderRight(wrapper, settings);
        });
        rightBtn.addEventListener('click', (e) => {
            IviGallery._moveSliderLeft(wrapper, settings);
        });
    }

    /**
     * Move with arrow keys. When mouse on, add class to element in order to control it.
     * @param wrapper
     * @param settings
     * @private
     */
    static _navigateWithArrowKeys(wrapper, settings) {
        var el = document.getElementById(wrapper.id);

        el.addEventListener("mouseover", function () {
            IviParagraphs.addClassToElement(el, 'iviparagraphs__gallery-wrapper-hover');
            document.body.onkeydown = function (event) {
                IviGallery._decideHowToMoveWithKeys(event.keyCode, wrapper, settings);
            };
        }, false);
        el.addEventListener("mouseout", function () {
            el.classList.remove('iviparagraphs__gallery-wrapper-hover');
        }, false);
    }

    /**
     * Decide whether to move right or left when controlling with keys
     * @param isClicked
     * @param wrapper
     * @param settings
     * @private
     */
    static _decideHowToMoveWithKeys(keyCode, wrapper, settings) {
        if (keyCode === 37) {
            if (IviParagraphs.elementHasClass(wrapper, 'iviparagraphs__gallery-wrapper-hover')) {
                IviGallery._moveSliderRight(wrapper, settings);
            }
        }
        if (keyCode === 39) {
            if (IviParagraphs.elementHasClass(wrapper, 'iviparagraphs__gallery-wrapper-hover')) {
                IviGallery._moveSliderLeft(wrapper, settings);
            }
        }
    }

    static _moveGalleryOnMouseClick(wrapper, settings) {
        var el = document.getElementById(wrapper.id);
        el.onclick = function (e) {
            IviGallery._decideHowToMove(e.clientX, wrapper, settings);
        };
    }

    /**
     * Decide whether to move right or left when controlling with click
     * @param isClicked
     * @param wrapper
     * @param settings
     * @private
     */
    static _decideHowToMove(isClicked, wrapper, settings) {
        if (isClicked < 0.3 * wrapper.parentNode.clientWidth) {
            IviGallery._moveSliderRight(wrapper, settings);
        }
        if (isClicked > 0.7 * wrapper.parentNode.clientWidth) {
            IviGallery._moveSliderLeft(wrapper, settings);
        }
    }

    /**
     * For touch events
     * @param wrapper
     * @param settings
     * @private
     */
    static _makeGalleryTouchDraggable(wrapper, settings) {

        var draggingIndex;
        var isDown = false;
        var el = document.getElementById(wrapper.id);
        var startX;
        let style = getComputedStyle(wrapper);
        var startLeft = parseInt(style.getPropertyValue('left'), 10);
        var dx = 0;
        var startPosition;
        var endPosition;

// listen to mouse events
        wrapper.addEventListener('touchstart', function (e) {
            if (wrapper.clientWidth > wrapper.parentNode.clientWidth) {

                IviParagraphs.addClassToElement(wrapper, wrapper.id);
                handleMouseDown(e);
            }
        });


        wrapper.ontouchmove = function (e) {
            if (wrapper.clientWidth > wrapper.parentNode.clientWidth) {
                handleMouseMove(e);
            }
        };

        wrapper.ontouchend = function (e) {
            if (wrapper.clientWidth > wrapper.parentNode.clientWidth) {
                handleMouseUp(e);
            }
        };


        function handleMouseDown(e) {
            // tell the browser we're handling this event
            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === true) {
                e.preventDefault();
                e.stopPropagation();
                // get mouse position
                startX = parseInt(e.touches[0].clientX);
                startPosition = e.touches[0].clientX;
                draggingIndex = undefined;
                isDown = true;
            }

            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === false) {
                return;
            }

        }

        function handleMouseUp(e) {

            endPosition = e.changedTouches[0].clientX;
            //    if (endPosition - startPosition > 10 || startPosition - endPosition > 10)
            if ((endPosition > startPosition && endPosition - startPosition > 10) || (startPosition > endPosition && startPosition - endPosition > 10)) {

                if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === true) {
                    // tell the browser we're handling this event
                    e.preventDefault();
                    e.stopPropagation();
                    isDown = false;

                    var newLeft;
                    if (dx > 0) {
                        newLeft = parseInt(style.getPropertyValue('left'), 10);
                        IviGallery._moveSliderRight(wrapper, settings, newLeft);
                    }
                    else {
                        newLeft = parseInt(style.getPropertyValue('left'), 10);
                        IviGallery._moveSliderLeft(wrapper, settings, newLeft);
                    }
                    dx = 0;
                    wrapper.classList.remove(wrapper.id);
                }
                if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === false) {

                }
            }
            else {
                IviGallery._decideHowToMove(startPosition, wrapper, settings);
            }


        }

        function handleMouseMove(e) {

            if (!isDown) {
                return;
            }
            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === true) {

                e.preventDefault();
                e.stopPropagation();
                // get mouse position
                let mouseX = parseInt(e.touches[0].clientX);
                var dragging = wrapper;
                dx = mouseX - startX;
                startX = mouseX;
                wrapper.style.left = (parseInt(dragging.style.left) + dx) + 'px';

                el.touchcancel = function () {
                    wrapper.classList.remove(wrapper.id);
                    wrapper.style.left = startLeft + 'px';
                    return false;
                };

            }

            el.touchcancel = function () {

                if (IviParagraphs.elementHasClass(wrapper, wrapper.id) == true) {
                    wrapper.classList.remove(wrapper.id);
                    wrapper.style.left = startLeft + 'px';
                    //  startLeft = 0;
                    return false;
                }

            };
        }
    }

    static _makeGalleryDrag(wrapper, settings) {

        var draggingIndex;
        var isDown = false;
        var el = document.getElementById(wrapper.id);
        var startX;
        let style = getComputedStyle(wrapper);
        var startLeft = parseInt(style.getPropertyValue('left'), 10);
        var dx = 0;

        var startPosition;
        var movePosition;
        var endPosition;

// listen to mouse events
        wrapper.onmousedown = (function (e) {
            if (wrapper.clientWidth > wrapper.parentNode.clientWidth) {
                IviParagraphs.addClassToElement(wrapper, wrapper.id);
                handleMouseDown(e);
            }
        });
        wrapper.onmousemove = (function (e) {
            if (wrapper.clientWidth > wrapper.parentNode.clientWidth) {
                handleMouseMove(e);
            }

        });
        wrapper.onmouseup = (function (e) {
            if (wrapper.clientWidth > wrapper.parentNode.clientWidth) {
                handleMouseUp(e);
            }

        });


        function handleMouseDown(e) {
            // tell the browser we're handling this event
            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === true) {
                e.preventDefault();
                e.stopPropagation();
                startPosition = e.clientX;
                // get mouse position
                startX = parseInt(e.clientX);
                draggingIndex = undefined;
                isDown = true;
            }

            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === false) {
                return;
            }

        }

        function handleMouseUp(e) {

            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === true) {
                // tell the browser we're handling this event
                endPosition = e.clientX;

                if ((endPosition > startPosition && endPosition - startPosition > 10) || (startPosition > endPosition && startPosition - endPosition > 10) || (((endPosition > startPosition && endPosition - startPosition < 10) || (startPosition > endPosition && startPosition - endPosition < 10)) && 0.3 * wrapper.parentNode.clientWidth < startPosition && startPosition < 0.7 * wrapper.parentNode.clientWidth)) {
                    e.preventDefault();
                    e.stopPropagation();
                    isDown = false;
                    var newLeft;
                    if (dx > 0) {
                        newLeft = parseInt(style.getPropertyValue('left'), 10);
                        IviGallery._moveSliderRight(wrapper, settings, newLeft);
                    }
                    else {
                        newLeft = parseInt(style.getPropertyValue('left'), 10);
                        IviGallery._moveSliderLeft(wrapper, settings, newLeft);
                    }
                    dx = 0;
                    wrapper.classList.remove(wrapper.id);
                }
                else {
                    wrapper.classList.remove(wrapper.id);
                    IviGallery._decideHowToMove(startPosition, wrapper, settings);
                }
                if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === false) {

                }
            }


        }

        function handleMouseMove(e) {

            movePosition = e.clientX;
            // if (movePosition - startPosition > 10 || startPosition - movePosition > 10) {
            if (!isDown) {
                return;
            }
            if (IviParagraphs.elementHasClass(wrapper, wrapper.id) === true) {

                e.preventDefault();
                e.stopPropagation();
                // get mouse position
                let mouseX = parseInt(e.clientX);
                var dragging = wrapper;
                dx = mouseX - startX;
                startX = mouseX;
                wrapper.style.left = (parseInt(dragging.style.left) + dx) + 'px';

                el.onmouseout = function () {
                    wrapper.classList.remove(wrapper.id);
                    wrapper.style.left = startLeft + 'px';
                    return false;
                };

            }

            el.onmouseout = function () {

                if (IviParagraphs.elementHasClass(wrapper, wrapper.id) == true) {
                    wrapper.classList.remove(wrapper.id);
                    wrapper.style.left = startLeft + 'px';
                    //  startLeft = 0;
                    return false;
                }

            };
            //   }


        }


    }


    static _moveSliderLeft(wrapper, settings, startLeft) {
        if (wrapper.className.indexOf('iviparagraphs__gallery-wrapper-start') < 0) {
            IviGallery._addWidthAndPaddingToGalleryByMove(wrapper, settings);
        }
        IviGallery._transformSliderLeft(wrapper, settings, startLeft);
        setTimeout(function () {
            let clone = wrapper.parentNode.getElementsByClassName('iviparagraphs__gallery-wrapper-clone');
            wrapper.appendChild(wrapper.firstChild);
            wrapper.style.opacity = 1;
            wrapper.parentNode.removeChild(clone[0]);
            IviGallery.correctLeft(wrapper.parentNode, settings);
        }, 500);


    }

    static _moveSliderRight(wrapper, settings, startLeft) {
        if (wrapper.className.indexOf('iviparagraphs__gallery-wrapper-start') < 0) {
            IviGallery._addWidthAndPaddingToGalleryByMove(wrapper, settings);
        }
        IviGallery._transformSliderRight(wrapper, settings, startLeft);
        IviGallery.correctLeft(wrapper.parentNode, settings);
        setTimeout(function () {
            let clone = wrapper.parentNode.getElementsByClassName('iviparagraphs__gallery-wrapper-clone');
            wrapper.insertBefore(wrapper.lastChild, wrapper.firstChild);
            wrapper.style.opacity = 1;
            // IviParagraphs.addClassToElement(clone, 'iviparagraphs__gallery-wrapper-clone-inactive');
            wrapper.parentNode.removeChild(clone[0]);
            IviGallery.correctLeft(wrapper.parentNode, settings);
        }, 500);
    }

    /**
     * Add Paddings to first and last elements in order to make all paddings the same. And add the width of these paddings to the width of wrapper
     * Also add class in order not to repeat this action (class is the orientation for the code)
     * @param wrapper
     * @param settings
     */
    static _addWidthAndPaddingToGalleryByMove(wrapper, settings) {
        IviParagraphs.addClassToElement(wrapper, 'iviparagraphs__gallery-wrapper-start');
        let style = getComputedStyle(wrapper);
        let width = parseInt(style.getPropertyValue('width'), 10);
        let wrapperWidthWithNewPaddings = width + settings.horizontalPadding;
        wrapper.style.width = wrapperWidthWithNewPaddings + 'px';
        wrapper.firstChild.style.paddingLeft = settings.horizontalPadding / 2 + 'px';
        wrapper.lastChild.style.paddingRight = settings.horizontalPadding / 2 + 'px';
    }

    static _transformSliderLeft(wrapper, settings, startLeft) {
        let oldLeft;
        //If event comes from btn, we have the oldLeft itself. If from drag - we get the position of dragged wrapper
        if (startLeft === undefined) {
            oldLeft = IviGallery._getOldLeft(wrapper, settings);
        }
        else {
            oldLeft = startLeft;
        }
        let newLeft = IviGallery._getNewLeftForLeft(wrapper, settings);
        let firstWidth = wrapper.firstChild.clientWidth;
        let distance = -(oldLeft - newLeft + firstWidth);
        let clone = wrapper.cloneNode(true); // true means clone all childNodes and all event handlers
        clone.classList.add('iviparagraphs__gallery-wrapper-clone');
        clone.style.transform = 'translate(0px)';
        clone.style.mozTransform = 'translate(0px)';
        clone.style.webkitTransform = 'translate(0px)';
        wrapper.parentNode.appendChild(clone);
        clone.style.zIndex = 2;
        clone.style.backgroundColor = settings.cloneBackground;
        wrapper.style.opacity = 0;
        clone.classList.add('iviparagraphs__gallery-wrapper-clone-active');
        setTimeout(function () {
            clone.style.transform = 'translate(' + distance + 'px)';
            clone.style.mozTransform = 'translate(' + distance + 'px)';
            clone.style.webkitTransform = 'translate(' + distance + 'px)';
        }, 50);

    }

    static _transformSliderRight(wrapper, settings, startLeft) {
        let oldLeft;
        if (startLeft === undefined) {
            oldLeft = IviGallery._getOldLeft(wrapper, settings);
        }
        else {
            oldLeft = startLeft;
        }

        let newLeft = IviGallery._getNewLeftForRight(wrapper, settings);
        let lastWidth = wrapper.lastChild.clientWidth;
        let distance = (lastWidth - (oldLeft - newLeft));
        let clone = wrapper.cloneNode(true); // true means clone all childNodes and all event handlers
        clone.classList.add('iviparagraphs__gallery-wrapper-clone');
        clone.style.transform = 'translate(0px)';
        clone.style.mozTransform = 'translate(0px)';
        clone.style.webkitTransform = 'translate(0px)';
        wrapper.parentNode.appendChild(clone);
        clone.style.zIndex = 2;
        clone.style.backgroundColor = settings.cloneBackground;
        wrapper.style.opacity = 0;
        clone.classList.add('iviparagraphs__gallery-wrapper-clone-active');
        setTimeout(function () {
            clone.style.transform = 'translate(' + distance + 'px)';
            clone.style.mozTransform = 'translate(' + distance + 'px)';
            clone.style.webkitTransform = 'translate(' + distance + 'px)';
        }, 50);

    }

    static _getOldLeft(wrapper, settings) {
        let length = wrapper.childElementCount;
        let galleryWidth = wrapper.parentNode.clientWidth;
        let firstImagesWidth = 0;
        let centre;

        if (length % 2 == 0) {
            let i;
            for (i = 0; i < (length / 2 - 1); i++) {
                firstImagesWidth += wrapper.children[i].clientWidth;
            }
            centre = firstImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2;
        }
        else {
            let i;
            for (i = 0; i < (length / 2 - 1); i++) {
                firstImagesWidth += wrapper.children[i].clientWidth;
            }
            centre = firstImagesWidth + wrapper.children[length / 2 - 0.5].clientWidth / 2;
        }

        let rightCentre;

        let rightImagesWidth = 0;
        if (length % 2 == 0) {
            let i;
            for (i = length; i > (length / 2 + 1); i--) {

                rightImagesWidth += wrapper.children[i - 1].clientWidth;
            }
            rightCentre = rightImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2;

        }
        else {
            let i;
            for (i = length; i > (length / 2 + 1); i--) {

                rightImagesWidth += wrapper.children[i - 1].clientWidth;
            }
            rightCentre = rightImagesWidth + wrapper.children[length / 2 - 0.5].clientWidth / 2;
        }

        let centreOffset = wrapper.clientWidth / 2 - centre;
        // let simpleLeft = (galleryWidth - wrapperWidth) / 2 - settings.horizontalPadding;
        let simpleLeft = (galleryWidth - wrapper.clientWidth) / 2;
        let resultLeft = simpleLeft + centreOffset;

        if (galleryWidth / 2 > centre) {
            return -settings.horizontalPadding;
        }
        if (galleryWidth / 2 > rightCentre) {
            return resultLeft + galleryWidth / 2 - rightCentre;
        }
        if (galleryWidth / 2 < centre && galleryWidth / 2 < rightCentre) {
            return resultLeft - settings.horizontalPadding / 2;
        }
    }

    static _getNewLeftForLeft(wrapper, settings) {
        let length = wrapper.childElementCount;
        let galleryWidth = wrapper.parentNode.clientWidth;
        let firstImagesWidth = 0;
        let centre;

        if (length % 2 == 0) {
            let i;
            for (i = 1; i < (length / 2); i++) {
                firstImagesWidth += wrapper.children[i].clientWidth;
            }
            centre = firstImagesWidth + wrapper.children[length / 2].clientWidth / 2;
        }
        else {
            let i;
            for (i = 1; i < (length / 2); i++) {
                firstImagesWidth += wrapper.children[i].clientWidth;
            }
            centre = firstImagesWidth + wrapper.children[length / 2 + 0.5].clientWidth / 2;
        }

        let rightCentre;

        let rightImagesWidth = 0;
        if (length % 2 == 0) {
            let i;
            for (i = length; i > (length / 2 + 1); i--) {

                rightImagesWidth += wrapper.children[i - 1].clientWidth;
            }
            rightCentre = rightImagesWidth + wrapper.children[length / 2 - 1].clientWidth / 2 + wrapper.firstChild.clientWidth;

        }
        else {
            if (length < 4) {
                rightCentre = wrapper.firstChild.clientWidth + wrapper.children[2].clientWidth / 2 - settings.horizontalPadding;
            }
            else {
                let i;
                for (i = length; i > (length / 2 + 1); i--) {

                    rightImagesWidth += wrapper.children[i - 1].clientWidth;
                }
                rightCentre = rightImagesWidth + wrapper.children[length / 2 + 0.5].clientWidth / 2 + wrapper.firstChild.clientWidth;
            }

        }

        let centreOffset = wrapper.clientWidth / 2 - centre;
        let simpleLeft = (galleryWidth - wrapper.clientWidth) / 2;
        let resultLeft = simpleLeft + centreOffset;

        if (galleryWidth / 2 > centre) {
            return -settings.horizontalPadding;
        }
        if (galleryWidth / 2 > rightCentre) {
            return resultLeft + galleryWidth / 2 - rightCentre;
        }
        if (galleryWidth / 2 < centre && galleryWidth / 2 < rightCentre) {
            return resultLeft - settings.horizontalPadding / 2;
        }
    }

    static _getNewLeftForRight(wrapper, settings) {
        let length = wrapper.childElementCount;
        let galleryWidth = wrapper.parentNode.clientWidth;
        let firstImagesWidth = 0;
        let centre;

        if (length % 2 == 0) {
            let i;
            for (i = 1; i < (length / 2 - 1); i++) {
                firstImagesWidth += wrapper.children[i - 1].clientWidth;
            }
            centre = firstImagesWidth + wrapper.children[length / 2 - 2].clientWidth / 2 + wrapper.lastChild.clientWidth;
        }
        else {
            if (length < 4) {
                centre = wrapper.lastChild.clientWidth + wrapper.children[0].clientWidth / 2/* - settings.horizontalPadding*/;
            }
            else {
                let i;
                for (i = 1; i < (length / 2 - 1); i++) {
                    firstImagesWidth += wrapper.children[i - 1].clientWidth;
                }
                centre = firstImagesWidth + wrapper.children[length / 2 - 1.5].clientWidth / 2 + wrapper.lastChild.clientWidth;
            }

        }


        let rightCentre;

        let rightImagesWidth = 0;
        if (length % 2 == 0) {
            let i;
            for (i = length; i > (length / 2 - 1); i--) {
                rightImagesWidth += wrapper.children[i - 1].clientWidth;
            }
            rightCentre = rightImagesWidth + wrapper.children[length / 2 - 2].clientWidth / 2 - wrapper.lastChild.clientWidth;

        }
        else {
            if (length < 4) {
                rightCentre = wrapper.firstChild.clientWidth / 2 + wrapper.children[1].clientWidth/* - settings.horizontalPadding*/;
            }
            else {
                let i;
                for (i = length; i > (length / 2); i--) {
                    rightImagesWidth += wrapper.children[i - 1].clientWidth;
                }

                rightCentre = rightImagesWidth + wrapper.children[length / 2 - 1.5].clientWidth / 2 - wrapper.lastChild.clientWidth;
            }

        }

        let centreOffset = wrapper.clientWidth / 2 - centre;
        // let simpleLeft = (galleryWidth - wrapperWidth) / 2 - settings.horizontalPadding;
        let simpleLeft = (galleryWidth - wrapper.clientWidth) / 2;
        let resultLeft = simpleLeft + centreOffset;

        if (galleryWidth / 2 > centre) {
            return -settings.horizontalPadding;
        }
        if (galleryWidth / 2 > rightCentre) {
            return resultLeft + galleryWidth / 2 - rightCentre;
        }
        if (galleryWidth / 2 < centre && galleryWidth / 2 < rightCentre) {
            return resultLeft - settings.horizontalPadding / 2;
        }
    }

}