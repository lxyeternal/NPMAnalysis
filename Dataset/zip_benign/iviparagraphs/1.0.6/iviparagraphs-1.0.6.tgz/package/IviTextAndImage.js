import IviParagraphs from './IviParagraphs';
export default class IviTextAndImage {

    constructor(textAndImageClass, settings) {

    }

    static set(textAndImageClass, settings) {
        var textAndImages = document.getElementsByClassName(textAndImageClass);
        if (textAndImages.length > 0) {
            IviTextAndImage._run(textAndImages, settings);
        }

    }

    static _run(textAndImages, settings) {
        for (var element of textAndImages) {
            if (settings.defaultStyle == true) {
                element.className += " iviparagraphs__textandimage-default";
                for (let child of element.children) {
                    IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandimage');
                }
                let position = IviParagraphs.leftOrRight(element);
                IviTextAndImage._buildImg(element, settings, position);
            }

            let styleNumber = IviParagraphs.getStyleNumber(element);

            if (settings.defaultStyle == false) {

                let position = IviParagraphs.leftOrRight(element);
                IviTextAndImage._buildImg(element, settings, position);
                if (settings.span == true) {
                    //IviTextAndImage._addSpan(element, styleNumber, settings);
                    let wrapper = element.getElementsByClassName('iviparagraphs__textandimage-wrapper')[0];
                    IviParagraphs.addSpan(wrapper, styleNumber, settings, 'iviparagraphs__textandimage', 'iviparagraphs__textandimage-title', 'iviparagraphs__textandimage-subtitle', 'iviparagraphs__textandimage-text', 'iviparagraphs__textandimage-link', 'iviparagraphs__textandimage-textwrapper');
                }
                IviTextAndImage._setStyles(element, settings);
            }
        }

        if (document.getElementsByClassName('iviplaceholder').length > 0) {
            for (let item of document.getElementsByClassName('iviplaceholder')) {
                if (item.className.indexOf('iviplaceholder-none') < 1) {
                    IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                }
            }
        }
    }

    static _buildImg(element, settings, position) {
        IviParagraphs.setCss(element, 'marginTop', settings.marginTop + 'px');
        IviParagraphs.setCss(element, 'marginBottom', settings.marginBottom + 'px');
        let image = element.getElementsByClassName('iviparagraphs__textandimage-img')[0];
        let fid = IviParagraphs.getFid(image);

        if(fid) {
            IviParagraphs.getJSONforSingleImageFromFid(fid, image);
        }

      /*  if (IviParagraphs.elementHasClass(image, 'ivimap')) {
            IviParagraphs.addMap(image);
        }*/

        let fidForWrapper = IviParagraphs.getFid(element);

        let wrapper = document.createElement('div');
        wrapper.classList.add('iviparagraphs__textandimage-wrapper');
        if (settings.defaultStyle == true) {
            wrapper.classList.add('iviparagraphs__textandimage-wrapper-default');
        }
        if (fidForWrapper !== false) {
            wrapper.classList.add('iviparagraphs__textandimage-wrapper-img-' + fidForWrapper);
        }
        element.appendChild(wrapper);

        let title = element.getElementsByClassName('iviparagraphs__textandimage-title');
        let subtitle = element.getElementsByClassName('iviparagraphs__textandimage-subtitle');
        let text = element.getElementsByClassName('iviparagraphs__textandimage-text');
        let link = element.getElementsByClassName('iviparagraphs__textandimage-link');

        if (title.length > 0) {
            wrapper.appendChild(title[0]);
        }
        if (subtitle.length > 0) {
            wrapper.appendChild(subtitle[0]);
        }
        if (text.length > 0) {
            wrapper.appendChild(text[0]);
        }
        if (link.length > 0) {
            wrapper.appendChild(link[0]);
        }
        if (position === 'right') {
            element.appendChild(image);
        }

        if (settings.defaultStyle == true) {
            IviTextAndImage._applyDefaultPaddings(element, settings)
        }
    }

    static _applyDefaultPaddings(element, settings) {
        //  let imageWidth = IviParagraphs.applySize(settings.defaultImgWidth.responsive);
        let wrapper;
        if (element.getElementsByClassName('iviparagraphs__textandimage-textwrapper').length > 0) {
            wrapper = element.getElementsByClassName('iviparagraphs__textandimage-textwrapper')[0];
        }
        else {
            wrapper = element.getElementsByClassName('iviparagraphs__textandimage-wrapper')[0];
        }

        let image = element.getElementsByClassName('iviparagraphs__textandimage-img')[0];

        if (window.innerWidth < 768) {
            let imageWidth = image.clientWidth;
            image.style.height = imageWidth + 'px';
            for (let child of wrapper.children) {
                if (child == wrapper.firstChild) {
                    child.style.paddingTop = settings.zeroElementsPadding + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                }
                else if (child == wrapper.lastChild) {
                    child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                }
                else {
                    child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                }
            }
        }
        else {
            IviTextAndImage._applyImageStylesForLargerScreens(element, settings);
        }

        window.addEventListener('resize', function () {
            if (window.innerWidth < 768) {
                let imageWidth = image.clientWidth;
                image.style.height = imageWidth + 'px';
                for (let child of wrapper.children) {
                    if (child == wrapper.firstChild) {
                        child.style.paddingTop = settings.zeroElementsPadding + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                    else if (child == wrapper.lastChild) {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                    }
                    else {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                }
            }
            else {
                IviTextAndImage._applyImageStylesForLargerScreens(element, settings);
            }
        });

        function onElementClassChange(elm, callback) {
            var lastClasses = elm.className, newClasses;
            (function run() {
                newClasses = elm.className;
                if (lastClasses != newClasses)
                    callback();
                lastClasses = newClasses;

                if (elm.ElementClassChange)
                    clearTimeout(elm.ElementClassChangeTimer);

                elm.ElementClassChangeTimer = setTimeout(run, 200);
            })();
        }

        onElementClassChange(document.body, function () {
            setTimeout(function () {
                if (window.innerWidth < 768) {
                    let imageWidth = image.clientWidth;
                    image.style.height = imageWidth + 'px';
                    for (let child of wrapper.children) {
                        if (child == wrapper.firstChild) {
                            child.style.paddingTop = settings.zeroElementsPadding + 'px';
                            child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                        }
                        else if (child == wrapper.lastChild) {
                            child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                            child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                        }
                        else {
                            child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                            child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                        }
                    }
                }
                else {
                    IviTextAndImage._applyImageStylesForLargerScreens(element, settings);
                }
            }, 400);
        });
    }

    static _applyImageStylesForLargerScreens(element, settings) {

        let wrapper;
        let wrapperMarginTop = 0;
        let wrapperMarginBottom = 0;
        if (element.getElementsByClassName('iviparagraphs__textandimage-textwrapper').length > 0) {
            wrapper = element.getElementsByClassName('iviparagraphs__textandimage-textwrapper')[0];
            let styleSettings = settings[IviParagraphs.getStyleNumber(element)];

            if (styleSettings.hasOwnProperty('textwrapper')) {
                if (styleSettings.textwrapper.hasOwnProperty('marginTop')) {
                    wrapperMarginTop += Math.floor(styleSettings.textwrapper.marginTop.substring(0, styleSettings.textwrapper.marginTop.length - 2));
                }
                if (styleSettings.textwrapper.hasOwnProperty('marginBottom')) {
                    wrapperMarginBottom += Math.floor(styleSettings.textwrapper.marginBottom.substring(0, styleSettings.textwrapper.marginBottom.length - 2));
                }
            }
        }
        else {
            wrapper = element.getElementsByClassName('iviparagraphs__textandimage-wrapper')[0];
        }
        let image = element.getElementsByClassName('iviparagraphs__textandimage-img')[0];
        let imageProcentage = image.clientWidth / element.clientWidth;
        let idealHeight;
        if (imageProcentage < 0.34) {
            idealHeight = image.clientWidth;
        }
        if (0.33 < imageProcentage < 0.42) {
            idealHeight = image.clientWidth * 0.75;
        }
        if (imageProcentage > 0.41) {
            idealHeight = image.clientWidth * 0.5;
        }

        let elementsHeight = 0;

        for (let child of wrapper.children) {
            var cs = getComputedStyle(child);
            var paddingY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
            elementsHeight += child.clientHeight - paddingY;
            if (child == wrapper.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == wrapper.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
        }

        if (idealHeight > elementsHeight + settings.largeElementsPadding * (wrapper.childElementCount + 1) + wrapperMarginTop + wrapperMarginBottom) {
            image.style.height = idealHeight + 'px';
            if (wrapperMarginTop + wrapperMarginBottom == 0) {
                wrapper.style.paddingTop = (idealHeight - (elementsHeight + settings.largeElementsPadding * (wrapper.childElementCount + 1))) / 2 + 'px';
                wrapper.style.height = idealHeight + 'px';
            }
            else {
                // wrapper.style.marginTop = (idealHeight - (elementsHeight + settings.largeElementsPadding * (wrapper.childElementCount + 1) + wrapperMarginTop + wrapperMarginBottom)) / 2 + 'px';
                // wrapper.style.marginBottom = (idealHeight - (elementsHeight + settings.largeElementsPadding * (wrapper.childElementCount + 1) + wrapperMarginTop + wrapperMarginBottom)) / 2 + 'px';
                wrapper.style.height = idealHeight - wrapperMarginTop - wrapperMarginBottom + 'px';
            }

        }
        else {
            wrapper.style.paddingTop = 0 + 'px';
            wrapper.style.marginTop = wrapperMarginTop + 'px';
            wrapper.style.marginBottom = wrapperMarginBottom + 'px';
            image.style.height = elementsHeight + settings.largeElementsPadding * (wrapper.childElementCount + 1) + wrapperMarginTop + wrapperMarginBottom + 'px';
        }
    }

    static _setStyles(element, settings) {
        let wrapper = element.getElementsByClassName('iviparagraphs__textandimage-wrapper')[0];
        let styleNumber = IviParagraphs.getStyleNumber(element);
        let styleSettings = settings[styleNumber];
        if (styleSettings == undefined) {
            element.className += " iviparagraphs__textandimage-default";
            for (let child of element.children) {
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandimage');
            }
            let wrapper = element.getElementsByClassName('iviparagraphs__textandimage-wrapper')[0];
            for (let child of wrapper.children) {
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandimage');
            }
            //  IviTextAndImage._applyImageStylesForLargerScreens(element, settings);
        }

        if (styleSettings !== undefined) {

            IviTextAndImage._setMainCss(element, styleSettings);

            for (let key in styleSettings) {

                if (key == 'ImgWidth') {
                    IviTextAndImage._setImageWidth(element, styleSettings);
                }
                if (key == 'TextWidth') {
                    IviTextAndImage._setTextWidth(element, styleSettings);
                }
                if (key == 'title' || key == 'subtitle' || key == 'text' || key == 'link' || key == 'textwrapper') {
                    IviTextAndImage._setElementCss(element, key, styleSettings);
                }
                if (key == 'linkClass') {
                    let link = element.getElementsByClassName('iviparagraphs__textandimage-link');
                    if (link.length > 0) {
                        link[0].className += ' ' + styleSettings['linkClass'];
                    }
                }
                if (key == 'titleClass') {
                    let title = element.getElementsByClassName('iviparagraphs__textandimage-title');
                    if (title.length > 0) {
                        title[0].className += ' ' + styleSettings['titleClass'];
                    }
                }
                if (key == 'subtitleClass') {
                    let subtitle = element.getElementsByClassName('iviparagraphs__textandimage-subtitle');
                    if (subtitle.length > 0) {
                        subtitle[0].className += ' ' + styleSettings['subtitleClass'];
                    }
                }
                if (key == 'textClass') {
                    let text = element.getElementsByClassName('iviparagraphs__textandimage-text');
                    if (text.length > 0) {
                        text[0].className += ' ' + styleSettings['textClass'];
                    }
                }
            }

        }
        IviTextAndImage._applyDefaultPaddings(element, settings);

        let fid = IviParagraphs.getFid(wrapper);
        if (fid !== false) {
            IviParagraphs.getJSONforSingleImageFromFid(fid, wrapper);
        }
    }


    static _setMainCss(element, styleSettings) {
        if (styleSettings.hasOwnProperty('main')) {
            IviParagraphs.defineCss(element, styleSettings.main);

        }
    }

    static _setImageWidth(element, styleSettings) {
        if (styleSettings.hasOwnProperty('ImgWidth')) {
            let img = element.getElementsByClassName('iviparagraphs__textandimage-img')[0];
            IviParagraphs.defineCss(img, styleSettings.ImgWidth);

        }
    }

    static _setTextWidth(element, styleSettings) {
        if (styleSettings.hasOwnProperty('TextWidth')) {
            let wrapper = element.getElementsByClassName('iviparagraphs__textandimage-wrapper')[0];
            IviParagraphs.defineCss(wrapper, styleSettings.TextWidth);

        }
    }

    static _setElementCss(element, fragment, styleSettings) {
        let elementPart = element.getElementsByClassName('iviparagraphs__textandimage-' + fragment);

        if (elementPart.length > 0) {
            IviParagraphs.defineCss(elementPart[0], styleSettings[fragment]);

        }
    }
}