import IviParagraphs from './IviParagraphs';
export default class IviThreeParts {

    static set(threePartsClass, settings) {
        var threePartsEls = document.getElementsByClassName(threePartsClass);
        if (threePartsEls.length > 0) {
            IviThreeParts._run(threePartsEls, settings);
        }
    }

    static _run(threePartsEls, settings) {

        for (let threeParts of threePartsEls) {
            if (threeParts.childElementCount === 3) {
                IviThreeParts.orderElements(threeParts);
                IviParagraphs.setCss(threeParts, 'marginTop', settings.marginTop + 'px');
                IviParagraphs.setCss(threeParts, 'marginBottom', settings.marginBottom + 'px');
                let fid = IviParagraphs.getFid(threeParts.getElementsByClassName('iviparagraphs__threeparts-img')[0]);
                if (fid !== false) {
                    IviParagraphs.getJSONforSingleImageFromFid(fid, threeParts.getElementsByClassName('iviparagraphs__threeparts-imgwrapper')[0]);
                }

                let fid2 = IviParagraphs.getFid(threeParts.getElementsByClassName('iviparagraphs__threeparts-title')[0]);
                if (fid2 !== false) {
                    IviParagraphs.getJSONforSingleImageFromFid(fid2, threeParts.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0]);
                }

                function onElementHeightChange(elm, callback) {
                    var lastHeight = elm.clientHeight, newHeight;
                    (function run() {
                        newHeight = elm.clientHeight;
                        if (lastHeight != newHeight)
                            callback();
                        lastHeight = newHeight;

                        if (elm.onElementHeightChangeTimer)
                            clearTimeout(elm.onElementHeightChangeTimer);

                        elm.onElementHeightChangeTimer = setTimeout(run, 200);
                    })();
                }

                if (settings.defaultStyle == true) {
                    threeParts.className += " iviparagraphs__threeparts-default";
                    for (let child of threeParts.children) {
                        IviParagraphs.setDefaultSettings(child, 'iviparagraphs__threeparts');
                        for (let childChild of child.children) {
                            IviParagraphs.setDefaultSettings(childChild, 'iviparagraphs__threeparts');
                        }
                    }
                }

                if (settings.defaultStyle == false) {
                    IviThreeParts._setCss(threeParts, settings);

                }

                if (window.innerWidth < 768) {
                    IviThreeParts._setHeightOfImageForMobile(threeParts);
                }
                else {
                    IviThreeParts._buildElementsForLargerScreens(threeParts, settings);
                }

                window.addEventListener('resize', function () {
                    if (window.innerWidth < 768) {
                        IviThreeParts._setHeightOfImageForMobile(threeParts);
                    }
                    else {
                        IviThreeParts._buildElementsForLargerScreens(threeParts, settings);
                    }
                });


                onElementHeightChange(document.body, function () {
                    if (window.innerWidth < 768) {
                        IviThreeParts._setHeightOfImageForMobile(threeParts);
                    }
                    else {
                        IviThreeParts._buildElementsForLargerScreens(threeParts, settings);
                    }
                });

                function onElementClassChange(elm, callback) {
                    var lastClasses = elm.className, newClasses;
                    (function run() {
                        newClasses = elm.className;
                        if (lastClasses != newClasses)
                            callback();
                        lastClasses = newClasses;

                        if (elm.ElementClassChange)
                            clearTimeout(elm.ElementClassChangeTimer);

                        elm.ElementClassChangeTimer = setTimeout(run, 200);
                    })();
                }

                onElementClassChange(document.body, function () {
                    setTimeout(function () {
                        if (window.innerWidth < 768) {
                            IviThreeParts._setHeightOfImageForMobile(threeParts);
                        }
                        else {
                            IviThreeParts._buildElementsForLargerScreens(threeParts, settings);
                        }
                    }, 400);
                });
            }

        }
    }

    static _setCss(threeParts, settings) {
        let styleNumber = IviParagraphs.getStyleNumber(threeParts);
        let styleSettings = settings[styleNumber];
        if (styleSettings == undefined) {
            threeParts.className += " iviparagraphs__threeparts-default";
            for (let child of threeParts.children) {
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__threeparts');
                for (let childChild of child.children) {
                    IviParagraphs.setDefaultSettings(childChild, 'iviparagraphs__threeparts');
                }
            }
        }

        if (styleSettings !== undefined) {

            IviThreeParts._setMainCss(threeParts, styleSettings);
            for (let key in styleSettings) {

                if (key == 'imgWidth') {
                    IviThreeParts._setImageWidth(threeParts, styleSettings);
                }
                if (key == 'textWidth') {
                    IviThreeParts._setTextWidth(threeParts, styleSettings);
                }
                if (key == 'titleWidth') {
                    IviThreeParts._setTitleWidth(threeParts, styleSettings);
                }
                if (key == 'title' || key == 'text' || key == 'textwrapper') {
                    IviThreeParts._setElementCss(threeParts, key, styleSettings);
                }
                if (key == 'titleClass') {
                    let title = threeParts.getElementsByClassName('iviparagraphs__threeparts-title');
                    if (title.length > 0) {
                        title[0].className += ' ' + styleSettings['titleClass'];
                    }
                }
                if (key == 'textClass') {
                    let text = threeParts.getElementsByClassName('iviparagraphs__threeparts-text');
                    if (text.length > 0) {
                        text[0].className += ' ' + styleSettings['textClass'];
                    }
                }
            }
        }
    }


    static _buildElementsForLargerScreens(element, settings) {
        let title = element.getElementsByClassName('iviparagraphs__threeparts-title')[0];
        let titleWrapper = element.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0];
        let titleClone = title.cloneNode(true);
        titleClone.style.opacity = 0;
        titleClone.style.position = 'relative';
        titleClone.style.display = 'inline-block';

        let cloneArray = titleClone.textContent.split(' ');
        let cloneLength = 0;
        let cloneLargestItem = '';
        for (let cloneItem of cloneArray) {
            if (cloneItem.length > cloneLength) {
                cloneLargestItem = cloneItem;
                cloneLength = cloneItem.length;
            }
        }
        titleClone.textContent = cloneLargestItem;
        titleWrapper.appendChild(titleClone);
        let titleWidth = titleClone.clientWidth;
        titleWrapper.removeChild(titleClone);
        if (titleWidth > element.clientWidth * 0.3) {
            IviThreeParts._buildDoubleElement(element, settings);
        }
        else {
            IviThreeParts._buildTripleElement(element, settings);
        }
    }

    static _buildDoubleElement(element, settings) {

        let titleWrapper = element.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0];
        let textWrapper = element.getElementsByClassName('iviparagraphs__threeparts-textwrapper')[0];
        let imgWrapper = element.getElementsByClassName('iviparagraphs__threeparts-imgwrapper')[0];
        let testWide = element.getElementsByClassName('iviparagraphs__threeparts-widewrapper');
        if (testWide.length == 0) {
            let wideWrap = document.createElement('div');
            wideWrap.classList.add('iviparagraphs__threeparts-widewrapper');
            element.appendChild(wideWrap);
            wideWrap.appendChild(titleWrapper);
            wideWrap.appendChild(textWrapper);

            wideWrap.style.width = 66.666 + '%';
        }
        else {
            element.getElementsByClassName('iviparagraphs__threeparts-widewrapper')[0].style.width = 66.6666 + '%';
        }
        IviThreeParts._setElementsHeightForDouble(element, settings);
    }

    static _setElementsHeightForDouble(element, settings) {
        let image = element.getElementsByClassName('iviparagraphs__threeparts-imgwrapper')[0];
        let wrapper = element.getElementsByClassName('iviparagraphs__threeparts-widewrapper')[0];
        let imageProcentage = image.clientWidth / element.clientWidth;
        let idealHeight;
        if (imageProcentage < 0.34) {
            idealHeight = image.clientWidth;
        }
        if (0.33 < imageProcentage < 0.42) {
            idealHeight = image.clientWidth * 0.75;
        }
        if (imageProcentage > 0.41) {
            idealHeight = image.clientWidth * 0.5;
        }
        let title = element.getElementsByClassName('iviparagraphs__threeparts-title')[0];
        let text = element.getElementsByClassName('iviparagraphs__threeparts-text')[0];

        title.style.position = 'relative';
        text.style.position = 'relative';
        title.style.top = 0;
        text.style.top = 0;
        title.parentNode.style.height = 'auto';
        text.parentNode.style.height = 'auto';
        title.style.height = 'auto';
        text.style.height = 'auto';
        let elementsHeight = wrapper.clientHeight;

        if (elementsHeight > idealHeight) {
            image.style.height = elementsHeight + 'px';
        }
        else {
            image.style.height = idealHeight + 'px';
            wrapper.style.paddingTop = (idealHeight - elementsHeight) / 2 + 'px';
            wrapper.style.paddingBottom = (idealHeight - elementsHeight) / 2 + 'px';
        }
    }

    static _buildTripleElement(element, settings) {
        let testWrapper = element.getElementsByClassName('iviparagraphs__threeparts-widewrapper');
        if (testWrapper.length > 0) {
            element.appendChild(element.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0]);
            element.appendChild(element.getElementsByClassName('iviparagraphs__threeparts-textwrapper')[0]);
            element.removeChild(testWrapper[0]);
            IviThreeParts.orderElements(element);
        }
        let styleNumber = IviParagraphs.getStyleNumber(element);
        let styleSettings = settings[styleNumber];
        if (styleSettings == undefined) {
            element.className += " iviparagraphs__threeparts-default";
            for (let child of element.children) {
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__threeparts');
                for (let childChild of child.children) {
                    IviParagraphs.setDefaultSettings(childChild, 'iviparagraphs__threeparts');
                }
            }
        }

        if (styleSettings !== undefined) {

            IviThreeParts._setMainCss(element, styleSettings);
            for (let key in styleSettings) {

                if (key == 'imgWidth') {
                    IviThreeParts._setImageWidth(element, styleSettings);
                }
                if (key == 'textWidth') {
                    IviThreeParts._setTextWidth(element, styleSettings);
                }
                if (key == 'titleWidth') {
                    IviThreeParts._setTitleWidth(element, styleSettings);
                }
            }
        }

        IviThreeParts._setElementsHeightForTriple(element, settings);
    }

    static _setElementsHeightForTriple(element, settings) {
        let image = element.getElementsByClassName('iviparagraphs__threeparts-imgwrapper')[0];
        let titleWrapper = element.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0];
        let textWrapper = element.getElementsByClassName('iviparagraphs__threeparts-textwrapper')[0];

        let title = element.getElementsByClassName('iviparagraphs__threeparts-title')[0];
        let text = element.getElementsByClassName('iviparagraphs__threeparts-text')[0];
        let titleHeight = title.clientHeight;
        let textHeight = text.clientHeight;
        title.style.position = 'absolute';
        text.style.position = 'absolute';
        title.style.paddingTop = 0;
        text.style.paddingTop = 0;
        title.style.paddingBottom = 0;
        text.style.paddingBottom = 0;

        textWrapper.style.height = textHeight + 'px';
        let imageProcentage = image.clientWidth / element.clientWidth;
        let idealHeight;
        if (imageProcentage < 0.34) {
            idealHeight = image.clientWidth * 1.15;
        }
        if (0.33 < imageProcentage < 0.42) {
            idealHeight = image.clientWidth;
        }
        if (imageProcentage > 0.41) {
            idealHeight = image.clientWidth * 0.5;
        }
        let heighestElement;
        let heighestHeight = 0;
        let elElements = [titleWrapper, textWrapper];

        for (let child of elElements) {
            if (child.clientHeight > heighestHeight) {
                heighestElement = child;
                heighestHeight = child.clientHeight;
            }
        }

        if (idealHeight > (heighestHeight + 40)) {
            image.style.height = idealHeight + 60 + 'px';
            for (let child of elElements) {
                child.style.height = idealHeight + 60 + 'px';
                child.style.height = idealHeight + 60 + 'px';
            }
        }
        else {
            image.style.height = heighestHeight + 'px';
            for (let child of elElements) {
                child.style.height = heighestHeight + 'px';
                child.style.height = heighestHeight + 'px';
            }

        }

        title.style.top = (image.clientHeight - titleHeight) / 2 + 'px';
        text.style.top = (image.clientHeight - textHeight) / 2 + 'px';
    }

    static _setHeightOfImageForMobile(element) {
        if (window.innerWidth < 768) {
            let testWrapper = element.getElementsByClassName('iviparagraphs__threeparts-widewrapper');
            if (testWrapper.length > 0) {
                element.appendChild(element.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0]);
                element.appendChild(element.getElementsByClassName('iviparagraphs__threeparts-textwrapper')[0]);
                element.removeChild(testWrapper[0]);
                IviThreeParts.orderElements(element);
            }
            element.getElementsByClassName('iviparagraphs__threeparts-img')[0].style.height = element.clientWidth + 'px';
        }
    }

    static orderElements(threePartsEls) {

        let elements = [];
        if (threePartsEls.firstChild.className.indexOf('wrapper') < 0) {
            for (let child of threePartsEls.children) {
                elements[IviThreeParts.getItemPosition(child) - 1] = child;
            }
            for (let element of elements) {
                element.parentNode.appendChild(element);
            }

            for (let element of elements) {
                let wrap = document.createElement('div');
                let classes = element.className;
                let classesParts = classes.split(' ');
                wrap.classList.add(classesParts[0] + 'wrapper');
                element.parentNode.appendChild(wrap);
                wrap.appendChild(element);
            }
        }
        else {
            for (let child of threePartsEls.children) {
                elements[IviThreeParts.getItemPosition(child.firstChild) - 1] = child;
            }
            for (let element of elements) {
                element.parentNode.appendChild(element);
            }
        }
    }

    static getItemPosition(element) {
        let classes = element.className;
        let classesParts = classes.split(' ');

        let styleNumber;
        for (let elClass of classesParts) {
            if (elClass.indexOf('position-') >= 0) {
                styleNumber = elClass;
            }
        }

        let classesEls = styleNumber.split('__');
        let style;
        for (let elClass of classesEls) {
            if (elClass.indexOf('position-') >= 0) {
                style = elClass;
            }
        }

        let classesArray = style.split('-');
        return classesArray[1];
    }

    static _setMainCss(element, styleSettings) {
        if (styleSettings.hasOwnProperty('main')) {
            IviParagraphs.defineCss(element, styleSettings.main);

        }
    }

    static _setImageWidth(element, styleSettings) {
        if (styleSettings.hasOwnProperty('imgWidth')) {
            let img = element.getElementsByClassName('iviparagraphs__threeparts-imgwrapper')[0];
            IviParagraphs.defineCss(img, styleSettings.imgWidth);
        }
    }

    static _setTextWidth(element, styleSettings) {
        if (styleSettings.hasOwnProperty('textWidth')) {
            let wrapper = element.getElementsByClassName('iviparagraphs__threeparts-textwrapper')[0];
            IviParagraphs.defineCss(wrapper, styleSettings.textWidth);
        }
    }

    static _setTitleWidth(element, styleSettings) {
        if (styleSettings.hasOwnProperty('titleWidth')) {
            let wrapper = element.getElementsByClassName('iviparagraphs__threeparts-titlewrapper')[0];
            IviParagraphs.defineCss(wrapper, styleSettings.titleWidth);
        }
    }

    static _setElementCss(element, fragment, styleSettings) {
        let elementPart = element.getElementsByClassName('iviparagraphs__threeparts-' + fragment);

        if (elementPart.length > 0) {
            IviParagraphs.defineCss(elementPart[0], styleSettings[fragment]);
        }
    }

}