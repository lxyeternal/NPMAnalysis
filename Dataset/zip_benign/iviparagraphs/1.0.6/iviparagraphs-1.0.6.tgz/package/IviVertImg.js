import IviParagraphs from './IviParagraphs';

export default class IviVertImg {

    static set(imgClass, settings) {

        var images = document.getElementsByClassName(imgClass);

        if (images.length > 0) {
            IviVertImg._run(images, settings);
        }
    }

    static _run(images, settings) {

        for (var image of images) {

            IviParagraphs.setCss(image, 'marginTop', settings.marginTop + 'px');
            IviParagraphs.setCss(image, 'marginBottom', settings.marginBottom + 'px');
            IviVertImg._setStyles(image, settings);
            let wrap = image.getElementsByClassName('iviparagraphs__vertimg-img')[0];
            let fid = IviParagraphs.getFid(wrap);
            if (fid !== false) {
                IviVertImg._getJSONforGalleryImageFromFid(fid, image, settings);
            }
        }

        if (document.getElementsByClassName('iviplaceholder').length > 0) {
            for (let item of document.getElementsByClassName('iviplaceholder')) {
                if (item.className.indexOf('iviplaceholder-none') < 1) {
                    IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                }
            }
        }
    }

    static _getJSONforGalleryImageFromFid(fid, image, settings) {

        let langPrefix = document.documentElement.lang == 'ru' ? '' : '/' + document.documentElement.lang;
        var topDist;
        topDist = window.pageXOffset;
        let loadBefore = 400 + window.innerHeight;

        if (topDist > (image.getBoundingClientRect().top - loadBefore)) {
            if (image.className.indexOf('iviparagraphs__vertimg-loaded') < 0) {
                IviParagraphs.addClassToElement(image, 'iviparagraphs__vertimg-loaded');
                fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                    .then(function (response) {
                        return response.json();
                    }).then(function (json) {
                    IviVertImg._buildImgArea(json, image, settings);

                }).catch(function (ex) {
                    console.log('parsing failed', ex);
                })
            }

        }

        window.addEventListener("scroll", function (event) {
            topDist = this.scrollY;
            if (topDist > (image.getBoundingClientRect().top - loadBefore) || topDist === undefined) {
                if (image.className.indexOf('iviparagraphs__vertimg-loaded') < 0) {
                    IviParagraphs.addClassToElement(image, 'iviparagraphs__vertimg-loaded');
                    fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                        .then(function (response) {
                            return response.json();
                        }).then(function (json) {
                        IviVertImg._buildImgArea(json, image, settings);

                    }).catch(function (ex) {
                        console.log('parsing failed', ex);
                    })
                }

            }
        }, false);
    }

    static _buildImgArea(json, image, settings) {

        let img = new Image();
        img.src = json[0];

        img.onload = function () {
            let wrap = image.getElementsByClassName('iviparagraphs__vertimg-img')[0];
            let imgEl = document.createElement('img');
            imgEl.src = json[0];
            wrap.appendChild(imgEl);
        };
    }

    static _setStyles(image, settings) {
        for (let key in settings) {
            if (key == 'img') {
                IviParagraphs.defineCss(image.getElementsByClassName('iviparagraphs__vertimg-img')[0], settings.img);
            }
            if (key == 'title') {
                let title = image.getElementsByClassName('iviparagraphs__vertimg-title');
                if (title.length > 0) {
                    IviParagraphs.defineCss(image.getElementsByClassName('iviparagraphs__vertimg-title')[0], settings.title);
                }
            }
            if (key == 'titleClass') {
                let title = image.getElementsByClassName('iviparagraphs__vertimg-title');
                if (title.length > 0) {
                    title[0].className += ' ' + settings['titleClass'];
                }
            }
        }
    }

}