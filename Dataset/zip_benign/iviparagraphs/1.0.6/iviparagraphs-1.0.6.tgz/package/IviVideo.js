import IviParagraphs from './IviParagraphs';

export default class Ivivideo {

    static set(videoClass, settings) {

        var videos = document.getElementsByClassName(videoClass);

        if (videos.length > 0) {
            Ivivideo._run(videos, settings);
        }
    }

    static _run(videos, settings) {
        for (var video of videos) {

            IviParagraphs.setCss(video, 'marginTop', settings.marginTop + 'px');
            IviParagraphs.setCss(video, 'marginBottom', settings.marginBottom + 'px');
            Ivivideo._setStyles(video, settings);

        }
    }

    static _setStyles(video, settings) {

        let styleNumber = IviParagraphs.getStyleNumber(video);
        let styleSettings = settings[styleNumber];
        IviParagraphs.defineCss(video, styleSettings);

        if (styleNumber === 'style1') {
            let fid = IviParagraphs.getFid(video);
            let bgClone = document.createElement('div');
         //   bgClone.classList.add('')
            IviParagraphs.addClassToElement(bgClone, 'iviparagraphs__video-clone');
            video.appendChild(bgClone);
            if(fid) {
                IviParagraphs.getJSONforSingleImageFromFid(fid, bgClone);
            }
        }

    }
}