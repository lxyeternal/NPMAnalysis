import IviParagraphs from './IviParagraphs';

export default class IviTextAndBooking {
    static set(twoTextsClass, settings) {
        var twoTexts = document.getElementsByClassName(twoTextsClass);
        if (twoTexts.length > 0) {
            IviTextAndBooking._run(twoTexts, settings);
        }
    }

    static _run(twoTexts, settings) {
        for (var element of twoTexts) {
            let narrowEl = element.getElementsByClassName('iviparagraphs__textandbooking-narrowwrap');
            let wideEl = element.getElementsByClassName('iviparagraphs__textandbooking-widewrap');

            if (narrowEl.length > 0 && wideEl.length > 0) {

                let narrowElement = narrowEl[0];
                let wideElement = wideEl[0];
                let position = IviParagraphs.leftOrRight(element);

                if (settings.defaultStyle == true) {
                    narrowElement.className += " iviparagraphs__textandbooking-narrowwrap-default";
                    wideElement.className += " iviparagraphs__textandbooking-widewrap-default";
                    for (let child of narrowElement.children) {
                        IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandbooking');
                    }
                    for (let child of wideElement.children) {
                        IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandbooking');
                    }
                    IviTextAndBooking._buildElement(narrowElement, wideElement, settings, position);
                }
                let styleNumberNarrow = IviParagraphs.getStyleNumber(narrowElement);

                let styleNumberWide = IviParagraphs.getStyleNumber(wideElement);

                if (settings.defaultStyle == false) {

                    IviTextAndBooking._buildElement(narrowElement, wideElement, settings, position);
                    if (settings.span == true) {

                      //  IviParagraphs.addSpan(narrowElement, styleNumberNarrow, settings, 'iviparagraphs__textandbooking', 'iviparagraphs__textandbooking-title', 'iviparagraphs__textandbooking-subtitle', 'iviparagraphs__textandbooking-text', 'iviparagraphs__textandbooking-link', 'iviparagraphs__textandbooking-textwrapper');
                        IviParagraphs.addSpan(wideElement, styleNumberWide, settings, 'iviparagraphs__textandbooking', 'iviparagraphs__textandbooking-title', 'iviparagraphs__textandbooking-subtitle', 'iviparagraphs__textandbooking-text', 'iviparagraphs__textandbooking-link', 'iviparagraphs__textandbooking-widetextwrapper');

                    }

                    IviTextAndBooking._setStyles(narrowElement, wideElement, settings);
                }
            }


        }
    }

    static _buildElement(narrowElement, wideElement, settings, position) {
        IviParagraphs.setCss(narrowElement.parentNode, 'marginTop', settings.marginTop + 'px');
        IviParagraphs.setCss(narrowElement.parentNode, 'marginBottom', settings.marginBottom + 'px');

        if (position === 'right') {
            narrowElement.parentNode.appendChild(narrowElement);
        }

        if (settings.defaultStyle == true) {
            IviTextAndBooking._applyDefaultPaddings(narrowElement, wideElement, settings)
        }
    }

    static _applyDefaultPaddings(narrowElement, wideElement, settings) {

        let wrapper1;
        let wrapper2;

        if (narrowElement.getElementsByClassName('iviparagraphs__textandbooking-textwrapper').length > 0) {
            wrapper1 = narrowElement.getElementsByClassName('iviparagraphs__textandbooking-textwrapper')[0];
        }
        else {
            wrapper1 = narrowElement;
        }

        if (wideElement.getElementsByClassName('iviparagraphs__textandbooking-widetextwrapper').length > 0) {
            wrapper2 = wideElement.getElementsByClassName('iviparagraphs__textandbooking-widetextwrapper')[0];
        }
        else {
            wrapper2 = wideElement;
        }

        if (window.innerWidth < 768) {

            for (let child of wrapper1.children) {
                if (child == wrapper1.firstChild) {
                    child.style.paddingTop = settings.zeroElementsPadding + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                }
                else if (child == wrapper1.lastChild) {
                    child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                }
                else {
                    child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                }
            }

            for (let child of wrapper2.children) {
                if (child == wrapper2.firstChild) {
                    child.style.paddingTop = settings.zeroElementsPadding + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                }
                else if (child == wrapper2.lastChild) {
                    child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                }
                else {
                    child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                    child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                }
            }

        }
        else {
            IviTextAndBooking._applyImageStylesForLargerScreens(narrowElement, wideElement, settings);
        }

        window.addEventListener('resize', function () {
            if (window.innerWidth < 768) {
                wrapper1.style.height = 'auto';
                wrapper2.style.height = 'auto';
                for (let child of wrapper1.children) {
                    if (child == wrapper1.firstChild) {
                        child.style.paddingTop = settings.zeroElementsPadding + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                    else if (child == wrapper1.lastChild) {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                    }
                    else {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                }

                for (let child of wrapper2.children) {
                    if (child == wrapper2.firstChild) {
                        child.style.paddingTop = settings.zeroElementsPadding + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                    else if (child == wrapper2.lastChild) {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                    }
                    else {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                }

            }
            else {
                setTimeout(function () {
                        IviTextAndBooking._applyImageStylesForLargerScreens(narrowElement, wideElement, settings);
                }, 750);
              //  IviTextAndBooking._applyImageStylesForLargerScreens(narrowElement, wideElement, settings);
            }
        });



        function onElementHeightChange(elm, callback) {

            var lastHeight = elm.clientHeight, newHeight;
            (function run() {
                newHeight = elm.clientHeight;
                if (lastHeight != newHeight)
                    callback();
                lastHeight = newHeight;

                if (elm.onElementHeightChangeTimer)
                    clearTimeout(elm.onElementHeightChangeTimer);

                elm.onElementHeightChangeTimer = setTimeout(run, 400);
            })();
        }


        onElementHeightChange(document.body, function () {
            if (window.innerWidth < 768) {
                wrapper1.style.height = 'auto';
                wrapper2.style.height = 'auto';
                for (let child of wrapper1.children) {
                    if (child == wrapper1.firstChild) {
                        child.style.paddingTop = settings.zeroElementsPadding + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                    else if (child == wrapper1.lastChild) {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                    }
                    else {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                }

                for (let child of wrapper2.children) {
                    if (child == wrapper2.firstChild) {
                        child.style.paddingTop = settings.zeroElementsPadding + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                    else if (child == wrapper2.lastChild) {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding + 'px';
                    }
                    else {
                        child.style.paddingTop = settings.zeroElementsPadding / 2 + 'px';
                        child.style.paddingBottom = settings.zeroElementsPadding / 2 + 'px';
                    }
                }

            }
            else {
                setTimeout(function () {
                    IviTextAndBooking._applyImageStylesForLargerScreens(narrowElement, wideElement, settings);
                }, 750);
                //  IviTextAndBooking._applyImageStylesForLargerScreens(narrowElement, wideElement, settings);
            }
        });

        setTimeout(function () {
            if (window.innerWidth > 768) {
                IviTextAndBooking._applyImageStylesForLargerScreens(narrowElement, wideElement, settings);
            }
        }, 750);

    }

    static _applyImageStylesForLargerScreens(narrowElement, wideElement, settings) {

        let wrapper1;
        let wrapper2;
        let wrapperMarginTop = 0;
        let wrapperMarginBottom = 0;
        let wrapperMarginTop2 = 0;
        let wrapperMarginBottom2 = 0;

        if (narrowElement.getElementsByClassName('iviparagraphs__textandbooking-textwrapper').length > 0) {
            wrapper1 = narrowElement.getElementsByClassName('iviparagraphs__textandbooking-textwrapper')[0];
            let styleSettings = settings[IviParagraphs.getStyleNumber(narrowElement)];

            if (styleSettings.hasOwnProperty('textwrapper')) {
                if (styleSettings.textwrapper.hasOwnProperty('marginTop')) {
                    wrapperMarginTop += Math.floor(styleSettings.textwrapper.marginTop.substring(0, styleSettings.textwrapper.marginTop.length - 2));
                }
                if (styleSettings.textwrapper.hasOwnProperty('marginBottom')) {
                    wrapperMarginBottom += Math.floor(styleSettings.textwrapper.marginBottom.substring(0, styleSettings.textwrapper.marginBottom.length - 2));
                }
            }
        }
        else {
            wrapper1 = narrowElement;
        }

        if (wideElement.getElementsByClassName('iviparagraphs__textandbooking-widetextwrapper').length > 0) {
            wrapper2 = wideElement.getElementsByClassName('iviparagraphs__textandbooking-widetextwrapper')[0];
            let styleSettings = settings[IviParagraphs.getStyleNumber(wideElement)];

            if (styleSettings.hasOwnProperty('widetextwrapper')) {
                if (styleSettings.widetextwrapper.hasOwnProperty('marginTop')) {
                    wrapperMarginTop2 += Math.floor(styleSettings.widetextwrapper.marginTop.substring(0, styleSettings.widetextwrapper.marginTop.length - 2));
                }
                if (styleSettings.textwrapper.hasOwnProperty('marginBottom')) {
                    wrapperMarginBottom2 += Math.floor(styleSettings.widetextwrapper.marginBottom.substring(0, styleSettings.widetextwrapper.marginBottom.length - 2));
                }
            }
        }
        else {
            wrapper2 = wideElement;
        }

        let elementsHeight = 0;
        let elementsHeight2 = 0;
        var cs, paddingY, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight;
        for (let child of wrapper1.children) {
            cs = getComputedStyle(child);
            paddingY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
            elementsHeight += child.clientHeight - paddingY;
        }

        //console.log(elementsHeight, wrapper1);

        for (let child of wrapper2.children) {
            cs = getComputedStyle(child);
            paddingY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
            elementsHeight2 += child.clientHeight - paddingY;
        }
      //  console.log(elementsHeight2, wrapper2);
        if (elementsHeight > elementsHeight2) {
            higherElement = wrapper1;
            lowerElement = wrapper2;
            higherMarginTop = wrapperMarginTop;
            higherMarginBottom = wrapperMarginBottom;
            lowerMarginTop = wrapperMarginTop2;
            lowerMarginBottom = wrapperMarginBottom2;
            higherHeight = elementsHeight + settings.largeElementsPadding * (higherElement.childElementCount + 1) + higherMarginTop + higherMarginBottom;
            lowerElementsHeight = elementsHeight2;
            higherElementsHeight = elementsHeight;
        }
        else {
            higherElement = wrapper2;
            lowerElement = wrapper1;
            higherMarginTop = wrapperMarginTop2;
            higherMarginBottom = wrapperMarginBottom2;
            lowerMarginTop = wrapperMarginTop;
            lowerMarginBottom = wrapperMarginBottom;
            higherHeight = elementsHeight2 + settings.largeElementsPadding * (higherElement.childElementCount + 1) + higherMarginTop + higherMarginBottom;
            lowerElementsHeight = elementsHeight;
            higherElementsHeight = elementsHeight2;
        }

      /*  if (wrapper1.getElementsByClassName('iviparagraphs__textandbooking-title').length > 0 && wrapper2.getElementsByClassName('iviparagraphs__textandbooking-title').length > 0 && wrapper1.getElementsByClassName('iviparagraphs__textandbooking-link').length > 0 && wrapper2.getElementsByClassName('iviparagraphs__textandbooking-link').length > 0) {
            IviTextAndBooking._largeScreenSizesForTitlesAndLinks(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight);
        }
        else if (wrapper1.getElementsByClassName('iviparagraphs__textandbooking-link').length > 0 && wrapper2.getElementsByClassName('iviparagraphs__textandbooking-link').length > 0) {
            IviTextAndBooking._largeScreenSizesForLinks(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight);
        }*/

         if (wrapper1.getElementsByClassName('iviparagraphs__textandbooking-title').length > 0 && wrapper2.getElementsByClassName('iviparagraphs__textandbooking-title').length > 0 && (wrapper2.getElementsByClassName('iviparagraphs__textandbooking-link').length < 1 || wrapper1.getElementsByClassName('iviparagraphs__textandbooking-link').length < 1)) {
            IviTextAndBooking._largeScreenSizesForTitles(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight);

        }
        else {
            IviTextAndBooking._largeScreenSizesCommon(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight);

         }

    }

    static _largeScreenSizesCommon(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight) {

        for (let child of higherElement.children) {

            if (child == higherElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == higherElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }

        }

        for (let child of lowerElement.children) {
            child.style.marginTop = 0 + 'px';
            child.style.marginBottom = 0 + 'px';
            if (child == lowerElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == lowerElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }

        }

        let restHeight = 0;
        if (lowerElement.childElementCount > 1) {
            for (let child of lowerElement.children) {
                restHeight += child.clientHeight;
            }

            let restWholeHeight = higherHeight - lowerMarginTop - lowerMarginBottom;
            let marginCorrect = (restWholeHeight - restHeight) / (lowerElement.childElementCount);

            for (let child of lowerElement.children) {
                if (child !== lowerElement.firstChild && child !== lowerElement.lastChild) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.firstChild) {
                    child.style.marginTop = marginCorrect + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.lastChild) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect + 'px';
                }
            }
        }

        lowerElement.style.height = higherHeight - lowerMarginBottom - lowerMarginTop + 'px';
    }

    static _largeScreenSizesForTitles(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight) {

        for (let child of higherElement.children) {

            if (child == higherElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == higherElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }

        }

        for (let child of lowerElement.children) {
            if (child == lowerElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == lowerElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
           // child.style.marginTop = 0;
           // child.style.marginBottom = 0;
        }

        let higherTitle = higherElement.getElementsByClassName('iviparagraphs__textandbooking-title')[0];
        let lowerTitle = lowerElement.getElementsByClassName('iviparagraphs__textandbooking-title')[0];

      /*  if (higherMarginTop > lowerMarginTop) {
            lowerTitle.style.marginTop = higherMarginTop + 'px';
        }
        else {

        }*/

        let correctHeight = 0;

        if (higherMarginTop > lowerMarginTop) {
            lowerTitle.style.marginTop = higherMarginTop + 'px';
            // correctHeight = - higherMarginTop;
        }
        if (higherMarginTop < lowerMarginTop) {
            higherTitle.style.marginTop = lowerMarginTop + 'px';
            correctHeight = lowerMarginTop;
        }

        var cs = getComputedStyle(lowerTitle);
        var m = parseFloat(cs.marginTop);

        let restHeight = 0;
        if (lowerElement.childElementCount > 1) {
            for (let child of lowerElement.children) {
                if (child !== lowerElement.firstChild) {
                    restHeight += child.clientHeight;
                }
            }
            let restWholeHeight = higherHeight - lowerMarginTop - lowerMarginBottom - lowerTitle.clientHeight - m;
            let marginCorrect = (restWholeHeight - restHeight) / (lowerElement.childElementCount - 1);

            for (let child of lowerElement.children) {
                if (child !== lowerElement.firstChild && child !== lowerElement.children[1]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.children[1]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                   // child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.lastChild) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                  //s  child.style.marginBottom = marginCorrect + 'px';
                }
            }
        }

       // lowerElement.style.height = higherHeight - lowerMarginBottom - lowerMarginTop + 'px';

        lowerElement.style.height = higherHeight - lowerMarginBottom - lowerMarginTop + correctHeight + 'px';
    }

    static _largeScreenSizesForLinks(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight) {

        for (let child of higherElement.children) {

            if (child == higherElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == higherElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }

        }

        for (let child of lowerElement.children) {
            if (child == lowerElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == lowerElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
        }

        let lowerLink = lowerElement.getElementsByClassName('iviparagraphs__textandbooking-link')[0];
        let higherLink = higherElement.getElementsByClassName('iviparagraphs__textandbooking-link')[0];
        let correctLink = 0;
        if (higherLink.offsetTop - lowerLink.parentNode.clientHeight < 10) {
            correctLink = higherLink.offsetTop - lowerLink.parentNode.clientHeight - 10;
        }

        lowerLink.style.position = 'absolute';
        lowerLink.style.top = higherLink.offsetTop + correctLink + 'px';
        lowerLink.style.width = 100 + '%';
        lowerLink.style.left = 0;

        let restHeight = 0;
        if (lowerElement.childElementCount > 1) {
            for (let child of lowerElement.children) {
                if (child !== lowerElement.lastChild) {
                    restHeight += child.clientHeight;
                }
            }

            let restWholeHeight = higherLink.offsetTop - lowerMarginTop - lowerMarginBottom + correctLink;
            let marginCorrect = (restWholeHeight - restHeight) / (lowerElement.childElementCount - 1);

            for (let child of lowerElement.children) {
                if (child !== lowerElement.lastChild && child !== lowerElement.children[lowerElement.childElementCount - 2]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.firstChild) {
                    child.style.marginTop = marginCorrect + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.children[lowerElement.childElementCount - 2]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect + 'px';
                }
            }
        }

        lowerElement.style.height = higherHeight - lowerMarginBottom - lowerMarginTop + 'px';
    }

    static _largeScreenSizesForTitlesAndLinks(settings, higherElement, lowerElement, higherMarginTop, higherMarginBottom, lowerMarginTop, lowerMarginBottom, higherHeight, lowerElementsHeight, higherElementsHeight) {

        for (let child of higherElement.children) {

            if (child == higherElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == higherElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }

        }

        for (let child of lowerElement.children) {
            if (child == lowerElement.firstChild) {
                child.style.paddingTop = settings.largeElementsPadding + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
            else if (child == lowerElement.lastChild) {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding + 'px';
            }
            else {
                child.style.paddingTop = settings.largeElementsPadding / 2 + 'px';
                child.style.paddingBottom = settings.largeElementsPadding / 2 + 'px';
            }
        }

        let higherTitle = higherElement.getElementsByClassName('iviparagraphs__textandbooking-title')[0];
        let lowerTitle = lowerElement.getElementsByClassName('iviparagraphs__textandbooking-title')[0];

        if (higherMarginTop > lowerMarginTop) {
            lowerTitle.style.marginTop = higherMarginTop + 'px';
        }
        else {

        }

        var cs = getComputedStyle(lowerTitle);
        var m = parseFloat(cs.marginTop);
        let lowerLink = lowerElement.getElementsByClassName('iviparagraphs__textandbooking-link')[0];
        let higherLink = higherElement.getElementsByClassName('iviparagraphs__textandbooking-link')[0];
        //    lowerLink.style.marginTop = (higherElementsHeight - lowerElementsHeight) + m + 'px';

        let correctLink = 0;
        if (higherLink.offsetTop - lowerLink.parentNode.clientHeight < 10) {
            correctLink = higherLink.offsetTop - lowerLink.parentNode.clientHeight - 10;
        }

        lowerLink.style.position = 'absolute';
        lowerLink.style.top = higherLink.offsetTop + correctLink + 'px';
        lowerLink.style.width = 100 + '%';
        lowerLink.style.left = 0;

        let restHeight = 0;
        if (lowerElement.childElementCount > 2) {
            for (let child of lowerElement.children) {
                if (child !== lowerElement.firstChild && child !== lowerElement.lastChild) {
                    restHeight += child.clientHeight;
                }
            }

            let restWholeHeight = higherHeight - /*higherMarginTop - higherMarginBottom - */lowerMarginTop - lowerMarginBottom - lowerTitle.clientHeight - m - lowerLink.clientHeight + correctLink;
            let marginCorrect = (restWholeHeight - restHeight) / (lowerElement.childElementCount - 2);

            for (let child of lowerElement.children) {
               /* if (child !== lowerElement.firstChild && child !== lowerElement.lastChild && child !== lowerElement.children[1] && child !== lowerElement.children[lowerElement.childElementCount - 2]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.children[1]) {
                    child.style.marginTop = marginCorrect + 'px';
                    child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.children[lowerElement.childElementCount - 2]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    child.style.marginBottom = marginCorrect + 'px';
                }*/
                if (child !== lowerElement.firstChild && child !== lowerElement.lastChild && child !== lowerElement.children[1] && child !== lowerElement.children[lowerElement.childElementCount - 2]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    //  child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.children[1]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    // child.style.marginBottom = marginCorrect / 2 + 'px';
                }
                if (child === lowerElement.children[lowerElement.childElementCount - 2]) {
                    child.style.marginTop = marginCorrect / 2 + 'px';
                    //child.style.marginBottom = marginCorrect + 'px';
                }
            }
        }

        lowerElement.style.height = higherHeight - lowerMarginBottom - lowerMarginTop + 'px';
    }


    static _setStyles(narrowElement, wideElement, settings) {

        let styleNumber = IviParagraphs.getStyleNumber(narrowElement);
        let styleNumber2 = IviParagraphs.getStyleNumber(wideElement);
        let styleSettings = settings[styleNumber];
        let styleSettings2 = settings[styleNumber2];
        if (styleSettings == undefined) {
            narrowElement.className += " iviparagraphs__textandbooking-narrowwrap-default";
            for (let child of narrowElement.children) {
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandbooking');
            }
        }

        if (styleSettings2 == undefined) {
            wideElement.className += " iviparagraphs__textandbooking-widewrap-default";
            for (let child of wideElement.children) {
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__textandbooking');
            }
        }

        IviTextAndBooking._setNarrowWidth(narrowElement, settings);
        IviTextAndBooking._setWideWidth(wideElement, settings);

        if (styleSettings !== undefined) {

            IviTextAndBooking._setMainCss(narrowElement, styleSettings);

            for (let key in styleSettings) {

                if (key == 'title' || key == 'subtitle' || key == 'text' || key == 'link' || key == 'textwrapper') {
                    IviTextAndBooking._setElementCss(narrowElement, key, styleSettings);

                }
                if (key == 'linkClass') {
                    let link = narrowElement.getElementsByClassName('iviparagraphs__textandbooking-link');
                    if (link.length > 0) {
                        link[0].className += ' ' + styleSettings['linkClass'];
                    }
                }
                if (key == 'titleClass') {
                    let title = narrowElement.getElementsByClassName('iviparagraphs__textandbooking-title');
                    if (title.length > 0) {
                        title[0].className += ' ' + styleSettings['titleClass'];
                        let titleClone = title[0].cloneNode(true);
                        titleClone.style.opacity = 0;
                        titleClone.style.position = 'relative';
                        titleClone.style.display = 'inline-block';

                        let cloneArray = titleClone.textContent.split(' ');
                        let cloneLength = 0;
                        let cloneLargestItem = '';
                        for (let cloneItem of cloneArray) {
                            if (cloneItem.length > cloneLength) {
                                cloneLargestItem = cloneItem;
                                cloneLength = cloneItem.length;
                            }
                        }
                        titleClone.textContent = cloneLargestItem;
                        narrowElement.appendChild(titleClone);
                        let titleWidth = titleClone.clientWidth;
                        narrowElement.removeChild(titleClone);
                        if (titleWidth > narrowElement.clientWidth) {
                            IviParagraphs.addClassToElement(title[0], 'h4');
                        }
                        else {
                            title[0].className = title[0].className.replace('h4', ' ');
                        }
                    }
                }
                if (key == 'subtitleClass') {
                    let subtitle = narrowElement.getElementsByClassName('iviparagraphs__textandbooking-subtitle');
                    if (subtitle.length > 0) {
                        subtitle[0].className += ' ' + styleSettings['subtitleClass'];
                    }
                }
                if (key == 'textClass') {
                    let text = narrowElement.getElementsByClassName('iviparagraphs__textandbooking-text');
                    if (text.length > 0) {
                        text[0].className += ' ' + styleSettings['textClass'];
                    }
                }
            }
        }

        if (styleSettings2 !== undefined) {

            IviTextAndBooking._setMainCss(wideElement, styleSettings2);

            for (let key in styleSettings2) {
                if (key == 'title' || key == 'subtitle' || key == 'text' || key == 'link' || key == 'widetextwrapper') {
                    IviTextAndBooking._setElementCss(wideElement, key, styleSettings2);
                }
                if (key == 'linkClass') {
                    let link = wideElement.getElementsByClassName('iviparagraphs__textandbooking-link');
                    if (link.length > 0) {
                        link[0].className += ' ' + styleSettings2['linkClass'];
                    }
                }
                if (key == 'titleClass') {
                    let title = wideElement.getElementsByClassName('iviparagraphs__textandbooking-title');
                    if (title.length > 0) {
                        title[0].className += ' ' + styleSettings2['titleClass'];

                    }
                }
                if (key == 'subtitleClass') {
                    let subtitle = wideElement.getElementsByClassName('iviparagraphs__textandbooking-subtitle');
                    if (subtitle.length > 0) {
                        subtitle[0].className += ' ' + styleSettings2['subtitleClass'];
                    }
                }
                if (key == 'textClass') {
                    let text = wideElement.getElementsByClassName('iviparagraphs__textandbooking-text');
                    if (text.length > 0) {
                        text[0].className += ' ' + styleSettings2['textClass'];
                    }
                }
            }
        }


        setTimeout(function () {
            if (window.innerWidth > 768) {
                IviTextAndBooking._applyDefaultPaddings(narrowElement, wideElement, settings);
            }
        }, 750);


        let fid = IviParagraphs.getFid(narrowElement);
        if (fid !== false) {
            IviParagraphs.getJSONforSingleImageFromFid(fid, narrowElement);
        }
        let fid2 = IviParagraphs.getFid(wideElement);
        if (fid2 !== false) {
            IviParagraphs.getJSONforSingleImageFromFid(fid2, wideElement);
        }
    }


    static _setMainCss(element, styleSettings) {
        if (styleSettings.hasOwnProperty('main')) {
            IviParagraphs.defineCss(element, styleSettings.main);

        }
    }

    static _setNarrowWidth(element, settings) {
        if (settings.hasOwnProperty('narrowWidth')) {
            IviParagraphs.defineCss(element, settings.narrowWidth);

        }
    }

    static _setWideWidth(element, settings) {
        if (settings.hasOwnProperty('wideWidth')) {
            IviParagraphs.defineCss(element, settings.wideWidth);

        }
    }

    static _setElementCss(element, fragment, styleSettings) {

        let elementPart = element.getElementsByClassName('iviparagraphs__textandbooking-' + fragment);

        if (elementPart.length > 0) {
            IviParagraphs.defineCss(elementPart[0], styleSettings[fragment]);

        }
    }


}