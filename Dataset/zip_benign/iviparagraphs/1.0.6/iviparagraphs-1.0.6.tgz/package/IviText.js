import IviParagraphs from './IviParagraphs';

export default class IviText {

    static set(textClass, settings) {
        var texts = document.getElementsByClassName(textClass);

        if (texts.length > 0) {
            IviText._run(texts, settings);
        }
    }

    static _run(texts, settings) {

        for (var element of texts) {

            if (settings.defaultStyle == true) {
                element.className += " iviparagraphs__text-default";
                for (let child of element.children) {
                    //IviText._setDefaultSettings(child);
                    IviParagraphs.setDefaultSettings(child, 'iviparagraphs__text');
                }
            }

            if (settings.defaultStyle == false) {

                element.style.marginBottom = settings.marginBottom + 'px';
                element.style.marginTop = settings.marginTop + 'px';
                IviText._setStyle(element, settings);
            }
        }
    }

    static _setStyle(element, settings) {

        let styleNumber = IviParagraphs.getStyleNumber(element);
        let styleSettings = settings[styleNumber];
        if (styleSettings == undefined) {
            element.className += " iviparagraphs__text-default";
            for (let child of element.children) {
              //  IviText._setDefaultSettings(child);
                IviParagraphs.setDefaultSettings(child, 'iviparagraphs__text');
            }
        }
        if (settings.span == true) {
           // IviText._addSpan(element, styleNumber, settings);
            IviParagraphs.addSpan(element, styleNumber, settings, 'iviparagraphs__text', 'iviparagraphs__text-title', 'iviparagraphs__text-subtitle', 'iviparagraphs__text-words', 'iviparagraphs__text-link', 'iviparagraphs__text-wrapper');
        }
        if (styleSettings !== undefined) {

            IviText._setMainCss(element, styleSettings);

            for (let key in styleSettings) {

                if (key == 'title' || key == 'subtitle' || key == 'words' || key == 'link' || key == 'wrapper') {
                    IviText._setElementCss(element, key, styleSettings);
                }
                if (key == 'linkClass') {
                    let link = element.getElementsByClassName('iviparagraphs__text-link');
                    if (link.length > 0) {
                        link[0].className += ' ' + styleSettings['linkClass'];
                    }
                }
                if (key == 'titleClass') {
                    let title = element.getElementsByClassName('iviparagraphs__text-title');
                    if (title.length > 0) {
                        title[0].className += ' ' + styleSettings['titleClass'];
                    }
                }
                if (key == 'subtitleClass') {
                    let subtitle = element.getElementsByClassName('iviparagraphs__text-subtitle');
                    if (subtitle.length > 0) {
                        subtitle[0].className += ' ' + styleSettings['subtitleClass'];
                    }
                }
                if (key == 'textClass') {
                    let text = element.getElementsByClassName('iviparagraphs__text-words');
                    if (text.length > 0) {
                        text[0].className += ' ' + styleSettings['textClass'];
                    }
                }
            }

        }

        let textWithImageClass;
        let classes = element.className;
        let classesArrayImg = classes.split('-');
        for (let elClass of classesArrayImg) {
            if (elClass.indexOf('img') >= 0) {
                textWithImageClass = elClass;
            }
        }
        if (textWithImageClass !== undefined) {
            let textWithImageClassParts = textWithImageClass.split('__');
            if (!isNaN(Math.floor(textWithImageClassParts[1]))) {
                IviParagraphs.getJSONforSingleImageFromFid(textWithImageClassParts[1], element);
            }

        }

    }

    static _setMainCss(element, styleSettings) {
        if (styleSettings.hasOwnProperty('main')) {
            IviParagraphs.defineCss(element, styleSettings.main);

        }
        else {

        }
    }

    static _setElementCss(element, fragment, styleSettings) {
        let elementPart = element.getElementsByClassName('iviparagraphs__text-' + fragment);

        if (elementPart.length > 0) {
            IviParagraphs.defineCss(elementPart[0], styleSettings[fragment]);

        }

        if (document.getElementsByClassName('iviplaceholder').length > 0) {
            for (let item of document.getElementsByClassName('iviplaceholder')) {
                if (item.className.indexOf('iviplaceholder-none') < 1) {
                    IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                }
            }
        }

    }

}