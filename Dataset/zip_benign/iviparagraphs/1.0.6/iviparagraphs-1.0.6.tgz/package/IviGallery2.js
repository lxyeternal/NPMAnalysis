import IviParagraphs from './IviParagraphs';

export default class IviGallery {

    static set(galleryClass, settings) {
        var galleries = document.getElementsByClassName(galleryClass);

        if (galleries.length > 0) {
            IviGallery._run(galleries, settings);
        }
    }

    static _run(galleries, settings) {
        for (var gallery of galleries) {

            if (gallery.children.length > 2) {
                IviParagraphs.setCss(gallery, 'marginTop', settings.marginTop + 'px');
                IviParagraphs.setCss(gallery, 'marginBottom', settings.marginBottom + 'px');

                let styleNumber = IviParagraphs.getStyleNumber(gallery);

                if (styleNumber == 'style1') {
                    IviGallery._startFirstGallery(gallery, settings[styleNumber]);
                }

                if (styleNumber == 'style2') {

                }

                if (styleNumber == 'style3') {

                }

                if (styleNumber == 'style4') {

                }
            }


        }
    }

    static _startFirstGallery(gallery, settings) {

        let screenHeight = IviParagraphs.applySize(settings.height.responsive);
        IviGallery.buildArea(gallery);
        IviGallery._buildFirstGallery(gallery, settings, settings.height.responsive[screenHeight]);
        window.addEventListener('resize', function () {
            screenHeight = IviParagraphs.applySize(settings.height.responsive);
            IviGallery._buildFirstGallery(gallery, settings, settings.height.responsive[screenHeight]);

        });
    }

    static _buildFirstGallery(gallery, settings, height) {
        let length = gallery.children.length;
        let wrapper = gallery.getElementsByClassName('iviparagraphs__gallery-wrapper')[0];
        wrapper.style.height = height + 'px';
        /*let ind = 0;
         for (let image of gallery.children) {
         console.log(image);
         ind++;
         IviParagraphs.addClassToElement(image, 'iviparagraphs__gallery-num-' + ind);
         }*/

        IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(gallery.children[length - 2]), gallery.children[length - 2], height, settings, length - 2);
        //  IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(gallery.firstChild), gallery.firstChild, height, settings, 0);
        //  IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(gallery.children[1]), gallery.children[1], height, settings, 1);

    }

    static addFirstSlide(image, height, settings, num) {
        let wrapper = image.parentNode.getElementsByClassName('iviparagraphs__gallery-wrapper')[0];
        if (wrapper.childElementCount == 1) {
            IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(wrapper.parentNode.firstChild), wrapper.parentNode.children[length - 2], height, settings, 0);
        }
        if (wrapper.childElementCount == 2) {
            IviGallery.getJSONforGalleryImageFromFid(IviParagraphs.getFid(wrapper.parentNode.children[1]), wrapper.parentNode.children[1], height, settings, 1);
        }
    }

    static chooseSlideToAdd(wrapper, num, settings, where) {
        let element = wrapper.parentNode.children[num];
        let fid = IviParagraphs.getFid(element);
        IviGallery.getJSONforAddSlideFromFid(fid, element, settings, num, where);
    }

    static getJSONforGalleryImageFromFid(fid, image, height, settings, num) {
        let langPrefix = document.documentElement.lang == 'ru' ? '' : '/' + document.documentElement.lang;
        var topDist;
        topDist = window.pageXOffset;
        image.fetched = 0;
        let loadBefore = 400 + window.innerHeight;

        if (topDist > (image.getBoundingClientRect().top - loadBefore) && image.fetched !== 1) {
            image.fetched = 1;
            fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                .then(function (response) {
                    return response.json();
                }).then(function (json) {
                IviGallery.getImageDimensions(json, image, height, settings, num);

            }).catch(function (ex) {
                console.log('parsing failed', ex);
            })
        }

        window.addEventListener("scroll", function (event) {
            topDist = this.scrollY;

            if (topDist > (image.getBoundingClientRect().top - loadBefore) && image.fetched !== 1) {
                image.fetched = 1;

                fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
                    .then(function (response) {
                        return response.json();
                    }).then(function (json) {
                    IviGallery.getImageDimensions(json, image, height, settings, num);

                }).catch(function (ex) {
                    console.log('parsing failed', ex);
                })
            }
        }, false);
    }

    static getImageDimensions(json, image, height, settings, num) {

        let img = new Image();
        img.src = json[0];

        img.onload = function () {
            let ratio = img.naturalWidth / img.naturalHeight;
            let width = height * ratio;
            IviGallery.setFirstSlides(json, image, height, settings, num);
        };
    }

    static buildArea(gallery) {
        let galleryWrap = document.createElement('div');
        galleryWrap.classList.add('iviparagraphs__gallery-wrapper');
        gallery.appendChild(galleryWrap);
    }

    static setFirstSlides(json, image, height, settings, num) {

        let firstSlide = document.createElement('img');
        firstSlide.classList.add('iviparagraphs__gallery__item-' + num);
        firstSlide.src = json[0];
        let wrapper = image.parentNode.lastChild;
        firstSlide.style.height = height + 'px';

        if (wrapper.childElementCount < 3) {
            wrapper.appendChild(firstSlide);
            // if (wrapper.childElementCount < 2) {
            IviGallery.addFirstSlide(image, height, settings, num);
//            fid, image, height, settings, num
            //  }
        }

        if (wrapper.children.length === 3) {
            //  IviGallery.arrangeImages(wrapper, settings);
            IviGallery.setWrapperWidth(wrapper, settings);
        }
    }

    static setWrapperWidth(wrapper, settings) {

        let images = wrapper.children;
        let galleryWidth = wrapper.parentNode.clientWidth;

        images[1].style.paddingRight = settings.horizontalPadding + 'px';
        images[1].style.paddingLeft = settings.horizontalPadding + 'px';
        let wrapperWidth = 0;
        for (let image of images) {
            wrapperWidth += image.clientWidth;
        }

        wrapper.style.width = wrapperWidth + settings.horizontalPadding * 2 + 'px';
        let centre = images[0].clientWidth + images[1].clientWidth / 2;
        let centreOffset = (wrapperWidth + settings.horizontalPadding * 2) / 2 - centre;
        let simpleLeft = (galleryWidth - wrapperWidth) / 2 - settings.horizontalPadding;
        let resultLeft = simpleLeft + centreOffset;
        wrapper.style.left = resultLeft + 'px';

        // if (galleryWidth > wrapperWidth) {
        console.log(wrapper.parentNode);
        let leftOffset = galleryWidth / 2 - wrapperWidth / 2 + centreOffset;
        let rightOffset = galleryWidth - images[0].clientWidth - images[1].clientWidth - images[2].clientWidth - leftOffset;
        if (leftOffset > 0 && wrapper.parentNode.childElementCount > 4) {
            IviGallery.addSlideToLeftSide(wrapper, settings);
        }
        if (rightOffset > 0  && wrapper.parentNode.childElementCount > 4) {
            IviGallery.addSlideToRightSide(wrapper, settings);
        }

        //  }
        window.addEventListener('resize', function () {
            wrapperWidth = 0;
            for (let image of images) {
                wrapperWidth += image.clientWidth;
            }
            wrapper.style.width = wrapperWidth + settings.horizontalPadding * 2 + 'px';
            wrapper.style.left = (window.innerWidth - wrapperWidth) / 2 - settings.horizontalPadding + (wrapperWidth + settings.horizontalPadding * 2) / 2 - images[0].clientWidth + images[1].clientWidth / 2 + 'px';


        });
    }

    // Set the element with the largest ietem-num as first. Than - with the smallest, that - the third
    /* static arrangeImages(wrapper, settings) {
     let images = wrapper.children;

     let numArray = [];
     let ind = -1;
     for (let element of images) {
     ind++;
     let classes = element.className;
     let classesParts = classes.split('__');
     let styleNumber;

     for (let elClass of classesParts) {
     if (elClass.indexOf('item') >= 0) {
     styleNumber = elClass;
     }
     }
     let classesArray = styleNumber.split('-');
     let itemNum = classesArray[1];
     numArray[ind] = itemNum;

     }

     let maxNum = 0;

     for (let numb of numArray) {
     if (numb > maxNum) {
     maxNum = numb;
     }
     }

     let resNums = [];
     resNums[0] = maxNum;
     let i = 0;
     for (let resNum of numArray) {
     if (resNum != maxNum) {
     i++;
     resNums[i] = resNum;
     }
     }

     let wrapperParent = wrapper.parentNode;
     let itemS = wrapperParent.getElementsByClassName('iviparagraphs__gallery__item-' + maxNum)[0];
     let item1 = wrapperParent.getElementsByClassName('iviparagraphs__gallery__item-' + resNums[1])[0];
     let item2 = wrapperParent.getElementsByClassName('iviparagraphs__gallery__item-' + resNums[2])[0];
     wrapper.innerHTML = '';

     wrapper.appendChild(itemS);
     wrapper.appendChild(item1);
     wrapper.appendChild(item2);

     if (wrapper.childElementCount === 3) {
     IviGallery.setWrapperWidth(wrapper, settings);
     }

     }*/

    static addSlideToLeftSide(wrapper, settings) {
        let lastNum = IviParagraphs.getItemNumber(wrapper.firstChild);
        IviGallery.chooseSlideToAdd(wrapper, (Math.floor(lastNum) - 1), settings, 'before');
    }

    static addSlideToRightSide(wrapper, settings) {
        let lastNum = IviParagraphs.getItemNumber(wrapper.lastChild);
        IviGallery.chooseSlideToAdd(wrapper, (Math.floor(lastNum) + 1), settings, 'after');
    }

    static getJSONforAddSlideFromFid(fid, image, settings, num, where) {
        let langPrefix = document.documentElement.lang == 'ru' ? '' : '/' + document.documentElement.lang;
        fetch(langPrefix + '/rest/api/par/horimg/' + fid, {credentials: 'include'})
            .then(function (response) {
                return response.json();
            }).then(function (json) {
            if (where === 'before') {
                IviGallery.addBefore(json, image, settings, num);
            }
            if (where === 'after') {
                IviGallery.addAfter(json, image, settings, num);
            }

        }).catch(function (ex) {
            console.log('parsing failed', ex);
        });

    }

    static addBefore(json, image, settings, num) {

        let img = new Image();
        img.src = json[0];

        img.onload = function () {
            let firstSlide = document.createElement('img');
            firstSlide.classList.add('iviparagraphs__gallery__item-' + num);
            firstSlide.src = json[0];
            let wrapper = image.parentNode.lastChild;
            firstSlide.style.height = 100 + '%';
            firstSlide.style.paddingRight = settings.horizontalPadding + 'px';
            let ratio = img.naturalWidth / img.naturalHeight;
            let width = wrapper.clientHeight * ratio;
            let style = getComputedStyle(wrapper);
            let left = parseInt(style.getPropertyValue('left'), 10);
            wrapper.style.width = wrapper.clientWidth + settings.horizontalPadding + width + 'px';
            wrapper.style.left = left - width + 'px';
            wrapper.insertBefore(firstSlide, wrapper.firstChild);
        };
    }

    static addAfter(json, image, settings, num) {
        let img = new Image();
        img.src = json[0];

        img.onload = function () {
            let firstSlide = document.createElement('img');
            firstSlide.classList.add('iviparagraphs__gallery__item-' + num);
            firstSlide.src = json[0];
            let wrapper = image.parentNode.lastChild;
            firstSlide.style.height = 100 + '%';
            firstSlide.style.paddingLeft = settings.horizontalPadding + 'px';
            let ratio = img.naturalWidth / img.naturalHeight;
            let width = wrapper.clientHeight * ratio;
            let style = getComputedStyle(wrapper);
            let left = parseInt(style.getPropertyValue('left'), 10);
            wrapper.style.width = wrapper.clientWidth + settings.horizontalPadding + width + 'px';
            wrapper.appendChild(firstSlide);
        };
    }

    static addSlides() {

    }

}