import IviParagraphs from './IviParagraphs';

export default class IviHorImage {

    constructor() {
        this.body = document.body;
    }

    static set(imgClass, settings) {
        var images = document.getElementsByClassName(imgClass);

        if (images.length > 0) {
            IviHorImage._run(images, settings);
        }
    }


    static _run(images, settings) {

        for (var image of images) {

            let imgWrapper = image.getElementsByClassName('iviparagraphs__horimage-img')[0];
            let classes = imgWrapper.className;
            let classesArray = classes.split(' ');
            let classesArraySecond = classesArray[1].split('-');

            IviHorImage.addCss(settings, image);
            IviHorImage.imgHeight(settings, image);
            window.onresize = function () {
                IviHorImage.imgHeight(settings, image);
            };
            IviParagraphs.getJSONforSingleImageFromFid(classesArraySecond[2], image);
        }

        if (document.getElementsByClassName('iviplaceholder').length > 0) {
            for (let item of document.getElementsByClassName('iviplaceholder')) {
                if (item.className.indexOf('iviplaceholder-none') < 1) {
                    IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                }
            }
        }
    }

    static addCss(settings, image) {
        image.style.marginBottom = settings.marginBottom + 'px';
        image.style.marginTop = settings.marginTop + 'px';
    }

    static imgHeight(settings) {

        let imgs = document.getElementsByClassName('iviparagraphs__horimage');
        for(let img of imgs) {
            img.style.height = (window.innerHeight * settings.height) + 'px';
        }

    }

}