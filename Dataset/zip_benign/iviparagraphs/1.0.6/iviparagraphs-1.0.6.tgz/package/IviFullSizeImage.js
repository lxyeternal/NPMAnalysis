import IviParagraphs from './IviParagraphs';

export default class IviFullSizeImage {

    static set(imgClass, settings) {

        var images = document.getElementsByClassName(imgClass);
        if (images.length > 0) {
            IviFullSizeImage._run(images, settings);
        }
    }

    static _run(images, settings) {
        let index = 0;
        for (var image of images) {

            let imgWrapper = image.getElementsByClassName('iviparagraphs__fsimage-img')[0];
            let classes = imgWrapper.className;
            let classesArray = classes.split(' ');
            let classesArraySecond = classesArray[1].split('-');
            let title = image.getElementsByClassName('iviparagraphs__fsimage-title');


            if (settings.defaultTitle == true) {
                if (title.length > 0) {
                    IviParagraphs.addClassToElement(title[0], 'iviparagraphs__fsimage-title-default');
                }
            }
            if (settings.defaultTitle == false) {
                IviParagraphs.addClassToElement(title[0], settings.titleClass);
                if (Object.keys(settings.style).length > 0 && settings.style.hasOwnProperty('title')) {
                    IviParagraphs.defineCss(title[0], settings.style.title);
                }
            }
            if (settings.span == true && settings.spanClass.length > 0) {
                IviFullSizeImage._addSpan(image, settings);
            }
            if (settings.imageLayer == true) {
                let layer = document.createElement('div');
                layer.classList.add('iviparagraphs__fsimage-layer');
                image.appendChild(layer);
            }

            let mainClasses = image.className;
            let mainClassesArray = mainClasses.split(' ');
            for (let elClass of mainClassesArray) {
                if (elClass.indexOf('iviparagraphs__fsimage-arrow') >= 0) {

                    if (settings.arrowClass.length > 0) {
                        index++;
                        IviFullSizeImage._addArrow(image, index, settings);
                    }
                }
            }

            IviFullSizeImage.imgHeightAndMargin(image, imgWrapper, settings);
            IviParagraphs.getJSONforSingleImageFromFid(classesArraySecond[2], imgWrapper);
        }

        window.addEventListener('resize', function () {
            for (var image of images) {
                let imgWrapper = image.getElementsByClassName('iviparagraphs__fsimage-img')[0];
                IviFullSizeImage.imgHeightAndMargin(image, imgWrapper, settings);
                IviFullSizeImage._addSpan(image, settings);
            }

        });


      //  setTimeout(function () {
            if (document.getElementsByClassName('iviplaceholder').length > 0) {
                for (let item of document.getElementsByClassName('iviplaceholder')) {
                    if (item.className.indexOf('iviplaceholder-none') < 1) {
                        IviParagraphs.addClassToElement(item, 'iviplaceholder-none');
                    }
                }
            }
      //  }, 250);


    }

    static imgHeightAndMargin(image, imgWrapper, settings) {

        var headerHeight = IviParagraphs.getHeaderHeight();
        let title = image.getElementsByClassName('iviparagraphs__fsimage-title');
        let arrow = image.getElementsByClassName('iviparagraphs__fsimage-elementarrow');
        let titleHeight = 0;
        let arrowHeight = 0;
        if (title.length > 0) {
            titleHeight = title[0].clientHeight;
        }
        if (arrow.length > 0) {
            arrowHeight = arrow[0].clientHeight;
        }

        if (document.getElementsByClassName('iviparagraphs')[0].firstChild == image) {

            var header = document.getElementById('header');
            if (title.length > 0) {

                if ((window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) / 2 < 0) {
                    title[0].style.paddingBottom = 40 + 'px';
                    title[0].style.paddingTop = 40 + 'px';
                    title[0].style.top = 0;
                    titleHeight += 80;
                }
                else {
                    title[0].style.paddingBottom = 0 + 'px';
                    title[0].style.paddingTop = 0 + 'px';
                    title[0].style.top = (window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) / 2 + 'px';
                }

            }
            IviParagraphs.setCss(image, 'marginBottom', settings.marginBottom + 'px');

            if ((window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) / 2 < (arrowHeight + 20)) {
                if ((window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) < 0) {
                    imgWrapper.style.height = titleHeight + arrowHeight + 20 + 'px';
                }
                else {
                    imgWrapper.style.height = (window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) + titleHeight + arrowHeight + 20 + 'px';
                }

            }
            else {
                imgWrapper.style.height = window.innerHeight - headerHeight - settings.bottomOffset + 'px';
            }
        }
        else {

            IviParagraphs.setCss(image, 'marginTop', settings.marginTop + 'px');
            IviParagraphs.setCss(image, 'marginBottom', settings.marginBottom + 'px');
            if (title.length > 0) {
                title[0].style.top = (window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) / 2 + 'px';
            }

            if ((window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) / 2 < (arrowHeight + 20)) {
                imgWrapper.style.height = (window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) + titleHeight +arrowHeight + 20 + 'px';
            }
            else {
                imgWrapper.style.height = window.innerHeight - headerHeight - settings.bottomOffset + 'px';
            }
        }
    }


    static _addArrow(image, index, settings) {
        let arrowWrap = document.createElement('div');
        arrowWrap.classList.add('iviparagraphs__fsimage-elementarrow');
        image.appendChild(arrowWrap);
        var link = document.createElement('a');
        link.href = '#scroll-' + index;
        link.classList.add('scroll');
        arrowWrap.appendChild(link);
        let arrowImg = document.createElement('div');
        arrowImg.classList.add('iviparagraphs__fsimage-elementarrow-img');
        IviParagraphs.addClassToElement(arrowImg, settings.arrowClass);
        link.appendChild(arrowImg);
        let scrollId = document.createElement('div');
        scrollId.id = 'scroll-' + index;
        scrollId.classList.add('iviparagraphs__fsimage-scroll');
        image.appendChild(scrollId);
    }

    static _addSpan(image, settings) {
        let spanWrap = document.createElement('div');
        spanWrap.classList.add('iviparagraphs__fsimage-line');

        let span = document.createElement('div');
        span.classList.add(settings.spanClass);
        spanWrap.appendChild(span);

        let title = image.getElementsByClassName('iviparagraphs__fsimage-title');
        let titleHeight = title[0].clientHeight;
        let headerHeight = IviParagraphs.getHeaderHeight();

        if ((window.innerHeight - headerHeight - settings.bottomOffset - titleHeight) / 2 > (window.innerHeight - headerHeight - settings.bottomOffset) * 0.35) {
            let element = image.getElementsByClassName('iviparagraphs__fsimage-line');
            if (element.length < 1) {
                image.appendChild(spanWrap);
            }

        }
        else {
            let element = image.getElementsByClassName('iviparagraphs__fsimage-line');
            if (element.length > 0) {
                image.removeChild(element[0])
            }

        }

    }

}