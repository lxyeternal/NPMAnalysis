/**
 * 解析并执行公式
 * @param {Object} input - 输入对象，包含公式和参数
 * @param {string} input.formula - 数学公式
 * @param {Object} input.data - 参数对象
 * @return {number} - 计算结果
 */
function evaluateFormula(input) {
    const { formula, data } = input;

    // 用参数替换公式中的变量
    let replacedFormula = formula;
    for (const key in data) {
        if (data.hasOwnProperty(key)) {
            const value = data[key];
            const regex = new RegExp(`\\b${key}\\b`, 'g');
            replacedFormula = replacedFormula.replace(regex, value);
        }
    }

    // 解析并计算公式
    return evaluateExpression(replacedFormula);
}

/**
 * 解析并计算表达式
 * @param {string} expr - 表达式
 * @return {number} - 计算结果
 */
function evaluateExpression(expr) {
    // 去除空格
    expr = expr.replace(/\s+/g, '');

    // 处理括号
    while (expr.includes('(')) {
        expr = expr.replace(/\([^()]*\)/g, (subExpr) => {
            return evaluateSimpleExpression(subExpr.slice(1, -1));
        });
    }

    return evaluateSimpleExpression(expr);
}

/**
 * 解析并计算简单表达式（无括号）
 * @param {string} expr - 简单表达式
 * @return {number} - 计算结果
 */
function evaluateSimpleExpression(expr) {
    const operators = ['+', '-', '*', '/'];
    const precedence = {
        '+': 1,
        '-': 1,
        '*': 2,
        '/': 2
    };

    const outputQueue = [];
    const operatorStack = [];

    let numberBuffer = [];

    for (let i = 0; i < expr.length; i++) {
        const char = expr[i];

        if (!isNaN(char) || char === '.') {
            numberBuffer.push(char);
        } else if (operators.includes(char)) {
            if (numberBuffer.length) {
                outputQueue.push(numberBuffer.join(''));
                numberBuffer = [];
            }

            while (
                operatorStack.length &&
                precedence[operatorStack[operatorStack.length - 1]] >= precedence[char]
            ) {
                outputQueue.push(operatorStack.pop());
            }

            operatorStack.push(char);
        }
    }

    if (numberBuffer.length) {
        outputQueue.push(numberBuffer.join(''));
    }

    while (operatorStack.length) {
        outputQueue.push(operatorStack.pop());
    }

    const resultStack = [];

    outputQueue.forEach((token) => {
        if (!isNaN(token)) {
            resultStack.push(parseFloat(token));
        } else {
            const b = resultStack.pop();
            const a = resultStack.pop();
            switch (token) {
                case '+':
                    resultStack.push(a + b);
                    break;
                case '-':
                    resultStack.push(a - b);
                    break;
                case '*':
                    resultStack.push(a * b);
                    break;
                case '/':
                    resultStack.push(a / b);
                    break;
            }
        }
    });

    return resultStack[0];
}

module.exports = evaluateFormula;