

## Intro

This is a package that can be used to calculate formulations in the following form(sth. like JSON):

1. formula in String format
2. data in the JSON format.

## Usage

To use this package, follow the following steps:

1. install the package using npm.

   ```bash
   npm install mark_tools
   ```
2. import the package

   ```javascript
   const evaluateFormula = require("mark_tools");
   ```
3. use the evaluateFormula function to calculate the result.

   ```javascript
   const evaluateFormula = require("mark_tools");

   const input = {
       formula: '(x+y)*z',
       data: {
           x: 0.1,
           y: 0.2,
           z: 1
       }
   };

   const result = evaluateFormula(input);
   console.log(result)
   ```

And after this example, you will be able to see the result 0.3 logged in the console.
