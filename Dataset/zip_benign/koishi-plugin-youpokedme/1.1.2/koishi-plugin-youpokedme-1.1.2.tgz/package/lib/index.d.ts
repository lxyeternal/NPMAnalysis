import { Context, Schema } from 'koishi';
export declare const name = "youpokedme";
export declare const usage = "\n**\u8BE5\u63D2\u4EF6\u4EC5\u652F\u6301onebot\u652F\u6301\u6233\u4E00\u6233\u7684\u534F\u8BAE**  \nreply\u662F\u5FC5\u586B\u9879\uFF0C\u5FC5\u987B\u586Breply\u914D\u7F6E\u9879\u624D\u80FD\u6B63\u5E38\u4F7F\u7528  \n\u4F7F\u7528\u65B9\u6CD5\u8BF7\u770B[README](https://www.npmjs.com/package/koishi-plugin-youpokedme)  \n**\u6CE8\u610F** \u7531\u4E8Ego-cqhttp\u5DF2\u505C\u6B62\u66F4\u65B0\uFF0C\u800C\u65B0\u7684\u534F\u8BAE\u6682\u4E0D\u652F\u6301\u6233\u4E00\u6233\uFF0C\u56E0\u6B64\u672C\u63D2\u4EF6\u4E5F\u968F\u4E4B\u505C\u6B62\u66F4\u65B0  \n\u611F\u8C22go-cqhttp\u7684\u966A\u4F34\uFF0C\u4E5F\u611F\u8C22\u5927\u5BB6\u7684\u652F\u6301\u3002\n";
export interface Config {
    reply: string[];
    pokebk: number;
    rdmImgFolder: string;
    rdmImgodds: number;
    rdmAudioFolder: string;
    rdmAudioodds: number;
}
export declare const schema: Schema<Schemastery.ObjectS<{
    reply: Schema<string[], string[]>;
    pokebk: Schema<number, number>;
    rdmImgFolder: Schema<string, string>;
    rdmImgodds: Schema<number, number>;
    rdmAudioFolder: Schema<string, string>;
    rdmAudioodds: Schema<number, number>;
}>, Schemastery.ObjectT<{
    reply: Schema<string[], string[]>;
    pokebk: Schema<number, number>;
    rdmImgFolder: Schema<string, string>;
    rdmImgodds: Schema<number, number>;
    rdmAudioFolder: Schema<string, string>;
    rdmAudioodds: Schema<number, number>;
}>>;
export declare function apply(ctx: Context, config: Config): void;
