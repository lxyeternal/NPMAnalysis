/**
 * calculate control points from points that a curve passes through
 * @param {Array<Array>} points array of point that a bezier curve passes through. ex[ [0, 0], [2, 3], [5, 10] ]
 * @param {number} t1 option: to modify curvature, pass number (0 <= t1 <= 1)
 * @param {number} t2 option: to modify curvature, pass number (0 <= t2 <= 1)
 * @return array of points, that is, an origin point, one or two control points, and an end point
 */
export function calcCtrlPoints(points, t1, t2) {

    if(points.length == 3)
        return calcQuadraticCtrlPoint(points, t1)
    if(points.length == 4)
        return calcCubicCtrlPoint(points, t1, t2)
}

export function calcQuadraticCtrlPoint(points, t = .5) {

    var copyPoints = [...points]

    var t0 =(1-t) * (1-t)
    var t1 = 2 * (1-t) * t
    var t2 = t * t

    var [p0, p1, p2] = [copyPoints[0], copyPoints[1], copyPoints[2]]

    var px = - (t0 * p0[0] + t2 * p2[0] - p1[0]) / t1
    var py = - (t0 * p0[1] + t2 * p2[1] - p1[1]) / t1
    
    copyPoints[1] = [px, py]

    return copyPoints
}

export function calcCubicCtrlPoint(points, t1 = 1/3, t2 = 2/3) {

    var copyPoints = [...points]

    var [a1, b1] = [3 * t1 * (1-t1) * (1-t1), 3 * (1-t1) * t1 * t1]
    var [a2, b2] = [3 * t2 * (1-t2) * (1-t2), 3 * (1-t2) * t2 * t2]

    var [p0, pa, pb, p3] = [points[0], points[1], points[2], points[3]]

    var d = a1 * b2 - b1 * a2
    var inversedMatrix = [
        [b2 / d, - b1 / d],
        [- a2 / d, a1 / d]
    ]

    var matrixX = [
        pa[0] - (1-t1) * (1-t1) * (1-t1) * p0[0] - t1 * t1 * t1 * p3[0],
        pb[0] - (1-t2) * (1-t2) * (1-t2) * p0[0] - t2 * t2 * t2 * p3[0],
    ]
    var matrixY = [
        pa[1] - (1-t1) * (1-t1) * (1-t1) * p0[1] - t1 * t1 * t1 * p3[1],
        pb[1] - (1-t2) * (1-t2) * (1-t2) * p0[1] - t2 * t2 * t2 * p3[1],
    ]

    copyPoints[1] = [inversedMatrix[0][0] * matrixX[0] + inversedMatrix[0][1] * matrixX[1], inversedMatrix[0][0] * matrixY[0] + inversedMatrix[0][1] * matrixY[1]]
    copyPoints[2] = [inversedMatrix[1][0] * matrixX[0] + inversedMatrix[1][1] * matrixX[1], inversedMatrix[1][0] * matrixY[0] + inversedMatrix[1][1] * matrixY[1]]

    return copyPoints
}