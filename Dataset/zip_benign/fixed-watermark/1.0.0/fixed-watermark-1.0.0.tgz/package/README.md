# fixed-watermark

给页面添加水印，水印使用fixed定位

## Install
```
npm instal --save fixed-watermark
```

## Usage
```
import watermark from 'fixed-watermark';

watermark({
     watermark_txt: 'text',
     watermark_x: 20, // 水印起始位置x轴坐标
     watermark_y: 20, // 水印起始位置Y轴坐标
     watermark_rows: 10, // 水印行数
     watermark_cols: 10, // 水印列数
     watermark_x_space: 100, // 水印x轴间隔
     watermark_y_space: 50, // 水印y轴间隔
     watermark_color: '#aaa', // 水印字体颜色
     watermark_alpha: 0.4, // 水印透明度
     watermark_fontsize: '15px', // 水印字体大小
     watermark_font: '微软雅黑', // 水印字体
     watermark_width: 210, // 水印宽度
     watermark_height: 80, // 水印长度
     watermark_angle: 15 // 水印倾斜度数
})
```