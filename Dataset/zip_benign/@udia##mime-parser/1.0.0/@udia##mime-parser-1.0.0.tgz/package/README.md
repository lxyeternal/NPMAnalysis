# @udia/mime-parser

[![udia-mime-parser-npmjs-badge]][udia-mime-parser-npmjs]
[![udia-mime-parser-build-test-badge]][udia-mime-parser-build-test]

Utility package for parsing mime headers.

## Example

```bash
npm i @udia/mime-parser
# or
yarn add @udia/mime-parser
```

```typescript
import {
  parseMimeType,
  parseMediaRange,
  quality,
  bestMatch,
} from '@udia/mime-parser'

parseMimeType('application/xhtml;q=0.5')
// ['application', 'xhtml', { q: '0.5' }]

parseMediaRange('text/plain;charset=UTF-8')
// ['text', 'plain', { charset: 'UTF-8', q: '1' }]

quality('text/javascript', 'text/*;q=0.3, text/html;q=0.7, */*;q=0.5')
// 0.3

bestMatch(
  ['text/plain', 'text/html'],
  'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
)
// 'text/html'
```

## See also

- https://code.google.com/archive/p/mimeparse/
- https://github.com/kriskowal/mimeparse

## License

[`AGPL-3.0`](../../LICENSE)

```text
Copyright (C) 2021-2022 Alexander Wong <alex@udia.ca>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
```

[udia-mime-parser-gh]: https://github.com/udiaca/common/tree/main/packages/udia-mime-parser
[udia-mime-parser-npmjs-badge]: https://badge.fury.io/js/@udia%2Fmime-parser.svg
[udia-mime-parser-npmjs]: https://www.npmjs.com/package/@udia/mime-parser
[udia-mime-parser-build-test-badge]: https://github.com/udiaca/common/actions/workflows/udia-mime-parser-build-test.yml/badge.svg
[udia-mime-parser-build-test]: https://github.com/udiaca/common/actions/workflows/udia-mime-parser-build-test.yml
