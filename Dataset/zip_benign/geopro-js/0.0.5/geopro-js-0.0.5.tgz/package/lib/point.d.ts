import { HCoords, HomogeneousCoords, GeoMatrix } from './types';
import { Vector } from './vector';
import { Frame } from './frame';
import { UnitVector } from './unitvector';
/**
 * A 3D point
 * @public
 */
export declare class Point implements HomogeneousCoords {
    private _coord;
    constructor(x: number, y: number, z: number, w?: number);
    get isPoint(): boolean;
    get x(): number;
    get y(): number;
    get z(): number;
    get coordinates(): HCoords;
    /**
     * Use a transformation M to return a new point p' = M·p
     * @param m - transformation matrix
     */
    map: (m: GeoMatrix) => Point;
    /**
     * Create a point given the coordinates relative to a frame
     * @param f - the frame of reference
     * @param c - the vector components
     */
    relative: (f: Frame) => Point;
    /**
     * Create a point adding the given vector to this point.
     */
    add: (v: Vector) => Point;
    /**
     * Create a point adding all the vectors to this point.
     */
    adds: (vs: Vector[]) => Point;
    /**
     * Create a point given an array of coordinates (must be 4 long)
     */
    static fromHCoords: (values: number[]) => Point;
    along: (t: number, dir: UnitVector) => Point;
    /**
     * Returns true if the point are in the same location within tolerance
     */
    static equals: (p1: Point, p2: Point) => boolean;
    /**
     * Returns true if the point are NOT in the same location within tolerance
     */
    static notEquals: (p1: Point, p2: Point) => boolean;
}
/**
 * TypeGuard to cast coordinates to a Point
 * @param o
 */
export declare function isPoint(o: HomogeneousCoords): o is Point;
//# sourceMappingURL=point.d.ts.map