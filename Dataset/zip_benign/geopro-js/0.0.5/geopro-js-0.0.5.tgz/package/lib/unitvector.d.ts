import { VCoords, HomogeneousCoords, GeoMatrix } from './types';
import { Vector } from './vector';
import { Frame } from './frame';
import { Point } from './point';
/**
 * A 3D unit-vector
 * @public
 */
export declare class UnitVector implements HomogeneousCoords {
    private _coord;
    static fromVector(v: Vector): UnitVector;
    /**
     * Build a unit vector. (by default along the X axis).
     * @param x - x component
     * @param y - y component
     * @param z - z component
     */
    constructor(x?: number, y?: number, z?: number);
    /**
     * Build a new unit-vector given 3 components
     * @param x - X component
     * @param y - Y component
     * @param z - Z component
     */
    private static fromComponents;
    /**
     * Build a new unit-vector given vector components
     * @param c - components
     */
    static fromVCoords(c: VCoords): UnitVector;
    /**
     * return tru if the object is a UnitVector
     */
    get isUnitVector(): boolean;
    /**
     * Get component along the X axis
     */
    get x(): number;
    /**
     * Get component along the Y axis
     */
    get y(): number;
    /**
     * Get component along the Z axis
     */
    get z(): number;
    /**
     * Get the unit-vector components
     */
    get coordinates(): VCoords;
    /**
     * Retrieve the length of the vector: |v|
     * For unit-vector the length is always 1
     */
    get length(): number;
    /**
     * Return a new vector along the direction of this unit-vector and
     * of length s
     * @param s - the multiplier
     */
    multiplyBy(s: number): Vector;
    /**
     * Use a transformation M to return a new unit-vector u' = M·u
     * @param m - transformation matrix
     */
    map: (t: GeoMatrix) => UnitVector;
    /**
     * Calculate the direction from p2 to p1
     * @param p1 - first point
     * @param p2 - seconf point
     */
    static fromPoints: (p1: Point, p2: Point) => UnitVector;
    /**
     * Return this unit vector as relative to the given frame
     * @param m - transformation matrix
     */
    relative: (f: Frame) => UnitVector;
    static equals: (v1: UnitVector, v2: UnitVector) => boolean;
    static notEquals: (v1: UnitVector, v2: UnitVector) => boolean;
    /**
     * Returns true if the two unit vectors are parallel
     * Note: vector can point in the same or opposite direction
     * @param v1 - a first unit-vector
     * @param v2 - a second unit-vector
     */
    static parallel: (v1: UnitVector, v2: UnitVector) => boolean;
    /**
     * Returns a new UnitVector computed as the cross-product
     * of the two unit-vector passed as parameter: u' = u1 x u2
     * @param v1 - a first unit-vector
     * @param v2 - a second unit-vector
     */
    static crossProduct: (v1: UnitVector, v2: UnitVector) => UnitVector;
    /**
     * Return the result of the dot-product of the two unit-vectors
     * Note: Uses the right-hand rule.
     * @param v1 - a first unit-vector
     * @param v2 - a second unit-vector
     */
    static dotProduct: (v1: UnitVector, v2: UnitVector) => number;
    /**
     * Return the angle between two unit-vectors.
     * Note: Uses the right-hand rule.
     * @param v1 - a first unit-vector
     * @param v2 - a second unit-vector
     */
    static angleBetween: (v1: UnitVector, v2: UnitVector) => number;
}
export declare function isUnitVector(o: HomogeneousCoords): o is UnitVector;
//# sourceMappingURL=unitvector.d.ts.map