import { Matrix, Row, Col, GeoMatrix } from './types';
/**
 * A simple projection transformation
 * @public
 */
export declare class Project implements GeoMatrix {
    private _direct;
    private _fov;
    private _d;
    /**
     * build a basic projection on XY on Z=-1
     * @param fov - Field of view angle (in radians)
     */
    constructor(d: number, fov?: number);
    get directMatrix(): Matrix;
    direct(row: Row, col: Col): Number;
    /**
     * Builds and returns the composition of t with this transformation
     * That is: resM = t.M · this.M
     * @param t - the transformation to compose with
     */
    composeWith(t: GeoMatrix): Project;
    private get fovScale();
    static fovScale(d: number, fov: number): number;
    static fromOrthographicOnXY(d: number, fov: number): Project;
    static fromOrthographicOnXZ(d: number, fov: number): Project;
    static fromOrthographicOnYZ(d: number, fov: number): Project;
    static fromPerspectiveOnXY(d: number, fov: number): Project;
    static fromPerspectiveOnXZ(d: number, fov: number): Project;
    static fromPerspectiveOnYZ(d: number, fov: number): Project;
    private static fromMatrix;
}
//# sourceMappingURL=project.d.ts.map