import { Matrix, HCoords, VCoords } from './types';
export declare const precision = 0.00001;
export declare type Round = {
    (p: number, n: number): number;
    (p: number): (n: number) => number;
};
export declare const round: Round;
/**
 * @public
 */
export declare const round4: (n: number) => number;
/**
 * @public
 */
export declare const round3: (n: number) => number;
/**
 * @public
 */
export declare const round2: (n: number) => number;
/**
 * @public
 */
export declare const round1: (n: number) => number;
/**
 * @public
 */
export declare const matrixMultiply: (t1: Matrix, t2: Matrix) => Matrix;
export declare const matrixEqual: (m1: Matrix, m2: Matrix) => boolean;
export declare const matrixVectorMultiply: (t: Matrix, v: VCoords) => VCoords;
export declare const matrixPointMultiply: (t: Matrix, v: HCoords) => HCoords;
export declare const invertAffineOrthogonalMatrix: (t: Matrix) => Matrix;
//# sourceMappingURL=math.d.ts.map