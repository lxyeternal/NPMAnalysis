import { VCoords, HomogeneousCoords, GeoMatrix } from './types';
import { Point } from './point';
import { Frame } from './frame';
/**
 * A 3D vector
 * @public
 */
export declare class Vector implements HomogeneousCoords {
    private _coord;
    /**
     * Build a vector in space with the given components
     * @param x - X component
     * @param y - Y component
     * @param z - Z component
     */
    constructor(x: number, y: number, z: number);
    /**
     * Build a new vector given vector components
     * @param c - components
     */
    static fromVCoords: (vals: VCoords) => Vector;
    /**
     * Return true is the object is a Vector
     */
    get isVector(): boolean;
    /**
     * Get component along the X axis
     */
    get x(): number;
    /**
     * Get component along the Y axis
     */
    get y(): number;
    /**
     * Get component along the Z axis
     */
    get z(): number;
    /**
     * Get the vector components
     */
    get coordinates(): VCoords;
    /**
     * Retrieve the length of the vector: |v|
     */
    get length(): number;
    /**
     * Return a new vector by multiplying this one by a scalar
     * @param s - the multiplier
     */
    multiplyBy: (s: number) => Vector;
    /**
     * Use a transformation M to return a new vector v' = M·v
     * @param m - transformation matrix
     */
    map(m: GeoMatrix): Vector;
    /**
     * Create a vector given the coordinates relative to a frame
     * @param f - the frame of reference
     * @param c - the vector components
     */
    relative: (f: Frame) => Vector;
    /**
     * Determine if two vectors are equals (within tollerance)
     * @param v1 -
     * @param v2 -
     */
    static equals: (v1: Vector, v2: Vector) => boolean;
    static notEquals: (v1: Vector, v2: Vector) => boolean;
    static parallel: (v1: Vector, v2: Vector) => boolean;
    static fromPoints: (p1: Point, p2: Point) => Vector;
    static adds: (v1: Vector, ...vs: Vector[]) => Vector;
    static crossProduct: (v1: Vector, v2: Vector) => Vector;
    static dotProduct: (v1: Vector, v2: Vector) => number;
}
export declare function isVector(o: HomogeneousCoords): o is Vector;
//# sourceMappingURL=vector.d.ts.map