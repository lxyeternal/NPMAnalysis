import { HomogeneousCoords, GeoMatrix, AffineGeoMatrix } from './types';
import { Point, Vector, Frame } from '.';
export declare type Map = {
    <T extends HomogeneousCoords>(t: GeoMatrix, o: T): T;
    (t: GeoMatrix): <T extends HomogeneousCoords>(o: T) => T;
};
/**
 * Apply the transformation to a point.
 * p' = M*p
 * @param t - a transformation or a frame of reference
 * @param o - a transformable object (i.e an object derived from HomogeneousCoords)
 * @public
 */
export declare const map: Map;
declare type RelativeToGlobal = {
    <T extends HomogeneousCoords>(frame: Frame, p: T): T;
    (frame: Frame): <T extends HomogeneousCoords>(p: T) => T;
};
/**
 * Build a global object from one relative to the given reference frame
 */
export declare const fromRelative: RelativeToGlobal;
/**
 * Compose transformations right to left (eg T2*T1)
 * @param tlist - a list of transformation to combine
 * @public
 */
export declare const compose: (...l: AffineGeoMatrix[]) => AffineGeoMatrix;
export declare type AddToPoint = {
    (p: Point, v: Vector, ...vs: Vector[]): Point;
    (p: Point): (v: Vector, ...vs: Vector[]) => Point;
};
/**
 * Add vectors to a point
 */
export declare const addToPoint: AddToPoint;
export declare type AddToVector = {
    (v1: Vector, v: Vector, ...vs: Vector[]): Vector;
    (v1: Vector): (v: Vector, ...vs: Vector[]) => Vector;
};
/**
 * Add vectors to a vector
 */
export declare const addToVector: AddToVector;
export {};
//# sourceMappingURL=operations.d.ts.map