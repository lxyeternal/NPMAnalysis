import { Matrix, Row, Col, GeoMatrix, InvertibleGroMatrix, AffineGeoMatrix } from './types';
/**
 * A affine 3D transformation
 * @public
 */
export declare class Transform implements GeoMatrix, InvertibleGroMatrix {
    private _direct;
    private _inverse;
    constructor();
    get directMatrix(): Matrix;
    get inverseMatrix(): Matrix;
    direct(row: Row, col: Col): Number;
    inverse(row: Row, col: Col): Number;
    invert(): Transform;
    /**
     * Builds and returns the composition of t with this transformation
     * That is: resM = t.M · this.M
     * @param t - the transformation to compose with
     */
    composeWith(t: AffineGeoMatrix): AffineGeoMatrix;
    private static fromMatrices;
    static byInverting(t: Transform): Transform;
    static fromTranslation(tx: number, ty: number, tz: number): Transform;
    static fromRotationX(a: number): Transform;
    static fromRotationY(a: number): Transform;
    static fromRotationZ(a: number): Transform;
    static fromScale(tx: number, ty: number, tz: number): Transform;
}
//# sourceMappingURL=transform.d.ts.map