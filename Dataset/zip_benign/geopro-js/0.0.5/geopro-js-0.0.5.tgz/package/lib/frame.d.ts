import { Point } from './point';
import { Vector } from './vector';
import { Matrix, GeoMatrix, Row, Col, InvertibleGroMatrix, AffineGeoMatrix } from './types';
/**
 * A frame of reference
 * @public
 */
export declare class Frame implements GeoMatrix, InvertibleGroMatrix {
    private _direct;
    private _inverse;
    /**
     * Build a frame directly with 2 matrices
     * @param dir - Direct matrix
     * @param inv - its inverse
     * @internal
     */
    private static fromMatrices;
    /**
     * Build an Identity frame, center in the origin and aligned
     * along the main three axes.
     */
    constructor();
    /**
     * Build a Frame throug an origin and 2 independent vector.
     * The first vector will be considered the Z direction
     * The second vector will point in the semi-space of x
     * @param o - origin point
     * @param v1 - a vector indicating the Z of the new frame
     * @param v2 - a vector in the XY plane of the new frame
     */
    static from2Vectors: (o: Point, v1: Vector, v2: Vector) => Frame;
    /**
     * Retrieve the matrix used to transform from this frame to
     * the global frame.
     */
    get directMatrix(): Matrix;
    /**
     * Retrieve the matrix used to transform from global frame
     * to this frame
     */
    get inverseMatrix(): Matrix;
    /**
     * Retrieve an element of the direct transformation matrix
     * @param row - row of the element to retrieve.
     * @param col - column of the element to retrieve.
     */
    direct(row: Row, col: Col): Number;
    /**
     * Retrieve an element of the inverse transformation matrix
     * @param row - row of the element to retrieve.
     * @param col - column of the element to retrieve.
     */
    inverse(row: Row, col: Col): Number;
    /**
     * The i vector for this frame
     */
    get i(): Vector;
    /**
     * The j vector for this frame
     */
    get j(): Vector;
    /**
     * The k vector for this frame
     */
    get k(): Vector;
    /**
     * The origin of this frame
     */
    get origin(): Point;
    /**
     * Invert the transformation defined for this frame.
     */
    invert(): GeoMatrix;
    /**
     * Builds and returns the composition of t with the
     * transformation represented by this frame.
     * This can be use to transform a frame to another
     * by using simple transformations.
     * That is: resM = t.M · this.M
     * @param t - the transformation to compose with
     */
    composeWith(t: AffineGeoMatrix): AffineGeoMatrix;
}
//# sourceMappingURL=frame.d.ts.map