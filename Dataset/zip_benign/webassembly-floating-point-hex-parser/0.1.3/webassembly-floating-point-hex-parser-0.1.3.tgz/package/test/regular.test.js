const parse = require( process.env.NODE_ENV === 'PRODUCTION' ? '../src/' : '../lib/' );

test('Positive values should be parsed correctly', () => {

	expect(parse('0x1')).toBe(1);
	expect(parse('0x1p-1')).toBe(0.5);
	expect(parse('0x1p1')).toBe(2);
	expect(parse('0x1p+8')).toBe(256);
	expect(parse('0x1p-6')).toBe(0.015625);
	expect(parse('0x1.b7p-1')).toBe(0.857421875);
	expect(parse('0X1.921FB4D12D84AP+1')).toBe(3.1415926);
	expect(parse('0x1.999999999999ap-4')).toBe(0.1);

	expect(parse('0x1.921fb54442d18p+2')).toBe(6.283185307179586);
	expect(parse('0x0.0000000000001p-1022')).toBe(5e-324);
	expect(parse('0x1p-1022')).toBe(2.2250738585072014e-308);
	expect(parse('0x0.fffffffffffffp-1022')).toBe(2.225073858507201e-308);
	expect(parse('0x1.fffffffffffffp+1023')).toBe(1.7976931348623157e+308);
	expect(parse('0x1.p100')).toBe(1.2676506002282294e+30);

});

test('Should return the same value for equivalent inputs', () => {
	expect(parse('0x1.999999999999ap-4')).toBe(parse('0x3.3333333333334p-5'));
	expect(parse('0xcc.ccccccccccdp-11')).toBe(parse('0x1.999999999999ap-4'));
});

test('Zeros should be parsed with correct sign', () => {

	expect(parse('-0x0p0')).toBe(-0);
	expect(parse('+0x0p-4')).toBe(+0);
	expect(parse('-0x0')).toBe(-0);
	expect(parse('-0x0.0p0')).toBe(-0);
	expect(parse('-0x0.p0')).toBe(-0);
	expect(parse('+0x0p0')).toBe(+0);
	expect(parse('+0x0')).toBe(+0);
	expect(parse('+0x0p36')).toBe(+0);
	expect(parse('+0x0.0p0')).toBe(+0);
	expect(parse('+0x0.p0')).toBe(+0);

});

test('Negative values should be parsed correctly', () => {
	
	expect(parse('-0x0.1p4')).toBe(-1);
	expect(parse('-0x1.1')).toBe(-1.0625);
	expect(parse('-0x0.1')).toBe(-0.0625);
	expect(parse('-0x1')).toBe(-1);
	expect(parse('-0x1p-1')).toBe(-0.5);
	expect(parse('-0x1p1')).toBe(-2);
	expect(parse('-0x1p+8')).toBe(-256);
	expect(parse('-0x1p-6')).toBe(-0.015625);
	expect(parse('-0x1.b7p-1')).toBe(-0.857421875);
	expect(parse('-0X1.921FB4D12D84AP+1')).toBe(-3.1415926);
	expect(parse('-0x1.999999999999ap-4')).toBe(-0.1);
	expect(parse('-0x1.921fb54442d18p+2')).toBe(-6.283185307179586);
	expect(parse('-0x0.0000000000001p-1022')).toBe(-5e-324);
	expect(parse('-0x1p-1022')).toBe(-2.2250738585072014e-308);
	expect(parse('-0x0.fffffffffffffp-1022')).toBe(-2.225073858507201e-308);
	expect(parse('-0x1.fffffffffffffp+1023')).toBe(-1.7976931348623157e+308);
	expect(parse('-0x1.p100')).toBe(-1.2676506002282294e+30);

});

test('Compensated overflow in exponent', () => {

	expect(parse('0x1p-1074')).toBe(5e-324);

});
