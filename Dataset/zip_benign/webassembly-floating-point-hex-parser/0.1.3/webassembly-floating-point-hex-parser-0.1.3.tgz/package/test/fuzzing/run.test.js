const { execFileSync } = require('child_process');
const path = require('path');
const parse = require('../../lib/index.js');
const numberOfRuns = process.env.FUZZ_AMOUNT ? parseInt(process.env.FUZZ_AMOUNT) : 100;

test('Should behave like "printf" from C', () => {

	for(let i = 1; i < numberOfRuns; ++i) {
		const output = execFileSync( path.resolve('./test/fuzzing/parse.out'), [ i ], { encoding: 'utf8' } );
		const [ arg, result ] = output.split(' ');
		expect( parse(arg) ).toBe( parseFloat(result) );
	}

});
