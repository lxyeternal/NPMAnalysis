function Watermark() {
    //默认设置
    this.defaultSettings={
        watermark_el: document.body,//水印载体 默认Body
        watermark_marktype: 1,//水印类型 1-文字 2-图片 
        watermark_txt:"水印默认样式展示",//水印文字
        watermark_type: 'single', //水印类型 单个-single 平铺-tile
        watermark_x:'50%',//单个水印x轴坐标
        watermark_y:"50%",//单个水印Y轴坐标
        watermark_start_x:10,//水印起始位置x轴坐标
        watermark_start_y:10,//水印起始位置Y轴坐标
        watermark_rows:100,//水印行数
        watermark_cols:100,//水印列数
        watermark_x_space:10,//水印x轴间隔
        watermark_y_space:10,//水印y轴间隔
        watermark_color:'#000',//水印字体颜色
        watermark_alpha:0.5,//水印透明度
        watermark_fontsize:20,//水印字体大小
        watermark_fontweight:400,//水印字体字重
        watermark_fontstyle:'nomal',//水印字体倾斜
        watermark_font:'微软雅黑',//水印字体
        watermark_angle:30,//水印倾斜度数
        watermark_src: "",//图片水印src  
        watermark_scale:1,//水印图片缩放  
        watermark_hidden:1,//隐形水印 1开启 2关闭
        watermark_hidden_text:'版权所有 盗版必究',//隐形水印文字 
    }
    this.initOption(arguments)
}
//初始化
Watermark.prototype.initOption = function(argument){
    //采用配置项替换默认值
    if(argument.length===1&&typeof argument[0] ==="object" ){
      var src=argument[0]||{}
      for(let key in src){
        if(src[key]&&this.defaultSettings[key]&&src[key]===this.defaultSettings[key])
        continue
        else if(src[key])
        this.defaultSettings[key]=src[key]
      }
    }
    //检测载体
    if(!this.defaultSettings.watermark_el){
        return 
    }
    //是否开启隐形水印
    if(this.defaultSettings.watermark_hidden === 1){
        this.InvisibleWatermark()
    }
    if(this.defaultSettings.watermark_hidden === 2){
        this.defaultSettings.watermark_el.style.background= 'none'
    }
    //获取宽高
    this.getWidthHeight()
}
//文字水印
Watermark.prototype.TextWatermark = function(){
    const ol = this.defaultSettings
    const parTemp = ol.watermark_el
    //创建虚拟文档 性能优化
    var oTemp = document.createDocumentFragment()
    //单个水印
    if(ol.watermark_type === 'single'){
        var mask_div = document.createElement('div')
        var mask_span = document.createElement('span')
        //设置div样式
        mask_div.className = 'mask_div00'
        mask_div.style.display = 'flex'
        mask_div.style.alignItems = 'center'
        mask_div.style.justifyContent = 'center'
        mask_div.style.position = "absolute"
        mask_div.style.width = ol.originW + 'px'
        mask_div.style.height = ol.originH + 'px'
        if(String(ol.watermark_x).includes('%')){
            mask_div.style.left = ol.watermark_x
        }else{
            mask_div.style.left = ol.watermark_x + 'px'
        }
        if(String(ol.watermark_y).includes('%')){
            mask_div.style.top = ol.watermark_y
        }else{
            mask_div.style.top = ol.watermark_y + 'px'
        }
        mask_div.style.opacity = ol.watermark_alpha
        mask_div.style.webkitTransform = "translate(-50%, -50%)"
        mask_div.style.MozTransform = "translate(-50%, -50%)"
        mask_div.style.msTransform = "translate(-50%, -50%)"
        mask_div.style.OTransform = "translate(-50%, -50%)"
        mask_div.style.transform = "translate(-50%, -50%)"
        mask_div.style.overflow = "hidden"
        mask_div.style.zIndex = "999"
        mask_div.style.pointerEvents='none'//pointer-events:none  让水印不遮挡页面的点击事件
        //设置span样式
        mask_span.appendChild(document.createTextNode(ol.watermark_txt))
        mask_span.style.visibility = "visible"
        mask_span.style.whiteSpace = "nowrap"
        mask_span.style.pointerEvents='none'//pointer-events:none  让水印不遮挡页面的点击事件
        mask_span.style.fontSize = ol.watermark_fontsize + 'px'
        mask_span.style.lineHeight = ol.watermark_fontsize + 'px'
        mask_span.style.fontWeight = ol.watermark_fontweight
        mask_span.style.fontStyle = ol.watermark_fontstyle
        mask_span.style.fontFamily = ol.watermark_font
        mask_span.style.color = ol.watermark_color
        mask_span.style.textAlign = "center"
        mask_span.style.webkitTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_span.style.MozTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_span.style.msTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_span.style.OTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_span.style.transform = "rotate(" + ol.watermark_angle + "deg)"
        mask_span.style.display = "block"
        mask_div.appendChild(mask_span)
        oTemp.appendChild(mask_div)
    }
    //平铺水印
    if(ol.watermark_type === 'tile'){
        var x
        var y
        for (var i = 0 ;i < ol.watermark_rows; i++) {
            y = ol.watermark_start_y + (ol.watermark_y_space + ol.originH) * i
            for (var j = 0; j < ol.watermark_cols ;j++) {
                x = ol.watermark_start_x + (ol.originW + ol.watermark_x_space) * j
                var mask_div = document.createElement('div')
                var mask_span = document.createElement('span')
                mask_div.id = 'mask_div' + i + j
                mask_div.className = 'mask_div'
                mask_div.style.display = 'flex'
                mask_div.style.alignItems = 'center'
                mask_div.style.justifyContent = 'center'
                mask_span.appendChild(document.createTextNode(ol.watermark_txt))
                //设置水印div倾斜显示
                mask_span.style.webkitTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_span.style.MozTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_span.style.msTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_span.style.OTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_span.style.transform = "rotate(" + ol.watermark_angle + "deg)"
                mask_span.style.transformOrigin = "center"
                mask_span.style.visibility = ""
                mask_span.style.whiteSpace = "nowrap"
                mask_div.style.position = "absolute"
                mask_div.style.width = ol.originW + 'px'
                mask_div.style.height = ol.originH + 'px'
                mask_div.style.left = x + 'px'
                mask_div.style.top = y + 'px'
                mask_div.style.overflow = "hidden"
                mask_div.style.zIndex = "999"
                mask_div.style.pointerEvents='none'//pointer-events:none  让水印不遮挡页面的点击事件
                mask_span.style.opacity = ol.watermark_alpha
                mask_span.style.fontSize = ol.watermark_fontsize + 'px'
                mask_span.style.lineHeight = ol.watermark_fontsize + 'px'
                mask_span.style.fontWeight = ol.watermark_fontweight
                mask_span.style.fontStyle = ol.watermark_fontstyle
                mask_span.style.fontFamily = ol.watermark_font
                mask_span.style.color = ol.watermark_color
                mask_span.style.textAlign = "center"
                mask_span.style.display = "inline-block"
                mask_div.appendChild(mask_span)
                oTemp.appendChild(mask_div)
            }
        }
    }
    parTemp.appendChild(oTemp)
}
//图片水印
Watermark.prototype.PictureWatermark = function(){
    const ol = this.defaultSettings
    const parTemp = ol.watermark_el
    //创建虚拟文档 性能优化
    var oTemp = document.createDocumentFragment()
    
    //单个水印
    if(ol.watermark_type === 'single'){
        var mask_div = document.createElement('div')
        var mask_img = document.createElement('img')
        //设置div样式
        mask_div.className = 'mask_div00'
        mask_div.style.display = 'flex'
        mask_div.style.alignItems = 'center'
        mask_div.style.justifyContent = 'center'
        mask_div.style.position = "absolute"
        mask_div.style.width = ol.originW * ol.watermark_scale + 'px'
        mask_div.style.height = ol.originH * ol.watermark_scale + 'px'
        if(String(ol.watermark_x).includes('%')){
            mask_div.style.left = ol.watermark_x
        }else{
            mask_div.style.left = ol.watermark_x + 'px'
        }
        if(String(ol.watermark_y).includes('%')){
            mask_div.style.top = ol.watermark_y
        }else{
            mask_div.style.top = ol.watermark_y + 'px'
        }
        mask_div.style.overflow = "hidden"
        mask_div.style.zIndex = "999"
        mask_div.style.pointerEvents='none'//pointer-events:none  让水印不遮挡页面的点击事件
        mask_div.style.opacity = ol.watermark_alpha
        mask_div.style.webkitTransform = "translate(-50%, -50%)"
        mask_div.style.MozTransform = "translate(-50%, -50%)"
        mask_div.style.msTransform = "translate(-50%, -50%)"
        mask_div.style.OTransform = "translate(-50%, -50%)"
        mask_div.style.transform = "translate(-50%, -50%)"
        //设置img样式
        mask_img.src = ol.watermark_src
        mask_img.style.display = "block"
        mask_img.style.webkitTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_img.style.MozTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_img.style.msTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_img.style.OTransform = "rotate(" + ol.watermark_angle + "deg)"
        mask_img.style.transform = "rotate(" + ol.watermark_angle + "deg)"
        mask_img.style.transformOrigin = "center"
        mask_img.style.width =  ol.width * ol.watermark_scale + 'px'
        mask_img.style.height =  ol.height * ol.watermark_scale + 'px'
        mask_div.appendChild(mask_img)
        oTemp.appendChild(mask_div)
    }
    //平铺水印
    if(ol.watermark_type === 'tile'){
        var x
        var y
        for (var i = 0 ;i < ol.watermark_rows ;i++) {
            y = ol.watermark_start_y + (ol.watermark_y_space + ol.originH * ol.watermark_scale) * i
            for (var j = 0 ;j < ol.watermark_cols ;j++) {
                x = ol.watermark_start_x + (ol.originW * ol.watermark_scale + ol.watermark_x_space) * j 
                var mask_div = document.createElement('div')
                var mask_img = document.createElement('img')
                //设置div样式
                mask_div.className = 'mask_div'+ i + j
                mask_div.style.display = 'flex'
                mask_div.style.alignItems = 'center'
                mask_div.style.justifyContent = 'center'
                mask_div.style.position = "absolute"
                mask_div.style.width = ol.originW * ol.watermark_scale + 'px'
                mask_div.style.height = ol.originH * ol.watermark_scale + 'px'
                mask_div.style.left = x + 'px'
                mask_div.style.top = y + 'px'
                mask_div.style.overflow = "hidden"
                mask_div.style.zIndex = "999"
                mask_div.style.pointerEvents='none'//pointer-events:none  让水印不遮挡页面的点击事件
                mask_div.style.opacity = ol.watermark_alpha
                //设置img样式
                mask_img.src = ol.watermark_src
                mask_img.style.display = "block"
                mask_img.style.webkitTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_img.style.MozTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_img.style.msTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_img.style.OTransform = "rotate(" + ol.watermark_angle + "deg)"
                mask_img.style.transform = "rotate(" + ol.watermark_angle + "deg)"
                mask_img.style.transformOrigin = "center"
                mask_img.style.width =  ol.width * ol.watermark_scale + 'px'
                mask_img.style.height =  ol.height * ol.watermark_scale + 'px'
                mask_div.appendChild(mask_img)
                oTemp.appendChild(mask_div)
            }
        }
    }
    parTemp.appendChild(oTemp)
}
//隐形水印
Watermark.prototype.InvisibleWatermark = function(){
    if(this.defaultSettings.watermark_el.style.background){
        return false
    }
    var mask_span = document.createElement('span')
    mask_span.appendChild(document.createTextNode(this.defaultSettings.watermark_hidden_text))
    mask_span.id = "text"
    mask_span.style.fontSize = 12 + 'px'
    mask_span.style.lineHeight = 12 + 'px'
    document.body.appendChild(mask_span)
    const width = document.getElementById('text').offsetWidth + 20
    const height = document.getElementById('text').offsetHeight + 20
    document.body.removeChild(mask_span)
    //创建svg
    //创建svg
    const svgStr = `<svg
                        width="${width}"
                        height="${height}"
                        xmlns="http://www.w3.org/2000/svg" version="1.1">
                    <text
                        x="50%" y="50%"
                        text-anchor="middle"
                        fill="rgba(127,127,127,.1)" 
                        style="opacity:.1;font-family:-apple-system,system-ui,BlinkMacSystemFont,Helvetica Neue,PingFang SC,Hiragino Sans GB,Microsoft YaHei,Arial,sans-serif;font-size:12px;font-weight:400;">${this.defaultSettings.watermark_hidden_text}</text>
                </svg>`;
  const base64Url = `data:image/svg+xml;base64,${window.btoa(unescape(encodeURIComponent(svgStr)))}`;
  this.defaultSettings.watermark_el.style.background= 'URL(' + base64Url + ')'
}

//获取宽高
Watermark.prototype.getWidthHeight = function(){
    const ol = this.defaultSettings
    //文字
    if(ol.watermark_marktype === 1){
        //创建文字demo 获取宽高
        var mask_span = document.createElement('span')
        mask_span.appendChild(document.createTextNode(ol.watermark_txt))
        mask_span.id = "mask_span_demo"
        mask_span.style.fontSize = ol.watermark_fontsize + 'px'
        mask_span.style.lineHeight = ol.watermark_fontsize + 'px'
        document.body.appendChild(mask_span)
        ol.width = document.getElementById('mask_span_demo').offsetWidth
        ol.height = document.getElementById('mask_span_demo').offsetHeight
        document.body.removeChild(mask_span)
        this.CalculateRC()
    }
    //图片
    if(ol.watermark_marktype === 2){
        this._getImageOriginSize(ol.watermark_src).then(({width,height})=>{
            ol.width = width
            ol.height = height
            this.CalculateRC()
        })
    }
}

//重新计算行列数
Watermark.prototype.CalculateRC = function(){
    const ol = this.defaultSettings
    const parTemp = ol.watermark_el
    //获取页面最大宽度
    var page_width = Math.max(parTemp.scrollWidth,parTemp.clientWidth)
    //获取页面最大高度
    var page_height = Math.max(parTemp.scrollHeight,parTemp.clientHeight)

    ol.originW = ol.width
    ol.originH = ol.height
    var angle = Math.abs(ol.watermark_angle)
    if( angle > 0){
        ol.originW = (ol.height * Math.sin(angle * Math.PI/180.0)) + (ol.width * Math.cos(angle * Math.PI/180.0))
        ol.originH = (ol.height * Math.cos(angle * Math.PI/180.0)) + (ol.width * Math.sin(angle * Math.PI/180.0))
    }
    //计算水印列数
    if (ol.watermark_cols == 0 || (parseInt((ol.originW + ol.watermark_x_space) * ol.watermark_cols) > page_width)) {
        ol.watermark_cols = Math.ceil(page_width / (ol.originW + ol.watermark_x_space)) - 0
    }
    //计算水印行数
    if (ol.watermark_rows == 0 || (parseInt((ol.originH + ol.watermark_y_space) * ol.watermark_rows) > page_height)) {
        ol.watermark_rows = Math.ceil(page_height / (ol.originH + ol.watermark_y_space)) - 0
    }
    //文字
    if(this.defaultSettings.watermark_marktype === 1){
        this.TextWatermark()
    }
    //图片
    if(this.defaultSettings.watermark_marktype === 2){
        this.PictureWatermark()
    }
}

//获取图片宽高
Watermark.prototype._getImageOriginSize = function(src){
    return new Promise(resolve => {
        const image = new Image()
        image.src = src
        image.onload = function () {
            const { width, height } = image
            resolve({width,height})
        }
    })
}