const path = require('path');
const webpack = require('webpack');
let pkg = require('../package.json');
module.exports = {
  mode: 'production',
  entry: './src/watermark.js',
  output: {
    path: path.resolve(__dirname, '../dist'),
    filename: 'index.js',
    publicPath: '/dist/',
    library: 'storeWatermark',
    libraryTarget: 'umd',
    umdNamedDefine: true
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              '@babel/preset-env'
            ],
            plugins: [
              [
                '@babel/plugin-transform-runtime'
              ],
            ]
          }
        }
      }
    ]
  },
  plugins: [
    new webpack.BannerPlugin(`${[
      'Author:' + '' + pkg.author,
      'Version:' + '' + pkg.version,
      'Date:' + '' + new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString(),
    ].join('\n')}`),
  ]
};
