# watermark-web
watermark.watermark.js是基于Dom对象实现的打水印系统，有文字和图片两种模式。水印采用动态计算，可实时更新属性并重新添加，水印dom外层设有保护dom，实时计算最小宽高，防止水印重叠。

# api

|属性    | 说明  | 默认值  | 可选  | 备注  |
| ------------ | ------------ | ------------ | ------------ | ------------ |
| watermark_el | 水印载体  | document.body  | document.body 或 document.getElementById(id)  | 水印载体，默认Body  |
| watermark_marktype | 水印类型 |  1 |  1 或 2 |  1-文字 2-图片 |
|  watermark_type | 水印添加形式 |  single | single 或 tile  |  single-单个 tile-平铺 |
|  watermark_txt |  水印文字 | 我是水印  | 可编辑 |  |
|  watermark_x | 水印起始位置x轴坐标  |  10 |  可编辑 |  |
|  watermark_y | 水印起始位置Y轴坐标  | 10  |  可编辑 |  |
|  watermark_rows | 水印行数 |  100 |   | 自动计算 |
| watermark_cols  | 水印列数  | 100  |   | 自动计算 |
| watermark_x_space  |  x轴间隔 | 10  |  可编辑 |  |
| watermark_y_space  | y轴间隔  |  10 | 可编辑  |  |
| watermark_color  | 字体颜色  |  #000 | 可编辑  |  |
| watermark_alpha  | 透明度  |  0.5 | 可编辑  |  |
| watermark_fontsize  | 字体大小  |  15 | 可编辑  |  |
| watermark_fontweight  | 字体字重 | 400 |  可编辑  |   |
| watermark_fontstyle  | 字体样式  |  nomal | normal 或 itality  |  |
| watermark_font  | 字体  |  微软雅黑 | 可编辑  |  |
| watermark_angle  | 倾斜度数  |  30 | 可编辑  |  |
| watermark_src  | 图片链接  |  none | 可编辑  |  |
| watermark_scale  | 图片缩放  |  原始大小 | 可编辑  | 0.5-5 |
| watermark_hidden  | 隐形水印  |  1 | 1 或 2  | 1-开启 2-关闭 |
| watermark_hidden_text  | 隐形水印文字  |  版权所有 盗版必究 | 可编辑 |  |
