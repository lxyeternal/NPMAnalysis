declare const useFetchMediaType: (url?: string, sourceUrl?: string) => {
    fetchFinalURL: () => Promise<void>;
    mediaType: string | null;
    finalURL: string | null;
    mediaUrl: string | undefined;
    isLoading: boolean;
};
export default useFetchMediaType;
