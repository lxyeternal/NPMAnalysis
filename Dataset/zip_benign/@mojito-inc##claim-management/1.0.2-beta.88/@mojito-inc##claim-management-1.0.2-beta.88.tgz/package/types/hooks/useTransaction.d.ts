import { TransactionDetailsProps } from '../providers/TransactionProvider';
interface TransactionProps {
    transactionDetails: TransactionDetailsProps;
    error: boolean;
    fetchInvoiceDetail: (invoice: string) => void;
}
declare function useTransaction(): TransactionProps;
export default useTransaction;
