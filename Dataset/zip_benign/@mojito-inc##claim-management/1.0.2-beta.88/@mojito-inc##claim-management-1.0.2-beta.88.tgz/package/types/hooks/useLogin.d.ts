interface Configuration {
    chainId: number;
    crossmintApiKey?: string;
    orgId: string;
}
interface LoginParam {
    getSignature: (walletAddress: string, networkId: string) => Promise<string | undefined>;
    login: (signatureMessage: string, crossMintSignature: string, chainId: number, address: string, firstName?: string, lastName?: string, email?: string, loginWithPersonalInformation?: boolean) => Promise<string | undefined>;
}
declare const useLogin: (config: Configuration) => LoginParam;
export default useLogin;
