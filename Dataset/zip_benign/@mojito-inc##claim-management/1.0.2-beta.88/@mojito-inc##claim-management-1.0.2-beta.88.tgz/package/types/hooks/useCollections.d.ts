import { CollectionItemByClaimCode, AuctionData } from '@mojito-inc/core-service';
export type CollectionsProps = {
    collectionDetailsById?: AuctionData;
    collectionDetailsByCode?: CollectionItemByClaimCode;
    errorMsg?: string;
    isLoading: boolean;
    fetchCollectionById: (id: string) => void;
    fetchCollectionByCode: (claimCode: string) => void;
};
declare function useCollections(): CollectionsProps;
export default useCollections;
