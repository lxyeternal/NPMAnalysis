import { WalletDetailsProps } from '../providers/WalletDetailsProvider';
declare function useWallet(): WalletDetailsProps;
export default useWallet;
