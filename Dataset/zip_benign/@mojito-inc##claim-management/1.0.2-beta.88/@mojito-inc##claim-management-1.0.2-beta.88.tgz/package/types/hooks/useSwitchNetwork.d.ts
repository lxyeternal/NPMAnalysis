import { SupportedChainIDs } from '../providers/WalletDetailsProvider';
declare const useSwitchNetwork: () => {
    switchChain: (id: SupportedChainIDs) => void;
    switchStatus: "switch" | "switching" | "switched";
};
export default useSwitchNetwork;
