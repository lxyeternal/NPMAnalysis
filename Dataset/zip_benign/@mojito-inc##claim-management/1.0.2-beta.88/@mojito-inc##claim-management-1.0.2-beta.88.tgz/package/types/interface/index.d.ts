import { CSSProperties, ReactElement } from 'react';
import { WalletOptionsProps } from '../components/ConnectExistingWallet';
import { ContentData } from '../components/EnterCodeContainer';
import { PayWithGasContentProps } from '../components/PayWithGasContainer';
import { NftContentDetails } from '../components/NftAttributes';
export declare enum ClaimContainerType {
    CONNECT_WALLET = "CONNECT_WALLET",
    ENTER_CODE = "ENTER_CODE",
    LOADING = "LOADING",
    SUCCESS = "SUCCESS",
    OTP = "OTP",
    ERROR = "ERROR",
    EXISTING_WALLET = "EXISTING_WALLET",
    RECOVERY_CODE = "RECOVERY_CODE",
    CHECK_TOKEN_GATING = "CHECK_TOKEN_GATING",
    NOT_ELIGIBLE_TOKEN_GATING = "NOT_ELIGIBLE_TOKEN_GATING",
    PAY_WITH_GAS = "PAY_WITH_GAS",
    CLAIM_ERROR = "CLAIM_ERROR",
    CLAIM_CODE_ERROR = "CLAIM_CODE_ERROR"
}
export interface ContentUpdateProps {
    title?: string;
    description?: string;
    seriesName?: string;
    CTA?: string;
}
export interface CopyUpdateProps {
    title?: string;
    description?: string;
    CTA?: string;
}
export interface ContentUpdateTokenGatingNotEligibleProps {
    description?: string;
    walletLimitReachedError?: string;
    notEligibleError?: string;
    pendingTransactionError?: string;
}
export interface ClaimErrorContentProps {
    title?: string;
}
interface ContentProps {
    ClaimCodeContent?: ContentData;
    SuccessContent?: ContentData;
    ConnectWalletContent?: ContentData;
    LoaderContent?: ContentUpdateProps;
    RecoveryCodeModal?: {
        description?: string;
    };
    TokenGatingContent?: ContentUpdateProps;
    TokenGatingNotEligibleContent?: ContentUpdateTokenGatingNotEligibleProps;
    ClaimWithGasContent?: PayWithGasContentProps;
    ClaimErrorContent?: ClaimErrorContentProps;
}
interface LinkProps {
    logoUrl?: string;
    termsUrl: string;
    privacyUrl?: string;
    additionalTermsUrl?: string;
    viewTokenTrackerURL?: boolean;
    doNotHaveWalletURL?: string;
}
export interface ClaimModalLayoutProps {
    open: boolean;
    claimStatus: string;
    currentModalState: ClaimContainerType;
    code: string;
    error: string;
    inValidCode?: string | null;
    address: string;
    isEnterClaimCode?: boolean;
    email: string;
    otp: string;
    loaderTitle: string;
    loaderDescription: string;
    recoveryCode: string;
    walletOptions: WalletOptionsProps;
    tokenTrackerURL: string;
    checked: boolean;
    termsUrl: string;
    showLoader: boolean;
    logoUrl?: string;
    viewTokenTrackerURL?: boolean;
    additionalTermsUrl?: string;
    privacyUrl?: string;
    content?: ContentProps;
    tokenName?: string;
    tokenGatingName?: string;
    tokenGatingError?: string;
    showDisconnectButton?: boolean;
    showBuyButton?: boolean;
    isTokenGating?: boolean;
    price?: string;
    validation?: 'clear' | 'no_balance' | 'wrong_network';
    networkName?: string;
    currency?: string;
    isTermsDisabled?: boolean;
    showRefreshIcon?: boolean;
    onClickSwitchNetwork: () => void;
    onClickDoNotHaveWallet: () => void;
    onChangeCheck: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeEmail: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeCode: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeRecoveryCode: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeOTP: (event: string) => void;
    onClickMetamask: () => void;
    onClickWalletConnect: () => void;
    onClickCrossmint: () => void;
    onClickContinueWithEmail: () => void;
    onClickRecoveryCode: () => void;
    onClickExistingWallet: () => void;
    onClickClaimNow: () => void;
    onCloseModal: () => void;
    handleSuccessRedirection?: () => void;
    handleRetry: () => void;
    onClickBreadcrumb: (event: string) => void;
    onClickContinueCheckToken: () => void;
    onClickBuyToken?: () => void;
    onClickDisconnectWallet: () => void;
    onClickClaimWithGas: () => void;
    onClickContinueWithGoogle: () => void;
    onClickRefreshIcon: () => void;
}
export interface ClaimConfiguration {
    chainId: number;
    crossmintApiKey?: string;
    orgId: string;
    crossmintEnv?: string;
    paperClientId?: string;
    paperNetworkName?: any;
}
export interface BalanceData {
    native: number;
    nonNative: number;
}
export interface SupportedNetworksData {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
interface TokenGatingConfigProps {
    groupId: string;
    ruleId: string;
}
export declare enum SaleType {
    TokenGating = "TokenGating",
    SkipTokenGating = "SkipTokenGating",
    CustomCode = "CustomCode",
    NoCode = "NoCode",
    BuyNow = "BuyNow"
}
export interface WalletOptionsMixersProps {
    enableMetamask: boolean;
    enableWalletConnect: boolean;
    enableEmailWallet: boolean;
}
export interface PaymentOptionsProps {
    creditCard?: boolean;
    walletConnect?: boolean;
    wire?: boolean;
}
export interface ClaimTokenModalWithoutMixersProps {
    open: boolean;
    firstName?: string;
    lastName?: string;
    userEmail?: string;
    loginWithPersonalInformation?: boolean;
    claimCode?: string;
    listingId?: string;
    isDisConnect: boolean;
    config: ClaimConfiguration;
    tokenGatingConfig?: TokenGatingConfigProps;
    link: LinkProps;
    content?: ContentProps;
    skipClaimModal?: boolean;
    skipSuccessModal?: boolean;
    skipConfirmClaimModal?: boolean;
    isPaperWallet?: boolean;
    tokenName?: string;
    showDisconnectButton?: boolean;
    showBuyButton?: boolean;
    price?: string;
    isClaimWithGas?: boolean;
    claimType: 'TokenGating' | 'SkipTokenGating' | 'CustomCode' | 'NoCode' | 'BuyNow';
    isTermsDisabled?: boolean;
    skipNetworkValidationOnConnect?: boolean;
    mixersConfig?: {
        lotId: string;
        walletOptions: WalletOptionsMixersProps;
        paymentId?: string;
        discountCode?: string;
        paymentOptions: PaymentOptionsProps;
        checkOutApiKey?: string;
        errorPageUrl: string;
        successPageUrl: string;
        invoiceId?: string;
        isWeb2Login?: boolean;
        skipSignature?: boolean;
        breadCrumbs?: string[];
        isAutoFillCountryCode?: boolean;
        onClickGoToMarketPlace?: () => void;
    };
    onCloseModal: () => void;
    onSuccess?: () => void;
    onClickBuyToken?: () => void;
}
export type BuyNowClaimTokenModalProps = Omit<ClaimTokenModalWithoutMixersProps, 'mixersConfig'> & {
    mixersConfig: {
        lotId: string;
        walletOptions: WalletOptionsMixersProps;
        paymentId?: string;
        discountCode?: string;
        paymentOptions: PaymentOptionsProps;
        checkOutApiKey?: string;
        errorPageUrl: string;
        successPageUrl: string;
        invoiceId?: string;
        isWeb2Login?: boolean;
        skipSignature?: boolean;
        onClickGoToMarketPlace?: () => void;
    };
    claimType: 'BuyNow';
};
export type ClaimTokenModalProps = ClaimTokenModalWithoutMixersProps | BuyNowClaimTokenModalProps;
export type ButtonNameProps = {
    primary: string;
    secondary: string;
    teritary: string;
};
export type VideoAttributes = {
    controls?: boolean;
    muted?: boolean;
    loop?: boolean;
    playsInline?: boolean;
    autoPlay?: boolean;
    layoutSize?: string;
};
export type MediaContainerProps = {
    url: string;
    width?: string;
    height?: string;
    style?: CSSProperties;
    sourceUrl?: string;
    placeholderImage?: string;
    enableCardVideo?: boolean;
    videoAttributes?: VideoAttributes;
};
export type MediaContent = {
    width?: string;
    isPoweredBy?: boolean;
    height?: string;
    style?: CSSProperties;
    enableCardVideo?: boolean;
    sourceUrl?: string;
    moreInfo?: boolean;
    mediaOnly?: boolean;
    videoAttributes?: VideoAttributes;
};
export type ClaimTokenCodeLayoutProps = {
    buttonName?: string;
    width?: string;
    contentDetails?: NftContentDetails;
    customErrorTemplate?: ReactElement | string | null;
    error?: string;
    isLoading?: boolean;
    mediaContent?: MediaContent;
    mediaOnly?: boolean;
    moreInfo?: boolean;
    isPoweredBy?: boolean;
    customErrorEnabled?: boolean;
    onClickClaim?: (listingId: string) => void;
};
export type ClaimTokenCodeProp = {
    loader?: ReactElement | string;
    customErrorTemplate?: ReactElement | string;
    claimCode: string;
    buttonName: ButtonNameProps;
    mediaOnly?: boolean;
    moreInfo?: boolean;
    customErrorEnabled?: boolean;
    mediaContent?: MediaContent;
    width?: string;
    onClickClaim: (listingId: string) => void;
};
export interface MetaData {
    name: string;
    description: string;
    url: string;
    icons: string[];
}
export interface CheckoutContainerProps {
    show: boolean;
    success?: boolean;
    token?: string;
    email?: string;
    logoUrl?: string;
    config?: ClaimConfiguration;
    mixersConfig?: {
        lotId: string;
        walletOptions: WalletOptionsMixersProps;
        paymentId?: string;
        discountCode?: string;
        paymentOptions: PaymentOptionsProps;
        checkOutApiKey?: string;
        errorPageUrl: string;
        successPageUrl: string;
        invoiceId?: string;
        isWeb2Login?: boolean;
        skipSignature?: boolean;
        breadCrumbs?: string[];
        isAutoFillCountryCode?: boolean;
    };
    listingId?: string;
    walletDetails?: any;
    uri?: string;
    walletConnectProjectId?: string;
    clientId?: string;
    paymentId?: string;
    activeChain?: 'ethereum' | 'polygon' | 'goerli' | 'mumbai' | 'sepolia' | 'base-sepolia-testnet' | 'base';
    disconnect?: () => void;
    refetchBalance?: () => void;
    onClickConnectWallet?: () => void;
    onClickGoToMarketPlace?: () => void;
}
export interface PaymentMixersSuccessProps {
    onClickGoToMarketPlace: () => void;
}
export {};
