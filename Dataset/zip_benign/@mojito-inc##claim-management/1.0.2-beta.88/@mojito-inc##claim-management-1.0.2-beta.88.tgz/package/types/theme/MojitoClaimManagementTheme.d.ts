export interface MojitoClaimManagementTheme {
    font: {
        primary: string;
        secondary: string;
        tertiary: string;
    };
    Header?: {
        background?: string;
    };
    Footer?: {
        background?: string;
        color?: string;
    };
    Hero?: {
        background?: string;
        color?: string;
    };
    Discount?: {
        inProgressColor: string;
        inProgressBackground: string;
    };
    delivery?: {
        textColor?: string;
        tokenTrackerColor?: string;
    };
    error?: string;
    success?: string;
    linkColor?: string;
    deliveryBackgroundColor?: string;
    textTertiary?: string;
    borderColor?: string;
    claimTokenCode?: {
        mobileTitleSize?: string;
        desktopTitleSize?: string;
        claimTokenImg?: {
            maxHeight?: string;
            maxWidth?: string;
        };
    };
}
