export declare enum ClaimErrors {
    RECORD_NOT_FOUND = "record not found",
    CODE_REDEEMED = "code redeemed",
    LIMIT_REACHED = "redeeming limit reached",
    RECOVERY_CODE = "Invalid recovery",
    ALL_CLAIMED = "total available units: 0",
    TOKEN_GATING_CLAIMED = "The given gating rule is already processing/completed"
}
export declare const RPC_URL: {
    1: string;
    5: string;
    80001: string;
    137: string;
};
export declare const emailRegex: RegExp;
export declare enum WalletProviderType {
    METAMASK = "Metamask",
    WALLET_CONNECT = "WalletConnect",
    EMAIL = "Email",
    CROSSMINT = "Crossmint"
}
export declare enum AuthTokenType {
    TOKEN = "Token",
    BEARER = "Bearer"
}
export declare const SessionVariable: {
    NetworkDetails: string;
    WalletDetails: string;
};
