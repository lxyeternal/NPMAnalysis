export declare const Images: {
    SUCCESS: string;
    COUPONS: string;
    METAMASK: string;
    CROSSMINT: string;
    WALLET_CONNECT: string;
    ERROR: string;
    MOJITO_LOGO: string;
    GOOGLE: string;
    POWERED_BY: string;
    SENTIMENT_EMOJI: string;
};
