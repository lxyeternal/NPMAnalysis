import React from 'react';
import { VideoAttributes } from '../interface';
export type CustomVideoPlayerProps = {
    sourceUrl: string;
    videoAttributes: VideoAttributes;
    onError: (error: Error) => void;
    playBtnEnabled: boolean;
};
export declare const CustomVideoPlayer: React.FC<CustomVideoPlayerProps>;
