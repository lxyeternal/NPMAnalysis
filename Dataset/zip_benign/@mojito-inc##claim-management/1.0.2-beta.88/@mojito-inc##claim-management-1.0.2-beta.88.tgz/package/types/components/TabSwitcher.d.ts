import * as React from 'react';
export interface TabSwitcherProps {
    value: string;
    children: React.ReactNode;
}
export interface TabPanelProps {
    id: string;
    children: React.ReactNode;
}
/**
 * This is TabPanel
 * @public
 */
declare const TabPanel: ({ id, children }: TabPanelProps) => React.JSX.Element;
/**
 * This is a TabSwitcher
 * @public
 */
declare const TabSwitcher: ({ value, children }: TabSwitcherProps) => React.JSX.Element;
export { TabSwitcher, TabPanel };
