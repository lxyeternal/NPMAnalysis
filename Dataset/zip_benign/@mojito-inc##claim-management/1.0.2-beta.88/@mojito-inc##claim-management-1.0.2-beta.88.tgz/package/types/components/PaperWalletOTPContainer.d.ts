import * as React from 'react';
import { ContentData } from './EnterCodeContainer';
export interface PaperWalletOTPContainerProps {
    content?: ContentData;
    email: string;
    otp: string;
    error?: string;
    logoUrl?: string;
    onClickRequestNewCode: () => void;
    onChangeOTP: (event: string) => void;
}
declare const PaperWalletOTPContainer: ({ content, email, otp, error, logoUrl, onChangeOTP, onClickRequestNewCode, }: PaperWalletOTPContainerProps) => React.JSX.Element;
export default PaperWalletOTPContainer;
