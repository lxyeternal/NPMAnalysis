import * as React from 'react';
interface ErrorContainerProps {
    errorMessage: string;
    handleRetry: () => void;
}
declare const ErrorContainer: ({ errorMessage, handleRetry }: ErrorContainerProps) => React.JSX.Element;
export default ErrorContainer;
