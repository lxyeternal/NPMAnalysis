import * as React from 'react';
import { ContentData } from './EnterCodeContainer';
export interface SuccessContainerProps {
    claimStatus: string;
    deliveryWallet: string;
    viewTokenTrackerURL?: boolean;
    tokenTrackerURL: string;
    content?: ContentData;
    showRefreshIcon?: boolean;
    onClickRefreshIcon?: () => void;
    onClickSuccess?: () => void;
}
declare const SuccessContainer: ({ claimStatus, deliveryWallet, viewTokenTrackerURL, tokenTrackerURL, content, showRefreshIcon, onClickRefreshIcon, onClickSuccess, }: SuccessContainerProps) => React.JSX.Element;
export default SuccessContainer;
