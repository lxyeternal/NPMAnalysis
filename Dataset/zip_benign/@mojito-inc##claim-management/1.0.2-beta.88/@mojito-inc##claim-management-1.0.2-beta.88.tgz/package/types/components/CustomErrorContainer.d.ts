import React from 'react';
export type CustomErrorContainerProps = {
    image?: any;
    errorMessage?: string;
    customErrorEnabled?: boolean;
};
declare const CustomErrorContainer: ({ image, errorMessage, customErrorEnabled }: CustomErrorContainerProps) => React.JSX.Element;
export default CustomErrorContainer;
