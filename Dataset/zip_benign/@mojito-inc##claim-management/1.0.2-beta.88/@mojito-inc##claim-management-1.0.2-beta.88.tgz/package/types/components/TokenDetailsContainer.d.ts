import * as React from 'react';
export interface TokenDetailsContainerProps {
    price: string;
    walletAddress: string;
    networkName: string;
}
declare const TokenDetailsContainer: ({ price, walletAddress, networkName }: TokenDetailsContainerProps) => React.JSX.Element;
export default TokenDetailsContainer;
