import React from 'react';
export type NFTAttributes = {
    traitType: string;
    traitValue: string;
};
export type NftContentDetails = {
    title?: string;
    listingName?: string;
    description?: string;
    image?: string;
    animationUrl?: string;
    tokenId?: string;
    tokenType?: string;
    networkName?: string;
    networkChainId: number;
    nftAttributes: NFTAttributes[];
    contractAddress: string;
    isClaimAvailable: boolean;
    id?: string;
    startDate?: string;
    endDate?: string;
    isSaleStarted: boolean;
    isSaleEnded: boolean;
} | undefined;
export declare const NftAttributes: ({ nftAttributes }: {
    nftAttributes: {
        traitType: string;
        traitValue: string;
    }[];
}) => React.JSX.Element;
export declare const NFTInfoContent: ({ content, value, isLink, nftContentDetails: NftData }: {
    content?: string;
    value?: string;
    isLink?: boolean;
    nftContentDetails?: NftContentDetails;
}) => React.JSX.Element;
