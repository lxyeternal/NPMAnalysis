import * as React from 'react';
import { type SxProps } from '@mui/material/styles';
export interface BreadcrumbItem {
    label: string;
    value: string;
}
export interface BreadcrumbsProps {
    list: BreadcrumbItem[];
    selectedValue: string;
    separator?: JSX.Element;
    /**
     * Determines how the breadcrumb separator
     *
     * @remarks
     * See {@link SxProps| the SxProps enum} for more details.
     *
     * @defaultValue { fontSize: 13 }
     */
    separatorStyle?: SxProps;
    itemStyle?: SxProps;
    itemHighlightedStyle?: SxProps;
    onClickBreadcrumb?: (value: string) => void;
}
declare const Breadcrumbs: React.FC<BreadcrumbsProps>;
export default Breadcrumbs;
