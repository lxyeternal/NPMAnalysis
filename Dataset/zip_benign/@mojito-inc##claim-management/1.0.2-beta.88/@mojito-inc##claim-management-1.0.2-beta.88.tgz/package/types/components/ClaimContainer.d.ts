import * as React from 'react';
export interface ClaimContainerProps {
    image?: string;
    title: string;
    subTitle?: string;
    description?: string;
    error?: string;
}
declare const ClaimContainer: ({ image, title, subTitle, description, error, }: ClaimContainerProps) => React.JSX.Element;
export default ClaimContainer;
