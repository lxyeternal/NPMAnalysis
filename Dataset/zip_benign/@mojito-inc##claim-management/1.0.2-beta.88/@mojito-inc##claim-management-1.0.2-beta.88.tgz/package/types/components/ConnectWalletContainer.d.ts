import React from 'react';
import { ContentData } from './EnterCodeContainer';
export interface ConnectWalletContainerProps {
    content?: ContentData;
    email: string;
    error?: string;
    logoUrl?: string;
    onChangeEmail: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onClickContinueWithEmail: () => void;
    onClickExistingWallet: () => void;
    onClickContinueWithGoogle: () => void;
}
declare const ConnectWalletContainer: ({ content, email, error, logoUrl, onChangeEmail, onClickContinueWithEmail, onClickExistingWallet, onClickContinueWithGoogle, }: ConnectWalletContainerProps) => React.JSX.Element;
export default ConnectWalletContainer;
