import * as React from 'react';
import { MediaContainerProps } from '../interface';
declare const MediaContainer: React.FC<MediaContainerProps>;
export default MediaContainer;
