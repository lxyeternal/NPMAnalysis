import * as React from 'react';
interface ErrorTagContainerProps {
    children: JSX.Element;
}
declare const ErrorTagContainer: ({ children }: ErrorTagContainerProps) => React.JSX.Element;
export default ErrorTagContainer;
