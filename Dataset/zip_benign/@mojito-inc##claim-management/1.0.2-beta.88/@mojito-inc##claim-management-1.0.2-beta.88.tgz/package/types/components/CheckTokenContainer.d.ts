import * as React from 'react';
import { ContentUpdateProps } from '../interface';
export interface CheckTokenContainerProps {
    tokenName?: string;
    content?: ContentUpdateProps;
    logoUrl?: string;
    onClickContinue: () => void;
}
declare const CheckTokenContainer: ({ content, logoUrl, tokenName, onClickContinue, }: CheckTokenContainerProps) => React.JSX.Element;
export default CheckTokenContainer;
