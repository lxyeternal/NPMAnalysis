import * as React from 'react';
import { CheckoutContainerProps } from '../interface';
declare const CheckoutContainer: ({ email, show, success, logoUrl, token, config, mixersConfig, listingId, uri, walletDetails, activeChain, walletConnectProjectId, clientId, paymentId, disconnect, refetchBalance, onClickGoToMarketPlace, }: CheckoutContainerProps) => React.JSX.Element;
export default CheckoutContainer;
