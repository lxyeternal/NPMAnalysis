import * as React from 'react';
interface InfoContainerProps {
    description: string;
}
declare const InfoContainer: ({ description }: InfoContainerProps) => React.JSX.Element;
export default InfoContainer;
