import * as React from 'react';
export interface PayWithGasContentProps {
    title?: string;
    description?: string;
    buttonName?: string;
    breadcrumbsLabel?: string;
    agreeTermsAndConditionsMessage?: string;
    privacyPolicyLabel?: string;
    termsAndConditionsLabel?: string;
    image?: string;
    termsSeparatorText?: string;
}
export interface PayWithGasContainerProps {
    error?: string;
    checked: boolean;
    termsUrl: string;
    isLoading: boolean;
    privacyUrl?: string;
    content?: PayWithGasContentProps;
    price?: string;
    validation?: 'clear' | 'no_balance' | 'wrong_network';
    networkName?: string;
    currency?: string;
    loaderDescription?: string;
    onChangeCheck: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onClickClaimNow: () => void;
    onClickSwitchNetwork: () => void;
}
declare const PayWithGasContainer: ({ error, checked, termsUrl, privacyUrl, content, price, isLoading, validation, networkName, currency, loaderDescription, onChangeCheck, onClickClaimNow, onClickSwitchNetwork, }: PayWithGasContainerProps) => React.JSX.Element;
export default PayWithGasContainer;
