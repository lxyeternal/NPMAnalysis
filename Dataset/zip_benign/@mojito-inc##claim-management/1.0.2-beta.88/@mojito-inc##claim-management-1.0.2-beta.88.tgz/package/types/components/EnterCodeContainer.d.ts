import * as React from 'react';
export interface ContentData {
    title?: string;
    description?: string;
    buttonName?: string;
    breadcrumbsLabel?: string;
    agreeTermsAndConditionsMessage?: string;
    additionalTermsAndConditionsLabel?: string;
    privacyPolicyLabel?: string;
    termsandConditionsLabel?: string;
    titleImageURL?: string;
    termsSeparatorText?: string;
}
export interface EnterCodeContainerProps {
    code: string;
    error?: string;
    inValidCode?: string | null;
    isEnterClaimCode?: boolean;
    checked: boolean;
    isTermsDisabled?: boolean;
    additionalTermsUrl?: string;
    termsUrl: string;
    privacyUrl?: string;
    content?: ContentData;
    onChangeCheck: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeCode: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onClickClaimNow: () => void;
}
declare const EnterCodeContainer: ({ code, error, inValidCode, isEnterClaimCode, checked, additionalTermsUrl, termsUrl, isTermsDisabled, privacyUrl, content, onChangeCheck, onChangeCode, onClickClaimNow, }: EnterCodeContainerProps) => React.JSX.Element;
export default EnterCodeContainer;
