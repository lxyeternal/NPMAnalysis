import * as React from 'react';
import { ContentData } from './EnterCodeContainer';
export interface WalletOptionsProps {
    enableMetamask: boolean;
    enableWalletConnect: boolean;
    enableCrossmint: boolean;
    enableEmailWallet: boolean;
}
export interface ConnectWalletProps {
    walletOptions: WalletOptionsProps;
    logoUrl?: string;
    content?: ContentData;
    onClickDoNotHaveWallet: () => void;
    onClickMetamask: () => void;
    onClickCrossMint: () => void;
    onClickWalletConnect: () => void;
}
declare const ConnectExistingWalletContainer: ({ walletOptions, logoUrl, onClickDoNotHaveWallet, content, onClickMetamask, onClickCrossMint, onClickWalletConnect, }: ConnectWalletProps) => React.JSX.Element;
export default ConnectExistingWalletContainer;
