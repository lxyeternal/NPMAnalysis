import * as React from 'react';
export interface RecoveryCodeContainerProps {
    recoveryCode: string;
    logoUrl?: string;
    error: string;
    description?: string;
    onClickRecoveryCode: () => void;
    onChangeRecoveryCode: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
declare const RecoveryCodeContainer: ({ recoveryCode, logoUrl, error, description, onClickRecoveryCode, onChangeRecoveryCode, }: RecoveryCodeContainerProps) => React.JSX.Element;
export default RecoveryCodeContainer;
