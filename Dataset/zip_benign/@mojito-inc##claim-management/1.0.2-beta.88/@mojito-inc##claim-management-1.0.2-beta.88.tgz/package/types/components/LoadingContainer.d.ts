import * as React from 'react';
interface LoadingContainerProps {
    loaderTitle: string;
    description?: string;
}
declare const LoadingContainer: ({ loaderTitle, description }: LoadingContainerProps) => React.JSX.Element;
export default LoadingContainer;
