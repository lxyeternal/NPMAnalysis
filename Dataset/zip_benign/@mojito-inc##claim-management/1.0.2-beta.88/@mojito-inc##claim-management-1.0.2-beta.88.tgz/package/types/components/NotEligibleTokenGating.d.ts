import * as React from 'react';
import { ContentUpdateProps } from '../interface';
export interface NotEligibleTokenContainerProps {
    tokenName?: string;
    tokenGatingError?: string;
    content?: ContentUpdateProps;
    showDisconnectButton?: boolean;
    logoUrl?: string;
    showBuyButton?: boolean;
    onClickDisconnectWallet: () => void;
    onClickBuyToken?: () => void;
}
declare const NotEligibleTokenContainer: ({ content, logoUrl, showDisconnectButton, tokenName, tokenGatingError, showBuyButton, onClickDisconnectWallet, onClickBuyToken, }: NotEligibleTokenContainerProps) => React.JSX.Element;
export default NotEligibleTokenContainer;
