import * as React from 'react';
import { ChangeEvent, Ref } from 'react';
import { type SxProps } from '@mui/material/styles';
export interface TextInputProps {
    placeholder?: string;
    onChange?: (event: ChangeEvent<HTMLInputElement>) => void;
    value?: string;
    InputPropsStyle?: SxProps;
    sx?: SxProps;
    error?: string;
    type?: string;
    disabled?: boolean;
    autoFocus?: boolean;
    inputRef?: Ref<HTMLElement>;
}
declare const TextInput: ({ placeholder, onChange, value, sx, InputPropsStyle, error, type, disabled, autoFocus, inputRef, }: TextInputProps) => React.JSX.Element;
export default TextInput;
