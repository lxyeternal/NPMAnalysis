import * as React from 'react';
import { ClaimErrorContentProps } from '../interface';
export interface ClaimErrorContainerProps {
    error?: string;
    content?: ClaimErrorContentProps;
    logoUrl?: string;
    onClickDisconnectWallet: () => void;
}
declare const ClaimErrorContainer: ({ content, logoUrl, error, onClickDisconnectWallet, }: ClaimErrorContainerProps) => React.JSX.Element;
export default ClaimErrorContainer;
