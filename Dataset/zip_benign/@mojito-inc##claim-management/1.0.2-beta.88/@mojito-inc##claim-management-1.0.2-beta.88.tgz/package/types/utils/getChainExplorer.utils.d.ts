export declare const getChainExplorer: (chainId: number, walletAddress: string) => string;
