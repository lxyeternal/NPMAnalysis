import { ethers } from 'ethers';
interface BalanceData {
    native: number;
    nonNative: number;
}
export declare function getNonNativeCurrencyBalancePaper(provider: ethers.providers.Web3Provider | any, currencyContractAddress: string, currency: string): Promise<number>;
export declare function getNonNativeCurrencyBalance(provider: ethers.providers.Web3Provider | any, currencyContractAddress: string, currency: string): Promise<number>;
export declare const getBalance: (provider: ethers.providers.Web3Provider | any, walletAddress: string, chainId: number, providerType: string) => Promise<BalanceData>;
export {};
