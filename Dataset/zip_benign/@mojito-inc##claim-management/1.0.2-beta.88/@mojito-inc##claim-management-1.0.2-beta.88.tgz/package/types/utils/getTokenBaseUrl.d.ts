export declare const getTokenBaseUrl: (chainId: number, contractAddress: string, tokenId?: string) => string;
