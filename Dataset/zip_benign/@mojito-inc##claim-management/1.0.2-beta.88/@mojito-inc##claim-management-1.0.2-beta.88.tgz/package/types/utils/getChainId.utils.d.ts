import { SupportedNetworks } from '../public/ClaimManagementProvider';
export declare const getChainId: (name: string) => number;
export declare const getChainIdByName: (name: SupportedNetworks) => 137 | 80001 | 1 | 5 | 11155111 | 8453 | 84532;
