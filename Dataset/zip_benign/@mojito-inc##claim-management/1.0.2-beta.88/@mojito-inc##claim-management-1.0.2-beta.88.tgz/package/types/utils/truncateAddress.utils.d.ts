export declare const truncateAddress: (data: string) => string;
