export declare const getProvider: (providerType: string, embeddedWalletSigner: any, walletProvider: any, paperClient: any, isPaper: boolean) => Promise<any>;
