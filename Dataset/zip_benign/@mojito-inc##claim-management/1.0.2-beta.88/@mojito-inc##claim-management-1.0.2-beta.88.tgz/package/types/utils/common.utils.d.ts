export declare function splitAlphaNumeric(input: string): string;
export declare function getSaleStatus(details: {
    startDate: string;
    endDate: string;
}): {
    isSaleStarted: boolean;
    isSaleEnded: boolean;
};
