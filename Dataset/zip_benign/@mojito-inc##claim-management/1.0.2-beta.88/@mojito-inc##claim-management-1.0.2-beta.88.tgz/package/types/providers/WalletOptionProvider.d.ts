import * as React from 'react';
import { ReactNode } from 'react';
import { WalletOptionsProps } from '../components/ConnectExistingWallet';
interface WalletOptionsProviderProps {
    children: ReactNode;
    walletOption?: WalletOptionsProps | undefined;
}
export declare const WalletOptionsProvider: ({ children, walletOption }: WalletOptionsProviderProps) => React.JSX.Element;
export declare const useWalletOptions: () => WalletOptionsProps;
export default WalletOptionsProvider;
