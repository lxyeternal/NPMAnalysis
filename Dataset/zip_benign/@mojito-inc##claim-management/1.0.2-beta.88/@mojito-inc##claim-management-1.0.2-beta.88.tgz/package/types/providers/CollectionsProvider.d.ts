import { AuctionData, CollectionItemByClaimCode } from '@mojito-inc/core-service';
import * as React from 'react';
export type CollectionDetailsProps = {
    collectionDetailsById: AuctionData;
    collectionDetailsByCode: CollectionItemByClaimCode;
    errorMsg: string;
    isLoading: boolean;
    fetchDetailsByClaimCode: (claimCode: string) => void;
};
export declare const useCollectionDetails: () => CollectionDetailsProps;
export declare const CollectionDetailsProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
