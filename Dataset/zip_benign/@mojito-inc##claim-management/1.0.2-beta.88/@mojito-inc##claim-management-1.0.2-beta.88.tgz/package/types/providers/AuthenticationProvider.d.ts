import * as React from 'react';
interface Authentication {
    onAuthenticated: (token: string) => void;
}
interface AuthenticationProviderProps {
    children: React.ReactNode;
    onAuthenticated: (token: string) => void;
}
export declare const AuthenticationContext: React.Context<Authentication>;
declare const AuthenticationProvider: ({ children, onAuthenticated, }: AuthenticationProviderProps) => React.JSX.Element;
export declare const useAuthentication: () => Authentication;
export default AuthenticationProvider;
