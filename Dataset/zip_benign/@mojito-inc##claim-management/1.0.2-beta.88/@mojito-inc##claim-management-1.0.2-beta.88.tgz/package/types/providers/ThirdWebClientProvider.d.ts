import * as React from 'react';
export interface ThirdWebClientContext {
    clientId: string;
}
export declare const useThirdWebClient: () => ThirdWebClientContext;
interface ThirdWebClientProviderProps {
    projectId: string;
    children: React.ReactNode;
}
export declare const ThirdWebClientProvider: ({ children, projectId }: ThirdWebClientProviderProps) => React.JSX.Element;
export {};
