import * as React from 'react';
import { ApolloClientOptions } from '../public/ClaimManagementProvider';
export interface WalletConnectContextProps {
    clientOptions: ApolloClientOptions;
    activeChain: 'ethereum' | 'polygon' | 'goerli' | 'mumbai' | 'sepolia' | 'base-sepolia-testnet' | 'base';
    clientId: string;
    projectId: string;
}
export declare const useWalletConnectDetails: () => WalletConnectContextProps;
export declare const WalletConnectProvider: ({ children, value }: {
    children: React.ReactNode;
    value: WalletConnectContextProps;
}) => React.JSX.Element;
