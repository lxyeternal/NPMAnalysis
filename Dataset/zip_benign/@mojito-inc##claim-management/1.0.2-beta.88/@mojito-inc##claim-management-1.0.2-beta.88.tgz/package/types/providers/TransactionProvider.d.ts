import * as React from 'react';
export interface TransactionDetailsProps {
    transactionHash: string;
    status: string;
    invoiceId: string;
}
export interface TransactionDetailsContextType {
    transactionDetails: TransactionDetailsProps;
    setTransactionDetails(f: TransactionDetailsProps | ((prev: TransactionDetailsProps) => TransactionDetailsProps)): void;
}
export declare const useTransactionDetails: () => TransactionDetailsContextType;
export declare const TransactionDetailsProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
