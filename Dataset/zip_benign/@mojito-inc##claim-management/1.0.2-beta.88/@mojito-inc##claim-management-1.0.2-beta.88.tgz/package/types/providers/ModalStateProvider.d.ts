import * as React from 'react';
import { ClaimContainerType } from '../interface';
export interface ModalStateContextType {
    modalState: ClaimContainerType;
    setModalState(f: ClaimContainerType | ((prev: ClaimContainerType) => ClaimContainerType)): void;
}
export declare const useModalState: () => ModalStateContextType;
export declare const ModalStateProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
