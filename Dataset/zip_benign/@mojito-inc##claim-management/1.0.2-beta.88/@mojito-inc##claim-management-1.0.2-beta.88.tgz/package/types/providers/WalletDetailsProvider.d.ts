import * as React from 'react';
import { BalanceData, SupportedNetworksData } from '../interface';
export interface WalletDetailsProps {
    address: string;
    networkDetails: SupportedNetworksData;
    balance: BalanceData;
    provider: any;
    providerType: string;
}
export type SupportedChainIDs = 1 | 4 | 137 | 80001 | 11155111 | 5 | 84532 | 8453;
export interface SwitchNetworkDetailProp {
    isSwitch: boolean;
    chainId: SupportedChainIDs;
    switchStatus: 'switch' | 'switching' | 'switched';
}
export interface WalletDetailsContextType {
    walletDetails: WalletDetailsProps;
    switchNetworkDetails: SwitchNetworkDetailProp;
    setWalletDetails(f: WalletDetailsProps | ((prev: WalletDetailsProps) => WalletDetailsProps)): void;
    SetSwitchNetworkDetails(f: SwitchNetworkDetailProp | ((prev: SwitchNetworkDetailProp) => SwitchNetworkDetailProp)): void;
}
export declare const useWalletDetails: () => WalletDetailsContextType;
export declare const WalletDetailsProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
