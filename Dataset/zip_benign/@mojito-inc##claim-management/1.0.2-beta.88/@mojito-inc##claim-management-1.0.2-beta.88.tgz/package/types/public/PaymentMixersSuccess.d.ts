import * as React from 'react';
import { PaymentMixersSuccessProps } from '../interface';
declare const PaymentMixersSuccess: ({ onClickGoToMarketPlace }: PaymentMixersSuccessProps) => React.JSX.Element;
export default PaymentMixersSuccess;
