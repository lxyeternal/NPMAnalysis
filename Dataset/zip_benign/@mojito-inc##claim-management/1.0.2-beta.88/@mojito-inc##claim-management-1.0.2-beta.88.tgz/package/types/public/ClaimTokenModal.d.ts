import * as React from 'react';
import { ClaimTokenModalProps } from '../interface';
declare const ClaimTokenModal: ({ open, config, firstName, lastName, loginWithPersonalInformation, userEmail, claimCode, listingId, skipSuccessModal, isDisConnect, link, content, skipClaimModal, skipConfirmClaimModal, isPaperWallet, tokenGatingConfig, tokenName, showDisconnectButton, showBuyButton, price, isClaimWithGas, claimType, mixersConfig, isTermsDisabled, skipNetworkValidationOnConnect, onClickBuyToken, onCloseModal, onSuccess, }: ClaimTokenModalProps) => React.JSX.Element;
export default ClaimTokenModal;
