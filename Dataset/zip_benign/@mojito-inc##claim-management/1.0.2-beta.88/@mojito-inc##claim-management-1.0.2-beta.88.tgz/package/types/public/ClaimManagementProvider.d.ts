import * as React from 'react';
import { Theme } from '@mui/material/styles';
import { MetaData } from '../interface';
import { WalletOptionsProps } from '../components/ConnectExistingWallet';
export interface ApolloClientOptions {
    uri?: string;
    token?: string;
}
export type SupportedNetworks = 'ethereum' | 'polygon' | 'goerli' | 'mumbai' | 'sepolia' | 'base-sepolia-testnet' | 'base';
export interface ClaimManagementProviderProps {
    children: JSX.Element | JSX.Element[];
    theme: Theme;
    clientOptions: ApolloClientOptions;
    walletConnectProjectId: string;
    activeChain: SupportedNetworks;
    clientId: string;
    metaData?: MetaData;
    walletOption?: WalletOptionsProps;
    onAuthenticated: (token: string) => void;
}
declare const ClaimManagementProvider: ({ children, theme, clientOptions, metaData, walletConnectProjectId, clientId, activeChain, walletOption, onAuthenticated, }: ClaimManagementProviderProps) => React.JSX.Element;
export default ClaimManagementProvider;
