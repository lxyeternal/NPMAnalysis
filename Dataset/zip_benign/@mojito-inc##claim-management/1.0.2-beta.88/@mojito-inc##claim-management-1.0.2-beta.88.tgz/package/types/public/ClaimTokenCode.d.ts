import React from 'react';
import { ClaimTokenCodeProp } from '../interface';
declare const ClaimTokenCode: React.FC<ClaimTokenCodeProp>;
export default ClaimTokenCode;
