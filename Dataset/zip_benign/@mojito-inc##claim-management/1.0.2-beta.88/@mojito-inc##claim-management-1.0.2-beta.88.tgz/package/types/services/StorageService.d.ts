declare class SecureStorage {
    key: string;
    constructor(key: string);
    setValue: (value: any) => void;
    getValue: () => string | null | undefined;
    clear: () => void;
}
export declare const StorageService: {
    token: SecureStorage;
    walletAddress: SecureStorage;
    tokenType: SecureStorage;
};
export {};
