import React from 'react';
import { ClaimTokenCodeLayoutProps } from '../interface';
export declare const ClaimTokenCodeLayout: React.FC<ClaimTokenCodeLayoutProps>;
