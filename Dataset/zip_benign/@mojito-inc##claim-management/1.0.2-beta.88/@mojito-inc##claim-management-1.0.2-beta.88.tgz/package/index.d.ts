import * as React from 'react';
import React__default, { ReactElement, CSSProperties } from 'react';
import { Theme } from '@mui/material/styles';
import { AuctionData, CollectionItemByClaimCode } from '@mojito-inc/core-service';

type CustomErrorContainerProps = {
    image?: any;
    errorMessage?: string;
    customErrorEnabled?: boolean;
};
declare const CustomErrorContainer: ({ image, errorMessage, customErrorEnabled }: CustomErrorContainerProps) => React__default.JSX.Element;

interface ContentData {
    title?: string;
    description?: string;
    buttonName?: string;
    breadcrumbsLabel?: string;
    agreeTermsAndConditionsMessage?: string;
    additionalTermsAndConditionsLabel?: string;
    privacyPolicyLabel?: string;
    termsandConditionsLabel?: string;
    titleImageURL?: string;
    termsSeparatorText?: string;
}

interface WalletOptionsProps {
    enableMetamask: boolean;
    enableWalletConnect: boolean;
    enableCrossmint: boolean;
    enableEmailWallet: boolean;
}

interface PayWithGasContentProps {
    title?: string;
    description?: string;
    buttonName?: string;
    breadcrumbsLabel?: string;
    agreeTermsAndConditionsMessage?: string;
    privacyPolicyLabel?: string;
    termsAndConditionsLabel?: string;
    image?: string;
    termsSeparatorText?: string;
}

interface ContentUpdateProps {
    title?: string;
    description?: string;
    seriesName?: string;
    CTA?: string;
}
interface ContentUpdateTokenGatingNotEligibleProps {
    description?: string;
    walletLimitReachedError?: string;
    notEligibleError?: string;
    pendingTransactionError?: string;
}
interface ClaimErrorContentProps {
    title?: string;
}
interface ContentProps {
    ClaimCodeContent?: ContentData;
    SuccessContent?: ContentData;
    ConnectWalletContent?: ContentData;
    LoaderContent?: ContentUpdateProps;
    RecoveryCodeModal?: {
        description?: string;
    };
    TokenGatingContent?: ContentUpdateProps;
    TokenGatingNotEligibleContent?: ContentUpdateTokenGatingNotEligibleProps;
    ClaimWithGasContent?: PayWithGasContentProps;
    ClaimErrorContent?: ClaimErrorContentProps;
}
interface LinkProps {
    logoUrl?: string;
    termsUrl: string;
    privacyUrl?: string;
    additionalTermsUrl?: string;
    viewTokenTrackerURL?: boolean;
    doNotHaveWalletURL?: string;
}
interface ClaimConfiguration {
    chainId: number;
    crossmintApiKey?: string;
    orgId: string;
    crossmintEnv?: string;
    paperClientId?: string;
    paperNetworkName?: any;
}
interface BalanceData {
    native: number;
    nonNative: number;
}
interface SupportedNetworksData {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
interface TokenGatingConfigProps {
    groupId: string;
    ruleId: string;
}
interface WalletOptionsMixersProps {
    enableMetamask: boolean;
    enableWalletConnect: boolean;
    enableEmailWallet: boolean;
}
interface PaymentOptionsProps {
    creditCard?: boolean;
    walletConnect?: boolean;
    wire?: boolean;
}
interface ClaimTokenModalWithoutMixersProps {
    open: boolean;
    firstName?: string;
    lastName?: string;
    userEmail?: string;
    loginWithPersonalInformation?: boolean;
    claimCode?: string;
    listingId?: string;
    isDisConnect: boolean;
    config: ClaimConfiguration;
    tokenGatingConfig?: TokenGatingConfigProps;
    link: LinkProps;
    content?: ContentProps;
    skipClaimModal?: boolean;
    skipSuccessModal?: boolean;
    skipConfirmClaimModal?: boolean;
    isPaperWallet?: boolean;
    tokenName?: string;
    showDisconnectButton?: boolean;
    showBuyButton?: boolean;
    price?: string;
    isClaimWithGas?: boolean;
    claimType: 'TokenGating' | 'SkipTokenGating' | 'CustomCode' | 'NoCode' | 'BuyNow';
    isTermsDisabled?: boolean;
    skipNetworkValidationOnConnect?: boolean;
    mixersConfig?: {
        lotId: string;
        walletOptions: WalletOptionsMixersProps;
        paymentId?: string;
        discountCode?: string;
        paymentOptions: PaymentOptionsProps;
        checkOutApiKey?: string;
        errorPageUrl: string;
        successPageUrl: string;
        invoiceId?: string;
        isWeb2Login?: boolean;
        skipSignature?: boolean;
        breadCrumbs?: string[];
        isAutoFillCountryCode?: boolean;
        onClickGoToMarketPlace?: () => void;
    };
    onCloseModal: () => void;
    onSuccess?: () => void;
    onClickBuyToken?: () => void;
}
type BuyNowClaimTokenModalProps = Omit<ClaimTokenModalWithoutMixersProps, 'mixersConfig'> & {
    mixersConfig: {
        lotId: string;
        walletOptions: WalletOptionsMixersProps;
        paymentId?: string;
        discountCode?: string;
        paymentOptions: PaymentOptionsProps;
        checkOutApiKey?: string;
        errorPageUrl: string;
        successPageUrl: string;
        invoiceId?: string;
        isWeb2Login?: boolean;
        skipSignature?: boolean;
        onClickGoToMarketPlace?: () => void;
    };
    claimType: 'BuyNow';
};
type ClaimTokenModalProps = ClaimTokenModalWithoutMixersProps | BuyNowClaimTokenModalProps;
type ButtonNameProps = {
    primary: string;
    secondary: string;
    teritary: string;
};
type VideoAttributes = {
    controls?: boolean;
    muted?: boolean;
    loop?: boolean;
    playsInline?: boolean;
    autoPlay?: boolean;
    layoutSize?: string;
};
type MediaContent = {
    width?: string;
    isPoweredBy?: boolean;
    height?: string;
    style?: CSSProperties;
    enableCardVideo?: boolean;
    sourceUrl?: string;
    moreInfo?: boolean;
    mediaOnly?: boolean;
    videoAttributes?: VideoAttributes;
};
type ClaimTokenCodeProp = {
    loader?: ReactElement | string;
    customErrorTemplate?: ReactElement | string;
    claimCode: string;
    buttonName: ButtonNameProps;
    mediaOnly?: boolean;
    moreInfo?: boolean;
    customErrorEnabled?: boolean;
    mediaContent?: MediaContent;
    width?: string;
    onClickClaim: (listingId: string) => void;
};
interface MetaData {
    name: string;
    description: string;
    url: string;
    icons: string[];
}
interface PaymentMixersSuccessProps {
    onClickGoToMarketPlace: () => void;
}

interface ApolloClientOptions {
    uri?: string;
    token?: string;
}
type SupportedNetworks = 'ethereum' | 'polygon' | 'goerli' | 'mumbai' | 'sepolia' | 'base-sepolia-testnet' | 'base';
interface ClaimManagementProviderProps {
    children: JSX.Element | JSX.Element[];
    theme: Theme;
    clientOptions: ApolloClientOptions;
    walletConnectProjectId: string;
    activeChain: SupportedNetworks;
    clientId: string;
    metaData?: MetaData;
    walletOption?: WalletOptionsProps;
    onAuthenticated: (token: string) => void;
}
declare const ClaimManagementProvider: ({ children, theme, clientOptions, metaData, walletConnectProjectId, clientId, activeChain, walletOption, onAuthenticated, }: ClaimManagementProviderProps) => React.JSX.Element;

declare const ClaimTokenModal: ({ open, config, firstName, lastName, loginWithPersonalInformation, userEmail, claimCode, listingId, skipSuccessModal, isDisConnect, link, content, skipClaimModal, skipConfirmClaimModal, isPaperWallet, tokenGatingConfig, tokenName, showDisconnectButton, showBuyButton, price, isClaimWithGas, claimType, mixersConfig, isTermsDisabled, skipNetworkValidationOnConnect, onClickBuyToken, onCloseModal, onSuccess, }: ClaimTokenModalProps) => React.JSX.Element;

declare const PaymentMixersSuccess: ({ onClickGoToMarketPlace }: PaymentMixersSuccessProps) => React.JSX.Element;

declare const ClaimTokenCode: React__default.FC<ClaimTokenCodeProp>;

interface WalletDetailsProps {
    address: string;
    networkDetails: SupportedNetworksData;
    balance: BalanceData;
    provider: any;
    providerType: string;
}
type SupportedChainIDs = 1 | 4 | 137 | 80001 | 11155111 | 5 | 84532 | 8453;

declare function useWallet(): WalletDetailsProps;

interface TransactionDetailsProps {
    transactionHash: string;
    status: string;
    invoiceId: string;
}

interface TransactionProps {
    transactionDetails: TransactionDetailsProps;
    error: boolean;
    fetchInvoiceDetail: (invoice: string) => void;
}
declare function useTransaction(): TransactionProps;

type CollectionDetailsProps = {
    collectionDetailsById: AuctionData;
    collectionDetailsByCode: CollectionItemByClaimCode;
    errorMsg: string;
    isLoading: boolean;
    fetchDetailsByClaimCode: (claimCode: string) => void;
};
declare const useCollectionDetails: () => CollectionDetailsProps;

declare const useSwitchNetwork: () => {
    switchChain: (id: SupportedChainIDs) => void;
    switchStatus: "switch" | "switching" | "switched";
};

export { ApolloClientOptions, ClaimConfiguration, ClaimManagementProvider, ClaimManagementProviderProps, ClaimTokenCode, ClaimTokenCodeProp, ClaimTokenModal, ClaimTokenModalProps, CollectionDetailsProps, CustomErrorContainer, CustomErrorContainerProps, PaymentMixersSuccess, PaymentMixersSuccessProps, useCollectionDetails, useSwitchNetwork, useTransaction, useWallet };
