export default {
  // importPath: 'https://unpkg.com/@polight/lego/dist/lego.min.js',
  importPath: '@polight/lego/dist/lego.min.js',
  baseClassName: 'Lego',
  sourceDir: 'bricks',
  targetDir: 'dist',
  watch: true,
  preScript: '',
  preStyle: ''
}