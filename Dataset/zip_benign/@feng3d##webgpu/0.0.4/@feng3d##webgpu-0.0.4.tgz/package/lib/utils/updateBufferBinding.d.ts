import { IBufferBinding } from "@feng3d/render-api";
import { IBufferBindingInfo } from "./getBufferBindingInfo";
/**
 * 初始化缓冲区绑定。
 *
 * @param variableInfo
 * @param uniformData
 * @returns
 */
export declare function updateBufferBinding(resourceName: string, bufferBindingInfo: IBufferBindingInfo, uniformData: IBufferBinding): void;
//# sourceMappingURL=updateBufferBinding.d.ts.map