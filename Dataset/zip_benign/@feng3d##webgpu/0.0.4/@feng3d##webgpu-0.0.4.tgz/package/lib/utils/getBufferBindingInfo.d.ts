import { TypeInfo } from "wgsl_reflect";
/**
 * 获取缓冲区绑定信息。
 *
 * @param type 类型信息。
 * @param paths 当前路径。
 * @param offset 当前编译。
 * @param bufferBindingInfo 缓冲区绑定信息。
 * @returns
 */
export declare function getBufferBindingInfo(type: TypeInfo, paths?: string[], offset?: number, bufferBindingInfo?: IBufferBindingInfo): IBufferBindingInfo;
type DataCls = Float32ArrayConstructor | Int32ArrayConstructor | Uint32ArrayConstructor | Int16ArrayConstructor;
/**
 * 缓冲区绑定信息。
 */
export interface IBufferBindingInfo {
    size: number;
    items: {
        paths: string[];
        offset: number;
        size: number;
        Cls: DataCls;
    }[];
}
export {};
//# sourceMappingURL=getBufferBindingInfo.d.ts.map