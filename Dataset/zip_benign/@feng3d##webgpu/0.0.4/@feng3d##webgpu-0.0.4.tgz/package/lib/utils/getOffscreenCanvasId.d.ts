export declare function getOffscreenCanvasId(canvas: OffscreenCanvas): any;
//# sourceMappingURL=getOffscreenCanvasId.d.ts.map