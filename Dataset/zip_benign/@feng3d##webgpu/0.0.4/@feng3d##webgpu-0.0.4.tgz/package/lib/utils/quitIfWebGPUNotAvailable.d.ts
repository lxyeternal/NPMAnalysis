/// <reference types="@webgpu/types" />
/**
 * Shows an error dialog if getting a adapter or device wasn't successful,
 * or if/when the device is lost or has an uncaptured error.
 */
export declare function quitIfWebGPUNotAvailable(adapter: GPUAdapter | null, device: GPUDevice | null): asserts device;
//# sourceMappingURL=quitIfWebGPUNotAvailable.d.ts.map