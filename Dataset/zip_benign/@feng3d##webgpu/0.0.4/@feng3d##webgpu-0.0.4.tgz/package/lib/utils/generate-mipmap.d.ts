/// <reference types="@webgpu/types" />
/**
 * Generates mip levels from level 0 to the last mip for an existing texture
 *
 * The texture must have been created with TEXTURE_BINDING and
 * RENDER_ATTACHMENT and been created with mip levels
 *
 * @param device
 * @param texture
 */
export declare function generateMipmap(device: GPUDevice, texture: GPUTexture): void;
//# sourceMappingURL=generate-mipmap.d.ts.map