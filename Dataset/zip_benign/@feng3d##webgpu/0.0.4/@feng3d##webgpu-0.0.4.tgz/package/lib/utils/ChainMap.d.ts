/**
 * 链式Map。
 *
 * 多个key数组对应一个值。
 *
 * 由于键值可能是字面值也可能是对象，因此无法使用 {@link WeakMap} 来构建{@link ChainMap}，只能使用 {@link Map}。
 */
export declare class ChainMap<K extends Array<any>, V> {
    private _map;
    /**
     * 获取键对应的值。
     *
     * @param keys 键。
     * @returns 值。
     */
    get(keys: K): V;
    /**
     * 设置映射。
     *
     * @param keys 键。
     * @param value 值。
     */
    set(keys: K, value: V): void;
    /**
     * 删除映射。
     *
     * @param keys 键。
     * @returns 如果找到目标值且被删除返回 `true` ，否则返回 `false` 。
     */
    delete(keys: K): boolean;
}
//# sourceMappingURL=ChainMap.d.ts.map