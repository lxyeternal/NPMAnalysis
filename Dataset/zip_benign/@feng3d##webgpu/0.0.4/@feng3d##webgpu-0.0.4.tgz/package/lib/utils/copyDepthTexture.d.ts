/// <reference types="@webgpu/types" />
/**
 * 拷贝 深度纹理到 普通纹理。
 *
 * @param device GPU设备。
 * @param sourceTexture 源纹理。
 * @param targetTexture 目标纹理。
 */
export declare function copyDepthTexture(device: GPUDevice, sourceTexture: GPUTexture, targetTexture: GPUTexture): void;
//# sourceMappingURL=copyDepthTexture.d.ts.map