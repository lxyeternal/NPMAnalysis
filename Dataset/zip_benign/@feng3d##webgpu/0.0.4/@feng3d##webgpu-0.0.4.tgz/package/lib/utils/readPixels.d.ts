/// <reference types="@webgpu/types" />
/**
 * 从 GPU纹理 上读取数据。
 *
 * @param device GPU设备。
 * @param texture GPU纹理
 * @param x 纹理读取X坐标。
 * @param y 纹理读取Y坐标。
 * @param width 纹理读取宽度。
 * @param height 纹理读取高度。
 *
 * @returns 读取到的数据。
 */
export declare function readPixels(device: GPUDevice, params: {
    texture: GPUTexture;
    origin: GPUOrigin3D;
    copySize: {
        width: number;
        height: number;
    };
}): Promise<Uint8Array>;
//# sourceMappingURL=readPixels.d.ts.map