/// <reference types="@webgpu/types" />
/**
 * 操作纹理进行Y轴翻转或进行预乘Alpha。
 *
 * @param texture 被操作的纹理。
 * @param invertY 是否Y轴翻转
 * @param premultiplyAlpha 是否预乘Alpha。
 */
export declare function textureInvertYPremultiplyAlpha(device: GPUDevice, texture: GPUTexture, options: {
    invertY?: boolean;
    premultiplyAlpha?: boolean;
}): void;
//# sourceMappingURL=textureInvertYPremultiplyAlpha.d.ts.map