import { ICopyBufferToBuffer, ICopyTextureToTexture, IRenderObject, IRenderPassDescriptor, ISubmit } from "@feng3d/render-api";
import { IGPUComputeObject } from "./data/IGPUComputeObject";
import { WebGPU } from "./WebGPU";
/**
 * 按步骤来组织 IGPUSubmit 对象。
 *
 * 不建议使用。
 */
export declare class WebGPUStep {
    private _currentSubmit;
    private _currentRenderPassEncoder;
    private _currentComputePassEncoder;
    readonly webGPU: WebGPU;
    constructor(webGPU: WebGPU);
    renderPass(descriptor: IRenderPassDescriptor): void;
    renderObject(renderObject: IRenderObject): void;
    computePass(): void;
    computeObject(computeObject: IGPUComputeObject): void;
    copyTextureToTexture(copyTextureToTexture: ICopyTextureToTexture): void;
    copyBufferToBuffer(copyBufferToBuffer: ICopyBufferToBuffer): void;
    /**
     * 提交 GPU 。
     *
     * @param submit 一次 GPU 提交内容。
     *
     * @see GPUQueue.submit
     */
    submit(submit?: ISubmit): void;
}
//# sourceMappingURL=WebGPUStep.d.ts.map