/// <reference types="@webgpu/types" />
import { IRenderObject, IRenderPassObject } from "@feng3d/render-api";
import { IGPURenderPassFormat } from "../internal/IGPURenderPassFormat";
import { RunWebGPU } from "./RunWebGPU";
/**
 * 套壳模式（RunWebGPUCommandCache）优于覆盖函数(RunWebGPUCommandCache1)的形式。
 */
export declare class RunWebGPUCommandCache extends RunWebGPU {
    protected runRenderPassObjects(device: GPUDevice, passEncoder: GPURenderPassEncoder, renderPassFormat: IGPURenderPassFormat, renderObjects?: IRenderPassObject[]): void;
    protected runRenderBundleObjects(device: GPUDevice, bundleEncoder: GPURenderBundleEncoder, renderPassFormat: IGPURenderPassFormat, renderObjects?: IRenderObject[]): void;
    protected runRenderObject(device: GPUDevice, passEncoder: GPURenderPassEncoder | GPURenderBundleEncoder, renderPassFormat: IGPURenderPassFormat, renderObject: IRenderObject): void;
}
//# sourceMappingURL=RunWebGPUCommandCache.d.ts.map