import { IGPUSetIndexBuffer } from "./IGPUIndexBuffer";
export declare function getIGPUSetIndexBuffer(index: Uint16Array | Uint32Array): IGPUSetIndexBuffer;
//# sourceMappingURL=getIGPUSetIndexBuffer.d.ts.map