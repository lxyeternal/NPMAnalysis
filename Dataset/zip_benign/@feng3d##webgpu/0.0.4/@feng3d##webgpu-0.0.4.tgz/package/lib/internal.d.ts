export { getIGPUTextureLikeSize as getGPUTextureSize } from "./caches/getIGPUTextureSize";
export * from "./caches/getWGSLReflectInfo";
//# sourceMappingURL=internal.d.ts.map