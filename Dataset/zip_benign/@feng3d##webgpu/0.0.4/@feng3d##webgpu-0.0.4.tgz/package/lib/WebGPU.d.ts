/// <reference types="@webgpu/types" />
import { IBuffer, ISubmit, ITextureLike } from "@feng3d/render-api";
import { IGPUReadPixels } from "./data/IGPUReadPixels";
/**
 * WebGPU 对象。
 *
 * 提供 `WebGPU` 操作入口 {@link WebGPU.submit}。
 */
export declare class WebGPU {
    private _runWebGPU;
    /**
     * 初始化 WebGPU 获取 GPUDevice 。
     */
    init(options?: GPURequestAdapterOptions, descriptor?: GPUDeviceDescriptor): Promise<this>;
    device: GPUDevice;
    /**
     * 提交 GPU 。
     *
     * @param submit 一次 GPU 提交内容。
     *
     * @see GPUQueue.submit
     */
    submit(submit: ISubmit): void;
    /**
     * 销毁纹理。
     *
     * @param texture 需要被销毁的纹理。
     */
    destoryTexture(texture: ITextureLike): void;
    /**
     * 操作纹理进行Y轴翻转或进行预乘Alpha。
     *
     * @param texture 被操作的纹理。
     * @param invertY 是否Y轴翻转
     * @param premultiplyAlpha 是否预乘Alpha。
     */
    textureInvertYPremultiplyAlpha(texture: ITextureLike, options: {
        invertY?: boolean;
        premultiplyAlpha?: boolean;
    }): void;
    /**
     * 拷贝 深度纹理到 普通纹理。
     *
     * @param device GPU设备。
     * @param sourceTexture 源纹理。
     * @param targetTexture 目标纹理。
     */
    copyDepthTexture(sourceTexture: ITextureLike, targetTexture: ITextureLike): void;
    /**
     * 从 GPU纹理 上读取数据。
     *
     * @param gpuReadPixels
     *
     * @returns 读取到的数据。
     */
    readPixels(gpuReadPixels: IGPUReadPixels): Promise<Uint8Array>;
    /**
     * 从GPU缓冲区读取数据到CPU。
     *
     * @param buffer GPU缓冲区。
     * @param offset 读取位置。
     * @param size 读取字节数量。
     * @returns CPU数据缓冲区。
     */
    readBuffer(buffer: IBuffer, offset?: GPUSize64, size?: GPUSize64): Promise<ArrayBuffer>;
    getGPUTextureSize(input: ITextureLike): import("@feng3d/render-api").ITextureSize;
}
//# sourceMappingURL=WebGPU.d.ts.map