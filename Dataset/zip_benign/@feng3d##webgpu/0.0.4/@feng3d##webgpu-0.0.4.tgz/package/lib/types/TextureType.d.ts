/// <reference types="@webgpu/types" />
/**
 * 纹理维度。
 */
export declare const TextureDimensionality: {
    "1D": string;
    "2D": string;
    "3D": string;
    Cube: string;
};
export type TextureDimensionality = keyof typeof TextureDimensionality;
/**
 * 纹理为是否数组。
 */
export declare const TextureArrayed: {
    No: boolean;
    Yes: boolean;
};
export type TextureArrayed = keyof typeof TextureArrayed;
/**
 * 纹理第二类型，描述纹理维度以及是否为数组。
 */
export type TextureSecondType = [TextureDimensionality, TextureArrayed, GPUTextureViewDimension];
/**
 * 采样纹理类型。
 *
 * @see https://gpuweb.github.io/gpuweb/wgsl/#sampled-texture-type
 */
export declare const SampledTextureType: {
    texture_1d: TextureSecondType;
    texture_2d: TextureSecondType;
    texture_2d_array: TextureSecondType;
    texture_3d: TextureSecondType;
    texture_cube: TextureSecondType;
    texture_cube_array: TextureSecondType;
};
export type SampledTextureType = keyof typeof SampledTextureType;
/**
 * 多重采样纹理类型。
 *
 * @see https://gpuweb.github.io/gpuweb/wgsl/#multisampled-texture-type
 */
export declare const MultisampledTextureType: {
    texture_multisampled_2d: TextureSecondType;
    texture_depth_multisampled_2d: TextureSecondType;
};
export type MultisampledTextureType = keyof typeof MultisampledTextureType;
/**
 * 外部纹理类型。
 *
 * @see https://gpuweb.github.io/gpuweb/wgsl/#external-texture-type
 */
export declare const ExternalSampledTextureType: {
    texture_external: TextureSecondType;
};
export type ExternalSampledTextureType = keyof typeof ExternalSampledTextureType;
/**
 * 存储纹理类型。
 *
 * @see https://gpuweb.github.io/gpuweb/wgsl/#texture-storage
 */
export declare const StorageTextureType: {
    texture_storage_1d: TextureSecondType;
    texture_storage_2d: TextureSecondType;
    texture_storage_2d_array: TextureSecondType;
    texture_storage_3d: TextureSecondType;
};
export type StorageTextureType = keyof typeof StorageTextureType;
/**
 * 深度纹理类型。
 */
export declare const DepthTextureType: {
    texture_depth_2d: TextureSecondType;
    texture_depth_2d_array: TextureSecondType;
    texture_depth_cube: TextureSecondType;
    texture_depth_cube_array: TextureSecondType;
};
/**
 * 所有纹理类型。
 */
export declare const TextureType: {
    texture_depth_2d: TextureSecondType;
    texture_depth_2d_array: TextureSecondType;
    texture_depth_cube: TextureSecondType;
    texture_depth_cube_array: TextureSecondType;
    texture_storage_1d: TextureSecondType;
    texture_storage_2d: TextureSecondType;
    texture_storage_2d_array: TextureSecondType;
    texture_storage_3d: TextureSecondType;
    texture_external: TextureSecondType;
    texture_multisampled_2d: TextureSecondType;
    texture_depth_multisampled_2d: TextureSecondType;
    texture_1d: TextureSecondType;
    texture_2d: TextureSecondType;
    texture_2d_array: TextureSecondType;
    texture_3d: TextureSecondType;
    texture_cube: TextureSecondType;
    texture_cube_array: TextureSecondType;
};
export type TextureType = keyof typeof TextureType;
//# sourceMappingURL=TextureType.d.ts.map