/// <reference types="@webgpu/types" />
/**
 * 有类型数组构造器。
 */
export type TypedArrayConstructor = Int8ArrayConstructor | Uint8ArrayConstructor | Int16ArrayConstructor | Uint16ArrayConstructor | Int32ArrayConstructor | Uint32ArrayConstructor | Float32ArrayConstructor;
/**
 * GPU顶点数据类型
 */
export type GPUVertexDataType = "unsigned int" | "signed int" | "unsigned normalized" | "signed normalized" | "float";
/**
 * 顶点数据在WGSL中的类型。
 */
export type WGSLVertexType = "vec2<u32>" | "vec4<u32>" | "vec2<i32>" | "vec4<i32>" | "vec2<f32>" | "vec4<f32>" | "vec2<f16>" | "vec4<f16>" | "f32" | "vec3<f32>" | "u32" | "vec3<u32>" | "i32" | "vec3<i32>";
/**
 * GPU顶点格式对应的信息
 */
export type GPUVertexFormatValue = {
    /**
     * 数据类型。
     */
    dataType: GPUVertexDataType;
    /**
     * 部件数量。
     */
    components: 1 | 2 | 3 | 4;
    /**
     * 所占字节尺寸。
     */
    byteSize: 2 | 4 | 8 | 12 | 16;
    /**
     * 在着色器中对应类型。
     */
    wgslType: WGSLVertexType;
    /**
     * 对应类型数组构造器。
     */
    typedArrayConstructor: TypedArrayConstructor;
};
/**
 * 顶点格式对应信息映射
 *
 * 以 {@link GPUVertexFormat} 为键值。
 *
 * @see https://www.orillusion.com/zh/webgpu.html#vertex-formats
 */
export declare const gpuVertexFormatMap: Record<GPUVertexFormat, GPUVertexFormatValue>;
/**
 * WGSL着色器中顶点类型对应的GPU顶点数据格式。
 */
export type WGSLVertexTypeValue = {
    /**
     * 默认对应的GPU顶点数据格式。
     */
    format: GPUVertexFormat;
    /**
     * 可能对应的GPU顶点数据格式列表。
     */
    possibleFormats: GPUVertexFormat[];
};
/**
 * WGSL着色器中顶点类型对应的GPU顶点数据格式映射。
 */
export declare const wgslVertexTypeMap: Record<WGSLVertexType, WGSLVertexTypeValue>;
//# sourceMappingURL=VertexFormat.d.ts.map