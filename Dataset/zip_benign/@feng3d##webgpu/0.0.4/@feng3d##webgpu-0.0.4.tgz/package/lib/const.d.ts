export declare const getRealGPUBindGroup = "getRealGPUBindGroup";
//# sourceMappingURL=const.d.ts.map