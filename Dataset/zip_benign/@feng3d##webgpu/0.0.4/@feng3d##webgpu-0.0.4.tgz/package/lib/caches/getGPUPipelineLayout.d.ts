/// <reference types="@webgpu/types" />
import { IGPUPipelineLayoutDescriptor } from "../internal/IGPUPipelineLayoutDescriptor";
export declare function getGPUPipelineLayout(device: GPUDevice, layout: IGPUPipelineLayoutDescriptor): GPUPipelineLayout;
//# sourceMappingURL=getGPUPipelineLayout.d.ts.map