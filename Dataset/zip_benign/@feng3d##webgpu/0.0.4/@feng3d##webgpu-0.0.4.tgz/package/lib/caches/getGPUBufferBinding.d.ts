/// <reference types="@webgpu/types" />
import { IBufferBinding } from "@feng3d/render-api";
export declare function getGPUBufferBinding(device: GPUDevice, resource: IBufferBinding): GPUBufferBinding;
//# sourceMappingURL=getGPUBufferBinding.d.ts.map