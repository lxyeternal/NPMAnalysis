/// <reference types="@webgpu/types" />
import { NGPURenderPipeline } from "../internal/NGPURenderPipeline";
export declare function getGPURenderPipeline(device: GPUDevice, renderPipeline: NGPURenderPipeline): GPURenderPipeline;
//# sourceMappingURL=getGPURenderPipeline.d.ts.map