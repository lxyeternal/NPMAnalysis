/// <reference types="@webgpu/types" />
import { ITextureLike } from "@feng3d/render-api";
/**
 * 获取GPU纹理 {@link GPUTexture} 。
 *
 * @param device GPU设备。
 * @param iGPUTextureBase 纹理描述。
 * @returns GPU纹理。
 */
export declare function getGPUTexture(device: GPUDevice, textureLike: ITextureLike, autoCreate?: boolean): GPUTexture;
//# sourceMappingURL=getGPUTexture.d.ts.map