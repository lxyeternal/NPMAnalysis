/// <reference types="@webgpu/types" />
import { IGPUCanvasContext } from "../data/IGPUCanvasContext";
export declare function getGPUCanvasContext(device: GPUDevice, context: IGPUCanvasContext): GPUCanvasContext;
//# sourceMappingURL=getGPUCanvasContext.d.ts.map