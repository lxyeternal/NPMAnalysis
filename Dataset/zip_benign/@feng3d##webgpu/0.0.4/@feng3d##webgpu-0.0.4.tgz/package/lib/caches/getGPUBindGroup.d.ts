/// <reference types="@webgpu/types" />
import { IGPUBindGroupDescriptor } from "../internal/IGPUBindGroupDescriptor";
export declare function getGPUBindGroup(device: GPUDevice, bindGroup: IGPUBindGroupDescriptor): GPUBindGroup;
//# sourceMappingURL=getGPUBindGroup.d.ts.map