import { IGPUPipelineLayoutDescriptor } from "../internal/IGPUPipelineLayoutDescriptor";
export type IGPUShader = {
    readonly vertex?: string;
    readonly fragment?: string;
    readonly compute?: string;
};
export declare function getIGPUShaderKey(shader: IGPUShader): string;
/**
 * 从GPU管线中获取管线布局。
 *
 * @param shader GPU管线。
 * @returns 管线布局。
 */
export declare function getIGPUPipelineLayout(shader: IGPUShader): IGPUPipelineLayoutDescriptor;
//# sourceMappingURL=getIGPUPipelineLayout.d.ts.map