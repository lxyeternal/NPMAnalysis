/// <reference types="@webgpu/types" />
import { IRenderPassDescriptor } from "@feng3d/render-api";
/**
 * 获取GPU渲染通道描述。
 *
 * @param device GPU设备。
 * @param descriptor 渲染通道描述。
 * @returns GPU渲染通道描述。
 */
export declare function getGPURenderPassDescriptor(device: GPUDevice, descriptor: IRenderPassDescriptor): GPURenderPassDescriptor;
//# sourceMappingURL=getGPURenderPassDescriptor.d.ts.map