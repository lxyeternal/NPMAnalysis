/// <reference types="@webgpu/types" />
import { ITextureDimension } from "@feng3d/render-api";
export declare function getGPUTextureDimension(dimension: ITextureDimension): GPUTextureDimension;
//# sourceMappingURL=getGPUTextureDimension.d.ts.map