/// <reference types="@webgpu/types" />
/**
 * 由纹理格式获取纹理可支持的用途。
 *
 * 包含深度、多重采样、以及个别的无法作为存储纹理。
 *
 * @param format
 * @param sampleCount
 * @returns
 */
export declare function getTextureUsageFromFormat(device: GPUDevice, format: GPUTextureFormat, sampleCount?: 4): GPUTextureUsageFlags;
//# sourceMappingURL=getTextureUsageFromFormat.d.ts.map