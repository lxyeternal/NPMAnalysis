import { IIndicesDataTypes, IRenderPipeline, IVertexAttributes } from "@feng3d/render-api";
import { IGPURenderPassFormat } from "../internal/IGPURenderPassFormat";
import { NGPURenderPipeline } from "../internal/NGPURenderPipeline";
import { NGPUVertexBuffer } from "../internal/NGPUVertexBuffer";
/**
 * 从渲染管线描述、渲染通道描述以及完整的顶点属性数据映射获得完整的渲染管线描述以及顶点缓冲区数组。
 *
 * @param renderPipeline 渲染管线描述。
 * @param renderPass 渲染通道描述。
 * @param vertices 顶点属性数据映射。
 * @returns 完整的渲染管线描述以及顶点缓冲区数组。
 */
export declare function getNGPURenderPipeline(renderPipeline: IRenderPipeline, renderPassFormat: IGPURenderPassFormat, vertices: IVertexAttributes, indices: IIndicesDataTypes): {
    /**
     * GPU渲染管线描述。
     */
    pipeline: NGPURenderPipeline;
    /**
     * GPU渲染时使用的顶点缓冲区列表。
     */
    vertexBuffers: NGPUVertexBuffer[];
};
//# sourceMappingURL=getNGPURenderPipeline.d.ts.map