/// <reference types="@webgpu/types" />
import { IRenderPass, IRenderPassObject } from "@feng3d/render-api";
export declare function getGPURenderOcclusionQuery(renderObjects?: readonly IRenderPassObject[]): GPURenderOcclusionQuery;
interface GPURenderOcclusionQuery {
    init: (device: GPUDevice, renderPassDescriptor: GPURenderPassDescriptor) => void;
    resolve: (device: GPUDevice, commandEncoder: GPUCommandEncoder, renderPass: IRenderPass) => void;
}
export {};
//# sourceMappingURL=getGPURenderOcclusionQuery.d.ts.map