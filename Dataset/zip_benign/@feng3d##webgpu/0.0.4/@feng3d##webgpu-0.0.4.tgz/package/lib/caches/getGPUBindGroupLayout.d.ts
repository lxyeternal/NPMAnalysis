/// <reference types="@webgpu/types" />
export declare function getGPUBindGroupLayout(device: GPUDevice, layout: GPUBindGroupLayoutDescriptor): GPUBindGroupLayout;
//# sourceMappingURL=getGPUBindGroupLayout.d.ts.map