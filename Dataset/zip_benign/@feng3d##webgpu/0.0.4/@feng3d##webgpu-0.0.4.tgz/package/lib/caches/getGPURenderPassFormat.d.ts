import { IRenderPassDescriptor } from "@feng3d/render-api";
import { IGPURenderPassFormat } from "../internal/IGPURenderPassFormat";
/**
 * 获取渲染通道格式。
 *
 * @param descriptor 渲染通道描述。
 * @returns
 */
export declare function getGPURenderPassFormat(descriptor: IRenderPassDescriptor): IGPURenderPassFormat;
//# sourceMappingURL=getGPURenderPassFormat.d.ts.map