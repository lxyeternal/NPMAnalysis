import { WgslReflect } from "wgsl_reflect";
import { IGPUBindGroupLayoutEntry } from "../internal/IGPUPipelineLayoutDescriptor";
/**
 * 从WebGPU着色器代码中获取反射信息。
 *
 * @param code WebGPU着色器代码。
 * @returns 从WebGPU着色器代码中获取的反射信息。
 */
export declare function getWGSLReflectInfo(code: string): WgslReflect;
export type IGPUBindGroupLayoutEntryMap = {
    [name: string]: IGPUBindGroupLayoutEntry;
};
export declare function getIGPUBindGroupLayoutEntryMap(code: string): IGPUBindGroupLayoutEntryMap;
//# sourceMappingURL=getWGSLReflectInfo.d.ts.map