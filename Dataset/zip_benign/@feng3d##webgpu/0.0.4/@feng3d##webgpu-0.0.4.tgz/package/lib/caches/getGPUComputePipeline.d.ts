/// <reference types="@webgpu/types" />
import { IGPUComputePipeline } from "../data/IGPUComputePipeline";
export declare function getGPUComputePipeline(device: GPUDevice, computePipeline: IGPUComputePipeline): GPUComputePipeline;
//# sourceMappingURL=getGPUComputePipeline.d.ts.map