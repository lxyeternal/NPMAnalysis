import { IUniforms } from "@feng3d/render-api";
import { IGPUShader } from "../caches/getIGPUPipelineLayout";
import { IGPUSetBindGroup } from "../internal/IGPUSetBindGroup";
export declare function getIGPUSetBindGroups(shader: IGPUShader, bindingResources: IUniforms): IGPUSetBindGroup[];
//# sourceMappingURL=getIGPUSetBindGroups.d.ts.map