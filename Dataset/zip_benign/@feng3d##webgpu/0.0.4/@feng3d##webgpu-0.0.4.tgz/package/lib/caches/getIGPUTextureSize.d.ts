import { ITextureImageSource, ITextureLike, ITextureSize } from "@feng3d/render-api";
/**
 * 获取纹理尺寸。
 *
 * @param texture 纹理。
 * @returns 纹理尺寸。
 */
export declare function getIGPUTextureLikeSize(texture: ITextureLike): ITextureSize;
export declare function getIGPUTextureSourceSize(source?: ITextureImageSource[]): ITextureSize;
//# sourceMappingURL=getIGPUTextureSize.d.ts.map