/// <reference types="@webgpu/types" />
import { ISampler } from "@feng3d/render-api";
export declare function getGPUSampler(device: GPUDevice, sampler: ISampler): GPUSampler;
//# sourceMappingURL=getGPUSampler.d.ts.map