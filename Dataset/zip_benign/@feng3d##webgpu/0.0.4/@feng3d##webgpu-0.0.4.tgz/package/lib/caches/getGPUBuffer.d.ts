/// <reference types="@webgpu/types" />
import { IBuffer } from "@feng3d/render-api";
/**
 * 获取 GPU 缓冲。
 *
 * @param device
 * @param buffer
 * @returns
 */
export declare function getGPUBuffer(device: GPUDevice, buffer: IBuffer): GPUBuffer;
//# sourceMappingURL=getGPUBuffer.d.ts.map