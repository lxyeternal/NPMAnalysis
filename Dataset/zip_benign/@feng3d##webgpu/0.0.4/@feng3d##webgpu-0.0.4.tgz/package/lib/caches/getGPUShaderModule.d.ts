/// <reference types="@webgpu/types" />
export declare function getGPUShaderModule(device: GPUDevice, code: string): GPUShaderModule;
//# sourceMappingURL=getGPUShaderModule.d.ts.map