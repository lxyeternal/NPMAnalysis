import { IBuffer, IVertexDataTypes, TypedArray } from "@feng3d/render-api";
export declare function getIGPUBuffer(bufferSource: TypedArray): IBuffer;
export declare function getIGPUVertexBuffer(data: IVertexDataTypes): IBuffer;
export declare function getIGPUIndexBuffer(data: Uint16Array | Uint32Array): IBuffer;
//# sourceMappingURL=getIGPUBuffer.d.ts.map