/// <reference types="@webgpu/types" />
import { IRenderPass } from "@feng3d/render-api";
import { IGPUComputePass } from "../data/IGPUComputePass";
import { IGPUTimestampQuery } from "../data/IGPUTimestampQuery";
export declare function getGPURenderTimestampQuery(device: GPUDevice, timestampQuery?: IGPUTimestampQuery): GPURenderTimestampQuery;
interface GPURenderTimestampQuery {
    init: (device: GPUDevice, passDescriptor: GPURenderPassDescriptor | GPUComputePassDescriptor) => void;
    resolve: (device: GPUDevice, commandEncoder: GPUCommandEncoder, renderPass: IRenderPass | IGPUComputePass) => void;
}
export {};
//# sourceMappingURL=getGPURenderTimestampQuery.d.ts.map