/// <reference types="@webgpu/types" />
import { ITextureView } from "@feng3d/render-api";
export declare function getGPUTextureView(device: GPUDevice, view: ITextureView): GPUTextureView;
//# sourceMappingURL=getGPUTextureView.d.ts.map