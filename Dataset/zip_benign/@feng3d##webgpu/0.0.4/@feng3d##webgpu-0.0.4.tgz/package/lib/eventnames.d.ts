/**
 * WebGPU纹理销毁事件
 */
export declare const GPUTexture_destroy = "GPUTexture_destroy";
/**
 * WebGPU纹理视图销毁事件
 */
export declare const GPUTextureView_destroy = "GPUTextureView_destroy";
export declare const GPUQueue_submit = "GPUQueue_submit";
export declare const IGPUTexture_resize = "IGPUTexture_resize";
export declare const IGPUSampler_changed = "IGPUSampler_changed";
//# sourceMappingURL=eventnames.d.ts.map