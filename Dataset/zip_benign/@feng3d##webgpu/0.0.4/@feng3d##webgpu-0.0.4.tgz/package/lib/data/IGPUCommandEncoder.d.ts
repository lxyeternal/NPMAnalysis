import { IGPUComputePass } from "./IGPUComputePass";
declare module "@feng3d/render-api" {
    interface IPassEncoderMap {
        IGPUComputePass: IGPUComputePass;
    }
}
//# sourceMappingURL=IGPUCommandEncoder.d.ts.map