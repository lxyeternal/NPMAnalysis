import { ISampler } from "@feng3d/render-api";
import { IGPUExternalTexture } from "./IGPUExternalTexture";
declare module "@feng3d/render-api" {
    interface IUniformTypeMap {
        ISampler: ISampler;
        ITextureView: ITextureView;
        IGPUExternalTexture: IGPUExternalTexture;
    }
}
//# sourceMappingURL=IGPUBindingResources.d.ts.map