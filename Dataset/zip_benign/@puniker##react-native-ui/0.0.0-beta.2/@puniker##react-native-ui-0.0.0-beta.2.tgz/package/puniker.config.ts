import {ReactNativeUiKitConfig} from './puniker-config'

module.exports = {
  palette: {
    LIGHT: '#ffffff',
    MEDIUM: '#757575',
    PRIMARY: '#db002a',
    ALERT: '#ff9047',
    SUCCESS: '#1ee49e',
    BACK: '#f2f2f2',
    DARK: '#232426',
  },
  buttons: {
    primary: {
      borderRadius: 4,
      backgroundColor: 'PRIMARY',
      fontType: 'body_1',
      fontColor: 'LIGHT',
    },
  },
  forms: {
    borderRadius: 5,
    onlyActiveInBottom: true,
    textInput: {
      borderColor: 'PRIMARY',
      activeBorderColor: 'DARK',
      color: 'DARK',
    },
  },
  typography: {
    fontFamily: {},
    fontTypes: {
      head_1: {
        fontSize: 34,
        letterSpacing: 0.2,
      },
      head_2: {
        fontSize: 28,
        letterSpacing: 0.2,
      },
      head_3: {
        fontSize: 22,
        letterSpacing: 0.4,
      },
      head_4: {
        fontSize: 20,
        letterSpacing: 0.2,
      },

      body_1: {
        fontSize: 17,
        letterSpacing: 0.2,
      },
      body_2: {
        fontSize: 15,
        letterSpacing: 0.2,
      },
      caption_1: {
        fontSize: 13,
        letterSpacing: 0.2,
      },
      caption_2: {
        fontSize: 11,
        letterSpacing: 0.2,
      },
    },
  },
} as ReactNativeUiKitConfig
