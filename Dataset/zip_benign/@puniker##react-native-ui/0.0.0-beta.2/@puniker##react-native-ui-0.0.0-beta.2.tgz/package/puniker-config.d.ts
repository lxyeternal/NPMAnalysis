export interface ReactNativeUiKitConfig {
  palette: ReactNativeUiKitConfigPalette
  buttons: ReactNativeUiKitConfigButtons
  typography: ReactNativeUiKitConfigTypography
  forms: ReactNativeUiKitConfigForms
}

// THEME
interface ReactNativeUiKitConfigPalette {
  LIGHT: string
  MEDIUM: string
  PRIMARY: string
  ALERT: string
  SUCCESS: string
  BACK: string
  DARK: string
}

// FORMS
interface ReactNativeUiKitConfigForms {
  borderRadius: number
  onlyActiveInBottom: boolean
  textInput: ReactNativeUiKitConfigFormsTextInput
}
interface ReactNativeUiKitConfigFormsTextInput {
  borderColor: keyof ReactNativeUiKitConfigPalette
  activeBorderColor: keyof ReactNativeUiKitConfigPalette
  color: keyof ReactNativeUiKitConfigPalette
}

// BUTTONS
interface ReactNativeUiKitConfigButtons {
  primary: ReactNativeUiKitConfigPrimaryButton
}
interface ReactNativeUiKitConfigPrimaryButton {
  borderRadius: number
  backgroundColor: keyof ReactNativeUiKitConfigPalette
  fontType: keyof ReactNativeUiKitConfigTypographyFontTypes
  fontColor: keyof ReactNativeUiKitConfigPalette
}

// TYPOGRAPHY
interface ReactNativeUiKitConfigTypography {
  fontFamily: ReactNativeUiKitConfigTypographyFontFamily
  fontTypes: ReactNativeUiKitConfigTypographyFontTypes
}
interface ReactNativeUiKitConfigTypographyFontFamily {
  light?: string
  regular?: string
  bold?: string
}
interface ReactNativeUiKitConfigTypographyFontTypes {
  head_1: ReactNativeUiKitConfigTypographyFontType
  head_2: ReactNativeUiKitConfigTypographyFontType
  head_3: ReactNativeUiKitConfigTypographyFontType
  head_4: ReactNativeUiKitConfigTypographyFontType
  body_1: ReactNativeUiKitConfigTypographyFontType
  body_2: ReactNativeUiKitConfigTypographyFontType
  caption_1: ReactNativeUiKitConfigTypographyFontType
  caption_2: ReactNativeUiKitConfigTypographyFontType
}
interface ReactNativeUiKitConfigTypographyFontType {
  fontSize: number
  lineHeight?: number
  letterSpacing: number
}
