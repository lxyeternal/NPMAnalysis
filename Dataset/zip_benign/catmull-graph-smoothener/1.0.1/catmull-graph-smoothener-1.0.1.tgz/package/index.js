function create(dataArray)
{
    return createWithAlpha(dataArray, 0.5);
}

function createWithAlpha(dataArray, alpha)
{
    if(!Array.isArray(dataArray))
        throw "Argument 0: Array expected";
    if(isNaN(alpha) || alpha > 1 || alpha < 0)
        throw "Argument 1: Alpha must lie within range 0 and 1";
    return {
        points:dataArray,
        alpha:alpha,
        getAt:function(x) 
        {
            return getAt(x, dataArray, alpha);
        },
		bakeValues:function(precision)
		{
			return bakeStuff(dataArray, alpha, precision, valueGetter)
		},
		bakeCoordinates:function(precision)
		{
			return bakeStuff(dataArray, alpha, precision, coordGetter)
		}
    };
}

exports.create = create;
exports.createWithAlpha = createWithAlpha;

function bakeStuff(dataArray, alpha, precision, getter)
{
	if(isNaN(precision) || !Number.isInteger(precision) || precision < 1)
		throw "Argument 2: A positive integer expected"
	var len = precision*dataArray.length + 1;
	var arr = [];
	for(var i = 0; i < len; i++)
	{
		arr.push(getter(i, precision, dataArray, alpha));
	}
	return arr;
}

function valueGetter(i, precision, dataArray, alpha)
{
	return getAt(i/precision, dataArray, alpha);
}

function coordGetter(i, precision, dataArray, alpha)
{
	return [i/precision, getAt(i/precision, dataArray, alpha)];
}

function getAt(x, dataArray, alpha)
{
    if(isNaN(x))
        throw "Argument 0: Number expected";
    if(!Array.isArray(dataArray))
        throw "Argument 1: Array expected";
    if(x < 0 || x > dataArray.length - 1)
        throw "Argument 0: Out of range";
    x = +x;
    if(Number.isInteger(x))
    {
        return dataArray[x];
    }
    else if(dataArray.length === 2)
    {
        return getForFourPoints(x % 1, alpha,
            2*dataArray[0] - dataArray[1],
            dataArray[0],
            dataArray[1],
            2*dataArray[1] - dataArray[0]);
    }
    else if(x < 1)
    {
        return getForFourPoints(x % 1, alpha,
            2*dataArray[0] - dataArray[1],
            dataArray[0],
            dataArray[1],
            dataArray[2]);
    }
    else if(x > dataArray.length - 2)
    {
        return getForFourPoints(x % 1, alpha,
            dataArray[dataArray.length - 3],
            dataArray[dataArray.length - 2],
            dataArray[dataArray.length - 1],
            2*dataArray[dataArray.length - 1]
                - dataArray[dataArray.length - 2]);
    }
    else
    {
        return getForFourPoints(x % 1, alpha,
            dataArray[Math.floor(x) - 1],
            dataArray[Math.floor(x)],
            dataArray[Math.floor(x) + 1],
            dataArray[Math.floor(x) + 2]);
    }
    
}

function getForFourPoints(progress, alpha, p0, p1, p2, p3)
{
    var t0 = 0;
    var t1 = getT(p0, p1, alpha);
    var t2 = getT(p1, p2, alpha) + t1;
    var t3 = getT(p2, p3, alpha) + t2;
    
    var t = t1 + progress*(t2-t1);
    
	var A1 = (t1-t)/(t1-t0)*p0 + (t-t0)/(t1-t0)*p1;
	var A2 = (t2-t)/(t2-t1)*p1 + (t-t1)/(t2-t1)*p2;
	var A3 = (t3-t)/(t3-t2)*p2 + (t-t2)/(t3-t2)*p3;
		    
    var B1 = (t2-t)/(t2-t0)*A1 + (t-t0)/(t2-t0)*A2;
    var B2 = (t3-t)/(t3-t1)*A2 + (t-t1)/(t3-t1)*A3;
		    
    return (t2-t)/(t2-t1)*B1 + (t-t1)/(t2-t1)*B2;
}

function getT(pLeft, pRight, alpha)
{
    return Math.pow(1 + ((pLeft-pRight)*(pLeft-pRight)),
                    0.5*alpha);
}