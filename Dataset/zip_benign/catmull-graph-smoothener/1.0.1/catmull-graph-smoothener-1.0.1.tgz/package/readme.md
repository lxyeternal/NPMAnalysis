### What is this?

This package allows you to smoothen a list of data points and interpolate values between them.

### How to use this?

The package contains two methods: `create(dataArray)` a `createWithAlpha(dataArray, alpha)`. Both functions take an array of numbers and create an object with the following values:
* `points` - the data points stored just as provided.
* `alpha`  - must be in range 0-1, default is 0.5, higher values tend to create smoother curves.
They also provide the following methods:
* `getAt(x)`, which is used to read the y value of the graph at any float x between 0 and points.length - 1 inclusive. x corresponds to the position of points in the list of data points; 2.7 reads a value interpolated between points of indices 2 and 3 (third and fourth points).
* `bakeValues(precision)`, where precision is a positive integer, returns an array of values read from 0 in steps of 1/precision. For precision=1 this means that just the data points are returned.
* `bakeCoordinates(precision)`, where precision is a positive integer, works like the above function, but returns an array of 2-item arrays. First item is the x coordinate that would be used to get the value and the second item is the actual value.