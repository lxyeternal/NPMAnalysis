# @kyobobook/kbb-js

교보문고 Front-end JavaScript Pacakge (umd)

* <https://www.npmjs.com/package/@kyobobook/kbb-js>

## unpkg 배포 경로

* <https://unpkg.com/@kyobobook/kbb-js>
* <https://unpkg.com/@kyobobook/kbb-js@1.0.1/dist>
    
## browserlist

* <https://github.com/browserslist/browserslist>

```sh
# Browsers that we support
# npx browserlist '> 0.5%, last 2 versions, Firefox ESR, not dead, IE 11'
> 0.5%
last 2 versions
Firefox ESR
not dead
IE 11 # sorry
```

## [commands](COMMAND.md)

node package commands

## [LICENSE](LICENSE.md)

Copyright(c) 2021-2022 Kyobo Book Centre All right reserved.
This software is the proprietary information of Kyobo Book.
