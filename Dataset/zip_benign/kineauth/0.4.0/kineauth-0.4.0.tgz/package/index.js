'use strict';

var kineauth;
if (process.browser) {
  kineauth = require('./lib/kineauth-browserify');
} else {
  kineauth = require('./lib/kineauth-node');

  // add node-specific encrypt/decrypt
  kineauth.encrypt = require('./lib/encrypt');
  kineauth.decrypt = require('./lib/decrypt');
  kineauth.middleware = require('./lib/middleware/kineauth');
}

module.exports = kineauth;
