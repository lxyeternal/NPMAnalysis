### Installation

```
yarn add nori-sdk
```

### Initialization

```
import { Nori } from "nori-sdk";

const sdk = new Nori();
```

### Example Usage

```
import { Nori } from "nori-sdk";

const main = async () => {
  const quoteRequest = {
    inputTokenAddress: "0x6b175474e89094c44da98b954eedeac495271d0f", //DAI.ETH address on ethereum
    outputTokenAddress: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", // USDC address on solana
    sourceChainId: 1,
    destinationChainId: 88888,
    amount: "10000000000000000000", // input amount in wei
    slippage: 0.5,
  };

  const sdk = new Eddy();
  const quoteResponse = await sdk.bridge.getQuoteForBridge(quoteRequest);

  console.log(quoteResponse);

  const contractRequest = {
    inputTokenAddress: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
    outputTokenAddress: "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
    sourceChainId: 9999,
    destinationChainId: 137,
    amount: "100000000000000000000",
    slippage: 0.5,
    walletAddress: "0xF493118C11E32c6622933010775119622190BF2D",
  };

  const contractConfig = await sdk.bridge.getContractConfigForTx(
    contractRequest
  );
  console.log(contractConfig);

  // Fetches all active pools on zetachain
  const pools = await sdk.pool.getPools({ chainId: 7000 })

  console.log(pools);

  const tokens = await sdk.tokens.getSupportedCrossChainTokens({
    chainId: 1,
  });

  console.log(tokens);

  // Fetches tokens supported for swapping on same chain
  const swaptoken = await sdk.tokens.getSupportedSameChainTokens({
    chainId: 7000,
  });

  console.log(swaptoken);

  //Fetches tokens support for cross chain bridging
  const supportedchains = await sdk.bridge.getSupportedChains();

  console.log(supportedchains);
};

main();


```
