module.exports = {

  add: function add(array) {
  if(!Array.isArray(array)) {
    if(typeof array == "string") {
      array = array.split(',')
    } else {
      return null
    }
  }
let checkArray = array.every(e => isNaN(e)); // any condition

if(checkArray != false) {
return "One or more provided arguments are not numbers!"
}
for (var i = 0, sum = 0; i < array.length; sum += Number(array[i++]));
return sum
},
multi: function multi(array) {
  if(!Array.isArray(array)) {
    if(typeof array == "string") {
      array = array.split(',')
    } else {
      return null
    }
  }
let checkArray = array.every(e => isNaN(e)); // any condition

if(checkArray != false) {
return "One or more provided arguments are not numbers!"
}
for (var i = 1, sum = array[0]; i < array.length; sum *= Number(array[i++]));
return sum
},
subtr: function subtr(array) {
  if(!Array.isArray(array)) {
    if(typeof array == "string") {
      array = array.split(',')
    } else {
      return null
    }
  }
let checkArray = array.every(e => isNaN(e)); // any condition

if(checkArray != false) {
return "One or more provided arguments are not numbers!"
}
for (var i = 1, sum = array[0]; i < array.length; sum -= Number(array[i++]));
return sum
},
div: function div(array) {
  if(!Array.isArray(array)) {
    if(typeof array == "string") {
      array = array.split(',')
    } else {
      return null
    }
  }
let checkArray = array.every(e => isNaN(e)); // any condition

if(checkArray != false) {
return "One or more provided arguments are not numbers!"
}
for (var i = 1, sum = array[0]; i < array.length; sum /= Number(array[i++]));
return sum
},
pow: function pow(array) {
  if(!Array.isArray(array)) {
    if(typeof array == "string") {
      array = array.split(',')
    } else {
      return null
    }
  }
let checkArray = array.every(e => isNaN(e)); // any condition

if(checkArray != false) {
return "One or more provided arguments are not numbers!"
}
for (var i = 1, sum = array[0]; i < array.length; sum **= Number(array[i++]));
return sum
},
avg:  function avg(array) {
  if(!Array.isArray(array)) {
    if(typeof array == "string") {
      array = array.split(',')
    } else {
      return null
    }
  }
let checkArray = array.every(e => isNaN(e)); // any condition

if(checkArray != false) {
return "One or more provided arguments are not numbers!"
}
for (var i = 0, sum = 0; i < array.length; sum += Number(array[i++]));
var ans = sum / array.length
return ans
}
}