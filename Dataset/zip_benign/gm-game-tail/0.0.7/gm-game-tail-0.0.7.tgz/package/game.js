let PIXI, particles;
let Game = function (options) {
  this.options = Object.assign({}, options);

  let padding = Object.assign({
    left: 0,
    top: 0,
    right: 0,
    bottom: 0
  }, this.options.gameSource.padding);
  // 音频
  if (!!this.options.innerAudioContext) {
    this.innerAudioContext = this.options.innerAudioContext;
  }
  this.padding = {
    left: padding.left * this.options.$game.fObj.scale,
    right: padding.right * this.options.$game.fObj.scale,
    top: padding.top * this.options.$game.fObj.scale,
    bottom: padding.bottom * this.options.$game.fObj.scale,
  };
  PIXI = this.options.$game.fObj.PIXI;
  particles = this.options.$game.fObj.PIXI.particles;
  this.width = this.options.$game.fObj.size.windowWidth;
  this.height = this.options.$game.fObj.size.windowHeight;

  // 1.创建pixi需要的对象 容器
  // 精灵容器
  this.spriteContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.spriteContainer);
  // 尾巴
  this.TailBox = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.TailBox);
  // 操作元素容器 (只有一个元素)
  this.playerContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.playerContainer);
  // 引导提示
  this.guideContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.guideContainer);
  // 倒计时容器
  this.timeContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.timeContainer);
  // 开始倒计时容器
  this.beginTimeContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.beginTimeContainer);
  // 分数容器
  this.scoreContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.scoreContainer);
  // 选中轨道状态容器
  this.touchContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.touchContainer);
  // 小分数容器
  this.minScoreContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.minScoreContainer);
  // 提示小分数容器
  this.tipScoreContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.tipScoreContainer);
  // 大分数容器
  this.maxScoreContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.maxScoreContainer);
  // 动画容器
  this.animateContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.animateContainer);

  // 绘制个矩形，解决触摸事件
  let rect1 = new PIXI.Graphics();
  rect1.beginFill(0xff0000, 0);
  rect1.drawRect(0, 0, this.width, this.height);
  rect1.endFill();
  this.playerContainer.addChild(rect1);
  this.playerContainer.setChildIndex(rect1, 0);

  // 2.遍历图片资源 并 去重
  let imgArr = [];
  options.gameSource = JSON.parse(JSON.stringify(options.gameSource));
  this.traverse(options.gameSource, function (k, v) {
    if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
      imgArr.push(v);
    }
  })
  if (!!options.touchObj) {
    options.touchObj = JSON.parse(JSON.stringify(options.touchObj));
    this.traverse(options.touchObj, function (k, v) {
      if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
        imgArr.push(v);
      }
    })
  }

  // 定时更新
  this.ticker = PIXI.ticker.shared;
  // this.ticker.speed = 5;
  this.ticker.autoStart = false;
  this.ticker.addOnce(() => { });

  // 3.加载图片资源
  if (imgArr.length > 0) {
    let loader = new PIXI.loaders.Loader();
    imgArr.forEach(item => {
      loader.add(this.uniId(), item);
    })
    this.pixiLoadFun(loader);
  } else {
    this.init({});
    this.options.initDone();
  }
  // 绑定事件
  if (!!options.gameSource.playerInfo) {
    // 滑动事件
    this.bindEvent();
  } else {
    if (!!options.touchObj) {
      // 缩放点击事件
      this.bindTouchEvent();
    } else {
      // 点击元素事件
      this.bindClickEvent();
    }
  }

  this.ticker.add(() => this.draw());
}
Game.prototype = Object.assign(Game.prototype, {
  pixiLoadFun: function (loader) {
    let time1 = new Date().getTime();
    loader.on("progress", e => {
      this.options.progressFun(e.progress);
    })
    loader.on("error", e => {
      this.options.errorFun(e);
    })
    loader.load(() => {
      // 资源加载完成
      time1 = "";
      this.init({});
      this.options.initDone();
    });
    setTimeout(() => {
      // 5秒还没加载完，重新加载一遍
      if (!!time1) {
        console.log("重新加载资源...")
        this.pixiLoadFun(loader);
      }
    }, 5000)
  },
  uniId: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  },
  random: function (options) {
    let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
    let tempNum;
    do {
      let num = Math.random() * (opt.max - opt.min) + opt.min;
      tempNum = !!opt.isFloat ? num : parseInt(num);
    } while (opt.noNum.includes(tempNum));
    return tempNum;
  },
  isArray: function (obj) {
    return obj instanceof Array;
  },
  isObject: function (obj) {
    // 判断数组对象
    if (!(obj instanceof Array) && (obj instanceof Object)) {
      return true;
    }
    return false;
  },
  traverse: function (obj, callback) {
    // 遍历json
    for (let name in obj) {
      // 如果是json对象
      if (this.isObject(obj[name])) {
        this.traverse(obj[name], callback);
      } else if (this.isArray(obj[name])) {
        // 数组对象
        obj[name].forEach(item => {
          this.traverse(item, callback);
        })
      } else {
        callback(name, obj[name]);
      }
    }
  },
  audioFun: function (name) {
    if (!name) { return false; }
    let tempAudio;
    if (!!this.fAudio) {
      this.fAudio.destroy();
    }
    const innerAudioContext = my.createInnerAudioContext();
    this.fAudio = innerAudioContext;
    for (let audioName in this.options.audio) {
      let audioObj = this.options.audio[audioName];

      if (!!name && name == audioName) {
        tempAudio = audioObj;
      }
    }
    if (!!tempAudio) {
      this.fAudio.src = tempAudio.src;
      this.fAudio.play();
    }
  },
  bindEvent: function () {
    // 绑定事件
    this.playerContainer.interactive = true;
    this.touchIng = false;
    this.playerContainer.on('touchend', (e) => {
      if (this.iStart != "start") { return false; }
      if (!(!!this.playerSprite && !!this.playerSprite.visible)) { return false; }
      if (!!this.touchIng) { return false; }
      this.touchIng = true;
      // 移动操作元素
      let min = (this.width / 4 - this.playerSprite.width / 2);
      let max = (this.width / 4 * 3 - this.playerSprite.width / 2);

      let to = min;
      if (this.playerSprite.x == min) {
        to = max;
      }
      this.to = to;
    })
  },
  bindTouchEvent: function () {
    // 绑定事件
    this.playerContainer.interactive = true;
    let singleW = this.width / (this.options.gameCol || 3);
    this.playerContainer.on('touchstart', (e) => {
      if (this.iStart != "start" || !!this.touched) {
        return false;
      }

      let x = e.data.global.x,
        y = e.data.global.y;

      // 1.判断用户是否点击了可点区域
      let topY = this.options.touchObj.top * this.options.$game.fObj.scale;
      let bottomY = this.options.touchObj.bottom * this.options.$game.fObj.scale;
      let tempH = (bottomY - topY);
      let centerY = topY + tempH / 2;

      if (y < topY || y > bottomY) {
        this.touched = false;
        return false;
      }
      // 2.判断用户点击了哪列
      let col = Math.ceil(x / singleW) - 1;
      this.touched = { topY, bottomY, tempH, centerY, col };
    })
    this.playerContainer.on('touchend', (e) => {
      this.touched = false;
    })
  },
  bindClickEvent: function () {// 绑定事件
    this.playerContainer.interactive = true;
    this.clickInfo = null;
    this.playerContainer.on('touchstart', (e) => {
      if (this.iStart != "start") { return false; }
      let x = e.data.global.x,
        y = e.data.global.y;
      this.clickInfo = { x, y };
    })
    this.playerContainer.on('touchend', (e) => {
      this.clickInfo = null;
    })
  },
  showTipFun: function (scoreTip) {
    // 绘制类型
    this.hideSpriteArrFun("maxScoreSpriteArr");
    this.hideSpriteArrFun("minScoreSpriteArr");
    let scoreType = Object.assign({ type: "maxScore" }, scoreTip);
    scoreType.type = "maxScore";
    scoreType.x = (this.width - scoreType.width * this.options.$game.fObj.scale) / 2;
    scoreType.y = scoreType.top * this.options.$game.fObj.scale;
    let typeSprite = this.renderSprite(scoreType);
    // 绘制提示下面的分数---------------------------
    this.renderMinScoreFun(typeSprite);

    if (!!scoreTip.fadeTime) {
      typeSprite.endTime = new Date().getTime() + scoreTip.fadeTime;
      if (!!this.typeSprite1) {
        this.typeSprite1.visible = false;
      }
      this.typeSprite1 = typeSprite;
    }
  },
  renderMinScoreFun: function (sprite) {
    /* [{
      minTime: 20,
      maxTime: 30,
      score: [{
        min: 80,//最小百分比
        max: 100,//最大百分比
        score: 15,//分数
        type: "PERFECT",//类型
        src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GyyUAh1FJvbE05YOr_!!1080040467.png",
        width: 366,
        height: 108,
        top: 650,
        fadeTime: 500,//毫秒 显示多久消失 0就不消失，直到下次更新状态
        add: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018kU1tj1FJvbE08N6F_!!1080040467.png", width: 91, height: 92,showWidth:37 },
        minNum: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lZsEBV1FJvbAB7ucU_!!1080040467.png", width: 930, height: 108, fadeTime: 500,showWidth: 48 },
      },]
    }]; */
    let scoreObj = sprite.imgObj;
    // 绘制小分数
    // 1.隐藏小分数
    // this.hideSpriteArrFun("minScoreSpriteArr");
    // 2.绘制
    let scoreArr = (scoreObj.score + "").split("");//分数
    let endSprite;
    let singleW = scoreObj.minNum.width / 10;
    let singleW1 = scoreObj.minNum.showWidth || (scoreObj.minNum.width / 10);
    // 需要显示的中心点
    let centerX = sprite.x + sprite.width / 2;
    // 数字总宽度
    let numW = scoreArr.length * (singleW1 * this.options.$game.fObj.scale);
    // 加号宽度
    let addW;
    try {
      addW = (scoreObj.add.showWidth || scoreObj.add.width) * this.options.$game.fObj.scale;
    } catch (e) {
      addW = 0;
    }
    let baseX = centerX - (addW + numW) / 2;
    let tempH = Math.max(scoreObj.add.height, scoreObj.minNum.height);
    let tempH2 = (scoreObj.minNum.top || 0) * this.options.$game.fObj.scale;
    // 2.1 绘制加号
    try {
      let addObj = Object.assign({ type: "minScore" }, scoreObj.add);
      addObj.x = baseX + (addW - addObj.width * this.options.$game.fObj.scale) / 2;
      addObj.y = sprite.y + sprite.height + (tempH - scoreObj.add.height) * this.options.$game.fObj.scale / 2 + tempH2;
      endSprite = this.renderSprite(addObj);
    } catch (e) {
      endSprite = {
        x: 0,
        width: scoreObj.minNum.width * this.options.$game.fObj.scale
      };
    }
    // 2.2 绘制数字
    scoreArr.forEach((num) => {
      let numObj = Object.assign({ type: "minScore" }, scoreObj.minNum);
      let showWidth = endSprite.width;
      try {
        showWidth = endSprite.imgObj.showWidth * this.options.$game.fObj.scale;
      } catch (e) { }
      numObj.x = endSprite.x + showWidth;
      numObj.y = sprite.y + sprite.height + (tempH - scoreObj.minNum.height) * this.options.$game.fObj.scale / 2 + tempH2;
      numObj.width = singleW;
      endSprite = this.renderSprite(numObj, { x: singleW * num });
    });
  },
  frame: function (img, x, y) {
    // 返回texture
    let source = img.src, width = img.width, height = img.height;

    let texture, imageFrame;
    if (typeof source === "string") {
      if (PIXI.utils.TextureCache[source]) {
        texture = new PIXI.Texture(PIXI.utils.TextureCache[source]);
      }
    }
    if (!texture) { console.log(`Please load the ${source} texture into the cache.`); } else {
      imageFrame = new PIXI.Rectangle(x, y, width, height);
      texture.frame = imageFrame;
      return texture;
    }
  },
  renderSprite: function (tImg, ops) {
    let sprite;
    if (!tImg.uniId) {
      // 没有唯一标识，说明第一次生成
      if (tImg.type == "animate") {
        // 动画
        let textures = [];
        tImg.srcArr.forEach(img => {
          textures.push(this.frame(img, 0, 0));
        })
        sprite = new PIXI.extras.AnimatedSprite(textures);
        sprite.animationSpeed = tImg.boomSpeed;
        sprite.loop = false;
        sprite.onComplete = function () {
          if (!!tImg.maxAnimate) {
            // 执行回调
            try {
              tImg.callback(sprite);
            } catch (e) { }
          }
          // this.visible = false;
        }
      } else {
        sprite = new PIXI.Sprite();

        let options = Object.assign({ x: 0, y: 0 }, ops);
        sprite.texture = this.frame(tImg, options.x, options.y);
        // sprite.texture = this.frame(tImg, 0, 0);
      }

      sprite.width = tImg.width * this.options.$game.fObj.scale;
      sprite.height = tImg.height * this.options.$game.fObj.scale;
      if (!tImg.x && typeof tImg.x === "undefined") {
        let totalCol = (this.options.gameCol || 3);
        let curCol = tImg.colIndex;
        let singleColW = (this.width - this.padding.left - this.padding.right) / totalCol;
        tImg.x = this.padding.left + (singleColW - sprite.width) / 2 + curCol * singleColW;
      }

      sprite.x = (tImg.x || 0);
      sprite.y = (tImg.y || 0);
      sprite.imgObj = tImg;

      tImg.sprite = sprite;
      tImg.uniId = this.uniId();

      if (tImg.type == "player") {
        // 操作球
        sprite.x = (this.width / 4 - sprite.width / 2);
        sprite.y = (this.height - sprite.height) / 2;
        this.playerSprite = sprite;
        this.playerContainer.addChild(sprite);

        if (!!tImg.userImg) {
          this.renderSprite(Object.assign({
            type: "userImg",
            x: 0,
            y: 0
          }, tImg.userImg));
        }
      } else if (tImg.type == "guide") {
        if (!!tImg.globalName) {
          this[tImg.globalName] = sprite;
        }
        this.guideArr.push(sprite);
        this.guideContainer.addChild(sprite);
      } else if (tImg.type == "score") {
        sprite.y = (tImg.y || 0);
        sprite.type = tImg.type;
        if (tImg.ttW) {
          sprite.width = tImg.ttW * this.options.$game.fObj.scale;
          sprite.height = tImg.ttH * this.options.$game.fObj.scale;
          sprite.x = (this.width - sprite.width) / 2;
        }
        if (!!tImg.isBg) {
          this.scoreBgSprite = sprite;
        } else {
          this.scoreSpriteArr.push(sprite);
        }
        this.scoreContainer.addChild(sprite);
      } else if (tImg.type == "touchBg") {
        this.touchSpriteArr.push(sprite);
        this.touchContainer.addChild(sprite);
      } else if (tImg.type == "beginTime") {
        sprite.x = (this.width - sprite.width) / 2;
        sprite.y = (this.height - sprite.height) / 2;
        this.beginTimeSpriteArr.push(sprite);
        this.beginTimeContainer.addChild(sprite);
      } else if (tImg.type == "time") {
        sprite.y = (tImg.y || 0);
        sprite.type = tImg.type;

        if (!!tImg.isBg) {
          this.timeBgSprite = sprite;
        } else {
          this.timeSpriteArr.push(sprite);
        }
        this.timeContainer.addChild(sprite);
      } else if (tImg.type == "animate") {
        sprite.type = tImg.type;
        if (!!tImg.globalName) {
          this[tImg.globalName] = sprite;
        }
        sprite.stop()
        sprite.gotoAndPlay(0)
        this.animateSpriteArr.push(sprite);
        this.animateContainer.addChild(sprite);
      } else if (tImg.type == "minScore") {
        this.minScoreSpriteArr.push(sprite);
        this.minScoreContainer.addChild(sprite);
      } else if (tImg.type == "maxScore") {
        this.maxScoreSpriteArr.push(sprite);
        this.maxScoreContainer.addChild(sprite);
      } else if (tImg.type == "tipScore") {
        this.tipScoreSpriteArr.push(sprite);
        this.tipScoreContainer.addChild(sprite);
      } else if (tImg.type == "userImg") {
        sprite.baseX = (this.playerSprite.imgObj.padding || 0) * this.options.$game.fObj.scale;
        let r = (this.playerSprite.width - (sprite.baseX * 2)) / 2;

        sprite.width = 2 * r;
        sprite.height = 2 * r;
        sprite.x = this.playerSprite.x + sprite.baseX;
        sprite.y = this.playerSprite.y + sprite.baseX;

        // 绘制用户头像圆角
        let userImg = new PIXI.Graphics();
        userImg.beginFill(0xff0000, 0);
        userImg.drawCircle(sprite.x + r, sprite.y + r, r);
        userImg.endFill();

        this.userMask = userImg;
        sprite.mask = userImg;

        this.playerUserSprite = sprite;

        this.playerContainer.addChild(sprite);
        // this.options.$game.fObj.application.stage.addChild(userImg);
      } else {
        let curBoundTop = 0;
        let curBoundBottom = 0;
        try {
          curBoundTop = tImg.bound.top * this.options.$game.fObj.scale;
        } catch (e) { }
        try {
          curBoundBottom = tImg.bound.bottom * this.options.$game.fObj.scale;
        } catch (e) { }

        if (typeof this.options.gameCol == "undefined") {
          sprite.x = (this.width - sprite.width) / 2;
        }
        sprite.y = (tImg.y || 0) - sprite.height + curBoundBottom;
        this.nextRenderY = sprite.y + curBoundTop;
        sprite.type = !!tImg.type;
        sprite.visible = false;
        this.spriteArr.push(sprite);
        this.spriteContainer.addChild(sprite);

        this.lastSprite = sprite;

        this.checkDegShowSpriteFun(sprite);
      }
    } else {
      sprite = tImg.sprite;
    }
    return sprite;
  },
  checkDegShowSpriteFun(sprite) {
    if (!!sprite.noCheck) {
      return false;
    }
    if (typeof this.options.minDegWidth != "undefined") {
      /* 
              -----minDegWidth----
             /          |         \
            /     minTomaxHeight   \
           /            |           \
           --------maxDegWidth--------
       */
      // =============================================
      // 缩放比例
      let baseW = this.options.minDegWidth * this.options.$game.fObj.scale;
      let sW1 = (this.options.maxDegWidth - this.options.minDegWidth) / this.options.minTomaxHeight;
      // 轨道总宽度
      let tempCurW = baseW + sW1 * (sprite.y - this.padding.top);
      let leftX = (this.width - tempCurW) / 2;
      let tempScale = tempCurW / (this.options.maxDegWidth * this.options.$game.fObj.scale);
      // 总轨道条数
      let totalCol = this.options.gameCol || 3;
      // 当前元素轨道
      let curCol = sprite.imgObj.colIndex;
      // 单行轨道宽度
      let singleW = tempCurW / totalCol;

      let w = sprite.imgObj.width * this.options.$game.fObj.scale, h = sprite.imgObj.height * this.options.$game.fObj.scale;
      sprite.width = w;
      sprite.height = h;

      let tScale1 = Math.min(tempScale, 2);
      tScale1 = tScale1 * this.options.$game.fObj.scale;

      sprite.scale.set(tScale1, tScale1);
      sprite.x = leftX + curCol * singleW + (singleW - sprite.width) / 2;

      if (sprite.y + sprite.height < this.padding.top || sprite.y > this.height || sprite.x > this.width - leftX || sprite.x + sprite.width < leftX) {
        sprite.visible = false;
      } else {
        sprite.visible = true;
      }
    } else {
      if (sprite.y + sprite.height < this.padding.top || sprite.y > this.height || sprite.x > this.width || sprite.x + sprite.width < 0) {
        sprite.visible = false;
      } else {
        sprite.visible = true;
      }
    }
  },
  // 添加障碍物
  addBlock: function () {
    if (typeof this.nextRenderY != "undefined") {
      // 生成下一个元素
      this.renderBlock();
      if (!!this.lastSprite && this.nextRenderY - this.maxJGH >= -this.height) {
        this.nextRenderY = this.lastSprite.y - this.maxJGH;
        this.calcNextRenderY = this.maxJGH;

        this.addBlock();
      } else {
        this.nextRenderY = undefined;
      }
    }
  },
  renderBlock: function () {
    let energyArr = [],//正负能量球都存在
      barrierArr = [];//触碰到就游戏结束的障碍物
    let energyArr1 = [];//全是正能量球
    let energyArr2 = [];//全是负能量球（触碰到不结束的障碍物）
    let energyTotalProbability = 0, barrierTotalProbability = 0;
    let energyTotalProbability1 = 0;
    let energyTotalProbability2 = 0;
    !!this.options.gameSource.energyArr && this.options.gameSource.energyArr.forEach(item => {
      let showHeight = item.showHeight || 0;
      if (showHeight <= ((this.totalCount || 0) / 10)) {
        item.probability = item.probability || 1;
        item.max = energyTotalProbability + item.probability
        energyTotalProbability = item.max;
        energyArr.push(Object.assign({}, item));

        if (!!item.val && item.val < 0) {
          // 能量为负数的球
          item.max = energyTotalProbability2 + item.probability
          energyTotalProbability2 = item.max;
          energyArr2.push(Object.assign({}, item));
        } else {
          // 能量为正数的球
          item.max = energyTotalProbability1 + item.probability
          energyTotalProbability1 = item.max;
          energyArr1.push(Object.assign({}, item));
        }
      }
    });
    !!this.options.gameSource.barrierArr && this.options.gameSource.barrierArr.forEach(item => {
      let showHeight = item.showHeight || 0;
      if (showHeight <= ((this.totalCount || 0) / 10)) {
        item.probability = item.probability || 1;
        item.max = barrierTotalProbability + item.probability
        barrierTotalProbability = item.max;
        barrierArr.push(Object.assign({}, item));
      }
    })
    let energyProbability = this.options.gameSource.energyProbability || 1;
    let barrierProbability = this.options.gameSource.barrierProbability || 1;
    if (barrierProbability < 1) {
      barrierProbability = 0;
    }
    // 根据能量和障碍物的概率生成对应元素

    let num1 = this.random({ max: energyProbability + barrierProbability });
    let renderArr, maxProbability, spriteType;
    if (!!this.maxEnergyNum && this.maxEnergyNum <= this.curEnergyNum) {
      // 如果有限制能量球个数，当达到上限后，只生成障碍物
      num1 = energyProbability;
    }
    if (num1 < energyProbability || barrierArr.length <= 0) {
      // 生成能量元素
      renderArr = energyArr;
      maxProbability = energyTotalProbability;
      spriteType = true;
    } else {
      // 生成障碍物元素
      renderArr = barrierArr;
      maxProbability = barrierTotalProbability;
      spriteType = false;
    }
    let notArr = [];
    if (typeof this.lastColIndex != "undefined") {
      notArr.push(this.lastColIndex);
    }
    // 计算当前渲染在哪条道上
    let colIndex = this.random({ max: (this.options.gameCol || 3), noNum: notArr });
    // 此次生成的元素
    let defaultImg;
    let tempIndex = this.random({ max: maxProbability });
    renderArr.forEach(item => {
      if (!defaultImg && item.max > tempIndex) {
        defaultImg = Object.assign({
          colIndex,
          y: this.nextRenderY,
          type: spriteType,
        }, item);
      }
    })
    // 更新下一个元素出现高度
    this.maxJGH -= (this.options.barrierHeightStep || 0);
    if (!this.options.gameSource.JGH) {
      try {
        this.maxJGH = Math.max((this.playerSprite.height + 5), this.maxJGH);//两个障碍物间的高度 (最低高度为玩家高度+5)
      } catch (e) {
        this.maxJGH = Math.max((5), this.maxJGH);//两个障碍物间的高度 (最低高度为玩家高度+5)
      }
    } else {
      this.maxJGH = Math.max(this.options.gameSource.JGH, this.maxJGH);//两个障碍物间的高度 (最低高度为玩家高度+5)
    }

    if (!!defaultImg) {
      try {
        if (!!defaultImg.val && defaultImg.val > 0) {
          // 生成了能量为正数的元素
          this.curEnergyNum++;
        }
      } catch (e) { }
      this.lastColIndex = colIndex;
      let curSprite = this.renderSprite(defaultImg);
      curSprite.cIdx = this.cIdx++;
      // 生成引导提示
      if (!!this.options.gameSource.guideTip && !!this.options.gameSource.guideTip[curSprite.cIdx]) {
        let guideImg = Object.assign({
          type: "guide",
          globalName: 'guide' + curSprite.cIdx
        }, this.options.gameSource.guideTip[curSprite.cIdx]);
        guideImg.y = (curSprite.height - guideImg.height * this.options.$game.fObj.scale) / 2 + curSprite.y;
        let type = "left";
        if ((!!this.prevShowType && this.prevShowType == "left") || (!!guideImg.showPos && guideImg.showPos == "right")) {
          type = "right";
        }
        this.prevShowType = type;
        let tempX = 0;
        if (type == "left") {
          tempX = (curSprite.x - guideImg.width * this.options.$game.fObj.scale) / 2;
        } else {
          let baseX = curSprite.x + curSprite.width;
          tempX = baseX + (this.width - baseX - guideImg.width * this.options.$game.fObj.scale) / 2;
        }
        guideImg.x = tempX;

        this.renderSprite(guideImg);
      }
    }
  },
  // 获取了能量
  updateFun: function (item) {
    if (!!item.imgObj.activeImg) {
      // 播放动画
      let w = item.imgObj.activeImg[0].width, h = item.imgObj.activeImg[0].height;
      let animateObj = Object.assign({}, {
        type: "animate",
        maxAnimate: true,
        srcArr: item.imgObj.activeImg,
        boomSpeed: item.imgObj.activeSpeed,
        width: w,
        height: h,
        x: item.x + (item.width - w * this.options.$game.fObj.scale) / 2,
        y: item.y + (item.height - h * this.options.$game.fObj.scale) / 2,
        callback: (spri) => {
          setTimeout(() => {
            try {
              spri.visible = false;
            } catch (e) { }
          }, (item.imgObj.fadeTime || 0.01) * 1000);
        }
      });
      this.renderSprite(animateObj);
    }
    try {
      let audioName = item.imgObj.audioName;
      if (!!audioName) {
        this.audioFun(audioName);
      }
    } catch (e) { }
    this.tipScoreFun(item);
    try {
      let curIndex = item.imgObj.colIndex;
      if (!!this.options.touchObj.activeBg) {
        // 有需要显示的背景轨道
        let img = Object.assign({
          type: "touchBg",
          x: 0,
          y: 0
        }, this.options.touchObj.activeBg[curIndex]);
        img.x = img.x * this.options.$game.fObj.scale;
        img.y = img.y * this.options.$game.fObj.scale;
        let sprite = this.renderSprite(img);

        if (!!img.fadeTime) {
          sprite.endTime = new Date().getTime() + img.fadeTime;
          this.bgSprite1 = sprite;
        }
      }
    } catch (e) { }
    try {
      this.renderScore(this.totalScore);
    } catch (e) { }
    try {
      this.options.updateFun(item);
    } catch (e) { }
    // 吃到了该元素，player是否有改变
    let imgObj = item.imgObj;
    if (!!imgObj.changePlayer) {
      // 要改变player元素
      this.changePlayerFun(item);
    }
    if (!!imgObj.isPause) {
      // 暂停游戏
      this.pause();
    }
  },
  changePlayerFun(sprite) {
    // 改变player元素
    this.hideSpriteArrFun("animateSpriteArr");

    let imgObj = sprite.imgObj;
    let changePlayer = imgObj.changePlayer;
    // 操作球
    let playerInfo = this.playerSprite.imgObj,
      maxTime = changePlayer.boomSpeed || 0;
    let w1 = changePlayer.boomArr[0].width, h1 = changePlayer.boomArr[0].height;
    let cw1 = w1 - playerInfo.width, ch1 = h1 - playerInfo.height;
    // 操作球有序列帧动画
    let animateObj = Object.assign({}, {
      type: "animate",
      globalName: "playerClone",
      maxAnimate: true,
      srcArr: changePlayer.boomArr,
      boomSpeed: maxTime,
      width: w1,
      height: h1,
      x: this.playerSprite.x - cw1 / 2 * this.options.$game.fObj.scale,
      y: this.playerSprite.y - ch1 / 2 * this.options.$game.fObj.scale,
      callback: (spri) => {
        setTimeout(() => {
          try {
            this.playerSprite.visible = true;
            spri.visible = false;
          } catch (e) { }
        }, (changePlayer.fadeTime || 0.01) * 1000);
      }
    });
    this.renderSprite(animateObj);
    if (!!changePlayer.hidePlayer) {
      this.playerSprite.visible = false;
    }
  },
  upTailFun: function () {
    if (!!this.TailEmitter) {
      let now = Date.now();
      this.TailEmitter.update((now - this.TailElapsed) * 0.001);
      this.TailElapsed = now;
      // //这个是设置粒子坐标 达到拖尾效果
      this.TailEmitter.updateOwnerPos(this.playerSprite.x + this.playerSprite.width / 2, this.playerSprite.y + this.playerSprite.height / 4 * 2)
    }
  },
  /**
   * 刷新粒子跟随效果
   * @param {*} FollowNode 跟随节点
   * @param {*} emitter 发射器
   * @param {*} elapsed 过去时间
   */
  draw: function (name) {
    // 绘图
    this.addBlock();
    if (!!this.to) {
      // 需要移动player
      let curX = this.playerSprite.x;
      let toX = curX;
      let stepPlayer = this.options.gameSource.playerInfo.speed || 10;
      if (this.to > curX) {
        // player需要向右移动
        if (curX + stepPlayer < this.to) {
          toX = curX + stepPlayer;
        } else {
          toX = this.to;
          this.to = 0;
          this.touchIng = false;
        }
      } else {
        // player需要向左移动
        if (curX - stepPlayer > this.to) {
          toX = curX - stepPlayer;
        } else {
          toX = this.to;
          this.to = 0;
          this.touchIng = false;
        }
      }

      this.playerSprite.x = toX;
    }
    this.upTailFun();

    if (this.calcNextRenderY <= 0 && typeof this.nextRenderY == "undefined" && (this.lastSprite.y - this.maxJGH) >= -this.height) {
      this.nextRenderY = this.lastSprite.y - this.maxJGH;
      this.calcNextRenderY = this.maxJGH;
    }
    this.calcNextRenderY -= this.speed;
    // 能量和障碍物
    let obj = null;
    let tempStop = false;
    let curTime = new Date().getTime();
    if (!!this.bgSprite1 && !!this.bgSprite1.visible) {
      let endTime = this.bgSprite1.endTime;
      if (curTime >= endTime) {
        this.bgSprite1.visible = false;
      }
    }
    if (!!this.typeSprite1 && this.typeSprite1.visible) {
      let endTime = this.typeSprite1.endTime;
      if (curTime >= endTime) {
        this.typeSprite1.visible = false;
        this.hideSpriteArrFun("minScoreSpriteArr");
      }
    }
    this.spriteArr.forEach(item => {
      if (item.y <= this.height) {
        if (!!item.visible) {
          let imgObj = item.imgObj;
          // bound: { width: 70, top: 60, bottom: 24 }
          let x = item.x;
          let y = item.y;
          let width = item.width;
          let height = item.height;
          // 障碍物边界-----------------
          let bound = Object.assign({ left: 0, top: 0, right: 0, bottom: 0 }, imgObj.bound);
          if (!!bound) {
            let left = (bound.left / imgObj.width) * width;
            let right = (bound.right / imgObj.width) * width;
            let top = (bound.top / imgObj.height) * height;
            let bottom = (bound.bottom / imgObj.height) * height;

            x = x + left;
            width = width - left - right;
            y = y + top;
            height = height - top - bottom;
          }
          if (!!this.playerSprite) {
            // 障碍物边界-----------------
            let boolX = ((x <= this.playerSprite.x && this.playerSprite.x <= x + width) || (x <= this.playerSprite.x + this.playerSprite.width && this.playerSprite.x + this.playerSprite.width <= x + width));
            let boolX1 = (this.playerSprite.x <= x && x <= this.playerSprite.x + this.playerSprite.width) || (this.playerSprite.x <= x + width && x + width <= this.playerSprite.x + this.playerSprite.width)
            let boolY = ((y <= this.playerSprite.y && this.playerSprite.y <= y + height) || (y <= this.playerSprite.y + this.playerSprite.height && this.playerSprite.y + this.playerSprite.height <= y + height))
            let boolY1 = (this.playerSprite.y <= y && y <= this.playerSprite.y + this.playerSprite.height) || (this.playerSprite.y <= y + height && y + height <= this.playerSprite.y + this.playerSprite.height);
            if ((boolY || boolY1) && (boolX || boolX1)) {
              if (!item.type) {
                // 障碍物
                // 标识已经被触发过一次 防止继续游戏时出发
                if (!item.old) {
                  // 第一次碰到障碍物了，游戏结束
                  if (!!this.options.noOver) {
                    obj = item;
                  } else {
                    tempStop = true;
                    this.overSprite = item;
                  }
                  item.old = true;
                } else {
                  item.visible = false;
                }
              } else {
                // 碰到能量
                obj = item;
                this.totalScore += (imgObj.val || 0);
                item.visible = false;
              }
            }
          }
          if (!!this.clickInfo) {
            // 点击坐标
            if (x <= this.clickInfo.x && this.clickInfo.x <= x + width) {
              if (y <= this.clickInfo.y && this.clickInfo.y <= y + height) {
                // 点中了该元素
                item.visible = false;
                obj = item;
                this.totalScore += (imgObj.val || 0);
              }
            }
          }
          // 点击匹配对应列的元素
          if (!!this.touched) {
            let { col, centerY, tempH } = this.touched;
            if (imgObj.colIndex == col && !!item.visible && !item.clickStatus) {
              let spritePos = {
                top: item.y + bound.top * this.options.$game.fObj.scale,
                bottom: item.y + (imgObj.height - bound.bottom) * this.options.$game.fObj.scale,
                left: item.x - bound.left * this.options.$game.fObj.scale,
                right: item.x + (imgObj.width - bound.right) * this.options.$game.fObj.scale,
              };
              spritePos.tempH = (spritePos.bottom - spritePos.top);
              spritePos.centerY = spritePos.top + spritePos.tempH / 2;
              // 判断元素是否进入可点击区域
              if (Math.abs(centerY - spritePos.centerY) <= (tempH + spritePos.tempH) / 2) {
                obj = item;
                this.touched = false;
                // 点击中了元素
                // 1.标记点击状态
                item.clickStatus = true;
                item.visible = false;
                item.noCheck = true;
                // 2.生成点击后的图片
                // this.clickBlockFun(sprite);
                // 3.更新分数
                let per = 1 - Math.abs(centerY - spritePos.centerY) / ((tempH + spritePos.tempH) / 2);
                let curTime = new Date().getTime();
                let oldTime = this.curTime;
                if (!!this.startTime) {
                  oldTime = parseInt((curTime - this.startTime) / 1000);
                }
                let time = this.curTime - oldTime;

                let scoreTip;
                this.options.touchObj.scoreRange.forEach(item => {
                  if (item.minTime < time && time <= item.maxTime) {
                    // 在此分数段
                    item.score.forEach(score => {
                      if (score.min < (per * 100) && (per * 100) <= score.max) {
                        // 此类型提示
                        scoreTip = score;
                      }
                    })
                  }
                })
                if (!!scoreTip) {
                  let curScore = (imgObj.val || 0) + (scoreTip.score || 0);
                  this.totalScore += curScore;
                  // perfect提示
                  this.showTipFun(Object.assign({}, scoreTip, { score: curScore }));
                }
              }
            }
          }
          // 不判断是否隐藏，隐藏元素也向下移动
          item.y += this.speed;
          if (!!this[`guide${item.cIdx}`]) {
            this[`guide${item.cIdx}`].y = (item.height - this[`guide${item.cIdx}`].height) / 2 + item.y;
            if (!!this[`guide${item.cIdx}`].imgObj.hide && !!obj && obj.cIdx == item.cIdx) {
              this[`guide${item.cIdx}`].visible = false;
            }
          }
          if (!!item.visible) {
            this.checkDegShowSpriteFun(item);
          } else {
            item.noCheck = true;
          }
        } else {
          // 不判断是否隐藏，隐藏元素也向下移动
          item.y += this.speed;
          if (!!this[`guide${item.cIdx}`]) {
            this[`guide${item.cIdx}`].y = (item.height - this[`guide${item.cIdx}`].height) / 2 + item.y;
          }
          this.checkDegShowSpriteFun(item);
        }
      }
    })
    if (!!obj) {
      this.updateFun(obj);
    }
    let timeOver = "";
    if (!!this.options.gameSource.timePos && name != "init") {
      let curTime = new Date().getTime();
      let oldTime = this.curTime;
      if (!!this.startTime) {
        oldTime = parseInt((curTime - this.startTime) / 1000);
      }

      if (this.curTime >= oldTime) {
        this.renderTime(this.curTime - oldTime);
      } else {
        // 游戏结束
        timeOver = "timeout"
        this.renderTime(0);
      }
    }
    if ((!!tempStop || !!timeOver) && name != "init") {
      this.gameOver(timeOver);
    }

    this.totalCount += this.speed;
    // 判断并设置速度=========================
    this.calcSpeed += this.speed;
    if (this.calcSpeed >= (this.options.gameSource.speedStepHeight || 200)) {
      let speedStep = this.options.gameSource.speedStep;
      if (typeof this.options.gameSource.speedStep == "undefined") {
        speedStep = 0.2;
      }
      this.speed = parseFloat(parseFloat(this.speed + speedStep).toFixed(2));
      if (!!this.options.gameSource.maxSpeed && this.speed >= this.options.gameSource.maxSpeed) {
        this.speed = this.options.gameSource.maxSpeed;
      }
      this.calcSpeed = 0;
    }
  },
  hideSpriteArrFun(name, ops) {
    let options = Object.assign({ childs: [] }, ops);
    if (!!this[name]) {
      this[name].forEach(sprite => {
        if (!!sprite.visible) {
          sprite.visible = false;
        }
        options.childs.forEach(t => {
          if (!!sprite[t] && !!sprite[t].visible) {
            sprite[t].visible = false;
          }
        })
      })
    }
  },
  init: function (defaultData = {}) {
    this.hideSpriteArrFun("scoreSpriteArr");
    this.hideSpriteArrFun("timeSpriteArr");
    this.hideSpriteArrFun("animateSpriteArr");
    this.hideSpriteArrFun("maxScoreSpriteArr");
    this.hideSpriteArrFun("minScoreSpriteArr");
    this.hideSpriteArrFun("tipScoreSpriteArr");
    this.hideSpriteArrFun("touchSpriteArr");
    this.hideSpriteArrFun("spriteArr");
    this.hideSpriteArrFun("beginTimeSpriteArr");
    this.hideSpriteArrFun("guideArr");
    // 障碍物
    this.spriteArr = defaultData.spriteArr || [];// 存放精灵数组
    this.guideArr = defaultData.guideArr || [];//引导提示精灵数组
    this.scoreSpriteArr = defaultData.scoreSpriteArr || [];// 存放分数精灵数组
    this.timeSpriteArr = defaultData.timeSpriteArr || [];// 存放倒计时精灵数组
    this.animateSpriteArr = defaultData.animateSpriteArr || [];// 存放动画精灵数组
    this.maxScoreSpriteArr = defaultData.maxScoreSpriteArr || [];//存放大分数精灵数字
    this.minScoreSpriteArr = defaultData.minScoreSpriteArr || [];//存放小分数精灵数字
    this.tipScoreSpriteArr = defaultData.tipScoreSpriteArr || [];//存放提示小分数精灵数字
    this.touchSpriteArr = defaultData.touchSpriteArr || [];//存放点击轨道选中状态
    this.beginTimeSpriteArr = defaultData.beginTimeSpriteArr || [];//开始倒计时
    this.speed = defaultData.speed || this.options.gameSource.speed || 4;// 障碍物速度
    this.maxEnergyNum = defaultData.maxEnergyNum || this.options.gameSource.maxEnergyNum;// 只能吃到的最大能量个数
    this.curEnergyNum = 0;// 当前吃到的能量个数
    this.calcSpeed = defaultData.calcSpeed || 0;
    this.lastSprite = defaultData.lastSprite || null;
    this.touched = false;
    this.to = 0;
    this.touchIng = false;
    this.cIdx = 0;

    // 操作球
    if (!this.playerSprite && !!this.options.gameSource.playerInfo) {
      this.player = defaultData.player || Object.assign({ type: "player" }, this.options.gameSource.playerInfo);
      this.renderSprite(this.player);
      //尾巴
      let TailData = this.options.gameSource.playerInfo.tail;
      if (!!TailData && !!particles) {
        let TailArr = [];
        TailData.srcArr.forEach(img => {
          TailArr.push(this.frame(img, 0, 0));
        })
        this.TailEmitter = new particles.Emitter(
          this.TailBox, TailArr, TailData.config,
        );
        this.TailEmitter.emit = true;
        this.TailElapsed = Date.now();
      }
    }
    let JGH = this.options.gameSource.JGH;
    if (!!JGH) {
      JGH = JGH * this.options.$game.fObj.scale;
    } else {
      if (!!this.playerSprite) {
        JGH = this.playerSprite.height;
      } else {
        JGH = 0;
      }
    }
    this.maxJGH = defaultData.maxJGH || JGH * (this.options.barrierMaxHeight || 1.5);//两个障碍物之间的间隔最大距离
    if (this.maxJGH >= this.height / 2) {
      this.maxJGH = this.height / 2;
    }
    // 生成障碍物在屏幕上位置 暂时设置为半屏-------
    let tempH = (this.height - this.padding.top - this.padding.bottom) / 2 + this.padding.top;
    if (typeof this.options.gameSource.firstShowHeight != "undefined") {
      tempH = (this.options.gameSource.firstShowHeight * this.options.$game.fObj.scale) + this.padding.top;
    }
    this.nextRenderY = defaultData.nextY || tempH;
    this.calcNextRenderY = this.maxJGH;

    this.totalScore = defaultData.totalScore || 0;
    if (!!this.options.gameSource.scorePos) {
      this.renderScore(this.totalScore);
    }
    if (!!this.options.gameSource.timePos) {
      this.curTime = this.options.gameSource.timePos.time;
      this.renderTime(this.curTime);
    }

    // ===========================================================================================测试线条begin============================================
    let tempArr = [];
    if (!!this.options.gameSource.line) {
      let t1 = Object.assign({}, this.options.gameSource.line, {
        type: "score",
        isBg: true,
        ttW: this.options.minDegWidth,
        ttH: 2,
        x: 300 * this.options.$game.fObj.scale,
        y: this.padding.top
      });
      tempArr.push(t1)
      let t2 = Object.assign({}, t1, {
        ttW: this.options.maxDegWidth,
        x: 0,
        y: this.padding.top + this.options.minTomaxHeight * this.options.$game.fObj.scale
      })
      tempArr.push(t2)
    }
    if (!!this.options.touchObj && !!this.options.touchObj.line) {
      let t1 = Object.assign({}, this.options.touchObj.line, {
        type: "score",
        isBg: true,
        x: 0,//300 * this.options.$game.fObj.scale,
        y: this.options.touchObj.top * this.options.$game.fObj.scale
      });
      tempArr.push(t1)
      let t2 = Object.assign({}, t1, {
        y: this.options.touchObj.bottom * this.options.$game.fObj.scale
      })
      tempArr.push(t2)
    }
    tempArr.forEach(item => {
      this.renderSprite(item)
    })
    // ===========================================================================================测试线条end============================================

    this.draw("init");
  },
  backCenterX(centerX, width, num) {
    // num最大为4 返回当前数字的x坐标
    let x;
    if (num == 4) {
      x = centerX - 2 * width;
    }
    if (num == 3) {
      x = centerX - width * 1.5;
    }
    if (num == 2) {
      x = centerX - width;
    }
    if (num == 1) {
      x = centerX - width * 0.5;
    }
    return x;
  },
  renderTime: function (num) {
    // 1.判断是否渲染了时间背景图，如果没有，则渲染
    let timePos = this.options.gameSource.timePos;
    if (!this.timeBgSprite && !!timePos.src) {
      // 渲染背景底图
      let timeBgObj = Object.assign({}, {
        type: "time",
        isBg: true,
        src: timePos.src,
        width: timePos.width,
        height: timePos.height,
        x: timePos.left * this.options.$game.fObj.scale,
        y: timePos.top * this.options.$game.fObj.scale,
      });
      this.renderSprite(timeBgObj);
    }
    // 2.隐藏已显示的时间
    this.hideSpriteArrFun("timeSpriteArr");
    // 3.渲染分数
    let numS = (parseInt(num / 60) + '');
    if (numS.length < 2) {
      numS = "0" + numS;
    }
    let arr1 = numS.replace('.', '0').split('');
    let numS2 = (num % 60 + '');
    if (numS2.length < 2) {
      numS2 = "0" + numS2;
    }
    let arr2 = numS2.split('');
    let numArr = timePos.numArr || [];
    if (!!timePos.center) {
      // 时间在该点居中显示
      try {
        let timeObj, firstNumX = 0;
        let baseLeft = 0;
        if (!!timePos.endImg) {
          baseLeft = -timePos.endImg.width / 2 * this.options.$game.fObj.scale;
        }
        if (arr1[0] != 0) {
          if (!firstNumX) { firstNumX = this.backCenterX(timePos.center, numArr[arr1[0]].width, 4); }
          // 第一位时间
          timeObj = Object.assign({}, numArr[arr1[0]], {
            type: "time",
            x: firstNumX * this.options.$game.fObj.scale + baseLeft,
            y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
          });
          this.renderSprite(timeObj);
        }
        if ((arr1[1] != 0 && !firstNumX) || !!firstNumX) {
          if (!!firstNumX) {
            firstNumX = firstNumX + numArr[arr1[0]].width;
          } else {
            firstNumX = this.backCenterX(timePos.center, numArr[arr1[0]].width, 3);
          }
          // 第二位时间
          timeObj = Object.assign({}, numArr[arr1[1]], {
            type: "time",
            x: firstNumX * this.options.$game.fObj.scale + baseLeft,
            y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
          });
          this.renderSprite(timeObj);
        }
        if ((arr2[0] != 0 && !firstNumX) || !!firstNumX) {
          if (!!firstNumX) {
            firstNumX = firstNumX + numArr[arr1[0]].width;
          } else {
            firstNumX = this.backCenterX(timePos.center, numArr[arr1[0]].width, 2);
          }
          // 第三位时间
          timeObj = Object.assign({}, numArr[arr2[0]], {
            type: "time",
            x: firstNumX * this.options.$game.fObj.scale + baseLeft,
            y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
          });
          this.renderSprite(timeObj);
        }
        if (true) {
          if (!!firstNumX) {
            firstNumX = firstNumX + numArr[arr1[0]].width;
          } else {
            firstNumX = this.backCenterX(timePos.center, numArr[arr1[0]].width, 1);
          }
          // 第四位时间
          timeObj = Object.assign({}, numArr[arr2[1]], {
            type: "time",
            x: firstNumX * this.options.$game.fObj.scale + baseLeft,
            y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
          });
          this.renderSprite(timeObj);
        }
        // 最后一个图片
        if (!!timePos.endImg) {
          let endImg = Object.assign({}, timePos.endImg, {
            type: "time",
            x: firstNumX * this.options.$game.fObj.scale + baseLeft + numArr[0].width * this.options.$game.fObj.scale,
            y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
          });
          this.renderSprite(endImg);
        }
      } catch (e) { }
    } else {
      // 第一位时间
      let timeObj = Object.assign({}, numArr[arr1[0]], {
        type: "time",
        x: ((timePos.timeleft || 0)) * this.options.$game.fObj.scale,
        y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
      });
      this.renderSprite(timeObj);
      // 第二位时间
      timeObj = Object.assign({}, numArr[arr1[1]], {
        type: "time",
        x: ((timePos.timeleft || 0) + numArr[arr1[0]].width) * this.options.$game.fObj.scale,
        y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
      });
      this.renderSprite(timeObj);
      // 第三位时间
      timeObj = Object.assign({}, numArr[arr2[0]], {
        type: "time",
        x: ((timePos.timeRight || 0) - numArr[arr2[0]].width * 2) * this.options.$game.fObj.scale,
        y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
      });
      this.renderSprite(timeObj);
      // 第四位时间
      timeObj = Object.assign({}, numArr[arr2[1]], {
        type: "time",
        x: ((timePos.timeRight || 0) - numArr[arr2[0]].width) * this.options.$game.fObj.scale,
        y: (timePos.timeTop || 0) * this.options.$game.fObj.scale,
      });
      this.renderSprite(timeObj);
    }
  },
  renderScore: function (score = 0) {
    // 1.判断是否渲染了分数背景图，如果没有，则渲染
    let scorePos = this.options.gameSource.scorePos;
    if (!this.scoreBgSprite && !!scorePos.src) {
      // 渲染背景底图
      let scoreBgObj = Object.assign({}, {
        type: "score",
        isBg: true,
        src: scorePos.src,
        width: scorePos.width,
        height: scorePos.height,
        x: scorePos.left * this.options.$game.fObj.scale,
        y: scorePos.top * this.options.$game.fObj.scale,
      });
      this.renderSprite(scoreBgObj);
    }
    // 2.隐藏已显示的分数
    this.hideSpriteArrFun("scoreSpriteArr");
    // 3.渲染分数
    let scoreArr = (score + "").split("");
    let centerPos = scorePos.scoreCenter;
    scoreArr.forEach((num, index) => {
      let numArr = scorePos.numArr || [];
      let x = 0;
      if (!!scorePos.scoreRight) {
        x = ((scorePos.scoreRight || 0) - numArr[num].width * ((scoreArr.length - index) + 1)) * this.options.$game.fObj.scale;
      }
      if (!!scorePos.scoreLeft) {
        x = scorePos.scoreLeft * this.options.$game.fObj.scale + numArr[num].width * index * this.options.$game.fObj.scale;
      }
      if (!!centerPos) {
        x = (centerPos - numArr[num].width * scoreArr.length / 2) * this.options.$game.fObj.scale + index * numArr[num].width * this.options.$game.fObj.scale;
      }
      if (!!scorePos.center) {
        let baseX = (750 - scoreArr.length * numArr[num].width) / 2 * this.options.$game.fObj.scale;
        x = baseX + index * numArr[num].width * this.options.$game.fObj.scale;
      }
      // 渲染分数
      let scoreBgObj = Object.assign({}, numArr[num], {
        type: "score",
        x: x,
        y: (scorePos.scoreTop || 0) * this.options.$game.fObj.scale,
      });
      this.renderSprite(scoreBgObj);
    });
  },
  tipScoreFun: function (item) {
    clearTimeout(this.tipTimer);
    let score = 0;
    try {
      score = item.imgObj.val;
    } catch (e) { }
    if (score == 0) {
      return false;
    }
    let numArr = this.options.gameSource.scorePos.tipNumArr;
    if (!numArr) { return false; }

    let scoreArr = (score + "").split("");
    let singleNumW = numArr[0].width * this.options.$game.fObj.scale;
    // 1.隐藏已显示的分数
    this.hideSpriteArrFun("tipScoreSpriteArr");
    // 2.判断并渲染加号
    let endX = 0;
    if (!!this.options.gameSource.scorePos.tipAdd) {
      let tipAddImg = Object.assign({
        type: "tipScore",
        x: (this.width - singleNumW * scoreArr.length - this.options.gameSource.scorePos.tipAdd.width * this.options.$game.fObj.scale) / 2,
        y: this.height / 2 - this.playerSprite.height * 2
      }, this.options.gameSource.scorePos.tipAdd);
      let ts = this.renderSprite(tipAddImg);
      endX = ts.x + ts.width;
    }
    // 3.渲染分数
    scoreArr.forEach((num, index) => {
      // 渲染分数
      let scoreBgObj = Object.assign({}, numArr[num], {
        type: "tipScore",
        x: endX,
        y: this.height / 2 - this.playerSprite.height * 2
      });
      let ts = this.renderSprite(scoreBgObj);
      endX = ts.x + ts.width;
    });
    this.tipTimer = setTimeout(() => {
      this.hideSpriteArrFun("tipScoreSpriteArr");
    }, this.options.gameSource.scorePos.tipFadeTime || 500);
  },
  animateBoom: function (callback) {
    // 游戏结束，判断是否有爆炸效果
    let maxTime = 0;

    this.hideSpriteArrFun("animateSpriteArr");

    // 操作球
    let playerInfo = this.playerSprite.imgObj;
    let maxType = "player";
    maxTime = playerInfo.boomSpeed || 0;
    // 障碍物
    let zawInfo = this.overSprite;
    if (!!zawInfo) {
      let zawObj = zawInfo.imgObj;
      let zawObjTime = zawObj.boomSpeed || 0;
      if (zawObjTime > maxTime) {
        maxType = "zaw";
        maxTime = zawObjTime;
      }

      if (!!zawObj.boomArr && !!zawObj.boomArr.length > 0) {
        // 碰撞到的障碍物有序列帧动画
        let animateObj = Object.assign({}, {
          type: "animate",
          maxAnimate: maxType == "zaw",
          srcArr: zawObj.boomArr,
          boomSpeed: zawObj.boomSpeed,
          width: zawObj.width,
          height: zawObj.height,
          x: this.overSprite.x,
          y: this.overSprite.y,
          callback
        });
        this.renderSprite(animateObj);
        this.overSprite.visible = false;
      }
    }
    if (!!playerInfo.boomArr && playerInfo.boomArr.length > 0) {
      // 操作球有序列帧动画
      let animateObj = Object.assign({}, {
        type: "animate",
        maxAnimate: maxType == "player",
        srcArr: playerInfo.boomArr,
        boomSpeed: playerInfo.boomSpeed,
        width: playerInfo.width,
        height: playerInfo.height,
        x: this.playerSprite.x,
        y: this.playerSprite.y,
        callback
      });
      this.renderSprite(animateObj);
      this.playerSprite.visible = false;
    }

    if (maxType == "player" && maxTime == 0) {
      // 没有动画
      setTimeout(() => {
        try {
          callback();
        } catch (e) { }
      }, maxTime * 1000);
    }
  },
  // 模拟 requestAnimationFrame
  doAnimationFrame(callback) {
    var currTime = new Date().getTime();
    this.lastFrameTime = this.lastFrameTime || 0;
    var timeToCall = Math.max(0, 16 - (currTime - this.lastFrameTime));
    var id = setTimeout(function () { callback(currTime + timeToCall); }, timeToCall);
    this.lastFrameTime = currTime + timeToCall;
    return id;
  },
  // 模拟 cancelAnimationFrame
  abortAnimationFrame(id) {
    clearTimeout(id)
  },
  tickerStart() {
    let _this = this;
    if (!!_this.req) { return false; }
    this.tickerStopStatus = false;
    /* function ani() {
      _this.draw();
      if (!_this.tickerStopStatus) {
        _this.req = _this.options.$game.fObj.pixiCanvas.requestAnimationFrame(ani)
        // _this.req = _this.doAnimationFrame(ani);
      }
    }

    ani(); */

    this.ticker.start();
    this.req = true;
  },
  tickerStop() {
    this.iStart = false;
    this.tickerStopStatus = true;

    this.ticker.stop();
    /* this.options.$game.fObj.pixiCanvas.cancelAnimationFrame(this.req) */
    // this.abortAnimationFrame(this.req);
    this.req = null;
  },
  showBeginTime: function (imgArr, index = 0, callback) {
    this.playerSprite.visible = false;
    this.TailBox.visible = false;
    this.hideSpriteArrFun("beginTimeSpriteArr");
    let img = Object.assign({
      type: "beginTime"
    }, imgArr[index]);
    this.renderSprite(img)
    if (index == imgArr.length) {
      this.hideSpriteArrFun("beginTimeSpriteArr");
      this.playerSprite.visible = true;
      this.TailBox.visible = true;
      callback && callback();
    } else {
      setTimeout(() => {
        index = index + 1;
        this.showBeginTime(imgArr, index, callback)
      }, 1000)
    }
  },
})
// 游戏继续
Game.prototype.continue = function () {
  if (this.iStart != "pause" && this.iStart != "over") {
    return false;
  }
  if (this.iStart != "pause") { return false; }
  if (!!this.innerAudioContext) {
    this.innerAudioContext.play();
  }
  // 继续游戏，先隐藏之前碰撞到的障碍物
  this.hideSpriteArrFun("animateSpriteArr");
  if (!!this.overSprite) {
    this.overSprite.visible = false;
  }
  if (!!this.playerSprite) {
    this.playerSprite.visible = true;
  }
  if (!!this.pauseTime && !!this.startTime) {
    let curTime = new Date().getTime();
    this.startTime += (curTime - this.pauseTime);
    this.pauseTime = 0;
  }
  this.iStart = false;
  this.startGame("continue");
}
Game.prototype.pause = function () {
  if (!this.iStart || this.iStart == "pause") { return false; }
  if (this.iStart != "start") { return false; }
  if (!!this.pauseTime) { return false; }
  this.pauseTime = new Date().getTime();
  this.tickerStop();
  this.iStart = "pause";
  if (!!this.innerAudioContext) {
    this.innerAudioContext.pause();
  }
}
// 游戏结束
Game.prototype.gameOver = function (type) {
  if (!this.iStart || this.iStart == "pause" || this.iStart == "over") { return false; }
  this.bb = false;
  this.pauseTime = new Date().getTime();
  this.tickerStop();
  if (!!this.innerAudioContext) {
    this.innerAudioContext.stop();
  }
  this.iStart = "over";
  // 防止结束了还在移动
  let bl = true;
  if (!!this.options.playerAnimal) {
    if (type == "timeout") {
      // 倒计时结束结束游戏
      if (!!this.options.isTimeOverAnimal) {
        // 游戏时间结束结束游戏时，player动画是否执行，默认false不执行
        bl = false;
      }
    } else {
      // 碰撞到障碍物结束游戏
    }
  } else {
    if (!!this.overSprite && !!this.overSprite.imgObj.changePlayer) {
      this.changePlayerFun(this.overSprite);
    }

    try {
      let audioName = this.overSprite.imgObj.audioName;
      if (!!audioName) {
        this.audioFun(audioName);
      }
    } catch (e) { }
  }
  if (!bl) {
    this.animateBoom(() => {
      try {
        this.options.overFun({ score: this.totalScore, type });
      } catch (e) { }
    });
  } else {
    try {
      // 页面销毁时，不调用游戏结束回调
      if (type != "unmount") {
        this.options.overFun({ score: this.totalScore, type });
      }
    } catch (e) { }
  }
}
// 重置游戏
Game.prototype.reset = function () {
  clearInterval(this.tt);
  this.pauseTime = 0;
  this.tickerStop();
  // 1.隐藏元素
  this.hideSpriteArrFun("spriteArr");
  if (!!this.innerAudioContext) {
    this.innerAudioContext.stop();
  }

  if (!!this.playerSprite) {
    this.playerSprite.visible = true;
    // 2.居中显示player
    this.playerSprite.x = (this.width / 4 - this.playerSprite.width / 2);
    this.playerSprite.y = (this.height - this.playerSprite.height) / 2;
  }
  let time = 500;
  this.tt = setInterval(() => {
    if (time > 0) {
      this.upTailFun();
    } else {
      clearInterval(this.tt);
    }
    time--;
  }, 10);

  this.startTime = new Date().getTime();
  // 3.重新生成新元素
  this.init();
}
Game.prototype.startGame = function (type) {
  if (!!this.iStart) { return false; }
  this.iStart = "start";
  this.overSprite = null;
  if (!!this.playerSprite) {
    this.playerSprite.visible = true;
  }
  this.hideSpriteArrFun("animateSpriteArr");
  this.hideSpriteArrFun("beginTimeSpriteArr");

  if (!!this.options.gameSource.beginTip && !this.bb) {
    this.bb = true;
    // 有开始提示倒数计时
    this.showBeginTime(this.options.gameSource.beginTip, 0, () => {
      if (type != "continue") {
        this.startTime = new Date().getTime();
        if (!!this.innerAudioContext) {
          this.innerAudioContext.play();
        }
      }
      this.tickerStart();
    });
  } else {
    if (type != "continue") {
      this.startTime = new Date().getTime();
      if (!!this.innerAudioContext) {
        this.innerAudioContext.play();
      }
    }
    this.tickerStart();
  }
}

export {
  Game
}