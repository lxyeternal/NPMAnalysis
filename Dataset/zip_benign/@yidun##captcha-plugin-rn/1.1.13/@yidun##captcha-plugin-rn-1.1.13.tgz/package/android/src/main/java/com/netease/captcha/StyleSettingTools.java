package com.netease.captcha;

import android.text.TextUtils;

import com.facebook.react.bridge.ReadableMap;
import com.netease.nis.basesdk.Logger;
import com.netease.nis.captcha.CaptchaConfiguration;
import com.netease.nis.captcha.CaptchaConfiguration.LangType;

import org.json.JSONObject;

/**
 * @author liuxiaoshuai
 * @date 2022/7/26
 * @desc
 * @email liulingfeng@mistong.com
 */
public class StyleSettingTools {
    private StyleSettingTools() {

    }

    private static final String RADIUS = "radius";
    private static final String CAP_BAR_TEXT_ALIGN = "capBarTextAlign";
    private static final String CAP_BAR_BORDER_COLOR = "capBarBorderColor";
    private static final String CAP_BAR_TEXT_COLOR = "capBarTextColor";
    private static final String CAP_BAR_TEXT_SIZE = "capBarTextSize";
    private static final String CAP_BAR_TEXT_WEIGHT = "capBarTextWeight";
    private static final String CAP_BAR_TITLE_HEIGHT = "capBarTitleHeight";
    private static final String CAP_BODY_PADDING = "capBodyPadding";
    private static final String CAP_PADDING_TOP = "capPaddingTop";
    private static final String CAP_PADDING_RIGHT = "capPaddingRight";
    private static final String CAP_PADDING_BOTTOM = "capPaddingBottom";
    private static final String CAP_PADDING_LEFT = "capPaddingLeft";
    private static final String PADDING_TOP = "paddingTop";
    private static final String PADDING_BOTTOM = "paddingBottom";
    private static final String CAP_BORDER_RADIUS = "capBorderRadius";
    private static final String BORDER_COLOR = "borderColor";
    private static final String BACKGROUND = "background";
    private static final String BORDER_COLOR_MOVING = "borderColorMoving";
    private static final String BACKGROUND_MOVING = "backgroundMoving";
    private static final String BORDER_COLOR_SUCCESS = "borderColorSuccess";
    private static final String BACKGROUND_SUCCESS = "backgroundSuccess";
    private static final String BACKGROUND_ERROR = "backgroundError";
    private static final String BORDER_COLOR_ERROR = "borderColorError";
    private static final String SLIDE_BACKGROUND = "slideBackground";
    private static final String TEXT_SIZE = "textSize";
    private static final String TEXT_COLOR = "textColor";
    private static final String HEIGHT = "height";
    private static final String BORDER_RADIUS = "borderRadius";
    private static final String GAP = "gap";
    private static final String EXECUTE_BORDER_RADIUS = "executeBorderRadius";
    private static final String EXECUTE_BACKGROUND = "executeBackground";
    private static final String EXECUTE_TOP = "executeTop";
    private static final String EXECUTE_RIGHT = "executeRight";

    public static void setStyle(ReadableMap styleConfig, CaptchaConfiguration.Builder builder) {
        try {
            int radius = styleConfig.hasKey(RADIUS) ? styleConfig.getInt(RADIUS) : -1;
            String capBarTextAlign = styleConfig.hasKey(CAP_BAR_TEXT_ALIGN) ? styleConfig.getString(CAP_BAR_TEXT_ALIGN) : "";
            String capBarBorderColor = styleConfig.hasKey(CAP_BAR_BORDER_COLOR) ? styleConfig.getString(CAP_BAR_BORDER_COLOR) : "";
            String capBarTextColor = styleConfig.hasKey(CAP_BAR_TEXT_COLOR) ? styleConfig.getString(CAP_BAR_TEXT_COLOR) : "";
            int capBarTextSize = styleConfig.hasKey(CAP_BAR_TEXT_SIZE) ? styleConfig.getInt(CAP_BAR_TEXT_SIZE) : -1;
            String capBarTextWeight = styleConfig.hasKey(CAP_BAR_TEXT_WEIGHT) ? styleConfig.getString(CAP_BAR_TEXT_WEIGHT) : "";
            int capBarTitleHeight = styleConfig.hasKey(CAP_BAR_TITLE_HEIGHT) ? styleConfig.getInt(CAP_BAR_TITLE_HEIGHT) : -1;
            int capBodyPadding = styleConfig.hasKey(CAP_BODY_PADDING) ? styleConfig.getInt(CAP_BODY_PADDING) : -1;
            int capPaddingTop = styleConfig.hasKey(CAP_PADDING_TOP) ? styleConfig.getInt(CAP_PADDING_TOP) : -1;
            int capPaddingRight = styleConfig.hasKey(CAP_PADDING_RIGHT) ? styleConfig.getInt(CAP_PADDING_RIGHT) : -1;
            int capPaddingBottom = styleConfig.hasKey(CAP_PADDING_BOTTOM) ? styleConfig.getInt(CAP_PADDING_BOTTOM) : -1;
            int capPaddingLeft = styleConfig.hasKey(CAP_PADDING_LEFT) ? styleConfig.getInt(CAP_PADDING_LEFT) : -1;
            int paddingTop = styleConfig.hasKey(PADDING_TOP) ? styleConfig.getInt(PADDING_TOP) : -1;
            int paddingBottom = styleConfig.hasKey(PADDING_BOTTOM) ? styleConfig.getInt(PADDING_BOTTOM) : -1;
            int capBorderRadius = styleConfig.hasKey(CAP_BORDER_RADIUS) ? styleConfig.getInt(CAP_BORDER_RADIUS) : -1;
            String borderColor = styleConfig.hasKey(BORDER_COLOR) ? styleConfig.getString(BORDER_COLOR) : "";
            String background = styleConfig.hasKey(BACKGROUND) ? styleConfig.getString(BACKGROUND) : "";
            String borderColorMoving = styleConfig.hasKey(BORDER_COLOR_MOVING) ? styleConfig.getString(BORDER_COLOR_MOVING) : "";
            String backgroundMoving = styleConfig.hasKey(BACKGROUND_MOVING) ? styleConfig.getString(BACKGROUND_MOVING) : "";
            String borderColorSuccess = styleConfig.hasKey(BORDER_COLOR_SUCCESS) ? styleConfig.getString(BORDER_COLOR_SUCCESS) : "";
            String backgroundSuccess = styleConfig.hasKey(BACKGROUND_SUCCESS) ? styleConfig.getString(BACKGROUND_SUCCESS) : "";
            String backgroundError = styleConfig.hasKey(BACKGROUND_ERROR) ? styleConfig.getString(BACKGROUND_ERROR) : "";
            String borderColorError = styleConfig.hasKey(BORDER_COLOR_ERROR) ? styleConfig.getString(BORDER_COLOR_ERROR) : "";
            String slideBackground = styleConfig.hasKey(SLIDE_BACKGROUND) ? styleConfig.getString(SLIDE_BACKGROUND) : "";
            int textSize = styleConfig.hasKey(TEXT_SIZE) ? styleConfig.getInt(TEXT_SIZE) : -1;
            String textColor = styleConfig.hasKey(TEXT_COLOR) ? styleConfig.getString(TEXT_COLOR) : "";
            int height = styleConfig.hasKey(HEIGHT) ? styleConfig.getInt(HEIGHT) : -1;
            int borderRadius = styleConfig.hasKey(BORDER_RADIUS) ? styleConfig.getInt(BORDER_RADIUS) : -1;
            String gap = styleConfig.hasKey(GAP) ? styleConfig.getString(GAP) : "";
            int executeBorderRadius = styleConfig.hasKey(EXECUTE_BORDER_RADIUS) ? styleConfig.getInt(EXECUTE_BORDER_RADIUS) : -1;
            String executeBackground = styleConfig.hasKey(EXECUTE_BACKGROUND) ? styleConfig.getString(EXECUTE_BACKGROUND) : "";
            String executeTop = styleConfig.hasKey(EXECUTE_TOP) ? styleConfig.getString(EXECUTE_TOP) : "";
            String executeRight = styleConfig.hasKey(EXECUTE_RIGHT) ? styleConfig.getString(EXECUTE_RIGHT) : "";

            if (radius != -1) {
                builder.setRadius(radius);
            }
            JSONObject jo = new JSONObject();
            JSONObject customStyles = new JSONObject();
            JSONObject popupStyles = new JSONObject();

            if (!TextUtils.isEmpty(capBarTextAlign)) {
                popupStyles.put(CAP_BAR_TEXT_ALIGN, capBarTextAlign);
            }
            if (!TextUtils.isEmpty(capBarBorderColor)) {
                popupStyles.put(CAP_BAR_BORDER_COLOR, capBarBorderColor);
            }
            if (!TextUtils.isEmpty(capBarTextColor)) {
                popupStyles.put(CAP_BAR_TEXT_COLOR, capBarTextColor);
            }
            if (capBarTextSize != -1) {
                popupStyles.put(CAP_BAR_TEXT_SIZE, capBarTextSize);
            }
            if (!TextUtils.isEmpty(capBarTextWeight)) {
                popupStyles.put(CAP_BAR_TEXT_WEIGHT, capBarTextWeight);
            }
            if (capBarTitleHeight != -1) {
                popupStyles.put("capBarHeight", capBarTitleHeight);
            }
            if (capBodyPadding != -1) {
                popupStyles.put("capPadding", capBodyPadding);
            }
            if (capPaddingTop != -1) {
                popupStyles.put(CAP_PADDING_TOP, capPaddingTop);
            }
            if (capPaddingRight != -1) {
                popupStyles.put(CAP_PADDING_RIGHT, capPaddingRight);
            }
            if (capPaddingBottom != -1) {
                popupStyles.put(CAP_PADDING_BOTTOM, capPaddingBottom);
            }
            if (capPaddingLeft != -1) {
                popupStyles.put(CAP_PADDING_LEFT, capPaddingLeft);
            }
            if (paddingTop != -1) {
                popupStyles.put(PADDING_TOP, paddingTop);
            }
            if (paddingBottom != -1) {
                popupStyles.put(PADDING_BOTTOM, paddingBottom);
            }
            JSONObject imagePanel = new JSONObject();
            if (capBorderRadius != -1) {
                imagePanel.put(BORDER_RADIUS, capBorderRadius + "px");
            }
            customStyles.put("imagePanel", imagePanel);
            JSONObject controlBar = new JSONObject();
            if (!TextUtils.isEmpty(borderColor)) {
                controlBar.put(BORDER_COLOR, borderColor);
            }
            if (!TextUtils.isEmpty(background)) {
                controlBar.put(BACKGROUND, background);
            }
            if (!TextUtils.isEmpty(borderColorMoving)) {
                controlBar.put(BORDER_COLOR_MOVING, borderColorMoving);
            }
            if (!TextUtils.isEmpty(backgroundMoving)) {
                controlBar.put(BACKGROUND_MOVING, backgroundMoving);
            }
            if (!TextUtils.isEmpty(borderColorSuccess)) {
                controlBar.put(BORDER_COLOR_SUCCESS, borderColorSuccess);
            }
            if (!TextUtils.isEmpty(backgroundSuccess)) {
                controlBar.put(BACKGROUND_SUCCESS, backgroundSuccess);
            }
            if (!TextUtils.isEmpty(backgroundError)) {
                controlBar.put(BACKGROUND_ERROR, backgroundError);
            }
            if (!TextUtils.isEmpty(borderColorError)) {
                controlBar.put(BORDER_COLOR_ERROR, borderColorError);
            }
            if (!TextUtils.isEmpty(slideBackground)) {
                controlBar.put(SLIDE_BACKGROUND, slideBackground);
            }
            if (textSize != -1) {
                controlBar.put(TEXT_SIZE, textSize);
            }
            if (!TextUtils.isEmpty(textColor)) {
                controlBar.put(TEXT_COLOR, textColor);
            }
            if (height != -1) {
                controlBar.put(HEIGHT, height);
            }
            if (borderRadius != -1) {
                controlBar.put(BORDER_RADIUS, borderRadius + "px");
            }
            customStyles.put("controlBar", controlBar);
            if (!TextUtils.isEmpty(gap)) {
                customStyles.put("gap", gap);
            }
            if (executeBorderRadius != -1) {
                customStyles.put(EXECUTE_BORDER_RADIUS, executeBorderRadius + "px");
            }
            if (!TextUtils.isEmpty(executeBackground)) {
                customStyles.put(EXECUTE_BACKGROUND, executeBackground);
            }
            if (!TextUtils.isEmpty(executeTop)) {
                customStyles.put(EXECUTE_TOP, executeTop);
            }
            if (!TextUtils.isEmpty(executeRight)) {
                customStyles.put(EXECUTE_RIGHT, executeRight);
            }
            jo.put("customStyles", customStyles);
            jo.put("popupStyles", popupStyles);
            builder.setUiParams(jo.toString());
        } catch (Exception e) {
            Logger.e(e.getMessage());
        }
    }

    public static CaptchaConfiguration.LangType string2LangType(String langTypeStr) {
        CaptchaConfiguration.LangType langType;
        switch (langTypeStr) {
            case "am": {
                langType = LangType.LANG_AM;
            }
            break;
            case "ar": {
                langType = LangType.LANG_AR;
            }
            break;
            case "as": {
                langType = LangType.LANG_AS;
            }
            break;
            case "az": {
                langType = LangType.LANG_AZ;
            }
            break;
            case "be": {
                langType = LangType.LANG_BE;
            }
            break;
            case "bg": {
                langType = LangType.LANG_BG;
            }
            break;
            case "bn": {
                langType = LangType.LANG_BN;
            }
            break;
            case "bo": {
                langType = LangType.LANG_BO;
            }
            break;
            case "bs": {
                langType = LangType.LANG_BS;
            }
            break;
            case "ca": {
                langType = LangType.LANG_CA;
            }
            break;
            case "cs": {
                langType = LangType.LANG_CS;
            }
            break;
            case "da": {
                langType = LangType.LANG_DA;
            }
            break;
            case "de": {
                langType = LangType.LANG_DE;
            }
            break;
            case "el": {
                langType = LangType.LANG_EL;
            }
            break;
            case "en":
            case "en-GB": {
                langType = LangType.LANG_EN;
            }
            break;
            case "en-US": {
                langType = LangType.LANG_EN_US;
            }
            break;
            case "es": {
                langType = LangType.LANG_ES;
            }
            break;
            case "es-la": {
                langType = LangType.LANG_ES_LA;
            }
            break;
            case "et": {
                langType = LangType.LANG_ET;
            }
            break;
            case "eu": {
                langType = LangType.LANG_EU;
            }
            break;
            case "fa": {
                langType = LangType.LANG_FA;
            }
            break;
            case "fi": {
                langType = LangType.LANG_FI;
            }
            break;
            case "fr": {
                langType = LangType.LANG_FR;
            }
            break;
            case "gl": {
                langType = LangType.LANG_GL;
            }
            break;
            case "gu": {
                langType = LangType.LANG_GU;
            }
            break;
            case "hi": {
                langType = LangType.LANG_HI;
            }
            break;
            case "hr": {
                langType = LangType.LANG_HR;
            }
            break;
            case "hu": {
                langType = LangType.LANG_HU;
            }
            break;
            case "id": {
                langType = LangType.LANG_ID;
            }
            break;
            case "it": {
                langType = LangType.LANG_IT;
            }
            break;
            case "he": {
                langType = LangType.LANG_HE;
            }
            break;
            case "ja": {
                langType = LangType.LANG_JA;
            }
            break;
            case "jv": {
                langType = LangType.LANG_JV;
            }
            break;
            case "ka": {
                langType = LangType.LANG_KA;
            }
            break;
            case "kk": {
                langType = LangType.LANG_KK;
            }
            break;
            case "km": {
                langType = LangType.LANG_KM;
            }
            break;
            case "kn": {
                langType = LangType.LANG_KN;
            }
            break;
            case "ko": {
                langType = LangType.LANG_KO;
            }
            break;
            case "lo": {
                langType = LangType.LANG_LO;
            }
            break;
            case "lt": {
                langType = LangType.LANG_LT;
            }
            break;
            case "lv": {
                langType = LangType.LANG_LV;
            }
            break;
            case "mai": {
                langType = LangType.LANG_MAI;
            }
            break;
            case "mi": {
                langType = LangType.LANG_MI;
            }
            break;
            case "mk": {
                langType = LangType.LANG_MK;
            }
            break;
            case "ml": {
                langType = LangType.LANG_ML;
            }
            break;
            case "mn": {
                langType = LangType.LANG_MN;
            }
            break;
            case "mr": {
                langType = LangType.LANG_MR;
            }
            break;
            case "ms": {
                langType = LangType.LANG_MS;
            }
            break;
            case "my": {
                langType = LangType.LANG_MY;
            }
            break;
            case "no": {
                langType = LangType.LANG_NO;
            }
            break;
            case "ne": {
                langType = LangType.LANG_NE;
            }
            break;
            case "nl": {
                langType = LangType.LANG_NL;
            }
            break;
            case "or": {
                langType = LangType.LANG_OR;
            }
            break;
            case "pa": {
                langType = LangType.LANG_PA;
            }
            break;
            case "pl": {
                langType = LangType.LANG_PL;
            }
            break;
            case "pt": {
                langType = LangType.LANG_PT;
            }
            break;
            case "pt-br": {
                langType = LangType.LANG_PT_BR;
            }
            break;
            case "ro": {
                langType = LangType.LANG_RO;
            }
            break;
            case "ru": {
                langType = LangType.LANG_RU;
            }
            break;
            case "si": {
                langType = LangType.LANG_SI;
            }
            break;
            case "sk": {
                langType = LangType.LANG_SK;
            }
            break;
            case "sl": {
                langType = LangType.LANG_SL;
            }
            break;
            case "sr": {
                langType = LangType.LANG_SR;
            }
            break;
            case "sv": {
                langType = LangType.LANG_SV;
            }
            break;
            case "sw": {
                langType = LangType.LANG_SW;
            }
            break;
            case "ta": {
                langType = LangType.LANG_TA;
            }
            break;
            case "te": {
                langType = LangType.LANG_TE;
            }
            break;
            case "th": {
                langType = LangType.LANG_TH;
            }
            break;
            case "fil": {
                langType = LangType.LANG_FIL;
            }
            break;
            case "tr": {
                langType = LangType.LANG_TR;
            }
            break;
            case "ug": {
                langType = LangType.LANG_UG;
            }
            break;
            case "uk": {
                langType = LangType.LANG_UK;
            }
            break;
            case "ur": {
                langType = LangType.LANG_UR;
            }
            break;
            case "uz": {
                langType = LangType.LANG_UZ;
            }
            break;
            case "vi": {
                langType = LangType.LANG_VI;
            }
            break;
            case "zh-HK": {
                langType = LangType.LANG_ZH_HK;
            }
            break;
            case "zh-TW": {
                langType = LangType.LANG_ZH_TW;
            }
            break;
            default: {
                langType = LangType.LANG_ZH_CN;
            }
        }
        return langType;
    }
}
