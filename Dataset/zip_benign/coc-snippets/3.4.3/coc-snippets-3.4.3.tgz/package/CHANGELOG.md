# 3.4.3

- Fix snippet file may not loaded.
- Fix context snippet may not loaded.

# 3.4.2

- Fix python async issue on vim by use vim's timer.

# 3.4.1

- Execute python global scripts with current filetype only, instead of one
  script for all filetypes.
- Fix known issues with UltiSnips actions.

# 3.4.0

- Support all UltiSnips options, including `t` `s` and `m`.

# 3.3.1

- Add configuration `snippets.disableSyntaxes`.

# 3.3.0

- Add command `snippets.addFiletypes` for add additional snippets filetypes.
- Support variable `b:coc_snippets_filetypes` on buffer create.

# 3.2.0

- Add execContext-option to enable context-execution for completion.
- Fix filepath on vim built with win32unix.

# 3.0.6

- Avoid check and show context snippets in pum.

# 3.0.5

- Fix `snippets.editSnippets` not contains global snippet files.
- Fix snipmate viml interpolation not work.

# 3.0.4

- Register snippets.editSnippets when ultisnips enabled.
- Fix same directory check on case insensive system.

# 3.0.3

- Fix trigger kind for regex snippet.

# 3.0.2

- Add command `snippets.openOutput`.

# 3.0.1

- Fix languageIds of textmate snippets.
- Fix bad params for resolveSnippet.

# 3.0.0

- Not parse ultisnip snippets.

# 2.5.2

- Fix escape for `$` in ultisnip body.

# 2.5.1

- Respect languageIds in `scope` for VSCode snippets.
- Respect languageId in comment for VSCode snippets.
- Load global scoped VSCode snippets for all filetypes.
- Support workspace snippets in `.vscode` folder.

# 2.5.0

- Load snippets when necessary.
- Not show progress status item on loading.
- Load `all.snippets`of ultisnip when filetype is empty.
- Support extends for snipmate snippets.
- Support configuration `snippets.excludePatterns`.
