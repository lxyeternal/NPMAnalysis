export declare enum TimeInterval {
    monthly = "monthly",
    annually = "annually"
}
