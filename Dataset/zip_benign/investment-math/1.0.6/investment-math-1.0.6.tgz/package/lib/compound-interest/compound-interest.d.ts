import { CalculatedCompoundInterest } from './models/calculated-compound-interest';
import { CompoundInterestParameters } from './models/compound-interest-parameters';
/**
 * Calculate a compound interest of a investment with constant deposits
 */
export declare const calculateCompoundInterest: (data: CompoundInterestParameters) => CalculatedCompoundInterest;
