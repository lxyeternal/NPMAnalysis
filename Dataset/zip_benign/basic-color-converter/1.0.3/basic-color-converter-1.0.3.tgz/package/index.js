const componentToRgb = (hexPart) => parseInt(hexPart, 16);

const hexToRgb = (_hex) => {
  const hex = _hex.slice(1);

  if (hex.length === 6 || hex.length === 8) {
    const r = componentToRgb(hex.slice(0, 2));
    const g = componentToRgb(hex.slice(2, 4));
    const b = componentToRgb(hex.slice(4, 6));
    const a = +(componentToRgb(hex.slice(6, 8)) / 255).toFixed(2);

    return a ? `rgba(${r}, ${g}, ${b}, ${a})` : `rgb(${r}, ${g}, ${b})`;
  } else {
    throw new Error("Invalid hex");
  }
};

const componentToHex = (rgbPart) => {
  const hexPart = parseInt(rgbPart).toString(16);
  return hexPart.length === 1 ? `0${hexPart}` : hexPart;
};

const rgbToHex = (_rgb) => {
  const rgb = _rgb.replace(/rgb\(|\)|rgba\(|\)|\s/gi, "").split(",");

  const r = componentToHex(rgb[0]);
  const g = componentToHex(rgb[1]);
  const b = componentToHex(rgb[2]);
  const a = rgb[3] && componentToHex(Math.round(rgb[3] * 255));

  return `#${r}${g}${b}${a ? a : ""}`;
};

module.exports = { rgbToHex, hexToRgb };
