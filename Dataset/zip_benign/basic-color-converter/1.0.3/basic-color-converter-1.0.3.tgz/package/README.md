## Basic Color Converter

Convert hex to rgb, rgb to hex.

### Usage

```sh
import { rgbToHex, rgbToHex } from 'basic-color-converter';


hexToRgb("#72b1ff")
//rgb(114, 177, 255)

rgbToHex("rgba(35, 41, 51, 0.5)")
//"#23293380"

```
