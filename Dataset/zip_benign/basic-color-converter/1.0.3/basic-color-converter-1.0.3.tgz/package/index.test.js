const { rgbToHex, hexToRgb } = require("./index");

describe("Rgb to Hex", () => {
  test("Convert rgb to hex", () => {
    expect(rgbToHex("rgb(114, 177, 255)")).toBe("#72b1ff");
  });
  test("Convert rgba to hex", () => {
    expect(rgbToHex("rgba(35, 41, 51, 0.5)")).toBe("#23293380");
  });
});

describe("Hex to rgb", () => {
  test("Convert hex to rgb", () => {
    expect(hexToRgb("#72b1ff")).toBe("rgb(114, 177, 255)");
  });
  test("Convert transparent hex to rgba", () => {
    expect(hexToRgb("#23293380")).toBe("rgba(35, 41, 51, 0.5)");
  });
});
