import { Big, BigSource } from 'big.js';
export interface Options {
    /** start value */
    from: BigSource;
    /** end value */
    to: BigSource;
    /** ease function (e.g. import { easeQuadInOut } from 'd3-ease') */
    ease?: (nomalizedTime: number) => number;
}
export declare const interpolateBig: ({ from, to, ease, }: Options) => (e: number) => Big;
