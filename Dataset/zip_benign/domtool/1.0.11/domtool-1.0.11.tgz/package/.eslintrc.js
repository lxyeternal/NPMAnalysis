module.exports = {
  extends: 'eslint-config-ray',
  globals: {
    getComputedStyle: true
  },
  rules: {
    'no-magic-numbers': 0,
    'no-continue': 0,
    'no-prototype-builtins': 0,
    'prefer-rest-params': 0,
    'no-mixed-operators': 0
  }
};
