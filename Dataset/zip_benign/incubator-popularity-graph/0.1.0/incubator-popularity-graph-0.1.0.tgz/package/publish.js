const ghpages = require('gh-pages')

ghpages.publish('dist', function (error) {
  if (error) {
    console.log('Failed to publish', error)
  } else {
    console.log('Published!')
  }
})
