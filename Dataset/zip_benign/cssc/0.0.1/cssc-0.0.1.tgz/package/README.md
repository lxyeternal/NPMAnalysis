# 1. Introduction

CSSC

Please report issues on [Github] (https://github.com/afelix/cssc/issues).

For feedback, suggestions, etc. write to <skryzhanovsky@ya.ru>.

# 2. Installation

## 2.1. Prerequisites

* for command line use: Linux / Mac OS X / any OS with working Node.js

## 2.2. Install using git

Prerequisites:

* git&nbsp;— [http://git-scm.com/](http://git-scm.com/)

To install:

* run `git clone git://github.com/afelix/cssc.git`

## 2.3. Install using npm

Prerequisites:

* nodejs 0.4.x or newer&nbsp;— [http://nodejs.org](http://nodejs.org)
* npm&nbsp;— [http://github.com/isaacs/npm/](http://github.com/isaacs/npm/)

To install (global):

* run `npm install cssc -g`

To update:

* run `npm update cssc`

To uninstall:

* run `npm uninstall cssc`

# 3. Usage

## 3.1. From the command line

Run `bin/cssc` (when installed from git), you will need to have nodejs 0.4.x or newer installed&nbsp;— [http://nodejs.org](http://nodejs.org)

Run `cssc` (when installed from npm).

Usage:

    cssc
        shows usage information
    cssc <filename>
        counts CSS tokens in <filename> and outputs the result to stdout
    cssc <in_filename> <out_filename>
    cssc -i <in_filename> -o <out_filename>
    cssc --input <in_filename> --output <out_filename>
        counts CSS tokens in <in_filename> and outputs the result to <out_filename>
    cssc -h
    cssc --help
        shows usage information
    cssc -v
    cssc --version
        shows the version number

Example:

    $ echo ".foo { p: v } .foo, .bar + .car { p: v }" > test.css
    $ cssc test.css
    Total selector groups: 2
    Total simple selectors: 3
    Total unique simple selectors: 2

# 4. Statistics (in a nutshell)

Sample CSS:

    .foo {
        p: v
    }
    .foo, .bar + .car {
        p: v
    }

Here:

* `.foo` and `.bar + .car` are so called simple selectors;
* `.bar + .car` is selector group.

So in resulting statistics you will see:

* 2 selector groups — `.foo` and `.foo, .bar + .car`;
* 3 simple selectors — `.foo`, `.foo` and `.foo, .bar + .car`;
* 2 unique simple selectors — `.foo` and `.bar + .car`.

# 5. Authors

* Sergey Kryzhanovsky (<skryzhanovsky@ya.ru>)

# 6. And finally

* CSSC is licensed under [MIT](https://github.com/afelix/cssc/blob/master/MIT-LICENSE.txt)
