export { IsolationForest } from './IsolationForest';
