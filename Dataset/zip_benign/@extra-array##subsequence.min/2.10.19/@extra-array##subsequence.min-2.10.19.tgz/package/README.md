Picks an arbitrary subsequence.
[:package:](https://www.npmjs.com/package/@extra-array/subsequence)
[:smiley_cat:](https://github.com/orgs/nodef/packages?repo_name=extra-array)
[:running:](https://npm.runkit.com/@extra-array/subsequence)
[:vhs:](https://asciinema.org/a/332138)
[:moon:](https://www.npmjs.com/package/@extra-array/subsequence.min)
[:scroll:](https://unpkg.com/@extra-array/subsequence/)
[:newspaper:](https://nodef.github.io/extra-array/)
[:blue_book:](https://github.com/nodef/extra-array/wiki/)

> Similar: [subsequence], [subsequences], [hasSubsequence], [searchSubsequence].

> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

> This is browserified, minified version of [@extra-array/subsequence].<br>
> It is exported as global variable **array_subsequence**.<br>
> CDN: [unpkg], [jsDelivr].

[@extra-array/subsequence]: https://www.npmjs.com/package/@extra-array/subsequence
[unpkg]: https://unpkg.com/@extra-array/subsequence.min
[jsDelivr]: https://cdn.jsdelivr.net/npm/@extra-array/subsequence.min

<br>

```javascript
array.subsequence(x, [n], [r]);
// x: an array
// n: number of values (-1 => any)
// r: random seed 0->1
```

```javascript
const array = require("extra-array");

var x = [1, 2, 3, 4, 5];
array.subsequence(x);
// [ 1, 2 ]

array.subsequence(x, 3, 0.3);
// [ 1, 3, 5 ]

array.subsequence(x, 2, 0.3);
// [ 3, 5 ]
```

<br>
<br>


## References

- [shuffle: PHP](https://www.php.net/manual/en/function.shuffle.php)
- [shuffle-seed: @webcaetano](https://www.npmjs.com/package/shuffle-seed)
- [shuffle-array: @pazguille](https://www.npmjs.com/package/shuffle-array)
- [Seeding the random number generator in Javascript](https://stackoverflow.com/a/47593316/1413259)

[subsequence]: https://github.com/nodef/extra-array/wiki/subsequence
[subsequences]: https://github.com/nodef/extra-array/wiki/subsequences
[hasSubsequence]: https://github.com/nodef/extra-array/wiki/hasSubsequence
[searchSubsequence]: https://github.com/nodef/extra-array/wiki/searchSubsequence
