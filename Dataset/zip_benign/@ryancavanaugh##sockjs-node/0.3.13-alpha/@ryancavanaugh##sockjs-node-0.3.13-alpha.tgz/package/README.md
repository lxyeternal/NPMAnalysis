# Installation
> `npm install --save-dev @ryancavanaugh/sockjs-node`

# Summary
This package contains type definitions for sockjs-node 0.3.x.

The project URL or description is https://github.com/sockjs/sockjs-node

# Credits

These definitions were written by Phil McCloghry-Laing <https://github.com/pmccloghrylaing>.

# Details
Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the sockjs-node directory.

Additional Details
 * Last updated: Thu, 21 Apr 2016 17:45:06 GMT
 * Typings kind: ProperModule
 * Library Dependencies: node
 * Module Dependencies: equire('http'
 * Global values: none
