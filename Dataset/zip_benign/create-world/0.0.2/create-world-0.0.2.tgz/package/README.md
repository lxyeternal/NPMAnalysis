<h1 align="center">
  create-world
</h1>
<h4 align="center">
    Create procedurally generated 2D worlds
</h4>

<div align="center">
  <img src="https://badgen.net/npm/v/create-world?icon=npm" />
  <img src="https://badgen.net/bundlephobia/minzip/create-world" />
</div>

Add a short introduction here.

---

## :sparkles: Features

---

## :wrench: Example usage

const world = createWorld({})
const generatedTiles = generateArea(world)({ x: 1, y: 0 })

---

## :package: Install

**npm**

```
npm install create-world
```

**yarn**

```
yarn add create-world
```

---

## :newspaper: API

---

## :book: Recipes

Mud-world:

```
const TileType = {
  WATER: 'water',
  MUD: 'mud',
}

const FeatureType = {
  LOG: 'log',
}

const world = createWorld({
  // order matters since resulting tiles will be first type matched
  tiles: [
    { type: TileType.WATER, noiseMax: -0.3 },
    // default tile so that something is always matched
    { type: TileType.MUD },
  ],
  features: [
    {
      type: FeatureType.LOG,
      tileTypesAllowed: [TileType.MUD],
      likelihood: 5,
    },
  ],
})
```

---

## :computer: Develop

### Commands

| Command           | Description                                    |
| ----------------- | ---------------------------------------------- |
| `yarn build`      | Generate files in the `dist` folder            |
| `yarn release`    | Start the process to release a new version     |
| `yarn typecheck`  | Run a type check with `typescript`             |
| `yarn lint`       | Lint with `eslint`                             |
| `yarn clean`      | Remove build artefact (`.tgz` file)            |
| `yarn build-test` | Builds, packs and installs to `example` folder |

### Workflow

1. Make changes
2. `yarn build-test` and verify that your changes work.
3. Commit to `master` or make `PR`

#### Release

1. `yarn release:prepare` - Sets up your library for release
2. If everything worked in the previous step: `yarn release`
