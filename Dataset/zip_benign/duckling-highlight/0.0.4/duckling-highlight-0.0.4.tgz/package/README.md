# duckling-highlight

Created by : Mr Dk.

2019.07 @Nanjing, Jiangsu, China

---

Highlight.js is a syntax highlighter written in JavaScript. It works in
the browser as well as on the server. It works with pretty much any
markup, doesn’t depend on any framework, and has automatic language
detection.

---

## CommonJS

You can import Highlight.js as a CommonJS-module:

```bash
npm install duckling-highlight --save
```

In your application:

```js
import hljs from 'duckling-highlight';
```

To set the syntax highlighting style, if your build tool processes CSS from your JavaScript entry point, you can import the stylesheet directly into your CommonJS-module:

```js
import hljs from 'duckling-highlight';
import 'duckling-highlight/styles/atom-one-light.css';

document.querySelectorAll('div.code').forEach((block) => {
  hljs.highlightBlock(block, 'atom-one-dark');
});
```

## Style

The selectors start with `hljs-` followed by theme name.

```css
.hljs-atom-one-dark {
  display: block;
  overflow-x: auto;
  padding: 0.5em;
  color: #abb2bf;
  background: #282c34;
}

.hljs-atom-one-dark-comment,
.hljs-atom-one-dark-quote {
  color: #5c6370;
  font-style: italic;
}
```

## Build

Run following command in the root directory of the project to build and publish:

```bash
node tools/build.js -t node
```

## License

Highlight.js is released under the BSD License. See [LICENSE][7] file
for details.

## Links

The official site for the library is at <https://highlightjs.org/>.

Further in-depth documentation for the API and other topics is at
<http://highlightjs.readthedocs.io/>.

Authors and contributors are listed in the [AUTHORS.en.txt][8] file.

[1]: http://highlightjs.readthedocs.io/en/latest/api.html#inithighlightingonload
[2]: http://highlightjs.readthedocs.io/en/latest/css-classes-reference.html
[3]: http://highlightjs.readthedocs.io/en/latest/api.html#highlightblock-block
[4]: http://highlightjs.readthedocs.io/en/latest/api.html#configure-options
[5]: https://highlightjs.org/download/
[6]: http://highlightjs.readthedocs.io/en/latest/building-testing.html
[7]: https://github.com/highlightjs/highlight.js/blob/master/LICENSE
[8]: https://github.com/highlightjs/highlight.js/blob/master/AUTHORS.en.txt

---
