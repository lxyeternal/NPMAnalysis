type CSSModuleClasses = {readonly [key: string]: string}
declare module '*.scss' {
	const classes: CSSModuleClasses
	export default classes
}
declare module '*.scss?global' {}

declare module '*.svg?react' {
	type ComponentType<T> = import('react').ComponentType<T>
	type SVGProps<T> = import('react').SVGProps<T>
	type ReactSVGElement = import('react').ReactSVGElement

	const component: ComponentType<SVGProps<ReactSVGElement>>
	export default component
}

// general
declare module '*?raw' {
	const content: string
	export default content
}
declare module '*?url' {
	const src: string
	export default src
}
// force base-64
declare module '*?inline' {
	const src: string
	export default src
}

// other
declare module '*.pdf' {
	const src: string
	export default src
}
declare module '*.txt' {
	const src: string
	export default src
}

// images
declare module '*.apng' {
	const url: string
	export default url
}
declare module '*.png' {
	const url: string
	export default url
}
declare module '*.jpeg' {
	const url: string
	export default url
}
declare module '*.jpg' {
	const url: string
	export default url
}
declare module '*.pjpeg' {
	const src: string
	export default src
}
declare module '*.jfif' {
	const src: string
	export default src
}
declare module '*.pjp' {
	const src: string
	export default src
}
declare module '*.gif' {
	const url: string
	export default url
}
declare module '*.bmp' {
	const url: string
	export default url
}
declare module '*.cur' {
	const url: string
	export default url
}
declare module '*.ico' {
	const url: string
	export default url
}
declare module '*.webp' {
	const url: string
	export default url
}
declare module '*.svg' {
	const url: string
	export default url
}

// media
declare module '*.mp4' {
	const src: string
	export default src
}
declare module '*.webm' {
	const src: string
	export default src
}
declare module '*.ogg' {
	const src: string
	export default src
}
declare module '*.mp3' {
	const src: string
	export default src
}
declare module '*.wav' {
	const src: string
	export default src
}
declare module '*.flac' {
	const src: string
	export default src
}
declare module '*.aac' {
	const src: string
	export default src
}
declare module '*.opus' {
	const src: string
	export default src
}
declare module '*.mov' {
	const src: string
	export default src
}

// fonts
declare module '*.woff' {
	const src: string
	export default src
}
declare module '*.woff2' {
	const src: string
	export default src
}
declare module '*.eot' {
	const src: string
	export default src
}
declare module '*.ttf' {
	const src: string
	export default src
}
declare module '*.otf' {
	const src: string
	export default src
}

// sizes
interface IImageSize {
	width: number
	height: number
}

declare module 'jfif?size' {
	const size: IImageSize
	export default size
}
declare module 'pjp?size' {
	const size: IImageSize
	export default size
}
declare module 'pjpeg?size' {
	const size: IImageSize
	export default size
}
declare module 'apng?size' {
	const size: IImageSize
	export default size
}
declare module 'bmp?size' {
	const size: IImageSize
	export default size
}
declare module 'cur?size' {
	const size: IImageSize
	export default size
}
declare module 'dds?size' {
	const size: IImageSize
	export default size
}
declare module 'gif?size' {
	const size: IImageSize
	export default size
}
declare module 'icns?size' {
	const size: IImageSize
	export default size
}
declare module 'ico?size' {
	const size: IImageSize
	export default size
}
declare module 'jpeg?size' {
	const size: IImageSize
	export default size
}
declare module 'jpg?size' {
	const size: IImageSize
	export default size
}
declare module 'png?size' {
	const size: IImageSize
	export default size
}
declare module 'psd?size' {
	const size: IImageSize
	export default size
}
declare module 'tiff?size' {
	const size: IImageSize
	export default size
}
declare module 'webp?size' {
	const size: IImageSize
	export default size
}
declare module 'avif?size' {
	const size: IImageSize
	export default size
}
declare module 'svg?size' {
	const size: IImageSize
	export default size
}

// srcset
type ImageFormatEnum = 'webp' | 'png' | 'jpeg' | 'avif'

type IImagePreset = Record<ImageFormatEnum, [url: string, descriptor?: string][]> & {size: {
		width: number
		height: number
		dimension?: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8
	}} & {lqip: Record<ImageFormatEnum, string>}

declare module '*jfif?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'pjp?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'pjpeg?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'apng?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'bmp?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'cur?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'dds?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'gif?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'icns?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'ico?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'jpeg?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'jpg?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'png?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'psd?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'tiff?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'webp?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'avif?srcset' {
	const srcset: IImagePreset
	export default srcset
}
declare module 'svg?srcset' {
	const srcset: IImagePreset
	export default srcset
}
