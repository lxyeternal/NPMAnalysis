#!/usr/bin/env node

import {readNBConfig} from '#nbConfig.mjs'
import {CliCommand, WebpackEnv} from '#config.mjs'
import {compileServer} from '#server.mjs'
import {compileClient} from '#client.mjs'
import {cliBuildBoth, cliDev} from '#cli.mjs'
import {startExecute} from '#babel/babel.mjs'


/**
 * @returns {Promise<void>}
 */
async function main() {
	const command = process.argv[2]
	console.log(command)
	const argv = process.argv.slice(3)
	switch (command) {
		case CliCommand.dev:
			await cliDev()
			break
		case CliCommand.build:
			await cliBuildBoth()
			break
		case CliCommand['watch:server']:
			await compileServer(await readNBConfig(WebpackEnv.development, argv))
			break
		case CliCommand['watch:client']:
			await compileClient(await readNBConfig(WebpackEnv.development, argv))
			break
		case CliCommand['build:server']:
			await compileServer(await readNBConfig(WebpackEnv.production, argv))
			break
		case CliCommand['build:client']:
			await compileClient(await readNBConfig(WebpackEnv.production, argv))
			break
		case CliCommand.execute:
			await startExecute(await readNBConfig(WebpackEnv.development, argv))
			break
		case CliCommand.analyze:
			await compileClient({
				...await readNBConfig(WebpackEnv.production, argv),
				enableAnalyzer: true
			})
			break
		case CliCommand.help:
			console.log(`Available commands: ${Object.values(CliCommand).join(', ')}`)
			break
		case undefined:
			console.log(`no command. Available commands: ${Object.values(CliCommand).join(', ')}`)
			break
		default:
			throw new Error(`Unknown command: ${command}. Available commands: ${Object.values(CliCommand).join(', ')}`)
	}
}

main().catch(e => {
	console.error(e)
	process.exit(1)
})
