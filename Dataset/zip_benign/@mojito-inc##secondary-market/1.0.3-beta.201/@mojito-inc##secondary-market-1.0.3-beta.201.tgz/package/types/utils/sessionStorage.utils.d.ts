export declare const session: (keyVariable: string, getData: boolean, data?: any) => any;
