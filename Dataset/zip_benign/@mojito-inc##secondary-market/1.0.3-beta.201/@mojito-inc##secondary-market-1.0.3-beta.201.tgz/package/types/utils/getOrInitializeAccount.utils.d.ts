import { Connection, PublicKey } from '@solana/web3.js';
export declare const getOrInitializeAccount: (connection: Connection, tokenAccount: PublicKey, owner: PublicKey, mintAccount: PublicKey, connectedPublicKey: PublicKey, onHandleSetProgressMessage: (message: string) => void, provider: any, providerType: string, balance?: number, customRPCUrl?: string, rentExemptMinimum?: number) => Promise<{
    isAvailable: boolean;
    usedBalance: number;
}>;
