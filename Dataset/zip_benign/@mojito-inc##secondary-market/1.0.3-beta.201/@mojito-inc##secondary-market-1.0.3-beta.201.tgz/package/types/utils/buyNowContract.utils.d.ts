import { BubbleGumParams } from '@mojito-inc/core-service';
import { HandleSentryFunctionProp } from '../interface';
interface BuyTokenProps {
    tokenId: string;
    price: string;
    owner: string;
    contractAddress: string;
    proofOfApproval: string;
    random: string;
    currencyContractAddress: string;
    marketPlaceContractAddress: string;
    provider: any;
    selectedAddress: string;
}
interface TransactionStatusProps {
    status: boolean;
    message: string | 'Error' | 'Reject';
}
export declare function buyTokenWithNonNativeCurrency({ tokenId, price, contractAddress, owner, random, proofOfApproval, selectedAddress, currencyContractAddress, marketPlaceContractAddress, provider, }: BuyTokenProps): Promise<TransactionStatusProps | undefined>;
export declare function buyTokenWithNativeCurrency({ tokenId, price, owner, random, proofOfApproval, contractAddress, selectedAddress, currencyContractAddress, marketPlaceContractAddress, provider, }: BuyTokenProps): Promise<TransactionStatusProps | undefined>;
export declare const buySolanaNFT: (address: string, _balance: {
    native: number;
    nonNative: number;
}, providerType: string, provider: any, chainId: number, onHandleSetProgressMessage: (message: string) => void, data?: BubbleGumParams, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
export {};
