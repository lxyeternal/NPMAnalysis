import React from 'react';
import { Theme } from '@mui/material/styles';
export declare const getProvenanceEventIcons: (eventType: string, theme: Theme) => React.JSX.Element | null;
