export declare const getSolanaBalance: (address: string, network?: 'mainnet-beta' | 'devnet' | 'testnet', customRPCUrl?: string) => Promise<{
    native: number;
    nonNative: any;
}>;
