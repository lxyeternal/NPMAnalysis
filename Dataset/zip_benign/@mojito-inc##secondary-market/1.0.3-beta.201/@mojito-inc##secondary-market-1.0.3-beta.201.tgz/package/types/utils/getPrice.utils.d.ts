import { TokenPriceProps } from '../interface';
interface PriceListProps {
    buyNowPrice: TokenPriceProps[];
    lastPurchasedPrice: TokenPriceProps[];
    makeOfferHighestPrice: TokenPriceProps[];
    makeOfferLatestPrice: TokenPriceProps[];
}
export declare const getPrice: (status: string, price: PriceListProps, listedPrice: TokenPriceProps[]) => {
    price: TokenPriceProps[];
    label: string;
};
export {};
