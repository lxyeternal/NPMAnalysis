import { HandleSentryFunctionProp } from '../interface';
export interface RejectOfferAPIResposne {
    seller: string;
    sellerTokenAccount: string;
    buyer: string;
    offer: string;
    offerEscrow: string;
    systemProgram: string;
    descriminator: number[];
    mintAccount?: string;
}
export declare const rejectOfferSolana: (address: string, _balance: {
    native: number;
    nonNative: number;
}, provider: any, providerType: string, onHandleSetProgressMessage: (message: string) => void, chainId: number, mintAccount: string, data?: RejectOfferAPIResposne, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
