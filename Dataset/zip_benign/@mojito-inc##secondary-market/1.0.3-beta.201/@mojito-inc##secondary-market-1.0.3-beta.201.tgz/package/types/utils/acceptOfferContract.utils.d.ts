import { BubbleGumParams } from '@mojito-inc/core-service';
import { HandleSentryFunctionProp } from '../interface';
export declare function buyerBalance(address: string, contractAddress: string, provider: any, chainId: number): Promise<string | undefined>;
interface acceptOfferApprovalProps {
    tokenId: string;
    price: number;
    buyerAddress: string;
    contractAddress: string;
    marketPlaceContractAddress: string;
    proofOfApproval: string;
    random: string;
    quantity: number;
    tax: number;
    expiryDate: string;
    networkContractAddress: string;
    provider: any;
}
export declare const acceptOfferApproval: ({ tokenId, price, buyerAddress, quantity, tax, contractAddress, marketPlaceContractAddress, random, expiryDate, proofOfApproval, networkContractAddress, provider, }: acceptOfferApprovalProps) => Promise<any>;
export declare const acceptOfferSolana: (address: string, _balance: {
    native: number;
    nonNative: number;
}, provider: any, providerType: string, onHandleSetProgressMessage: (message: string) => void, chainId: number, data?: BubbleGumParams, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
export {};
