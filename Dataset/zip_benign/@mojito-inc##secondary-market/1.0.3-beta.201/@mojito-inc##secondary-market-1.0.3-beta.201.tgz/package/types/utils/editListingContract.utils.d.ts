import { BubbleGumListParams } from '@mojito-inc/core-service';
import { HandleSentryFunctionProp } from '../interface';
export declare const editListingSolana: (address: string, _balance: {
    native: number;
    nonNative: number;
}, provider: any, providerType: string, onHandleSetProgressMessage: (message: string) => void, chainId: number, data?: BubbleGumListParams, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
