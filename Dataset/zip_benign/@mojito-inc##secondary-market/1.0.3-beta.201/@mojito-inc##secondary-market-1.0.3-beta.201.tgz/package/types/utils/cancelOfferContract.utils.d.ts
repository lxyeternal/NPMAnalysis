import { HandleSentryFunctionProp } from '../interface';
export interface CancelOfferAPIResposne {
    seller: string;
    sellerTokenAccount: string;
    buyer: string;
    offer: string;
    offerEscrow: string;
    systemProgram: string;
    descriminator: number[];
    mintAccount?: string;
}
export declare const cancelOfferSolanaItem: (address: string, _balance: {
    native: number;
    nonNative: number;
}, provider: any, providerType: string, chainId: number, onHandleSetProgressMessage: (message: string) => void, mintAccount: string, data?: CancelOfferAPIResposne, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
