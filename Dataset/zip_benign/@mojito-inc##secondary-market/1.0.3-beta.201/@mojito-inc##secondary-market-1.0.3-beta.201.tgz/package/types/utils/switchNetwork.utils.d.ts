interface SwitchNetworkResponse {
    status: boolean;
    message: string;
}
export declare const onSwitchNetwork: (chainId: number, isMetamask: boolean, provider: any) => Promise<SwitchNetworkResponse>;
export {};
