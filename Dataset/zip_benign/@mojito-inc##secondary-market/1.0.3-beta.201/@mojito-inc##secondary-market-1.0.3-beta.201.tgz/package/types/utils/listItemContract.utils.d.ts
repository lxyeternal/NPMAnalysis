import { BubbleGumListParams } from '@mojito-inc/core-service';
import { HandleSentryFunctionProp } from '../interface';
interface CheckApproval {
    marketPlaceContractAddress: string;
    tokenContractAddress: string;
    contractName: string;
    provider: any;
}
interface ApproveToken {
    marketPlaceContractAddress: string;
    tokenContractAddress: string;
    contractName: string;
    provider: any;
}
interface TransactionStatusProps {
    status: boolean;
    message: string | any;
}
export declare const checkApproval: ({ marketPlaceContractAddress, tokenContractAddress, contractName, provider, }: CheckApproval) => Promise<boolean>;
export declare const approveToken: ({ marketPlaceContractAddress, tokenContractAddress, contractName, provider, }: ApproveToken) => Promise<TransactionStatusProps>;
export declare const waitForApproval: (transaction: any) => Promise<boolean>;
export declare const listItemSolana: (address: string, _balance: {
    native: number;
    nonNative: number;
}, providerType: string, provider: any, onHandleSetProgressMessage: (message: string) => void, chainId: number, data?: BubbleGumListParams, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
        listingReceipt: string;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
export {};
