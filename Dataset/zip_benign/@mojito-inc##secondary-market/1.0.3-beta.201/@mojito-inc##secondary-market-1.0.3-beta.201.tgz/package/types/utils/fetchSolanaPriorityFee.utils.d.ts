export declare const fetchSolanaPriorityFee: (apiURL?: string, transaction?: any, defaultFee?: number) => Promise<any>;
