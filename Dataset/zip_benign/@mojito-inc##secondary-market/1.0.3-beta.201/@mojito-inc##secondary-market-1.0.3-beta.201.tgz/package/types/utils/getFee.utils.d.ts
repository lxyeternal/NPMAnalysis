export declare const getFee: (price: number, fee: number, isUSD: boolean, isFee?: boolean) => number;
