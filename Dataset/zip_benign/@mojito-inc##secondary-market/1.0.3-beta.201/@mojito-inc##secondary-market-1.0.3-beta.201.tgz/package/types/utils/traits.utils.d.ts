export declare const getTraitsDescription: (value: any) => any;
export declare const getTraitsPercent: (prevalence: number) => string;
