export declare function formatNumberWithCommas(value: number | string): string;
