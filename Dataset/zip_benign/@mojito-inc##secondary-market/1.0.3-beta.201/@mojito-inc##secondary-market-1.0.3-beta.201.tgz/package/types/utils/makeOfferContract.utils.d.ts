import { BubblegumMakeOfferParams } from '@mojito-inc/core-service';
import { HandleSentryFunctionProp } from '../interface';
interface CheckApprovalProps {
    price: number;
    currencyContractAddress: string;
    marketPlaceContractAddress: string;
    currency: string;
    provider: any;
    status?: boolean;
}
interface UnlockApprovalProps {
    currencyContractAddress: string;
    marketPlaceContractAddress: string;
    currency: string;
    provider: any;
}
interface ApprovalResponse {
    status: boolean;
    message: 'Success' | 'Error' | 'Reject';
}
export declare function checkApproval({ price, status, marketPlaceContractAddress, currencyContractAddress, currency, provider, }: CheckApprovalProps): Promise<boolean | undefined | string>;
export declare function unlockApproval({ marketPlaceContractAddress, currencyContractAddress, currency, provider, }: UnlockApprovalProps): Promise<ApprovalResponse | undefined>;
export declare const makeOfferSolanaItem: (address: string, _balance: {
    native: number;
    nonNative: number;
}, provider: any, providerType: string, onHandleSetProgressMessage: (message: string) => void, chainId: number, ownerAddress: string, data?: BubblegumMakeOfferParams, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
        offerReceipt: string;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
export {};
