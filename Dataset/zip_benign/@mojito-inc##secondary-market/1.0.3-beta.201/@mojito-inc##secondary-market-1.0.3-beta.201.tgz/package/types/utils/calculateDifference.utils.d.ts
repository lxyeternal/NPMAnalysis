export declare const calculatePercentageDifference: (a: number, b: number) => string;
