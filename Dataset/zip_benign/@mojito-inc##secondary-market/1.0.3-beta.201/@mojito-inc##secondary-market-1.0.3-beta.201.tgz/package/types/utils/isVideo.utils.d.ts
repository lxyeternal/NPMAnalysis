export declare const isVideo: (url: string) => boolean;
