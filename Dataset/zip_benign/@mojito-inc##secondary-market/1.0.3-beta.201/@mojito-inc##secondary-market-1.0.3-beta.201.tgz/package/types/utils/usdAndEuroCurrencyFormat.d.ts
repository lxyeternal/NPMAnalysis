export declare const formatUsdAndEuroCurrency: (value: number | string, currency: 'USD' | 'EUR' | string) => string;
