export declare const customErrorMessage: (error: any) => any;
