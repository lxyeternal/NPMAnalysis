interface SwapPriceProps {
    price: number;
    currencyContractAddress: string;
    provider: any;
}
interface SwapResponse {
    status: boolean;
    message: string;
}
export declare function swapPrice({ price, currencyContractAddress, provider, }: SwapPriceProps): Promise<SwapResponse>;
export {};
