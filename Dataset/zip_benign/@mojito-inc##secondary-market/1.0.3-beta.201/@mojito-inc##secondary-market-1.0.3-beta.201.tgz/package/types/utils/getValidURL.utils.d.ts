export declare const getValidURL: (data: string) => string;
