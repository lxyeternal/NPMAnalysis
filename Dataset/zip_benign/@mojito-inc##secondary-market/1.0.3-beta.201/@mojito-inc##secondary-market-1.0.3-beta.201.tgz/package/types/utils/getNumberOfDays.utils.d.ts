export declare const numberOfDays: (value: string) => number;
