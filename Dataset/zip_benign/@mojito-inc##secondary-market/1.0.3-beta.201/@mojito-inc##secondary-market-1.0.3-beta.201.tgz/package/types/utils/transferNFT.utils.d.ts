interface TransferTokenProps {
    tokenId: string;
    tokenType: string;
    contractAddress: string;
    toAddress: string;
    signer: any;
    walletAddress: string;
    maxFeePerGas: number;
    maxPriorityFeePerGas: number;
}
interface TransactionStatusProps {
    status: boolean;
    message: string | 'Error' | 'Reject';
}
export declare function transferToken({ tokenId, tokenType, contractAddress, toAddress, signer, walletAddress, maxFeePerGas, maxPriorityFeePerGas, }: TransferTokenProps): Promise<TransactionStatusProps | undefined>;
export {};
