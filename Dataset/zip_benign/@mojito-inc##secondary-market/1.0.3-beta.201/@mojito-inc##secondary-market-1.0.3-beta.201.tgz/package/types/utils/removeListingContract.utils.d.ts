import { bubbleGumListArgParams } from '@mojito-inc/core-service';
import { HandleSentryFunctionProp } from '../interface';
export interface RemoveListingApiResponse {
    seller: string;
    sellerTokenAccount: string;
    mintAccount: string;
    metadataId: string;
    systemProgram: string;
    tokenProgram: string;
    rent: string;
    bubblegumProgram: string;
    compressionProgram: string;
    treeAuthority: string;
    leafOwner: string;
    previousLeafDelegate: string;
    newLeafDelegate: string;
    logWrapper: string;
    merkleTree: string;
    listDiscriminator: number[];
    bubblegumListArg: bubbleGumListArgParams;
    listingReceipt: string;
}
export declare const removeListingSolanaItem: (address: string, _balance: {
    native: number;
    nonNative: number;
}, provider: any, providerType: string, onHandleSetProgressMessage: (message: string) => void, chainId: number, data?: RemoveListingApiResponse, customRPCUrl?: string, handleSentryLogs?: HandleSentryFunctionProp, rentExemptMinimum?: number) => Promise<{
    success: boolean;
    response: {
        hash: any;
    };
    error?: undefined;
} | {
    success: boolean;
    error: any;
    response?: undefined;
} | null>;
