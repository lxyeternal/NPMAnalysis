export declare const getTransferedStatusName: (name: string) => string;
