export declare enum ActiveWalletSort {
    RECENTLY_LISTED = "recently_listed",
    RECENTLY_MINTED = "recently_minted",
    INITIALLY_MINTED = "initially_minted",
    PRICE_LOW_TO_HIGH = "price_low_to_high",
    PRICE_HIGH_TO_LOW = "price_high_to_low",
    MOST_SAVED = "most_saved",
    PURCHASED_FROM_ORG = "purchased_from_org"
}
