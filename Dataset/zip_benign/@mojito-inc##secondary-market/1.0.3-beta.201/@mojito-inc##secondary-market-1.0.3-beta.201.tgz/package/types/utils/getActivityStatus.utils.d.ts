export declare const getActivityStatus: (name: string) => string;
