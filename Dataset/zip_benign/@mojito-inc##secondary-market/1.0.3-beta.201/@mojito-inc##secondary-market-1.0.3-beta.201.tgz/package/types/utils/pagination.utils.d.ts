export declare const getTotalPage: (total: number, limit: number) => number;
