export declare const getTotalVin: (tokenId: string, chainId?: number, customRPCUrl?: string) => Promise<number>;
