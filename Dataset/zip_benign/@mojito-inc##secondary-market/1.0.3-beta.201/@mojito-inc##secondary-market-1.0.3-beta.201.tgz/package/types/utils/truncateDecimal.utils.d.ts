export declare const truncateDecimal: (price?: string | number, index?: number, removeEmptyDot?: boolean) => string;
export declare function roundUp(price: number, precision: number): number;
