export declare const validateWalletAddress: (address: string) => boolean;
