export declare const getEtherScanURL: (chainId: number, hash: string) => string;
export declare const getNFTScanURL: (chainId: number, hash: string) => string;
export declare const getChainExplorerURL: (chainId: number, contractAddress: string, tokenId: string) => string;
export declare const getChainNFTScanExplorerURL: (chainId: number, contractAddress: string, tokenId: string) => string;
export declare const getSolanaEnvByChainId: (id?: number) => "mainnet-beta" | "devnet" | "testnet";
