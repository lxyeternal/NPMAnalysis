export declare const truncateAddress: (address: string, front?: number, back?: number) => string;
