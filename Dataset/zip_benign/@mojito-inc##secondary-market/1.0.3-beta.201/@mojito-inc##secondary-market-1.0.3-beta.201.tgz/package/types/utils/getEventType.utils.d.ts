export declare const getEventTypeName: (name: string, isSeller: boolean, isBuyer: boolean) => string;
