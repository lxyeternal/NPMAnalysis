import { OfferData } from '../interface';
export declare const useTokenOffer: (orgId: string, itemId: string, isWalletConnected?: boolean, currency?: string) => {
    offerData: OfferData[] | null | undefined;
    offerLoading: boolean;
    offerRefetch: () => void;
};
