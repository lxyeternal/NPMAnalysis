import { CurrencyCodeFiat, InvoiceFilterInputData } from '@mojito-inc/core-service';
import { TokenCardProps } from '../component';
import { ActivityDetail } from '../component/ActivityCard';
import { SupportedNetworksData, WalletType } from '../interface';
export interface ActiveWalletFilter {
    search?: string;
    sort?: string;
}
export interface GetActiveWalletsContentParam {
    walletAddress: string;
    networkId: string;
    orgID: string;
    filters?: ActiveWalletFilter;
    nextPageKey?: string;
    refreshCache?: boolean;
    contractAddress?: string;
    currency?: CurrencyCodeFiat;
    itemFilter?: InvoiceFilterInputData;
    walletType?: WalletType;
}
export type InvoiceType = 'ALL_INVOICES' | 'MY_INVOICES';
export interface GetUserOrderActivityParam {
    orgId: string;
    limit: number;
    offset: number;
    placeholderImage: string;
    filterByStatus?: string[];
    invoiceType?: InvoiceType;
    returnAllStatuses?: boolean;
    listingId?: string;
    dropId?: string;
}
export interface GenerateInvoiceParam {
    invoiceID: string;
    orderID: string;
    activityName: string;
    invoiceResType: string;
    isSecondary?: boolean;
}
export interface DownloadUrlData {
    mediaURL: string;
    type: string;
    contentType: string;
    expiryDuration: string;
}
export declare const useWallet: (config: GetActiveWalletsContentParam, activityConfig: GetUserOrderActivityParam, invoiceConfig?: GenerateInvoiceParam) => {
    activeWalletsLoading: boolean;
    activeWalletsData: TokenCardProps[] | null;
    activityLoading: boolean;
    totalActivity: number;
    activityData: ActivityDetail[] | null;
    networkData: SupportedNetworksData[] | null | undefined;
    totalActiveWallets: number;
    fetchActiveWalletItems: () => void;
    fetchActivityItems: () => void;
    downloadUrlLoading: boolean;
    getDownloadUrl: (url: string, contractAddress: string, tokenID: string) => Promise<any>;
};
