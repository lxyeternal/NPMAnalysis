import { HandleSentryFunctionProp } from '../interface';
declare const useSolanaWalletPolling: () => {
    checkForMismatchWalletAddress: (currentAppWalletAddress: string, providerType: string, handleSentryLog?: HandleSentryFunctionProp) => Promise<{
        isMismatched: boolean;
        address: string | undefined;
    }>;
};
export default useSolanaWalletPolling;
