interface CollectionsListParams {
    orgID: string;
    marketplaceID: string;
}
declare const useCollectionsList: ({ marketplaceID, orgID, }: CollectionsListParams) => {
    collectionsListLoading: boolean;
    collectionsOptions: {
        label: string;
        value: string;
    }[];
    fetchCollections: () => Promise<void>;
    fetchCollectionsList: () => void;
};
export default useCollectionsList;
