import { MutableRefObject } from 'react';
type UseViewProps = {
    threshold?: number;
    elementRef: MutableRefObject<HTMLDivElement | null>;
};
declare const useInView: ({ threshold, elementRef }: UseViewProps) => {
    inView: boolean;
    elementRef: MutableRefObject<HTMLDivElement | null>;
};
export default useInView;
