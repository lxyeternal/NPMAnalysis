import { CryptoCurrency, Currency, SupportedNetworksData, TokenPriceProps, TokenStatus } from '../interface';
interface Artist {
    id: string;
    description: string;
    artistName: string;
    artistLocation: string;
    artistContactEmail: string;
    artistContactNumber: string;
    artistWebsite: string;
    slug?: string;
}
interface MetadataAttributes {
    traitType: string;
    value: {
        intValue?: number;
        floatValue?: number;
        stringValue?: string;
        boolValue?: string;
        __typename?: string;
    };
    displayType: string;
    maxValue: number;
    prevalance?: number;
}
interface MetaData {
    name: string;
    description: string;
    image: string;
    attributes: MetadataAttributes[];
    externalURL: string;
    backgroundColor: string;
    animationURL: string;
    timestamp: number;
    language: string;
    openSeaImageURL?: string;
    tags: string[];
    yearCreated: string;
    createdBy: string;
}
export interface TokenDetailsData {
    contractAddress: string;
    tokenId: number;
    network: string;
    owner: string;
    contractName: string;
    tokenType: string;
    mintedAt: string;
    status: TokenStatus;
    metadata: MetaData;
    artist: Artist;
    isMakeOfferEnabled: boolean;
    isBuyNowEnabled: boolean;
    isOfferExist: boolean;
    mediaSourceExtension: string;
    mediaSourceType: string;
    mediaSourceURL: string;
    listedOrderInfo: {
        id: string;
        listedCurrency: {
            contractAddress: string;
        };
        price: TokenPriceProps[];
    };
    latestOffer: {
        price: TokenPriceProps[];
    };
    balance: number;
    price: {
        buyNowPrice: TokenPriceProps[];
        lastPurchasedPrice: TokenPriceProps[];
        makeOfferHighestPrice: TokenPriceProps[];
        makeOfferLatestPrice: TokenPriceProps[];
    };
    isFavorite: boolean;
    nftTokenId: string;
    tokenURI: string;
    networkID: string;
    tokenOwnerAvatar: string;
    tokenOwnerAddress: string;
    tokenOwnerUsername: string;
    editions: number;
    editionNumber: number;
}
interface USDConversionData {
    amount: string;
    currency: string;
    base: string;
}
interface TokenParam {
    orgId: string;
    contractAddress: string;
    onChainTokenID: string;
    cryptoCurrencyCode?: CryptoCurrency;
    currency?: Currency;
}
export declare const useTokenDetails: (config: TokenParam, isOpen?: boolean, tokenDetailsData?: TokenDetailsData) => {
    tokenData: TokenDetailsData | null | undefined;
    networkData: SupportedNetworksData[] | null | undefined;
    usdData: USDConversionData | null | undefined;
    detailsLoading: boolean;
    isNetworkLoading: boolean;
    isPriceLoading: boolean;
    isError: boolean;
    reFetchAPI: () => void;
};
export {};
