import { Currency, ProvenanceProps, TraitsData } from '../interface';
interface TokenParam {
    orgId: string;
    contractAddress: string;
    itemId: string;
    onChainTokenID: string;
    networkId: string;
    ownerAddress: string;
    limit?: number;
    offset?: number;
    currency?: Currency;
    showSpecialTraits?: boolean;
    connectedChainId?: number;
    customRPCUrl?: string;
}
export declare const useProvenance: (config: TokenParam) => {
    provenanceData: ProvenanceProps[] | null | undefined;
    provenanceLoading: boolean;
    traitsData: TraitsData[] | null | undefined;
    traitsLoading: boolean;
    totalProvenanceData: number;
    provenanceRefetch: () => void;
    traitsRefetch: () => void;
};
export {};
