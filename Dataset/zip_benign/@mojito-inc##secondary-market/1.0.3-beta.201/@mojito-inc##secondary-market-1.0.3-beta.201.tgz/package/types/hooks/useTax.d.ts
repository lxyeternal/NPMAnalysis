import { TaxEstimateType } from '../interface';
interface EstimateTaxData {
    platformFee: number;
    royaltyFee: number;
    taxPercentage: number;
    commissionFee: number;
    taxResponse?: {
        USDUnitprice: number;
        cryptoTaxPrice: number;
        cryptoTotalPrice: number;
        taxPercentage: number;
    };
}
export declare const useTax: (orgId: string, estimateType: TaxEstimateType, nftTokenId: string, isOpen?: boolean, currency?: string) => {
    taxData: EstimateTaxData | null;
    taxLoading: boolean;
};
export {};
