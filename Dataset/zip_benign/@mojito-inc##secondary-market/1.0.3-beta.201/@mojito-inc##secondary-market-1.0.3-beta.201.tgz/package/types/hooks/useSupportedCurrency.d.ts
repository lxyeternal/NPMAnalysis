interface SupportedCurrencyData {
    id: string;
    name: string;
    networkId: string;
    symbol: string;
    contractAddress: string;
    secondaryMarketplaceContractAddress: string;
    network: {
        id: string;
        name: string;
        chainID: number;
        wethAddress: string;
        paymentCurrency: string;
    };
}
interface TokenParam {
    orgId: string;
    contractAddress: string;
    itemId: string;
    onChainTokenID?: string;
}
export declare const useSupportedCurrency: (config: TokenParam, open?: boolean) => {
    supportedCurrencyData: SupportedCurrencyData[] | null | undefined;
    currencyLoading: boolean;
};
export {};
