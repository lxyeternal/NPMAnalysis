declare const useFetchMediaType: (url?: string) => {
    fetchFinalURL: (mediaUrl: string) => Promise<void>;
    mediaType: string | null;
    isLoading: boolean;
    finalURL: string | null;
};
export default useFetchMediaType;
