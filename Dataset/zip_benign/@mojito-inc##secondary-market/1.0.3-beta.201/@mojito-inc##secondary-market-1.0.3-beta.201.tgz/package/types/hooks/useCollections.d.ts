import { AttributeFilterDataProp, WalletType } from '../interface';
import { TokenCardDetail } from '../component/TokenCard';
export declare enum RegistryTokenFilterInput {
    RECENTLY_LISTED = "recently_listed",
    RECENTLY_MINTED = "recently_minted",
    INITIALLY_MINTED = "initially_minted",
    PRICE_LOW_TO_HIGH = "price_low_to_high",
    PRICE_HIGH_TO_LOW = "price_high_to_low"
}
interface RegistryFilterMetadata {
    traitType: string;
    traitValue: string[];
}
export interface CollectionParams {
    orgID: string;
    marketplaceID: string;
    search?: string;
    limit?: number;
    offset?: number;
    filters: RegistryTokenFilterInput;
    walletType?: WalletType;
    metaDataFilters?: RegistryFilterMetadata[];
    walletAddress: string;
    selectedCollection?: string;
    currencyType: string;
}
export interface CollectionDataProps {
    cardDetail: TokenCardDetail;
    id: string;
    tokenId: string;
    contractAddress: string;
}
export declare const useCollections: (config: CollectionParams) => {
    collectionsLoading: boolean;
    traitsLoading: boolean;
    collectionsData: CollectionDataProps[] | null;
    totalCollections: number;
    traitsData: AttributeFilterDataProp[];
    fetchCollection: () => void;
    fetchMetaDataDetails: () => void;
};
export {};
