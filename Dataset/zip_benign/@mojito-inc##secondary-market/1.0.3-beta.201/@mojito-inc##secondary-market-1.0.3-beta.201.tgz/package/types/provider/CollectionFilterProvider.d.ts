import * as React from 'react';
import { ReactNode, Dispatch, SetStateAction } from 'react';
import { CollectionDataProps } from '../hooks/useCollections';
import { AttributeFilterDataProp, Currency, WalletProps, WalletType } from '../interface';
export interface CollectionFilterSearchProp {
    field: string;
    value: string;
}
export interface CollectionFilterSelectedValueProp {
    field: string;
    value: string[];
}
interface CollectionFilterProp {
    search: CollectionFilterSearchProp[];
    selectedFilter: CollectionFilterSelectedValueProp[];
    refetchFilter: boolean;
    filteredCollectionData: CollectionDataProps[] | null;
    filteredCollectionsLoading: boolean;
    searchText: string;
    offset: number;
    totalCollections: number;
    traitsData: AttributeFilterDataProp[];
    filter: string | undefined;
    walletType: WalletType;
    selectedCollection: string;
    collectionsOptions: {
        label: string;
        value: string;
    }[];
    currencyType: Currency;
    setSearch: Dispatch<SetStateAction<CollectionFilterSearchProp[]>>;
    setSelectedFilter: Dispatch<SetStateAction<CollectionFilterSelectedValueProp[]>>;
    setRefetchFilter: Dispatch<SetStateAction<boolean>>;
    setSearchText: Dispatch<SetStateAction<string>>;
    setOffset: Dispatch<SetStateAction<number>>;
    setFilter: Dispatch<SetStateAction<string | undefined>>;
    fetchCollection: () => void;
    fetchCollectionsList: () => void;
    setSelectedCollection: Dispatch<SetStateAction<string>>;
    clearTraitsFilter: () => void;
    setCurrencyType: Dispatch<SetStateAction<Currency>>;
}
interface CollectionFilterProviderProp {
    isShowFilters: boolean;
    filterConfig: {
        orgID: string;
        marketplaceID: string;
    };
    walletDetails: WalletProps;
    walletType: WalletType;
    children: ReactNode;
}
export declare const tokensFilterOptions: {
    label: string;
    value: string;
}[];
export declare const useFilterData: () => CollectionFilterProp;
declare const CollectionFilterProvider: ({ isShowFilters, walletType, children, filterConfig, walletDetails, }: CollectionFilterProviderProp) => React.JSX.Element;
export default CollectionFilterProvider;
