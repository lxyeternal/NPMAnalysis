import * as React from 'react';
import { ExclusiveEventHintOrCaptureContext } from '@sentry/core/build/types/utils/prepareEvent';
import { SentryConfig } from './SecondaryMarketProvider';
interface SentryContextProp {
    addExtraLogsForSentry: (key: string, value: unknown) => void;
    addCaptureExceptionForSentry: (exception: unknown, hint?: ExclusiveEventHintOrCaptureContext) => void;
}
interface SentryProviderProp {
    sentryConfig?: SentryConfig;
    children: JSX.Element | JSX.Element[];
}
export declare const useSentry: () => SentryContextProp;
declare const SentryProvider: React.FC<SentryProviderProp>;
export default SentryProvider;
