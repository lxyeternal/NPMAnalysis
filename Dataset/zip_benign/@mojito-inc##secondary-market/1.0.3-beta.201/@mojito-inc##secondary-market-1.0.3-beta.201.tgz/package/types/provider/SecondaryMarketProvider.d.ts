import * as React from 'react';
import { Theme } from '@mui/material/styles';
import { BrowserOptions } from '@sentry/react';
export interface ApolloClientOptions {
    uri?: string;
    token?: string;
}
export interface SentryConfig {
    isEnableSentry?: boolean;
    config?: BrowserOptions;
}
interface SecondaryThemeProviderProps {
    children: JSX.Element | JSX.Element[];
    theme: Theme;
    clientOptions: ApolloClientOptions;
    sentryConfig?: SentryConfig;
}
declare const SecondaryMarketProvider: ({ children, theme, clientOptions, sentryConfig }: SecondaryThemeProviderProps) => React.JSX.Element;
export default SecondaryMarketProvider;
