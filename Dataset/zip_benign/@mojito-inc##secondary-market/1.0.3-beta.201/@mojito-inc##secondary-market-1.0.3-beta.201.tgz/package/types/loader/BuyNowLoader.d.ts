import * as React from 'react';
declare const BuyNowLoader: () => React.JSX.Element;
export default BuyNowLoader;
