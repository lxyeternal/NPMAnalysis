import * as React from 'react';
interface TableRowLoaderProps {
    name: string;
    rows: number;
    columns: number;
}
declare const TableRowLoader: ({ name, columns, rows, }: TableRowLoaderProps) => React.JSX.Element;
export default TableRowLoader;
