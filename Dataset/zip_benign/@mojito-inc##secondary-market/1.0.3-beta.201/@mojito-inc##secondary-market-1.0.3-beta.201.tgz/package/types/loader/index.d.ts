import BuyNowLoader from './BuyNowLoader';
import TableRowLoader from './TableRowLoader';
import DetailsPageLoader from './DetailsPageLoader';
import TokenCardLoader from './TokenCardLoader';
import ActivityCardLoader from './ActivityCardLoader';
export { BuyNowLoader, TableRowLoader, DetailsPageLoader, TokenCardLoader, ActivityCardLoader, };
