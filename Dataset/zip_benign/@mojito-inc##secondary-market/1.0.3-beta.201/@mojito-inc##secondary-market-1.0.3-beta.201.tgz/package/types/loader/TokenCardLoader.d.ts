import * as React from 'react';
interface TokenCardLoaderProps {
    cardLoaderBg?: string;
    cardSkeletonBg?: string;
}
declare const TokenCardLoader: ({ cardLoaderBg, cardSkeletonBg, }: TokenCardLoaderProps) => React.JSX.Element;
export default TokenCardLoader;
