import * as React from 'react';
interface ActivityCardLoaderProps {
    isMobile?: boolean;
}
declare const ActivityCardLoader: ({ isMobile }: ActivityCardLoaderProps) => React.JSX.Element;
export default ActivityCardLoader;
