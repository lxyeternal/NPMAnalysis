import * as React from 'react';
declare const NetworkDetailsLoader: () => React.JSX.Element;
export default NetworkDetailsLoader;
