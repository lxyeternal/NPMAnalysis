import * as React from 'react';
export interface TraitsContainerProps {
    traitsList: string[];
}
declare const TraitsLoader: ({ traitsList }: TraitsContainerProps) => React.JSX.Element;
export default TraitsLoader;
