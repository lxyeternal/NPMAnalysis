import * as React from 'react';
declare const ProductDetailPageLayout: () => React.JSX.Element;
export default ProductDetailPageLayout;
