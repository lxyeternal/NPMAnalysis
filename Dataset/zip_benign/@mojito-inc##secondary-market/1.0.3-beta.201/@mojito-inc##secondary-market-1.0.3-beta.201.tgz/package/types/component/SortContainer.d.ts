import * as React from 'react';
export interface OptionsProps {
    value: string;
    label: string;
}
export interface SortProps {
    leftIcon: JSX.Element;
    text: string;
    selectedValue: OptionsProps;
    options: OptionsProps[];
    open: boolean;
    isMobileScreen?: boolean;
    anchorEl: HTMLElement | null;
    handleClickListItem: (event: React.MouseEvent<HTMLElement>) => void;
    handleApply: () => void;
    handleMenuItemClick: (option: OptionsProps) => void;
    handleClose: () => void;
}
declare const SortMenu: ({ leftIcon, text, selectedValue, options, open, isMobileScreen, anchorEl, handleClickListItem, handleApply, handleMenuItemClick, handleClose, }: SortProps) => React.JSX.Element;
export default SortMenu;
