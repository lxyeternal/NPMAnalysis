import * as React from 'react';
import { FeeData } from '../interface';
export interface PriceContainerProps {
    serviceFee: FeeData;
    creatorFee: FeeData;
    totalPrice?: FeeData;
    ethIcon?: string;
    tooltipTitle?: string;
}
declare const PriceContainer: ({ creatorFee, serviceFee, totalPrice, ethIcon, tooltipTitle, }: PriceContainerProps) => React.JSX.Element;
export default PriceContainer;
