import * as React from 'react';
import { ListingType } from '../constant';
import { WalletMediaConfig } from '../interface';
export interface TokenCardDetail {
    collectionName: string;
    cryptoPrice: number;
    usdPrice: number;
    collectionType: string;
    priceLabel: string;
    cryptoLabel: string;
    tokenImage: string;
    tokenName: string;
    tokenSubtitle: string;
    buttonName?: string;
    animationURL?: string;
    id?: string;
    thumbnailImage?: string;
    tokenId?: string | number;
    contractAddress?: string;
    networkId?: string;
    tokenOwnerAddress?: string;
    networkChainId?: number;
    video?: string;
    downloadVideo?: string;
    placeholderImage?: string;
}
export interface TokenCardProps {
    listingType?: ListingType;
    cardDetail: TokenCardDetail;
    showMenu?: boolean;
    walletMediaConfig?: WalletMediaConfig;
    placeholderImage?: string;
    currency?: 'USD' | 'EUR';
    isShowSecondaryButton?: boolean;
    secondaryButtonLabel?: string;
    onClickSecondaryButton?: () => void;
    handleMenuOpen?: (event: React.MouseEvent<HTMLElement>) => void;
    onClickButton?: () => void;
    onClickCard?: () => void;
}
declare const TokenCard: ({ listingType, cardDetail, showMenu, placeholderImage, walletMediaConfig, currency, isShowSecondaryButton, secondaryButtonLabel, onClickSecondaryButton, handleMenuOpen, onClickButton, onClickCard, }: TokenCardProps) => React.JSX.Element;
export default TokenCard;
