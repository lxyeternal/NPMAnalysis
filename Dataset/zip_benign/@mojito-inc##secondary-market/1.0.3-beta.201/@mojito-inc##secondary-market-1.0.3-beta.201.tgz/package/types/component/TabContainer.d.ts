import * as React from 'react';
interface TabsData {
    index: number;
    label: string;
    showTab?: boolean;
    icon?: React.ReactElement;
    component?: React.ReactNode;
}
export interface TabBarProps {
    tabs: TabsData[];
    tabValue: number;
    setCurrentTab?: (tab: string) => void;
    isBottomTab?: boolean;
}
declare const TabBar: ({ tabs, tabValue, setCurrentTab, isBottomTab, }: TabBarProps) => React.JSX.Element;
export default TabBar;
