import * as React from 'react';
import { VideoAttributes } from './CustomVideoPlayer';
export type MediaContainerProps = {
    url: string;
    width?: string;
    height?: string;
    style?: React.CSSProperties;
    placeholderImage?: string;
    enableCardVideo?: boolean;
    videoAttributes?: VideoAttributes;
    imageBorderRadius?: string;
};
declare const ImageWithVideoPlayer: React.FC<MediaContainerProps>;
export default ImageWithVideoPlayer;
