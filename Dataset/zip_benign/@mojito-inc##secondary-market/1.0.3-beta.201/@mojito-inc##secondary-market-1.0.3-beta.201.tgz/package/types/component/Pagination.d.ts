import * as React from 'react';
export interface PaginationProps {
    total: number;
    offset: number;
    onHandlePagination: (selectedPage: number) => void;
}
declare const Pagination: ({ total, offset, onHandlePagination, }: PaginationProps) => React.JSX.Element;
export default Pagination;
