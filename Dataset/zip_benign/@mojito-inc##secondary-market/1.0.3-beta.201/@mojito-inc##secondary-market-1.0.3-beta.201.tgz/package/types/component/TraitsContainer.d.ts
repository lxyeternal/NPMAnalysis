import React from 'react';
import { TraitsData } from '../interface';
export interface TraitsContainerProps {
    traitsList: TraitsData[];
}
declare const TraitsContainer: ({ traitsList }: TraitsContainerProps) => React.JSX.Element;
export default TraitsContainer;
