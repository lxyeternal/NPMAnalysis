import * as React from 'react';
import { ProvenanceProps } from '../interface';
export interface ProvenanceContainerProps {
    data: ProvenanceProps[];
    chainId: number;
    totalData: number;
    offset: number;
    provenanceLoading: boolean;
    onHandlePagination: (page: number) => void;
}
declare const ProvenanceContainer: ({ data, chainId, totalData, offset, onHandlePagination, provenanceLoading }: ProvenanceContainerProps) => React.JSX.Element;
export default ProvenanceContainer;
