import * as React from 'react';
interface NoDataContainerProps {
    noDataMessage?: string;
    border?: boolean;
}
declare const NoDataContainer: ({ noDataMessage, border }: NoDataContainerProps) => React.JSX.Element;
export default NoDataContainer;
