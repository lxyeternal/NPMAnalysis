import * as React from 'react';
export interface TokenNetworkDetailsContainerProps {
    networkName: string;
    tokenType: string;
    contractAddress: string;
    tokenId: string;
    chainId: number;
    metaDataURL: string;
    edition?: number;
    walletType: string;
}
declare const TokenNetworkDetailsContainer: ({ networkName, tokenType, contractAddress, tokenId, chainId, metaDataURL, edition, walletType, }: TokenNetworkDetailsContainerProps) => React.JSX.Element;
export default TokenNetworkDetailsContainer;
