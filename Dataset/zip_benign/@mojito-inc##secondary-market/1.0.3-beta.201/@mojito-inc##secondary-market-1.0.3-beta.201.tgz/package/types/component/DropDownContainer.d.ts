import React from 'react';
import { SelectChangeEvent } from '@mui/material/Select';
export interface DropDownProps {
    selectedValue: string;
    title: string;
    menu: {
        label: string;
        value: string;
    }[];
    onChangeValue: (event: SelectChangeEvent) => void;
    isMakeOfferModal?: boolean;
}
declare const DropDownContainer: ({ selectedValue, title, menu, onChangeValue, isMakeOfferModal, }: DropDownProps) => React.JSX.Element;
export default DropDownContainer;
