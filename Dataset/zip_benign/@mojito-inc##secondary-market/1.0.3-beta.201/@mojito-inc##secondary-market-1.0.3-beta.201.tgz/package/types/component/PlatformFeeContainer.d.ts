import * as React from 'react';
import { BuyNowFeeData, Currency } from '../interface';
export interface PlatformFeeProps {
    creatorFeeData: BuyNowFeeData;
    serviceFeeData: BuyNowFeeData;
    currency?: Currency;
}
declare const PlatformFee: ({ creatorFeeData, serviceFeeData, currency }: PlatformFeeProps) => React.JSX.Element;
export default PlatformFee;
