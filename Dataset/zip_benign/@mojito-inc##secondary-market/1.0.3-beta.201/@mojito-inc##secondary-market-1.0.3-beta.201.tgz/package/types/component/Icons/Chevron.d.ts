import React from 'react';
declare const ChevronIcon: () => React.JSX.Element;
export default ChevronIcon;
