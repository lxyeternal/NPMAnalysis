import * as React from 'react';
import { CSSProperties } from 'react';
import { VideoAttributes } from './CustomVideoPlayer';
export interface VideoWithImageCardProps {
    url?: string;
    width?: string;
    height?: string;
    style?: CSSProperties;
    placeholderImage?: string;
    videoAttributes?: VideoAttributes;
}
declare const _default: React.NamedExoticComponent<VideoWithImageCardProps>;
export default _default;
