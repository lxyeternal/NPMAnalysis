import * as React from 'react';
export interface FeeContainerProps {
    title: string;
    cryptoPrice: string;
    usdPrice: string;
    ethIcon?: string;
    isTotalPrice?: boolean;
    totalPriceFontSize?: number;
}
declare const FeeContainer: ({ title, cryptoPrice, usdPrice, ethIcon, isTotalPrice, totalPriceFontSize, }: FeeContainerProps) => React.JSX.Element;
export default FeeContainer;
