import * as React from 'react';
interface MenuOptions {
    menuName: string;
    menuIcon?: React.ReactElement;
    menuAction?: () => void;
    hideMenu?: boolean;
}
export interface MenuContainerProps {
    isMobileScreen?: boolean;
    anchorEl: HTMLElement | null;
    menuOptions: MenuOptions[];
    copied: string;
    handleMenuClose: () => void;
}
declare const MenuContainer: ({ isMobileScreen, anchorEl, menuOptions, copied, handleMenuClose, }: MenuContainerProps) => React.JSX.Element;
export default MenuContainer;
