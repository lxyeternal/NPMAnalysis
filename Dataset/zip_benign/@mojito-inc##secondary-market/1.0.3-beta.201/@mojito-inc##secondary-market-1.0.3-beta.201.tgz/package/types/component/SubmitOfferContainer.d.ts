import * as React from 'react';
export interface SubmitOfferContainerProps {
    cryptoPrice: string;
    usdPrice: string;
    expiryDate: string;
}
declare const SubmitOfferContainer: ({ cryptoPrice, usdPrice, expiryDate }: SubmitOfferContainerProps) => React.JSX.Element;
export default SubmitOfferContainer;
