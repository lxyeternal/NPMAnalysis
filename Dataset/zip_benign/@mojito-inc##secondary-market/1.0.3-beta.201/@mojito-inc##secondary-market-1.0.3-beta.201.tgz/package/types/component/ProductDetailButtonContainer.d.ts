import * as React from 'react';
export interface ProductDetailButtonContainerProps {
    isBuyNow: boolean;
    isListItem: boolean;
    isEditListing: boolean;
    isMakeOffer: boolean;
    isCancelOffer: string;
    onClickPrimary: (event: 'Buy Now' | 'List Item' | 'Edit Listing' | '') => void;
    onClickSecondary: (event: 'Make Offer' | 'Remove Listing' | 'Cancel Offer' | '', isCancelOffer: string) => void;
}
declare const ProductDetailButtonContainer: ({ isBuyNow, isEditListing, isListItem, isMakeOffer, isCancelOffer, onClickPrimary, onClickSecondary, }: ProductDetailButtonContainerProps) => React.JSX.Element;
export default ProductDetailButtonContainer;
