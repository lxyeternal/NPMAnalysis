import * as React from 'react';
import { ToastTypeProps } from '../interface';
export interface ToastContainerProps {
    message: string;
    status: ToastTypeProps;
}
declare const ToastContainer: ({ message, status }: ToastContainerProps) => React.JSX.Element;
export default ToastContainer;
