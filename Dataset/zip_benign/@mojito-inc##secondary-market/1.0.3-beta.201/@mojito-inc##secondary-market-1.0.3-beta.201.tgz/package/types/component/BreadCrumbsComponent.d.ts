import * as React from 'react';
import { type SxProps } from '@mui/material/styles';
export interface BreadcrumbItem {
    label: string;
    value: string;
}
export interface BreadcrumbsProps {
    list: BreadcrumbItem[];
    selectedValue: string;
    separator?: JSX.Element;
    separatorStyle?: SxProps;
    itemStyle?: SxProps;
    itemHighlightedStyle?: SxProps;
}
declare const BreadcrumbsContainer: ({ list, selectedValue, separator, separatorStyle, itemStyle, itemHighlightedStyle, }: BreadcrumbsProps) => React.JSX.Element;
export default BreadcrumbsContainer;
