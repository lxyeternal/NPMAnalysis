import * as React from 'react';
export interface TermsAndConditionProps {
    checked: boolean;
    termURL: string;
    conditionOfBusinessURL: string;
    error?: boolean;
    handleTermsAndCondition: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
declare const TermsAndConditionContainer: ({ checked, termURL, conditionOfBusinessURL, error, handleTermsAndCondition, }: TermsAndConditionProps) => React.JSX.Element;
export default TermsAndConditionContainer;
