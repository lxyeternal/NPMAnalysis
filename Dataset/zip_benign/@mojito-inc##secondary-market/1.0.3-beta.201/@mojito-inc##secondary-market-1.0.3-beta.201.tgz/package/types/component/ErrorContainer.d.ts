import * as React from 'react';
export interface ErrorContainerProps {
    title: string;
    message: string;
    subTitle: string;
    onClick: () => void;
}
declare const ErrorContainer: ({ title, subTitle, message, onClick }: ErrorContainerProps) => React.JSX.Element;
export default ErrorContainer;
