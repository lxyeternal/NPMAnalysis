import React from 'react';
import { TokenCardDetail } from './TokenCard';
declare const TruncatedDescription: React.FC<TokenCardDetail>;
export default TruncatedDescription;
