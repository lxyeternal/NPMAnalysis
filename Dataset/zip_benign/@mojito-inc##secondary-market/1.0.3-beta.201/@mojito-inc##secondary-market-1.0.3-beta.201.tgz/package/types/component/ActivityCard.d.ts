import * as React from 'react';
import { ListingType } from '../constant';
interface NFTPrice {
    value: number;
    unit: string;
    usdValue: string;
}
export interface ActivityDetail {
    date: string;
    activityName: string;
    InvoiceID: string;
    TransactionHash: string;
    OrderID: string;
    NetworkId?: string;
    itemName: string;
    tokenId: number | string;
    listingImage?: string;
    nftTokenId: string;
    contractAddress: string;
    status: string;
    tokenImage: string;
    price: NFTPrice;
    activity: string;
    isSecondary?: boolean;
    eventType: string;
    fromWalletAddress: string;
    toWalletAddress: string;
}
export interface ActivityCardProps {
    listingType?: ListingType;
    activityDetail: ActivityDetail;
    desktopView?: boolean;
    showInvoice?: boolean;
    showViewItem?: boolean;
    placeholderImage?: string;
    onClickDownload: (item: ActivityDetail) => void;
    onClickEtherscan: (item: ActivityDetail) => void;
    onClickActivityViewItem: (item: ActivityDetail) => void;
}
declare const ActivityCard: ({ listingType, activityDetail, desktopView, showInvoice, showViewItem, placeholderImage, onClickDownload, onClickEtherscan, onClickActivityViewItem, }: ActivityCardProps) => React.JSX.Element;
export default ActivityCard;
