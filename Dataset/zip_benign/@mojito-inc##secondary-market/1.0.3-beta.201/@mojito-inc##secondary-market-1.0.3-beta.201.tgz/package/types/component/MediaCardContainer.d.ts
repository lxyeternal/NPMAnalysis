import * as React from 'react';
import { ActivityCardProps } from './ActivityCard';
import { WalletType } from '../interface';
export interface MediaContainerProps {
    url?: string;
    height?: number | string;
    style?: React.CSSProperties;
    desktopView?: boolean;
    placeholderImage?: string;
    enableCardVideo?: boolean;
}
export type MediaCardContainerProps = ActivityCardProps & {
    enableCardVideo?: boolean;
    freeClaimText?: string;
    walletType?: WalletType;
    walletAddress?: string;
    currency?: 'USD' | 'EUR';
};
export declare const MediaCardContainer: React.FC<MediaCardContainerProps>;
