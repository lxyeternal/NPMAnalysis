import * as React from 'react';
import { Currency, OfferData } from '../interface';
export interface OfferCardContainerProps {
    data: OfferData[];
    walletAddress: string;
    offersOffset: number;
    totalOffers: number;
    selectedCurrency?: Currency;
    onClickAcceptOffer: (event: OfferData) => void;
    onClickRejectOffer: (event: OfferData) => void;
    onClickCancelOffer: (event: string) => void;
    onHandleOffersPagination: (page: number) => void;
}
declare const OfferCardContainer: ({ data, walletAddress, offersOffset, totalOffers, selectedCurrency, onClickAcceptOffer, onClickRejectOffer, onClickCancelOffer, onHandleOffersPagination, }: OfferCardContainerProps) => React.JSX.Element;
export default OfferCardContainer;
