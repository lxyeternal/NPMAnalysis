import { FC } from 'react';
interface TokenDescriptionContainerProps {
    title: string;
    subTitle: string;
}
declare const TokenDescriptionContainer: FC<TokenDescriptionContainerProps>;
export default TokenDescriptionContainer;
