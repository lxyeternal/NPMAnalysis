import * as React from 'react';
import { VideoAttributes } from './CustomVideoPlayer';
export interface ImageContentContainerProps {
    url: string;
    title: string;
    subTitle: string;
    placeholderImage?: string;
    height?: string;
    videoAttributes?: VideoAttributes;
}
declare const MediaContentContainer: ({ url, title, subTitle, placeholderImage, height, videoAttributes, }: ImageContentContainerProps) => React.JSX.Element;
export default MediaContentContainer;
