import * as React from 'react';
export interface FooterProps {
    footerLinks?: {
        name: string;
        link: string;
    }[];
    footerSocialMedia?: {
        logo: string;
        link: string;
    }[];
}
declare const Footer: ({ footerLinks, footerSocialMedia }: FooterProps) => React.JSX.Element;
export default Footer;
