import { FC } from 'react';
import { AttributeFilterComponentProps } from '../../interface';
declare const AttributeFilterComponent: FC<AttributeFilterComponentProps>;
export default AttributeFilterComponent;
