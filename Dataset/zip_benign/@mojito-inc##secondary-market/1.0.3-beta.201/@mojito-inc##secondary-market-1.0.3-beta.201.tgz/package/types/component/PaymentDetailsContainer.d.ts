import * as React from 'react';
import { WalletType } from '../interface';
export interface PaymentDetailsContainerProps {
    totalPrice: string;
    ethIcon?: string;
    transactionHash: string;
    walletAddress: string;
    copied: string;
    referenceNumber: string;
    onClickViewOnEtherScan: () => void;
    onClickCopyReference: () => void;
    onClickCopyHash: () => void;
    onClickCopyWalletAddress: () => void;
    walletType?: WalletType;
}
declare const PaymentDetailsContainer: ({ totalPrice, ethIcon, transactionHash, walletAddress, referenceNumber, copied, onClickCopyReference, onClickCopyHash, onClickCopyWalletAddress, onClickViewOnEtherScan, walletType, }: PaymentDetailsContainerProps) => React.JSX.Element;
export default PaymentDetailsContainer;
