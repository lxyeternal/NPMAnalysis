import * as React from 'react';
export interface OptionsProps {
    value: string;
    label: string;
}
export interface MenuDetailsProps {
    selectedValue: OptionsProps;
    options: OptionsProps[];
    isMobileScreen?: boolean;
    handleApply: () => void;
    handleMenuItemClick: (option: OptionsProps) => void;
}
declare const MenuDetails: ({ selectedValue, options, isMobileScreen, handleApply, handleMenuItemClick, }: MenuDetailsProps) => React.JSX.Element;
export default MenuDetails;
