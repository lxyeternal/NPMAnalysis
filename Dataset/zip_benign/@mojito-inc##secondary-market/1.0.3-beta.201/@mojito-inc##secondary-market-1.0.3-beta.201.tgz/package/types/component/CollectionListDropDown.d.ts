import React from 'react';
export interface DropDownProps {
    selectedValue: string;
    title: string;
    menu: {
        label: string;
        value: string;
    }[];
    onChangeValue: (event: string) => void;
}
declare const CollectionListDropDown: ({ selectedValue, title, menu, onChangeValue, }: DropDownProps) => React.JSX.Element;
export default CollectionListDropDown;
