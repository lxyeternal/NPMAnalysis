import * as React from 'react';
export interface WalletNotConnectedProps {
    message: string;
    onConnectWallet: () => void;
}
declare const WalletNotConnectedContainer: ({ message, onConnectWallet }: WalletNotConnectedProps) => React.JSX.Element;
export default WalletNotConnectedContainer;
