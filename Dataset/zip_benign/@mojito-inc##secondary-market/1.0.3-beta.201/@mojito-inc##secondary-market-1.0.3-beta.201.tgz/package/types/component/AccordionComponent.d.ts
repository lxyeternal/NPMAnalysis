import * as React from 'react';
import { TraitsOptionProp } from '../interface';
interface AccordionProp {
    title: string;
    search: any;
    options: TraitsOptionProp[];
    selectedOptions: string[];
    renderSearch?: boolean;
    headingTitle?: string;
    onChangeSearch: (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, field: string) => void;
    handleToggleOption: (e: any, option: TraitsOptionProp, title: string) => void;
}
declare const AccordionComponent: ({ title, search, onChangeSearch, options, handleToggleOption, selectedOptions, renderSearch, headingTitle, }: AccordionProp) => React.JSX.Element;
export default AccordionComponent;
