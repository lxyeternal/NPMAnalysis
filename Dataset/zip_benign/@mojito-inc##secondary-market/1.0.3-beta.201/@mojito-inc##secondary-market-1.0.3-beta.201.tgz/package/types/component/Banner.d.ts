import * as React from 'react';
import { SxProps, Theme } from '@mui/material/styles';
export interface BannerProps {
    title?: string;
    subtitle?: string;
    mediaURL?: string;
    buttonName?: string;
    titleStyle?: SxProps<Theme>;
    subtitleStyle?: SxProps<Theme>;
    buttonStyle?: SxProps<Theme>;
    onClickButton?: () => void;
}
declare const Banner: ({ title, subtitle, buttonName, mediaURL, titleStyle, subtitleStyle, buttonStyle, onClickButton, }: BannerProps) => React.JSX.Element;
export default Banner;
