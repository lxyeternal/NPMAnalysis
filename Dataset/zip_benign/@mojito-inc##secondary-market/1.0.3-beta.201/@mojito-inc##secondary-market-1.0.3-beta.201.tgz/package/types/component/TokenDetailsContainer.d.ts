import * as React from 'react';
export interface TokenDetailsContainerProps {
    collectionName: string;
    isFavorite: boolean;
    tokenName: string;
    owner: string;
    cryptoPrice: string;
    usdPrice: string;
    loaderImage: string;
    isLoading: boolean;
    showFavorite?: boolean;
    onClickFavorite: () => void;
    tokenId: string;
    chainId: number;
}
declare const TokenDetailsContainer: ({ collectionName, isFavorite, tokenName, owner, cryptoPrice, usdPrice, loaderImage, isLoading, showFavorite, onClickFavorite, chainId, tokenId, }: TokenDetailsContainerProps) => React.JSX.Element;
export default TokenDetailsContainer;
