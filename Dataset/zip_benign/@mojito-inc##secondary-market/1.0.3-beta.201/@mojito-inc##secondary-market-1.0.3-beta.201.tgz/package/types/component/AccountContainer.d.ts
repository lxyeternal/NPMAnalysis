import * as React from 'react';
export interface AccountContainerProps {
    currency: {
        currencyName: string;
        currencyIcon: string | undefined;
    };
    nonNativeCurrency: {
        currencyName: string;
        currencyIcon: string | undefined;
    };
    walletAddress: string;
    walletBalance: {
        native: number;
        nonNative: number;
    };
    isCopied: boolean;
    networkName?: string;
    hideWalletBalance?: boolean;
    isFullAddress?: boolean;
    isMobile?: boolean;
    onClickCopy: (action?: 'Icon' | 'Button') => void;
    handleRefetchBalance?: () => void;
    refreshIcon?: string;
}
declare const AccountContainer: ({ currency, walletAddress, walletBalance, networkName, isMobile, isCopied, isFullAddress, hideWalletBalance, nonNativeCurrency, onClickCopy, handleRefetchBalance, refreshIcon, }: AccountContainerProps) => React.JSX.Element;
export default AccountContainer;
