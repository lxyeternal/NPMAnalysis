import React from 'react';
declare const ClientOnly: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
export default ClientOnly;
