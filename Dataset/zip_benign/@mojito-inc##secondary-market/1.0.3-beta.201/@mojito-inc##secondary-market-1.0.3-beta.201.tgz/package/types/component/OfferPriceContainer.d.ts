import * as React from 'react';
export interface OfferPriceProps {
    totalprice?: number;
    currency: string;
    wethValue: string;
}
declare const OfferPriceContainer: ({ currency, totalprice, wethValue, }: OfferPriceProps) => React.JSX.Element;
export default OfferPriceContainer;
