import * as React from 'react';
import { SelectChangeEvent } from '@mui/material/Select';
export interface InputDropdownContainerProps {
    ethIcon?: string;
    currencyData: string;
    title: string;
    isDropdown: boolean;
    currencyList?: {
        label: string;
        value: string;
    }[];
    disabled?: boolean;
    price?: string;
    selectCurrency?: string;
    maxLength?: number;
    transferField?: boolean;
    hideBorder?: boolean;
    iconClick?: () => void;
    onChangePrice?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeCurrency?: (event: SelectChangeEvent) => void;
}
declare const InputDropdownContainer: ({ ethIcon, title, price, selectCurrency, isDropdown, currencyData, currencyList, disabled, maxLength, transferField, iconClick, onChangeCurrency, onChangePrice, hideBorder, }: InputDropdownContainerProps) => React.JSX.Element;
export default InputDropdownContainer;
