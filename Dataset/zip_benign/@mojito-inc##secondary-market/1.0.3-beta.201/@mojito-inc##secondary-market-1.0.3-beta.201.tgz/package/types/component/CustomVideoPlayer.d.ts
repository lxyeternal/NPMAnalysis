import React from 'react';
export type VideoAttributes = {
    width?: string;
    height?: string;
    controls?: boolean;
    muted?: boolean;
    loop?: boolean;
    playsInline?: boolean;
    autoPlay?: boolean;
    cloudinaryUrl?: string;
    playBtnEnabled?: boolean;
    customThumbnail?: string;
    thumbnailFrame?: 'first' | 'last' | 'custom' | 'thumbnail-only';
    optionalFrame?: 'first' | 'last';
};
export type CustomVideoPlayerProps = {
    width?: string;
    height?: string;
    sourceUrl: string;
    onError: (error: Error) => void;
    controls?: boolean;
    videoAttributes?: VideoAttributes;
    cloudinaryUrl?: string;
};
export declare const CustomVideoPlayer: React.FC<CustomVideoPlayerProps>;
