import * as React from 'react';
export interface WalletStatusContainerProps {
    walletAddress: string;
    ethIcon?: string;
    balance: string;
    isSwap: boolean;
    copied: boolean;
    symbol: string;
    onClickCopy: () => void;
    onClickDisconnectWallet: () => void;
    onClickConnectWallet: () => void;
    onClickSwap: () => void;
}
declare const WalletStatusContainer: ({ walletAddress, ethIcon, balance, isSwap, copied, symbol, onClickCopy, onClickDisconnectWallet, onClickConnectWallet, onClickSwap, }: WalletStatusContainerProps) => React.JSX.Element;
export default WalletStatusContainer;
