import * as React from 'react';
import { Currency } from '../interface';
export interface TotalOfferPriceProps {
    wethValue: string;
    listPrice: string;
    priceUSD: number;
    ethIcon?: string;
    toolTipTitle: string;
    isError?: boolean;
    fiatCurrency?: Currency;
    title?: string;
}
declare const TotalOfferPriceContainer: ({ ethIcon, wethValue, listPrice, priceUSD, toolTipTitle, isError, fiatCurrency, title, }: TotalOfferPriceProps) => React.JSX.Element;
export default TotalOfferPriceContainer;
