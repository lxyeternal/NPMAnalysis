import * as React from 'react';
import { TransferNFTSuccessProps } from '../interface';
declare const TransferNFTSuccessLayout: ({ open, headerTitle, modalMessage, modalIcon, buttonName, buttonAction, handleCloseSuccessModal, handleClickViewTransfer, }: TransferNFTSuccessProps) => React.JSX.Element;
export default TransferNFTSuccessLayout;
