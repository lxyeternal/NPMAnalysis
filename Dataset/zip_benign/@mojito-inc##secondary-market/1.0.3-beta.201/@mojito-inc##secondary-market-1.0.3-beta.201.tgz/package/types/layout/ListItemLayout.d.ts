import * as React from 'react';
import { ListItemLayoutProps } from '../interface';
declare const ListItemLayout: ({ open, image, tokenDetails, breadCrumbs, selectedBreadCrumbs, creatorFee, serviceFee, totalPrice, listingPrice, currencyData, price, selectCurrency, error, isEdit, progress, currencyList, isRemoveListing, switchNetwork, isValidListItem, isLoading, walletConnection, maxLength, walletType, contractProgressMessage, mediaCardAttributes, onClickSwitchNetwork, onChangeCurrency, onChangePrice, onClickListItem, onCloseModal, onClickConnectWallet, }: ListItemLayoutProps) => React.JSX.Element;
export default ListItemLayout;
