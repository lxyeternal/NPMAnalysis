import React from 'react';
import { BuyNowLayoutProps } from '../interface';
declare const BuyNowLayout: ({ open, image, tokenDetails, breadCrumbs, selectedBreadCrumbs, currencyData, price, usdPrice, selectCurrency, error, progress, walletAddress, balance, validateBuyNow, copied, termsCheck, validateTerms, orderDetails, currencyList, detailsLoading, symbol, isValidBuyNow, termsURL, conditionOfBusinessURL, walletType, contractProgressMessage, mediaCardAttributes, onClickViewOnEtherScan, onChangeTermsAndCondition, onChangeCurrency, onClickCopyReference, onClickCopyHash, onClickCopyWalletAddress, onClickDisconnectWallet, onClickConnectWallet, onClickSwap, onClickSwitchNetwork, onClickBuyNow, onCloseModal, }: BuyNowLayoutProps) => React.JSX.Element;
export default BuyNowLayout;
