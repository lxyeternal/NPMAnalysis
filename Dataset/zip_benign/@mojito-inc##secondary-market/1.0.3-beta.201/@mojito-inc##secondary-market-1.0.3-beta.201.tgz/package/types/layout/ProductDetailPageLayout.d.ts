import * as React from 'react';
import { ProductDetailPageLayoutProps } from '../interface';
declare const ProductDetailPageLayout: ({ tokenData, traitsList, offerList, provenanceData, walletAddress, button, isFavorite, isLoading, loaderImage, totalProvenanceData, provenanceOffset, offersOffset, totalOffers, totalOffersPage, provenanceLoading, favoriteLoading, showFavorite, fiatCurrency, onClickFavorite, onClickPrimary, onClickSecondary, onClickAcceptOffer, onClickCancelOffer, onClickRejectOffer, onHandleProvenancePagination, onHandleOffersPagination, placeHolderImage, walletType, videoAttributes, isError, }: ProductDetailPageLayoutProps) => React.JSX.Element;
export default ProductDetailPageLayout;
