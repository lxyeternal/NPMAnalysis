import * as React from 'react';
import { BannerProps } from '../component';
import { ImageProps, TokenProps, WalletProps } from '../interface';
import { VideoAttributes } from '../component/CustomVideoPlayer';
interface CollectionPageLayoutProps {
    walletDetails: WalletProps;
    Image: ImageProps;
    config: {
        orgId: string;
    };
    primaryBannerDetails?: BannerProps;
    secondaryBannerDetails?: BannerProps;
    priceInputRange?: number;
    showAttributeFilters?: boolean;
    onConnectWallet: () => void;
    onRefetchBalance: () => void;
    onClickDisconnectWallet: () => void;
    onClickCard: (params?: TokenProps) => void;
    onClickCustomRedirection?: (params?: TokenProps) => void;
    onViewItem?: (params?: TokenProps) => void;
    backToMarketPlace?: (params?: TokenProps) => void;
    cardLoaderBg?: string;
    cardSkeletonBg?: string;
    currencyValue?: 'USD' | 'EUR';
    searchPlaceholderText?: string;
    collectionFilterProp?: string;
    termsURL?: string;
    conditionOfBusinessURL?: string;
    videoAttributes?: VideoAttributes;
    customRPCUrl?: string;
    onHandleApiSessionExpired?: () => void;
}
declare const CollectionPageLayout: ({ walletDetails, Image, config, primaryBannerDetails, secondaryBannerDetails, priceInputRange, showAttributeFilters, cardLoaderBg, cardSkeletonBg, currencyValue, searchPlaceholderText, collectionFilterProp, termsURL, conditionOfBusinessURL, customRPCUrl, videoAttributes, onConnectWallet, onRefetchBalance, onClickDisconnectWallet, onClickCard, onViewItem, onClickCustomRedirection, backToMarketPlace, onHandleApiSessionExpired, }: CollectionPageLayoutProps) => React.JSX.Element;
export default CollectionPageLayout;
