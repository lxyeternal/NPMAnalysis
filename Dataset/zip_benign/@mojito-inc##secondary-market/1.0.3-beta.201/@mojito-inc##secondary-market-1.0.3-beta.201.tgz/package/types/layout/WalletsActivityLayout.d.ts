import * as React from 'react';
import { ActivityDetail } from '../component/ActivityCard';
import { ListingType } from '../constant';
import { WalletType } from '../interface';
interface WalletsActivityDataProps {
    listingType?: ListingType;
    noDataMessage?: string;
    offset: number;
    totalPage: number;
    activityLoading: boolean;
    walletActivityData: ActivityDetail[];
    isMobile: boolean;
    showInvoice?: boolean;
    showViewItem?: boolean;
    placeholderImage?: string;
    enableCardVideo?: boolean;
    freeClaimText?: string;
    handlePagination: (page: number) => void;
    onClickDownload: (item: ActivityDetail) => void;
    onClickEtherscan: (item: ActivityDetail) => void;
    onClickActivityViewItem: (item: ActivityDetail) => void;
    walletType?: WalletType;
    walletAddress?: string;
    onConnectWallet: () => void;
    currency?: 'USD' | 'EUR';
}
declare const WalletsActivityLayout: ({ listingType, noDataMessage, offset, totalPage, activityLoading, walletActivityData, isMobile, showInvoice, showViewItem, placeholderImage, enableCardVideo, freeClaimText, handlePagination, onClickDownload, onClickEtherscan, onClickActivityViewItem, walletType, walletAddress, onConnectWallet, currency, }: WalletsActivityDataProps) => React.JSX.Element;
export default WalletsActivityLayout;
