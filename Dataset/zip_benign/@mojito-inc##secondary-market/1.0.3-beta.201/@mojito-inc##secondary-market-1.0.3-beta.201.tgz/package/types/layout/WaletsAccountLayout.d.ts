import * as React from 'react';
import { WalletsAccountLayoutProps } from '../interface';
declare const WalletsAccountLayout: ({ copied, currency, walletAddress, walletBalance, hideWalletBalance, isMobile, disconnectText, networkName, copyAddressText, isFullAddress, nonNativeCurrency, walletType, onClickLogout, onConnectWallet, onClickCopy, onClickTopUp, handleRefetchBalance, refreshIcon, }: WalletsAccountLayoutProps) => React.JSX.Element;
export default WalletsAccountLayout;
