import * as React from 'react';
import { WalletsLabelDataProps } from '../interface';
declare const WalletsLabelLayout: ({ listingType, noDataMessage, offset, activeWalletData, sortWalletLabel, anchorEl, open, selectedValue, walletAddress, search, showMenu, showSearch, showSort, showRefresh, refetchIcon, totalActiveWallets, activeWalletsLoading, placeholderImage, walletMediaConfig, currency, secondaryButtonLabel, isRefetchingWallets, onClickSecondaryButton, handleMenuOpen, handlePagination, handleSearchText, onClickToken, onClickCard, onConnectWallet, handleClickListItem, handleApply, handleMenuItemClick, handleClose, onClickRefreshCache, }: WalletsLabelDataProps) => React.JSX.Element;
export default WalletsLabelLayout;
