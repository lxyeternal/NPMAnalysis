import React from 'react';
import { TokensListLayoutProps } from '../interface';
declare const TokensListLayout: ({ tokensData, tokensFilterValue, tokensFilterOptions, collectionsLoading, search, showFilter, showAttributeFilters, traitsData, cardLoaderBg, cardSkeletonBg, placeHolderImage, onChangeFilter, onChangeSearch, onClickTokenButton, onClickCard, setShowFilter, onChangeCollectionFilter, searchPlaceholderText, videoAttributes, showFilterLoader, }: TokensListLayoutProps) => React.JSX.Element;
export default TokensListLayout;
