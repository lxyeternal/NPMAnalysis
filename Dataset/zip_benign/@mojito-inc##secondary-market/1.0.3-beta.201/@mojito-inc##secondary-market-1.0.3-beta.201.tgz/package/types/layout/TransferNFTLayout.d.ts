import * as React from 'react';
import { TransferNFTProps } from '../interface';
declare const TransferNFTLayout: ({ open, copied, error, transferWalletAddress, tokenDetails, maxLength, confirmTransfer, mediaCardAttributes, onClickCopy, onChangeWalletAddress, onCloseModal, handlePaste, onTransferNFT, onConfirmTransferNFT, onEditWalletAddress, }: TransferNFTProps) => React.JSX.Element;
export default TransferNFTLayout;
