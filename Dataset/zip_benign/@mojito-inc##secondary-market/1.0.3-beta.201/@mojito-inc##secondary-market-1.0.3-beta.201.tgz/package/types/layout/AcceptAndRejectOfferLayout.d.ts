import * as React from 'react';
import { AcceptAndRejectOfferLayoutProps } from '../interface';
declare const AcceptAndRejectOfferLayout: ({ open, image, tokenDetails, breadCrumbs, selectedBreadCrumbs, error, progress, price, listPricePercentage, isValidOffer, isRejectOffer, switchNetwork, isPDP, walletConnection, isLoading, fiatCurrency, walletType, creatorFee, serviceFee, totalOffer, contractProgressMessage, mediaCardAttributes, onClickAcceptOrRejectOffer, onClickSwitchNetwork, onCloseModal, onClickConnectWallet, }: AcceptAndRejectOfferLayoutProps) => React.JSX.Element;
export default AcceptAndRejectOfferLayout;
