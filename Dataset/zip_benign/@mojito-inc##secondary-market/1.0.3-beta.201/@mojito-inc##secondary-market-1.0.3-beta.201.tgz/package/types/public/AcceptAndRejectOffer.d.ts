import * as React from 'react';
import { AcceptAndRejectOfferProps } from '../interface';
declare const AcceptAndRejectOffer: ({ open, image, config, tokenDetails, orderId, isRejectOffer, tokenDetailsData, walletDetails, isPDP, customRPCUrl, mediaCardAttributes, onClickViewItem, onCloseModal, onClickBackToMarketPlace, onConnectWallet, onRefetchBalance, onHandleApiSessionExpired, }: AcceptAndRejectOfferProps) => React.JSX.Element;
export default AcceptAndRejectOffer;
