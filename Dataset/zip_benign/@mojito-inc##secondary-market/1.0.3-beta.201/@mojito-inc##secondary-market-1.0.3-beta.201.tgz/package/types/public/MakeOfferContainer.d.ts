import * as React from 'react';
import { MakeOfferProps } from '../interface';
declare const MakeOfferContainer: ({ open, image, config, tokenDetails, tokenDetailsData, isCancelOffer, walletDetails, priceInputRange, termsURL, conditionOfBusinessURL, customRPCUrl, mediaCardAttributes, onClickViewItem, onCloseModal, onClickBackToMarketPlace, onRefetchBalance, onConnectWallet, onHandleApiSessionExpired, }: MakeOfferProps) => React.JSX.Element;
export default MakeOfferContainer;
