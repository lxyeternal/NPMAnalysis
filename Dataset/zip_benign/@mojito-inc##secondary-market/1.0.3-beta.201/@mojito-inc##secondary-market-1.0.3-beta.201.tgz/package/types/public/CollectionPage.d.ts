import * as React from 'react';
import { CollectionPageProps } from '../interface';
declare const CollectionPage: ({ walletDetails, marketplaceID, Image, config, primaryBannerDetails, secondaryBannerDetails, priceInputRange, showAttributeFilters, walletType, cardLoaderBg, cardSkeletonBg, currencyValue, searchPlaceholderText, collectionFilterProp, customRPCUrl, videoAttributes, onConnectWallet, onRefetchBalance, onClickDisconnectWallet, onClickCard, onViewItem, onClickCustomRedirection, backToMarketPlace, onHandleApiSessionExpired, }: CollectionPageProps) => React.JSX.Element;
export default CollectionPage;
