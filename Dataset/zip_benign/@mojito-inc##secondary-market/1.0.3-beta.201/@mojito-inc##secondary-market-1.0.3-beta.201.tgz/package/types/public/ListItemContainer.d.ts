import * as React from 'react';
import { ListItemProps } from '../interface';
declare const ListItemContainer: ({ open, image, config, tokenDetails, isRemoveListing, tokenDetailsData, walletDetails, priceInputRange, customRPCUrl, mediaCardAttributes, onCloseModal, onClickViewItem, onClickBackToMarketPlace, onConnectWallet, onRefetchBalance, onHandleApiSessionExpired, }: ListItemProps) => React.JSX.Element;
export default ListItemContainer;
