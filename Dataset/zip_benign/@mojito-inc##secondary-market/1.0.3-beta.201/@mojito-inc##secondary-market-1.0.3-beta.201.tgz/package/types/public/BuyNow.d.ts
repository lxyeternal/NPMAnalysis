import * as React from 'react';
import { BuyNowProps } from '../interface';
declare const BuyNowContainer: ({ open, image, config, tokenDetails, tokenDetailsData, walletDetails, termsURL, conditionOfBusinessURL, mediaCardAttributes, onClickViewItem, onCloseModal, onClickBackToMarketPlace, onClickConnectWallet, onClickDisconnectWallet, onRefetchBalance, onHandleApiSessionExpired, }: BuyNowProps) => React.JSX.Element;
export default BuyNowContainer;
