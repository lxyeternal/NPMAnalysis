import * as React from 'react';
import { ProductDetailPageProps } from '../interface';
declare const ProductDetailPage: ({ config, tokenDetails, Image, walletDetails, priceInputRange, showSpecialTraits, videoAttributes, mediaCardAttributes, onConnectWallet, onClickDisconnectWallet, onRefetchBalance, onViewItem, onBackToMarketplace, onHandleApiSessionExpired, }: ProductDetailPageProps) => React.JSX.Element;
export default ProductDetailPage;
