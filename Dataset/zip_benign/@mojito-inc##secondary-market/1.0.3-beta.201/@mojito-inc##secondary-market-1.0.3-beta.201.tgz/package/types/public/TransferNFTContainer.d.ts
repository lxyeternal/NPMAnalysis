import * as React from 'react';
import { TransferNFTPageProps } from '../interface';
declare const TransferNFTContainer: ({ open, tokenDetails, walletDetails, configChainId, networksData, mediaCardAttributes, onCloseTransferNFTModal, onOpenSuccessModal, onOpenLoadingModal, }: TransferNFTPageProps) => React.JSX.Element;
export default TransferNFTContainer;
