import * as React from 'react';
import { WalletsPageProps } from '../interface';
declare const WalletsPage: ({ content, config, walletDetails, Image, showMenu, hideWalletBalance, listingType, priceInputRange, tabConfig, showInvoice, showViewItem, showRefresh, refreshCache, showSearch, showSort, menusToDisplay, filterByStatus, walletMediaConfig, isFullAddress, customRPCUrl, tabIndex, walletSecondaryButtonLabel, topUpUrl, onClickSecondaryButtonWallet, onClickCustomRedirection, onClickLogout, onConnectWallet, onViewItem, onClickCard, setTabIndex, handleRefetchBalance, onHandleApiSessionExpired, }: WalletsPageProps) => React.JSX.Element;
export default WalletsPage;
