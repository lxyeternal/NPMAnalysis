import { ChangeEvent, MouseEvent, ReactElement } from 'react';
import { CurrencyCodeFiat, InvoiceFilterInputData } from '@mojito-inc/core-service';
import { SelectChangeEvent } from '@mui/material/Select';
import { ExclusiveEventHintOrCaptureContext } from '@sentry/core/build/types/utils/prepareEvent';
import { TokenDetailsData } from '../hooks/useTokenDetails';
import { BannerProps, TokenCardProps } from '../component';
import { CollectionDataProps } from '../hooks/useCollections';
import { OptionsProps } from '../component/SortContainer';
import { BreadcrumbItem } from '../component/BreadCrumbsComponent';
import { ListingType } from '../constant';
import { InvoiceType } from '../hooks/useWallet';
import { VideoAttributes } from '../component/CustomVideoPlayer';
export interface FeeData {
    title: string;
    usdPrice: string;
    cryptoPrice: string;
}
export interface ImageProps {
    logo: string;
    loader: string;
    maticIcon?: string;
    nativeCurrencyIcon?: string;
    nonNativeCurrencyIcon?: string;
    placeHolderImage?: string;
    refetchIcon?: string;
}
export declare enum ToastTypeProps {
    ERROR = "error",
    SUCCESS = "success",
    WARNING = "warning",
    SUCCESS_WITHOUT_ICON = "success without icon",
    WARNING_WITHOUT_ICON = "warning without icon"
}
export declare enum Currency {
    EUR = "EUR",
    USD = "USD"
}
export declare enum CryptoCurrency {
    ETH = "ETH",
    MATIC = "MATIC",
    WETH = "WETH",
    WMATIC = "WMATIC",
    AR = "AR",
    BTC = "BTC",
    USDC = "USDC",
    USDT = "USDT",
    SOL = "SOL",
    VIN = "VIN"
}
export type WalletType = 'ethereum' | 'solana';
export interface ProgressProps {
    loading: boolean;
    success: boolean;
}
export interface SupportedNetworksData {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
export interface WalletProps {
    walletAddress: string;
    networkDetails: SupportedNetworksData;
    providerType: string;
    balance: {
        native: number;
        nonNative: number;
    };
    provider: any;
    open: boolean;
    disConnect: boolean;
    refetchBalance: boolean;
    walletType: WalletType;
}
export interface ListItemLayoutProps {
    open: boolean;
    image: ImageProps;
    tokenDetails: {
        tokenImage: string;
        tokenName: string;
        tokenArtistName: string;
        thumbnail?: string;
    };
    breadCrumbs: BreadcrumbItem[];
    selectedBreadCrumbs: string;
    serviceFee: FeeData;
    creatorFee: FeeData;
    totalPrice: FeeData;
    listingPrice: FeeData;
    currencyData: string;
    price: string;
    error: string;
    isEdit: boolean;
    progress: ProgressProps;
    contractProgressMessage?: string;
    selectCurrency?: string;
    currencyList: {
        label: string;
        value: string;
    }[];
    isRemoveListing: boolean;
    switchNetwork: string;
    isValidListItem: string;
    isLoading: boolean;
    walletConnection: string;
    maxLength?: number;
    isEthereumWallet?: boolean;
    walletType?: WalletType;
    mediaCardAttributes?: VideoAttributes;
    onChangePrice: (event: ChangeEvent<HTMLInputElement>) => void;
    onChangeCurrency?: (event: SelectChangeEvent) => void;
    onClickListItem: (value: string) => void;
    onClickSwitchNetwork: () => void;
    onCloseModal: () => void;
    onClickConnectWallet: () => void;
}
export interface ListItemProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    isRemoveListing: boolean;
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    priceInputRange?: number;
    customRPCUrl?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onClickBackToMarketPlace: () => void;
    onConnectWallet: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
export declare enum TokenStatus {
    NEW = "NEW",
    ENQUIRY_PENDING = "ENQUIRY_PENDING",
    OPEN_FOR_SALE = "OPEN_FOR_SALE",
    SALE_PENDING = "SALE_PENDING",
    STALE_OWNERSHIP = "STALE_OWNERSHIP"
}
export declare enum TaxEstimateType {
    LIST_FOR_SALE = "ListForSale",
    BUY_NOW = "BuyNow",
    MAKE_OFFER = "MakeOffer",
    ACCEPT_OFFER = "AcceptOffer"
}
export interface TokenPriceProps {
    value: number;
    unit: string;
    type: string;
}
export interface WalletDetailsData {
    walletAddress: string;
    networkDetails: SupportedNetworksData;
    providerType: string;
    balance: {
        native: number;
        nonNative: number;
    };
    provider: any;
}
export declare enum CryptoCurrencyCode {
    ETH = "ETH",
    MATIC = "MATIC",
    WETH = "WETH",
    WMATIC = "WMATIC"
}
export declare enum ProviderType {
    METAMASK = "Metamask",
    WALLET_CONNECT = "WalletConnect",
    EMAIL = "Email"
}
export interface ToastStatusProps {
    message: string;
    status: ToastTypeProps;
}
export declare enum OfferStatus {
    PENDING = "PENDING",
    CANCELLED = "CANCELLED",
    REJECTED = "REJECTED",
    FAILED = "FAILED",
    COMPLETED = "COMPLETED",
    EXPIRED = "EXPIRED",
    REMOVED = "REMOVED",
    PROCESSING = "PROCESSING"
}
export interface AcceptAndRejectOfferLayoutProps {
    open: boolean;
    image: ImageProps;
    tokenDetails: {
        tokenImage: string;
        tokenName: string;
        tokenArtistName: string;
        thumbnail?: string;
    };
    breadCrumbs: BreadcrumbItem[];
    selectedBreadCrumbs: string;
    listPricePercentage: string;
    contractProgressMessage?: string;
    price: {
        usd: number;
        totalPrice: string;
    };
    error: string;
    progress: ProgressProps;
    isValidOffer: boolean;
    isRejectOffer: boolean;
    switchNetwork: string;
    walletConnection: string;
    isLoading: boolean;
    isPDP?: boolean;
    fiatCurrency?: Currency;
    walletType?: WalletType;
    creatorFee: FeeData;
    serviceFee: FeeData;
    totalOffer: FeeData;
    mediaCardAttributes?: VideoAttributes;
    onClickAcceptOrRejectOffer: (value: string) => void;
    onClickSwitchNetwork: () => void;
    onCloseModal: () => void;
    onClickConnectWallet: () => void;
}
export interface AcceptAndRejectOfferProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    isRejectOffer: boolean;
    orderId: string;
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    isPDP?: boolean;
    customRPCUrl?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onConnectWallet: () => void;
    onClickBackToMarketPlace?: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
export interface ValidateTermsProps {
    terms: boolean;
    conditions: boolean;
}
export interface ValidateMakeOfferProps {
    networkCheck: boolean;
    balanceCheck: boolean;
    isSwap: boolean;
    message: string;
}
export interface MakeOfferLayoutProps {
    open: boolean;
    image: ImageProps;
    tokenDetails: {
        tokenImage: string;
        tokenName: string;
        tokenArtistName: string;
        thumbnail?: string;
        chainId: number;
    };
    error: string;
    progress: ProgressProps;
    breadCrumbs: BreadcrumbItem[];
    selectedBreadCrumbs: string;
    currencyData: string;
    price: string;
    durationList: {
        label: string;
        value: string;
    }[];
    duration: string;
    listPricePercentage: string;
    contractProgressMessage?: string;
    totalPrice: {
        usd: number;
        crypto: string;
    };
    buyNowPrice?: TokenPriceProps[];
    termsCheck: boolean;
    policyCheck: boolean;
    offerExpires: string;
    validateTerms: ValidateTermsProps;
    validateMakeOffer: ValidateMakeOfferProps;
    symbol: string;
    currencyList: {
        label: string;
        value: string;
    }[];
    isCancelOffer: boolean;
    isValidMakeOffer: string;
    walletConnection: string;
    isLoading: boolean;
    termsURL: string;
    conditionOfBusinessURL: string;
    maxLength?: number;
    fiatCurrency?: Currency;
    mediaCardAttributes?: VideoAttributes;
    onChangeTermsAndCondition: (e: ChangeEvent<HTMLInputElement>) => void;
    onChangePolicy: (e: ChangeEvent<HTMLInputElement>) => void;
    onChangeDuration: (event: SelectChangeEvent) => void;
    onChangePrice: (event: ChangeEvent<HTMLInputElement>) => void;
    onClickMakeOffer: (event: string) => void;
    onClickSwap: (event: string) => void;
    onClickSwitchNetwork: () => void;
    onCloseModal: () => void;
    onClickConnectWallet: () => void;
    walletType?: WalletType;
}
export interface MakeOfferProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    isCancelOffer: boolean;
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    priceInputRange?: number;
    termsURL?: string;
    conditionOfBusinessURL?: string;
    customRPCUrl?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onClickBackToMarketPlace?: () => void;
    onConnectWallet: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
export interface ValidateBuyNowProps {
    networkCheck: boolean;
    balanceCheck: boolean;
    isSwap: boolean;
    message: string;
    isWalletConnected: boolean;
}
export interface BuyNowFeeData {
    usdPrice: number;
    percentage: any;
    cryptoPrice: number;
}
export interface BuyNowLayoutProps {
    open: boolean;
    image: ImageProps;
    tokenDetails: {
        tokenImage: string;
        tokenName: string;
        tokenArtistName: string;
        thumbnail?: string;
        chainId: number;
    };
    breadCrumbs: BreadcrumbItem[];
    selectedBreadCrumbs: string;
    currencyData: string;
    price: string;
    usdPrice: string;
    error: string;
    progress: ProgressProps;
    selectCurrency: string;
    copied: string;
    walletAddress: string;
    balance: string;
    validateBuyNow: ValidateBuyNowProps;
    validateTerms: boolean;
    termsCheck: boolean;
    orderDetails: {
        referenceNumber: string;
        transactionHash: string;
        price: string;
    };
    currencyList: {
        label: string;
        value: string;
    }[];
    detailsLoading: boolean;
    symbol: string;
    isValidBuyNow: string;
    termsURL: string;
    conditionOfBusinessURL: string;
    walletType?: WalletType;
    contractProgressMessage?: string;
    mediaCardAttributes?: VideoAttributes;
    onClickViewOnEtherScan: () => void;
    onChangeTermsAndCondition: (e: ChangeEvent<HTMLInputElement>) => void;
    onChangeCurrency?: (event: SelectChangeEvent) => void;
    onClickCopyReference: () => void;
    onClickCopyHash: () => void;
    onClickCopyWalletAddress: () => void;
    onClickDisconnectWallet: () => void;
    onClickConnectWallet: () => void;
    onClickSwap: (event: string) => void;
    onClickSwitchNetwork: () => void;
    onClickBuyNow: (value: string) => void;
    onCloseModal: () => void;
}
export interface BuyNowProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
        customRPCUrl?: string;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    termsURL?: string;
    conditionOfBusinessURL?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onClickConnectWallet: () => void;
    onClickDisconnectWallet: () => void;
    onClickBackToMarketPlace?: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
export interface OfferData {
    id: string;
    expiryDate: string;
    offerStatus: string;
    buyerAddress: string;
    price: TokenPriceProps[];
    userName: string;
    ownerWalletAddress: string;
}
export interface ProvenanceProps {
    eventType: any;
    price: string;
    from: string;
    to: string;
    blockTimestamp: string;
    hash: string | null;
}
export interface TraitsData {
    title: string;
    description: string;
    percent: string;
}
export interface ProductDetailPageLayoutProps {
    tokenData: {
        url: string;
        collectionName: string;
        tokenName: string;
        owner: string;
        cryptoPrice: string;
        usdPrice: string;
        networkName: string;
        tokenType: string;
        contractAddress: string;
        tokenId: string;
        chainId: number;
        metaDataURL: string;
        description: string;
        edition?: number;
        thumbnail?: string;
    };
    traitsList: TraitsData[];
    button: {
        isBuyNow: boolean;
        isListItem: boolean;
        isEditListing: boolean;
        isMakeOffer: boolean;
    };
    offerList: OfferData[];
    walletAddress: string;
    provenanceData: ProvenanceProps[];
    loaderImage: string;
    isFavorite: boolean;
    showFavorite?: boolean;
    isLoading: boolean;
    favoriteLoading: boolean;
    error?: string;
    walletType: WalletType;
    fiatCurrency?: Currency;
    isError: boolean;
    onClickAcceptOffer: (event: OfferData) => void;
    onClickRejectOffer: (event: OfferData) => void;
    onClickCancelOffer: (event: string) => void;
    onClickPrimary: (event: 'Buy Now' | 'List Item' | 'Edit Listing' | '') => void;
    onClickSecondary: (event: 'Make Offer' | 'Remove Listing' | 'Cancel Offer' | '', isCancelOffer: string) => void;
    onClickFavorite: () => void;
    totalProvenanceData: number;
    provenanceOffset: number;
    onHandleProvenancePagination: (page: number) => void;
    offersOffset: number;
    onHandleOffersPagination: (page: number) => void;
    totalOffers: number;
    totalOffersPage: number;
    provenanceLoading: boolean;
    placeHolderImage?: string;
    videoAttributes?: VideoAttributes;
}
export interface ProductDetailPageProps {
    config: {
        orgId: string;
        fiatCurrency?: Currency;
        cryptoCurrency?: CryptoCurrency;
        showFavorite?: boolean;
        termsURL?: string;
        conditionOfBusinessURL?: string;
        customRPCUrl?: string;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
    };
    Image: ImageProps;
    walletDetails: WalletProps;
    priceInputRange?: number;
    showSpecialTraits?: boolean;
    videoAttributes?: VideoAttributes;
    mediaCardAttributes?: VideoAttributes;
    onConnectWallet: () => void;
    onClickDisconnectWallet: () => void;
    onRefetchBalance: () => void;
    onViewItem?: () => void;
    onBackToMarketplace?: () => void;
    onHandleApiSessionExpired?: () => void;
}
interface filterOption {
    label: string;
    value: string;
}
export interface TokenProps {
    id?: string;
    tokenId?: number | string;
    contractAddress?: string;
    networkId?: string;
}
export interface TraitsOptionProp {
    title: string;
    count?: number;
    value: string;
}
export interface AttributeFilterDataProp {
    title: string;
    values: TraitsOptionProp[];
    type: string;
}
export interface TokensListLayoutProps {
    tokensData: CollectionDataProps[] | null;
    tokensFilterValue: string;
    tokensFilterOptions: filterOption[];
    collectionsLoading?: boolean;
    search: string;
    showFilter?: boolean;
    showAttributeFilters?: boolean;
    traitsData?: AttributeFilterDataProp[];
    cardLoaderBg?: string;
    cardSkeletonBg?: string;
    placeHolderImage?: string;
    videoAttributes?: VideoAttributes;
    onChangeSearch: (search: ChangeEvent<HTMLInputElement>) => void;
    onChangeFilter: (event: SelectChangeEvent) => void;
    onClickTokenButton: (item: CollectionDataProps) => void;
    onClickCard?: (item: TokenProps) => void;
    setShowFilter: (showFilter: boolean) => void;
    onChangeCollectionFilter: (event: string) => void;
    searchPlaceholderText?: string;
    showFilterLoader?: boolean;
}
export interface CollectionPageProps {
    walletDetails: WalletProps;
    marketplaceID: string;
    Image: ImageProps;
    config: {
        orgId: string;
        termsURL?: string;
        conditionOfBusinessURL?: string;
    };
    searchPlaceholderText?: string;
    primaryBannerDetails?: BannerProps;
    secondaryBannerDetails?: BannerProps;
    priceInputRange?: number;
    showAttributeFilters?: boolean;
    walletType?: WalletType;
    customRPCUrl?: string;
    videoAttributes?: VideoAttributes;
    onConnectWallet: () => void;
    onRefetchBalance: () => void;
    onClickDisconnectWallet: () => void;
    onClickCard: (params?: TokenProps) => void;
    onClickCustomRedirection?: (params?: TokenProps) => void;
    onViewItem?: (params?: TokenProps) => void;
    backToMarketPlace?: (params?: TokenProps) => void;
    cardLoaderBg?: string;
    cardSkeletonBg?: string;
    currencyValue?: 'USD' | 'EUR';
    collectionFilterProp?: string;
    onHandleApiSessionExpired?: () => void;
}
export interface InvoiceConfigParams {
    invoiceID: string;
    orderID: string;
    activityName: string;
    invoiceResType: string;
    isSecondary?: boolean;
}
export interface WalletConfigProps {
    orgId: string;
    chainId: number;
    contractAddress?: string;
    currency?: CurrencyCodeFiat;
    cryptoCurrency?: CryptoCurrency;
    itemFilter?: InvoiceFilterInputData;
    invoiceType?: InvoiceType;
    returnAllStatuses?: boolean;
    enableCardVideo?: boolean;
}
export type WalletMediaConfig = {
    mediaOnly?: boolean;
    enableCardVideo?: boolean;
    lineClamp?: number;
    videoAttributes?: VideoAttributes;
};
export interface WalletsPageProps {
    isFullAddress?: boolean;
    walletDetails: WalletProps;
    config: WalletConfigProps;
    Image: ImageProps;
    walletMediaConfig?: WalletMediaConfig;
    listingType?: ListingType;
    showMenu?: boolean;
    menusToDisplay?: string[];
    hideWalletBalance?: boolean;
    priceInputRange?: number;
    tabConfig?: {
        tabLabel?: string;
        showTab?: boolean;
    }[];
    showInvoice?: boolean;
    showViewItem?: boolean;
    showSearch?: boolean;
    showSort?: boolean;
    refreshCache?: boolean;
    showRefresh?: boolean;
    content?: {
        noDataContent?: string;
        disconnectText?: string;
        copyAddressText?: string;
        activityCardFreeClaimText?: string;
    };
    filterByStatus?: string[];
    currencyValue?: 'USD' | 'EUR';
    customRPCUrl?: string;
    walletSecondaryButtonLabel?: string;
    onClickSecondaryButtonWallet?: (item: TokenProps) => void;
    onClickLogout: () => void;
    onConnectWallet: () => void;
    onViewItem?: (params?: TokenProps) => void;
    onClickCustomRedirection?: (params?: TokenProps) => void;
    onClickCard?: (params?: TokenProps) => void;
    tabIndex?: number | null;
    setTabIndex?: (value: number) => void;
    handleRefetchBalance?: () => void;
    onHandleApiSessionExpired?: () => void;
    topUpUrl?: string;
}
export interface WalletsLabelDataProps {
    listingType?: ListingType;
    noDataMessage?: string;
    copied: string;
    walletMediaConfig?: WalletMediaConfig;
    showMenu: boolean;
    offset: number;
    activeWalletData: TokenCardProps[];
    sortWalletLabel: OptionsProps[];
    open: boolean;
    selectedValue: OptionsProps;
    walletAddress: string;
    search: string;
    totalActiveWallets: number;
    activeWalletsLoading: boolean;
    showSearch?: boolean;
    showSort?: boolean;
    showRefresh?: boolean;
    anchorEl?: HTMLElement | null;
    refetchIcon?: string;
    placeholderImage?: string;
    currency?: Currency;
    secondaryButtonLabel?: string;
    isRefetchingWallets?: boolean;
    onClickSecondaryButton?: (item: TokenProps) => void;
    handleMenuOpen?: (event: MouseEvent<HTMLElement>, item: TokenCardProps) => void;
    handleMenuClose?: () => void;
    handlePagination: (page: number) => void;
    handleSearchText: (search: ChangeEvent<HTMLInputElement>) => void;
    onClickToken: (item: TokenCardProps) => void;
    onClickCard?: (item: TokenProps) => void;
    onConnectWallet: () => void;
    handleToastClose: () => void;
    handleClickListItem: (event: MouseEvent<HTMLElement>) => void;
    handleApply: () => void;
    handleMenuItemClick: (option: OptionsProps) => void;
    handleClose: () => void;
    onClickRefreshCache: () => void;
}
export interface WalletsAccountLayoutProps {
    walletBalance: {
        native: number;
        nonNative: number;
    };
    walletAddress: string;
    walletType: WalletType;
    hideWalletBalance?: boolean;
    currency: {
        currencyName: string;
        currencyIcon: string | undefined;
    };
    nonNativeCurrency: {
        currencyName: string;
        currencyIcon: string | undefined;
    };
    copied: string;
    isMobile: boolean;
    networkName?: string;
    disconnectText?: string;
    isFullAddress?: boolean;
    copyAddressText?: string;
    onClickLogout: () => void;
    onConnectWallet: () => void;
    onClickCopy: (data: string) => void;
    onClickTopUp: () => void;
    handleRefetchBalance?: () => void;
    refreshIcon?: string;
}
export interface TransferNFTProps {
    open: boolean;
    copied: string;
    error: string;
    walletDetails: WalletProps;
    transferWalletAddress: string;
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
        tokenImage: string;
        tokenName: string;
        thumbnail?: string;
        placeHolderImage?: string;
        tokenSubTitle: string;
    };
    maxLength: number;
    confirmTransfer: boolean;
    mediaCardAttributes?: VideoAttributes;
    onClickCopy: (data: string) => void;
    handlePaste: () => void;
    onCloseModal: () => void;
    onChangeWalletAddress: (event: ChangeEvent<HTMLInputElement>) => void;
    onTransferNFT: () => void;
    onConfirmTransferNFT: () => void;
    onEditWalletAddress: () => void;
}
export interface TransferNFTPageProps {
    open: boolean;
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
        placeHolderImage?: string;
        tokenImage: string;
        tokenName: string;
        tokenSubTitle: string;
        tokenType: string;
        tokenOwnerAddress: string;
        thumbnail?: string;
    };
    mediaCardAttributes?: VideoAttributes;
    walletDetails: WalletProps;
    networksData?: SupportedNetworksData[] | null | undefined;
    configChainId?: number;
    onCloseTransferNFTModal: () => void;
    onOpenSuccessModal: (txHash: string) => void;
    onOpenLoadingModal: (txHash: string) => void;
}
export interface TransferNFTSuccessProps {
    open: boolean;
    headerTitle?: string;
    modalMessage: string;
    modalIcon: ReactElement | undefined;
    buttonName?: string;
    buttonAction?: () => void;
    handleCloseSuccessModal: () => void;
    handleClickViewTransfer: () => void;
}
export interface AttributeFilterComponentProps {
    filtersData: AttributeFilterDataProp[];
    showFilter: boolean;
    onClearFilter: (event: any) => void;
}
export type SentryExtraLogDataProp = {
    key?: string;
    value?: unknown;
};
export type SentryCaptureExceptionProp = {
    exception?: unknown;
    hint?: ExclusiveEventHintOrCaptureContext;
};
export type HandleSentryFunctionProp = (extraLogData?: SentryExtraLogDataProp, exceptionLogData?: SentryCaptureExceptionProp) => void;
export {};
