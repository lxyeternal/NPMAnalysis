export declare const RPC_URL: {
    1: string;
    5: string;
    80001: string;
    137: string;
};
export declare enum ErrorsType {
    USER_REJECTED = "rejected",
    USER_DENIED = "denied",
    INSUFFICIENT_FUNDS = "insufficient funds",
    SIGNER_ERROR = "requires a signer"
}
export declare const SessionVariable: {
    NetworkDetails: string;
    WalletDetails: string;
    AuthToken: string;
    CollectionFilter: string;
    Provider: string;
    WalletSort: string;
};
export declare enum TabType {
    DETAILS = "DETAILS",
    OFFERS = "OFFERS"
}
export declare enum ButtonType {
    LIST_ITEM = "LIST_ITEM",
    EDIT_LIST_ITEM = "EDIT_LIST_ITEM",
    MAKE_OFFER = "MAKE_OFFER",
    BUY_NOW = "BUY_NOW",
    ENQUIRE = "ENQUIRE",
    CANCEL = "OFFER",
    VIEW_DETAILS = "VIEW_DETAILS"
}
export declare const ModalMessage: {
    TRANSFER_INPROGRESS: string;
    TRANSFER_SUCCESS: string;
    DOWNLOAD_SUCCESS: string;
    DOWNLOAD_INPROGRESS: string;
};
export declare enum ListingType {
    SALE = "sale",
    CLAIMABLE = "claimable"
}
export declare enum ProvenanceEventType {
    LIST = "List",
    SALE = "Sale",
    OFFER_REJECTED = "Offer_Rejected",
    OFFER_CANCELLED = "Offer_Cancelled",
    OFFER = "Offer",
    MINTED = "Minted",
    TRANSFER = "Transfer",
    LIST_REMOVED = "List_Removed",
    OFFER_SOLD = "Offer_Sold",
    EXPIRED = "Expired"
}
