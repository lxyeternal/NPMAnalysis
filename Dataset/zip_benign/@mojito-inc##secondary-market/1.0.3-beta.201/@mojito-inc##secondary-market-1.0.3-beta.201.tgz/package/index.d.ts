import * as React from 'react';
import { CSSProperties } from 'react';
import { CurrencyCodeFiat, InvoiceFilterInputData } from '@mojito-inc/core-service';
import { SxProps, Theme } from '@mui/material/styles';
import { BrowserOptions } from '@sentry/react';
import { ExclusiveEventHintOrCaptureContext } from '@sentry/core/build/types/utils/prepareEvent';

type VideoAttributes = {
    width?: string;
    height?: string;
    controls?: boolean;
    muted?: boolean;
    loop?: boolean;
    playsInline?: boolean;
    autoPlay?: boolean;
    cloudinaryUrl?: string;
    playBtnEnabled?: boolean;
    customThumbnail?: string;
    thumbnailFrame?: 'first' | 'last' | 'custom' | 'thumbnail-only';
    optionalFrame?: 'first' | 'last';
};

interface VideoWithImageCardProps {
    url?: string;
    width?: string;
    height?: string;
    style?: CSSProperties;
    placeholderImage?: string;
    videoAttributes?: VideoAttributes;
}
declare const _default: React.NamedExoticComponent<VideoWithImageCardProps>;

interface Artist {
    id: string;
    description: string;
    artistName: string;
    artistLocation: string;
    artistContactEmail: string;
    artistContactNumber: string;
    artistWebsite: string;
    slug?: string;
}
interface MetadataAttributes {
    traitType: string;
    value: {
        intValue?: number;
        floatValue?: number;
        stringValue?: string;
        boolValue?: string;
        __typename?: string;
    };
    displayType: string;
    maxValue: number;
    prevalance?: number;
}
interface MetaData {
    name: string;
    description: string;
    image: string;
    attributes: MetadataAttributes[];
    externalURL: string;
    backgroundColor: string;
    animationURL: string;
    timestamp: number;
    language: string;
    openSeaImageURL?: string;
    tags: string[];
    yearCreated: string;
    createdBy: string;
}
interface TokenDetailsData {
    contractAddress: string;
    tokenId: number;
    network: string;
    owner: string;
    contractName: string;
    tokenType: string;
    mintedAt: string;
    status: TokenStatus;
    metadata: MetaData;
    artist: Artist;
    isMakeOfferEnabled: boolean;
    isBuyNowEnabled: boolean;
    isOfferExist: boolean;
    mediaSourceExtension: string;
    mediaSourceType: string;
    mediaSourceURL: string;
    listedOrderInfo: {
        id: string;
        listedCurrency: {
            contractAddress: string;
        };
        price: TokenPriceProps[];
    };
    latestOffer: {
        price: TokenPriceProps[];
    };
    balance: number;
    price: {
        buyNowPrice: TokenPriceProps[];
        lastPurchasedPrice: TokenPriceProps[];
        makeOfferHighestPrice: TokenPriceProps[];
        makeOfferLatestPrice: TokenPriceProps[];
    };
    isFavorite: boolean;
    nftTokenId: string;
    tokenURI: string;
    networkID: string;
    tokenOwnerAvatar: string;
    tokenOwnerAddress: string;
    tokenOwnerUsername: string;
    editions: number;
    editionNumber: number;
}

interface BannerProps {
    title?: string;
    subtitle?: string;
    mediaURL?: string;
    buttonName?: string;
    titleStyle?: SxProps<Theme>;
    subtitleStyle?: SxProps<Theme>;
    buttonStyle?: SxProps<Theme>;
    onClickButton?: () => void;
}

declare enum ListingType {
    SALE = "sale",
    CLAIMABLE = "claimable"
}

type InvoiceType = 'ALL_INVOICES' | 'MY_INVOICES';

interface ImageProps {
    logo: string;
    loader: string;
    maticIcon?: string;
    nativeCurrencyIcon?: string;
    nonNativeCurrencyIcon?: string;
    placeHolderImage?: string;
    refetchIcon?: string;
}
declare enum Currency {
    EUR = "EUR",
    USD = "USD"
}
declare enum CryptoCurrency {
    ETH = "ETH",
    MATIC = "MATIC",
    WETH = "WETH",
    WMATIC = "WMATIC",
    AR = "AR",
    BTC = "BTC",
    USDC = "USDC",
    USDT = "USDT",
    SOL = "SOL",
    VIN = "VIN"
}
type WalletType = 'ethereum' | 'solana';
interface SupportedNetworksData {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
interface WalletProps {
    walletAddress: string;
    networkDetails: SupportedNetworksData;
    providerType: string;
    balance: {
        native: number;
        nonNative: number;
    };
    provider: any;
    open: boolean;
    disConnect: boolean;
    refetchBalance: boolean;
    walletType: WalletType;
}
interface ListItemProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    isRemoveListing: boolean;
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    priceInputRange?: number;
    customRPCUrl?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onClickBackToMarketPlace: () => void;
    onConnectWallet: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
declare enum TokenStatus {
    NEW = "NEW",
    ENQUIRY_PENDING = "ENQUIRY_PENDING",
    OPEN_FOR_SALE = "OPEN_FOR_SALE",
    SALE_PENDING = "SALE_PENDING",
    STALE_OWNERSHIP = "STALE_OWNERSHIP"
}
interface TokenPriceProps {
    value: number;
    unit: string;
    type: string;
}
interface AcceptAndRejectOfferProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    isRejectOffer: boolean;
    orderId: string;
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    isPDP?: boolean;
    customRPCUrl?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onConnectWallet: () => void;
    onClickBackToMarketPlace?: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
interface MakeOfferProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    isCancelOffer: boolean;
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    priceInputRange?: number;
    termsURL?: string;
    conditionOfBusinessURL?: string;
    customRPCUrl?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onClickBackToMarketPlace?: () => void;
    onConnectWallet: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
interface BuyNowProps {
    open: boolean;
    image: ImageProps;
    config: {
        orgId: string;
        currency?: Currency;
        customRPCUrl?: string;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
        itemId: string;
    };
    walletDetails: WalletProps;
    tokenDetailsData?: TokenDetailsData;
    termsURL?: string;
    conditionOfBusinessURL?: string;
    mediaCardAttributes?: VideoAttributes;
    onCloseModal: () => void;
    onClickViewItem: () => void;
    onClickConnectWallet: () => void;
    onClickDisconnectWallet: () => void;
    onClickBackToMarketPlace?: () => void;
    onRefetchBalance?: (event: boolean) => void;
    onHandleApiSessionExpired?: () => void;
}
interface ProductDetailPageProps {
    config: {
        orgId: string;
        fiatCurrency?: Currency;
        cryptoCurrency?: CryptoCurrency;
        showFavorite?: boolean;
        termsURL?: string;
        conditionOfBusinessURL?: string;
        customRPCUrl?: string;
    };
    tokenDetails: {
        onChainTokenID: string;
        contractAddress: string;
    };
    Image: ImageProps;
    walletDetails: WalletProps;
    priceInputRange?: number;
    showSpecialTraits?: boolean;
    videoAttributes?: VideoAttributes;
    mediaCardAttributes?: VideoAttributes;
    onConnectWallet: () => void;
    onClickDisconnectWallet: () => void;
    onRefetchBalance: () => void;
    onViewItem?: () => void;
    onBackToMarketplace?: () => void;
    onHandleApiSessionExpired?: () => void;
}
interface TokenProps {
    id?: string;
    tokenId?: number | string;
    contractAddress?: string;
    networkId?: string;
}
interface CollectionPageProps {
    walletDetails: WalletProps;
    marketplaceID: string;
    Image: ImageProps;
    config: {
        orgId: string;
        termsURL?: string;
        conditionOfBusinessURL?: string;
    };
    searchPlaceholderText?: string;
    primaryBannerDetails?: BannerProps;
    secondaryBannerDetails?: BannerProps;
    priceInputRange?: number;
    showAttributeFilters?: boolean;
    walletType?: WalletType;
    customRPCUrl?: string;
    videoAttributes?: VideoAttributes;
    onConnectWallet: () => void;
    onRefetchBalance: () => void;
    onClickDisconnectWallet: () => void;
    onClickCard: (params?: TokenProps) => void;
    onClickCustomRedirection?: (params?: TokenProps) => void;
    onViewItem?: (params?: TokenProps) => void;
    backToMarketPlace?: (params?: TokenProps) => void;
    cardLoaderBg?: string;
    cardSkeletonBg?: string;
    currencyValue?: 'USD' | 'EUR';
    collectionFilterProp?: string;
    onHandleApiSessionExpired?: () => void;
}
interface WalletConfigProps {
    orgId: string;
    chainId: number;
    contractAddress?: string;
    currency?: CurrencyCodeFiat;
    cryptoCurrency?: CryptoCurrency;
    itemFilter?: InvoiceFilterInputData;
    invoiceType?: InvoiceType;
    returnAllStatuses?: boolean;
    enableCardVideo?: boolean;
}
type WalletMediaConfig = {
    mediaOnly?: boolean;
    enableCardVideo?: boolean;
    lineClamp?: number;
    videoAttributes?: VideoAttributes;
};
interface WalletsPageProps {
    isFullAddress?: boolean;
    walletDetails: WalletProps;
    config: WalletConfigProps;
    Image: ImageProps;
    walletMediaConfig?: WalletMediaConfig;
    listingType?: ListingType;
    showMenu?: boolean;
    menusToDisplay?: string[];
    hideWalletBalance?: boolean;
    priceInputRange?: number;
    tabConfig?: {
        tabLabel?: string;
        showTab?: boolean;
    }[];
    showInvoice?: boolean;
    showViewItem?: boolean;
    showSearch?: boolean;
    showSort?: boolean;
    refreshCache?: boolean;
    showRefresh?: boolean;
    content?: {
        noDataContent?: string;
        disconnectText?: string;
        copyAddressText?: string;
        activityCardFreeClaimText?: string;
    };
    filterByStatus?: string[];
    currencyValue?: 'USD' | 'EUR';
    customRPCUrl?: string;
    walletSecondaryButtonLabel?: string;
    onClickSecondaryButtonWallet?: (item: TokenProps) => void;
    onClickLogout: () => void;
    onConnectWallet: () => void;
    onViewItem?: (params?: TokenProps) => void;
    onClickCustomRedirection?: (params?: TokenProps) => void;
    onClickCard?: (params?: TokenProps) => void;
    tabIndex?: number | null;
    setTabIndex?: (value: number) => void;
    handleRefetchBalance?: () => void;
    onHandleApiSessionExpired?: () => void;
    topUpUrl?: string;
}

declare const ListItemContainer: ({ open, image, config, tokenDetails, isRemoveListing, tokenDetailsData, walletDetails, priceInputRange, customRPCUrl, mediaCardAttributes, onCloseModal, onClickViewItem, onClickBackToMarketPlace, onConnectWallet, onRefetchBalance, onHandleApiSessionExpired, }: ListItemProps) => React.JSX.Element;

declare const AcceptAndRejectOffer: ({ open, image, config, tokenDetails, orderId, isRejectOffer, tokenDetailsData, walletDetails, isPDP, customRPCUrl, mediaCardAttributes, onClickViewItem, onCloseModal, onClickBackToMarketPlace, onConnectWallet, onRefetchBalance, onHandleApiSessionExpired, }: AcceptAndRejectOfferProps) => React.JSX.Element;

declare const MakeOfferContainer: ({ open, image, config, tokenDetails, tokenDetailsData, isCancelOffer, walletDetails, priceInputRange, termsURL, conditionOfBusinessURL, customRPCUrl, mediaCardAttributes, onClickViewItem, onCloseModal, onClickBackToMarketPlace, onRefetchBalance, onConnectWallet, onHandleApiSessionExpired, }: MakeOfferProps) => React.JSX.Element;

declare const BuyNowContainer: ({ open, image, config, tokenDetails, tokenDetailsData, walletDetails, termsURL, conditionOfBusinessURL, mediaCardAttributes, onClickViewItem, onCloseModal, onClickBackToMarketPlace, onClickConnectWallet, onClickDisconnectWallet, onRefetchBalance, onHandleApiSessionExpired, }: BuyNowProps) => React.JSX.Element;

declare const ProductDetailPage: ({ config, tokenDetails, Image, walletDetails, priceInputRange, showSpecialTraits, videoAttributes, mediaCardAttributes, onConnectWallet, onClickDisconnectWallet, onRefetchBalance, onViewItem, onBackToMarketplace, onHandleApiSessionExpired, }: ProductDetailPageProps) => React.JSX.Element;

interface ApolloClientOptions {
    uri?: string;
    token?: string;
}
interface SentryConfig {
    isEnableSentry?: boolean;
    config?: BrowserOptions;
}
interface SecondaryThemeProviderProps {
    children: JSX.Element | JSX.Element[];
    theme: Theme;
    clientOptions: ApolloClientOptions;
    sentryConfig?: SentryConfig;
}
declare const SecondaryMarketProvider: ({ children, theme, clientOptions, sentryConfig }: SecondaryThemeProviderProps) => React.JSX.Element;

declare const CollectionPage: ({ walletDetails, marketplaceID, Image, config, primaryBannerDetails, secondaryBannerDetails, priceInputRange, showAttributeFilters, walletType, cardLoaderBg, cardSkeletonBg, currencyValue, searchPlaceholderText, collectionFilterProp, customRPCUrl, videoAttributes, onConnectWallet, onRefetchBalance, onClickDisconnectWallet, onClickCard, onViewItem, onClickCustomRedirection, backToMarketPlace, onHandleApiSessionExpired, }: CollectionPageProps) => React.JSX.Element;

declare const WalletsPage: ({ content, config, walletDetails, Image, showMenu, hideWalletBalance, listingType, priceInputRange, tabConfig, showInvoice, showViewItem, showRefresh, refreshCache, showSearch, showSort, menusToDisplay, filterByStatus, walletMediaConfig, isFullAddress, customRPCUrl, tabIndex, walletSecondaryButtonLabel, topUpUrl, onClickSecondaryButtonWallet, onClickCustomRedirection, onClickLogout, onConnectWallet, onViewItem, onClickCard, setTabIndex, handleRefetchBalance, onHandleApiSessionExpired, }: WalletsPageProps) => React.JSX.Element;

interface SentryContextProp {
    addExtraLogsForSentry: (key: string, value: unknown) => void;
    addCaptureExceptionForSentry: (exception: unknown, hint?: ExclusiveEventHintOrCaptureContext) => void;
}
declare const useSentry: () => SentryContextProp;

export { AcceptAndRejectOffer, BuyNowContainer as BuyNow, CollectionPage, CryptoCurrency, Currency, ListItemContainer as ListItem, MakeOfferContainer as MakeOffer, ProductDetailPage, SecondaryMarketProvider, _default as VideoWithImageCard, VideoWithImageCardProps, WalletsPage, useSentry };
