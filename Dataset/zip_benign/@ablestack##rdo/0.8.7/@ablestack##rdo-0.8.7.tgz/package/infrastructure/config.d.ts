export declare function configKeyToCraEnvKey(key: string): string;
export declare function getConfigValue<TKey extends string = string, TVal = string | number | boolean>(key: TKey, defaultVal: TVal): TVal;
