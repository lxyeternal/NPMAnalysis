"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = exports.DefaultLogger = void 0;
const tslib_1 = require("tslib");
/* eslint-disable @typescript-eslint/interface-name-prefix */
const debug_1 = tslib_1.__importDefault(require("debug"));
const dotenv_1 = tslib_1.__importDefault(require("dotenv"));
const config_1 = require("./config");
dotenv_1.default.config();
class DefaultLogger {
    constructor(namespace) {
        this._logger = debug_1.default(`rdo.${namespace}`);
        DefaultLogger._appLogLevel = config_1.getConfigValue('RDO_LOG_LEVEL', 3);
    }
    log(logLevel, msg, ...logObjects) {
        if (DefaultLogger._appLogLevel >= logLevel) {
            if (logObjects)
                this._logger(msg, ...logObjects);
            else
                this._logger(msg);
        }
        else {
            // console.log(`Rdo. Level "${logLevel}" not at app log level "${DefaultLogger._appLogLevel}"`, msg, logLevel);
        }
    }
    error(msg, ...logObjects) {
        this.log(1, `ERROR!!!: ${msg}`, logObjects);
    }
    warn(msg, ...logObjects) {
        this.log(2, `WARN!: ${msg}`, logObjects);
    }
    info(msg, ...logObjects) {
        this.log(3, `Info: ${msg}`, logObjects);
    }
    debug(msg, ...logObjects) {
        this.log(4, `Debug: ${msg}`, logObjects);
    }
    trace(msg, ...logObjects) {
        this.log(5, `Trace: ${msg}`, logObjects);
    }
    static setGlobalLogLevel(logLevel) {
        DefaultLogger._appLogLevel = logLevel;
    }
}
exports.DefaultLogger = DefaultLogger;
let make = (namespace) => {
    return new DefaultLogger(namespace);
};
function setLoggerFactory(loggerFactory) {
    make = loggerFactory;
}
exports.Logger = { make, setLoggerFactory };
//# sourceMappingURL=logger.js.map