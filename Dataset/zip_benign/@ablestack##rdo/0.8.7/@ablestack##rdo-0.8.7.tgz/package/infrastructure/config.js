"use strict";
// Utility Methods
//
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfigValue = exports.configKeyToCraEnvKey = void 0;
function isNumber(val) {
    return val && val !== '' && !isNaN(parseInt(val));
}
function isBoolean(val) {
    return val === 'true' || val === 'false';
}
function parseBoolean(val) {
    return val === 'true';
}
function camelToSnakeUpperCase(str) {
    const _ = str.replace(/([A-Z])/g, `_$1`);
    return _.toUpperCase();
}
function configKeyToCraEnvKey(key) {
    // if already in .env cra format, just return
    if (key.startsWith('REACT_APP'))
        return key;
    // if already in uppercase, just add cra prefix
    if (!/[a-z]/.test(key))
        return `REACT_APP_${key}`;
    // else, convert from camel to upper
    return `REACT_APP_${camelToSnakeUpperCase(key)}`;
}
exports.configKeyToCraEnvKey = configKeyToCraEnvKey;
// Main
//
function getConfigValue(key, defaultVal) {
    let val = process.env[key];
    if (!val)
        val = process.env[configKeyToCraEnvKey(key)];
    if (!val)
        return defaultVal;
    if (typeof val !== 'string')
        return val;
    if (isNumber(val))
        return parseInt(val);
    if (isBoolean(val))
        return parseBoolean(val);
    return val;
}
exports.getConfigValue = getConfigValue;
//# sourceMappingURL=config.js.map