"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListMap = void 0;
const tslib_1 = require("tslib");
const mobx_1 = require("mobx");
const logger_1 = require("../infrastructure/logger");
const logger = logger_1.Logger.make('ListMap');
/**
 *
 *
 * @export
 * @class ListMap
 * @implements {ISyncableRDOKeyBasedCollection<S, D>}
 * @implements {Map<string | number, D>}
 * @template S
 * @template D
 * @description: A readonly, syncable, Map-Array collection hybrid, with a built in observable array (accessed via array$). Manages the internal array in parallel with the internal map so as to only trigger observable changes when necessary
 */
class ListMap {
    constructor({ makeCollectionKey, makeRdo, } = {}) {
        this.indexByKeyMap = new Map();
        this._array$ = null;
        this[Symbol.toStringTag] = 'ListMap';
        this.add = ({ key, newItem }) => {
            this._map$.set(key, newItem);
            this._array$ = null;
            return true;
        };
        this.replace = ({ key, origItem, newItem }) => {
            this._map$.set(key, newItem);
            this._array$ = null;
            return true;
        };
        this.delete = ({ key, origItem }) => {
            this._map$.delete(key);
            this._array$ = null;
            return true;
        };
        this._makeCollectionKey = makeCollectionKey;
        this._makeRdo = makeRdo;
        this._map$ = new Map();
    }
    get size() {
        return this._map$.size;
    }
    get array$() {
        if (!this._array$)
            this._array$ = Array.from(this._map$.values());
        return this._array$;
    }
    // -----------------------------------
    // Readonly Map Interface
    // -----------------------------------
    forEach(callbackfn, thisArg) {
        this._map$.forEach(callbackfn);
    }
    get(key) {
        return this._map$.get(key);
    }
    has(key) {
        return this._map$.has(key);
    }
    entries() {
        return this._map$.entries();
    }
    keys() {
        return this._map$.keys();
    }
    values() {
        return this._map$.values();
    }
    [Symbol.iterator]() {
        return this._map$.entries();
    }
    // -----------------------------------
    // ISyncableRdoCollection
    // -----------------------------------
    elements() {
        return this._map$.values();
    }
    //------------------------------
    // RdoSyncableCollectionNW
    //------------------------------
    tryMakeCollectionKey(item, index) {
        if (!this._makeCollectionKey)
            return undefined;
        return this._makeCollectionKey(item);
    }
    makeRdo(sourceItem) {
        if (!this._makeRdo)
            return undefined;
        return this._makeRdo(sourceItem);
    }
}
tslib_1.__decorate([
    mobx_1.observable.shallow,
    tslib_1.__metadata("design:type", Map)
], ListMap.prototype, "_map$", void 0);
tslib_1.__decorate([
    mobx_1.computed,
    tslib_1.__metadata("design:type", Number),
    tslib_1.__metadata("design:paramtypes", [])
], ListMap.prototype, "size", null);
tslib_1.__decorate([
    mobx_1.observable.shallow,
    tslib_1.__metadata("design:type", Object)
], ListMap.prototype, "_array$", void 0);
tslib_1.__decorate([
    mobx_1.computed,
    tslib_1.__metadata("design:type", Array),
    tslib_1.__metadata("design:paramtypes", [])
], ListMap.prototype, "array$", null);
exports.ListMap = ListMap;
//# sourceMappingURL=list-map.js.map