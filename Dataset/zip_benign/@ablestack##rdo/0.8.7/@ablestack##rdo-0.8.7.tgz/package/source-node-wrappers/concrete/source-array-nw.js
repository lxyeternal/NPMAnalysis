"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceArrayNW = void 0;
const __1 = require("../..");
const logger_1 = require("../../infrastructure/logger");
const types_1 = require("../../types");
const source_base_nw_1 = require("../base/source-base-nw");
const logger = logger_1.Logger.make('RdoMapNW');
class SourceArrayNW extends source_base_nw_1.SourceBaseNW {
    // /**
    //  *
    //  *
    //  * @readonly
    //  * @memberof SourceArrayNW
    //  * @description Returns map of element indexes by key. Note that if elements with duplicate keys are present in the source array, the first index with the corresponding key will be in the Map
    //  */
    // public get mapOfIndexByKey() {
    //   if (!this._mapOfIndexByKey) this.initializeMaps();
    //   return this._mapOfIndexByKey!;
    // }
    // private _mapOfIndexByKey: Map<number> | undefined;
    // /**
    //  *
    //  *
    //  * @readonly
    //  * @memberof SourceArrayNW
    //  * @description Returns map of elements by key. Note that if elements with duplicate keys are present in the source array, the first element with the corresponding key will be in the Map
    //  */
    // public get mapOfElementByKey() {
    //   if (!this._mapOfElementByKey) this.initializeMaps();
    //   return this._mapOfElementByKey!;
    // }
    // private _mapOfElementByKey: Map<string | number, S> | undefined;
    constructor({ value, sourceNodeTypePath, sourceNodeInstancePath, key, typeInfo, matchingNodeOptions, globalNodeOptions, }) {
        super({ sourceNodeTypePath, sourceNodeInstancePath, key, typeInfo, matchingNodeOptions, globalNodeOptions });
        //------------------------------
        // ISourceCollectionNodeWrapper
        //------------------------------
        this.makeCollectionKey = (item, index) => {
            var _a, _b, _c, _d;
            logger.trace(`makeCollectionKey`, { rdoNode: this.wrappedRdoNode, item, index });
            if (item === null || item === undefined)
                throw new Error(`Can not make collection key from null or undefined source object`);
            if ((_b = (_a = this.matchingNodeOptions) === null || _a === void 0 ? void 0 : _a.makeRdoCollectionKey) === null || _b === void 0 ? void 0 : _b.fromSourceElement) {
                const key = this.matchingNodeOptions.makeRdoCollectionKey.fromSourceElement(item);
                logger.trace(`made collection key from matchingNodeOptions (item, key)`, item, key);
                return key;
            }
            if (((_c = this.wrappedRdoNode) === null || _c === void 0 ? void 0 : _c.value) && types_1.isITryMakeCollectionKey((_d = this.wrappedRdoNode) === null || _d === void 0 ? void 0 : _d.value)) {
                const key = this.wrappedRdoNode.value.tryMakeCollectionKey(item, index);
                if (key !== undefined) {
                    logger.trace(`made collection key from isITryMakeCollectionKey (item, key)`, item, key);
                    return key;
                }
                else {
                    logger.trace(`isITryMakeCollectionKey:true, but tryMakeCollectionKey was undefined. Continuing`, item);
                }
            }
            // Look for idKey
            if (item[__1.config.defaultIdKey]) {
                const key = item[__1.config.defaultIdKey];
                logger.trace(`made collection key from idKey (item, key)`, __1.config.defaultIdKey, key);
                return key;
            }
            // If item is primitive, use that as key
            if (__1.NodeTypeUtils.isPrimitive(item)) {
                logger.trace(`made collection key from primitive (key)`, item);
                return item;
            }
            // If no key here, just use index
            logger.trace(`using index as collection key`, index);
            return index;
        };
        this._value = value.filter((element) => element !== null && element !== undefined);
    }
    // //------------------------------
    // // Private
    // //------------------------------
    // private initializeMaps() {
    //   this._mapOfElementByKey = new Map<string | number, S>();
    //   this._mapOfIndexByKey = new Map<number>();
    //   for (let i = 0; i < this.value.length; i++) {
    //     const newElementKey = this.makeCollectionKey(this.value[i], i);
    //     if (!this._mapOfElementByKey.has(newElementKey)) {
    //       this._mapOfElementByKey.set(newElementKey, this.value[i]);
    //       this._mapOfIndexByKey.set(newElementKey, i);
    //     }
    //   }
    // }
    //------------------------------
    // ISourceNodeWrapper
    //------------------------------
    get value() {
        return this._value;
    }
    childElementCount() {
        return this._value.length;
    }
    //------------------------------
    // ISourceInternalNodeWrapper
    //------------------------------
    getNode() {
        return this._value;
    }
    elements() {
        return this._value;
    }
}
exports.SourceArrayNW = SourceArrayNW;
//# sourceMappingURL=source-array-nw.js.map