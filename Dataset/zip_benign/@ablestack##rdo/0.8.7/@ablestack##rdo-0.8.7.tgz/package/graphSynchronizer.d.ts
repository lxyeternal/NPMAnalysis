import { IEqualityComparer, IGraphSynchronizer, IGraphSyncOptions, IRdoInternalNodeWrapper, IRdoNodeWrapper, ISyncChildNode, RdoNodeTypes } from '.';
import { SubscriptionFunction } from './infrastructure/event-emitter';
import { NodeChange } from './types/event-types';
/**
 *
 *
 * @export
 * @class GraphSynchronizer
 */
export declare class GraphSynchronizer implements IGraphSynchronizer {
    private _eventEmitter;
    private _globalNodeOptions;
    private _targetedOptionNodePathsMap;
    private _targetedOptionMatchersArray;
    private _mutableNodeCache;
    private _nodeTracker;
    private _sourceNodeWrapperFactory;
    private _rdoNodeWrapperFactory;
    readonly DefaultEqualityComparer: IEqualityComparer;
    constructor(options?: IGraphSyncOptions);
    /**
     *
     */
    smartSync<S extends Record<string, any>, D extends Record<string, any>>({ rootSourceNode, rootRdo }: {
        rootSourceNode: S;
        rootRdo: D;
    }): void;
    subscribeToNodeChanges(func: SubscriptionFunction<NodeChange>): void;
    unsubscribeToNodeChanges(func: SubscriptionFunction<NodeChange>): void;
    /**
     *
     */
    wrapRdoNode: <S, D>({ sourceNodeTypePath, sourceNodeInstancePath, sourceNode, sourceNodeItemKey, rdoNode, rdoNodeItemKey, wrappedParentRdoNode, }: {
        sourceNodeTypePath: string;
        sourceNodeInstancePath: string;
        rdoNode: RdoNodeTypes<S, D>;
        sourceNode: S;
        wrappedParentRdoNode?: IRdoInternalNodeWrapper<any, any> | undefined;
        rdoNodeItemKey?: string | number | undefined;
        sourceNodeItemKey?: string | number | undefined;
    }) => IRdoNodeWrapper<S, D>;
    /**
     *
     */
    syncChildNode: ISyncChildNode;
}
