"use strict";
//--------------------------------------------------------
// RDO - SYNC CUSTOMIZATION INTERFACES TYPES
//-------------------------------------------------------
Object.defineProperty(exports, "__esModule", { value: true });
exports.IsIAfterSmartSync = exports.IsIAfterSyncUpdate = exports.IsIBeforeSyncUpdate = exports.IsIBeforeSmartSync = exports.IsICustomEqualityRDO = exports.IsICustomSync = exports.IsIHasCustomRdoFieldNames = void 0;
function IsIHasCustomRdoFieldNames(o) {
    return o && o.tryGetRdoFieldname && typeof o.tryGetRdoFieldname === 'function';
}
exports.IsIHasCustomRdoFieldNames = IsIHasCustomRdoFieldNames;
function IsICustomSync(o) {
    return o && o.synchronizeState && typeof o.synchronizeState === 'function';
}
exports.IsICustomSync = IsICustomSync;
function IsICustomEqualityRDO(o) {
    return o && o.isStateEqual && typeof o.isStateEqual === 'function';
}
exports.IsICustomEqualityRDO = IsICustomEqualityRDO;
function IsIBeforeSmartSync(o) {
    return o && o.beforeSyncIfNeeded && typeof o.beforeSyncIfNeeded === 'function';
}
exports.IsIBeforeSmartSync = IsIBeforeSmartSync;
function IsIBeforeSyncUpdate(o) {
    return o && o.beforeSyncUpdate && typeof o.beforeSyncUpdate === 'function';
}
exports.IsIBeforeSyncUpdate = IsIBeforeSyncUpdate;
function IsIAfterSyncUpdate(o) {
    return o && o.afterSyncUpdate && typeof o.afterSyncUpdate === 'function';
}
exports.IsIAfterSyncUpdate = IsIAfterSyncUpdate;
function IsIAfterSmartSync(o) {
    return o && o.afterSyncIfNeeded && typeof o.afterSyncIfNeeded === 'function';
}
exports.IsIAfterSmartSync = IsIAfterSmartSync;
//# sourceMappingURL=rdo-customization-types.js.map