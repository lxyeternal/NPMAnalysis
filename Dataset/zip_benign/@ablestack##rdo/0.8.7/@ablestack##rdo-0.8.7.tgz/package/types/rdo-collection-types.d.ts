import { IMakeRdo, IRdoInternalNodeWrapper } from './internal-types';
export declare type MakeCollectionKeyMethod<T> = (item: T) => string | number;
export interface ITryMakeCollectionKey<T> {
    tryMakeCollectionKey: (item: T, index: number) => string | number | undefined;
}
export declare function isITryMakeCollectionKey(o: any): o is ITryMakeCollectionKey<any>;
export interface IMakeCollectionKey<T> {
    makeCollectionKey: (item: T, index: number) => string | number;
}
export declare function isIMakeCollectionKey(o: any): o is IMakeCollectionKey<any>;
export interface IMakeRdoElement<S, D> {
    makeRdoElement(sourceObject: S): D | undefined;
}
export declare function isIMakeRdoElement(o: any): o is IMakeRdoElement<any, any>;
export interface IRdoCollectionNodeWrapper<S, D> extends IRdoInternalNodeWrapper<S, D> {
    elements(): Iterable<D | undefined>;
}
export declare function isIRdoCollectionNodeWrapper(o: any): o is IRdoCollectionNodeWrapper<any, any>;
export interface IRdoKeyBasedCollectionNodeWrapper<S, D> extends IRdoInternalNodeWrapper<S, D> {
    onAdd: NodeAddHandler<S>;
    onReplace: NodeReplaceHandler<S>;
    onDelete: NodeDeleteHandler<S>;
}
export declare function isIRdoKeyBasedCollectionNodeWrapper(o: any): o is IRdoCollectionNodeWrapper<any, any>;
export interface ISyncableKeyBasedCollection<T> {
    readonly size: number;
    elements(): Iterable<T>;
    add({ index, key, newItem }: {
        index?: number;
        key: string | number;
        newItem: T;
    }): any;
    replace({ index, key, origItem, newItem }: {
        index?: number;
        key: string | number;
        origItem: any;
        newItem: T;
    }): any;
    delete({ index, key, origItem }: {
        index?: number;
        key: string | number;
        origItem: T;
    }): any;
}
export declare function IsISyncableCollection<T>(o: any): o is ISyncableKeyBasedCollection<T>;
export interface ISyncableRDOKeyBasedCollection<S, D> extends IMakeRdo<S, D>, ISyncableKeyBasedCollection<D>, ITryMakeCollectionKey<S> {
}
export declare function IsISyncableRDOCollection(o: any): o is ISyncableRDOKeyBasedCollection<any, any>;
export interface NodeAddHandler<T> {
    ({ index, key, newItem }: {
        index?: number;
        key: string | number;
        newItem: T;
    }): boolean;
}
export interface NodeReplaceHandler<T> {
    ({ index, key, origItem, newItem }: {
        index?: number;
        key: string | number;
        origItem: any;
        newItem: T;
    }): boolean;
}
export interface NodeDeleteHandler<T> {
    ({ index, key, origItem }: {
        index?: number;
        key: string | number;
        origItem: T;
    }): boolean;
}
