import { IGlobalNodeOptions, INodeSyncOptions, IRdoCollectionNodeWrapper, ISourceNodeWrapper, ISyncChildNode, NodeTypeInfo } from '../..';
import { EventEmitter } from '../../infrastructure/event-emitter';
import { MutableNodeCache } from '../../infrastructure/mutable-node-cache';
import { IEqualityComparer, IRdoInternalNodeWrapper, NodeReplaceHandler, NodeAddHandler, NodeDeleteHandler } from '../../types';
import { NodeChange } from '../../types/event-types';
import { RdoInternalNWBase } from './rdo-internal-nw-base';
export declare abstract class RdoCollectionNWBase<S, D> extends RdoInternalNWBase<S, D> implements IRdoCollectionNodeWrapper<S, D> {
    private _equalityComparer;
    constructor({ typeInfo, key, mutableNodeCache, wrappedParentRdoNode, wrappedSourceNode, defaultEqualityComparer, syncChildNode, matchingNodeOptions, globalNodeOptions, targetedOptionMatchersArray, eventEmitter, }: {
        typeInfo: NodeTypeInfo;
        key: string | number | undefined;
        mutableNodeCache: MutableNodeCache;
        wrappedParentRdoNode: IRdoInternalNodeWrapper<S, D> | undefined;
        wrappedSourceNode: ISourceNodeWrapper<S, D>;
        defaultEqualityComparer: IEqualityComparer;
        syncChildNode: ISyncChildNode;
        matchingNodeOptions: INodeSyncOptions<any, any> | undefined;
        globalNodeOptions: IGlobalNodeOptions | undefined;
        targetedOptionMatchersArray: Array<INodeSyncOptions<any, any>>;
        eventEmitter: EventEmitter<NodeChange>;
    });
    protected get equalityComparer(): IEqualityComparer;
    /** */
    protected handleAddElement({ index, collectionKey, newItem, newSourceElement, addHandler }: {
        addHandler: NodeAddHandler<D>;
        index: number;
        collectionKey: string | number;
        newItem: any;
        newSourceElement: S;
    }): boolean;
    /** */
    protected handleReplaceOrUpdate({ replaceHandler, index, collectionKey, lastElementKey, nextElementKey, origItem, newSourceElement, previousSourceElement, }: {
        replaceHandler: NodeReplaceHandler<D>;
        index: number;
        collectionKey: string | number;
        lastElementKey: string | number;
        nextElementKey: string | number;
        origItem: any;
        newSourceElement: S;
        previousSourceElement: S;
    }): {
        changed: boolean;
        newItem: any;
    };
    /** */
    protected handleDeleteElement({ deleteHandler, index, collectionKey, rdoToDelete, previousSourceElement }: {
        deleteHandler: NodeDeleteHandler<D>;
        index?: number;
        collectionKey: string | number;
        rdoToDelete: any;
        previousSourceElement: S;
    }): boolean;
    abstract elements(): Iterable<D>;
}
