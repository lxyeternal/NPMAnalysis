"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.comparerUtils = exports.comparers = void 0;
const tslib_1 = require("tslib");
const equality_1 = tslib_1.__importDefault(require("@wry/equality"));
function apolloComparer(a, b) {
    return equality_1.default(a, b);
}
function identityComparer(a, b) {
    return a === b;
}
// function structuralComparer(a: any, b: any): boolean {
//   // FUTURE
//   // return deepEqual(a, b);
//   return false;
// }
// function shallowComparer(a: any, b: any): boolean {
//   // FUTURE
//   //return deepEqual(a, b, 1);
//   return false;
// }
function referentialComparer(a, b) {
    return Object.is(a, b);
}
function _updateIfNotEqual(comparer, origVal, newVal, set) {
    if (comparer(origVal, newVal))
        return false;
    origVal = newVal;
    set(newVal);
    return true;
}
exports.comparers = {
    valueGraph: apolloComparer,
    identity: identityComparer,
    //structural: structuralComparer,
    referential: referentialComparer,
};
exports.comparerUtils = {
    valueGraph: {
        updateIfNotEqual: (origVal, newVal, set) => _updateIfNotEqual(exports.comparers.valueGraph, origVal, newVal, set),
    },
    identity: {
        updateIfNotEqual: (origVal, newVal, set) => _updateIfNotEqual(exports.comparers.identity, origVal, newVal, set),
    },
    //structural: structuralComparer,
    referential: {
        updateIfNotEqual: (origVal, newVal, set) => _updateIfNotEqual(exports.comparers.referential, origVal, newVal, set),
    }
    //shallow: shallowComparer,
};
//# sourceMappingURL=comparers.js.map