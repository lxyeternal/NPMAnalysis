export interface IEqualsComparer<T> {
    (a: T, b: T): boolean;
}
export interface IUpdateIfNotEqual<T> {
    (a: T, b: T, set: (T: any) => void): boolean;
}
declare function apolloComparer(a: any, b: any): boolean;
declare function identityComparer(a: any, b: any): boolean;
declare function referentialComparer(a: any, b: any): boolean;
export declare const comparers: {
    valueGraph: typeof apolloComparer;
    identity: typeof identityComparer;
    referential: typeof referentialComparer;
};
export declare const comparerUtils: {
    valueGraph: {
        updateIfNotEqual: <T>(origVal: T, newVal: T, set: (T: any) => void) => boolean;
    };
    identity: {
        updateIfNotEqual: <T_1>(origVal: T_1, newVal: T_1, set: (T: any) => void) => boolean;
    };
    referential: {
        updateIfNotEqual: <T_2>(origVal: T_2, newVal: T_2, set: (T: any) => void) => boolean;
    };
};
export {};
