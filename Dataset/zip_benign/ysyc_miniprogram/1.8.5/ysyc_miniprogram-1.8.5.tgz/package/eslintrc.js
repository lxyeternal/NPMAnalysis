const path = require('path')
module.exports = {
  extends: [
    'taro/react',
    './.eslintrc-auto-import.json'
 ],
  parser: '@babel/eslint-parser',
  plugins: [ 'import-newlines', 'simple-import-sort' ],
  rules: {
    'simple-import-sort/imports': 'error',
    'simple-import-sort/exports': 'error',
    'import-newlines/enforce': [
      'error',
      {
        items: 3,
        semi: false,
        forceSingleLine : false,
      },
    ],
    indent: [ 'error', 2, ], //缩进风格
    'react/jsx-indent-props': [ 2, 2, ], //验证JSX中的props缩进
    // 限制JSX中单行上的props的最大数量
    'react/jsx-max-props-per-line': [ 1, { maximum: 1, }, ],
    // "react/jsx-closing-bracket-location": [1, 'tag-aligned'],
    //
    'react/jsx-wrap-multilines': [
      1,
      {
        declaration: 'parens-new-line',
        assignment: 'parens-new-line',
        assignment: 'parens-new-line',
        return: 'parens-new-line',
        arrow: 'parens-new-line',
        condition: 'parens-new-line',
        logical: 'parens-new-line',
        prop: 'parens-new-line',
      },
    ],
    'react/jsx-first-prop-new-line': [ 'error', 'multiline', ],
    // 不允许有空行
    'react/jsx-props-no-multi-spaces': 1,
    'react/jsx-sort-props': [
      1,
      {
        callbacksLast: true,
        // react 保留关键字靠前
        reservedFirst: true,
      },
    ],
    // useEffect自动补仓依赖(第二个参数)
    'react-hooks/exhaustive-deps': 0,
    // 空标签
    'react/self-closing-comp': 1,
    // jsx 中必须有React导入
    'react/react-in-jsx-scope': 0,
    "react/jsx-no-undef": [1, { "allowGlobals": true }],
    // 'react/jsx-curly-newline':['error',{ multiline: "consistent", singleline: "consistent" }],
    //
    'no-multi-spaces': 1, //不能用多余的空格
    'comma-dangle': [
      'error',
      {
        arrays: 'always',
        objects: 'always',
        imports: 'always',
        exports: 'never',
        functions: 'ignore',
      },
    ], //对象字面量项尾不能有逗号
    'spaced-comment': 0, // 注释内有空格或者缩进
    eqeqeq: 0,

    'no-await-in-loop': 1,
    'no-cond-assign': 1,
    'no-dupe-args': 1,
    'no-empty': 1,
    'no-extra-boolean-cast': 1,
    // 'no-extra-parens': 1, //禁止不必要的括号
    'no-extra-semi': 1, //禁止不必要的分号
    'no-inner-declarations': 1, //禁止不必要的分号
    'no-irregular-whitespace': 1, //禁止不规则的空白
    'no-prototype-builtins': 0, // hasOwnProperty 1- 禁止直接使用 Object.prototypes 的内置属性
    'no-regex-spaces': 1,
    'no-sparse-arrays': 1,
    'no-template-curly-in-string': 1,
    'no-unexpected-multiline': 1,
    'no-unreachable': 1,
    'no-unsafe-negation': 1,
    'use-isnan': 1,
    // 'require-atomic-updates': 1,
    'valid-typeof': 1,

    curly: 1,
    complexity: 1,
    'dot-location': 1,
    'dot-notation': 1,
    'no-div-regex': 1,
    'no-else-return': 1,
    'no-empty-function': 1,
    'no-empty-pattern': 1,
    'no-eq-null': 1,
    'no-eval': 1,
    'no-extra-bind': 1,
    'no-extra-label': 1,
    'no-fallthrough': 1,
    'no-global-assign': 1,
    'no-implicit-globals': 1,
    'no-invalid-this': 1,
    'no-labels': 1,
    'no-lone-blocks': 1,
    'no-loop-func': 1,
    'no-magic-numbers': 0,
    'no-new': 1,
    'no-new-wrappers': 1,
    'no-octal': 1,
    'no-redeclare': 1,
    'no-restricted-properties': 1,
    'no-return-assign': 1,
    'no-self-assign': 1,
    'no-self-compare': 1,
    'no-sequences': 1,
    'no-unmodified-loop-condition': 1,
    'no-unused-expressions': 1,
    // 'no-useless-catch': 1,
    'no-unused-labels': 1,
    'no-useless-escape': 1,
    'no-useless-return': 1,
    'no-warning-comments': 1,
    'no-with': 1,
    'prefer-promise-reject-errors': 1,
    'require-await': 1,
    'vars-on-top': 1,
    'wrap-iife': 1,
    'no-undef': 1,
    'no-undef-init': 1,
    'no-unused-vars': 1,
    'no-use-before-define': 1,

    'block-spacing': 1,
    'brace-style': 1,
    'comma-style': [ 'error', 'last', ],
    'func-call-spacing': [ 'error', 'never', ],
    'no-spaced-func': 'error',
    'implicit-arrow-linebreak': [ 'error', 'beside', ],
    'jsx-quotes': [ 'error', 'prefer-single', ],
    'max-len': [
      'error',
      {
        code: 120,
        ignoreComments: true,
        ignoreTrailingComments: true,
        ignoreUrls: true,
        ignoreStrings: true,
        ignoreTemplateLiterals: true,
      },
    ],
    'max-nested-callbacks': [ 'error', 4, ],
    'no-mixed-spaces-and-tabs': 'error',
    'no-var': 'error',
    'prefer-template': 'error',
    camelcase: [ 'error', { properties: 'never', }, ],
    'padded-blocks': [ 'error', 'never', ],
    // 最大空行
    'no-multiple-empty-lines': [
      'error',
      {
        max: 1,
        maxBOF: 1,
      },
    ],
    'function-paren-newline': [ 'error', { minItems: 3, }, ],
    'no-dupe-keys': 'error',
    'no-duplicate-imports': [ 'error', { includeExports: true, }, ],
    'no-lonely-if': 'error',
    'no-mixed-operators': 'error',
    // 'no-nested-ternary': "error",
    'no-whitespace-before-property': 'error',
    // object
    'object-curly-newline': [
      'error',
      {
        // multiline: true,
        // minProperties: 3,
        // "ObjectExpression": "never",
        "ObjectExpression": { "multiline": true, "minProperties": 3 },
        "ObjectPattern": { "multiline": true, "minProperties": 3 },
        "ImportDeclaration": { "multiline": true, "minProperties": 3 },
        "ExportDeclaration": { "multiline": true, "minProperties": 3 }
      },
    ],
    'object-curly-spacing': [ 'error', 'always', ],
    // 'object-property-newline': ['error', { "allowMultiplePropertiesPerLine": false, allowAllPropertiesOnSameLine: true }],
    'object-property-newline': 'error',

    // arrray 数组超过3个item 括号换行
    'array-bracket-newline': [
      'error',
      {
        multiline: true,
        minItems: 3,
      },
    ],
    'array-bracket-spacing': [ 'error', 'always', ],
    'array-callback-return': 'error',
    // 数组超过3个item item换行
    'array-element-newline': [
      'error',
      {
        multiline: true,
        minItems: 3,
      },
    ],
    'quote-props': [ 'error', 'as-needed', ],
    quotes: [ 'error', 'single', ],
    semi: [ 'error', 'never', ],
    'space-infix-ops': 'error',
    'key-spacing': [
      'error',
      {
        beforeColon: false,
        afterColon: true,
      },
    ],
    'arrow-spacing': 'error',
    'template-curly-spacing': 'error',
    'comma-spacing': [
      'error',
      {
        before: false,
        after: true,
      },
    ],
    'keyword-spacing': [
      'error',
      {
        before: true,
        after: true,
      },
    ],
    'space-before-blocks': 'error',
    'space-before-function-paren': [ 'error', 'never', ],
    'space-in-parens': [ 'error', 'never', ],
    // 多个三目
    'multiline-ternary': [ 'error', 'always-multiline', ],
    'operator-linebreak': [ 'error', 'after', ],
  },
  globals: {
    Component: true,
    wx: true,
  },
}
