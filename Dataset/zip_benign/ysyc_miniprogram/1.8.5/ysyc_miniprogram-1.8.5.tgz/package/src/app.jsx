import React, { Component, } from 'react'
// import { StoreContext, } from 'redux-react-hook'
import { Provider, } from 'react-redux'

import store from './store'
// import './app.scss'
class App extends Component {
  constructor(...arg) {
    super(...arg)
  }
  render() {
    return (
      <Provider store={store}>
        {this.props.children}
      </Provider>
    )
  }
}

export default App
