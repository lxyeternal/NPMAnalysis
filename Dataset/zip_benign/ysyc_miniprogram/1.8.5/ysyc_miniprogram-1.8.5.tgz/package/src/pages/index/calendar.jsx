import React, { useEffect, } from 'react'
import Layout from '@/components/Layout'
import Calendar from '@/components/calendar'

export default function() {
  return (
    <Layout
      style={{ padding: '0', }}
    >
      <Calendar
        renderHeader={() => {
          return (
            <view
              style={{
                backgroundColor: '#f2f2f2',
                display: 'flex', 
                alignItems: 'center',
                justifyContent: 'space-around',
                paddingTop: '10PX',
              }}
            >
              <view>
                上个月
              </view>
              <view
                style={{
                  position: 'relative',
                  height: '45PX',
                  width: '150PX',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <view
                  style={{
                    position: 'absolute',
                    top: '0',
                    left: '0',
                    right: '0',
                    bottom: '3PX',
                    background: '#fff',
                    border: '1PX solid #ededed',
                    borderBottom: 'none',
                    borderRadius: '10PX 10PX 0 0',
                    // boxShadow: '3px -3px 5px #ededed',
                    backgroundColor: '#fff',
                    transform: 'perspective(15PX)  rotateX(5deg)',
                    // zIndex: '-1', 
                  }}
                >
                </view>
                <view
                  style={{ position: 'relative', }}
                >
                标题222
                </view>
              </view> 
              <view>
                下个月
              </view>
            </view>
          )
        }} 
      />
    </Layout>
  )
}
