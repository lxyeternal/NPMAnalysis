import React, { useEffect, } from 'react'
import Layout from '@/components/Layout'
import useForm from '@/components/useForm'
import RadioGroup from '@/components/RadioGroup'
import Form from '@/components/Form'
import '@/assets/css/iconfont.scss'

export default function() {
  const {
    formData, setFormData, SubmitButton, 
  } = useForm({ url: 'api/form', })
  return (
    <Layout 
      style={{ 
        paddingLeft: '0PX',
        paddingRight: '0PX',
        paddingBottom: '100PX', 
      }}
      footerStyle={{
        backgroundColor: '#fff',
        bottom: 0, 
      }}
      footer={<SubmitButton title='提交表单' />}
    >
      <view>
        姓名：<input
          value={formData.name}
          onChange={(val) => {
            setFormData({ name: val, })
          }} 
        />
      </view>
      <view>
        性别：
        <RadioGroup
          value={formData.sex}
          onChange={(val) => {
            setFormData({ sex: val, })
          }}
          data={[
            {
              type_id: 1,
              type_name: '男', 
            }, 
            {
              type_id: 2,
              type_name: '女', 
            }, 
          ]}
        />
      </view>
      
    </Layout>
  )
}
