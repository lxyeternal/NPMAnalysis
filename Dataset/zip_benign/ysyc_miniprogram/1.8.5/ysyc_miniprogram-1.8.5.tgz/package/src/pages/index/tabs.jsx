import React, { useEffect, } from 'react'
import Layout from '@/components/Layout'
import useList from '@/components/useList'
import List from '@/components/List'
import Tabs from '@/components/Tabs'

export default function() {
  const { listProps, setParams, } = useList({ url: 'api/list', })
  return (
    <Layout >
      <Tabs
        tabs={[
          {
            type_id: 1,
            type_name: '选项卡1', 
          }, 
          {
            type_id: 2,
            type_name: '选项卡2', 
          }, 
        ]}
        onClick={(i, item) => {
          setParams({ status: item.type_id, })
        }}
      />
      <List
        {...listProps}
        renderItem={(item, i) => {
          return (
            <view
              style={{
                padding: '10PX 0',
                borderBottom: '1PX solid #e5e5e5', 
              }}
            >
              <view>
                {item.name}
              </view>
              <view
                style={{
                  fontSize: '12PX',
                  color: '#999', 
                }}
              >
                {item.desc}
              </view>
            </view>
          )
        }}
      />
    </Layout>
  )
}
