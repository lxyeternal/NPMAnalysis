
import React, { } from 'react'

import styles from '@/assets/css/iconfont.scss'
import Form from '@/components/Form'
import Layout from '@/components/Layout'
import useForm from '@/components/useForm'

export default function() {
  const {
    formProps, SubmitButton, validate,
  } = useForm({ url: 'api/form', })
  return (
    <Layout
      footer={<SubmitButton title='提交表单' />}
      footerStyle={{
        backgroundColor: '#fff',
        bottom: 0,
      }}
      style={{
        paddingLeft: '0PX',
        paddingRight: '0PX',
        paddingBottom: '100PX',
      }}
    >
      <Form
        {...formProps}
        items={[
          {
            type: 'test',
            label: '测试自定义类型',
          },
          {
            label: '姓名',
            name: 'name',
            rules: [
              {
                required: true,
                message: '姓名必填！',
              },
              /* {
                type: 'array',
                message: '必须是数组',
              },
              {
                max: 10,
                message: '数字最大值10',
              },
              {
                maxLength: 10,
                message: '最多10个字符',
              },
              {
                minLength: 10,
                message: '最少10个字符',
              },
              {
                min: 10,
                message: '数字最小值10',
              },
              {
                validator(
                  value, rule, formData
                ) {
                  if (!value) {
                    return '不能为空'
                  }
                },
              }, */
            ],
          },
          {
            label: '性别',
            name: 'sex',
            type: 'radio',
            data: [
              {
                type_id: '男',
                type_name: '男',
              },
              {
                type_id: '女',
                type_name: '女',
              },
            ],
          },
          {
            label: '职业',
            name: 'zy',
            type: 'checkbox',
            data: [
              {
                type_id: 1,
                type_name: 'it',
              },
              {
                type_id: 2,
                type_name: '外卖',
              },
              {
                type_id: 3,
                type_name: '销售',
              },
            ],
          },
          {
            label: '学历',
            name: 'xl',
            type: 'picker',
            firstItem: {
              type_id: -999,
              type_name: '全部',
            },
            data: [
              {
                type_id: 1,
                type_name: '本科',
              },
              {
                type_id: 2,
                type_name: '大专',
              },
              {
                type_id: 3,
                type_name: '硕士',
              },
            ],
            lastItem: {
              type_id: -888,
              type_name: '取消',
              style: {
                backgroundColor: '#f00',
                color: '#fff',
              },
            },
          },

          {
            label: '地区',
            name: 'ps',
            type: 'area',
          },
          {
            label: '日期',
            name: 'rq',
            type: 'date',
          },
          {
            label: '是否毕业',
            name: 'by',
            type: 'switch',
          },
          {
            label: '证件',
            name: 'zj',
            type: 'image',
          },
          {
            label: '胶囊',
            name: 'jn',
            type: 'capsuleGroup',
            // capsuleItemStyle: { padding: '0 15PX', },
            // style: { flexWrap: 'nowrap', },
            data: [
              {
                type_id: 1,
                type_name: '本科',
              },
              {
                type_id: 2,
                type_name: '大专',
              },
              {
                type_id: 3,
                type_name: '硕士',
              },
              {
                type_id: -999,
                type_name: '自定义',
                suffix: '元',
              },
            ],
            rules: [
              {
                validator: (val) => {
                  if (!val) {
                    return '胶囊必填'
                  }
                },
              },
            ],
          },
          {
            label: '跳转到其它页面',
            name: 'name',
            placeholder: '请选择',
            // navigateTo({url, query})
            url: '/pages/index/pagePicker',
            // 额外的参数
            params: { a: 1, },
            type: 'pagePicker',
            // 可选
            /* parseValue(val) {
              if (val === undefined) {
                return '请选择'
              }
              // 可根据val值，自定义返回显示的内容，parseValue会覆盖placeholder和正常值
              return val == 1 ? '是': '否'
            },
            // 可选
            onChange: (val) => {
              console.log('val :>> ', val);
            }
            */
            // 可选
            onClick: (next) => {
              // 验证其它 validate(['name']) name - 要验证的表单字段
              if (validate([ 'jn', ])) {
                next()
                // next({
                //   url: '',
                //   params: {}
                // })
              }
            },
          },
          { type: 'gap', },
          {
            label: '说明',
            name: 'remark',
            type: 'textarea',
          },
        ]}
      />

    </Layout>
  )
}
