import React, { useEffect, useState, } from 'react'
import Layout from '@/components/Layout'
import SearchBar from '@/components/SearchBar'
import Title from '@/components/Title'
import { navigateTo, } from '@/service/utils'
// import '@/assets/css/iconfont.scss'

export default function() {
  const [ searchVal, setSearchVal, ] = useState('test')
  useEffect(() => {
  }, [])
  return (
    <Layout >
      <Title title='基本用法' />
      <SearchBar
        onChange={(v) => {
          console.log('v :>> ', v)
        }}
      />
      <Title title='传值' />
      值：{searchVal}
      <SearchBar
        value={searchVal}
        onChange={(v) => {
          console.log('v :>> ', v)
          setSearchVal(v)
        }}
      />
      <Title title='不显示取消' />
      <SearchBar
        showCancel={false}
        onChange={(v) => {
          console.log('v :>> ', v)
        }}
      />
      <Title title='显示确定' />
      <SearchBar
        showOk
        onChange={(v) => {
          console.log('v :>> ', v)
        }}
      />
      <Title title='点击跳转' />
      <SearchBar
        url=''
        onClick={() => {
          navigateTo({ url: '/pages/index/form', })
        }}
      />
    </Layout>
  )
}
