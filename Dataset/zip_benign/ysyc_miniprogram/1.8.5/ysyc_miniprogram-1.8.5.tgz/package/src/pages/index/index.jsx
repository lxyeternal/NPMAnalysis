import '@/assets/css/iconfont.scss'

import { useDispatch, useSelector, } from 'react-redux'

export default function() {
  const dispatch = useDispatch()
  // 调用
  const config = useSelector(useCallback((state) => {
    return state.config
  }, []))
  const getConfig = () => {
    setTimeout(() => {
      dispatch({
        type: 'setConfig',
        payload: { title: '1111', },
      })
    }, 1000)
  }
  return (
    <Layout
      message='暂无内容！'
      style={{ paddingBottom: '160PX', }}
    >
      <Table
        isList
        itemStyle={{ alignItems: 'center', }}
        items={[
          {
            label: '按钮',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/button', })
            },
          },
          {
            label: '列表',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/list', })
            },
          },
          {
            label: '选项卡',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/tabs', })
            },
          },
          {
            label: '表单',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/form', })
            },
          },
          {
            label: '弹窗',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/modal', })
            },
          },
          {
            label: '图表',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/charts', })
            },
          },

          {
            label: '搜索框',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/search', })
            },
          },
          {
            label: '页面传值',
            hasArrow: true,
          },
          {
            label: '分享',
            hasArrow: true,
          },
          {
            label: '焦点图',
            hasArrow: true,
          },
          {
            label: '签名',
            hasArrow: true,
          },
          {
            label: '过滤',
            hasArrow: true,
          },
          {
            label: '日历',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/calendar', })
            },
          },
          {
            label: '步骤条',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/steps', })
            },
          },
          {
            label: 'redux',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/redux', })
            },
          },
          {
            label: '用户隐私',
            hasArrow: true,
            onClick() {
              utils.navigateTo({ url: 'pages/index/areePrivacy', })
            },
          },
        ]}
      />
    </Layout>
  )
}
