import React, { useState, Fragment, } from 'react'
import {
    Layout, Image, useUpload,
} from '@/components'
import { View, Text, } from '@tarojs/components'
import Taro, { useDidShow, eventCenter, } from '@tarojs/taro'
import {
    xcx, csf_xcx_qdan, csf_xcx_pz, csf_xcx_qxan,
} from '@/service/assets'
import './index.scss'

export default function() {
    const [ cameraImg, setCameraImg, ] = useState('')
    const [ show, setShow, ] = useState(false)

    const { uploadFiles, loading, } = useUpload({
        onChange(v) {
            eventCenter.trigger('cameraDone', v)
            // 上传成功后
        },
    })
    useDidShow(() => {
        Taro.authorize({
            scope: 'scope.camera',
            success() {
                setShow(true)
            },
            fail() {
                setShow(false)
                Taro.showModal({
                    title: '提示',
                    content: '没有授权无法拍照！',
                    confirmText: '授权',
                    cancelText: '拒绝',
                    success: function(res) {
                        if (res.confirm) {
                            Taro.openSetting({
                                success(rs) {
                                    // res.authSetting = {
                                    //   "scope.userInfo": true,
                                    //   "scope.userLocation": true
                                    // }
                                },
                            })
                        } else if (res.cancel) {
                            console.log('用户点击取消')
                        }
                    },
                })
            },
        })
    })
    const takePhoto = () => {
        // setCameraImg('ecc982e25ac3212e871df9396183ed50')
        const ctx = Taro.createCameraContext()
        ctx.takePhoto({
            quality: 'high',
            success(res) {
                setCameraImg(res.tempImagePath)
            },
            fail(res) {
                console.log(res)
            },
        })
    }
    const takePick = () => {
        Taro.chooseImage({
            // sourceType: ['camera'],
            success(res) {
                uploadFiles(res.tempFilePaths[0], (new Date()).getTime())
            },
        })
    }
    const saveImg = () => {
        if (!loading) {
            /*Taro.chooseImage({
                success(res) {
                    uploadFiles(res.tempFilePaths[0], (new Date()).getTime())
                }
            })*/
            uploadFiles(cameraImg, (new Date()).getTime())
        }
    }
    return (
        <Layout >
            <view class='camera-box'>
                {show ?
                    (!cameraImg && (
                        <camera
                            class='camera'
                            device-position='back'
                            flash='off'
                            frameSize='large'
                        >
                            <cover-view class='id_m'>
                                <cover-image
                                    class='img'
                                    src={xcx}
                                ></cover-image>
                            </cover-view>
                        </camera>
                    )) :
                    <View class='camera'></View>}
                {cameraImg && (
                    <Image
                        className='camera-img'
                        style={{ width: '100%', }}
                        mode='widthFix'
                        src={cameraImg}
                    ></Image>
                )}
                <view
                    class='action'
                >
                    {/*拍照按钮*/}
                    {!cameraImg && (
                        <Fragment>
                            <View class='back-btn'>
                                <Image
                                    src={csf_xcx_qxan}
                                    onClick={() => {
                                        Taro.navigateBack()
                                    }}
                                />
                                <Text>取消</Text>
                            </View>
                            <View class='take-btn'>
                                <Image
                                    src={csf_xcx_pz}
                                    onClick={takePhoto}
                                />
                                <Text>拍照</Text>
                            </View>
                            {process.env.NODE_ENV == 'development' ? (
                                <View class='take-btn'>
                                    <Image
                                        src={csf_xcx_pz}
                                        onClick={takePick}
                                    />
                                    <Text>相册选取</Text>
                                </View>
                            ) : <View style={{ width: '50px', }}></View>}
                        </Fragment>
                    )}
                    {cameraImg && (
                        <Fragment>
                            {/*取消按钮*/}
                            <View class='cancel-btn'>
                                <Image
                                    class='cancel-btn'
                                    src={csf_xcx_qxan}
                                    onClick={() => setCameraImg('')}
                                />
                                <Text>取消</Text>
                            </View>
                            {/*确定按钮*/}
                            <View class='save-btn'>
                                <Image
                                    class
                                    src={csf_xcx_qdan}
                                    onClick={saveImg}
                                />
                                <Text>确定</Text>
                            </View>
                        </Fragment>
                    )}
                </view>
            </view>
        </Layout>
    )
}
