
export default function() {
  const { listProps, } = useList({ url: 'api/list', })
  return (
    <Layout >
      <List
        {...listProps}
        renderItem={(item, i) => {
          return (
            <view
              style={{
                padding: '10PX 0',
                borderBottom: '1PX solid #e5e5e5',
              }}
            >
              <view>
                {item.name}
              </view>
              <view
                style={{
                  fontSize: '12PX',
                  color: '#999',
                }}
              >
                {item.desc}
              </view>
            </view>
          )
        }}
      />
    </Layout>
  )
}
