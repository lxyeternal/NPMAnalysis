// import { useSocket, } from '@/components'
import {
  Button,
  Canvas,
  CoverView,
  Input,
  Navigator,
  PageContainer,
  Picker,
  Swiper,
  SwiperItem,
  Switch,
  Textarea,
} from '@tarojs/components'
import React, { useEffect, useState, } from 'react'

export default function() {
  const [ data, setData, ] = useState({})
  useEffect(() => {
    setTimeout(() => {
      setData({ id: 1, })
    }, 1000)
  }, [])
  return (
    <view>
      <Input placeholder='input' />
      <Switch />
      <Canvas />
      <Picker />
      <CoverView />
      <Textarea />
      <PageContainer />
      <Swiper>
        <SwiperItem />
      </Swiper>
      <Button
        open-type='exit'
        target='miniProgram'
      >
                button
      </Button>
      <Navigator
        open-type='exit'
        target='miniProgram'
      >退出小程序</Navigator>
    </view>
  )
}
