
import Button from '@/components/Button'
import Layout from '@/components/Layout'
import ModalAreePrivacy from '@/components/ModalAreePrivacy'

export default function() {
  return (
    <Layout >
      <Button
        openType='chooseAvatar'
        title='获取头像'
        onChooseAvatar={(e) => {
          console.log('value-55 :>> ', e)
        }}
      />
      <Button
        openType='getPhoneNumber'
        title='获取电话号码'
        onGetPhoneNumber={(e) => {
          console.log('value-56 :>> ', e)
        }}
      />
      <Button
        title='获取剪切板内容'
        onClick={() => {
          wx.getClipboardData({
            success(res) {
              console.log('getClipboardData success', res)
            },
            fail(res) {
              console.log('getClipboardData fail', res)
            },
          })
        }}
      />
      <ModalAreePrivacy
        onAgreePrivacyAuthorization={(e) => {
          console.log('value-08 :>> ', e)
        }}
      />
    </Layout>
  )
}
