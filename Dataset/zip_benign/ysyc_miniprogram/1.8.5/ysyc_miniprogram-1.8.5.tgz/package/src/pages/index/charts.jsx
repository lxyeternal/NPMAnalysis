import React, { useEffect, } from 'react'

import Layout from '@/components/Layout'
import useCharts from '@/components/useCharts'

export default function() {
  const { getChartPorps, updateData, } = useCharts()
  const { getChartPorps: getChartPorps1, updateData: updateData1, } = useCharts({ id: 'chart2', })
  const { getChartPorps: getChartPorps2, updateData: updateData2, } = useCharts({ id: 'arbar', })
  const getData = () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          series: [
            {
              data: [
                {
                  name: '一班',
                  value: 50, 
                },
                {
                  name: '二班',
                  value: 30, 
                },
                {
                  name: '三班',
                  value: 20, 
                },
                {
                  name: '四班',
                  value: 18,
                  labelText: '四班:18人', 
                },
                {
                  name: '五班',
                  value: 8, 
                }, 
              ], 
            },
          ], 
        })
      }, 300)
    })
  }
  useEffect(() => {
    getData().then(res => {
      updateData(res)
      updateData1({
        type: 'column',
        background: '#FFFFFF',
        color: [
          '#FAC858',
          '#EE6666',
          '#FAC858',
          '#EE6666',
          '#73C0DE',
          '#3CA272',
          '#FC8452',
          '#9A60B4',
          '#ea7ccc',
        ],
        categories: [
          '2018',
          '2019',
          '2020',
          '2021',
          '2022',
          '2023',
        ],
        series: [
          {
            name: '目标值',
            data: [
              35,
              36,
              31,
              33,
              13,
              34,
            ],
          },
          {
            name: '完成量',
            textColor: '#f00',
            formatter: (value) => `${value}个`,
            data: [
              18,
              27,
              21,
              24,
              6,
              28,
            ],
          },
        ],
        
        padding: [
          15,
          15,
          0,
          5,
        ],
        enableScroll: false,
        legend: {},
        xAxis: { disableGrid: true, },
        yAxis: { data: [ { min: 0, }, ], },
        extra: {
          column: {
            type: 'group',
            width: 10,
            activeBgColor: '#000000',
            activeBgOpacity: 0.08,
            linearType: 'custom',
            seriesGap: 5,
            linearOpacity: 0.5,
            barBorderCircle: true,
            customColor: [ '#FA7D8D', '#EB88E2', ],
          },
        },
      })
      updateData2({
        
        type: 'arcbar',
        series: [
          {
            name: '正确率',
            color: '#2fc25b',
            data: 0.8,
          },
        ],
        background: '#FFFFFF',
        color: [
          '#1890FF',
          '#91CB74',
          '#FAC858',
          '#EE6666',
          '#73C0DE',
          '#3CA272',
          '#FC8452',
          '#9A60B4',
          '#ea7ccc',
        ],
        title: {
          name: '80%',
          fontSize: 35,
          color: '#2fc25b',
        },
        subtitle: {
          name: '正确率',
          fontSize: 25,
          color: '#666666',
        },
        extra: {
          arcbar: {
            type: 'circle',
            width: 12,
            backgroundColor: '#ffe000',
            startAngle: 1.75,
            endAngle: 0.25,
            lineCap: 'round',
            gap: 10,
          },
        },
      })
    }) 
  }, [])
  return (
    <Layout
      style={{ padding: '0', }}
    >
      <canvas
        {...getChartPorps()}
      />
      <canvas
        {...getChartPorps1()}
      />
      <canvas
        {...getChartPorps2()}
      />
    </Layout>
  )
}
