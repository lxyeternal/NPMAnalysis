import React from 'react'
import {
    Layout, useAuth, Button, Image,
} from '@/components'

const SignPage = () => {
    const { getPhoneNumber, loading, } = useAuth()
    return (
        <Layout
            style={{ padding: '20PX', }}
        >
            {/* <Image
                src='/static/miniprogram/images/logo.png'
                style={{
                    width: '160PX',
                    height: '60PX',
                    display: 'block',
                    margin: '80PX auto',
                }}
            /> */}
            <Button
                type='primary'
                loading={loading}
                style={{ marginTop: '200PX', }}
                openType='getPhoneNumber'
                onGetPhoneNumber={getPhoneNumber}
            >授权获取手机号码</Button>
        </Layout>
    )
}

export default SignPage
