import React, { useState, } from 'react'
import {
  Layout, Title,
  useAuth,
} from '@/components'
import Taro, { getCurrentInstance, } from '@tarojs/taro'

//import './index.scss'
import ajax from '@/service/ajax'
import {
  AtButton, AtForm, AtInput, AtMessage,
} from 'taro-ui'

class Countdown extends React.Component {
  constructor(props) {
    super(props)
    this.state = { seconds: 0, }
  }
  setTimer() {
    if (!this.timer) {
      this.countdonwn()
    }
  }
  clearTimer() {
    if (this.timer) {
      clearTimeout(this.timer)
    }
  }

  countdonwn() {
    let { seconds, } = this.state
    let sec = seconds - 1

    if (sec < 0) {
      this.clearTimer()
      this.props.onTimeUp && this.props.onTimeUp()
      return
    }
    this.setState({ seconds: sec, })
    this.timer = setTimeout(() => {
      this.countdonwn()
    }, 1000)
  }
  UNSAFE_componentWillReceiveProps(nextProps) {
    if (JSON.stringify(this.props) === JSON.stringify(nextProps)) {
      return
    }
    this.clearTimer()
    this.setTimer()
  }
  componentDidMount() {
    this.setTimer()
  }
  componentWillUnmount() {
    this.clearTimer()
  }
  componentDidHide() {
    this.clearTimer()
  }
  componentDidShow() {
    this.setTimer()
  }
  render() {
    const {
      text, type, onClick, duration,
    } = this.props
    const { seconds, } = this.state
    return (
      <AtButton
        type={type}
        onClick={() => {
          if (seconds < 1) {
            onClick().then(() => {
              this.setState({ seconds: duration, })
              this.countdonwn()
            })
          }
        }}
      >
        {seconds > 0 ? `剩余${seconds}秒` : text}
      </AtButton>
    )
  }
}

export default function() {
  const { router, } = getCurrentInstance()
  //const [openId, setOpenID] = useState(router.params['open_id'] || '')
  const openId = router.params.open_id || ''
  const [ data, setFormData, ] = useState({
    open_id: openId,
    phone: '',
    code: '',
  })
  const { setUserInfo, } = useAuth()

  const goBack = () => {
    const pages = Taro.getCurrentPages()
    if (pages.length >= 3) {
      Taro.switchTab({ url: `/${pages[pages.length - 3].route}`, })
    } else {
      Taro.switchTab({ url: '/pages/my/index', })
    }
  }

  return (
    <Layout>
      <Title title='绑定手机' />
      <AtMessage />
      <AtForm
        reportSubmit={false}
      >
        <view className='at-row'>
          <AtInput
            name='phone'
            type='phone'
            placeholder='请输入手机号码'
            value={data.phone}
            required
            onChange={(v) => {
              setFormData(Object.assign(
                {}, data, { phone: v, }
              ))
            }}
          />
        </view>
        <view className='at-row'>
          <view className='at-col at-col-8'>
            <AtInput
              name='code'
              type='number'
              placeholder='请输入验证码'
              required
              value={data.code}
              onChange={(v) => {
                setFormData(Object.assign(
                  {}, data, { code: v, }
                ))
              }}
            />
          </view>
          <view className='at-col at-col-4'>
            <Countdown
              text='获取验证码'
              duration={60}
              onClick={async() => {
                let res = await ajax({
                  url: '/wechat/login/checkPhoneMsg',
                  data: { phone: data.phone, },
                })
                Taro.atMessage({
                  message: '验证码已发送到您的手机',
                  type: 'success',
                })
              }}
            />
          </view>
        </view>
        <view
          className='at-row'
          style={{ marginTop: '20px', }}
        >
          <view className='at-col at-col-12'>
            <AtButton
              type='primary'
              onClick={() => {
                ajax({
                  url: '/wechat/login/bindPhone',
                  method: 'POST',
                  data,
                }).then((res) => {
                  if (res.code == 1) {
                    Taro.atMessage({
                      message: '登录成功',
                      type: 'success',
                    })
                    setUserInfo(res.data)
                    //Taro.switchTab({ url: '/pages/my/index' })
                    goBack()
                  } else {
                    Taro.atMessage({
                      message: res.msg,
                      type: 'error',
                    })
                  }
                })
              }}
            >立即登录</AtButton>
          </view>
        </view>
      </AtForm>
    </Layout>
  )
}
