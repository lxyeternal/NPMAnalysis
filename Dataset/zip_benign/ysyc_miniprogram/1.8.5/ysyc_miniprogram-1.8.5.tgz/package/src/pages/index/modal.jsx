import React, { } from 'react'

import Button from '@/components/Button'
import Layout from '@/components/Layout'
import Modal from '@/components/Modal'
import ModalForm from '@/components/ModalForm'
import Title from '@/components/Title'

export default function() {
  return (
    <Layout >
      <Title title='基本用法' />
      <Modal
        modalContent={() => (
          <view
            style={{ padding: '15PX', }}
          >
            <view>
          弹窗内容
            </view>
            <view>
          弹窗内容
            </view>
            <view>
          弹窗内容
            </view>
            <view>
          弹窗内容
            </view>
          </view>
        )}
        modalTitle='弹窗标题'
        title='弹窗'
      />
      <Title title='位置 - 居中弹窗' />
      <Modal
        modalContent={() => (
          <view
            style={{ padding: '15PX', }}
          >
            <view>
          弹窗内容
            </view>
          
          </view>
        )}
        modalContentStyle={{ width: '90%', }}
        modalTitle='弹窗标题'
        position='center'
        title='位置'
      />
      <Title title='自定义title' />
      <Modal
        modalContent={() => (
          <view
            style={{ padding: '15PX', }}
          >
            <view>
          弹窗内容
            </view>
          
          </view>
        )}
        modalTitle='弹窗标题'
        title={(show) => {
          return (
            <Button
              title='自定义弹窗'
              onClick={() => {
                show(true)
              }}
            />
          )
        }}
      />
      <Title title='自定义title' />
      <ModalForm
        formItems={[
          {
            label: '姓名',
            name: 'name',
            rules: [
              {
                required: true,
                message: '姓名必填！', 
              }, 
            ],
          }, 
          {
            label: '性别',
            name: 'sex',
            type: 'radio',
            data: [
              {
                type_id: '男',
                type_name: '男', 
              }, 
              {
                type_id: '女',
                type_name: '女', 
              }, 
            ],
          }, 
          {
            label: '职业',
            name: 'zy',
            type: 'checkbox',
            data: [
              {
                type_id: 1,
                type_name: 'it', 
              }, 
              {
                type_id: 2,
                type_name: '外卖', 
              }, 
              {
                type_id: 3,
                type_name: '销售', 
              }, 
            ],
          }, 
        ]}
        modalTitle='弹窗表单'
        title='表单'
      />
    </Layout>
  )
}
