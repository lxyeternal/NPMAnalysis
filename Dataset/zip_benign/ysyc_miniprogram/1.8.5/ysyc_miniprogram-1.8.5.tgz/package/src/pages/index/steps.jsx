import React, { useEffect, } from 'react'
import Layout from '@/components/Layout'
import Steps from '@/components/Steps'

export default function() {
  return (
    <Layout >
      <Steps
        data={[
          {
            label: '第一步',
            icon: 'icon-dls_danx01', 
          },
          {
            label: '第二步第二步',
            icon: 'icon-dl_qc', 
          },
          {
            label: '第三步第三步',
            icon: 'icon-check_box_px_rounded', 
          }, 
        ]}
      />
      <Steps
        data={[
          { label: '第一步', },
          { label: '第二步第二步', },
          { label: '第三步第三步', }, 
        ]}
      />
    </Layout>
  )
}
