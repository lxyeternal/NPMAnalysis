import React, { useEffect, useState, } from 'react'
import Taro, { eventCenter, } from '@tarojs/taro'
import Layout from '@/components/Layout'
import Button from '@/components/Button'

export default function() {
  return (
    <Layout >
      <Button
        title='点击返回参数1'
        onClick={() => {
          eventCenter.trigger('callback', {
            value: 1,
            title: '是',
          })
          Taro.navigateBack()
        }}
      />
      <Button
        title='点击返回参数0'
        onClick={() => {
          eventCenter.trigger('callback', {
            value: 0,
            title: '否',
          })
          Taro.navigateBack()
        }}
      />
    </Layout>
  )
}
