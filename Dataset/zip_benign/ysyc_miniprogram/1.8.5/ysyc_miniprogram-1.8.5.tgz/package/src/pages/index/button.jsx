import React, { useEffect, useState, } from 'react'
import Layout from '@/components/Layout'
import Button from '@/components/Button'
import Title from '@/components/Title'
import '@/assets/css/iconfont.scss'
import './button.scss'

export default function() {
  const [ loading, setLoading, ] = useState(false)
  return (
    <Layout >
      <Title title='基本用法' />
      <Button title='按钮' />
      <Title title='风格' />
      <Button
        title='按钮'
        type='primary'
      />
      <Button
        title='按钮'
        type='danger'
      />
      <Button
        title='按钮'
        type='warning'
      />
      <Button
        title='按钮'
        type='info'
      />
      <Button
        title='按钮圆角'
        type='primary'
        round
      />
      <Button
        title='按钮'
        type='primary'
        plain
      />
      <Title title='大小' />
      <view
        style={{ display: 'flex', }}
      >
        <Button
          size='large'
          title='按钮'
        />
        <Button
          size='medium'
          title='按钮'
        />
        <Button
          size='small'
          title='按钮'
        />
        <Button
          size='mini'
          title='按钮'
        />
      </view>
      <Title title='图标' />
      <Button
        title='图标'
        icon='icon-sy_sousuo iconfont-ysyc'
      />
      <Title title='自定义' />
      <Button
        title='自定义'
        style={{
          width: '100PX',
          backgroundColor: '#f00',
          color: '#fff',
          fontSize: '12PX',
        }} 
      />
      <Button
        title='不可用'
        disabled
      />
      <Button
        title='点击加载'
        loading={loading}
        onClick={() => {
          setLoading(true)
          setTimeout(() => {
            setLoading(false)
          }, 2000)
        }}
      />
      <Button
        title='点击'
        onClick={() => {
          console.log('222 :>> ', 222)
        }}
      />
    </Layout>
  )
}
