import React, { useCallback, } from 'react'
import { useDispatch, useSelector, } from 'react-redux'

import Button from '@/components/Button'
import Layout from '@/components/Layout'

export default function() {
  const { userInfo, } = useSelector(useCallback((state) => {
    return { userInfo: state.user ?? {}, }
  }, []))
  const dispatch = useDispatch()
  return (
    <Layout >
      姓名： {userInfo.name}
      <Button
        title='设置姓名'
        onClick={() => {
          dispatch({
            type: 'setUserInfo',
            payload: { name: '大福', },
          })
        }}
      />
    </Layout>
  )
}
