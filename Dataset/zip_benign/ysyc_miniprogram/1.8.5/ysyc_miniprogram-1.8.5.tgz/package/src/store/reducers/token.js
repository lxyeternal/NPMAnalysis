import Taro from '@tarojs/taro'
import { handleActions, } from 'redux-actions'
// init
let initState = null

export default handleActions({
  setToken(state, { payload, }) {
    Taro.setStorageSync('token', payload)
    return payload
  },
  clearToken() {
    Taro.removeStorageSync('token')
    return null
  },
}, initState)
