import { handleActions, } from 'redux-actions'
// init
let initState = { img_host: 'http://img.cxe.local', }

export default handleActions({
  setConfig(state, { payload, }) {
    return {
      ...state,
      ...payload,
    }
  },
}, initState)
