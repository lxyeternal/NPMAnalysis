import { handleActions, } from 'redux-actions'
// init
let initState = { }

export default handleActions({
  setCategory(state, payload) {
    return {
      ...state,
      ...payload, 
    }
  },
}, initState)
