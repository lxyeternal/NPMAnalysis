import { handleActions, } from 'redux-actions'
// init
let initState = {
  message: [],
  messageUnread: 0,
  messageNum: 0,
}

export default handleActions({
  setMessage(state, { payload, }) {
    return {
      ...state,
      ...payload,
    }
  },
}, initState)
