import { applyMiddleware, legacy_createStore as createStore, } from 'redux'
import { createLogger, } from 'redux-logger'

import rootReducer from './reducers/index1'

const middlewares = [ createLogger({ collapsed: true, }), ]

const configStore = () => {
  return createStore(rootReducer, applyMiddleware(...middlewares),)
}
export default configStore()
