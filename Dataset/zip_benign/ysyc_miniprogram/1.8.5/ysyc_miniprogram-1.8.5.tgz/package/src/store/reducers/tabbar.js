import { handleActions, } from 'redux-actions'
// init
let initState = {
  selected: 0, 
  num: 0, 
}

export default handleActions({
  setTabbar(state, { payload, }) {
    return {
      ...initState,
      ...payload,
    }
  },
}, initState)
