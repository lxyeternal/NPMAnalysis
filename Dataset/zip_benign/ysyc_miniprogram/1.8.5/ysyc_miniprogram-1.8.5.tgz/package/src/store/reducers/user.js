import Taro from '@tarojs/taro'
import { handleActions, } from 'redux-actions'
// init
let initState = { id: '', }

export default handleActions({
  setUserInfo(state, { payload, }) {
    const _state = {
      ...state,
      ...payload,
    }
    Taro.setStorageSync('userInfo', _state)
    return _state
  },
  clearUserInfo() {
    Taro.removeStorageSync('userInfo')
    Taro.removeStorageSync('token')
    return { ...initState, }
  },
}, initState)
