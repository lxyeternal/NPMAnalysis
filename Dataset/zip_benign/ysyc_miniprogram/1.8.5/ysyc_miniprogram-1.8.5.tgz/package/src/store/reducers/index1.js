import { combineReducers, } from 'redux'

import importFile from '../../service/importFile'
import categories from './categories'
import config from './config'
import message from './message'
import tabbar from './tabbar'
import token from './token'
import user from './user'

// const res = {}
const res = importFile(
  require.context(
    '@/store/reducers/', false, /\.js$/
  ), null, 'index'
)
export default combineReducers({
  user,
  message,
  config,
  token,
  tabbar,
  categories,
  ...res,
})
