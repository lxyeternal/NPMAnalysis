// import { sy01Icon, sy_02_icon, rw_01_icon, rw_02_icon, xx_01_icon, xx_02_icon, wode_01_icon, wode_02_icon } from '@/service/assets'
// 代码没用，只是为了不报错
const sy01Icon = 'assets/wode_yhk_icon.png'
export default {
  pages: [
    'pages/index/index',
    'pages/index/test',
    'pages/index/list',
    'pages/index/button',
    'pages/index/tabs',
    'pages/index/form',
    'pages/index/modal',
    'pages/index/calendar',
    'pages/index/charts',
    'pages/index/search',
    'pages/index/steps',
    'pages/index/pagePicker',
    'pages/index/redux',
    'pages/index/areePrivacy',
  ],
  // 在 `subpackages` 字段添加分包
  /*"subpackages": [
        {
            "root": "pages",
            "pages": [
                'my/index',
            ]
        }
    ],*/
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: 'ysyc_miniprogram',
    navigationBarTextStyle: 'black',
  },
  permission: { 'scope.userLocation': { desc: '你的位置信息将用于录入设备位置信息', }, },
  tabBar: {
    custom: true,
    // "position": "bottom",
    list: [
      {
        iconPath: sy01Icon,
        selectedIconPath: sy01Icon,
        pagePath: 'pages/index/index',
        text: '首页',
      },
      {
        iconPath: sy01Icon,
        selectedIconPath: sy01Icon,
        pagePath: 'pages/index/test',
        text: '测试',
      },
    ],
  },
  __usePrivacyCheck__: true,
}
