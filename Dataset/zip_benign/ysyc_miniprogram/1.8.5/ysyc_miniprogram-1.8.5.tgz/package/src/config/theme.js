// 导出的变量支持String,Object
// colors
export const primary = '#3E82FE'
export const info = '#eee'
export const text = '#fff'
export const danger = '#f30'
export const success = '#eaa218'
export const warning = '#eaa218'
export const muted = '#999'
export const muted2 = '#a8a8a8'
// button
export const buttonColor = {
  primary,
  info,
  text,
  danger,
  success,
  warning,
}
export const buttonSize = {
  large: '50PX',
  medium: '42PX',
  small: '32PX',
  mini: '26PX',
  tiny: '22PX',
}
export const buttonFontSize = {
  large: '18PX',
  medium: '16PX',
  small: '14PX',
  mini: '12PX',
  tiny: '12PX',
}
export const buttonBorderRadius = {
  large: '4PX',
  medium: '3PX',
  small: '3PX',
  mini: '3PX',
  tiny: '3PX',
}
// CapsuleGroup
export const capsuleGroupActiveBgColor = primary
// tabs
export const tabsActiveColor = primary
// battery
export const batteryColor = primary
// layout
export const layoutStyle = {
  paddingLeft: '15PX',
  paddingRight: '15PX',
}
// tag
export const tagSize = {
  small: '14PX',
  mini: '12PX',
  medium: '16PX',
  large: '30PX',
}
export const tagPadding = {
  small: '0 5PX',
  mini: '0 3PX',
  medium: '0 3PX',
  large: '0 4PX',
}
export const tagHeight = {
  small: '24PX',
  mini: '18PX',
  medium: '30PX',
  large: '40PX',
}