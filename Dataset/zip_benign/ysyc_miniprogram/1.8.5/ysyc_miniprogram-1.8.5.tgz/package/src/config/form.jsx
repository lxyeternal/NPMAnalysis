
export const getFormItem = ({
  item, type, value, onChange, getCategory,
}) => {
  if (type == 'test') {
    return (
      <input
        placeholder='测试'
        value={value}
        onChange={(v) => {
          onChange(item, v)
        }}
      />
    )
  }
}
