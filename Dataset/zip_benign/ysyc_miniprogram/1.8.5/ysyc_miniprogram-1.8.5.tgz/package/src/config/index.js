// import * as options from '@/config'
const options = require('@/config')

const API_BASE_URL = options.API_BASE_URL || 'https://123.com'
const _options = {
  TEL: '400-6525-188',
  API_BASE_URL,
  WS_URL: 'wss://123.com/ws',
  IMG_HOST: API_BASE_URL,
  CAPTCHA_URL: `${API_BASE_URL}/captcha`,
  WEBVIEW_URL: API_BASE_URL,
  UPLOAD_URL: `${API_BASE_URL}/api/resource/wxChunk`,
  UPLOAD_MERGE_URL: `${API_BASE_URL}/api/resource/wxChunkMerge`,
  UPLOAD_PRIVATE_URL: `${API_BASE_URL}/portalapi/upload/upload`,
  RESULT_TEMPLATE: {
    code: 200,
    data: 'data',
    list: 'data',
    msg: 'msg',
    page: 'page',
    pageSize: 'pageSize',
    total: 'total',
  },
  ...options,
}
module.exports = _options
