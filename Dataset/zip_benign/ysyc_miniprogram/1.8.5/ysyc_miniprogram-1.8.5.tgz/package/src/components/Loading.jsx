
import styles from '../assets/css/loading.scss'

export default function({
  loading = true, style = {}, size = 24,
}) {
  if (!loading) {
    return false
  }
  return (
    <view
      class='weui-loading'
      style={{
        width: `${size}PX`,
        height: `${size}PX`,
        ...style,
      }}
    />
  )
}
