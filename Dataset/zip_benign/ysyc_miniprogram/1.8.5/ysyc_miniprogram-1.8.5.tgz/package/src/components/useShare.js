import { useShareAppMessage, useShareTimeline, } from '@tarojs/taro'

export default ({
  shareAppMessage = {}, shareTimeline = {}, onShare = () => null,
} = {}) => {
  // 发给朋友
  useShareAppMessage((...args) => {
    shareAppMessage.title = shareAppMessage.title ?? '仓师傅'
    onShare(...args)
    return shareAppMessage
  })
  useShareTimeline((...args) => {
    shareTimeline.title = shareTimeline.title ?? '仓师傅'
    if (shareTimeline.imageUrl) {
      shareTimeline.imageUrl = utils.imgUrl(shareTimeline.imageUrl)
    }
    onShare(...args)
    return shareTimeline
  })
  return {}
}
