
import styles from '../assets/css/button.scss'

export default function({
  type = 'primary',
  title, plain = false, size = 'medium', icon, round = false, children,
  disabled = false,
  loading = false,
  loadingText,
  style = {}, iconStyle = {},
  onClick = utils.noop,
  data,
  ...props
}) {
  const _style = {
    marginLeft: '0',
    marginRight: '0',
    boxSizing: 'border-box',
    whiteSpace: 'nowrap',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }
  const sizeMap = getTheme('buttonSize')
  const fontSizeMap = getTheme('buttonFontSize')
  const typeMap = getTheme('buttonColor')
  const borderRadiusMap = getTheme('buttonBorderRadius')
  _style.fontSize = fontSizeMap[size]
  if (type.includes('text')) {
    _style.color = typeMap[type.replace('text-', '')]
    _style.lineHeight = '1.2'
    _style.backgroundColor = 'transparent'
    _style.padding = 0
  } else {
    _style.height = sizeMap[size]
    // bdrs
    _style.borderRadius = round ? sizeMap[size] : borderRadiusMap[size]
    // /plain
    if (plain) {
      _style.border = `1PX solid ${typeMap[type]}`
      _style.backgroundColor = '#fff'
      if (type != 'info') {
        _style.color = typeMap[type]
      } else {
        _style.color = '#888'
      }
    } else {
      _style.color = '#fff'
      /*       if (type != 'info') {
        _style.color = '#fff'
      } else {
        _style.color = '#888'
      }
      */
      _style.backgroundColor = typeMap[type]
    }
    _style.padding = '0 10PX'
  }
  if (disabled) {
    _style.opacity = '.5'
  }
  // button props
  const _props = {
    loading,
    disabled,
    onClick(...args) {
      if (!loading) {
        onClick(...args)
      }
    },
    ...props,
  }
  const _title = loadingText ? (loading ? loadingText : title ?? children) : (title ?? children)
  Object.assign(_style, style)
  if (icon) {
    return (
    // eslint-disable-next-line react/forbid-elements
      <button
        data-data={data}
        {..._props}
        style={_style}
      >
        {!loading && (
          <>
            <view
              class={!icon.includes('iconfont') ? `iconfont ${icon}` : icon}
              style={{
                fontSize: _style.fontSize,
                ...iconStyle,
              }}
            />
            <view style={{ width: '3PX', }} > </view>
          </>
        )}
        <view>{_title}</view>
      </button>
    )
  }
  return (
  // eslint-disable-next-line react/forbid-elements
    <button
      {..._props}
      style={_style}
    >{_title}</button>
  )
}
