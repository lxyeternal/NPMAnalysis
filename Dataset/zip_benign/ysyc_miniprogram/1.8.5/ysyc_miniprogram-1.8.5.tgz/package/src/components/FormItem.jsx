const _getRequired = (rules) => {
  let _required = false
  if (rules) {
    for (let index = 0; index < rules.length; index++) {
      const item = rules[index]
      if (item.required ?? false) {
        _required = true
        break
      }
    }
  }
  return _required
}
export default function({
  label,
  labelPosition = 'left',
  labelStyle = {},
  valueStyle = {},
  children,
  suffix,
  rules,
  style = {},
  hasBorder = true,
  hasArrow = false,
}) {
  const _required = _getRequired(rules)
  return (
    <view
      style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: labelPosition == 'top' ? 'flex-start' : 'center',
        flexDirection: labelPosition == 'top' ? 'column' : 'row',
        padding: '15PX 0',
        margin: '0 20PX',
        borderTop: hasBorder ? '.5PX solid #eee' : 'none',
        ...style,
      }}
    >
      {/* label */}
      <view
        style={{
          marginBottom: labelPosition == 'top' ? '8PX' : 0,
          // backgroundColor: 'blue',
          fontSize: '15PX',
          marginRight: '10PX',
          flex: 'none',
          ...labelStyle,
        }}
      >
        {label}
        {_required && (
          <text
            style={{
              marginLeft: '5PX',
              color: '#f30',
            }}
          >*</text>
        )}
      </view>
      {/* value */}
      <view
        style={{
          fontSize: '14PX',
          display: 'flex',
          alignItems: 'center',
          width: '100%',
          // backgroundColor: 'blue',
          justifyContent: labelPosition == 'top' ? 'flex-start' : 'flex-end',
          ...valueStyle,
        }}
      >
        {children}
        {!!suffix && (
          <view
            style={{
              marginLeft: '5PX',
              whiteSpace: 'nowrap',
            }}
          >{suffix}</view>
        )}
        {!!hasArrow && (
          <text
            class='iconfont-ysyc icon-dls_xz'
            style={{
              fontSize: '14PX',
              marginLeft: '5PX',
              color: '#ccc',
            }}
          />
        )}
      </view>
    </view>
  )
}
