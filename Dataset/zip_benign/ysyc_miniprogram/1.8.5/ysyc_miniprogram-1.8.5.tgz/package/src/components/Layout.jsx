
const { layoutStyle = {}, } = getTheme()
export default function({
  children,
  style = {},
  footer = '',
  footerStyle = {},
  titleBar = '',
  titleBarStyle = {},
  loading = false,
  isTab = false,
  scrollabled = true,
  id = '',
}) {
  const [ statusBarHeight, setStatusBarHeight, ] = useState(45)
  useEffect(() => {
    // 自定义titleBar才需要
    if (titleBar) {
      const _statusBarHeight = Taro.getSystemInfoSync().statusBarHeight
      setStatusBarHeight(_statusBarHeight)
    }
  }, [])
  if (loading) {
    return (
      <view
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
        }}
      >
        <Alert
          text
          title='加载中...'
        />
      </view>
    )
  }
  const _style = {
    paddingBottom: footer ? '60PX' : 0,
    paddingTop: titleBar ? `${statusBarHeight + 45}PX` : 0,
    boxSizing: 'border-box',
    // backgroundColor: '#f4f7f9',
    minHeight: '100vh',
    // height: '100vh',
    fontSize: '14PX',
    ...layoutStyle,
    ...style,
  }
  return (
    <>
      {!!titleBar && (
        <view
          style={{
            position: 'fixed',
            top: `${statusBarHeight}PX`,
            left: 0,
            right: 0,
            borderbottom: '1PX solid #eee',
            backgroundColor: '#fff',
            boxSizing: 'border-box',
            height: '45PX',
            zIndex: 999,
            // display: 'flex',
            // alignItems: 'center',
            // justifyContent: 'center',
            ...titleBarStyle,
          }}
        >
          {titleBar}
        </view>
      )}
      {!!footer && (
        <view
          class='footer'
          style={{
            position: 'fixed',
            borderTop: '1PX solid #eee',
            left: 0,
            right: 0,
            bottom: isTab ? 'calc(50PX + env(safe-area-inset-bottom))' : 'env(safe-area-inset-bottom)',
            padding: '10PX 15PX',
            zIndex: 99999,
            backgroundColor: '#fff',
            boxSizing: 'border-box',
            ...footerStyle,
          }}
        >
          {footer}
        </view>
      )}
      {scrollabled ?
        (
          <scroll-view
            id={id}
            style={_style}
          >
            {children}
          </scroll-view>
        ) :
        (
          <view
            id={id}
            style={_style}
          >
            {children}
          </view>
        )}
    </>
  )
}
