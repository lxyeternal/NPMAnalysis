import { useState, } from 'react'
import { noop, date as dateFormat, } from '../../service/utils'

import calendar, {
  isDate,
  isSameDay,
  isSameYear,
  isSameMonth,
  getDateISO,
  getNextMonth,
  getPreviousMonth,
  WEEK_DAYS,
  CALENDAR_MONTHS, 
} from './helper'

export default ({
  onChange = noop, multiple, initDate, format, onMonthChange = noop,
} = {}) => {
  // 获取最新状态
  const resolveStateFromDate = (date) => {
    const isDateObject = isDate(date)
    const _date = isDateObject ? date : new Date()
    let current = null
    if (multiple) {
      current = state?.current || []
      if (isDateObject) {
        current.push(dateFormat(date, format))
      }
    } else {
      current = isDateObject ? dateFormat(date, format) : null
    }

    return {
      current,
      month: +_date.getMonth() + 1,
      year: _date.getFullYear(),
    }
  }
  const [ state, _setState, ] = useState({
    ...resolveStateFromDate(initDate),
    today: new Date(),
  })
  
  const getCalendarDates = () => {
    const {
      current, month, year, 
    } = state
    const calendarMonth = month || +current.getMonth() + 1
    const calendarYear = year || current.getFullYear()

    return calendar(calendarMonth, calendarYear)
  }
  const setState = (args) => {
    _setState(prev => {
      const newState = {
        ...prev,
        ...args,
      }
      return newState
    })
  }
  const gotoDate = date => evt => {
    evt?.preventDefault()
    const { current, } = state
    const formatDate = dateFormat(date, format)
    if ((multiple && !current.includes(formatDate)) || current != formatDate) {
      setState(resolveStateFromDate(date))
      if (multiple) {
        onChange(current)
      } else {
        onChange(formatDate)
      }
    }
  }
  
  const gotoPreviousMonth = (cb = noop) => {
    const { month, year, } = state
    const newState = getPreviousMonth(month, year)
    setState(newState)
    if (typeof cb == 'function') {
      cb(newState)
    }
    onMonthChange(newState)
  }

  const gotoNextMonth = (cb = noop) => {
    const { month, year, } = state
    const newState = getNextMonth(month, year)
    setState(newState)
    if (typeof cb == 'function') {
      cb(newState)
    }
    onMonthChange(newState)
  }

  const gotoPreviousYear = () => {
    const { year, } = state
    setState({ year: year - 1, })
  }

  const gotoNextYear = () => {
    const { year, } = state
    setState({ year: year + 1, })
  }
  const getMonthname = () => {
    const { month, } = state
    const monthname = Object.keys(CALENDAR_MONTHS)[
      Math.max(0, Math.min(month - 1, 11))
    ]
    return monthname
  }
  return {
    state,
    setState,
    isSameDay,
    isSameMonth,
    gotoDate,
    getDateISO,

    isSameYear,
    WEEK_DAYS,

    getCalendarDates,

    gotoPreviousMonth,
    gotoNextMonth,
    gotoPreviousYear,
    gotoNextYear,
    getMonthname,
  }
}
