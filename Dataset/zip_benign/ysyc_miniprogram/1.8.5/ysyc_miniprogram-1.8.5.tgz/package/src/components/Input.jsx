
export default function({
  value, disabled, placeholder = '请输入', inputType, style = {}, focus,
  onChange = utils.noop, onInput = utils.noop, onFocus = utils.noop,
}) {
  const [ _value, setValue, ] = useState(value)
  useEffect(() => {
    setValue(value)
  }, [ value, ])
  return (
    <input
      disabled={disabled}
      focus={focus}
      password={inputType == 'password'}
      placeholder={placeholder}
      placeholder-style='color:#a8a8a8'
      style={{
        textAlign: 'right',
        color: disabled ? '#999' : '#333',
        ...style,
      }}
      type={inputType}
      value={_value}
      onBlur={(e) => {
        // 用onInput有问题
        const _val = e.detail.value
        setValue(_val)
        onChange(_val)
      }}
      onFocus={onFocus}
      onInput={(e) => {
        const _val = e.detail.value
        setValue(_val)
        onInput(_val)
      }}
    />
  )
}
