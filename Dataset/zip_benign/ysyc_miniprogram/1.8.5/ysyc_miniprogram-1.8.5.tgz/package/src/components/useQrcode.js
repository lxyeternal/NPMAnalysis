import qrcode from '../service/qrcode'

export default ({
  size = 120,
  id = 'myQrcode',
  foreground,
  correctLevel = 3,
  text: initText,
  ...args
} = {}) => {
  let timer
  const createQrcode = ({ text, ..._args } = {}) => {
    qrcode({
      width: size,
      height: size,
      canvasId: id,
      foreground,
      correctLevel,
      text: text || initText,
      ...args,
      ..._args,
    })
  }
  useEffect(() => {
    if (initText) {
      clearTimeout(timer)
      timer = setTimeout(() => {
        createQrcode()
      }, 0)
    }
    return () => {
      clearTimeout(timer)
    }
  }, [])
  const getQrcodePorps = (argsEx = { }) => {
    return {
      style: {
        width: utils.parseSize(size),
        height: utils.parseSize(size),
        backgroundColor: '#eee',
        // border: '.5PX solid #efefef',
      },
      width: size,
      height: size,
      canvasId: id,
      id,
      ...argsEx,
    }
  }
  //生成图片
  const saveImageToPhotosAlbum = () => {
    Taro.canvasToTempFilePath({
      canvasId: id,
      // fileType: 'jpg',
      success: function(res) {
        let filePath = res.tempFilePath
        Taro.saveImageToPhotosAlbum({
          filePath,
          success(rs) {
            console.log(rs)
          },
          fail(rs) {
            console.log(rs)
          },
        })
      },
      fail(res) {
      },
    })
  }
  return {
    getQrcodePorps,
    createQrcode,
    saveImageToPhotosAlbum,
  }
}
