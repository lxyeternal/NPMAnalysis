
export default function(props) {
  return (
  // eslint-disable-next-line react/forbid-elements
    <textarea
      autoHeight
      maxlength={-1}
      placeholder-style='color:#a8a8a8'
      {...props}
      style={{
        minHeight: '100PX',
        border: '1PX solid #eee',
        padding: '10PX',
        color: '#333',
        width: '100%',
        lineHeight: '24PX',
        boxSizing: 'border-box',
        borderRadius: '3PX',
        // backgroundColor: '#f1f1f1',
        ...(props.style || {}),
      }}
      onBlur={(v) => {
        if (props.onChange) {
          props.onChange(v.detail.value)
        }
      }}
      onInput={(v) => {
        if (props.onInput) {
          props.onInput(v.detail.value)
        }
      }}
    />
  )
}
