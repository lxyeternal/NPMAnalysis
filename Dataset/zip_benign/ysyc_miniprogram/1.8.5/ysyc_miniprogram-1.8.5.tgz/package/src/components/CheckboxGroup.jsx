
export default function({
  data, value = [], onChange = utils.noop, checkboxItemStyle = {}, checkboxStyle = {}, checkboxType = '',
}) {
  const { getItemInfo, } = useCheckboxGroup({
    value,
    onChange,
  })
  if (!data) {
    return <view>请先设置data!</view>
  }
  return (
    <view
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        ...checkboxStyle,
      }}
    >
      {data.map((item, i) => {
        const {
          isActive,
          onClickItem,
        } = getItemInfo(item, i)
        if (checkboxType == 'capsule') {
          return (
            <CapsuleItem
              key={i}
              active={isActive}
              style={checkboxItemStyle}
              title={item.type_name}
              onClick={onClickItem}
            />
          )
        }
        return (
          <Checkbox
            key={i}
            label={item.type_name}
            style={{
              marginRight: '15PX',
              ...checkboxItemStyle,
            }}
            value={isActive}
            onChange={onClickItem}
          />
        )
      })}
    </view>
  )
}
