
export default function({
  title = '', modalTitle, modalContent, show = false, onClose = utils.noop, onShow = utils.noop, closeOnClickModal = true,
  position = 'bottom',
  style = {}, modalStyle = {}, modalContentStyle = {},
  destroyOnClose = true,
} = {}) {
  const [ _show, setShow, ] = useState(show)
  useEffect(() => {
    setShow(show)
  }, [ show, ])
  useEffect(() => {
    if (!_show) {
      onClose()
    } else {
      onShow()
    }
  }, [ _show, ])
  if (position == 'center') {
    modalStyle = {
      alignItems: 'center',
      justifyContent: 'center',
      ...modalStyle,
    }
    modalContentStyle = {
      borderRadius: '10PX',
      width: '80%',
      ...modalContentStyle,
    }
  }
  const _modal = () => {
    if (!_show && destroyOnClose) {
      return false
    }
    return (
      <view
        style={{
          backgroundColor: 'rgba(0,0,0,.6)',
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          zIndex: 999999,
          display: destroyOnClose ? 'flex' : (_show ? 'flex' : 'none'),
          alignItems: 'flex-end',
          ...modalStyle,
        }}
        onClick={() => {
          if (closeOnClickModal) {
            setShow(false)
          }
          // e.stopPropagation()
        }}
      >
        <view
          style={{
            width: '100%',
            flex: 'none',
            backgroundColor: '#fff',
            borderRadius: '5PX 5PX 0 0',
            boxSizing: 'border-box',
            ...modalContentStyle,
          }}
          onClick={(e) => {
            e.stopPropagation()
          }}
        >
          {typeof modalTitle == 'function' ?
            modalTitle(setShow) :
            modalTitle && (
              <view
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  height: '40PX',
                  padding: '0 25px 0 15px',
                  borderBottom: '.5PX solid #eee',
                  position: 'relative',
                }}
              >
                <view
                  style={{
                    fontSize: '14PX',
                    // fontWeight: 'bold',
                    color: '#666',
                  }}
                > {modalTitle}</view>
                <view
                  class='icon-guanbi iconfont-ysyc'
                  style={{
                    color: '#ccc',
                    position: 'absolute',
                    right: '10PX',
                    top: '10PX',
                    lineHeight: 1.2,
                  }}
                  onClick={() => {
                    setShow(false)
                  }}
                />
              </view>
            )}
          {modalContent?.(setShow) ?? '请设置modalContent!'}
        </view>
      </view>
    )
  }
  if (!title) {
    return _modal()
  }
  return (
    <view style={style}>
      {typeof title == 'function' ?
        title(setShow, _show) :
        (
          <view
            onClick={() => {
              setShow(!_show)
            }}
          >
            {title}
          </view>
        )}
      {_modal()}
    </view>
  )
}
