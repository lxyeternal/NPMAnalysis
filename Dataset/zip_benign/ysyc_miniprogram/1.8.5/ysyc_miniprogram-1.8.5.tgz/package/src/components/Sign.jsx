
export default function({
  disabled, value, onChange, style = {},
}) {
  const { getCanvasProps, } = useSign({
    onSave: () => {

    },
  })
  useEffect(() => {
    // 默认值
    if (onChange && !value) {
      const _val = Taro.getStorageSync('sign')
      if (_val) {
        onChange(_val)
      }
    }
  }, [])
  if (value) {
    return (
      <Image
        src={value}
        style={{
          width: '100%',
          height: '100%',
          ...style,
        }}
      />
    )
  }
  return <canvas {...getCanvasProps({ style, })} />
}
