
export default function({
  value, style = {}, onChange = utils.noop, inputStyle = {},
}) {
  const [ _value, _setValue, ] = useState(value)
  useEffect(() => {
    _setValue(value)
  }, [ value, ])
  const setValue = (val) => {
    _setValue(val)
    onChange(val)
  }
  return (
    <view
      style={{
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'center',
        lineHeight: '26PX',
        ...style,
      }}
    >
      <view
        class='iconfont-ysyc icon-reduce'
        style={{
          fontSize: '18PX',
          width: '26PX',
          textAlign: 'center',
        }}
        onClick={() => {
          if (_value > 1) {
            setValue(_value - 1)
          }
        }}
      />
      <Input
        placeholder=''
        style={{
          padding: '2PX 5PX',
          textAlign: 'center',
          background: '#F2F2F2',
          margin: '0 5PX',
          fontSize: '16PX',
          width: '60PX',
          ...inputStyle,
        }}
        type='number'
        value={_value}
        onChange={(val) => {
          setValue(val)
        }}
      />
      <view
        class='iconfont-ysyc icon-plus'
        style={{
          fontSize: '18PX',
          width: '26PX',
          textAlign: 'center',
        }}
        onClick={() => {
          setValue(_value + 1)
        }}
      />
    </view>
  )
}
