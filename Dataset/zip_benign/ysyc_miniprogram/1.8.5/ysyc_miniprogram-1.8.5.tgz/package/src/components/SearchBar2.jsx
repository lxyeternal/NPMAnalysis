
export default function({
  style = {},
  url, onActive = utils.noop, params = {},
  placeholder = '请输入关键词查询', value: _value, keyWord = 'q',
  renderItem = utils.noop, //
  extraHeight = 60,
  active: _active,
}) {
  const [ value, setValue, ] = useState(_value)
  const [ active, setActive, ] = useState(false)
  useEffect(() => {
    setActive(_active)
  }, [])
  const {
    list, setParams, reload,
  } = useList({
    autoLoad: false,
    url,
    data: params,
  })
  return (
    <>
      <view
        style={{
          display: 'flex',
          alignItems: 'center',
          padding: '10PX 15PX',
          boxSizing: 'border-box',
          height: '60PX',
          borderBottom: '1PX solid #e5e5e5',
          backgroundColor: '#fff',
          ...style,
        }}
      >
        <view
          style={{
            backgroundColor: '#F1F2F6',
            padding: '0 15PX',
            borderRadius: '18PX',
            fontSize: '14PX',
            color: '#999',
            display: 'flex',
            alignItems: 'center',
            height: '36PX',
            flex: 1,
          }}
          onClick={() => {
          // Taro.redirectTo({ url, })
          }}
        >
          <view
            class='icon-sy_sousuo iconfont-ysyc'
            // key='search'
            style={{
              marginRight: '5PX',
              fontSize: '14PX',
            }}
          />
          <input
            placeholder={placeholder}
            style={{
              // backgroundColor: 'red',
              flex: 1,
            }}
            value={value}
            onClick={() => {
              if (!active) {
                reload()
                setActive(true)
                onActive(true)
              }
            }}
            onInput={(e) => {
              const _val = e.detail.value
              setValue(_val)
              setParams({ [keyWord]: _val, })
            }}
          />
          {!!value && (
            <view
              class='icon-dl_qc iconfont-ysyc'
              style={{
                marginLeft: 'auto',
                color: '#a8a8a8',
              }}
              onClick={() => {
                setValue('')
                setParams({ [keyWord]: -999, })
              }}
            />
          )}
        </view>
        {active && (
          <Button
            style={{ marginLeft: '15PX', }}
            title='取消'
            type='text-primary'
            onClick={() => {
              setActive(false)
              setValue('')
              onActive(false)
            }}
          />
        )}
      </view>
      {active && (
        <view
          style={{
            backgroundColor: '#fff',
            height: `calc(100vh - ${utils.parseSize(extraHeight)})`,
            overflow: 'auto',
          }}
        >
          {list.map(renderItem)}
        </view>
      ) }
    </>
  )
}
