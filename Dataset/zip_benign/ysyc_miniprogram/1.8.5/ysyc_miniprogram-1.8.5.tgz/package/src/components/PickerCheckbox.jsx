const { primary, } = getTheme()

export default function({
  placeholder = '请选择', disabled, data, onChange, value: _value = [], titleStyle = {}, modalTitle = '请选择', clickBefore, renderTitle, renderItemTitle,
}) {
  const {
    getItemInfo, getTitle, value,
  } = useCheckboxGroup({
    data,
    value: _value,
    // onChange,
  })

  const [ title, setTitle, ] = useState(getTitle(_value))
  return (
    <Modal
      modalContent={() => (
        <view
          style={{
            maxHeight: '50vh',
            overflow: 'auto',
            padding: '10PX',
          }}
        >
          <view>
            {data?.map((item, i) => {
              const { isActive, onClickItem, } = getItemInfo(item, i)
              return (
                <IconButton
                  key={i}
                  icon={isActive ? 'icon-dls_danx01' : 'icon-dls_dx02'}
                  style={{
                    textAlign: 'center',
                    height: '42PX',
                    lineHeight: '42PX',
                    color: isActive ? primary : '#444',
                    borderBottom: '.5PX solid #fafafa',
                  }}
                  onClick={() => {
                    onClickItem()
                  }}
                >
                  {renderItemTitle?.(
                    item, i, isActive
                  ) ?? item.type_name}
                </IconButton>
              )
            }) ?? <view>请先设置data!</view>}
          </view>
        </view>
      )}
      modalTitle={(show) => {
        return (
          <view
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '10PX',
              color: '#555',
            }}
          >
            <view onClick={() => show(false)}>
            取消
            </view>
            <view
              style={{ fontWeight: 'bold', }}
            >
              {modalTitle}
            </view>
            <view
              onClick={() => {
                onChange(value)
                setTitle(getTitle(value))
                show(false)
              }}
            >
            确定
            </view>
          </view>
        )
      }}
      title={(show) => (
        <view
          style={{
            color: (title && !disabled) ? 'inherit' : '#999',
            // textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            height: '24PX',
            overflow: 'hidden',
            lineHeight: '24PX',
            // backgroundColor: 'blue',
            ...titleStyle,
          }}
          onClick={() => {
            if (!disabled) {
              if (clickBefore) {
                clickBefore(show)
              } else {
                show(true)
              }
            }
          }}
        >{renderTitle?.({ title, }) || (title ?? placeholder)}</view>
      )}
    />
  )
}
