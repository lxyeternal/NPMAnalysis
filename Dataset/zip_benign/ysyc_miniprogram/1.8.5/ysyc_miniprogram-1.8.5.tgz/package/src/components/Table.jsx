/* eslint-disable complexity */

export default function({
  style = {},
  labelWidth,
  // labelPosition = 'left',
  itemStyle = {},
  itemLabelStyle = {},
  itemValueStyle = {},
  iconStyle = {},
  itemWidth,
  hasBorder,
  hasArrow = false,
  data = {},
  isList = false,
  items,
}) {
  const { fieldTitle, } = useCategory()
  const _getShow = (item) => {
    if (typeof item.show == 'function') {
      return item.show(data ?? {})
    }
    return item.show ?? true
  }
  if (isList) {
    hasBorder = hasBorder ?? true
  }
  return (
    <view
      style={{
        fontSize: '15PX',
        display: 'flex',
        flexWrap: 'wrap',
        ...style,
      }}
    >
      {items.map((item, i) => {
        if (!_getShow(item)) {
          return false
        }
        if (item.type == 'block') {
          return item.render()
        }

        if (item.type == 'line') {
          return (
            <Divider key={i} />
          )
        }
        if (item.type == 'gap') {
          return (
            <Gap key={i} />
          )
        }
        // 原始值
        let _val = utils.getObjectValue(data, item.prop)
        // 渲染后的值
        let itemValue
        if (item.hasOwnProperty('render')) {
          itemValue = typeof item.render == 'function' ?
            item.render({
              value: _val,
              row: data,
              fieldTitle,
            }) :
            item.render
        } else if (item.type == 'date') {
          itemValue = utils.date(_val, 'YYYY-MM-DD')
        } else if (item.type == 'dateTime') {
          itemValue = utils.date(_val)
        } else if (item.type == 'fieldTitle') {
          itemValue = (
            <>
              {item.prefix ?? ''} {fieldTitle({
                value: _val,
                prop: item.alias ?? item.prop,
                data: item.data,
                render: (it) => {
                  return <text class={it.color}>{it.type_name}</text>
                },
              })}
            </>
          )
        } else if (item.type == 'image') {
          item.style = {
            flexDirection: 'column',
            alignItems: 'flex-start',
          }
          item.valueStyle = {
            marginTop: '10PX',
            marginLeft: '0',
            width: '100%',
          }
          itemValue = <Images value={_val} />
        } else {
          itemValue = <>{item.prefix ?? ''}{_val ?? item.value ?? ''}</>
        }
        return (
          <view
            key={i}
            style={{
              display: 'flex',
              padding: isList ? '15PX 0' : '6PX 0',
              width: itemWidth ?? (item.width ?? '100%'),
              borderTop: (hasBorder && i > 0) ? '.5PX solid #e5e5e5' : 'none',
              alignItems: 'center',
              ...itemStyle,
              ...(item.style ?? {}),
            }}
            onClick={item.onClick ?? (() => null)}
          >
            {!!item.icon && (
              <view
                class={`${item.icon.includes('iconfont-ysyc') ? '' : 'iconfont'} ${item.icon}`}
                style={{
                  fontSize: '24PX',
                  marginRight: '10PX',
                  color: item.iconColor,
                  ...iconStyle,
                }}
              />
            )}
            <view
              style={{
                color: isList ? '#333' : '#999',
                flex: 'none',
                marginRight: '5PX',
                width: utils.parseSize(labelWidth) ?? 'auto',
                ...itemLabelStyle,
                ...(item.labelStyle ?? {}),
              }}
            >{item.label}</view>
            <view
              style={{
                marginLeft: isList ? 'auto' : 0,
                color: isList ? '#999' : '#333',
                ...itemValueStyle,
                ...(item.valueStyle ?? {}),
              }}
            >{itemValue}</view>
            <view
              style={{ marginLeft: '5PX', }}
            >{item.suffix}</view>
            {(item.hasArrow ?? hasArrow) && (
              <view
                class='icon-dls_xz iconfont-ysyc'
                style={{
                  marginLeft: '5PX',
                  fontSize: '16PX',
                  color: '#aaa',
                  ...(item.arrowStyle ?? {}),
                }}
              />
            )}
          </view>
        )
      })}
    </view>
  )
}
