
const { primary, } = getTheme()

export default function({
  placeholder = '请选择', disabled, data = [], onChange = () => null, value, titleStyle = {}, modalTitle = '请选择', clickBefore, renderTitle, renderItemTitle, style = {}, renderAppend, onClose = () => null,
  firstItem, lastItem,
}) {
  /* const firstItem = {
    type_id: -999,
    type_name: '全部',
  } */
  const [ title, setTitle, ] = useState()
  const [ _value, setValue, ] = useState(value)
  const allData = [ ...data, ]
  if (firstItem) {
    allData.unshift(firstItem)
  }
  if (lastItem) {
    allData.push(lastItem)
  }
  useEffect(() => {
    setValue(value)
    const { type_name: typeName, } = allData.find(item => item.type_id == value) ?? {}
    setTitle(typeName)
  }, [ value, ])
  const itemStyle = {
    textAlign: 'center',
    height: '42PX',
    lineHeight: '42PX',
    color: primary,
  }
  return (
    <Modal
      modalContent={(show) => (
        <view
          style={{
            maxHeight: '50vh',
            overflow: 'auto',
            padding: '10PX',
          }}
        >
          <view>
            {data.length ?
              allData.map((item, i) => {
                const isActive = item.type_id == _value
                return (
                  <view
                    key={i}
                    style={{
                      ...itemStyle,
                      color: isActive ? primary : '#444',
                      borderBottom: '.5PX solid #fafafa',
                      ...(item.style ?? {}),
                    }}
                    onClick={(() => {
                      if (item.onClick) {
                        item.onClick?.(show, value)
                      } else if (item.type_id == -888) {
                        show(false)
                      } else {
                        show(false)
                        if (onChange) {
                          const _val = isActive ? value : item.type_id
                          // const _val = isActive ? -999 : item.type_id
                          setValue(_val)
                          setTitle(item.type_name)
                          onChange(_val, isActive ? {} : item)
                        }
                      }
                    })}
                  >
                    {renderItemTitle?.(
                      item, i, isActive
                    ) ?? item.type_name}
                  </view>
                )
              }) :
              (
                <view
                  style={{ textAlign: 'center', }}
                >没有数据!</view>
              )}
            {renderAppend?.(show, itemStyle)}
          </view>
        </view>
      )}
      modalTitle={modalTitle}
      style={style}
      title={(show) => (
        <view
          style={{
            color: (title && !disabled) ? '#333' : '#a8a8a8',
            // textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            height: '24PX',
            overflow: 'hidden',
            lineHeight: '24PX',
            // backgroundColor: 'blue',
            ...titleStyle,
          }}
          onClick={() => {
            if (!disabled) {
              if (clickBefore) {
                clickBefore(show)
              } else {
                show(true)
              }
            }
          }}
        >{renderTitle?.({ title, }) || (title ?? placeholder)}</view>
      )}
      onClose={onClose}
    />
  )
}
