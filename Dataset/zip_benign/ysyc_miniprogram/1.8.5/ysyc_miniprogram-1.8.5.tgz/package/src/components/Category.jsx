export default function({
  placeholder = '请选择', disabled, data = [], onChange = () => null, value, titleStyle = {},
  modalTitle = '请选择', url, params = {},
  // level = 2, pid = 0,
  props = {
    children: 'children',
    label: 'name',
    value: 'id',
  },
}) {
  const [ _value, setValue, ] = useState([])
  const [ _data, setData, ] = useState(data)
  const [ _title, setTitle, ] = useState()

  const _getParent = (
    val, d = [], parent = [], lvl = 0
  ) => {
    if (!val) {
      return []
    }
    for (let i = 0; i < d.length; i++) {
      if (lvl == 0) {
        parent = []
      }
      const item = d[i]
      if (item[props.value] == val) {
        parent.push(item)
        break
      } else if (item[props.children]) {
        parent.push(item)
        const _parent = _getParent(
          val, item[props.children], parent, lvl + 1
        )
        if (_parent.length > lvl + 1) {
          break
        } else {
          parent.pop()
        }
      }
    }
    return [ ...parent, ]
  }
  useEffect(() => {
    const _parent = _getParent(value, _data)
    setValue(_parent.map(item => item[props.value]))
    setTitle(_parent.map(item => item[props.label]).join(' - '))
  }, [ value, _data, ])

  useEffect(() => {
    if (!data.length) {
      _getData()
    }
  }, [])

  const _getData = () => {
    if (_data.length) {
      return
    }
    ajax({
      url,
      data: { ...params, },
    }).then(res => {
      setData(res.data.list || res.data)
    })
  }

  const _subData = (id) => {
    const _item = _data.find(item => item[props.value] == id) ?? {}
    return _item.children ?? []
  }
  const renderItems = ({
    data: itemData = [], style = {}, value: val, onClick = () => null,
  }) => {
    return (
      <view
        style={{
          height: '100%',
          overflow: 'auto',
          borderLeft: '.5PX solid #eee',
          flex: 1,
          ...style,
        }}
      >
        {itemData.map((item, i) => {
          const isActive = val.includes(item[props.value])
          return (
            <view
              key={i}
              style={{
                textAlign: 'center',
                height: '42PX',
                lineHeight: '42PX',
                color: isActive ? '#eaa218' : '#444',
                borderBottom: '.5PX solid #fafafa',
              }}
              onClick={() => {
                onClick(item)
              }}
            >
              {item[props.label]}
            </view>
          )
        })}
      </view>
    )
  }

  return (
    <Modal
      modalContent={(show) => (
        <view
          style={{
            height: '40vh',
            padding: '10PX',
            display: 'flex',
          }}
        >
          {renderItems({
            data: _data,
            style: { borderLeft: 'none', },
            value: _value,
            onClick(item) {
              setValue([ item[props.value], ])
              // 只有一级
              if (!item[props.children] || !item[props.children].length) {
                onChange(item[props.value], item)
                show(false)
              }
            },
          })}
          {renderItems({
            data: _subData(_value[0]),
            value: _value,
            onClick(item) {
              setValue(prev => {
                prev[1] = item[props.value]
                return [ ...prev, ]
              })
              onChange(item[props.value], item)
              show(false)
            },
          })}
        </view>
      )}
      modalTitle={modalTitle}
      title={(show) => (
        <view
          style={{
            color: (_title && !disabled) ? '#333' : '#a8a8a8',
            // textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            height: '24PX',
            overflow: 'hidden',
            lineHeight: '24PX',
            // backgroundColor: 'blue',
            ...titleStyle,
          }}
          onClick={() => {
            if (!disabled) {
              show(true)
            }
          }}
        >{_title || placeholder}</view>
      )}
    />
  )
}
