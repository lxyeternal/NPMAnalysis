
const gblen = function(value) {
  const _str = String(value)
  let len = 0
  for (let i = 0; i < _str.length; i++) {
    if (_str.charCodeAt(i) > 127 || _str.charCodeAt(i) == 94) {
      len += 2
    } else {
      len ++
    }
  }
  return len
}
export default ({
  url,
  data: initParams = {},
  ajaxThen = utils.noop,
  ajaxCatch = utils.noop,
  transformData = utils.noop,
  ajaxBefore,
  message = true,
  ajaxThenBack = 0,
} = {}) => {
  const [ formData, setFormData, ] = useState(initParams)
  const [ loading, setLoading, ] = useState(false)
  const validateOptions = useRef({})
  const validateItem = (value = '', rule = {}) => {
    if (rule.required) {
      if ((rule.type == 'array' && !value.length) || !value) {
        return rule.message || '必填！'
      }
    } else if (rule.maxLength < value.length) {
      return rule.message
    } else if (rule.minLength > value.length) {
      return rule.message
    } else if (rule.maxGbLength < gblen(value)) {
      return rule.message
    } else if (rule.minGbLength > gblen(value)) {
      return rule.message
    } else if (rule.max < +value) {
      return rule.message
    } else if (rule.min > +value) {
      return rule.message
    } else if (rule.validator) {
      const _msg = rule.validator(
        value, rule, formData
      )
      if (_msg) {
        return _msg
      }
    }
  }
  const validate = (keys = []) => {
    if (process.env.NODE_ENV == 'development') {
      console.log('formData：', formData)
    }
    const messages = []
    const _keys = keys.length ? keys : Object.keys(validateOptions.current)
    _keys.forEach(k => {
      if (Array.isArray(validateOptions.current[k])) {
        validateOptions.current[k].forEach(function(rule) {
          let result = validateItem(formData[k], rule)
          if (result) {
            messages.push(result)
          }
        })
      } else {
        let result = validateItem(formData[k], validateOptions.current[k])
        if (result) {
          messages.push(result)
        }
      }
    })
    if (messages.length) {
      Taro.showToast({
        title: messages[0],
        icon: 'none',
        duration: 2000,
      })
      return false
    }
    return true
  }
  // let timer = useRef()
  const _handleSubmit = ({
    title, icon, duration, ajaxThen: onSubmitted, hasOnBefore = true,
  } = {}) => {
    if (loading) {
      return
    }
    const _formData = { ...formData, }
    // 使用next方便onBefore中处理异步
    const _next = (...args) => {
      _handleSubmit({
        hasOnBefore: false,
        ...args,
      })
    }
    // clearTimeout(timer.current)
    // timer.current = setTimeout(() => {
    // 提交前的数据处理
    if (hasOnBefore && ajaxBefore?.(_formData, _next) === false) {
      return
    }
    if (!validate()) {
      return
    }
    setLoading(true)
    ajax({
      url,
      method: 'POST',
      data: _formData,
      message,
      toast: {
        title,
        icon,
        duration,
      },
    }).then(res => {
      if (res.code == configs.RESULT_TEMPLATE.code) {
        ajaxThen(res, formData)
        if (ajaxThenBack) {
          wx.navigateBack()
        }
        if (onSubmitted) {
          onSubmitted(res)
        }
      }
      setLoading(false)
    }).catch((res) => {
      ajaxCatch(res, formData)
      setLoading(false)
      Taro.showToast({
        title: res.msg || (res.errMsg?.includes('domain list') ? '域名无效!' : res.errMsg) || res.errorMessage,
        icon: 'none',
        duration: 2000,
      })
    })
    // }, 300)
  }

  const SubmitButton = (props) => {
    const showLoading = props.showLoading ?? true
    return (
      <Button
        loading={showLoading ? loading : false}
        type='primary'
        {...props}
        onClick={() => {
          if (props.onClick) {
            props.onClick(_handleSubmit)
          } else {
            _handleSubmit({
              ...props.toast,
              ajaxThen: props.onSubmitted,
            })
          }
        }}
      >
        {props.title}
      </Button>
    )
  }
  const _setFormData = (now) => {
    let isReset = !Object.keys(now).length
    if (isReset) {
      setFormData(initParams)
      return
    }
    Object.keys(now).forEach(key => {
      utils.setObjectValue(
        formData, key, now[key]
      )
    })
    // setFormData({ ...formData, })
    setFormData(prev => {
      return {
        ...prev,
        ...formData,
      }
    })
  }

  return {
    formData,
    SubmitButton,
    submit: _handleSubmit,
    validate,
    setFormData: _setFormData,
    validateOptions,
    formProps: {
      validateOptions,
      setFormData: _setFormData,
      formData,
    },
    loading,
  }
}
