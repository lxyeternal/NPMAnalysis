
export default function({
  style = {}, iconStyle = {}, icon = 'icon-dls_xz', onClick = utils.noop, title, children, disabled = false, type,
}) {
  title = title || children
  if (type) {
    style.color = style.color || getTheme(type)
  }
  const _onClick = () => {
    if (!disabled) {
      onClick()
    }
  }
  const _icon = (
    <view
      class={icon.includes('iconfont') ? icon : `iconfont-ysyc ${icon}`}
      style={{
        color: disabled ? '#888' : (style.color || 'inherit'),
        fontSize: style.fontSize ?? 'inherit',
        ...(title ? iconStyle : style),
      }}
      onClick={!title ? _onClick : utils.noop}
    />
  )
  if (!title) {
    return _icon
  }
  return (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        ...style,
        color: disabled ? '#888' : (style.color || 'inherit'),
      }}
      onClick={_onClick}
    >
      {_icon}
      {title && (
        <view
          style={{ width: '5PX', }}
        />
      )}
      {title}
    </view>
  )
}
