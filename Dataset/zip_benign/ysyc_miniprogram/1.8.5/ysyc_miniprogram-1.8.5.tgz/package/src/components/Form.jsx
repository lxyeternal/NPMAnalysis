
export default function({
  items, style = {}, footer, footerStyle = {},
  itemStyle = {}, valueStyle, labelStyle, labelPosition, formData: _formData,
  setFormData: _setFormData, validateOptions = { current: {}, },
}) {
  /* const [ _formData, _setFormData, ] = useState(formData)*/
  /* useEffect(() => {
        console.log('formData1', _formData)
        // _setFormData(formData)
    }, _formData) */
  const { getCategory, } = useCategory()
  if (!items.length) {
    return (
      <view>请先设置items!</view>
    )
  }

  const _getCategory = (item) => {
    if (item.data) {
      return item.data
    }
    return getCategory(item.alias || item.name, item)
  }
  const _onChange = (
    item, val, ...args
  ) => {
    _setFormData({ [item.name]: val, })
    if (item.onChange) {
      item.onChange(val, ...args)
    }
  }
  // eslint-disable-next-line complexity
  const renderItem = (item, i) => {
    const _value = utils.getObjectValue(_formData, item.name)
    if (!utils.parseShow(item, _formData)) {
      delete validateOptions.current[item.name]
      return false
    }
    if (item.rules) {
      validateOptions.current[item.name] = item.rules
    }
    if (i == 0) {
      // 第一个无边框
      item.hasBorder = item.hasBorder ?? false
    }
    if (item.type == 'gap') {
      return <Gap />
    }
    if (item.type == 'block') {
      item.hasBorder = item.hasBorder ?? true
      return (
        <view
          style={{
            padding: '10PX 0',
            margin: '0 20PX',
            borderTop: item.hasBorder ? '.5PX solid #eee' : 'none',
            ...item.itemStyle,
          }}
        >
          {item.render({
            renderItem,
            data: _formData,
            setFormData: _setFormData,
          })}
        </view>
      )
    }
    let _child

    // 默认值初始化
    /*  if (item.value !== undefined) {
            if (!_formData[item.name]) {
                _setFormData({ [item.name]: item.value, })
            }
        } */
    if (item.render) {
      _child = item.render({
        _formData,
        setFormData: _setFormData,
      })
    } else if (item.type == 'radio') {
      item.labelPosition = item.labelPosition ?? 'top'
      _child = (
        <RadioGroup
          data={_getCategory(item)}
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(
              item, val, _setFormData
            )
          }}
        />
      )
    } else if (item.type == 'checkbox') {
      item.labelPosition = item.labelPosition ?? 'top'
      _child = (
        <CheckboxGroup
          checkboxStyle={{ flex: 1, }}
          data={_getCategory(item)}
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'capsuleGroup') {
      item.labelPosition = item.labelPosition ?? 'top'
      _child = (
        <CapsuleGroup
          data={_getCategory(item)}
          itemStyle={{
            marginRight: '10PX',
            marginBottom: '10PX',
            fontSize: '12PX',
          }}
          style={{ flex: 1, }}
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'picker') {
      item.hasArrow = true
      _child = (
        <Picker
          data={_getCategory(item)}
          value={_value}
          {...item}
          onChange={(val, activeItem) => {
            _onChange(
              item, val, activeItem, _setFormData
            )
          }}
        />
      )
    } else if (item.type == 'pickerCheckbox') {
      item.hasArrow = true
      _child = (
        <PickerCheckbox
          data={_getCategory(item)}
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'category') {
      item.hasArrow = true
      _child = (
        <Category
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'pagePicker') {
      item.hasArrow = true
      _child = (
        <PagePicker
          value={_value}
          {...item}
          onChange={(val, args) => {
            _onChange(
              item, val, args
            )
          }}
        />
      )
    } else if (item.type == 'date') {
      item.hasArrow = true
      _child = (
        <PickerDate
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'area') {
      item.hasArrow = true
      _child = (
        <Area
          value={_value}
          {...item}
          onChange={(val, nextData) => {
            _onChange(
              item, val, nextData
            )
          }}
        />
      )
    } else if (item.type == 'image') {
      item.labelPosition = item.labelPosition ?? 'top'
      _child = (
        <Upload
          value={_value}
          {...item}
          type={item.uploadType ?? 'image'}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'textarea') {
      item.labelPosition = item.labelPosition ?? 'top'
      _child = (
        <Textarea
          value={_value}
          {...item}
          // onChange={(val) => {
          onInput={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'sign') {
      item.label = item.label ?? '签字'
      _child = (
        <Sign
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else if (item.type == 'switch') {
      _child = (
        <Switch
          value={_value}
          {...item}
          onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    } else {
      _child = (
        <Input
          value={_value}
          {...item}
          onInput={(val) => {
            // onChange={(val) => {
            _onChange(item, val)
          }}
        />
      )
    }
    _child = getFormItem({
      item,
      onChange: _onChange,
      type: item.type,
      value: _value,
      getCategory: _getCategory,
    }) ?? _child

    return (
      <FormItem
        key={i}
        hasArrow={item.hasArrow}
        hasBorder={item.hasBorder}
        label={item.label}
        labelPosition={item.labelPosition || labelPosition}
        labelStyle={item.labelStyle || labelStyle}
        rules={item.rules}
        style={item.formItemStyle || item.itemStyle || itemStyle}
        suffix={item.suffix}
        valueStyle={item.valueStyle || valueStyle}
      >
        {_child}
      </FormItem>
    )
  }

  return (
    <>
      <view
        scrollTop={300}
        style={{
          backgroundColor: '#fff',
          margin: '10PX 0',
          ...style,
        }}
      >
        {items.map(renderItem)}
      </view>
      {!!footer && (
        <view
          style={{
            padding: '0 20PX',
            margin: '10PX 0',
            ...footerStyle,
          }}
        >{footer}</view>
      )}
    </>
  )
}
