
export default function({
  onChange = utils.noop, disabled, value, activeColor = '#eaa218', blockColor = '#eaa218', blockSize = 18, showValue = false, min = 0, max = 100,
}) {
  // const [ _value, setValue, ] = useState(value)
  // useEffect(() => {
  //     setValue(value)
  // }, [ value, ])
  return (
    <view
      class='text-muted'
    >
      <slider
        activeColor={activeColor}
        blockColor={blockColor}
        blockSize={blockSize}
        disabled={disabled}
        max={max}
        min={min}
        showValue={showValue}
        style={{
          marginLeft: '5PX',
          width: '100PX',
        }}
        value={value}
        onChange={(e) => {
          onChange(+e.detail.value)
        }}
      />
    </view>
  )
}
