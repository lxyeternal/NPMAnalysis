/**
 * 加载列表数据
 * @param  {String}   options.url      请求的url
 * @param  {Object}   options.data:    initParams    提交的参数
 * @param  {Function} options.ajaxThen 回调函数
 * @param  {Boolean}   autoLoad=true   自动加载数据
 * @return {Object}   result           结果
 * @return {Array}   result.list       数据
 * @return {Object}   result.page      分页
 * @return {Function}   result.setParams 设置参数，设置后会重新请求数据
 * @return {Function}   result.reload  重新请求数据
 * @return {Boolean}   result.loading  请求数据时的状态
 * @return {Object}   result.props     content的props
 *
 */

export default ({
  url,
  data: initParams,
  defaultData = {},
  ajaxBefore = () => true,
  ajaxThen = () => null,
  ajaxCatch = () => null,
  autoLoad: initAutoLoad = true,
  message = false,
  didShow = false,
  message401 = true,
  method = 'GET',
}) => {
  const [ data, _setData, ] = useState(defaultData)
  initParams = Object.assign({}, initParams)
  const [ params, _setParams, ] = useState(initParams)

  const autoLoad = useRef(didShow ? false : initAutoLoad)
  const [ loading, _setLoading, ] = useState(false)
  const _url = useRef(url)
  const cancel = useRef(() => null)
  // let cancel = () => {}

  useEffect(() => {
    // 第一次是否加载
    if (autoLoad.current) {
      getData()
    } else {
      autoLoad.current = true
    }
    return () => {
      cancel.current()
    }
  }, [ params, autoLoad, ])

  useDidShow(() => {
    if (didShow) {
      getData()
    }
  })
  const getData = async() => {
    if (!_url.current) {
      console.log('url 不存在！')
      return
    }
    if (loading) {
      return
    }
    // 处理多次请求，只处理最后一次
    if (cancel.current) {
      cancel.current()
    }
    _setLoading(true)
    // 删除多余的参数
    delete params.counter
    if (!ajaxBefore(params)) {
      return false
    }
    let res
    try {
      res = await ajax({
        url: _url.current,
        data: { ...params, },
        message,
        message401,
        method,
        cancelFn: (cb) => cancel.current = cb,
      })
      _setData({
        ...defaultData,
        ...res.data,
      })
      ajaxThen(res, { setData, })
    } catch (err) {
      ajaxCatch(err)
    }
    _setLoading(false)
  }
  const setParams = (now, override = false) => {
    _setParams((prev) => {
      if (typeof now == 'function') {
        return now(prev)
      }
      if (override) {
        return now
      }
      return {
        ...prev,
        ...now,
      }
    })
  }

  const reload = () => {
    _setParams((prev) => ({
      ...prev,
      counter: prev.counter++,
    }))
  }
  const setData = (now) => {
    _setData((prev) => ({
      ...prev,
      ...now,
    }))
  }
  return {
    data,
    setParams,
    setUrl: (u) => {
      _url.current = u
    },
    reload,
    params,
    setData,
    loading: loading,

    detailProps: {
      data,
      loading,
    },
  }
}
