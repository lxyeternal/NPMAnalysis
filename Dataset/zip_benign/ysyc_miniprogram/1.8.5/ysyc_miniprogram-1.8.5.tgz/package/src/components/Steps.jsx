
const { primary, } = getTheme()
export default function({
  data = [], style = {}, active = 0,
}) {
  const [ _active, setActive, ] = useState(0)
  useEffect(() => {
    setActive(active)
  }, [ active, ])
  const renderIcon = (
    item, i, color
  ) => {
    return (
      <view
        style={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
        }}
      >
        <view
          style={{
            flex: 1,
            height: '0',
            borderTop: '2PX solid #ddd',
            position: 'absolute',
            left: i == 0 ? '50%' : '-100%',
            right: i == data.length - 1 ? '50%' : '-100%',
          }}
        />
        {item.icon ?
          (
            <Icon
              src={`${item.icon}`}
              style={{
                fontSize: '20PX',
                position: 'relative',
                zIndex: 10,
              }}
            />
          ) :
          (
            <view
              style={{
                width: '22PX',
                height: '22PX',
                color: '#fff',
                borderRadius: '50%',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: color,
                position: 'relative',
                zIndex: 10,
              }}
            >
              {i + 1}
            </view>
          )}
      </view>
    )
  }
  return (
    <view
      style={{
        padding: '10PX 0',
        display: 'flex',
        justifyContent: 'space-between',
        ...style,
      }}
    >
      {data.map((item, i) => {
        const isActive = _active == i
        const color = isActive ? primary : '#ccc'
        return (
          <view
            key={i}
            style={{
              position: 'relative',
              display: 'flex',
              color,
              flexDirection: 'column',
              alignItems: 'center',
            }}
            /* onClick={() => {
              setActive(i)
            }} */
          >
            {renderIcon(
              item, i, color
            )}
            <view
              style={{
                marginTop: '5PX',
                color: isActive ? '#666' : color,
              }}
            >{item.label}</view>
          </view>
        )
      })}
    </view>
  )
}
