
async function getLocation() {
  try {
    const rs = await Taro.getLocation({ type: 'wgs84', })
    if (rs && rs.latitude) {
      return `${rs.latitude},${rs.longitude}`
    }
    return ''
  } catch {
    return ''
  }
}
export default () => {
  const [ _city, setCity, ] = useState({})
  useEffect(() => {
    _getCity().then(c => setCity(c))
  }, [])
  const _setCity = (city) => {
    let c = city
    if (typeof city == 'function') {
      c = city(_city)
    }
    Taro.setStorageSync('city', JSON.stringify(c))
    setCity(c)
  }
  const _getCity = async(reLocation = false) => {
    let city = JSON.parse(Taro.getStorageSync('city') || '{}')
    // reLocation是否重新定位
    if (city.name && !reLocation) {
      return city
    }
    const res = await getLocation()
    const rs = await ajax({
      url: '/wechat/home/latlngToArea',
      data: {
        latlng: res,
        level: 2,
      },
    })

    const _rs = rs.data ?
      {
        name: rs.data.name,
        code: rs.data.code,
        parentcode: rs.data.parentcode,
      } :
      {}

    // _setCity(_rs)
    return _rs
  }
  return {
    city: _city,
    setCity: _setCity,
    getCity: _getCity,
  }
}
