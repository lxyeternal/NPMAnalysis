
export default function({
  value, onChange = () => null, items = [],
}) {
  let _value = items.findIndex(it => it.type_id == value)
  return (
    <picker
      header-text='排序'
      range={items}
      range-key='type_name'
      value={_value == -1 ? 0 : _value}
      onChange={(e) => {
        let detail = e.detail
        let val = items[detail.value].type_id
        onChange(val)
      }}
    >
      <text
        class='icon-ck_paixu iconfont-ysyc'
        style={{
          fontSize: '13PX',
          color: '#73777A',
        }}
      />
    </picker>
  )
}
