import Taro, { useRouter, } from '@tarojs/taro'

export default ({
  url = 'mini/wx_login',
  onLoginThen, tabsUrl = [
    '/pages/my/index',
    '/pages/record/index',
    '/pages/index/index',
  ],
} = {}) => {
  const [ loading, setLoading, ] = useState(false)
  const { params, } = useRouter()
  const { userInfo, token, } = useSelector(useCallback((state) => {
    return {
      userInfo: state.user ?? {},
      token: state.token,
    }
  }, []))
  const role = [ 'manager', 'ceshi', ].includes(userInfo.role) ? 'manager' : userInfo.role
  const dispatch = useDispatch()// 权限
  const checkAuth = (cb) => {
    // data.auth_state = 1
    if (role == 'manager') {
      cb()
    } else if (role) {
      wx.showToast({
        title: '您还未开通此功能，请联系厂商',
        icon: 'none',
        duration: 2000,
      })
    } else {
      wx.showToast({
        title: '请登录后操作',
        icon: 'none',
        duration: 2000,
      })
    }
  }

  const setUserInfo = (d) => {
    dispatch({
      type: 'setUserInfo',
      payload: d,
    })
  }
  const clearUserInfo = () => {
    dispatch({ type: 'clearToken', })
    dispatch({ type: 'clearUserInfo', })
  }

  const loginThen = (res) => {
    // 登录成功
    const _token = res.data.access_token
    if (_token) {
      dispatch({
        type: 'setToken',
        payload: _token,
      })
    }
    dispatch({
      type: 'setUserInfo',
      payload: {
        // code,
        system: res.data.system,
        ...res.data.user,
      },
    })
    if (onLoginThen) {
      onLoginThen(res)
    }
  }

  const setAuthData = () => {
    if (token) {
      return {
        token,
        userInfo,
      }
    }
    const _userInfo = wx.getStorageSync('userInfo')
    const _token = wx.getStorageSync('token')
    if (_userInfo) {
      setUserInfo(_userInfo)
    }
    if (_token) {
      dispatch({
        type: 'setToken',
        payload: _token,
      })
    } else {
      clearUserInfo()
    }
    return {
      token: _token,
      userInfo: _userInfo,
    }
  }

  const login = async({ ajaxThen = utils.noop, reLogin = true, } = {}) => {
    // 登录过的不再登录
    const d = setAuthData()

    if (d.token && (d.userInfo.isTest || !reLogin)) {
      const res = {
        code: configs.RESULT_TEMPLATE.code,
        access_token: d.token,
        role: d.userInfo.role,
        system: d.userInfo.system,
        data: { user: d.userInfo, },
      }
      ajaxThen(res)
      return res
    }
    setLoading(true)
    const wxRes = await wx.login()
    let res = {
      code: 0,
      msg: wxRes.errMsg,
    }
    if (wxRes.code) {
      //只拿openid
      res = await ajax({
        url: '/mini/auth/login',
        method: 'POST',
        data: { code: wxRes.code, },
        message: false,
      })
      if (res.code == configs.RESULT_TEMPLATE.code) {
        // loginThen(res, wxRes.code)
        loginThen(res)
        ajaxThen(res)
      }
    }
    setLoading(false)
    return res
  }

  const [ showRegLogin, setShowRegLogin, ] = useState(true)
  // 获取手机号码并登录
  const getPhoneNumber = async(e, { test = false, ajaxThen = utils.noop, } = {}) => {
    if (e.detail.iv) {
      // if (e.detail.iv && params.token) {
      setLoading(true)
      const wxRes = await wx.login()
      let res
      if (test) {
        res = {
          code: configs.RESULT_TEMPLATE.code,
          role: '2',
          system: '3',
          data: {
            access_token: 'testtesttesttesttesttesttesttest',
            user: { id: 1, },
          },
        }
      } else {
        res = await ajax({
          url,
          method: 'post',
          data: {
            code: wxRes.code,
            encryptedData: e.detail.encryptedData,
            iv: e.detail.iv,
          },
        })
      }
      if (res.code == configs.RESULT_TEMPLATE.code) {
        setShowRegLogin(false)
        loginThen(res)
        ajaxThen(res)
      }
      goBack()
      setLoading(false)
    }
  }

  const checkAuth2 = ({ success = utils.noop, roles = [ 'yonghu', 'manager', ], }) => {
    if (!userInfo.op_name && !userInfo.name && roles.includes(role)) {
      // 没有绑定，转去获取手机，绑定
      // 当前页面url
      const backUrl = encodeURIComponent(`/${Taro.Current.page.$taroPath}`)
      // backUrl - 来源页面,
      // token - 此时还未登录成功，将token传递过去
      const _token = wx.getStorageSync('token')
      wx.navigateTo({ url: `/pages/signin/index?token=${_token}&backUrl=${backUrl}`, })
    } else {
      success()
    }
  }

  const goBack = () => {
    const urls = tabsUrl
    const backUrl = decodeURIComponent(params.backUrl)
    const backUrlPre = backUrl.split('?')[0]
    // 返回来源页面
    if (urls.includes(backUrlPre)) {
      wx.switchTab({ url: backUrl, })
    } else {
      wx.redirectTo({ url: backUrl, })
    }
  }

  // type - page | block
  const LoginView = ({
    style = {}, children, type = 'block', className, onClick = utils.noop, title = '您尚未登录，无法查看消息',
  }) => {
    const _onClick = () => {
      if (userInfo.auth_state == 0) {
        wx.showToast({
          title: '您未被邀请！',
          icon: 'none',
          duration: 2000,
        })
      } else if (userInfo.account_id) {
        onClick()
      } else {
        login()
      }
    }

    if (type == 'page') {
      return (
        <view
          style={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            height: '100vh',
            ...style,
          }}
        >
          <Image
            src='/static/miniprogram/images/tt@3x.png'
            style={{
              width: '220PX',
              height: '150PX',
              margin: '20PX 0 30PX',
            }}
          />
          <view
            style={{
              marginBottom: '15PX',
              fontWeight: 'bold',
              color: '#666',
            }}
          >{title}</view>
          <Button
            style={{ width: '180PX', }}
            title='登录查看消息'
            onClick={_onClick}
          />
        </view>
      )
    }
    return (
      <view
        class={className}
        style={style}
        onClick={_onClick}
      >
        {children}
      </view>
    )
  }
  const TestLoginButton = ({
    url: testUrl = 'mini/auth/login',
    ajaxThen = utils.noop, style = {}, formData = {
      name: '15658752357',
      password: '851024',
    },
    formItems = [
      {
        placeholder: '用户名',
        style: {
          textAlign: 'left',
          width: '100%',
          height: '30PX',
        },
        name: 'name',
        rules: [
          {
            required: true,
            message: '用户名必填',
          },
        ],
      },
      {
        placeholder: '密码',
        style: {
          textAlign: 'left',
          width: '100%',
          height: '30PX',
        },
        name: 'password',
        inputType: 'password',
        rules: [
          {
            required: true,
            message: '密码必填',
          },
        ],
      },
    ],
  }) => {
    if (process.env.NODE_ENV != 'development') {
      return false
    }
    return (
      <ModalForm
        formItems={formItems}
        modalTitle='测试登录'
        params={formData}
        position='center'
        style={style}
        title={(show) => {
          return (
            <Button
              size='small'
              style={{ marginBottom: '10PX', }}
              title='测试登录'
              onClick={show}
            />
          )
        }}
        url={testUrl}
        onSubmitted={(res) => {
          res.data.user.isTest = 1
          loginThen(res)
          ajaxThen(res)
        }}
      />
    )
  }

  const logout = () => {
    ajax({
      url: 'mini/logout',
      method: 'POST',
      message: false,
    }).then(() => {
      clearUserInfo()
      /* wx.showToast({
            title: '已退出登录',
            icon: 'none',
            duration: 1000,
            }) */
      wx.switchTab({ url: '/pages/my/index', })
    })
  }
  return {
    setAuthData,
    checkAuth,
    checkAuth2,
    userInfo,
    LoginView,
    TestLoginButton,
    setUserInfo,
    clearUserInfo,
    login,
    loading,
    token,
    getPhoneNumber,
    showRegLogin,
    goBack,
    logout,
    role,
  }
}
