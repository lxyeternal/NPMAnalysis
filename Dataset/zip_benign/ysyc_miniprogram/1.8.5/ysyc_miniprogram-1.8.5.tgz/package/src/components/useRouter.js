
import { useRouter, } from '@tarojs/taro'

/**
 * userRouter 路由相关
 * @param {object} opts 配置
 * @param {boolean} opts.del 执行过是否立即删除params
 * @returns {object} result
 * @returns {object} result.params 一般用作大数据传递
 * @returns {object} result.query 一般传递普通的字符串参数，参数会在url上显示出来
 * @example
 *  navigateTo({
      url: 'url',
      query: {
        a: 1
      }
    })
 * const {params, query} = useRouter()
 * query.a // 1
 */
export default ({ del = true, } = {}) => {
  const { params: query, } = useRouter()
  const params = useRef({})
  Object.keys(query).forEach(key => (query[key] = decodeURIComponent(query[key])))
  params.current = getGlobalData('params', del) ?? params.current
  return {
    query,
    params: params.current,
  }
}
