
export default function({
  children, title, action, show = true, style = {}, contentStyle = {}, onClick = () => null,
}) {
  return show ?
    (
      <view
        style={{
          padding: '5PX 0 10PX',
          marginBottom: '10PX',
          backgroundColor: '#fff',
          borderRadius: '5PX',
          ...style,
        }}
        onClick={onClick}
      >
        {!!title && (
          <Title
            action={action}
            size={18}
            style={{
              paddingLeft: '20PX',
              paddingRight: '20PX',
            }}
            title={title}
          />
        )}

        <view
          style={{
            paddingLeft: '20PX',
            paddingRight: '20PX',
            ...contentStyle,
          }}
        >
          {children}
        </view>
      </view>
    ) :
    null
}
