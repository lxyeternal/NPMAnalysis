
export default function({
  // title 兼容，后续删除
  title,
  label, value, onChange = utils.noop, trueValue = true, falseValue = false, style = {}, disabled,
}) {
  const [ _value, setValue, ] = useState(falseValue)
  label = label || title
  useEffect(() => {
    setValue(value ?? falseValue)
  }, [ value, ])
  const _isActive = _value == trueValue
  return (
    <view
      style={{
        // margin: '5PX 12PX 5PX 0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: _isActive ? '#3E82FE' : '#73777A',
        ...style,
      }}
      onClick={() => {
        if (disabled) {
          return
        }
        if (!_isActive) {
          setValue(trueValue)
          onChange(trueValue)
        } else {
          setValue(falseValue)
          onChange(falseValue)
        }
      }}
    >
      <view
        class={`${_isActive ? 'icon-check_box_px_rounded' : 'icon-checkbox-copy'} iconfont-ysyc`}
        style={{
          paddingTop: '1PX',
          backgroundColor: disabled ? '#eee' : 'transparent',
        }}
      />
      {!!label && (
        <view
          style={{ marginLeft: '5PX', }}
        >{label}</view>
      )}
    </view>
  )
}
