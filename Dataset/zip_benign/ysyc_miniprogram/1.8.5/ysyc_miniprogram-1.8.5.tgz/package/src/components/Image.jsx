
export default function({
  style = {}, src = '', className, mode = 'scaleToFill', onClick = utils.noop, isThumb = true,
}) {
  return (
    <image
      class={className}
      mode={mode}
      src={utils.imgUrl(src, isThumb)}
      style={style}
      onClick={onClick}
    />
  )
}
