
// @deprecated
export default function({
  style = {}, iconStyle = {}, src = '', onClick = utils.noop, title,
}) {
  const _icon = (
    <view
      class={src.includes('ysyc') ? src : `iconfont ${src}`}
      style={{ ...(title ? iconStyle : style), }}
      onClick={onClick}
    />
  )
  if (!title) {
    return _icon
  }
  return (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        ...style,
      }}
      onClick={onClick}
    >
      {_icon}
      {title && (
        <view
          style={{ width: '5PX', }}
        />
      )}
      {title}
    </view>
  )
}
