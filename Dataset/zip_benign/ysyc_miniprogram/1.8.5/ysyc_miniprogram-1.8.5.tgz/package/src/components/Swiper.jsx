
export default function({
  data = [], style = {}, title, append,
}) {
  const [ current, setCurrent, ] = useState(0)
  const handlePreviewImage = () => {
    utils.previewImage(data, current)
  }
  return (
    <view
      style={{
        width: '100%',
        height: '200px',
        background: '#fff',
        position: 'relative',
        ...style,
      }}
    >
      <swiper
        autoplay
        circular
        indicatorActiveColor='#333'
        indicatorColor='#999'
        indicatorDots
        style={{
          width: '100%',
          height: '100%',
        }}
        onChange={(e) => {
          setCurrent(e.detail.current)
        }}
        onClick={handlePreviewImage}
      >
        {data.map((item, i) => (
          <swiper-item key={i}>
            <Image
              src={typeof item == 'object' ? item.url : item}
              style={{
                width: '100%',
                height: '100%',
                background: '#eee',
              }}
            />
          </swiper-item>
        ))}
      </swiper>
      {!!title && (
        <view
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            height: '34PX',
            backgroundColor: 'rgba(0,0,0,.3)',
            zIndex: 9999,
          }}
        >
          {title?.({
            index: current,
            total: data.length,
          })}
        </view>
      )}
      {!!append && append({
        index: current,
        total: data.length,
      })}
    </view>
  )
}
