
export default function({ title = '更多', onClick, }) {
  return (
    <view
      style={{
        fontSize: '14PX',
        color: '#73777A;',
      }}
      onClick={onClick}
    >
      {title}
      <text
        class='iconfont-ysyc icon-sy_gengduo'
        style={{
          marginLeft: '5PX',
          fontSize: '15PX',
          color: '#D8D8D8',
        }}
      />
    </view>
  )
}
