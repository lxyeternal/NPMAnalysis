export default function({
  value = [], data = [], placeholder = '请选择', onChange = utils.noop,
}) {
  const [ _value, setValue, ] = useState(value)
  const [ _title, setTitle, ] = useState()
  useEffect(() => {
    setTitle(value.join(','))
  }, [ value, ])
  return (
    <Modal
      modalContent={() => (
        <view
          style={{
            height: '40vh',
            padding: '10PX',
            display: 'flex',
          }}
        >
          {Array.from({ length: 3, }).map((it, i) => (
            <view
              key={i}
              style={{
                height: '100%',
                overflow: 'auto',
                borderLeft: i > 0 ? '.5PX solid #eee' : 'none',
                flex: 1,
              }}
            >
              {data.map((item, j) => {
                const isActive = _value[i] == item.type_name
                const disabled = _value.includes(item.type_name) && !isActive
                return (
                  <view
                    key={j}
                    style={{
                      textAlign: 'center',
                      height: '34PX',
                      lineHeight: '34PX',
                      color: disabled ? '#a8a8a8' : (isActive ? '#3E82FE' : '#444'),
                    }}
                    onClick={() => {
                      if (!disabled) {
                        _value[i] = item.type_name
                        setValue([ ..._value, ])
                      }
                    }}
                  >
                    {item.type_name}
                  </view>
                )
              })}
            </view>
          ))}
        </view>
      )}
      modalTitle={(setShow) => {
        return (
          <view
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '10PX',
              borderBottom: '.5PX solid #eee',
            }}
          >
            <view
              style={{ color: '#3E82FE', }}
              onClick={() => {
                setShow(false)
              }}
            > 取消 </view>
            <view> 请选择 </view>
            <view
              style={{ color: '#3E82FE', }}
              onClick={() => {
                onChange(_value,)
                setShow(false)
              }}
            >确定</view>
          </view>
        )
      }}
      title={(setShow) => (
        <view
          style={{ color: _title ? '#333' : '#a8a8a8', }}
          onClick={() => {
            setShow(true)
          }}
        >{_title || placeholder}</view>
      )}

    />
  )
}
