import Uploader from 'miniprogram-file-uploader'

const maxSize = 50 * 1024 * 1024 // 上传最大文件限制
const eachSize = 1 * 1024 * 1024 // 每块文件大小

const getFileName = (_path = '') => {
  let aPath = (`${_path}`).split('/')
  return aPath.pop()
}

// 格式化文件大小显示文字
const getSize = (size) => {
  return size > 1024 ?
    size / 1024 > 1024 ?
      size / (1024 * 1024) > 1024 ?
        `${(size / (1024 * 1024 * 1024)).toFixed(2)}GB` :
        `${(size / (1024 * 1024)).toFixed(2)}MB` :
      `${(size / 1024).toFixed(2)}KB` :
    `${(size).toFixed(2)}B`
}
export default ({
  multiple = false,
  // 私有上传，上传的图片只有登录后才可以访问
  isPrivate = true,
  value,
  water = true,
  type,
  onChange = () => null,
} = {}) => {
  const Token = Taro.getStorageSync('token')
  // 上传url
  let uploadUrl = configs.UPLOAD_URL
  let mergeUrl = configs.UPLOAD_MERGE_URL
  if (!isPrivate) {
    uploadUrl = `${configs.UPLOAD_PRIVATE_URL}?key=img_park_file&status=1&water=${+water}`
  }
  // 转化后的数据
  const [ _value, setValue, ] = useState([])

  useEffect(() => {
    _transeformValue()
  }, [ value, ])
  // 将['111', '222', '333'] 转换成 [{url:'111', type: 'image'}, {url:'222', type: 'image'}, {url:'333', type: 'image'}]
  const _transeformValue = async() => {
    let _val = value
    if (!Array.isArray(value)) {
      _val = value ? [ value, ] : []
    }
    // 转换url
    let _valNew = []
    for (let i = 0; i < _val.length; i++) {
      let item = _val[i]
      let itemNew = item
      if (type == 'all') {
        // 上传类型为all时，不能确定文件类型，需要重新请求服务器获取
        // eslint-disable-next-line no-await-in-loop
        const res = await ajax({
          url: '/api/resource/info',
          data: { id: item, },
        })
        itemNew = res.data[item] ?? {}
        // 返回的数据不统一，转换成统一数据
        itemNew.url = item
        itemNew.mime_type = itemNew.mime
      }
      _valNew.push(_getItem(itemNew))
    }
    setValue(_valNew)
  }

  const _getItem = (item, t) => {
    let _url = item
    let _type = t
    if (typeof item == 'object') {
      _url = item.url
      if (item.mime_type) {
        _type = item.mime_type.split('/')[0]
      }
      _type = item.type || _type || 'image'
    }
    return {
      url: getFileShow(_url),
      id: _url,
      type: _type,
    }
  }

  // 转化为原数据
  const parseValue = (val) => {
    if (multiple) {
      return val.map(item => item.id)
    }
    return val?.[0]?.id
  }

  const _onChange = (
    val, isDel = false, uploadType
  ) => {
    if (isDel) {
      _value.splice(val, 1)
    } else {
      _value.push(_getItem(val, uploadType))
    }
    setValue(_value)
    onChange(parseValue(_value))
  }
  // FILE url
  const getFileShow = (src) => {
    if (!isPrivate) {
      return utils.imgUrl(src)
    }
    return `${configs.IMG_HOST_PATHNAME}?id=${src}&token=${Token}`
  }
  // const [ percent, setPercent, ] = useState(0)
  const [ loading, setLoading, ] = useState(false)

  // 非私有上传
  const uploadFileOpen = async(
    filePath, key, limitSize, uploadType
  ) => {
    setLoading(true)
    return Taro.uploadFile({
      url: uploadUrl,
      filePath,
      name: 'file',
      header: { 'Content-Type': 'multipart/form-data', },
      // formData: adds,
      success: function(res) {
        try {
          const result = JSON.parse(res.data)
          if (result.code != 1) {
            wx.showToast({
              title: result.msg || '未知错误',
              icon: 'none',
              duration: 2000,
            })
          } else if (result.msg) {
            _onChange(
              result.msg, false, uploadType
            )
          }
        } catch (err) {
          console.warn(err)
        }
        setLoading(false)
      },
      fail: function() {
        setLoading(false)
      },
    })
  }
  const uploadFile = async(
    filePath, key, limitSize, uploadType
  ) => {
    const { size, } = await Taro.getFileInfo({ filePath, })
    // return false;
    const _limitSize = limitSize ? `${limitSize} * 1024 * 1024` : maxSize
    if (size > _limitSize) {
      return wx.showToast({
        title: `您选择的文件大于${getSize(_limitSize)}`,
        icon: 'none',
        duration: 2000,
      })
    }
    setLoading(true)
    const [ fileName, suffix, ] = getFileName(filePath).split('.')
    const uploader = new Uploader({
      tempFilePath: filePath,
      totalSize: size,
      uploadUrl,
      mergeUrl,
      timeout: 60000,
      failStatus: [
        404,
        415,
        500,
        501,
        401,
      ],
      chunkSize: eachSize,
      header: { token: Token, },
      fileName: key || fileName,
      query: {
        water: water ? 1 : 0,
        key,
        suffix,
      },
    })
    uploader.on('complete', () => {
    //   console.log('upload complete', res)
    })
    uploader.on('success', (result) => {
      if (result.code != 1) {
        wx.showToast({
          title: result.msg || '未知错误',
          icon: 'none',
          duration: 2000,
        })
      } else if (result.data) {
        _onChange(
          result.data, false, uploadType
        )
      }
      setLoading(false)
    })
    uploader.on('fail', (result) => {
      wx.showToast({
        title: result.msg || '未登录',
        icon: 'none',
        duration: 2000,
      })
      setLoading(false)
    })
    uploader.upload()
  }
  // button
  // 批处理
  const uploadFiles = async(
    data, key, limitSize, uploadType
  ) => {
    let _uploadFile = uploadFile
    if (!isPrivate) {
      _uploadFile = uploadFileOpen
    }
    if (multiple) {
      for (let i = 0; i < data.length; i++) {
        if (data[i]) {
          // eslint-disable-next-line no-await-in-loop
          await _uploadFile(
            data[i], key, limitSize, uploadType
          )
        }
      }
    } else {
      await _uploadFile(
        data, key, limitSize, uploadType
      )
    }
  }

  const removeFile = useCallback((i) => {
    Taro.showModal({
      title: '提示',
      content: '此操作将永久删除该文件, 是否继续?',
      success(res) {
        if (res.confirm) {
          _onChange(i, true)
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      },
    })
  }, [ _value, _onChange, ])
  return {
    removeFile,
    // percent,
    uploadFiles,
    getFileShow,
    uploadValue: _value,
    loading,
  }
}
