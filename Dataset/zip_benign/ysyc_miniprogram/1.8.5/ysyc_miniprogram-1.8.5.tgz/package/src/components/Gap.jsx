
export default function({
  color = '#f2f2f2', height = 8, style = {},
}) {
  return (
    <view
      style={{
        backgroundColor: color,
        height: `${height}PX`,
        ...style,
      }}
    />
  )
}
