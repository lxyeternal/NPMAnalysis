
export default function({
  active = false, style = {}, onClick, title = '标题',
}) {
  return (
    <view
      style={{
        width: '24%',
        marginRight: '1%',
        marginBottom: '10PX',
        padding: '0 5PX',
        height: '32PX',
        border: '1PX solid #ddd',
        borderRadius: '5PX',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: active ? getTheme('capsuleGroupActiveBgColor') : 'none',
        boxSizing: 'border-box',
        color: active ? '#fff' : 'none',
        ...style,
      }}
      onClick={onClick}
    >{title}</view>
  )
}
