/**
 * 加载列表数据
 * @param  {String}   options.url      请求的url
 * @param  {Object}   options.data:    initParams    提交的参数
 * @param  {Function} options.ajaxThen 回调函数
 * @param  {Boolean}   autoLoad=true   自动加载数据
 * @param  {Boolean}   reloadClearList=false 重新请求前清空列表
 * @return {Object}   result           结果
 * @return {Array}   result.list       数据
 * @return {Object}   result.page      分页
 * @return {Function}   result.setParams 设置参数，设置后会重新请求数据
 * @return {Function}   result.reload  重新请求数据
 * @return {Boolean}   result.loading  请求数据时的状态
 * @return {Object}   result.props     content的props
 *
 */
export default ({
  url,
  data: initParams,
  ajaxThen = () => null,
  ajaxCatch = () => null,
  autoLoad: initAutoLoad = true,
  ajaxBefore,
  message = false,
  didShow = false,
  message401 = true,
  reloadClearList = false,
}) => {
  const [ result, setData, ] = useState({
    list: [],
    total: 0,
  })
  initParams = Object.assign({
    [configs.RESULT_TEMPLATE.page]: 1,
    [configs.RESULT_TEMPLATE.pageSize]: 10,
  }, initParams)
  const [ params, _setParams, ] = useState(initParams)
  const [ loading, _setLoading, ] = useState(true)
  const _url = useRef(url)
  // 第一次加载
  const isFirst = useRef(true)
  const timer = useRef()
  const autoLoad = useRef(didShow ? false : initAutoLoad)
  const getData = async() => {
    if (!_url.current) {
      console.log('url 不存在！')
      return
    }

    // 请求前
    if (ajaxBefore && !ajaxBefore(params)) {
      return
    }
    // 正在加载时不加载，第一次加载忽略loading
    if (loading && !isFirst.current) {
      isFirst.current = false
      return
    }
    _setLoading(true)
    // 删除多余的参数
    // delete params.counter
    if (params[configs.RESULT_TEMPLATE.page] == 1 && reloadClearList) {
      setData({
        list: [],
        total: 0,
      })
    }
    try {
      const res = await ajax({
        url: _url.current,
        data: { ...params, },
        authing: true,
        message,
        message401,
      })
      let _data = res.data
      if (_data) {
        _data = utils.getObjectValue(res, configs.RESULT_TEMPLATE.list) || []
        if (params[configs.RESULT_TEMPLATE.page] > 1) {
          _data = [ ...result.list, ..._data, ]
        }
      }
      if (!Array.isArray(res.data)) {
        setData({
          ...res.data,
          list: _data,
        })
      } else {
        setData({
          total: utils.getObjectValue(res, configs.RESULT_TEMPLATE.total) || 10,
          list: _data,
        })
      }
      ajaxThen(res)
    } catch (error) {
      ajaxCatch(error)
      console.log('error', error)
    }
    _setLoading(false)
  }
  useEffect(() => {
    // 第一次是否加载
    if (autoLoad.current) {
      getData()
    } else {
      autoLoad.current = true
    }
    return () => {
      clearTimeout(timer.current)
    }
  }, [ params, ])

  useDidShow(() => {
    if (didShow) {
      reload()
      // getData()
    }
  })

  const setParams = (now, override = false) => {
    _setParams((prev) => {
      if (typeof now == 'function') {
        return now(prev)
      }
      let isReset = !Object.keys(now).length
      if (isReset) {
        return initParams
      } else if (override) {
        return {
          ...now,
          [configs.RESULT_TEMPLATE.page]: 1,
        }
      }
      return {
        ...prev,
        // 重置分页
        [configs.RESULT_TEMPLATE.page]: 1,
        ...now,
      }
    })
  }

  const load = () => {
    // 保证上一次加载完成
    if (loading) {
      return
    }
    setParams((prev) => {
      return {
        ...prev,
        [configs.RESULT_TEMPLATE.page]: prev[configs.RESULT_TEMPLATE.page] + 1,
      }
    })
  }

  const reload = () => {
    setParams((prev) => {
      return {
        ...prev,
        [configs.RESULT_TEMPLATE.page]: 1,
        // counter: prev.counter++,
      }
    })
  }

  const [ scrollabled, setScrollabled, ] = useState(true)
  // 没有了
  const isEmpty = result.list.length == result.total
  return {
    list: result.list,
    setList(ls) {
      setData({ list: ls, })
    },
    setParams,
    setUrl(u) {
      _url.current = u
    },
    reload,
    params,
    loading,
    isEmpty,
    load,
    total: result.total,
    result,
    setLoading: _setLoading,
    setScrollabled,
    listProps: {
      data: result.list,
      loading,
      isEmpty,
      scrollabled,
      onRefresherRefresh: reload,
      onScrollToLower: () => {
        if (process.env.TARO_ENV === 'weapp') {
          load()
        } else {
          clearTimeout(timer.current)
          timer.current = setTimeout(() => {
            load()
          }, 600)
        }
      },
    },
  }
}
