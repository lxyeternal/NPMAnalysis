export default function(props) {
  const _submit = (d = {}) => {
    ajax({
      url: props.url,
      method: props.method ?? 'POST',
      data: {
        ...(props.params || {}),
        ...d,
      },
      message: true,
    }).then(res => {
      if (props.onSubmitted) {
        props.onSubmitted(res)
      }
    })
  }
  props.comfirm = props.comfirm ?? true
  return (
    <Button
      {...props}
      onClick={(e) => {
        e.stopPropagation()
        if (props.comfirm) {
          Taro.showModal({
            title: props.comfirmTitle ?? '提示',
            content: props.comfirmContent ?? '确定要这样操作？',
            success: (res) => {
              if (res.confirm) {
                _submit()
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            },
          })
        } else if (props.onClick) {
          props.onClick(_submit)
        } else {
          _submit()
        }
      }}
    />
  )
}
