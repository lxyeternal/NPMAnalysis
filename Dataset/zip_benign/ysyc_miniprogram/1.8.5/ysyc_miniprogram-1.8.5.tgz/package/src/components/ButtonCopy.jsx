export default ({
  data, icon, title, style = {}, ...args
}) => {
  return (
    <IconButton
      {...args}
      icon={icon}
      style={style}
      title={title}
      onClick={() => {
        wx.setClipboardData({
          data,
          success() {
            wx.showToast({
              icon: 'none',
              title: '复制成功！',
            })
          },
        })
      }}
    />
  )
}