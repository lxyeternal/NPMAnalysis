export default function({
  children,
  data,
  style = {},
  footer,
  footerStyle = {},
  loading = false,
  onScroll = utils.noop,
}) {
  if (loading) {
    return (
      <view
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
        }}
      >
        <Alert
          text
          title='加载中...'
        />
      </view>
    )
  }
  if (data && !Object.keys(data).length) {
    return <Alert text />
  }
  return (
    <scroll-view
      scrollY
      style={{
        // padding: '0 20PX',
        position: 'relative',
        paddingBottom: footer ? '60PX' : 0,
        ...style,
      }}
      onScroll={onScroll}
    >
      {children}
      {!!footer && (
        <view
          style={{
            position: 'fixed',
            left: 0,
            right: 0,
            bottom: 0,
            height: '60PX',
            borderTop: '.5PX solid #e5e5e5',
            backgroundColor: '#fff',
            ...footerStyle,
          }}
        >
          {footer?.()}
        </view>
      )}
    </scroll-view>
  )
}
