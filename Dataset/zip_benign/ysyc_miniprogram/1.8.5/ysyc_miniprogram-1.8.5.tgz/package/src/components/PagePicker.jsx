
// PagePicker
export default function({
  value, url: _url, onChange = utils.noop, placeholder = '请选择', parseValue, title: _title, params: _params, style = {}, onClick,
}) {
  const [ title, setTitle, ] = useState(_title ?? placeholder)
  useEffect(() => {
    setTitle(_title)
  }, [ _title, ])
  return (
    <view
      style={{
        color: value ? '#333' : '#999',
        ...style,
      }}
      onClick={() => {
        const next = ({ url, params, } = {}) => {
          let newUrl = url || _url
          let newParams = params || _params
          if (newUrl) {
            eventCenter.off('callback').
              on('callback', ({ value: val, ...args }) => {
                setTitle(args.title ?? val)
                onChange(val, args)
              })
            utils.navigateTo({
              url: newUrl,
              params: newParams,
            })
          }
        }

        if (onClick) {
          onClick(next)
        } else {
          next()
        }
      }}
    >
      {parseValue ? parseValue(value, title) : (title ?? placeholder) }
    </view>
  )
}
