import React, { useEffect, useState, } from 'react'

import getTheme from '../../service/getTheme'
import { date as dateFormat, noop, } from '../../service/utils'
import useCalendar from './useCalendar'

const centerStyle = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
}

const primary = getTheme('primary')
export default function({
  style = {}, bodyStyle = {},
  onChange = noop, date: initDate, renderHeader, max, min, onItemClick = noop, renderItemDate, multiple = false, format = 'YYYY-MM-DD',
  onMonthChange,
}) {
  const {
    state,
    setState,
    isSameDay,
    isSameMonth,
    gotoDate,
    getDateISO,

    isSameYear,
    WEEK_DAYS,
    getCalendarDates,
    gotoPreviousMonth,
    gotoNextMonth,
    gotoPreviousYear,
    gotoNextYear,
    getMonthname,
  } = useCalendar({
    onChange,
    onMonthChange,
    initDate,
    multiple,
    format,
  })
  const _renderItemDate = ({
    day, isToday, index, inMonth, onClick, isCurrent,
  }) => {
    return (
      <view
        key={index}
        style={{
          minWidth: '42PX',
          maxWidth: '100%',
          marginBottom: '8PX',
          minHeight: '42PX',
          display: 'flex',
          alignItems: 'center',
          // alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column',
          // backgroundColor: isToday ? '#f00' : '',
          border: isCurrent ? `1PX solid ${primary}` : '1PX solid #fff',
          backgroundColor: isCurrent ? '#ecf2ff' : '',
          borderRadius: '5PX',
          color: inMonth ? ((isToday || isCurrent) ? primary : '') : '#999',
          fontWeight: 'bold',
        }}
        onClick={onClick}
      >
        {/* icon-duigou */}
        {renderItemDate ?
          renderItemDate({
            day,
            isToday,
            index,
            inMonth,
            isCurrent,
          }) :
          (
            <>
              {day}
              {isToday && (
                <view
                  style={{ fontSize: '12PX', }}
                >今天</view>
              )}
            </>
          )}
      </view>
    )
  }
  const renderCalendarDate = (date, index) => {
    const {
      current, month, year, today,
    } = state
    const _date = new Date(date.join('-'))
    const formatDate = dateFormat(_date, format)
    const isToday = isSameDay(_date, today)
    const isCurrent = current && (multiple ? current.includes(formatDate) : formatDate == current)
    const inMonth =
      month && year && isSameMonth(_date, new Date([
        year,
        month,
        1,
      ].join('-')))
    const onClick = () => {
      gotoDate(_date)()
      // onItemClick(_date)
    }

    return (
      <view
        key={getDateISO(_date)}
        style={{
          width: 'calc(100%/7)',
          display: 'flex',
          alignItems: 'stretch',
          justifyContent: 'center',
        }}
      >
        {_renderItemDate({
          day: _date.getDate(),
          isToday,
          index,
          inMonth,
          isCurrent,
          onClick,
        })}
      </view>
    )
  }
  // console.log('state :>> ', state)
  return (
    <view
      style={{
        backgroundColor: '#fff',
        ...style,
      }}
    >
      {renderHeader ?
        renderHeader({
          gotoPreviousMonth,
          gotoNextMonth,
          gotoPreviousYear,
          gotoNextYear,
          isSameYear,
          ...state,
          setState,
        }) :
        (
          <view
            style={{
              display: 'flex',
              justifyContent: 'space-between',
            }}
          >
            <view
              style={{
                ...centerStyle,
                color: primary,
              }}
              onClick={gotoPreviousMonth}
            >
              <view
                class='iconfont icon-dls_xz'
                style={{ transform: 'rotate(180deg)', }}
              > </view>
          上一月
            </view>
            <view
              style={{ fontWeight: 'bold', }}
            >
              {state.year} 年 {state.month} 月
            </view>
            <view
              style={{
                ...centerStyle,
                color: primary,
              }}
              onClick={gotoNextMonth}
            >
          下一月
              <view class='iconfont icon-dls_xz'> </view>
            </view>
          </view>
        )}
      <view
        style={{ ...bodyStyle, }}
      >
        <view
          style={{ display: 'flex', }}
        >
          {Object.values(WEEK_DAYS).map((item, i) => {
            return (
              <view
                key={i}
                style={{
                  width: 'calc(100%/7)',
                  textAlign: 'center',
                  padding: '10PX 0',
                  color: '#999',
                  fontSize: '14PX',
                }}
              >
                {item}
              </view>
            )
          })}
        </view>
        <view
          style={{
            display: 'flex',
            flexWrap: 'wrap',
          }}
        >
          {getCalendarDates().map(renderCalendarDate)}
        </view>
      </view>
    </view>
  )
}
