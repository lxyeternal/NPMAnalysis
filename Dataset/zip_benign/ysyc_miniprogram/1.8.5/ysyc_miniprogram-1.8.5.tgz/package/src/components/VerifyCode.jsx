// VerifyCode
const { primary, } = getTheme()
export default function({
  // 发送验证码的url
  url = '/wechat/login/applyPhoneCode',
  params = {},
  // 是否需要图形验证码
  useCaptcha = true,
  // phone手机号码来自data里的哪个字段
  phone = 'username',
  // 出错时的回调
  // onCatch = () => null,
}) {
  const timer = useRef()
  const [ start, setStart, ] = useState(0)
  const [ codeTitle, setCodeTitle, ] = useState('获取验证码')
  useEffect(() => {
    return () => {
      clearTimeout(timer.current)
    }
  }, [])
  const getCode = () => {
    /*if (!params.captchaCode) {
            this.$emit('catch', '验证码不能为空')
            return
        }*/
    // console.log(params)
    if (!params[phone]) {
      // onCatch('手机号码不能为空')
      wx.showToast({
        title: '手机号码不能为空',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    if (start) {
      return
    }
    let downTimeSms = t => {
      if (t > 0) {
        setCodeTitle(`${t}秒后重发`)
      } else {
        setCodeTitle('获取验证码')
        setStart(0)
        return
      }
      clearTimeout(timer.current)
      timer.current = setTimeout(function() {
        t--
        downTimeSms(t)
      }, 1000)
    }
    let data = { username: params[phone], }
    if (useCaptcha) {
      data.captchaCode = params.captchaCode
      //data.sess_id = getGlobalKey('captcha')
    }
    ajax({
      url,
      data,
    }).then(res => {
      if (res.code != 1) {
        // onCatch(res.msg)
        wx.showToast({
          title: res.msg,
          icon: 'none',
          duration: 2000,
        })
      } else {
        setStart(1)
        downTimeSms(60)
        wx.showToast({
          title: res.msg,
          icon: 'none',
          duration: 1000,
        })
      }
    })
  }
  return (
    <view
      style={{ color: primary, }}
      onClick={getCode}
    >{codeTitle}</view>
  )
}
