
const { primary, } = getTheme()
export default function({
  data, value, onChange = utils.noop, append, radioItemStyle = {}, radioStyle = {}, radioType = '',
}) {
  const [ _value, setValue, ] = useState(value)
  if (!data) {
    return <view>请先设置data!</view>
  }
  useEffect(() => {
    setValue(value)
  }, [ value, ])
  return (
    <view
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        width: radioType == 'capsule' ? '100%' : 'auto',
        ...radioStyle,
      }}
    >
      {data.map((item, i) => {
        const isActive = _value == item.type_id
        if (radioType == 'capsule') {
          return (
            <CapsuleItem
              key={i}
              active={isActive}
              style={radioItemStyle}
              title={item.type_name}
              onClick={() => {
                if (!isActive) {
                  setValue(item.type_id)
                  onChange(item.type_id)
                }
              }}
            />
          )
        }
        return (
          <view
            key={i}
            style={{
              display: 'flex',
              alignItems: 'center',
              margin: '5PX 12PX 5PX 0',
              color: isActive ? primary : '#73777A',
            }}
            onClick={() => {
              if (!isActive) {
                setValue(item.type_id)
                onChange(item.type_id)
              }
            }}
          >
            <view
              class={`${isActive ? 'icon-dls_danx01' : 'icon-dls_dx02'} iconfont-ysyc`}
              style={{ marginRight: '5PX', }}
            />
            <view>{item.type_name}</view>
          </view>
        )
      })}
      {append?.()}
    </view>
  )
}
