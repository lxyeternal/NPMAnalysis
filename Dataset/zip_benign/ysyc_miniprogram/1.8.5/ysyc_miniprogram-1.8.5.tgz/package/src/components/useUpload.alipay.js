import {
  useState, useCallback, useEffect,
} from 'react'

export default ({} = {}) => {
  return { a: 1, }
}
