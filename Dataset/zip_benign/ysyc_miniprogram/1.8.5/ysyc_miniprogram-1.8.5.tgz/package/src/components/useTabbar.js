
export default ({ selected = 0, ...args } = {}) => {
  useDidShow(() => {
    // eslint-disable-next-line no-unused-expressions
    getCurrentInstance().page?.getTabBar?.()?.setData({
      selected,
      ...args,
    })
  })
  return {}
}
