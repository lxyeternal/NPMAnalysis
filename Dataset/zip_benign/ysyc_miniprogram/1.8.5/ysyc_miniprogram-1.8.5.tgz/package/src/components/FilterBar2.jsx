
// import Taro from '@tarojs/taro'

// FilterBar
export default function({
  options, onChange = () => null, params: _params, itemStyle = {},
}) {
  const [ params, setParams, ] = useState({})
  useEffect(() => {
    if (_params) {
      setParams(_params)
    }
  }, [ _params, ])
  const _onChange = (item, val) => {
    params[item.prop] = val
    setParams({ ...params, })
    onChange(params)
  }
  const _options = options.filter(item => utils.parseShow(item.show ?? true, params))
  return (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#fff',
      }}
    >
      {_options.map((item, i) => {
        let _item = (
          <view />
        )
        if (item.render) {
          _item = item.render(params)
        } else if (item.type == 'date') {
          _item = (
            <PickerDate
              placeholder={item.label}
              value={params[item.prop]}
              {...item}
              onChange={(val) => {
                _onChange(item, val)
              }}
            />
          )
        } else if (item.type == 'picker') {
          _item = (
            <Picker
              placeholder={item.label}
              value={params[item.prop]}
              {...item}
              onChange={(val) => {
                _onChange(item, val)
              }}
            />
          )
        } else if (item.type == 'pickerCheckbox') {
          _item = (
            <PickerCheckbox
              placeholder={item.label}
              titleStyle={{
                color: 'inherit',
                maxWidth: '90PX',
                textOverflow: 'ellipsis',
              }}
              value={params[item.prop]}
              {...item}
              onChange={(val) => {
                _onChange(item, val)
              }}
            />
          )
        }
        return (
          <view
            key={i}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: `calc(100% / ${_options.length || 1})`,
              height: '40PX',
              ...itemStyle,
            }}
          >
            {_item}
            <view
              class='icon-sy_icon iconfont-ysyc'
              style={{
                marginLeft: '5PX',
                fontSize: '14PX',
                color: '#999',
              }}
            > </view>
          </view>
        )
      })}
    </view>
  )
}
