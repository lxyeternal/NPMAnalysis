import { Image, } from '@tarojs/components'

import imageDefault from '../assets/images/avatar.png'

// avatar
export default function({
  style = {},
  circle,
  size = 'medium',
  src,
  image, // @deprecated
  onClick = () => null,
}) {
  image = src || image
  const sizeMap = {
    large: 72,
    medium: 60,
    small: 34,
  }
  const _style = {
    width: `${sizeMap[size]}PX`,
    height: `${sizeMap[size]}PX`,
    overflow: 'hidden',
    ...style,
  }
  if (circle) {
    _style.borderRadius = '50%'
  }
  return (
    <Image
      src={image ? utils.imgUrl(image) : imageDefault}
      style={_style}
      onClick={onClick}
    />
  )
}
