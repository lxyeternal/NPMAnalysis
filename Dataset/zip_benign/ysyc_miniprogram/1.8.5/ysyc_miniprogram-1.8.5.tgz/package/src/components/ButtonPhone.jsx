
export default ({
  phone, icon, title, style = {}, ...args
}) => {
  return (
    <IconButton
      {...args}
      icon={icon}
      style={{ ...style, }}
      title={title}
      onClick={() => {
        wx.makePhoneCall({ phoneNumber: phone, })
      }}
    />
  )
}