
export default function({
  value, onChange = utils.noop, data = [], style = {}, itemStyle = {}, capsuleItemStyle = {},
}) {
  const [ _value, setValue, ] = useState(value)
  useEffect(() => {
    setValue(value)
  }, [ value, ])
  const _itemStyle = {
    whiteSpace: 'nowrap',
    height: '32PX',
    border: '1PX solid #ddd',
    borderRadius: '5PX',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxSizing: 'border-box',
    backgroundColor: '#fff',
    ...itemStyle,
    ...capsuleItemStyle,
  }
  return (
    <view
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        ...style,
      }}
    >
      {data.map((item, i) => {
        const _isActive = _value == item.type_id
        // const _isExist = data.find(it => it.type_id == _value)
        return (
          <>
            {/* -999 自定义 */}
            {item.type_id == -999 ? (
              <view
                style={{
                  ..._itemStyle,
                  ...(item.style ?? {}),
                  padding: 0,
                }}
              >
                <Input
                  inputType='number'
                  style={{
                    border: 'none',
                    textAlign: 'center',
                  }}
                  onInput={onChange}
                  value={_value > 0 ? _value : ''}
                  // value={_isExist ? '' : _value}
                  placeholder={item.type_name}
                />
                {!!item.suffix && (
                  <view
                    style={{ margin: '0 5PX', }}
                  >
                    {item.suffix}
                  </view>
                )}
              </view>
            ) : (
              <view
                style={{
                  padding: '0 5PX',
                  ..._itemStyle,
                  backgroundColor: _isActive ? getTheme('capsuleGroupActiveBgColor') : '#fff',
                  color: _isActive ? '#fff' : 'none',
                  ...(item.style ?? {}),
                }}
                onClick={() => {
                  if (typeof item.type_name !== 'function') {
                    onChange(item.type_id, item)
                  }
                  if (item.onChange) {
                    item.onChange()
                  }
                  // setValue(item.type_id)
                }}
              >
                {typeof item.type_name == 'function' ?
                  item.type_name({
                    /* value: item.type_id,
                    itemChange: () => {
                      onChange(item.type_id, item)
                    },  */
                  }) :
                  item.type_name}
              </view>
            )}
          </>
        )
      })}
    </view>
  )
}
