
export default (props = {}) => {
  const [ isFollow, setIsFollow, ] = useState(false)
  const addFollow = (data) => {
    ajax({
      url: isFollow ? '/wechat/attention/removed' : '/wechat/attention/attention',
      method: 'POST',
      data,
    }).then(res => {
      if (res.code == configs.RESULT_TEMPLATE.code) {
        setIsFollow(!isFollow)
      }
    })
  }
  return {
    isFollow,
    addFollow,
  }
}
