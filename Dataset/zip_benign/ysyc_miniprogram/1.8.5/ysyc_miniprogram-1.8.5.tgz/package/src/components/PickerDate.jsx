
export default function({
  onChange = utils.noop, start, end, value, placeholder = '请选择', valueFormat = 'timestamp', hasIcon,
}) {
  const _title = valueFormat == 'timestamp' ? utils.date(value, 'YYYY-MM-DD') : value
  return (
    <picker
      end={end}
      mode='date'
      start={start}
      style={{
        paddingTop: '5PX',
        paddingBottom: '5PX',
      }}
      value={_title}
      onChange={(e) => {
        let val = e.detail.value
        if (valueFormat == 'timestamp') {
          val = utils.dateUnix(val)
        }
        onChange(val)
      }}
    >
      <view
        style={{
          color: value ? 'inherit' : '#999',
          display: hasIcon ? 'flex' : 'block',
          alignItems: 'center',
        }}
      >
        {value ? _title : placeholder}
        {hasIcon && (
          <view
            class='icon-sy_icon iconfont-ysyc'
            style={{
              fontSize: '12PX',
              marginLeft: '3PX',
            }}
          > </view>
        )}
      </view>
    </picker>
  )
}
