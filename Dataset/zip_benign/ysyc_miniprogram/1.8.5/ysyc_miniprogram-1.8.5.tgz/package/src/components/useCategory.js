
import * as categoriesAll from '@/service/categories'

const demandKey = [ 'land_uses', ]
export default () => {
  const storeCategory = useSelector(useCallback((state) => {
    return state.categories
  }, []))
  const dispatch = useDispatch()
  // 被加载的key
  const loadedMap = useRef({})
  const _getData = () => {
    ajax({
      url: '/backapi/system/propertyAll',
      // 启用缓存
      cacheKey: 'property',
    }).then(res => {
      const _categoriesAll = {}
      Object.keys(res.data).forEach(key => {
        if (demandKey.includes(key)) {
          _categoriesAll[`demand_${key}`] = res.data[key].data
        }
        // 过滤掉了不限
        _categoriesAll[key] = _categoriesAll[key] ?? res.data[key].data.filter(item => item.type_name != '不限')
      })
      dispatch({
        type: 'setCategory',
        ..._categoriesAll,
      })
    })
  }
  const _getCategory = (key, item = {}) => {
    const _value = categoriesAll[key]
    const _ajaxGetCategory = () => {
      loadedMap.current[key] = true
      _value(item.ajaxData).then(res => {
        dispatch({
          type: 'setCategory',
          [key]: res || [],
        })
        if (item.reload) {
          loadedMap.current[key] = false
          // item.reload = false
        }
      }).catch(() => {
        loadedMap.current[key] = false
      })
    }
    if (item.reload && !loadedMap.current[key]) {
      _ajaxGetCategory()
    }
    if (!storeCategory[key]) {
      if (Array.isArray(_value)) {
        storeCategory[key] = _value
        dispatch({
          type: 'setCategory',
          [key]: _value,
        })
      }
      if (typeof _value == 'function' && !loadedMap.current[key]) {
        _ajaxGetCategory()
      }
    }
    return storeCategory[key] || []
  }
  useEffect(() => {
    // 只执行一次
    // _getData()
  }, [])

  const _fieldTitle = ({
    prop, data, value, sep = ',', isArray = false, isObject = false, render,
  }) => {
    let _data = data ?? []
    let values = []
    let titles = []
    let _activeItems = []

    if (_data.length == 0) {
      _data = _getCategory(prop)
    }
    if (Array.isArray(value)) {
      values = value
    } else if (value || value === 0) {
      values = [ value, ]
    }

    if (_data.length > 0) {
      values.forEach((v) => {
        let _item = _data.find((item) => item.type_id == v)

        if (_item) {
          titles.push(_item.type_name)
          _activeItems.push(_item)
        }
      })
    } else {
      titles = values
    }

    if (isArray) {
      return titles
    }
    const _activeItem = _activeItems.length == 1 ? _activeItems[0] : _activeItems
    if (isObject) {
      return _activeItem
    }
    const _titles = titles.length > 0 ? titles.join(sep) : '--'
    if (render) {
      return render(_activeItem, _titles)
    }
    return _titles
  }

  return {
    categories: storeCategory,
    fieldTitle: _fieldTitle,
    getCategory: _getCategory,
    initProperty: _getData,
  }
}
