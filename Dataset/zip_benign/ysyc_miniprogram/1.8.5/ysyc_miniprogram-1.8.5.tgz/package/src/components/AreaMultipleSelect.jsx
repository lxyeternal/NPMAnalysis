
export default ({
  placeholder = '请选择', onChange = () => null, limit = 2, value, modalTitle = '请选择', disabled,
}) => {
  const _getParentCode = (code) => {
    const _code = `${code}`
    let _parentCode = -999
    if (_code.length == 9) {
      // 镇
      _parentCode = _code.slice(0, 6)
    } else if (+_code.slice(4, 6) > 0) {
      // 区
      _parentCode = `${_code.slice(0, 4)}00`
    } else if (+_code.slice(2, 4) > 0) {
      // 市
      _parentCode = `${_code.slice(0, 2)}0000`
    }
    return +_parentCode
  }
  const {
    areaData, setValue, setArea, areaValue, title: _title,
  } = useArea({
    // 加上父级
    value: value ? [ _getParentCode(value[0]), ...value, ] : [],
    limit,
  })
  return (
    <Modal
      modalContent={() => (
        <view
          style={{
            height: '40vh',
            padding: '10PX',
            display: 'flex',
          }}
        >
          {Array.from({ length: limit, }).map((it, i) => (
            <view
              key={i}
              style={{
                height: '100%',
                overflow: 'auto',
                borderLeft: i > 0 ? '.5PX solid #eee' : 'none',
                flex: 1,
              }}
            >
              {areaData[i]?.map((item, j) => {
                const index = areaValue.findIndex(item1 => item1 == item.type_id)
                const isActive = index > -1
                return (
                  <view
                    key={j}
                    style={{
                      textAlign: 'center',
                      height: '34PX',
                      lineHeight: '34PX',
                      color: isActive ? '#eaa218' : '#444',
                    }}
                    onClick={() => {
                      if (i == 0) {
                        // 第一级正常显示
                        setArea(0, item.type_id)
                      } else {
                        // 第二级多选
                        if (isActive) {
                          areaValue.splice(index, 1)
                        } else {
                          areaValue.push(item.type_id)
                        }
                        setValue([ ...areaValue, ])
                      }
                    }}
                  >
                    {item.type_name}
                  </view>
                )
              })}
            </view>
          ))}
        </view>
      )}
      modalTitle={(setShow) => {
        return (
          <view
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '10PX',
              borderBottom: '.5PX solid #eee',
            }}
          >
            <view
              style={{ color: '#eaa218', }}
              onClick={() => {
                setShow(false)
              }}
            > 取消 </view>
            <view> {modalTitle} </view>
            <view
              style={{ color: '#eaa218', }}
              onClick={() => {
                // 去掉父级
                areaValue.shift()
                onChange(areaValue)
                setShow(false)
              }}
            >确定</view>
          </view>
        )
      }}
      title={(setShow) => (
        <view
          style={{ color: (_title && !disabled) ? '#333' : '#a8a8a8', }}
          onClick={() => {
            if (!disabled) {
              setValue(value ? [ _getParentCode(value[0]), ...value, ] : [],)
              setShow(true)
            }
          }}
        >{_title || placeholder}</view>
      )}

    />
  )
}
