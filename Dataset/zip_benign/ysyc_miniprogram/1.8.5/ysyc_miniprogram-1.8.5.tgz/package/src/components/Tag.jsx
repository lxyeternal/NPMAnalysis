
const tagTheme = getTheme()

export default function({
  title = '',
  type = 'primary',
  size = 'mini',
  round = false,
  effect = 'light',
  style = {},
}) {
  const getColorMap = (_type) => {
    const colorValue = tagTheme[_type]
    return {
      light: {
        backgroundColor: `rgba(${utils.set16ToRgb(colorValue)}, .2)`,
        color: colorValue,
      },
      dark: {
        backgroundColor: colorValue,
        color: '#fff',
      },
      plain: {
        backgroundColor: '#fff',
        color: colorValue,
      },
    }
  }
  let _tagColor = getColorMap(type)[effect]
  if (!title) {
    return false
  }
  return (
    <text
      style={{
        padding: tagTheme.tagPadding[size],
        alignItems: 'center',
        height: tagTheme.tagHeight[size],
        fontSize: tagTheme.tagSize[size],
        color: _tagColor.color,
        borderRadius: round ? '10PX' : '2PX',
        boxSizing: 'border-box',
        border: effect == 'light' ? 'none' : `1PX solid ${_tagColor.color}`,
        backgroundColor: _tagColor.backgroundColor,
        whiteSpace: 'nowrap',
        ...style,
      }}
    >
      {title}
    </text>
  )
}
