
export default (props = {}) => {
  const {
    multiple,
    onChange = () => null,
    type = 'image',
    value,
    placeholder,
    isPrivate = true,
    style = {},
    width,
    height,
    crossAxisCount = 3,
    extraSpace = 40,
  } = props
  // 删除style, 会影响itemStyle
  delete props.style
  const {
    loading, uploadFiles, removeFile, uploadValue,
  } = useUpload({
    value,
    multiple,
    isPrivate,
    onChange,
    type,
  })

  const buttonClick = useCallback(({ name, disabled, }) => {
    if (disabled) {
      return false
    }
    if (type == 'camera') {
      eventCenter.off('cameraDone').on('cameraDone', (v) => {
        onChange(v)
        Taro.navigateBack()
      })
      Taro.navigateTo({ url: '/pages/camera/index', })
    } else if (type == 'image') {
      Taro.chooseImage({
        // sourceType: ['camera'],
        success(res) {
          uploadFiles(
            multiple ? res.tempFilePaths : res.tempFilePaths[0], name, 10, 'image'
          )
        },
        fail(err) {
          console.error(err)
        },
      })
    } else if (type == 'file') {
      Taro.chooseMessageFile({
        count: 10,
        type: 'file',
        success: function(res) {
          // tempFilePath可以作为img标签的src属性显示图片
          // console.log('tempFilePaths :>> ', res)
          if (res.tempFiles.length) {
            uploadFiles(
              res.tempFiles.map(item => item.path), res.tempFiles[0].name, 10, 'file'
            )
          }
        },
        fail(err) {
          console.error(err)
        },
      })
    } else if (type == 'all') {
      Taro.showActionSheet({
        itemList: [ '图片', '视频', ],
        success(rs) {
          if (rs.tapIndex == 0) {
            Taro.chooseImage({
              // sourceType: ['camera'],
              success(res) {
                uploadFiles(
                  multiple ? res.tempFilePaths : res.tempFilePaths[0], name, 10, 'image'
                  // res.tempFilePaths[0], name, 10, 'image'
                )
              },
              fail(err) {
                console.error(err)
              },
            })
          } else if (rs.tapIndex == 1) {
            Taro.chooseVideo({
              // sourceType: 'album',
              success(res) {
                uploadFiles(
                  res.tempFilePath, name, 10, 'video'
                )
              },
              fail(err) {
                console.error(err)
              },
            })
          }
        },
        fail: function(res) {
          console.log(res.errMsg)
        },
      })
    } else {
      Taro.chooseVideo({
        // sourceType: 'album',
        success(res) {
          uploadFiles(res.tempFilePath, name)
        },
        fail(err) {
          console.error(err)
        },
      })
    }
  }, [
    onChange,
    type,
    uploadFiles,
  ])
  // }, [uploadFiles])

  // 图片的间隔
  const space = 5
  const ww = Taro.getSystemInfoSync().windowWidth
  const getSize = (size) => {
    let _size = (ww - extraSpace + (space * 2)) / crossAxisCount
    /* if (!multiple) {
            _size = 100
        } */
    return utils.parseSize(size || _size)
  }
  const itemStyle = {
    width: getSize(width),
    height: getSize(height),
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    boxSizing: 'border-box',
    padding: `${space}PX`,
  }
  const itemInnerStyle = {
    width: '100%',
    height: '100%',
    boxSizing: 'border-box',
    verticalAlign: 'top',
  }
  const showButton = () => {
    const ss = {
      content: '',
      position: 'absolute',
      top: '50%',
      left: '50%',
      display: 'inline-block',
      width: '25PX',
      height: '1PX',
      borderRadius: '1PX',
      background: '#ccc',
    }
    let showButtonInner = (
      <view>
        <view
          style={{
            ...ss,
            transform: 'translate3d(-50%, -50%, 0) rotate(0deg)',
          }}
        />
        <view
          style={{
            ...ss,
            transform: 'translate3d(-50%, -50%, 0) rotate(90deg)',
          }}
        />
      </view>
    )
    if (loading) {
      showButtonInner = (<Loading />)
    }
    return (
      <view
        style={itemStyle}
        onClick={() => buttonClick(props)}
      >
        <view
          style={{
            border: '1PX solid #eee',
            ...itemInnerStyle,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {showButtonInner}
        </view>
      </view>
    )
  }
  const closeButton = (i) => {
    const ss = {
      content: '',
      position: 'absolute',
      top: '50%',
      left: '50%',
      display: 'inline-block',
      width: '10PX',
      height: '1PX',
      borderRadius: '1PX',
      background: '#FFF',
    }
    return (
      <view
        style={{
          right: `${space}PX`,
          top: `${space}PX`,
          width: '22PX',
          height: '22PX',
          borderBottomLeftRadius: '5PX',
          backgroundColor: 'rgba(0,0,0,.5)',
          position: 'absolute',
        }}
        onClick={() => removeFile(i)}
      >
        <view
          style={{
            ...ss,
            transform: 'translate3d(-50%, -50%, 0) rotate(-45deg)',
          }}
        />
        <view
          style={{
            ...ss,
            transform: 'translate3d(-50%, -50%, 0) rotate(45deg)',
          }}
        />
      </view>
    )
  }
  const renderPlaceholder = () => {
    if (typeof placeholder == 'function') {
      return placeholder()
    } else if (placeholder) {
      return (
        <view
          style={{
            color: '#999',
            fontSize: '12PX',
            marginBottom: '5PX',
          }}
        >{placeholder}</view>
      )
    }
    return false
  }
  return (
    <view
      style={{ width: '100%', }}
    >
      {renderPlaceholder()}
      <view
        style={{
          display: 'flex',
          // justifyContent: 'space-between',
          flexWrap: 'wrap',
          margin: `0 -${space}PX`,
          ...style,
        }}
      >
        {uploadValue.map((item, i) => (
          <view
            key={i}
            style={itemStyle}
            {...props}
          >
            {(() => {
              const itemInnerStyle1 = {
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#999',
                fontSize: '30PX',
                border: '1PX solid #eee',
                boxSizing: 'border-box',
              }
              if (([ 'image', 'camera', ].includes(type) || item.type == 'image')) {
                return (
                  <Image
                    src={item.url}
                    style={itemInnerStyle}
                    onClick={() => { // 需要预览的图片http链接列表
                      Taro.previewImage({ urls: [ item.url, ], })
                    }}
                  />
                )
              } else if (type == 'video') {
                return (
                  <view
                    class='icon-video iconfont-ysyc'
                    style={{
                      ...itemInnerStyle,
                      ...itemInnerStyle1,
                    }}
                    onClick={() => {
                      wx.previewMedia({
                        sources: [
                          {
                            url: item.url,
                            type: 'video',
                          },
                        ],
                      })
                    }}
                  />
                )
              }
              return (
                <view
                  class='icon-24gl-fileText iconfont-ysyc'
                  style={{
                    ...itemInnerStyle,
                    ...itemInnerStyle1,
                  }}
                  onClick={() => {
                  }}
                />
              )
            })()}
            {!props.disabled && closeButton(i)}
          </view>
        ))}
        {(!uploadValue.length || multiple) && showButton()}
      </view>
    </view>
  )
}
