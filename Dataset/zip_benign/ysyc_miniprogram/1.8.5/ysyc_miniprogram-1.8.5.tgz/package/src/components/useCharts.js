import uCharts from '../service/charts'

let uChartsInstance = {}
export default ({
  type = 'ring', width = '100%', height = 250, title = {}, subtitle = {}, id = 'chart1', chartOpts = {},
} = {}) => {
  const systemInfo = useRef({})
  // const newOpts = useRef({})
  const drawCharts = () => {
    const ww = width == '100%' ? systemInfo.current.windowWidth : width
    // const pixelRatio = systemInfo.current.pixelRatio
    let ctx = wx.createCanvasContext(id)
    uChartsInstance[id] = new uCharts({
      type,
      context: ctx,
      width: ww,
      height: height,
      series: [],
      // series: newOpts.current.series,
      // pixelRatio: pixelRatio,
      animation: true,
      rotate: false,
      rotateLock: false,
      background: '#FFFFFF',
      color: [
        '#1890FF',
        '#91CB74',
        '#FAC858',
        '#EE6666',
        '#73C0DE',
        '#3CA272',
        '#FC8452',
        '#9A60B4',
        '#ea7ccc',
      ],
      padding: [
        30,
        30,
        30,
        30,
      ],
      dataLabel: true,
      legend: {
        show: false,
        position: 'bottom',
        lineHeight: 25,
      },
      title: {
        name: '',
        fontSize: 14,
        color: '#666666',
        ...title,
      },
      subtitle: {
        name: '',
        fontSize: 22,
        color: '#222222',
        ...subtitle,
      },
      extra: {
        arcbar: {
          type: 'default',
          width: 12,
          backgroundColor: '',
          startAngle: 0.75,
          endAngle: 0.25,
          gap: 2,
          linearType: 'custom',
          customColor: [ '#477eff', ],
        },
        ring: {
          ringWidth: 15,
          activeOpacity: 0.5,
          activeRadius: 10,
          offsetAngle: 0,
          labelWidth: 15,
          border: true,
          borderWidth: 3,
          borderColor: '#FFFFFF',
        },
      },
      ...chartOpts,
    })
    // const query = wx.createSelectorQuery()
    /* query.select(`#${id}`).
      fields({
        node: true,
        size: true,
      }).exec((res) => {
        if (res[0]) {
          const canvas = res[0].node
          const ctx = canvas.getContext('2d')
          canvas.width = ww * pixelRatio
          canvas.height = height * pixelRatio
          uChartsInstance[id] = new uCharts({
          })
        } else {
          console.error('[uCharts]: 未获取到 context')
        }
      })  */
  }
  const updateData = (args) => {
    if (uChartsInstance[id]) {
      // drawCharts()
      uChartsInstance[id].updateData(args)
    }
  }
  useEffect(() => {
    systemInfo.current = wx.getSystemInfoSync()
    drawCharts()
    return () => {
      // destroye(id)
      uChartsInstance = {}
    }
  }, [])
  const getChartPorps = (args = { }) => {
    return {
      canvasId: id,
      id,
      // type: '2d',
      ...args,
      style: {
        width: utils.parseSize(width),
        height: utils.parseSize(height),
        boxSizing: 'border-box',
        ...(args.style || {}),
      },
    }
  }
  const destroye = (_id) => {
    if (_id) {
      delete uChartsInstance[_id]
    } else {
      uChartsInstance = {}
    }
  }
  return {
    destroye,
    getChartPorps,
    updateData,
  }
}
