
export default function({
  width,
  height,
  value = [],
  extraSpace = 40,
  crossAxisCount = 3,
}) {
  const space = 5
  const getSize = (size) => {
    return size || `calc((100vw - ${extraSpace}PX) / ${crossAxisCount} - ${space * 2}PX)`
  }
  if (process.env.NODE_ENV == 'development') {
    if (!Array.isArray(value)) {
      console.log('Images: value 不是一个数组')
    }
  }
  return (
    <view
      style={{ width: '100%', }}
    >
      {value?.map((item, i) => {
        return (
          <Image
            key={i}
            isThumb
            src={item}
            style={{
              width: getSize(width),
              height: getSize(height),
              marginRight: `${space}PX`,
            }}
            onClick={() => {
              utils.previewImage(value, i)
            }}
          />
        )
      })}
    </view>
  )
}
