
export default function({ height = '28PX', width = '60PX', }) {
  const [ src, setSrc, ] = useState(configs.CAPTCHA_URL)
  return (
    <image
      src={src}
      style={{
        height,
        width,
      }}
      onClick={() => {
        setSrc(`${src}?`)
      }}
    />
  )
}
/*
import React, { useState, useMemo, useEffect } from 'react'
import { configs.CAPTCHA_URL, } from '@/config'
//import { Image, } from '@/components'
import Taro, { useDidShow, } from '@tarojs/taro'
import { Image } from '@tarojs/components'
import { getGlobalKey, generateGlobalKey, getCookie, setCookie } from '@/service/utils'

export default function({ height = '28PX', width = '60PX', }) {
    const [ src, setSrc ] = useState(configs.CAPTCHA_URL)
    useDidShow(() => {
        console.log('useDidShow')
    })
    const [skey, setKey] = useState(getGlobalKey('captcha'))
    const [imgData, setImgData] = useState('')
    useEffect(() => {
        if (src !='' && skey != '') {
            const _ckey = 'CAPTCHA_KEY'
            let _data = Taro.getStorageSync(_ckey)
            if (_data != null && _data.key == skey && _data.expired < (new Date()).getTime()) {
                console.log('get image form cache')
                setImgData(_data.data)
            } else {
                console.log('get image form remote')
                Taro.request({
                    url: src + '?key=' + skey,
                    responseType: 'arraybuffer',
                    useStore: true,
                    header: {
                        Cookies: getCookie(src)
                    },
                    success: (rs) => {
                        console.log(rs)
                        if (rs.statusCode == 200) {
                            let cookies = (rs.header['Set-Cookie'] || '').replace(/,/g, ';')
                            if (cookies != '') {
                                setCookie(src, cookies)
                            }

                            let contentType = rs.header['Content-Type'].split(';')[0].replace(/^\s+/,'').replace(/\s+$/,'')
                            let _imgData = `data:${contentType};base64,${Taro.arrayBufferToBase64(rs.data).replace(/[\r\n]/g, '')}`
                            Taro.setStorageSync(_ckey, {key:skey, data:_imgData, expired: (new Date()).getTime() + 180})
                            setImgData(_imgData)
                        } else {
                            console.error(rs)
                        }

                    }
                })
            }

        }

        return () => {

        };
    }, [src, skey]);
    //const img = useMemo(() => {

        return (
            <Image
                //src={src + '?id=' + getGlobalKey('captcha')}
                src={imgData}
                style={{
                    height,
                    width,
                }}

                onClick={() => {
                    //setSrc(`${src}?`)
                    generateGlobalKey('captcha')
                    setKey(getGlobalKey('captcha'))
                }}
            />
        )
    //}, [ src ])
    //return img
}

*/
