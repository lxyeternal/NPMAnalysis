
export default function({
  style = {},
  onClick,
  placeholder = '请输入关键词查询',
  active: _active,
  value: _value,
  focus = false,
  onActive = utils.noop,
  onChange = utils.noop,
  showCancel = true,
  showOk = false,
  emptyValue = -999,
}) {
  const [ value, setValue, ] = useState(_value)
  const [ active, setActive, ] = useState(false)
  const _onChange = (v) => {
    if (v === '') {
      onChange(emptyValue)
    } else {
      onChange(v)
    }
  }

  useEffect(() => {
    setActive(_active)
  }, [])
  return (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        padding: '10PX 15PX',
        boxSizing: 'border-box',
        height: '60PX',
        // borderBottom: '1PX solid #e5e5e5',
        backgroundColor: '#fff',
        ...style,
      }}
      onClick={() => {
        if (onClick) {
          onClick()
        }
      }}
    >
      <view
        style={{
          backgroundColor: '#F1F2F6',
          padding: '0 15PX',
          borderRadius: '18PX',
          fontSize: '14PX',
          color: '#999',
          display: 'flex',
          alignItems: 'center',
          height: '36PX',
          flex: 1,
        }}
      >
        <view
          class='icon-sy_sousuo iconfont-ysyc'
          // key='search'
          style={{
            marginRight: '5PX',
            fontSize: '14PX',
          }}
        />
        <input
          focus={focus}
          placeholder={placeholder}
          style={{
            // backgroundColor: 'red',
            flex: 1,
          }}
          value={value}
          onClick={() => {
            if (!active && !onClick) {
              setActive(true)
              onActive(true)
            }
          }}
          onConfirm={(e) => {
            const _val = e.detail.value
            _onChange(_val)
          }}
          onInput={(e) => {
            const _val = e.detail.value
            setValue(_val)
          }}
        />
      </view>
      {active && showOk && (
        <Button
          style={{ marginLeft: '15PX', }}
          title='搜索'
          type='text-primary'
          onClick={() => {
            _onChange(value)
          }}
        />
      )}
      {active && showCancel && (
        <Button
          style={{ marginLeft: '15PX', }}
          title='取消'
          type='text-primary'
          onClick={() => {
            setActive(false)
            setValue('')
            onActive(false)
            _onChange('')
          }}
        />
      )}
    </view>
  )
}
