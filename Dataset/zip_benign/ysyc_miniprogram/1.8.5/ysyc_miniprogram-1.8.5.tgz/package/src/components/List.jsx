
export default function({
  data = [],
  renderItem,
  // 下拉刷新
  onRefresherRefresh = () => null,
  // 滚动到底部
  onScrollToLower = () => null,
  renderHeader = () => null,
  // 弹窗有问题时可设备成false or 内部有使用fixed需要设置为false
  refresherEnabled = true,
  extraHeight = 41,
  loading = false,
  isEmpty = false,
  scrollabled = true,
  className,
  children,
  style = {},
}) {
  const [ refresher, setRefresher, ] = useState(false)
  let freshing = false
  const stop = () => {
    setRefresher(false)
    freshing = false
  }
  const renderAlert = () => {
    if (loading) {
      return (
        <Alert
          text
          title='加载中...'
        />
      )
    }
    if (!data.length) {
      return (
        <Alert
          style={{ padding: '30PX', }}
          text
        />
      )
    }
    if (isEmpty) {
      return (
        <Alert
          text
          title='没有了！'
        />
      )
    }
  }
  const getHeight = () => {
    if (!data.length) {
      return 'auto'
    }
    return `calc(100vh - (${utils.parseSize(extraHeight)} + env(safe-area-inset-bottom)))`
  }
  return (
    <scroll-view
      class={className}
      lowerThreshold={50}
      refresher-background='transparent'
      refresherTriggered={refresher}
      scrollWithAnimation
      scrollY={scrollabled}
      style={{
        height: getHeight(),
        boxSizing: 'border-box',
        ...style,
      }}
      onRefresherRefresh={() => {
        if (freshing) {
          return
        }
        freshing = true
        setRefresher(true)
        onRefresherRefresh()
        setTimeout(() => {
          stop()
        }, 1000)
      }}
      onScrollToLower={onScrollToLower}
      trapScroll
      // refresherThreshold={45}
      refresherEnabled={refresherEnabled}
    >
      {renderHeader()}
      {data?.length > 0 && (children ?? data.map((item, i) => {
        return renderItem?.(item, i) ?? (<view>请设置renderItem！</view>)
      }))}
      {renderAlert()}
    </scroll-view >
  )
}
