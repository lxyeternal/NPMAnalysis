
export default function({
  title = '', modalTitle,
  style = {}, modalStyle = {}, modalBodyStyle = {}, modalContentStyle = {},
  url, params = {}, formItems = [], show = false, position = 'bottom', labelStyle,
  onSubmitted, onClose, onShow, ajaxBefore,
  message = true,
}) {
  const {
    SubmitButton, formData, setFormData, formProps,
  } = useForm({
    url,
    data: params,
    message,
  })

  return (
    <Modal
      modalContent={(setShow) => {
        return (
          <Form
            {...formProps}
            footer={(
              <SubmitButton
                title='提交'
                onClick={(_handleSubmit) => {
                  if (ajaxBefore?.(formData, setShow) === false) {
                    return
                  }
                  _handleSubmit({
                    ajaxThen: (rs) => {
                      if (onSubmitted) {
                        onSubmitted(rs)
                      }
                      if (rs.code == configs.RESULT_TEMPLATE.code) {
                        setShow(false)
                      }
                    },
                  })
                }}
              />
            )}
            footerStyle={{ margin: '0 0 20PX', }}
            items={formItems}
            labelStyle={labelStyle}
            style={{
              margin: '0',
              ...modalBodyStyle,
            }}
          />
        )
      }}
      modalContentStyle={modalContentStyle}
      modalStyle={modalStyle}
      modalTitle={modalTitle}
      position={position}
      show={show}
      style={style}
      title={title}
      onClose={onClose}
      onShow={() => {
        if (onShow) {
          onShow()
        }
        setFormData(params)
      }}
    />

  )
}
