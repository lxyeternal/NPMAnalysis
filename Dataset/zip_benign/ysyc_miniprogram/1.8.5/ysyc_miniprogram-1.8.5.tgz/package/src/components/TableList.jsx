/* eslint-disable complexity */

const primaryLight = getTheme('primaryLight')
export default function({
  style = {},
  data = {},
  columns = [],
  headerStyle = {},
  rowStyle = () => ({}),
  cellStyle = () => ({}),
  border = false,
  onSelectionChange = utils.noop,
  onClickRow = utils.noop,
}) {
  const { fieldTitle, } = useCategory()
  const [ _checked, _setChecked, ] = useState([])
  const _getShow = (item) => {
    if (typeof item.show == 'function') {
      return item.show(data ?? {})
    }
    return item.show ?? true
  }
  const getTdStyle = (item, isHeader) => {
    const _style = {
      padding: '3PX 0',
      height: '100%',
      width: utils.parseSize(item.width),
      flex: item.width ? 'none' : 1,
      boxSizing: 'border-box',
      display: 'flex',
      alignItems: 'center',
      justifyContent: item.align ?? 'center',
      margin: '0 -0.5PX -0.5PX 0',
      borderRight: border ? '.5PX solid #D8D8D8' : '.5PX solid #fff',
      borderBottom: border ? '.5PX solid #D8D8D8' : 'none',
      ...cellStyle(),
    }
    if (!isHeader) {
      Object.assign(_style, (item.style || {}))
    }
    return _style
  }
  const renderHeader = (_columns) => {
    return (
      <view
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          backgroundColor: primaryLight,
          height: '40PX',
          alignItems: 'center',
          ...headerStyle,
        }}
      >
        {_columns.map((item, i) => {
          if (!_getShow(item)) {
            return false
          }
          return (
            <view
              key={i}
              style={{
                ...getTdStyle(item, 1),
                backgroundColor: headerStyle.backgroundColor || primaryLight,
              }}
            >
              {item.label}
            </view>
          )
        })}
      </view>
    )
  }
  const renderBody = (_columns) => {
    return data.map((_data, j) => {
      return (
        <view
          key={j}
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            height: '34PX',
            alignItems: 'center',
            ...rowStyle(_data),
          }}
          onClick={() => onClickRow(_data, j)}
        >
          {_columns.map((item, i) => {
            if (!_getShow(item)) {
              return false
            }
            // 原始值
            let _val = utils.getObjectValue(_data, item.prop)
            // 渲染后的值
            let itemValue
            if (item.hasOwnProperty('render')) {
              itemValue = typeof item.render == 'function' ?
                item.render({
                  value: _val,
                  row: _data,
                  index: j,
                  fieldTitle,
                }) :
                item.render
            } else if (item.type == 'selection') {
              const _index = _checked.findIndex(it => it == _data.id)
              const _isChecked = _index > -1
              const _disabled = typeof item.disabled == 'function' ?
                item.disabled({ row: _data, }) :
                item.disabled
              itemValue = (
                <Checkbox
                  disabled={_disabled}
                  value={_isChecked}
                  onChange={() => {
                    if (!_isChecked) {
                      _checked.push(_data.id)
                    } else {
                      _checked.splice(_index, 1)
                    }
                    _setChecked([ ..._checked, ])
                    onSelectionChange(_checked)
                  }}
                />
              )
            } else if (item.type == 'date') {
              itemValue = utils.date(_val, 'YYYY-MM-DD')
            } else if (item.type == 'dateTime') {
              itemValue = utils.date(_val)
            } else if (item.type == 'fieldTitle') {
              itemValue = (item.prefix ?? '') + fieldTitle({
                value: _val,
                prop: item.alias ?? item.prop,
                data: item.data,
                render(valueItem, titles) {
                  if (Array.isArray(_val)) {
                    return titles
                  }
                  return <text class={valueItem.color}>{valueItem.type_name}</text>
                },
              }) + (item.suffix ?? '')
            } else if (item.type == 'image') {
              itemValue = _val
            } else {
              itemValue = (item.prefix ?? '') + (_val ?? '--') + (item.suffix ?? '')
            }
            return (
              <view
                key={i}
                style={{ ...getTdStyle(item), }}
              >
                {itemValue}
              </view>
            )
          })}
        </view>
      )
    })
  }

  const _columnsFixed = columns.filter(item => item.fixed)
  return (
    <view
      style={{
        fontSize: '13PX',
        // borderLeft: border ? '.5PX solid #D8D8D8' : 'none',
        // borderTop: border ? '.5PX solid #D8D8D8' : 'none',
        border: border ? '.5PX solid #D8D8D8' : 'none',
        position: 'relative',
        ...style,
      }}
    >
      {_columnsFixed.length ?
        (
          <>
            <view
              style={{
                position: 'absolute',
                left: 0,
                top: 0,
                zIndex: 99,
                backgroundColor: '#fff',
              }}
            >
              {renderHeader(_columnsFixed)}
              {renderBody(_columnsFixed)}
            </view>
            <view
              style={{ overflowX: 'auto', }}
            >
              {renderHeader(columns)}
              {data.length ?
                renderBody(columns) :
                (
                  <Alert
                    style={{ fontSize: '12PX', }}
                    text
                  />
                )}
            </view>
          </>
        ) :
        (
          <>
            {renderHeader(columns)}
            {data.length ?
              renderBody(columns) :
              (
                <Alert
                  style={{ fontSize: '12PX', }}
                  text
                />
              )}
          </>
        )}

    </view>
  )
}
