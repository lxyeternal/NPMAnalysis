
export default function({
  data = [], value: _value = [], onChange, prop = 'type_id',
} = {}) {
  const [ value, setValue, ] = useState(_value)
  const [ valueItem, setValueItem, ] = useState([])
  const first = useRef(true)
  useEffect(() => {
    // 第一次或有value才执行，否则死循环
    if (Array.isArray(_value) && (!first.current || _value.length)) {
      setValue(_value)
      first.current = false
    }
  }, [ _value, ])
  const getTitle = (val) => {
    let newVal = []
    data.forEach(item => {
      const _v = prop ? item[prop] : item
      if (val.includes(_v)) {
        newVal.push(item.type_name)
      }
    })

    return newVal.length ? newVal.join('、') : null
  }
  const getItemInfo = (item) => {
    const _v = prop ? item[prop] : item
    const index = value.findIndex(it => it == _v)
    const isActive = index > -1 //&& !!_value.length
    const onClickItem = () => {
      if (!isActive) {
        value.push(_v)
        valueItem.push(item)
      } else {
        value.splice(index, 1)
        valueItem.splice(index, 1)
      }
      setValue([ ...value, ])
      setValueItem([ ...valueItem, ])
      if (onChange) {
        onChange(value, valueItem)
      }
    }
    return {
      index,
      isActive,
      onClickItem,
    }
  }
  return {
    value,
    valueItem,
    getTitle,
    getItemInfo,
  }
}
