
const { primary, } = getTheme()
let _resolve
export default function({
  modalTitle = '隐私保护指引',
  style = {}, modalStyle = {}, modalContentStyle = {},
  position = 'center',
  content,
  onClose = utils.noop, onShow,
  onAgreePrivacyAuthorization = utils.noop,
  onDisagreePrivacyAuthorization = utils.noop,
}) {
  const [ show, setShow, ] = useState()
  useDidShow(() => {
    wx.onNeedPrivacyAuthorization((resolve) => {
      _resolve = resolve
      setShow(true)
    })
  })
  const _content = content ?? (
    <view
      style={{
        fontSize: '14PX',
        lineHeight: '1.8',
      }}
    >
      在使用前,请仔细阅读<text
        style={{ color: primary, }}
        onClick={() => {
          wx.openPrivacyContract()
        }}
      >《隐私保护指引》</text>。如果您同意《隐私保护指引》，请点击＂同意＂开始使用。
    </view>
  )
  return (
    <Modal
      closeOnClickModal={false}
      destroyOnClose={false}
      modalContent={() => {
        return (
          <view
            style={{ padding: '15PX', }}
          >
            {_content}
            <view
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: '15PX',
              }}
            >
              <Button
                size='small'
                style={{
                  color: '#666',
                  backgroundColor: '#eee',
                  marginRight: '15PX',
                }}
                title='拒绝'
                type='info'
                onClick={(e) => {
                  _resolve({ event: 'disagree', })
                  onDisagreePrivacyAuthorization(e)
                  setShow(false)
                }}
              />
              <Button
                id='agree-btn'
                openType='agreePrivacyAuthorization'
                size='small'
                title='同意'
                onAgreePrivacyAuthorization={(e) => {
                  _resolve({
                    event: 'agree',
                    buttonId: 'agree-btn',
                  })
                  onAgreePrivacyAuthorization(e)
                  setShow(false)
                }}
              />
            </view>
          </view>
        )
      }}
      modalContentStyle={{ ...modalContentStyle, }}
      modalStyle={modalStyle}
      modalTitle={modalTitle}
      position={position}
      show={show}
      style={style}
      onClose={(...args) => {
        onClose(...args)
        setShow(false)
      }}
      onShow={() => {
        if (onShow) {
          onShow()
        }
      }}
    />

  )
}
