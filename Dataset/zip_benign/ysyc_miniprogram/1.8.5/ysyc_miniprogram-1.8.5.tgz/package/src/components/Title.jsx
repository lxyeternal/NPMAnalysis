
export default function({
  title, action, size = 20, color = '#333', style = {}, titleIcon, titleStyle = {}, actionStyle = {}, titleSub = '', onClick = () => null,
}) {
  return (
    <view
      style={{
        padding: '10PX 0',
        display: 'flex',
        alignItems: 'center',
        ...style,
      }}
      onClick={onClick}
    >
      {!!titleIcon && (
        <view
          class={`iconfont-ysyc iconfont ${titleIcon}`}
          style={{
            fontSize: '16PX',
            color: '#666',
            marginRight: '5PX',
          }}
        />
      )}
      <view
        style={{
          fontSize: `${size}PX`,
          fontWeight: 'bold',
          color,
          ...titleStyle,
        }}
      >
        {title}
      </view>
      {titleSub}
      {!!action && (
        <view
          style={{
            marginLeft: 'auto',
            color: '#999',
            ...actionStyle,
          }}
        >
          {typeof action == 'function' ? action() : action}
        </view>
      )}
    </view>
  )
}
