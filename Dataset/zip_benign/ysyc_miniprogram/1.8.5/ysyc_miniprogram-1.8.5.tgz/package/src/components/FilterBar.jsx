
const { primary, } = getTheme()
function ItmeLayout({
  label, labelSub, children,
}) {
  return (
    <>
      <view
        style={{
          fontSize: '16PX',
          color: '#333',
          fontWeight: 'bold',
          padding: '5PX 0',
        }}
      >
        {label}
        <text
          style={{
            fontSize: '14PX',
            color: '#999',
          }}
        >{labelSub}</text>
      </view>
      <view
        style={{
          display: 'flex',
          padding: '5PX 0',
          flexWrap: 'wrap',
          borderBottom: '1PX solid #ededed',
          marginBottom: '10PX',
        }}
      >
        {children}
      </view>
    </>
  )
}

// 多选和单选差不多，写一起了
function Check({
  value, option, onChange = () => null,
}) {
  let multiple = option.type == 'checkbox'
  const [ _value, setValue, ] = useState(value ?? (multiple ? [] : null))
  useEffect(() => {
    setValue(value ?? (multiple ? [] : null))
  }, [ value, ])
  return (
    <ItmeLayout
      label={option.label}
      labelSub={multiple ? '(多选)' : ''}
    >
      {option.data?.map((item, i) => {
        const isActive = multiple ? _value.includes(item.type_id) : _value == item.type_id
        return (
          <view
            key={i}
            style={{
              width: '72PX',
              height: '32PX',
              lineHeight: '32PX',
              textAlign: 'center',
              borderRadius: '2PX',
              backgroundColor: isActive ? '#EBF2FE' : '#F4F4F4',
              margin: ((i + 1) % 4 == 0 && i != 0) ? '5PX 0 5PX 0' : '5PX 10PX 5PX 0',
              fontSize: '13PX',
              color: isActive ? primary : '#73777A',
            }}
            onClick={() => {
              if (multiple) {
                if (isActive) {
                  let _index = _value.findIndex(it => it == item.type_id)
                  if (_index > -1) {
                    _value.splice(_index, 1)
                  }
                } else {
                  _value.push(item.type_id)
                }
                setValue(_value)
                onChange(_value)
              } else {
                setValue(item.type_id)
                onChange(isActive ? -999 : item.type_id)
              }
            }}
          >
            {item.type_name}
          </view>
        )
      }) ?? <view>请设置data!</view>}
    </ItmeLayout>
  )
}

function Area({
  onChange = () => null, value, limit = 3,
}) {
  // const city = JSON.parse(Taro.getStorageSync('city') || '{}')
  let defaultValue = value ?? [ ]
  // let defaultValue = value ?? [ city.parentcode, city.code, ]
  // 区域相关
  const {
    areaData, setArea, areaValue,
  } = useArea({
    value: defaultValue,
    // limit,
  })
  const _getItem = (
    item, j, onClick = (() => null), isActive
  ) => {
    const _isActive = isActive ?? areaValue.includes(item.type_id)
    return (
      <view
        key={j}
        style={{
          padding: '10PX 0',
          color: _isActive ? primary : '#333',
        }}
        onClick={onClick}
      >
        {item.type_name}
      </view>
    )
  }
  return (
    <view
      style={{ display: 'flex', }}
    >
      {Array.from({ length: limit, }).map((n, i) => {
        const items = areaData[i] ?? []
        /* if (i < 2) {
                    return false
                } */
        return (
          <view
            key={i}
            style={{
              padding: '5PX 10PX 5PX 20PX',
              flex: 1,
              maxHeight: '60vh',
              overflow: 'auto',
              borderLeft: i > 0 ? '1PX solid #e5e5e5' : 'none',
            }}
          >
            {i == limit - 1 && items.length > 0 && _getItem(
              {
                type_id: -999,
                type_name: '全部',
              },
              99999,
              () => {
                if (areaValue.length == limit) {
                  areaValue.pop()
                }
                onChange(areaValue)
              },
              // 最后一级不存在要高亮
              !areaValue[limit - 1]
            )}
            {items.map((item, j) => {
              return _getItem(
                item,
                j,
                () => {
                  setArea(i, item.type_id)
                  // 最后一级才请求
                  if (i == limit - 1) {
                    onChange(areaValue)
                  }
                }
              )
            })}
          </view>
        )
      })}
    </view>
  )
}

// FilterBar
export default function({
  options, onChange = () => null, params = {}, extraHeight = 0, onShowToggle = () => null,
}) {
  const height = 40
  const [ _index, setIndex, ] = useState()

  const [ _params, setParams, ] = useState(params)

  const [ _show, setShow, ] = useState(false)

  if (!options.length) {
    return false
  }
  const show = () => {
    setShow(true)
    onShowToggle(true)
  }

  // 关闭弹窗
  let hide = () => {
    setIndex(null)
    setShow(false)
    onShowToggle(false)
  }
  let _onChange = () => {
    // console.log(_params)
    onChange(_params)
  }
  let _renderContent = () => {
    const option = options[_index]
    const _type = option.type ?? 'select'
    if (_type == 'date') {
      return false
    }
    // 更多
    if (option.items) {
      return (
        <view>
          <view
            style={{
              padding: '10PX 20PX',
              overflow: 'auto',
              maxHeight: '60vh',
            }}
          >
            {option.items.map((item, i) => {
              const { type: itemType = 'radio', } = item
              if (itemType == 'block') {
                return item.render()
              } else if (itemType == 'render') {
                return (
                  <ItmeLayout label={item.label}>
                    {item.render()}
                  </ItmeLayout>
                )
              } else if ([ 'checkbox', 'radio', ].includes(itemType)) {
                return (
                  <Check
                    key={i}
                    option={item}
                    value={_params[item.prop]}
                    onChange={(val) => {
                      _params[item.prop] = val
                      setParams({ ..._params, })
                    }}
                  />
                )
              }
              return false
            })}
          </view>
          <view
            style={{ display: 'flex', }}
          >
            <view
              style={{
                width: '50%',
                textAlign: 'center',
                backgroundColor: '#F6F6F6',
                fontSize: '17PX',
                height: '48PX',
                lineHeight: '48PX',
                color: ' #73777A',
              }}
              onClick={() => {
                option.items.forEach(it => {
                  delete _params[it.prop]
                })
                setParams({ ..._params, })
              }}
            >重置</view>
            <view
              style={{
                width: '50%',
                textAlign: 'center',
                backgroundColor: primary,
                fontSize: '17PX',
                height: '48PX',
                lineHeight: '48PX',
                color: ' #fff',
              }}
              onClick={() => {
                _onChange()
                hide()
              }}
            >完成</view>
          </view>
        </view >
      )
    } else if (_type == 'area') {
      return (
        <Area
          limit={option.limit}
          value={_params[option.prop]}
          onChange={(val) => {
            _params[option.prop] = val
            setParams({ ..._params, })
            _onChange()
            hide()
          }}
        />
      )
      // } else if (_type == 'date') {
      //   return (

    //   )
    } else if (_type == 'select') {
      return (
        <view
          style={{
            padding: '5PX 0',
            overflow: 'auto',
            maxHeight: '60vh',
          }}
        >
          {option.data.map((item, i) => {
            const isActive = _params[option.prop] == item.type_id
            return (
              <view
                key={i}
                style={{
                  padding: '10PX 0',
                  margin: '0 20PX',
                  fontSize: '15PX',
                  borderTop: i > 0 ? '1PX solid #EDEDED' : 'none',
                  color: isActive ? primary : '#333',
                }}
                onClick={() => {
                  if (isActive) {
                    delete _params[option.prop]
                  } else {
                    _params[option.prop] = item.type_id
                  }
                  setParams({ ..._params, })
                  _onChange()
                  hide()
                }}
              >{item.type_name}</view>
            )
          })}
        </view>
      )
    } else if (_type == 'render') {
      return option.render()
    }
    return <view>请设置内容！</view>
  }
  const _renderLabel = ({
    option, valNum,
    hasValue,
    isActive,
    index,
  }) => {
    let labelValue
    if (typeof option.label == 'function') {
      labelValue = option.label({
        onChange(val) {
          _params[option.prop] = val
          setParams({ ..._params, })
          _onChange()
        },
      })
    } else {
      labelValue = (
        <text >{option.label} {valNum > 0 ? `(${valNum})` : ''}</text>
      )
    }
    return (
      <view
        key={index}
        style={{
          fontSize: '14PX',
          display: 'flex',
          alignItems: 'center',
          height: `${height}PX`,
          color: (isActive || hasValue) ? primary : '#333',
        }}
        onClick={() => {
          if (isActive) {
            hide()
          } else {
            setIndex(index)
            if (option.type !== 'date' && option.type != 'custom') {
              show()
            }
          }
        }}
      >
        {labelValue}
        <text
          class='icon-sy_icon iconfont-ysyc'
          style={{
            color: '#D8D8D8',
            fontSize: '7PX',
            marginLeft: '5PX',
            marginTop: '2PX',
          }}
        />
      </view>

    )
  }
  return (
    <view >
      {/* bar */}
      <view
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          alignItems: 'center',
          padding: '0 10PX',
          height: `${height}PX`,
          borderBottom: '1PX solid #e5e5e5',
          backgroundColor: '#fff',
        }}
      >
        {options.map((option, i) => {
          const _type = option.type ?? 'select'
          if (_type == 'block') {
            return option.render?.() ?? false
          }

          const isActive = _index == i
          // 是否有值
          let hasValue = false
          let valNum = 0
          if (_type == 'area') {
            hasValue = _params[option.prop]?.length > 0
            // } else if (_type == 'date') {
          } else if (option.items) {
            option.items.forEach((it) => {
              if (_params[it.prop]) {
                valNum++
              }
            })
            hasValue = valNum > 0
          } else if ([
            'select',
            'radio',
            'checkbox',
          ].includes(_type)) {
            hasValue = _params[option.prop] != -999 && !!_params[option.prop]
          }
          if (_type == 'date') {
            return (
              <picker
                mode='date'
                value={_params[option.prop]}
                onChange={(e) => {
                  let val = e.detail.value
                  _params[option.prop] = val
                  setParams({ ..._params, })
                  _onChange()
                }}
              >
                {_renderLabel({
                  option,
                  hasValue,
                  isActive,
                  index: i,
                })}
              </picker>
            )
          }
          return _renderLabel({
            option,
            hasValue,
            valNum,
            isActive,
            index: i,
          })
        })}
      </view>
      {/* 弹窗 */}
      {_show && (
        <view
          style={{
            position: 'absolute',
            top: `${height + extraHeight + 1}PX`,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.5)',
            zIndex: 99999,
          }}
          onClick={() => {
            hide()
          }}
        >
          <view
            style={{ backgroundColor: '#fff', }}
            onClick={(e) => {
              e.stopPropagation()
            }}
          >
            {_renderContent()}
          </view>
        </view>
      )}
    </view>
  )
}
