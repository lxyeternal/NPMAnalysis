
const _color = getTheme('primary')

export default function({
  onChange = utils.noop, disabled, value, color, style = {},
}) {
  // const [ _value, setValue, ] = useState(value)
  // useEffect(() => {
  //     setValue(value)
  // }, [ value, ])
  return (
    <view
      class='text-muted'
      style={{
        display: 'flex',
        alignItems: 'center',
        ...style,
      }}
    >
      {value ? '开启' : '关闭'}
      <switch
        checked={!!value}
        color={color ?? _color}
        disabled={disabled}
        style={{ marginLeft: '5PX', }}
        onChange={(e) => {
          onChange(+e.detail.value)
        }}
      />
    </view>
  )
}
