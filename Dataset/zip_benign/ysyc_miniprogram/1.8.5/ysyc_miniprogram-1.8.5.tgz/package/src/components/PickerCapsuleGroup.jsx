
const { primary, } = getTheme()

export default function({
  placeholder = '请选择', disabled, data, onChange = () => null, value, titleStyle = {}, modalTitle = '请选择', clickBefore, renderTitle, renderItemTitle,
}) {
  const [ title, setTitle, ] = useState()
  const [ _value, setValue, ] = useState(value)
  useEffect(() => {
    setValue(value)
    const { type_name: typeName, } = data?.find(item => item.type_id == value) ?? {}
    setTitle(typeName)
  }, [ value, ])
  return (
    <Modal
      modalContent={(show) => (
        <view
          style={{
            maxHeight: '50vh',
            overflow: 'auto',
            display: 'flex',
            flexWrap: 'wrap',
            padding: '5PX',
          }}
        >
          {data?.map((item, i) => {
            const isActive = item.type_id == _value
            return (
              <view
                key={i}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxSizing: 'border-box',
                  width: '25%',
                  padding: '5PX',
                }}
              >
                <view
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: isActive ? '#fff' : '#444',
                    backgroundColor: isActive ? primary : '#f2f2f2',
                    border: '1PX solid #f2f2f2',
                    boxSizing: 'border-box',
                    padding: '10PX 0',
                    borderRadius: '5PX',
                    width: '100%',
                  }}
                  onClick={() => {
                    show(false)
                    if (onChange) {
                      const _val = isActive ? value : item.type_id
                      // const _val = isActive ? -999 : item.type_id
                      setValue(_val)
                      setTitle(item.type_name)
                      onChange(_val, isActive ? {} : item)
                    }
                  }}
                >
                  {renderItemTitle?.(
                    item, i, isActive
                  ) ?? item.type_name}
                </view>
              </view>
            )
          }) ?? <view>请先设置data!</view>}
        </view>
      )}
      modalTitle={modalTitle}
      title={(show) => (
        <view
          style={{
            color: (title && !disabled) ? 'inherit' : '#a8a8a8',
            // textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            height: '24PX',
            overflow: 'hidden',
            lineHeight: '24PX',
            // backgroundColor: 'blue',
            ...titleStyle,
          }}
          onClick={() => {
            if (!disabled) {
              if (clickBefore) {
                clickBefore(show)
              } else {
                show(true)
              }
            }
          }}
        >{renderTitle?.({ title, }) || (title ?? placeholder)}</view>
      )}
    />
  )
}
