
export default ({ identify = 'DEV', autoLoad = true, } = {}) => {
  const [ _cateSub, setData, ] = useState([])
  const _getData = () => {
    ajax({
      url: '/wechat/index/listSubCate',
      data: { identify, },
    }).then(res => {
      const cateSub = res.data.map(item => ({
        type_id: item.id,
        type_name: item.name,
      }))
      setData(cateSub)
    })
  }

  useEffect(() => {
    // 只执行一次
    if (autoLoad) {
      _getData()
    }
  }, [])

  return {
    cateSub: _cateSub,
    getData: _getData,
  }
}
