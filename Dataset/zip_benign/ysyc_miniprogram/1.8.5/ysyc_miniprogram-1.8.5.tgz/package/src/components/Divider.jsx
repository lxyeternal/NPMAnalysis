import React from 'react'

export default function({
  color = '#e5e5e5', width, height,
  // 垂直方向
  vertical = false, style = {},
}) {
  if (vertical) {
    return (
      <view
        style={{
          borderLeft: `1PX solid ${color}`,
          width: 0,
          height: utils.parseSize(height ?? '100%'),
          margin: `0 ${utils.parseSize(width)}`,
          ...style,
        }}
      />
    )
  }
  return (
    <view
      style={{
        borderBottom: `.5PX solid ${color}`,
        height: 0,
        width: '100%',
        margin: `${utils.parseSize(height ?? '10PX')} 0`,
        ...style,
      }}
    />
  )
}
