export default function({
  placeholder = '请选择', onChange = utils.noop, limit = 3, value, modalTitle = '请选择', disabled,
}) {
  const {
    areaData, setArea, areaValue, title, nextData,
  } = useArea({
    value,
    limit,
  })
  return (
    <Modal
      modalContent={() => (
        <view
          style={{
            height: '40vh',
            padding: '10PX',
            display: 'flex',
          }}
        >
          {Array.from({ length: limit, }).map((it, i) => (
            <view
              key={i}
              style={{
                height: '100%',
                overflow: 'auto',
                borderLeft: i > 0 ? '.5PX solid #eee' : 'none',
                flex: 1,
              }}
            >
              {areaData[i]?.map((item, j) => {
                const isActive = areaValue.includes(item.type_id)
                return (
                  <view
                    key={j}
                    style={{
                      textAlign: 'center',
                      height: '34PX',
                      lineHeight: '34PX',
                      color: isActive ? '#3E82FE' : '#444',
                    }}
                    onClick={() => {
                      setArea(i, item.type_id)
                    }}
                  >
                    {item.type_name}
                  </view>
                )
              })}
            </view>
          ))}
        </view>
      )}
      modalTitle={(setShow) => {
        return (
          <view
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '10PX',
              borderBottom: '.5PX solid #eee',
            }}
          >
            <view
              style={{ color: '#3E82FE', }}
              onClick={() => {
                setShow(false)
              }}
            > 取消 </view>
            <view> {modalTitle} </view>
            <view
              style={{ color: '#3E82FE', }}
              onClick={() => {
                if (areaValue.length == limit) {
                  onChange(areaValue, {
                    areaData,
                    nextData,
                  })
                  // generateTitle()
                  setShow(false)
                } else {
                  wx.showToast({
                    title: `请选择到${limit}级`,
                    icon: 'none',
                    duration: 2000,
                  })
                }
              }}
            >确定</view>
          </view>
        )
      }}
      title={(setShow) => (
        <view
          style={{ color: (title && !disabled) ? '#333' : '#a8a8a8', }}
          onClick={() => {
            if (!disabled) {
              setShow(true)
            }
          }}
        >{title || placeholder}</view>
      )}

    />
  )
}
