
export default function({
  children,
  content,
  contentStyle = {},
}) {
  const [ show, setShow, ] = useState(false)
  return (
    <view
      style={{ position: 'relative', }}
      onClick={() => {
        setShow(!show)
      }}
    >
      {children}
      <view
        style={{
          position: 'absolute',
          display: show ? 'block' : 'none',
          backgroundColor: '#fff',
          border: '1PX solid #eaa218',
          padding: '10PX',
          ...contentStyle,
        }}
      >
        {content()}
      </view>
    </view>
  )
}
