
const _color = getTheme('tabsActiveColor')
export default function({
  tabs = [],
  // 索引
  active,
  onClick = () => null,
  renderContent,
  contentStyle = {},
  append,
  style = {},
  itemStyle = {},
  activeItemStyle = {},
  // size = 'medium',
  fill = true,
  type = 'card', // capsule
}) {
  const [ _active, setActive, ] = useState(active ?? 0)
  const _style = {
    display: 'flex',
    alignItems: 'center',
    padding: '0 20PX',
    whiteSpace: 'nowrap',
    backgroundColor: '#fff',
    overflow: 'auto',
    height: '48PX',
  }
  if (type == 'capsule') {
    Object.assign(_style, {
      justifyContent: 'center',
      height: '30PX',
    })
  } else {
    Object.assign(_style, {
      justifyContent: fill ? 'center' : 'flex-start',
      borderBottom: '.5PX solid #eee',
    })
  }

  const _getItemStyle = (
    item, i, isActive
  ) => {
    const _itemStyle = {
      fontSize: '15PX',
      display: 'flex',
      alignItems: 'center',
      boxSizing: 'border-box',
      justifyContent: 'center',
      height: '100%',
    }
    if (type == 'capsule') {
      let _borderRadius = 0
      if (i == 0) {
        _borderRadius = '5PX 0 0 5PX'
      } else if (tabs.length - 1 == i) {
        _borderRadius = '0 5PX 5PX 0'
      }

      Object.assign(_itemStyle, {
        color: isActive ? '#fff' : _color,
        backgroundColor: isActive ? _color : '#fff',
        padding: '0 10PX',
        border: `.5PX solid ${_color}`,
        borderLeft: i == 0 ? `.5PX solid ${_color}` : 'none',
        borderRadius: _borderRadius,
      })
    } else {
      Object.assign(_itemStyle, {
        marginRight: fill ? 0 : '15PX',
        width: fill ? `calc(100% / ${tabs.length || 1})` : 'auto',
        color: isActive ? _color : '#73777a',
      })
    }
    return Object.assign(_itemStyle, {
      ...itemStyle,
      ...(isActive ? activeItemStyle : {}),
      ...(item.style || {}),
    })
  }
  return (
    <>
      <view
        style={{
          ..._style,
          ...style,
        }}
      >
        {tabs.map((item, i) => {
          let isActive = _active == i
          return (
            <view
              key={i}
              style={_getItemStyle(
                item, i, isActive
              )}
              onClick={() => {
                setActive(i)
                onClick(i, item)
              }}
            >
              <view
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderBottom: isActive ? `2PX solid ${_color}` : '2PX solid transparent',
                  boxSizing: 'border-box',
                  height: '100%',
                }}
              >{item.type_name}</view>
            </view>
          )
        })}
        {!!append && (
          <view
            style={{ marginLeft: 'auto', }}
          >{append(_active, tabs[_active])}</view>
        )}
      </view>
      {!!renderContent && (
        <view
          style={{
            marginTop: '5PX',
            ...contentStyle,
          }}
        >{renderContent?.(_active, tabs[_active])}</view>
      )}
    </>
  )
}
