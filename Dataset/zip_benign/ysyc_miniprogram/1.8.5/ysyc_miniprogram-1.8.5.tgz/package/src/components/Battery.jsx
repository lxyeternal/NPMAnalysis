const _defaultColor = getTheme('batteryColor')
export default function({
  style = {},
  value = 50,
  color = _defaultColor,
  warnColor = '#f00',
  warnValue = 20,
  baseValue = 100,
}) {
  useEffect(() => {
  }, [])
  const _color = value <= warnValue ? warnColor : color
  return (
    <view
      style={{
        color: '#34495e',
        border: `1px solid ${_color}`,
        width: '22px',
        height: '12px',
        position: 'relative',
        borderRadius: '2px',
        boxSizing: 'border-box',
        padding: '1px',
        ...style,
      }}
    >
      <view
        style={{
          position: 'absolute',
          top: '2px',
          bottom: '2px',
          right: '-3px',
          width: '1px',
          display: 'border-box',
          border: `1px solid ${_color}`,
          borderLeft: '0',
        }}
      />
      <view
        style={{
          height: '100%',
          width: '100%',
        }}
      >
        <view
          style={{
            borderRadius: '1px',
            backgroundColor: `${_color}`,
            height: '100%',
            width: `${value}%`,
            borderTopRightRadius: 0,
            borderBottomRightRadius: 0,
          }}
        />
      </view>
    </view>
  )
}
