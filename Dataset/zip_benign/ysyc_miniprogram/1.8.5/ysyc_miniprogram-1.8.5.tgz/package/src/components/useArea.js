
export default ({ value = [], limit = 2, } = {}) => {
  const [ _value, setValue, ] = useState(value)
  // 已经请求过的data保存下来，优化
  const [ _data, setData, ] = useState({})
  const [ _title, setTitle, ] = useState()
  const [ _once, setOnce, ] = useState(false)
  useEffect(() => {
    // 数据请求完成后执行
    if (_once) {
      _generateTitle()
    }
  }, [ value, _once, ])
  useEffect(() => {
    _getDataByValue(_value ?? [])
    // setValue(value)
    //  _value,
  }, [ _value, ])

  const _getItems = useCallback(() => {
    const _d = [ -999, ..._value, ].map(item => _data[item] ?? [])
    return _d
  }, [ _value, _data, ])
  // 按code获取类型和父级code
  const _getCodeType = (code) => {
    const _code = `${code}`
    let _parent
    let _type
    if (_code == '-999') {
      // 全国
      _parent = 0
      _type = '-999'
    } else if (_code.length == 9) {
      // 镇
      _type = 'town'
      _parent = _code.slice(0, 6)
    } else if (+_code.slice(4, 6) > 0) {
      // 区
      _type = 'region'
      _parent = `${_code.slice(0, 4)}00`
    } else if (+_code.slice(2, 4) > 0) {
      // 市
      _type = 'city'
      _parent = `${_code.slice(0, 2)}0000`
    } else if (+_code.slice(2, 4) == 0) {
      // 省
      _type = 'province'
      _parent = -999
    }
    return {
      type: _type,
      parent: +_parent,
    }
  }
  const _generateTitle = useCallback((val) => {
    const _val = val ?? _value
    let titles = []
    _val.forEach((item) => {
      const _codeType = _getCodeType(item)
      const activeItem = _data[_codeType.parent]?.find(it => it.type_id == item) ?? {}
      if (activeItem.type_name) {
        titles.push(activeItem.type_name)
      }
    })
    setTitle(titles.join(','))
  }, [
    _value, value,
    // _data,
  ])

  const _getData = async(code = -999,) => {
    if (!code) {
      return []
    }
    const _codeType = _getCodeType(code)
    const urls = {
      '-999': 'getProvince',
      province: 'getCity',
      city: 'getRegion',
      region: 'getTown',
    }
    const _url = urls[_codeType.type]
    if (!_url) {
      return []
    }
    let res = await ajax({
      url: `/memberapi/ajax/${_url}`,
      data: { code, },
      // 一级(省级)缓存下来，
      cacheKey: `area_data${code}`,
    })
    const _d = res.data.map(item => ({
      type_id: item.code,
      type_name: item.name,
    }))
    return _d
  }

  const _getDataByValue = async(values = []) => {
    const _values = [ -999, ...values, ]
    for (let i = 0; i < _values.length; i++) {
      const val = _values[i]
      // 已存在的就不再请求
      if (_data[val]) {
        continue
      }

      // eslint-disable-next-line no-await-in-loop
      const _d = await _getData(val)
      // 同样的数据只请求一次
      _data[val] = _d
      // 请求后再判断，为了得到下一级的数据
      if (i >= limit) {
        break
      }
      // setValue([ ...values, ])
    }
    setData({ ..._data, })
    if (!_once) {
      setOnce(true)
    }
  }

  return {
    getArea: _getData,
    unsetArea: () => {
      setValue([])
    },
    setValue: setValue,
    setArea: (index, val) => {
      _value.splice(
        index, _value.length, val
      )
      setValue([ ..._value, ])
    },
    setArea1: setValue,
    areaValue: _value,
    title: _title,
    generateTitle: _generateTitle,
    areaData: _getItems(),
    // 下一级data
    nextData: _data[_value[_value.length - 1]] ?? [],
  }
}
