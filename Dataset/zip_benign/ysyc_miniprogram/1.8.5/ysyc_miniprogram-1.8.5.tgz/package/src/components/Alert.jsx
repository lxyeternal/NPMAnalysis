export default function({
  style = {}, color, textColor, type = 'info', text = false, icon, title = '暂无内容！', action, iconStyle = {},
}) {
  const colorsMap = {
    info: '#F2F4F9',
    primary: '#f6f8ff',
    success: '#01C77F',
    warning: '#fcf6ed',
    danger: '#FF7070',
  }
  const textColorsMap = {
    success: '#67c23a',
    primary: '#555',
    info: '#909399',
    warning: '#de8c17',
    danger: '#f56c6c',
  }
  let _color = color ?? colorsMap[type]
  let _textColor = textColor ?? textColorsMap[type]

  return (
    <view
      style={{
        display: 'flex',
        backgroundColor: text ? 'transparent' : _color,
        justifyContent: text ? 'center' : 'start',
        alignItems: 'center',
        fontSize: text ? '16PX' : '12PX',
        padding: '10PX',
        ...style,
      }}
    >
      {!!icon && (
        <view
          class={`${icon} iconfont-ysyc`}
          style={{
            color: _textColor,
            marginRight: '5PX',
            fontSize: style.fontSize ?? '12PX',
            ...iconStyle,
          }}
        />
      )}
      <view
        style={{ color: _textColor, }}
      >{title}</view>
      {action && (
        <view
          style={{
            marginLeft: 'auto',
            // flex: 1,
          }}
        >{action}</view>
      )}
    </view>
  )
}
