
const _color = getTheme('primary')

export default function({
  onChange = utils.noop, onChangeBefore, disabled, value = 0, color = _color, style = {}, size = 24,
  labelTrue = '开启', labelFalse = '关闭', valueTrue = 1, valueFalse = 0,
  labelPosition = 'inner', // inner left right
}) {
  const [ _value, setValue, ] = useState(+value)
  useEffect(() => {
    setValue(value == valueTrue)
  }, [ value, ])
  const space = 2
  const getLabelColor = () => {
    if (labelPosition == 'inner') {
      return _value ? '#fff' : '#a8a8a8'
    }
    return _value ? color : '#a8a8a8'
  }
  const _label = (
    <view
      style={{
        color: getLabelColor(),
        padding: '0 3PX',
        fontSize: '12PX',
      }}
    >
      {_value ? labelTrue : labelFalse}
    </view>
  )
  const _onChange = () => {
    const _val = _value ? valueFalse : valueTrue
    setValue(_val)
    onChange(_val)
  }
  const _switch = (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: (_value ? color : (disabled ? '#eee' : '#fff')),
        border: '1PX solid #eaeaea',
        borderRadius: `${size}PX`,
        height: `${size}PX`,
        flexDirection: _value ? 'row-reverse' : 'reverse',
        minWidth: size > 20 ? '46PX' : '30PX',
      }}
    >
      <view
        style={{
          borderRadius: '50%',
          backgroundColor: '#fff',
          margin: `${space}PX`,
          width: `${size - (space * 2)}PX`,
          height: `${size - (space * 2)}PX`,
          boxShadow: '0 0 3px rgba(0,0,0,.3)',
        }}
      />
      {labelPosition == 'inner' && _label}
      <view style={{ width: '5PX', }} > </view>
    </view>
  )
  return (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        opacity: disabled ? .6 : 1,
        ...style,
      }}
      onClick={(e) => {
        e.stopPropagation()
        if (!disabled) {
          if (onChangeBefore) {
            onChangeBefore(_onChange)
          } else {
            _onChange()
          }
        }
      }}
    >
      {labelPosition == 'left' && _label}
      {_switch}
      {labelPosition == 'right' && _label}
    </view>
  )
}
