
const { primary, } = getTheme()
export default function({
  value: _value, onChange, label, disabled, style = {},
}) {
  const [ value, setValue, ] = useState(_value)
  useEffect(() => {
    setValue(_value)
  }, [ _value, ])
  return (
    <view
      style={{
        display: 'flex',
        alignItems: 'center',
        color: (value ? primary : '#73777A'),
        ...style,
      }}
      onClick={(e) => {
        if (!disabled && onChange) {
          e.stopPropagation()
          setValue(!value)
          onChange(!value)
        }
      }}
    >
      <view
        class={`${value ? 'icon-dls_danx01' : 'icon-dls_dx02'} iconfont-ysyc`}
        style={{ opacity: disabled ? .5 : 1, }}
      />
      <view style={{ width: '5PX', }} > </view>
      {label}
    </view>
  )
}
