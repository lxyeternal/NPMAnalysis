/* eslint-disable no-unused-expressions */

export default ({ onSaved = () => null, } = {}) => {
  let isButtonDown = useRef(false)
  let color = useRef('#000000')
  let context = useRef(null)
  const signData = useRef({
    arrx: [],
    arry: [],
    arrz: [],
  })
  // let canvasw = 0
  // var canvash = 0;
  const [ loading, setLoading, ] = useState(false)
  useDidShow(() => {
    init()
    // context.drawImage('../../images/img111.png', 0, 0, canvasw, 500);
  })
  const init = (data) => {
    let _signData = (Taro.getStorageSync('signData') || Taro.getStorageSync('userInfo')?.sign_track?.newest) || {
      arrx: [],
      arry: [],
      arrz: [],
    }

    // 使用 wx.createContext 获取绘图上下文 context
    context.current = Taro.createCanvasContext('canvas')
    context.current.beginPath()
    context.current.setStrokeStyle(color.current)
    context.current.setFillStyle('white')//填充白色
    context.current.restore()
    context.current.setLineWidth(4)
    context.current.setLineCap('round')
    context.current.setLineJoin('round')

    signData.current = _signData
    toDraw(_signData)
  }
  const canvasStart = (event) => {
    isButtonDown.current = true
    signData.current.arrz.push(0)
    signData.current.arrx.push(event.changedTouches[0].x)
    signData.current.arry.push(event.changedTouches[0].y)
  }
  const toDraw = ({
    arrx, arry, arrz,
  }) => {
    for (let i = 0; i < arrx.length; i++) {
      if (arrz[i] == 0) {
        context.current.moveTo?.(arrx[i], arry[i])
      } else {
        context.current.lineTo?.(arrx[i], arry[i])
      }
    }
    // context.current.clearRect(0, 0, canvasw, canvash);
    context.current.setStrokeStyle(color.current)
    context.current.setFillStyle('white')//填充白色
    // ctx.fillRect(0, 0, canvasw , canvash);//画出矩形白色背景
    context.current.restore()
    context.current.setLineWidth(4)
    context.current.setLineCap('round')
    context.current.setLineJoin('round')
    context.current.stroke()
    context.current.draw?.(false)
  }
  //过程
  const canvasMove = (event) => {
    if (isButtonDown.current) {
      signData.current.arrz.push(1)
      signData.current.arrx.push(event.changedTouches[0].x)
      signData.current.arry.push(event.changedTouches[0].y)
    }
    toDraw(signData.current)
  }
  const canvasEnd = (event) => {
    isButtonDown.current = false
  }
  const canvasIdErrorCallback = (e) => {
    console.error(e.detail.errMsg)
  }
  const cleardraw = () => {
    // console.log(arrx, arry, arrz);
    //清除画布
    signData.current = {
      arrx: [],
      arry: [],
      arrz: [],
    }
    context.current?.draw?.(false)
  }
  const uploadImg = ({ filePath = '', btnOnsave, } = {}) => {
    const uploadImgUrl = `${configs.API_BASE_URL}/api/resource/upload`
    const Token = Taro.getStorageSync('token')
    // 只能真机测试
    setLoading(true)
    Taro.uploadFile({
      url: uploadImgUrl,
      name: 'file',
      filePath,
      header: {
        Token,
        'Content-Type': 'multipart/form-data',
      },
      formData: {
        status: 1,
        water: 1,
        // file: 'boundary',
        key: 'sign',
      },
      method: 'POST',
      success(res) {
        const result = JSON.parse(res.data)
        if (result.code == 1) {
          //非我的签名页面进来本地保存签名和canvas轨迹
          Taro.setStorageSync('signData', signData.current)
          Taro.setStorageSync('sign', result.data)
          onSaved?.(result.data, signData.current)
          btnOnsave?.(result.data, signData.current)
        } else if (result.code == 401) {
          wx.showToast({
            icon: 'none',
            title: res.msg || '未登录！',
          })
        } else {
          wx.showToast({
            icon: 'none',
            title: res.msg || '未知错误！',
          })
        }
      },
      complete() {
        setLoading(false)
      },
    })
  }
  const getImg = ({ onSave: btnOnsave = () => null, }) => {
    if (signData.current.arrx.length == 0) {
      Taro.showModal({
        title: '提示',
        content: '签名内容不能为空！',
        showCancel: false,
      })
      return false
    }
    //生成图片
    Taro.canvasToTempFilePath({
      canvasId: 'canvas',
      // fileType: 'jpg',
      success: function(res) {
        let filePath = res.tempFilePath
        uploadImg({
          filePath,
          btnOnsave,
        })
      },

    })
  }

  return {
    signData: signData.current,
    cleardraw,
    getImg,
    loading,
    setColor: (c) => {
      color.current = c
      toDraw(signData.current)
    },
    getCanvasProps: (props, style = {}) => {
      return {
        className: 'canvas',
        id: 'canvas',
        canvasId: 'canvas',
        style: {
          width: '100%',
          height: '300px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: '10px',
          boxSizing: 'border-box',
          ...style,
        },
        // type="2d"
        disableScroll: true,
        onTouchStart: canvasStart,
        onTouchMove: canvasMove,
        onTouchEnd: canvasEnd,
        onTouchCancel: canvasEnd,
        onError: canvasIdErrorCallback,
        ...props,
      }
    },
  }
}
