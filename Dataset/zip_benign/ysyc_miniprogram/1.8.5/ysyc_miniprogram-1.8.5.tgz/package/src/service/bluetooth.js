/* eslint-disable camelcase */
import Taro, { eventCenter, } from '@tarojs/taro'

let machineData = {}
// 开启蓝牙
export const openBluetoothAdapter = async(_machineData) => {
    machineData = _machineData
    setTimeout(function() {
        wx.hideLoading()
    }, 20000)
    if ((machineData.ble_code == Taro.lastConnectDevice || Taro.lastConnectCode == machineData.code) && Taro.blueEnable) {
        wx.showToast({
            title: '该设备已连接蓝牙',
            icon: 'none',
            duration: 1500,
        })
        //重新进入页面时重读设备当前状态
        setTimeout(function() {
            eventCenter.trigger('onInfoChange', {})
        }, 2000)

        return
    }
    //Taro.blueEnable = false
    //关闭之前的
    await closeBLEConnection()
    wx.openBluetoothAdapter({
        success: (res) => {
            console.log('openBluetoothAdapter success', res)
            //Taro.blueOpenEnable = true
            Taro.discoveryStarted = false
            startBluetoothDevicesDiscovery()
        },
        fail: (res) => {
            console.log('openBluetoothAdapter fail', res)
            if (res.errCode === 10001) {
                wx.hideLoading()
                wx.showToast({
                    title: '请先开启蓝牙（ios系统手机需给微信开启蓝牙权限）',
                    icon: 'none',
                    duration: 2000,
                })
            }
            wx.onBluetoothAdapterStateChange(function(rs) {
                console.log('onBluetoothAdapterStateChange', rs)
                //Taro.discoveryStarted = false
                if (rs.available) {
                    //Taro.blueOpenEnable = true
                    if (!rs.discovering) {
                        Taro.discoveryStarted = false
                        startBluetoothDevicesDiscovery()
                    }
                } else {
                    //Taro.blueOpenEnable = false
                }
            })
        },
    })
}

// 开始搜寻附近的蓝牙外围设备
const startBluetoothDevicesDiscovery = () => {
    console.log('discoveryStarted', Taro.discoveryStarted)
    if (Taro.discoveryStarted) {
        return
    }
    Taro.discoveryStarted = true
    wx.startBluetoothDevicesDiscovery({
        allowDuplicatesKey: false,
        //services: [ '00000001-0000-1000-8000-00805F9B34FB', ],
        success() {
            // 搜索到设备
            let info = wx.getSystemInfoSync()
            if (info.platform === 'android') {
                // android 需要执行的代码
                wx.onBluetoothDeviceFound((res) => {
                    console.log('discoveryStarted', Taro.discoveryStarted)
                    if (!Taro.discoveryStarted) {
                        return
                    }
                    console.log('machineData1', machineData)
                    const activeDevice = res.devices.find(item => {
                        // return item.name = 'Redmi 9A' || item.localName == 'Redmi 9A'
                        return item.deviceId == machineData.ble_code || item.localName == machineData.code
                    })
                    if (activeDevice) {
                        stopBluetoothDevicesDiscovery()
                        Taro.currentCode = machineData.code
                        console.log('安卓开始连接蓝牙:onBluetoothDeviceFound')
                        createBLEConnection(activeDevice.deviceId)
                    } else {
                        //console.log('没有设备')
                    }
                })
                setTimeout(function() {
                    wx.getBluetoothDevices({
                        success: function(res) {
                            console.log('discoveryStarted', Taro.discoveryStarted)
                            if (!Taro.discoveryStarted) {
                                return
                            }
                            console.log('devices', res.devices)
                            console.log('machineData2', machineData)
                            const activeDevice = res.devices.find(item => {
                                // return item.name = 'Redmi 9A' || item.localName == 'Redmi 9A'
                                return item.deviceId == machineData.ble_code || item.localName == machineData.code
                            })
                            console.log('blueEnable', Taro.blueEnable)
                            if (Taro.blueEnable) {
                                return
                            }
                            console.log('activeDevice', activeDevice)
                            if (activeDevice) {
                                stopBluetoothDevicesDiscovery()
                                Taro.currentCode = machineData.code
                                console.log('安卓开始连接蓝牙:getBluetoothDevices')
                                createBLEConnection(activeDevice.deviceId)
                            } else {
                                //console.log('没有设备')
                            }
                        },
                    })
                }, 3000)
            } else {
                wx.onBluetoothDeviceFound((res) => {
                    console.log('discoveryStarted', Taro.discoveryStarted)
                    if (!Taro.discoveryStarted) {
                        return
                    }
                    const activeDevice = res.devices.find(item => {
                        // return item.name = 'Redmi 9A' || item.localName == 'Redmi 9A'
                        return item.deviceId == machineData.ble_code || item.localName == machineData.code
                    })
                    if (activeDevice) {
                        stopBluetoothDevicesDiscovery()
                        Taro.currentCode = machineData.code
                        createBLEConnection(activeDevice.deviceId)
                    } else {
                        //console.log('没有设备')
                    }
                })
            }
        },
    })
}
// 停止搜索
const stopBluetoothDevicesDiscovery = () => {
    try {
        wx.stopBluetoothDevicesDiscovery({
            success(res) {
                Taro.discoveryStarted = false
                console.log('stopBluetoothDevicesDiscovery success', res)
            },
            fail(err) {
                console.log('stopBluetoothDevicesDiscovery fail', err)
            },
        })

        console.log('stopBluetoothDevicesDiscovery success')
    } catch (err) {
        console.log('stopBluetoothDevicesDiscovery fail')
    }
}
// 连接蓝牙
const createBLEConnection = async(deviceId) => {
    // const deviceId = machineData.ble_code
    if (!deviceId) {
        console.log('设备未发现')
        return
    }
    wx.showLoading({
        title: '连接设备中',
        mask: true,
    })
    // 先关闭之前的
    //await closeBLEConnection()
    try {
        await wx.createBLEConnection({ deviceId, })
        wx.hideLoading()
        // 获取蓝牙低功耗设备所有服务
        const uuid = '00000001-0000-1000-8000-00805F9B34FB'
        // 蓝牙状态改变时
        wx.onBLEConnectionStateChanged(function(res) {
            console.log('device_state_chanage', res)
            //const deviceId = machineData.ble_code
            if (res.deviceId == deviceId) {
                if (res.connected) {
                    Taro.lastConnectDevice = deviceId
                    Taro.lastConnectCode = machineData.code
                    Taro.blueEnable = true
                    //Taro.blueOpenEnable = true
                    // app.globalData.current_code = machineData.code
                } else {
                    Taro.blueEnable = false
                    //Taro.blueOpenEnable = false
                }
                eventCenter.trigger('onBLEConnectionStateChanged', res)
            }
        })

        const res = await wx.getBLEDeviceServices({ deviceId, })
        // 对应的服务
        const activeServie = res.services.find(item => item.isPrimary && item.uuid == uuid)
        if (activeServie) {
            // 特征
            getBLEDeviceCharacteristics(deviceId, uuid)
        }
    //为什么，连接后要关闭查找
    //stopBluetoothDevicesDiscovery()
    } catch (err) {
        wx.hideLoading()
        //连接失败重试
        console.log('errMsg', err.errMsg)
        if (err.errMsg != 'createBLEConnection:fail:already connect') {
            await wx.showToast({
                title: `失败${err.errMsg}重试`,
                icon: 'none',
                duration: 2000,
            })
            createBLEConnection(deviceId)
        } else {
            Taro.blueEnable = true
            eventCenter.trigger('onBLEConnectionStateChanged', { connected: true, })
        }
    }
}
// 断开连接
const closeBLEConnection = async() => {
    if (!Taro.lastConnectDevice) {
    //之前没连上过，无需关闭蓝牙
        Taro.blueEnable = false
        return
    }
    try {
        const res = await wx.closeBLEConnection({ deviceId: Taro.lastConnectDevice, })
        console.log('close_res', res)
        eventCenter.trigger('closeBLEConnection', res)
        Taro.lastConnectDevice = null
        Taro.lastConnectCode = null
        Taro.blueEnable = false
        eventCenter.trigger('onBLEConnectionStateChanged', { connected: false, })
        return res
    } catch (e) {
        console.log(e)
    }
}
// 获取蓝牙低功耗设备某个服务中所有特征
const getBLEDeviceCharacteristics = (deviceId, _serviceId) => {
    wx.getBLEDeviceCharacteristics({
        deviceId,
        serviceId: _serviceId,
        success: (res) => {
            console.log('getBLEDeviceCharacteristics success', res.characteristics)
            // app.globalData.current_code = machineData.code
            for (let i = 0; i < res.characteristics.length; i++) {
                let item = res.characteristics[i]
                console.log('设备信息', item)
                if (item.properties.read) {
                    wx.readBLECharacteristicValue({
                        deviceId,
                        serviceId: _serviceId,
                        characteristicId: item.uuid,
                    })
                }
                if (item.properties.write) {
                    // setData({ canWrite: true, })
                    Taro.serviceId = _serviceId
                    Taro.characteristicId = item.uuid
                }
                if (item.properties.notify || item.properties.indicate) {
                    // 启用蓝牙低功耗设备特征值变化时的 notify 功能，订阅特征
                    wx.notifyBLECharacteristicValueChange({
                        deviceId,
                        serviceId: _serviceId,
                        characteristicId: item.uuid,
                        state: true,
                        // eslint-disable-next-line no-loop-func
                        success(rs) {
                            console.log(rs, 'resjieguo')
                            //读取电表信息
                            eventCenter.trigger('onInfoChange', {})
                            // /监听蓝牙低功耗设备的特征值变化事件 (监控设备信息变化) ， 需要wx.notifyBLECharacteristicValueChange开启后生效
                            wx.onBLECharacteristicValueChange(function(res1) {
                                //console.log("notify", JSON.stringify(res1))
                                // 此时可以拿到蓝牙设备返回来的数据是一个ArrayBuffer类型数据，所以需要通过一个方法转换成字符串
                                let nonceId = ab2hex(res1.value)
                                //console.log('nonceId', nonceId) // nonceId：设备传过来的值。
                                //console.log('retOrder', retOrder)
                                let rOrder = wx.getStorageSync('retOrder') ? wx.getStorageSync('retOrder') : ''
                                if (rOrder.substr(0, 2) == '68') {
                                    rOrder += nonceId
                                } else if (nonceId.substr(0, 2) == '68') {
                                    rOrder = nonceId
                                } else {
                                    return
                                }
                                //console.log('rOrder', rOrder)
                                if (checkOrderComplete(rOrder)) {
                                    let pushData = {}
                                    let _currentAction = Taro.currentAction
                                    pushData[_currentAction] = rOrder
                                    pushData.code = machineData.code
                                    if (Taro.currentPayOrder && _currentAction == 'gd') {
                                        pushData.pay_order = Taro.currentPayOrder
                                    }
                                    if (Taro.currentCouponUseId && _currentAction == 'gd') {
                                        pushData.coupon_use_id = Taro.currentCouponUseId
                                    }
                                    if (Taro.currentCouponUseId > 0 && _currentAction == 'ykfg') {
                                        pushData.coupon_use_id = Taro.currentCouponUseId
                                    }
                                    // socketSendData(pushData)
                                    eventCenter.trigger('onOrderComplete', pushData)
                                    Taro.currentAction = ''
                                    // 过滤到上一个已发送的指令
                                    const _orderList = Taro.orderList.filter(it => it.action != rOrder)
                                    sendOrders(_orderList)
                                    wx.setStorageSync('retOrder', '')
                                    //app.globalData.ret_orders = ret_orders;
                                } else {
                                    wx.setStorageSync('retOrder', rOrder)
                                }
                            })
                        },
                    })
                }
            }
            Taro.lastConnectDevice = deviceId
            Taro.lastConnectCode = machineData.code
            Taro.blueEnable = true
            eventCenter.trigger('onBLEConnectionStateChanged', { connected: true, })
        },
        fail(res) {
            console.error('getBLEDeviceCharacteristics', res)
        },
    })
}

// ArrayBuffer转16进度字符串示例
const ab2hex = (buffer) => {
    let hexArr = Array.prototype.map.call(new Uint8Array(buffer),
        function(bit) {
            return (`00${bit.toString(16)}`).slice(-2)
        })
    return hexArr.join('')
}
const checkOrderComplete = (order,) => {
    if (!order) {
        return false
    }

    if (order.substr(-2, 2) != '16') {
        return false
    }
    let check_code = order.substr(-4, 2)
    let hex_data
    if (machineData.type == 0) {
        hex_data = order.substr(0, order.length - 4)
    }
    if (machineData.type == 1) {
        hex_data = order.substr(8, order.length - 12)
    }
    //console.log('hex_data', hex_data);
    let init_hex = 0
    for (let i = 0; i < (hex_data.length) / 2; i++) {
        let hex_i = hex_data.substr(i * 2, 2)
        init_hex += hex2int(hex_i)
    }
    //console.log('int2hex', int2hex(init_hex));
    let ret_hex_check = int2hex(init_hex)
    ret_hex_check = ret_hex_check.substr(-2, 2)
    ret_hex_check = ret_hex_check.length == 1 ? (`${0}${ret_hex_check}`) : ret_hex_check
    if (ret_hex_check != check_code) {
        return false
    }

    return true
}

const hex2int = (hex) => {
    let len = hex.length, a = new Array(len), code
    for (let i = 0; i < len; i++) {
        code = hex.charCodeAt(i)
        if (48 <= code && code < 58) {
            code -= 48
        } else {
            code = (code & 0xdf) - 65 + 10
        }
        a[i] = code
    }

    return a.reduce(function(acc, c) {
        acc = 16 * acc + c
        return acc
    }, 0)
}

const int2hex = (num) => {
    let hex = '0123456789abcdef'
    let s = ''
    while (num) {
        s = hex.charAt(num % 16) + s
        num = Math.floor(num / 16)
    }
    return s.substr(-2, 2)
}
// 发送指令给设备
const writeBLECharacteristicValue = async(
    hex
) => {
    if (!hex) {
        wx.showToast({
            title: '指令缺失，终止发送',
            icon: 'none',
            duration: 2000,
        })
        return
    }
    let typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function(h) {
        return parseInt(h, 16)
    }))

    let buffer = typedArray.buffer

    // machineData = machineData

    if (Taro.lastConnectDevice === undefined) {
        wx.showToast({
            title: '未检测到有连接的蓝牙设备',
            icon: 'none',
            duration: 2000,
        })
        return
    }

    try {
        const res = await wx.writeBLECharacteristicValue({
            deviceId: Taro.lastConnectDevice,
            serviceId: Taro.serviceId,
            characteristicId: Taro.characteristicId,
            value: buffer,
        })
        console.log('write_result', res)
        if (res.errCode == 10006) {
            //蓝牙连接已经断开了
            Taro.blueEnable = false
            eventCenter.trigger('onBLEConnectionStateChanged', { connected: false, })
        }
    } catch (err) {
        wx.showToast({
            title: `发送失败:${JSON.stringify(err)}`,
            icon: 'none',
            duration: 2000,
        })
        Taro.blueEnable = false
        eventCenter.trigger('onBLEConnectionStateChanged', { connected: false, })
        console.log(err)
    }
}

export const sendOrders = (orderList) => {
    if (!Taro.blueEnable) {
        wx.showToast({
            title: '蓝牙未连接！',
            duration: 2000,
            icon: 'none',
        })
        return
    }
    console.log('orderList', orderList)
    // 如果没有在发送，就执行, orderList可以随时被加入队列， 使用Taro.orderList.push()
    if (!Taro.currentAction && orderList.length > 0) {
    // let item = orderList[0]
        let item = orderList.shift()
        Taro.orderList = orderList
        // 每次发送第一个，直到为空
        sendOrder(item.order, item.action)
    }
}
// 发送执行指令给设备
export const sendOrder = (order, action) => {
    if (!action) {
        wx.showToast({
            title: '无动作标记！',
            duration: 2000,
            icon: 'none',
        })
        return
    }
    if (!Taro.blueEnable) {
        wx.showToast({
            title: '蓝牙未连接！',
            duration: 2000,
            icon: 'none',
        })
        return
    }
    if (!Taro.socketEnable) {
        wx.showToast({
            title: 'socket已断开,请退出页面在进入重试',
            duration: 2000,
            icon: 'none',
        })
        return
    }

    if (!action) {
        wx.showToast({
            title: '请稍后操作',
            duration: 1500,
            icon: 'none',
        })
    }
    Taro.currentAction = action
    console.log('执行指令', order)
    //console.log("current_action", app.globalData.current_action);
    for (let i = 0; i < Math.ceil(order.length) / 40; i++) {
        writeBLECharacteristicValue(order.substr(i * 40, 40))
    }
}
