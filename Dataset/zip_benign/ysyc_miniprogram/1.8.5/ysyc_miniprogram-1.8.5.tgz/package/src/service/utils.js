import Taro from '@tarojs/taro'
import dayjs from 'dayjs'
// import duration from 'dayjs/plugin/duration'
import URL from 'url'

import noPic from '../assets/images/no_pic.png'
import {
  API_BASE_URL,
  IMG_HOST,
  IMG_HOST_PATHNAME,
} from '../config'
import deeps from './deeps'
import { setGlobalData, } from './globalData'

export const getDate = (time, options = {}) => {
  time = time || 0
  // 当前时间之后的add天
  if (options.add) {
    time += 1000 * 60 * 60 * 24 * options.add
  }
  let date = time ? (new Date(time)) : (new Date())
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  return {
    year,
    month,
    day,
    hour,
    minute,
  }
}
// 格式化时间
export const date = (str, format = 'YYYY-MM-DD H:mm:ss') => {
  let isNumber = (obj) => {
    return obj === +obj
  }
  let _str = '--'
  if (str) {
    // 兼容任意格式
    if (isNumber(str)) {
      str *= 1000
    }
    _str = dayjs(str).format(format)
  }
  return _str
}
// Unix 时间戳 (毫秒)
export const dateValueOf = (str) => {
  return dayjs(str).valueOf()
}
// Unix 时间戳 (秒)
export const dateUnix = (str) => {
  return dayjs(str).unix()
}

export const convertCurrency = (money) => { // 数字金额转换为中文金额
  //汉字的数字
  let cnNums = new Array(
    '零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'
  )
  //基本单位
  let cnIntRadice = new Array(
    '', '拾', '佰', '仟'
  )
  //对应整数部分扩展单位
  let cnIntUnits = new Array(
    '', '万', '亿', '兆'
  )
  //对应小数部分单位
  let cnDecUnits = new Array(
    '角', '分', '毫', '厘'
  )
  //整数金额时后面跟的字符
  let cnInteger = '整'
  //整型完以后的单位
  let cnIntLast = '元'
  //最大处理的数字
  let maxNum = 999999999999999.9999
  //金额整数部分
  let integerNum
  //金额小数部分
  let decimalNum
  //输出的中文金额字符串
  let chineseStr = ''
  //分离金额后用的数组，预定义
  let parts
  if (money == '') {
    return ''
  }
  money = parseFloat(money)
  if (money >= maxNum) {
    //超出最大处理数字
    return ''
  }
  if (money == 0) {
    chineseStr = cnNums[0] + cnIntLast + cnInteger
    return chineseStr
  }
  //转换为字符串
  money = money.toString()
  if (money.indexOf('.') == -1) {
    integerNum = money
    decimalNum = ''
  } else {
    parts = money.split('.')
    integerNum = parts[0]
    decimalNum = parts[1].substr(0, 4)
  }
  //获取整型部分转换
  if (parseInt(integerNum, 10) > 0) {
    let zeroCount = 0
    let IntLen = integerNum.length
    for (let i = 0; i < IntLen; i++) {
      let n = integerNum.substr(i, 1)
      let p = IntLen - i - 1
      let q = p / 4
      let m = p % 4
      if (n == '0') {
        zeroCount++
      } else {
        if (zeroCount > 0) {
          chineseStr += cnNums[0]
        }
        //归零
        zeroCount = 0
        chineseStr += cnNums[parseInt(n)] + cnIntRadice[m]
      }
      if (m == 0 && zeroCount < 4) {
        chineseStr += cnIntUnits[q]
      }
    }
    chineseStr += cnIntLast
  }
  //小数部分
  if (decimalNum != '') {
    let decLen = decimalNum.length
    for (let i = 0; i < decLen; i++) {
      let n = decimalNum.substr(i, 1)
      if (n != '0') {
        chineseStr += cnNums[Number(n)] + cnDecUnits[i]
      }
    }
  }
  if (chineseStr == '') {
    chineseStr += cnNums[0] + cnIntLast + cnInteger
    chineseStr += cnNums[0]
  } else if (decimalNum == '') {
    chineseStr += cnInteger
  }
  return chineseStr
}

/**
 * 转换图片地图
 * @param {string|object} src 图片地址 '6461e680a022de699d3d5808' | 'images/cxewap_sy_ppdc@2xz.png' | {url: '6461e680a022de699d3d5808'}
 * @param {boolean} isThumb 是否启用缩略图
 * @returns {string} 完整的url
 */
export const imgUrl = (src, isThumb = true) => {
  src = src?.url ?? src
  if (!src) {
    return noPic
  } else if (src.includes('assets') || src.includes('wxfile')) {
    return src
  }

  let aQuery = []
  const token = Taro.getStorageSync('token')
  if (token) {
    aQuery.push(`token=${token}`)
  }
  if (isThumb) {
    aQuery.push('thumb=1')
  }
  if (src.includes('http')) {
    return src
  } else if (src.includes('api/resource/show')) {
    return `${src}&${aQuery.join('&')}`
  } else if (src.includes('/')) {
    // 服务器静态图片
    if (src.includes('static')) {
      // src = '/static/miniprogram/tabbar/wode_02_icon.png'
      return `${API_BASE_URL}${src}`
    }
    return IMG_HOST + (src[0] == '/' ? '' : '/') + src
  }
  aQuery.push(`id=${src}`)
  // src = 'rwer43242343432'
  return `${IMG_HOST_PATHNAME}?${aQuery.join('&')}`
}

export const previewImage = (data, current = 0) => {
  const urls = data.map((item) => imgUrl(item, false))
  Taro.previewImage({
    current: urls[current], // 当前显示图片的http链接
    urls, // 需要预览的图片http链接列表
  })
}
export const getObjectValue = (data, key) => {
  return deeps.get(data, key)
}

export const setObjectValue = (
  data, key, value
) => {
  deeps.set(
    data, key, value
  )
}

export const getRandomStr = (n) => {
  let ret = ''
  const s = 'abcdefghijklmnopqrstuvwxyz'
  const str = `1234567890${s}${s.toUpperCase()}`
  const l = str.length
  for (let i = 0; i < n; i++) {
    ret += str.substr(parseInt(Math.random() * l), 1)
  }
  return ret
}
const GlobalKeys = {}
export const generateGlobalKey = (name) => {
  //GlobalKeys[name] = crypto.randomBytes(40).toString('base64')
  GlobalKeys[name] = getRandomStr(40)
  console.log([
    'generate key',
    name,
    GlobalKeys[name],
  ])
}
export const getGlobalKey = (name) => {
  return GlobalKeys[name] ?? ''
}
function getUrlHost(uri) {
  const url = URL.parse(uri, true)
  return url.href
}
function getCookieSaveKey(host, path = '/') {
  return `Cookies@${host}${path}`
}
export const setCookie = (url, cookieStr) => {
  const host = getUrlHost(url)
  Taro.setStorageSync(getCookieSaveKey(host), cookieStr)
}
export const getCookie = (url) => {
  const host = getUrlHost(url)
  return Taro.getStorageSync(getCookieSaveKey(host)) ?? {}
}
export const parseSize = size => {
  if (!size) {
    return
  }
  if (/%|auto|vh|vw|px/.test(String(size))) {
    return size
  }
  return `${parseInt(size)}px`
}

export const telFormat = (tel) => {
  if (!tel) {
    return
  }
  return `${tel.slice(0, 3)}****${tel.slice(-4)}`
}

export const noop = () => (() => null)
export const promiseNoop = new Promise(noop)
// 将分钟数量转换为小时和分钟字符串
export const toHourMinute = function(minutes) {
  if (!minutes) {
    return ''
  }
  return `${Math.floor(minutes / 60)}小时${minutes % 60}分`
  // 也可以转换为json，以方便外部使用
  // return {hour:Math.floor(minutes/60),minute:(minutes%60)};
}

/* dayjs.extend(duration)
export const toDuration = function(secends, isDate = false) {
  if (!secends) {
    return '-'
  }
  secends *= 1000
  const diffTime = isDate ? dayjs.duration(secends - dayjs()) : dayjs.duration(secends)
  const day = diffTime.days() //天
  const hours = diffTime.hours() //小时
  const minutes = diffTime.minutes() //分钟
  const seconds = diffTime.seconds() //秒
  const setPre = (val) => {
    return val < 10 ? (`0${val}`) : val
  }
  return `${setPre(day)}天${setPre(hours)}时${setPre(minutes)}分${setPre(seconds)}秒`
} */

/**
 * 获取剩余时间
 * @param {*} endtime 秒|普通时间
 * @returns
 * @example
 * uitls.getTimeRemaining('2023-4-12') /
 * uitls.getTimeRemaining(1294324324) /
 */
export const getTimeRemaining = (endtime) => {
  if (/^[0-9]*$/.test(endtime)) {
    endtime *= 1000
  }
  const t = Date.parse(new Date(endtime)) - Date.parse(new Date())
  const seconds = Math.floor((t / 1000) % 60)
  const minutes = Math.floor((t / 1000 / 60) % 60)
  const hours = Math.floor((t / (1000 * 60 * 60)) % 24)
  const days = Math.floor(t / (1000 * 60 * 60 * 24))
  return {
    total: t,
    days,
    hours,
    minutes,
    seconds,
  }
}

export const urlParse = URL.parse
export const urlFormat = URL.format
const navgationTo = (tag) => ({
  url, query, params, ...arg
}) => {
  if (url.slice(0, 1) != '/') {
    url = `/${url}`
  }
  const _url = urlParse(url, true)
  if (params) {
    setGlobalData('params', params)
  }
  if (query) {
    _url.query = query
  }

  return Taro[tag]({
    url: urlFormat(_url),
    ...arg,
  })
}
export const navigateTo = navgationTo('navigateTo')
export const switchTab = navgationTo('switchTab')
export const redirectTo = navgationTo('redirectTo')
export const navigateBack = ({ params, ...args } = {}) => {
  if (params) {
    setGlobalData('params', params)
  }
  return Taro.navigateBack(args)
}

/**
 * 百度地图BD09坐标---->中国正常GCJ02坐标
 * 腾讯地图用的也是GCJ02坐标
 * @param args [Object]
 * @return object;
 */
export const convertBd09ToGcj02 = (args = {}) => {
  let { lng, lat, } = args
  let $xPi = 3.14159265358979324 * 3000.0 / 180.0
  let $x = lng - 0.0065
  let $y = lat - 0.006
  let $z = Math.sqrt(($x * $x) + ($y * $y)) - (0.00002 * Math.sin($y * $xPi))
  let $theta = Math.atan2($y, $x) - (0.000003 * Math.cos($x * $xPi))
  lng = $z * Math.cos($theta)
  lat = $z * Math.sin($theta)
  return {
    lng,
    lat,
  }
}
/**
   * 生成五位数字或字母
   *
   * @static
   * @returns {string}
   * @memberof Util
   */
export const random = () => {
  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1)
}
/**
   * 生成唯一识别码
   * dd26333d-1bdb-2a2e-e489-80af2535dcda
   * @static
   * @returns {string}
   * @memberof Util
   */
export const guid = (length) => {
  const str = (`${random() + random()}-${random()}-${random()}-${random()}-${random()}${random()}${random()}`)
  return length ? str.substr(0, length) : str
}

export const toHourMinuteSecends = function(secends) {
  if (!secends) {
    return '00:00:00'
  }
  const _hours = Math.floor(secends / 3600)
  const _minutes = Math.floor((secends % 3600) / 60)
  const _secends = (secends % 3600) % 60
  const setPre = (val) => {
    return val < 10 ? (`0${val}`) : val
  }
  return `${setPre(_hours)}:${setPre(_minutes)}:${setPre(_secends)}`
}

export const parseShow = (item, args) => {
  let _show = true
  if (!item) {
    _show = false
  } else if (typeof item.show === 'function') {
    // _show = item.show(args) ?? true
    _show = item.show(args)
    if (_show === undefined) {
      _show = true
    }
  } else if (Array.isArray(item)) {
    _show = item.some(it => parseShow(it, args))
  } else {
    // _show = item.show ?? true
    _show = item.show
    if (_show === undefined) {
      _show = true
    }
  }

  return _show
}

export const stringJoin = (...args) => {
  const arr = []
  args.forEach((item, i) => {
    if (/(\^|\$)/.test(item)) {
      if (args[RegExp.$1 == '^' ? i - 1 : i + 1]) {
        const _item = item.replace(/(\^|\$)/g, '')
        arr.push(_item)
      }
    } else if (item) {
      arr.push(item)
    }
  })

  return arr.join(' ')
}
export const set16ToRgb = (str) => {
  let reg = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/
  if (!reg.test(str)) {
    return
  }
  let newStr = (str.toLowerCase()).replace(/\#/g, '')
  let len = newStr.length
  if (len == 3) {
    let t = ''
    for (let i = 0;i < len;i++) {
      t += newStr.slice(i, i + 1).concat(newStr.slice(i, i + 1))
    }
    newStr = t
  }
  let arr = [] //将字符串分隔，两个两个的分隔
  for (let i = 0;i < 6;i = i + 2) {
    let s = newStr.slice(i, i + 2)
    arr.push(parseInt(`0x${s}`))
  }
  return arr.join(',')
}