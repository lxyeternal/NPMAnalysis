// ArrayBuffer转16进度字符串示例
const ab2hex = (buffer) => {
    let hexArr = Array.prototype.map.call(new Uint8Array(buffer),
        function(bit) {
            return (`00${bit.toString(16)}`).slice(-2)
        })
    return hexArr.join('')
}
export const openBluetoothAdapter = (app) => {
    /*wx.showLoading({
    title: "开始匹配"
  })
  if (page.data.search_index == 0) {
    let search_index = setInterval(function () {
      wx.hideLoading()
      if (page.data.devices.length == 0) {
        console.log("努力查找中……");
      } else {
        clearInterval(page.data.search_index);
        wx.showToast({
          title: "设备已找到，开始建立连接",
          icon: 'none',
          duration: 2000
        })
      }
    }, 5000)
    page.setData({
      search_index: search_index
    })
  }*/
    let pages = getCurrentPages()
    let cPage = pages[pages.length - 1]

    //console.log("last_connect_device", cPage.data.machine.ble_code);
    //console.log("last_connect_device_local", wx.getStorageSync("last_connect_device"))
    //console.log("blue_enable", app.globalData.blue_enable);
    if (cPage.data.machine.ble_code == wx.getStorageSync('last_connect_device') && cPage.data.machine.ble_code && app.globalData.blue_enable) {
        wx.showToast({
            title: '该设备已连接蓝牙，不用再次连接',
            icon: 'none',
            duration: 1500,
        })
        return
    }

    if (!app.globalData.blue_open_enable) {
        wx.openBluetoothAdapter({
            success: (res) => {
                console.log('openBluetoothAdapter success', res)
                app.globalData.blue_open_enable = true
                startBluetoothDevicesDiscovery(app, cPage)
            },
            fail: (res) => {
                console.log(res)
                if (res.errCode === 10001) {
                    wx.hideLoading()
                    wx.showToast({
                        title: '请先开启蓝牙',
                        icon: 'none',
                        duration: 2000,
                    })
                    wx.onBluetoothAdapterStateChange(function(res) {
                        console.log('onBluetoothAdapterStateChange', res)
                        if (res.available) {
                            app.globalData.blue_open_enable = true
                            startBluetoothDevicesDiscovery(app, cPage)
                        } else {
                            app.globalData.blue_open_enable = false
                        }
                    })
                }
            },
        })
    } else {
        closeBLEConnection(cPage, app).then(function(res) {
            startBluetoothDevicesDiscovery(app, cPage)
        }).catch(function() {
            startBluetoothDevicesDiscovery(app, cPage)
        })
    }
}

const startBluetoothDevicesDiscovery = (app, page) => {
    if (app.globalData._discoveryStarted) {
        return
    }
    app.globalData._discoveryStarted = true
    wx.startBluetoothDevicesDiscovery({
        allowDuplicatesKey: true,
        success: (res) => {
            console.log('startBluetoothDevicesDiscovery success', res)
            onBluetoothDeviceFound(app, page)
        },
    })
}

const onBluetoothDeviceFound = (app, page) => {
    let that = page
    wx.onBluetoothDeviceFound((res) => {
        res.devices.forEach(device => {
            if (!device.name && !device.localName) {
                return
            }

            if (device.deviceId == that.data.machine.ble_code || device.localName == that.data.machine.code) {
                if (device.localName == that.data.machine.code) {
                    that.setData({ 'machine.ble_code': device.deviceId, })
                }
                app.globalData.device = device
                that.setData({ devices_change: true, })
                stopBluetoothDevicesDiscovery(app)
                createBLEConnection(page, app)
            }
        })
    })
}

const createBLEConnection = (page, app) => {
    const deviceId = page.data.machine.ble_code
    if (!deviceId) {
        console.log('设备未发现')
        return
    }

    wx.showLoading({
        title: '连接设备中……',
        mask: true,
    })
    closeBLEConnection(page).then(function() {
        wx.createBLEConnection({
            deviceId,
            success: (res) => {
                wx.hideLoading()
                getBLEDeviceServices(
                    page, deviceId, app
                )
                //为什么，连接后要关闭查找
                //stopBluetoothDevicesDiscovery()
            },
            fail(err) {
                wx.hideLoading()
                wx.showToast({
                    title: `失败${err.errMsg}重试`,
                    icon: 'none',
                    duration: 2000,
                })
                //连接失败重试
                console.log('errMsg', err.errMsg)
                if (err.errMsg != 'createBLEConnection:fail:already connect') {
                    createBLEConnection(page, app)
                } else {
                    app.globalData.blue_enable = true
                }
            },
        })
    }).catch(function() {
        wx.createBLEConnection({
            deviceId,
            success: (res) => {
                wx.hideLoading()
                getBLEDeviceServices(
                    page, deviceId, app
                )
                //为什么，连接后要关闭查找
                //stopBluetoothDevicesDiscovery()
            },
            fail(err) {
                wx.hideLoading()
                wx.showToast({
                    title: `失败${err.errMsg}重试`,
                    icon: 'none',
                    duration: 2000,
                })
                //连接失败重试
                console.log('errMsg', err.errMsg)
                if (err.errMsg != 'createBLEConnection:fail:already connect') {
                    createBLEConnection(page, app)
                } else {
                    app.globalData.blue_enable = true
                }
            },
        })
    })
}

const stopBluetoothDevicesDiscovery = (app) => {
    wx.stopBluetoothDevicesDiscovery({
        success(res) {
            console.log('stopBluetoothDevicesDiscovery success')
            app.globalData._discoveryStarted = false
        },
        fail(res) {
            console.log('stopBluetoothDevicesDiscovery fail')
        },
    })
}

export const closeBLEConnection = (page, app) => {
    let that = page
    return new Promise((resolve, reject) => {
        let deviceId = wx.getStorageSync('last_connect_device')
        if (!deviceId) {
            //之前没连上过，无需关闭蓝牙
            resolve()
        }
        console.log('deviceId', deviceId)
        wx.closeBLEConnection({
            deviceId: deviceId,
            success(res) {
                console.log('close_res', res)
                wx.showToast({
                    title: '蓝牙关闭成功！',
                    icon: 'none',
                    duration: 1500,
                })
                app.globalData.device = {}
                app.globalData.blue_enable = false
                wx.removeStorageSync('last_connect_device')
                app.globalData.current_code = ''
                that.setData({
                    connected: false,
                    canWrite: false,
                })
                resolve(res)
            },
            fail(err) {
                console.log('fail_res', err)
                reject(err)
            },
        })
    })
}

const getBLEDeviceServices = (
    page, deviceId, app
) => {
    console.log('service_deviceId', deviceId ? deviceId : page.data.machine.ble_code)
    wx.onBLEConnectionStateChanged(function(res) {
        console.log('device_state_chanage', res)
        if (res.deviceId == deviceId) {
            if (res.connected) {
                app.globalData.blue_enable = true
                wx.setStorageSync('last_connect_device', deviceId)
                app.globalData.current_code = page.data.machine.code
            } else {
                app.globalData.blue_enable = false
            }
        }
    })
    wx.getBLEDeviceServices({
        deviceId,
        success: (res) => {
            console.log('res.services', res.services)
            for (let i = 0; i < res.services.length; i++) {
                if (res.services[i].isPrimary && res.services[i].uuid == '00000001-0000-1000-8000-00805F9B34FB') {
                    getBLEDeviceCharacteristics(
                        page, deviceId, res.services[i].uuid, app
                    )
                    return
                }
            }
        },
    })
}

const getBLEDeviceCharacteristics = (
    page, deviceId, serviceId, app
) => {
    let that = page
    wx.getBLEDeviceCharacteristics({
        deviceId,
        serviceId,
        success: (res) => {
            console.log('getBLEDeviceCharacteristics success', res.characteristics)
            //page.start();
            app.globalData.blue_enable = true
            wx.setStorageSync('last_connect_device', deviceId)
            app.globalData.current_code = page.data.machine.code
            for (let i = 0; i < res.characteristics.length; i++) {
                let item = res.characteristics[i]
                console.log('设备信息', item)
                if (item.properties.read) {
                    wx.readBLECharacteristicValue({
                        deviceId,
                        serviceId,
                        characteristicId: item.uuid,
                    })
                }
                if (item.properties.write) {
                    that.setData({ canWrite: true, })
                    updateDevice(
                        deviceId, '_serviceId', serviceId, app
                    )
                    updateDevice(
                        deviceId, '_characteristicId', item.uuid, app
                    )
                }
                if (item.properties.notify || item.properties.indicate) {
                    wx.notifyBLECharacteristicValueChange({
                        deviceId,
                        serviceId,
                        characteristicId: item.uuid,
                        state: true,
                        success: function(res) {
                            console.log(res, 'resjieguo')
                            //读取电表信息
                            page.read_machine_info()
                            wx.onBLECharacteristicValueChange(function(res) {
                                //console.log("notify", JSON.stringify(res))
                                // 此时可以拿到蓝牙设备返回来的数据是一个ArrayBuffer类型数据，所以需要通过一个方法转换成字符串
                                let nonceId = ab2hex(res.value)
                                console.log('nonceId', nonceId) // nonceId：设备传过来的值。
                                let ret_order = app.globalData.ret_order
                                if (ret_order.substr(0, 2) == '68') {
                                    ret_order += nonceId
                                } else if (nonceId.substr(0, 2) == '68') {
                                    ret_order = nonceId
                                } else {
                                    return
                                }
                                //console.log("ret_order1", ret_order);
                                if (check_order_complete(ret_order, app)) {
                                    //console.log("ret_order2", ret_order);
                                    //let ret_orders = app.globalData.ret_orders;
                                    //ret_orders.push({action: app.globalData.current_action, order: ret_order});
                                    //let pages = getCurrentPages();
                                    //let page = pages[pages.length - 1];
                                    let pushData = {}
                                    pushData[app.globalData.current_action] = ret_order
                                    pushData.code = app.globalData.current_code
                                    if (app.globalData.current_pay_order && app.globalData.current_action == 'gd') {
                                        pushData.pay_order = app.globalData.current_pay_order
                                    }
                                    if (app.globalData.current_coupon_use_id && app.globalData.current_action == 'gd') {
                                        pushData.coupon_use_id = app.globalData.current_coupon_use_id
                                    }
                                    if (app.globalData.current_coupon_use_id > 0 && app.globalData.current_action == 'ykfg') {
                                        pushData.coupon_use_id = app.globalData.current_coupon_use_id
                                    }
                                    sendData(pushData, app)

                                    app.globalData.current_action = ''
                                    app.globalData.ret_order = ''
                                    //app.globalData.ret_orders = ret_orders;
                                } else {
                                    app.globalData.ret_order = ret_order
                                }
                            })
                        },
                    })
                }
            }
        },
        fail(res) {
            console.error('getBLEDeviceCharacteristics', res)
        },
    })

    const check_order_complete = (order, app) => {
        if (!order) {
            return false
        }

        if (order.substr(-2, 2) != '16') {
            return false
        }
        let check_code = order.substr(-4, 2)
        let hex_data
        if (app.globalData.machine.type == 0) {
            hex_data = order.substr(0, order.length - 4)
        }
        if (app.globalData.machine.type == 1) {
            hex_data = order.substr(8, order.length - 12)
        }
        //console.log('hex_data', hex_data);
        let init_hex = 0
        for (let i = 0; i < (hex_data.length) / 2; i++) {
            let hex_i = hex_data.substr(i * 2, 2)
            init_hex += hex2int(hex_i)
        }
        //console.log('int2hex', int2hex(init_hex));
        let ret_hex_check = int2hex(init_hex)
        ret_hex_check = ret_hex_check.substr(-2, 2)
        ret_hex_check = ret_hex_check.length == 1 ? (`${0}${ret_hex_check}`) : ret_hex_check
        if (ret_hex_check != check_code) {
            return false
        }

        return true
    }

    const hex2int = (hex) => {
        let len = hex.length, a = new Array(len), code
        for (let i = 0; i < len; i++) {
            code = hex.charCodeAt(i)
            if (48 <= code && code < 58) {
                code -= 48
            } else {
                code = (code & 0xdf) - 65 + 10
            }
            a[i] = code
        }

        return a.reduce(function(acc, c) {
            acc = 16 * acc + c
            return acc
        }, 0)
    }

    const int2hex = (num) => {
        let hex = '0123456789abcdef'
        let s = ''
        while (num) {
            s = hex.charAt(num % 16) + s
            num = Math.floor(num / 16)
        }
        return s.substr(-2, 2)
    }
}

const updateDevice = (
    deviceId, key, value, app
) => {
    if (app.globalData.device.deviceId == deviceId) {
        app.globalData.device[key] = value
    }
}

export const writeBLECharacteristicValue = (
    page, hex, app
) => {
    if (!hex) {
        wx.showToast({
            title: '指令缺失，终止发送',
            icon: 'none',
            duration: 2000,
        })
        return
    }
    let typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function(h) {
        return parseInt(h, 16)
    }))

    let buffer = typedArray.buffer

    app.globalData.machine = page.data.machine

    if (app.globalData.device.deviceId === undefined) {
        wx.showToast({
            title: '未检测到有连接的蓝牙设备',
            icon: 'none',
            duration: 2000,
        })
        return
    }

    let device = app.globalData.device

    wx.writeBLECharacteristicValue({
        deviceId: device.deviceId,
        serviceId: device._serviceId,
        characteristicId: device._characteristicId,
        value: buffer,
    }).then((res) => {
        console.log('write_result', res)
    }).catch((err) => {
        wx.showToast({
            title: `发送失败:${JSON.stringify(err)}`,
            icon: 'none',
            duration: 2000,
        })
        console.log(err)
    })
}
