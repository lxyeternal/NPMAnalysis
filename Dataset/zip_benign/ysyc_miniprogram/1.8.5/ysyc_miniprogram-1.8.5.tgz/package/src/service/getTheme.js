import * as themeX from '@/config/theme'

import * as theme from '../config/theme'

export default function(prop) {
  if (!prop) {
    return {
      ...theme,
      ...themeX,
    }
  }
  if (typeof theme[prop] == 'object') {
    return {
      ...theme[prop],
      ...themeX[prop],
    }
  }
  return themeX[prop] ?? theme[prop]
}
