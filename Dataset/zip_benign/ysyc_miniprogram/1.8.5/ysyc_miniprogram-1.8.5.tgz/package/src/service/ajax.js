
import store from '../store'
/**
 *
 * @param {Object} options
 * @param {String} options.method 默认GET  方法 GET POST
 * @param {Boolean} options.message 默认false 是否提示，错误时会自动提交，此设置不影响
 * @param {Object} options.data 提交的data 根据method会自动转换
 * @param {Object} options.header
 * @param {String} options.url url, 必填
 * @param {String} options.cacheKey 启用缓存
 * @returns
 */
const request = (options) => {
  let timer
  return new Promise((resolve, reject) => {
    options.method = options.method || 'GET'
    options.message = options.message ?? false
    options.message401 = options.message401 ?? true
    options.isLoading = options.isLoading ?? false
    // 未登录时是否自动切换到登录页面
    options.onNoLoginSwitchTab = options.onNoLoginSwitchTab ?? true
    options.data = options.data || {}
    // options.dataType = options.dataType || 'json'
    // store.getState().token
    const _token = options.token || Taro.getStorageSync('token')
    options.header = {
      ...(_token ?
        {
          Authorization: _token.includes('Bearer') ? _token : `Bearer ${_token}`,
          token: _token,
          sessionkey: _token,
        } :
        {}),
      contentType: 'application/json;charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest',
      ...(options.header || {}),
    }
    if (options.method == 'GET') {
      // 去掉不需求的参数
      Object.keys(options.data).forEach(k => {
        if (options.data[k] == -999) {
          delete options.data[k]
        }
        if (Array.isArray(options.data[k])) {
          if (options.data[k].length > 0) {
            options.data[k] = options.data[k].join(',')
          } else {
            delete options.data[k]
          }
        }
      })
    }

    if (options.url.indexOf('http') != 0) {
      // 兼容
      let sep = options.url[0] == '/' ? '' : '/'
      options.url = configs.API_BASE_URL + sep + options.url
    }

    options.success = res => {
      const _ajaxThen = () => {
        res.data.data = res.data.data || {}
        if (res.data.code == configs.RESULT_TEMPLATE.code) {
          resolve(res.data)
        } else {
          reject(res.data)
        }
        if (options.message) {
          Taro.hideLoading()
        }
      }

      // console.log('success:', res)
      if (typeof res.data != 'object') {
        res.data = {
          data: {},
          code: res.statusCode,
        }
      }
      res.data.code = res.data.code ?? res.statusCode
      if (res.data.code == 401) {
        store.dispatch({ type: 'clearToken', })
        store.dispatch({ type: 'clearUserInfo', })
        if (options.message401) {
          Taro.showToast({
            title: res.data[configs.RESULT_TEMPLATE.msg] ?? '未登录',
            icon: 'none',
            duration: 2000,
            success() {
              _ajaxThen()
              // if (options.onNoLoginSwitchTab) {
              //     Taro.switchTab({ url: '/pages/my/index', })
              // }
            },
          })
        } else {
          _ajaxThen()
        }
      } else if ([
        400,
        404,
        503,
        500,
        0,
      ].includes(res.data.code)) {
        Taro.showToast({
          title: res.data[configs.RESULT_TEMPLATE.msg] || res.data?.message || `未知错误${res.data?.code}`,
          icon: 'none',
          duration: 2000,
          success() {
            _ajaxThen()
          },
        })
      } else if (res.data.code == configs.RESULT_TEMPLATE.code) {
        // 缓存
        if (options.cacheKey) {
          Taro.setStorageSync(options.cacheKey, JSON.stringify(res.data))
        }
        if (options.message) {
          // Taro.showToast与Taro.hideLoading不能一起使用
          Taro.hideLoading()
          if (options.method.toLowerCase() == 'post') {
            const toast = options.toast ?? {}
            Taro.showToast({
              title: toast.title || res.data[configs.RESULT_TEMPLATE.msg],
              icon: toast.icon || 'success',
              duration: toast.duration || 1000,
              success() {
                clearTimeout(timer)
                timer = setTimeout(() => {
                  _ajaxThen()
                }, toast.duration || 1000)
              },
            })
          } else {
            _ajaxThen()
          }
        } else {
          _ajaxThen()
        }
      }
    }

    options.fail = res => {
      console.log('fail:', res)
      Taro.showToast({
        title: res.data?.[configs.RESULT_TEMPLATE.msg] || res.data?.message || `未知错误${res.data?.code}`,
        icon: 'none',
        duration: 2000,
        success() {
          reject(res)
        },
      })
      if (options.message) {
        Taro.hideLoading()
      }
    }
    if (options.message) {
      Taro.showLoading({ title: '加载中...', })
    }
    if (options.cacheKey) {
      let cache = Taro.getStorageSync(options.cacheKey)
      if (cache) {
        let cacheKeyVal = JSON.parse(cache || '{}')
        resolve(cacheKeyVal)
      } else {
        Taro.request(options)
      }
    } else {
      Taro.request(options)
    }
  })
}
/**
 * 小程序的promise没有finally方法，自己扩展下
 */
/*Promise.prototype.finally = function (callback) {
    let Promise = this.constructor
    return this.then(
        function (value) {
            Promise.resolve(callback()).then(
                function () {
                    return value
                }
            )
        },
        function (reason) {
            Promise.resolve(callback()).then(
                function () {
                    throw reason
                }
            )
        }
    )
}*/

//所有接口定义在这里

export default request
