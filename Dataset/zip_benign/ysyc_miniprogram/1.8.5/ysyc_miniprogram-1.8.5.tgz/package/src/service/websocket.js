
import Taro, { eventCenter, } from '@tarojs/taro'
import useAuth from '@/components/useAuth'

// const { login, } = useAuth()
const heartBeat = 20

export const linkSocket = () => {
    // if (Taro.socketTask) {
    //     let _socketTask = Taro.socketTask
    //     console.log('socket链接状态', _socketTask.readyState)
    //     if (_socketTask.readyState === 3) {
    //         Taro.socketEnable = false
    //     } else if (_socketTask.readyState === 1) {
    //         //连接可用,可发送数据
    //         Taro.socketEnable = true
    //     } else if (_socketTask.readyState === 2) {
    //         //连接正在关闭
    //         Taro.socketEnable = false
    //     } else if (_socketTask.readyState === 0) {
    //         Taro.socketEnable = false
    //     }
    // }
    if (!Taro.socketEnable) {
        const _socketTask = wx.connectSocket({
            url: 'wss://shuid.sisundz.com/ws',
            success() {
                console.log('发起连接')
            },
        })

        let heartCheck = {
            timeout: heartBeat * 1000,
            timeoutObj: null,
            serverTimeoutObj: null,
            reset: function() {
                clearTimeout(this.timeoutObj)
                clearTimeout(this.serverTimeoutObj)
                return this
            },
            start: function() {
                let that = this
                this.timeoutObj = setTimeout(() => {
                    //心跳包
                    let da = {}
                    da.action = 'heart_beat'
                    da.token = wx.getStorageSync('token')
                    let pushData = JSON.stringify(da)
                    console.log(pushData)
                    wx.sendSocketMessage({
                        data: pushData,
                        fail(error) {
                            console.log(error)
                            that.reset()
                            Taro.socketEnable = false
                            linkSocket()
                        },
                    })
                    this.serverTimeoutObj = setTimeout(() => {
                        console.log('主动关闭了？')
                        //wx.closeSocket()
                    }, this.timeout)
                }, this.timeout)
            },
        }
        _socketTask.onMessage(function(res) {
            // let pages = getCurrentPages()
            // let currPage = pages[pages.length - 1]
            if (res.data == 'pong') {
                //开始登录
                let da = {}
                da.token = wx.getStorageSync('token')
                da.action = 'login'
                let pushData = JSON.stringify(da)
                wx.sendSocketMessage({ data: pushData, })
            } else {
                let json = res.data
                console.log(json)
                json = JSON.parse(json)
                heartCheck.reset().start()
                if (json.ret_code == 200) {
                    switch (json.action) {
                    case 'login':
                        break
                    case 'heart_beat':
                        break
                    case 'machine_action':
                        // 停止充电
                        if (json.code != Taro.currentCode) {
                            console.log(`当前设备未连接:${json.code}`)
                            return
                        }
                        wx.showToast({
                            title: '操作成功',
                            duration: 2000,
                            icon: 'none',
                        })
                        // currPage.read_machine_info()
                        //重读一次设备状态信息（设备通电状态，需要去设备读）
                        eventCenter.trigger('onInfoChange', json)
                        break
                    case 'machine_info':
                        // 设备信息更新
                        if (json.code != Taro.currentCode) {
                            console.log(`当前设备未连接:${json.code}`)
                            return
                        }
                        if (json.data !== undefined) {
                            //wx.hideLoading()
                            // setData(machine) 在onMachineInfo里处理
                            // after_machine_info(currPage, json.data)
                            // currPage.setData({ machine: machine, })

                            wx.showToast({
                                title: '数据更新成功！',
                                icon: 'none',
                                duration: 1500,
                            })
                            // currPage.machine_status_info()
                            //再从接口读一次设备的使用状态
                            eventCenter.trigger('onMachineInfoRefresh', json)
                            eventCenter.trigger('onMachineUseStatus', json)
                        }
                        break
                    case 'gd_ret_success':
                        // 这个是支付成功通知小程序下发充电指令还没到充电成功
                        if (json.code != Taro.currentCode) {
                            console.log(`当前设备未连接:${json.code}`)
                            break
                        }
                        // currPage.send_order(json.data.gd, 'gd')
                        eventCenter.trigger('onGdRetSuccess', json)
                        break
                    default:
                        break
                    }
                } else if (json.ret_code == 100501) {
                    //登录失效
                    eventCenter.trigger('onSocketLoginLoss', {})
                } else {
                    wx.showToast({
                        title: `未知错误:${JSON.stringify(json)}`,
                        icon: 'none',
                        duration: 1500,
                    })
                }
            }
        })
        _socketTask.onClose = (res) => {
            //服务器已经关闭此连接
            heartCheck.reset()
            //连接不可用
            console.log('服务器关闭socket了,连接不可用了')
            Taro.socketEnable = false
            //10秒钟唤醒一次
            // 未完善
        }
        _socketTask.onOpen(function() {
            //连接可用了
            console.log('socket连接可用了')
            Taro.socketEnable = true
            eventCenter.off('onOrderComplete').on('onOrderComplete', socketSendData)
        })

        _socketTask.onError(function(err) {
            //连接出错了
            console.log('socket出错', err)
            Taro.socketEnable = false
        })

        Taro.socketTask = _socketTask
    }
}
export const socketSendData = (data,) => {
    if (Taro.socketEnable) {
        let da = {}
        da.action = 'action'
        //已经登录过直接发送uid(或者不需要发送了)
        da.token = wx.getStorageSync('token')
        da.data = data
        let pushData = JSON.stringify(da)
        console.log('pushData', pushData)
        Taro.socketTask.send({
            data: pushData,
            success: function(res) {
                console.log(res)
            },
            fail: function() {
                console.log('error')
                Taro.socketEnable = false
                linkSocket()
                wx.showToast({
                    title: 'socket断开了，重连',
                    duration: 1500,
                    icon: 'none',
                })
                //最多只重试5次
                let limit = 5
                let inR = setInterval(function() {
                    limit --
                    if (limit < 0) {
                        clearInterval(inR)
                    }
                    if (Taro.socketEnable) {
                        clearInterval(inR)
                        socketSendData(data)
                    }
                }, 1500)
                if (Taro.socketEnable) {
                    clearInterval(inR)
                }
            },
        })
    } else {
        console.log('当前socket还不可用,开始重连')
        linkSocket()
        wx.showToast({
            title: 'socket断开了，重连',
            duration: 1500,
            icon: 'none',
        })
        //最多只重试5次
        let limit = 5
        let inR = setInterval(function() {
            limit --
            if (limit < 0) {
                clearInterval(inR)
            }
            if (Taro.socketEnable) {
                clearInterval(inR)
                socketSendData(data)
            }
        }, 1500)
        if (Taro.socketEnable) {
            clearInterval(inR)
        }
    }
}
