import deeps from './deeps'

const globalData = {}
export function setGlobalData(
  key, val, t
) {
  globalData[key] = deeps.isObject(val) ? deeps.merge({}, val) : val
  if (t) {
    globalData[`${key}_exp`] = t
    globalData[`${key}_create`] = t
  }
}
export function getGlobalData(key, del = false) {
  const data = globalData[key]
  if (del) {
    delete globalData[key]
  }
  return data
}
export function removeGlobalData(key) {
  delete globalData[key]
}
