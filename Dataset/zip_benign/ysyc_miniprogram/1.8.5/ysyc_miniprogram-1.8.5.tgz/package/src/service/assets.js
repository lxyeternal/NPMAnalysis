import { API_BASE_URL, } from '@/config'

// 拍照
export const csf_xcx_qdan = `${API_BASE_URL}/static/miniprogram/images/csf_xcx_qdan@2x.png`
export const csf_xcx_pz = `${API_BASE_URL}/static/miniprogram/images/csf_xcx_pz@2x.png`
export const csf_xcx_qxan = `${API_BASE_URL}/static/miniprogram/images/csf_xcx_qxan@2x.png`
export const xcx = `${API_BASE_URL}/static/miniprogram/images/csf_xcx_ps@2x.png`

export const banner = `${API_BASE_URL}/static/miniprogram/images/banner_sj@3x.png`
export const logo = `${API_BASE_URL}/static/miniprogram/images/logo.jpg`

export const defaultAvatar = '/static/miniprogram/images/cxewap_sy_qzqg@2xz.png'
