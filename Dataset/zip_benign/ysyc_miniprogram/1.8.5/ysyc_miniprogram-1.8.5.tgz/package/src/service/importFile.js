/**
 * fileName 指定文件名
 * exclude 要排除的文件名
 */
export default (
  rc, fileName, exclude
) => {
  let obj = {}
  if (!rc) {
    return obj
  }
  const keys = rc.keys()
  for (let index = 0; index < keys.length; index++) {
    const path = keys[index]
    let k = path.replace(/\.\/(\S+)\.js$/, '$1')
    if (fileName && path.includes(`${fileName}.js`)) {
      obj = rc(path).default
      break
    } else if (!fileName && !path.includes(`${exclude}.js`)) {
      obj[k] = rc(path).default
    }
  }
  return obj
}