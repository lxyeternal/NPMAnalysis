
// export { default as App } from '../app'
// service
export { getFormItem } from '../config/form'
export * as configs from '../config/index'
export { default as ajax } from '../service/ajax'
export { default as deeps } from '../service/deeps'
export { default as getTheme } from '../service/getTheme'
export * from '../service/globalData'
export { default as MyContext } from '../service/myContext'
export { default as qrcode } from '../service/qrcode'
export * as utils from '../service/utils'
