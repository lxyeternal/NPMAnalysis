import Taro, { eventCenter, } from '@tarojs/taro'
import React, { useCallback, useState, } from 'react'
// import { useMappedState, useDispatch, } from 'redux-react-hook'
import { useDispatch, useSelector, } from 'react-redux'

import indexCss from './index.scss'

const color = '#666'
const selectedColor = '#3E82FE'
export default () => {
  const tabbarState = useSelector(useCallback((state) => {
    return state.tabbar
  }, []))
  const dispatch = useDispatch()
  const [ list, setList, ] = useState([
    {
      iconPath: 'icon-shouye1',
      selectedIconPath: 'icon-shouye1',
      pagePath: '/pages/index/index',
      text: '首页',
      num: 0,
    },
    {
      iconPath: 'icon-shouye1',
      selectedIconPath: 'icon-shouye1',
      pagePath: '/pages/index/test',
      text: '测试',
      num: 0,
    },
  ])

  const switchTab = (item, index) => {
    const url = item.pagePath
    dispatch({
      type: 'setTabbar',
      payload: { selected: index, }, 
    })
    Taro.switchTab({ url, })
  }
  return (
    <view class='tab-bar'>
      <view class='tab-bar-border'></view>
      {list.map((item, index) => {
        return (
          <view
            key={index}
            class='tab-bar-item'
            onClick={() => switchTab(item, index)}
            style={{ display: index === 2 ? (tabbarState.show ? 'flex' : 'none') : 'flex', }}
          >
            <view
              style={{
                position: 'relative',
                width: '20px',
                height: '20px',
                marginBottom: '3px',
                fontSize: '20px',
                color: tabbarState.selected === index ? selectedColor : color, 
              }}
              class={`iconfont ${tabbarState.selected === index ? item.selectedIconPath : item.iconPath}`}
            >
              {!!item.num && (
                <text
                  style={{
                    position: 'absolute',
                    right: '-8px',
                    fontSize: '8px',
                    width: '14px',
                    height: '14px',
                    lineHeight: '14px',
                    borderRadius: '14px',
                    background: '#f00',
                    color: '#fff', 
                  }}
                >{item.num}</text>
              )}
            </view>
            <view
              style={{
                fontSize: '11px',
                color: tabbarState.selected === index ? selectedColor : color, 
              }}
            >{item.text}</view>
          </view>
        )
      })}
    </view>
  )
}