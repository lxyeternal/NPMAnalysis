import fs from 'fs-extra'
import watch from 'node-watch'
import path from 'path'

const [
  node_,
  script_,
  project_,
] = process.argv
function exists(p) {
  return fs.existsSync(p) || path.existsSync(p)
}
function isFile(p) {
  return exists(p) && fs.statSync(p).isFile()
}
const toWatch = () => {
  if (!project_) {
    console.warn('请先指定要 debug 的项目名称, "yarn debug 项目名称"')
    return
  }
  const distPath = (p = '') => path.resolve(
    '../', project_, 'node_modules/ysyc_miniprogram', p
  )
  fs.copySync('./src', distPath('src'))
  fs.copySync('./config', distPath('config'))
  // fs.copySync('./src/index.js', distPath('src/index.js'))
  console.log(`已同步至${distPath()}`)
  watch(
    [
      './src',
      './eslintrc.js',
      './config', 
    ], { recursive: true, }, function(evt, name) {
      const toPath = distPath(name)
      console.log(evt, name)
      if (evt == 'update' && isFile(name)) {
        fs.copy(name, toPath)
      } else if (evt == 'remove') {
        fs.remove(toPath)
      }
    }
  )
}
toWatch()
