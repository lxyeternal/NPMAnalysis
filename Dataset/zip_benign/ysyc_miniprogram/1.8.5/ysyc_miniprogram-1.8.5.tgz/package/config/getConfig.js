const path = require('path')
const envConfig = require('./env')
const { syncConf, } = require('vscode-conf')

const resolve = (...args) => {
  return path.join(
    __dirname, '..', ...args
  )
}
class AutoImport {
  constructor(...args) {
    return require('unplugin-auto-import/webpack')(...args)
  }
}
require('./check')
// 同步配置
syncConf({ type: 'wx', })

module.exports = function(merge, { autoImport = [], } = {}) {
  const config = {
    projectName: 'miniprogram',
    date: '2020-7-21',
    designWidth: 750,
    deviceRatio: {
      640: 2.34 / 2,
      750: 1,
      828: 1.81 / 2,
    },
    sourceRoot: 'src',
    outputRoot: 'dist',
    plugins: [ 'taro-plugin-compiler-optimization', ],
    // plugins: [ 'taro-plugin-compiler-optimization', [ 'unplugin-auto-import/webpack', { imports: [ '@tarojs/taro', ], }, ], ],
    defineConstants: {},
    copy: {
      patterns: [
        {
          from: './sitemap.json',
          to: 'dist/weapp/sitemap.json',
        },
        {
          from: 'src/custom-tab-bar/',
          to: 'dist/custom-tab-bar/',
        },
        {
          from: 'src/assets/tabbar',
          to: 'dist/assets/tabbar',
        },
      ],
      options: {},
    },
    framework: 'react',
    compiler: {
      type: 'webpack5',
      // 仅 webpack5 支持依赖预编译配置
      prebundle: { enable: false, },
    },
    // Webpack 持久化缓存配置，建议开启。默认配置请参考：https://docs.taro.zone/docs/config-detail#cache
    cache: { enable: false, },
    mini: {
      alias: {
        '@': path.resolve('src/'),
        ajax: resolve('src/service/ajax'),
      },
      miniCssExtractPluginOption: { ignoreOrder: true, },
      postcss: {
        pxtransform: {
          enable: true,
          config: {},
        },
        url: {
          enable: true,
          config: {
            // 设定转换尺寸上限
            limit: 10240,
          },
        },
        cssModules: {
          enable: false, // 默认为 false，如需使用 css modules 功能，则设为 true
          config: {
            namingPattern: 'module', // 转换模式，取值为 global/module
            generateScopedName: '[name]__[local]___[hash:base64:5]',
          },
        },
      },

      compile: { include: [ modulePath => modulePath.indexOf('ysyc_miniprogram') >= 0, ], },
      webpackChain: (chain) => {
        // 自动导入
        chain.plugin('auto-import').use(AutoImport, [
          {
            dirs: [
              resolve('src/components'),
              resolve('src/auto-import'),
              ...autoImport,
            ],
            imports: [
              {
                '@tarojs/taro': [
                  'useDidShow',
                  'definePageConfig',
                  'eventCenter',
                  'getCurrentInstance',
                  'useReady',
                  [ 'default', 'Taro', ],
                ],
              },
              'react',
              { 'react-redux': [ 'useDispatch', 'useSelector', ], },
            ],
            exclude: [
              /[\\/]node_modules(?!\/\S*ysyc_miniprogram)[\\/]/,
              /[\\/]\.git[\\/]/,
              /[\\/]\.nuxt[\\/]/,
            ],
            dts: resolve('./auto-imports.d.ts'),
            include: [ /\.[tj]sx?$/, ],
            eslintrc: {
              enabled: true,
              filepath: resolve('./.eslintrc-auto-import.json'),
            },
          },
        ])
      },
    },
    h5: {
      publicPath: '/',
      staticDirectory: 'static',
      postcss: {
        autoprefixer: {
          enable: true,
          config: {},
        },
        cssModules: {
          enable: false, // 默认为 false，如需使用 css modules 功能，则设为 true
          config: {
            namingPattern: 'module', // 转换模式，取值为 global/module
            generateScopedName: '[name]__[local]___[hash:base64:5]',
          },
        },
      },
    },
  }
  // process.env.NODE_ENV 不生效，先删除了，内部会判断
  // delete process.env.NODE_ENV
  // return config
  if (process.env.NODE_ENV === 'development') {
    return merge(
      {}, config, require(path.resolve('config/dev')), { env: envConfig, }
    )
  }
  return merge(
    {}, config, require(path.resolve('config/prod')), { env: envConfig, }
  )
}
