const fs = require('fs')

const createEnvFile = (fileName) => {
  if (!fs.existsSync(fileName)) {
    fs.copyFileSync(`config/${fileName}-sample`, fileName)
  }
};
[
  '.env.development',
  '.env.production',
  '.env.release', 
  'project.config.json', 
].forEach(createEnvFile)

let envConfig = require('dotenv').config({ path: `.env.${process.env.NODE_ENV.trim()}`, }).parsed

if (!envConfig) {
  envConfig = require('dotenv').config({ path: '.env', }).parsed || {}
}
Object.keys(envConfig).forEach(key => {
  envConfig[key] = JSON.stringify(envConfig[key])
})
module.exports = envConfig