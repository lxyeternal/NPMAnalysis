const fs = require('fs-extra')

const checkConfigForm = () => {
  const _path = 'src/config/form.jsx'
  if (!fs.existsSync(_path)) {
    fs.writeFileSync(_path, `
import React, { } from 'react'

export const getFormItem = ({
    item,
    type,
    value,
    onChange,
    getCategory
}) => {
    // 写要扩展的代码, 请参考ysys_miniprogram/src/config/form.jsx
}
    `)
  }
}

checkConfigForm()

const checkStore = () => {
  const _path = 'src/store/reducers'
  fs.ensureDirSync(_path)
}
checkStore()

const checkTabbr = () => {
  const _path = 'src/assets/tabbar/tabbar图标.txt'
  fs.ensureFileSync(_path)
}

checkTabbr()