const getConfig = require('./getConfig')

module.exports = function(merge) {
  const config = getConfig(merge)
  return merge({}, config,)
}
