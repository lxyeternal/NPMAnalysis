// babel-preset-taro 更多选项和默认值：
// https://github.com/NervJS/taro/blob/next/packages/babel-preset-taro/README.md
const plugins = [
    // 根、子目录的公共插件
    '@babel/plugin-transform-runtime',
    '@babel/plugin-proposal-class-properties',
    // a.b.c => a?.b?.c
    '@babel/plugin-proposal-optional-chaining',
    '@babel/plugin-proposal-nullish-coalescing-operator',
    '@babel/plugin-proposal-export-default-from',
    // 'babel-plugin-add-module-exports'
    // 'transform-vue-jsx'
]

module.exports = {
    presets: [
        ['taro', {
            framework: 'react',
            ts: false
        }]
    ],
    plugins
}

