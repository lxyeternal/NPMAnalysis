module.exports = {
    extends: [
        './eslintrc'
    ],
    globals: {
      Component: true,
      wx: true,
      Table: true,
    },
}
