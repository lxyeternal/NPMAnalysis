export declare enum ScriptOptions {
    LATIN = "Latin",
    CHINESE = "Chinese",
    DEVANAGARI = "Devanagari",
    JAPANESE = "Japanese",
    KOREAN = "Korean"
}
export type Options = {
    visionIgnoreThreshold?: number;
    script?: ScriptOptions;
};
type TextReaderType = {
    read(imagePath: string, options?: Options): Promise<string[]>;
};
declare const _default: TextReaderType;
export default _default;
//# sourceMappingURL=index.d.ts.map