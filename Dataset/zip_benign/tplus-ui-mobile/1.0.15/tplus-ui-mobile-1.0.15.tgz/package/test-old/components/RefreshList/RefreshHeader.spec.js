/**
 * Created by TonyJiang on 16/4/7.
 */
import React from 'react';

import RefreshHeader from '../../../src/components/RefreshListRemove/RefreshHeader'

import 'should'
import chai from 'chai'
import sinon from 'sinon'
import expect from 'expect'
import { mount, shallow } from 'enzyme';

const assert = chai.assert;

describe('RefreshHeader' , ()=>{

    let watcherCallback = {};
    const watcherSPY = sinon.spy((variables , callback)=>{
        watcherCallback[variables] = callback
    });
    const requestDataSPY = sinon.spy(()=>{
        return new Promise((fullfill)=>{
            fullfill();
        });
    });
    const scrollToSPY = sinon.spy();

    const clientHeight = 300;
    const contentHeight = 3000;
    const distanceToRefresh = 40;
    const topLine = 0;
    const topTriggerLine = topLine + distanceToRefresh;

    let deltaYEvent = {
        deltaY : 0 ,
        clientHeight ,
        contentHeight ,
        duration : 0 ,
        isInertial : false
    };

    const refreshHeaderInstance = mount(
        <RefreshHeader
            distanceToRefresh={distanceToRefresh}
            requestData={requestDataSPY}
            scrollTo={scrollToSPY}
            watcher={watcherSPY}
        />
    );

    beforeEach(()=>{
        //重置初始状态
        requestDataSPY.reset();
        watcherCallback.reset({},{});
        deltaYEvent = {
            deltaY : 0 ,
            clientHeight ,
            contentHeight ,
            duration : 0 ,
            isInertial : false
        };
    });

    it('y轴移动到topLine+1 , 显示状态变为show' , ()=>{

        deltaYEvent.deltaY = topLine + 1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshHeaderInstance.state().show).toBe(true);

    });

    it('y轴移动到topLine-1 , 显示状态变为hide' , ()=>{

        deltaYEvent.deltaY = topLine-1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshHeaderInstance.state().show).toBe(false);

    });

    it('y轴移动到topTriggerLine+1 , 状态变为TRIGGER' , ()=>{

        watcherCallback.scrolling({} , {press : true , clientHeight , contentHeight});

        deltaYEvent.deltaY = topTriggerLine + 1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshHeaderInstance.state().status).toEqual(RefreshHeader.STATUS.TRIGGER);
    });

    it('y轴移动到topTriggerLine-1 , 状态变为INITIAL' , ()=>{
        watcherCallback.scrolling({} , {press : true , clientHeight , contentHeight});

        deltaYEvent.deltaY = topTriggerLine - 1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshHeaderInstance.state().status).toEqual(RefreshHeader.STATUS.INITIAL);
    });

    it('y轴移动到触发刷新状态后松手 , 应该调用props.requestData' , ()=>{
        watcherCallback.scrolling({} , {press : true , clientHeight , contentHeight});
        deltaYEvent.deltaY = topTriggerLine + 1;
        watcherCallback.deltaY({} , deltaYEvent);
        watcherCallback.scrolling({} , {press : false , clientHeight , contentHeight , direction : 'down'});

        expect(requestDataSPY.calledOnce).toBe(true);
    });

});
