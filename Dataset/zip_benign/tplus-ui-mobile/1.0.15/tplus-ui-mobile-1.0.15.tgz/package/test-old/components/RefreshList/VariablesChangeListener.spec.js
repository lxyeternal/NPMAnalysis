/**
 * Created by TonyJiang on 16/4/7.
 */
import React from 'react';

import VariablesChangeListener from '../../../src/components/RefreshListRemove/VariablesChangeListener'

import 'should'
import chai from 'chai'
import sinon from 'sinon'
import expect from 'expect'
import { mount, shallow } from 'enzyme';

const assert = chai.assert;

describe('VariablesChangeListener' , ()=>{

    let watcher;

    beforeEach(()=>{
        watcher = new VariablesChangeListener();
    });

    it('add调用后, _map中应该存在对应值' , ()=>{

        const testKey = 'test';
        const testValue = 'teststring';
        watcher.add(testKey , testValue);

        expect(watcher._map[testKey]).toEqual(testValue);

    });

    it('调用listen监听后, 调用update应该触发回调' , ()=>{

        const testKey = 'test2';
        const oldTestValue = 'oldtestvalue';
        const newTestValue = 'newtestvalue';

        const watcherCallback = sinon.spy();

        watcher.add(testKey , oldTestValue);
        watcher.listen(testKey , watcherCallback);

        watcher.update(testKey , newTestValue);

        expect(watcherCallback.calledOnce);
    });

    it('update触发回调时, 参数长度应该等于2 , 分别是之前的老值和新值' , ()=>{

        const testKey = 'test2';
        const oldTestValue = 'oldtestvalue';
        const newTestValue = 'newtestvalue';

        const watcherCallback = sinon.spy();

        watcher.add(testKey , oldTestValue);
        watcher.listen(testKey , watcherCallback);

        watcher.update(testKey , newTestValue);

        expect(watcherCallback.getCall(0).args.length).toEqual(2);
        expect(watcherCallback.getCall(0).args[0]).toEqual(oldTestValue);
        expect(watcherCallback.getCall(0).args[1]).toEqual(newTestValue);

    });

    it('对同一个变量进行多次监听,update时,每一个监听都被回调' , ()=>{
        const testKey = 'test2';
        const testValue = 'testvalue';
        const newTestValue = 'newtestvalue';

        const watcherCallback = sinon.spy();
        const watcherCallback2 = sinon.spy();
        const watcherCallback3 = sinon.spy();

        watcher.add(testKey , testValue);

        watcher.listen(testKey , watcherCallback);
        watcher.listen(testKey , watcherCallback2);
        watcher.listen(testKey , watcherCallback3);

        watcher.update(testKey , newTestValue);

        expect(watcherCallback.calledOnce).toBe(true);
        expect(watcherCallback2.calledOnce).toBe(true);
        expect(watcherCallback3.calledOnce).toBe(true);


    });


    
    
});