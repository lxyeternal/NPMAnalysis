/**
 * Created by TonyJiang on 16/4/6.
 */

import React from 'react';

import RefreshList from '../../../src/components/RefreshList'
import RefreshHeader from '../../../src/components/RefreshListRemove/RefreshHeader'
import _List from '../../../src/components/RefreshListRemove/_List'
import RefreshBottom from '../../../src/components/RefreshListRemove/RefreshBottom'
import ScrollBar from '../../../src/components/RefreshListRemove/ScrollBar'

import 'should'
import chai from 'chai'
import sinon from 'sinon'
import expect from 'expect'
import { mount, shallow } from 'enzyme';

const assert = chai.assert;

describe('RefreshListDeprecated' , ()=>{

    describe("render" , ()=>{

        it('验证子组件结构' , ()=>{

            let instance = shallow(<RefreshList />);

            let children = instance.children();

            expect(children.length).toBe(4);
            expect(children.at(0).type()).toBe(RefreshHeader);
            expect(children.at(1).type()).toBe(_List);
            expect(children.at(2).type()).toBe(RefreshBottom);
            expect(children.at(3).type()).toBe(ScrollBar);

        });

    });

    describe('api' , ()=>{

        const refreshDataSize = 10;
        const moreDataSize = 20;
        const refreshHandlerSPY = sinon.spy(()=>{
            return new Promise((fullfill)=>{
                fullfill(refreshDataSize);
            });
        });
        const moreHandlerSPY = sinon.spy(()=>{
            return new Promise((fullfill)=>{
                fullfill(moreDataSize)
            });
        });
        const itemRendererSPY = sinon.spy();

        const clientHeight = 300;
        const contentHeight = 3000;
        const distanceToRefresh = 40;
        const bottomTriggerLine = -(contentHeight - clientHeight) - distanceToRefresh;

        let deltaYEvent = {
            deltaY :  0,
            clientHeight ,
            contentHeight ,
            duration : 0 ,
            isInertial : false
        };
        
        const wrapper = mount(
            <RefreshList
                distanceToRefresh={distanceToRefresh}
                refreshHandler={refreshHandlerSPY}
                moreHandler={moreHandlerSPY}
                itemRenderer={itemRendererSPY}
            />
        );

        const instance = wrapper.instance();

        beforeEach(()=>{
            refreshHandlerSPY.reset();
            moreHandlerSPY.reset();
            itemRendererSPY.reset();
        });

        it('refreshHandler 在触发刷新时会被调用一次' , ()=>{

            instance._variableListener.update('scrolling' , {press:true , contentHeight , clientHeight});
            deltaYEvent.deltaY = distanceToRefresh + 1;
            instance._variableListener.update('deltaY' , deltaYEvent);
            instance._variableListener.update('scrolling' , {press:false , contentHeight , clientHeight , direction : 'down'});

            expect(refreshHandlerSPY.callCount).toBe(1);

        });

        it('moreHandler 在触发加载更多时会被调用一次' , ()=>{

            instance._variableListener.update('scrolling' , {press:true , contentHeight , clientHeight});
            deltaYEvent.deltaY = bottomTriggerLine - 1;
            instance._variableListener.update('deltaY' , deltaYEvent);
            instance._variableListener.update('scrolling' , {press:false , contentHeight , clientHeight , direction : 'up'});

            expect(moreHandlerSPY.callCount).toBe(1);

        });

        it('获取到数据后, itemRenderer会被调用dataSize次' , (done)=>{

            instance._variableListener.update('scrolling' , {press:true , contentHeight , clientHeight});
            deltaYEvent.deltaY = distanceToRefresh + 1;
            instance._variableListener.update('deltaY' , deltaYEvent);
            instance._variableListener.update('scrolling' , {press:false , contentHeight , clientHeight , direction : 'down'});

            //延迟等待state更新
            setTimeout(()=>{
                expect(itemRendererSPY.callCount).toEqual(refreshDataSize);
                done();
            } , 200);


        });

    });


});
