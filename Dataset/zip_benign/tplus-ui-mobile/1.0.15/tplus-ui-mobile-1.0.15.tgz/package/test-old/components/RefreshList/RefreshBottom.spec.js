/**
 * Created by TonyJiang on 16/4/7.
 */
import React from 'react';

import RefreshBottom from '../../../src/components/RefreshListRemove/RefreshBottom'

import 'should'
import chai from 'chai'
import sinon from 'sinon'
import expect from 'expect'
import { mount, shallow } from 'enzyme';

const assert = chai.assert;


describe('RefreshBottom' , ()=>{
    let watcherCallback = {};
    const watcherSPY = sinon.spy(function(variables , callback){
        watcherCallback[variables] = callback
    });
    const requestDataSPY = sinon.spy(()=>{
        return new Promise((fullfill)=>{
            fullfill();
        });
    });
    const scrollToSPY = sinon.spy();

    const clientHeight = 300;
    const contentHeight = 3000;
    const distanceToRefresh = 40;
    const bottomLine = -(contentHeight - clientHeight);
    const bottomTriggerLine = bottomLine - distanceToRefresh;

    let deltaYEvent = {
        deltaY : 0 ,
        clientHeight ,
        contentHeight ,
        duration : 0 ,
        isInertial : false
    };

    const refreshBottomInstance = mount(
        <RefreshBottom
            distanceToRefresh={distanceToRefresh}
            requestData={requestDataSPY}
            scrollTo={scrollToSPY}
            watcher={watcherSPY}
        />
    );

    beforeEach(()=>{
        //重置初始状态
        requestDataSPY.reset();
        watcherCallback.reset({},{});
        deltaYEvent = {
            deltaY : 0 ,
            clientHeight ,
            contentHeight ,
            duration : 0 ,
            isInertial : false
        };
    });

    it('y轴移动到bottomLine以下 , 显示状态变为show' , ()=>{

        deltaYEvent.deltaY = bottomLine - 1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshBottomInstance.state().show).toBe(true);

    });

    it('y轴移动到bottomLine以上 , 显示状态变为hide' , ()=>{

        deltaYEvent.deltaY = bottomLine + 1;
        watcherCallback.deltaY({} , deltaYEvent);
        expect(refreshBottomInstance.state().show).toBe(false);

    });


    it('y轴移动到bottomTriggerLine以上 , 状态变为TRIGGER' , ()=>{

        watcherCallback.scrolling({} , {press : true , clientHeight , contentHeight});

        deltaYEvent.deltaY = bottomTriggerLine - 1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshBottomInstance.state().status).toEqual(RefreshBottom.STATUS.TRIGGER);
    });

    it('y轴移动到bottomTriggerLine以下 , 状态变为INITIAL' , ()=>{
        watcherCallback.scrolling({} , {press : true , clientHeight , contentHeight});

        deltaYEvent.deltaY = bottomTriggerLine + 1;
        watcherCallback.deltaY({} , deltaYEvent);

        expect(refreshBottomInstance.state().status).toEqual(RefreshBottom.STATUS.INITIAL);
    });

    it('y轴移动到触发刷新状态后松手 , 应该调用props.requestData' , ()=>{
        watcherCallback.scrolling({} , {press : true , clientHeight , contentHeight});

        deltaYEvent.deltaY = bottomTriggerLine - 1;
        watcherCallback.deltaY({} , deltaYEvent);

        watcherCallback.scrolling({} , {press : false , clientHeight , contentHeight , direction : 'up'});

        expect(requestDataSPY.calledOnce).toBe(true);
    });
});