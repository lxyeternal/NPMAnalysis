# xgis-ol

<p>
<a href="https://www.npmjs.com/package/xgis-ol" target="_blank">
 <img src="https://img.shields.io/npm/v/xgis-ol?color=orange&logo=npm" />
</a>
<a href="https://www.npmjs.com/package/xgis-ol" target="_blank">
 <img src="https://img.shields.io/npm/dt/xgis-ol?logo=npm"/>
</a>
</p>

基于 Openlayers二次封装的WebGIS开发库

> xgis-ol 0.4.x以后版本是基于openlayers 10.3.x 、ol-ext和ol-mapbox-style进行二次封装的2D WebGIS开发库，相关组件UI改为quasar版，进一步增强原有功能，引入通过地图配置初始化地图和常用地图加载支持。

- v0.4.3 修改PrjGridTool.getProjectionOnline方法错误;XMap增加setProjection修改投影方法；

- v0.4.2  去掉measureToolList和drawToolList默认定位样式;实现将mapMenuState与地图对象绑定(调用改为xmap.mapMenuState),避免多地图状态互斥;WMTS图层ID默认为图层名（不再使用uuid）;解决图层树选中状态不更新BUG;

- v0.4.1  修改天地图影像图层别名错误;WMTSTool增加addWMTSLayerByXMLOptions方法;为XMap增加PrintTool打印工具类;增加地图文档DefaultMapConfig.json模版；增强PrjGridTool功能如下：

  1.  getProjectionOnline：在线查询EPSG，构建Projection
  2.  getWMTSCapabilities：获取WMTSGetCapabilities的XML元数据并解析成对象
  3.  getXMLOptionsFromCapabilities：解析XML对象构建WMTSOptions对象（用于加载WMTSLayer）
  4.  getScaleToResolutionParam  计算比例尺=》分辨率转换参数
  5.  computeScaleByResolution  通过分辨率，获取当前级别的比例尺
  6.  computeResolutionByScale  通过地图比例尺，计算地面分辨率

- v0.4.0  全新初始版本，相关API功能示例和开发文档参考门户页。

  ------

- v0.3.6  解决v0.3.5版ol新版本后导致无法构建TileGrid对象导致矢量图层无法加载问题

- ~~v0.3.5 解决LayerTree组件里Invalid watch source警告；升级ant-design-vue 4.x版本、ol 8.2.0版本、proj4 2.9.2~~  

- v0.3.4 *olxMap和XMapView增加multiWorld参数实现地图循环；地图中心点、鼠标位置的经纬度在[-180,180]之间

- v0.3.3 *去掉对xframelib库依赖；修改ant-design组件引入问题

- v0.3.2 解决图层管理无法关闭图层；增加图层定位；增加DrawFeatureTool；修改天地图图层名；支持地图多投影切换;修改PrjGridTool解决‘ol/prj’里的fromLonLat、toLonLat、transformExtent存在转换坐标失败的问题

- v0.3.1 根据山水项目完善功能，解决矢量切片加载getTileCoordForXYAndZ_方法报错

- v0.3.0 去掉地图背景为红；OLXMap支持修改地图视图；WMTTool的addWMTSLayerSelf定位错误

- v0.2.9 解决滚轮缩放时显示地图等级不变的问题

- v0.2.8 修改提示XMapView等未导出问题;修改XMapView用于多屏支持;WMTSTool增加addWMTSDebugLayer、addTileDebugLayer方法

- v0.2.7 封装核心的OLXMap组件和通用的XMapView组件;增加MapTool常用工具菜单;完善图层管理组件LayerTree;增加对接影像服务的WMTSTool.addWMTSLayerSelf方法

- v0.2.6 修改添加WMTSTool的加载WMTS方法和ITileGridSchema模型

- v0.2.5 重构后的第一版（重新梳理结构）

- v0.2.4 修改 addVTLayer 方法（根据矢量切片约定的 TileJson 元数据加载图层）

- v0.2.3 升级基础依赖 ol 6.9.0；解决升级的各种问题；重点重构 addVTLayer 加矢量切片图层

- v0.2.2 解决量算 BUG,支持不同投影下量算;增加按范围缩放定位地图

- v0.2.1 修改天地图图层加载（XYZ 方式有问题）；可从图层树里设置 Swipe 图层

- v0.2.0 天地图图层加入 KEY

- v0.1.9 解决图层树关闭问题；WMTS 加载存在小问题；修改存在的小问题

- v0.1.8 解决 measuretool 的问题;解决基础库打包.d.ts 过大的问题

- v0.1.7 解决 npm 库调用发现的各种问题;去掉 uuid 库依赖;加入 assest 字体资源

- v0.1.6 增加基于 AntdesignUI 的图层管理功能

- v0.1.5 常用地图功能封装

## What Works:

- 图层管理组件封装
- 鱼眼分析
- 卷帘分析（横向、纵向）
- 多地图同步
- 量算工具 封装
- 点、线、面绘制工具 封装
- 加载天地图、WMTS 和矢量切片图层

## Installation

`yarn add xgis-ol`

or

`npm i xgis-ol`

## Usage

暂无
