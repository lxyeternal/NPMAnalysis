# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [0.1.0-alpha.2](https://gitlab.com/bia-design/bianic-ui/compare/@bianic-ui/clickable@0.1.0-alpha.1...@bianic-ui/clickable@0.1.0-alpha.2) (2020-09-03)

**Note:** Version bump only for package @bianic-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 0.1.0-alpha.1 (2020-09-03)

### Bug Fixes

- **clickable:** update ClickableProps to include as type
  ([7615a43](https://gitlab.com/bia-design/bianic-ui/commit/7615a43cf465d9aceeb65322345f198e4db8cc07))
- **clickable:** update stories title
  ([0ef7173](https://gitlab.com/bia-design/bianic-ui/commit/0ef71730bf8a3cf6b0891d13bbd348250310e9ab))
- [#891](https://gitlab.com/bia-design/bianic-ui/issues/891)
  ([e107acc](https://gitlab.com/bia-design/bianic-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- prevent issue where right click triggers active css state
  ([4ea9b88](https://gitlab.com/bia-design/bianic-ui/commit/4ea9b8872599168f7a6ecb078b62f3473a25b4d8))
- ts issue with sx prop
  ([d3b1340](https://gitlab.com/bia-design/bianic-ui/commit/d3b1340cb255937927b4d4c56ce218141570b951))
- types issue in use-tabs
  ([c388927](https://gitlab.com/bia-design/bianic-ui/commit/c38892760257b9bbf1b63c05f7f9ccf1684a90b0))

# 1.0.0-rc.3 (2020-08-30)

**Note:** Version bump only for package @chakra-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.2 (2020-08-09)

**Note:** Version bump only for package @chakra-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-rc.1](https://github.com/chakra-ui/chakra-ui/compare/@chakra-ui/clickable@1.0.0-rc.0...@chakra-ui/clickable@1.0.0-rc.1) (2020-08-06)

**Note:** Version bump only for package @chakra-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-rc.0](https://github.com/chakra-ui/chakra-ui/compare/@chakra-ui/clickable@1.0.0-next.7...@chakra-ui/clickable@1.0.0-rc.0) (2020-07-26)

**Note:** Version bump only for package @chakra-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.7](https://github.com/chakra-ui/chakra-ui/compare/@chakra-ui/clickable@1.0.0-next.6...@chakra-ui/clickable@1.0.0-next.7) (2020-07-26)

### Bug Fixes

- prevent issue where right click triggers active css state
  ([4ea9b88](https://github.com/chakra-ui/chakra-ui/commit/4ea9b8872599168f7a6ecb078b62f3473a25b4d8))
- types issue in use-tabs
  ([c388927](https://github.com/chakra-ui/chakra-ui/commit/c38892760257b9bbf1b63c05f7f9ccf1684a90b0))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.6](https://github.com/chakra-ui/chakra-ui/compare/@chakra-ui/clickable@1.0.0-next.5...@chakra-ui/clickable@1.0.0-next.6) (2020-07-15)

**Note:** Version bump only for package @chakra-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.5](https://github.com/chakra-ui/chakra-ui/compare/@chakra-ui/clickable@1.0.0-next.4...@chakra-ui/clickable@1.0.0-next.5) (2020-07-15)

**Note:** Version bump only for package @chakra-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.4 (2020-07-01)

### Bug Fixes

- [#891](https://github.com/chakra-ui/chakra-ui/issues/891)
  ([e107acc](https://github.com/chakra-ui/chakra-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- ts issue with sx prop
  ([d3b1340](https://github.com/chakra-ui/chakra-ui/commit/d3b1340cb255937927b4d4c56ce218141570b951))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.3 (2020-06-28)

### Bug Fixes

- [#891](https://github.com/chakra-ui/chakra-ui/issues/891)
  ([e107acc](https://github.com/chakra-ui/chakra-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- ts issue with sx prop
  ([d3b1340](https://github.com/chakra-ui/chakra-ui/commit/d3b1340cb255937927b4d4c56ce218141570b951))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.2 (2020-06-21)

### Bug Fixes

- [#891](https://github.com/chakra-ui/chakra-ui/issues/891)
  ([e107acc](https://github.com/chakra-ui/chakra-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
