import { AwesomeQR } from "@qrcode-js/core";
export { AwesomeQR };
export declare function QRCodeBrowser(canvas: HTMLCanvasElement): AwesomeQR<HTMLCanvasElement>;
