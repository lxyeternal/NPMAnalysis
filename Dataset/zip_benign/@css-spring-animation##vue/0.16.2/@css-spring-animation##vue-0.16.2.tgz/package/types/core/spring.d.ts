import { Expression } from './math';
export interface Spring {
    expression: (data: {
        from: number;
        to: number;
        initialVelocity: number;
    }) => Expression;
    bounce: (data: {
        from: number;
        to: number;
        initialVelocity: number;
    }) => Expression;
    decay: (data: {
        from: number;
        to: number;
        initialVelocity: number;
    }) => Expression;
    velocity: (data: {
        time: number;
        from: number;
        to: number;
        initialVelocity: number;
    }) => number;
    settlingDuration: (data: {
        from: number;
        to: number;
    }) => number;
}
export declare function springStyle(spring: Spring, data: {
    from: number;
    to: number;
    initialVelocity: number;
}): string;
export declare function springValue(spring: Spring, data: {
    time: number;
    from: number;
    to: number;
    initialVelocity: number;
}): number;
export declare function springBounceValue(spring: Spring, data: {
    time: number;
    from: number;
    to: number;
    initialVelocity: number;
}): number;
export declare function springDecayValue(spring: Spring, data: {
    time: number;
    from: number;
    to: number;
    initialVelocity: number;
}): number;
export declare function springVelocity(spring: Spring, data: {
    time: number;
    from: number;
    to: number;
    initialVelocity: number;
}): number;
export declare function springSettlingDuration(spring: Spring, data: {
    from: number;
    to: number;
}): number;
/**
 * https://developer.apple.com/videos/play/wwdc2023/10158/
 */
export declare function createSpring(data: {
    bounce: number;
    duration: number;
}): Spring;
