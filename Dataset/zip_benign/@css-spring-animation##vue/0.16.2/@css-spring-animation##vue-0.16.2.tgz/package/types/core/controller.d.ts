import { AnimateContext, AnimateValue, SpringOptions } from './animate';
export interface SetStyleOptions<StyleKey extends keyof any> {
    animate?: boolean;
    velocity?: Record<StyleKey, number[]>;
}
export interface StopOptions {
    keepVelocity?: boolean;
}
export interface AnimationController<Style extends Record<string, AnimateValue>> {
    realValue: Record<keyof Style, number[]>;
    realVelocity: Record<keyof Style, number[]>;
    setStyle: (style: Style, options?: SetStyleOptions<keyof Style>) => AnimateContext<Record<keyof Style, number[]>>;
    setOptions: (options: SpringOptions) => void;
    stop: (options?: StopOptions) => void;
    onFinishCurrent: (fn: (data: {
        stopped: boolean;
    }) => void) => void;
    onSettleCurrent: (fn: (data: {
        stopped: boolean;
    }) => void) => void;
}
export declare function createAnimateController<Style extends Record<string, AnimateValue>>(set: (style: Record<string, string>) => void): AnimationController<Style>;
export declare function isSameStyle<Style extends Record<string, AnimateValue>>(a: Style, b: Style): boolean;
