export interface ParsedStyleTemplate {
    units: string[];
    wraps: string[];
}
export interface ParsedStyleValue extends ParsedStyleTemplate {
    values: number[];
}
export declare function parseStyleValue(value: string): ParsedStyleValue;
/**
 * If `target` has a value of 0 without unit, the unit is completed with the unit of the same position in `context`.
 */
export declare function completeParsedStyleUnit(target: ParsedStyleValue, context: ParsedStyleTemplate): ParsedStyleValue;
export declare function interpolateParsedStyle(template: ParsedStyleTemplate, values: (string | number)[]): string;
