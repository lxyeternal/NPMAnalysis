export type Expression = Value | Variable | Cosine | BinaryOperation | Exponential;
interface Value {
    type: 'value';
    value: number;
}
interface Variable {
    type: 'variable';
    name: string;
}
interface Cosine {
    type: 'cosine';
    radian: Expression;
}
interface BinaryOperation {
    type: 'binary';
    left: Expression;
    right: Expression;
    operator: '+' | '*';
}
interface Exponential {
    type: 'exponential';
    exponent: Expression;
}
export declare function v(value: number): Value;
export declare function var_(name: string): Variable;
export declare function cos(radian: Expression): Cosine;
export declare function add(left: Expression, right: Expression): BinaryOperation;
export declare function mul(left: Expression, right: Expression): BinaryOperation;
export declare function exp(exponent: Expression): Exponential;
export declare function generateCSSValue(expression: Expression): string;
export declare function calculate(expression: Expression, variables?: Record<string, number>): number;
export {};
