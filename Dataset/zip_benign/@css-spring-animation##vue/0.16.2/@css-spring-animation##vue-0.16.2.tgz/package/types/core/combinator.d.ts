export type Result<T> = Parsed<T> | Failed;
interface Parsed<T> {
    ok: true;
    value: T;
    rest: string;
}
interface Failed {
    ok: false;
}
export type Parser<T> = (value: string) => Result<T>;
export declare function regexp(regexp: RegExp): Parser<string>;
export declare function or<T>(...parsers: Parser<T>[]): Parser<T>;
export declare function map<T, U>(parser: Parser<T>, fn: (value: T) => U): Parser<U>;
export declare function seq<T>(...parsers: Parser<T>[]): Parser<T[]>;
export declare function many<T>(parser: Parser<T>): Parser<T[]>;
export declare function some<T>(parser: Parser<T>): Parser<T[]>;
export declare function optional(parser: Parser<string>): Parser<string>;
export declare function join(parser: Parser<string[]>): Parser<string>;
export declare function string(str: string): Parser<string>;
export declare const anyChar: Parser<string>;
export declare const integer: Parser<string>;
export declare const float: Parser<string>;
export declare const number: Parser<string>;
export declare const hexColor: Parser<string[]>;
export {};
