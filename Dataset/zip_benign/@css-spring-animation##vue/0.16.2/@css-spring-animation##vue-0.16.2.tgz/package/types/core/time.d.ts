export declare const t = "--css-spring-animation-time";
export declare function registerPropertyIfNeeded(): void;
export declare function wait(duration: number, forceResolve?: {
    fn: (() => void)[];
}): Promise<void>;
