import { ParsedStyleValue } from './style';
export type AnimateValue = number | string | ParsedStyleValue;
export interface SpringOptions {
    duration?: number;
    bounce?: number;
}
export interface AnimateOptions<Velocity extends Record<string, number[]>> extends SpringOptions {
    velocity?: Partial<Velocity>;
}
export interface AnimateContext<Values extends Record<string, number[]>> {
    realValue: Values;
    realVelocity: Values;
    finished: boolean;
    settled: boolean;
    finishingPromise: Promise<void>;
    settlingPromise: Promise<void>;
    stop: () => void;
    stoppedDuration: number | undefined;
}
export declare function animate<T extends Record<string, [AnimateValue, AnimateValue]>>(fromTo: T, set: (style: Record<string, string>) => void, options?: AnimateOptions<Record<keyof T, number[]>>): AnimateContext<Record<keyof T, number[]>>;
