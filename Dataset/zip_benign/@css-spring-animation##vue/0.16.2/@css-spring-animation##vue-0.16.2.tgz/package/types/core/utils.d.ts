export declare function mapValues<T, U>(object: T, fn: (value: T[keyof T], key: keyof T) => U): {
    [K in keyof T]: U;
};
export declare function zip<T>(a: readonly T[], b: readonly T[]): [T, T][];
export declare function range(start: number, end: number): number[];
export declare function isCssLinearTimingFunctionSupported(): boolean;
export declare function isCssMathAnimationSupported(): boolean;
export declare function forceReflow(): void;
