import { PropType } from 'vue';
import { AnimateValue, AnimationController } from '../core';
export declare const scKey: unique symbol;
export declare function createStyleSetter(el: HTMLElement): (style: Record<string, string>) => void;
export declare function useTransitionHooks(props: Omit<SpringTransitionProps, 'mode'>, emit: (name: string, el: Element) => void): {
    onBeforeEnter: (el: Element) => void;
    onEnter: (_el: Element, done: () => void) => void;
    onAfterEnter: (el: Element) => void;
    onEnterCancelled: (el: Element) => void;
    onBeforeLeave: (el: Element) => void;
    onLeave: (_el: Element, done: () => void) => void;
    onAfterLeave: (_el: Element) => void;
    onLeaveCancelled: (el: Element) => void;
};
export interface SpringTransitionProps {
    springStyle: Record<string, AnimateValue>;
    enterFrom?: Record<string, AnimateValue>;
    leaveTo?: Record<string, AnimateValue>;
    bounce?: number | {
        enter?: number;
        leave?: number;
    };
    duration?: number | {
        enter?: number;
        leave?: number;
    };
    name?: string;
    mode?: 'in-out' | 'out-in' | 'default';
    enterFromClass?: string;
    enterActiveClass?: string;
    enterToClass?: string;
    leaveFromClass?: string;
    leaveActiveClass?: string;
    leaveToClass?: string;
    onBeforeEnter?: (el: Element) => void;
    onAfterEnter?: (el: Element) => void;
    onEnterCancelled?: (el: Element) => void;
    onBeforeLeave?: (el: Element) => void;
    onAfterLeave?: (el: Element) => void;
    onLeaveCancelled?: (el: Element) => void;
}
export interface HTMLElementWithController extends HTMLElement {
    [scKey]?: AnimationController<Record<string, AnimateValue>>;
}
export declare const springTransitionProps: {
    readonly springStyle: {
        readonly type: PropType<Record<string, AnimateValue>>;
        readonly required: true;
    };
    readonly enterFrom: PropType<Record<string, AnimateValue>>;
    readonly leaveTo: PropType<Record<string, AnimateValue>>;
    readonly bounce: PropType<number | {
        enter: number;
        leave: number;
    }>;
    readonly duration: PropType<number | {
        enter: number;
        leave: number;
    }>;
};
declare const _default: {
    new (): {
        $props: SpringTransitionProps;
    };
};
export default _default;
