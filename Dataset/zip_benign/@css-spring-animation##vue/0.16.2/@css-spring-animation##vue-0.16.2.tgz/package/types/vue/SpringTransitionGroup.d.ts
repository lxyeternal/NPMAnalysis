import { SpringTransitionProps } from './SpringTransition.ts';
interface SpringTransitionGroupProps extends Omit<SpringTransitionProps, 'mode'> {
    tag?: string;
    bounce?: number | {
        move?: number;
        enter?: number;
        leave?: number;
    };
    duration?: number | {
        move?: number;
        enter?: number;
        leave?: number;
    };
}
declare const _default: {
    new (): {
        $props: SpringTransitionGroupProps;
    };
};
export default _default;
