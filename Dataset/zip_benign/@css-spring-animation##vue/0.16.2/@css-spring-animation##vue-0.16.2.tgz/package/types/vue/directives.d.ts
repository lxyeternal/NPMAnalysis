import { App } from 'vue';
declare function install(app: App): void;
export declare const springDirectives: {
    install: typeof install;
};
export {};
