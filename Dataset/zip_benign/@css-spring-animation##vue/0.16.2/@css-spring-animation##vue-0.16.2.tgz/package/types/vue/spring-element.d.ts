import { PropType } from 'vue';
import { AnimateValue } from '../core';
export declare const spring: Record<string, import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    springStyle: {
        type: PropType<Record<string, AnimateValue>>;
        required: true;
    };
    bounce: NumberConstructor;
    duration: NumberConstructor;
    disabled: BooleanConstructor;
    relocating: BooleanConstructor;
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    springStyle: {
        type: PropType<Record<string, AnimateValue>>;
        required: true;
    };
    bounce: NumberConstructor;
    duration: NumberConstructor;
    disabled: BooleanConstructor;
    relocating: BooleanConstructor;
}>> & Readonly<{}>, {
    disabled: boolean;
    relocating: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
