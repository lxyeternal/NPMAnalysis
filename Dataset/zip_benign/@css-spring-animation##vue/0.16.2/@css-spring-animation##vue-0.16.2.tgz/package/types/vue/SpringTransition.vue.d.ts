import { AnimateValue } from '../core';
export interface SpringTransitionProps {
    springStyle: Record<string, AnimateValue>;
    enterFrom?: Record<string, AnimateValue>;
    leaveTo?: Record<string, AnimateValue>;
    bounce?: number;
    duration?: number;
}
declare const _default: __VLS_WithTemplateSlots<import("vue").DefineComponent<__VLS_WithDefaults<__VLS_TypePropsToRuntimeProps<SpringTransitionProps>, {
    duration: number;
}>, {}, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    beforeEnter: (el: Element) => void;
    afterEnter: (el: Element) => void;
    enterCancelled: (el: Element) => void;
    beforeLeave: (el: Element) => void;
    afterLeave: (el: Element) => void;
    leaveCancelled: (el: Element) => void;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<__VLS_WithDefaults<__VLS_TypePropsToRuntimeProps<SpringTransitionProps>, {
    duration: number;
}>>> & {
    onBeforeEnter?: ((el: Element) => any) | undefined;
    onAfterEnter?: ((el: Element) => any) | undefined;
    onEnterCancelled?: ((el: Element) => any) | undefined;
    onBeforeLeave?: ((el: Element) => any) | undefined;
    onAfterLeave?: ((el: Element) => any) | undefined;
    onLeaveCancelled?: ((el: Element) => any) | undefined;
}, {
    duration: number;
}, {}>, {
    default?(_: {}): any;
}>;
export default _default;
type __VLS_NonUndefinedable<T> = T extends undefined ? never : T;
type __VLS_TypePropsToRuntimeProps<T> = {
    [K in keyof T]-?: {} extends Pick<T, K> ? {
        type: import('vue').PropType<__VLS_NonUndefinedable<T[K]>>;
    } : {
        type: import('vue').PropType<T[K]>;
        required: true;
    };
};
type __VLS_WithDefaults<P, D> = {
    [K in keyof Pick<P, keyof P>]: K extends keyof D ? __VLS_Prettify<P[K] & {
        default: D[K];
    }> : P[K];
};
type __VLS_Prettify<T> = {
    [K in keyof T]: T[K];
} & {};
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
