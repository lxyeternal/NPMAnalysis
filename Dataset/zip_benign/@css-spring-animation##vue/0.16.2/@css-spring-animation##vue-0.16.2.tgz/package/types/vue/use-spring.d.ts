import { DeepReadonly, MaybeRefOrGetter, Ref } from 'vue';
import { AnimateValue, SpringOptions } from '../core';
type RefOrGetter<T> = Ref<T> | (() => T);
export interface UseSpringOptions extends SpringOptions {
    disabled?: boolean;
    relocating?: boolean;
}
type SpringStyleRef = Readonly<Ref<Record<string, string>>>;
export interface UseSpringResult<Values extends Record<string, number[]>> {
    style: SpringStyleRef;
    realValue: DeepReadonly<Ref<Values>>;
    realVelocity: DeepReadonly<Ref<Values>>;
    onFinishCurrent: (fn: (data: {
        stopped: boolean;
    }) => void) => void;
    onSettleCurrent: (fn: (data: {
        stopped: boolean;
    }) => void) => void;
}
export declare function useSpring<Style extends Record<string, AnimateValue>>(styleMapper: RefOrGetter<Style>, options?: MaybeRefOrGetter<UseSpringOptions>): UseSpringResult<Record<keyof Style, number[]>>;
export {};
