#
# * grunt-wxi-shell
# * https://github.com/aponxi/grunt-wxi-shell
# *
# * Copyright (c) 2013 Logan Howlett
# * Licensed under the MIT license.
# 
# utilxi
_ = require "underscore"
exi = require "execxi"

"use strict"
module.exports = (grunt) ->


  grunt.registerMultiTask "wxi_shell", "Run an array of commands in terminal.", ->
    options = @data.options

    commands = @data.commands

    if _.has options, "cwd"
      cwd = options.cwd
      console.log cwd
      _.each commands, (v,k,l)->
        commands[k] = "cd #{cwd} && #{v}"
    res = exi.executeArray commands, options


    if res[0] is true then grunt.log.ok()
    else grunt.log.error()
    
      