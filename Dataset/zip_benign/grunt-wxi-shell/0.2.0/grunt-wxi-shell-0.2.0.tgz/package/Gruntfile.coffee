#
# * grunt-wxi-shell
# * https://github.com/aponxi/grunt-wxi-shell
# *
# * Copyright (c) 2013 Logan Howlett
# * Licensed under the MIT license.
# 
"use strict"
module.exports = (grunt) ->
  
  # Project configuration.
  grunt.initConfig    

    # Configuration to be run (and then tested).
    wxi_shell:
      make:
        options: 
          cwd: 'components/bootstrap'
          returnOutput: on
          chained: on
          exitSuccess: [0,2]
        commands:
          [
            "make"
          ,
            "make bootstrap"
          ]
      clean:
        options: 
          cwd: 'components/bootstrap'
          returnOutput: on
          chained: on
          exitSuccess: [0, 2]
        commands:
          [
            "make clean"
          ]
  
  # Actually load this plugin's task(s).
  grunt.loadTasks "tasks"
  
  # plugin's task(s), then test the result.

  grunt.registerTask "clean", ["wxi_shell:clean"]
  grunt.registerTask "test", ["clean", "wxi_shell:make"]
  # By default
  grunt.registerTask "default", ["test"]