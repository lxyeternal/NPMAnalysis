export type Procedure = (...args: any[]) => void;

export function debounce<F extends Procedure>(func: F): F {
    let isRunning = false;
    return function(...args: unknown[]) {
        if (!isRunning) {
            isRunning = true;
            func(...args);            
            isRunning = false;
        }
    } as any;
}
