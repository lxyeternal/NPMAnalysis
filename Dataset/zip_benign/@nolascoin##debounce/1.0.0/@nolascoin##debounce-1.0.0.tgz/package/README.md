# About

A debounce system is a set of code that keeps a function from running too many times. It comes from the idea of mechanical switch bounce, where a switch bounces when pushed, creating multiple signals. In the context of Roblox, this problem occurs mainly with the BasePart.Touched event, when a part touches another multiple times in a short space of time, but may be useful in other cases as well.

Source: https://developer.roblox.com/en-us/articles/Debounce

Example
```
CollectionService.GetTagged("trigger").forEach(part => {
    if (part.IsA("BasePart")) {
        part.Touched.Connect(debounce(otherPart => {
            const character = otherPart.Parent;
            if (character && character.IsA("Model") && character.FindFirstChild('Humanoid')) {       
                const targetPoint = (character.WaitForChild('HumanoidRootPart') as Part).Position;
                if (!targetPoint) {
                    return;
                }
                wait(0.5);
            }
        }));
    }
});
```
