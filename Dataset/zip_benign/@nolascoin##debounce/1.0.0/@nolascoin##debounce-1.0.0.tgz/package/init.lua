-- Compiled with https://roblox-ts.github.io v0.2.14
-- October 8, 2019, 12:41 AM Eastern Daylight Time

local exports = {};
local function debounce(func)
	local isRunning = false;
	return function(...)
		local args = { ... };
		if not isRunning then
			isRunning = true;
			func(unpack(args));
			isRunning = false;
		end;
	end;
end;
exports.debounce = debounce;
return exports;
