import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPInputComponent } from "./BPInputComponent";
export declare class BPToggleInputComponent extends BPInputComponent<boolean> {
    constructor(props: BPComponentProps<boolean>, context: UiConfigRendererContextType);
    private _onChange;
    renderInput(): import("react/jsx-runtime").JSX.Element;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
