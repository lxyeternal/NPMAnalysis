import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPInputComponent } from "./BPInputComponent";
import { BPValueComponentState } from "./BPValueComponent";
export declare class BPNumberInputComponent extends BPInputComponent<number> {
    constructor(props: BPComponentProps<number>, context: UiConfigRendererContextType);
    private _inputs;
    refreshConfigState(state?: BPValueComponentState<number>): Promise<void>;
    private _onChange;
    renderInput(): import("react/jsx-runtime").JSX.Element;
}
