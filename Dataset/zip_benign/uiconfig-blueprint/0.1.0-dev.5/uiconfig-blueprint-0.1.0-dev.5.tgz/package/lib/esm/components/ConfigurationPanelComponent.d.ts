import { UiObjectConfig } from 'uiconfig.js';
export declare function ConfigurationPanelComponent({ config }: {
    config: UiObjectConfig<any, 'panel'>;
}): import("react/jsx-runtime").JSX.Element;
