import { UiConfigRendererBlueprint } from "./UiConfigRendererBlueprint";
declare class UI extends UiConfigRendererBlueprint {
}
export { UiConfigRendererBlueprint, UI };
