import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPValueComponent, BPValueComponentState } from "./BPValueComponent";
import type { ColorRepresentation } from "three";
export type BPColorComponentState = BPValueComponentState<string> & {
    mode: 'number' | 'string' | 'Color';
    lastValue?: ColorRepresentation;
    srgbConvert: boolean;
};
export declare class BPColorInputComponent extends BPValueComponent<ColorRepresentation, BPColorComponentState, string> {
    private _inputRef;
    private _tempColor;
    constructor(props: BPComponentProps<ColorRepresentation>, context: UiConfigRendererContextType);
    convertValueToState(val: ColorRepresentation, state: BPColorComponentState): BPColorComponentState;
    convertStateToValue(state: BPColorComponentState): Promise<ColorRepresentation>;
    forceOnChange: boolean;
    doesNeedRefresh(state: BPColorComponentState, _?: boolean): boolean;
    private _mouseButtons;
    componentDidMount(): void;
    private _mouseMove;
    componentWillUnmount(): void;
    private _hasMouseUp;
    private _mouseUp;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
