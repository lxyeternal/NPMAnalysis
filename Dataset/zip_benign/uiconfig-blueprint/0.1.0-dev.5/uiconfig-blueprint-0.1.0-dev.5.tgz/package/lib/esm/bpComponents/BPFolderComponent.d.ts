import React, { ChangeEventHandler, DOMAttributes } from "react";
import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { PanelActions } from "@blueprintjs/core/lib/esm/components/panel-stack2/panelTypes";
import { BPContainerComponent, BPContainerComponentState } from './BPContainerComponent';
export type BPFolderComponentState = BPContainerComponentState & {};
export declare class BPFolderComponent extends BPContainerComponent<BPFolderComponentState> {
    constructor(props: BPComponentProps<void> & PanelActions, context: UiConfigRendererContextType);
    render(): import("react/jsx-runtime").JSX.Element | null;
}
export declare const FolderHeadCard: React.FC<React.PropsWithChildren<{
    open: boolean;
    label: string;
    minimal: boolean;
    level: number;
    disabled?: boolean;
    enabled?: boolean;
    onEnabledChange?: ChangeEventHandler<HTMLInputElement>;
    onClick: DOMAttributes<HTMLElement>['onClick'];
}>>;
