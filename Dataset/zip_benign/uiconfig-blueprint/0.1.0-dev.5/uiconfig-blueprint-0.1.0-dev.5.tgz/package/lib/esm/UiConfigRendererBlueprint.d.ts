import { JSUndoManager } from "ts-browser-helpers";
import { UiConfigRenderer, UiObjectConfig } from "uiconfig.js";
import { Root } from 'react-dom/client';
import { THREE } from "./threejs";
export declare class UiConfigRendererBlueprint extends UiConfigRenderer {
    constructor(container?: HTMLElement, { autoPostFrame }?: {
        autoPostFrame?: boolean | undefined;
    }, undoManager?: JSUndoManager | false);
    protected _root: Root;
    protected _createUiContainer(): HTMLDivElement;
    protected _refreshUiConfigObject(config: UiObjectConfig): void;
    renderUiConfig(_: UiObjectConfig): void;
    THREE: THREE | undefined;
    unmount(): void;
}
