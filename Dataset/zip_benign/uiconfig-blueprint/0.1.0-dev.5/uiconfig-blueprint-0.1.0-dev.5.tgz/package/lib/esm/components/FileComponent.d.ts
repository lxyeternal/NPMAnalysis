import React from "react";
import { BPFileComponentState } from "../bpComponents/BPFileComponent";
export interface FileComponentProps {
    state: BPFileComponentState;
    onChange: (state: Partial<BPFileComponentState>) => Promise<void>;
    previewSlot?: React.ReactNode;
    uuid?: string;
}
export declare const FileComponent: React.FC<FileComponentProps>;
