import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import React from "react";
import { BPLabelledComponent, BPLabelledComponentState } from "./BPLabelledComponent";
export declare class BPButtonComponent extends BPLabelledComponent<() => void, BPLabelledComponentState> {
    constructor(props: BPComponentProps<() => void>, context: UiConfigRendererContextType);
    onClick: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
