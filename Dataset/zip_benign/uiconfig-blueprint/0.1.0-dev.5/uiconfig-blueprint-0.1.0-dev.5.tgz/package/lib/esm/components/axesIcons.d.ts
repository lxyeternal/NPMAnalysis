export declare const axesXYZIcon: import("react/jsx-runtime").JSX.Element;
export declare const axesCubeIcon: import("react/jsx-runtime").JSX.Element;
export declare const axesTetrahedronIcon: import("react/jsx-runtime").JSX.Element;
export declare const axesSphereIcon: import("react/jsx-runtime").JSX.Element;
export declare const axesCubeFilledIcon: import("react/jsx-runtime").JSX.Element;
export declare const axesTetrahedronFilledIcon: import("react/jsx-runtime").JSX.Element;
export declare const axesSphereFilledIcon: import("react/jsx-runtime").JSX.Element;
