import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPInputComponent } from "./BPInputComponent";
import { BPValueComponentState } from "./BPValueComponent";
export interface DropdownItem {
    label: string;
    value: string | number;
}
export type BPDropdownComponentState = BPValueComponentState<string | number> & {
    options: DropdownItem[];
};
export declare class BPDropdownInputComponent extends BPInputComponent<string | number, BPDropdownComponentState> {
    constructor(props: BPComponentProps<string | number>, context: UiConfigRendererContextType);
    getUpdatedState(state: BPDropdownComponentState): BPDropdownComponentState;
    renderInput(): import("react/jsx-runtime").JSX.Element;
}
