import * as React from "react";
import { IconName, MaybeElement } from "@blueprintjs/core";
export declare class DraggableIcon extends React.Component<{
    icon: IconName | MaybeElement;
    size?: number;
    value: number;
    stepSize?: number;
    small?: boolean;
    disabled?: boolean;
    onChange: (v: number, last?: boolean) => void;
}> {
    private cursor;
    private dragStartOffset;
    private dragStartValue;
    private lastValue;
    private removeEvents;
    private mouseUpEvent;
    private mouseMoveEvent;
    render(): import("react/jsx-runtime").JSX.Element;
}
