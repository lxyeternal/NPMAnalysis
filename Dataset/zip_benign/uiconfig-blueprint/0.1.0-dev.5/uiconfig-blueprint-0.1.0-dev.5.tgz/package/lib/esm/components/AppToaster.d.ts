import { Toaster } from "@blueprintjs/core";
export declare const AppToasterRef: {
    ref: Toaster | null;
};
export declare const AppToaster: () => Toaster;
export declare function AppToasterOverlay(): import("react/jsx-runtime").JSX.Element;
