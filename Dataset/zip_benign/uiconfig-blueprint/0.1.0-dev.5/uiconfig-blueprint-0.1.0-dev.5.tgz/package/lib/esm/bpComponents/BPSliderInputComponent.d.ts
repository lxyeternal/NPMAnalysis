import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPInputComponent } from "./BPInputComponent";
import { BPValueComponentState } from "./BPValueComponent";
export type BPSliderComponentState = BPValueComponentState<number> & {
    min: number;
    max: number;
    step: number;
};
export declare class BPSliderInputComponent extends BPInputComponent<number, BPSliderComponentState> {
    constructor(props: BPComponentProps<number>, context: UiConfigRendererContextType);
    getUpdatedState(state: BPSliderComponentState): BPSliderComponentState;
    flexBasis: string;
    renderInput(): import("react/jsx-runtime").JSX.Element[];
}
