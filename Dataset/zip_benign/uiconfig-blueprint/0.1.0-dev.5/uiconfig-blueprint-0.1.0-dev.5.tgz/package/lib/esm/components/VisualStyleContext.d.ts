import React from 'react';
export declare const defaultVisualStyle: {
    darkMode: boolean;
    setDarkMode: (_: boolean) => void;
    themes: {
        'bpx-default': {
            label: string;
            link: string;
        };
        'bpx-bpv3': {
            label: string;
            link: string;
        };
        'bpx-flat': {
            label: string;
            link: string;
        };
        'bpx-carbon': {
            label: string;
            link: string;
        };
        'bpx-antd': {
            label: string;
            link: string;
        };
        'bpx-fluent': {
            label: string;
            link: string;
        };
        'bpx-pnnl': {
            label: string;
            link: string;
        };
    };
    theme: string;
    setTheme: (_: string) => void;
};
export declare const VisualStyleContext: React.Context<{
    darkMode: boolean;
    setDarkMode: (_: boolean) => void;
    themes: {
        'bpx-default': {
            label: string;
            link: string;
        };
        'bpx-bpv3': {
            label: string;
            link: string;
        };
        'bpx-flat': {
            label: string;
            link: string;
        };
        'bpx-carbon': {
            label: string;
            link: string;
        };
        'bpx-antd': {
            label: string;
            link: string;
        };
        'bpx-fluent': {
            label: string;
            link: string;
        };
        'bpx-pnnl': {
            label: string;
            link: string;
        };
    };
    theme: string;
    setTheme: (_: string) => void;
}>;
export declare const useVisualStyle: () => {
    darkMode: boolean;
    setDarkMode: (_: boolean) => void;
    themes: {
        'bpx-default': {
            label: string;
            link: string;
        };
        'bpx-bpv3': {
            label: string;
            link: string;
        };
        'bpx-flat': {
            label: string;
            link: string;
        };
        'bpx-carbon': {
            label: string;
            link: string;
        };
        'bpx-antd': {
            label: string;
            link: string;
        };
        'bpx-fluent': {
            label: string;
            link: string;
        };
        'bpx-pnnl': {
            label: string;
            link: string;
        };
    };
    theme: string;
    setTheme: (_: string) => void;
};
export declare function setupVisualStyle(): {
    darkMode: boolean;
    setDarkMode: React.Dispatch<React.SetStateAction<boolean>>;
    theme: string;
    setTheme: React.Dispatch<React.SetStateAction<string>>;
};
export declare function VisualStyleProvider({ children }: {
    children: React.ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function ThemeSettingsMenuComponent(): import("react/jsx-runtime").JSX.Element;
