import { BPComponent, BPComponentProps, BPComponentState, UiConfigRendererContextType } from "./BPComponent";
export type BPLabelledComponentState = BPComponentState & {
    label: string;
};
export declare abstract class BPLabelledComponent<TValue, TState, TProps extends BPComponentProps<TValue> = BPComponentProps<TValue>> extends BPComponent<TValue, TState & BPLabelledComponentState, TProps> {
    protected constructor(props: TProps, context: UiConfigRendererContextType, state: TState);
    getUpdatedState(state: TState & BPLabelledComponentState): TState & BPLabelledComponentState;
}
