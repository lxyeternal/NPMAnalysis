import React from "react";
import type { UiConfigRendererBase } from 'uiconfig.js';
import { UiObjectConfig } from 'uiconfig.js';
import { THREE } from "../threejs";
export type BPComponentProps<T> = {
    config: UiObjectConfig<T>;
    level?: number;
};
export type BPComponentState = {
    hidden?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
};
export interface UiConfigRendererBaseBp extends UiConfigRendererBase {
    THREE: THREE | undefined;
}
export declare const UiConfigRendererContext: React.Context<UiConfigRendererBaseBp>;
export type UiConfigRendererContextType = React.ContextType<typeof UiConfigRendererContext>;
export declare abstract class BPComponent<TValue, TState extends BPComponentState, TProps extends BPComponentProps<TValue> = BPComponentProps<TValue>> extends React.Component<TProps, TState> {
    static contextType: React.Context<UiConfigRendererBaseBp>;
    context: UiConfigRendererContextType;
    protected constructor(props: TProps, context: UiConfigRendererContextType, state: TState);
    setStatePromise(state: TState): Promise<void>;
    keyVersion: number;
    getUpdatedState(state: TState): TState;
    private _refreshing;
    refreshConfigState(state?: TState): Promise<void>;
    componentDidMount(): void;
    componentWillUnmount(): void;
}
