import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPLabelledComponent, BPLabelledComponentState } from "./BPLabelledComponent";
import { PrimitiveVal } from "uiconfig.js";
export type BPValueComponentState<TStateValue> = BPLabelledComponentState & {
    value: TStateValue;
};
export declare abstract class BPValueComponent<TValue extends PrimitiveVal, TState extends BPValueComponentState<TStateValue>, TStateValue> extends BPLabelledComponent<TValue, TState> {
    protected constructor(props: BPComponentProps<TValue>, context: UiConfigRendererContextType, state: TState);
    abstract convertValueToState(value: TValue, state: TState): TState;
    abstract convertStateToValue(state: TState): Promise<TValue>;
    private _lastValRef;
    getUpdatedState(state: TState): TState;
    protected _previousLast: boolean;
    doesNeedRefresh(state: TState, _last?: boolean): boolean;
    setState(state: TState, callback?: () => void): void;
    setValue(value: TStateValue, last?: boolean): Promise<void>;
    forceOnChange: boolean;
    updateStateValue(state: TState, last?: boolean): Promise<void>;
}
