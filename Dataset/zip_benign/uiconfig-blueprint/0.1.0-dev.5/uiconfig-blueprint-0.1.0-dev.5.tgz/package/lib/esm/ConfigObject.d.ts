import React from "react";
import { Class, PartialRecord } from "ts-browser-helpers";
import { BPComponentProps, BPComponentState, UiConfigRendererContext } from "./bpComponents/BPComponent";
import { PanelActions } from "@blueprintjs/core/lib/esm/components/panel-stack2/panelTypes";
import { UiObjectConfig } from 'uiconfig.js';
export type UiConfigTypes = 'input' | 'button' | 'folder' | 'checkbox' | 'toggle' | 'dropdown' | 'slider' | 'color' | 'image' | 'number' | 'panel' | 'tree' | 'hierarchy' | 'vec' | 'vec2' | 'vec3' | 'vec4' | 'monitor';
export interface ConfigProps extends PanelActions {
    config: UiObjectConfig;
    isPanel?: boolean;
    level?: number;
}
export declare const ConfigObjectGenerators: PartialRecord<UiConfigTypes, Class<React.Component<BPComponentProps<any>, BPComponentState>>>;
export declare class ConfigObject extends React.Component<ConfigProps, {}> {
    static contextType: React.Context<import("./bpComponents/BPComponent").UiConfigRendererBaseBp>;
    context: React.ContextType<typeof UiConfigRendererContext>;
    state: {};
    render(): import("react/jsx-runtime").JSX.Element;
}
