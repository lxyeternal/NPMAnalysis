import { PropsWithChildren } from "react";
export declare function FormGroupComponent(props: PropsWithChildren<{
    label: string;
    flexBasis?: string;
    disabled?: boolean;
}>): import("react/jsx-runtime").JSX.Element;
