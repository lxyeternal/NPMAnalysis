/// <reference types="react" />
import { BPComponent, BPComponentProps, BPComponentState, UiConfigRendererContextType } from "./BPComponent";
import { TreeNodeInfo } from "@blueprintjs/core";
export type BPTreeComponentState<T = {}> = BPComponentState & {
    nodes: TreeNodeInfo<T>[];
};
type NodePath = (string | number)[];
export declare abstract class BPTreeComponent<T = {}, TConfigVal extends any = void> extends BPComponent<TConfigVal, BPTreeComponentState<T>> {
    constructor(props: BPComponentProps<TConfigVal>, context: UiConfigRendererContextType);
    protected _infoMap: Map<string | number, TreeNodeInfo<T>>;
    protected _createNodeInfo(id: string, obj: T): {
        id: string;
        label: string;
        nodeData: T;
        childNodes: never[];
        isExpanded: boolean;
        isSelected: boolean;
    };
    protected abstract _getNodeId(obj: T): string;
    protected abstract _updateNodeInfo(node: TreeNodeInfo<T>, obj: T): TreeNodeInfo<T>;
    protected abstract _getRootNodes(): T[];
    protected _onNodeClick(_id: string | number): Promise<void>;
    protected _onNodeDoubleClick(_id: string | number): Promise<void>;
    protected _cloneNodes(callback?: (t: TreeNodeInfo<T>) => void, state?: TreeNodeInfo<T>[]): TreeNodeInfo<T>[];
    protected _getNodePath(id: string, nodes?: TreeNodeInfo<T>[]): NodePath;
    protected _forEachNode<T>(nodes: TreeNodeInfo<T>[] | undefined, callback: (node: TreeNodeInfo<T>, path: NodePath) => void, path?: NodePath): TreeNodeInfo<T>[] | undefined;
    protected _onNodeExpandCollapse(_id: string | number, expanded?: boolean): Promise<void>;
    protected _onNodeContextMenu(_id: string | number): Promise<void>;
    protected buildData(data: TreeNodeInfo<T>[], obj: T, _?: any, _2?: any): TreeNodeInfo<T>[];
    getUpdatedState(_state: BPTreeComponentState<T>): BPTreeComponentState<T>;
    deselectAll(): Promise<void>;
    setSelected(id?: string, expand?: boolean): Promise<void>;
    componentDidMount(): void;
    componentWillUnmount(): void;
    findSelectedNode(nodes?: TreeNodeInfo<T>[]): TreeNodeInfo<T> | undefined;
    getFlatNodes(onlyVisible?: boolean, nodes?: TreeNodeInfo<T>[], res?: TreeNodeInfo<T>[]): TreeNodeInfo<T>[];
    protected _handleKeyDown(e: React.KeyboardEvent): void;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
export {};
