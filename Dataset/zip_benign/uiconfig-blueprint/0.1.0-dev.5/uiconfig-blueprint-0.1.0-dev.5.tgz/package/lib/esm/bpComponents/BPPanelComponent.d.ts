import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPLabelledComponentState } from "./BPLabelledComponent";
import { PanelActions } from "@blueprintjs/core/lib/esm/components/panel-stack2/panelTypes";
import { UiObjectConfig } from 'uiconfig.js';
import { BPContainerComponent } from './BPContainerComponent';
export type BPPanelComponentState = BPLabelledComponentState & {
    children: UiObjectConfig[];
    expanded: boolean;
};
export declare class BPPanelComponent extends BPContainerComponent<BPPanelComponentState> {
    constructor(props: BPComponentProps<void> & PanelActions, context: UiConfigRendererContextType);
    setExpanded: (e: boolean) => void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
