import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPInputComponent } from "./BPInputComponent";
import { BPValueComponentState } from "./BPValueComponent";
import type { Vector2, Vector3, Vector4 } from "three";
export type BPVectorComponentState = BPValueComponentState<Vector2 | Vector3 | Vector4> & {
    min: number;
    max: number;
    step: number;
    components: 1 | 2 | 3 | 4;
};
export declare class BPVectorInputComponent extends BPInputComponent<Vector2 | Vector3 | Vector4, BPVectorComponentState> {
    constructor(props: BPComponentProps<Vector2 | Vector3 | Vector4>, context: UiConfigRendererContextType);
    forceOnChange: boolean;
    doesNeedRefresh(_: BPVectorComponentState): boolean;
    getUpdatedState(state: BPVectorComponentState): BPVectorComponentState;
    private _inputs;
    refreshConfigState(state?: BPVectorComponentState): Promise<void>;
    renderInput(): import("react/jsx-runtime").JSX.Element | import("react/jsx-runtime").JSX.Element[];
}
