import { Dispatch, ReactNode, SetStateAction } from 'react';
export type DialogStateType = {
    isOpen: boolean;
    title: string;
    content: ReactNode;
    actions: ReactNode;
    state: any;
    canClose: boolean;
};
export declare const defaultDialogContext: {
    isOpen: boolean;
    title: string;
    content: ReactNode;
    actions: ReactNode;
    state: any;
    canClose: boolean;
};
export declare function setupDialog(): {
    dialog: DialogStateType;
    open: (d: Partial<DialogStateType>) => void;
    close: () => void;
    setDialog: Dispatch<SetStateAction<DialogStateType>>;
    state: any;
    setState: (state: any) => void;
};
export declare const DialogContext: import("react").Context<{
    dialog: DialogStateType;
    open: (d: Partial<DialogStateType>) => void;
    close: () => void;
    setDialog: Dispatch<SetStateAction<DialogStateType>>;
    setState: Dispatch<SetStateAction<any>>;
    state: any;
}>;
export declare const useDialog: () => {
    dialog: DialogStateType;
    open: (d: Partial<DialogStateType>) => void;
    close: () => void;
    setDialog: Dispatch<SetStateAction<DialogStateType>>;
    setState: Dispatch<SetStateAction<any>>;
    state: any;
};
export declare function DialogProvider({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function DialogComponent(): import("react/jsx-runtime").JSX.Element;
interface DialogPromptProps extends Partial<DialogStateType> {
    closeButtonText?: string;
    submitButtonText?: string;
    message?: string;
    placeholder?: string;
    value?: string;
    showInput?: boolean;
    onClose?: (value: string) => boolean | undefined | Promise<boolean | undefined>;
    onSubmit?: (value: string) => boolean | undefined | any | Promise<boolean | undefined | any>;
}
export declare function useDialogPrompt(): {
    prompt: ({ closeButtonText, submitButtonText, message, placeholder, value, showInput, onClose, onSubmit, ...props }: DialogPromptProps) => Promise<string | null>;
    close: () => void;
};
export {};
