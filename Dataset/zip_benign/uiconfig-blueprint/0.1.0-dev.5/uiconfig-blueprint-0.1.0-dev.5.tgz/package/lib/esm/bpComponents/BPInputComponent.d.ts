import { BPValueComponent, BPValueComponentState } from "./BPValueComponent";
import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { ReactNode } from "react";
import { PrimitiveVal } from "uiconfig.js";
export declare abstract class BPInputComponent<TStateValue extends PrimitiveVal, TState extends BPValueComponentState<TStateValue> = BPValueComponentState<TStateValue>> extends BPValueComponent<TStateValue, TState, TStateValue> {
    protected constructor(props: BPComponentProps<TStateValue>, context: UiConfigRendererContextType, state: TState);
    convertValueToState(value: TStateValue, state: TState): TState;
    convertStateToValue(state: TState): Promise<TStateValue>;
    abstract renderInput(): ReactNode;
    protected flexBasis: string;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
