export declare function useLoadingState(): {
    loadingState: Record<string, boolean>;
    updateLoading: (key: string, promise?: void | Promise<any> | undefined) => Promise<void>;
};
export declare function useLoadingStateKey(): {
    loadingState: boolean;
    updateLoading: (promise?: void | Promise<any> | undefined) => Promise<void>;
};
