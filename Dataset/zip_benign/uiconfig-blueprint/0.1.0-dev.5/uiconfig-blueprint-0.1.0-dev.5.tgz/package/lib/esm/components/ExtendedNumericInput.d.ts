import React from "react";
import type { HTMLInputProps, NumericInputProps } from "@blueprintjs/core";
export interface IExtendedNumericInputState {
    value?: string;
}
export declare class ExtendedNumericInput extends React.PureComponent<HTMLInputProps & NumericInputProps & {
    onChange2: (v: number, last?: boolean) => void;
}, IExtendedNumericInputState> {
    state: IExtendedNumericInputState;
    setValue(val?: number): Promise<void>;
    render(): import("react/jsx-runtime").JSX.Element;
    private handleBlur;
    private _lastChangedValue;
    private handleKeyDown;
    private handleValueChange;
    private handleButtonClick;
    private handleConfirm;
    private expandScientificNotationTerms;
    private expandNumberAbbreviationTerms;
    private evaluateSimpleMathExpression;
    private nanStringToEmptyString;
    private expandAbbreviatedNumber;
    private expandScientificNotationNumber;
    private roundValue;
}
