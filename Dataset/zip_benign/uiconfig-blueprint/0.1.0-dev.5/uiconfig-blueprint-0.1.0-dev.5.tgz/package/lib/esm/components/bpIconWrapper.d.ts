import { HTMLAttributes, ReactNode } from "react";
export declare const bpIconWrapper: (path: ReactNode, viewbox?: number, svgProps?: HTMLAttributes<SVGElement>) => import("react/jsx-runtime").JSX.Element;
