import { BPLabelledComponent, BPLabelledComponentState } from './BPLabelledComponent';
import { BPComponentProps, UiConfigRendererContextType } from './BPComponent';
import { PanelActions } from '@blueprintjs/core/lib/esm/components/panel-stack2/panelTypes';
import { UiObjectConfig } from 'uiconfig.js';
export type BPContainerComponentState = BPLabelledComponentState & {
    children: UiObjectConfig[];
    expanded: boolean;
};
export declare class BPContainerComponent<TState extends BPContainerComponentState = BPContainerComponentState> extends BPLabelledComponent<void, TState, BPComponentProps<void> & PanelActions> {
    protected _childParentOnChange: UiObjectConfig['parentOnChange'];
    protected _registerChild(child: UiObjectConfig): void;
    protected _unregisterChild(child: UiObjectConfig): void;
    constructor(props: BPComponentProps<void> & PanelActions, context: UiConfigRendererContextType, state: TState);
    getUpdatedState(state: TState): TState & import("./BPComponent").BPComponentState & {
        children: UiObjectConfig<any, string, any>[];
        expanded: boolean;
        label: string;
    };
    componentDidMount(): void;
    componentWillUnmount(): void;
}
