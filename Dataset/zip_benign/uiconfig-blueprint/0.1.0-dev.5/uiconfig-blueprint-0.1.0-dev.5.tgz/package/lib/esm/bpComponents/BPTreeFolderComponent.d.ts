import { TreeNodeInfo } from "@blueprintjs/core";
import { BPTreeComponent } from "./BPTreeComponent";
import { UiObjectConfig } from 'uiconfig.js';
export declare class BPTreeFolderComponent extends BPTreeComponent<UiObjectConfig> {
    protected _getNodeId(obj: UiObjectConfig): string;
    protected _updateNodeInfo(node: TreeNodeInfo<UiObjectConfig>, obj: UiObjectConfig): TreeNodeInfo<UiObjectConfig<any, string, any>>;
    protected _getRootNodes(): UiObjectConfig[];
    protected _onNodeClick(_id: string | number): Promise<void>;
    protected _onNodeDoubleClick(_id: string | number): Promise<void>;
}
