import { UiObjectConfig } from 'uiconfig.js';
export declare function InspectorStackComponent({ config }: {
    config: UiObjectConfig<any, 'panel'>;
}): import("react/jsx-runtime").JSX.Element;
