import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPInputComponent } from "./BPInputComponent";
export declare class BPTextInputComponent extends BPInputComponent<string> {
    constructor(props: BPComponentProps<string>, context: UiConfigRendererContextType);
    private _onChange;
    renderInput(): import("react/jsx-runtime").JSX.Element;
}
