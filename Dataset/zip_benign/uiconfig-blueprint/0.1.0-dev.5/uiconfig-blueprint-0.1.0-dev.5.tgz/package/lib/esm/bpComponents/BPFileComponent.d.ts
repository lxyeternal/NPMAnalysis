import { BPComponentProps, UiConfigRendererContextType } from "./BPComponent";
import { BPValueComponent, BPValueComponentState } from "./BPValueComponent";
type StateValue = string | File | null;
type FileImportType = any;
export type BPFileComponentState = BPValueComponentState<StateValue> & {
    mode: 'url' | 'file';
    preview?: string;
};
type BPFileComponentExtras = {
    fileLoader?: {
        load: (v: string | File | {
            path: string;
            file: File | Blob;
        }) => Promise<FileImportType>;
    };
};
type BPFileComponentContextType = UiConfigRendererContextType & BPFileComponentExtras;
export declare class BPFileComponent<T extends FileImportType = FileImportType, TP = {}> extends BPValueComponent<T | null, BPFileComponentState, StateValue> {
    context: BPFileComponentContextType;
    props: BPComponentProps<T | null> & BPFileComponentExtras & TP;
    constructor(props: BPComponentProps<T | null> & BPFileComponentExtras & TP, context: BPFileComponentContextType);
    convertValueToState(_val: T | null, _state: BPFileComponentState): BPFileComponentState;
    convertStateToValue(state: BPFileComponentState): Promise<T | null>;
    renderPreviewSlot(): import("react/jsx-runtime").JSX.Element;
    render(): import("react/jsx-runtime").JSX.Element | null;
}
export {};
