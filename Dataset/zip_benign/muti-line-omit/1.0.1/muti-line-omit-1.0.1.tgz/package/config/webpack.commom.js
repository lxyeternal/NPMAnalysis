const webpack = require('webpack');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { resolve, resolveAssetsRootDir } = require('./utils');
const px2vw = require('postcss-px-to-viewport');

const { defineEnv, extractCss, _hash } = require('./config');


const px2vwOpts = {
  unitToConvert: "px", // 要转化的单位
  viewportWidth: 750, // UI设计稿的宽度
  unitPrecision: 6, // 转换后的精度，即小数点位数
  propList: ["*"], // 指定转换的css属性的单位，*代表全部css属性的单位都进行转换
  viewportUnit: "vw", // 指定需要转换成的视窗单位，默认vw
  fontViewportUnit: "vw", // 指定字体需要转换成的视窗单位，默认vw
  // selectorBlackList: ["wrap"], // 指定不转换为视窗单位的类名，
  minPixelValue: 1, // 默认值1，小于或等于1px则不进行转换
  mediaQuery: true, // 是否在媒体查询的css代码中也进行转换，默认false
  replace: true, // 是否转换后直接更换属性值
  exclude: [/node_modules/], // 设置忽略文件，用正则做目录名匹配
  landscape: false // 是否处理横屏情况
}

module.exports = {
  entry: {
    index: resolve('../src/main.js'),
  },
  output: {
    filename: `js/[name].js`,
    chunkFilename: `js/[name].[contenthash:8].js`,
    path: resolve('../build'),
    libraryTarget: "umd"
  },
  module: {
    rules: [
      {
        test: /\.(j|t)sx?$/,
        include: [resolve('../src')],
        use: [
          {
            loader: 'babel-loader'
          }
        ],
        exclude: /node_modules/
      },
      {
        test: /\.css$/, // 正则匹配文件路径
        exclude: /\.module\.css$/,
        use: [
          // 注意loader生效是从下往上的
          'style-loader',
          'css-loader',
          {
            loader: 'postcss-loader',
            options: {
              ident: 'postcss',
              plugins: () => [
                require('postcss-flexbugs-fixes'),
                require('postcss-preset-env')({
                  autoprefixer: {
                    grid: 'autoplace',
                  },
                  stage: 3,
                }),
                px2vw(px2vwOpts)
              ]
            }
          }
        ]
      },
      {
        test: /\.scss$/,
        exclude: /\.module\.(scss|sass)$/,
        use: [
          extractCss ? MiniCssExtractPlugin.loader : 'style-loader',
          'css-loader',
          {
            loader: 'postcss-loader',
            options: {
              ident: 'postcss',
              plugins: () => [
                require('postcss-flexbugs-fixes'),
                require('postcss-preset-env')({
                  autoprefixer: {
                    grid: 'autoplace',
                  },
                  stage: 3,
                }),
                px2vw(px2vwOpts)
              ]
            }
          },
          {
            loader: 'sass-loader',
            options: {
              includePaths: [resolve('../src/styles')]
            }
          }
        ]
      },
      {
        test: /\.module\.css$/, // 正则匹配文件路径
        exclude: /node_modules/,
        use: [
          // 注意loader生效是从下往上的
          'style-loader',
          {
            loader: 'css-loader',
            options: {
              importLoaders: 1,
              modules: {
                localIdentName: '[name]__[local]-[hash:base64:5]'
              },
            }
          },
          {
            loader: 'postcss-loader',
            options: {
              ident: 'postcss',
              plugins: () => [
                require('postcss-flexbugs-fixes'),
                require('postcss-preset-env')({
                  autoprefixer: {
                    grid: 'autoplace',
                  },
                  stage: 3,
                }),
                px2vw(px2vwOpts)
              ]
            }
          }
        ]
      },
      {
        test: /\.module\.(scss|sass)$/,
        use: [
          extractCss ? MiniCssExtractPlugin.loader : 'style-loader',
          {
            loader: 'css-loader',
            options: {
              importLoaders: 2,
              modules: {
                localIdentName: '[name]__[local]-[hash:base64:5]'
              },
            }
          },
          {
            loader: 'postcss-loader',
            options: {
              ident: 'postcss',
              plugins: () => [
                require('postcss-flexbugs-fixes'),
                require('postcss-preset-env')({
                  autoprefixer: {
                    grid: 'autoplace',
                  },
                  stage: 3,
                }),
                px2vw(px2vwOpts)
              ]
            }
          },
          {
            loader: 'sass-loader',
            options: {
              includePaths: [resolve('../src/styles')]
            }
          }
        ]
      },
      {
        test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              //1024 == 1kb
              //小于10kb时打包成base64编码的图片否则单独打包成图片
              limit: 10240,
              name: resolveAssetsRootDir('img/[name].[hash:7].[ext]')
            }
          }]
      },
      {
        test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
        use: [{
          loader: 'url-loader',
          options: {
            limit: 10240,
            name: resolveAssetsRootDir('font/[name].[hash:7].[ext]')
          }
        }]
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin(defineEnv)
  ],
  performance: {
    // 性能提示，可以提示过大文件
    hints: 'warning', // 性能提示开关 false | "error" | "warning"
    maxAssetSize: 100000, // 生成的文件最大限制 整数类型（以字节为单位）
    maxEntrypointSize: 100000, // 引入的文件最大限制 整数类型（以字节为单位）
    assetFilter: function (assetFilename) {
      // 提供资源文件名的断言函数
      return /\.(png|jpe?g|gif|svg)(\?.*)?$/.test(assetFilename)
    }
  },
  resolve: {
    extensions: ['.js', '.jsx'],
    alias: {
      '@': resolve('../src'),
      '@components': resolve('../src/components'),
      '@img': resolve('../src/assets/img'),
      '@views': resolve('../src/views'),
      '@actions': resolve('../src/actions'),
      '@reducers': resolve('../src/reducers'),
      '@store': resolve('../src/store'),
      '@hooks': resolve('../src/hooks'),
      '@styles': resolve('../src/styles'),
      '@vooConfig': resolve('../paramsConfig')
    }
  }
}