import React, { Component } from 'react'
import Truncation from './Truncation'

class Index extends Component {
  render () {
    return (
      <Truncation {...this.props} />
    )
  }
}

export default Index
