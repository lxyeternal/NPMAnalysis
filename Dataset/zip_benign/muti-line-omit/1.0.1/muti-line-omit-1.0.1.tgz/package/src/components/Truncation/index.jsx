import React, { Component } from 'react'
import PropTypes from 'prop-types'
import './index.scss'

class Truncation extends Component {
  state = {
    expanded: this.props.expanded
  }
  static defaultProps = {
    text: '',
    contentWidth: window.screen.width,
    fontSize: 16,
    maxLine: 3,
    ellipsisRate: 2.5,
    expanded: false,
    foldBtn: <span className="kg-truncation-fold">收起</span>,
    expandBtn: (
      <span>
        ...
        <span className="kg-truncation-expand">全部</span>
      </span>
    )
  }
  static propTypes = {
    text: PropTypes.string.isRequired,
    contentWidth: PropTypes.number,
    fontSize: PropTypes.number,
    maxLine: PropTypes.number,
    ellipsisRate: PropTypes.number,
    expanded: PropTypes.bool,
    foldBtn: PropTypes.node,
    expandBtn: PropTypes.node,
    toggleExpand: PropTypes.func
  }

  toggleExpand = () => {
    this.setState({
      expanded: !this.state.expanded
    })
  }

  halfWidth(str) {
    return str.match(/[ 0-9A-Za-z\x21-\x2f\x3a-\x40\x5b-\x60\x7B-\x7F]/g) || []
  }
  getClips(arr, count) {
    let acc = 0
    for (let i = 0; i < arr.length; i++) {
      acc += this.halfWidth(arr[i]).length ? 0.575 : 1

      if (acc >= count) return arr.slice(0, i)
    }

    return arr
  }
  solve({ text, contentWidth, fontSize, maxLine, ellipsisRate }) {
    const lines = text.split('\n')
    const letterPerLine = Math.floor(contentWidth / fontSize) // 计算一行有几个字
    let accLine = 0 // 累积的行数
    const res = []

    lines.forEach((item) => {
      if (accLine < maxLine) {
        const realText = Array.from(item) // 避免emoji
        const halfCount = this.halfWidth(item).length // 计算半角字符个数
        let lineCount = Math.ceil(
          (realText.length - halfCount * 0.425) / letterPerLine
        ) // 计算占了几行

        if (lineCount === 0) {
          // 只有一个 \n 特殊处理
          item = '　'
          lineCount = 1
        }
        if (accLine + lineCount > maxLine) {
          // 超过最大行了，需要截取
          const visibleTextCount = Math.floor(
            letterPerLine * (Math.min(ellipsisRate, maxLine) - accLine)
          ) // 换成省略号位置
          res.push(this.getClips(realText, visibleTextCount).join(''))
        } else if (accLine + lineCount <= maxLine) {
          // 还够显示
          res.push(item)
        }
        accLine += lineCount
      }
    })

    return res
  }
  addExtra(p, ex) {
    const { toggleExpand } = this.props
    const handler = toggleExpand || this.toggleExpand

    return p.map((item, i) => {
      const wrapper = (el) => <p key={i}>{el}</p>
      return i === p.length - 1
        ? wrapper(
            <>
              {item}
              {<span onClick={handler}>{ex}</span>}
            </>
          )
        : wrapper(item)
    })
  }
  get combine() {
    const { text, foldBtn, expandBtn, toggleExpand } = this.props
    const isExpanded = toggleExpand ? this.props.expanded : this.state.expanded
    const source = text.split('\n').map((i) => (i ? i : '　'))
    let shouldShowMore = false
    const res = this.solve(this.props)

    if (
      // 已截取
      res.length < source.length ||
      res[res.length - 1].length < source[source.length - 1].length
    ) {
      shouldShowMore = true
    }

    if (shouldShowMore) {
      return isExpanded
        ? this.addExtra(source, foldBtn)
        : this.addExtra(res, expandBtn)
    }

    return text
  }

  render() {
    return <div>{this.combine}</div>
  }
}

export default Truncation
