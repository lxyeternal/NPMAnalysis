import type { NumberArray } from 'cheminfo-types';
import { BaseRegression } from 'ml-regression-base';
type JsonType = ReturnType<SimpleLinearRegression['toJSON']>;
/**
 * Class representing simple linear regression.
 * The regression uses OLS to calculate intercept and slope.
 */
export declare class SimpleLinearRegression extends BaseRegression {
    slope: number;
    intercept: number;
    coefficients: number[];
    /**
     * @param x - explanatory variable
     * @param y - response variable
     */
    constructor(x: NumberArray, y: NumberArray);
    /**
     * Get the parameters and model name in JSON format
     * @returns
     */
    toJSON(): {
        name: string;
        slope: number;
        intercept: number;
    };
    _predict(x: number): number;
    /**
     * Finds x for the given y value.
     * @param y - response variable value
     * @returns - x value
     */
    computeX(y: number): number;
    /**
     * Strings the linear function in the form 'f(x) = ax + b'
     * @param precision - number of significant figures.
     * @returns
     */
    toString(precision?: number): string;
    /**
     * Strings the linear function in the form 'f(x) = ax + b'
     * @param precision - number of significant figures.
     * @returns
     */
    toLaTeX(precision?: number): string;
    /**
     * Class instance from a JSON Object.
     * @param json
     * @returns
     */
    static load(json: JsonType): SimpleLinearRegression;
}
export {};
//# sourceMappingURL=index.d.ts.map