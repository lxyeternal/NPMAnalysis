﻿export class Wqprogress{
    constructor(container,options){
        this.options = Object.assign({
            id:uuid(),
            width:120,
            bili:options.width/120,
            progressColor:'forestgreen'
        },options)
        let template = `
        <div id=${this.options.id}>
            <style>
                #${this.options.id}{
                    position: relative;
                    width:120px;
                    height:120px;
                }
                #${this.options.id} .content {
                    top: ${this.options.bili *10 }px;
                    left: ${this.options.bili * 10}px;
                    width: ${this.options.bili * 100}px;
                    height: ${this.options.bili *100 }px;
                    border-radius: 50%;
                    position: absolute;
                    background:red;
                    z-index: 5;
                }
                #${this.options.id} .bg1{
                    position: absolute;
                    width: ${this.options.bili *60 }px;
                    height: ${this.options.bili *120 }px;
                    border-radius: ${this.options.bili *120 }px 0 0 ${this.options.bili * 120}px;
                    z-index: 3;
                    background: sandybrown;
                }
                #${this.options.id} .bg2{
                    left: ${this.options.bili * 60}px;
                    position: absolute;
                    width: ${this.options.bili *60 }px;
                    height: ${this.options.bili *120 }px;
                    border-radius: 0px ${this.options.bili * 120}px ${this.options.bili *120 }px 0;
                    z-index: 1;
                    background: sandybrown;
                }
                #${this.options.id} .pr1 {
                    position: absolute;
                    left: ${this.options.bili * 60 }px;
                    width: ${this.options.bili * 60}px;
                    height: ${this.options.bili * 120}px;
                    border-radius: 0px ${this.options.bili * 120}px ${this.options.bili * 120 }px 0px;
                    z-index: 2;
                    background: ${this.options.progressColor};
                    transform: rotate(-180deg);
                    transform-origin: 0px ${this.options.bili * 60 }px;
                }
                #${this.options.id} .pr2 {
                    position: absolute;
                    left: ${this.options.bili * 60}px;
                    border-radius: 0px ${this.options.bili * 120}px ${this.options.bili * 120}px 0px;
                    z-index: 4;
                    background: ${this.options.progressColor};
                    transform: rotate(-180deg);
                    transform-origin: 0px ${this.options.bili * 60}px;
                }
            </style>
            <div class="bg1"></div>
            <div class="bg2"></div>
            <div class="pr1"></div>
            <div class="pr2"></div>
            <div class="content"></div>
        </div>
        `
        container.innerHTML = template
    }
    init(){
        
    }
    rerender(baifenbi){
        try{
            if(baifenbi<0 || baifenbi > 1){return}
            let pr1 = document.querySelector(`#${this.options.id} .pr1`)
            let pr2 = document.querySelector(`#${this.options.id} .pr2`)
            if(baifenbi < 0.5){
                pr1.style.transform = `rotate(-${180-(180*baifenbi)*2}deg)`
            }else{
                pr1.style.transform = 'rotate(0deg)'
                pr2.style.width = `${this.options.bili * 60}px`
                pr2.style.height = `${this.options.bili * 120}px`
                pr2.style.transform = `rotate(${180*(baifenbi-0.5)*2}deg)`
            }
        }catch(e){
            console.log('请不要频繁刷新')
        } 
        
    }
}
function uuid() { // 获取唯一值
    return ((Math.random()*6+10)|0).toString(16)+'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });
}
export class MyPromise extends Promise{
    static all(arr,fn){
        let result = []
        return new Promise((resolve,reject)=>{
            for(let i = 0;i < arr.length;i++){
                if(arr[i] instanceof Promise){
                    arr[i].then((res)=>{
                        result.push(res)
                       
                        if(fn){
                            fn(result)
                        }
                        if(result.length === arr.length){
                            resolve(result)
                        }
                    },(e)=>{
                        reject(e)
                    })
                }
                
            }
            
        })
    }
}