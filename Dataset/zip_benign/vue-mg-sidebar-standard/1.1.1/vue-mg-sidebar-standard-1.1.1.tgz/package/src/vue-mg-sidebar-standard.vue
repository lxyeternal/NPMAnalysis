<template>
<div>
    <transition-group>
        <!-- sidebar tab -->
        <div class="sidebar-tab" :style="{top : option.tab_height}" :class="{ left_2: sidebar_show }" @click="onSidebarClick()" key="tab" v-cloak>
            <i class="fas fa-times" v-if="sidebar_show"></i>
            <i class="fas fa-bars" v-else></i>
        </div>
    </transition-group>

    <transition name="slide">
        <!-- sidebar -->
        <nav class="sidebar bg-white shadow-sm" :style="{'padding-top' : option.top_height}" v-if="sidebar_show" v-cloak>
            <div class="sidebar-content text-muted">
                <div class="router_link" @click="onBack()">
                    <i class="fas fa-chevron-left mr-3"></i>Back
                </div>
            </div>
            <div class="sidebar-content text-muted" v-for="(route, index) in routes" :key="index">
                <div class="router_link" @click="onChangePath(route.name)" :class="{'active-link': $route.path === route.path}">
                    <i :class="route.icon" class="mr-2" v-if="route.icon"></i>{{ route.name }}
                </div>
            </div>
        </nav>
    </transition>

    <!-- サイドバー以外を暗くする -->
    <div class="black" v-if="sidebar_show" @click="onSidebarClick()"></div>
</div>
</template>

<script>
export default {
    props: {
      show: {
        type: Boolean,
        default: false,
      },
      option: {
        type: Object,
        'default': () => ({
          top_height: '0',
          tab_height: '75px',
        }),
      },
      routes: {
        type: Array,
        'default': () => ([
          {
            name: 'home',
            path: '/',
            icon: 'fas fa-home',
          }
        ]),
      }
    },
    mounted () {
      this.sidebar_show = this.show
    },
    data () {
        return {
            sidebar_show: false,
        }
    },
    methods: {
        onBack () {
            this.$router.go(-1)
        },
        onChangePath (name) {
            this.$router.push({ name: name})
        },
        onSidebarClick () {
            if (this.sidebar_show == false) {
                this.sidebar_show = true
                this.$emit('input',true)
            } else {
                this.sidebar_show = false
                this.$emit('input',false)
            }
        },
    },
}
</script>

<style lang="scss" scoped>
.sidebar {
  position: fixed;
  z-index: 3;
  top: 0;
  left: 0;
  overflow-y: auto;
  height: 100%;
  width: 200px;
}
.router_link {
  padding: 10px 20px;
  z-index: 4;
  cursor: pointer;
}
.router_link:hover {
  color: #fff;
}
.active-link {
  color: #fff;
}

[v-cloak] {
  display: none;
}

.sidebar-tab {
  z-index: 2;
  position: fixed;
  left: 0;
  font-size: 15px;
  color : white;
  background: rgba(#000, 0.2);
  padding: 10px 20px;
  border-radius: 0 20px 20px 0;
}
.sidebar-tab:hover {
  background: rgba(#000, 0.4);
}
.left_2 {
  left: 200px;
}


.slide-leave-active,
.slide-enter-active,
.v-move {
  transition: 1s;
}
.slide-leave-to,.slide-enter {
  transform: translate(-100%, 0);
}

@media ( max-width: 576px ) {
  .black {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height:100%;
    background-color: rgba(#000, 0.4);
    z-index: 1;
  }
}

/*スクロールバー全体*/
::-webkit-scrollbar {
    width: 7px;
}

/*スクロールバーの軌道*/
::-webkit-scrollbar-track {
  border-radius: 10px;
  box-shadow: inset 0 0 6px rgba(0, 0, 0, .1);
}

/*スクロールバーの動く部分*/
::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 50, .2);
  border-radius: 10px;
  box-shadow:0 0 0 1px rgba(255, 255, 255, .3);
}
</style>