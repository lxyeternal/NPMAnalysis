"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GaIsland = exports.populateOptions = exports.populate = void 0;
var random_1 = require("./utils/random");
/**
 * in-place populate the options.population gene pool
 * */
function populate(options) {
    while (options.population.length < options.populationSize) {
        options.population.push(options.randomIndividual());
    }
}
exports.populate = populate;
/**
 * Apply default options and populate when needed
 * */
function populateOptions(_options) {
    var mutationRate = _options.mutationRate, doesABeatB = _options.doesABeatB, population = _options.population, populationSize = _options.populationSize, randomIndividual = _options.randomIndividual, random = _options.random;
    /* eslint-disable-next-line prefer-const */
    var fullOptions;
    if (!mutationRate) {
        mutationRate = 0.5;
    }
    if (!doesABeatB) {
        doesABeatB = function (a, b) {
            return fullOptions.fitness(a) >= fullOptions.fitness(b);
        };
    }
    if (doesABeatB.length !== 2) {
        throw new TypeError('doesABeatB() should takes 2 arguments');
    }
    if (!populationSize) {
        populationSize = population ? population.length : 100;
    }
    if (populationSize < 1) {
        throw new Error('zero population');
    }
    if (!population) {
        if (!randomIndividual) {
            throw new Error('missing randomIndividual in options');
        }
        population = [];
    }
    if (!randomIndividual) {
        randomIndividual = function () {
            if (!fullOptions.population || fullOptions.population.length < 1) {
                throw new Error('no population for randomIndividual to seed from');
            }
            var gene = __assign({}, (0, random_1.randomElement)(fullOptions.random, fullOptions.population));
            fullOptions.mutate(gene, gene);
            return gene;
        };
    }
    if (randomIndividual.length !== 0) {
        throw new TypeError('randomIndividual() should takes no arguments');
    }
    if (!random) {
        random = Math.random;
    }
    if (random.length !== 0) {
        throw new TypeError('random() should takes no arguments');
    }
    if (_options.mutate.length !== 2) {
        throw new TypeError('mutate() should takes 2 arguments');
    }
    if (_options.crossover.length !== 3) {
        throw new TypeError('mutate() should takes 3 arguments');
    }
    fullOptions = __assign(__assign({}, _options), { mutationRate: mutationRate, doesABeatB: doesABeatB, population: population, populationSize: populationSize, randomIndividual: randomIndividual, random: random });
    populate(fullOptions);
    return fullOptions;
}
exports.populateOptions = populateOptions;
var GaIsland = /** @class */ (function () {
    function GaIsland(options) {
        this.options = populateOptions(options);
    }
    GaIsland.prototype.randomizePopulationOrder = function () {
        (0, random_1.shuffleArray)(this.options.random, this.options.population);
    };
    /**
     * should run populate() before invoking this function,
     * therefore assume options.population size is aligned with options.populationSize
     * */
    GaIsland.prototype.compete = function () {
        var n = this.options.populationSize;
        var population = this.options.population;
        var end = n - 1;
        for (var i = 0; i < end; i += 2) {
            var gene = population[i];
            var competitor = population[i + 1];
            if (!this.options.doesABeatB(gene, competitor)) {
                // competitor is stronger than current gene, or too far from this gene
                continue;
            }
            // competitor is weaker than the current gene, will reuse the competitor for new gene
            if (this.options.random() < this.options.mutationRate) {
                // mutate the gene, store the result on weak competitor
                this.options.mutate(gene, competitor);
            }
            else {
                // crossover the gene with a random parent, store the result on weak competitor
                var parent2 = (0, random_1.randomElement)(this.options.random, this.options.population);
                this.options.crossover(gene, parent2, competitor);
            }
        }
    };
    GaIsland.prototype.evolve = function () {
        this.randomizePopulationOrder();
        this.compete();
    };
    return GaIsland;
}());
exports.GaIsland = GaIsland;
