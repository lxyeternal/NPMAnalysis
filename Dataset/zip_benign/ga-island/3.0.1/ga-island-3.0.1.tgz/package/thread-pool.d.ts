/// <reference types="node" />
import { Worker } from 'worker_threads';
export type WeightedWorker = {
    weight: number;
    worker: Worker;
};
/**
 * only support request-response batch-by-batch
 * DO NOT support multiple interlaced concurrent batches
 * */
export declare class ThreadPool {
    totalWeights: number;
    workers: WeightedWorker[];
    dispatch: {
        <T, R>(inputs: T[], cb: (err: any, outputs: R[]) => void): void;
        <T, R>(inputs: T[]): Promise<R[]>;
    };
    constructor(options: {
        modulePath: string;
        /**
         * workload for each worker, default to 1.0 for all workers
         * */
        weights?: number[];
        /**
         * number of worker = (number of core / weights) * overload
         * default to 1.0
         * */
        overload?: number;
    } | {
        workers: WeightedWorker[];
    });
    close(): Promise<number>[];
}
