export type Options<G extends object> = {
    /**
     * The output should be updated in-place.
     * This design can reduce GC pressure with object pooling.
     *  */
    mutate: (input: G, output: G) => void;
    /**
     * default 0.5
     * chance of doing mutation, otherwise will do crossover
     * */
    mutationRate?: number;
    /**
     * The child should be updated in-place.
     * This design can reduce GC pressure with object pooling.
     *  */
    crossover: (aParent: G, bParent: G, child: G) => void;
    /**
     * higher is better
     * */
    fitness: (gene: G) => number;
    /**
     * default only compare the fitness
     * custom function should consider both distance and fitness
     * */
    doesABeatB?: (a: G, b: G) => boolean;
    population?: G[];
    /**
     * default 100
     * should be even number
     * */
    populationSize?: number;
    /**
     * default randomly pick a gene from the population than mutate
     * */
    randomIndividual?: () => G;
    /**
     * return floating number from 0 to 1 inclusively
     * default Math.random()
     * */
    random?: () => number;
};
export type RequiredOptions<G extends object> = Options<G> & ({
    population: G[];
} | {
    randomIndividual: () => G;
});
export type FullOptions<G extends object> = Required<Options<G>>;
/**
 * in-place populate the options.population gene pool
 * */
export declare function populate<G extends object>(options: FullOptions<G>): void;
/**
 * Apply default options and populate when needed
 * */
export declare function populateOptions<G extends object>(_options: RequiredOptions<G>): FullOptions<G>;
export declare class GaIsland<G extends object> {
    options: FullOptions<G>;
    constructor(options: RequiredOptions<G>);
    randomizePopulationOrder(): void;
    /**
     * should run populate() before invoking this function,
     * therefore assume options.population size is aligned with options.populationSize
     * */
    compete(): void;
    evolve(): void;
}
