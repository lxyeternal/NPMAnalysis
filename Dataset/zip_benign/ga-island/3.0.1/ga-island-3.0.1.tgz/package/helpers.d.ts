import { Random } from './utils/random';
/**
 * generate a not-bad doesABeatB() function for kick-starter
 * should use custom implement according to the context
 * */
export declare function genDoesABeatB<G>(options: {
    /**
     * higher is better,
     * zero or negative is failed gene
     * */
    fitness: (gene: G) => number;
    /**
     * normalized to 0..1 ?
     * */
    distance: (a: G, b: G) => number;
    min_distance: number;
    random?: Random;
}): (a: G, b: G) => boolean;
export declare function best<G>(options: {
    population: G[];
    fitness: (gene: G) => number;
}): {
    gene: G;
    fitness: number;
};
export declare function maxIndex(scores: number[]): number;
