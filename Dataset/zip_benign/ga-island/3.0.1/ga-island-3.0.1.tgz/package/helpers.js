"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.maxIndex = exports.best = exports.genDoesABeatB = void 0;
/**
 * generate a not-bad doesABeatB() function for kick-starter
 * should use custom implement according to the context
 * */
function genDoesABeatB(options) {
    return function doesABeatB(a, b) {
        var aScore = options.fitness(a);
        if (aScore <= 0) {
            return false;
        }
        // aScore > 0
        var bScore = options.fitness(b);
        if (bScore <= 0) {
            return true;
        }
        var distance = options.distance(a, b);
        if (distance >= options.min_distance &&
            (options.random || Math.random)() > 0.1 / distance) {
            return false;
        }
        return aScore > bScore;
    };
}
exports.genDoesABeatB = genDoesABeatB;
function best(options) {
    var n = options.population.length;
    if (n === 0) {
        throw new Error('empty population');
    }
    var bestGene = options.population[0];
    var bestFitness = options.fitness(bestGene);
    for (var i = 1; i < n; i++) {
        var gene = options.population[i];
        var fitness = options.fitness(gene);
        if (fitness > bestFitness) {
            bestFitness = fitness;
            bestGene = gene;
        }
    }
    return {
        gene: bestGene,
        fitness: bestFitness,
    };
}
exports.best = best;
function maxIndex(scores) {
    var n = scores.length;
    if (n === 0) {
        throw new Error('empty array');
    }
    var maxIdx = 0;
    var maxScore = scores[0];
    for (var idx = 1; idx < n; idx++) {
        var score = scores[idx];
        if (score > maxScore) {
            maxScore = score;
            maxIdx = idx;
        }
    }
    return maxIdx;
}
exports.maxIndex = maxIndex;
