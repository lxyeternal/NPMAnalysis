"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.shuffleArray = exports.randomBoolean = exports.randomElement = exports.randomNumber = void 0;
/**
 * @param random  custom implementation of Math.random()
 * @param min     inclusive lower bound
 * @param max     inclusive upper bound
 * @param step    interval between each value
 * */
function randomNumber(random, min, max, step) {
    var range = (max - min) / step + 1;
    return Math.floor(random() * range) * step + min;
}
exports.randomNumber = randomNumber;
function randomElement(random, xs) {
    var idx = Math.floor(random() * xs.length);
    return xs[idx];
}
exports.randomElement = randomElement;
/**
 * @param random        custom implementation of Math.random()
 * @param probability   change of getting true
 * */
function randomBoolean(random, probability) {
    if (probability === void 0) { probability = 0.5; }
    return random() < probability;
}
exports.randomBoolean = randomBoolean;
/**
 * in-place shuffle the order of elements in the array
 * */
function shuffleArray(random, xs) {
    var n = xs.length;
    for (var i = 0; i < n; i++) {
        var j = Math.floor(random() * n);
        var temp = xs[i];
        xs[i] = xs[j];
        xs[j] = temp;
    }
}
exports.shuffleArray = shuffleArray;
