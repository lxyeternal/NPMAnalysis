/**
 * return float value from 0 to 1 inclusively
 * as chance to change the Math.random() implementation
 * */
export type Random = () => number;
/**
 * @param random  custom implementation of Math.random()
 * @param min     inclusive lower bound
 * @param max     inclusive upper bound
 * @param step    interval between each value
 * */
export declare function randomNumber(random: Random, min: number, max: number, step: number): number;
export declare function randomElement<T>(random: Random, xs: T[]): T;
/**
 * @param random        custom implementation of Math.random()
 * @param probability   change of getting true
 * */
export declare function randomBoolean(random: Random, probability?: number): boolean;
/**
 * in-place shuffle the order of elements in the array
 * */
export declare function shuffleArray<T>(random: Random, xs: T[]): void;
