"use strict";
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThreadPool = void 0;
var os = require("os");
var util_1 = require("util");
var worker_threads_1 = require("worker_threads");
function defaultWeights() {
    return os.cpus().map(function (cpu) { return cpu.speed; });
}
/**
 * only support request-response batch-by-batch
 * DO NOT support multiple interlaced concurrent batches
 * */
var ThreadPool = /** @class */ (function () {
    function ThreadPool(options) {
        var _this = this;
        this.dispatch = (0, util_1.promisify)(function (input_list, cb) {
            var e_1, _a;
            var n = input_list.length;
            var output_list = new Array(n);
            var offset = 0;
            var pending = 0;
            var _loop_1 = function (worker) {
                var start_index = offset;
                var slice_count = Math.ceil((worker.weight / _this.totalWeights) * n);
                var input_sub_list = input_list.slice(offset, offset + slice_count);
                var end_index = offset + input_sub_list.length;
                pending++;
                worker.worker.once('message', function (output_sub_list) {
                    for (var output_index = start_index, sub_list_index = 0; output_index < end_index; output_index++, sub_list_index++) {
                        output_list[output_index] = output_sub_list[sub_list_index];
                    }
                    pending--;
                    if (pending === 0) {
                        cb(undefined, output_list);
                    }
                });
                worker.worker.postMessage(input_sub_list);
                if (end_index >= n) {
                    return "break";
                }
                offset = end_index;
            };
            try {
                for (var _b = __values(_this.workers), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var worker = _c.value;
                    var state_1 = _loop_1(worker);
                    if (state_1 === "break")
                        break;
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        });
        if ('workers' in options) {
            if (options.workers.length === 0) {
                throw new Error('require at least 1 workers');
            }
            this.workers = options.workers;
            this.totalWeights = 0;
            this.workers.forEach(function (x) { return (_this.totalWeights += x.weight); });
            return;
        }
        var weights = options.weights, overload = options.overload;
        if (!weights) {
            weights = defaultWeights();
        }
        if (weights.length === 0) {
            throw new Error('require at least 1 weights');
        }
        if (!overload) {
            overload = 1;
        }
        var n = weights.length * overload;
        this.workers = new Array(n);
        this.totalWeights = 0;
        for (var i = 0; i < n; i++) {
            var weight = weights[i % weights.length];
            this.totalWeights += weight;
            this.workers[i] = {
                weight: weight,
                worker: new worker_threads_1.Worker(options.modulePath),
            };
        }
    }
    ThreadPool.prototype.close = function () {
        return this.workers.map(function (worker) { return worker.worker.terminate(); });
    };
    return ThreadPool;
}());
exports.ThreadPool = ThreadPool;
