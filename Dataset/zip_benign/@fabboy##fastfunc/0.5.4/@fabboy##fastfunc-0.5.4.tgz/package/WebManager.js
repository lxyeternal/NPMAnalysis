const Check = require("./basic/check");
const Printer = require("./basic/printer")
const http = require('http');
const fs = require('fs');


    function WebServer(mainFile, host,port) {
        if(!Check(mainFile, "string")){
            Printer("Typing Error: [mainFile] is a String not " + mainFile + ", please enter a string", 1, true)
            return
        }
        if(!Check(host, "string")){
            Printer("Typing Error: [host] is a String not " + host + ", please enter a String", 1, true)
            return
        }
        if(!Check(port, "int")){
            Printer("Typing Error: [Port] is a Int not " + port + ", please enter a Int", 1, true)
            return
        }
        const requestListener = function (req, res) {
            res.writeHead(200, { 'content-type': 'text/html' })
            fs.createReadStream(mainFile).pipe(res)
        };
        const server = http.createServer(requestListener);
        server.listen(port, host, () => {
           Printer(`Server is running on http://${host}:${port}`, 2, false)
        });






    }

module.exports = WebServer;
