# What is FastFunc
FastFunc is a package written in Node.js which should make it easier and more efficient to code node.js. Read feature's for further information
# Features
1. Building a simple http webserver with just one line of code
2. Finding out the date and time of different countries and regions
3. A Wait () function which allows you to pause the code with just one line of code
4. An effective new function for printing in the console. It allows you to write in different colors with different signs
5. A function that allows you to use a line of code to check whether the variable is a string, int, float or bool

_For more information, see "Documentation"_
# Installation
Our package is available on NPM just use 

``
npm i @fabboy/fastfunc
``
Import the package:
   ````
   const FF = require("@fabboy/fastfunc")
   ````
# Documentation
**If you want to...**
 
\
   **Create a simple Http webserver:**
   ```
   FF.WebServer(true, true, "index.html", "localhost",3000)
   ```
You can turn on of the debug with the second true/false \
You can change the Main file from "Index.html" to what you want.\
You can also change the Port

   **Find the date from a country**
   ```
   FF.GetTime("Germany", "Europe/Zurich", 1)
   ```
   The output is Date + Time if you print it or used it somewhere else.
   There are 3 different modes:\
   ``1`` = date + time\
   ``2`` = date\
   ``3`` = time\
\
   **Create a pause in your code**
   ```
   FF.Wait(2000).then(r => {       
     //stuff                    
   })                              
   ```
   **Print the effective ways**
   ```
   FF.Printer("Hello World", 1, true)           
   ```
   The first arg is the Text. \
   The Seconde is the Type/Color:
   
   ``1`` = Alert in red\
   ``2`` = Information in yellow\
   ``3`` = Console comment in green\
   ``4`` = Console comment in blue\
   ``5`` = Console comment in magenta\

If you activated the sign with the last argument, you will always get a sign: \
[!] {Text}\
[?] {Text}\
[#] {Text}\
[~] {Text}\
[*] {Text}\

**Want to check if a variable is a string, int, float or bool**
1. Example\
In this example the output would be (if you print it) false.
```
const test = 2;           
FF.Check(test, "string")  
```
2. Example\
In this example the output would be (if you print it) true.
```
const test = 2;           
FF.Check(test, "int")   
```

# Changelog
**0.5: Release of the Basic functions:**
 1. Check
 2. Printer
 3. Time

**0.5.1: Bug fixes**
   1. Wait
   2. Bug Fixes

**0.5.2: Added simple Webserver**
1. Webserver added 
2. Updated Readme

# License

ISC License

Copyright (c) [2021] [Fabboy]

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
