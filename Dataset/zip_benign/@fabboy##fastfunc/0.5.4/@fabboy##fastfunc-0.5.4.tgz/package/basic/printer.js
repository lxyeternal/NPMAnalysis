const Check = require("./check")

function Printer(text, type,sign){
    if(typeof sign != "boolean"){
        Printer("Typing Error: [sign] is a Boolean not " + sign + ", please enter a Boolean", 1, true)
        return
    }
    if(!Check(type, "Int")){
       console.log("\x1b[31m","Typing Error: [Type] is a Integer not " + type + ", please enter a Integer")
        return
    }
    if(sign == true) {
        if (type == 1) {
            console.log("\x1b[31m", "[!] " + text, "\x1b[0m")
        }
        if (type == 2) {
            console.log("\x1b[33m", "[?] " + text, "\x1b[0m")
        }
        if (type == 3) {
            console.log("\x1b[32m", "[#] " + text, "\x1b[0m")
        }
        if (type == 4) {
            console.log("\x1b[34m", "[~] " + text, "\x1b[0m")
        }
        if (type == 5) {
            console.log("\x1b[35m", "[*] " + text, "\x1b[0m")
        }
    }
    if(sign == false){
        if (type == 1) {
            console.log("\x1b[31m", text, "\x1b[0m")
        }
        if (type == 2) {
            console.log("\x1b[33m",text, "\x1b[0m")
        }
        if (type == 3) {
            console.log("\x1b[32m",text, "\x1b[0m")
        }
        if (type == 4) {
            console.log("\x1b[34m",text, "\x1b[0m")
        }
        if (type == 5) {
            console.log("\x1b[35m",text, "\x1b[0m")
        }
    }
}

module.exports = Printer;