
function Check(value, type) {
    if(typeof type != "string"){
        console.log("\x1b[31m", "[!] " + "Typing Error: [type] is a String not " + type + ", please enter a String")
    }
    if(type == "Int" || type == "int" || type=="1") {
        return !isNaN(value) &&
            parseInt(Number(value)) == value &&
            !isNaN(parseInt(value, 10));
    }
    if(type=="Bool" || type=="bool" || type=="2"){
        if(typeof value == "boolean"){
            return true
        }else{
            return false
        }
    }
    if(type=="Float" || type=="float" || type=="3"){
        if(Number(value) === value && value % 1 !== 0){
            return true
        }else{
            return false
        }
    }
    if(type=="String" || type=="string" || type=="4"){
        if(typeof value == "string"){
            return true
        }else{
            return false
        }
    }
}
module.exports = Check;