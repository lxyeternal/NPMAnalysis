const version = "0.5.3";
const Printer = require("./basic/printer");
//const HttpReq = require("./web/HttpRequest");

exports.Check = require('./basic/check');
exports.Printer = require('./basic/printer');
exports.GetTime = require("./basic/time")
exports.Wait = require("./basic/wait")
exports.WebServer = require("./WebManager")
