interface ObserverOptions {
    childList: boolean;
    attributes: boolean;
    subtree: boolean;
    attributeFilter?: string[] | undefined;
    characterData?: boolean;
    attributeOldValue?: boolean;
    characterDataOldValue?: boolean;
}
interface MarkOptions {
    prefix?: string;
    text: string;
    width?: number;
    height?: number;
    color?: string;
    font?: string;
    fontSize?: number;
    alpha?: number;
    rotate?: number;
    scale?: number;
    startX?: number;
    startY?: number;
    rows?: number;
    cols?: number;
    xGap?: number;
    yGap?: number;
    repeat?: boolean;
}
declare type Options = {
    debug?: boolean;
    container: string | HTMLElement;
    image: string;
    monitor?: boolean;
    encoderOptions?: number;
    style?: {
        [key: string]: any;
    };
    observer: MutationCallback;
    observerOptions: ObserverOptions;
} & MarkOptions;
export default class WaterMark {
    options: Options;
    private ctx;
    private canvas;
    dom: HTMLElement | null;
    observer: MutationObserver | null;
    constructor(options: Options);
    render(): void;
    private draw;
    drawImage(): void;
    drawFont(): void;
    observerWaterMark(dom?: HTMLElement | null): void;
    disposeObserver(): void;
    setWaterMark(dom?: HTMLElement | null): void;
    removeWaterMark(dom?: HTMLElement | null): void;
    /**
     * @description 获取图片
     * @param type 图片格式, 默认为 image/png
     * @param encoderOptions 在指定图片格式为 image/jpeg 或 image/webp的情况下, 可以从 0 到 1 的区间内选择图片的质量。如果超出取值范围, 将会使用默认值 0.92。其他参数会被忽略。
     * @returns 包含 data URI 的DOMString。
     */
    getImage(type?: string, encoderOptions?: number | undefined): string;
    merge(options: Options): {
        debug: boolean;
        monitor: boolean;
        repeat: boolean;
        container: string;
        encoderOptions: number;
    } & {
        prefix: string;
        text: string;
        image: string;
        color: string;
        font: string;
        fontSize: number;
        alpha: number;
        rotate: number;
        scale: number;
        startX: number;
        startY: number;
        rows: number;
        cols: number;
        xGap: number;
        yGap: number;
    } & {
        debug?: boolean | undefined;
        container: string | HTMLElement;
        image: string;
        monitor?: boolean | undefined;
        encoderOptions?: number | undefined;
        style?: {
            [key: string]: any;
        } | undefined;
        observer: MutationCallback;
        observerOptions: ObserverOptions;
    } & MarkOptions & {
        style: {
            width: number;
            height: number;
            left: number;
            top: number;
            position: string;
            'pointer-events': string;
            overflow: string;
            'z-index': number;
        } & {
            [key: string]: any;
        };
        observerOptions: {
            childList: boolean;
            attributes: boolean;
            subtree: boolean;
            attributeFilter: string[];
        } & ObserverOptions;
    };
}
export {};
//# sourceMappingURL=index.d.ts.map