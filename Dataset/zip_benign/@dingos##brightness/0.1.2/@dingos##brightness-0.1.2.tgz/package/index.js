const os = require('os')
const macBrightness = require('./mac/brightness')
const linuxBrightness = require('brightness')

const platform = os.platform()

exports.getBrightness = async () => {
  switch (platform) {
    case 'darwin':
      return macBrightness.getBrightness()
    case 'linux':
      return await linuxBrightness.get()
    case 'win32':
      //@TODO need implement
      return null
    default:
      return null
  }
}

exports.setBrightness = async brightness => {
  switch (platform) {
    case 'darwin':
      return macBrightness.setBrightness(brightness)
    case 'linux':
      return await linuxBrightness.set(brightness)
    case 'win32':
      //@TODO need implement
      return null
    default:
      return null
  }
}
