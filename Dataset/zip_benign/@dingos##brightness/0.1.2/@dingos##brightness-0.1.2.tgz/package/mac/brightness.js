// Copyright (c) 2021 Lu Yuan. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

const brightness = require('bindings')('macos_brightness.node')

module.exports = brightness
