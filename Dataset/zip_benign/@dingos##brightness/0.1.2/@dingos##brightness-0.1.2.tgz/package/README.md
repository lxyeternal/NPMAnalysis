# Brightness

## example

```javascript
const { getBrightness, setBrightness } = require('@dingos/brightness')
// get brightness
const brightness = await getBrightness()
// set brightness
setBrightness(0.5)
```
