module.exports = {
  printWidth: 120, // 单行长度
  tabWidth: 2, // 缩进长度
  useTabs: false, // 使用空格代替tab缩进
  trailingComma: 'all', // 多行时尽可能打印尾随逗号
  semi: false, // 句末使用分号
  singleQuote: true, // 使用单引号
  bracketSpacing: true, // 在对象前后添加空格-eg: { foo: bar }
  endOfLine: 'lf', // 结束行形式为 \n
  embeddedLanguageFormatting: 'auto', // 对引用的代码进行格式化
  arrowParens: 'avoid', // x => x
}
