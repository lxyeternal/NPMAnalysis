# Gatsby Scroller
<img alt="GitHub package.json version (branch)" src="https://img.shields.io/github/package-json/v/koniecznytomek/react-styled-grid-layout/master?label=Version">


Simple package to manipulate **window scroll speed** and smooth effect during scroll. 

## Install

`npm i gatsby-scroller`

## Usage

You can wrap those page components you want to animate during window scroll 
or all page wrapping layout component.

```jsx

import React from 'react';
import Scroller from 'gatsby-scroller';

const Layout = ({ children }) => (
  <>
    <Scroller offset={5} lenght={2}>
      {children}
    </Scroller>
  </>
);

export default Layout;
```

## Options
You can manipulate the flow of animation through props below:

|Props|Type|Example| Default|
|:----------|:------|:------|:--------|
|offset  | _number_ | offset={2}| 5|
|lenght  | _number_ | lenght={1}| 1|
|ease  | _string_ | ease='ease-in'| cubic-bezier(0.16, 1, 0.3, 1)|

## Live demo

Soon

## Github

https://github.com/koniecznytomek/gatsby-scroller

## Licence

MIT

## Author

Feel free to contact:

@tomekkoniec

tomek@tomekkonieczny.com
