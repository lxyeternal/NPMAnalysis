import React, { useEffect, useRef } from 'react';

export const Scroller = ({
  children,
  offset = 5,
  lenght = 1,
  ease = 'cubic-bezier(0.16, 1, 0.3, 1)',
}) => {
  const content = useRef();
  const wrapper = useRef();

  useEffect(() => {
    const handler = () => {
      const body = document.body.getBoundingClientRect().top;
      const bodyOffset = body / offset;

      const container = content.current;

      container.style.top = `${bodyOffset}px`;
      container.style.position = 'fixed';
      container.style.transition = `all ${lenght}s ${ease}`;
    };

    const windowHeight = content.current.offsetHeight;
    wrapper.current.style.height = `${windowHeight}px`;

    window.addEventListener('scroll', handler);

    return () => {
      window.removeEventListener('scroll', handler);
    };
  });
  return (
      <div ref={wrapper}>
        <div ref={content}>{children}</div>
      </div>
  );
};
export default Scroller;
