# Installation
> `npm install --save-dev @ryancavanaugh/jquery.timepicker`

# Summary
This package contains type definitions for jQuery UI Timepicker 0.3.

The project URL or description is http://fgelinas.com/code/timepicker/

# Credits

These definitions were written by Anwar Javed <https://github.com/anwarjaved>.

# Details
Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the jquery.timepicker directory.

Additional Details
 * Last updated: Tue, 17 May 2016 00:18:23 GMT
 * Typings kind: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: none
