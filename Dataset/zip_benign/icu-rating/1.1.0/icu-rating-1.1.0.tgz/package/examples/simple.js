var rating = require('../index');

var games = [];
    var game = {
        rating : 1600,
        result : 1
    };
    games.push(game);

    var newRating = rating(1600, games, 24)
    console.log(JSON.stringify(newRating))