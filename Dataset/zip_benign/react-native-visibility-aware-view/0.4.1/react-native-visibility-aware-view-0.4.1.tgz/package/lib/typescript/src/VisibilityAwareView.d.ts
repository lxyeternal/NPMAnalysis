import React from "react";
import type { VisibilityAwareViewProps } from "./VisibilityAwareViewNativeComponent";
import { VisibilityAwareViewHandle } from "./VisibilityAwareViewNativeComponent";
export declare const VisibilityAwareView: React.ForwardRefExoticComponent<VisibilityAwareViewProps & React.RefAttributes<VisibilityAwareViewHandle>>;
//# sourceMappingURL=VisibilityAwareView.d.ts.map