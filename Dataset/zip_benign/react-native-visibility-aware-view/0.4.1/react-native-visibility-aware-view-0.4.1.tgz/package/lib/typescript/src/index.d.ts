import type { VisibilityAwareView } from "./VisibilityAwareView";
export { VisibilityAwareView } from "./VisibilityAwareView";
export { VisibilityAwareViewHandle, VisibilityAwareViewProps } from "./VisibilityAwareViewNativeComponent";
export default VisibilityAwareView;
//# sourceMappingURL=index.d.ts.map