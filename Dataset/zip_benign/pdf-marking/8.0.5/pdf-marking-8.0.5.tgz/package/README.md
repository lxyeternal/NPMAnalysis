# Marking 阅卷

详细使用方法请参考demo

---

## 安装

---

```
npm install pdf-marking
```

## 属性

---

| 属性名      | 说明    | 类型      | 可选值       | 默认值   |
|---------- |-------- |---------- |-------------  |-------- |
| data-load-fn     | 数据加载方法,该方法参数为调用load是传入的参数   | Function(arg)  |   —   |    —     |
| selection-bg-color     | 文本选区背景颜色   | String    | — | rgba(0, 180, 255, 0.5)   |
| hide-pagenav  | 隐藏页码导航    | Boolean   | —   | false   |
| hide-toolbox  | 隐藏工具条    | Object   | —   | 见watermark对象   |
| hide-contextmenupopup  | 隐藏右键菜单    | Number   | —   | 5   |
| max-scale  | 最大缩放比例    | Number   | —   | 4   |
| textpopup-disableelement  | 禁用选区弹出层元素    | Array   | highlight,copy   | []   |
| contextmenupopup-disableelement  | 禁用右键菜单弹出层元素    | Array   | highlight,pan,freeLine,freeText   | []   |
| threshold  | 滑动阈值（swipe-up/down事件）    | Number   | -   | 100   |

---
## 对象

---

### annotation 注释对象

参考App.vue


## 事件

---

| 事件名      | 说明    | 参数      |
|---------- |-------- |---------- |
| page-change     | 页码改变   | pageIndex  |
| annotation-change     | 注释发生改变   |  (annotations,action)   |
| annotation-click    | 注释点击事件   |  (event,annotation)   |
| loaded  | 打开后触发   | —   |
| swipe-up  | 滑到底部时继续向上滑时触发   | —   |
| swipe-down  | 滑到顶部时继续向下滑时触发   | —   |

## 方法

---

| 方法名      | 说明    | 参数      |
|---------- |-------- |---------- |
| open  | 打开    | { data,annotationList,notInit }   |
| skipPage  | 跳转页面    | pageIndex   |
| skipByWordPos  | 通过文字位置跳转页面    | wordPos   |
| nextPage  | 下一页    | —   |
| prevPage  | 上一页    | —   |
| setScaleType  | 设置缩放类型/大小    | page-fit,page-width,数字  |
| zoomin     | 放大   | —    |
| zoomout  | 缩小    | —   |
| addAnnotationData     | 添加注释  | —  |
| removeAnnotation     | 添加注释  | relationId  |
| copySelectText  | 复制选区文本    | —   |
| setPointerType     | 设置指针类型   | hand/select/highlight/freeLine/line/rect/ellipse/arrow/eraser/freeText    |
