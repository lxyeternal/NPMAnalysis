# Pug (HTML) wrapper for SocketStream 0.3

Allows you to use [Pug](https://pugjs.org/api/getting-started.html) files (.jade) in your SocketStream project.


### Instructions

Add `ss-pug` to your application's `package.json` file and then add this line to app.js:

``` javascript
ss.client.formatters.add(require('ss-pug'));
```


### Passing local variables

Some 3rd-party authentication libraries will want to inject HTML into your views.
You may easily pass through local variables as so:

``` javascript
ss.client.formatters.add(require('ss-pug'), {locals: {myvar: 'myvalue'}});
```