"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var ALL = '__ALL__';
var Emitter = /** @class */ (function () {
    function Emitter(options) {
        var DEFAULT_OPTIONS = {
            isDevMode: false,
            onCycle: function (chain) {
                console.error('[typed-rx-emitter] Error: Cyclical dependency detected. '
                    + 'This may cause a stack overflow unless you fix it. '
                    + chain.join(' -> '));
            }
        };
        this.emitterState = {
            callChain: new Set,
            observables: new Map,
            observers: new Map,
            options: __assign({}, DEFAULT_OPTIONS, options)
        };
    }
    /**
     * Emit an event (silently fails if no listeners are hooked up yet)
     */
    Emitter.prototype.emit = function (key, value) {
        var _a = this.emitterState.options, isDevMode = _a.isDevMode, onCycle = _a.onCycle;
        if (isDevMode) {
            if (this.emitterState.callChain.has(key)) {
                onCycle(Array.from(this.emitterState.callChain).concat(key));
                return this;
            }
            else {
                this.emitterState.callChain.add(key);
            }
        }
        if (this.hasChannel(key)) {
            this.emitOnChannel(key, value);
        }
        if (this.hasChannel(ALL)) {
            this.emitOnChannel(ALL, value);
        }
        if (isDevMode)
            this.emitterState.callChain.clear();
        return this;
    };
    /**
     * Subscribe to an event
     */
    Emitter.prototype.on = function (key) {
        return this.createChannel(key);
    };
    /**
     * Subscribe to all events
     */
    Emitter.prototype.all = function () {
        return this.createChannel(ALL);
    };
    ///////////////////// privates /////////////////////
    Emitter.prototype.createChannel = function (key) {
        var _this = this;
        if (!this.emitterState.observers.has(key)) {
            this.emitterState.observers.set(key, []);
        }
        if (!this.emitterState.observables.has(key)) {
            this.emitterState.observables.set(key, []);
        }
        var observable = rxjs_1.Observable
            .create(function (_) {
            _this.emitterState.observers.get(key).push(_);
            return function () { return _this.deleteChannel(key, observable); };
        });
        this.emitterState.observables.get(key).push(observable);
        return observable;
    };
    Emitter.prototype.deleteChannel = function (key, observable) {
        if (!this.emitterState.observables.has(key)) {
            return;
        }
        var array = this.emitterState.observables.get(key);
        var index = array.indexOf(observable);
        if (index < 0) {
            return;
        }
        array.splice(index, 1);
        if (!array.length) {
            this.emitterState.observables.delete(key);
            this.emitterState.observers.delete(key);
        }
    };
    Emitter.prototype.emitOnChannel = function (key, value) {
        this.emitterState.observers.get(key).forEach(function (_) { return _.next(value); });
    };
    Emitter.prototype.hasChannel = function (key) {
        return this.emitterState.observables.has(key);
    };
    return Emitter;
}());
exports.Emitter = Emitter;
//# sourceMappingURL=index.js.map