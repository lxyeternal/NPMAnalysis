export declare class NguCarouselModule {
}
