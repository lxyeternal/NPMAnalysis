var MAX_PERIODS = 20000; //maximum number of candles to track. 20000 by default.
//note -- requests for candles older than MAX_PERIODS periods will "roll over" to the beginning!

//create a new tracker
var CandlesTracker = require('./index.js');
var myCandlesTracker = new CandlesTracker(MAX_PERIODS);

//candle data
var c = {
    o: 1.0,
    h: 2.0,
    l: 0.5,
    c: 2.0,
    v: 2000
}

// var c2 = { //can also use this format
//     open: 1.0,
//     high: 2.0,
//     low: 0.5,
//     close: 2.0,
//     volume: 2000
// }

//submitCandle(o,h,l,c,v,bid,ask,timeDeltaInt,timeStampInt64) -- everything defaults to zero
myCandlesTracker.submitCandle(c.o, c.h, c.l, c.c, c.v);
//or
// myCandlesTracker.submitCandle(c); //c2 format also works

//get old candle -- up to MAX_PERIODS ago [rolls over to beginning afterwards]
var nPeriodsAgo = 1;
// console.log(myCandlesTracker.getCandle(nPeriodsAgo));
//{ o: 1, h: 2, l: 0.5, c: 2, v: 2000, b: 0, a: 0, td: 0, ts: 0n }

//get a merged candle [higher timeframe candle]
//first submit some period==1 candles
myCandlesTracker.submitCandle(c.o, c.h, c.l, c.c, c.v);
myCandlesTracker.submitCandle(c.o, c.h*2, c.l, c.c, c.v);
myCandlesTracker.submitCandle(c.o, c.h*3, c.l, c.c, c.v);
myCandlesTracker.submitCandle(c.o, c.h*4, c.l, c.c, c.v);
myCandlesTracker.submitCandle(c.o, c.h*5, c.l, c.c, c.v);
//now we get merged candle from index [nPeriodsAgo ... nPeriodsAgo+5]
console.log(myCandlesTracker.getMergedCandle(nPeriodsAgo, nPeriodsAgo+5));
console.log(myCandlesTracker.getMergedCandleObj(nPeriodsAgo, nPeriodsAgo+5));
//note that nPeriodsAgo=1 gives us the latest candle
//{ o: 1, h: 10, l: 0, c: 0, v: 12000 }
//{ open: 1, high: 10, low: 0, close: 0, volume: 12000 }









console.log(myCandlesTracker.getCandleObj(nPeriodsAgo));
// {
//     open: 1,
//     high: 2,
//     low: 0.5,
//     close: 2,
//     volume: 2000,
//     bid: 0,
//     ask: 0,
//     bidSize: 0,
//     askSize: 0,
//     timeDelta: 0,
//     timestamp: 0n
// }
