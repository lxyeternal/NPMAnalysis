module.exports = function(maxPeriods=20000){
    var _this = this;
    this.index = 0;
    this.b = new Float32Array(maxPeriods);
    this.a = new Float32Array(maxPeriods);
    this.bs = new Int32Array(maxPeriods);
    this.as = new Int32Array(maxPeriods);
    this.o = new Float32Array(maxPeriods);
    this.h = new Float32Array(maxPeriods);
    this.l = new Float32Array(maxPeriods);
    this.c = new Float32Array(maxPeriods);
    this.v = new Float32Array(maxPeriods);
    this.td = new Int32Array(maxPeriods);
    this.ts = new BigInt64Array(maxPeriods);

    this.submitCandle = function(o=0,h=0,l=0,c=0,v=0, b=0,a=0,td=0,ts=0,bs=0,as=0){ //bs as for bid ask size

        if (typeof o === 'object') {
            // Assume o is a candle object and extract properties
            h = o.h || o.high ||  0;
            l = o.l || o.low || 0;
            c = o.c || o.close || 0;
            v = o.v || o.volume || 0;
            b = o.b || o.bid || 0;
            a = o.a || o.ask || 0;
            td = o.td || o.timeDelta || 0;
            ts = o.ts || o.timestamp || 0;
            bs = o.bs || o.bidSize || 0;
            as = o.as || o.askSize || 0;
            o = o.o || o.open || 0;
        }

        var i = _this.index;
        _this.b[i] = b;
        _this.a[i] = a;
        _this.o[i] = o;
        _this.h[i] = h;
        _this.l[i] = l;
        _this.c[i] = c;
        _this.v[i] = v;
        _this.bs[i] = bs;
        _this.as[i] = as;
        _this.td[i] = td;
        _this.ts[i] = BigInt((ts||0));
        _this.index=(_this.index+1)%maxPeriods;
    }

    // this.submitCandleObj = function(candle){
    //     var i = _this.index;
    //     _this.b[i] = candle.b || candle.bid || 0.0;
    //     _this.a[i] = candle.a || candle.ask || 0.0;
    //     _this.o[i] = candle.o || candle.open || 0.0;
    //     _this.h[i] = candle.h || candle.high || 0.0;
    //     _this.l[i] = candle.l || candle.low || 0.0;
    //     _this.c[i] = candle.c || candle.close || 0.0;
    //     _this.v[i] = candle.v || candle.volume || 0.0;
    //     _this.bs[i] = candle.bs || candle.bidSize || 0.0;
    //     _this.as[i] = candle.as || candle.askSize || 0.0;
    //     _this.td[i] = candle.td || candle.timeDelta || 0.0;
    //     _this.ts[i] = BigInt((candle.ts|| candle.timestamp || 0.0));
    //     _this.index=(_this.index+1)%maxPeriods;
    // }

    this.getCandle = function(n){ //note that 1 is latest candle
        var i = (_this.index-n+maxPeriods)%maxPeriods;
        return {
            o: _this.o[i],
            h: _this.h[i],
            l: _this.l[i],
            c: _this.c[i],
            v: _this.v[i],
            b: _this.b[i],
            a: _this.a[i],
            bs: _this.bs[i],
            as: _this.as[i],
            td: _this.td[i],
            ts: _this.ts[i]
        }
    }

    this.getMergedCandleObj = function(nAgoStart, nAgoEnd) {
        var c = _this.getMergedCandle(nAgoStart, nAgoEnd);
        return {
            open: c.o,
            high: c.h,
            low: c.l,
            close: c.c,
            volume: c.v,
            // bid: c.b,
            // ask: c.a,
            // bidSize: c.bs,
            // askSize: c.as,
            // timeDelta: c.td,
            // timestamp: c.ts
        }
    }

    this.getMergedCandle = function(nAgoStart, nAgoEnd) {//note that index 1 is latest candle
        var tracker = _this;
        // Initialize merged candle object
        var mergedCandle = {
            o: 0,
            h: -Infinity,
            l: Infinity,
            c: 0,
            v: 0,
            // ts: 0,
            // td: 0,
        };

        for (var i = nAgoStart; i <= nAgoEnd; i++) {
            var currentCandle = tracker.getCandle(i); //minus 1 because 1 is latest, not zero

            // Update merged candle data
            mergedCandle.o = (i == nAgoStart) ? currentCandle.o : mergedCandle.o;
            mergedCandle.h = Math.max(mergedCandle.h, currentCandle.h);
            mergedCandle.l = Math.min(mergedCandle.l, currentCandle.l);
            mergedCandle.c = (i == nAgoEnd) ? currentCandle.c : mergedCandle.c;
            mergedCandle.v += currentCandle.v;
            // mergedCandle.ts = Math.max(currentCandle.ts, mergedCandle.ts);
            // mergedCandle.td += currentCandle.td;
        }

        return mergedCandle;
    }

    this.getCandleObj = function(n){
        var i = (_this.index-n+maxPeriods)%maxPeriods;
        return {
            open: _this.o[i],
            high: _this.h[i],
            low: _this.l[i],
            close: _this.c[i],
            volume: _this.v[i],
            bid: _this.b[i],
            ask: _this.a[i],
            bidSize: _this.bs[i],
            askSize: _this.as[i],
            timeDelta: _this.td[i],
            timestamp: _this.ts[i]
        }
    }

    return this;
}