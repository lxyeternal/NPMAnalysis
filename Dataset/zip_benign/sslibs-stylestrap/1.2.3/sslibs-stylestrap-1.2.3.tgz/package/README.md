# Stylestrap

## Installation

`npm i sslibs-stylestrap`

## Usage

Create a variables file:

`src/app/app.styles.scss`
```scss
$primary: #2674fb;
$primary-light: #73a2ff;
$primary-lighter: rgba(115, 162, 255, 0.4);
$primary-dark: #004ac7;
$primary-white: #f1f9ff;
$secondary: #7e44f6;
$danger: #fb2626;
$danger-dark: rgba(251, 38, 38, 0.4);
$pure-white: #fff;
$white: #fafafa;
$white-translucent: rgba(255, 255, 255, 0.733);
$grey-1: #e5e5e5;
$grey-2: #cecece;
$grey-3: #7f7f7f;
$grey-4: #707070;
$grey-5: #505050;
$grey-6: #444444;
$grey-7: #333333;
$grey-8: #222222;
$black: #242424;
$black-dark: rgba(0, 0, 0, 0.16);
$focus: rgba(0, 74, 199, 0.4);
$success: #97d266;
$success-dark: rgba(151, 210, 102, 0.4);
$success-border: #d5e6c7;
$warning: #f0ad4e;
$warning-border: #ffe5c1;

$header-height: 64px;
$mobile-breakpoint: 1080px;

```

Add this to your main stylesheet:

`src/styles.scss`
```scss
/**
 * Stylestrap
 */
@import '../node_modules/sslibs-stylestrap/stylestrap.scss';

/**
 * App Styles
 */
@import './app/app.styles.scss';
```
