import { OnInit } from '@angular/core';
export declare class PreviewComponent implements OnInit {
    constructor();
    ngOnInit(): void;
}
