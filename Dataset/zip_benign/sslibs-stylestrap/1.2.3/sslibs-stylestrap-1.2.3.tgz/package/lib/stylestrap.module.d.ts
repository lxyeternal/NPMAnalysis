export declare class StylestrapModule {
}
