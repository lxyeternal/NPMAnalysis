# Stylestrap

## [1.2.3] Nov-22-2019

### Fixes
- Change alpha-hex to rgba
- npm update

## [1.2.2] Oct-01-2019

### Fixes
- [Issue #63] Must set editor-header h1 line-height
- [Issue #64] App header should be higher z-index than editor-header
- [Issue #67] Button whitespace nowrap should only be active on desktop

## [1.2.1] Sep-17-2019

### Fixes
- [Issue #58] Footer should be at bottom of page, even on empty pages
- [Issue #59] Page single editor toolbar needs margin-top
- Added $footer-height scss variable

## [1.2.0] Sep-13-2019

### Additions
- [Issue #51] Add CKE style
- [Issue #54] Add input-group

### Fixes
- [Issue #47] Editor-header should use $header-height
- [Issue #50] Toolbar item should have hover-effect
- [Issue #52] Buttons should have no text-decoration
- [Issue #53] Remove footer flex

## [1.1.0] Sep-10-2019

### Additions
- Added `header-height` variable
- [Issue #42] Add toolbar style

### Fixes
- [Issue #45] Header & footer should not be selectable
- [Issue #44] Remove box-shadow from inputs
- [Issue #41] Update editor-button
- [Issue #40] Editor header text should truncate properly
- [Issue #39] Links with button class don't get hover effect

## [1.0.0] Aug-24-2019

### Breaking Changes
- [Issue #33] Remove header header-bg/clear style

## [0.2.0] Aug-24-2019

### Additions
- [Issue #29] Create editor-header button class

### Fixes
- [Issue #32] Use font-display: swap

## [0.1.0] Aug-09-2019

### Additions
- Added full-width editor pages
	- Added `.editor-header`
	- Added `.editor-region`

## [0.0.13] Aug-04-2019

### Fixes
- Cleanup
- [Issue #25] [Stylestrap] nav color should be pure-white

## [0.0.12] Jul-25-2019

### Fixes
- Button color hotfix

## [0.0.11] Jul-25-2019

### Fixes
- mat-menu link color hotfix

## [0.0.10] Jul-25-2019

### Fixes
- [Issue #21] Fix modal window scroll
- [Issue #20] Cleanup archive-controls search on mobile
- [Issue #16] Visited link color should not unset

## [0.0.9] Jul-13-2019

### Fixes
- [Issue #14] Modal body has excess padding
- [Issue #13] Error message text alert colors are off

## [0.0.8] Jul-07-2019

### Fixes
- [Issue #11] Searchform button should set flex
- [Issue #10] Input type search should not show validation colors
- [Issue #9] Button outline radius should match border radius

## [0.0.7] Jul-05-2019

### Fixes
- [Issue #7] Dress up search boxes
- [Issue #6] Router outlet should have min-height equal to header

## [0.0.6] Jul-03-2019

### Fixes
- Archive page `.mat-sort-header-button` should not inherit button background-color

## [0.0.5] Jul-01-2019

### Fixes
- Archive page `.mat-sort-header-button` should not inherit button background-color

## [0.0.4] Jul-01-2019

### Fixes
- [Issue #4] Adjust alert icon
- [Issue #3] Modal body needs less padding on mobile

## [0.0.3] Jun-25-2019 - Mat-Select Trigger

### Fixes
- Fixed unclickable select input area
- Updated alerts and error-message-text

## [0.0.2] Jun-25-2019 - Cleanup

### Fixes
- Fixed mat-checkbox wrap
- Fixed fonts
- Added $border-radius
- Added $grey-8

## [0.0.1] Jun-24-2019 - Initial Release
