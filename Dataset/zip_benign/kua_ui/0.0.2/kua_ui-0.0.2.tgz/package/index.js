let Look = require('./src/Look')
let k = require('./src/k')
let Snip = require('./src/Snip')
let TSR = require('./src/TSR')
let { Btn, BtnClass } = require('./src/Btn')
let { Box, BoxClass } = require('./src/Box')
let {Inpit, InpitClass} = require('./src/Inpit')
let Anim = require('./src/Anim')
let Navigation = require('./src/Navigation')
module.exports = {
	Look,
	k,
	Snip,
	Box, BoxClass,
	Btn, BtnClass,
	Inpit, InpitClass,
	TSR,
	Anim,
	Navigation,
}
