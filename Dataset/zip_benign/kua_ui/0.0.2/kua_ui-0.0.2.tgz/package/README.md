#Anim 使用方法
// 参数说明
let an = Anim.init($time, $func(value), $ease)
an.play($callbackFunction)

// 例子
let an = Anim.init(0.4, (p) => {
	this.setState({
		selected: 1 * p
	})
})
an.replay = 5 //重放5次
an.play(()=>{console.log('end')})
an.stop()

// 使用序列播放动画
let anq = Anim.queue()
anq.anims = [an1, an2]
anq.play()

# Look 使用方法
```
// 创建一个观察者单例 looker.js
let { Look } = require('../kua_ui')
let looker = Look.init()
let keys = {
	move: 'move',
}
module.exports = { looker, keys }

// in React
// 添加一个key, state
looker.bindValue(keys.move, { x: 0 })

// 添加一个观察者listen, 它会等待trigger触发
looker.listen(keys.move, (value) => {
	// 做一些事情,例如修改某个state
	this.setState({ x: value })
	//修改key对应的state
	looker.bindValue(keys.move, { x: value })
})

// 触发某一个key
looker.trigger(keys.move, 1)
```

# Lang.js
```
let changeLanguage =  function(str){
	let end = {}
	if (str === 'en') {
		end = {...lang_en}
	}
	else if (str === 'jp') {
		end = {...lang_jp}
	}
	return end
}

let Lang = {
	language:'cn',
	changeLanguage: changeLanguage,
	menu:'菜单',
}

let lang_en = {
	...Lang,
	menu:'menu',
}

let lang_jp = {
	...Lang,
	menu:'jp',
}

module.exports = Lang
```