let TSR = require('./TSR')
let Navigation = {
	init(now=document.documentElement, next=document.documentElement){
		let child = {
			push(){
				let bodyColor = document.body.style.backgroundColor
				document.body.style.backgroundColor = '#000'

				now.style = {
					transform: TSR([-300, 0, 0], null, null)
				}
				next.style = {
					transform: TSR([-200, 0, 0], null, null)
				}
			}
		}
		return child
	},
}

module.exports = Navigation