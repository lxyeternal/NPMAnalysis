/* eslint-disable */
const React = require('react')
const k = require('./k')
const Snip = require('./Snip')
const {Box} = require('./Box')

let BtnClass = {
	css: {},
	rest: {},
	getDefaultProps() {
		return {
			...Snip.props,
			doTouchEnter() { },
			doTouchDown() { },
			doTouchMove() { },
			doTouchUp() { },
		}
	},
	componentWillMount() {
		this.init()
	},
	render() {
		let t = this
		return (
			<Box {...t.rest}>{t.props.children}</Box>
		)
	},
	init() {
		if (!k.pc) {
			this.rest = Snip.props || {
				...this.rest,
				onTouchStart: this.props.doTouchDown,
				onTouchEnd: this.props.doTouchUp,
				// onTouchCancel: this.props.touchEnd,
				onTouchMove: this.props.doTouchMove,
			}
		} else {
			this.rest = Snip.props || {
				...this.rest,
				onMouseEnter: this.props.doTouchEnter,
				// onMouseLeave: this.props.touchEnd,
				onMouseDown: this.props.doTouchDown,
				onMouseUp: this.props.doTouchUp,
				onMouseMove: this.props.doTouchMove,
			}
		}
		this.css = {
			cursor: 'pointer',
		}
	},
	componentWillUpdate(){
		const { style, doTouchDown, doTouchUp, doTouchEnter, doTouchMove, ...rest } = this.props
		this.css = {
			...this.css,
			...style
		}
		this.rest = {
			...this.rest,
			...rest,
			style: this.css
		}
	},
}

const Btn = React.createClass(BtnClass)
module.exports = {BtnClass, Btn}


